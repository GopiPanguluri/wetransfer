<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-05-22 00:46:03 --> Config Class Initialized
INFO - 2018-05-22 00:46:03 --> Hooks Class Initialized
DEBUG - 2018-05-22 00:46:03 --> UTF-8 Support Enabled
INFO - 2018-05-22 00:46:03 --> Utf8 Class Initialized
INFO - 2018-05-22 00:46:03 --> URI Class Initialized
INFO - 2018-05-22 00:46:03 --> Router Class Initialized
INFO - 2018-05-22 00:46:03 --> Output Class Initialized
INFO - 2018-05-22 00:46:03 --> Security Class Initialized
DEBUG - 2018-05-22 00:46:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 00:46:04 --> Input Class Initialized
INFO - 2018-05-22 00:46:04 --> Language Class Initialized
ERROR - 2018-05-22 00:46:04 --> 404 Page Not Found: /index
INFO - 2018-05-22 00:46:05 --> Config Class Initialized
INFO - 2018-05-22 00:46:05 --> Config Class Initialized
INFO - 2018-05-22 00:46:05 --> Hooks Class Initialized
INFO - 2018-05-22 00:46:05 --> Hooks Class Initialized
DEBUG - 2018-05-22 00:46:05 --> UTF-8 Support Enabled
DEBUG - 2018-05-22 00:46:05 --> UTF-8 Support Enabled
INFO - 2018-05-22 00:46:05 --> Utf8 Class Initialized
INFO - 2018-05-22 00:46:05 --> Utf8 Class Initialized
INFO - 2018-05-22 00:46:05 --> URI Class Initialized
INFO - 2018-05-22 00:46:05 --> URI Class Initialized
INFO - 2018-05-22 00:46:05 --> Router Class Initialized
INFO - 2018-05-22 00:46:05 --> Output Class Initialized
INFO - 2018-05-22 00:46:05 --> Router Class Initialized
INFO - 2018-05-22 00:46:05 --> Security Class Initialized
INFO - 2018-05-22 00:46:05 --> Output Class Initialized
INFO - 2018-05-22 00:46:05 --> Security Class Initialized
DEBUG - 2018-05-22 00:46:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-22 00:46:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 00:46:05 --> Input Class Initialized
INFO - 2018-05-22 00:46:05 --> Input Class Initialized
INFO - 2018-05-22 00:46:05 --> Language Class Initialized
INFO - 2018-05-22 00:46:05 --> Language Class Initialized
ERROR - 2018-05-22 00:46:05 --> 404 Page Not Found: /index
ERROR - 2018-05-22 00:46:05 --> 404 Page Not Found: /index
INFO - 2018-05-22 00:46:05 --> Config Class Initialized
INFO - 2018-05-22 00:46:06 --> Hooks Class Initialized
DEBUG - 2018-05-22 00:46:06 --> UTF-8 Support Enabled
INFO - 2018-05-22 00:46:06 --> Utf8 Class Initialized
INFO - 2018-05-22 00:46:06 --> URI Class Initialized
INFO - 2018-05-22 00:46:06 --> Router Class Initialized
INFO - 2018-05-22 00:46:06 --> Output Class Initialized
INFO - 2018-05-22 00:46:06 --> Security Class Initialized
DEBUG - 2018-05-22 00:46:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 00:46:06 --> Input Class Initialized
INFO - 2018-05-22 00:46:06 --> Language Class Initialized
ERROR - 2018-05-22 00:46:06 --> 404 Page Not Found: /index
INFO - 2018-05-22 00:46:06 --> Config Class Initialized
INFO - 2018-05-22 00:46:06 --> Hooks Class Initialized
DEBUG - 2018-05-22 00:46:06 --> UTF-8 Support Enabled
INFO - 2018-05-22 00:46:06 --> Utf8 Class Initialized
INFO - 2018-05-22 00:46:06 --> URI Class Initialized
INFO - 2018-05-22 00:46:06 --> Router Class Initialized
INFO - 2018-05-22 00:46:06 --> Output Class Initialized
INFO - 2018-05-22 00:46:06 --> Security Class Initialized
DEBUG - 2018-05-22 00:46:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 00:46:06 --> Input Class Initialized
INFO - 2018-05-22 00:46:06 --> Language Class Initialized
ERROR - 2018-05-22 00:46:06 --> 404 Page Not Found: /index
INFO - 2018-05-22 00:46:15 --> Config Class Initialized
INFO - 2018-05-22 00:46:15 --> Hooks Class Initialized
DEBUG - 2018-05-22 00:46:15 --> UTF-8 Support Enabled
INFO - 2018-05-22 00:46:15 --> Utf8 Class Initialized
INFO - 2018-05-22 00:46:15 --> URI Class Initialized
INFO - 2018-05-22 00:46:15 --> Router Class Initialized
INFO - 2018-05-22 00:46:15 --> Output Class Initialized
INFO - 2018-05-22 00:46:15 --> Security Class Initialized
DEBUG - 2018-05-22 00:46:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 00:46:15 --> Input Class Initialized
INFO - 2018-05-22 00:46:15 --> Language Class Initialized
INFO - 2018-05-22 00:46:15 --> Language Class Initialized
INFO - 2018-05-22 00:46:15 --> Config Class Initialized
INFO - 2018-05-22 00:46:15 --> Loader Class Initialized
DEBUG - 2018-05-22 00:46:15 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 00:46:15 --> Helper loaded: url_helper
INFO - 2018-05-22 00:46:15 --> Helper loaded: form_helper
INFO - 2018-05-22 00:46:15 --> Helper loaded: date_helper
INFO - 2018-05-22 00:46:15 --> Helper loaded: util_helper
INFO - 2018-05-22 00:46:15 --> Helper loaded: text_helper
INFO - 2018-05-22 00:46:15 --> Helper loaded: string_helper
INFO - 2018-05-22 00:46:15 --> Database Driver Class Initialized
DEBUG - 2018-05-22 00:46:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 00:46:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 00:46:15 --> Email Class Initialized
INFO - 2018-05-22 00:46:15 --> Controller Class Initialized
DEBUG - 2018-05-22 00:46:15 --> Admin MX_Controller Initialized
INFO - 2018-05-22 00:46:15 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 00:46:15 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 00:46:15 --> Login MX_Controller Initialized
DEBUG - 2018-05-22 00:46:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 00:46:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-22 00:46:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-22 00:46:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-22 00:46:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-22 00:46:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-22 00:46:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-22 00:46:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/dashboard.php
INFO - 2018-05-22 00:46:16 --> Final output sent to browser
DEBUG - 2018-05-22 00:46:16 --> Total execution time: 0.3822
INFO - 2018-05-22 00:46:16 --> Config Class Initialized
INFO - 2018-05-22 00:46:16 --> Hooks Class Initialized
DEBUG - 2018-05-22 00:46:16 --> UTF-8 Support Enabled
INFO - 2018-05-22 00:46:16 --> Utf8 Class Initialized
INFO - 2018-05-22 00:46:16 --> URI Class Initialized
INFO - 2018-05-22 00:46:16 --> Router Class Initialized
INFO - 2018-05-22 00:46:16 --> Output Class Initialized
INFO - 2018-05-22 00:46:16 --> Security Class Initialized
DEBUG - 2018-05-22 00:46:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 00:46:16 --> Input Class Initialized
INFO - 2018-05-22 00:46:16 --> Language Class Initialized
ERROR - 2018-05-22 00:46:16 --> 404 Page Not Found: /index
INFO - 2018-05-22 00:46:16 --> Config Class Initialized
INFO - 2018-05-22 00:46:16 --> Hooks Class Initialized
DEBUG - 2018-05-22 00:46:16 --> UTF-8 Support Enabled
INFO - 2018-05-22 00:46:16 --> Utf8 Class Initialized
INFO - 2018-05-22 00:46:16 --> URI Class Initialized
INFO - 2018-05-22 00:46:16 --> Router Class Initialized
INFO - 2018-05-22 00:46:16 --> Output Class Initialized
INFO - 2018-05-22 00:46:16 --> Security Class Initialized
DEBUG - 2018-05-22 00:46:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 00:46:16 --> Input Class Initialized
INFO - 2018-05-22 00:46:16 --> Language Class Initialized
ERROR - 2018-05-22 00:46:16 --> 404 Page Not Found: /index
INFO - 2018-05-22 00:50:38 --> Config Class Initialized
INFO - 2018-05-22 00:50:38 --> Hooks Class Initialized
DEBUG - 2018-05-22 00:50:38 --> UTF-8 Support Enabled
INFO - 2018-05-22 00:50:38 --> Utf8 Class Initialized
INFO - 2018-05-22 00:50:38 --> URI Class Initialized
INFO - 2018-05-22 00:50:38 --> Router Class Initialized
INFO - 2018-05-22 00:50:38 --> Output Class Initialized
INFO - 2018-05-22 00:50:38 --> Security Class Initialized
DEBUG - 2018-05-22 00:50:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 00:50:38 --> Input Class Initialized
INFO - 2018-05-22 00:50:38 --> Language Class Initialized
INFO - 2018-05-22 00:50:38 --> Language Class Initialized
INFO - 2018-05-22 00:50:38 --> Config Class Initialized
INFO - 2018-05-22 00:50:38 --> Loader Class Initialized
DEBUG - 2018-05-22 00:50:38 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 00:50:38 --> Helper loaded: url_helper
INFO - 2018-05-22 00:50:38 --> Helper loaded: form_helper
INFO - 2018-05-22 00:50:38 --> Helper loaded: date_helper
INFO - 2018-05-22 00:50:38 --> Helper loaded: util_helper
INFO - 2018-05-22 00:50:38 --> Helper loaded: text_helper
INFO - 2018-05-22 00:50:38 --> Helper loaded: string_helper
INFO - 2018-05-22 00:50:39 --> Database Driver Class Initialized
DEBUG - 2018-05-22 00:50:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 00:50:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 00:50:39 --> Email Class Initialized
INFO - 2018-05-22 00:50:39 --> Controller Class Initialized
DEBUG - 2018-05-22 00:50:39 --> Profile MX_Controller Initialized
DEBUG - 2018-05-22 00:50:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 00:50:39 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 00:50:39 --> Login MX_Controller Initialized
INFO - 2018-05-22 00:50:39 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 00:50:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 00:50:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-22 00:50:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-22 00:50:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-22 00:50:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-22 00:50:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-05-22 00:50:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-22 00:50:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-22 00:50:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/reset_password.php
INFO - 2018-05-22 00:50:39 --> Final output sent to browser
DEBUG - 2018-05-22 00:50:39 --> Total execution time: 0.6385
INFO - 2018-05-22 00:50:40 --> Config Class Initialized
INFO - 2018-05-22 00:50:40 --> Hooks Class Initialized
DEBUG - 2018-05-22 00:50:41 --> UTF-8 Support Enabled
INFO - 2018-05-22 00:50:41 --> Utf8 Class Initialized
INFO - 2018-05-22 00:50:41 --> URI Class Initialized
INFO - 2018-05-22 00:50:41 --> Router Class Initialized
INFO - 2018-05-22 00:50:41 --> Output Class Initialized
INFO - 2018-05-22 00:50:41 --> Security Class Initialized
DEBUG - 2018-05-22 00:50:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 00:50:41 --> Input Class Initialized
INFO - 2018-05-22 00:50:41 --> Language Class Initialized
ERROR - 2018-05-22 00:50:41 --> 404 Page Not Found: /index
INFO - 2018-05-22 00:50:41 --> Config Class Initialized
INFO - 2018-05-22 00:50:41 --> Hooks Class Initialized
DEBUG - 2018-05-22 00:50:41 --> UTF-8 Support Enabled
INFO - 2018-05-22 00:50:41 --> Utf8 Class Initialized
INFO - 2018-05-22 00:50:41 --> URI Class Initialized
INFO - 2018-05-22 00:50:41 --> Router Class Initialized
INFO - 2018-05-22 00:50:41 --> Output Class Initialized
INFO - 2018-05-22 00:50:41 --> Security Class Initialized
DEBUG - 2018-05-22 00:50:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 00:50:41 --> Input Class Initialized
INFO - 2018-05-22 00:50:41 --> Language Class Initialized
ERROR - 2018-05-22 00:50:41 --> 404 Page Not Found: /index
INFO - 2018-05-22 00:50:41 --> Config Class Initialized
INFO - 2018-05-22 00:50:41 --> Hooks Class Initialized
DEBUG - 2018-05-22 00:50:41 --> UTF-8 Support Enabled
INFO - 2018-05-22 00:50:41 --> Utf8 Class Initialized
INFO - 2018-05-22 00:50:41 --> URI Class Initialized
INFO - 2018-05-22 00:50:41 --> Router Class Initialized
INFO - 2018-05-22 00:50:41 --> Output Class Initialized
INFO - 2018-05-22 00:50:41 --> Security Class Initialized
DEBUG - 2018-05-22 00:50:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 00:50:41 --> Input Class Initialized
INFO - 2018-05-22 00:50:41 --> Language Class Initialized
ERROR - 2018-05-22 00:50:41 --> 404 Page Not Found: /index
INFO - 2018-05-22 00:50:41 --> Config Class Initialized
INFO - 2018-05-22 00:50:42 --> Hooks Class Initialized
DEBUG - 2018-05-22 00:50:42 --> UTF-8 Support Enabled
INFO - 2018-05-22 00:50:42 --> Utf8 Class Initialized
INFO - 2018-05-22 00:50:42 --> URI Class Initialized
INFO - 2018-05-22 00:50:42 --> Router Class Initialized
INFO - 2018-05-22 00:50:42 --> Output Class Initialized
INFO - 2018-05-22 00:50:42 --> Security Class Initialized
DEBUG - 2018-05-22 00:50:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 00:50:42 --> Input Class Initialized
INFO - 2018-05-22 00:50:42 --> Language Class Initialized
ERROR - 2018-05-22 00:50:42 --> 404 Page Not Found: /index
INFO - 2018-05-22 00:50:42 --> Config Class Initialized
INFO - 2018-05-22 00:50:42 --> Hooks Class Initialized
DEBUG - 2018-05-22 00:50:42 --> UTF-8 Support Enabled
INFO - 2018-05-22 00:50:42 --> Utf8 Class Initialized
INFO - 2018-05-22 00:50:42 --> URI Class Initialized
INFO - 2018-05-22 00:50:42 --> Router Class Initialized
INFO - 2018-05-22 00:50:42 --> Output Class Initialized
INFO - 2018-05-22 00:50:42 --> Security Class Initialized
DEBUG - 2018-05-22 00:50:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 00:50:42 --> Input Class Initialized
INFO - 2018-05-22 00:50:42 --> Language Class Initialized
ERROR - 2018-05-22 00:50:42 --> 404 Page Not Found: /index
INFO - 2018-05-22 00:50:42 --> Config Class Initialized
INFO - 2018-05-22 00:50:42 --> Hooks Class Initialized
DEBUG - 2018-05-22 00:50:42 --> UTF-8 Support Enabled
INFO - 2018-05-22 00:50:42 --> Utf8 Class Initialized
INFO - 2018-05-22 00:50:42 --> URI Class Initialized
INFO - 2018-05-22 00:50:42 --> Router Class Initialized
INFO - 2018-05-22 00:50:42 --> Output Class Initialized
INFO - 2018-05-22 00:50:42 --> Security Class Initialized
DEBUG - 2018-05-22 00:50:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 00:50:42 --> Input Class Initialized
INFO - 2018-05-22 00:50:42 --> Language Class Initialized
ERROR - 2018-05-22 00:50:42 --> 404 Page Not Found: /index
INFO - 2018-05-22 00:52:28 --> Config Class Initialized
INFO - 2018-05-22 00:52:28 --> Hooks Class Initialized
DEBUG - 2018-05-22 00:52:28 --> UTF-8 Support Enabled
INFO - 2018-05-22 00:52:29 --> Utf8 Class Initialized
INFO - 2018-05-22 00:52:29 --> URI Class Initialized
INFO - 2018-05-22 00:52:29 --> Router Class Initialized
INFO - 2018-05-22 00:52:29 --> Output Class Initialized
INFO - 2018-05-22 00:52:29 --> Security Class Initialized
DEBUG - 2018-05-22 00:52:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 00:52:29 --> Input Class Initialized
INFO - 2018-05-22 00:52:29 --> Language Class Initialized
INFO - 2018-05-22 00:52:29 --> Language Class Initialized
INFO - 2018-05-22 00:52:29 --> Config Class Initialized
INFO - 2018-05-22 00:52:29 --> Loader Class Initialized
DEBUG - 2018-05-22 00:52:29 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 00:52:29 --> Helper loaded: url_helper
INFO - 2018-05-22 00:52:29 --> Helper loaded: form_helper
INFO - 2018-05-22 00:52:29 --> Helper loaded: date_helper
INFO - 2018-05-22 00:52:29 --> Helper loaded: util_helper
INFO - 2018-05-22 00:52:29 --> Helper loaded: text_helper
INFO - 2018-05-22 00:52:29 --> Helper loaded: string_helper
INFO - 2018-05-22 00:52:29 --> Database Driver Class Initialized
DEBUG - 2018-05-22 00:52:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 00:52:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 00:52:29 --> Email Class Initialized
INFO - 2018-05-22 00:52:29 --> Controller Class Initialized
DEBUG - 2018-05-22 00:52:29 --> Profile MX_Controller Initialized
DEBUG - 2018-05-22 00:52:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 00:52:29 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 00:52:29 --> Login MX_Controller Initialized
INFO - 2018-05-22 00:52:29 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 00:52:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 00:52:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-22 00:52:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-22 00:52:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-22 00:52:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-22 00:52:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-05-22 00:52:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-22 00:52:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-22 00:52:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/reset_password.php
INFO - 2018-05-22 00:52:29 --> Final output sent to browser
DEBUG - 2018-05-22 00:52:29 --> Total execution time: 0.5138
INFO - 2018-05-22 00:52:30 --> Config Class Initialized
INFO - 2018-05-22 00:52:30 --> Hooks Class Initialized
DEBUG - 2018-05-22 00:52:30 --> UTF-8 Support Enabled
INFO - 2018-05-22 00:52:30 --> Utf8 Class Initialized
INFO - 2018-05-22 00:52:30 --> URI Class Initialized
INFO - 2018-05-22 00:52:30 --> Router Class Initialized
INFO - 2018-05-22 00:52:30 --> Output Class Initialized
INFO - 2018-05-22 00:52:30 --> Security Class Initialized
DEBUG - 2018-05-22 00:52:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 00:52:30 --> Input Class Initialized
INFO - 2018-05-22 00:52:30 --> Language Class Initialized
ERROR - 2018-05-22 00:52:30 --> 404 Page Not Found: /index
INFO - 2018-05-22 00:52:30 --> Config Class Initialized
INFO - 2018-05-22 00:52:30 --> Hooks Class Initialized
DEBUG - 2018-05-22 00:52:30 --> UTF-8 Support Enabled
INFO - 2018-05-22 00:52:30 --> Utf8 Class Initialized
INFO - 2018-05-22 00:52:30 --> URI Class Initialized
INFO - 2018-05-22 00:52:30 --> Router Class Initialized
INFO - 2018-05-22 00:52:30 --> Output Class Initialized
INFO - 2018-05-22 00:52:30 --> Security Class Initialized
DEBUG - 2018-05-22 00:52:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 00:52:31 --> Input Class Initialized
INFO - 2018-05-22 00:52:31 --> Language Class Initialized
ERROR - 2018-05-22 00:52:31 --> 404 Page Not Found: /index
INFO - 2018-05-22 00:52:31 --> Config Class Initialized
INFO - 2018-05-22 00:52:31 --> Hooks Class Initialized
DEBUG - 2018-05-22 00:52:31 --> UTF-8 Support Enabled
INFO - 2018-05-22 00:52:31 --> Utf8 Class Initialized
INFO - 2018-05-22 00:52:31 --> URI Class Initialized
INFO - 2018-05-22 00:52:31 --> Router Class Initialized
INFO - 2018-05-22 00:52:31 --> Output Class Initialized
INFO - 2018-05-22 00:52:31 --> Security Class Initialized
DEBUG - 2018-05-22 00:52:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 00:52:31 --> Input Class Initialized
INFO - 2018-05-22 00:52:31 --> Language Class Initialized
ERROR - 2018-05-22 00:52:31 --> 404 Page Not Found: /index
INFO - 2018-05-22 00:52:47 --> Config Class Initialized
INFO - 2018-05-22 00:52:47 --> Hooks Class Initialized
DEBUG - 2018-05-22 00:52:47 --> UTF-8 Support Enabled
INFO - 2018-05-22 00:52:47 --> Utf8 Class Initialized
INFO - 2018-05-22 00:52:47 --> URI Class Initialized
INFO - 2018-05-22 00:52:47 --> Router Class Initialized
INFO - 2018-05-22 00:52:47 --> Output Class Initialized
INFO - 2018-05-22 00:52:47 --> Security Class Initialized
DEBUG - 2018-05-22 00:52:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 00:52:47 --> Input Class Initialized
INFO - 2018-05-22 00:52:47 --> Language Class Initialized
INFO - 2018-05-22 00:52:47 --> Language Class Initialized
INFO - 2018-05-22 00:52:47 --> Config Class Initialized
INFO - 2018-05-22 00:52:47 --> Loader Class Initialized
DEBUG - 2018-05-22 00:52:47 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 00:52:47 --> Helper loaded: url_helper
INFO - 2018-05-22 00:52:47 --> Helper loaded: form_helper
INFO - 2018-05-22 00:52:47 --> Helper loaded: date_helper
INFO - 2018-05-22 00:52:47 --> Helper loaded: util_helper
INFO - 2018-05-22 00:52:47 --> Helper loaded: text_helper
INFO - 2018-05-22 00:52:47 --> Helper loaded: string_helper
INFO - 2018-05-22 00:52:48 --> Database Driver Class Initialized
DEBUG - 2018-05-22 00:52:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 00:52:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 00:52:48 --> Email Class Initialized
INFO - 2018-05-22 00:52:48 --> Controller Class Initialized
DEBUG - 2018-05-22 00:52:48 --> Profile MX_Controller Initialized
DEBUG - 2018-05-22 00:52:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 00:52:48 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 00:52:48 --> Login MX_Controller Initialized
INFO - 2018-05-22 00:52:48 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 00:52:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 00:52:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-22 00:56:03 --> Config Class Initialized
INFO - 2018-05-22 00:56:03 --> Hooks Class Initialized
DEBUG - 2018-05-22 00:56:03 --> UTF-8 Support Enabled
INFO - 2018-05-22 00:56:03 --> Utf8 Class Initialized
INFO - 2018-05-22 00:56:03 --> URI Class Initialized
INFO - 2018-05-22 00:56:03 --> Router Class Initialized
INFO - 2018-05-22 00:56:03 --> Output Class Initialized
INFO - 2018-05-22 00:56:03 --> Security Class Initialized
DEBUG - 2018-05-22 00:56:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 00:56:03 --> Input Class Initialized
INFO - 2018-05-22 00:56:03 --> Language Class Initialized
INFO - 2018-05-22 00:56:03 --> Language Class Initialized
INFO - 2018-05-22 00:56:03 --> Config Class Initialized
INFO - 2018-05-22 00:56:03 --> Loader Class Initialized
DEBUG - 2018-05-22 00:56:03 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 00:56:03 --> Helper loaded: url_helper
INFO - 2018-05-22 00:56:03 --> Helper loaded: form_helper
INFO - 2018-05-22 00:56:03 --> Helper loaded: date_helper
INFO - 2018-05-22 00:56:04 --> Helper loaded: util_helper
INFO - 2018-05-22 00:56:04 --> Helper loaded: text_helper
INFO - 2018-05-22 00:56:04 --> Helper loaded: string_helper
INFO - 2018-05-22 00:56:04 --> Database Driver Class Initialized
DEBUG - 2018-05-22 00:56:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 00:56:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 00:56:04 --> Email Class Initialized
INFO - 2018-05-22 00:56:04 --> Controller Class Initialized
DEBUG - 2018-05-22 00:56:04 --> Profile MX_Controller Initialized
INFO - 2018-05-22 00:56:04 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 00:56:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 00:56:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Profile_model.php
DEBUG - 2018-05-22 00:56:04 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 00:56:04 --> Login MX_Controller Initialized
DEBUG - 2018-05-22 00:56:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-22 00:56:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-22 00:56:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-22 00:56:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-22 00:56:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-22 00:56:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-22 00:56:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/admin_password.php
INFO - 2018-05-22 00:56:04 --> Final output sent to browser
DEBUG - 2018-05-22 00:56:04 --> Total execution time: 0.3505
INFO - 2018-05-22 00:59:38 --> Config Class Initialized
INFO - 2018-05-22 00:59:38 --> Hooks Class Initialized
DEBUG - 2018-05-22 00:59:38 --> UTF-8 Support Enabled
INFO - 2018-05-22 00:59:38 --> Utf8 Class Initialized
INFO - 2018-05-22 00:59:38 --> URI Class Initialized
INFO - 2018-05-22 00:59:38 --> Router Class Initialized
INFO - 2018-05-22 00:59:38 --> Output Class Initialized
INFO - 2018-05-22 00:59:38 --> Security Class Initialized
DEBUG - 2018-05-22 00:59:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 00:59:38 --> Input Class Initialized
INFO - 2018-05-22 00:59:38 --> Language Class Initialized
INFO - 2018-05-22 00:59:38 --> Language Class Initialized
INFO - 2018-05-22 00:59:38 --> Config Class Initialized
INFO - 2018-05-22 00:59:38 --> Loader Class Initialized
DEBUG - 2018-05-22 00:59:38 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 00:59:38 --> Helper loaded: url_helper
INFO - 2018-05-22 00:59:38 --> Helper loaded: form_helper
INFO - 2018-05-22 00:59:38 --> Helper loaded: date_helper
INFO - 2018-05-22 00:59:38 --> Helper loaded: util_helper
INFO - 2018-05-22 00:59:38 --> Helper loaded: text_helper
INFO - 2018-05-22 00:59:38 --> Helper loaded: string_helper
INFO - 2018-05-22 00:59:38 --> Database Driver Class Initialized
DEBUG - 2018-05-22 00:59:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 00:59:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 00:59:38 --> Email Class Initialized
INFO - 2018-05-22 00:59:38 --> Controller Class Initialized
DEBUG - 2018-05-22 00:59:38 --> Profile MX_Controller Initialized
DEBUG - 2018-05-22 00:59:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 00:59:38 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 00:59:38 --> Login MX_Controller Initialized
INFO - 2018-05-22 00:59:38 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 00:59:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 00:59:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-22 00:59:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-22 00:59:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-22 00:59:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-22 00:59:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-05-22 00:59:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-22 00:59:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-22 00:59:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/reset_password.php
INFO - 2018-05-22 00:59:38 --> Final output sent to browser
DEBUG - 2018-05-22 00:59:38 --> Total execution time: 0.4295
INFO - 2018-05-22 00:59:40 --> Config Class Initialized
INFO - 2018-05-22 00:59:40 --> Hooks Class Initialized
DEBUG - 2018-05-22 00:59:40 --> UTF-8 Support Enabled
INFO - 2018-05-22 00:59:40 --> Utf8 Class Initialized
INFO - 2018-05-22 00:59:40 --> URI Class Initialized
INFO - 2018-05-22 00:59:40 --> Router Class Initialized
INFO - 2018-05-22 00:59:40 --> Output Class Initialized
INFO - 2018-05-22 00:59:40 --> Security Class Initialized
DEBUG - 2018-05-22 00:59:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 00:59:40 --> Input Class Initialized
INFO - 2018-05-22 00:59:40 --> Language Class Initialized
ERROR - 2018-05-22 00:59:40 --> 404 Page Not Found: /index
INFO - 2018-05-22 00:59:40 --> Config Class Initialized
INFO - 2018-05-22 00:59:40 --> Hooks Class Initialized
DEBUG - 2018-05-22 00:59:40 --> UTF-8 Support Enabled
INFO - 2018-05-22 00:59:40 --> Utf8 Class Initialized
INFO - 2018-05-22 00:59:40 --> URI Class Initialized
INFO - 2018-05-22 00:59:41 --> Router Class Initialized
INFO - 2018-05-22 00:59:41 --> Output Class Initialized
INFO - 2018-05-22 00:59:41 --> Security Class Initialized
DEBUG - 2018-05-22 00:59:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 00:59:41 --> Input Class Initialized
INFO - 2018-05-22 00:59:41 --> Language Class Initialized
ERROR - 2018-05-22 00:59:41 --> 404 Page Not Found: /index
INFO - 2018-05-22 00:59:41 --> Config Class Initialized
INFO - 2018-05-22 00:59:41 --> Hooks Class Initialized
DEBUG - 2018-05-22 00:59:41 --> UTF-8 Support Enabled
INFO - 2018-05-22 00:59:41 --> Utf8 Class Initialized
INFO - 2018-05-22 00:59:41 --> URI Class Initialized
INFO - 2018-05-22 00:59:41 --> Router Class Initialized
INFO - 2018-05-22 00:59:41 --> Output Class Initialized
INFO - 2018-05-22 00:59:41 --> Security Class Initialized
DEBUG - 2018-05-22 00:59:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 00:59:42 --> Input Class Initialized
INFO - 2018-05-22 00:59:42 --> Language Class Initialized
INFO - 2018-05-22 00:59:42 --> Config Class Initialized
INFO - 2018-05-22 00:59:42 --> Hooks Class Initialized
ERROR - 2018-05-22 00:59:42 --> 404 Page Not Found: /index
DEBUG - 2018-05-22 00:59:42 --> UTF-8 Support Enabled
INFO - 2018-05-22 00:59:42 --> Utf8 Class Initialized
INFO - 2018-05-22 00:59:42 --> URI Class Initialized
INFO - 2018-05-22 00:59:42 --> Router Class Initialized
INFO - 2018-05-22 00:59:42 --> Output Class Initialized
INFO - 2018-05-22 00:59:42 --> Security Class Initialized
DEBUG - 2018-05-22 00:59:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 00:59:42 --> Input Class Initialized
INFO - 2018-05-22 00:59:42 --> Language Class Initialized
ERROR - 2018-05-22 00:59:42 --> 404 Page Not Found: /index
INFO - 2018-05-22 00:59:42 --> Config Class Initialized
INFO - 2018-05-22 00:59:42 --> Hooks Class Initialized
DEBUG - 2018-05-22 00:59:42 --> UTF-8 Support Enabled
INFO - 2018-05-22 00:59:42 --> Utf8 Class Initialized
INFO - 2018-05-22 00:59:42 --> URI Class Initialized
INFO - 2018-05-22 00:59:42 --> Router Class Initialized
INFO - 2018-05-22 00:59:42 --> Output Class Initialized
INFO - 2018-05-22 00:59:42 --> Security Class Initialized
DEBUG - 2018-05-22 00:59:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 00:59:42 --> Input Class Initialized
INFO - 2018-05-22 00:59:42 --> Language Class Initialized
ERROR - 2018-05-22 00:59:42 --> 404 Page Not Found: /index
INFO - 2018-05-22 00:59:42 --> Config Class Initialized
INFO - 2018-05-22 00:59:42 --> Hooks Class Initialized
DEBUG - 2018-05-22 00:59:42 --> UTF-8 Support Enabled
INFO - 2018-05-22 00:59:42 --> Utf8 Class Initialized
INFO - 2018-05-22 00:59:42 --> URI Class Initialized
INFO - 2018-05-22 00:59:42 --> Router Class Initialized
INFO - 2018-05-22 00:59:42 --> Output Class Initialized
INFO - 2018-05-22 00:59:42 --> Security Class Initialized
DEBUG - 2018-05-22 00:59:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 00:59:42 --> Input Class Initialized
INFO - 2018-05-22 00:59:42 --> Language Class Initialized
ERROR - 2018-05-22 00:59:42 --> 404 Page Not Found: /index
INFO - 2018-05-22 00:59:42 --> Config Class Initialized
INFO - 2018-05-22 00:59:42 --> Hooks Class Initialized
DEBUG - 2018-05-22 00:59:42 --> UTF-8 Support Enabled
INFO - 2018-05-22 00:59:42 --> Utf8 Class Initialized
INFO - 2018-05-22 00:59:42 --> URI Class Initialized
INFO - 2018-05-22 00:59:42 --> Router Class Initialized
INFO - 2018-05-22 00:59:42 --> Output Class Initialized
INFO - 2018-05-22 00:59:42 --> Security Class Initialized
DEBUG - 2018-05-22 00:59:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 00:59:43 --> Input Class Initialized
INFO - 2018-05-22 00:59:43 --> Language Class Initialized
ERROR - 2018-05-22 00:59:43 --> 404 Page Not Found: /index
INFO - 2018-05-22 01:03:33 --> Config Class Initialized
INFO - 2018-05-22 01:03:33 --> Hooks Class Initialized
DEBUG - 2018-05-22 01:03:33 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:03:33 --> Utf8 Class Initialized
INFO - 2018-05-22 01:03:33 --> URI Class Initialized
INFO - 2018-05-22 01:03:33 --> Router Class Initialized
INFO - 2018-05-22 01:03:33 --> Output Class Initialized
INFO - 2018-05-22 01:03:33 --> Security Class Initialized
DEBUG - 2018-05-22 01:03:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:03:33 --> Input Class Initialized
INFO - 2018-05-22 01:03:33 --> Language Class Initialized
INFO - 2018-05-22 01:03:33 --> Language Class Initialized
INFO - 2018-05-22 01:03:33 --> Config Class Initialized
INFO - 2018-05-22 01:03:33 --> Loader Class Initialized
DEBUG - 2018-05-22 01:03:33 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 01:03:33 --> Helper loaded: url_helper
INFO - 2018-05-22 01:03:33 --> Helper loaded: form_helper
INFO - 2018-05-22 01:03:33 --> Helper loaded: date_helper
INFO - 2018-05-22 01:03:33 --> Helper loaded: util_helper
INFO - 2018-05-22 01:03:33 --> Helper loaded: text_helper
INFO - 2018-05-22 01:03:33 --> Helper loaded: string_helper
INFO - 2018-05-22 01:03:33 --> Database Driver Class Initialized
DEBUG - 2018-05-22 01:03:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 01:03:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 01:03:33 --> Email Class Initialized
INFO - 2018-05-22 01:03:33 --> Controller Class Initialized
DEBUG - 2018-05-22 01:03:33 --> Profile MX_Controller Initialized
DEBUG - 2018-05-22 01:03:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 01:03:33 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 01:03:33 --> Login MX_Controller Initialized
INFO - 2018-05-22 01:03:33 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 01:03:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 01:03:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-22 01:03:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-22 01:03:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-22 01:03:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-22 01:03:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-05-22 01:03:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-22 01:03:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-22 01:03:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/reset_password.php
INFO - 2018-05-22 01:03:33 --> Final output sent to browser
DEBUG - 2018-05-22 01:03:33 --> Total execution time: 0.5123
INFO - 2018-05-22 01:03:37 --> Config Class Initialized
INFO - 2018-05-22 01:03:37 --> Hooks Class Initialized
INFO - 2018-05-22 01:03:38 --> Config Class Initialized
DEBUG - 2018-05-22 01:03:38 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:03:38 --> Utf8 Class Initialized
INFO - 2018-05-22 01:03:38 --> URI Class Initialized
INFO - 2018-05-22 01:03:38 --> Config Class Initialized
INFO - 2018-05-22 01:03:38 --> Hooks Class Initialized
INFO - 2018-05-22 01:03:38 --> Router Class Initialized
INFO - 2018-05-22 01:03:38 --> Config Class Initialized
INFO - 2018-05-22 01:03:38 --> Hooks Class Initialized
DEBUG - 2018-05-22 01:03:38 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:03:38 --> Config Class Initialized
INFO - 2018-05-22 01:03:38 --> Utf8 Class Initialized
INFO - 2018-05-22 01:03:38 --> URI Class Initialized
INFO - 2018-05-22 01:03:38 --> Router Class Initialized
INFO - 2018-05-22 01:03:38 --> Output Class Initialized
INFO - 2018-05-22 01:03:38 --> Security Class Initialized
DEBUG - 2018-05-22 01:03:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:03:38 --> Input Class Initialized
INFO - 2018-05-22 01:03:38 --> Language Class Initialized
ERROR - 2018-05-22 01:03:38 --> 404 Page Not Found: /index
INFO - 2018-05-22 01:03:38 --> Hooks Class Initialized
INFO - 2018-05-22 01:03:38 --> Hooks Class Initialized
DEBUG - 2018-05-22 01:03:38 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:03:38 --> Output Class Initialized
INFO - 2018-05-22 01:03:38 --> Utf8 Class Initialized
INFO - 2018-05-22 01:03:38 --> Security Class Initialized
INFO - 2018-05-22 01:03:38 --> URI Class Initialized
DEBUG - 2018-05-22 01:03:38 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:03:38 --> Utf8 Class Initialized
DEBUG - 2018-05-22 01:03:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-22 01:03:38 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:03:38 --> URI Class Initialized
INFO - 2018-05-22 01:03:38 --> Input Class Initialized
INFO - 2018-05-22 01:03:38 --> Utf8 Class Initialized
INFO - 2018-05-22 01:03:38 --> Router Class Initialized
INFO - 2018-05-22 01:03:38 --> Output Class Initialized
INFO - 2018-05-22 01:03:38 --> URI Class Initialized
INFO - 2018-05-22 01:03:38 --> Language Class Initialized
INFO - 2018-05-22 01:03:38 --> Router Class Initialized
ERROR - 2018-05-22 01:03:38 --> 404 Page Not Found: /index
INFO - 2018-05-22 01:03:38 --> Output Class Initialized
INFO - 2018-05-22 01:03:38 --> Security Class Initialized
INFO - 2018-05-22 01:03:38 --> Router Class Initialized
DEBUG - 2018-05-22 01:03:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:03:38 --> Output Class Initialized
INFO - 2018-05-22 01:03:38 --> Security Class Initialized
INFO - 2018-05-22 01:03:38 --> Config Class Initialized
INFO - 2018-05-22 01:03:38 --> Hooks Class Initialized
INFO - 2018-05-22 01:03:38 --> Input Class Initialized
DEBUG - 2018-05-22 01:03:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:03:38 --> Security Class Initialized
INFO - 2018-05-22 01:03:38 --> Input Class Initialized
DEBUG - 2018-05-22 01:03:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:03:38 --> Language Class Initialized
DEBUG - 2018-05-22 01:03:38 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:03:38 --> Input Class Initialized
INFO - 2018-05-22 01:03:38 --> Language Class Initialized
ERROR - 2018-05-22 01:03:38 --> 404 Page Not Found: /index
INFO - 2018-05-22 01:03:38 --> Utf8 Class Initialized
ERROR - 2018-05-22 01:03:38 --> 404 Page Not Found: /index
INFO - 2018-05-22 01:03:38 --> Language Class Initialized
INFO - 2018-05-22 01:03:38 --> URI Class Initialized
INFO - 2018-05-22 01:03:38 --> Config Class Initialized
INFO - 2018-05-22 01:03:38 --> Hooks Class Initialized
ERROR - 2018-05-22 01:03:38 --> 404 Page Not Found: /index
INFO - 2018-05-22 01:03:38 --> Router Class Initialized
INFO - 2018-05-22 01:03:38 --> Config Class Initialized
INFO - 2018-05-22 01:03:38 --> Hooks Class Initialized
INFO - 2018-05-22 01:03:38 --> Output Class Initialized
DEBUG - 2018-05-22 01:03:38 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:03:38 --> Config Class Initialized
INFO - 2018-05-22 01:03:38 --> Hooks Class Initialized
INFO - 2018-05-22 01:03:38 --> Security Class Initialized
DEBUG - 2018-05-22 01:03:38 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:03:38 --> Utf8 Class Initialized
INFO - 2018-05-22 01:03:38 --> Utf8 Class Initialized
INFO - 2018-05-22 01:03:38 --> URI Class Initialized
DEBUG - 2018-05-22 01:03:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-22 01:03:38 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:03:38 --> Utf8 Class Initialized
INFO - 2018-05-22 01:03:38 --> URI Class Initialized
INFO - 2018-05-22 01:03:38 --> Input Class Initialized
INFO - 2018-05-22 01:03:38 --> Router Class Initialized
INFO - 2018-05-22 01:03:38 --> URI Class Initialized
INFO - 2018-05-22 01:03:38 --> Language Class Initialized
INFO - 2018-05-22 01:03:38 --> Router Class Initialized
INFO - 2018-05-22 01:03:38 --> Output Class Initialized
INFO - 2018-05-22 01:03:38 --> Router Class Initialized
ERROR - 2018-05-22 01:03:38 --> 404 Page Not Found: /index
INFO - 2018-05-22 01:03:38 --> Security Class Initialized
INFO - 2018-05-22 01:03:38 --> Output Class Initialized
INFO - 2018-05-22 01:03:38 --> Output Class Initialized
DEBUG - 2018-05-22 01:03:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:03:38 --> Config Class Initialized
INFO - 2018-05-22 01:03:38 --> Security Class Initialized
INFO - 2018-05-22 01:03:38 --> Hooks Class Initialized
INFO - 2018-05-22 01:03:38 --> Security Class Initialized
INFO - 2018-05-22 01:03:38 --> Input Class Initialized
DEBUG - 2018-05-22 01:03:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:03:38 --> Language Class Initialized
DEBUG - 2018-05-22 01:03:38 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:03:38 --> Input Class Initialized
DEBUG - 2018-05-22 01:03:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:03:38 --> Utf8 Class Initialized
INFO - 2018-05-22 01:03:38 --> Input Class Initialized
ERROR - 2018-05-22 01:03:38 --> 404 Page Not Found: /index
INFO - 2018-05-22 01:03:38 --> Language Class Initialized
INFO - 2018-05-22 01:03:38 --> URI Class Initialized
INFO - 2018-05-22 01:03:38 --> Language Class Initialized
ERROR - 2018-05-22 01:03:38 --> 404 Page Not Found: /index
INFO - 2018-05-22 01:03:38 --> Router Class Initialized
ERROR - 2018-05-22 01:03:38 --> 404 Page Not Found: /index
INFO - 2018-05-22 01:03:38 --> Output Class Initialized
INFO - 2018-05-22 01:03:38 --> Security Class Initialized
DEBUG - 2018-05-22 01:03:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:03:38 --> Input Class Initialized
INFO - 2018-05-22 01:03:38 --> Language Class Initialized
ERROR - 2018-05-22 01:03:38 --> 404 Page Not Found: /index
INFO - 2018-05-22 01:06:03 --> Config Class Initialized
INFO - 2018-05-22 01:06:03 --> Hooks Class Initialized
DEBUG - 2018-05-22 01:06:03 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:06:03 --> Utf8 Class Initialized
INFO - 2018-05-22 01:06:03 --> URI Class Initialized
INFO - 2018-05-22 01:06:03 --> Router Class Initialized
INFO - 2018-05-22 01:06:03 --> Output Class Initialized
INFO - 2018-05-22 01:06:03 --> Security Class Initialized
DEBUG - 2018-05-22 01:06:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:06:03 --> Input Class Initialized
INFO - 2018-05-22 01:06:03 --> Language Class Initialized
INFO - 2018-05-22 01:06:03 --> Language Class Initialized
INFO - 2018-05-22 01:06:03 --> Config Class Initialized
INFO - 2018-05-22 01:06:03 --> Loader Class Initialized
DEBUG - 2018-05-22 01:06:03 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 01:06:03 --> Helper loaded: url_helper
INFO - 2018-05-22 01:06:03 --> Helper loaded: form_helper
INFO - 2018-05-22 01:06:03 --> Helper loaded: date_helper
INFO - 2018-05-22 01:06:03 --> Helper loaded: util_helper
INFO - 2018-05-22 01:06:03 --> Helper loaded: text_helper
INFO - 2018-05-22 01:06:03 --> Helper loaded: string_helper
INFO - 2018-05-22 01:06:03 --> Database Driver Class Initialized
DEBUG - 2018-05-22 01:06:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 01:06:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 01:06:03 --> Email Class Initialized
INFO - 2018-05-22 01:06:03 --> Controller Class Initialized
DEBUG - 2018-05-22 01:06:03 --> Profile MX_Controller Initialized
DEBUG - 2018-05-22 01:06:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 01:06:03 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 01:06:03 --> Login MX_Controller Initialized
INFO - 2018-05-22 01:06:03 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 01:06:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 01:06:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-22 01:06:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-22 01:06:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-22 01:06:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-22 01:06:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-05-22 01:06:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-22 01:06:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-22 01:06:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/reset_password.php
INFO - 2018-05-22 01:06:03 --> Final output sent to browser
DEBUG - 2018-05-22 01:06:03 --> Total execution time: 0.4466
INFO - 2018-05-22 01:06:05 --> Config Class Initialized
INFO - 2018-05-22 01:06:05 --> Hooks Class Initialized
DEBUG - 2018-05-22 01:06:05 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:06:05 --> Utf8 Class Initialized
INFO - 2018-05-22 01:06:05 --> URI Class Initialized
INFO - 2018-05-22 01:06:05 --> Router Class Initialized
INFO - 2018-05-22 01:06:05 --> Output Class Initialized
INFO - 2018-05-22 01:06:05 --> Security Class Initialized
DEBUG - 2018-05-22 01:06:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:06:05 --> Input Class Initialized
INFO - 2018-05-22 01:06:05 --> Language Class Initialized
ERROR - 2018-05-22 01:06:05 --> 404 Page Not Found: /index
INFO - 2018-05-22 01:06:05 --> Config Class Initialized
INFO - 2018-05-22 01:06:05 --> Hooks Class Initialized
DEBUG - 2018-05-22 01:06:05 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:06:05 --> Utf8 Class Initialized
INFO - 2018-05-22 01:06:05 --> URI Class Initialized
INFO - 2018-05-22 01:06:05 --> Router Class Initialized
INFO - 2018-05-22 01:06:05 --> Output Class Initialized
INFO - 2018-05-22 01:06:05 --> Security Class Initialized
DEBUG - 2018-05-22 01:06:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:06:05 --> Input Class Initialized
INFO - 2018-05-22 01:06:05 --> Language Class Initialized
ERROR - 2018-05-22 01:06:05 --> 404 Page Not Found: /index
INFO - 2018-05-22 01:06:05 --> Config Class Initialized
INFO - 2018-05-22 01:06:05 --> Hooks Class Initialized
DEBUG - 2018-05-22 01:06:05 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:06:05 --> Utf8 Class Initialized
INFO - 2018-05-22 01:06:06 --> URI Class Initialized
INFO - 2018-05-22 01:06:06 --> Router Class Initialized
INFO - 2018-05-22 01:06:06 --> Output Class Initialized
INFO - 2018-05-22 01:06:06 --> Security Class Initialized
DEBUG - 2018-05-22 01:06:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:06:06 --> Input Class Initialized
INFO - 2018-05-22 01:06:06 --> Language Class Initialized
ERROR - 2018-05-22 01:06:06 --> 404 Page Not Found: /index
INFO - 2018-05-22 01:08:16 --> Config Class Initialized
INFO - 2018-05-22 01:08:16 --> Hooks Class Initialized
DEBUG - 2018-05-22 01:08:16 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:08:16 --> Utf8 Class Initialized
INFO - 2018-05-22 01:08:16 --> URI Class Initialized
INFO - 2018-05-22 01:08:16 --> Router Class Initialized
INFO - 2018-05-22 01:08:16 --> Output Class Initialized
INFO - 2018-05-22 01:08:16 --> Security Class Initialized
DEBUG - 2018-05-22 01:08:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:08:16 --> Input Class Initialized
INFO - 2018-05-22 01:08:16 --> Language Class Initialized
INFO - 2018-05-22 01:08:16 --> Language Class Initialized
INFO - 2018-05-22 01:08:16 --> Config Class Initialized
INFO - 2018-05-22 01:08:16 --> Loader Class Initialized
DEBUG - 2018-05-22 01:08:16 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 01:08:16 --> Helper loaded: url_helper
INFO - 2018-05-22 01:08:16 --> Helper loaded: form_helper
INFO - 2018-05-22 01:08:16 --> Helper loaded: date_helper
INFO - 2018-05-22 01:08:16 --> Helper loaded: util_helper
INFO - 2018-05-22 01:08:16 --> Helper loaded: text_helper
INFO - 2018-05-22 01:08:16 --> Helper loaded: string_helper
INFO - 2018-05-22 01:08:16 --> Database Driver Class Initialized
DEBUG - 2018-05-22 01:08:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 01:08:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 01:08:16 --> Email Class Initialized
INFO - 2018-05-22 01:08:16 --> Controller Class Initialized
DEBUG - 2018-05-22 01:08:16 --> Profile MX_Controller Initialized
DEBUG - 2018-05-22 01:08:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 01:08:16 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 01:08:16 --> Login MX_Controller Initialized
INFO - 2018-05-22 01:08:16 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 01:08:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 01:08:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-22 01:08:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-22 01:08:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-22 01:08:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-22 01:08:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-05-22 01:08:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-22 01:08:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-22 01:08:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/reset_password.php
INFO - 2018-05-22 01:08:16 --> Final output sent to browser
DEBUG - 2018-05-22 01:08:16 --> Total execution time: 0.3909
INFO - 2018-05-22 01:08:19 --> Config Class Initialized
INFO - 2018-05-22 01:08:19 --> Hooks Class Initialized
DEBUG - 2018-05-22 01:08:19 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:08:19 --> Utf8 Class Initialized
INFO - 2018-05-22 01:08:19 --> URI Class Initialized
INFO - 2018-05-22 01:08:19 --> Router Class Initialized
INFO - 2018-05-22 01:08:19 --> Output Class Initialized
INFO - 2018-05-22 01:08:19 --> Security Class Initialized
DEBUG - 2018-05-22 01:08:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:08:19 --> Input Class Initialized
INFO - 2018-05-22 01:08:19 --> Language Class Initialized
ERROR - 2018-05-22 01:08:19 --> 404 Page Not Found: /index
INFO - 2018-05-22 01:08:19 --> Config Class Initialized
INFO - 2018-05-22 01:08:19 --> Hooks Class Initialized
DEBUG - 2018-05-22 01:08:19 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:08:20 --> Utf8 Class Initialized
INFO - 2018-05-22 01:08:20 --> URI Class Initialized
INFO - 2018-05-22 01:08:20 --> Router Class Initialized
INFO - 2018-05-22 01:08:20 --> Output Class Initialized
INFO - 2018-05-22 01:08:20 --> Security Class Initialized
DEBUG - 2018-05-22 01:08:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:08:20 --> Input Class Initialized
INFO - 2018-05-22 01:08:20 --> Language Class Initialized
ERROR - 2018-05-22 01:08:20 --> 404 Page Not Found: /index
INFO - 2018-05-22 01:08:20 --> Config Class Initialized
INFO - 2018-05-22 01:08:20 --> Hooks Class Initialized
DEBUG - 2018-05-22 01:08:20 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:08:20 --> Utf8 Class Initialized
INFO - 2018-05-22 01:08:20 --> URI Class Initialized
INFO - 2018-05-22 01:08:20 --> Router Class Initialized
INFO - 2018-05-22 01:08:20 --> Output Class Initialized
INFO - 2018-05-22 01:08:20 --> Security Class Initialized
DEBUG - 2018-05-22 01:08:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:08:20 --> Input Class Initialized
INFO - 2018-05-22 01:08:20 --> Language Class Initialized
ERROR - 2018-05-22 01:08:20 --> 404 Page Not Found: /index
INFO - 2018-05-22 01:08:35 --> Config Class Initialized
INFO - 2018-05-22 01:08:35 --> Hooks Class Initialized
DEBUG - 2018-05-22 01:08:35 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:08:35 --> Utf8 Class Initialized
INFO - 2018-05-22 01:08:35 --> URI Class Initialized
INFO - 2018-05-22 01:08:35 --> Router Class Initialized
INFO - 2018-05-22 01:08:35 --> Output Class Initialized
INFO - 2018-05-22 01:08:35 --> Security Class Initialized
DEBUG - 2018-05-22 01:08:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:08:35 --> Input Class Initialized
INFO - 2018-05-22 01:08:35 --> Language Class Initialized
INFO - 2018-05-22 01:08:35 --> Language Class Initialized
INFO - 2018-05-22 01:08:35 --> Config Class Initialized
INFO - 2018-05-22 01:08:35 --> Loader Class Initialized
DEBUG - 2018-05-22 01:08:35 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 01:08:35 --> Helper loaded: url_helper
INFO - 2018-05-22 01:08:35 --> Helper loaded: form_helper
INFO - 2018-05-22 01:08:35 --> Helper loaded: date_helper
INFO - 2018-05-22 01:08:35 --> Helper loaded: util_helper
INFO - 2018-05-22 01:08:35 --> Helper loaded: text_helper
INFO - 2018-05-22 01:08:35 --> Helper loaded: string_helper
INFO - 2018-05-22 01:08:35 --> Database Driver Class Initialized
DEBUG - 2018-05-22 01:08:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 01:08:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 01:08:35 --> Email Class Initialized
INFO - 2018-05-22 01:08:35 --> Controller Class Initialized
DEBUG - 2018-05-22 01:08:35 --> Profile MX_Controller Initialized
DEBUG - 2018-05-22 01:08:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 01:08:35 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 01:08:35 --> Login MX_Controller Initialized
INFO - 2018-05-22 01:08:35 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 01:08:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 01:08:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-22 01:08:43 --> Config Class Initialized
INFO - 2018-05-22 01:08:43 --> Hooks Class Initialized
DEBUG - 2018-05-22 01:08:43 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:08:43 --> Utf8 Class Initialized
INFO - 2018-05-22 01:08:43 --> URI Class Initialized
INFO - 2018-05-22 01:08:43 --> Router Class Initialized
INFO - 2018-05-22 01:08:43 --> Output Class Initialized
INFO - 2018-05-22 01:08:43 --> Security Class Initialized
DEBUG - 2018-05-22 01:08:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:08:43 --> Input Class Initialized
INFO - 2018-05-22 01:08:43 --> Language Class Initialized
INFO - 2018-05-22 01:08:43 --> Language Class Initialized
INFO - 2018-05-22 01:08:43 --> Config Class Initialized
INFO - 2018-05-22 01:08:43 --> Loader Class Initialized
DEBUG - 2018-05-22 01:08:43 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 01:08:43 --> Helper loaded: url_helper
INFO - 2018-05-22 01:08:43 --> Helper loaded: form_helper
INFO - 2018-05-22 01:08:43 --> Helper loaded: date_helper
INFO - 2018-05-22 01:08:43 --> Helper loaded: util_helper
INFO - 2018-05-22 01:08:43 --> Helper loaded: text_helper
INFO - 2018-05-22 01:08:43 --> Helper loaded: string_helper
INFO - 2018-05-22 01:08:43 --> Database Driver Class Initialized
DEBUG - 2018-05-22 01:08:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 01:08:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 01:08:43 --> Email Class Initialized
INFO - 2018-05-22 01:08:43 --> Controller Class Initialized
DEBUG - 2018-05-22 01:08:43 --> Profile MX_Controller Initialized
DEBUG - 2018-05-22 01:08:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 01:08:43 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 01:08:43 --> Login MX_Controller Initialized
INFO - 2018-05-22 01:08:43 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 01:08:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 01:08:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-22 01:09:07 --> Config Class Initialized
INFO - 2018-05-22 01:09:07 --> Hooks Class Initialized
DEBUG - 2018-05-22 01:09:08 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:09:08 --> Utf8 Class Initialized
INFO - 2018-05-22 01:09:08 --> URI Class Initialized
INFO - 2018-05-22 01:09:08 --> Router Class Initialized
INFO - 2018-05-22 01:09:08 --> Output Class Initialized
INFO - 2018-05-22 01:09:08 --> Security Class Initialized
DEBUG - 2018-05-22 01:09:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:09:08 --> Input Class Initialized
INFO - 2018-05-22 01:09:08 --> Language Class Initialized
INFO - 2018-05-22 01:09:08 --> Language Class Initialized
INFO - 2018-05-22 01:09:08 --> Config Class Initialized
INFO - 2018-05-22 01:09:08 --> Loader Class Initialized
DEBUG - 2018-05-22 01:09:08 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 01:09:08 --> Helper loaded: url_helper
INFO - 2018-05-22 01:09:08 --> Helper loaded: form_helper
INFO - 2018-05-22 01:09:08 --> Helper loaded: date_helper
INFO - 2018-05-22 01:09:08 --> Helper loaded: util_helper
INFO - 2018-05-22 01:09:08 --> Helper loaded: text_helper
INFO - 2018-05-22 01:09:08 --> Helper loaded: string_helper
INFO - 2018-05-22 01:09:08 --> Database Driver Class Initialized
DEBUG - 2018-05-22 01:09:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 01:09:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 01:09:08 --> Email Class Initialized
INFO - 2018-05-22 01:09:08 --> Controller Class Initialized
DEBUG - 2018-05-22 01:09:08 --> Profile MX_Controller Initialized
DEBUG - 2018-05-22 01:09:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 01:09:08 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 01:09:08 --> Login MX_Controller Initialized
INFO - 2018-05-22 01:09:08 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 01:09:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 01:09:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-22 01:10:07 --> Config Class Initialized
INFO - 2018-05-22 01:10:07 --> Hooks Class Initialized
DEBUG - 2018-05-22 01:10:07 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:10:07 --> Utf8 Class Initialized
INFO - 2018-05-22 01:10:07 --> URI Class Initialized
INFO - 2018-05-22 01:10:07 --> Router Class Initialized
INFO - 2018-05-22 01:10:07 --> Output Class Initialized
INFO - 2018-05-22 01:10:07 --> Security Class Initialized
DEBUG - 2018-05-22 01:10:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:10:07 --> Input Class Initialized
INFO - 2018-05-22 01:10:07 --> Language Class Initialized
INFO - 2018-05-22 01:10:07 --> Language Class Initialized
INFO - 2018-05-22 01:10:07 --> Config Class Initialized
INFO - 2018-05-22 01:10:07 --> Loader Class Initialized
DEBUG - 2018-05-22 01:10:07 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 01:10:07 --> Helper loaded: url_helper
INFO - 2018-05-22 01:10:07 --> Helper loaded: form_helper
INFO - 2018-05-22 01:10:07 --> Helper loaded: date_helper
INFO - 2018-05-22 01:10:07 --> Helper loaded: util_helper
INFO - 2018-05-22 01:10:07 --> Helper loaded: text_helper
INFO - 2018-05-22 01:10:07 --> Helper loaded: string_helper
INFO - 2018-05-22 01:10:07 --> Database Driver Class Initialized
DEBUG - 2018-05-22 01:10:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 01:10:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 01:10:07 --> Email Class Initialized
INFO - 2018-05-22 01:10:07 --> Controller Class Initialized
DEBUG - 2018-05-22 01:10:07 --> Profile MX_Controller Initialized
DEBUG - 2018-05-22 01:10:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 01:10:07 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 01:10:07 --> Login MX_Controller Initialized
INFO - 2018-05-22 01:10:07 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 01:10:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 01:10:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-22 01:10:26 --> Config Class Initialized
INFO - 2018-05-22 01:10:26 --> Hooks Class Initialized
DEBUG - 2018-05-22 01:10:26 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:10:26 --> Utf8 Class Initialized
INFO - 2018-05-22 01:10:26 --> URI Class Initialized
INFO - 2018-05-22 01:10:26 --> Router Class Initialized
INFO - 2018-05-22 01:10:26 --> Output Class Initialized
INFO - 2018-05-22 01:10:26 --> Security Class Initialized
DEBUG - 2018-05-22 01:10:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:10:26 --> Input Class Initialized
INFO - 2018-05-22 01:10:26 --> Language Class Initialized
INFO - 2018-05-22 01:10:26 --> Language Class Initialized
INFO - 2018-05-22 01:10:26 --> Config Class Initialized
INFO - 2018-05-22 01:10:26 --> Loader Class Initialized
DEBUG - 2018-05-22 01:10:26 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 01:10:26 --> Helper loaded: url_helper
INFO - 2018-05-22 01:10:26 --> Helper loaded: form_helper
INFO - 2018-05-22 01:10:26 --> Helper loaded: date_helper
INFO - 2018-05-22 01:10:26 --> Helper loaded: util_helper
INFO - 2018-05-22 01:10:26 --> Helper loaded: text_helper
INFO - 2018-05-22 01:10:26 --> Helper loaded: string_helper
INFO - 2018-05-22 01:10:26 --> Database Driver Class Initialized
DEBUG - 2018-05-22 01:10:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 01:10:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 01:10:26 --> Email Class Initialized
INFO - 2018-05-22 01:10:26 --> Controller Class Initialized
DEBUG - 2018-05-22 01:10:26 --> Profile MX_Controller Initialized
DEBUG - 2018-05-22 01:10:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 01:10:26 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 01:10:26 --> Login MX_Controller Initialized
INFO - 2018-05-22 01:10:26 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 01:10:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 01:10:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-22 01:12:05 --> Config Class Initialized
INFO - 2018-05-22 01:12:05 --> Hooks Class Initialized
DEBUG - 2018-05-22 01:12:05 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:12:05 --> Utf8 Class Initialized
INFO - 2018-05-22 01:12:05 --> URI Class Initialized
INFO - 2018-05-22 01:12:05 --> Router Class Initialized
INFO - 2018-05-22 01:12:05 --> Output Class Initialized
INFO - 2018-05-22 01:12:05 --> Security Class Initialized
DEBUG - 2018-05-22 01:12:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:12:05 --> Input Class Initialized
INFO - 2018-05-22 01:12:05 --> Language Class Initialized
INFO - 2018-05-22 01:12:05 --> Language Class Initialized
INFO - 2018-05-22 01:12:05 --> Config Class Initialized
INFO - 2018-05-22 01:12:05 --> Loader Class Initialized
DEBUG - 2018-05-22 01:12:05 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 01:12:05 --> Helper loaded: url_helper
INFO - 2018-05-22 01:12:05 --> Helper loaded: form_helper
INFO - 2018-05-22 01:12:05 --> Helper loaded: date_helper
INFO - 2018-05-22 01:12:05 --> Helper loaded: util_helper
INFO - 2018-05-22 01:12:05 --> Helper loaded: text_helper
INFO - 2018-05-22 01:12:05 --> Helper loaded: string_helper
INFO - 2018-05-22 01:12:05 --> Database Driver Class Initialized
DEBUG - 2018-05-22 01:12:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 01:12:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 01:12:05 --> Email Class Initialized
INFO - 2018-05-22 01:12:05 --> Controller Class Initialized
DEBUG - 2018-05-22 01:12:05 --> Profile MX_Controller Initialized
DEBUG - 2018-05-22 01:12:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 01:12:05 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 01:12:05 --> Login MX_Controller Initialized
INFO - 2018-05-22 01:12:05 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 01:12:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 01:12:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-22 01:13:13 --> Config Class Initialized
INFO - 2018-05-22 01:13:13 --> Hooks Class Initialized
DEBUG - 2018-05-22 01:13:13 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:13:13 --> Utf8 Class Initialized
INFO - 2018-05-22 01:13:13 --> URI Class Initialized
INFO - 2018-05-22 01:13:13 --> Router Class Initialized
INFO - 2018-05-22 01:13:13 --> Output Class Initialized
INFO - 2018-05-22 01:13:13 --> Security Class Initialized
DEBUG - 2018-05-22 01:13:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:13:13 --> Input Class Initialized
INFO - 2018-05-22 01:13:13 --> Language Class Initialized
INFO - 2018-05-22 01:13:13 --> Language Class Initialized
INFO - 2018-05-22 01:13:13 --> Config Class Initialized
INFO - 2018-05-22 01:13:13 --> Loader Class Initialized
DEBUG - 2018-05-22 01:13:13 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 01:13:13 --> Helper loaded: url_helper
INFO - 2018-05-22 01:13:13 --> Helper loaded: form_helper
INFO - 2018-05-22 01:13:13 --> Helper loaded: date_helper
INFO - 2018-05-22 01:13:13 --> Helper loaded: util_helper
INFO - 2018-05-22 01:13:13 --> Helper loaded: text_helper
INFO - 2018-05-22 01:13:13 --> Helper loaded: string_helper
INFO - 2018-05-22 01:13:13 --> Database Driver Class Initialized
DEBUG - 2018-05-22 01:13:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 01:13:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 01:13:13 --> Email Class Initialized
INFO - 2018-05-22 01:13:13 --> Controller Class Initialized
DEBUG - 2018-05-22 01:13:13 --> Profile MX_Controller Initialized
DEBUG - 2018-05-22 01:13:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 01:13:13 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 01:13:13 --> Login MX_Controller Initialized
INFO - 2018-05-22 01:13:13 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 01:13:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 01:13:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-22 01:13:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-22 01:13:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-22 01:13:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-22 01:13:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-05-22 01:13:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-22 01:13:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-22 01:13:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/reset_password.php
INFO - 2018-05-22 01:13:13 --> Final output sent to browser
DEBUG - 2018-05-22 01:13:13 --> Total execution time: 0.4766
INFO - 2018-05-22 01:13:15 --> Config Class Initialized
INFO - 2018-05-22 01:13:15 --> Hooks Class Initialized
DEBUG - 2018-05-22 01:13:15 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:13:15 --> Utf8 Class Initialized
INFO - 2018-05-22 01:13:15 --> URI Class Initialized
INFO - 2018-05-22 01:13:15 --> Router Class Initialized
INFO - 2018-05-22 01:13:15 --> Output Class Initialized
INFO - 2018-05-22 01:13:15 --> Security Class Initialized
DEBUG - 2018-05-22 01:13:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:13:15 --> Input Class Initialized
INFO - 2018-05-22 01:13:15 --> Language Class Initialized
ERROR - 2018-05-22 01:13:15 --> 404 Page Not Found: /index
INFO - 2018-05-22 01:13:15 --> Config Class Initialized
INFO - 2018-05-22 01:13:15 --> Hooks Class Initialized
DEBUG - 2018-05-22 01:13:15 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:13:15 --> Utf8 Class Initialized
INFO - 2018-05-22 01:13:15 --> URI Class Initialized
INFO - 2018-05-22 01:13:15 --> Router Class Initialized
INFO - 2018-05-22 01:13:15 --> Output Class Initialized
INFO - 2018-05-22 01:13:15 --> Security Class Initialized
DEBUG - 2018-05-22 01:13:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:13:15 --> Input Class Initialized
INFO - 2018-05-22 01:13:15 --> Language Class Initialized
ERROR - 2018-05-22 01:13:15 --> 404 Page Not Found: /index
INFO - 2018-05-22 01:13:15 --> Config Class Initialized
INFO - 2018-05-22 01:13:15 --> Hooks Class Initialized
DEBUG - 2018-05-22 01:13:15 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:13:15 --> Utf8 Class Initialized
INFO - 2018-05-22 01:13:15 --> URI Class Initialized
INFO - 2018-05-22 01:13:15 --> Router Class Initialized
INFO - 2018-05-22 01:13:16 --> Output Class Initialized
INFO - 2018-05-22 01:13:16 --> Security Class Initialized
DEBUG - 2018-05-22 01:13:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:13:16 --> Input Class Initialized
INFO - 2018-05-22 01:13:16 --> Language Class Initialized
ERROR - 2018-05-22 01:13:16 --> 404 Page Not Found: /index
INFO - 2018-05-22 01:13:37 --> Config Class Initialized
INFO - 2018-05-22 01:13:37 --> Hooks Class Initialized
DEBUG - 2018-05-22 01:13:37 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:13:37 --> Utf8 Class Initialized
INFO - 2018-05-22 01:13:37 --> URI Class Initialized
INFO - 2018-05-22 01:13:37 --> Router Class Initialized
INFO - 2018-05-22 01:13:37 --> Output Class Initialized
INFO - 2018-05-22 01:13:37 --> Security Class Initialized
DEBUG - 2018-05-22 01:13:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:13:37 --> Input Class Initialized
INFO - 2018-05-22 01:13:38 --> Language Class Initialized
INFO - 2018-05-22 01:13:38 --> Language Class Initialized
INFO - 2018-05-22 01:13:38 --> Config Class Initialized
INFO - 2018-05-22 01:13:38 --> Loader Class Initialized
DEBUG - 2018-05-22 01:13:38 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 01:13:38 --> Helper loaded: url_helper
INFO - 2018-05-22 01:13:38 --> Helper loaded: form_helper
INFO - 2018-05-22 01:13:38 --> Helper loaded: date_helper
INFO - 2018-05-22 01:13:38 --> Helper loaded: util_helper
INFO - 2018-05-22 01:13:38 --> Helper loaded: text_helper
INFO - 2018-05-22 01:13:38 --> Helper loaded: string_helper
INFO - 2018-05-22 01:13:38 --> Database Driver Class Initialized
DEBUG - 2018-05-22 01:13:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 01:13:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 01:13:38 --> Email Class Initialized
INFO - 2018-05-22 01:13:38 --> Controller Class Initialized
DEBUG - 2018-05-22 01:13:38 --> Profile MX_Controller Initialized
DEBUG - 2018-05-22 01:13:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 01:13:38 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 01:13:38 --> Login MX_Controller Initialized
INFO - 2018-05-22 01:13:38 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 01:13:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 01:13:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-22 01:14:13 --> Config Class Initialized
INFO - 2018-05-22 01:14:13 --> Hooks Class Initialized
DEBUG - 2018-05-22 01:14:13 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:14:13 --> Utf8 Class Initialized
INFO - 2018-05-22 01:14:13 --> URI Class Initialized
INFO - 2018-05-22 01:14:13 --> Router Class Initialized
INFO - 2018-05-22 01:14:14 --> Output Class Initialized
INFO - 2018-05-22 01:14:14 --> Security Class Initialized
DEBUG - 2018-05-22 01:14:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:14:14 --> Input Class Initialized
INFO - 2018-05-22 01:14:14 --> Language Class Initialized
INFO - 2018-05-22 01:14:14 --> Language Class Initialized
INFO - 2018-05-22 01:14:14 --> Config Class Initialized
INFO - 2018-05-22 01:14:14 --> Loader Class Initialized
DEBUG - 2018-05-22 01:14:14 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 01:14:14 --> Helper loaded: url_helper
INFO - 2018-05-22 01:14:14 --> Helper loaded: form_helper
INFO - 2018-05-22 01:14:14 --> Helper loaded: date_helper
INFO - 2018-05-22 01:14:14 --> Helper loaded: util_helper
INFO - 2018-05-22 01:14:14 --> Helper loaded: text_helper
INFO - 2018-05-22 01:14:14 --> Helper loaded: string_helper
INFO - 2018-05-22 01:14:14 --> Database Driver Class Initialized
DEBUG - 2018-05-22 01:14:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 01:14:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 01:14:14 --> Email Class Initialized
INFO - 2018-05-22 01:14:14 --> Controller Class Initialized
DEBUG - 2018-05-22 01:14:14 --> Profile MX_Controller Initialized
DEBUG - 2018-05-22 01:14:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 01:14:14 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 01:14:14 --> Login MX_Controller Initialized
INFO - 2018-05-22 01:14:14 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 01:14:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 01:14:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-22 01:14:25 --> Config Class Initialized
INFO - 2018-05-22 01:14:25 --> Hooks Class Initialized
DEBUG - 2018-05-22 01:14:25 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:14:25 --> Utf8 Class Initialized
INFO - 2018-05-22 01:14:25 --> URI Class Initialized
INFO - 2018-05-22 01:14:25 --> Router Class Initialized
INFO - 2018-05-22 01:14:25 --> Output Class Initialized
INFO - 2018-05-22 01:14:25 --> Security Class Initialized
DEBUG - 2018-05-22 01:14:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:14:25 --> Input Class Initialized
INFO - 2018-05-22 01:14:25 --> Language Class Initialized
INFO - 2018-05-22 01:14:25 --> Language Class Initialized
INFO - 2018-05-22 01:14:25 --> Config Class Initialized
INFO - 2018-05-22 01:14:25 --> Loader Class Initialized
DEBUG - 2018-05-22 01:14:25 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 01:14:25 --> Helper loaded: url_helper
INFO - 2018-05-22 01:14:25 --> Helper loaded: form_helper
INFO - 2018-05-22 01:14:25 --> Helper loaded: date_helper
INFO - 2018-05-22 01:14:25 --> Helper loaded: util_helper
INFO - 2018-05-22 01:14:25 --> Helper loaded: text_helper
INFO - 2018-05-22 01:14:25 --> Helper loaded: string_helper
INFO - 2018-05-22 01:14:25 --> Database Driver Class Initialized
DEBUG - 2018-05-22 01:14:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 01:14:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 01:14:25 --> Email Class Initialized
INFO - 2018-05-22 01:14:25 --> Controller Class Initialized
DEBUG - 2018-05-22 01:14:25 --> Profile MX_Controller Initialized
DEBUG - 2018-05-22 01:14:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 01:14:25 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 01:14:25 --> Login MX_Controller Initialized
INFO - 2018-05-22 01:14:25 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 01:14:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 01:14:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-22 01:14:40 --> Config Class Initialized
INFO - 2018-05-22 01:14:40 --> Hooks Class Initialized
DEBUG - 2018-05-22 01:14:40 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:14:40 --> Utf8 Class Initialized
INFO - 2018-05-22 01:14:40 --> URI Class Initialized
INFO - 2018-05-22 01:14:40 --> Router Class Initialized
INFO - 2018-05-22 01:14:40 --> Output Class Initialized
INFO - 2018-05-22 01:14:40 --> Security Class Initialized
DEBUG - 2018-05-22 01:14:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:14:40 --> Input Class Initialized
INFO - 2018-05-22 01:14:40 --> Language Class Initialized
INFO - 2018-05-22 01:14:40 --> Language Class Initialized
INFO - 2018-05-22 01:14:40 --> Config Class Initialized
INFO - 2018-05-22 01:14:40 --> Loader Class Initialized
DEBUG - 2018-05-22 01:14:40 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 01:14:40 --> Helper loaded: url_helper
INFO - 2018-05-22 01:14:40 --> Helper loaded: form_helper
INFO - 2018-05-22 01:14:40 --> Helper loaded: date_helper
INFO - 2018-05-22 01:14:40 --> Helper loaded: util_helper
INFO - 2018-05-22 01:14:40 --> Helper loaded: text_helper
INFO - 2018-05-22 01:14:40 --> Helper loaded: string_helper
INFO - 2018-05-22 01:14:40 --> Database Driver Class Initialized
DEBUG - 2018-05-22 01:14:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 01:14:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 01:14:40 --> Email Class Initialized
INFO - 2018-05-22 01:14:40 --> Controller Class Initialized
DEBUG - 2018-05-22 01:14:40 --> Profile MX_Controller Initialized
DEBUG - 2018-05-22 01:14:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 01:14:40 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 01:14:40 --> Login MX_Controller Initialized
INFO - 2018-05-22 01:14:40 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 01:14:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 01:14:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-22 01:14:40 --> Config Class Initialized
INFO - 2018-05-22 01:14:40 --> Hooks Class Initialized
DEBUG - 2018-05-22 01:14:40 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:14:40 --> Utf8 Class Initialized
INFO - 2018-05-22 01:14:40 --> URI Class Initialized
INFO - 2018-05-22 01:14:40 --> Router Class Initialized
INFO - 2018-05-22 01:14:40 --> Output Class Initialized
INFO - 2018-05-22 01:14:40 --> Security Class Initialized
DEBUG - 2018-05-22 01:14:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:14:40 --> Input Class Initialized
INFO - 2018-05-22 01:14:40 --> Language Class Initialized
ERROR - 2018-05-22 01:14:40 --> 404 Page Not Found: /index
INFO - 2018-05-22 01:14:52 --> Config Class Initialized
INFO - 2018-05-22 01:14:52 --> Hooks Class Initialized
DEBUG - 2018-05-22 01:14:52 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:14:52 --> Utf8 Class Initialized
INFO - 2018-05-22 01:14:52 --> URI Class Initialized
INFO - 2018-05-22 01:14:52 --> Router Class Initialized
INFO - 2018-05-22 01:14:52 --> Output Class Initialized
INFO - 2018-05-22 01:14:52 --> Security Class Initialized
DEBUG - 2018-05-22 01:14:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:14:52 --> Input Class Initialized
INFO - 2018-05-22 01:14:52 --> Language Class Initialized
INFO - 2018-05-22 01:14:52 --> Language Class Initialized
INFO - 2018-05-22 01:14:52 --> Config Class Initialized
INFO - 2018-05-22 01:14:52 --> Loader Class Initialized
DEBUG - 2018-05-22 01:14:52 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 01:14:52 --> Helper loaded: url_helper
INFO - 2018-05-22 01:14:52 --> Helper loaded: form_helper
INFO - 2018-05-22 01:14:52 --> Helper loaded: date_helper
INFO - 2018-05-22 01:14:52 --> Helper loaded: util_helper
INFO - 2018-05-22 01:14:52 --> Helper loaded: text_helper
INFO - 2018-05-22 01:14:52 --> Helper loaded: string_helper
INFO - 2018-05-22 01:14:52 --> Database Driver Class Initialized
DEBUG - 2018-05-22 01:14:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 01:14:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 01:14:52 --> Email Class Initialized
INFO - 2018-05-22 01:14:52 --> Controller Class Initialized
DEBUG - 2018-05-22 01:14:52 --> Profile MX_Controller Initialized
DEBUG - 2018-05-22 01:14:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 01:14:52 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 01:14:52 --> Login MX_Controller Initialized
INFO - 2018-05-22 01:14:52 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 01:14:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 01:14:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-22 01:14:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-22 01:14:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-22 01:14:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-22 01:14:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-05-22 01:14:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-22 01:14:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-22 01:14:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/reset_password.php
INFO - 2018-05-22 01:14:52 --> Final output sent to browser
DEBUG - 2018-05-22 01:14:52 --> Total execution time: 0.4068
INFO - 2018-05-22 01:14:56 --> Config Class Initialized
INFO - 2018-05-22 01:14:56 --> Hooks Class Initialized
DEBUG - 2018-05-22 01:14:56 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:14:56 --> Utf8 Class Initialized
INFO - 2018-05-22 01:14:56 --> URI Class Initialized
INFO - 2018-05-22 01:14:56 --> Router Class Initialized
INFO - 2018-05-22 01:14:56 --> Output Class Initialized
INFO - 2018-05-22 01:14:56 --> Security Class Initialized
DEBUG - 2018-05-22 01:14:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:14:56 --> Input Class Initialized
INFO - 2018-05-22 01:14:56 --> Language Class Initialized
INFO - 2018-05-22 01:14:56 --> Language Class Initialized
INFO - 2018-05-22 01:14:56 --> Config Class Initialized
INFO - 2018-05-22 01:14:56 --> Loader Class Initialized
DEBUG - 2018-05-22 01:14:56 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 01:14:56 --> Helper loaded: url_helper
INFO - 2018-05-22 01:14:56 --> Helper loaded: form_helper
INFO - 2018-05-22 01:14:56 --> Helper loaded: date_helper
INFO - 2018-05-22 01:14:56 --> Helper loaded: util_helper
INFO - 2018-05-22 01:14:56 --> Helper loaded: text_helper
INFO - 2018-05-22 01:14:56 --> Helper loaded: string_helper
INFO - 2018-05-22 01:14:56 --> Database Driver Class Initialized
DEBUG - 2018-05-22 01:14:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 01:14:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 01:14:56 --> Email Class Initialized
INFO - 2018-05-22 01:14:56 --> Controller Class Initialized
DEBUG - 2018-05-22 01:14:56 --> Profile MX_Controller Initialized
DEBUG - 2018-05-22 01:14:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 01:14:56 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 01:14:56 --> Login MX_Controller Initialized
INFO - 2018-05-22 01:14:56 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 01:14:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 01:14:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-22 01:14:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-22 01:14:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-22 01:14:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-22 01:14:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-05-22 01:14:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-22 01:14:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-22 01:14:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/reset_password.php
INFO - 2018-05-22 01:14:56 --> Final output sent to browser
DEBUG - 2018-05-22 01:14:56 --> Total execution time: 0.5041
INFO - 2018-05-22 01:14:57 --> Config Class Initialized
INFO - 2018-05-22 01:14:57 --> Hooks Class Initialized
DEBUG - 2018-05-22 01:14:57 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:14:57 --> Utf8 Class Initialized
INFO - 2018-05-22 01:14:57 --> URI Class Initialized
INFO - 2018-05-22 01:14:57 --> Router Class Initialized
INFO - 2018-05-22 01:14:57 --> Output Class Initialized
INFO - 2018-05-22 01:14:57 --> Security Class Initialized
DEBUG - 2018-05-22 01:14:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:14:58 --> Input Class Initialized
INFO - 2018-05-22 01:14:58 --> Language Class Initialized
ERROR - 2018-05-22 01:14:58 --> 404 Page Not Found: /index
INFO - 2018-05-22 01:14:58 --> Config Class Initialized
INFO - 2018-05-22 01:14:58 --> Hooks Class Initialized
DEBUG - 2018-05-22 01:14:58 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:14:58 --> Utf8 Class Initialized
INFO - 2018-05-22 01:14:58 --> URI Class Initialized
INFO - 2018-05-22 01:14:58 --> Router Class Initialized
INFO - 2018-05-22 01:14:58 --> Output Class Initialized
INFO - 2018-05-22 01:14:58 --> Security Class Initialized
DEBUG - 2018-05-22 01:14:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:14:58 --> Input Class Initialized
INFO - 2018-05-22 01:14:58 --> Language Class Initialized
ERROR - 2018-05-22 01:14:58 --> 404 Page Not Found: /index
INFO - 2018-05-22 01:14:58 --> Config Class Initialized
INFO - 2018-05-22 01:14:58 --> Hooks Class Initialized
DEBUG - 2018-05-22 01:14:58 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:14:58 --> Utf8 Class Initialized
INFO - 2018-05-22 01:14:58 --> URI Class Initialized
INFO - 2018-05-22 01:14:58 --> Router Class Initialized
INFO - 2018-05-22 01:14:58 --> Output Class Initialized
INFO - 2018-05-22 01:14:58 --> Security Class Initialized
DEBUG - 2018-05-22 01:14:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:14:59 --> Input Class Initialized
INFO - 2018-05-22 01:14:59 --> Language Class Initialized
ERROR - 2018-05-22 01:14:59 --> 404 Page Not Found: /index
INFO - 2018-05-22 01:15:12 --> Config Class Initialized
INFO - 2018-05-22 01:15:12 --> Hooks Class Initialized
DEBUG - 2018-05-22 01:15:12 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:15:12 --> Utf8 Class Initialized
INFO - 2018-05-22 01:15:12 --> URI Class Initialized
INFO - 2018-05-22 01:15:12 --> Router Class Initialized
INFO - 2018-05-22 01:15:12 --> Output Class Initialized
INFO - 2018-05-22 01:15:12 --> Security Class Initialized
DEBUG - 2018-05-22 01:15:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:15:12 --> Input Class Initialized
INFO - 2018-05-22 01:15:12 --> Language Class Initialized
INFO - 2018-05-22 01:15:12 --> Language Class Initialized
INFO - 2018-05-22 01:15:12 --> Config Class Initialized
INFO - 2018-05-22 01:15:12 --> Loader Class Initialized
DEBUG - 2018-05-22 01:15:12 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 01:15:12 --> Helper loaded: url_helper
INFO - 2018-05-22 01:15:12 --> Helper loaded: form_helper
INFO - 2018-05-22 01:15:12 --> Helper loaded: date_helper
INFO - 2018-05-22 01:15:12 --> Helper loaded: util_helper
INFO - 2018-05-22 01:15:12 --> Helper loaded: text_helper
INFO - 2018-05-22 01:15:12 --> Helper loaded: string_helper
INFO - 2018-05-22 01:15:12 --> Database Driver Class Initialized
DEBUG - 2018-05-22 01:15:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 01:15:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 01:15:12 --> Email Class Initialized
INFO - 2018-05-22 01:15:12 --> Controller Class Initialized
DEBUG - 2018-05-22 01:15:12 --> Profile MX_Controller Initialized
DEBUG - 2018-05-22 01:15:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 01:15:13 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 01:15:13 --> Login MX_Controller Initialized
INFO - 2018-05-22 01:15:13 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 01:15:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 01:15:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-22 01:15:36 --> Config Class Initialized
INFO - 2018-05-22 01:15:36 --> Hooks Class Initialized
DEBUG - 2018-05-22 01:15:36 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:15:36 --> Utf8 Class Initialized
INFO - 2018-05-22 01:15:36 --> URI Class Initialized
INFO - 2018-05-22 01:15:36 --> Router Class Initialized
INFO - 2018-05-22 01:15:36 --> Output Class Initialized
INFO - 2018-05-22 01:15:36 --> Security Class Initialized
DEBUG - 2018-05-22 01:15:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:15:36 --> Input Class Initialized
INFO - 2018-05-22 01:15:36 --> Language Class Initialized
INFO - 2018-05-22 01:15:36 --> Language Class Initialized
INFO - 2018-05-22 01:15:36 --> Config Class Initialized
INFO - 2018-05-22 01:15:36 --> Loader Class Initialized
DEBUG - 2018-05-22 01:15:36 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 01:15:36 --> Helper loaded: url_helper
INFO - 2018-05-22 01:15:36 --> Helper loaded: form_helper
INFO - 2018-05-22 01:15:36 --> Helper loaded: date_helper
INFO - 2018-05-22 01:15:36 --> Helper loaded: util_helper
INFO - 2018-05-22 01:15:36 --> Helper loaded: text_helper
INFO - 2018-05-22 01:15:36 --> Helper loaded: string_helper
INFO - 2018-05-22 01:15:36 --> Database Driver Class Initialized
DEBUG - 2018-05-22 01:15:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 01:15:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 01:15:36 --> Email Class Initialized
INFO - 2018-05-22 01:15:36 --> Controller Class Initialized
DEBUG - 2018-05-22 01:15:36 --> Profile MX_Controller Initialized
DEBUG - 2018-05-22 01:15:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 01:15:36 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 01:15:36 --> Login MX_Controller Initialized
INFO - 2018-05-22 01:15:36 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 01:15:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 01:15:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-22 01:15:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-22 01:15:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-22 01:15:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-22 01:15:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-05-22 01:15:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-22 01:15:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-22 01:15:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/reset_password.php
INFO - 2018-05-22 01:15:36 --> Final output sent to browser
DEBUG - 2018-05-22 01:15:36 --> Total execution time: 0.4389
INFO - 2018-05-22 01:15:38 --> Config Class Initialized
INFO - 2018-05-22 01:15:38 --> Hooks Class Initialized
DEBUG - 2018-05-22 01:15:38 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:15:38 --> Utf8 Class Initialized
INFO - 2018-05-22 01:15:38 --> URI Class Initialized
INFO - 2018-05-22 01:15:38 --> Router Class Initialized
INFO - 2018-05-22 01:15:38 --> Output Class Initialized
INFO - 2018-05-22 01:15:38 --> Security Class Initialized
DEBUG - 2018-05-22 01:15:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:15:38 --> Input Class Initialized
INFO - 2018-05-22 01:15:38 --> Language Class Initialized
ERROR - 2018-05-22 01:15:38 --> 404 Page Not Found: /index
INFO - 2018-05-22 01:15:38 --> Config Class Initialized
INFO - 2018-05-22 01:15:38 --> Hooks Class Initialized
DEBUG - 2018-05-22 01:15:38 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:15:38 --> Utf8 Class Initialized
INFO - 2018-05-22 01:15:38 --> URI Class Initialized
INFO - 2018-05-22 01:15:39 --> Router Class Initialized
INFO - 2018-05-22 01:15:39 --> Output Class Initialized
INFO - 2018-05-22 01:15:39 --> Security Class Initialized
DEBUG - 2018-05-22 01:15:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:15:39 --> Input Class Initialized
INFO - 2018-05-22 01:15:39 --> Language Class Initialized
ERROR - 2018-05-22 01:15:39 --> 404 Page Not Found: /index
INFO - 2018-05-22 01:15:39 --> Config Class Initialized
INFO - 2018-05-22 01:15:39 --> Hooks Class Initialized
DEBUG - 2018-05-22 01:15:39 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:15:39 --> Utf8 Class Initialized
INFO - 2018-05-22 01:15:39 --> URI Class Initialized
INFO - 2018-05-22 01:15:39 --> Router Class Initialized
INFO - 2018-05-22 01:15:39 --> Output Class Initialized
INFO - 2018-05-22 01:15:39 --> Security Class Initialized
DEBUG - 2018-05-22 01:15:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:15:39 --> Input Class Initialized
INFO - 2018-05-22 01:15:39 --> Language Class Initialized
ERROR - 2018-05-22 01:15:39 --> 404 Page Not Found: /index
INFO - 2018-05-22 01:15:51 --> Config Class Initialized
INFO - 2018-05-22 01:15:51 --> Hooks Class Initialized
DEBUG - 2018-05-22 01:15:51 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:15:51 --> Utf8 Class Initialized
INFO - 2018-05-22 01:15:51 --> URI Class Initialized
INFO - 2018-05-22 01:15:51 --> Router Class Initialized
INFO - 2018-05-22 01:15:51 --> Output Class Initialized
INFO - 2018-05-22 01:15:51 --> Security Class Initialized
DEBUG - 2018-05-22 01:15:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:15:51 --> Input Class Initialized
INFO - 2018-05-22 01:15:51 --> Language Class Initialized
INFO - 2018-05-22 01:15:51 --> Language Class Initialized
INFO - 2018-05-22 01:15:51 --> Config Class Initialized
INFO - 2018-05-22 01:15:51 --> Loader Class Initialized
DEBUG - 2018-05-22 01:15:51 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 01:15:51 --> Helper loaded: url_helper
INFO - 2018-05-22 01:15:51 --> Helper loaded: form_helper
INFO - 2018-05-22 01:15:51 --> Helper loaded: date_helper
INFO - 2018-05-22 01:15:51 --> Helper loaded: util_helper
INFO - 2018-05-22 01:15:51 --> Helper loaded: text_helper
INFO - 2018-05-22 01:15:51 --> Helper loaded: string_helper
INFO - 2018-05-22 01:15:51 --> Database Driver Class Initialized
DEBUG - 2018-05-22 01:15:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 01:15:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 01:15:51 --> Email Class Initialized
INFO - 2018-05-22 01:15:51 --> Controller Class Initialized
DEBUG - 2018-05-22 01:15:51 --> Profile MX_Controller Initialized
DEBUG - 2018-05-22 01:15:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 01:15:51 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 01:15:51 --> Login MX_Controller Initialized
INFO - 2018-05-22 01:15:51 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 01:15:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 01:15:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-22 01:16:40 --> Config Class Initialized
INFO - 2018-05-22 01:16:40 --> Hooks Class Initialized
DEBUG - 2018-05-22 01:16:40 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:16:40 --> Utf8 Class Initialized
INFO - 2018-05-22 01:16:40 --> URI Class Initialized
INFO - 2018-05-22 01:16:40 --> Router Class Initialized
INFO - 2018-05-22 01:16:40 --> Output Class Initialized
INFO - 2018-05-22 01:16:40 --> Security Class Initialized
DEBUG - 2018-05-22 01:16:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:16:40 --> Input Class Initialized
INFO - 2018-05-22 01:16:40 --> Language Class Initialized
INFO - 2018-05-22 01:16:40 --> Language Class Initialized
INFO - 2018-05-22 01:16:40 --> Config Class Initialized
INFO - 2018-05-22 01:16:40 --> Loader Class Initialized
DEBUG - 2018-05-22 01:16:40 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 01:16:40 --> Helper loaded: url_helper
INFO - 2018-05-22 01:16:40 --> Helper loaded: form_helper
INFO - 2018-05-22 01:16:40 --> Helper loaded: date_helper
INFO - 2018-05-22 01:16:40 --> Helper loaded: util_helper
INFO - 2018-05-22 01:16:40 --> Helper loaded: text_helper
INFO - 2018-05-22 01:16:40 --> Helper loaded: string_helper
INFO - 2018-05-22 01:16:40 --> Database Driver Class Initialized
DEBUG - 2018-05-22 01:16:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 01:16:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 01:16:40 --> Email Class Initialized
INFO - 2018-05-22 01:16:40 --> Controller Class Initialized
DEBUG - 2018-05-22 01:16:40 --> Profile MX_Controller Initialized
DEBUG - 2018-05-22 01:16:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 01:16:40 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 01:16:40 --> Login MX_Controller Initialized
INFO - 2018-05-22 01:16:40 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 01:16:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 01:16:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-22 01:16:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-22 01:16:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-22 01:16:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-22 01:16:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-05-22 01:16:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-22 01:16:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-22 01:16:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/reset_password.php
INFO - 2018-05-22 01:16:40 --> Final output sent to browser
DEBUG - 2018-05-22 01:16:40 --> Total execution time: 0.4430
INFO - 2018-05-22 01:16:41 --> Config Class Initialized
INFO - 2018-05-22 01:16:41 --> Hooks Class Initialized
DEBUG - 2018-05-22 01:16:41 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:16:41 --> Utf8 Class Initialized
INFO - 2018-05-22 01:16:41 --> URI Class Initialized
INFO - 2018-05-22 01:16:41 --> Router Class Initialized
INFO - 2018-05-22 01:16:41 --> Output Class Initialized
INFO - 2018-05-22 01:16:41 --> Security Class Initialized
DEBUG - 2018-05-22 01:16:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:16:41 --> Input Class Initialized
INFO - 2018-05-22 01:16:41 --> Language Class Initialized
ERROR - 2018-05-22 01:16:41 --> 404 Page Not Found: /index
INFO - 2018-05-22 01:16:41 --> Config Class Initialized
INFO - 2018-05-22 01:16:41 --> Hooks Class Initialized
DEBUG - 2018-05-22 01:16:41 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:16:41 --> Utf8 Class Initialized
INFO - 2018-05-22 01:16:41 --> URI Class Initialized
INFO - 2018-05-22 01:16:41 --> Router Class Initialized
INFO - 2018-05-22 01:16:41 --> Output Class Initialized
INFO - 2018-05-22 01:16:41 --> Security Class Initialized
DEBUG - 2018-05-22 01:16:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:16:41 --> Input Class Initialized
INFO - 2018-05-22 01:16:41 --> Language Class Initialized
ERROR - 2018-05-22 01:16:41 --> 404 Page Not Found: /index
INFO - 2018-05-22 01:16:41 --> Config Class Initialized
INFO - 2018-05-22 01:16:41 --> Hooks Class Initialized
DEBUG - 2018-05-22 01:16:42 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:16:42 --> Utf8 Class Initialized
INFO - 2018-05-22 01:16:42 --> URI Class Initialized
INFO - 2018-05-22 01:16:42 --> Router Class Initialized
INFO - 2018-05-22 01:16:42 --> Output Class Initialized
INFO - 2018-05-22 01:16:42 --> Security Class Initialized
DEBUG - 2018-05-22 01:16:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:16:42 --> Input Class Initialized
INFO - 2018-05-22 01:16:42 --> Language Class Initialized
ERROR - 2018-05-22 01:16:42 --> 404 Page Not Found: /index
INFO - 2018-05-22 01:16:48 --> Config Class Initialized
INFO - 2018-05-22 01:16:48 --> Hooks Class Initialized
DEBUG - 2018-05-22 01:16:48 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:16:48 --> Utf8 Class Initialized
INFO - 2018-05-22 01:16:48 --> URI Class Initialized
INFO - 2018-05-22 01:16:48 --> Router Class Initialized
INFO - 2018-05-22 01:16:48 --> Output Class Initialized
INFO - 2018-05-22 01:16:48 --> Security Class Initialized
DEBUG - 2018-05-22 01:16:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:16:48 --> Input Class Initialized
INFO - 2018-05-22 01:16:48 --> Language Class Initialized
ERROR - 2018-05-22 01:16:48 --> 404 Page Not Found: /index
INFO - 2018-05-22 01:16:48 --> Config Class Initialized
INFO - 2018-05-22 01:16:48 --> Hooks Class Initialized
DEBUG - 2018-05-22 01:16:48 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:16:48 --> Utf8 Class Initialized
INFO - 2018-05-22 01:16:48 --> URI Class Initialized
INFO - 2018-05-22 01:16:48 --> Router Class Initialized
INFO - 2018-05-22 01:16:48 --> Output Class Initialized
INFO - 2018-05-22 01:16:48 --> Security Class Initialized
DEBUG - 2018-05-22 01:16:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:16:48 --> Input Class Initialized
INFO - 2018-05-22 01:16:48 --> Language Class Initialized
ERROR - 2018-05-22 01:16:48 --> 404 Page Not Found: /index
INFO - 2018-05-22 01:16:48 --> Config Class Initialized
INFO - 2018-05-22 01:16:48 --> Hooks Class Initialized
DEBUG - 2018-05-22 01:16:48 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:16:48 --> Utf8 Class Initialized
INFO - 2018-05-22 01:16:48 --> URI Class Initialized
INFO - 2018-05-22 01:16:49 --> Router Class Initialized
INFO - 2018-05-22 01:16:49 --> Output Class Initialized
INFO - 2018-05-22 01:16:49 --> Security Class Initialized
DEBUG - 2018-05-22 01:16:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:16:49 --> Input Class Initialized
INFO - 2018-05-22 01:16:49 --> Language Class Initialized
ERROR - 2018-05-22 01:16:49 --> 404 Page Not Found: /index
INFO - 2018-05-22 01:16:51 --> Config Class Initialized
INFO - 2018-05-22 01:16:51 --> Hooks Class Initialized
DEBUG - 2018-05-22 01:16:51 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:16:51 --> Utf8 Class Initialized
INFO - 2018-05-22 01:16:51 --> URI Class Initialized
INFO - 2018-05-22 01:16:51 --> Router Class Initialized
INFO - 2018-05-22 01:16:51 --> Output Class Initialized
INFO - 2018-05-22 01:16:51 --> Security Class Initialized
DEBUG - 2018-05-22 01:16:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:16:51 --> Input Class Initialized
INFO - 2018-05-22 01:16:51 --> Language Class Initialized
INFO - 2018-05-22 01:16:51 --> Language Class Initialized
INFO - 2018-05-22 01:16:51 --> Config Class Initialized
INFO - 2018-05-22 01:16:51 --> Loader Class Initialized
DEBUG - 2018-05-22 01:16:51 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 01:16:51 --> Helper loaded: url_helper
INFO - 2018-05-22 01:16:51 --> Helper loaded: form_helper
INFO - 2018-05-22 01:16:51 --> Helper loaded: date_helper
INFO - 2018-05-22 01:16:51 --> Helper loaded: util_helper
INFO - 2018-05-22 01:16:51 --> Helper loaded: text_helper
INFO - 2018-05-22 01:16:51 --> Helper loaded: string_helper
INFO - 2018-05-22 01:16:51 --> Database Driver Class Initialized
DEBUG - 2018-05-22 01:16:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 01:16:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 01:16:51 --> Email Class Initialized
INFO - 2018-05-22 01:16:51 --> Controller Class Initialized
DEBUG - 2018-05-22 01:16:51 --> Profile MX_Controller Initialized
DEBUG - 2018-05-22 01:16:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 01:16:51 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 01:16:51 --> Login MX_Controller Initialized
INFO - 2018-05-22 01:16:51 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 01:16:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 01:16:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-22 01:16:59 --> Config Class Initialized
INFO - 2018-05-22 01:16:59 --> Hooks Class Initialized
DEBUG - 2018-05-22 01:16:59 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:16:59 --> Utf8 Class Initialized
INFO - 2018-05-22 01:16:59 --> URI Class Initialized
INFO - 2018-05-22 01:16:59 --> Router Class Initialized
INFO - 2018-05-22 01:16:59 --> Output Class Initialized
INFO - 2018-05-22 01:16:59 --> Security Class Initialized
DEBUG - 2018-05-22 01:16:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:16:59 --> Input Class Initialized
INFO - 2018-05-22 01:16:59 --> Language Class Initialized
INFO - 2018-05-22 01:16:59 --> Language Class Initialized
INFO - 2018-05-22 01:16:59 --> Config Class Initialized
INFO - 2018-05-22 01:16:59 --> Loader Class Initialized
DEBUG - 2018-05-22 01:16:59 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 01:16:59 --> Helper loaded: url_helper
INFO - 2018-05-22 01:16:59 --> Helper loaded: form_helper
INFO - 2018-05-22 01:16:59 --> Helper loaded: date_helper
INFO - 2018-05-22 01:16:59 --> Helper loaded: util_helper
INFO - 2018-05-22 01:16:59 --> Helper loaded: text_helper
INFO - 2018-05-22 01:16:59 --> Helper loaded: string_helper
INFO - 2018-05-22 01:16:59 --> Database Driver Class Initialized
DEBUG - 2018-05-22 01:16:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 01:16:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 01:16:59 --> Email Class Initialized
INFO - 2018-05-22 01:16:59 --> Controller Class Initialized
DEBUG - 2018-05-22 01:16:59 --> Profile MX_Controller Initialized
DEBUG - 2018-05-22 01:16:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 01:16:59 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 01:16:59 --> Login MX_Controller Initialized
INFO - 2018-05-22 01:16:59 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 01:16:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 01:16:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-22 01:17:24 --> Config Class Initialized
INFO - 2018-05-22 01:17:24 --> Hooks Class Initialized
DEBUG - 2018-05-22 01:17:24 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:17:24 --> Utf8 Class Initialized
INFO - 2018-05-22 01:17:24 --> URI Class Initialized
INFO - 2018-05-22 01:17:24 --> Router Class Initialized
INFO - 2018-05-22 01:17:24 --> Output Class Initialized
INFO - 2018-05-22 01:17:24 --> Security Class Initialized
DEBUG - 2018-05-22 01:17:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:17:24 --> Input Class Initialized
INFO - 2018-05-22 01:17:24 --> Language Class Initialized
INFO - 2018-05-22 01:17:24 --> Language Class Initialized
INFO - 2018-05-22 01:17:24 --> Config Class Initialized
INFO - 2018-05-22 01:17:24 --> Loader Class Initialized
DEBUG - 2018-05-22 01:17:24 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 01:17:24 --> Helper loaded: url_helper
INFO - 2018-05-22 01:17:24 --> Helper loaded: form_helper
INFO - 2018-05-22 01:17:24 --> Helper loaded: date_helper
INFO - 2018-05-22 01:17:24 --> Helper loaded: util_helper
INFO - 2018-05-22 01:17:24 --> Helper loaded: text_helper
INFO - 2018-05-22 01:17:24 --> Helper loaded: string_helper
INFO - 2018-05-22 01:17:24 --> Database Driver Class Initialized
DEBUG - 2018-05-22 01:17:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 01:17:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 01:17:24 --> Email Class Initialized
INFO - 2018-05-22 01:17:24 --> Controller Class Initialized
DEBUG - 2018-05-22 01:17:24 --> Profile MX_Controller Initialized
DEBUG - 2018-05-22 01:17:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 01:17:24 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 01:17:24 --> Login MX_Controller Initialized
INFO - 2018-05-22 01:17:24 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 01:17:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 01:17:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-22 01:17:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-22 01:17:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-22 01:17:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-22 01:17:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-05-22 01:17:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-22 01:17:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-22 01:17:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/reset_password.php
INFO - 2018-05-22 01:17:24 --> Final output sent to browser
DEBUG - 2018-05-22 01:17:24 --> Total execution time: 0.4200
INFO - 2018-05-22 01:17:25 --> Config Class Initialized
INFO - 2018-05-22 01:17:25 --> Hooks Class Initialized
DEBUG - 2018-05-22 01:17:25 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:17:25 --> Utf8 Class Initialized
INFO - 2018-05-22 01:17:25 --> URI Class Initialized
INFO - 2018-05-22 01:17:25 --> Router Class Initialized
INFO - 2018-05-22 01:17:25 --> Output Class Initialized
INFO - 2018-05-22 01:17:25 --> Security Class Initialized
DEBUG - 2018-05-22 01:17:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:17:25 --> Input Class Initialized
INFO - 2018-05-22 01:17:25 --> Language Class Initialized
ERROR - 2018-05-22 01:17:25 --> 404 Page Not Found: /index
INFO - 2018-05-22 01:17:25 --> Config Class Initialized
INFO - 2018-05-22 01:17:25 --> Hooks Class Initialized
DEBUG - 2018-05-22 01:17:25 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:17:25 --> Utf8 Class Initialized
INFO - 2018-05-22 01:17:25 --> URI Class Initialized
INFO - 2018-05-22 01:17:25 --> Router Class Initialized
INFO - 2018-05-22 01:17:25 --> Output Class Initialized
INFO - 2018-05-22 01:17:25 --> Security Class Initialized
DEBUG - 2018-05-22 01:17:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:17:25 --> Input Class Initialized
INFO - 2018-05-22 01:17:25 --> Language Class Initialized
ERROR - 2018-05-22 01:17:26 --> 404 Page Not Found: /index
INFO - 2018-05-22 01:17:26 --> Config Class Initialized
INFO - 2018-05-22 01:17:26 --> Hooks Class Initialized
DEBUG - 2018-05-22 01:17:26 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:17:26 --> Utf8 Class Initialized
INFO - 2018-05-22 01:17:26 --> URI Class Initialized
INFO - 2018-05-22 01:17:26 --> Router Class Initialized
INFO - 2018-05-22 01:17:26 --> Output Class Initialized
INFO - 2018-05-22 01:17:26 --> Security Class Initialized
DEBUG - 2018-05-22 01:17:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:17:26 --> Input Class Initialized
INFO - 2018-05-22 01:17:26 --> Language Class Initialized
ERROR - 2018-05-22 01:17:26 --> 404 Page Not Found: /index
INFO - 2018-05-22 01:17:29 --> Config Class Initialized
INFO - 2018-05-22 01:17:29 --> Hooks Class Initialized
DEBUG - 2018-05-22 01:17:29 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:17:29 --> Utf8 Class Initialized
INFO - 2018-05-22 01:17:29 --> URI Class Initialized
INFO - 2018-05-22 01:17:29 --> Router Class Initialized
INFO - 2018-05-22 01:17:29 --> Output Class Initialized
INFO - 2018-05-22 01:17:29 --> Security Class Initialized
DEBUG - 2018-05-22 01:17:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:17:29 --> Input Class Initialized
INFO - 2018-05-22 01:17:29 --> Language Class Initialized
ERROR - 2018-05-22 01:17:29 --> 404 Page Not Found: /index
INFO - 2018-05-22 01:17:29 --> Config Class Initialized
INFO - 2018-05-22 01:17:29 --> Hooks Class Initialized
DEBUG - 2018-05-22 01:17:29 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:17:29 --> Utf8 Class Initialized
INFO - 2018-05-22 01:17:29 --> URI Class Initialized
INFO - 2018-05-22 01:17:29 --> Router Class Initialized
INFO - 2018-05-22 01:17:29 --> Output Class Initialized
INFO - 2018-05-22 01:17:29 --> Security Class Initialized
DEBUG - 2018-05-22 01:17:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:17:29 --> Input Class Initialized
INFO - 2018-05-22 01:17:29 --> Language Class Initialized
ERROR - 2018-05-22 01:17:29 --> 404 Page Not Found: /index
INFO - 2018-05-22 01:17:29 --> Config Class Initialized
INFO - 2018-05-22 01:17:29 --> Hooks Class Initialized
DEBUG - 2018-05-22 01:17:29 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:17:29 --> Utf8 Class Initialized
INFO - 2018-05-22 01:17:29 --> URI Class Initialized
INFO - 2018-05-22 01:17:29 --> Router Class Initialized
INFO - 2018-05-22 01:17:29 --> Output Class Initialized
INFO - 2018-05-22 01:17:29 --> Security Class Initialized
DEBUG - 2018-05-22 01:17:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:17:29 --> Input Class Initialized
INFO - 2018-05-22 01:17:29 --> Language Class Initialized
ERROR - 2018-05-22 01:17:29 --> 404 Page Not Found: /index
INFO - 2018-05-22 01:17:38 --> Config Class Initialized
INFO - 2018-05-22 01:17:38 --> Hooks Class Initialized
DEBUG - 2018-05-22 01:17:38 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:17:38 --> Utf8 Class Initialized
INFO - 2018-05-22 01:17:38 --> URI Class Initialized
INFO - 2018-05-22 01:17:38 --> Router Class Initialized
INFO - 2018-05-22 01:17:38 --> Output Class Initialized
INFO - 2018-05-22 01:17:38 --> Security Class Initialized
DEBUG - 2018-05-22 01:17:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:17:38 --> Input Class Initialized
INFO - 2018-05-22 01:17:38 --> Language Class Initialized
INFO - 2018-05-22 01:17:38 --> Language Class Initialized
INFO - 2018-05-22 01:17:39 --> Config Class Initialized
INFO - 2018-05-22 01:17:39 --> Loader Class Initialized
DEBUG - 2018-05-22 01:17:39 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 01:17:39 --> Helper loaded: url_helper
INFO - 2018-05-22 01:17:39 --> Helper loaded: form_helper
INFO - 2018-05-22 01:17:39 --> Helper loaded: date_helper
INFO - 2018-05-22 01:17:39 --> Helper loaded: util_helper
INFO - 2018-05-22 01:17:39 --> Helper loaded: text_helper
INFO - 2018-05-22 01:17:39 --> Helper loaded: string_helper
INFO - 2018-05-22 01:17:39 --> Database Driver Class Initialized
DEBUG - 2018-05-22 01:17:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 01:17:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 01:17:39 --> Email Class Initialized
INFO - 2018-05-22 01:17:39 --> Controller Class Initialized
DEBUG - 2018-05-22 01:17:39 --> Profile MX_Controller Initialized
DEBUG - 2018-05-22 01:17:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 01:17:39 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 01:17:39 --> Login MX_Controller Initialized
INFO - 2018-05-22 01:17:39 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 01:17:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 01:17:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-22 01:17:59 --> Config Class Initialized
INFO - 2018-05-22 01:17:59 --> Hooks Class Initialized
DEBUG - 2018-05-22 01:17:59 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:17:59 --> Utf8 Class Initialized
INFO - 2018-05-22 01:17:59 --> URI Class Initialized
INFO - 2018-05-22 01:17:59 --> Router Class Initialized
INFO - 2018-05-22 01:17:59 --> Output Class Initialized
INFO - 2018-05-22 01:17:59 --> Security Class Initialized
DEBUG - 2018-05-22 01:17:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:17:59 --> Input Class Initialized
INFO - 2018-05-22 01:17:59 --> Language Class Initialized
INFO - 2018-05-22 01:17:59 --> Language Class Initialized
INFO - 2018-05-22 01:17:59 --> Config Class Initialized
INFO - 2018-05-22 01:17:59 --> Loader Class Initialized
DEBUG - 2018-05-22 01:17:59 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 01:17:59 --> Helper loaded: url_helper
INFO - 2018-05-22 01:17:59 --> Helper loaded: form_helper
INFO - 2018-05-22 01:17:59 --> Helper loaded: date_helper
INFO - 2018-05-22 01:17:59 --> Helper loaded: util_helper
INFO - 2018-05-22 01:17:59 --> Helper loaded: text_helper
INFO - 2018-05-22 01:17:59 --> Helper loaded: string_helper
INFO - 2018-05-22 01:17:59 --> Database Driver Class Initialized
DEBUG - 2018-05-22 01:17:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 01:17:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 01:17:59 --> Email Class Initialized
INFO - 2018-05-22 01:17:59 --> Controller Class Initialized
DEBUG - 2018-05-22 01:17:59 --> Profile MX_Controller Initialized
DEBUG - 2018-05-22 01:17:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 01:17:59 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 01:17:59 --> Login MX_Controller Initialized
INFO - 2018-05-22 01:17:59 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 01:17:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 01:17:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-22 01:17:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-22 01:17:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-22 01:18:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-22 01:18:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-05-22 01:18:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-22 01:18:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-22 01:18:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/profile.php
INFO - 2018-05-22 01:18:00 --> Final output sent to browser
DEBUG - 2018-05-22 01:18:00 --> Total execution time: 0.5011
INFO - 2018-05-22 01:18:00 --> Config Class Initialized
INFO - 2018-05-22 01:18:00 --> Hooks Class Initialized
DEBUG - 2018-05-22 01:18:00 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:18:00 --> Utf8 Class Initialized
INFO - 2018-05-22 01:18:00 --> URI Class Initialized
INFO - 2018-05-22 01:18:00 --> Router Class Initialized
INFO - 2018-05-22 01:18:00 --> Output Class Initialized
INFO - 2018-05-22 01:18:00 --> Security Class Initialized
DEBUG - 2018-05-22 01:18:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:18:00 --> Input Class Initialized
INFO - 2018-05-22 01:18:00 --> Language Class Initialized
ERROR - 2018-05-22 01:18:00 --> 404 Page Not Found: /index
INFO - 2018-05-22 01:18:00 --> Config Class Initialized
INFO - 2018-05-22 01:18:00 --> Hooks Class Initialized
DEBUG - 2018-05-22 01:18:00 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:18:00 --> Utf8 Class Initialized
INFO - 2018-05-22 01:18:00 --> URI Class Initialized
INFO - 2018-05-22 01:18:00 --> Router Class Initialized
INFO - 2018-05-22 01:18:01 --> Config Class Initialized
INFO - 2018-05-22 01:18:01 --> Hooks Class Initialized
INFO - 2018-05-22 01:18:01 --> Output Class Initialized
DEBUG - 2018-05-22 01:18:01 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:18:01 --> Utf8 Class Initialized
INFO - 2018-05-22 01:18:01 --> Security Class Initialized
DEBUG - 2018-05-22 01:18:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:18:01 --> URI Class Initialized
INFO - 2018-05-22 01:18:01 --> Input Class Initialized
INFO - 2018-05-22 01:18:01 --> Language Class Initialized
INFO - 2018-05-22 01:18:01 --> Router Class Initialized
INFO - 2018-05-22 01:18:01 --> Output Class Initialized
ERROR - 2018-05-22 01:18:01 --> 404 Page Not Found: /index
INFO - 2018-05-22 01:18:01 --> Security Class Initialized
DEBUG - 2018-05-22 01:18:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:18:01 --> Input Class Initialized
INFO - 2018-05-22 01:18:01 --> Language Class Initialized
ERROR - 2018-05-22 01:18:01 --> 404 Page Not Found: /index
INFO - 2018-05-22 01:18:01 --> Config Class Initialized
INFO - 2018-05-22 01:18:01 --> Hooks Class Initialized
DEBUG - 2018-05-22 01:18:01 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:18:01 --> Utf8 Class Initialized
INFO - 2018-05-22 01:18:01 --> URI Class Initialized
INFO - 2018-05-22 01:18:01 --> Router Class Initialized
INFO - 2018-05-22 01:18:01 --> Output Class Initialized
INFO - 2018-05-22 01:18:01 --> Security Class Initialized
DEBUG - 2018-05-22 01:18:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:18:01 --> Input Class Initialized
INFO - 2018-05-22 01:18:01 --> Language Class Initialized
ERROR - 2018-05-22 01:18:01 --> 404 Page Not Found: /index
INFO - 2018-05-22 01:18:01 --> Config Class Initialized
INFO - 2018-05-22 01:18:01 --> Hooks Class Initialized
DEBUG - 2018-05-22 01:18:01 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:18:01 --> Utf8 Class Initialized
INFO - 2018-05-22 01:18:01 --> URI Class Initialized
INFO - 2018-05-22 01:18:01 --> Router Class Initialized
INFO - 2018-05-22 01:18:01 --> Output Class Initialized
INFO - 2018-05-22 01:18:01 --> Security Class Initialized
DEBUG - 2018-05-22 01:18:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:18:01 --> Input Class Initialized
INFO - 2018-05-22 01:18:01 --> Language Class Initialized
ERROR - 2018-05-22 01:18:01 --> 404 Page Not Found: /index
INFO - 2018-05-22 01:18:16 --> Config Class Initialized
INFO - 2018-05-22 01:18:16 --> Hooks Class Initialized
DEBUG - 2018-05-22 01:18:16 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:18:16 --> Utf8 Class Initialized
INFO - 2018-05-22 01:18:16 --> URI Class Initialized
INFO - 2018-05-22 01:18:16 --> Router Class Initialized
INFO - 2018-05-22 01:18:16 --> Output Class Initialized
INFO - 2018-05-22 01:18:16 --> Security Class Initialized
DEBUG - 2018-05-22 01:18:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:18:16 --> Input Class Initialized
INFO - 2018-05-22 01:18:16 --> Language Class Initialized
ERROR - 2018-05-22 01:18:16 --> 404 Page Not Found: /index
INFO - 2018-05-22 01:20:58 --> Config Class Initialized
INFO - 2018-05-22 01:20:58 --> Hooks Class Initialized
DEBUG - 2018-05-22 01:20:58 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:20:58 --> Utf8 Class Initialized
INFO - 2018-05-22 01:20:58 --> URI Class Initialized
INFO - 2018-05-22 01:20:58 --> Router Class Initialized
INFO - 2018-05-22 01:20:58 --> Output Class Initialized
INFO - 2018-05-22 01:20:58 --> Security Class Initialized
DEBUG - 2018-05-22 01:20:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:20:58 --> Input Class Initialized
INFO - 2018-05-22 01:20:58 --> Language Class Initialized
ERROR - 2018-05-22 01:20:58 --> 404 Page Not Found: /index
INFO - 2018-05-22 01:36:45 --> Config Class Initialized
INFO - 2018-05-22 01:36:45 --> Hooks Class Initialized
DEBUG - 2018-05-22 01:36:45 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:36:45 --> Utf8 Class Initialized
INFO - 2018-05-22 01:36:45 --> URI Class Initialized
INFO - 2018-05-22 01:36:45 --> Router Class Initialized
INFO - 2018-05-22 01:36:45 --> Output Class Initialized
INFO - 2018-05-22 01:36:45 --> Security Class Initialized
DEBUG - 2018-05-22 01:36:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:36:45 --> Input Class Initialized
INFO - 2018-05-22 01:36:45 --> Language Class Initialized
INFO - 2018-05-22 01:36:45 --> Language Class Initialized
INFO - 2018-05-22 01:36:45 --> Config Class Initialized
INFO - 2018-05-22 01:36:45 --> Loader Class Initialized
DEBUG - 2018-05-22 01:36:45 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 01:36:45 --> Helper loaded: url_helper
INFO - 2018-05-22 01:36:45 --> Helper loaded: form_helper
INFO - 2018-05-22 01:36:45 --> Helper loaded: date_helper
INFO - 2018-05-22 01:36:45 --> Helper loaded: util_helper
INFO - 2018-05-22 01:36:45 --> Helper loaded: text_helper
INFO - 2018-05-22 01:36:45 --> Helper loaded: string_helper
INFO - 2018-05-22 01:36:45 --> Database Driver Class Initialized
DEBUG - 2018-05-22 01:36:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 01:36:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 01:36:45 --> Email Class Initialized
INFO - 2018-05-22 01:36:45 --> Controller Class Initialized
DEBUG - 2018-05-22 01:36:45 --> Profile MX_Controller Initialized
DEBUG - 2018-05-22 01:36:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 01:36:45 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 01:36:45 --> Login MX_Controller Initialized
INFO - 2018-05-22 01:36:45 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 01:36:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 01:36:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-22 01:36:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-22 01:36:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-22 01:36:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-22 01:36:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-05-22 01:36:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-22 01:36:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-22 01:36:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/reset_password.php
INFO - 2018-05-22 01:36:45 --> Final output sent to browser
DEBUG - 2018-05-22 01:36:46 --> Total execution time: 0.4299
INFO - 2018-05-22 01:36:47 --> Config Class Initialized
INFO - 2018-05-22 01:36:47 --> Hooks Class Initialized
DEBUG - 2018-05-22 01:36:47 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:36:47 --> Utf8 Class Initialized
INFO - 2018-05-22 01:36:47 --> URI Class Initialized
INFO - 2018-05-22 01:36:47 --> Router Class Initialized
INFO - 2018-05-22 01:36:47 --> Output Class Initialized
INFO - 2018-05-22 01:36:47 --> Security Class Initialized
DEBUG - 2018-05-22 01:36:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:36:47 --> Input Class Initialized
INFO - 2018-05-22 01:36:47 --> Language Class Initialized
ERROR - 2018-05-22 01:36:47 --> 404 Page Not Found: /index
INFO - 2018-05-22 01:36:47 --> Config Class Initialized
INFO - 2018-05-22 01:36:47 --> Hooks Class Initialized
DEBUG - 2018-05-22 01:36:47 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:36:47 --> Utf8 Class Initialized
INFO - 2018-05-22 01:36:47 --> URI Class Initialized
INFO - 2018-05-22 01:36:47 --> Router Class Initialized
INFO - 2018-05-22 01:36:47 --> Output Class Initialized
INFO - 2018-05-22 01:36:47 --> Security Class Initialized
DEBUG - 2018-05-22 01:36:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:36:47 --> Input Class Initialized
INFO - 2018-05-22 01:36:47 --> Language Class Initialized
ERROR - 2018-05-22 01:36:47 --> 404 Page Not Found: /index
INFO - 2018-05-22 01:36:47 --> Config Class Initialized
INFO - 2018-05-22 01:36:47 --> Hooks Class Initialized
DEBUG - 2018-05-22 01:36:48 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:36:48 --> Utf8 Class Initialized
INFO - 2018-05-22 01:36:48 --> URI Class Initialized
INFO - 2018-05-22 01:36:48 --> Router Class Initialized
INFO - 2018-05-22 01:36:48 --> Output Class Initialized
INFO - 2018-05-22 01:36:48 --> Security Class Initialized
DEBUG - 2018-05-22 01:36:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:36:48 --> Input Class Initialized
INFO - 2018-05-22 01:36:48 --> Language Class Initialized
ERROR - 2018-05-22 01:36:48 --> 404 Page Not Found: /index
INFO - 2018-05-22 01:37:00 --> Config Class Initialized
INFO - 2018-05-22 01:37:00 --> Hooks Class Initialized
DEBUG - 2018-05-22 01:37:00 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:37:00 --> Utf8 Class Initialized
INFO - 2018-05-22 01:37:00 --> URI Class Initialized
INFO - 2018-05-22 01:37:00 --> Router Class Initialized
INFO - 2018-05-22 01:37:00 --> Output Class Initialized
INFO - 2018-05-22 01:37:00 --> Security Class Initialized
DEBUG - 2018-05-22 01:37:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:37:00 --> Input Class Initialized
INFO - 2018-05-22 01:37:00 --> Language Class Initialized
INFO - 2018-05-22 01:37:00 --> Language Class Initialized
INFO - 2018-05-22 01:37:00 --> Config Class Initialized
INFO - 2018-05-22 01:37:00 --> Loader Class Initialized
DEBUG - 2018-05-22 01:37:00 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 01:37:00 --> Helper loaded: url_helper
INFO - 2018-05-22 01:37:00 --> Helper loaded: form_helper
INFO - 2018-05-22 01:37:00 --> Helper loaded: date_helper
INFO - 2018-05-22 01:37:00 --> Helper loaded: util_helper
INFO - 2018-05-22 01:37:00 --> Helper loaded: text_helper
INFO - 2018-05-22 01:37:00 --> Helper loaded: string_helper
INFO - 2018-05-22 01:37:00 --> Database Driver Class Initialized
DEBUG - 2018-05-22 01:37:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 01:37:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 01:37:00 --> Email Class Initialized
INFO - 2018-05-22 01:37:00 --> Controller Class Initialized
DEBUG - 2018-05-22 01:37:00 --> Profile MX_Controller Initialized
DEBUG - 2018-05-22 01:37:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 01:37:00 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 01:37:00 --> Login MX_Controller Initialized
INFO - 2018-05-22 01:37:00 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 01:37:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 01:37:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-22 01:37:05 --> Config Class Initialized
INFO - 2018-05-22 01:37:05 --> Hooks Class Initialized
DEBUG - 2018-05-22 01:37:05 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:37:05 --> Utf8 Class Initialized
INFO - 2018-05-22 01:37:05 --> URI Class Initialized
INFO - 2018-05-22 01:37:05 --> Router Class Initialized
INFO - 2018-05-22 01:37:05 --> Output Class Initialized
INFO - 2018-05-22 01:37:05 --> Security Class Initialized
DEBUG - 2018-05-22 01:37:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:37:05 --> Input Class Initialized
INFO - 2018-05-22 01:37:05 --> Language Class Initialized
INFO - 2018-05-22 01:37:05 --> Language Class Initialized
INFO - 2018-05-22 01:37:05 --> Config Class Initialized
INFO - 2018-05-22 01:37:05 --> Loader Class Initialized
DEBUG - 2018-05-22 01:37:05 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 01:37:05 --> Helper loaded: url_helper
INFO - 2018-05-22 01:37:05 --> Helper loaded: form_helper
INFO - 2018-05-22 01:37:05 --> Helper loaded: date_helper
INFO - 2018-05-22 01:37:05 --> Helper loaded: util_helper
INFO - 2018-05-22 01:37:05 --> Helper loaded: text_helper
INFO - 2018-05-22 01:37:05 --> Helper loaded: string_helper
INFO - 2018-05-22 01:37:05 --> Database Driver Class Initialized
DEBUG - 2018-05-22 01:37:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 01:37:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 01:37:05 --> Email Class Initialized
INFO - 2018-05-22 01:37:05 --> Controller Class Initialized
DEBUG - 2018-05-22 01:37:05 --> Profile MX_Controller Initialized
DEBUG - 2018-05-22 01:37:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 01:37:05 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 01:37:05 --> Login MX_Controller Initialized
INFO - 2018-05-22 01:37:05 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 01:37:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 01:37:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-22 01:38:05 --> Config Class Initialized
INFO - 2018-05-22 01:38:05 --> Hooks Class Initialized
DEBUG - 2018-05-22 01:38:05 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:38:05 --> Utf8 Class Initialized
INFO - 2018-05-22 01:38:05 --> URI Class Initialized
INFO - 2018-05-22 01:38:05 --> Router Class Initialized
INFO - 2018-05-22 01:38:05 --> Output Class Initialized
INFO - 2018-05-22 01:38:05 --> Security Class Initialized
DEBUG - 2018-05-22 01:38:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:38:05 --> Input Class Initialized
INFO - 2018-05-22 01:38:05 --> Language Class Initialized
INFO - 2018-05-22 01:38:05 --> Language Class Initialized
INFO - 2018-05-22 01:38:05 --> Config Class Initialized
INFO - 2018-05-22 01:38:05 --> Loader Class Initialized
DEBUG - 2018-05-22 01:38:05 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 01:38:05 --> Helper loaded: url_helper
INFO - 2018-05-22 01:38:05 --> Helper loaded: form_helper
INFO - 2018-05-22 01:38:05 --> Helper loaded: date_helper
INFO - 2018-05-22 01:38:05 --> Helper loaded: util_helper
INFO - 2018-05-22 01:38:05 --> Helper loaded: text_helper
INFO - 2018-05-22 01:38:05 --> Helper loaded: string_helper
INFO - 2018-05-22 01:38:05 --> Database Driver Class Initialized
DEBUG - 2018-05-22 01:38:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 01:38:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 01:38:05 --> Email Class Initialized
INFO - 2018-05-22 01:38:05 --> Controller Class Initialized
DEBUG - 2018-05-22 01:38:05 --> Profile MX_Controller Initialized
DEBUG - 2018-05-22 01:38:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 01:38:05 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 01:38:05 --> Login MX_Controller Initialized
INFO - 2018-05-22 01:38:05 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 01:38:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 01:38:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-22 01:38:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-22 01:38:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-22 01:38:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-22 01:38:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-05-22 01:38:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-22 01:38:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-22 01:38:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/reset_password.php
INFO - 2018-05-22 01:38:05 --> Final output sent to browser
DEBUG - 2018-05-22 01:38:05 --> Total execution time: 0.4470
INFO - 2018-05-22 01:38:07 --> Config Class Initialized
INFO - 2018-05-22 01:38:07 --> Hooks Class Initialized
DEBUG - 2018-05-22 01:38:07 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:38:07 --> Utf8 Class Initialized
INFO - 2018-05-22 01:38:07 --> URI Class Initialized
INFO - 2018-05-22 01:38:07 --> Router Class Initialized
INFO - 2018-05-22 01:38:07 --> Output Class Initialized
INFO - 2018-05-22 01:38:07 --> Security Class Initialized
DEBUG - 2018-05-22 01:38:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:38:07 --> Input Class Initialized
INFO - 2018-05-22 01:38:07 --> Language Class Initialized
ERROR - 2018-05-22 01:38:07 --> 404 Page Not Found: /index
INFO - 2018-05-22 01:38:07 --> Config Class Initialized
INFO - 2018-05-22 01:38:07 --> Hooks Class Initialized
DEBUG - 2018-05-22 01:38:07 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:38:07 --> Utf8 Class Initialized
INFO - 2018-05-22 01:38:07 --> URI Class Initialized
INFO - 2018-05-22 01:38:07 --> Router Class Initialized
INFO - 2018-05-22 01:38:07 --> Output Class Initialized
INFO - 2018-05-22 01:38:07 --> Security Class Initialized
DEBUG - 2018-05-22 01:38:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:38:07 --> Input Class Initialized
INFO - 2018-05-22 01:38:07 --> Language Class Initialized
ERROR - 2018-05-22 01:38:07 --> 404 Page Not Found: /index
INFO - 2018-05-22 01:38:07 --> Config Class Initialized
INFO - 2018-05-22 01:38:07 --> Hooks Class Initialized
DEBUG - 2018-05-22 01:38:08 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:38:08 --> Utf8 Class Initialized
INFO - 2018-05-22 01:38:08 --> URI Class Initialized
INFO - 2018-05-22 01:38:08 --> Router Class Initialized
INFO - 2018-05-22 01:38:08 --> Output Class Initialized
INFO - 2018-05-22 01:38:08 --> Security Class Initialized
DEBUG - 2018-05-22 01:38:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:38:08 --> Input Class Initialized
INFO - 2018-05-22 01:38:08 --> Language Class Initialized
ERROR - 2018-05-22 01:38:08 --> 404 Page Not Found: /index
INFO - 2018-05-22 01:38:08 --> Config Class Initialized
INFO - 2018-05-22 01:38:08 --> Hooks Class Initialized
DEBUG - 2018-05-22 01:38:08 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:38:08 --> Utf8 Class Initialized
INFO - 2018-05-22 01:38:08 --> URI Class Initialized
INFO - 2018-05-22 01:38:08 --> Router Class Initialized
INFO - 2018-05-22 01:38:08 --> Output Class Initialized
INFO - 2018-05-22 01:38:08 --> Security Class Initialized
DEBUG - 2018-05-22 01:38:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:38:08 --> Input Class Initialized
INFO - 2018-05-22 01:38:09 --> Language Class Initialized
ERROR - 2018-05-22 01:38:09 --> 404 Page Not Found: /index
INFO - 2018-05-22 01:38:09 --> Config Class Initialized
INFO - 2018-05-22 01:38:09 --> Hooks Class Initialized
DEBUG - 2018-05-22 01:38:09 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:38:09 --> Utf8 Class Initialized
INFO - 2018-05-22 01:38:09 --> URI Class Initialized
INFO - 2018-05-22 01:38:09 --> Router Class Initialized
INFO - 2018-05-22 01:38:09 --> Output Class Initialized
INFO - 2018-05-22 01:38:09 --> Security Class Initialized
DEBUG - 2018-05-22 01:38:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:38:09 --> Input Class Initialized
INFO - 2018-05-22 01:38:09 --> Language Class Initialized
ERROR - 2018-05-22 01:38:09 --> 404 Page Not Found: /index
INFO - 2018-05-22 01:38:09 --> Config Class Initialized
INFO - 2018-05-22 01:38:09 --> Hooks Class Initialized
DEBUG - 2018-05-22 01:38:09 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:38:09 --> Utf8 Class Initialized
INFO - 2018-05-22 01:38:09 --> URI Class Initialized
INFO - 2018-05-22 01:38:09 --> Router Class Initialized
INFO - 2018-05-22 01:38:09 --> Output Class Initialized
INFO - 2018-05-22 01:38:09 --> Security Class Initialized
DEBUG - 2018-05-22 01:38:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:38:09 --> Input Class Initialized
INFO - 2018-05-22 01:38:09 --> Language Class Initialized
ERROR - 2018-05-22 01:38:09 --> 404 Page Not Found: /index
INFO - 2018-05-22 01:38:16 --> Config Class Initialized
INFO - 2018-05-22 01:38:16 --> Hooks Class Initialized
DEBUG - 2018-05-22 01:38:16 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:38:16 --> Utf8 Class Initialized
INFO - 2018-05-22 01:38:16 --> URI Class Initialized
INFO - 2018-05-22 01:38:17 --> Router Class Initialized
INFO - 2018-05-22 01:38:17 --> Output Class Initialized
INFO - 2018-05-22 01:38:17 --> Security Class Initialized
DEBUG - 2018-05-22 01:38:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:38:17 --> Input Class Initialized
INFO - 2018-05-22 01:38:17 --> Language Class Initialized
INFO - 2018-05-22 01:38:17 --> Language Class Initialized
INFO - 2018-05-22 01:38:17 --> Config Class Initialized
INFO - 2018-05-22 01:38:17 --> Loader Class Initialized
DEBUG - 2018-05-22 01:38:17 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 01:38:17 --> Helper loaded: url_helper
INFO - 2018-05-22 01:38:17 --> Helper loaded: form_helper
INFO - 2018-05-22 01:38:17 --> Helper loaded: date_helper
INFO - 2018-05-22 01:38:17 --> Helper loaded: util_helper
INFO - 2018-05-22 01:38:17 --> Helper loaded: text_helper
INFO - 2018-05-22 01:38:17 --> Helper loaded: string_helper
INFO - 2018-05-22 01:38:17 --> Database Driver Class Initialized
DEBUG - 2018-05-22 01:38:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 01:38:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 01:38:17 --> Email Class Initialized
INFO - 2018-05-22 01:38:17 --> Controller Class Initialized
DEBUG - 2018-05-22 01:38:17 --> Profile MX_Controller Initialized
DEBUG - 2018-05-22 01:38:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 01:38:17 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 01:38:17 --> Login MX_Controller Initialized
INFO - 2018-05-22 01:38:17 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 01:38:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 01:38:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-22 01:38:25 --> Config Class Initialized
INFO - 2018-05-22 01:38:25 --> Hooks Class Initialized
DEBUG - 2018-05-22 01:38:25 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:38:25 --> Utf8 Class Initialized
INFO - 2018-05-22 01:38:25 --> URI Class Initialized
INFO - 2018-05-22 01:38:25 --> Router Class Initialized
INFO - 2018-05-22 01:38:25 --> Output Class Initialized
INFO - 2018-05-22 01:38:25 --> Security Class Initialized
DEBUG - 2018-05-22 01:38:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:38:25 --> Input Class Initialized
INFO - 2018-05-22 01:38:25 --> Language Class Initialized
INFO - 2018-05-22 01:38:25 --> Language Class Initialized
INFO - 2018-05-22 01:38:25 --> Config Class Initialized
INFO - 2018-05-22 01:38:25 --> Loader Class Initialized
DEBUG - 2018-05-22 01:38:25 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 01:38:25 --> Helper loaded: url_helper
INFO - 2018-05-22 01:38:25 --> Helper loaded: form_helper
INFO - 2018-05-22 01:38:25 --> Helper loaded: date_helper
INFO - 2018-05-22 01:38:25 --> Helper loaded: util_helper
INFO - 2018-05-22 01:38:25 --> Helper loaded: text_helper
INFO - 2018-05-22 01:38:25 --> Helper loaded: string_helper
INFO - 2018-05-22 01:38:26 --> Database Driver Class Initialized
DEBUG - 2018-05-22 01:38:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 01:38:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 01:38:26 --> Email Class Initialized
INFO - 2018-05-22 01:38:26 --> Controller Class Initialized
DEBUG - 2018-05-22 01:38:26 --> Profile MX_Controller Initialized
DEBUG - 2018-05-22 01:38:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 01:38:26 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 01:38:26 --> Login MX_Controller Initialized
INFO - 2018-05-22 01:38:26 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 01:38:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 01:38:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-22 01:38:49 --> Config Class Initialized
INFO - 2018-05-22 01:38:49 --> Hooks Class Initialized
DEBUG - 2018-05-22 01:38:49 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:38:50 --> Utf8 Class Initialized
INFO - 2018-05-22 01:38:50 --> URI Class Initialized
INFO - 2018-05-22 01:38:50 --> Router Class Initialized
INFO - 2018-05-22 01:38:50 --> Output Class Initialized
INFO - 2018-05-22 01:38:50 --> Security Class Initialized
DEBUG - 2018-05-22 01:38:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:38:50 --> Input Class Initialized
INFO - 2018-05-22 01:38:50 --> Language Class Initialized
INFO - 2018-05-22 01:38:50 --> Language Class Initialized
INFO - 2018-05-22 01:38:50 --> Config Class Initialized
INFO - 2018-05-22 01:38:50 --> Loader Class Initialized
DEBUG - 2018-05-22 01:38:50 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 01:38:50 --> Helper loaded: url_helper
INFO - 2018-05-22 01:38:50 --> Helper loaded: form_helper
INFO - 2018-05-22 01:38:50 --> Helper loaded: date_helper
INFO - 2018-05-22 01:38:50 --> Helper loaded: util_helper
INFO - 2018-05-22 01:38:50 --> Helper loaded: text_helper
INFO - 2018-05-22 01:38:50 --> Helper loaded: string_helper
INFO - 2018-05-22 01:38:50 --> Database Driver Class Initialized
DEBUG - 2018-05-22 01:38:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 01:38:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 01:38:50 --> Email Class Initialized
INFO - 2018-05-22 01:38:50 --> Controller Class Initialized
DEBUG - 2018-05-22 01:38:50 --> Profile MX_Controller Initialized
DEBUG - 2018-05-22 01:38:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 01:38:50 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 01:38:50 --> Login MX_Controller Initialized
INFO - 2018-05-22 01:38:50 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 01:38:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 01:38:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-22 01:38:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-22 01:38:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-22 01:38:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-22 01:38:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-05-22 01:38:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-22 01:38:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-22 01:38:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/reset_password.php
INFO - 2018-05-22 01:38:50 --> Final output sent to browser
DEBUG - 2018-05-22 01:38:50 --> Total execution time: 0.4529
INFO - 2018-05-22 01:38:51 --> Config Class Initialized
INFO - 2018-05-22 01:38:51 --> Hooks Class Initialized
DEBUG - 2018-05-22 01:38:51 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:38:51 --> Utf8 Class Initialized
INFO - 2018-05-22 01:38:51 --> URI Class Initialized
INFO - 2018-05-22 01:38:51 --> Router Class Initialized
INFO - 2018-05-22 01:38:51 --> Output Class Initialized
INFO - 2018-05-22 01:38:51 --> Security Class Initialized
DEBUG - 2018-05-22 01:38:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:38:51 --> Input Class Initialized
INFO - 2018-05-22 01:38:51 --> Language Class Initialized
ERROR - 2018-05-22 01:38:51 --> 404 Page Not Found: /index
INFO - 2018-05-22 01:38:51 --> Config Class Initialized
INFO - 2018-05-22 01:38:51 --> Hooks Class Initialized
DEBUG - 2018-05-22 01:38:51 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:38:51 --> Utf8 Class Initialized
INFO - 2018-05-22 01:38:51 --> URI Class Initialized
INFO - 2018-05-22 01:38:51 --> Router Class Initialized
INFO - 2018-05-22 01:38:51 --> Output Class Initialized
INFO - 2018-05-22 01:38:51 --> Security Class Initialized
DEBUG - 2018-05-22 01:38:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:38:51 --> Input Class Initialized
INFO - 2018-05-22 01:38:51 --> Language Class Initialized
ERROR - 2018-05-22 01:38:51 --> 404 Page Not Found: /index
INFO - 2018-05-22 01:38:51 --> Config Class Initialized
INFO - 2018-05-22 01:38:51 --> Hooks Class Initialized
DEBUG - 2018-05-22 01:38:51 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:38:51 --> Utf8 Class Initialized
INFO - 2018-05-22 01:38:51 --> URI Class Initialized
INFO - 2018-05-22 01:38:51 --> Router Class Initialized
INFO - 2018-05-22 01:38:51 --> Output Class Initialized
INFO - 2018-05-22 01:38:51 --> Security Class Initialized
DEBUG - 2018-05-22 01:38:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:38:51 --> Input Class Initialized
INFO - 2018-05-22 01:38:51 --> Language Class Initialized
ERROR - 2018-05-22 01:38:51 --> 404 Page Not Found: /index
INFO - 2018-05-22 01:38:53 --> Config Class Initialized
INFO - 2018-05-22 01:38:53 --> Hooks Class Initialized
DEBUG - 2018-05-22 01:38:53 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:38:53 --> Utf8 Class Initialized
INFO - 2018-05-22 01:38:53 --> URI Class Initialized
INFO - 2018-05-22 01:38:53 --> Router Class Initialized
INFO - 2018-05-22 01:38:53 --> Output Class Initialized
INFO - 2018-05-22 01:38:53 --> Security Class Initialized
DEBUG - 2018-05-22 01:38:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:38:53 --> Input Class Initialized
INFO - 2018-05-22 01:38:53 --> Language Class Initialized
ERROR - 2018-05-22 01:38:53 --> 404 Page Not Found: /index
INFO - 2018-05-22 01:38:53 --> Config Class Initialized
INFO - 2018-05-22 01:38:53 --> Hooks Class Initialized
DEBUG - 2018-05-22 01:38:53 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:38:53 --> Utf8 Class Initialized
INFO - 2018-05-22 01:38:53 --> URI Class Initialized
INFO - 2018-05-22 01:38:53 --> Router Class Initialized
INFO - 2018-05-22 01:38:53 --> Output Class Initialized
INFO - 2018-05-22 01:38:53 --> Security Class Initialized
DEBUG - 2018-05-22 01:38:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:38:53 --> Input Class Initialized
INFO - 2018-05-22 01:38:53 --> Language Class Initialized
ERROR - 2018-05-22 01:38:53 --> 404 Page Not Found: /index
INFO - 2018-05-22 01:38:53 --> Config Class Initialized
INFO - 2018-05-22 01:38:53 --> Hooks Class Initialized
DEBUG - 2018-05-22 01:38:53 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:38:53 --> Utf8 Class Initialized
INFO - 2018-05-22 01:38:53 --> URI Class Initialized
INFO - 2018-05-22 01:38:53 --> Router Class Initialized
INFO - 2018-05-22 01:38:53 --> Output Class Initialized
INFO - 2018-05-22 01:38:54 --> Security Class Initialized
DEBUG - 2018-05-22 01:38:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:38:54 --> Input Class Initialized
INFO - 2018-05-22 01:38:54 --> Language Class Initialized
ERROR - 2018-05-22 01:38:54 --> 404 Page Not Found: /index
INFO - 2018-05-22 01:39:08 --> Config Class Initialized
INFO - 2018-05-22 01:39:08 --> Hooks Class Initialized
DEBUG - 2018-05-22 01:39:08 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:39:08 --> Utf8 Class Initialized
INFO - 2018-05-22 01:39:08 --> URI Class Initialized
INFO - 2018-05-22 01:39:08 --> Router Class Initialized
INFO - 2018-05-22 01:39:08 --> Output Class Initialized
INFO - 2018-05-22 01:39:08 --> Security Class Initialized
DEBUG - 2018-05-22 01:39:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:39:08 --> Input Class Initialized
INFO - 2018-05-22 01:39:08 --> Language Class Initialized
INFO - 2018-05-22 01:39:08 --> Language Class Initialized
INFO - 2018-05-22 01:39:08 --> Config Class Initialized
INFO - 2018-05-22 01:39:08 --> Loader Class Initialized
DEBUG - 2018-05-22 01:39:08 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 01:39:08 --> Helper loaded: url_helper
INFO - 2018-05-22 01:39:08 --> Helper loaded: form_helper
INFO - 2018-05-22 01:39:08 --> Helper loaded: date_helper
INFO - 2018-05-22 01:39:08 --> Helper loaded: util_helper
INFO - 2018-05-22 01:39:08 --> Helper loaded: text_helper
INFO - 2018-05-22 01:39:08 --> Helper loaded: string_helper
INFO - 2018-05-22 01:39:08 --> Database Driver Class Initialized
DEBUG - 2018-05-22 01:39:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 01:39:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 01:39:08 --> Email Class Initialized
INFO - 2018-05-22 01:39:08 --> Controller Class Initialized
DEBUG - 2018-05-22 01:39:08 --> Profile MX_Controller Initialized
DEBUG - 2018-05-22 01:39:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 01:39:09 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 01:39:09 --> Login MX_Controller Initialized
INFO - 2018-05-22 01:39:09 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 01:39:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 01:39:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-22 01:39:18 --> Config Class Initialized
INFO - 2018-05-22 01:39:18 --> Hooks Class Initialized
DEBUG - 2018-05-22 01:39:18 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:39:18 --> Utf8 Class Initialized
INFO - 2018-05-22 01:39:18 --> URI Class Initialized
INFO - 2018-05-22 01:39:18 --> Router Class Initialized
INFO - 2018-05-22 01:39:18 --> Output Class Initialized
INFO - 2018-05-22 01:39:18 --> Security Class Initialized
DEBUG - 2018-05-22 01:39:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:39:18 --> Input Class Initialized
INFO - 2018-05-22 01:39:18 --> Language Class Initialized
INFO - 2018-05-22 01:39:18 --> Language Class Initialized
INFO - 2018-05-22 01:39:18 --> Config Class Initialized
INFO - 2018-05-22 01:39:18 --> Loader Class Initialized
DEBUG - 2018-05-22 01:39:18 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 01:39:18 --> Helper loaded: url_helper
INFO - 2018-05-22 01:39:18 --> Helper loaded: form_helper
INFO - 2018-05-22 01:39:18 --> Helper loaded: date_helper
INFO - 2018-05-22 01:39:18 --> Helper loaded: util_helper
INFO - 2018-05-22 01:39:18 --> Helper loaded: text_helper
INFO - 2018-05-22 01:39:18 --> Helper loaded: string_helper
INFO - 2018-05-22 01:39:18 --> Database Driver Class Initialized
DEBUG - 2018-05-22 01:39:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 01:39:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 01:39:18 --> Email Class Initialized
INFO - 2018-05-22 01:39:18 --> Controller Class Initialized
DEBUG - 2018-05-22 01:39:18 --> Profile MX_Controller Initialized
DEBUG - 2018-05-22 01:39:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 01:39:18 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 01:39:18 --> Login MX_Controller Initialized
INFO - 2018-05-22 01:39:18 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 01:39:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 01:39:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-22 01:39:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-22 01:39:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-22 01:39:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-22 01:39:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-05-22 01:39:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-22 01:39:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-22 01:39:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/reset_password.php
INFO - 2018-05-22 01:39:18 --> Final output sent to browser
DEBUG - 2018-05-22 01:39:18 --> Total execution time: 0.4522
INFO - 2018-05-22 01:39:19 --> Config Class Initialized
INFO - 2018-05-22 01:39:19 --> Hooks Class Initialized
DEBUG - 2018-05-22 01:39:19 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:39:19 --> Utf8 Class Initialized
INFO - 2018-05-22 01:39:19 --> URI Class Initialized
INFO - 2018-05-22 01:39:19 --> Router Class Initialized
INFO - 2018-05-22 01:39:19 --> Output Class Initialized
INFO - 2018-05-22 01:39:19 --> Security Class Initialized
DEBUG - 2018-05-22 01:39:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:39:19 --> Input Class Initialized
INFO - 2018-05-22 01:39:19 --> Language Class Initialized
ERROR - 2018-05-22 01:39:19 --> 404 Page Not Found: /index
INFO - 2018-05-22 01:39:19 --> Config Class Initialized
INFO - 2018-05-22 01:39:19 --> Hooks Class Initialized
DEBUG - 2018-05-22 01:39:19 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:39:19 --> Utf8 Class Initialized
INFO - 2018-05-22 01:39:19 --> URI Class Initialized
INFO - 2018-05-22 01:39:19 --> Router Class Initialized
INFO - 2018-05-22 01:39:19 --> Output Class Initialized
INFO - 2018-05-22 01:39:19 --> Security Class Initialized
DEBUG - 2018-05-22 01:39:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:39:19 --> Input Class Initialized
INFO - 2018-05-22 01:39:19 --> Language Class Initialized
ERROR - 2018-05-22 01:39:19 --> 404 Page Not Found: /index
INFO - 2018-05-22 01:39:20 --> Config Class Initialized
INFO - 2018-05-22 01:39:20 --> Hooks Class Initialized
DEBUG - 2018-05-22 01:39:20 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:39:20 --> Utf8 Class Initialized
INFO - 2018-05-22 01:39:20 --> URI Class Initialized
INFO - 2018-05-22 01:39:20 --> Router Class Initialized
INFO - 2018-05-22 01:39:20 --> Output Class Initialized
INFO - 2018-05-22 01:39:20 --> Security Class Initialized
DEBUG - 2018-05-22 01:39:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:39:20 --> Input Class Initialized
INFO - 2018-05-22 01:39:20 --> Language Class Initialized
ERROR - 2018-05-22 01:39:20 --> 404 Page Not Found: /index
INFO - 2018-05-22 01:39:21 --> Config Class Initialized
INFO - 2018-05-22 01:39:21 --> Hooks Class Initialized
DEBUG - 2018-05-22 01:39:21 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:39:21 --> Utf8 Class Initialized
INFO - 2018-05-22 01:39:21 --> URI Class Initialized
INFO - 2018-05-22 01:39:21 --> Router Class Initialized
INFO - 2018-05-22 01:39:21 --> Output Class Initialized
INFO - 2018-05-22 01:39:21 --> Security Class Initialized
DEBUG - 2018-05-22 01:39:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:39:21 --> Input Class Initialized
INFO - 2018-05-22 01:39:21 --> Language Class Initialized
ERROR - 2018-05-22 01:39:21 --> 404 Page Not Found: /index
INFO - 2018-05-22 01:39:21 --> Config Class Initialized
INFO - 2018-05-22 01:39:21 --> Hooks Class Initialized
DEBUG - 2018-05-22 01:39:21 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:39:21 --> Utf8 Class Initialized
INFO - 2018-05-22 01:39:21 --> URI Class Initialized
INFO - 2018-05-22 01:39:21 --> Router Class Initialized
INFO - 2018-05-22 01:39:21 --> Output Class Initialized
INFO - 2018-05-22 01:39:21 --> Security Class Initialized
DEBUG - 2018-05-22 01:39:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:39:21 --> Input Class Initialized
INFO - 2018-05-22 01:39:21 --> Language Class Initialized
ERROR - 2018-05-22 01:39:21 --> 404 Page Not Found: /index
INFO - 2018-05-22 01:39:21 --> Config Class Initialized
INFO - 2018-05-22 01:39:21 --> Hooks Class Initialized
DEBUG - 2018-05-22 01:39:21 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:39:21 --> Utf8 Class Initialized
INFO - 2018-05-22 01:39:21 --> URI Class Initialized
INFO - 2018-05-22 01:39:21 --> Router Class Initialized
INFO - 2018-05-22 01:39:22 --> Output Class Initialized
INFO - 2018-05-22 01:39:22 --> Security Class Initialized
DEBUG - 2018-05-22 01:39:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:39:22 --> Input Class Initialized
INFO - 2018-05-22 01:39:22 --> Language Class Initialized
ERROR - 2018-05-22 01:39:22 --> 404 Page Not Found: /index
INFO - 2018-05-22 01:39:29 --> Config Class Initialized
INFO - 2018-05-22 01:39:29 --> Hooks Class Initialized
DEBUG - 2018-05-22 01:39:29 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:39:29 --> Utf8 Class Initialized
INFO - 2018-05-22 01:39:29 --> URI Class Initialized
INFO - 2018-05-22 01:39:29 --> Router Class Initialized
INFO - 2018-05-22 01:39:29 --> Output Class Initialized
INFO - 2018-05-22 01:39:29 --> Security Class Initialized
DEBUG - 2018-05-22 01:39:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:39:29 --> Input Class Initialized
INFO - 2018-05-22 01:39:29 --> Language Class Initialized
INFO - 2018-05-22 01:39:29 --> Language Class Initialized
INFO - 2018-05-22 01:39:29 --> Config Class Initialized
INFO - 2018-05-22 01:39:29 --> Loader Class Initialized
DEBUG - 2018-05-22 01:39:29 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 01:39:29 --> Helper loaded: url_helper
INFO - 2018-05-22 01:39:29 --> Helper loaded: form_helper
INFO - 2018-05-22 01:39:29 --> Helper loaded: date_helper
INFO - 2018-05-22 01:39:29 --> Helper loaded: util_helper
INFO - 2018-05-22 01:39:29 --> Helper loaded: text_helper
INFO - 2018-05-22 01:39:29 --> Helper loaded: string_helper
INFO - 2018-05-22 01:39:29 --> Database Driver Class Initialized
DEBUG - 2018-05-22 01:39:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 01:39:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 01:39:29 --> Email Class Initialized
INFO - 2018-05-22 01:39:29 --> Controller Class Initialized
DEBUG - 2018-05-22 01:39:29 --> Profile MX_Controller Initialized
DEBUG - 2018-05-22 01:39:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 01:39:29 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 01:39:29 --> Login MX_Controller Initialized
INFO - 2018-05-22 01:39:29 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 01:39:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 01:39:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-22 01:39:44 --> Config Class Initialized
INFO - 2018-05-22 01:39:44 --> Hooks Class Initialized
DEBUG - 2018-05-22 01:39:44 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:39:44 --> Utf8 Class Initialized
INFO - 2018-05-22 01:39:44 --> URI Class Initialized
INFO - 2018-05-22 01:39:44 --> Router Class Initialized
INFO - 2018-05-22 01:39:44 --> Output Class Initialized
INFO - 2018-05-22 01:39:44 --> Security Class Initialized
DEBUG - 2018-05-22 01:39:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:39:44 --> Input Class Initialized
INFO - 2018-05-22 01:39:44 --> Language Class Initialized
INFO - 2018-05-22 01:39:44 --> Language Class Initialized
INFO - 2018-05-22 01:39:44 --> Config Class Initialized
INFO - 2018-05-22 01:39:44 --> Loader Class Initialized
DEBUG - 2018-05-22 01:39:44 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 01:39:44 --> Helper loaded: url_helper
INFO - 2018-05-22 01:39:44 --> Helper loaded: form_helper
INFO - 2018-05-22 01:39:44 --> Helper loaded: date_helper
INFO - 2018-05-22 01:39:44 --> Helper loaded: util_helper
INFO - 2018-05-22 01:39:44 --> Helper loaded: text_helper
INFO - 2018-05-22 01:39:44 --> Helper loaded: string_helper
INFO - 2018-05-22 01:39:44 --> Database Driver Class Initialized
DEBUG - 2018-05-22 01:39:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 01:39:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 01:39:44 --> Email Class Initialized
INFO - 2018-05-22 01:39:44 --> Controller Class Initialized
DEBUG - 2018-05-22 01:39:44 --> Profile MX_Controller Initialized
DEBUG - 2018-05-22 01:39:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 01:39:44 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 01:39:44 --> Login MX_Controller Initialized
INFO - 2018-05-22 01:39:44 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 01:39:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 01:39:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-22 01:39:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-22 01:39:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-22 01:39:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-22 01:39:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-05-22 01:39:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-22 01:39:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-22 01:39:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/reset_password.php
INFO - 2018-05-22 01:39:44 --> Final output sent to browser
DEBUG - 2018-05-22 01:39:44 --> Total execution time: 0.4632
INFO - 2018-05-22 01:39:45 --> Config Class Initialized
INFO - 2018-05-22 01:39:45 --> Hooks Class Initialized
DEBUG - 2018-05-22 01:39:45 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:39:45 --> Utf8 Class Initialized
INFO - 2018-05-22 01:39:45 --> URI Class Initialized
INFO - 2018-05-22 01:39:45 --> Router Class Initialized
INFO - 2018-05-22 01:39:45 --> Output Class Initialized
INFO - 2018-05-22 01:39:45 --> Security Class Initialized
DEBUG - 2018-05-22 01:39:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:39:45 --> Input Class Initialized
INFO - 2018-05-22 01:39:45 --> Language Class Initialized
ERROR - 2018-05-22 01:39:45 --> 404 Page Not Found: /index
INFO - 2018-05-22 01:39:45 --> Config Class Initialized
INFO - 2018-05-22 01:39:45 --> Hooks Class Initialized
DEBUG - 2018-05-22 01:39:45 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:39:45 --> Utf8 Class Initialized
INFO - 2018-05-22 01:39:45 --> URI Class Initialized
INFO - 2018-05-22 01:39:45 --> Router Class Initialized
INFO - 2018-05-22 01:39:45 --> Output Class Initialized
INFO - 2018-05-22 01:39:45 --> Security Class Initialized
DEBUG - 2018-05-22 01:39:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:39:45 --> Input Class Initialized
INFO - 2018-05-22 01:39:46 --> Language Class Initialized
ERROR - 2018-05-22 01:39:46 --> 404 Page Not Found: /index
INFO - 2018-05-22 01:39:46 --> Config Class Initialized
INFO - 2018-05-22 01:39:46 --> Hooks Class Initialized
DEBUG - 2018-05-22 01:39:46 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:39:46 --> Utf8 Class Initialized
INFO - 2018-05-22 01:39:46 --> URI Class Initialized
INFO - 2018-05-22 01:39:46 --> Router Class Initialized
INFO - 2018-05-22 01:39:46 --> Output Class Initialized
INFO - 2018-05-22 01:39:46 --> Security Class Initialized
DEBUG - 2018-05-22 01:39:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:39:46 --> Input Class Initialized
INFO - 2018-05-22 01:39:46 --> Language Class Initialized
ERROR - 2018-05-22 01:39:46 --> 404 Page Not Found: /index
INFO - 2018-05-22 01:39:47 --> Config Class Initialized
INFO - 2018-05-22 01:39:47 --> Hooks Class Initialized
DEBUG - 2018-05-22 01:39:47 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:39:47 --> Utf8 Class Initialized
INFO - 2018-05-22 01:39:47 --> URI Class Initialized
INFO - 2018-05-22 01:39:47 --> Router Class Initialized
INFO - 2018-05-22 01:39:47 --> Output Class Initialized
INFO - 2018-05-22 01:39:47 --> Security Class Initialized
DEBUG - 2018-05-22 01:39:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:39:47 --> Input Class Initialized
INFO - 2018-05-22 01:39:47 --> Language Class Initialized
ERROR - 2018-05-22 01:39:47 --> 404 Page Not Found: /index
INFO - 2018-05-22 01:39:47 --> Config Class Initialized
INFO - 2018-05-22 01:39:47 --> Hooks Class Initialized
DEBUG - 2018-05-22 01:39:47 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:39:47 --> Utf8 Class Initialized
INFO - 2018-05-22 01:39:47 --> URI Class Initialized
INFO - 2018-05-22 01:39:47 --> Router Class Initialized
INFO - 2018-05-22 01:39:47 --> Output Class Initialized
INFO - 2018-05-22 01:39:47 --> Security Class Initialized
DEBUG - 2018-05-22 01:39:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:39:47 --> Input Class Initialized
INFO - 2018-05-22 01:39:47 --> Language Class Initialized
ERROR - 2018-05-22 01:39:47 --> 404 Page Not Found: /index
INFO - 2018-05-22 01:39:47 --> Config Class Initialized
INFO - 2018-05-22 01:39:47 --> Hooks Class Initialized
DEBUG - 2018-05-22 01:39:47 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:39:47 --> Utf8 Class Initialized
INFO - 2018-05-22 01:39:47 --> URI Class Initialized
INFO - 2018-05-22 01:39:47 --> Router Class Initialized
INFO - 2018-05-22 01:39:47 --> Output Class Initialized
INFO - 2018-05-22 01:39:47 --> Security Class Initialized
DEBUG - 2018-05-22 01:39:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:39:47 --> Input Class Initialized
INFO - 2018-05-22 01:39:47 --> Language Class Initialized
ERROR - 2018-05-22 01:39:47 --> 404 Page Not Found: /index
INFO - 2018-05-22 01:40:17 --> Config Class Initialized
INFO - 2018-05-22 01:40:17 --> Hooks Class Initialized
DEBUG - 2018-05-22 01:40:17 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:40:17 --> Utf8 Class Initialized
INFO - 2018-05-22 01:40:17 --> URI Class Initialized
INFO - 2018-05-22 01:40:17 --> Router Class Initialized
INFO - 2018-05-22 01:40:17 --> Output Class Initialized
INFO - 2018-05-22 01:40:17 --> Security Class Initialized
DEBUG - 2018-05-22 01:40:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:40:17 --> Input Class Initialized
INFO - 2018-05-22 01:40:17 --> Language Class Initialized
INFO - 2018-05-22 01:40:17 --> Language Class Initialized
INFO - 2018-05-22 01:40:17 --> Config Class Initialized
INFO - 2018-05-22 01:40:17 --> Loader Class Initialized
DEBUG - 2018-05-22 01:40:17 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 01:40:17 --> Helper loaded: url_helper
INFO - 2018-05-22 01:40:17 --> Helper loaded: form_helper
INFO - 2018-05-22 01:40:17 --> Helper loaded: date_helper
INFO - 2018-05-22 01:40:17 --> Helper loaded: util_helper
INFO - 2018-05-22 01:40:17 --> Helper loaded: text_helper
INFO - 2018-05-22 01:40:17 --> Helper loaded: string_helper
INFO - 2018-05-22 01:40:17 --> Database Driver Class Initialized
DEBUG - 2018-05-22 01:40:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 01:40:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 01:40:17 --> Email Class Initialized
INFO - 2018-05-22 01:40:17 --> Controller Class Initialized
DEBUG - 2018-05-22 01:40:17 --> Profile MX_Controller Initialized
DEBUG - 2018-05-22 01:40:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 01:40:17 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 01:40:17 --> Login MX_Controller Initialized
INFO - 2018-05-22 01:40:17 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 01:40:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 01:40:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-22 01:40:21 --> Config Class Initialized
INFO - 2018-05-22 01:40:21 --> Hooks Class Initialized
DEBUG - 2018-05-22 01:40:21 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:40:21 --> Utf8 Class Initialized
INFO - 2018-05-22 01:40:21 --> URI Class Initialized
INFO - 2018-05-22 01:40:21 --> Router Class Initialized
INFO - 2018-05-22 01:40:21 --> Output Class Initialized
INFO - 2018-05-22 01:40:21 --> Security Class Initialized
DEBUG - 2018-05-22 01:40:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:40:21 --> Input Class Initialized
INFO - 2018-05-22 01:40:21 --> Language Class Initialized
INFO - 2018-05-22 01:40:21 --> Language Class Initialized
INFO - 2018-05-22 01:40:21 --> Config Class Initialized
INFO - 2018-05-22 01:40:21 --> Loader Class Initialized
DEBUG - 2018-05-22 01:40:21 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 01:40:21 --> Helper loaded: url_helper
INFO - 2018-05-22 01:40:21 --> Helper loaded: form_helper
INFO - 2018-05-22 01:40:21 --> Helper loaded: date_helper
INFO - 2018-05-22 01:40:21 --> Helper loaded: util_helper
INFO - 2018-05-22 01:40:21 --> Helper loaded: text_helper
INFO - 2018-05-22 01:40:21 --> Helper loaded: string_helper
INFO - 2018-05-22 01:40:21 --> Database Driver Class Initialized
DEBUG - 2018-05-22 01:40:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 01:40:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 01:40:21 --> Email Class Initialized
INFO - 2018-05-22 01:40:21 --> Controller Class Initialized
DEBUG - 2018-05-22 01:40:21 --> Profile MX_Controller Initialized
DEBUG - 2018-05-22 01:40:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 01:40:21 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 01:40:21 --> Login MX_Controller Initialized
INFO - 2018-05-22 01:40:21 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 01:40:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 01:40:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-22 01:40:24 --> Config Class Initialized
INFO - 2018-05-22 01:40:24 --> Hooks Class Initialized
DEBUG - 2018-05-22 01:40:24 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:40:24 --> Utf8 Class Initialized
INFO - 2018-05-22 01:40:24 --> URI Class Initialized
INFO - 2018-05-22 01:40:24 --> Router Class Initialized
INFO - 2018-05-22 01:40:24 --> Output Class Initialized
INFO - 2018-05-22 01:40:24 --> Security Class Initialized
DEBUG - 2018-05-22 01:40:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:40:24 --> Input Class Initialized
INFO - 2018-05-22 01:40:24 --> Language Class Initialized
INFO - 2018-05-22 01:40:24 --> Language Class Initialized
INFO - 2018-05-22 01:40:24 --> Config Class Initialized
INFO - 2018-05-22 01:40:24 --> Loader Class Initialized
DEBUG - 2018-05-22 01:40:24 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 01:40:24 --> Helper loaded: url_helper
INFO - 2018-05-22 01:40:24 --> Helper loaded: form_helper
INFO - 2018-05-22 01:40:24 --> Helper loaded: date_helper
INFO - 2018-05-22 01:40:24 --> Helper loaded: util_helper
INFO - 2018-05-22 01:40:24 --> Helper loaded: text_helper
INFO - 2018-05-22 01:40:24 --> Helper loaded: string_helper
INFO - 2018-05-22 01:40:24 --> Database Driver Class Initialized
DEBUG - 2018-05-22 01:40:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 01:40:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 01:40:25 --> Email Class Initialized
INFO - 2018-05-22 01:40:25 --> Controller Class Initialized
DEBUG - 2018-05-22 01:40:25 --> Profile MX_Controller Initialized
DEBUG - 2018-05-22 01:40:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 01:40:25 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 01:40:25 --> Login MX_Controller Initialized
INFO - 2018-05-22 01:40:25 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 01:40:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 01:40:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-22 01:41:14 --> Config Class Initialized
INFO - 2018-05-22 01:41:14 --> Hooks Class Initialized
DEBUG - 2018-05-22 01:41:14 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:41:14 --> Utf8 Class Initialized
INFO - 2018-05-22 01:41:14 --> URI Class Initialized
INFO - 2018-05-22 01:41:14 --> Router Class Initialized
INFO - 2018-05-22 01:41:14 --> Output Class Initialized
INFO - 2018-05-22 01:41:14 --> Security Class Initialized
DEBUG - 2018-05-22 01:41:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:41:14 --> Input Class Initialized
INFO - 2018-05-22 01:41:14 --> Language Class Initialized
INFO - 2018-05-22 01:41:14 --> Language Class Initialized
INFO - 2018-05-22 01:41:14 --> Config Class Initialized
INFO - 2018-05-22 01:41:14 --> Loader Class Initialized
DEBUG - 2018-05-22 01:41:14 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 01:41:14 --> Helper loaded: url_helper
INFO - 2018-05-22 01:41:14 --> Helper loaded: form_helper
INFO - 2018-05-22 01:41:14 --> Helper loaded: date_helper
INFO - 2018-05-22 01:41:14 --> Helper loaded: util_helper
INFO - 2018-05-22 01:41:14 --> Helper loaded: text_helper
INFO - 2018-05-22 01:41:14 --> Helper loaded: string_helper
INFO - 2018-05-22 01:41:14 --> Database Driver Class Initialized
DEBUG - 2018-05-22 01:41:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 01:41:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 01:41:14 --> Email Class Initialized
INFO - 2018-05-22 01:41:14 --> Controller Class Initialized
DEBUG - 2018-05-22 01:41:14 --> Profile MX_Controller Initialized
DEBUG - 2018-05-22 01:41:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 01:41:14 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 01:41:14 --> Login MX_Controller Initialized
INFO - 2018-05-22 01:41:14 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 01:41:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 01:41:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-22 01:41:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-22 01:41:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-22 01:41:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-22 01:41:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-05-22 01:41:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-22 01:41:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-22 01:41:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/profile.php
INFO - 2018-05-22 01:41:14 --> Final output sent to browser
DEBUG - 2018-05-22 01:41:14 --> Total execution time: 0.5691
INFO - 2018-05-22 01:41:14 --> Config Class Initialized
INFO - 2018-05-22 01:41:14 --> Hooks Class Initialized
DEBUG - 2018-05-22 01:41:14 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:41:14 --> Utf8 Class Initialized
INFO - 2018-05-22 01:41:14 --> URI Class Initialized
INFO - 2018-05-22 01:41:14 --> Router Class Initialized
INFO - 2018-05-22 01:41:14 --> Output Class Initialized
INFO - 2018-05-22 01:41:14 --> Security Class Initialized
DEBUG - 2018-05-22 01:41:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:41:14 --> Input Class Initialized
INFO - 2018-05-22 01:41:14 --> Language Class Initialized
ERROR - 2018-05-22 01:41:15 --> 404 Page Not Found: /index
INFO - 2018-05-22 01:41:15 --> Config Class Initialized
INFO - 2018-05-22 01:41:15 --> Hooks Class Initialized
DEBUG - 2018-05-22 01:41:15 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:41:15 --> Utf8 Class Initialized
INFO - 2018-05-22 01:41:15 --> URI Class Initialized
INFO - 2018-05-22 01:41:15 --> Config Class Initialized
INFO - 2018-05-22 01:41:15 --> Router Class Initialized
INFO - 2018-05-22 01:41:15 --> Hooks Class Initialized
INFO - 2018-05-22 01:41:15 --> Output Class Initialized
INFO - 2018-05-22 01:41:15 --> Security Class Initialized
DEBUG - 2018-05-22 01:41:15 --> UTF-8 Support Enabled
DEBUG - 2018-05-22 01:41:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:41:15 --> Input Class Initialized
INFO - 2018-05-22 01:41:15 --> Language Class Initialized
INFO - 2018-05-22 01:41:15 --> Utf8 Class Initialized
ERROR - 2018-05-22 01:41:15 --> 404 Page Not Found: /index
INFO - 2018-05-22 01:41:15 --> URI Class Initialized
INFO - 2018-05-22 01:41:15 --> Config Class Initialized
INFO - 2018-05-22 01:41:15 --> Hooks Class Initialized
INFO - 2018-05-22 01:41:15 --> Router Class Initialized
INFO - 2018-05-22 01:41:15 --> Output Class Initialized
DEBUG - 2018-05-22 01:41:15 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:41:15 --> Security Class Initialized
INFO - 2018-05-22 01:41:15 --> Utf8 Class Initialized
INFO - 2018-05-22 01:41:15 --> URI Class Initialized
DEBUG - 2018-05-22 01:41:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:41:15 --> Input Class Initialized
INFO - 2018-05-22 01:41:15 --> Router Class Initialized
INFO - 2018-05-22 01:41:15 --> Language Class Initialized
INFO - 2018-05-22 01:41:15 --> Output Class Initialized
ERROR - 2018-05-22 01:41:15 --> 404 Page Not Found: /index
INFO - 2018-05-22 01:41:15 --> Security Class Initialized
DEBUG - 2018-05-22 01:41:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:41:15 --> Input Class Initialized
INFO - 2018-05-22 01:41:15 --> Language Class Initialized
ERROR - 2018-05-22 01:41:15 --> 404 Page Not Found: /index
INFO - 2018-05-22 01:41:16 --> Config Class Initialized
INFO - 2018-05-22 01:41:16 --> Hooks Class Initialized
DEBUG - 2018-05-22 01:41:16 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:41:16 --> Utf8 Class Initialized
INFO - 2018-05-22 01:41:16 --> URI Class Initialized
INFO - 2018-05-22 01:41:16 --> Router Class Initialized
INFO - 2018-05-22 01:41:16 --> Output Class Initialized
INFO - 2018-05-22 01:41:16 --> Security Class Initialized
DEBUG - 2018-05-22 01:41:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:41:16 --> Input Class Initialized
INFO - 2018-05-22 01:41:16 --> Language Class Initialized
ERROR - 2018-05-22 01:41:16 --> 404 Page Not Found: /index
INFO - 2018-05-22 01:41:39 --> Config Class Initialized
INFO - 2018-05-22 01:41:39 --> Hooks Class Initialized
DEBUG - 2018-05-22 01:41:39 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:41:39 --> Utf8 Class Initialized
INFO - 2018-05-22 01:41:39 --> URI Class Initialized
INFO - 2018-05-22 01:41:39 --> Router Class Initialized
INFO - 2018-05-22 01:41:39 --> Output Class Initialized
INFO - 2018-05-22 01:41:39 --> Security Class Initialized
DEBUG - 2018-05-22 01:41:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:41:39 --> Input Class Initialized
INFO - 2018-05-22 01:41:39 --> Language Class Initialized
INFO - 2018-05-22 01:41:39 --> Language Class Initialized
INFO - 2018-05-22 01:41:39 --> Config Class Initialized
INFO - 2018-05-22 01:41:39 --> Loader Class Initialized
DEBUG - 2018-05-22 01:41:39 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 01:41:39 --> Helper loaded: url_helper
INFO - 2018-05-22 01:41:39 --> Helper loaded: form_helper
INFO - 2018-05-22 01:41:39 --> Helper loaded: date_helper
INFO - 2018-05-22 01:41:39 --> Helper loaded: util_helper
INFO - 2018-05-22 01:41:39 --> Helper loaded: text_helper
INFO - 2018-05-22 01:41:39 --> Helper loaded: string_helper
INFO - 2018-05-22 01:41:39 --> Database Driver Class Initialized
DEBUG - 2018-05-22 01:41:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 01:41:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 01:41:39 --> Email Class Initialized
INFO - 2018-05-22 01:41:39 --> Controller Class Initialized
DEBUG - 2018-05-22 01:41:39 --> Profile MX_Controller Initialized
DEBUG - 2018-05-22 01:41:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 01:41:39 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 01:41:39 --> Login MX_Controller Initialized
INFO - 2018-05-22 01:41:39 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 01:41:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 01:41:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-22 01:41:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-22 01:41:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-22 01:41:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-22 01:41:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-05-22 01:41:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-22 01:41:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-22 01:41:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/profile.php
INFO - 2018-05-22 01:41:39 --> Final output sent to browser
DEBUG - 2018-05-22 01:41:39 --> Total execution time: 0.4741
INFO - 2018-05-22 01:41:39 --> Config Class Initialized
INFO - 2018-05-22 01:41:39 --> Hooks Class Initialized
DEBUG - 2018-05-22 01:41:39 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:41:39 --> Utf8 Class Initialized
INFO - 2018-05-22 01:41:39 --> URI Class Initialized
INFO - 2018-05-22 01:41:39 --> Router Class Initialized
INFO - 2018-05-22 01:41:39 --> Output Class Initialized
INFO - 2018-05-22 01:41:39 --> Security Class Initialized
DEBUG - 2018-05-22 01:41:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:41:39 --> Input Class Initialized
INFO - 2018-05-22 01:41:39 --> Language Class Initialized
ERROR - 2018-05-22 01:41:39 --> 404 Page Not Found: /index
INFO - 2018-05-22 01:41:41 --> Config Class Initialized
INFO - 2018-05-22 01:41:41 --> Hooks Class Initialized
DEBUG - 2018-05-22 01:41:41 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:41:41 --> Utf8 Class Initialized
INFO - 2018-05-22 01:41:41 --> URI Class Initialized
INFO - 2018-05-22 01:41:41 --> Router Class Initialized
INFO - 2018-05-22 01:41:41 --> Output Class Initialized
INFO - 2018-05-22 01:41:41 --> Config Class Initialized
INFO - 2018-05-22 01:41:41 --> Hooks Class Initialized
INFO - 2018-05-22 01:41:41 --> Security Class Initialized
DEBUG - 2018-05-22 01:41:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-22 01:41:41 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:41:41 --> Input Class Initialized
INFO - 2018-05-22 01:41:41 --> Language Class Initialized
ERROR - 2018-05-22 01:41:41 --> 404 Page Not Found: /index
INFO - 2018-05-22 01:41:41 --> Utf8 Class Initialized
INFO - 2018-05-22 01:41:41 --> URI Class Initialized
INFO - 2018-05-22 01:41:41 --> Router Class Initialized
INFO - 2018-05-22 01:41:41 --> Config Class Initialized
INFO - 2018-05-22 01:41:41 --> Hooks Class Initialized
INFO - 2018-05-22 01:41:41 --> Output Class Initialized
INFO - 2018-05-22 01:41:41 --> Security Class Initialized
DEBUG - 2018-05-22 01:41:41 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:41:42 --> Utf8 Class Initialized
DEBUG - 2018-05-22 01:41:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:41:42 --> URI Class Initialized
INFO - 2018-05-22 01:41:42 --> Input Class Initialized
INFO - 2018-05-22 01:41:42 --> Language Class Initialized
INFO - 2018-05-22 01:41:42 --> Router Class Initialized
ERROR - 2018-05-22 01:41:42 --> 404 Page Not Found: /index
INFO - 2018-05-22 01:41:42 --> Output Class Initialized
INFO - 2018-05-22 01:41:42 --> Security Class Initialized
DEBUG - 2018-05-22 01:41:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:41:42 --> Input Class Initialized
INFO - 2018-05-22 01:41:42 --> Language Class Initialized
ERROR - 2018-05-22 01:41:42 --> 404 Page Not Found: /index
INFO - 2018-05-22 01:41:42 --> Config Class Initialized
INFO - 2018-05-22 01:41:42 --> Hooks Class Initialized
DEBUG - 2018-05-22 01:41:42 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:41:42 --> Utf8 Class Initialized
INFO - 2018-05-22 01:41:42 --> URI Class Initialized
INFO - 2018-05-22 01:41:42 --> Router Class Initialized
INFO - 2018-05-22 01:41:42 --> Output Class Initialized
INFO - 2018-05-22 01:41:42 --> Security Class Initialized
DEBUG - 2018-05-22 01:41:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:41:42 --> Input Class Initialized
INFO - 2018-05-22 01:41:42 --> Language Class Initialized
ERROR - 2018-05-22 01:41:42 --> 404 Page Not Found: /index
INFO - 2018-05-22 01:41:43 --> Config Class Initialized
INFO - 2018-05-22 01:41:43 --> Hooks Class Initialized
DEBUG - 2018-05-22 01:41:43 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:41:43 --> Utf8 Class Initialized
INFO - 2018-05-22 01:41:43 --> URI Class Initialized
INFO - 2018-05-22 01:41:43 --> Router Class Initialized
INFO - 2018-05-22 01:41:43 --> Output Class Initialized
INFO - 2018-05-22 01:41:43 --> Security Class Initialized
DEBUG - 2018-05-22 01:41:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:41:43 --> Input Class Initialized
INFO - 2018-05-22 01:41:43 --> Language Class Initialized
ERROR - 2018-05-22 01:41:43 --> 404 Page Not Found: /index
INFO - 2018-05-22 01:41:43 --> Config Class Initialized
INFO - 2018-05-22 01:41:43 --> Hooks Class Initialized
DEBUG - 2018-05-22 01:41:43 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:41:43 --> Utf8 Class Initialized
INFO - 2018-05-22 01:41:43 --> URI Class Initialized
INFO - 2018-05-22 01:41:43 --> Router Class Initialized
INFO - 2018-05-22 01:41:43 --> Output Class Initialized
INFO - 2018-05-22 01:41:43 --> Security Class Initialized
DEBUG - 2018-05-22 01:41:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:41:43 --> Input Class Initialized
INFO - 2018-05-22 01:41:43 --> Language Class Initialized
ERROR - 2018-05-22 01:41:43 --> 404 Page Not Found: /index
INFO - 2018-05-22 01:41:43 --> Config Class Initialized
INFO - 2018-05-22 01:41:43 --> Hooks Class Initialized
DEBUG - 2018-05-22 01:41:43 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:41:43 --> Utf8 Class Initialized
INFO - 2018-05-22 01:41:43 --> URI Class Initialized
INFO - 2018-05-22 01:41:43 --> Router Class Initialized
INFO - 2018-05-22 01:41:43 --> Output Class Initialized
INFO - 2018-05-22 01:41:43 --> Security Class Initialized
DEBUG - 2018-05-22 01:41:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:41:43 --> Input Class Initialized
INFO - 2018-05-22 01:41:44 --> Language Class Initialized
ERROR - 2018-05-22 01:41:44 --> 404 Page Not Found: /index
INFO - 2018-05-22 01:41:47 --> Config Class Initialized
INFO - 2018-05-22 01:41:47 --> Hooks Class Initialized
DEBUG - 2018-05-22 01:41:47 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:41:47 --> Utf8 Class Initialized
INFO - 2018-05-22 01:41:47 --> URI Class Initialized
INFO - 2018-05-22 01:41:47 --> Router Class Initialized
INFO - 2018-05-22 01:41:47 --> Output Class Initialized
INFO - 2018-05-22 01:41:47 --> Security Class Initialized
DEBUG - 2018-05-22 01:41:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:41:47 --> Input Class Initialized
INFO - 2018-05-22 01:41:47 --> Language Class Initialized
INFO - 2018-05-22 01:41:47 --> Language Class Initialized
INFO - 2018-05-22 01:41:47 --> Config Class Initialized
INFO - 2018-05-22 01:41:47 --> Loader Class Initialized
DEBUG - 2018-05-22 01:41:47 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 01:41:47 --> Helper loaded: url_helper
INFO - 2018-05-22 01:41:47 --> Helper loaded: form_helper
INFO - 2018-05-22 01:41:47 --> Helper loaded: date_helper
INFO - 2018-05-22 01:41:47 --> Helper loaded: util_helper
INFO - 2018-05-22 01:41:47 --> Helper loaded: text_helper
INFO - 2018-05-22 01:41:47 --> Helper loaded: string_helper
INFO - 2018-05-22 01:41:47 --> Database Driver Class Initialized
DEBUG - 2018-05-22 01:41:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 01:41:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 01:41:47 --> Email Class Initialized
INFO - 2018-05-22 01:41:47 --> Controller Class Initialized
DEBUG - 2018-05-22 01:41:47 --> Profile MX_Controller Initialized
DEBUG - 2018-05-22 01:41:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 01:41:47 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 01:41:47 --> Login MX_Controller Initialized
INFO - 2018-05-22 01:41:47 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 01:41:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 01:41:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-22 01:41:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-22 01:41:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-22 01:41:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-22 01:41:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-05-22 01:41:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-22 01:41:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-22 01:41:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/reset_password.php
INFO - 2018-05-22 01:41:47 --> Final output sent to browser
DEBUG - 2018-05-22 01:41:47 --> Total execution time: 0.5563
INFO - 2018-05-22 01:41:48 --> Config Class Initialized
INFO - 2018-05-22 01:41:48 --> Hooks Class Initialized
DEBUG - 2018-05-22 01:41:48 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:41:48 --> Utf8 Class Initialized
INFO - 2018-05-22 01:41:48 --> URI Class Initialized
INFO - 2018-05-22 01:41:48 --> Router Class Initialized
INFO - 2018-05-22 01:41:48 --> Output Class Initialized
INFO - 2018-05-22 01:41:48 --> Security Class Initialized
DEBUG - 2018-05-22 01:41:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:41:48 --> Input Class Initialized
INFO - 2018-05-22 01:41:48 --> Language Class Initialized
ERROR - 2018-05-22 01:41:48 --> 404 Page Not Found: /index
INFO - 2018-05-22 01:41:48 --> Config Class Initialized
INFO - 2018-05-22 01:41:48 --> Hooks Class Initialized
DEBUG - 2018-05-22 01:41:48 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:41:48 --> Utf8 Class Initialized
INFO - 2018-05-22 01:41:48 --> URI Class Initialized
INFO - 2018-05-22 01:41:48 --> Router Class Initialized
INFO - 2018-05-22 01:41:48 --> Output Class Initialized
INFO - 2018-05-22 01:41:48 --> Security Class Initialized
DEBUG - 2018-05-22 01:41:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:41:48 --> Input Class Initialized
INFO - 2018-05-22 01:41:48 --> Language Class Initialized
ERROR - 2018-05-22 01:41:48 --> 404 Page Not Found: /index
INFO - 2018-05-22 01:41:48 --> Config Class Initialized
INFO - 2018-05-22 01:41:48 --> Hooks Class Initialized
DEBUG - 2018-05-22 01:41:48 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:41:48 --> Utf8 Class Initialized
INFO - 2018-05-22 01:41:49 --> URI Class Initialized
INFO - 2018-05-22 01:41:49 --> Router Class Initialized
INFO - 2018-05-22 01:41:49 --> Output Class Initialized
INFO - 2018-05-22 01:41:49 --> Security Class Initialized
DEBUG - 2018-05-22 01:41:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:41:49 --> Input Class Initialized
INFO - 2018-05-22 01:41:49 --> Language Class Initialized
ERROR - 2018-05-22 01:41:49 --> 404 Page Not Found: /index
INFO - 2018-05-22 01:42:08 --> Config Class Initialized
INFO - 2018-05-22 01:42:08 --> Hooks Class Initialized
DEBUG - 2018-05-22 01:42:08 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:42:08 --> Utf8 Class Initialized
INFO - 2018-05-22 01:42:08 --> URI Class Initialized
INFO - 2018-05-22 01:42:08 --> Router Class Initialized
INFO - 2018-05-22 01:42:08 --> Output Class Initialized
INFO - 2018-05-22 01:42:08 --> Security Class Initialized
DEBUG - 2018-05-22 01:42:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:42:08 --> Input Class Initialized
INFO - 2018-05-22 01:42:08 --> Language Class Initialized
INFO - 2018-05-22 01:42:08 --> Language Class Initialized
INFO - 2018-05-22 01:42:08 --> Config Class Initialized
INFO - 2018-05-22 01:42:08 --> Loader Class Initialized
DEBUG - 2018-05-22 01:42:08 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 01:42:08 --> Helper loaded: url_helper
INFO - 2018-05-22 01:42:08 --> Helper loaded: form_helper
INFO - 2018-05-22 01:42:08 --> Helper loaded: date_helper
INFO - 2018-05-22 01:42:08 --> Helper loaded: util_helper
INFO - 2018-05-22 01:42:08 --> Helper loaded: text_helper
INFO - 2018-05-22 01:42:08 --> Helper loaded: string_helper
INFO - 2018-05-22 01:42:08 --> Database Driver Class Initialized
DEBUG - 2018-05-22 01:42:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 01:42:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 01:42:08 --> Email Class Initialized
INFO - 2018-05-22 01:42:08 --> Controller Class Initialized
DEBUG - 2018-05-22 01:42:08 --> Profile MX_Controller Initialized
DEBUG - 2018-05-22 01:42:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 01:42:08 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 01:42:08 --> Login MX_Controller Initialized
INFO - 2018-05-22 01:42:08 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 01:42:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 01:42:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-22 01:42:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-22 01:42:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-22 01:42:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-22 01:42:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-05-22 01:42:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-22 01:42:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-22 01:42:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/reset_password.php
INFO - 2018-05-22 01:42:08 --> Final output sent to browser
DEBUG - 2018-05-22 01:42:08 --> Total execution time: 0.4762
INFO - 2018-05-22 01:42:09 --> Config Class Initialized
INFO - 2018-05-22 01:42:09 --> Hooks Class Initialized
DEBUG - 2018-05-22 01:42:09 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:42:09 --> Utf8 Class Initialized
INFO - 2018-05-22 01:42:09 --> URI Class Initialized
INFO - 2018-05-22 01:42:09 --> Router Class Initialized
INFO - 2018-05-22 01:42:09 --> Output Class Initialized
INFO - 2018-05-22 01:42:09 --> Security Class Initialized
DEBUG - 2018-05-22 01:42:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:42:09 --> Input Class Initialized
INFO - 2018-05-22 01:42:09 --> Language Class Initialized
ERROR - 2018-05-22 01:42:09 --> 404 Page Not Found: /index
INFO - 2018-05-22 01:42:09 --> Config Class Initialized
INFO - 2018-05-22 01:42:09 --> Hooks Class Initialized
DEBUG - 2018-05-22 01:42:09 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:42:09 --> Utf8 Class Initialized
INFO - 2018-05-22 01:42:09 --> URI Class Initialized
INFO - 2018-05-22 01:42:09 --> Router Class Initialized
INFO - 2018-05-22 01:42:09 --> Output Class Initialized
INFO - 2018-05-22 01:42:09 --> Security Class Initialized
DEBUG - 2018-05-22 01:42:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:42:09 --> Input Class Initialized
INFO - 2018-05-22 01:42:09 --> Language Class Initialized
ERROR - 2018-05-22 01:42:09 --> 404 Page Not Found: /index
INFO - 2018-05-22 01:42:09 --> Config Class Initialized
INFO - 2018-05-22 01:42:09 --> Hooks Class Initialized
DEBUG - 2018-05-22 01:42:09 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:42:09 --> Utf8 Class Initialized
INFO - 2018-05-22 01:42:09 --> URI Class Initialized
INFO - 2018-05-22 01:42:09 --> Router Class Initialized
INFO - 2018-05-22 01:42:10 --> Output Class Initialized
INFO - 2018-05-22 01:42:10 --> Security Class Initialized
DEBUG - 2018-05-22 01:42:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:42:10 --> Input Class Initialized
INFO - 2018-05-22 01:42:10 --> Language Class Initialized
ERROR - 2018-05-22 01:42:10 --> 404 Page Not Found: /index
INFO - 2018-05-22 01:42:11 --> Config Class Initialized
INFO - 2018-05-22 01:42:11 --> Hooks Class Initialized
DEBUG - 2018-05-22 01:42:11 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:42:11 --> Utf8 Class Initialized
INFO - 2018-05-22 01:42:11 --> URI Class Initialized
INFO - 2018-05-22 01:42:11 --> Router Class Initialized
INFO - 2018-05-22 01:42:11 --> Output Class Initialized
INFO - 2018-05-22 01:42:11 --> Security Class Initialized
DEBUG - 2018-05-22 01:42:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:42:11 --> Input Class Initialized
INFO - 2018-05-22 01:42:11 --> Language Class Initialized
ERROR - 2018-05-22 01:42:11 --> 404 Page Not Found: /index
INFO - 2018-05-22 01:42:11 --> Config Class Initialized
INFO - 2018-05-22 01:42:11 --> Hooks Class Initialized
DEBUG - 2018-05-22 01:42:11 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:42:11 --> Utf8 Class Initialized
INFO - 2018-05-22 01:42:11 --> URI Class Initialized
INFO - 2018-05-22 01:42:11 --> Router Class Initialized
INFO - 2018-05-22 01:42:11 --> Output Class Initialized
INFO - 2018-05-22 01:42:11 --> Security Class Initialized
DEBUG - 2018-05-22 01:42:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:42:11 --> Input Class Initialized
INFO - 2018-05-22 01:42:11 --> Language Class Initialized
ERROR - 2018-05-22 01:42:11 --> 404 Page Not Found: /index
INFO - 2018-05-22 01:42:11 --> Config Class Initialized
INFO - 2018-05-22 01:42:11 --> Hooks Class Initialized
DEBUG - 2018-05-22 01:42:11 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:42:11 --> Utf8 Class Initialized
INFO - 2018-05-22 01:42:11 --> URI Class Initialized
INFO - 2018-05-22 01:42:11 --> Router Class Initialized
INFO - 2018-05-22 01:42:11 --> Output Class Initialized
INFO - 2018-05-22 01:42:11 --> Security Class Initialized
DEBUG - 2018-05-22 01:42:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:42:11 --> Input Class Initialized
INFO - 2018-05-22 01:42:11 --> Language Class Initialized
ERROR - 2018-05-22 01:42:11 --> 404 Page Not Found: /index
INFO - 2018-05-22 01:42:15 --> Config Class Initialized
INFO - 2018-05-22 01:42:15 --> Hooks Class Initialized
DEBUG - 2018-05-22 01:42:15 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:42:15 --> Utf8 Class Initialized
INFO - 2018-05-22 01:42:15 --> URI Class Initialized
INFO - 2018-05-22 01:42:15 --> Router Class Initialized
INFO - 2018-05-22 01:42:15 --> Output Class Initialized
INFO - 2018-05-22 01:42:15 --> Security Class Initialized
DEBUG - 2018-05-22 01:42:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:42:15 --> Input Class Initialized
INFO - 2018-05-22 01:42:15 --> Language Class Initialized
INFO - 2018-05-22 01:42:15 --> Language Class Initialized
INFO - 2018-05-22 01:42:15 --> Config Class Initialized
INFO - 2018-05-22 01:42:16 --> Loader Class Initialized
DEBUG - 2018-05-22 01:42:16 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 01:42:16 --> Helper loaded: url_helper
INFO - 2018-05-22 01:42:16 --> Helper loaded: form_helper
INFO - 2018-05-22 01:42:16 --> Helper loaded: date_helper
INFO - 2018-05-22 01:42:16 --> Helper loaded: util_helper
INFO - 2018-05-22 01:42:16 --> Helper loaded: text_helper
INFO - 2018-05-22 01:42:16 --> Helper loaded: string_helper
INFO - 2018-05-22 01:42:16 --> Database Driver Class Initialized
DEBUG - 2018-05-22 01:42:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 01:42:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 01:42:16 --> Email Class Initialized
INFO - 2018-05-22 01:42:16 --> Controller Class Initialized
DEBUG - 2018-05-22 01:42:16 --> Profile MX_Controller Initialized
DEBUG - 2018-05-22 01:42:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 01:42:16 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 01:42:16 --> Login MX_Controller Initialized
INFO - 2018-05-22 01:42:16 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 01:42:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 01:42:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-22 01:42:25 --> Config Class Initialized
INFO - 2018-05-22 01:42:25 --> Hooks Class Initialized
DEBUG - 2018-05-22 01:42:25 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:42:25 --> Utf8 Class Initialized
INFO - 2018-05-22 01:42:25 --> URI Class Initialized
INFO - 2018-05-22 01:42:25 --> Router Class Initialized
INFO - 2018-05-22 01:42:25 --> Output Class Initialized
INFO - 2018-05-22 01:42:25 --> Security Class Initialized
DEBUG - 2018-05-22 01:42:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:42:25 --> Input Class Initialized
INFO - 2018-05-22 01:42:25 --> Language Class Initialized
INFO - 2018-05-22 01:42:25 --> Language Class Initialized
INFO - 2018-05-22 01:42:25 --> Config Class Initialized
INFO - 2018-05-22 01:42:25 --> Loader Class Initialized
DEBUG - 2018-05-22 01:42:25 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 01:42:25 --> Helper loaded: url_helper
INFO - 2018-05-22 01:42:25 --> Helper loaded: form_helper
INFO - 2018-05-22 01:42:25 --> Helper loaded: date_helper
INFO - 2018-05-22 01:42:25 --> Helper loaded: util_helper
INFO - 2018-05-22 01:42:25 --> Helper loaded: text_helper
INFO - 2018-05-22 01:42:25 --> Helper loaded: string_helper
INFO - 2018-05-22 01:42:25 --> Database Driver Class Initialized
DEBUG - 2018-05-22 01:42:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 01:42:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 01:42:25 --> Email Class Initialized
INFO - 2018-05-22 01:42:25 --> Controller Class Initialized
DEBUG - 2018-05-22 01:42:26 --> Profile MX_Controller Initialized
DEBUG - 2018-05-22 01:42:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 01:42:26 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 01:42:26 --> Login MX_Controller Initialized
INFO - 2018-05-22 01:42:26 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 01:42:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 01:42:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-22 01:42:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-22 01:42:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-22 01:42:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-22 01:42:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-05-22 01:42:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-22 01:42:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-22 01:42:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/profile.php
INFO - 2018-05-22 01:42:26 --> Final output sent to browser
DEBUG - 2018-05-22 01:42:26 --> Total execution time: 0.6554
INFO - 2018-05-22 01:42:26 --> Config Class Initialized
INFO - 2018-05-22 01:42:26 --> Hooks Class Initialized
DEBUG - 2018-05-22 01:42:26 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:42:26 --> Utf8 Class Initialized
INFO - 2018-05-22 01:42:26 --> URI Class Initialized
INFO - 2018-05-22 01:42:26 --> Router Class Initialized
INFO - 2018-05-22 01:42:26 --> Output Class Initialized
INFO - 2018-05-22 01:42:26 --> Security Class Initialized
DEBUG - 2018-05-22 01:42:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:42:26 --> Input Class Initialized
INFO - 2018-05-22 01:42:26 --> Language Class Initialized
ERROR - 2018-05-22 01:42:26 --> 404 Page Not Found: /index
INFO - 2018-05-22 01:42:26 --> Config Class Initialized
INFO - 2018-05-22 01:42:27 --> Hooks Class Initialized
DEBUG - 2018-05-22 01:42:27 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:42:27 --> Utf8 Class Initialized
INFO - 2018-05-22 01:42:27 --> URI Class Initialized
INFO - 2018-05-22 01:42:27 --> Router Class Initialized
INFO - 2018-05-22 01:42:27 --> Config Class Initialized
INFO - 2018-05-22 01:42:27 --> Hooks Class Initialized
INFO - 2018-05-22 01:42:27 --> Output Class Initialized
DEBUG - 2018-05-22 01:42:27 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:42:27 --> Utf8 Class Initialized
INFO - 2018-05-22 01:42:27 --> URI Class Initialized
INFO - 2018-05-22 01:42:27 --> Security Class Initialized
INFO - 2018-05-22 01:42:27 --> Router Class Initialized
DEBUG - 2018-05-22 01:42:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:42:27 --> Input Class Initialized
INFO - 2018-05-22 01:42:27 --> Output Class Initialized
INFO - 2018-05-22 01:42:27 --> Language Class Initialized
INFO - 2018-05-22 01:42:27 --> Security Class Initialized
ERROR - 2018-05-22 01:42:27 --> 404 Page Not Found: /index
DEBUG - 2018-05-22 01:42:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:42:27 --> Input Class Initialized
INFO - 2018-05-22 01:42:27 --> Language Class Initialized
ERROR - 2018-05-22 01:42:27 --> 404 Page Not Found: /index
INFO - 2018-05-22 01:42:27 --> Config Class Initialized
INFO - 2018-05-22 01:42:27 --> Hooks Class Initialized
DEBUG - 2018-05-22 01:42:27 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:42:27 --> Utf8 Class Initialized
INFO - 2018-05-22 01:42:27 --> URI Class Initialized
INFO - 2018-05-22 01:42:27 --> Router Class Initialized
INFO - 2018-05-22 01:42:27 --> Output Class Initialized
INFO - 2018-05-22 01:42:27 --> Security Class Initialized
DEBUG - 2018-05-22 01:42:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:42:27 --> Input Class Initialized
INFO - 2018-05-22 01:42:27 --> Language Class Initialized
ERROR - 2018-05-22 01:42:27 --> 404 Page Not Found: /index
INFO - 2018-05-22 01:42:27 --> Config Class Initialized
INFO - 2018-05-22 01:42:27 --> Hooks Class Initialized
DEBUG - 2018-05-22 01:42:27 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:42:27 --> Utf8 Class Initialized
INFO - 2018-05-22 01:42:27 --> URI Class Initialized
INFO - 2018-05-22 01:42:27 --> Router Class Initialized
INFO - 2018-05-22 01:42:27 --> Output Class Initialized
INFO - 2018-05-22 01:42:27 --> Security Class Initialized
DEBUG - 2018-05-22 01:42:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:42:27 --> Input Class Initialized
INFO - 2018-05-22 01:42:27 --> Language Class Initialized
ERROR - 2018-05-22 01:42:27 --> 404 Page Not Found: /index
INFO - 2018-05-22 01:43:27 --> Config Class Initialized
INFO - 2018-05-22 01:43:27 --> Hooks Class Initialized
DEBUG - 2018-05-22 01:43:27 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:43:27 --> Utf8 Class Initialized
INFO - 2018-05-22 01:43:27 --> URI Class Initialized
INFO - 2018-05-22 01:43:27 --> Router Class Initialized
INFO - 2018-05-22 01:43:27 --> Output Class Initialized
INFO - 2018-05-22 01:43:27 --> Security Class Initialized
DEBUG - 2018-05-22 01:43:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:43:27 --> Input Class Initialized
INFO - 2018-05-22 01:43:27 --> Language Class Initialized
INFO - 2018-05-22 01:43:27 --> Language Class Initialized
INFO - 2018-05-22 01:43:27 --> Config Class Initialized
INFO - 2018-05-22 01:43:27 --> Loader Class Initialized
DEBUG - 2018-05-22 01:43:27 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 01:43:27 --> Helper loaded: url_helper
INFO - 2018-05-22 01:43:27 --> Helper loaded: form_helper
INFO - 2018-05-22 01:43:27 --> Helper loaded: date_helper
INFO - 2018-05-22 01:43:27 --> Helper loaded: util_helper
INFO - 2018-05-22 01:43:27 --> Helper loaded: text_helper
INFO - 2018-05-22 01:43:27 --> Helper loaded: string_helper
INFO - 2018-05-22 01:43:27 --> Database Driver Class Initialized
DEBUG - 2018-05-22 01:43:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 01:43:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 01:43:27 --> Email Class Initialized
INFO - 2018-05-22 01:43:27 --> Controller Class Initialized
DEBUG - 2018-05-22 01:43:27 --> Profile MX_Controller Initialized
DEBUG - 2018-05-22 01:43:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 01:43:27 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 01:43:27 --> Login MX_Controller Initialized
INFO - 2018-05-22 01:43:27 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 01:43:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 01:43:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-22 01:43:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-22 01:43:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-22 01:43:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-22 01:43:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-05-22 01:43:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-22 01:43:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-22 01:43:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/profile.php
INFO - 2018-05-22 01:43:27 --> Final output sent to browser
INFO - 2018-05-22 01:43:27 --> Config Class Initialized
INFO - 2018-05-22 01:43:27 --> Hooks Class Initialized
DEBUG - 2018-05-22 01:43:27 --> Total execution time: 0.5404
DEBUG - 2018-05-22 01:43:27 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:43:27 --> Utf8 Class Initialized
INFO - 2018-05-22 01:43:27 --> URI Class Initialized
INFO - 2018-05-22 01:43:27 --> Router Class Initialized
INFO - 2018-05-22 01:43:27 --> Output Class Initialized
INFO - 2018-05-22 01:43:27 --> Security Class Initialized
DEBUG - 2018-05-22 01:43:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:43:27 --> Input Class Initialized
INFO - 2018-05-22 01:43:27 --> Language Class Initialized
ERROR - 2018-05-22 01:43:27 --> 404 Page Not Found: /index
INFO - 2018-05-22 01:43:28 --> Config Class Initialized
INFO - 2018-05-22 01:43:28 --> Hooks Class Initialized
DEBUG - 2018-05-22 01:43:28 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:43:28 --> Utf8 Class Initialized
INFO - 2018-05-22 01:43:28 --> Config Class Initialized
INFO - 2018-05-22 01:43:28 --> URI Class Initialized
INFO - 2018-05-22 01:43:28 --> Hooks Class Initialized
INFO - 2018-05-22 01:43:28 --> Router Class Initialized
DEBUG - 2018-05-22 01:43:28 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:43:28 --> Utf8 Class Initialized
INFO - 2018-05-22 01:43:28 --> URI Class Initialized
INFO - 2018-05-22 01:43:28 --> Output Class Initialized
INFO - 2018-05-22 01:43:28 --> Router Class Initialized
INFO - 2018-05-22 01:43:28 --> Security Class Initialized
DEBUG - 2018-05-22 01:43:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:43:28 --> Input Class Initialized
INFO - 2018-05-22 01:43:28 --> Language Class Initialized
ERROR - 2018-05-22 01:43:28 --> 404 Page Not Found: /index
INFO - 2018-05-22 01:43:28 --> Output Class Initialized
INFO - 2018-05-22 01:43:28 --> Security Class Initialized
INFO - 2018-05-22 01:43:28 --> Config Class Initialized
INFO - 2018-05-22 01:43:28 --> Hooks Class Initialized
DEBUG - 2018-05-22 01:43:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:43:28 --> Input Class Initialized
DEBUG - 2018-05-22 01:43:28 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:43:28 --> Utf8 Class Initialized
INFO - 2018-05-22 01:43:28 --> Language Class Initialized
INFO - 2018-05-22 01:43:28 --> URI Class Initialized
INFO - 2018-05-22 01:43:28 --> Router Class Initialized
ERROR - 2018-05-22 01:43:28 --> 404 Page Not Found: /index
INFO - 2018-05-22 01:43:28 --> Output Class Initialized
INFO - 2018-05-22 01:43:28 --> Security Class Initialized
DEBUG - 2018-05-22 01:43:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:43:28 --> Input Class Initialized
INFO - 2018-05-22 01:43:28 --> Language Class Initialized
ERROR - 2018-05-22 01:43:28 --> 404 Page Not Found: /index
INFO - 2018-05-22 01:43:28 --> Config Class Initialized
INFO - 2018-05-22 01:43:28 --> Hooks Class Initialized
DEBUG - 2018-05-22 01:43:28 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:43:28 --> Utf8 Class Initialized
INFO - 2018-05-22 01:43:28 --> URI Class Initialized
INFO - 2018-05-22 01:43:28 --> Router Class Initialized
INFO - 2018-05-22 01:43:29 --> Output Class Initialized
INFO - 2018-05-22 01:43:29 --> Security Class Initialized
DEBUG - 2018-05-22 01:43:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:43:29 --> Input Class Initialized
INFO - 2018-05-22 01:43:29 --> Language Class Initialized
ERROR - 2018-05-22 01:43:29 --> 404 Page Not Found: /index
INFO - 2018-05-22 01:58:16 --> Config Class Initialized
INFO - 2018-05-22 01:58:16 --> Hooks Class Initialized
DEBUG - 2018-05-22 01:58:16 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:58:16 --> Utf8 Class Initialized
INFO - 2018-05-22 01:58:16 --> URI Class Initialized
INFO - 2018-05-22 01:58:16 --> Router Class Initialized
INFO - 2018-05-22 01:58:16 --> Output Class Initialized
INFO - 2018-05-22 01:58:16 --> Security Class Initialized
DEBUG - 2018-05-22 01:58:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:58:16 --> Input Class Initialized
INFO - 2018-05-22 01:58:16 --> Language Class Initialized
INFO - 2018-05-22 01:58:16 --> Language Class Initialized
INFO - 2018-05-22 01:58:16 --> Config Class Initialized
INFO - 2018-05-22 01:58:16 --> Loader Class Initialized
DEBUG - 2018-05-22 01:58:16 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 01:58:16 --> Helper loaded: url_helper
INFO - 2018-05-22 01:58:16 --> Helper loaded: form_helper
INFO - 2018-05-22 01:58:16 --> Helper loaded: date_helper
INFO - 2018-05-22 01:58:16 --> Helper loaded: util_helper
INFO - 2018-05-22 01:58:16 --> Helper loaded: text_helper
INFO - 2018-05-22 01:58:16 --> Helper loaded: string_helper
INFO - 2018-05-22 01:58:16 --> Database Driver Class Initialized
DEBUG - 2018-05-22 01:58:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 01:58:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 01:58:16 --> Email Class Initialized
INFO - 2018-05-22 01:58:16 --> Controller Class Initialized
DEBUG - 2018-05-22 01:58:16 --> Profile MX_Controller Initialized
DEBUG - 2018-05-22 01:58:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 01:58:16 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 01:58:16 --> Login MX_Controller Initialized
INFO - 2018-05-22 01:58:16 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 01:58:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 01:58:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-22 01:58:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-22 01:58:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-22 01:58:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-22 01:58:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-05-22 01:58:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-22 01:58:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-22 01:58:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/profile.php
INFO - 2018-05-22 01:58:17 --> Final output sent to browser
DEBUG - 2018-05-22 01:58:17 --> Total execution time: 0.4949
INFO - 2018-05-22 01:58:17 --> Config Class Initialized
INFO - 2018-05-22 01:58:17 --> Hooks Class Initialized
DEBUG - 2018-05-22 01:58:17 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:58:17 --> Utf8 Class Initialized
INFO - 2018-05-22 01:58:17 --> URI Class Initialized
INFO - 2018-05-22 01:58:17 --> Router Class Initialized
INFO - 2018-05-22 01:58:17 --> Output Class Initialized
INFO - 2018-05-22 01:58:17 --> Security Class Initialized
DEBUG - 2018-05-22 01:58:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:58:17 --> Input Class Initialized
INFO - 2018-05-22 01:58:17 --> Language Class Initialized
ERROR - 2018-05-22 01:58:17 --> 404 Page Not Found: /index
INFO - 2018-05-22 01:58:20 --> Config Class Initialized
INFO - 2018-05-22 01:58:20 --> Hooks Class Initialized
DEBUG - 2018-05-22 01:58:20 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:58:20 --> Utf8 Class Initialized
INFO - 2018-05-22 01:58:20 --> URI Class Initialized
INFO - 2018-05-22 01:58:20 --> Router Class Initialized
INFO - 2018-05-22 01:58:20 --> Output Class Initialized
INFO - 2018-05-22 01:58:20 --> Security Class Initialized
DEBUG - 2018-05-22 01:58:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:58:20 --> Input Class Initialized
INFO - 2018-05-22 01:58:20 --> Language Class Initialized
ERROR - 2018-05-22 01:58:20 --> 404 Page Not Found: /index
INFO - 2018-05-22 01:58:20 --> Config Class Initialized
INFO - 2018-05-22 01:58:20 --> Hooks Class Initialized
DEBUG - 2018-05-22 01:58:20 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:58:20 --> Utf8 Class Initialized
INFO - 2018-05-22 01:58:20 --> URI Class Initialized
INFO - 2018-05-22 01:58:20 --> Router Class Initialized
INFO - 2018-05-22 01:58:20 --> Output Class Initialized
INFO - 2018-05-22 01:58:20 --> Security Class Initialized
DEBUG - 2018-05-22 01:58:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:58:20 --> Input Class Initialized
INFO - 2018-05-22 01:58:20 --> Language Class Initialized
ERROR - 2018-05-22 01:58:20 --> 404 Page Not Found: /index
INFO - 2018-05-22 01:58:20 --> Config Class Initialized
INFO - 2018-05-22 01:58:20 --> Hooks Class Initialized
DEBUG - 2018-05-22 01:58:20 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:58:20 --> Utf8 Class Initialized
INFO - 2018-05-22 01:58:20 --> URI Class Initialized
INFO - 2018-05-22 01:58:20 --> Router Class Initialized
INFO - 2018-05-22 01:58:21 --> Output Class Initialized
INFO - 2018-05-22 01:58:21 --> Security Class Initialized
DEBUG - 2018-05-22 01:58:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:58:21 --> Input Class Initialized
INFO - 2018-05-22 01:58:21 --> Language Class Initialized
ERROR - 2018-05-22 01:58:21 --> 404 Page Not Found: /index
INFO - 2018-05-22 01:58:23 --> Config Class Initialized
INFO - 2018-05-22 01:58:23 --> Hooks Class Initialized
DEBUG - 2018-05-22 01:58:23 --> UTF-8 Support Enabled
INFO - 2018-05-22 01:58:23 --> Utf8 Class Initialized
INFO - 2018-05-22 01:58:23 --> URI Class Initialized
INFO - 2018-05-22 01:58:23 --> Router Class Initialized
INFO - 2018-05-22 01:58:23 --> Output Class Initialized
INFO - 2018-05-22 01:58:23 --> Security Class Initialized
DEBUG - 2018-05-22 01:58:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 01:58:24 --> Input Class Initialized
INFO - 2018-05-22 01:58:24 --> Language Class Initialized
INFO - 2018-05-22 01:58:24 --> Language Class Initialized
INFO - 2018-05-22 01:58:24 --> Config Class Initialized
INFO - 2018-05-22 01:58:24 --> Loader Class Initialized
DEBUG - 2018-05-22 01:58:24 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 01:58:24 --> Helper loaded: url_helper
INFO - 2018-05-22 01:58:24 --> Helper loaded: form_helper
INFO - 2018-05-22 01:58:24 --> Helper loaded: date_helper
INFO - 2018-05-22 01:58:24 --> Helper loaded: util_helper
INFO - 2018-05-22 01:58:24 --> Helper loaded: text_helper
INFO - 2018-05-22 01:58:24 --> Helper loaded: string_helper
INFO - 2018-05-22 01:58:24 --> Database Driver Class Initialized
DEBUG - 2018-05-22 01:58:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 01:58:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 01:58:24 --> Email Class Initialized
INFO - 2018-05-22 01:58:24 --> Controller Class Initialized
ERROR - 2018-05-22 01:58:24 --> 404 Page Not Found: ../modules/home/controllers/Profile/save_user_data
INFO - 2018-05-22 02:16:42 --> Config Class Initialized
INFO - 2018-05-22 02:16:42 --> Hooks Class Initialized
DEBUG - 2018-05-22 02:16:42 --> UTF-8 Support Enabled
INFO - 2018-05-22 02:16:42 --> Utf8 Class Initialized
INFO - 2018-05-22 02:16:43 --> URI Class Initialized
INFO - 2018-05-22 02:16:43 --> Router Class Initialized
INFO - 2018-05-22 02:16:43 --> Output Class Initialized
INFO - 2018-05-22 02:16:43 --> Security Class Initialized
DEBUG - 2018-05-22 02:16:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 02:16:43 --> Input Class Initialized
INFO - 2018-05-22 02:16:43 --> Language Class Initialized
INFO - 2018-05-22 02:16:43 --> Language Class Initialized
INFO - 2018-05-22 02:16:43 --> Config Class Initialized
INFO - 2018-05-22 02:16:43 --> Loader Class Initialized
DEBUG - 2018-05-22 02:16:43 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 02:16:43 --> Helper loaded: url_helper
INFO - 2018-05-22 02:16:43 --> Helper loaded: form_helper
INFO - 2018-05-22 02:16:43 --> Helper loaded: date_helper
INFO - 2018-05-22 02:16:43 --> Helper loaded: util_helper
INFO - 2018-05-22 02:16:43 --> Helper loaded: text_helper
INFO - 2018-05-22 02:16:43 --> Helper loaded: string_helper
INFO - 2018-05-22 02:16:43 --> Database Driver Class Initialized
DEBUG - 2018-05-22 02:16:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 02:16:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 02:16:43 --> Email Class Initialized
INFO - 2018-05-22 02:16:43 --> Controller Class Initialized
DEBUG - 2018-05-22 02:16:43 --> Profile MX_Controller Initialized
DEBUG - 2018-05-22 02:16:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 02:16:43 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 02:16:43 --> Login MX_Controller Initialized
INFO - 2018-05-22 02:16:43 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 02:16:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 02:16:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-22 02:16:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-22 02:16:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-22 02:16:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-22 02:16:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-05-22 02:16:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-22 02:16:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-22 02:16:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/profile.php
INFO - 2018-05-22 02:16:43 --> Final output sent to browser
DEBUG - 2018-05-22 02:16:43 --> Total execution time: 0.5340
INFO - 2018-05-22 02:16:43 --> Config Class Initialized
INFO - 2018-05-22 02:16:43 --> Hooks Class Initialized
DEBUG - 2018-05-22 02:16:43 --> UTF-8 Support Enabled
INFO - 2018-05-22 02:16:43 --> Utf8 Class Initialized
INFO - 2018-05-22 02:16:43 --> URI Class Initialized
INFO - 2018-05-22 02:16:43 --> Router Class Initialized
INFO - 2018-05-22 02:16:43 --> Output Class Initialized
INFO - 2018-05-22 02:16:43 --> Security Class Initialized
DEBUG - 2018-05-22 02:16:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 02:16:43 --> Input Class Initialized
INFO - 2018-05-22 02:16:43 --> Language Class Initialized
ERROR - 2018-05-22 02:16:43 --> 404 Page Not Found: /index
INFO - 2018-05-22 02:16:46 --> Config Class Initialized
INFO - 2018-05-22 02:16:46 --> Hooks Class Initialized
DEBUG - 2018-05-22 02:16:46 --> UTF-8 Support Enabled
INFO - 2018-05-22 02:16:46 --> Utf8 Class Initialized
INFO - 2018-05-22 02:16:46 --> URI Class Initialized
INFO - 2018-05-22 02:16:46 --> Router Class Initialized
INFO - 2018-05-22 02:16:46 --> Output Class Initialized
INFO - 2018-05-22 02:16:46 --> Security Class Initialized
DEBUG - 2018-05-22 02:16:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 02:16:46 --> Input Class Initialized
INFO - 2018-05-22 02:16:47 --> Language Class Initialized
ERROR - 2018-05-22 02:16:47 --> 404 Page Not Found: /index
INFO - 2018-05-22 02:16:47 --> Config Class Initialized
INFO - 2018-05-22 02:16:47 --> Hooks Class Initialized
DEBUG - 2018-05-22 02:16:47 --> UTF-8 Support Enabled
INFO - 2018-05-22 02:16:47 --> Utf8 Class Initialized
INFO - 2018-05-22 02:16:47 --> URI Class Initialized
INFO - 2018-05-22 02:16:47 --> Router Class Initialized
INFO - 2018-05-22 02:16:47 --> Output Class Initialized
INFO - 2018-05-22 02:16:47 --> Security Class Initialized
DEBUG - 2018-05-22 02:16:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 02:16:47 --> Input Class Initialized
INFO - 2018-05-22 02:16:47 --> Language Class Initialized
ERROR - 2018-05-22 02:16:47 --> 404 Page Not Found: /index
INFO - 2018-05-22 02:16:47 --> Config Class Initialized
INFO - 2018-05-22 02:16:47 --> Hooks Class Initialized
DEBUG - 2018-05-22 02:16:47 --> UTF-8 Support Enabled
INFO - 2018-05-22 02:16:47 --> Utf8 Class Initialized
INFO - 2018-05-22 02:16:47 --> URI Class Initialized
INFO - 2018-05-22 02:16:47 --> Router Class Initialized
INFO - 2018-05-22 02:16:47 --> Output Class Initialized
INFO - 2018-05-22 02:16:47 --> Security Class Initialized
DEBUG - 2018-05-22 02:16:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 02:16:47 --> Input Class Initialized
INFO - 2018-05-22 02:16:47 --> Language Class Initialized
ERROR - 2018-05-22 02:16:47 --> 404 Page Not Found: /index
INFO - 2018-05-22 02:16:56 --> Config Class Initialized
INFO - 2018-05-22 02:16:56 --> Hooks Class Initialized
DEBUG - 2018-05-22 02:16:56 --> UTF-8 Support Enabled
INFO - 2018-05-22 02:16:56 --> Utf8 Class Initialized
INFO - 2018-05-22 02:16:56 --> URI Class Initialized
INFO - 2018-05-22 02:16:56 --> Router Class Initialized
INFO - 2018-05-22 02:16:56 --> Output Class Initialized
INFO - 2018-05-22 02:16:56 --> Security Class Initialized
DEBUG - 2018-05-22 02:16:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 02:16:56 --> Input Class Initialized
INFO - 2018-05-22 02:16:56 --> Language Class Initialized
INFO - 2018-05-22 02:16:56 --> Language Class Initialized
INFO - 2018-05-22 02:16:56 --> Config Class Initialized
INFO - 2018-05-22 02:16:56 --> Loader Class Initialized
DEBUG - 2018-05-22 02:16:56 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 02:16:56 --> Helper loaded: url_helper
INFO - 2018-05-22 02:16:56 --> Helper loaded: form_helper
INFO - 2018-05-22 02:16:56 --> Helper loaded: date_helper
INFO - 2018-05-22 02:16:56 --> Helper loaded: util_helper
INFO - 2018-05-22 02:16:56 --> Helper loaded: text_helper
INFO - 2018-05-22 02:16:56 --> Helper loaded: string_helper
INFO - 2018-05-22 02:16:56 --> Database Driver Class Initialized
DEBUG - 2018-05-22 02:16:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 02:16:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 02:16:56 --> Email Class Initialized
INFO - 2018-05-22 02:16:56 --> Controller Class Initialized
DEBUG - 2018-05-22 02:16:56 --> Profile MX_Controller Initialized
DEBUG - 2018-05-22 02:16:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 02:16:56 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 02:16:56 --> Login MX_Controller Initialized
INFO - 2018-05-22 02:16:56 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 02:16:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 02:16:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-22 02:16:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-22 02:16:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-22 02:16:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-22 02:16:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-05-22 02:16:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-22 02:16:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-22 02:16:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/profile.php
INFO - 2018-05-22 02:16:56 --> Final output sent to browser
DEBUG - 2018-05-22 02:16:56 --> Total execution time: 0.5443
INFO - 2018-05-22 02:16:57 --> Config Class Initialized
INFO - 2018-05-22 02:16:57 --> Hooks Class Initialized
DEBUG - 2018-05-22 02:16:57 --> UTF-8 Support Enabled
INFO - 2018-05-22 02:16:57 --> Utf8 Class Initialized
INFO - 2018-05-22 02:16:57 --> URI Class Initialized
INFO - 2018-05-22 02:16:57 --> Router Class Initialized
INFO - 2018-05-22 02:16:57 --> Output Class Initialized
INFO - 2018-05-22 02:16:57 --> Security Class Initialized
DEBUG - 2018-05-22 02:16:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 02:16:57 --> Input Class Initialized
INFO - 2018-05-22 02:16:57 --> Language Class Initialized
ERROR - 2018-05-22 02:16:57 --> 404 Page Not Found: /index
INFO - 2018-05-22 02:16:57 --> Config Class Initialized
INFO - 2018-05-22 02:16:57 --> Hooks Class Initialized
DEBUG - 2018-05-22 02:16:57 --> UTF-8 Support Enabled
INFO - 2018-05-22 02:16:57 --> Utf8 Class Initialized
INFO - 2018-05-22 02:16:58 --> URI Class Initialized
INFO - 2018-05-22 02:16:58 --> Router Class Initialized
INFO - 2018-05-22 02:16:58 --> Output Class Initialized
INFO - 2018-05-22 02:16:58 --> Security Class Initialized
DEBUG - 2018-05-22 02:16:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 02:16:58 --> Input Class Initialized
INFO - 2018-05-22 02:16:58 --> Language Class Initialized
ERROR - 2018-05-22 02:16:58 --> 404 Page Not Found: /index
INFO - 2018-05-22 02:16:58 --> Config Class Initialized
INFO - 2018-05-22 02:16:58 --> Hooks Class Initialized
DEBUG - 2018-05-22 02:16:58 --> UTF-8 Support Enabled
INFO - 2018-05-22 02:16:58 --> Utf8 Class Initialized
INFO - 2018-05-22 02:16:58 --> URI Class Initialized
INFO - 2018-05-22 02:16:58 --> Router Class Initialized
INFO - 2018-05-22 02:16:58 --> Output Class Initialized
INFO - 2018-05-22 02:16:58 --> Security Class Initialized
DEBUG - 2018-05-22 02:16:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 02:16:58 --> Input Class Initialized
INFO - 2018-05-22 02:16:58 --> Language Class Initialized
ERROR - 2018-05-22 02:16:58 --> 404 Page Not Found: /index
INFO - 2018-05-22 02:16:58 --> Config Class Initialized
INFO - 2018-05-22 02:16:58 --> Hooks Class Initialized
DEBUG - 2018-05-22 02:16:58 --> UTF-8 Support Enabled
INFO - 2018-05-22 02:16:58 --> Utf8 Class Initialized
INFO - 2018-05-22 02:16:58 --> URI Class Initialized
INFO - 2018-05-22 02:16:58 --> Router Class Initialized
INFO - 2018-05-22 02:16:58 --> Output Class Initialized
INFO - 2018-05-22 02:16:58 --> Security Class Initialized
DEBUG - 2018-05-22 02:16:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 02:16:58 --> Input Class Initialized
INFO - 2018-05-22 02:16:58 --> Language Class Initialized
ERROR - 2018-05-22 02:16:58 --> 404 Page Not Found: /index
INFO - 2018-05-22 02:17:25 --> Config Class Initialized
INFO - 2018-05-22 02:17:25 --> Hooks Class Initialized
DEBUG - 2018-05-22 02:17:25 --> UTF-8 Support Enabled
INFO - 2018-05-22 02:17:25 --> Utf8 Class Initialized
INFO - 2018-05-22 02:17:25 --> URI Class Initialized
INFO - 2018-05-22 02:17:25 --> Router Class Initialized
INFO - 2018-05-22 02:17:25 --> Output Class Initialized
INFO - 2018-05-22 02:17:25 --> Security Class Initialized
DEBUG - 2018-05-22 02:17:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 02:17:25 --> Input Class Initialized
INFO - 2018-05-22 02:17:25 --> Language Class Initialized
ERROR - 2018-05-22 02:17:25 --> 404 Page Not Found: /index
INFO - 2018-05-22 02:17:56 --> Config Class Initialized
INFO - 2018-05-22 02:17:56 --> Hooks Class Initialized
DEBUG - 2018-05-22 02:17:56 --> UTF-8 Support Enabled
INFO - 2018-05-22 02:17:56 --> Utf8 Class Initialized
INFO - 2018-05-22 02:17:56 --> URI Class Initialized
INFO - 2018-05-22 02:17:56 --> Router Class Initialized
INFO - 2018-05-22 02:17:56 --> Output Class Initialized
INFO - 2018-05-22 02:17:56 --> Security Class Initialized
DEBUG - 2018-05-22 02:17:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 02:17:56 --> Input Class Initialized
INFO - 2018-05-22 02:17:56 --> Language Class Initialized
INFO - 2018-05-22 02:17:57 --> Language Class Initialized
INFO - 2018-05-22 02:17:57 --> Config Class Initialized
INFO - 2018-05-22 02:17:57 --> Loader Class Initialized
DEBUG - 2018-05-22 02:17:57 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 02:17:57 --> Helper loaded: url_helper
INFO - 2018-05-22 02:17:57 --> Helper loaded: form_helper
INFO - 2018-05-22 02:17:57 --> Helper loaded: date_helper
INFO - 2018-05-22 02:17:57 --> Helper loaded: util_helper
INFO - 2018-05-22 02:17:57 --> Helper loaded: text_helper
INFO - 2018-05-22 02:17:57 --> Helper loaded: string_helper
INFO - 2018-05-22 02:17:57 --> Database Driver Class Initialized
DEBUG - 2018-05-22 02:17:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 02:17:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 02:17:57 --> Email Class Initialized
INFO - 2018-05-22 02:17:57 --> Controller Class Initialized
DEBUG - 2018-05-22 02:17:57 --> Profile MX_Controller Initialized
DEBUG - 2018-05-22 02:17:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 02:17:57 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 02:17:57 --> Login MX_Controller Initialized
INFO - 2018-05-22 02:17:57 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 02:17:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 02:17:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-22 02:17:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-22 02:17:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-22 02:17:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-22 02:17:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-05-22 02:17:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-22 02:17:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-22 02:17:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/profile.php
INFO - 2018-05-22 02:17:57 --> Final output sent to browser
DEBUG - 2018-05-22 02:17:57 --> Total execution time: 0.5761
INFO - 2018-05-22 02:17:58 --> Config Class Initialized
INFO - 2018-05-22 02:17:58 --> Hooks Class Initialized
DEBUG - 2018-05-22 02:17:58 --> UTF-8 Support Enabled
INFO - 2018-05-22 02:17:58 --> Utf8 Class Initialized
INFO - 2018-05-22 02:17:58 --> URI Class Initialized
INFO - 2018-05-22 02:17:58 --> Router Class Initialized
INFO - 2018-05-22 02:17:58 --> Output Class Initialized
INFO - 2018-05-22 02:17:58 --> Security Class Initialized
DEBUG - 2018-05-22 02:17:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 02:17:58 --> Input Class Initialized
INFO - 2018-05-22 02:17:58 --> Language Class Initialized
ERROR - 2018-05-22 02:17:58 --> 404 Page Not Found: /index
INFO - 2018-05-22 02:17:58 --> Config Class Initialized
INFO - 2018-05-22 02:17:58 --> Hooks Class Initialized
DEBUG - 2018-05-22 02:17:58 --> UTF-8 Support Enabled
INFO - 2018-05-22 02:17:58 --> Utf8 Class Initialized
INFO - 2018-05-22 02:17:58 --> URI Class Initialized
INFO - 2018-05-22 02:17:58 --> Router Class Initialized
INFO - 2018-05-22 02:17:58 --> Output Class Initialized
INFO - 2018-05-22 02:17:58 --> Security Class Initialized
DEBUG - 2018-05-22 02:17:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 02:17:58 --> Input Class Initialized
INFO - 2018-05-22 02:17:58 --> Language Class Initialized
ERROR - 2018-05-22 02:17:58 --> 404 Page Not Found: /index
INFO - 2018-05-22 02:17:58 --> Config Class Initialized
INFO - 2018-05-22 02:17:58 --> Hooks Class Initialized
DEBUG - 2018-05-22 02:17:58 --> UTF-8 Support Enabled
INFO - 2018-05-22 02:17:59 --> Utf8 Class Initialized
INFO - 2018-05-22 02:17:59 --> URI Class Initialized
INFO - 2018-05-22 02:17:59 --> Router Class Initialized
INFO - 2018-05-22 02:17:59 --> Output Class Initialized
INFO - 2018-05-22 02:17:59 --> Security Class Initialized
DEBUG - 2018-05-22 02:17:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 02:17:59 --> Input Class Initialized
INFO - 2018-05-22 02:17:59 --> Language Class Initialized
ERROR - 2018-05-22 02:17:59 --> 404 Page Not Found: /index
INFO - 2018-05-22 02:22:47 --> Config Class Initialized
INFO - 2018-05-22 02:22:47 --> Hooks Class Initialized
DEBUG - 2018-05-22 02:22:47 --> UTF-8 Support Enabled
INFO - 2018-05-22 02:22:47 --> Utf8 Class Initialized
INFO - 2018-05-22 02:22:47 --> URI Class Initialized
INFO - 2018-05-22 02:22:47 --> Router Class Initialized
INFO - 2018-05-22 02:22:47 --> Output Class Initialized
INFO - 2018-05-22 02:22:47 --> Security Class Initialized
DEBUG - 2018-05-22 02:22:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 02:22:47 --> Input Class Initialized
INFO - 2018-05-22 02:22:47 --> Language Class Initialized
INFO - 2018-05-22 02:22:47 --> Language Class Initialized
INFO - 2018-05-22 02:22:47 --> Config Class Initialized
INFO - 2018-05-22 02:22:47 --> Loader Class Initialized
DEBUG - 2018-05-22 02:22:47 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 02:22:47 --> Helper loaded: url_helper
INFO - 2018-05-22 02:22:47 --> Helper loaded: form_helper
INFO - 2018-05-22 02:22:47 --> Helper loaded: date_helper
INFO - 2018-05-22 02:22:48 --> Helper loaded: util_helper
INFO - 2018-05-22 02:22:48 --> Helper loaded: text_helper
INFO - 2018-05-22 02:22:48 --> Helper loaded: string_helper
INFO - 2018-05-22 02:22:48 --> Database Driver Class Initialized
DEBUG - 2018-05-22 02:22:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 02:22:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 02:22:48 --> Email Class Initialized
INFO - 2018-05-22 02:22:48 --> Controller Class Initialized
DEBUG - 2018-05-22 02:22:48 --> Profile MX_Controller Initialized
DEBUG - 2018-05-22 02:22:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 02:22:48 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 02:22:48 --> Login MX_Controller Initialized
INFO - 2018-05-22 02:22:48 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 02:22:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 02:22:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-22 02:22:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-22 02:22:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-22 02:22:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-22 02:22:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-05-22 02:22:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-22 02:22:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-22 02:22:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/profile.php
INFO - 2018-05-22 02:22:48 --> Final output sent to browser
DEBUG - 2018-05-22 02:22:48 --> Total execution time: 1.3429
INFO - 2018-05-22 02:22:48 --> Config Class Initialized
INFO - 2018-05-22 02:22:48 --> Hooks Class Initialized
DEBUG - 2018-05-22 02:22:48 --> UTF-8 Support Enabled
INFO - 2018-05-22 02:22:48 --> Utf8 Class Initialized
INFO - 2018-05-22 02:22:48 --> URI Class Initialized
INFO - 2018-05-22 02:22:48 --> Router Class Initialized
INFO - 2018-05-22 02:22:49 --> Output Class Initialized
INFO - 2018-05-22 02:22:49 --> Security Class Initialized
DEBUG - 2018-05-22 02:22:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 02:22:49 --> Input Class Initialized
INFO - 2018-05-22 02:22:49 --> Language Class Initialized
ERROR - 2018-05-22 02:22:49 --> 404 Page Not Found: /index
INFO - 2018-05-22 02:22:50 --> Config Class Initialized
INFO - 2018-05-22 02:22:50 --> Hooks Class Initialized
DEBUG - 2018-05-22 02:22:50 --> UTF-8 Support Enabled
INFO - 2018-05-22 02:22:50 --> Utf8 Class Initialized
INFO - 2018-05-22 02:22:50 --> Config Class Initialized
INFO - 2018-05-22 02:22:50 --> Hooks Class Initialized
INFO - 2018-05-22 02:22:50 --> URI Class Initialized
DEBUG - 2018-05-22 02:22:50 --> UTF-8 Support Enabled
INFO - 2018-05-22 02:22:50 --> Utf8 Class Initialized
INFO - 2018-05-22 02:22:50 --> Router Class Initialized
INFO - 2018-05-22 02:22:50 --> Output Class Initialized
INFO - 2018-05-22 02:22:50 --> URI Class Initialized
INFO - 2018-05-22 02:22:50 --> Router Class Initialized
INFO - 2018-05-22 02:22:50 --> Security Class Initialized
DEBUG - 2018-05-22 02:22:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 02:22:50 --> Output Class Initialized
INFO - 2018-05-22 02:22:50 --> Security Class Initialized
INFO - 2018-05-22 02:22:50 --> Input Class Initialized
INFO - 2018-05-22 02:22:50 --> Language Class Initialized
DEBUG - 2018-05-22 02:22:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 02:22:50 --> Input Class Initialized
ERROR - 2018-05-22 02:22:50 --> 404 Page Not Found: /index
INFO - 2018-05-22 02:22:50 --> Language Class Initialized
ERROR - 2018-05-22 02:22:50 --> 404 Page Not Found: /index
INFO - 2018-05-22 02:22:50 --> Config Class Initialized
INFO - 2018-05-22 02:22:50 --> Hooks Class Initialized
DEBUG - 2018-05-22 02:22:50 --> UTF-8 Support Enabled
INFO - 2018-05-22 02:22:50 --> Utf8 Class Initialized
INFO - 2018-05-22 02:22:50 --> URI Class Initialized
INFO - 2018-05-22 02:22:50 --> Router Class Initialized
INFO - 2018-05-22 02:22:50 --> Output Class Initialized
INFO - 2018-05-22 02:22:50 --> Security Class Initialized
DEBUG - 2018-05-22 02:22:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 02:22:50 --> Input Class Initialized
INFO - 2018-05-22 02:22:50 --> Language Class Initialized
ERROR - 2018-05-22 02:22:50 --> 404 Page Not Found: /index
INFO - 2018-05-22 02:22:50 --> Config Class Initialized
INFO - 2018-05-22 02:22:50 --> Hooks Class Initialized
DEBUG - 2018-05-22 02:22:50 --> UTF-8 Support Enabled
INFO - 2018-05-22 02:22:50 --> Utf8 Class Initialized
INFO - 2018-05-22 02:22:50 --> URI Class Initialized
INFO - 2018-05-22 02:22:50 --> Router Class Initialized
INFO - 2018-05-22 02:22:50 --> Output Class Initialized
INFO - 2018-05-22 02:22:50 --> Security Class Initialized
DEBUG - 2018-05-22 02:22:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 02:22:51 --> Input Class Initialized
INFO - 2018-05-22 02:22:51 --> Language Class Initialized
ERROR - 2018-05-22 02:22:51 --> 404 Page Not Found: /index
INFO - 2018-05-22 02:23:40 --> Config Class Initialized
INFO - 2018-05-22 02:23:40 --> Hooks Class Initialized
DEBUG - 2018-05-22 02:23:40 --> UTF-8 Support Enabled
INFO - 2018-05-22 02:23:40 --> Utf8 Class Initialized
INFO - 2018-05-22 02:23:40 --> URI Class Initialized
INFO - 2018-05-22 02:23:40 --> Router Class Initialized
INFO - 2018-05-22 02:23:40 --> Output Class Initialized
INFO - 2018-05-22 02:23:40 --> Security Class Initialized
DEBUG - 2018-05-22 02:23:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 02:23:40 --> Input Class Initialized
INFO - 2018-05-22 02:23:40 --> Language Class Initialized
INFO - 2018-05-22 02:23:40 --> Language Class Initialized
INFO - 2018-05-22 02:23:40 --> Config Class Initialized
INFO - 2018-05-22 02:23:40 --> Loader Class Initialized
DEBUG - 2018-05-22 02:23:40 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 02:23:40 --> Helper loaded: url_helper
INFO - 2018-05-22 02:23:40 --> Helper loaded: form_helper
INFO - 2018-05-22 02:23:40 --> Helper loaded: date_helper
INFO - 2018-05-22 02:23:40 --> Helper loaded: util_helper
INFO - 2018-05-22 02:23:40 --> Helper loaded: text_helper
INFO - 2018-05-22 02:23:40 --> Helper loaded: string_helper
INFO - 2018-05-22 02:23:40 --> Database Driver Class Initialized
DEBUG - 2018-05-22 02:23:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 02:23:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 02:23:40 --> Email Class Initialized
INFO - 2018-05-22 02:23:40 --> Controller Class Initialized
DEBUG - 2018-05-22 02:23:40 --> Profile MX_Controller Initialized
DEBUG - 2018-05-22 02:23:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 02:23:40 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 02:23:40 --> Login MX_Controller Initialized
INFO - 2018-05-22 02:23:40 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 02:23:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 02:23:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-22 02:23:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-22 02:23:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-22 02:23:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-22 02:23:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-05-22 02:23:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-22 02:23:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-22 02:23:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/profile.php
INFO - 2018-05-22 02:23:41 --> Final output sent to browser
DEBUG - 2018-05-22 02:23:41 --> Total execution time: 0.5178
INFO - 2018-05-22 02:23:42 --> Config Class Initialized
INFO - 2018-05-22 02:23:42 --> Hooks Class Initialized
DEBUG - 2018-05-22 02:23:42 --> UTF-8 Support Enabled
INFO - 2018-05-22 02:23:42 --> Utf8 Class Initialized
INFO - 2018-05-22 02:23:42 --> URI Class Initialized
INFO - 2018-05-22 02:23:42 --> Router Class Initialized
INFO - 2018-05-22 02:23:42 --> Output Class Initialized
INFO - 2018-05-22 02:23:42 --> Security Class Initialized
DEBUG - 2018-05-22 02:23:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 02:23:42 --> Input Class Initialized
INFO - 2018-05-22 02:23:42 --> Language Class Initialized
ERROR - 2018-05-22 02:23:42 --> 404 Page Not Found: /index
INFO - 2018-05-22 02:23:42 --> Config Class Initialized
INFO - 2018-05-22 02:23:42 --> Hooks Class Initialized
DEBUG - 2018-05-22 02:23:42 --> UTF-8 Support Enabled
INFO - 2018-05-22 02:23:42 --> Utf8 Class Initialized
INFO - 2018-05-22 02:23:42 --> URI Class Initialized
INFO - 2018-05-22 02:23:42 --> Router Class Initialized
INFO - 2018-05-22 02:23:42 --> Output Class Initialized
INFO - 2018-05-22 02:23:42 --> Security Class Initialized
DEBUG - 2018-05-22 02:23:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 02:23:42 --> Input Class Initialized
INFO - 2018-05-22 02:23:42 --> Language Class Initialized
ERROR - 2018-05-22 02:23:42 --> 404 Page Not Found: /index
INFO - 2018-05-22 02:23:42 --> Config Class Initialized
INFO - 2018-05-22 02:23:42 --> Hooks Class Initialized
DEBUG - 2018-05-22 02:23:42 --> UTF-8 Support Enabled
INFO - 2018-05-22 02:23:42 --> Utf8 Class Initialized
INFO - 2018-05-22 02:23:42 --> URI Class Initialized
INFO - 2018-05-22 02:23:42 --> Router Class Initialized
INFO - 2018-05-22 02:23:42 --> Output Class Initialized
INFO - 2018-05-22 02:23:42 --> Security Class Initialized
DEBUG - 2018-05-22 02:23:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 02:23:42 --> Input Class Initialized
INFO - 2018-05-22 02:23:42 --> Language Class Initialized
ERROR - 2018-05-22 02:23:42 --> 404 Page Not Found: /index
INFO - 2018-05-22 02:23:54 --> Config Class Initialized
INFO - 2018-05-22 02:23:54 --> Hooks Class Initialized
DEBUG - 2018-05-22 02:23:54 --> UTF-8 Support Enabled
INFO - 2018-05-22 02:23:54 --> Utf8 Class Initialized
INFO - 2018-05-22 02:23:54 --> URI Class Initialized
INFO - 2018-05-22 02:23:54 --> Router Class Initialized
INFO - 2018-05-22 02:23:54 --> Output Class Initialized
INFO - 2018-05-22 02:23:54 --> Security Class Initialized
DEBUG - 2018-05-22 02:23:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 02:23:54 --> Input Class Initialized
INFO - 2018-05-22 02:23:54 --> Language Class Initialized
INFO - 2018-05-22 02:23:54 --> Language Class Initialized
INFO - 2018-05-22 02:23:54 --> Config Class Initialized
INFO - 2018-05-22 02:23:54 --> Loader Class Initialized
DEBUG - 2018-05-22 02:23:54 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 02:23:54 --> Helper loaded: url_helper
INFO - 2018-05-22 02:23:54 --> Helper loaded: form_helper
INFO - 2018-05-22 02:23:54 --> Helper loaded: date_helper
INFO - 2018-05-22 02:23:54 --> Helper loaded: util_helper
INFO - 2018-05-22 02:23:54 --> Helper loaded: text_helper
INFO - 2018-05-22 02:23:54 --> Helper loaded: string_helper
INFO - 2018-05-22 02:23:54 --> Database Driver Class Initialized
DEBUG - 2018-05-22 02:23:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 02:23:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 02:23:54 --> Email Class Initialized
INFO - 2018-05-22 02:23:54 --> Controller Class Initialized
DEBUG - 2018-05-22 02:23:54 --> Profile MX_Controller Initialized
DEBUG - 2018-05-22 02:23:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 02:23:54 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 02:23:54 --> Login MX_Controller Initialized
INFO - 2018-05-22 02:23:54 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 02:23:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 02:23:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-22 02:23:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-22 02:23:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-22 02:23:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-22 02:23:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-05-22 02:23:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-22 02:23:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-22 02:23:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/profile.php
INFO - 2018-05-22 02:23:54 --> Final output sent to browser
DEBUG - 2018-05-22 02:23:54 --> Total execution time: 0.5139
INFO - 2018-05-22 02:23:55 --> Config Class Initialized
INFO - 2018-05-22 02:23:55 --> Hooks Class Initialized
DEBUG - 2018-05-22 02:23:55 --> UTF-8 Support Enabled
INFO - 2018-05-22 02:23:55 --> Utf8 Class Initialized
INFO - 2018-05-22 02:23:55 --> Config Class Initialized
INFO - 2018-05-22 02:23:55 --> Hooks Class Initialized
INFO - 2018-05-22 02:23:55 --> URI Class Initialized
DEBUG - 2018-05-22 02:23:55 --> UTF-8 Support Enabled
INFO - 2018-05-22 02:23:55 --> Utf8 Class Initialized
INFO - 2018-05-22 02:23:56 --> URI Class Initialized
INFO - 2018-05-22 02:23:56 --> Router Class Initialized
INFO - 2018-05-22 02:23:56 --> Router Class Initialized
INFO - 2018-05-22 02:23:56 --> Output Class Initialized
INFO - 2018-05-22 02:23:56 --> Output Class Initialized
INFO - 2018-05-22 02:23:56 --> Security Class Initialized
INFO - 2018-05-22 02:23:56 --> Security Class Initialized
DEBUG - 2018-05-22 02:23:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-22 02:23:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 02:23:56 --> Input Class Initialized
INFO - 2018-05-22 02:23:56 --> Input Class Initialized
INFO - 2018-05-22 02:23:56 --> Language Class Initialized
INFO - 2018-05-22 02:23:56 --> Language Class Initialized
ERROR - 2018-05-22 02:23:56 --> 404 Page Not Found: /index
ERROR - 2018-05-22 02:23:56 --> 404 Page Not Found: /index
INFO - 2018-05-22 02:23:56 --> Config Class Initialized
INFO - 2018-05-22 02:23:56 --> Hooks Class Initialized
DEBUG - 2018-05-22 02:23:56 --> UTF-8 Support Enabled
INFO - 2018-05-22 02:23:56 --> Utf8 Class Initialized
INFO - 2018-05-22 02:23:56 --> URI Class Initialized
INFO - 2018-05-22 02:23:56 --> Router Class Initialized
INFO - 2018-05-22 02:23:56 --> Output Class Initialized
INFO - 2018-05-22 02:23:56 --> Security Class Initialized
DEBUG - 2018-05-22 02:23:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 02:23:56 --> Input Class Initialized
INFO - 2018-05-22 02:23:56 --> Language Class Initialized
ERROR - 2018-05-22 02:23:56 --> 404 Page Not Found: /index
INFO - 2018-05-22 02:23:56 --> Config Class Initialized
INFO - 2018-05-22 02:23:56 --> Hooks Class Initialized
DEBUG - 2018-05-22 02:23:56 --> UTF-8 Support Enabled
INFO - 2018-05-22 02:23:56 --> Utf8 Class Initialized
INFO - 2018-05-22 02:23:56 --> URI Class Initialized
INFO - 2018-05-22 02:23:56 --> Router Class Initialized
INFO - 2018-05-22 02:23:56 --> Output Class Initialized
INFO - 2018-05-22 02:23:56 --> Security Class Initialized
DEBUG - 2018-05-22 02:23:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 02:23:56 --> Input Class Initialized
INFO - 2018-05-22 02:23:56 --> Language Class Initialized
ERROR - 2018-05-22 02:23:56 --> 404 Page Not Found: /index
INFO - 2018-05-22 02:24:05 --> Config Class Initialized
INFO - 2018-05-22 02:24:05 --> Hooks Class Initialized
DEBUG - 2018-05-22 02:24:05 --> UTF-8 Support Enabled
INFO - 2018-05-22 02:24:05 --> Utf8 Class Initialized
INFO - 2018-05-22 02:24:05 --> URI Class Initialized
INFO - 2018-05-22 02:24:05 --> Router Class Initialized
INFO - 2018-05-22 02:24:05 --> Output Class Initialized
INFO - 2018-05-22 02:24:05 --> Security Class Initialized
DEBUG - 2018-05-22 02:24:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 02:24:05 --> Input Class Initialized
INFO - 2018-05-22 02:24:05 --> Language Class Initialized
ERROR - 2018-05-22 02:24:05 --> 404 Page Not Found: /index
INFO - 2018-05-22 02:24:49 --> Config Class Initialized
INFO - 2018-05-22 02:24:49 --> Hooks Class Initialized
DEBUG - 2018-05-22 02:24:49 --> UTF-8 Support Enabled
INFO - 2018-05-22 02:24:49 --> Utf8 Class Initialized
INFO - 2018-05-22 02:24:49 --> URI Class Initialized
INFO - 2018-05-22 02:24:49 --> Router Class Initialized
INFO - 2018-05-22 02:24:49 --> Output Class Initialized
INFO - 2018-05-22 02:24:49 --> Security Class Initialized
DEBUG - 2018-05-22 02:24:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 02:24:49 --> Input Class Initialized
INFO - 2018-05-22 02:24:49 --> Language Class Initialized
INFO - 2018-05-22 02:24:49 --> Language Class Initialized
INFO - 2018-05-22 02:24:49 --> Config Class Initialized
INFO - 2018-05-22 02:24:49 --> Loader Class Initialized
DEBUG - 2018-05-22 02:24:49 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 02:24:49 --> Helper loaded: url_helper
INFO - 2018-05-22 02:24:49 --> Helper loaded: form_helper
INFO - 2018-05-22 02:24:49 --> Helper loaded: date_helper
INFO - 2018-05-22 02:24:49 --> Helper loaded: util_helper
INFO - 2018-05-22 02:24:49 --> Helper loaded: text_helper
INFO - 2018-05-22 02:24:49 --> Helper loaded: string_helper
INFO - 2018-05-22 02:24:49 --> Database Driver Class Initialized
DEBUG - 2018-05-22 02:24:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 02:24:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 02:24:49 --> Email Class Initialized
INFO - 2018-05-22 02:24:49 --> Controller Class Initialized
DEBUG - 2018-05-22 02:24:49 --> Profile MX_Controller Initialized
DEBUG - 2018-05-22 02:24:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 02:24:49 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 02:24:49 --> Login MX_Controller Initialized
INFO - 2018-05-22 02:24:50 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 02:24:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 02:24:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-22 02:24:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-22 02:24:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-22 02:24:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-22 02:24:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-05-22 02:24:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-22 02:24:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-22 02:24:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/profile.php
INFO - 2018-05-22 02:24:50 --> Final output sent to browser
DEBUG - 2018-05-22 02:24:50 --> Total execution time: 0.5705
INFO - 2018-05-22 02:24:51 --> Config Class Initialized
INFO - 2018-05-22 02:24:51 --> Hooks Class Initialized
DEBUG - 2018-05-22 02:24:51 --> UTF-8 Support Enabled
INFO - 2018-05-22 02:24:51 --> Utf8 Class Initialized
INFO - 2018-05-22 02:24:51 --> URI Class Initialized
INFO - 2018-05-22 02:24:51 --> Router Class Initialized
INFO - 2018-05-22 02:24:51 --> Output Class Initialized
INFO - 2018-05-22 02:24:51 --> Security Class Initialized
DEBUG - 2018-05-22 02:24:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 02:24:51 --> Input Class Initialized
INFO - 2018-05-22 02:24:51 --> Language Class Initialized
ERROR - 2018-05-22 02:24:51 --> 404 Page Not Found: /index
INFO - 2018-05-22 02:24:51 --> Config Class Initialized
INFO - 2018-05-22 02:24:51 --> Hooks Class Initialized
DEBUG - 2018-05-22 02:24:51 --> UTF-8 Support Enabled
INFO - 2018-05-22 02:24:51 --> Utf8 Class Initialized
INFO - 2018-05-22 02:24:51 --> URI Class Initialized
INFO - 2018-05-22 02:24:51 --> Router Class Initialized
INFO - 2018-05-22 02:24:51 --> Output Class Initialized
INFO - 2018-05-22 02:24:51 --> Security Class Initialized
DEBUG - 2018-05-22 02:24:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 02:24:51 --> Input Class Initialized
INFO - 2018-05-22 02:24:51 --> Language Class Initialized
ERROR - 2018-05-22 02:24:51 --> 404 Page Not Found: /index
INFO - 2018-05-22 02:24:51 --> Config Class Initialized
INFO - 2018-05-22 02:24:51 --> Hooks Class Initialized
DEBUG - 2018-05-22 02:24:51 --> UTF-8 Support Enabled
INFO - 2018-05-22 02:24:51 --> Utf8 Class Initialized
INFO - 2018-05-22 02:24:51 --> URI Class Initialized
INFO - 2018-05-22 02:24:51 --> Router Class Initialized
INFO - 2018-05-22 02:24:51 --> Output Class Initialized
INFO - 2018-05-22 02:24:51 --> Security Class Initialized
DEBUG - 2018-05-22 02:24:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 02:24:51 --> Input Class Initialized
INFO - 2018-05-22 02:24:51 --> Language Class Initialized
ERROR - 2018-05-22 02:24:51 --> 404 Page Not Found: /index
INFO - 2018-05-22 02:24:52 --> Config Class Initialized
INFO - 2018-05-22 02:24:52 --> Hooks Class Initialized
DEBUG - 2018-05-22 02:24:52 --> UTF-8 Support Enabled
INFO - 2018-05-22 02:24:52 --> Utf8 Class Initialized
INFO - 2018-05-22 02:24:52 --> URI Class Initialized
INFO - 2018-05-22 02:24:52 --> Router Class Initialized
INFO - 2018-05-22 02:24:52 --> Output Class Initialized
INFO - 2018-05-22 02:24:52 --> Security Class Initialized
DEBUG - 2018-05-22 02:24:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 02:24:52 --> Input Class Initialized
INFO - 2018-05-22 02:24:52 --> Language Class Initialized
ERROR - 2018-05-22 02:24:52 --> 404 Page Not Found: /index
INFO - 2018-05-22 02:24:52 --> Config Class Initialized
INFO - 2018-05-22 02:24:52 --> Hooks Class Initialized
DEBUG - 2018-05-22 02:24:52 --> UTF-8 Support Enabled
INFO - 2018-05-22 02:24:52 --> Utf8 Class Initialized
INFO - 2018-05-22 02:24:52 --> URI Class Initialized
INFO - 2018-05-22 02:24:52 --> Router Class Initialized
INFO - 2018-05-22 02:24:52 --> Output Class Initialized
INFO - 2018-05-22 02:24:52 --> Security Class Initialized
DEBUG - 2018-05-22 02:24:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 02:24:52 --> Input Class Initialized
INFO - 2018-05-22 02:24:52 --> Language Class Initialized
ERROR - 2018-05-22 02:24:52 --> 404 Page Not Found: /index
INFO - 2018-05-22 02:24:52 --> Config Class Initialized
INFO - 2018-05-22 02:24:52 --> Hooks Class Initialized
DEBUG - 2018-05-22 02:24:52 --> UTF-8 Support Enabled
INFO - 2018-05-22 02:24:52 --> Utf8 Class Initialized
INFO - 2018-05-22 02:24:52 --> URI Class Initialized
INFO - 2018-05-22 02:24:52 --> Router Class Initialized
INFO - 2018-05-22 02:24:52 --> Output Class Initialized
INFO - 2018-05-22 02:24:53 --> Security Class Initialized
DEBUG - 2018-05-22 02:24:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 02:24:53 --> Input Class Initialized
INFO - 2018-05-22 02:24:53 --> Language Class Initialized
ERROR - 2018-05-22 02:24:53 --> 404 Page Not Found: /index
INFO - 2018-05-22 02:31:06 --> Config Class Initialized
INFO - 2018-05-22 02:31:06 --> Hooks Class Initialized
DEBUG - 2018-05-22 02:31:06 --> UTF-8 Support Enabled
INFO - 2018-05-22 02:31:06 --> Utf8 Class Initialized
INFO - 2018-05-22 02:31:06 --> URI Class Initialized
INFO - 2018-05-22 02:31:06 --> Router Class Initialized
INFO - 2018-05-22 02:31:06 --> Output Class Initialized
INFO - 2018-05-22 02:31:06 --> Security Class Initialized
DEBUG - 2018-05-22 02:31:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 02:31:06 --> Input Class Initialized
INFO - 2018-05-22 02:31:06 --> Language Class Initialized
INFO - 2018-05-22 02:31:06 --> Language Class Initialized
INFO - 2018-05-22 02:31:06 --> Config Class Initialized
INFO - 2018-05-22 02:31:06 --> Loader Class Initialized
DEBUG - 2018-05-22 02:31:06 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 02:31:06 --> Helper loaded: url_helper
INFO - 2018-05-22 02:31:06 --> Helper loaded: form_helper
INFO - 2018-05-22 02:31:06 --> Helper loaded: date_helper
INFO - 2018-05-22 02:31:06 --> Helper loaded: util_helper
INFO - 2018-05-22 02:31:06 --> Helper loaded: text_helper
INFO - 2018-05-22 02:31:06 --> Helper loaded: string_helper
INFO - 2018-05-22 02:31:06 --> Database Driver Class Initialized
DEBUG - 2018-05-22 02:31:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 02:31:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 02:31:06 --> Email Class Initialized
INFO - 2018-05-22 02:31:06 --> Controller Class Initialized
DEBUG - 2018-05-22 02:31:06 --> Profile MX_Controller Initialized
DEBUG - 2018-05-22 02:31:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 02:31:06 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 02:31:06 --> Login MX_Controller Initialized
INFO - 2018-05-22 02:31:06 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 02:31:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 02:31:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-22 02:31:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-22 02:31:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-22 02:31:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-22 02:31:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-05-22 02:31:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-22 02:31:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-22 02:31:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/profile.php
INFO - 2018-05-22 02:31:06 --> Final output sent to browser
DEBUG - 2018-05-22 02:31:07 --> Total execution time: 0.5264
INFO - 2018-05-22 02:31:08 --> Config Class Initialized
INFO - 2018-05-22 02:31:08 --> Hooks Class Initialized
DEBUG - 2018-05-22 02:31:08 --> UTF-8 Support Enabled
INFO - 2018-05-22 02:31:09 --> Utf8 Class Initialized
INFO - 2018-05-22 02:31:09 --> URI Class Initialized
INFO - 2018-05-22 02:31:09 --> Router Class Initialized
INFO - 2018-05-22 02:31:09 --> Output Class Initialized
INFO - 2018-05-22 02:31:09 --> Security Class Initialized
DEBUG - 2018-05-22 02:31:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 02:31:09 --> Input Class Initialized
INFO - 2018-05-22 02:31:09 --> Language Class Initialized
ERROR - 2018-05-22 02:31:09 --> 404 Page Not Found: /index
INFO - 2018-05-22 02:31:09 --> Config Class Initialized
INFO - 2018-05-22 02:31:09 --> Hooks Class Initialized
DEBUG - 2018-05-22 02:31:09 --> UTF-8 Support Enabled
INFO - 2018-05-22 02:31:09 --> Utf8 Class Initialized
INFO - 2018-05-22 02:31:09 --> URI Class Initialized
INFO - 2018-05-22 02:31:09 --> Router Class Initialized
INFO - 2018-05-22 02:31:09 --> Output Class Initialized
INFO - 2018-05-22 02:31:09 --> Security Class Initialized
DEBUG - 2018-05-22 02:31:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 02:31:09 --> Input Class Initialized
INFO - 2018-05-22 02:31:09 --> Language Class Initialized
ERROR - 2018-05-22 02:31:09 --> 404 Page Not Found: /index
INFO - 2018-05-22 02:31:09 --> Config Class Initialized
INFO - 2018-05-22 02:31:09 --> Hooks Class Initialized
DEBUG - 2018-05-22 02:31:09 --> UTF-8 Support Enabled
INFO - 2018-05-22 02:31:09 --> Utf8 Class Initialized
INFO - 2018-05-22 02:31:09 --> URI Class Initialized
INFO - 2018-05-22 02:31:09 --> Router Class Initialized
INFO - 2018-05-22 02:31:09 --> Output Class Initialized
INFO - 2018-05-22 02:31:09 --> Security Class Initialized
DEBUG - 2018-05-22 02:31:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 02:31:09 --> Input Class Initialized
INFO - 2018-05-22 02:31:09 --> Language Class Initialized
ERROR - 2018-05-22 02:31:09 --> 404 Page Not Found: /index
INFO - 2018-05-22 02:31:37 --> Config Class Initialized
INFO - 2018-05-22 02:31:37 --> Hooks Class Initialized
DEBUG - 2018-05-22 02:31:37 --> UTF-8 Support Enabled
INFO - 2018-05-22 02:31:37 --> Utf8 Class Initialized
INFO - 2018-05-22 02:31:37 --> URI Class Initialized
INFO - 2018-05-22 02:31:37 --> Router Class Initialized
INFO - 2018-05-22 02:31:37 --> Output Class Initialized
INFO - 2018-05-22 02:31:37 --> Security Class Initialized
DEBUG - 2018-05-22 02:31:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 02:31:37 --> Input Class Initialized
INFO - 2018-05-22 02:31:37 --> Language Class Initialized
INFO - 2018-05-22 02:31:37 --> Language Class Initialized
INFO - 2018-05-22 02:31:37 --> Config Class Initialized
INFO - 2018-05-22 02:31:37 --> Loader Class Initialized
DEBUG - 2018-05-22 02:31:37 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 02:31:37 --> Helper loaded: url_helper
INFO - 2018-05-22 02:31:37 --> Helper loaded: form_helper
INFO - 2018-05-22 02:31:37 --> Helper loaded: date_helper
INFO - 2018-05-22 02:31:37 --> Helper loaded: util_helper
INFO - 2018-05-22 02:31:37 --> Helper loaded: text_helper
INFO - 2018-05-22 02:31:37 --> Helper loaded: string_helper
INFO - 2018-05-22 02:31:37 --> Database Driver Class Initialized
DEBUG - 2018-05-22 02:31:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 02:31:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 02:31:37 --> Email Class Initialized
INFO - 2018-05-22 02:31:37 --> Controller Class Initialized
DEBUG - 2018-05-22 02:31:37 --> Profile MX_Controller Initialized
DEBUG - 2018-05-22 02:31:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 02:31:38 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 02:31:38 --> Login MX_Controller Initialized
INFO - 2018-05-22 02:31:38 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 02:31:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 02:31:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-22 02:31:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-22 02:31:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-22 02:31:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-22 02:31:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-05-22 02:31:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-22 02:31:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-22 02:31:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/profile.php
INFO - 2018-05-22 02:31:38 --> Final output sent to browser
DEBUG - 2018-05-22 02:31:38 --> Total execution time: 0.6149
INFO - 2018-05-22 02:31:39 --> Config Class Initialized
INFO - 2018-05-22 02:31:39 --> Hooks Class Initialized
DEBUG - 2018-05-22 02:31:39 --> UTF-8 Support Enabled
INFO - 2018-05-22 02:31:39 --> Utf8 Class Initialized
INFO - 2018-05-22 02:31:39 --> URI Class Initialized
INFO - 2018-05-22 02:31:39 --> Router Class Initialized
INFO - 2018-05-22 02:31:39 --> Output Class Initialized
INFO - 2018-05-22 02:31:39 --> Security Class Initialized
DEBUG - 2018-05-22 02:31:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 02:31:39 --> Input Class Initialized
INFO - 2018-05-22 02:31:39 --> Language Class Initialized
ERROR - 2018-05-22 02:31:39 --> 404 Page Not Found: /index
INFO - 2018-05-22 02:31:39 --> Config Class Initialized
INFO - 2018-05-22 02:31:39 --> Hooks Class Initialized
DEBUG - 2018-05-22 02:31:39 --> UTF-8 Support Enabled
INFO - 2018-05-22 02:31:39 --> Utf8 Class Initialized
INFO - 2018-05-22 02:31:39 --> URI Class Initialized
INFO - 2018-05-22 02:31:39 --> Router Class Initialized
INFO - 2018-05-22 02:31:39 --> Output Class Initialized
INFO - 2018-05-22 02:31:39 --> Security Class Initialized
DEBUG - 2018-05-22 02:31:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 02:31:39 --> Input Class Initialized
INFO - 2018-05-22 02:31:39 --> Language Class Initialized
ERROR - 2018-05-22 02:31:39 --> 404 Page Not Found: /index
INFO - 2018-05-22 02:31:40 --> Config Class Initialized
INFO - 2018-05-22 02:31:40 --> Hooks Class Initialized
DEBUG - 2018-05-22 02:31:40 --> UTF-8 Support Enabled
INFO - 2018-05-22 02:31:40 --> Utf8 Class Initialized
INFO - 2018-05-22 02:31:40 --> URI Class Initialized
INFO - 2018-05-22 02:31:40 --> Router Class Initialized
INFO - 2018-05-22 02:31:40 --> Output Class Initialized
INFO - 2018-05-22 02:31:40 --> Security Class Initialized
DEBUG - 2018-05-22 02:31:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 02:31:40 --> Input Class Initialized
INFO - 2018-05-22 02:31:40 --> Language Class Initialized
ERROR - 2018-05-22 02:31:40 --> 404 Page Not Found: /index
INFO - 2018-05-22 02:31:48 --> Config Class Initialized
INFO - 2018-05-22 02:31:48 --> Hooks Class Initialized
DEBUG - 2018-05-22 02:31:48 --> UTF-8 Support Enabled
INFO - 2018-05-22 02:31:48 --> Utf8 Class Initialized
INFO - 2018-05-22 02:31:48 --> URI Class Initialized
INFO - 2018-05-22 02:31:48 --> Router Class Initialized
INFO - 2018-05-22 02:31:48 --> Output Class Initialized
INFO - 2018-05-22 02:31:48 --> Security Class Initialized
DEBUG - 2018-05-22 02:31:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 02:31:48 --> Input Class Initialized
INFO - 2018-05-22 02:31:48 --> Language Class Initialized
INFO - 2018-05-22 02:31:48 --> Language Class Initialized
INFO - 2018-05-22 02:31:48 --> Config Class Initialized
INFO - 2018-05-22 02:31:48 --> Loader Class Initialized
DEBUG - 2018-05-22 02:31:48 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 02:31:48 --> Helper loaded: url_helper
INFO - 2018-05-22 02:31:48 --> Helper loaded: form_helper
INFO - 2018-05-22 02:31:48 --> Helper loaded: date_helper
INFO - 2018-05-22 02:31:48 --> Helper loaded: util_helper
INFO - 2018-05-22 02:31:48 --> Helper loaded: text_helper
INFO - 2018-05-22 02:31:48 --> Helper loaded: string_helper
INFO - 2018-05-22 02:31:48 --> Database Driver Class Initialized
DEBUG - 2018-05-22 02:31:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 02:31:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 02:31:48 --> Email Class Initialized
INFO - 2018-05-22 02:31:48 --> Controller Class Initialized
DEBUG - 2018-05-22 02:31:48 --> Profile MX_Controller Initialized
DEBUG - 2018-05-22 02:31:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 02:31:48 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 02:31:48 --> Login MX_Controller Initialized
INFO - 2018-05-22 02:31:48 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 02:31:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 02:31:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-22 02:31:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-22 02:31:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-22 02:31:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-22 02:31:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-05-22 02:31:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-22 02:31:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-22 02:31:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/profile.php
INFO - 2018-05-22 02:31:48 --> Final output sent to browser
DEBUG - 2018-05-22 02:31:48 --> Total execution time: 0.5563
INFO - 2018-05-22 02:31:49 --> Config Class Initialized
INFO - 2018-05-22 02:31:49 --> Hooks Class Initialized
DEBUG - 2018-05-22 02:31:49 --> UTF-8 Support Enabled
INFO - 2018-05-22 02:31:49 --> Utf8 Class Initialized
INFO - 2018-05-22 02:31:49 --> URI Class Initialized
INFO - 2018-05-22 02:31:49 --> Router Class Initialized
INFO - 2018-05-22 02:31:49 --> Output Class Initialized
INFO - 2018-05-22 02:31:49 --> Security Class Initialized
DEBUG - 2018-05-22 02:31:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 02:31:49 --> Input Class Initialized
INFO - 2018-05-22 02:31:49 --> Language Class Initialized
ERROR - 2018-05-22 02:31:49 --> 404 Page Not Found: /index
INFO - 2018-05-22 02:31:50 --> Config Class Initialized
INFO - 2018-05-22 02:31:50 --> Hooks Class Initialized
DEBUG - 2018-05-22 02:31:50 --> UTF-8 Support Enabled
INFO - 2018-05-22 02:31:50 --> Utf8 Class Initialized
INFO - 2018-05-22 02:31:50 --> URI Class Initialized
INFO - 2018-05-22 02:31:50 --> Router Class Initialized
INFO - 2018-05-22 02:31:50 --> Output Class Initialized
INFO - 2018-05-22 02:31:50 --> Security Class Initialized
DEBUG - 2018-05-22 02:31:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 02:31:50 --> Input Class Initialized
INFO - 2018-05-22 02:31:50 --> Language Class Initialized
ERROR - 2018-05-22 02:31:50 --> 404 Page Not Found: /index
INFO - 2018-05-22 02:31:50 --> Config Class Initialized
INFO - 2018-05-22 02:31:50 --> Hooks Class Initialized
DEBUG - 2018-05-22 02:31:50 --> UTF-8 Support Enabled
INFO - 2018-05-22 02:31:50 --> Utf8 Class Initialized
INFO - 2018-05-22 02:31:50 --> URI Class Initialized
INFO - 2018-05-22 02:31:50 --> Router Class Initialized
INFO - 2018-05-22 02:31:50 --> Output Class Initialized
INFO - 2018-05-22 02:31:50 --> Security Class Initialized
DEBUG - 2018-05-22 02:31:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 02:31:50 --> Input Class Initialized
INFO - 2018-05-22 02:31:50 --> Language Class Initialized
ERROR - 2018-05-22 02:31:50 --> 404 Page Not Found: /index
INFO - 2018-05-22 02:37:54 --> Config Class Initialized
INFO - 2018-05-22 02:37:54 --> Hooks Class Initialized
DEBUG - 2018-05-22 02:37:54 --> UTF-8 Support Enabled
INFO - 2018-05-22 02:37:54 --> Utf8 Class Initialized
INFO - 2018-05-22 02:37:54 --> URI Class Initialized
INFO - 2018-05-22 02:37:54 --> Router Class Initialized
INFO - 2018-05-22 02:37:54 --> Output Class Initialized
INFO - 2018-05-22 02:37:54 --> Security Class Initialized
DEBUG - 2018-05-22 02:37:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 02:37:54 --> Input Class Initialized
INFO - 2018-05-22 02:37:54 --> Language Class Initialized
INFO - 2018-05-22 02:37:54 --> Language Class Initialized
INFO - 2018-05-22 02:37:54 --> Config Class Initialized
INFO - 2018-05-22 02:37:54 --> Loader Class Initialized
DEBUG - 2018-05-22 02:37:54 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 02:37:54 --> Helper loaded: url_helper
INFO - 2018-05-22 02:37:54 --> Helper loaded: form_helper
INFO - 2018-05-22 02:37:54 --> Helper loaded: date_helper
INFO - 2018-05-22 02:37:54 --> Helper loaded: util_helper
INFO - 2018-05-22 02:37:54 --> Helper loaded: text_helper
INFO - 2018-05-22 02:37:54 --> Helper loaded: string_helper
INFO - 2018-05-22 02:37:54 --> Database Driver Class Initialized
DEBUG - 2018-05-22 02:37:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 02:37:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 02:37:54 --> Email Class Initialized
INFO - 2018-05-22 02:37:54 --> Controller Class Initialized
DEBUG - 2018-05-22 02:37:54 --> Profile MX_Controller Initialized
DEBUG - 2018-05-22 02:37:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 02:37:54 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 02:37:54 --> Login MX_Controller Initialized
INFO - 2018-05-22 02:37:54 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 02:37:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 02:37:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-22 02:37:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-22 02:37:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-22 02:37:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-22 02:37:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-05-22 02:37:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-22 02:37:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-22 02:37:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/profile.php
INFO - 2018-05-22 02:37:54 --> Final output sent to browser
DEBUG - 2018-05-22 02:37:55 --> Total execution time: 0.6816
INFO - 2018-05-22 02:37:56 --> Config Class Initialized
INFO - 2018-05-22 02:37:56 --> Hooks Class Initialized
DEBUG - 2018-05-22 02:37:56 --> UTF-8 Support Enabled
INFO - 2018-05-22 02:37:56 --> Utf8 Class Initialized
INFO - 2018-05-22 02:37:56 --> URI Class Initialized
INFO - 2018-05-22 02:37:56 --> Router Class Initialized
INFO - 2018-05-22 02:37:56 --> Output Class Initialized
INFO - 2018-05-22 02:37:57 --> Security Class Initialized
DEBUG - 2018-05-22 02:37:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 02:37:57 --> Input Class Initialized
INFO - 2018-05-22 02:37:57 --> Language Class Initialized
ERROR - 2018-05-22 02:37:57 --> 404 Page Not Found: /index
INFO - 2018-05-22 02:37:57 --> Config Class Initialized
INFO - 2018-05-22 02:37:57 --> Hooks Class Initialized
DEBUG - 2018-05-22 02:37:57 --> UTF-8 Support Enabled
INFO - 2018-05-22 02:37:57 --> Utf8 Class Initialized
INFO - 2018-05-22 02:37:57 --> URI Class Initialized
INFO - 2018-05-22 02:37:57 --> Router Class Initialized
INFO - 2018-05-22 02:37:57 --> Output Class Initialized
INFO - 2018-05-22 02:37:57 --> Security Class Initialized
DEBUG - 2018-05-22 02:37:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 02:37:57 --> Input Class Initialized
INFO - 2018-05-22 02:37:57 --> Language Class Initialized
ERROR - 2018-05-22 02:37:57 --> 404 Page Not Found: /index
INFO - 2018-05-22 02:37:57 --> Config Class Initialized
INFO - 2018-05-22 02:37:57 --> Hooks Class Initialized
DEBUG - 2018-05-22 02:37:57 --> UTF-8 Support Enabled
INFO - 2018-05-22 02:37:57 --> Utf8 Class Initialized
INFO - 2018-05-22 02:37:57 --> URI Class Initialized
INFO - 2018-05-22 02:37:57 --> Router Class Initialized
INFO - 2018-05-22 02:37:57 --> Output Class Initialized
INFO - 2018-05-22 02:37:57 --> Security Class Initialized
DEBUG - 2018-05-22 02:37:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 02:37:57 --> Input Class Initialized
INFO - 2018-05-22 02:37:57 --> Language Class Initialized
ERROR - 2018-05-22 02:37:57 --> 404 Page Not Found: /index
INFO - 2018-05-22 02:38:05 --> Config Class Initialized
INFO - 2018-05-22 02:38:05 --> Hooks Class Initialized
DEBUG - 2018-05-22 02:38:05 --> UTF-8 Support Enabled
INFO - 2018-05-22 02:38:05 --> Utf8 Class Initialized
INFO - 2018-05-22 02:38:05 --> URI Class Initialized
INFO - 2018-05-22 02:38:05 --> Router Class Initialized
INFO - 2018-05-22 02:38:05 --> Output Class Initialized
INFO - 2018-05-22 02:38:05 --> Security Class Initialized
DEBUG - 2018-05-22 02:38:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 02:38:05 --> Input Class Initialized
INFO - 2018-05-22 02:38:05 --> Language Class Initialized
INFO - 2018-05-22 02:38:05 --> Language Class Initialized
INFO - 2018-05-22 02:38:05 --> Config Class Initialized
INFO - 2018-05-22 02:38:05 --> Loader Class Initialized
DEBUG - 2018-05-22 02:38:05 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 02:38:05 --> Helper loaded: url_helper
INFO - 2018-05-22 02:38:05 --> Helper loaded: form_helper
INFO - 2018-05-22 02:38:05 --> Helper loaded: date_helper
INFO - 2018-05-22 02:38:05 --> Helper loaded: util_helper
INFO - 2018-05-22 02:38:05 --> Helper loaded: text_helper
INFO - 2018-05-22 02:38:05 --> Helper loaded: string_helper
INFO - 2018-05-22 02:38:05 --> Database Driver Class Initialized
DEBUG - 2018-05-22 02:38:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 02:38:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 02:38:05 --> Email Class Initialized
INFO - 2018-05-22 02:38:05 --> Controller Class Initialized
DEBUG - 2018-05-22 02:38:05 --> Profile MX_Controller Initialized
DEBUG - 2018-05-22 02:38:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 02:38:05 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 02:38:06 --> Login MX_Controller Initialized
INFO - 2018-05-22 02:38:06 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 02:38:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 02:38:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-22 02:39:15 --> Config Class Initialized
INFO - 2018-05-22 02:39:15 --> Hooks Class Initialized
DEBUG - 2018-05-22 02:39:15 --> UTF-8 Support Enabled
INFO - 2018-05-22 02:39:15 --> Utf8 Class Initialized
INFO - 2018-05-22 02:39:15 --> URI Class Initialized
INFO - 2018-05-22 02:39:15 --> Router Class Initialized
INFO - 2018-05-22 02:39:15 --> Output Class Initialized
INFO - 2018-05-22 02:39:15 --> Security Class Initialized
DEBUG - 2018-05-22 02:39:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 02:39:15 --> Input Class Initialized
INFO - 2018-05-22 02:39:15 --> Language Class Initialized
INFO - 2018-05-22 02:39:15 --> Language Class Initialized
INFO - 2018-05-22 02:39:15 --> Config Class Initialized
INFO - 2018-05-22 02:39:15 --> Loader Class Initialized
DEBUG - 2018-05-22 02:39:15 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 02:39:15 --> Helper loaded: url_helper
INFO - 2018-05-22 02:39:15 --> Helper loaded: form_helper
INFO - 2018-05-22 02:39:15 --> Helper loaded: date_helper
INFO - 2018-05-22 02:39:15 --> Helper loaded: util_helper
INFO - 2018-05-22 02:39:15 --> Helper loaded: text_helper
INFO - 2018-05-22 02:39:15 --> Helper loaded: string_helper
INFO - 2018-05-22 02:39:15 --> Database Driver Class Initialized
DEBUG - 2018-05-22 02:39:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 02:39:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 02:39:15 --> Email Class Initialized
INFO - 2018-05-22 02:39:15 --> Controller Class Initialized
DEBUG - 2018-05-22 02:39:15 --> Profile MX_Controller Initialized
DEBUG - 2018-05-22 02:39:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 02:39:15 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 02:39:15 --> Login MX_Controller Initialized
INFO - 2018-05-22 02:39:15 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 02:39:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 02:39:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-22 02:39:31 --> Config Class Initialized
INFO - 2018-05-22 02:39:31 --> Hooks Class Initialized
DEBUG - 2018-05-22 02:39:31 --> UTF-8 Support Enabled
INFO - 2018-05-22 02:39:31 --> Utf8 Class Initialized
INFO - 2018-05-22 02:39:31 --> URI Class Initialized
INFO - 2018-05-22 02:39:31 --> Router Class Initialized
INFO - 2018-05-22 02:39:31 --> Output Class Initialized
INFO - 2018-05-22 02:39:31 --> Security Class Initialized
DEBUG - 2018-05-22 02:39:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 02:39:31 --> Input Class Initialized
INFO - 2018-05-22 02:39:31 --> Language Class Initialized
INFO - 2018-05-22 02:39:31 --> Language Class Initialized
INFO - 2018-05-22 02:39:31 --> Config Class Initialized
INFO - 2018-05-22 02:39:31 --> Loader Class Initialized
DEBUG - 2018-05-22 02:39:31 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 02:39:31 --> Helper loaded: url_helper
INFO - 2018-05-22 02:39:31 --> Helper loaded: form_helper
INFO - 2018-05-22 02:39:31 --> Helper loaded: date_helper
INFO - 2018-05-22 02:39:31 --> Helper loaded: util_helper
INFO - 2018-05-22 02:39:31 --> Helper loaded: text_helper
INFO - 2018-05-22 02:39:31 --> Helper loaded: string_helper
INFO - 2018-05-22 02:39:31 --> Database Driver Class Initialized
DEBUG - 2018-05-22 02:39:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 02:39:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 02:39:31 --> Email Class Initialized
INFO - 2018-05-22 02:39:31 --> Controller Class Initialized
DEBUG - 2018-05-22 02:39:31 --> Profile MX_Controller Initialized
DEBUG - 2018-05-22 02:39:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 02:39:31 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 02:39:31 --> Login MX_Controller Initialized
INFO - 2018-05-22 02:39:31 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 02:39:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 02:39:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-22 02:39:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-22 02:39:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-22 02:39:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-22 02:39:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-05-22 02:39:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-22 02:39:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-22 02:39:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/profile.php
INFO - 2018-05-22 02:39:31 --> Final output sent to browser
DEBUG - 2018-05-22 02:39:31 --> Total execution time: 0.5838
INFO - 2018-05-22 02:39:33 --> Config Class Initialized
INFO - 2018-05-22 02:39:33 --> Hooks Class Initialized
DEBUG - 2018-05-22 02:39:33 --> UTF-8 Support Enabled
INFO - 2018-05-22 02:39:33 --> Utf8 Class Initialized
INFO - 2018-05-22 02:39:34 --> URI Class Initialized
INFO - 2018-05-22 02:39:34 --> Router Class Initialized
INFO - 2018-05-22 02:39:34 --> Output Class Initialized
INFO - 2018-05-22 02:39:34 --> Security Class Initialized
DEBUG - 2018-05-22 02:39:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 02:39:34 --> Input Class Initialized
INFO - 2018-05-22 02:39:34 --> Language Class Initialized
ERROR - 2018-05-22 02:39:34 --> 404 Page Not Found: /index
INFO - 2018-05-22 02:39:34 --> Config Class Initialized
INFO - 2018-05-22 02:39:34 --> Hooks Class Initialized
DEBUG - 2018-05-22 02:39:34 --> UTF-8 Support Enabled
INFO - 2018-05-22 02:39:34 --> Utf8 Class Initialized
INFO - 2018-05-22 02:39:34 --> URI Class Initialized
INFO - 2018-05-22 02:39:34 --> Router Class Initialized
INFO - 2018-05-22 02:39:34 --> Output Class Initialized
INFO - 2018-05-22 02:39:34 --> Security Class Initialized
DEBUG - 2018-05-22 02:39:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 02:39:34 --> Input Class Initialized
INFO - 2018-05-22 02:39:34 --> Language Class Initialized
ERROR - 2018-05-22 02:39:34 --> 404 Page Not Found: /index
INFO - 2018-05-22 02:39:34 --> Config Class Initialized
INFO - 2018-05-22 02:39:34 --> Hooks Class Initialized
DEBUG - 2018-05-22 02:39:34 --> UTF-8 Support Enabled
INFO - 2018-05-22 02:39:34 --> Utf8 Class Initialized
INFO - 2018-05-22 02:39:34 --> URI Class Initialized
INFO - 2018-05-22 02:39:34 --> Router Class Initialized
INFO - 2018-05-22 02:39:34 --> Output Class Initialized
INFO - 2018-05-22 02:39:34 --> Security Class Initialized
DEBUG - 2018-05-22 02:39:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 02:39:34 --> Input Class Initialized
INFO - 2018-05-22 02:39:34 --> Language Class Initialized
ERROR - 2018-05-22 02:39:34 --> 404 Page Not Found: /index
INFO - 2018-05-22 02:51:21 --> Config Class Initialized
INFO - 2018-05-22 02:51:21 --> Hooks Class Initialized
DEBUG - 2018-05-22 02:51:21 --> UTF-8 Support Enabled
INFO - 2018-05-22 02:51:21 --> Utf8 Class Initialized
INFO - 2018-05-22 02:51:21 --> URI Class Initialized
INFO - 2018-05-22 02:51:21 --> Router Class Initialized
INFO - 2018-05-22 02:51:21 --> Output Class Initialized
INFO - 2018-05-22 02:51:21 --> Security Class Initialized
DEBUG - 2018-05-22 02:51:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 02:51:21 --> Input Class Initialized
INFO - 2018-05-22 02:51:21 --> Language Class Initialized
INFO - 2018-05-22 02:51:21 --> Language Class Initialized
INFO - 2018-05-22 02:51:21 --> Config Class Initialized
INFO - 2018-05-22 02:51:21 --> Loader Class Initialized
DEBUG - 2018-05-22 02:51:21 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 02:51:21 --> Helper loaded: url_helper
INFO - 2018-05-22 02:51:21 --> Helper loaded: form_helper
INFO - 2018-05-22 02:51:21 --> Helper loaded: date_helper
INFO - 2018-05-22 02:51:21 --> Helper loaded: util_helper
INFO - 2018-05-22 02:51:21 --> Helper loaded: text_helper
INFO - 2018-05-22 02:51:21 --> Helper loaded: string_helper
INFO - 2018-05-22 02:51:21 --> Database Driver Class Initialized
DEBUG - 2018-05-22 02:51:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 02:51:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 02:51:21 --> Email Class Initialized
INFO - 2018-05-22 02:51:21 --> Controller Class Initialized
DEBUG - 2018-05-22 02:51:21 --> Profile MX_Controller Initialized
DEBUG - 2018-05-22 02:51:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 02:51:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 02:51:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-22 02:51:21 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 02:51:21 --> Login MX_Controller Initialized
INFO - 2018-05-22 02:51:21 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 02:51:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-22 02:53:14 --> Config Class Initialized
INFO - 2018-05-22 02:53:14 --> Hooks Class Initialized
DEBUG - 2018-05-22 02:53:14 --> UTF-8 Support Enabled
INFO - 2018-05-22 02:53:14 --> Utf8 Class Initialized
INFO - 2018-05-22 02:53:14 --> URI Class Initialized
INFO - 2018-05-22 02:53:14 --> Router Class Initialized
INFO - 2018-05-22 02:53:14 --> Output Class Initialized
INFO - 2018-05-22 02:53:14 --> Security Class Initialized
DEBUG - 2018-05-22 02:53:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 02:53:14 --> Input Class Initialized
INFO - 2018-05-22 02:53:14 --> Language Class Initialized
INFO - 2018-05-22 02:53:14 --> Language Class Initialized
INFO - 2018-05-22 02:53:14 --> Config Class Initialized
INFO - 2018-05-22 02:53:14 --> Loader Class Initialized
DEBUG - 2018-05-22 02:53:14 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 02:53:14 --> Helper loaded: url_helper
INFO - 2018-05-22 02:53:14 --> Helper loaded: form_helper
INFO - 2018-05-22 02:53:14 --> Helper loaded: date_helper
INFO - 2018-05-22 02:53:14 --> Helper loaded: util_helper
INFO - 2018-05-22 02:53:14 --> Helper loaded: text_helper
INFO - 2018-05-22 02:53:14 --> Helper loaded: string_helper
INFO - 2018-05-22 02:53:14 --> Database Driver Class Initialized
DEBUG - 2018-05-22 02:53:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 02:53:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 02:53:14 --> Email Class Initialized
INFO - 2018-05-22 02:53:14 --> Controller Class Initialized
DEBUG - 2018-05-22 02:53:14 --> Profile MX_Controller Initialized
DEBUG - 2018-05-22 02:53:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 02:53:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 02:53:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-22 02:53:14 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 02:53:14 --> Login MX_Controller Initialized
INFO - 2018-05-22 02:53:14 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 02:53:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-22 02:53:14 --> Upload Class Initialized
ERROR - 2018-05-22 02:53:14 --> Severity: Notice --> Undefined index: old_profile_image E:\xampp\htdocs\consulting\application\modules\home\controllers\Profile.php 98
ERROR - 2018-05-22 02:53:14 --> Severity: Warning --> unlink(E:\xampp\htdocs\consulting\assets/images/users/): Permission denied E:\xampp\htdocs\consulting\application\modules\home\controllers\Profile.php 98
ERROR - 2018-05-22 02:53:14 --> Severity: Notice --> Undefined index: old_profile_image E:\xampp\htdocs\consulting\application\modules\home\controllers\Profile.php 99
INFO - 2018-05-22 02:59:18 --> Config Class Initialized
INFO - 2018-05-22 02:59:18 --> Hooks Class Initialized
DEBUG - 2018-05-22 02:59:18 --> UTF-8 Support Enabled
INFO - 2018-05-22 02:59:18 --> Utf8 Class Initialized
INFO - 2018-05-22 02:59:18 --> URI Class Initialized
INFO - 2018-05-22 02:59:18 --> Router Class Initialized
INFO - 2018-05-22 02:59:18 --> Output Class Initialized
INFO - 2018-05-22 02:59:18 --> Security Class Initialized
DEBUG - 2018-05-22 02:59:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 02:59:18 --> Input Class Initialized
INFO - 2018-05-22 02:59:18 --> Language Class Initialized
INFO - 2018-05-22 02:59:18 --> Language Class Initialized
INFO - 2018-05-22 02:59:18 --> Config Class Initialized
INFO - 2018-05-22 02:59:18 --> Loader Class Initialized
DEBUG - 2018-05-22 02:59:18 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 02:59:18 --> Helper loaded: url_helper
INFO - 2018-05-22 02:59:18 --> Helper loaded: form_helper
INFO - 2018-05-22 02:59:18 --> Helper loaded: date_helper
INFO - 2018-05-22 02:59:18 --> Helper loaded: util_helper
INFO - 2018-05-22 02:59:18 --> Helper loaded: text_helper
INFO - 2018-05-22 02:59:18 --> Helper loaded: string_helper
INFO - 2018-05-22 02:59:18 --> Database Driver Class Initialized
DEBUG - 2018-05-22 02:59:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 02:59:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 02:59:18 --> Email Class Initialized
INFO - 2018-05-22 02:59:18 --> Controller Class Initialized
DEBUG - 2018-05-22 02:59:18 --> Profile MX_Controller Initialized
DEBUG - 2018-05-22 02:59:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 02:59:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 02:59:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-22 02:59:18 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 02:59:18 --> Login MX_Controller Initialized
INFO - 2018-05-22 02:59:18 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 02:59:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-22 02:59:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-22 02:59:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-22 02:59:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-22 02:59:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-05-22 02:59:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-22 02:59:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-22 02:59:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/profile.php
INFO - 2018-05-22 02:59:19 --> Final output sent to browser
INFO - 2018-05-22 02:59:19 --> Config Class Initialized
INFO - 2018-05-22 02:59:19 --> Hooks Class Initialized
DEBUG - 2018-05-22 02:59:19 --> Total execution time: 0.8199
DEBUG - 2018-05-22 02:59:19 --> UTF-8 Support Enabled
INFO - 2018-05-22 02:59:19 --> Utf8 Class Initialized
INFO - 2018-05-22 02:59:19 --> URI Class Initialized
INFO - 2018-05-22 02:59:19 --> Router Class Initialized
INFO - 2018-05-22 02:59:19 --> Output Class Initialized
INFO - 2018-05-22 02:59:19 --> Security Class Initialized
DEBUG - 2018-05-22 02:59:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 02:59:19 --> Input Class Initialized
INFO - 2018-05-22 02:59:19 --> Language Class Initialized
ERROR - 2018-05-22 02:59:19 --> 404 Page Not Found: /index
INFO - 2018-05-22 02:59:20 --> Config Class Initialized
INFO - 2018-05-22 02:59:20 --> Hooks Class Initialized
DEBUG - 2018-05-22 02:59:21 --> UTF-8 Support Enabled
INFO - 2018-05-22 02:59:21 --> Utf8 Class Initialized
INFO - 2018-05-22 02:59:21 --> URI Class Initialized
INFO - 2018-05-22 02:59:21 --> Router Class Initialized
INFO - 2018-05-22 02:59:21 --> Output Class Initialized
INFO - 2018-05-22 02:59:21 --> Security Class Initialized
DEBUG - 2018-05-22 02:59:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 02:59:21 --> Input Class Initialized
INFO - 2018-05-22 02:59:21 --> Language Class Initialized
ERROR - 2018-05-22 02:59:21 --> 404 Page Not Found: /index
INFO - 2018-05-22 02:59:21 --> Config Class Initialized
INFO - 2018-05-22 02:59:21 --> Hooks Class Initialized
DEBUG - 2018-05-22 02:59:21 --> UTF-8 Support Enabled
INFO - 2018-05-22 02:59:21 --> Utf8 Class Initialized
INFO - 2018-05-22 02:59:21 --> URI Class Initialized
INFO - 2018-05-22 02:59:21 --> Router Class Initialized
INFO - 2018-05-22 02:59:21 --> Output Class Initialized
INFO - 2018-05-22 02:59:21 --> Security Class Initialized
DEBUG - 2018-05-22 02:59:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 02:59:21 --> Input Class Initialized
INFO - 2018-05-22 02:59:21 --> Language Class Initialized
ERROR - 2018-05-22 02:59:21 --> 404 Page Not Found: /index
INFO - 2018-05-22 02:59:21 --> Config Class Initialized
INFO - 2018-05-22 02:59:21 --> Hooks Class Initialized
DEBUG - 2018-05-22 02:59:21 --> UTF-8 Support Enabled
INFO - 2018-05-22 02:59:21 --> Utf8 Class Initialized
INFO - 2018-05-22 02:59:21 --> URI Class Initialized
INFO - 2018-05-22 02:59:21 --> Router Class Initialized
INFO - 2018-05-22 02:59:21 --> Output Class Initialized
INFO - 2018-05-22 02:59:21 --> Security Class Initialized
DEBUG - 2018-05-22 02:59:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 02:59:21 --> Input Class Initialized
INFO - 2018-05-22 02:59:21 --> Language Class Initialized
ERROR - 2018-05-22 02:59:21 --> 404 Page Not Found: /index
INFO - 2018-05-22 02:59:41 --> Config Class Initialized
INFO - 2018-05-22 02:59:41 --> Hooks Class Initialized
DEBUG - 2018-05-22 02:59:41 --> UTF-8 Support Enabled
INFO - 2018-05-22 02:59:41 --> Utf8 Class Initialized
INFO - 2018-05-22 02:59:41 --> URI Class Initialized
INFO - 2018-05-22 02:59:41 --> Router Class Initialized
INFO - 2018-05-22 02:59:41 --> Output Class Initialized
INFO - 2018-05-22 02:59:41 --> Security Class Initialized
DEBUG - 2018-05-22 02:59:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 02:59:41 --> Input Class Initialized
INFO - 2018-05-22 02:59:41 --> Language Class Initialized
INFO - 2018-05-22 02:59:41 --> Language Class Initialized
INFO - 2018-05-22 02:59:41 --> Config Class Initialized
INFO - 2018-05-22 02:59:41 --> Loader Class Initialized
DEBUG - 2018-05-22 02:59:41 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 02:59:41 --> Helper loaded: url_helper
INFO - 2018-05-22 02:59:41 --> Helper loaded: form_helper
INFO - 2018-05-22 02:59:41 --> Helper loaded: date_helper
INFO - 2018-05-22 02:59:41 --> Helper loaded: util_helper
INFO - 2018-05-22 02:59:41 --> Helper loaded: text_helper
INFO - 2018-05-22 02:59:41 --> Helper loaded: string_helper
INFO - 2018-05-22 02:59:41 --> Database Driver Class Initialized
DEBUG - 2018-05-22 02:59:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 02:59:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 02:59:41 --> Email Class Initialized
INFO - 2018-05-22 02:59:41 --> Controller Class Initialized
DEBUG - 2018-05-22 02:59:41 --> Profile MX_Controller Initialized
DEBUG - 2018-05-22 02:59:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 02:59:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 02:59:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-22 02:59:41 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 02:59:41 --> Login MX_Controller Initialized
INFO - 2018-05-22 02:59:41 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 02:59:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-22 02:59:41 --> Upload Class Initialized
ERROR - 2018-05-22 02:59:41 --> Severity: Warning --> unlink(E:\xampp\htdocs\consulting\assets/images/users/Gopi-Fertilizers-H2RQ56UJs8zEmgnf.PNG): No such file or directory E:\xampp\htdocs\consulting\application\modules\home\controllers\Profile.php 98
INFO - 2018-05-22 03:00:08 --> Config Class Initialized
INFO - 2018-05-22 03:00:08 --> Hooks Class Initialized
DEBUG - 2018-05-22 03:00:08 --> UTF-8 Support Enabled
INFO - 2018-05-22 03:00:08 --> Utf8 Class Initialized
INFO - 2018-05-22 03:00:08 --> URI Class Initialized
INFO - 2018-05-22 03:00:08 --> Router Class Initialized
INFO - 2018-05-22 03:00:08 --> Output Class Initialized
INFO - 2018-05-22 03:00:08 --> Security Class Initialized
DEBUG - 2018-05-22 03:00:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 03:00:08 --> Input Class Initialized
INFO - 2018-05-22 03:00:08 --> Language Class Initialized
INFO - 2018-05-22 03:00:08 --> Language Class Initialized
INFO - 2018-05-22 03:00:08 --> Config Class Initialized
INFO - 2018-05-22 03:00:08 --> Loader Class Initialized
DEBUG - 2018-05-22 03:00:08 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 03:00:08 --> Helper loaded: url_helper
INFO - 2018-05-22 03:00:08 --> Helper loaded: form_helper
INFO - 2018-05-22 03:00:08 --> Helper loaded: date_helper
INFO - 2018-05-22 03:00:08 --> Helper loaded: util_helper
INFO - 2018-05-22 03:00:08 --> Helper loaded: text_helper
INFO - 2018-05-22 03:00:08 --> Helper loaded: string_helper
INFO - 2018-05-22 03:00:08 --> Database Driver Class Initialized
DEBUG - 2018-05-22 03:00:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 03:00:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 03:00:08 --> Email Class Initialized
INFO - 2018-05-22 03:00:08 --> Controller Class Initialized
DEBUG - 2018-05-22 03:00:08 --> Profile MX_Controller Initialized
DEBUG - 2018-05-22 03:00:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 03:00:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 03:00:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-22 03:00:09 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 03:00:09 --> Login MX_Controller Initialized
INFO - 2018-05-22 03:00:09 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 03:00:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-22 03:00:09 --> Upload Class Initialized
ERROR - 2018-05-22 03:00:09 --> Severity: Warning --> unlink(E:\xampp\htdocs\consulting\assets/images/users/Gopi-Fertilizers-H2RQ56UJs8zEmgnf.PNG): No such file or directory E:\xampp\htdocs\consulting\application\modules\home\controllers\Profile.php 98
INFO - 2018-05-22 03:00:48 --> Config Class Initialized
INFO - 2018-05-22 03:00:48 --> Hooks Class Initialized
DEBUG - 2018-05-22 03:00:48 --> UTF-8 Support Enabled
INFO - 2018-05-22 03:00:48 --> Utf8 Class Initialized
INFO - 2018-05-22 03:00:48 --> URI Class Initialized
INFO - 2018-05-22 03:00:48 --> Router Class Initialized
INFO - 2018-05-22 03:00:48 --> Output Class Initialized
INFO - 2018-05-22 03:00:48 --> Security Class Initialized
DEBUG - 2018-05-22 03:00:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 03:00:48 --> Input Class Initialized
INFO - 2018-05-22 03:00:48 --> Language Class Initialized
INFO - 2018-05-22 03:00:48 --> Language Class Initialized
INFO - 2018-05-22 03:00:48 --> Config Class Initialized
INFO - 2018-05-22 03:00:48 --> Loader Class Initialized
DEBUG - 2018-05-22 03:00:48 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 03:00:48 --> Helper loaded: url_helper
INFO - 2018-05-22 03:00:48 --> Helper loaded: form_helper
INFO - 2018-05-22 03:00:48 --> Helper loaded: date_helper
INFO - 2018-05-22 03:00:48 --> Helper loaded: util_helper
INFO - 2018-05-22 03:00:48 --> Helper loaded: text_helper
INFO - 2018-05-22 03:00:48 --> Helper loaded: string_helper
INFO - 2018-05-22 03:00:48 --> Database Driver Class Initialized
DEBUG - 2018-05-22 03:00:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 03:00:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 03:00:48 --> Email Class Initialized
INFO - 2018-05-22 03:00:48 --> Controller Class Initialized
DEBUG - 2018-05-22 03:00:48 --> Profile MX_Controller Initialized
DEBUG - 2018-05-22 03:00:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 03:00:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 03:00:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-22 03:00:48 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 03:00:48 --> Login MX_Controller Initialized
INFO - 2018-05-22 03:00:48 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 03:00:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-22 03:00:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-22 03:00:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-22 03:00:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-22 03:00:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-05-22 03:00:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-22 03:00:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-22 03:00:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/profile.php
INFO - 2018-05-22 03:00:48 --> Final output sent to browser
INFO - 2018-05-22 03:00:48 --> Config Class Initialized
INFO - 2018-05-22 03:00:48 --> Hooks Class Initialized
DEBUG - 2018-05-22 03:00:48 --> Total execution time: 0.7306
DEBUG - 2018-05-22 03:00:48 --> UTF-8 Support Enabled
INFO - 2018-05-22 03:00:48 --> Utf8 Class Initialized
INFO - 2018-05-22 03:00:48 --> URI Class Initialized
INFO - 2018-05-22 03:00:48 --> Router Class Initialized
INFO - 2018-05-22 03:00:48 --> Output Class Initialized
INFO - 2018-05-22 03:00:48 --> Security Class Initialized
DEBUG - 2018-05-22 03:00:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 03:00:49 --> Input Class Initialized
INFO - 2018-05-22 03:00:49 --> Language Class Initialized
ERROR - 2018-05-22 03:00:49 --> 404 Page Not Found: /index
INFO - 2018-05-22 03:00:49 --> Config Class Initialized
INFO - 2018-05-22 03:00:49 --> Hooks Class Initialized
DEBUG - 2018-05-22 03:00:49 --> UTF-8 Support Enabled
INFO - 2018-05-22 03:00:49 --> Utf8 Class Initialized
INFO - 2018-05-22 03:00:49 --> URI Class Initialized
INFO - 2018-05-22 03:00:49 --> Router Class Initialized
INFO - 2018-05-22 03:00:49 --> Output Class Initialized
INFO - 2018-05-22 03:00:49 --> Security Class Initialized
DEBUG - 2018-05-22 03:00:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 03:00:49 --> Input Class Initialized
INFO - 2018-05-22 03:00:50 --> Language Class Initialized
ERROR - 2018-05-22 03:00:50 --> 404 Page Not Found: /index
INFO - 2018-05-22 03:00:50 --> Config Class Initialized
INFO - 2018-05-22 03:00:50 --> Hooks Class Initialized
DEBUG - 2018-05-22 03:00:50 --> UTF-8 Support Enabled
INFO - 2018-05-22 03:00:50 --> Utf8 Class Initialized
INFO - 2018-05-22 03:00:50 --> URI Class Initialized
INFO - 2018-05-22 03:00:50 --> Router Class Initialized
INFO - 2018-05-22 03:00:50 --> Output Class Initialized
INFO - 2018-05-22 03:00:50 --> Security Class Initialized
DEBUG - 2018-05-22 03:00:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 03:00:50 --> Input Class Initialized
INFO - 2018-05-22 03:00:50 --> Language Class Initialized
ERROR - 2018-05-22 03:00:50 --> 404 Page Not Found: /index
INFO - 2018-05-22 03:00:50 --> Config Class Initialized
INFO - 2018-05-22 03:00:50 --> Hooks Class Initialized
DEBUG - 2018-05-22 03:00:50 --> UTF-8 Support Enabled
INFO - 2018-05-22 03:00:50 --> Utf8 Class Initialized
INFO - 2018-05-22 03:00:50 --> URI Class Initialized
INFO - 2018-05-22 03:00:50 --> Router Class Initialized
INFO - 2018-05-22 03:00:50 --> Output Class Initialized
INFO - 2018-05-22 03:00:50 --> Security Class Initialized
DEBUG - 2018-05-22 03:00:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 03:00:50 --> Input Class Initialized
INFO - 2018-05-22 03:00:50 --> Language Class Initialized
ERROR - 2018-05-22 03:00:50 --> 404 Page Not Found: /index
INFO - 2018-05-22 03:01:56 --> Config Class Initialized
INFO - 2018-05-22 03:01:56 --> Hooks Class Initialized
DEBUG - 2018-05-22 03:01:56 --> UTF-8 Support Enabled
INFO - 2018-05-22 03:01:56 --> Utf8 Class Initialized
INFO - 2018-05-22 03:01:56 --> URI Class Initialized
INFO - 2018-05-22 03:01:56 --> Router Class Initialized
INFO - 2018-05-22 03:01:56 --> Output Class Initialized
INFO - 2018-05-22 03:01:56 --> Security Class Initialized
DEBUG - 2018-05-22 03:01:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 03:01:56 --> Input Class Initialized
INFO - 2018-05-22 03:01:56 --> Language Class Initialized
INFO - 2018-05-22 03:01:56 --> Language Class Initialized
INFO - 2018-05-22 03:01:56 --> Config Class Initialized
INFO - 2018-05-22 03:01:56 --> Loader Class Initialized
DEBUG - 2018-05-22 03:01:56 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 03:01:56 --> Helper loaded: url_helper
INFO - 2018-05-22 03:01:56 --> Helper loaded: form_helper
INFO - 2018-05-22 03:01:56 --> Helper loaded: date_helper
INFO - 2018-05-22 03:01:56 --> Helper loaded: util_helper
INFO - 2018-05-22 03:01:56 --> Helper loaded: text_helper
INFO - 2018-05-22 03:01:56 --> Helper loaded: string_helper
INFO - 2018-05-22 03:01:56 --> Database Driver Class Initialized
DEBUG - 2018-05-22 03:01:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 03:01:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 03:01:56 --> Email Class Initialized
INFO - 2018-05-22 03:01:56 --> Controller Class Initialized
DEBUG - 2018-05-22 03:01:56 --> Profile MX_Controller Initialized
DEBUG - 2018-05-22 03:01:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 03:01:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 03:01:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-22 03:01:56 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 03:01:56 --> Login MX_Controller Initialized
INFO - 2018-05-22 03:01:56 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 03:01:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-22 03:01:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-22 03:01:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-22 03:01:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-22 03:01:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-05-22 03:01:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-22 03:01:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-22 03:01:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/profile.php
INFO - 2018-05-22 03:01:56 --> Final output sent to browser
DEBUG - 2018-05-22 03:01:57 --> Total execution time: 0.6196
INFO - 2018-05-22 03:01:57 --> Config Class Initialized
INFO - 2018-05-22 03:01:57 --> Hooks Class Initialized
DEBUG - 2018-05-22 03:01:57 --> UTF-8 Support Enabled
INFO - 2018-05-22 03:01:57 --> Utf8 Class Initialized
INFO - 2018-05-22 03:01:58 --> URI Class Initialized
INFO - 2018-05-22 03:01:58 --> Router Class Initialized
INFO - 2018-05-22 03:01:58 --> Output Class Initialized
INFO - 2018-05-22 03:01:58 --> Security Class Initialized
DEBUG - 2018-05-22 03:01:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 03:01:58 --> Input Class Initialized
INFO - 2018-05-22 03:01:58 --> Language Class Initialized
ERROR - 2018-05-22 03:01:58 --> 404 Page Not Found: /index
INFO - 2018-05-22 03:01:58 --> Config Class Initialized
INFO - 2018-05-22 03:01:58 --> Hooks Class Initialized
DEBUG - 2018-05-22 03:01:58 --> UTF-8 Support Enabled
INFO - 2018-05-22 03:01:58 --> Utf8 Class Initialized
INFO - 2018-05-22 03:01:58 --> URI Class Initialized
INFO - 2018-05-22 03:01:58 --> Router Class Initialized
INFO - 2018-05-22 03:01:58 --> Output Class Initialized
INFO - 2018-05-22 03:01:58 --> Security Class Initialized
DEBUG - 2018-05-22 03:01:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 03:01:58 --> Input Class Initialized
INFO - 2018-05-22 03:01:58 --> Language Class Initialized
ERROR - 2018-05-22 03:01:58 --> 404 Page Not Found: /index
INFO - 2018-05-22 03:01:58 --> Config Class Initialized
INFO - 2018-05-22 03:01:58 --> Hooks Class Initialized
DEBUG - 2018-05-22 03:01:58 --> UTF-8 Support Enabled
INFO - 2018-05-22 03:01:58 --> Utf8 Class Initialized
INFO - 2018-05-22 03:01:59 --> URI Class Initialized
INFO - 2018-05-22 03:01:59 --> Router Class Initialized
INFO - 2018-05-22 03:01:59 --> Output Class Initialized
INFO - 2018-05-22 03:01:59 --> Security Class Initialized
DEBUG - 2018-05-22 03:01:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 03:01:59 --> Input Class Initialized
INFO - 2018-05-22 03:01:59 --> Language Class Initialized
ERROR - 2018-05-22 03:01:59 --> 404 Page Not Found: /index
INFO - 2018-05-22 03:03:07 --> Config Class Initialized
INFO - 2018-05-22 03:03:07 --> Hooks Class Initialized
DEBUG - 2018-05-22 03:03:07 --> UTF-8 Support Enabled
INFO - 2018-05-22 03:03:07 --> Utf8 Class Initialized
INFO - 2018-05-22 03:03:07 --> URI Class Initialized
INFO - 2018-05-22 03:03:07 --> Router Class Initialized
INFO - 2018-05-22 03:03:07 --> Output Class Initialized
INFO - 2018-05-22 03:03:07 --> Security Class Initialized
DEBUG - 2018-05-22 03:03:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 03:03:07 --> Input Class Initialized
INFO - 2018-05-22 03:03:07 --> Language Class Initialized
INFO - 2018-05-22 03:03:07 --> Language Class Initialized
INFO - 2018-05-22 03:03:07 --> Config Class Initialized
INFO - 2018-05-22 03:03:07 --> Loader Class Initialized
DEBUG - 2018-05-22 03:03:07 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 03:03:07 --> Helper loaded: url_helper
INFO - 2018-05-22 03:03:07 --> Helper loaded: form_helper
INFO - 2018-05-22 03:03:07 --> Helper loaded: date_helper
INFO - 2018-05-22 03:03:07 --> Helper loaded: util_helper
INFO - 2018-05-22 03:03:07 --> Helper loaded: text_helper
INFO - 2018-05-22 03:03:07 --> Helper loaded: string_helper
INFO - 2018-05-22 03:03:07 --> Database Driver Class Initialized
DEBUG - 2018-05-22 03:03:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 03:03:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 03:03:07 --> Email Class Initialized
INFO - 2018-05-22 03:03:07 --> Controller Class Initialized
DEBUG - 2018-05-22 03:03:07 --> Profile MX_Controller Initialized
DEBUG - 2018-05-22 03:03:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 03:03:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 03:03:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-22 03:03:07 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 03:03:07 --> Login MX_Controller Initialized
INFO - 2018-05-22 03:03:07 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 03:03:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
ERROR - 2018-05-22 03:03:07 --> Severity: Notice --> Undefined index: profile_image E:\xampp\htdocs\consulting\application\modules\home\controllers\Profile.php 86
INFO - 2018-05-22 03:03:54 --> Config Class Initialized
INFO - 2018-05-22 03:03:54 --> Hooks Class Initialized
DEBUG - 2018-05-22 03:03:54 --> UTF-8 Support Enabled
INFO - 2018-05-22 03:03:54 --> Utf8 Class Initialized
INFO - 2018-05-22 03:03:54 --> URI Class Initialized
INFO - 2018-05-22 03:03:54 --> Router Class Initialized
INFO - 2018-05-22 03:03:54 --> Output Class Initialized
INFO - 2018-05-22 03:03:54 --> Security Class Initialized
DEBUG - 2018-05-22 03:03:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 03:03:54 --> Input Class Initialized
INFO - 2018-05-22 03:03:54 --> Language Class Initialized
INFO - 2018-05-22 03:03:54 --> Language Class Initialized
INFO - 2018-05-22 03:03:54 --> Config Class Initialized
INFO - 2018-05-22 03:03:54 --> Loader Class Initialized
DEBUG - 2018-05-22 03:03:54 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 03:03:54 --> Helper loaded: url_helper
INFO - 2018-05-22 03:03:54 --> Helper loaded: form_helper
INFO - 2018-05-22 03:03:54 --> Helper loaded: date_helper
INFO - 2018-05-22 03:03:54 --> Helper loaded: util_helper
INFO - 2018-05-22 03:03:54 --> Helper loaded: text_helper
INFO - 2018-05-22 03:03:54 --> Helper loaded: string_helper
INFO - 2018-05-22 03:03:54 --> Database Driver Class Initialized
DEBUG - 2018-05-22 03:03:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 03:03:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 03:03:55 --> Email Class Initialized
INFO - 2018-05-22 03:03:55 --> Controller Class Initialized
DEBUG - 2018-05-22 03:03:55 --> Profile MX_Controller Initialized
DEBUG - 2018-05-22 03:03:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 03:03:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 03:03:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-22 03:03:55 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 03:03:55 --> Login MX_Controller Initialized
INFO - 2018-05-22 03:03:55 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 03:03:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-22 03:03:58 --> Config Class Initialized
INFO - 2018-05-22 03:03:58 --> Hooks Class Initialized
DEBUG - 2018-05-22 03:03:58 --> UTF-8 Support Enabled
INFO - 2018-05-22 03:03:58 --> Utf8 Class Initialized
INFO - 2018-05-22 03:03:58 --> URI Class Initialized
INFO - 2018-05-22 03:03:58 --> Router Class Initialized
INFO - 2018-05-22 03:03:58 --> Output Class Initialized
INFO - 2018-05-22 03:03:58 --> Security Class Initialized
DEBUG - 2018-05-22 03:03:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 03:03:58 --> Input Class Initialized
INFO - 2018-05-22 03:03:58 --> Language Class Initialized
INFO - 2018-05-22 03:03:58 --> Language Class Initialized
INFO - 2018-05-22 03:03:58 --> Config Class Initialized
INFO - 2018-05-22 03:03:58 --> Loader Class Initialized
DEBUG - 2018-05-22 03:03:58 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 03:03:58 --> Helper loaded: url_helper
INFO - 2018-05-22 03:03:58 --> Helper loaded: form_helper
INFO - 2018-05-22 03:03:58 --> Helper loaded: date_helper
INFO - 2018-05-22 03:03:58 --> Helper loaded: util_helper
INFO - 2018-05-22 03:03:58 --> Helper loaded: text_helper
INFO - 2018-05-22 03:03:58 --> Helper loaded: string_helper
INFO - 2018-05-22 03:03:58 --> Database Driver Class Initialized
DEBUG - 2018-05-22 03:03:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 03:03:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 03:03:58 --> Email Class Initialized
INFO - 2018-05-22 03:03:58 --> Controller Class Initialized
DEBUG - 2018-05-22 03:03:58 --> Profile MX_Controller Initialized
DEBUG - 2018-05-22 03:03:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 03:03:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 03:03:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-22 03:03:58 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 03:03:58 --> Login MX_Controller Initialized
INFO - 2018-05-22 03:03:58 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 03:03:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-22 03:04:05 --> Config Class Initialized
INFO - 2018-05-22 03:04:05 --> Hooks Class Initialized
DEBUG - 2018-05-22 03:04:05 --> UTF-8 Support Enabled
INFO - 2018-05-22 03:04:05 --> Utf8 Class Initialized
INFO - 2018-05-22 03:04:05 --> URI Class Initialized
INFO - 2018-05-22 03:04:05 --> Router Class Initialized
INFO - 2018-05-22 03:04:05 --> Output Class Initialized
INFO - 2018-05-22 03:04:05 --> Security Class Initialized
DEBUG - 2018-05-22 03:04:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 03:04:05 --> Input Class Initialized
INFO - 2018-05-22 03:04:05 --> Language Class Initialized
INFO - 2018-05-22 03:04:05 --> Language Class Initialized
INFO - 2018-05-22 03:04:05 --> Config Class Initialized
INFO - 2018-05-22 03:04:05 --> Loader Class Initialized
DEBUG - 2018-05-22 03:04:05 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 03:04:05 --> Helper loaded: url_helper
INFO - 2018-05-22 03:04:05 --> Helper loaded: form_helper
INFO - 2018-05-22 03:04:05 --> Helper loaded: date_helper
INFO - 2018-05-22 03:04:05 --> Helper loaded: util_helper
INFO - 2018-05-22 03:04:05 --> Helper loaded: text_helper
INFO - 2018-05-22 03:04:05 --> Helper loaded: string_helper
INFO - 2018-05-22 03:04:05 --> Database Driver Class Initialized
DEBUG - 2018-05-22 03:04:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 03:04:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 03:04:05 --> Email Class Initialized
INFO - 2018-05-22 03:04:05 --> Controller Class Initialized
DEBUG - 2018-05-22 03:04:05 --> Profile MX_Controller Initialized
DEBUG - 2018-05-22 03:04:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 03:04:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 03:04:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-22 03:04:05 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 03:04:05 --> Login MX_Controller Initialized
INFO - 2018-05-22 03:04:05 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 03:04:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-22 03:04:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-22 03:04:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-22 03:04:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-22 03:04:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-05-22 03:04:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-22 03:04:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-22 03:04:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/profile.php
INFO - 2018-05-22 03:04:06 --> Final output sent to browser
DEBUG - 2018-05-22 03:04:06 --> Total execution time: 0.6718
INFO - 2018-05-22 03:04:06 --> Config Class Initialized
INFO - 2018-05-22 03:04:06 --> Hooks Class Initialized
DEBUG - 2018-05-22 03:04:06 --> UTF-8 Support Enabled
INFO - 2018-05-22 03:04:06 --> Utf8 Class Initialized
INFO - 2018-05-22 03:04:06 --> URI Class Initialized
INFO - 2018-05-22 03:04:06 --> Router Class Initialized
INFO - 2018-05-22 03:04:06 --> Output Class Initialized
INFO - 2018-05-22 03:04:06 --> Security Class Initialized
DEBUG - 2018-05-22 03:04:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 03:04:06 --> Input Class Initialized
INFO - 2018-05-22 03:04:06 --> Language Class Initialized
ERROR - 2018-05-22 03:04:06 --> 404 Page Not Found: /index
INFO - 2018-05-22 03:04:07 --> Config Class Initialized
INFO - 2018-05-22 03:04:07 --> Hooks Class Initialized
DEBUG - 2018-05-22 03:04:07 --> UTF-8 Support Enabled
INFO - 2018-05-22 03:04:07 --> Utf8 Class Initialized
INFO - 2018-05-22 03:04:07 --> URI Class Initialized
INFO - 2018-05-22 03:04:07 --> Router Class Initialized
INFO - 2018-05-22 03:04:08 --> Output Class Initialized
INFO - 2018-05-22 03:04:08 --> Security Class Initialized
DEBUG - 2018-05-22 03:04:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 03:04:08 --> Input Class Initialized
INFO - 2018-05-22 03:04:08 --> Language Class Initialized
ERROR - 2018-05-22 03:04:08 --> 404 Page Not Found: /index
INFO - 2018-05-22 03:04:08 --> Config Class Initialized
INFO - 2018-05-22 03:04:08 --> Hooks Class Initialized
DEBUG - 2018-05-22 03:04:08 --> UTF-8 Support Enabled
INFO - 2018-05-22 03:04:08 --> Utf8 Class Initialized
INFO - 2018-05-22 03:04:08 --> URI Class Initialized
INFO - 2018-05-22 03:04:08 --> Router Class Initialized
INFO - 2018-05-22 03:04:08 --> Output Class Initialized
INFO - 2018-05-22 03:04:08 --> Security Class Initialized
DEBUG - 2018-05-22 03:04:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 03:04:08 --> Input Class Initialized
INFO - 2018-05-22 03:04:08 --> Language Class Initialized
ERROR - 2018-05-22 03:04:08 --> 404 Page Not Found: /index
INFO - 2018-05-22 03:04:08 --> Config Class Initialized
INFO - 2018-05-22 03:04:08 --> Hooks Class Initialized
DEBUG - 2018-05-22 03:04:08 --> UTF-8 Support Enabled
INFO - 2018-05-22 03:04:08 --> Utf8 Class Initialized
INFO - 2018-05-22 03:04:08 --> URI Class Initialized
INFO - 2018-05-22 03:04:08 --> Router Class Initialized
INFO - 2018-05-22 03:04:08 --> Output Class Initialized
INFO - 2018-05-22 03:04:08 --> Security Class Initialized
DEBUG - 2018-05-22 03:04:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 03:04:08 --> Input Class Initialized
INFO - 2018-05-22 03:04:08 --> Language Class Initialized
ERROR - 2018-05-22 03:04:08 --> 404 Page Not Found: /index
INFO - 2018-05-22 03:04:11 --> Config Class Initialized
INFO - 2018-05-22 03:04:11 --> Hooks Class Initialized
DEBUG - 2018-05-22 03:04:11 --> UTF-8 Support Enabled
INFO - 2018-05-22 03:04:11 --> Utf8 Class Initialized
INFO - 2018-05-22 03:04:11 --> URI Class Initialized
INFO - 2018-05-22 03:04:11 --> Router Class Initialized
INFO - 2018-05-22 03:04:11 --> Output Class Initialized
INFO - 2018-05-22 03:04:11 --> Security Class Initialized
DEBUG - 2018-05-22 03:04:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 03:04:11 --> Input Class Initialized
INFO - 2018-05-22 03:04:11 --> Language Class Initialized
INFO - 2018-05-22 03:04:11 --> Language Class Initialized
INFO - 2018-05-22 03:04:11 --> Config Class Initialized
INFO - 2018-05-22 03:04:11 --> Loader Class Initialized
DEBUG - 2018-05-22 03:04:11 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 03:04:11 --> Helper loaded: url_helper
INFO - 2018-05-22 03:04:11 --> Helper loaded: form_helper
INFO - 2018-05-22 03:04:11 --> Helper loaded: date_helper
INFO - 2018-05-22 03:04:11 --> Helper loaded: util_helper
INFO - 2018-05-22 03:04:11 --> Helper loaded: text_helper
INFO - 2018-05-22 03:04:11 --> Helper loaded: string_helper
INFO - 2018-05-22 03:04:11 --> Database Driver Class Initialized
DEBUG - 2018-05-22 03:04:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 03:04:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 03:04:11 --> Email Class Initialized
INFO - 2018-05-22 03:04:11 --> Controller Class Initialized
DEBUG - 2018-05-22 03:04:11 --> Profile MX_Controller Initialized
DEBUG - 2018-05-22 03:04:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 03:04:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 03:04:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-22 03:04:11 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 03:04:11 --> Login MX_Controller Initialized
INFO - 2018-05-22 03:04:11 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 03:04:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-22 03:04:14 --> Config Class Initialized
INFO - 2018-05-22 03:04:14 --> Hooks Class Initialized
DEBUG - 2018-05-22 03:04:14 --> UTF-8 Support Enabled
INFO - 2018-05-22 03:04:14 --> Utf8 Class Initialized
INFO - 2018-05-22 03:04:14 --> URI Class Initialized
INFO - 2018-05-22 03:04:14 --> Router Class Initialized
INFO - 2018-05-22 03:04:14 --> Output Class Initialized
INFO - 2018-05-22 03:04:14 --> Security Class Initialized
DEBUG - 2018-05-22 03:04:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 03:04:14 --> Input Class Initialized
INFO - 2018-05-22 03:04:14 --> Language Class Initialized
INFO - 2018-05-22 03:04:14 --> Language Class Initialized
INFO - 2018-05-22 03:04:14 --> Config Class Initialized
INFO - 2018-05-22 03:04:14 --> Loader Class Initialized
DEBUG - 2018-05-22 03:04:14 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 03:04:14 --> Helper loaded: url_helper
INFO - 2018-05-22 03:04:14 --> Helper loaded: form_helper
INFO - 2018-05-22 03:04:14 --> Helper loaded: date_helper
INFO - 2018-05-22 03:04:14 --> Helper loaded: util_helper
INFO - 2018-05-22 03:04:14 --> Helper loaded: text_helper
INFO - 2018-05-22 03:04:14 --> Helper loaded: string_helper
INFO - 2018-05-22 03:04:14 --> Database Driver Class Initialized
DEBUG - 2018-05-22 03:04:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 03:04:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 03:04:14 --> Email Class Initialized
INFO - 2018-05-22 03:04:14 --> Controller Class Initialized
DEBUG - 2018-05-22 03:04:14 --> Profile MX_Controller Initialized
DEBUG - 2018-05-22 03:04:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 03:04:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 03:04:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-22 03:04:14 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 03:04:14 --> Login MX_Controller Initialized
INFO - 2018-05-22 03:04:14 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 03:04:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-22 03:04:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-22 03:04:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-22 03:04:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-22 03:04:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-05-22 03:04:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-22 03:04:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-22 03:04:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/profile.php
INFO - 2018-05-22 03:04:15 --> Final output sent to browser
DEBUG - 2018-05-22 03:04:15 --> Total execution time: 0.6897
INFO - 2018-05-22 03:04:15 --> Config Class Initialized
INFO - 2018-05-22 03:04:15 --> Hooks Class Initialized
DEBUG - 2018-05-22 03:04:15 --> UTF-8 Support Enabled
INFO - 2018-05-22 03:04:15 --> Utf8 Class Initialized
INFO - 2018-05-22 03:04:15 --> URI Class Initialized
INFO - 2018-05-22 03:04:15 --> Router Class Initialized
INFO - 2018-05-22 03:04:15 --> Output Class Initialized
INFO - 2018-05-22 03:04:15 --> Security Class Initialized
DEBUG - 2018-05-22 03:04:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 03:04:15 --> Input Class Initialized
INFO - 2018-05-22 03:04:15 --> Language Class Initialized
ERROR - 2018-05-22 03:04:15 --> 404 Page Not Found: /index
INFO - 2018-05-22 03:04:16 --> Config Class Initialized
INFO - 2018-05-22 03:04:16 --> Hooks Class Initialized
DEBUG - 2018-05-22 03:04:16 --> UTF-8 Support Enabled
INFO - 2018-05-22 03:04:16 --> Utf8 Class Initialized
INFO - 2018-05-22 03:04:16 --> URI Class Initialized
INFO - 2018-05-22 03:04:16 --> Router Class Initialized
INFO - 2018-05-22 03:04:16 --> Output Class Initialized
INFO - 2018-05-22 03:04:16 --> Security Class Initialized
DEBUG - 2018-05-22 03:04:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 03:04:16 --> Input Class Initialized
INFO - 2018-05-22 03:04:16 --> Language Class Initialized
ERROR - 2018-05-22 03:04:16 --> 404 Page Not Found: /index
INFO - 2018-05-22 03:04:16 --> Config Class Initialized
INFO - 2018-05-22 03:04:16 --> Hooks Class Initialized
DEBUG - 2018-05-22 03:04:16 --> UTF-8 Support Enabled
INFO - 2018-05-22 03:04:16 --> Utf8 Class Initialized
INFO - 2018-05-22 03:04:16 --> URI Class Initialized
INFO - 2018-05-22 03:04:16 --> Router Class Initialized
INFO - 2018-05-22 03:04:16 --> Output Class Initialized
INFO - 2018-05-22 03:04:16 --> Security Class Initialized
DEBUG - 2018-05-22 03:04:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 03:04:17 --> Input Class Initialized
INFO - 2018-05-22 03:04:17 --> Language Class Initialized
ERROR - 2018-05-22 03:04:17 --> 404 Page Not Found: /index
INFO - 2018-05-22 03:04:17 --> Config Class Initialized
INFO - 2018-05-22 03:04:17 --> Hooks Class Initialized
DEBUG - 2018-05-22 03:04:17 --> UTF-8 Support Enabled
INFO - 2018-05-22 03:04:17 --> Utf8 Class Initialized
INFO - 2018-05-22 03:04:17 --> URI Class Initialized
INFO - 2018-05-22 03:04:17 --> Router Class Initialized
INFO - 2018-05-22 03:04:17 --> Output Class Initialized
INFO - 2018-05-22 03:04:17 --> Security Class Initialized
DEBUG - 2018-05-22 03:04:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 03:04:17 --> Input Class Initialized
INFO - 2018-05-22 03:04:17 --> Language Class Initialized
ERROR - 2018-05-22 03:04:17 --> 404 Page Not Found: /index
INFO - 2018-05-22 03:04:20 --> Config Class Initialized
INFO - 2018-05-22 03:04:20 --> Hooks Class Initialized
DEBUG - 2018-05-22 03:04:20 --> UTF-8 Support Enabled
INFO - 2018-05-22 03:04:20 --> Utf8 Class Initialized
INFO - 2018-05-22 03:04:20 --> URI Class Initialized
INFO - 2018-05-22 03:04:21 --> Router Class Initialized
INFO - 2018-05-22 03:04:21 --> Output Class Initialized
INFO - 2018-05-22 03:04:21 --> Security Class Initialized
DEBUG - 2018-05-22 03:04:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 03:04:21 --> Input Class Initialized
INFO - 2018-05-22 03:04:21 --> Language Class Initialized
INFO - 2018-05-22 03:04:21 --> Language Class Initialized
INFO - 2018-05-22 03:04:21 --> Config Class Initialized
INFO - 2018-05-22 03:04:21 --> Loader Class Initialized
DEBUG - 2018-05-22 03:04:21 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 03:04:21 --> Helper loaded: url_helper
INFO - 2018-05-22 03:04:21 --> Helper loaded: form_helper
INFO - 2018-05-22 03:04:21 --> Helper loaded: date_helper
INFO - 2018-05-22 03:04:21 --> Helper loaded: util_helper
INFO - 2018-05-22 03:04:21 --> Helper loaded: text_helper
INFO - 2018-05-22 03:04:21 --> Helper loaded: string_helper
INFO - 2018-05-22 03:04:21 --> Database Driver Class Initialized
DEBUG - 2018-05-22 03:04:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 03:04:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 03:04:21 --> Email Class Initialized
INFO - 2018-05-22 03:04:21 --> Controller Class Initialized
DEBUG - 2018-05-22 03:04:21 --> Profile MX_Controller Initialized
DEBUG - 2018-05-22 03:04:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 03:04:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 03:04:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-22 03:04:21 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 03:04:21 --> Login MX_Controller Initialized
INFO - 2018-05-22 03:04:21 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 03:04:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-22 03:04:43 --> Config Class Initialized
INFO - 2018-05-22 03:04:43 --> Hooks Class Initialized
DEBUG - 2018-05-22 03:04:43 --> UTF-8 Support Enabled
INFO - 2018-05-22 03:04:43 --> Utf8 Class Initialized
INFO - 2018-05-22 03:04:43 --> URI Class Initialized
INFO - 2018-05-22 03:04:43 --> Router Class Initialized
INFO - 2018-05-22 03:04:43 --> Output Class Initialized
INFO - 2018-05-22 03:04:43 --> Security Class Initialized
DEBUG - 2018-05-22 03:04:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 03:04:43 --> Input Class Initialized
INFO - 2018-05-22 03:04:43 --> Language Class Initialized
INFO - 2018-05-22 03:04:43 --> Language Class Initialized
INFO - 2018-05-22 03:04:43 --> Config Class Initialized
INFO - 2018-05-22 03:04:43 --> Loader Class Initialized
DEBUG - 2018-05-22 03:04:43 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 03:04:43 --> Helper loaded: url_helper
INFO - 2018-05-22 03:04:43 --> Helper loaded: form_helper
INFO - 2018-05-22 03:04:43 --> Helper loaded: date_helper
INFO - 2018-05-22 03:04:43 --> Helper loaded: util_helper
INFO - 2018-05-22 03:04:43 --> Helper loaded: text_helper
INFO - 2018-05-22 03:04:43 --> Helper loaded: string_helper
INFO - 2018-05-22 03:04:43 --> Database Driver Class Initialized
DEBUG - 2018-05-22 03:04:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 03:04:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 03:04:43 --> Email Class Initialized
INFO - 2018-05-22 03:04:44 --> Controller Class Initialized
DEBUG - 2018-05-22 03:04:44 --> Profile MX_Controller Initialized
DEBUG - 2018-05-22 03:04:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 03:04:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 03:04:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-22 03:04:44 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 03:04:44 --> Login MX_Controller Initialized
INFO - 2018-05-22 03:04:44 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 03:04:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-22 03:05:23 --> Config Class Initialized
INFO - 2018-05-22 03:05:23 --> Hooks Class Initialized
DEBUG - 2018-05-22 03:05:23 --> UTF-8 Support Enabled
INFO - 2018-05-22 03:05:23 --> Utf8 Class Initialized
INFO - 2018-05-22 03:05:23 --> URI Class Initialized
INFO - 2018-05-22 03:05:23 --> Router Class Initialized
INFO - 2018-05-22 03:05:23 --> Output Class Initialized
INFO - 2018-05-22 03:05:23 --> Security Class Initialized
DEBUG - 2018-05-22 03:05:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 03:05:23 --> Input Class Initialized
INFO - 2018-05-22 03:05:23 --> Language Class Initialized
INFO - 2018-05-22 03:05:23 --> Language Class Initialized
INFO - 2018-05-22 03:05:23 --> Config Class Initialized
INFO - 2018-05-22 03:05:23 --> Loader Class Initialized
DEBUG - 2018-05-22 03:05:23 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 03:05:23 --> Helper loaded: url_helper
INFO - 2018-05-22 03:05:23 --> Helper loaded: form_helper
INFO - 2018-05-22 03:05:23 --> Helper loaded: date_helper
INFO - 2018-05-22 03:05:23 --> Helper loaded: util_helper
INFO - 2018-05-22 03:05:23 --> Helper loaded: text_helper
INFO - 2018-05-22 03:05:23 --> Helper loaded: string_helper
INFO - 2018-05-22 03:05:24 --> Database Driver Class Initialized
DEBUG - 2018-05-22 03:05:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 03:05:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 03:05:24 --> Email Class Initialized
INFO - 2018-05-22 03:05:24 --> Controller Class Initialized
DEBUG - 2018-05-22 03:05:24 --> Profile MX_Controller Initialized
DEBUG - 2018-05-22 03:05:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 03:05:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 03:05:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-22 03:05:24 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 03:05:24 --> Login MX_Controller Initialized
INFO - 2018-05-22 03:05:24 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 03:05:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-22 03:05:29 --> Config Class Initialized
INFO - 2018-05-22 03:05:29 --> Hooks Class Initialized
DEBUG - 2018-05-22 03:05:29 --> UTF-8 Support Enabled
INFO - 2018-05-22 03:05:29 --> Utf8 Class Initialized
INFO - 2018-05-22 03:05:29 --> URI Class Initialized
INFO - 2018-05-22 03:05:29 --> Router Class Initialized
INFO - 2018-05-22 03:05:29 --> Output Class Initialized
INFO - 2018-05-22 03:05:29 --> Security Class Initialized
DEBUG - 2018-05-22 03:05:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 03:05:29 --> Input Class Initialized
INFO - 2018-05-22 03:05:29 --> Language Class Initialized
INFO - 2018-05-22 03:05:29 --> Language Class Initialized
INFO - 2018-05-22 03:05:29 --> Config Class Initialized
INFO - 2018-05-22 03:05:29 --> Loader Class Initialized
DEBUG - 2018-05-22 03:05:29 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 03:05:29 --> Helper loaded: url_helper
INFO - 2018-05-22 03:05:29 --> Helper loaded: form_helper
INFO - 2018-05-22 03:05:29 --> Helper loaded: date_helper
INFO - 2018-05-22 03:05:29 --> Helper loaded: util_helper
INFO - 2018-05-22 03:05:29 --> Helper loaded: text_helper
INFO - 2018-05-22 03:05:29 --> Helper loaded: string_helper
INFO - 2018-05-22 03:05:29 --> Database Driver Class Initialized
DEBUG - 2018-05-22 03:05:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 03:05:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 03:05:29 --> Email Class Initialized
INFO - 2018-05-22 03:05:29 --> Controller Class Initialized
DEBUG - 2018-05-22 03:05:29 --> Profile MX_Controller Initialized
DEBUG - 2018-05-22 03:05:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 03:05:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 03:05:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-22 03:05:29 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 03:05:29 --> Login MX_Controller Initialized
INFO - 2018-05-22 03:05:29 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 03:05:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-22 03:05:31 --> Config Class Initialized
INFO - 2018-05-22 03:05:31 --> Hooks Class Initialized
DEBUG - 2018-05-22 03:05:31 --> UTF-8 Support Enabled
INFO - 2018-05-22 03:05:31 --> Utf8 Class Initialized
INFO - 2018-05-22 03:05:31 --> URI Class Initialized
INFO - 2018-05-22 03:05:31 --> Router Class Initialized
INFO - 2018-05-22 03:05:31 --> Output Class Initialized
INFO - 2018-05-22 03:05:31 --> Security Class Initialized
DEBUG - 2018-05-22 03:05:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 03:05:31 --> Input Class Initialized
INFO - 2018-05-22 03:05:31 --> Language Class Initialized
INFO - 2018-05-22 03:05:31 --> Language Class Initialized
INFO - 2018-05-22 03:05:31 --> Config Class Initialized
INFO - 2018-05-22 03:05:31 --> Loader Class Initialized
DEBUG - 2018-05-22 03:05:31 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 03:05:31 --> Helper loaded: url_helper
INFO - 2018-05-22 03:05:31 --> Helper loaded: form_helper
INFO - 2018-05-22 03:05:31 --> Helper loaded: date_helper
INFO - 2018-05-22 03:05:31 --> Helper loaded: util_helper
INFO - 2018-05-22 03:05:31 --> Helper loaded: text_helper
INFO - 2018-05-22 03:05:31 --> Helper loaded: string_helper
INFO - 2018-05-22 03:05:32 --> Database Driver Class Initialized
DEBUG - 2018-05-22 03:05:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 03:05:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 03:05:32 --> Email Class Initialized
INFO - 2018-05-22 03:05:32 --> Controller Class Initialized
DEBUG - 2018-05-22 03:05:32 --> Profile MX_Controller Initialized
DEBUG - 2018-05-22 03:05:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 03:05:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 03:05:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-22 03:05:32 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 03:05:32 --> Login MX_Controller Initialized
INFO - 2018-05-22 03:05:32 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 03:05:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-22 03:05:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-22 03:05:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-22 03:05:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-22 03:05:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-05-22 03:05:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-22 03:05:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-22 03:05:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/profile.php
INFO - 2018-05-22 03:05:32 --> Final output sent to browser
DEBUG - 2018-05-22 03:05:32 --> Total execution time: 0.9393
INFO - 2018-05-22 03:05:32 --> Config Class Initialized
INFO - 2018-05-22 03:05:32 --> Hooks Class Initialized
DEBUG - 2018-05-22 03:05:32 --> UTF-8 Support Enabled
INFO - 2018-05-22 03:05:32 --> Utf8 Class Initialized
INFO - 2018-05-22 03:05:32 --> URI Class Initialized
INFO - 2018-05-22 03:05:32 --> Router Class Initialized
INFO - 2018-05-22 03:05:32 --> Output Class Initialized
INFO - 2018-05-22 03:05:32 --> Security Class Initialized
DEBUG - 2018-05-22 03:05:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 03:05:32 --> Input Class Initialized
INFO - 2018-05-22 03:05:32 --> Language Class Initialized
ERROR - 2018-05-22 03:05:32 --> 404 Page Not Found: /index
INFO - 2018-05-22 03:05:33 --> Config Class Initialized
INFO - 2018-05-22 03:05:33 --> Hooks Class Initialized
DEBUG - 2018-05-22 03:05:33 --> UTF-8 Support Enabled
INFO - 2018-05-22 03:05:33 --> Utf8 Class Initialized
INFO - 2018-05-22 03:05:33 --> URI Class Initialized
INFO - 2018-05-22 03:05:33 --> Router Class Initialized
INFO - 2018-05-22 03:05:33 --> Output Class Initialized
INFO - 2018-05-22 03:05:33 --> Security Class Initialized
DEBUG - 2018-05-22 03:05:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 03:05:33 --> Input Class Initialized
INFO - 2018-05-22 03:05:33 --> Language Class Initialized
ERROR - 2018-05-22 03:05:33 --> 404 Page Not Found: /index
INFO - 2018-05-22 03:05:33 --> Config Class Initialized
INFO - 2018-05-22 03:05:33 --> Hooks Class Initialized
DEBUG - 2018-05-22 03:05:33 --> UTF-8 Support Enabled
INFO - 2018-05-22 03:05:33 --> Utf8 Class Initialized
INFO - 2018-05-22 03:05:34 --> URI Class Initialized
INFO - 2018-05-22 03:05:34 --> Router Class Initialized
INFO - 2018-05-22 03:05:34 --> Output Class Initialized
INFO - 2018-05-22 03:05:34 --> Security Class Initialized
DEBUG - 2018-05-22 03:05:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 03:05:34 --> Input Class Initialized
INFO - 2018-05-22 03:05:34 --> Language Class Initialized
ERROR - 2018-05-22 03:05:34 --> 404 Page Not Found: /index
INFO - 2018-05-22 03:05:34 --> Config Class Initialized
INFO - 2018-05-22 03:05:34 --> Hooks Class Initialized
DEBUG - 2018-05-22 03:05:34 --> UTF-8 Support Enabled
INFO - 2018-05-22 03:05:34 --> Utf8 Class Initialized
INFO - 2018-05-22 03:05:34 --> URI Class Initialized
INFO - 2018-05-22 03:05:34 --> Router Class Initialized
INFO - 2018-05-22 03:05:34 --> Output Class Initialized
INFO - 2018-05-22 03:05:34 --> Security Class Initialized
DEBUG - 2018-05-22 03:05:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 03:05:34 --> Input Class Initialized
INFO - 2018-05-22 03:05:34 --> Language Class Initialized
ERROR - 2018-05-22 03:05:34 --> 404 Page Not Found: /index
INFO - 2018-05-22 03:06:09 --> Config Class Initialized
INFO - 2018-05-22 03:06:09 --> Hooks Class Initialized
DEBUG - 2018-05-22 03:06:09 --> UTF-8 Support Enabled
INFO - 2018-05-22 03:06:09 --> Utf8 Class Initialized
INFO - 2018-05-22 03:06:09 --> URI Class Initialized
INFO - 2018-05-22 03:06:09 --> Router Class Initialized
INFO - 2018-05-22 03:06:09 --> Output Class Initialized
INFO - 2018-05-22 03:06:09 --> Security Class Initialized
DEBUG - 2018-05-22 03:06:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 03:06:09 --> Input Class Initialized
INFO - 2018-05-22 03:06:09 --> Language Class Initialized
INFO - 2018-05-22 03:06:09 --> Language Class Initialized
INFO - 2018-05-22 03:06:09 --> Config Class Initialized
INFO - 2018-05-22 03:06:09 --> Loader Class Initialized
DEBUG - 2018-05-22 03:06:09 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 03:06:09 --> Helper loaded: url_helper
INFO - 2018-05-22 03:06:09 --> Helper loaded: form_helper
INFO - 2018-05-22 03:06:09 --> Helper loaded: date_helper
INFO - 2018-05-22 03:06:09 --> Helper loaded: util_helper
INFO - 2018-05-22 03:06:09 --> Helper loaded: text_helper
INFO - 2018-05-22 03:06:09 --> Helper loaded: string_helper
INFO - 2018-05-22 03:06:09 --> Database Driver Class Initialized
DEBUG - 2018-05-22 03:06:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 03:06:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 03:06:09 --> Email Class Initialized
INFO - 2018-05-22 03:06:09 --> Controller Class Initialized
DEBUG - 2018-05-22 03:06:09 --> Profile MX_Controller Initialized
DEBUG - 2018-05-22 03:06:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 03:06:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 03:06:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-22 03:06:09 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 03:06:09 --> Login MX_Controller Initialized
INFO - 2018-05-22 03:06:09 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 03:06:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-22 03:06:09 --> Upload Class Initialized
ERROR - 2018-05-22 03:06:09 --> Severity: Warning --> unlink(E:\xampp\htdocs\consulting\assets/images/users/): Permission denied E:\xampp\htdocs\consulting\application\modules\home\controllers\Profile.php 98
INFO - 2018-05-22 03:06:28 --> Config Class Initialized
INFO - 2018-05-22 03:06:28 --> Hooks Class Initialized
DEBUG - 2018-05-22 03:06:28 --> UTF-8 Support Enabled
INFO - 2018-05-22 03:06:28 --> Utf8 Class Initialized
INFO - 2018-05-22 03:06:28 --> URI Class Initialized
INFO - 2018-05-22 03:06:28 --> Router Class Initialized
INFO - 2018-05-22 03:06:28 --> Output Class Initialized
INFO - 2018-05-22 03:06:28 --> Security Class Initialized
DEBUG - 2018-05-22 03:06:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 03:06:28 --> Input Class Initialized
INFO - 2018-05-22 03:06:28 --> Language Class Initialized
INFO - 2018-05-22 03:06:28 --> Language Class Initialized
INFO - 2018-05-22 03:06:28 --> Config Class Initialized
INFO - 2018-05-22 03:06:28 --> Loader Class Initialized
DEBUG - 2018-05-22 03:06:28 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 03:06:28 --> Helper loaded: url_helper
INFO - 2018-05-22 03:06:28 --> Helper loaded: form_helper
INFO - 2018-05-22 03:06:28 --> Helper loaded: date_helper
INFO - 2018-05-22 03:06:29 --> Helper loaded: util_helper
INFO - 2018-05-22 03:06:29 --> Helper loaded: text_helper
INFO - 2018-05-22 03:06:29 --> Helper loaded: string_helper
INFO - 2018-05-22 03:06:29 --> Database Driver Class Initialized
DEBUG - 2018-05-22 03:06:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 03:06:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 03:06:29 --> Email Class Initialized
INFO - 2018-05-22 03:06:29 --> Controller Class Initialized
DEBUG - 2018-05-22 03:06:29 --> Profile MX_Controller Initialized
DEBUG - 2018-05-22 03:06:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 03:06:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 03:06:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-22 03:06:29 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 03:06:29 --> Login MX_Controller Initialized
INFO - 2018-05-22 03:06:29 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 03:06:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-22 03:06:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-22 03:06:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-22 03:06:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-22 03:06:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-05-22 03:06:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-22 03:06:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-22 03:06:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/profile.php
INFO - 2018-05-22 03:06:29 --> Final output sent to browser
DEBUG - 2018-05-22 03:06:29 --> Total execution time: 0.7355
INFO - 2018-05-22 03:06:30 --> Config Class Initialized
INFO - 2018-05-22 03:06:30 --> Hooks Class Initialized
DEBUG - 2018-05-22 03:06:30 --> UTF-8 Support Enabled
INFO - 2018-05-22 03:06:30 --> Utf8 Class Initialized
INFO - 2018-05-22 03:06:30 --> URI Class Initialized
INFO - 2018-05-22 03:06:30 --> Router Class Initialized
INFO - 2018-05-22 03:06:30 --> Output Class Initialized
INFO - 2018-05-22 03:06:30 --> Security Class Initialized
DEBUG - 2018-05-22 03:06:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 03:06:30 --> Input Class Initialized
INFO - 2018-05-22 03:06:30 --> Language Class Initialized
ERROR - 2018-05-22 03:06:30 --> 404 Page Not Found: /index
INFO - 2018-05-22 03:06:30 --> Config Class Initialized
INFO - 2018-05-22 03:06:30 --> Hooks Class Initialized
DEBUG - 2018-05-22 03:06:30 --> UTF-8 Support Enabled
INFO - 2018-05-22 03:06:30 --> Utf8 Class Initialized
INFO - 2018-05-22 03:06:30 --> URI Class Initialized
INFO - 2018-05-22 03:06:30 --> Router Class Initialized
INFO - 2018-05-22 03:06:30 --> Output Class Initialized
INFO - 2018-05-22 03:06:31 --> Security Class Initialized
DEBUG - 2018-05-22 03:06:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 03:06:31 --> Input Class Initialized
INFO - 2018-05-22 03:06:31 --> Language Class Initialized
ERROR - 2018-05-22 03:06:31 --> 404 Page Not Found: /index
INFO - 2018-05-22 03:06:31 --> Config Class Initialized
INFO - 2018-05-22 03:06:31 --> Hooks Class Initialized
DEBUG - 2018-05-22 03:06:31 --> UTF-8 Support Enabled
INFO - 2018-05-22 03:06:31 --> Utf8 Class Initialized
INFO - 2018-05-22 03:06:31 --> URI Class Initialized
INFO - 2018-05-22 03:06:31 --> Router Class Initialized
INFO - 2018-05-22 03:06:31 --> Output Class Initialized
INFO - 2018-05-22 03:06:31 --> Security Class Initialized
DEBUG - 2018-05-22 03:06:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 03:06:31 --> Input Class Initialized
INFO - 2018-05-22 03:06:31 --> Language Class Initialized
ERROR - 2018-05-22 03:06:31 --> 404 Page Not Found: /index
INFO - 2018-05-22 03:06:53 --> Config Class Initialized
INFO - 2018-05-22 03:06:53 --> Hooks Class Initialized
DEBUG - 2018-05-22 03:06:54 --> UTF-8 Support Enabled
INFO - 2018-05-22 03:06:54 --> Utf8 Class Initialized
INFO - 2018-05-22 03:06:54 --> URI Class Initialized
INFO - 2018-05-22 03:06:54 --> Router Class Initialized
INFO - 2018-05-22 03:06:54 --> Output Class Initialized
INFO - 2018-05-22 03:06:54 --> Security Class Initialized
DEBUG - 2018-05-22 03:06:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 03:06:54 --> Input Class Initialized
INFO - 2018-05-22 03:06:54 --> Language Class Initialized
INFO - 2018-05-22 03:06:54 --> Language Class Initialized
INFO - 2018-05-22 03:06:54 --> Config Class Initialized
INFO - 2018-05-22 03:06:54 --> Loader Class Initialized
DEBUG - 2018-05-22 03:06:54 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 03:06:54 --> Helper loaded: url_helper
INFO - 2018-05-22 03:06:54 --> Helper loaded: form_helper
INFO - 2018-05-22 03:06:54 --> Helper loaded: date_helper
INFO - 2018-05-22 03:06:54 --> Helper loaded: util_helper
INFO - 2018-05-22 03:06:54 --> Helper loaded: text_helper
INFO - 2018-05-22 03:06:54 --> Helper loaded: string_helper
INFO - 2018-05-22 03:06:54 --> Database Driver Class Initialized
DEBUG - 2018-05-22 03:06:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 03:06:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 03:06:54 --> Email Class Initialized
INFO - 2018-05-22 03:06:54 --> Controller Class Initialized
DEBUG - 2018-05-22 03:06:54 --> Profile MX_Controller Initialized
DEBUG - 2018-05-22 03:06:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 03:06:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 03:06:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-22 03:06:54 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 03:06:54 --> Login MX_Controller Initialized
INFO - 2018-05-22 03:06:54 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 03:06:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-22 03:08:17 --> Config Class Initialized
INFO - 2018-05-22 03:08:17 --> Hooks Class Initialized
DEBUG - 2018-05-22 03:08:17 --> UTF-8 Support Enabled
INFO - 2018-05-22 03:08:17 --> Utf8 Class Initialized
INFO - 2018-05-22 03:08:17 --> URI Class Initialized
INFO - 2018-05-22 03:08:17 --> Router Class Initialized
INFO - 2018-05-22 03:08:17 --> Output Class Initialized
INFO - 2018-05-22 03:08:17 --> Security Class Initialized
DEBUG - 2018-05-22 03:08:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 03:08:17 --> Input Class Initialized
INFO - 2018-05-22 03:08:17 --> Language Class Initialized
INFO - 2018-05-22 03:08:17 --> Language Class Initialized
INFO - 2018-05-22 03:08:17 --> Config Class Initialized
INFO - 2018-05-22 03:08:17 --> Loader Class Initialized
DEBUG - 2018-05-22 03:08:17 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 03:08:17 --> Helper loaded: url_helper
INFO - 2018-05-22 03:08:17 --> Helper loaded: form_helper
INFO - 2018-05-22 03:08:17 --> Helper loaded: date_helper
INFO - 2018-05-22 03:08:17 --> Helper loaded: util_helper
INFO - 2018-05-22 03:08:17 --> Helper loaded: text_helper
INFO - 2018-05-22 03:08:17 --> Helper loaded: string_helper
INFO - 2018-05-22 03:08:17 --> Database Driver Class Initialized
DEBUG - 2018-05-22 03:08:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 03:08:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 03:08:17 --> Email Class Initialized
INFO - 2018-05-22 03:08:17 --> Controller Class Initialized
DEBUG - 2018-05-22 03:08:17 --> Profile MX_Controller Initialized
DEBUG - 2018-05-22 03:08:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 03:08:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 03:08:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-22 03:08:18 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 03:08:18 --> Login MX_Controller Initialized
INFO - 2018-05-22 03:08:18 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 03:08:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-22 03:10:25 --> Config Class Initialized
INFO - 2018-05-22 03:10:25 --> Hooks Class Initialized
DEBUG - 2018-05-22 03:10:25 --> UTF-8 Support Enabled
INFO - 2018-05-22 03:10:25 --> Utf8 Class Initialized
INFO - 2018-05-22 03:10:25 --> URI Class Initialized
INFO - 2018-05-22 03:10:25 --> Router Class Initialized
INFO - 2018-05-22 03:10:25 --> Output Class Initialized
INFO - 2018-05-22 03:10:25 --> Security Class Initialized
DEBUG - 2018-05-22 03:10:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 03:10:25 --> Input Class Initialized
INFO - 2018-05-22 03:10:25 --> Language Class Initialized
INFO - 2018-05-22 03:10:25 --> Language Class Initialized
INFO - 2018-05-22 03:10:25 --> Config Class Initialized
INFO - 2018-05-22 03:10:25 --> Loader Class Initialized
DEBUG - 2018-05-22 03:10:25 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 03:10:25 --> Helper loaded: url_helper
INFO - 2018-05-22 03:10:25 --> Helper loaded: form_helper
INFO - 2018-05-22 03:10:25 --> Helper loaded: date_helper
INFO - 2018-05-22 03:10:25 --> Helper loaded: util_helper
INFO - 2018-05-22 03:10:25 --> Helper loaded: text_helper
INFO - 2018-05-22 03:10:25 --> Helper loaded: string_helper
INFO - 2018-05-22 03:10:25 --> Database Driver Class Initialized
DEBUG - 2018-05-22 03:10:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 03:10:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 03:10:25 --> Email Class Initialized
INFO - 2018-05-22 03:10:25 --> Controller Class Initialized
DEBUG - 2018-05-22 03:10:25 --> Profile MX_Controller Initialized
DEBUG - 2018-05-22 03:10:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 03:10:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 03:10:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-22 03:10:25 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 03:10:25 --> Login MX_Controller Initialized
INFO - 2018-05-22 03:10:25 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 03:10:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-22 03:10:29 --> Config Class Initialized
INFO - 2018-05-22 03:10:29 --> Hooks Class Initialized
DEBUG - 2018-05-22 03:10:29 --> UTF-8 Support Enabled
INFO - 2018-05-22 03:10:29 --> Utf8 Class Initialized
INFO - 2018-05-22 03:10:29 --> URI Class Initialized
INFO - 2018-05-22 03:10:29 --> Router Class Initialized
INFO - 2018-05-22 03:10:29 --> Output Class Initialized
INFO - 2018-05-22 03:10:29 --> Security Class Initialized
DEBUG - 2018-05-22 03:10:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 03:10:29 --> Input Class Initialized
INFO - 2018-05-22 03:10:29 --> Language Class Initialized
INFO - 2018-05-22 03:10:29 --> Language Class Initialized
INFO - 2018-05-22 03:10:29 --> Config Class Initialized
INFO - 2018-05-22 03:10:29 --> Loader Class Initialized
DEBUG - 2018-05-22 03:10:29 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 03:10:29 --> Helper loaded: url_helper
INFO - 2018-05-22 03:10:29 --> Helper loaded: form_helper
INFO - 2018-05-22 03:10:29 --> Helper loaded: date_helper
INFO - 2018-05-22 03:10:29 --> Helper loaded: util_helper
INFO - 2018-05-22 03:10:29 --> Helper loaded: text_helper
INFO - 2018-05-22 03:10:29 --> Helper loaded: string_helper
INFO - 2018-05-22 03:10:29 --> Database Driver Class Initialized
DEBUG - 2018-05-22 03:10:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 03:10:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 03:10:29 --> Email Class Initialized
INFO - 2018-05-22 03:10:29 --> Controller Class Initialized
DEBUG - 2018-05-22 03:10:29 --> Profile MX_Controller Initialized
DEBUG - 2018-05-22 03:10:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 03:10:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 03:10:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-22 03:10:29 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 03:10:29 --> Login MX_Controller Initialized
INFO - 2018-05-22 03:10:29 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 03:10:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-22 03:10:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-22 03:10:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-22 03:10:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-22 03:10:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-05-22 03:10:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-22 03:10:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-22 03:10:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/profile.php
INFO - 2018-05-22 03:10:30 --> Final output sent to browser
DEBUG - 2018-05-22 03:10:30 --> Total execution time: 0.7554
INFO - 2018-05-22 03:10:31 --> Config Class Initialized
INFO - 2018-05-22 03:10:31 --> Hooks Class Initialized
DEBUG - 2018-05-22 03:10:31 --> UTF-8 Support Enabled
INFO - 2018-05-22 03:10:31 --> Utf8 Class Initialized
INFO - 2018-05-22 03:10:32 --> URI Class Initialized
INFO - 2018-05-22 03:10:32 --> Router Class Initialized
INFO - 2018-05-22 03:10:32 --> Output Class Initialized
INFO - 2018-05-22 03:10:32 --> Security Class Initialized
DEBUG - 2018-05-22 03:10:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 03:10:32 --> Input Class Initialized
INFO - 2018-05-22 03:10:32 --> Language Class Initialized
ERROR - 2018-05-22 03:10:32 --> 404 Page Not Found: /index
INFO - 2018-05-22 03:10:32 --> Config Class Initialized
INFO - 2018-05-22 03:10:32 --> Hooks Class Initialized
DEBUG - 2018-05-22 03:10:32 --> UTF-8 Support Enabled
INFO - 2018-05-22 03:10:32 --> Utf8 Class Initialized
INFO - 2018-05-22 03:10:32 --> URI Class Initialized
INFO - 2018-05-22 03:10:32 --> Router Class Initialized
INFO - 2018-05-22 03:10:32 --> Output Class Initialized
INFO - 2018-05-22 03:10:32 --> Security Class Initialized
DEBUG - 2018-05-22 03:10:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 03:10:32 --> Input Class Initialized
INFO - 2018-05-22 03:10:32 --> Language Class Initialized
ERROR - 2018-05-22 03:10:32 --> 404 Page Not Found: /index
INFO - 2018-05-22 03:10:32 --> Config Class Initialized
INFO - 2018-05-22 03:10:32 --> Hooks Class Initialized
DEBUG - 2018-05-22 03:10:32 --> UTF-8 Support Enabled
INFO - 2018-05-22 03:10:32 --> Utf8 Class Initialized
INFO - 2018-05-22 03:10:32 --> URI Class Initialized
INFO - 2018-05-22 03:10:32 --> Router Class Initialized
INFO - 2018-05-22 03:10:32 --> Output Class Initialized
INFO - 2018-05-22 03:10:32 --> Security Class Initialized
DEBUG - 2018-05-22 03:10:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 03:10:32 --> Input Class Initialized
INFO - 2018-05-22 03:10:32 --> Language Class Initialized
ERROR - 2018-05-22 03:10:32 --> 404 Page Not Found: /index
INFO - 2018-05-22 03:10:37 --> Config Class Initialized
INFO - 2018-05-22 03:10:37 --> Hooks Class Initialized
DEBUG - 2018-05-22 03:10:37 --> UTF-8 Support Enabled
INFO - 2018-05-22 03:10:37 --> Utf8 Class Initialized
INFO - 2018-05-22 03:10:37 --> URI Class Initialized
INFO - 2018-05-22 03:10:37 --> Router Class Initialized
INFO - 2018-05-22 03:10:37 --> Output Class Initialized
INFO - 2018-05-22 03:10:37 --> Security Class Initialized
DEBUG - 2018-05-22 03:10:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 03:10:37 --> Input Class Initialized
INFO - 2018-05-22 03:10:37 --> Language Class Initialized
INFO - 2018-05-22 03:10:37 --> Language Class Initialized
INFO - 2018-05-22 03:10:37 --> Config Class Initialized
INFO - 2018-05-22 03:10:37 --> Loader Class Initialized
DEBUG - 2018-05-22 03:10:37 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 03:10:37 --> Helper loaded: url_helper
INFO - 2018-05-22 03:10:37 --> Helper loaded: form_helper
INFO - 2018-05-22 03:10:37 --> Helper loaded: date_helper
INFO - 2018-05-22 03:10:37 --> Helper loaded: util_helper
INFO - 2018-05-22 03:10:37 --> Helper loaded: text_helper
INFO - 2018-05-22 03:10:37 --> Helper loaded: string_helper
INFO - 2018-05-22 03:10:37 --> Database Driver Class Initialized
DEBUG - 2018-05-22 03:10:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 03:10:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 03:10:37 --> Email Class Initialized
INFO - 2018-05-22 03:10:37 --> Controller Class Initialized
DEBUG - 2018-05-22 03:10:37 --> Profile MX_Controller Initialized
DEBUG - 2018-05-22 03:10:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 03:10:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 03:10:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-22 03:10:37 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 03:10:37 --> Login MX_Controller Initialized
INFO - 2018-05-22 03:10:37 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 03:10:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-22 03:10:40 --> Config Class Initialized
INFO - 2018-05-22 03:10:40 --> Hooks Class Initialized
DEBUG - 2018-05-22 03:10:40 --> UTF-8 Support Enabled
INFO - 2018-05-22 03:10:40 --> Utf8 Class Initialized
INFO - 2018-05-22 03:10:41 --> URI Class Initialized
INFO - 2018-05-22 03:10:41 --> Router Class Initialized
INFO - 2018-05-22 03:10:41 --> Output Class Initialized
INFO - 2018-05-22 03:10:41 --> Security Class Initialized
DEBUG - 2018-05-22 03:10:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 03:10:41 --> Input Class Initialized
INFO - 2018-05-22 03:10:41 --> Language Class Initialized
INFO - 2018-05-22 03:10:41 --> Language Class Initialized
INFO - 2018-05-22 03:10:41 --> Config Class Initialized
INFO - 2018-05-22 03:10:41 --> Loader Class Initialized
DEBUG - 2018-05-22 03:10:41 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 03:10:41 --> Helper loaded: url_helper
INFO - 2018-05-22 03:10:41 --> Helper loaded: form_helper
INFO - 2018-05-22 03:10:41 --> Helper loaded: date_helper
INFO - 2018-05-22 03:10:41 --> Helper loaded: util_helper
INFO - 2018-05-22 03:10:41 --> Helper loaded: text_helper
INFO - 2018-05-22 03:10:41 --> Helper loaded: string_helper
INFO - 2018-05-22 03:10:41 --> Database Driver Class Initialized
DEBUG - 2018-05-22 03:10:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 03:10:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 03:10:41 --> Email Class Initialized
INFO - 2018-05-22 03:10:41 --> Controller Class Initialized
DEBUG - 2018-05-22 03:10:41 --> Profile MX_Controller Initialized
DEBUG - 2018-05-22 03:10:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 03:10:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 03:10:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-22 03:10:41 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 03:10:41 --> Login MX_Controller Initialized
INFO - 2018-05-22 03:10:41 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 03:10:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-22 03:10:43 --> Config Class Initialized
INFO - 2018-05-22 03:10:43 --> Hooks Class Initialized
DEBUG - 2018-05-22 03:10:43 --> UTF-8 Support Enabled
INFO - 2018-05-22 03:10:44 --> Utf8 Class Initialized
INFO - 2018-05-22 03:10:44 --> URI Class Initialized
INFO - 2018-05-22 03:10:44 --> Router Class Initialized
INFO - 2018-05-22 03:10:44 --> Output Class Initialized
INFO - 2018-05-22 03:10:44 --> Security Class Initialized
DEBUG - 2018-05-22 03:10:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 03:10:44 --> Input Class Initialized
INFO - 2018-05-22 03:10:44 --> Language Class Initialized
INFO - 2018-05-22 03:10:44 --> Language Class Initialized
INFO - 2018-05-22 03:10:44 --> Config Class Initialized
INFO - 2018-05-22 03:10:44 --> Loader Class Initialized
DEBUG - 2018-05-22 03:10:44 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 03:10:44 --> Helper loaded: url_helper
INFO - 2018-05-22 03:10:44 --> Helper loaded: form_helper
INFO - 2018-05-22 03:10:44 --> Helper loaded: date_helper
INFO - 2018-05-22 03:10:44 --> Helper loaded: util_helper
INFO - 2018-05-22 03:10:44 --> Helper loaded: text_helper
INFO - 2018-05-22 03:10:44 --> Helper loaded: string_helper
INFO - 2018-05-22 03:10:44 --> Database Driver Class Initialized
DEBUG - 2018-05-22 03:10:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 03:10:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 03:10:44 --> Email Class Initialized
INFO - 2018-05-22 03:10:44 --> Controller Class Initialized
DEBUG - 2018-05-22 03:10:44 --> Profile MX_Controller Initialized
DEBUG - 2018-05-22 03:10:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 03:10:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 03:10:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-22 03:10:44 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 03:10:44 --> Login MX_Controller Initialized
INFO - 2018-05-22 03:10:44 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 03:10:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-22 03:10:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-22 03:10:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-22 03:10:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-22 03:10:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-05-22 03:10:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-22 03:10:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-22 03:10:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/profile.php
INFO - 2018-05-22 03:10:44 --> Final output sent to browser
DEBUG - 2018-05-22 03:10:44 --> Total execution time: 0.7136
INFO - 2018-05-22 03:10:45 --> Config Class Initialized
INFO - 2018-05-22 03:10:45 --> Hooks Class Initialized
DEBUG - 2018-05-22 03:10:45 --> UTF-8 Support Enabled
INFO - 2018-05-22 03:10:45 --> Utf8 Class Initialized
INFO - 2018-05-22 03:10:45 --> URI Class Initialized
INFO - 2018-05-22 03:10:45 --> Router Class Initialized
INFO - 2018-05-22 03:10:45 --> Output Class Initialized
INFO - 2018-05-22 03:10:45 --> Security Class Initialized
DEBUG - 2018-05-22 03:10:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 03:10:45 --> Input Class Initialized
INFO - 2018-05-22 03:10:45 --> Language Class Initialized
ERROR - 2018-05-22 03:10:45 --> 404 Page Not Found: /index
INFO - 2018-05-22 03:10:45 --> Config Class Initialized
INFO - 2018-05-22 03:10:45 --> Hooks Class Initialized
DEBUG - 2018-05-22 03:10:45 --> UTF-8 Support Enabled
INFO - 2018-05-22 03:10:45 --> Utf8 Class Initialized
INFO - 2018-05-22 03:10:45 --> URI Class Initialized
INFO - 2018-05-22 03:10:45 --> Router Class Initialized
INFO - 2018-05-22 03:10:46 --> Output Class Initialized
INFO - 2018-05-22 03:10:46 --> Security Class Initialized
DEBUG - 2018-05-22 03:10:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 03:10:46 --> Input Class Initialized
INFO - 2018-05-22 03:10:46 --> Language Class Initialized
ERROR - 2018-05-22 03:10:46 --> 404 Page Not Found: /index
INFO - 2018-05-22 03:10:46 --> Config Class Initialized
INFO - 2018-05-22 03:10:46 --> Hooks Class Initialized
DEBUG - 2018-05-22 03:10:46 --> UTF-8 Support Enabled
INFO - 2018-05-22 03:10:46 --> Utf8 Class Initialized
INFO - 2018-05-22 03:10:46 --> URI Class Initialized
INFO - 2018-05-22 03:10:46 --> Router Class Initialized
INFO - 2018-05-22 03:10:46 --> Output Class Initialized
INFO - 2018-05-22 03:10:46 --> Security Class Initialized
DEBUG - 2018-05-22 03:10:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 03:10:46 --> Input Class Initialized
INFO - 2018-05-22 03:10:46 --> Language Class Initialized
ERROR - 2018-05-22 03:10:46 --> 404 Page Not Found: /index
INFO - 2018-05-22 03:10:48 --> Config Class Initialized
INFO - 2018-05-22 03:10:48 --> Hooks Class Initialized
DEBUG - 2018-05-22 03:10:48 --> UTF-8 Support Enabled
INFO - 2018-05-22 03:10:48 --> Utf8 Class Initialized
INFO - 2018-05-22 03:10:48 --> URI Class Initialized
INFO - 2018-05-22 03:10:48 --> Router Class Initialized
INFO - 2018-05-22 03:10:48 --> Output Class Initialized
INFO - 2018-05-22 03:10:48 --> Security Class Initialized
DEBUG - 2018-05-22 03:10:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 03:10:48 --> Input Class Initialized
INFO - 2018-05-22 03:10:48 --> Language Class Initialized
INFO - 2018-05-22 03:10:48 --> Language Class Initialized
INFO - 2018-05-22 03:10:48 --> Config Class Initialized
INFO - 2018-05-22 03:10:48 --> Loader Class Initialized
DEBUG - 2018-05-22 03:10:48 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 03:10:48 --> Helper loaded: url_helper
INFO - 2018-05-22 03:10:48 --> Helper loaded: form_helper
INFO - 2018-05-22 03:10:48 --> Helper loaded: date_helper
INFO - 2018-05-22 03:10:48 --> Helper loaded: util_helper
INFO - 2018-05-22 03:10:48 --> Helper loaded: text_helper
INFO - 2018-05-22 03:10:48 --> Helper loaded: string_helper
INFO - 2018-05-22 03:10:48 --> Database Driver Class Initialized
DEBUG - 2018-05-22 03:10:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 03:10:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 03:10:48 --> Email Class Initialized
INFO - 2018-05-22 03:10:48 --> Controller Class Initialized
DEBUG - 2018-05-22 03:10:48 --> Profile MX_Controller Initialized
DEBUG - 2018-05-22 03:10:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 03:10:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 03:10:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-22 03:10:48 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 03:10:48 --> Login MX_Controller Initialized
INFO - 2018-05-22 03:10:48 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 03:10:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-22 03:10:51 --> Config Class Initialized
INFO - 2018-05-22 03:10:51 --> Hooks Class Initialized
DEBUG - 2018-05-22 03:10:51 --> UTF-8 Support Enabled
INFO - 2018-05-22 03:10:51 --> Utf8 Class Initialized
INFO - 2018-05-22 03:10:51 --> URI Class Initialized
INFO - 2018-05-22 03:10:51 --> Router Class Initialized
INFO - 2018-05-22 03:10:51 --> Output Class Initialized
INFO - 2018-05-22 03:10:51 --> Security Class Initialized
DEBUG - 2018-05-22 03:10:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 03:10:51 --> Input Class Initialized
INFO - 2018-05-22 03:10:51 --> Language Class Initialized
INFO - 2018-05-22 03:10:51 --> Language Class Initialized
INFO - 2018-05-22 03:10:51 --> Config Class Initialized
INFO - 2018-05-22 03:10:52 --> Loader Class Initialized
DEBUG - 2018-05-22 03:10:52 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 03:10:52 --> Helper loaded: url_helper
INFO - 2018-05-22 03:10:52 --> Helper loaded: form_helper
INFO - 2018-05-22 03:10:52 --> Helper loaded: date_helper
INFO - 2018-05-22 03:10:52 --> Helper loaded: util_helper
INFO - 2018-05-22 03:10:52 --> Helper loaded: text_helper
INFO - 2018-05-22 03:10:52 --> Helper loaded: string_helper
INFO - 2018-05-22 03:10:52 --> Database Driver Class Initialized
DEBUG - 2018-05-22 03:10:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 03:10:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 03:10:52 --> Email Class Initialized
INFO - 2018-05-22 03:10:52 --> Controller Class Initialized
DEBUG - 2018-05-22 03:10:52 --> Profile MX_Controller Initialized
DEBUG - 2018-05-22 03:10:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 03:10:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 03:10:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-22 03:10:52 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 03:10:52 --> Login MX_Controller Initialized
INFO - 2018-05-22 03:10:52 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 03:10:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-22 03:10:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-22 03:10:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-22 03:10:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-22 03:10:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-05-22 03:10:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-22 03:10:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-22 03:10:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/profile.php
INFO - 2018-05-22 03:10:52 --> Final output sent to browser
DEBUG - 2018-05-22 03:10:52 --> Total execution time: 0.7199
INFO - 2018-05-22 03:10:53 --> Config Class Initialized
INFO - 2018-05-22 03:10:53 --> Hooks Class Initialized
DEBUG - 2018-05-22 03:10:53 --> UTF-8 Support Enabled
INFO - 2018-05-22 03:10:53 --> Utf8 Class Initialized
INFO - 2018-05-22 03:10:53 --> URI Class Initialized
INFO - 2018-05-22 03:10:53 --> Router Class Initialized
INFO - 2018-05-22 03:10:53 --> Output Class Initialized
INFO - 2018-05-22 03:10:53 --> Security Class Initialized
DEBUG - 2018-05-22 03:10:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 03:10:53 --> Input Class Initialized
INFO - 2018-05-22 03:10:53 --> Language Class Initialized
ERROR - 2018-05-22 03:10:53 --> 404 Page Not Found: /index
INFO - 2018-05-22 03:10:53 --> Config Class Initialized
INFO - 2018-05-22 03:10:53 --> Hooks Class Initialized
DEBUG - 2018-05-22 03:10:53 --> UTF-8 Support Enabled
INFO - 2018-05-22 03:10:53 --> Utf8 Class Initialized
INFO - 2018-05-22 03:10:53 --> URI Class Initialized
INFO - 2018-05-22 03:10:53 --> Router Class Initialized
INFO - 2018-05-22 03:10:53 --> Output Class Initialized
INFO - 2018-05-22 03:10:53 --> Security Class Initialized
DEBUG - 2018-05-22 03:10:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 03:10:53 --> Input Class Initialized
INFO - 2018-05-22 03:10:53 --> Language Class Initialized
ERROR - 2018-05-22 03:10:53 --> 404 Page Not Found: /index
INFO - 2018-05-22 03:10:53 --> Config Class Initialized
INFO - 2018-05-22 03:10:53 --> Hooks Class Initialized
DEBUG - 2018-05-22 03:10:53 --> UTF-8 Support Enabled
INFO - 2018-05-22 03:10:54 --> Utf8 Class Initialized
INFO - 2018-05-22 03:10:54 --> URI Class Initialized
INFO - 2018-05-22 03:10:54 --> Router Class Initialized
INFO - 2018-05-22 03:10:54 --> Output Class Initialized
INFO - 2018-05-22 03:10:54 --> Security Class Initialized
DEBUG - 2018-05-22 03:10:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 03:10:54 --> Input Class Initialized
INFO - 2018-05-22 03:10:54 --> Language Class Initialized
ERROR - 2018-05-22 03:10:54 --> 404 Page Not Found: /index
INFO - 2018-05-22 03:10:54 --> Config Class Initialized
INFO - 2018-05-22 03:10:54 --> Hooks Class Initialized
DEBUG - 2018-05-22 03:10:54 --> UTF-8 Support Enabled
INFO - 2018-05-22 03:10:54 --> Utf8 Class Initialized
INFO - 2018-05-22 03:10:54 --> URI Class Initialized
INFO - 2018-05-22 03:10:54 --> Router Class Initialized
INFO - 2018-05-22 03:10:54 --> Output Class Initialized
INFO - 2018-05-22 03:10:54 --> Security Class Initialized
DEBUG - 2018-05-22 03:10:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 03:10:54 --> Input Class Initialized
INFO - 2018-05-22 03:10:54 --> Language Class Initialized
INFO - 2018-05-22 03:10:54 --> Language Class Initialized
INFO - 2018-05-22 03:10:54 --> Config Class Initialized
INFO - 2018-05-22 03:10:54 --> Loader Class Initialized
DEBUG - 2018-05-22 03:10:54 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 03:10:54 --> Helper loaded: url_helper
INFO - 2018-05-22 03:10:54 --> Helper loaded: form_helper
INFO - 2018-05-22 03:10:54 --> Helper loaded: date_helper
INFO - 2018-05-22 03:10:54 --> Helper loaded: util_helper
INFO - 2018-05-22 03:10:54 --> Helper loaded: text_helper
INFO - 2018-05-22 03:10:54 --> Helper loaded: string_helper
INFO - 2018-05-22 03:10:54 --> Database Driver Class Initialized
DEBUG - 2018-05-22 03:10:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 03:10:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 03:10:55 --> Email Class Initialized
INFO - 2018-05-22 03:10:55 --> Controller Class Initialized
DEBUG - 2018-05-22 03:10:55 --> Profile MX_Controller Initialized
DEBUG - 2018-05-22 03:10:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 03:10:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 03:10:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-22 03:10:55 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 03:10:55 --> Login MX_Controller Initialized
INFO - 2018-05-22 03:10:55 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 03:10:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-22 03:11:26 --> Config Class Initialized
INFO - 2018-05-22 03:11:26 --> Hooks Class Initialized
DEBUG - 2018-05-22 03:11:26 --> UTF-8 Support Enabled
INFO - 2018-05-22 03:11:26 --> Utf8 Class Initialized
INFO - 2018-05-22 03:11:26 --> URI Class Initialized
INFO - 2018-05-22 03:11:26 --> Router Class Initialized
INFO - 2018-05-22 03:11:26 --> Output Class Initialized
INFO - 2018-05-22 03:11:26 --> Security Class Initialized
DEBUG - 2018-05-22 03:11:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 03:11:26 --> Input Class Initialized
INFO - 2018-05-22 03:11:26 --> Language Class Initialized
INFO - 2018-05-22 03:11:26 --> Language Class Initialized
INFO - 2018-05-22 03:11:26 --> Config Class Initialized
INFO - 2018-05-22 03:11:26 --> Loader Class Initialized
DEBUG - 2018-05-22 03:11:26 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 03:11:26 --> Helper loaded: url_helper
INFO - 2018-05-22 03:11:26 --> Helper loaded: form_helper
INFO - 2018-05-22 03:11:26 --> Helper loaded: date_helper
INFO - 2018-05-22 03:11:26 --> Helper loaded: util_helper
INFO - 2018-05-22 03:11:26 --> Helper loaded: text_helper
INFO - 2018-05-22 03:11:26 --> Helper loaded: string_helper
INFO - 2018-05-22 03:11:26 --> Database Driver Class Initialized
DEBUG - 2018-05-22 03:11:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 03:11:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 03:11:26 --> Email Class Initialized
INFO - 2018-05-22 03:11:26 --> Controller Class Initialized
DEBUG - 2018-05-22 03:11:26 --> Profile MX_Controller Initialized
DEBUG - 2018-05-22 03:11:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 03:11:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 03:11:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-22 03:11:26 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 03:11:26 --> Login MX_Controller Initialized
INFO - 2018-05-22 03:11:26 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 03:11:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-22 03:11:26 --> Upload Class Initialized
INFO - 2018-05-22 03:11:28 --> Config Class Initialized
INFO - 2018-05-22 03:11:28 --> Hooks Class Initialized
DEBUG - 2018-05-22 03:11:28 --> UTF-8 Support Enabled
INFO - 2018-05-22 03:11:28 --> Utf8 Class Initialized
INFO - 2018-05-22 03:11:28 --> URI Class Initialized
INFO - 2018-05-22 03:11:28 --> Router Class Initialized
INFO - 2018-05-22 03:11:28 --> Output Class Initialized
INFO - 2018-05-22 03:11:28 --> Security Class Initialized
DEBUG - 2018-05-22 03:11:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 03:11:28 --> Input Class Initialized
INFO - 2018-05-22 03:11:28 --> Language Class Initialized
INFO - 2018-05-22 03:11:28 --> Language Class Initialized
INFO - 2018-05-22 03:11:28 --> Config Class Initialized
INFO - 2018-05-22 03:11:28 --> Loader Class Initialized
DEBUG - 2018-05-22 03:11:28 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 03:11:28 --> Helper loaded: url_helper
INFO - 2018-05-22 03:11:28 --> Helper loaded: form_helper
INFO - 2018-05-22 03:11:28 --> Helper loaded: date_helper
INFO - 2018-05-22 03:11:28 --> Helper loaded: util_helper
INFO - 2018-05-22 03:11:28 --> Helper loaded: text_helper
INFO - 2018-05-22 03:11:28 --> Helper loaded: string_helper
INFO - 2018-05-22 03:11:28 --> Database Driver Class Initialized
DEBUG - 2018-05-22 03:11:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 03:11:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 03:11:28 --> Email Class Initialized
INFO - 2018-05-22 03:11:28 --> Controller Class Initialized
DEBUG - 2018-05-22 03:11:28 --> Profile MX_Controller Initialized
DEBUG - 2018-05-22 03:11:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 03:11:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 03:11:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-22 03:11:28 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 03:11:28 --> Login MX_Controller Initialized
INFO - 2018-05-22 03:11:28 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 03:11:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-22 03:11:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-22 03:11:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-22 03:11:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-22 03:11:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-05-22 03:11:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-22 03:11:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-22 03:11:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/profile.php
INFO - 2018-05-22 03:11:29 --> Final output sent to browser
DEBUG - 2018-05-22 03:11:29 --> Total execution time: 0.8257
INFO - 2018-05-22 03:11:29 --> Config Class Initialized
INFO - 2018-05-22 03:11:29 --> Hooks Class Initialized
DEBUG - 2018-05-22 03:11:29 --> UTF-8 Support Enabled
INFO - 2018-05-22 03:11:29 --> Utf8 Class Initialized
INFO - 2018-05-22 03:11:29 --> URI Class Initialized
INFO - 2018-05-22 03:11:29 --> Router Class Initialized
INFO - 2018-05-22 03:11:29 --> Output Class Initialized
INFO - 2018-05-22 03:11:30 --> Security Class Initialized
DEBUG - 2018-05-22 03:11:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 03:11:30 --> Input Class Initialized
INFO - 2018-05-22 03:11:30 --> Language Class Initialized
ERROR - 2018-05-22 03:11:30 --> 404 Page Not Found: /index
INFO - 2018-05-22 03:11:30 --> Config Class Initialized
INFO - 2018-05-22 03:11:30 --> Hooks Class Initialized
DEBUG - 2018-05-22 03:11:30 --> UTF-8 Support Enabled
INFO - 2018-05-22 03:11:30 --> Utf8 Class Initialized
INFO - 2018-05-22 03:11:30 --> URI Class Initialized
INFO - 2018-05-22 03:11:30 --> Router Class Initialized
INFO - 2018-05-22 03:11:30 --> Output Class Initialized
INFO - 2018-05-22 03:11:30 --> Security Class Initialized
DEBUG - 2018-05-22 03:11:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 03:11:30 --> Input Class Initialized
INFO - 2018-05-22 03:11:30 --> Language Class Initialized
ERROR - 2018-05-22 03:11:30 --> 404 Page Not Found: /index
INFO - 2018-05-22 03:11:30 --> Config Class Initialized
INFO - 2018-05-22 03:11:30 --> Hooks Class Initialized
DEBUG - 2018-05-22 03:11:30 --> UTF-8 Support Enabled
INFO - 2018-05-22 03:11:30 --> Utf8 Class Initialized
INFO - 2018-05-22 03:11:30 --> URI Class Initialized
INFO - 2018-05-22 03:11:30 --> Router Class Initialized
INFO - 2018-05-22 03:11:30 --> Output Class Initialized
INFO - 2018-05-22 03:11:30 --> Security Class Initialized
DEBUG - 2018-05-22 03:11:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 03:11:30 --> Input Class Initialized
INFO - 2018-05-22 03:11:30 --> Language Class Initialized
ERROR - 2018-05-22 03:11:30 --> 404 Page Not Found: /index
INFO - 2018-05-22 03:12:21 --> Config Class Initialized
INFO - 2018-05-22 03:12:21 --> Hooks Class Initialized
DEBUG - 2018-05-22 03:12:21 --> UTF-8 Support Enabled
INFO - 2018-05-22 03:12:21 --> Utf8 Class Initialized
INFO - 2018-05-22 03:12:21 --> URI Class Initialized
INFO - 2018-05-22 03:12:21 --> Router Class Initialized
INFO - 2018-05-22 03:12:21 --> Output Class Initialized
INFO - 2018-05-22 03:12:21 --> Security Class Initialized
DEBUG - 2018-05-22 03:12:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 03:12:21 --> Input Class Initialized
INFO - 2018-05-22 03:12:21 --> Language Class Initialized
INFO - 2018-05-22 03:12:21 --> Language Class Initialized
INFO - 2018-05-22 03:12:21 --> Config Class Initialized
INFO - 2018-05-22 03:12:21 --> Loader Class Initialized
DEBUG - 2018-05-22 03:12:21 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 03:12:21 --> Helper loaded: url_helper
INFO - 2018-05-22 03:12:21 --> Helper loaded: form_helper
INFO - 2018-05-22 03:12:21 --> Helper loaded: date_helper
INFO - 2018-05-22 03:12:21 --> Helper loaded: util_helper
INFO - 2018-05-22 03:12:21 --> Helper loaded: text_helper
INFO - 2018-05-22 03:12:21 --> Helper loaded: string_helper
INFO - 2018-05-22 03:12:21 --> Database Driver Class Initialized
DEBUG - 2018-05-22 03:12:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 03:12:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 03:12:21 --> Email Class Initialized
INFO - 2018-05-22 03:12:21 --> Controller Class Initialized
DEBUG - 2018-05-22 03:12:22 --> Profile MX_Controller Initialized
DEBUG - 2018-05-22 03:12:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 03:12:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 03:12:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-22 03:12:22 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 03:12:22 --> Login MX_Controller Initialized
INFO - 2018-05-22 03:12:22 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 03:12:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-22 03:12:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-22 03:12:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-22 03:12:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-22 03:12:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-05-22 03:12:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-22 03:12:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-22 03:12:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/addresses.php
INFO - 2018-05-22 03:12:22 --> Final output sent to browser
DEBUG - 2018-05-22 03:12:22 --> Total execution time: 0.6613
INFO - 2018-05-22 03:12:23 --> Config Class Initialized
INFO - 2018-05-22 03:12:23 --> Hooks Class Initialized
DEBUG - 2018-05-22 03:12:23 --> UTF-8 Support Enabled
INFO - 2018-05-22 03:12:23 --> Utf8 Class Initialized
INFO - 2018-05-22 03:12:23 --> URI Class Initialized
INFO - 2018-05-22 03:12:23 --> Router Class Initialized
INFO - 2018-05-22 03:12:23 --> Output Class Initialized
INFO - 2018-05-22 03:12:23 --> Security Class Initialized
DEBUG - 2018-05-22 03:12:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 03:12:23 --> Input Class Initialized
INFO - 2018-05-22 03:12:23 --> Language Class Initialized
ERROR - 2018-05-22 03:12:23 --> 404 Page Not Found: /index
INFO - 2018-05-22 03:12:23 --> Config Class Initialized
INFO - 2018-05-22 03:12:23 --> Hooks Class Initialized
DEBUG - 2018-05-22 03:12:23 --> UTF-8 Support Enabled
INFO - 2018-05-22 03:12:23 --> Utf8 Class Initialized
INFO - 2018-05-22 03:12:23 --> URI Class Initialized
INFO - 2018-05-22 03:12:23 --> Router Class Initialized
INFO - 2018-05-22 03:12:23 --> Output Class Initialized
INFO - 2018-05-22 03:12:23 --> Security Class Initialized
DEBUG - 2018-05-22 03:12:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 03:12:23 --> Input Class Initialized
INFO - 2018-05-22 03:12:23 --> Language Class Initialized
ERROR - 2018-05-22 03:12:23 --> 404 Page Not Found: /index
INFO - 2018-05-22 03:12:23 --> Config Class Initialized
INFO - 2018-05-22 03:12:23 --> Hooks Class Initialized
DEBUG - 2018-05-22 03:12:23 --> UTF-8 Support Enabled
INFO - 2018-05-22 03:12:23 --> Utf8 Class Initialized
INFO - 2018-05-22 03:12:23 --> URI Class Initialized
INFO - 2018-05-22 03:12:23 --> Router Class Initialized
INFO - 2018-05-22 03:12:23 --> Output Class Initialized
INFO - 2018-05-22 03:12:23 --> Security Class Initialized
DEBUG - 2018-05-22 03:12:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 03:12:23 --> Input Class Initialized
INFO - 2018-05-22 03:12:23 --> Language Class Initialized
ERROR - 2018-05-22 03:12:23 --> 404 Page Not Found: /index
INFO - 2018-05-22 03:13:58 --> Config Class Initialized
INFO - 2018-05-22 03:13:58 --> Hooks Class Initialized
DEBUG - 2018-05-22 03:13:58 --> UTF-8 Support Enabled
INFO - 2018-05-22 03:13:58 --> Utf8 Class Initialized
INFO - 2018-05-22 03:13:58 --> URI Class Initialized
INFO - 2018-05-22 03:13:58 --> Router Class Initialized
INFO - 2018-05-22 03:13:58 --> Output Class Initialized
INFO - 2018-05-22 03:13:58 --> Security Class Initialized
DEBUG - 2018-05-22 03:13:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 03:13:58 --> Input Class Initialized
INFO - 2018-05-22 03:13:58 --> Language Class Initialized
INFO - 2018-05-22 03:13:58 --> Language Class Initialized
INFO - 2018-05-22 03:13:58 --> Config Class Initialized
INFO - 2018-05-22 03:13:58 --> Loader Class Initialized
DEBUG - 2018-05-22 03:13:58 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 03:13:58 --> Helper loaded: url_helper
INFO - 2018-05-22 03:13:58 --> Helper loaded: form_helper
INFO - 2018-05-22 03:13:59 --> Helper loaded: date_helper
INFO - 2018-05-22 03:13:59 --> Helper loaded: util_helper
INFO - 2018-05-22 03:13:59 --> Helper loaded: text_helper
INFO - 2018-05-22 03:13:59 --> Helper loaded: string_helper
INFO - 2018-05-22 03:13:59 --> Database Driver Class Initialized
DEBUG - 2018-05-22 03:13:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 03:13:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 03:13:59 --> Email Class Initialized
INFO - 2018-05-22 03:13:59 --> Controller Class Initialized
DEBUG - 2018-05-22 03:13:59 --> Profile MX_Controller Initialized
DEBUG - 2018-05-22 03:13:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 03:13:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 03:13:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-22 03:13:59 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 03:13:59 --> Login MX_Controller Initialized
INFO - 2018-05-22 03:13:59 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 03:13:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-22 03:13:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-22 03:13:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-22 03:13:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-22 03:13:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-05-22 03:13:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-22 03:13:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-22 03:13:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/email_preferences.php
INFO - 2018-05-22 03:13:59 --> Final output sent to browser
DEBUG - 2018-05-22 03:13:59 --> Total execution time: 0.7675
INFO - 2018-05-22 03:14:00 --> Config Class Initialized
INFO - 2018-05-22 03:14:00 --> Hooks Class Initialized
DEBUG - 2018-05-22 03:14:00 --> UTF-8 Support Enabled
INFO - 2018-05-22 03:14:00 --> Utf8 Class Initialized
INFO - 2018-05-22 03:14:00 --> URI Class Initialized
INFO - 2018-05-22 03:14:00 --> Router Class Initialized
INFO - 2018-05-22 03:14:00 --> Output Class Initialized
INFO - 2018-05-22 03:14:00 --> Security Class Initialized
DEBUG - 2018-05-22 03:14:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 03:14:00 --> Input Class Initialized
INFO - 2018-05-22 03:14:00 --> Language Class Initialized
ERROR - 2018-05-22 03:14:00 --> 404 Page Not Found: /index
INFO - 2018-05-22 03:14:00 --> Config Class Initialized
INFO - 2018-05-22 03:14:00 --> Hooks Class Initialized
DEBUG - 2018-05-22 03:14:00 --> UTF-8 Support Enabled
INFO - 2018-05-22 03:14:00 --> Utf8 Class Initialized
INFO - 2018-05-22 03:14:00 --> URI Class Initialized
INFO - 2018-05-22 03:14:00 --> Router Class Initialized
INFO - 2018-05-22 03:14:00 --> Output Class Initialized
INFO - 2018-05-22 03:14:00 --> Security Class Initialized
DEBUG - 2018-05-22 03:14:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 03:14:00 --> Input Class Initialized
INFO - 2018-05-22 03:14:00 --> Language Class Initialized
ERROR - 2018-05-22 03:14:00 --> 404 Page Not Found: /index
INFO - 2018-05-22 03:14:00 --> Config Class Initialized
INFO - 2018-05-22 03:14:00 --> Hooks Class Initialized
DEBUG - 2018-05-22 03:14:00 --> UTF-8 Support Enabled
INFO - 2018-05-22 03:14:00 --> Utf8 Class Initialized
INFO - 2018-05-22 03:14:00 --> URI Class Initialized
INFO - 2018-05-22 03:14:00 --> Router Class Initialized
INFO - 2018-05-22 03:14:00 --> Output Class Initialized
INFO - 2018-05-22 03:14:00 --> Security Class Initialized
DEBUG - 2018-05-22 03:14:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 03:14:00 --> Input Class Initialized
INFO - 2018-05-22 03:14:01 --> Language Class Initialized
ERROR - 2018-05-22 03:14:01 --> 404 Page Not Found: /index
INFO - 2018-05-22 03:14:03 --> Config Class Initialized
INFO - 2018-05-22 03:14:03 --> Hooks Class Initialized
DEBUG - 2018-05-22 03:14:03 --> UTF-8 Support Enabled
INFO - 2018-05-22 03:14:03 --> Utf8 Class Initialized
INFO - 2018-05-22 03:14:03 --> URI Class Initialized
INFO - 2018-05-22 03:14:03 --> Router Class Initialized
INFO - 2018-05-22 03:14:03 --> Output Class Initialized
INFO - 2018-05-22 03:14:03 --> Security Class Initialized
DEBUG - 2018-05-22 03:14:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 03:14:03 --> Input Class Initialized
INFO - 2018-05-22 03:14:03 --> Language Class Initialized
INFO - 2018-05-22 03:14:03 --> Language Class Initialized
INFO - 2018-05-22 03:14:03 --> Config Class Initialized
INFO - 2018-05-22 03:14:03 --> Loader Class Initialized
DEBUG - 2018-05-22 03:14:03 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 03:14:03 --> Helper loaded: url_helper
INFO - 2018-05-22 03:14:03 --> Helper loaded: form_helper
INFO - 2018-05-22 03:14:03 --> Helper loaded: date_helper
INFO - 2018-05-22 03:14:03 --> Helper loaded: util_helper
INFO - 2018-05-22 03:14:03 --> Helper loaded: text_helper
INFO - 2018-05-22 03:14:03 --> Helper loaded: string_helper
INFO - 2018-05-22 03:14:03 --> Database Driver Class Initialized
DEBUG - 2018-05-22 03:14:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 03:14:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 03:14:03 --> Email Class Initialized
INFO - 2018-05-22 03:14:03 --> Controller Class Initialized
DEBUG - 2018-05-22 03:14:03 --> Profile MX_Controller Initialized
DEBUG - 2018-05-22 03:14:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 03:14:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 03:14:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-22 03:14:03 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 03:14:03 --> Login MX_Controller Initialized
INFO - 2018-05-22 03:14:03 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 03:14:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-22 03:14:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-22 03:14:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-22 03:14:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-22 03:14:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-05-22 03:14:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-22 03:14:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-22 03:14:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/billing.php
INFO - 2018-05-22 03:14:03 --> Final output sent to browser
DEBUG - 2018-05-22 03:14:03 --> Total execution time: 0.6976
INFO - 2018-05-22 03:14:04 --> Config Class Initialized
INFO - 2018-05-22 03:14:04 --> Hooks Class Initialized
DEBUG - 2018-05-22 03:14:04 --> UTF-8 Support Enabled
INFO - 2018-05-22 03:14:04 --> Utf8 Class Initialized
INFO - 2018-05-22 03:14:04 --> URI Class Initialized
INFO - 2018-05-22 03:14:04 --> Router Class Initialized
INFO - 2018-05-22 03:14:04 --> Output Class Initialized
INFO - 2018-05-22 03:14:04 --> Security Class Initialized
DEBUG - 2018-05-22 03:14:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 03:14:04 --> Input Class Initialized
INFO - 2018-05-22 03:14:04 --> Language Class Initialized
ERROR - 2018-05-22 03:14:04 --> 404 Page Not Found: /index
INFO - 2018-05-22 03:14:04 --> Config Class Initialized
INFO - 2018-05-22 03:14:04 --> Hooks Class Initialized
DEBUG - 2018-05-22 03:14:04 --> UTF-8 Support Enabled
INFO - 2018-05-22 03:14:04 --> Utf8 Class Initialized
INFO - 2018-05-22 03:14:04 --> URI Class Initialized
INFO - 2018-05-22 03:14:04 --> Router Class Initialized
INFO - 2018-05-22 03:14:04 --> Output Class Initialized
INFO - 2018-05-22 03:14:04 --> Security Class Initialized
DEBUG - 2018-05-22 03:14:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 03:14:05 --> Input Class Initialized
INFO - 2018-05-22 03:14:05 --> Language Class Initialized
ERROR - 2018-05-22 03:14:05 --> 404 Page Not Found: /index
INFO - 2018-05-22 03:14:05 --> Config Class Initialized
INFO - 2018-05-22 03:14:05 --> Hooks Class Initialized
DEBUG - 2018-05-22 03:14:05 --> UTF-8 Support Enabled
INFO - 2018-05-22 03:14:05 --> Utf8 Class Initialized
INFO - 2018-05-22 03:14:05 --> URI Class Initialized
INFO - 2018-05-22 03:14:05 --> Router Class Initialized
INFO - 2018-05-22 03:14:05 --> Output Class Initialized
INFO - 2018-05-22 03:14:05 --> Security Class Initialized
DEBUG - 2018-05-22 03:14:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 03:14:05 --> Input Class Initialized
INFO - 2018-05-22 03:14:05 --> Language Class Initialized
ERROR - 2018-05-22 03:14:05 --> 404 Page Not Found: /index
INFO - 2018-05-22 03:14:07 --> Config Class Initialized
INFO - 2018-05-22 03:14:07 --> Hooks Class Initialized
DEBUG - 2018-05-22 03:14:07 --> UTF-8 Support Enabled
INFO - 2018-05-22 03:14:07 --> Utf8 Class Initialized
INFO - 2018-05-22 03:14:07 --> URI Class Initialized
INFO - 2018-05-22 03:14:07 --> Router Class Initialized
INFO - 2018-05-22 03:14:07 --> Output Class Initialized
INFO - 2018-05-22 03:14:07 --> Security Class Initialized
DEBUG - 2018-05-22 03:14:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 03:14:07 --> Input Class Initialized
INFO - 2018-05-22 03:14:07 --> Language Class Initialized
INFO - 2018-05-22 03:14:07 --> Language Class Initialized
INFO - 2018-05-22 03:14:07 --> Config Class Initialized
INFO - 2018-05-22 03:14:07 --> Loader Class Initialized
DEBUG - 2018-05-22 03:14:07 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 03:14:07 --> Helper loaded: url_helper
INFO - 2018-05-22 03:14:07 --> Helper loaded: form_helper
INFO - 2018-05-22 03:14:07 --> Helper loaded: date_helper
INFO - 2018-05-22 03:14:07 --> Helper loaded: util_helper
INFO - 2018-05-22 03:14:07 --> Helper loaded: text_helper
INFO - 2018-05-22 03:14:07 --> Helper loaded: string_helper
INFO - 2018-05-22 03:14:07 --> Database Driver Class Initialized
DEBUG - 2018-05-22 03:14:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 03:14:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 03:14:07 --> Email Class Initialized
INFO - 2018-05-22 03:14:07 --> Controller Class Initialized
DEBUG - 2018-05-22 03:14:07 --> Profile MX_Controller Initialized
DEBUG - 2018-05-22 03:14:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 03:14:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 03:14:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-22 03:14:07 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 03:14:07 --> Login MX_Controller Initialized
INFO - 2018-05-22 03:14:07 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 03:14:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-22 03:14:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-22 03:14:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-22 03:14:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-22 03:14:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-05-22 03:14:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-22 03:14:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-22 03:14:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/addresses.php
INFO - 2018-05-22 03:14:07 --> Final output sent to browser
DEBUG - 2018-05-22 03:14:07 --> Total execution time: 0.6533
INFO - 2018-05-22 03:14:08 --> Config Class Initialized
INFO - 2018-05-22 03:14:08 --> Hooks Class Initialized
DEBUG - 2018-05-22 03:14:08 --> UTF-8 Support Enabled
INFO - 2018-05-22 03:14:08 --> Utf8 Class Initialized
INFO - 2018-05-22 03:14:08 --> URI Class Initialized
INFO - 2018-05-22 03:14:08 --> Router Class Initialized
INFO - 2018-05-22 03:14:08 --> Output Class Initialized
INFO - 2018-05-22 03:14:08 --> Security Class Initialized
DEBUG - 2018-05-22 03:14:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 03:14:08 --> Input Class Initialized
INFO - 2018-05-22 03:14:08 --> Language Class Initialized
ERROR - 2018-05-22 03:14:08 --> 404 Page Not Found: /index
INFO - 2018-05-22 03:14:09 --> Config Class Initialized
INFO - 2018-05-22 03:14:09 --> Hooks Class Initialized
DEBUG - 2018-05-22 03:14:09 --> UTF-8 Support Enabled
INFO - 2018-05-22 03:14:09 --> Utf8 Class Initialized
INFO - 2018-05-22 03:14:09 --> URI Class Initialized
INFO - 2018-05-22 03:14:09 --> Router Class Initialized
INFO - 2018-05-22 03:14:09 --> Output Class Initialized
INFO - 2018-05-22 03:14:09 --> Security Class Initialized
DEBUG - 2018-05-22 03:14:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 03:14:09 --> Input Class Initialized
INFO - 2018-05-22 03:14:09 --> Language Class Initialized
ERROR - 2018-05-22 03:14:09 --> 404 Page Not Found: /index
INFO - 2018-05-22 03:14:09 --> Config Class Initialized
INFO - 2018-05-22 03:14:09 --> Hooks Class Initialized
DEBUG - 2018-05-22 03:14:09 --> UTF-8 Support Enabled
INFO - 2018-05-22 03:14:09 --> Utf8 Class Initialized
INFO - 2018-05-22 03:14:09 --> URI Class Initialized
INFO - 2018-05-22 03:14:09 --> Router Class Initialized
INFO - 2018-05-22 03:14:09 --> Output Class Initialized
INFO - 2018-05-22 03:14:09 --> Security Class Initialized
DEBUG - 2018-05-22 03:14:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 03:14:09 --> Input Class Initialized
INFO - 2018-05-22 03:14:09 --> Language Class Initialized
ERROR - 2018-05-22 03:14:09 --> 404 Page Not Found: /index
INFO - 2018-05-22 03:14:10 --> Config Class Initialized
INFO - 2018-05-22 03:14:11 --> Hooks Class Initialized
DEBUG - 2018-05-22 03:14:11 --> UTF-8 Support Enabled
INFO - 2018-05-22 03:14:11 --> Utf8 Class Initialized
INFO - 2018-05-22 03:14:11 --> URI Class Initialized
INFO - 2018-05-22 03:14:11 --> Router Class Initialized
INFO - 2018-05-22 03:14:11 --> Output Class Initialized
INFO - 2018-05-22 03:14:11 --> Security Class Initialized
DEBUG - 2018-05-22 03:14:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 03:14:11 --> Input Class Initialized
INFO - 2018-05-22 03:14:11 --> Language Class Initialized
INFO - 2018-05-22 03:14:11 --> Language Class Initialized
INFO - 2018-05-22 03:14:11 --> Config Class Initialized
INFO - 2018-05-22 03:14:11 --> Loader Class Initialized
DEBUG - 2018-05-22 03:14:11 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 03:14:11 --> Helper loaded: url_helper
INFO - 2018-05-22 03:14:11 --> Helper loaded: form_helper
INFO - 2018-05-22 03:14:11 --> Helper loaded: date_helper
INFO - 2018-05-22 03:14:11 --> Helper loaded: util_helper
INFO - 2018-05-22 03:14:11 --> Helper loaded: text_helper
INFO - 2018-05-22 03:14:11 --> Helper loaded: string_helper
INFO - 2018-05-22 03:14:11 --> Database Driver Class Initialized
DEBUG - 2018-05-22 03:14:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 03:14:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 03:14:11 --> Email Class Initialized
INFO - 2018-05-22 03:14:11 --> Controller Class Initialized
DEBUG - 2018-05-22 03:14:11 --> Profile MX_Controller Initialized
DEBUG - 2018-05-22 03:14:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 03:14:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 03:14:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-22 03:14:11 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 03:14:11 --> Login MX_Controller Initialized
INFO - 2018-05-22 03:14:11 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 03:14:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-22 03:14:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-22 03:14:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-22 03:14:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-22 03:14:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-05-22 03:14:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-22 03:14:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-22 03:14:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/billing.php
INFO - 2018-05-22 03:14:11 --> Final output sent to browser
DEBUG - 2018-05-22 03:14:11 --> Total execution time: 0.6495
INFO - 2018-05-22 03:14:12 --> Config Class Initialized
INFO - 2018-05-22 03:14:12 --> Hooks Class Initialized
DEBUG - 2018-05-22 03:14:12 --> UTF-8 Support Enabled
INFO - 2018-05-22 03:14:12 --> Utf8 Class Initialized
INFO - 2018-05-22 03:14:12 --> URI Class Initialized
INFO - 2018-05-22 03:14:12 --> Router Class Initialized
INFO - 2018-05-22 03:14:12 --> Output Class Initialized
INFO - 2018-05-22 03:14:12 --> Security Class Initialized
DEBUG - 2018-05-22 03:14:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 03:14:12 --> Input Class Initialized
INFO - 2018-05-22 03:14:12 --> Language Class Initialized
ERROR - 2018-05-22 03:14:12 --> 404 Page Not Found: /index
INFO - 2018-05-22 03:14:12 --> Config Class Initialized
INFO - 2018-05-22 03:14:12 --> Hooks Class Initialized
DEBUG - 2018-05-22 03:14:12 --> UTF-8 Support Enabled
INFO - 2018-05-22 03:14:12 --> Utf8 Class Initialized
INFO - 2018-05-22 03:14:12 --> URI Class Initialized
INFO - 2018-05-22 03:14:12 --> Router Class Initialized
INFO - 2018-05-22 03:14:12 --> Output Class Initialized
INFO - 2018-05-22 03:14:12 --> Security Class Initialized
DEBUG - 2018-05-22 03:14:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 03:14:12 --> Input Class Initialized
INFO - 2018-05-22 03:14:12 --> Language Class Initialized
ERROR - 2018-05-22 03:14:12 --> 404 Page Not Found: /index
INFO - 2018-05-22 03:14:12 --> Config Class Initialized
INFO - 2018-05-22 03:14:12 --> Hooks Class Initialized
DEBUG - 2018-05-22 03:14:13 --> UTF-8 Support Enabled
INFO - 2018-05-22 03:14:13 --> Utf8 Class Initialized
INFO - 2018-05-22 03:14:13 --> URI Class Initialized
INFO - 2018-05-22 03:14:13 --> Router Class Initialized
INFO - 2018-05-22 03:14:13 --> Output Class Initialized
INFO - 2018-05-22 03:14:13 --> Security Class Initialized
DEBUG - 2018-05-22 03:14:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 03:14:13 --> Input Class Initialized
INFO - 2018-05-22 03:14:13 --> Language Class Initialized
ERROR - 2018-05-22 03:14:13 --> 404 Page Not Found: /index
INFO - 2018-05-22 03:14:17 --> Config Class Initialized
INFO - 2018-05-22 03:14:17 --> Hooks Class Initialized
DEBUG - 2018-05-22 03:14:17 --> UTF-8 Support Enabled
INFO - 2018-05-22 03:14:17 --> Utf8 Class Initialized
INFO - 2018-05-22 03:14:17 --> URI Class Initialized
INFO - 2018-05-22 03:14:17 --> Router Class Initialized
INFO - 2018-05-22 03:14:17 --> Output Class Initialized
INFO - 2018-05-22 03:14:17 --> Security Class Initialized
DEBUG - 2018-05-22 03:14:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 03:14:17 --> Input Class Initialized
INFO - 2018-05-22 03:14:17 --> Language Class Initialized
INFO - 2018-05-22 03:14:17 --> Language Class Initialized
INFO - 2018-05-22 03:14:17 --> Config Class Initialized
INFO - 2018-05-22 03:14:17 --> Loader Class Initialized
DEBUG - 2018-05-22 03:14:17 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 03:14:17 --> Helper loaded: url_helper
INFO - 2018-05-22 03:14:17 --> Helper loaded: form_helper
INFO - 2018-05-22 03:14:17 --> Helper loaded: date_helper
INFO - 2018-05-22 03:14:17 --> Helper loaded: util_helper
INFO - 2018-05-22 03:14:17 --> Helper loaded: text_helper
INFO - 2018-05-22 03:14:17 --> Helper loaded: string_helper
INFO - 2018-05-22 03:14:17 --> Database Driver Class Initialized
DEBUG - 2018-05-22 03:14:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 03:14:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 03:14:17 --> Email Class Initialized
INFO - 2018-05-22 03:14:17 --> Controller Class Initialized
DEBUG - 2018-05-22 03:14:17 --> Profile MX_Controller Initialized
DEBUG - 2018-05-22 03:14:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 03:14:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 03:14:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-22 03:14:17 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 03:14:17 --> Login MX_Controller Initialized
INFO - 2018-05-22 03:14:17 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 03:14:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-22 03:14:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-22 03:14:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-22 03:14:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-22 03:14:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-05-22 03:14:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-22 03:14:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-22 03:14:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/addresses.php
INFO - 2018-05-22 03:14:17 --> Final output sent to browser
DEBUG - 2018-05-22 03:14:17 --> Total execution time: 0.6613
INFO - 2018-05-22 03:14:18 --> Config Class Initialized
INFO - 2018-05-22 03:14:18 --> Hooks Class Initialized
DEBUG - 2018-05-22 03:14:18 --> UTF-8 Support Enabled
INFO - 2018-05-22 03:14:18 --> Utf8 Class Initialized
INFO - 2018-05-22 03:14:18 --> URI Class Initialized
INFO - 2018-05-22 03:14:18 --> Router Class Initialized
INFO - 2018-05-22 03:14:18 --> Output Class Initialized
INFO - 2018-05-22 03:14:18 --> Security Class Initialized
DEBUG - 2018-05-22 03:14:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 03:14:18 --> Input Class Initialized
INFO - 2018-05-22 03:14:18 --> Language Class Initialized
ERROR - 2018-05-22 03:14:18 --> 404 Page Not Found: /index
INFO - 2018-05-22 03:14:18 --> Config Class Initialized
INFO - 2018-05-22 03:14:18 --> Hooks Class Initialized
DEBUG - 2018-05-22 03:14:18 --> UTF-8 Support Enabled
INFO - 2018-05-22 03:14:18 --> Utf8 Class Initialized
INFO - 2018-05-22 03:14:18 --> URI Class Initialized
INFO - 2018-05-22 03:14:18 --> Router Class Initialized
INFO - 2018-05-22 03:14:19 --> Output Class Initialized
INFO - 2018-05-22 03:14:19 --> Security Class Initialized
DEBUG - 2018-05-22 03:14:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 03:14:19 --> Input Class Initialized
INFO - 2018-05-22 03:14:19 --> Language Class Initialized
ERROR - 2018-05-22 03:14:19 --> 404 Page Not Found: /index
INFO - 2018-05-22 03:14:19 --> Config Class Initialized
INFO - 2018-05-22 03:14:19 --> Hooks Class Initialized
DEBUG - 2018-05-22 03:14:19 --> UTF-8 Support Enabled
INFO - 2018-05-22 03:14:19 --> Utf8 Class Initialized
INFO - 2018-05-22 03:14:19 --> URI Class Initialized
INFO - 2018-05-22 03:14:19 --> Router Class Initialized
INFO - 2018-05-22 03:14:19 --> Output Class Initialized
INFO - 2018-05-22 03:14:19 --> Security Class Initialized
DEBUG - 2018-05-22 03:14:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 03:14:19 --> Input Class Initialized
INFO - 2018-05-22 03:14:19 --> Language Class Initialized
ERROR - 2018-05-22 03:14:19 --> 404 Page Not Found: /index
INFO - 2018-05-22 03:15:55 --> Config Class Initialized
INFO - 2018-05-22 03:15:55 --> Hooks Class Initialized
DEBUG - 2018-05-22 03:15:55 --> UTF-8 Support Enabled
INFO - 2018-05-22 03:15:55 --> Utf8 Class Initialized
INFO - 2018-05-22 03:15:55 --> URI Class Initialized
INFO - 2018-05-22 03:15:55 --> Router Class Initialized
INFO - 2018-05-22 03:15:55 --> Output Class Initialized
INFO - 2018-05-22 03:15:55 --> Security Class Initialized
DEBUG - 2018-05-22 03:15:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 03:15:55 --> Input Class Initialized
INFO - 2018-05-22 03:15:55 --> Language Class Initialized
INFO - 2018-05-22 03:15:55 --> Language Class Initialized
INFO - 2018-05-22 03:15:55 --> Config Class Initialized
INFO - 2018-05-22 03:15:55 --> Loader Class Initialized
DEBUG - 2018-05-22 03:15:55 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 03:15:55 --> Helper loaded: url_helper
INFO - 2018-05-22 03:15:55 --> Helper loaded: form_helper
INFO - 2018-05-22 03:15:55 --> Helper loaded: date_helper
INFO - 2018-05-22 03:15:55 --> Helper loaded: util_helper
INFO - 2018-05-22 03:15:55 --> Helper loaded: text_helper
INFO - 2018-05-22 03:15:55 --> Helper loaded: string_helper
INFO - 2018-05-22 03:15:55 --> Database Driver Class Initialized
DEBUG - 2018-05-22 03:15:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 03:15:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 03:15:55 --> Email Class Initialized
INFO - 2018-05-22 03:15:55 --> Controller Class Initialized
DEBUG - 2018-05-22 03:15:55 --> Profile MX_Controller Initialized
DEBUG - 2018-05-22 03:15:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 03:15:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 03:15:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-22 03:15:55 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 03:15:55 --> Login MX_Controller Initialized
INFO - 2018-05-22 03:15:55 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 03:15:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-22 03:15:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-22 03:15:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-22 03:15:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-22 03:15:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-05-22 03:15:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-22 03:15:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-22 03:15:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/billing.php
INFO - 2018-05-22 03:15:55 --> Final output sent to browser
DEBUG - 2018-05-22 03:15:55 --> Total execution time: 0.6980
INFO - 2018-05-22 03:15:56 --> Config Class Initialized
INFO - 2018-05-22 03:15:56 --> Hooks Class Initialized
DEBUG - 2018-05-22 03:15:56 --> UTF-8 Support Enabled
INFO - 2018-05-22 03:15:56 --> Utf8 Class Initialized
INFO - 2018-05-22 03:15:56 --> URI Class Initialized
INFO - 2018-05-22 03:15:56 --> Router Class Initialized
INFO - 2018-05-22 03:15:56 --> Output Class Initialized
INFO - 2018-05-22 03:15:56 --> Security Class Initialized
DEBUG - 2018-05-22 03:15:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 03:15:56 --> Input Class Initialized
INFO - 2018-05-22 03:15:56 --> Language Class Initialized
ERROR - 2018-05-22 03:15:56 --> 404 Page Not Found: /index
INFO - 2018-05-22 03:15:56 --> Config Class Initialized
INFO - 2018-05-22 03:15:57 --> Hooks Class Initialized
DEBUG - 2018-05-22 03:15:57 --> UTF-8 Support Enabled
INFO - 2018-05-22 03:15:57 --> Utf8 Class Initialized
INFO - 2018-05-22 03:15:57 --> URI Class Initialized
INFO - 2018-05-22 03:15:57 --> Router Class Initialized
INFO - 2018-05-22 03:15:57 --> Output Class Initialized
INFO - 2018-05-22 03:15:57 --> Security Class Initialized
DEBUG - 2018-05-22 03:15:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 03:15:57 --> Input Class Initialized
INFO - 2018-05-22 03:15:57 --> Language Class Initialized
ERROR - 2018-05-22 03:15:57 --> 404 Page Not Found: /index
INFO - 2018-05-22 03:15:57 --> Config Class Initialized
INFO - 2018-05-22 03:15:57 --> Hooks Class Initialized
DEBUG - 2018-05-22 03:15:57 --> UTF-8 Support Enabled
INFO - 2018-05-22 03:15:57 --> Utf8 Class Initialized
INFO - 2018-05-22 03:15:57 --> URI Class Initialized
INFO - 2018-05-22 03:15:57 --> Router Class Initialized
INFO - 2018-05-22 03:15:57 --> Output Class Initialized
INFO - 2018-05-22 03:15:57 --> Security Class Initialized
DEBUG - 2018-05-22 03:15:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 03:15:57 --> Input Class Initialized
INFO - 2018-05-22 03:15:57 --> Language Class Initialized
ERROR - 2018-05-22 03:15:57 --> 404 Page Not Found: /index
INFO - 2018-05-22 03:16:03 --> Config Class Initialized
INFO - 2018-05-22 03:16:04 --> Hooks Class Initialized
DEBUG - 2018-05-22 03:16:04 --> UTF-8 Support Enabled
INFO - 2018-05-22 03:16:04 --> Utf8 Class Initialized
INFO - 2018-05-22 03:16:04 --> URI Class Initialized
INFO - 2018-05-22 03:16:04 --> Router Class Initialized
INFO - 2018-05-22 03:16:04 --> Output Class Initialized
INFO - 2018-05-22 03:16:04 --> Security Class Initialized
DEBUG - 2018-05-22 03:16:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 03:16:04 --> Input Class Initialized
INFO - 2018-05-22 03:16:04 --> Language Class Initialized
INFO - 2018-05-22 03:16:04 --> Language Class Initialized
INFO - 2018-05-22 03:16:04 --> Config Class Initialized
INFO - 2018-05-22 03:16:04 --> Loader Class Initialized
DEBUG - 2018-05-22 03:16:04 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 03:16:04 --> Helper loaded: url_helper
INFO - 2018-05-22 03:16:04 --> Helper loaded: form_helper
INFO - 2018-05-22 03:16:04 --> Helper loaded: date_helper
INFO - 2018-05-22 03:16:04 --> Helper loaded: util_helper
INFO - 2018-05-22 03:16:04 --> Helper loaded: text_helper
INFO - 2018-05-22 03:16:04 --> Helper loaded: string_helper
INFO - 2018-05-22 03:16:04 --> Database Driver Class Initialized
DEBUG - 2018-05-22 03:16:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 03:16:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 03:16:04 --> Email Class Initialized
INFO - 2018-05-22 03:16:04 --> Controller Class Initialized
DEBUG - 2018-05-22 03:16:04 --> Profile MX_Controller Initialized
DEBUG - 2018-05-22 03:16:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 03:16:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 03:16:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-22 03:16:04 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 03:16:04 --> Login MX_Controller Initialized
INFO - 2018-05-22 03:16:04 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 03:16:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-22 03:16:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-22 03:16:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-22 03:16:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-22 03:16:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-05-22 03:16:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-22 03:16:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-22 03:16:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/email_preferences.php
INFO - 2018-05-22 03:16:04 --> Final output sent to browser
DEBUG - 2018-05-22 03:16:04 --> Total execution time: 0.6669
INFO - 2018-05-22 03:16:05 --> Config Class Initialized
INFO - 2018-05-22 03:16:05 --> Hooks Class Initialized
DEBUG - 2018-05-22 03:16:05 --> UTF-8 Support Enabled
INFO - 2018-05-22 03:16:05 --> Utf8 Class Initialized
INFO - 2018-05-22 03:16:05 --> URI Class Initialized
INFO - 2018-05-22 03:16:05 --> Router Class Initialized
INFO - 2018-05-22 03:16:05 --> Output Class Initialized
INFO - 2018-05-22 03:16:05 --> Security Class Initialized
DEBUG - 2018-05-22 03:16:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 03:16:05 --> Input Class Initialized
INFO - 2018-05-22 03:16:05 --> Language Class Initialized
ERROR - 2018-05-22 03:16:05 --> 404 Page Not Found: /index
INFO - 2018-05-22 03:16:05 --> Config Class Initialized
INFO - 2018-05-22 03:16:05 --> Hooks Class Initialized
DEBUG - 2018-05-22 03:16:05 --> UTF-8 Support Enabled
INFO - 2018-05-22 03:16:05 --> Utf8 Class Initialized
INFO - 2018-05-22 03:16:05 --> URI Class Initialized
INFO - 2018-05-22 03:16:05 --> Router Class Initialized
INFO - 2018-05-22 03:16:05 --> Output Class Initialized
INFO - 2018-05-22 03:16:05 --> Security Class Initialized
DEBUG - 2018-05-22 03:16:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 03:16:05 --> Input Class Initialized
INFO - 2018-05-22 03:16:05 --> Language Class Initialized
ERROR - 2018-05-22 03:16:05 --> 404 Page Not Found: /index
INFO - 2018-05-22 03:16:05 --> Config Class Initialized
INFO - 2018-05-22 03:16:05 --> Hooks Class Initialized
DEBUG - 2018-05-22 03:16:06 --> UTF-8 Support Enabled
INFO - 2018-05-22 03:16:06 --> Utf8 Class Initialized
INFO - 2018-05-22 03:16:06 --> URI Class Initialized
INFO - 2018-05-22 03:16:06 --> Router Class Initialized
INFO - 2018-05-22 03:16:06 --> Output Class Initialized
INFO - 2018-05-22 03:16:06 --> Security Class Initialized
DEBUG - 2018-05-22 03:16:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 03:16:06 --> Input Class Initialized
INFO - 2018-05-22 03:16:06 --> Language Class Initialized
ERROR - 2018-05-22 03:16:06 --> 404 Page Not Found: /index
INFO - 2018-05-22 03:16:48 --> Config Class Initialized
INFO - 2018-05-22 03:16:48 --> Hooks Class Initialized
DEBUG - 2018-05-22 03:16:48 --> UTF-8 Support Enabled
INFO - 2018-05-22 03:16:48 --> Utf8 Class Initialized
INFO - 2018-05-22 03:16:48 --> URI Class Initialized
INFO - 2018-05-22 03:16:48 --> Router Class Initialized
INFO - 2018-05-22 03:16:48 --> Output Class Initialized
INFO - 2018-05-22 03:16:48 --> Security Class Initialized
DEBUG - 2018-05-22 03:16:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 03:16:48 --> Input Class Initialized
INFO - 2018-05-22 03:16:48 --> Language Class Initialized
INFO - 2018-05-22 03:16:48 --> Language Class Initialized
INFO - 2018-05-22 03:16:48 --> Config Class Initialized
INFO - 2018-05-22 03:16:48 --> Loader Class Initialized
DEBUG - 2018-05-22 03:16:48 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 03:16:48 --> Helper loaded: url_helper
INFO - 2018-05-22 03:16:48 --> Helper loaded: form_helper
INFO - 2018-05-22 03:16:48 --> Helper loaded: date_helper
INFO - 2018-05-22 03:16:48 --> Helper loaded: util_helper
INFO - 2018-05-22 03:16:48 --> Helper loaded: text_helper
INFO - 2018-05-22 03:16:48 --> Helper loaded: string_helper
INFO - 2018-05-22 03:16:48 --> Database Driver Class Initialized
DEBUG - 2018-05-22 03:16:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 03:16:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 03:16:48 --> Email Class Initialized
INFO - 2018-05-22 03:16:48 --> Controller Class Initialized
DEBUG - 2018-05-22 03:16:48 --> Profile MX_Controller Initialized
DEBUG - 2018-05-22 03:16:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 03:16:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 03:16:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-22 03:16:48 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 03:16:48 --> Login MX_Controller Initialized
INFO - 2018-05-22 03:16:48 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 03:16:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-22 03:16:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-22 03:16:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-22 03:16:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-22 03:16:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-05-22 03:16:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-22 03:16:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-22 03:16:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/billing.php
INFO - 2018-05-22 03:16:48 --> Final output sent to browser
DEBUG - 2018-05-22 03:16:48 --> Total execution time: 0.6656
INFO - 2018-05-22 03:16:49 --> Config Class Initialized
INFO - 2018-05-22 03:16:49 --> Hooks Class Initialized
DEBUG - 2018-05-22 03:16:49 --> UTF-8 Support Enabled
INFO - 2018-05-22 03:16:49 --> Utf8 Class Initialized
INFO - 2018-05-22 03:16:49 --> URI Class Initialized
INFO - 2018-05-22 03:16:49 --> Router Class Initialized
INFO - 2018-05-22 03:16:49 --> Output Class Initialized
INFO - 2018-05-22 03:16:49 --> Security Class Initialized
DEBUG - 2018-05-22 03:16:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 03:16:49 --> Input Class Initialized
INFO - 2018-05-22 03:16:49 --> Language Class Initialized
ERROR - 2018-05-22 03:16:49 --> 404 Page Not Found: /index
INFO - 2018-05-22 03:16:49 --> Config Class Initialized
INFO - 2018-05-22 03:16:50 --> Hooks Class Initialized
DEBUG - 2018-05-22 03:16:50 --> UTF-8 Support Enabled
INFO - 2018-05-22 03:16:50 --> Utf8 Class Initialized
INFO - 2018-05-22 03:16:50 --> URI Class Initialized
INFO - 2018-05-22 03:16:50 --> Router Class Initialized
INFO - 2018-05-22 03:16:50 --> Output Class Initialized
INFO - 2018-05-22 03:16:50 --> Security Class Initialized
DEBUG - 2018-05-22 03:16:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 03:16:50 --> Input Class Initialized
INFO - 2018-05-22 03:16:50 --> Language Class Initialized
ERROR - 2018-05-22 03:16:50 --> 404 Page Not Found: /index
INFO - 2018-05-22 03:16:50 --> Config Class Initialized
INFO - 2018-05-22 03:16:50 --> Hooks Class Initialized
DEBUG - 2018-05-22 03:16:50 --> UTF-8 Support Enabled
INFO - 2018-05-22 03:16:50 --> Utf8 Class Initialized
INFO - 2018-05-22 03:16:50 --> URI Class Initialized
INFO - 2018-05-22 03:16:50 --> Router Class Initialized
INFO - 2018-05-22 03:16:50 --> Output Class Initialized
INFO - 2018-05-22 03:16:50 --> Security Class Initialized
DEBUG - 2018-05-22 03:16:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 03:16:50 --> Input Class Initialized
INFO - 2018-05-22 03:16:50 --> Language Class Initialized
ERROR - 2018-05-22 03:16:50 --> 404 Page Not Found: /index
INFO - 2018-05-22 04:36:03 --> Config Class Initialized
INFO - 2018-05-22 04:36:03 --> Hooks Class Initialized
DEBUG - 2018-05-22 04:36:03 --> UTF-8 Support Enabled
INFO - 2018-05-22 04:36:03 --> Utf8 Class Initialized
INFO - 2018-05-22 04:36:03 --> URI Class Initialized
INFO - 2018-05-22 04:36:03 --> Router Class Initialized
INFO - 2018-05-22 04:36:03 --> Output Class Initialized
INFO - 2018-05-22 04:36:03 --> Security Class Initialized
DEBUG - 2018-05-22 04:36:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 04:36:03 --> Input Class Initialized
INFO - 2018-05-22 04:36:03 --> Language Class Initialized
INFO - 2018-05-22 04:36:03 --> Language Class Initialized
INFO - 2018-05-22 04:36:03 --> Config Class Initialized
INFO - 2018-05-22 04:36:03 --> Loader Class Initialized
DEBUG - 2018-05-22 04:36:03 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 04:36:03 --> Helper loaded: url_helper
INFO - 2018-05-22 04:36:03 --> Helper loaded: form_helper
INFO - 2018-05-22 04:36:03 --> Helper loaded: date_helper
INFO - 2018-05-22 04:36:03 --> Helper loaded: util_helper
INFO - 2018-05-22 04:36:03 --> Helper loaded: text_helper
INFO - 2018-05-22 04:36:03 --> Helper loaded: string_helper
INFO - 2018-05-22 04:36:03 --> Database Driver Class Initialized
DEBUG - 2018-05-22 04:36:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 04:36:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 04:36:03 --> Email Class Initialized
INFO - 2018-05-22 04:36:03 --> Controller Class Initialized
DEBUG - 2018-05-22 04:36:03 --> Home MX_Controller Initialized
DEBUG - 2018-05-22 04:36:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 04:36:03 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 04:36:03 --> Login MX_Controller Initialized
INFO - 2018-05-22 04:36:03 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 04:36:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 04:36:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-22 04:36:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-22 04:36:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-22 04:36:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-22 04:36:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-22 04:36:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-22 04:36:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-05-22 04:36:03 --> Final output sent to browser
DEBUG - 2018-05-22 04:36:03 --> Total execution time: 0.8930
INFO - 2018-05-22 04:36:04 --> Config Class Initialized
INFO - 2018-05-22 04:36:04 --> Hooks Class Initialized
INFO - 2018-05-22 04:36:04 --> Config Class Initialized
INFO - 2018-05-22 04:36:04 --> Hooks Class Initialized
DEBUG - 2018-05-22 04:36:04 --> UTF-8 Support Enabled
INFO - 2018-05-22 04:36:04 --> Utf8 Class Initialized
DEBUG - 2018-05-22 04:36:04 --> UTF-8 Support Enabled
INFO - 2018-05-22 04:36:04 --> Utf8 Class Initialized
INFO - 2018-05-22 04:36:04 --> URI Class Initialized
INFO - 2018-05-22 04:36:04 --> URI Class Initialized
INFO - 2018-05-22 04:36:04 --> Router Class Initialized
INFO - 2018-05-22 04:36:05 --> Output Class Initialized
INFO - 2018-05-22 04:36:05 --> Router Class Initialized
INFO - 2018-05-22 04:36:05 --> Security Class Initialized
INFO - 2018-05-22 04:36:05 --> Output Class Initialized
DEBUG - 2018-05-22 04:36:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 04:36:05 --> Security Class Initialized
INFO - 2018-05-22 04:36:05 --> Input Class Initialized
INFO - 2018-05-22 04:36:05 --> Language Class Initialized
DEBUG - 2018-05-22 04:36:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-05-22 04:36:05 --> 404 Page Not Found: /index
INFO - 2018-05-22 04:36:05 --> Input Class Initialized
INFO - 2018-05-22 04:36:05 --> Language Class Initialized
ERROR - 2018-05-22 04:36:05 --> 404 Page Not Found: /index
INFO - 2018-05-22 04:36:05 --> Config Class Initialized
INFO - 2018-05-22 04:36:05 --> Hooks Class Initialized
DEBUG - 2018-05-22 04:36:05 --> UTF-8 Support Enabled
INFO - 2018-05-22 04:36:05 --> Utf8 Class Initialized
INFO - 2018-05-22 04:36:05 --> URI Class Initialized
INFO - 2018-05-22 04:36:05 --> Router Class Initialized
INFO - 2018-05-22 04:36:05 --> Output Class Initialized
INFO - 2018-05-22 04:36:05 --> Security Class Initialized
DEBUG - 2018-05-22 04:36:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 04:36:05 --> Input Class Initialized
INFO - 2018-05-22 04:36:05 --> Language Class Initialized
ERROR - 2018-05-22 04:36:05 --> 404 Page Not Found: /index
INFO - 2018-05-22 04:36:05 --> Config Class Initialized
INFO - 2018-05-22 04:36:05 --> Hooks Class Initialized
DEBUG - 2018-05-22 04:36:05 --> UTF-8 Support Enabled
INFO - 2018-05-22 04:36:05 --> Utf8 Class Initialized
INFO - 2018-05-22 04:36:05 --> URI Class Initialized
INFO - 2018-05-22 04:36:05 --> Router Class Initialized
INFO - 2018-05-22 04:36:05 --> Output Class Initialized
INFO - 2018-05-22 04:36:05 --> Security Class Initialized
DEBUG - 2018-05-22 04:36:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 04:36:05 --> Input Class Initialized
INFO - 2018-05-22 04:36:05 --> Language Class Initialized
ERROR - 2018-05-22 04:36:05 --> 404 Page Not Found: /index
INFO - 2018-05-22 04:36:15 --> Config Class Initialized
INFO - 2018-05-22 04:36:15 --> Hooks Class Initialized
DEBUG - 2018-05-22 04:36:15 --> UTF-8 Support Enabled
INFO - 2018-05-22 04:36:15 --> Utf8 Class Initialized
INFO - 2018-05-22 04:36:15 --> URI Class Initialized
INFO - 2018-05-22 04:36:15 --> Router Class Initialized
INFO - 2018-05-22 04:36:15 --> Output Class Initialized
INFO - 2018-05-22 04:36:15 --> Security Class Initialized
DEBUG - 2018-05-22 04:36:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 04:36:15 --> Input Class Initialized
INFO - 2018-05-22 04:36:15 --> Language Class Initialized
ERROR - 2018-05-22 04:36:15 --> 404 Page Not Found: /index
INFO - 2018-05-22 04:36:15 --> Config Class Initialized
INFO - 2018-05-22 04:36:15 --> Hooks Class Initialized
DEBUG - 2018-05-22 04:36:15 --> UTF-8 Support Enabled
INFO - 2018-05-22 04:36:16 --> Utf8 Class Initialized
INFO - 2018-05-22 04:36:16 --> URI Class Initialized
INFO - 2018-05-22 04:36:16 --> Router Class Initialized
INFO - 2018-05-22 04:36:16 --> Output Class Initialized
INFO - 2018-05-22 04:36:16 --> Security Class Initialized
DEBUG - 2018-05-22 04:36:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 04:36:16 --> Input Class Initialized
INFO - 2018-05-22 04:36:16 --> Language Class Initialized
ERROR - 2018-05-22 04:36:16 --> 404 Page Not Found: /index
INFO - 2018-05-22 04:36:16 --> Config Class Initialized
INFO - 2018-05-22 04:36:16 --> Hooks Class Initialized
DEBUG - 2018-05-22 04:36:16 --> UTF-8 Support Enabled
INFO - 2018-05-22 04:36:16 --> Utf8 Class Initialized
INFO - 2018-05-22 04:36:16 --> URI Class Initialized
INFO - 2018-05-22 04:36:16 --> Router Class Initialized
INFO - 2018-05-22 04:36:16 --> Output Class Initialized
INFO - 2018-05-22 04:36:16 --> Security Class Initialized
DEBUG - 2018-05-22 04:36:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 04:36:16 --> Input Class Initialized
INFO - 2018-05-22 04:36:16 --> Language Class Initialized
ERROR - 2018-05-22 04:36:16 --> 404 Page Not Found: /index
INFO - 2018-05-22 04:39:27 --> Config Class Initialized
INFO - 2018-05-22 04:39:27 --> Hooks Class Initialized
DEBUG - 2018-05-22 04:39:27 --> UTF-8 Support Enabled
INFO - 2018-05-22 04:39:27 --> Utf8 Class Initialized
INFO - 2018-05-22 04:39:27 --> URI Class Initialized
INFO - 2018-05-22 04:39:27 --> Router Class Initialized
INFO - 2018-05-22 04:39:28 --> Output Class Initialized
INFO - 2018-05-22 04:39:28 --> Security Class Initialized
DEBUG - 2018-05-22 04:39:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 04:39:28 --> Input Class Initialized
INFO - 2018-05-22 04:39:28 --> Language Class Initialized
INFO - 2018-05-22 04:39:28 --> Language Class Initialized
INFO - 2018-05-22 04:39:28 --> Config Class Initialized
INFO - 2018-05-22 04:39:28 --> Loader Class Initialized
DEBUG - 2018-05-22 04:39:28 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 04:39:28 --> Helper loaded: url_helper
INFO - 2018-05-22 04:39:28 --> Helper loaded: form_helper
INFO - 2018-05-22 04:39:28 --> Helper loaded: date_helper
INFO - 2018-05-22 04:39:28 --> Helper loaded: util_helper
INFO - 2018-05-22 04:39:28 --> Helper loaded: text_helper
INFO - 2018-05-22 04:39:28 --> Helper loaded: string_helper
INFO - 2018-05-22 04:39:28 --> Database Driver Class Initialized
DEBUG - 2018-05-22 04:39:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 04:39:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 04:39:28 --> Email Class Initialized
INFO - 2018-05-22 04:39:28 --> Controller Class Initialized
DEBUG - 2018-05-22 04:39:28 --> Profile MX_Controller Initialized
DEBUG - 2018-05-22 04:39:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 04:39:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 04:39:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-22 04:39:28 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 04:39:28 --> Login MX_Controller Initialized
INFO - 2018-05-22 04:39:28 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 04:39:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-22 04:39:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-22 04:39:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-22 04:39:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-22 04:39:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-05-22 04:39:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-22 04:39:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-22 04:39:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/billing.php
INFO - 2018-05-22 04:39:28 --> Final output sent to browser
DEBUG - 2018-05-22 04:39:28 --> Total execution time: 0.6882
INFO - 2018-05-22 04:39:30 --> Config Class Initialized
INFO - 2018-05-22 04:39:30 --> Hooks Class Initialized
DEBUG - 2018-05-22 04:39:30 --> UTF-8 Support Enabled
INFO - 2018-05-22 04:39:30 --> Utf8 Class Initialized
INFO - 2018-05-22 04:39:30 --> URI Class Initialized
INFO - 2018-05-22 04:39:30 --> Router Class Initialized
INFO - 2018-05-22 04:39:30 --> Output Class Initialized
INFO - 2018-05-22 04:39:30 --> Security Class Initialized
DEBUG - 2018-05-22 04:39:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 04:39:30 --> Input Class Initialized
INFO - 2018-05-22 04:39:30 --> Language Class Initialized
ERROR - 2018-05-22 04:39:30 --> 404 Page Not Found: /index
INFO - 2018-05-22 04:39:30 --> Config Class Initialized
INFO - 2018-05-22 04:39:30 --> Hooks Class Initialized
DEBUG - 2018-05-22 04:39:30 --> UTF-8 Support Enabled
INFO - 2018-05-22 04:39:30 --> Utf8 Class Initialized
INFO - 2018-05-22 04:39:30 --> URI Class Initialized
INFO - 2018-05-22 04:39:30 --> Router Class Initialized
INFO - 2018-05-22 04:39:30 --> Output Class Initialized
INFO - 2018-05-22 04:39:30 --> Security Class Initialized
DEBUG - 2018-05-22 04:39:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 04:39:30 --> Input Class Initialized
INFO - 2018-05-22 04:39:30 --> Language Class Initialized
ERROR - 2018-05-22 04:39:30 --> 404 Page Not Found: /index
INFO - 2018-05-22 04:39:30 --> Config Class Initialized
INFO - 2018-05-22 04:39:30 --> Hooks Class Initialized
DEBUG - 2018-05-22 04:39:31 --> UTF-8 Support Enabled
INFO - 2018-05-22 04:39:31 --> Utf8 Class Initialized
INFO - 2018-05-22 04:39:31 --> URI Class Initialized
INFO - 2018-05-22 04:39:31 --> Router Class Initialized
INFO - 2018-05-22 04:39:31 --> Output Class Initialized
INFO - 2018-05-22 04:39:31 --> Security Class Initialized
DEBUG - 2018-05-22 04:39:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 04:39:31 --> Input Class Initialized
INFO - 2018-05-22 04:39:31 --> Language Class Initialized
ERROR - 2018-05-22 04:39:31 --> 404 Page Not Found: /index
INFO - 2018-05-22 05:32:59 --> Config Class Initialized
INFO - 2018-05-22 05:32:59 --> Hooks Class Initialized
DEBUG - 2018-05-22 05:32:59 --> UTF-8 Support Enabled
INFO - 2018-05-22 05:32:59 --> Utf8 Class Initialized
INFO - 2018-05-22 05:32:59 --> URI Class Initialized
INFO - 2018-05-22 05:32:59 --> Router Class Initialized
INFO - 2018-05-22 05:32:59 --> Output Class Initialized
INFO - 2018-05-22 05:32:59 --> Security Class Initialized
DEBUG - 2018-05-22 05:32:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 05:32:59 --> Input Class Initialized
INFO - 2018-05-22 05:32:59 --> Language Class Initialized
INFO - 2018-05-22 05:32:59 --> Language Class Initialized
INFO - 2018-05-22 05:32:59 --> Config Class Initialized
INFO - 2018-05-22 05:32:59 --> Loader Class Initialized
DEBUG - 2018-05-22 05:32:59 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 05:32:59 --> Helper loaded: url_helper
INFO - 2018-05-22 05:32:59 --> Helper loaded: form_helper
INFO - 2018-05-22 05:32:59 --> Helper loaded: date_helper
INFO - 2018-05-22 05:32:59 --> Helper loaded: util_helper
INFO - 2018-05-22 05:32:59 --> Helper loaded: text_helper
INFO - 2018-05-22 05:32:59 --> Helper loaded: string_helper
INFO - 2018-05-22 05:32:59 --> Database Driver Class Initialized
DEBUG - 2018-05-22 05:32:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 05:32:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 05:32:59 --> Email Class Initialized
INFO - 2018-05-22 05:32:59 --> Controller Class Initialized
DEBUG - 2018-05-22 05:32:59 --> Profile MX_Controller Initialized
DEBUG - 2018-05-22 05:32:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 05:32:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 05:32:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-22 05:32:59 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 05:32:59 --> Login MX_Controller Initialized
INFO - 2018-05-22 05:32:59 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 05:32:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-22 05:32:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-22 05:32:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-22 05:32:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-22 05:32:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-05-22 05:32:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-22 05:32:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-22 05:33:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/profile.php
INFO - 2018-05-22 05:33:00 --> Final output sent to browser
DEBUG - 2018-05-22 05:33:00 --> Total execution time: 0.6832
INFO - 2018-05-22 05:33:01 --> Config Class Initialized
INFO - 2018-05-22 05:33:01 --> Hooks Class Initialized
DEBUG - 2018-05-22 05:33:01 --> UTF-8 Support Enabled
INFO - 2018-05-22 05:33:01 --> Utf8 Class Initialized
INFO - 2018-05-22 05:33:01 --> URI Class Initialized
INFO - 2018-05-22 05:33:01 --> Router Class Initialized
INFO - 2018-05-22 05:33:01 --> Output Class Initialized
INFO - 2018-05-22 05:33:01 --> Security Class Initialized
DEBUG - 2018-05-22 05:33:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 05:33:01 --> Input Class Initialized
INFO - 2018-05-22 05:33:01 --> Language Class Initialized
ERROR - 2018-05-22 05:33:01 --> 404 Page Not Found: /index
INFO - 2018-05-22 05:33:01 --> Config Class Initialized
INFO - 2018-05-22 05:33:02 --> Hooks Class Initialized
DEBUG - 2018-05-22 05:33:02 --> UTF-8 Support Enabled
INFO - 2018-05-22 05:33:02 --> Utf8 Class Initialized
INFO - 2018-05-22 05:33:02 --> URI Class Initialized
INFO - 2018-05-22 05:33:02 --> Router Class Initialized
INFO - 2018-05-22 05:33:02 --> Output Class Initialized
INFO - 2018-05-22 05:33:02 --> Security Class Initialized
DEBUG - 2018-05-22 05:33:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 05:33:02 --> Input Class Initialized
INFO - 2018-05-22 05:33:02 --> Language Class Initialized
ERROR - 2018-05-22 05:33:02 --> 404 Page Not Found: /index
INFO - 2018-05-22 05:33:02 --> Config Class Initialized
INFO - 2018-05-22 05:33:02 --> Hooks Class Initialized
DEBUG - 2018-05-22 05:33:02 --> UTF-8 Support Enabled
INFO - 2018-05-22 05:33:02 --> Utf8 Class Initialized
INFO - 2018-05-22 05:33:02 --> URI Class Initialized
INFO - 2018-05-22 05:33:02 --> Router Class Initialized
INFO - 2018-05-22 05:33:02 --> Output Class Initialized
INFO - 2018-05-22 05:33:02 --> Security Class Initialized
DEBUG - 2018-05-22 05:33:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 05:33:02 --> Input Class Initialized
INFO - 2018-05-22 05:33:02 --> Language Class Initialized
ERROR - 2018-05-22 05:33:02 --> 404 Page Not Found: /index
INFO - 2018-05-22 05:33:06 --> Config Class Initialized
INFO - 2018-05-22 05:33:06 --> Hooks Class Initialized
DEBUG - 2018-05-22 05:33:06 --> UTF-8 Support Enabled
INFO - 2018-05-22 05:33:06 --> Utf8 Class Initialized
INFO - 2018-05-22 05:33:06 --> URI Class Initialized
INFO - 2018-05-22 05:33:06 --> Router Class Initialized
INFO - 2018-05-22 05:33:06 --> Output Class Initialized
INFO - 2018-05-22 05:33:06 --> Security Class Initialized
DEBUG - 2018-05-22 05:33:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 05:33:06 --> Input Class Initialized
INFO - 2018-05-22 05:33:06 --> Language Class Initialized
INFO - 2018-05-22 05:33:06 --> Language Class Initialized
INFO - 2018-05-22 05:33:06 --> Config Class Initialized
INFO - 2018-05-22 05:33:06 --> Loader Class Initialized
DEBUG - 2018-05-22 05:33:06 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 05:33:06 --> Helper loaded: url_helper
INFO - 2018-05-22 05:33:06 --> Helper loaded: form_helper
INFO - 2018-05-22 05:33:06 --> Helper loaded: date_helper
INFO - 2018-05-22 05:33:06 --> Helper loaded: util_helper
INFO - 2018-05-22 05:33:06 --> Helper loaded: text_helper
INFO - 2018-05-22 05:33:06 --> Helper loaded: string_helper
INFO - 2018-05-22 05:33:06 --> Database Driver Class Initialized
DEBUG - 2018-05-22 05:33:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 05:33:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 05:33:06 --> Email Class Initialized
INFO - 2018-05-22 05:33:06 --> Controller Class Initialized
DEBUG - 2018-05-22 05:33:06 --> Profile MX_Controller Initialized
DEBUG - 2018-05-22 05:33:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 05:33:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 05:33:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-22 05:33:06 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 05:33:06 --> Login MX_Controller Initialized
INFO - 2018-05-22 05:33:06 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 05:33:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-22 05:33:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-22 05:33:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-22 05:33:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-22 05:33:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-05-22 05:33:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-22 05:33:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-22 05:33:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/addresses.php
INFO - 2018-05-22 05:33:06 --> Final output sent to browser
DEBUG - 2018-05-22 05:33:06 --> Total execution time: 0.7005
INFO - 2018-05-22 05:33:07 --> Config Class Initialized
INFO - 2018-05-22 05:33:07 --> Hooks Class Initialized
DEBUG - 2018-05-22 05:33:07 --> UTF-8 Support Enabled
INFO - 2018-05-22 05:33:07 --> Utf8 Class Initialized
INFO - 2018-05-22 05:33:07 --> URI Class Initialized
INFO - 2018-05-22 05:33:07 --> Router Class Initialized
INFO - 2018-05-22 05:33:07 --> Output Class Initialized
INFO - 2018-05-22 05:33:07 --> Security Class Initialized
DEBUG - 2018-05-22 05:33:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 05:33:07 --> Input Class Initialized
INFO - 2018-05-22 05:33:07 --> Language Class Initialized
ERROR - 2018-05-22 05:33:07 --> 404 Page Not Found: /index
INFO - 2018-05-22 05:33:07 --> Config Class Initialized
INFO - 2018-05-22 05:33:07 --> Hooks Class Initialized
DEBUG - 2018-05-22 05:33:08 --> UTF-8 Support Enabled
INFO - 2018-05-22 05:33:08 --> Utf8 Class Initialized
INFO - 2018-05-22 05:33:08 --> URI Class Initialized
INFO - 2018-05-22 05:33:08 --> Router Class Initialized
INFO - 2018-05-22 05:33:08 --> Output Class Initialized
INFO - 2018-05-22 05:33:08 --> Security Class Initialized
DEBUG - 2018-05-22 05:33:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 05:33:08 --> Input Class Initialized
INFO - 2018-05-22 05:33:08 --> Language Class Initialized
ERROR - 2018-05-22 05:33:08 --> 404 Page Not Found: /index
INFO - 2018-05-22 05:33:08 --> Config Class Initialized
INFO - 2018-05-22 05:33:08 --> Hooks Class Initialized
DEBUG - 2018-05-22 05:33:08 --> UTF-8 Support Enabled
INFO - 2018-05-22 05:33:08 --> Utf8 Class Initialized
INFO - 2018-05-22 05:33:08 --> URI Class Initialized
INFO - 2018-05-22 05:33:08 --> Router Class Initialized
INFO - 2018-05-22 05:33:08 --> Output Class Initialized
INFO - 2018-05-22 05:33:08 --> Security Class Initialized
DEBUG - 2018-05-22 05:33:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 05:33:08 --> Input Class Initialized
INFO - 2018-05-22 05:33:08 --> Language Class Initialized
ERROR - 2018-05-22 05:33:08 --> 404 Page Not Found: /index
INFO - 2018-05-22 05:33:09 --> Config Class Initialized
INFO - 2018-05-22 05:33:09 --> Hooks Class Initialized
DEBUG - 2018-05-22 05:33:09 --> UTF-8 Support Enabled
INFO - 2018-05-22 05:33:09 --> Utf8 Class Initialized
INFO - 2018-05-22 05:33:09 --> URI Class Initialized
INFO - 2018-05-22 05:33:09 --> Router Class Initialized
INFO - 2018-05-22 05:33:09 --> Output Class Initialized
INFO - 2018-05-22 05:33:09 --> Security Class Initialized
DEBUG - 2018-05-22 05:33:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 05:33:09 --> Input Class Initialized
INFO - 2018-05-22 05:33:09 --> Language Class Initialized
ERROR - 2018-05-22 05:33:09 --> 404 Page Not Found: /index
INFO - 2018-05-22 05:33:09 --> Config Class Initialized
INFO - 2018-05-22 05:33:09 --> Hooks Class Initialized
DEBUG - 2018-05-22 05:33:09 --> UTF-8 Support Enabled
INFO - 2018-05-22 05:33:09 --> Utf8 Class Initialized
INFO - 2018-05-22 05:33:09 --> URI Class Initialized
INFO - 2018-05-22 05:33:09 --> Router Class Initialized
INFO - 2018-05-22 05:33:10 --> Output Class Initialized
INFO - 2018-05-22 05:33:10 --> Security Class Initialized
DEBUG - 2018-05-22 05:33:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 05:33:10 --> Input Class Initialized
INFO - 2018-05-22 05:33:10 --> Language Class Initialized
ERROR - 2018-05-22 05:33:10 --> 404 Page Not Found: /index
INFO - 2018-05-22 05:33:10 --> Config Class Initialized
INFO - 2018-05-22 05:33:10 --> Hooks Class Initialized
DEBUG - 2018-05-22 05:33:10 --> UTF-8 Support Enabled
INFO - 2018-05-22 05:33:10 --> Utf8 Class Initialized
INFO - 2018-05-22 05:33:10 --> URI Class Initialized
INFO - 2018-05-22 05:33:10 --> Router Class Initialized
INFO - 2018-05-22 05:33:10 --> Output Class Initialized
INFO - 2018-05-22 05:33:10 --> Security Class Initialized
DEBUG - 2018-05-22 05:33:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 05:33:10 --> Input Class Initialized
INFO - 2018-05-22 05:33:10 --> Language Class Initialized
ERROR - 2018-05-22 05:33:10 --> 404 Page Not Found: /index
INFO - 2018-05-22 05:41:28 --> Config Class Initialized
INFO - 2018-05-22 05:41:28 --> Hooks Class Initialized
DEBUG - 2018-05-22 05:41:28 --> UTF-8 Support Enabled
INFO - 2018-05-22 05:41:28 --> Utf8 Class Initialized
INFO - 2018-05-22 05:41:28 --> URI Class Initialized
INFO - 2018-05-22 05:41:28 --> Router Class Initialized
INFO - 2018-05-22 05:41:28 --> Output Class Initialized
INFO - 2018-05-22 05:41:28 --> Security Class Initialized
DEBUG - 2018-05-22 05:41:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 05:41:28 --> Input Class Initialized
INFO - 2018-05-22 05:41:29 --> Language Class Initialized
INFO - 2018-05-22 05:41:29 --> Language Class Initialized
INFO - 2018-05-22 05:41:29 --> Config Class Initialized
INFO - 2018-05-22 05:41:29 --> Loader Class Initialized
DEBUG - 2018-05-22 05:41:29 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 05:41:29 --> Helper loaded: url_helper
INFO - 2018-05-22 05:41:29 --> Helper loaded: form_helper
INFO - 2018-05-22 05:41:29 --> Helper loaded: date_helper
INFO - 2018-05-22 05:41:29 --> Helper loaded: util_helper
INFO - 2018-05-22 05:41:29 --> Helper loaded: text_helper
INFO - 2018-05-22 05:41:29 --> Helper loaded: string_helper
INFO - 2018-05-22 05:41:29 --> Database Driver Class Initialized
DEBUG - 2018-05-22 05:41:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 05:41:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 05:41:29 --> Email Class Initialized
INFO - 2018-05-22 05:41:29 --> Controller Class Initialized
DEBUG - 2018-05-22 05:41:29 --> Profile MX_Controller Initialized
DEBUG - 2018-05-22 05:41:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 05:41:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 05:41:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-22 05:41:29 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 05:41:29 --> Login MX_Controller Initialized
INFO - 2018-05-22 05:41:29 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 05:41:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-22 05:41:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-22 05:41:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-22 05:41:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-22 05:41:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-05-22 05:41:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-22 05:41:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-22 05:41:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/addresses.php
INFO - 2018-05-22 05:41:29 --> Final output sent to browser
DEBUG - 2018-05-22 05:41:29 --> Total execution time: 0.6877
INFO - 2018-05-22 05:41:30 --> Config Class Initialized
INFO - 2018-05-22 05:41:30 --> Hooks Class Initialized
DEBUG - 2018-05-22 05:41:30 --> UTF-8 Support Enabled
INFO - 2018-05-22 05:41:30 --> Utf8 Class Initialized
INFO - 2018-05-22 05:41:30 --> URI Class Initialized
INFO - 2018-05-22 05:41:30 --> Router Class Initialized
INFO - 2018-05-22 05:41:30 --> Output Class Initialized
INFO - 2018-05-22 05:41:30 --> Security Class Initialized
DEBUG - 2018-05-22 05:41:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 05:41:30 --> Input Class Initialized
INFO - 2018-05-22 05:41:30 --> Language Class Initialized
ERROR - 2018-05-22 05:41:30 --> 404 Page Not Found: /index
INFO - 2018-05-22 05:41:30 --> Config Class Initialized
INFO - 2018-05-22 05:41:30 --> Hooks Class Initialized
DEBUG - 2018-05-22 05:41:30 --> UTF-8 Support Enabled
INFO - 2018-05-22 05:41:30 --> Utf8 Class Initialized
INFO - 2018-05-22 05:41:30 --> URI Class Initialized
INFO - 2018-05-22 05:41:30 --> Router Class Initialized
INFO - 2018-05-22 05:41:30 --> Output Class Initialized
INFO - 2018-05-22 05:41:30 --> Security Class Initialized
DEBUG - 2018-05-22 05:41:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 05:41:30 --> Input Class Initialized
INFO - 2018-05-22 05:41:30 --> Language Class Initialized
ERROR - 2018-05-22 05:41:30 --> 404 Page Not Found: /index
INFO - 2018-05-22 05:41:30 --> Config Class Initialized
INFO - 2018-05-22 05:41:30 --> Hooks Class Initialized
DEBUG - 2018-05-22 05:41:30 --> UTF-8 Support Enabled
INFO - 2018-05-22 05:41:31 --> Utf8 Class Initialized
INFO - 2018-05-22 05:41:31 --> URI Class Initialized
INFO - 2018-05-22 05:41:31 --> Router Class Initialized
INFO - 2018-05-22 05:41:31 --> Output Class Initialized
INFO - 2018-05-22 05:41:31 --> Security Class Initialized
DEBUG - 2018-05-22 05:41:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 05:41:31 --> Input Class Initialized
INFO - 2018-05-22 05:41:31 --> Language Class Initialized
ERROR - 2018-05-22 05:41:31 --> 404 Page Not Found: /index
INFO - 2018-05-22 05:43:26 --> Config Class Initialized
INFO - 2018-05-22 05:43:26 --> Hooks Class Initialized
DEBUG - 2018-05-22 05:43:26 --> UTF-8 Support Enabled
INFO - 2018-05-22 05:43:26 --> Utf8 Class Initialized
INFO - 2018-05-22 05:43:26 --> URI Class Initialized
INFO - 2018-05-22 05:43:26 --> Router Class Initialized
INFO - 2018-05-22 05:43:26 --> Output Class Initialized
INFO - 2018-05-22 05:43:26 --> Security Class Initialized
DEBUG - 2018-05-22 05:43:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 05:43:26 --> Input Class Initialized
INFO - 2018-05-22 05:43:26 --> Language Class Initialized
INFO - 2018-05-22 05:43:26 --> Language Class Initialized
INFO - 2018-05-22 05:43:26 --> Config Class Initialized
INFO - 2018-05-22 05:43:26 --> Loader Class Initialized
DEBUG - 2018-05-22 05:43:26 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 05:43:26 --> Helper loaded: url_helper
INFO - 2018-05-22 05:43:26 --> Helper loaded: form_helper
INFO - 2018-05-22 05:43:26 --> Helper loaded: date_helper
INFO - 2018-05-22 05:43:26 --> Helper loaded: util_helper
INFO - 2018-05-22 05:43:26 --> Helper loaded: text_helper
INFO - 2018-05-22 05:43:26 --> Helper loaded: string_helper
INFO - 2018-05-22 05:43:26 --> Database Driver Class Initialized
DEBUG - 2018-05-22 05:43:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 05:43:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 05:43:26 --> Email Class Initialized
INFO - 2018-05-22 05:43:26 --> Controller Class Initialized
ERROR - 2018-05-22 05:43:26 --> 404 Page Not Found: ../modules/home/controllers/Profile/save_addresses
INFO - 2018-05-22 05:43:30 --> Config Class Initialized
INFO - 2018-05-22 05:43:30 --> Hooks Class Initialized
DEBUG - 2018-05-22 05:43:30 --> UTF-8 Support Enabled
INFO - 2018-05-22 05:43:30 --> Utf8 Class Initialized
INFO - 2018-05-22 05:43:30 --> URI Class Initialized
INFO - 2018-05-22 05:43:30 --> Router Class Initialized
INFO - 2018-05-22 05:43:30 --> Output Class Initialized
INFO - 2018-05-22 05:43:30 --> Security Class Initialized
DEBUG - 2018-05-22 05:43:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 05:43:30 --> Input Class Initialized
INFO - 2018-05-22 05:43:30 --> Language Class Initialized
INFO - 2018-05-22 05:43:30 --> Language Class Initialized
INFO - 2018-05-22 05:43:30 --> Config Class Initialized
INFO - 2018-05-22 05:43:30 --> Loader Class Initialized
DEBUG - 2018-05-22 05:43:30 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 05:43:30 --> Helper loaded: url_helper
INFO - 2018-05-22 05:43:30 --> Helper loaded: form_helper
INFO - 2018-05-22 05:43:30 --> Helper loaded: date_helper
INFO - 2018-05-22 05:43:30 --> Helper loaded: util_helper
INFO - 2018-05-22 05:43:30 --> Helper loaded: text_helper
INFO - 2018-05-22 05:43:30 --> Helper loaded: string_helper
INFO - 2018-05-22 05:43:30 --> Database Driver Class Initialized
DEBUG - 2018-05-22 05:43:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 05:43:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 05:43:30 --> Email Class Initialized
INFO - 2018-05-22 05:43:30 --> Controller Class Initialized
DEBUG - 2018-05-22 05:43:31 --> Profile MX_Controller Initialized
DEBUG - 2018-05-22 05:43:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 05:43:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 05:43:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-22 05:43:31 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 05:43:31 --> Login MX_Controller Initialized
INFO - 2018-05-22 05:43:31 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 05:43:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-22 05:43:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-22 05:43:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-22 05:43:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-22 05:43:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-05-22 05:43:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-22 05:43:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-22 05:43:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/addresses.php
INFO - 2018-05-22 05:43:31 --> Final output sent to browser
DEBUG - 2018-05-22 05:43:31 --> Total execution time: 0.8249
INFO - 2018-05-22 05:45:02 --> Config Class Initialized
INFO - 2018-05-22 05:45:02 --> Hooks Class Initialized
DEBUG - 2018-05-22 05:45:02 --> UTF-8 Support Enabled
INFO - 2018-05-22 05:45:02 --> Utf8 Class Initialized
INFO - 2018-05-22 05:45:02 --> URI Class Initialized
INFO - 2018-05-22 05:45:02 --> Router Class Initialized
INFO - 2018-05-22 05:45:02 --> Output Class Initialized
INFO - 2018-05-22 05:45:02 --> Security Class Initialized
DEBUG - 2018-05-22 05:45:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 05:45:02 --> Input Class Initialized
INFO - 2018-05-22 05:45:02 --> Language Class Initialized
INFO - 2018-05-22 05:45:02 --> Language Class Initialized
INFO - 2018-05-22 05:45:02 --> Config Class Initialized
INFO - 2018-05-22 05:45:02 --> Loader Class Initialized
DEBUG - 2018-05-22 05:45:02 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 05:45:02 --> Helper loaded: url_helper
INFO - 2018-05-22 05:45:02 --> Helper loaded: form_helper
INFO - 2018-05-22 05:45:02 --> Helper loaded: date_helper
INFO - 2018-05-22 05:45:02 --> Helper loaded: util_helper
INFO - 2018-05-22 05:45:02 --> Helper loaded: text_helper
INFO - 2018-05-22 05:45:02 --> Helper loaded: string_helper
INFO - 2018-05-22 05:45:02 --> Database Driver Class Initialized
DEBUG - 2018-05-22 05:45:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 05:45:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 05:45:02 --> Email Class Initialized
INFO - 2018-05-22 05:45:02 --> Controller Class Initialized
DEBUG - 2018-05-22 05:45:02 --> Home MX_Controller Initialized
DEBUG - 2018-05-22 05:45:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 05:45:03 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 05:45:03 --> Login MX_Controller Initialized
INFO - 2018-05-22 05:45:03 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 05:45:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 05:45:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-22 05:45:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-22 05:45:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-22 05:45:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-22 05:45:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-22 05:45:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-22 05:45:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/progress.php
INFO - 2018-05-22 05:45:03 --> Final output sent to browser
DEBUG - 2018-05-22 05:45:03 --> Total execution time: 0.8666
INFO - 2018-05-22 05:45:03 --> Config Class Initialized
INFO - 2018-05-22 05:45:03 --> Hooks Class Initialized
DEBUG - 2018-05-22 05:45:03 --> UTF-8 Support Enabled
INFO - 2018-05-22 05:45:03 --> Utf8 Class Initialized
INFO - 2018-05-22 05:45:03 --> URI Class Initialized
INFO - 2018-05-22 05:45:03 --> Router Class Initialized
INFO - 2018-05-22 05:45:03 --> Output Class Initialized
INFO - 2018-05-22 05:45:04 --> Security Class Initialized
DEBUG - 2018-05-22 05:45:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 05:45:04 --> Input Class Initialized
INFO - 2018-05-22 05:45:04 --> Language Class Initialized
ERROR - 2018-05-22 05:45:04 --> 404 Page Not Found: /index
INFO - 2018-05-22 05:45:04 --> Config Class Initialized
INFO - 2018-05-22 05:45:04 --> Hooks Class Initialized
DEBUG - 2018-05-22 05:45:04 --> UTF-8 Support Enabled
INFO - 2018-05-22 05:45:04 --> Utf8 Class Initialized
INFO - 2018-05-22 05:45:04 --> URI Class Initialized
INFO - 2018-05-22 05:45:04 --> Router Class Initialized
INFO - 2018-05-22 05:45:04 --> Output Class Initialized
INFO - 2018-05-22 05:45:04 --> Security Class Initialized
DEBUG - 2018-05-22 05:45:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 05:45:04 --> Input Class Initialized
INFO - 2018-05-22 05:45:04 --> Language Class Initialized
ERROR - 2018-05-22 05:45:04 --> 404 Page Not Found: /index
INFO - 2018-05-22 05:45:04 --> Config Class Initialized
INFO - 2018-05-22 05:45:04 --> Hooks Class Initialized
DEBUG - 2018-05-22 05:45:04 --> UTF-8 Support Enabled
INFO - 2018-05-22 05:45:04 --> Utf8 Class Initialized
INFO - 2018-05-22 05:45:04 --> URI Class Initialized
INFO - 2018-05-22 05:45:04 --> Router Class Initialized
INFO - 2018-05-22 05:45:04 --> Output Class Initialized
INFO - 2018-05-22 05:45:04 --> Security Class Initialized
DEBUG - 2018-05-22 05:45:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 05:45:04 --> Input Class Initialized
INFO - 2018-05-22 05:45:04 --> Language Class Initialized
ERROR - 2018-05-22 05:45:04 --> 404 Page Not Found: /index
INFO - 2018-05-22 05:45:09 --> Config Class Initialized
INFO - 2018-05-22 05:45:09 --> Hooks Class Initialized
DEBUG - 2018-05-22 05:45:09 --> UTF-8 Support Enabled
INFO - 2018-05-22 05:45:09 --> Utf8 Class Initialized
INFO - 2018-05-22 05:45:09 --> URI Class Initialized
INFO - 2018-05-22 05:45:09 --> Router Class Initialized
INFO - 2018-05-22 05:45:09 --> Output Class Initialized
INFO - 2018-05-22 05:45:09 --> Security Class Initialized
DEBUG - 2018-05-22 05:45:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 05:45:09 --> Input Class Initialized
INFO - 2018-05-22 05:45:09 --> Language Class Initialized
INFO - 2018-05-22 05:45:09 --> Language Class Initialized
INFO - 2018-05-22 05:45:09 --> Config Class Initialized
INFO - 2018-05-22 05:45:09 --> Loader Class Initialized
DEBUG - 2018-05-22 05:45:09 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 05:45:09 --> Helper loaded: url_helper
INFO - 2018-05-22 05:45:09 --> Helper loaded: form_helper
INFO - 2018-05-22 05:45:09 --> Helper loaded: date_helper
INFO - 2018-05-22 05:45:09 --> Helper loaded: util_helper
INFO - 2018-05-22 05:45:09 --> Helper loaded: text_helper
INFO - 2018-05-22 05:45:09 --> Helper loaded: string_helper
INFO - 2018-05-22 05:45:09 --> Database Driver Class Initialized
DEBUG - 2018-05-22 05:45:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 05:45:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 05:45:09 --> Email Class Initialized
INFO - 2018-05-22 05:45:09 --> Controller Class Initialized
DEBUG - 2018-05-22 05:45:09 --> Home MX_Controller Initialized
DEBUG - 2018-05-22 05:45:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 05:45:10 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 05:45:10 --> Login MX_Controller Initialized
INFO - 2018-05-22 05:45:10 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 05:45:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 05:45:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-22 05:45:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-22 05:45:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-22 05:45:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-22 05:45:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-22 05:45:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-22 05:45:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/progress_product.php
INFO - 2018-05-22 05:45:10 --> Final output sent to browser
DEBUG - 2018-05-22 05:45:10 --> Total execution time: 0.6772
INFO - 2018-05-22 05:45:10 --> Config Class Initialized
INFO - 2018-05-22 05:45:10 --> Hooks Class Initialized
DEBUG - 2018-05-22 05:45:10 --> UTF-8 Support Enabled
INFO - 2018-05-22 05:45:10 --> Utf8 Class Initialized
INFO - 2018-05-22 05:45:10 --> URI Class Initialized
INFO - 2018-05-22 05:45:10 --> Router Class Initialized
INFO - 2018-05-22 05:45:10 --> Output Class Initialized
INFO - 2018-05-22 05:45:10 --> Security Class Initialized
DEBUG - 2018-05-22 05:45:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 05:45:10 --> Input Class Initialized
INFO - 2018-05-22 05:45:10 --> Language Class Initialized
ERROR - 2018-05-22 05:45:10 --> 404 Page Not Found: /index
INFO - 2018-05-22 05:45:11 --> Config Class Initialized
INFO - 2018-05-22 05:45:11 --> Hooks Class Initialized
DEBUG - 2018-05-22 05:45:11 --> UTF-8 Support Enabled
INFO - 2018-05-22 05:45:11 --> Utf8 Class Initialized
INFO - 2018-05-22 05:45:11 --> URI Class Initialized
INFO - 2018-05-22 05:45:11 --> Router Class Initialized
INFO - 2018-05-22 05:45:11 --> Output Class Initialized
INFO - 2018-05-22 05:45:11 --> Security Class Initialized
DEBUG - 2018-05-22 05:45:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 05:45:11 --> Input Class Initialized
INFO - 2018-05-22 05:45:11 --> Language Class Initialized
ERROR - 2018-05-22 05:45:11 --> 404 Page Not Found: /index
INFO - 2018-05-22 05:45:11 --> Config Class Initialized
INFO - 2018-05-22 05:45:11 --> Hooks Class Initialized
DEBUG - 2018-05-22 05:45:11 --> UTF-8 Support Enabled
INFO - 2018-05-22 05:45:11 --> Utf8 Class Initialized
INFO - 2018-05-22 05:45:11 --> URI Class Initialized
INFO - 2018-05-22 05:45:11 --> Router Class Initialized
INFO - 2018-05-22 05:45:11 --> Output Class Initialized
INFO - 2018-05-22 05:45:11 --> Security Class Initialized
DEBUG - 2018-05-22 05:45:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 05:45:11 --> Input Class Initialized
INFO - 2018-05-22 05:45:11 --> Language Class Initialized
ERROR - 2018-05-22 05:45:11 --> 404 Page Not Found: /index
INFO - 2018-05-22 05:45:34 --> Config Class Initialized
INFO - 2018-05-22 05:45:34 --> Hooks Class Initialized
DEBUG - 2018-05-22 05:45:34 --> UTF-8 Support Enabled
INFO - 2018-05-22 05:45:34 --> Utf8 Class Initialized
INFO - 2018-05-22 05:45:34 --> URI Class Initialized
INFO - 2018-05-22 05:45:34 --> Router Class Initialized
INFO - 2018-05-22 05:45:34 --> Output Class Initialized
INFO - 2018-05-22 05:45:34 --> Security Class Initialized
DEBUG - 2018-05-22 05:45:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 05:45:34 --> Input Class Initialized
INFO - 2018-05-22 05:45:34 --> Language Class Initialized
INFO - 2018-05-22 05:45:34 --> Language Class Initialized
INFO - 2018-05-22 05:45:34 --> Config Class Initialized
INFO - 2018-05-22 05:45:34 --> Loader Class Initialized
DEBUG - 2018-05-22 05:45:34 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 05:45:34 --> Helper loaded: url_helper
INFO - 2018-05-22 05:45:34 --> Helper loaded: form_helper
INFO - 2018-05-22 05:45:34 --> Helper loaded: date_helper
INFO - 2018-05-22 05:45:34 --> Helper loaded: util_helper
INFO - 2018-05-22 05:45:34 --> Helper loaded: text_helper
INFO - 2018-05-22 05:45:34 --> Helper loaded: string_helper
INFO - 2018-05-22 05:45:34 --> Database Driver Class Initialized
DEBUG - 2018-05-22 05:45:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 05:45:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 05:45:34 --> Email Class Initialized
INFO - 2018-05-22 05:45:34 --> Controller Class Initialized
DEBUG - 2018-05-22 05:45:34 --> Home MX_Controller Initialized
DEBUG - 2018-05-22 05:45:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 05:45:35 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 05:45:35 --> Login MX_Controller Initialized
INFO - 2018-05-22 05:45:35 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 05:45:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 05:45:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-22 05:45:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-22 05:45:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-22 05:45:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-22 05:45:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-22 05:45:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-22 05:45:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/progress_product.php
INFO - 2018-05-22 05:45:35 --> Final output sent to browser
DEBUG - 2018-05-22 05:45:35 --> Total execution time: 0.6608
INFO - 2018-05-22 05:45:35 --> Config Class Initialized
INFO - 2018-05-22 05:45:35 --> Hooks Class Initialized
DEBUG - 2018-05-22 05:45:35 --> UTF-8 Support Enabled
INFO - 2018-05-22 05:45:35 --> Utf8 Class Initialized
INFO - 2018-05-22 05:45:35 --> URI Class Initialized
INFO - 2018-05-22 05:45:35 --> Router Class Initialized
INFO - 2018-05-22 05:45:35 --> Output Class Initialized
INFO - 2018-05-22 05:45:35 --> Security Class Initialized
DEBUG - 2018-05-22 05:45:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 05:45:35 --> Input Class Initialized
INFO - 2018-05-22 05:45:35 --> Language Class Initialized
ERROR - 2018-05-22 05:45:35 --> 404 Page Not Found: /index
INFO - 2018-05-22 05:45:36 --> Config Class Initialized
INFO - 2018-05-22 05:45:36 --> Hooks Class Initialized
DEBUG - 2018-05-22 05:45:36 --> UTF-8 Support Enabled
INFO - 2018-05-22 05:45:36 --> Utf8 Class Initialized
INFO - 2018-05-22 05:45:36 --> URI Class Initialized
INFO - 2018-05-22 05:45:36 --> Router Class Initialized
INFO - 2018-05-22 05:45:36 --> Output Class Initialized
INFO - 2018-05-22 05:45:36 --> Security Class Initialized
DEBUG - 2018-05-22 05:45:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 05:45:36 --> Input Class Initialized
INFO - 2018-05-22 05:45:36 --> Language Class Initialized
ERROR - 2018-05-22 05:45:36 --> 404 Page Not Found: /index
INFO - 2018-05-22 05:45:36 --> Config Class Initialized
INFO - 2018-05-22 05:45:36 --> Hooks Class Initialized
DEBUG - 2018-05-22 05:45:36 --> UTF-8 Support Enabled
INFO - 2018-05-22 05:45:36 --> Utf8 Class Initialized
INFO - 2018-05-22 05:45:36 --> URI Class Initialized
INFO - 2018-05-22 05:45:36 --> Router Class Initialized
INFO - 2018-05-22 05:45:36 --> Output Class Initialized
INFO - 2018-05-22 05:45:36 --> Security Class Initialized
DEBUG - 2018-05-22 05:45:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 05:45:36 --> Input Class Initialized
INFO - 2018-05-22 05:45:36 --> Language Class Initialized
ERROR - 2018-05-22 05:45:36 --> 404 Page Not Found: /index
INFO - 2018-05-22 05:46:40 --> Config Class Initialized
INFO - 2018-05-22 05:46:40 --> Hooks Class Initialized
DEBUG - 2018-05-22 05:46:40 --> UTF-8 Support Enabled
INFO - 2018-05-22 05:46:41 --> Utf8 Class Initialized
INFO - 2018-05-22 05:46:41 --> URI Class Initialized
INFO - 2018-05-22 05:46:41 --> Router Class Initialized
INFO - 2018-05-22 05:46:41 --> Output Class Initialized
INFO - 2018-05-22 05:46:41 --> Security Class Initialized
DEBUG - 2018-05-22 05:46:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 05:46:41 --> Input Class Initialized
INFO - 2018-05-22 05:46:41 --> Language Class Initialized
INFO - 2018-05-22 05:46:41 --> Language Class Initialized
INFO - 2018-05-22 05:46:41 --> Config Class Initialized
INFO - 2018-05-22 05:46:41 --> Loader Class Initialized
DEBUG - 2018-05-22 05:46:41 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 05:46:41 --> Helper loaded: url_helper
INFO - 2018-05-22 05:46:41 --> Helper loaded: form_helper
INFO - 2018-05-22 05:46:41 --> Helper loaded: date_helper
INFO - 2018-05-22 05:46:41 --> Helper loaded: util_helper
INFO - 2018-05-22 05:46:41 --> Helper loaded: text_helper
INFO - 2018-05-22 05:46:41 --> Helper loaded: string_helper
INFO - 2018-05-22 05:46:41 --> Database Driver Class Initialized
DEBUG - 2018-05-22 05:46:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 05:46:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 05:46:41 --> Email Class Initialized
INFO - 2018-05-22 05:46:41 --> Controller Class Initialized
DEBUG - 2018-05-22 05:46:41 --> Home MX_Controller Initialized
DEBUG - 2018-05-22 05:46:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 05:46:41 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 05:46:41 --> Login MX_Controller Initialized
INFO - 2018-05-22 05:46:41 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 05:46:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 05:46:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-22 05:46:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-22 05:46:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-22 05:46:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-22 05:46:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-22 05:46:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-22 05:46:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/progress_product.php
INFO - 2018-05-22 05:46:41 --> Final output sent to browser
DEBUG - 2018-05-22 05:46:41 --> Total execution time: 0.7926
INFO - 2018-05-22 05:46:42 --> Config Class Initialized
INFO - 2018-05-22 05:46:42 --> Hooks Class Initialized
DEBUG - 2018-05-22 05:46:42 --> UTF-8 Support Enabled
INFO - 2018-05-22 05:46:42 --> Utf8 Class Initialized
INFO - 2018-05-22 05:46:42 --> URI Class Initialized
INFO - 2018-05-22 05:46:42 --> Router Class Initialized
INFO - 2018-05-22 05:46:42 --> Output Class Initialized
INFO - 2018-05-22 05:46:42 --> Security Class Initialized
DEBUG - 2018-05-22 05:46:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 05:46:42 --> Input Class Initialized
INFO - 2018-05-22 05:46:42 --> Language Class Initialized
ERROR - 2018-05-22 05:46:42 --> 404 Page Not Found: /index
INFO - 2018-05-22 05:46:42 --> Config Class Initialized
INFO - 2018-05-22 05:46:42 --> Hooks Class Initialized
DEBUG - 2018-05-22 05:46:42 --> UTF-8 Support Enabled
INFO - 2018-05-22 05:46:42 --> Utf8 Class Initialized
INFO - 2018-05-22 05:46:42 --> URI Class Initialized
INFO - 2018-05-22 05:46:42 --> Router Class Initialized
INFO - 2018-05-22 05:46:42 --> Output Class Initialized
INFO - 2018-05-22 05:46:42 --> Security Class Initialized
DEBUG - 2018-05-22 05:46:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 05:46:42 --> Input Class Initialized
INFO - 2018-05-22 05:46:43 --> Language Class Initialized
ERROR - 2018-05-22 05:46:43 --> 404 Page Not Found: /index
INFO - 2018-05-22 05:46:43 --> Config Class Initialized
INFO - 2018-05-22 05:46:43 --> Hooks Class Initialized
DEBUG - 2018-05-22 05:46:43 --> UTF-8 Support Enabled
INFO - 2018-05-22 05:46:43 --> Utf8 Class Initialized
INFO - 2018-05-22 05:46:43 --> URI Class Initialized
INFO - 2018-05-22 05:46:43 --> Router Class Initialized
INFO - 2018-05-22 05:46:43 --> Output Class Initialized
INFO - 2018-05-22 05:46:43 --> Security Class Initialized
DEBUG - 2018-05-22 05:46:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 05:46:43 --> Input Class Initialized
INFO - 2018-05-22 05:46:43 --> Language Class Initialized
ERROR - 2018-05-22 05:46:43 --> 404 Page Not Found: /index
INFO - 2018-05-22 05:53:36 --> Config Class Initialized
INFO - 2018-05-22 05:53:36 --> Hooks Class Initialized
DEBUG - 2018-05-22 05:53:36 --> UTF-8 Support Enabled
INFO - 2018-05-22 05:53:36 --> Utf8 Class Initialized
INFO - 2018-05-22 05:53:36 --> URI Class Initialized
INFO - 2018-05-22 05:53:36 --> Router Class Initialized
INFO - 2018-05-22 05:53:36 --> Output Class Initialized
INFO - 2018-05-22 05:53:36 --> Security Class Initialized
DEBUG - 2018-05-22 05:53:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 05:53:36 --> Input Class Initialized
INFO - 2018-05-22 05:53:36 --> Language Class Initialized
INFO - 2018-05-22 05:53:36 --> Language Class Initialized
INFO - 2018-05-22 05:53:36 --> Config Class Initialized
INFO - 2018-05-22 05:53:36 --> Loader Class Initialized
DEBUG - 2018-05-22 05:53:36 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 05:53:36 --> Helper loaded: url_helper
INFO - 2018-05-22 05:53:36 --> Helper loaded: form_helper
INFO - 2018-05-22 05:53:36 --> Helper loaded: date_helper
INFO - 2018-05-22 05:53:36 --> Helper loaded: util_helper
INFO - 2018-05-22 05:53:36 --> Helper loaded: text_helper
INFO - 2018-05-22 05:53:37 --> Helper loaded: string_helper
INFO - 2018-05-22 05:53:37 --> Database Driver Class Initialized
DEBUG - 2018-05-22 05:53:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 05:53:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 05:53:37 --> Email Class Initialized
INFO - 2018-05-22 05:53:37 --> Controller Class Initialized
DEBUG - 2018-05-22 05:53:37 --> Profile MX_Controller Initialized
DEBUG - 2018-05-22 05:53:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 05:53:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 05:53:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-22 05:53:37 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 05:53:37 --> Login MX_Controller Initialized
INFO - 2018-05-22 05:53:37 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 05:53:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-22 05:53:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-22 05:53:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-22 05:53:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-22 05:53:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-05-22 05:53:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-22 05:53:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-22 05:53:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/addresses.php
INFO - 2018-05-22 05:53:37 --> Final output sent to browser
DEBUG - 2018-05-22 05:53:37 --> Total execution time: 0.7177
INFO - 2018-05-22 05:53:37 --> Config Class Initialized
INFO - 2018-05-22 05:53:37 --> Hooks Class Initialized
DEBUG - 2018-05-22 05:53:37 --> UTF-8 Support Enabled
INFO - 2018-05-22 05:53:38 --> Utf8 Class Initialized
INFO - 2018-05-22 05:53:38 --> URI Class Initialized
INFO - 2018-05-22 05:53:38 --> Router Class Initialized
INFO - 2018-05-22 05:53:38 --> Output Class Initialized
INFO - 2018-05-22 05:53:38 --> Security Class Initialized
DEBUG - 2018-05-22 05:53:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 05:53:38 --> Input Class Initialized
INFO - 2018-05-22 05:53:38 --> Language Class Initialized
ERROR - 2018-05-22 05:53:38 --> 404 Page Not Found: /index
INFO - 2018-05-22 05:53:38 --> Config Class Initialized
INFO - 2018-05-22 05:53:38 --> Hooks Class Initialized
DEBUG - 2018-05-22 05:53:38 --> UTF-8 Support Enabled
INFO - 2018-05-22 05:53:38 --> Utf8 Class Initialized
INFO - 2018-05-22 05:53:38 --> URI Class Initialized
INFO - 2018-05-22 05:53:38 --> Router Class Initialized
INFO - 2018-05-22 05:53:38 --> Output Class Initialized
INFO - 2018-05-22 05:53:38 --> Security Class Initialized
DEBUG - 2018-05-22 05:53:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 05:53:38 --> Input Class Initialized
INFO - 2018-05-22 05:53:38 --> Language Class Initialized
ERROR - 2018-05-22 05:53:38 --> 404 Page Not Found: /index
INFO - 2018-05-22 05:53:38 --> Config Class Initialized
INFO - 2018-05-22 05:53:38 --> Hooks Class Initialized
DEBUG - 2018-05-22 05:53:38 --> UTF-8 Support Enabled
INFO - 2018-05-22 05:53:38 --> Utf8 Class Initialized
INFO - 2018-05-22 05:53:38 --> URI Class Initialized
INFO - 2018-05-22 05:53:38 --> Router Class Initialized
INFO - 2018-05-22 05:53:38 --> Output Class Initialized
INFO - 2018-05-22 05:53:38 --> Security Class Initialized
DEBUG - 2018-05-22 05:53:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 05:53:38 --> Input Class Initialized
INFO - 2018-05-22 05:53:38 --> Language Class Initialized
ERROR - 2018-05-22 05:53:38 --> 404 Page Not Found: /index
INFO - 2018-05-22 06:00:30 --> Config Class Initialized
INFO - 2018-05-22 06:00:30 --> Hooks Class Initialized
DEBUG - 2018-05-22 06:00:30 --> UTF-8 Support Enabled
INFO - 2018-05-22 06:00:30 --> Utf8 Class Initialized
INFO - 2018-05-22 06:00:30 --> URI Class Initialized
INFO - 2018-05-22 06:00:30 --> Router Class Initialized
INFO - 2018-05-22 06:00:30 --> Output Class Initialized
INFO - 2018-05-22 06:00:30 --> Security Class Initialized
DEBUG - 2018-05-22 06:00:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 06:00:30 --> Input Class Initialized
INFO - 2018-05-22 06:00:30 --> Language Class Initialized
INFO - 2018-05-22 06:00:30 --> Language Class Initialized
INFO - 2018-05-22 06:00:30 --> Config Class Initialized
INFO - 2018-05-22 06:00:30 --> Loader Class Initialized
DEBUG - 2018-05-22 06:00:30 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 06:00:30 --> Helper loaded: url_helper
INFO - 2018-05-22 06:00:30 --> Helper loaded: form_helper
INFO - 2018-05-22 06:00:30 --> Helper loaded: date_helper
INFO - 2018-05-22 06:00:30 --> Helper loaded: util_helper
INFO - 2018-05-22 06:00:30 --> Helper loaded: text_helper
INFO - 2018-05-22 06:00:30 --> Helper loaded: string_helper
INFO - 2018-05-22 06:00:30 --> Database Driver Class Initialized
DEBUG - 2018-05-22 06:00:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 06:00:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 06:00:30 --> Email Class Initialized
INFO - 2018-05-22 06:00:30 --> Controller Class Initialized
DEBUG - 2018-05-22 06:00:30 --> Profile MX_Controller Initialized
DEBUG - 2018-05-22 06:00:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 06:00:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 06:00:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-22 06:00:30 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 06:00:30 --> Login MX_Controller Initialized
INFO - 2018-05-22 06:00:30 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 06:00:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-22 06:00:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-22 06:00:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-22 06:00:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-22 06:00:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-05-22 06:00:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-22 06:00:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-22 06:00:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/addresses.php
INFO - 2018-05-22 06:00:30 --> Final output sent to browser
DEBUG - 2018-05-22 06:00:30 --> Total execution time: 0.7344
INFO - 2018-05-22 06:00:33 --> Config Class Initialized
INFO - 2018-05-22 06:00:33 --> Hooks Class Initialized
DEBUG - 2018-05-22 06:00:33 --> UTF-8 Support Enabled
INFO - 2018-05-22 06:00:33 --> Utf8 Class Initialized
INFO - 2018-05-22 06:00:33 --> URI Class Initialized
INFO - 2018-05-22 06:00:33 --> Router Class Initialized
INFO - 2018-05-22 06:00:33 --> Output Class Initialized
INFO - 2018-05-22 06:00:33 --> Security Class Initialized
DEBUG - 2018-05-22 06:00:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 06:00:33 --> Input Class Initialized
INFO - 2018-05-22 06:00:34 --> Language Class Initialized
ERROR - 2018-05-22 06:00:34 --> 404 Page Not Found: /index
INFO - 2018-05-22 06:00:34 --> Config Class Initialized
INFO - 2018-05-22 06:00:34 --> Hooks Class Initialized
DEBUG - 2018-05-22 06:00:34 --> UTF-8 Support Enabled
INFO - 2018-05-22 06:00:34 --> Utf8 Class Initialized
INFO - 2018-05-22 06:00:34 --> URI Class Initialized
INFO - 2018-05-22 06:00:34 --> Router Class Initialized
INFO - 2018-05-22 06:00:34 --> Output Class Initialized
INFO - 2018-05-22 06:00:34 --> Security Class Initialized
DEBUG - 2018-05-22 06:00:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 06:00:34 --> Input Class Initialized
INFO - 2018-05-22 06:00:34 --> Language Class Initialized
ERROR - 2018-05-22 06:00:34 --> 404 Page Not Found: /index
INFO - 2018-05-22 06:00:34 --> Config Class Initialized
INFO - 2018-05-22 06:00:34 --> Hooks Class Initialized
DEBUG - 2018-05-22 06:00:34 --> UTF-8 Support Enabled
INFO - 2018-05-22 06:00:34 --> Utf8 Class Initialized
INFO - 2018-05-22 06:00:34 --> URI Class Initialized
INFO - 2018-05-22 06:00:34 --> Router Class Initialized
INFO - 2018-05-22 06:00:34 --> Output Class Initialized
INFO - 2018-05-22 06:00:34 --> Security Class Initialized
DEBUG - 2018-05-22 06:00:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 06:00:34 --> Input Class Initialized
INFO - 2018-05-22 06:00:34 --> Language Class Initialized
ERROR - 2018-05-22 06:00:34 --> 404 Page Not Found: /index
INFO - 2018-05-22 06:00:41 --> Config Class Initialized
INFO - 2018-05-22 06:00:41 --> Hooks Class Initialized
DEBUG - 2018-05-22 06:00:41 --> UTF-8 Support Enabled
INFO - 2018-05-22 06:00:41 --> Utf8 Class Initialized
INFO - 2018-05-22 06:00:41 --> URI Class Initialized
INFO - 2018-05-22 06:00:41 --> Router Class Initialized
INFO - 2018-05-22 06:00:41 --> Output Class Initialized
INFO - 2018-05-22 06:00:41 --> Security Class Initialized
DEBUG - 2018-05-22 06:00:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 06:00:41 --> Input Class Initialized
INFO - 2018-05-22 06:00:41 --> Language Class Initialized
ERROR - 2018-05-22 06:00:41 --> 404 Page Not Found: /index
INFO - 2018-05-22 06:00:41 --> Config Class Initialized
INFO - 2018-05-22 06:00:41 --> Hooks Class Initialized
DEBUG - 2018-05-22 06:00:41 --> UTF-8 Support Enabled
INFO - 2018-05-22 06:00:41 --> Utf8 Class Initialized
INFO - 2018-05-22 06:00:41 --> URI Class Initialized
INFO - 2018-05-22 06:00:41 --> Router Class Initialized
INFO - 2018-05-22 06:00:41 --> Output Class Initialized
INFO - 2018-05-22 06:00:41 --> Security Class Initialized
DEBUG - 2018-05-22 06:00:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 06:00:41 --> Input Class Initialized
INFO - 2018-05-22 06:00:41 --> Language Class Initialized
ERROR - 2018-05-22 06:00:41 --> 404 Page Not Found: /index
INFO - 2018-05-22 06:00:41 --> Config Class Initialized
INFO - 2018-05-22 06:00:41 --> Hooks Class Initialized
DEBUG - 2018-05-22 06:00:41 --> UTF-8 Support Enabled
INFO - 2018-05-22 06:00:41 --> Utf8 Class Initialized
INFO - 2018-05-22 06:00:41 --> URI Class Initialized
INFO - 2018-05-22 06:00:41 --> Router Class Initialized
INFO - 2018-05-22 06:00:41 --> Output Class Initialized
INFO - 2018-05-22 06:00:41 --> Security Class Initialized
DEBUG - 2018-05-22 06:00:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 06:00:41 --> Input Class Initialized
INFO - 2018-05-22 06:00:41 --> Language Class Initialized
ERROR - 2018-05-22 06:00:41 --> 404 Page Not Found: /index
INFO - 2018-05-22 06:02:51 --> Config Class Initialized
INFO - 2018-05-22 06:02:51 --> Hooks Class Initialized
DEBUG - 2018-05-22 06:02:51 --> UTF-8 Support Enabled
INFO - 2018-05-22 06:02:51 --> Utf8 Class Initialized
INFO - 2018-05-22 06:02:51 --> URI Class Initialized
INFO - 2018-05-22 06:02:51 --> Router Class Initialized
INFO - 2018-05-22 06:02:51 --> Output Class Initialized
INFO - 2018-05-22 06:02:51 --> Security Class Initialized
DEBUG - 2018-05-22 06:02:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 06:02:51 --> Input Class Initialized
INFO - 2018-05-22 06:02:51 --> Language Class Initialized
INFO - 2018-05-22 06:02:51 --> Language Class Initialized
INFO - 2018-05-22 06:02:51 --> Config Class Initialized
INFO - 2018-05-22 06:02:51 --> Loader Class Initialized
DEBUG - 2018-05-22 06:02:51 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 06:02:51 --> Helper loaded: url_helper
INFO - 2018-05-22 06:02:51 --> Helper loaded: form_helper
INFO - 2018-05-22 06:02:51 --> Helper loaded: date_helper
INFO - 2018-05-22 06:02:51 --> Helper loaded: util_helper
INFO - 2018-05-22 06:02:51 --> Helper loaded: text_helper
INFO - 2018-05-22 06:02:51 --> Helper loaded: string_helper
INFO - 2018-05-22 06:02:51 --> Database Driver Class Initialized
DEBUG - 2018-05-22 06:02:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 06:02:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 06:02:52 --> Email Class Initialized
INFO - 2018-05-22 06:02:52 --> Controller Class Initialized
DEBUG - 2018-05-22 06:02:52 --> Profile MX_Controller Initialized
DEBUG - 2018-05-22 06:02:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 06:02:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 06:02:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-22 06:02:52 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 06:02:52 --> Login MX_Controller Initialized
INFO - 2018-05-22 06:02:52 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 06:02:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-22 06:02:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-22 06:02:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-22 06:02:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-22 06:02:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-05-22 06:02:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-22 06:02:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-22 06:02:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/addresses.php
INFO - 2018-05-22 06:02:52 --> Final output sent to browser
DEBUG - 2018-05-22 06:02:52 --> Total execution time: 0.7231
INFO - 2018-05-22 06:02:52 --> Config Class Initialized
INFO - 2018-05-22 06:02:52 --> Hooks Class Initialized
DEBUG - 2018-05-22 06:02:53 --> UTF-8 Support Enabled
INFO - 2018-05-22 06:02:53 --> Utf8 Class Initialized
INFO - 2018-05-22 06:02:53 --> URI Class Initialized
INFO - 2018-05-22 06:02:53 --> Router Class Initialized
INFO - 2018-05-22 06:02:53 --> Output Class Initialized
INFO - 2018-05-22 06:02:53 --> Security Class Initialized
DEBUG - 2018-05-22 06:02:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 06:02:53 --> Input Class Initialized
INFO - 2018-05-22 06:02:53 --> Language Class Initialized
ERROR - 2018-05-22 06:02:53 --> 404 Page Not Found: /index
INFO - 2018-05-22 06:02:53 --> Config Class Initialized
INFO - 2018-05-22 06:02:53 --> Hooks Class Initialized
DEBUG - 2018-05-22 06:02:53 --> UTF-8 Support Enabled
INFO - 2018-05-22 06:02:53 --> Utf8 Class Initialized
INFO - 2018-05-22 06:02:53 --> URI Class Initialized
INFO - 2018-05-22 06:02:53 --> Router Class Initialized
INFO - 2018-05-22 06:02:53 --> Output Class Initialized
INFO - 2018-05-22 06:02:53 --> Security Class Initialized
DEBUG - 2018-05-22 06:02:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 06:02:53 --> Input Class Initialized
INFO - 2018-05-22 06:02:53 --> Language Class Initialized
ERROR - 2018-05-22 06:02:53 --> 404 Page Not Found: /index
INFO - 2018-05-22 06:02:54 --> Config Class Initialized
INFO - 2018-05-22 06:02:54 --> Hooks Class Initialized
DEBUG - 2018-05-22 06:02:54 --> UTF-8 Support Enabled
INFO - 2018-05-22 06:02:54 --> Utf8 Class Initialized
INFO - 2018-05-22 06:02:54 --> URI Class Initialized
INFO - 2018-05-22 06:02:54 --> Router Class Initialized
INFO - 2018-05-22 06:02:54 --> Output Class Initialized
INFO - 2018-05-22 06:02:54 --> Security Class Initialized
DEBUG - 2018-05-22 06:02:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 06:02:54 --> Input Class Initialized
INFO - 2018-05-22 06:02:54 --> Language Class Initialized
ERROR - 2018-05-22 06:02:54 --> 404 Page Not Found: /index
INFO - 2018-05-22 21:28:48 --> Config Class Initialized
INFO - 2018-05-22 21:28:48 --> Hooks Class Initialized
DEBUG - 2018-05-22 21:28:48 --> UTF-8 Support Enabled
INFO - 2018-05-22 21:28:49 --> Utf8 Class Initialized
INFO - 2018-05-22 21:28:49 --> URI Class Initialized
INFO - 2018-05-22 21:28:49 --> Config Class Initialized
INFO - 2018-05-22 21:28:49 --> Hooks Class Initialized
DEBUG - 2018-05-22 21:28:49 --> UTF-8 Support Enabled
INFO - 2018-05-22 21:28:49 --> Utf8 Class Initialized
INFO - 2018-05-22 21:28:49 --> Router Class Initialized
INFO - 2018-05-22 21:28:49 --> URI Class Initialized
INFO - 2018-05-22 21:28:49 --> Router Class Initialized
INFO - 2018-05-22 21:28:49 --> Output Class Initialized
INFO - 2018-05-22 21:28:49 --> Output Class Initialized
INFO - 2018-05-22 21:28:49 --> Security Class Initialized
INFO - 2018-05-22 21:28:49 --> Security Class Initialized
DEBUG - 2018-05-22 21:28:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-22 21:28:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 21:28:49 --> Input Class Initialized
INFO - 2018-05-22 21:28:49 --> Input Class Initialized
INFO - 2018-05-22 21:28:49 --> Language Class Initialized
INFO - 2018-05-22 21:28:49 --> Language Class Initialized
INFO - 2018-05-22 21:28:49 --> Language Class Initialized
INFO - 2018-05-22 21:28:49 --> Language Class Initialized
INFO - 2018-05-22 21:28:49 --> Config Class Initialized
INFO - 2018-05-22 21:28:49 --> Config Class Initialized
INFO - 2018-05-22 21:28:49 --> Loader Class Initialized
INFO - 2018-05-22 21:28:49 --> Loader Class Initialized
DEBUG - 2018-05-22 21:28:49 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
DEBUG - 2018-05-22 21:28:49 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 21:28:49 --> Helper loaded: url_helper
INFO - 2018-05-22 21:28:49 --> Helper loaded: url_helper
INFO - 2018-05-22 21:28:49 --> Helper loaded: form_helper
INFO - 2018-05-22 21:28:49 --> Helper loaded: form_helper
INFO - 2018-05-22 21:28:49 --> Helper loaded: date_helper
INFO - 2018-05-22 21:28:49 --> Helper loaded: date_helper
INFO - 2018-05-22 21:28:49 --> Helper loaded: util_helper
INFO - 2018-05-22 21:28:49 --> Helper loaded: util_helper
INFO - 2018-05-22 21:28:49 --> Helper loaded: text_helper
INFO - 2018-05-22 21:28:49 --> Helper loaded: text_helper
INFO - 2018-05-22 21:28:49 --> Helper loaded: string_helper
INFO - 2018-05-22 21:28:49 --> Helper loaded: string_helper
INFO - 2018-05-22 21:28:49 --> Database Driver Class Initialized
INFO - 2018-05-22 21:28:49 --> Database Driver Class Initialized
DEBUG - 2018-05-22 21:28:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-05-22 21:28:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 21:28:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 21:28:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 21:28:50 --> Email Class Initialized
INFO - 2018-05-22 21:28:50 --> Email Class Initialized
INFO - 2018-05-22 21:28:50 --> Controller Class Initialized
INFO - 2018-05-22 21:28:50 --> Controller Class Initialized
DEBUG - 2018-05-22 21:28:50 --> Home MX_Controller Initialized
DEBUG - 2018-05-22 21:28:50 --> Profile MX_Controller Initialized
DEBUG - 2018-05-22 21:28:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 21:28:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 21:28:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 21:28:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-22 21:28:50 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 21:28:50 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 21:28:50 --> Login MX_Controller Initialized
DEBUG - 2018-05-22 21:28:50 --> Login MX_Controller Initialized
INFO - 2018-05-22 21:28:50 --> Language file loaded: language/english/data_lang.php
INFO - 2018-05-22 21:28:50 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 21:28:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-22 21:28:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 21:28:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-22 21:28:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
DEBUG - 2018-05-22 21:28:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-05-22 21:28:50 --> Config Class Initialized
INFO - 2018-05-22 21:28:50 --> Hooks Class Initialized
DEBUG - 2018-05-22 21:28:50 --> UTF-8 Support Enabled
INFO - 2018-05-22 21:28:50 --> Utf8 Class Initialized
INFO - 2018-05-22 21:28:50 --> URI Class Initialized
INFO - 2018-05-22 21:28:50 --> Router Class Initialized
INFO - 2018-05-22 21:28:50 --> Output Class Initialized
INFO - 2018-05-22 21:28:50 --> Security Class Initialized
DEBUG - 2018-05-22 21:28:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 21:28:50 --> Input Class Initialized
INFO - 2018-05-22 21:28:50 --> Language Class Initialized
INFO - 2018-05-22 21:28:50 --> Language Class Initialized
INFO - 2018-05-22 21:28:50 --> Config Class Initialized
INFO - 2018-05-22 21:28:50 --> Loader Class Initialized
DEBUG - 2018-05-22 21:28:50 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 21:28:50 --> Helper loaded: url_helper
INFO - 2018-05-22 21:28:50 --> Helper loaded: form_helper
INFO - 2018-05-22 21:28:50 --> Helper loaded: date_helper
INFO - 2018-05-22 21:28:50 --> Helper loaded: util_helper
INFO - 2018-05-22 21:28:50 --> Helper loaded: text_helper
INFO - 2018-05-22 21:28:50 --> Helper loaded: string_helper
INFO - 2018-05-22 21:28:51 --> Database Driver Class Initialized
DEBUG - 2018-05-22 21:28:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 21:28:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 21:28:51 --> Email Class Initialized
INFO - 2018-05-22 21:28:51 --> Controller Class Initialized
DEBUG - 2018-05-22 21:28:51 --> Profile MX_Controller Initialized
DEBUG - 2018-05-22 21:28:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 21:28:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 21:28:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-22 21:28:51 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 21:28:51 --> Login MX_Controller Initialized
INFO - 2018-05-22 21:28:51 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 21:28:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-22 21:28:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-05-22 21:29:12 --> Config Class Initialized
INFO - 2018-05-22 21:29:12 --> Hooks Class Initialized
DEBUG - 2018-05-22 21:29:12 --> UTF-8 Support Enabled
INFO - 2018-05-22 21:29:12 --> Utf8 Class Initialized
INFO - 2018-05-22 21:29:12 --> URI Class Initialized
INFO - 2018-05-22 21:29:12 --> Router Class Initialized
INFO - 2018-05-22 21:29:12 --> Output Class Initialized
INFO - 2018-05-22 21:29:12 --> Security Class Initialized
DEBUG - 2018-05-22 21:29:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 21:29:12 --> Input Class Initialized
INFO - 2018-05-22 21:29:12 --> Language Class Initialized
INFO - 2018-05-22 21:29:12 --> Language Class Initialized
INFO - 2018-05-22 21:29:12 --> Config Class Initialized
INFO - 2018-05-22 21:29:12 --> Loader Class Initialized
DEBUG - 2018-05-22 21:29:12 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 21:29:12 --> Helper loaded: url_helper
INFO - 2018-05-22 21:29:12 --> Helper loaded: form_helper
INFO - 2018-05-22 21:29:12 --> Helper loaded: date_helper
INFO - 2018-05-22 21:29:12 --> Helper loaded: util_helper
INFO - 2018-05-22 21:29:12 --> Helper loaded: text_helper
INFO - 2018-05-22 21:29:12 --> Helper loaded: string_helper
INFO - 2018-05-22 21:29:12 --> Database Driver Class Initialized
DEBUG - 2018-05-22 21:29:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 21:29:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 21:29:12 --> Email Class Initialized
INFO - 2018-05-22 21:29:12 --> Controller Class Initialized
DEBUG - 2018-05-22 21:29:12 --> Login MX_Controller Initialized
INFO - 2018-05-22 21:29:12 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 21:29:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 21:29:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-22 21:29:12 --> Email starts for user@colin.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-05-22 21:29:12 --> Login status user@colin.com - failure
INFO - 2018-05-22 21:29:12 --> Final output sent to browser
DEBUG - 2018-05-22 21:29:12 --> Total execution time: 0.6307
INFO - 2018-05-22 21:29:24 --> Config Class Initialized
INFO - 2018-05-22 21:29:24 --> Hooks Class Initialized
DEBUG - 2018-05-22 21:29:24 --> UTF-8 Support Enabled
INFO - 2018-05-22 21:29:24 --> Utf8 Class Initialized
INFO - 2018-05-22 21:29:24 --> URI Class Initialized
INFO - 2018-05-22 21:29:24 --> Router Class Initialized
INFO - 2018-05-22 21:29:24 --> Output Class Initialized
INFO - 2018-05-22 21:29:24 --> Security Class Initialized
DEBUG - 2018-05-22 21:29:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 21:29:24 --> Input Class Initialized
INFO - 2018-05-22 21:29:24 --> Language Class Initialized
INFO - 2018-05-22 21:29:24 --> Language Class Initialized
INFO - 2018-05-22 21:29:24 --> Config Class Initialized
INFO - 2018-05-22 21:29:24 --> Loader Class Initialized
DEBUG - 2018-05-22 21:29:24 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 21:29:24 --> Helper loaded: url_helper
INFO - 2018-05-22 21:29:24 --> Helper loaded: form_helper
INFO - 2018-05-22 21:29:24 --> Helper loaded: date_helper
INFO - 2018-05-22 21:29:24 --> Helper loaded: util_helper
INFO - 2018-05-22 21:29:24 --> Helper loaded: text_helper
INFO - 2018-05-22 21:29:24 --> Helper loaded: string_helper
INFO - 2018-05-22 21:29:24 --> Database Driver Class Initialized
DEBUG - 2018-05-22 21:29:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 21:29:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 21:29:24 --> Email Class Initialized
INFO - 2018-05-22 21:29:24 --> Controller Class Initialized
DEBUG - 2018-05-22 21:29:24 --> Login MX_Controller Initialized
INFO - 2018-05-22 21:29:24 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 21:29:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 21:29:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-22 21:29:24 --> Email starts for user@colin.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-05-22 21:29:24 --> Login status user@colin.com - failure
INFO - 2018-05-22 21:29:24 --> Final output sent to browser
DEBUG - 2018-05-22 21:29:24 --> Total execution time: 0.5293
INFO - 2018-05-22 21:29:30 --> Config Class Initialized
INFO - 2018-05-22 21:29:30 --> Hooks Class Initialized
DEBUG - 2018-05-22 21:29:30 --> UTF-8 Support Enabled
INFO - 2018-05-22 21:29:30 --> Utf8 Class Initialized
INFO - 2018-05-22 21:29:31 --> URI Class Initialized
INFO - 2018-05-22 21:29:31 --> Router Class Initialized
INFO - 2018-05-22 21:29:31 --> Output Class Initialized
INFO - 2018-05-22 21:29:31 --> Security Class Initialized
DEBUG - 2018-05-22 21:29:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 21:29:31 --> Input Class Initialized
INFO - 2018-05-22 21:29:31 --> Language Class Initialized
INFO - 2018-05-22 21:29:31 --> Language Class Initialized
INFO - 2018-05-22 21:29:31 --> Config Class Initialized
INFO - 2018-05-22 21:29:31 --> Loader Class Initialized
DEBUG - 2018-05-22 21:29:31 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 21:29:31 --> Helper loaded: url_helper
INFO - 2018-05-22 21:29:31 --> Helper loaded: form_helper
INFO - 2018-05-22 21:29:31 --> Helper loaded: date_helper
INFO - 2018-05-22 21:29:31 --> Helper loaded: util_helper
INFO - 2018-05-22 21:29:31 --> Helper loaded: text_helper
INFO - 2018-05-22 21:29:31 --> Helper loaded: string_helper
INFO - 2018-05-22 21:29:31 --> Database Driver Class Initialized
DEBUG - 2018-05-22 21:29:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 21:29:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 21:29:31 --> Email Class Initialized
INFO - 2018-05-22 21:29:31 --> Controller Class Initialized
DEBUG - 2018-05-22 21:29:31 --> Login MX_Controller Initialized
INFO - 2018-05-22 21:29:31 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 21:29:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 21:29:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-22 21:29:31 --> Email starts for user@colin.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-05-22 21:29:31 --> User session created for 4
INFO - 2018-05-22 21:29:31 --> Login status user@colin.com - success
INFO - 2018-05-22 21:29:31 --> Final output sent to browser
DEBUG - 2018-05-22 21:29:31 --> Total execution time: 0.5957
INFO - 2018-05-22 21:29:31 --> Config Class Initialized
INFO - 2018-05-22 21:29:31 --> Hooks Class Initialized
DEBUG - 2018-05-22 21:29:31 --> UTF-8 Support Enabled
INFO - 2018-05-22 21:29:31 --> Utf8 Class Initialized
INFO - 2018-05-22 21:29:31 --> URI Class Initialized
INFO - 2018-05-22 21:29:31 --> Router Class Initialized
INFO - 2018-05-22 21:29:31 --> Output Class Initialized
INFO - 2018-05-22 21:29:31 --> Security Class Initialized
DEBUG - 2018-05-22 21:29:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 21:29:31 --> Input Class Initialized
INFO - 2018-05-22 21:29:31 --> Language Class Initialized
INFO - 2018-05-22 21:29:31 --> Language Class Initialized
INFO - 2018-05-22 21:29:31 --> Config Class Initialized
INFO - 2018-05-22 21:29:31 --> Loader Class Initialized
DEBUG - 2018-05-22 21:29:31 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 21:29:31 --> Helper loaded: url_helper
INFO - 2018-05-22 21:29:31 --> Helper loaded: form_helper
INFO - 2018-05-22 21:29:31 --> Helper loaded: date_helper
INFO - 2018-05-22 21:29:31 --> Helper loaded: util_helper
INFO - 2018-05-22 21:29:31 --> Helper loaded: text_helper
INFO - 2018-05-22 21:29:31 --> Helper loaded: string_helper
INFO - 2018-05-22 21:29:31 --> Database Driver Class Initialized
DEBUG - 2018-05-22 21:29:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 21:29:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 21:29:32 --> Email Class Initialized
INFO - 2018-05-22 21:29:32 --> Controller Class Initialized
DEBUG - 2018-05-22 21:29:32 --> Home MX_Controller Initialized
DEBUG - 2018-05-22 21:29:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 21:29:32 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 21:29:32 --> Login MX_Controller Initialized
INFO - 2018-05-22 21:29:32 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 21:29:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 21:29:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-22 21:29:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-22 21:29:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-22 21:29:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-22 21:29:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-22 21:29:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-22 21:29:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-05-22 21:29:32 --> Final output sent to browser
DEBUG - 2018-05-22 21:29:32 --> Total execution time: 0.8974
INFO - 2018-05-22 21:29:33 --> Config Class Initialized
INFO - 2018-05-22 21:29:33 --> Hooks Class Initialized
DEBUG - 2018-05-22 21:29:33 --> UTF-8 Support Enabled
INFO - 2018-05-22 21:29:33 --> Utf8 Class Initialized
INFO - 2018-05-22 21:29:33 --> URI Class Initialized
INFO - 2018-05-22 21:29:33 --> Router Class Initialized
INFO - 2018-05-22 21:29:33 --> Output Class Initialized
INFO - 2018-05-22 21:29:33 --> Security Class Initialized
DEBUG - 2018-05-22 21:29:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 21:29:33 --> Input Class Initialized
INFO - 2018-05-22 21:29:33 --> Language Class Initialized
ERROR - 2018-05-22 21:29:33 --> 404 Page Not Found: /index
INFO - 2018-05-22 21:29:33 --> Config Class Initialized
INFO - 2018-05-22 21:29:33 --> Hooks Class Initialized
DEBUG - 2018-05-22 21:29:33 --> UTF-8 Support Enabled
INFO - 2018-05-22 21:29:33 --> Utf8 Class Initialized
INFO - 2018-05-22 21:29:33 --> URI Class Initialized
INFO - 2018-05-22 21:29:33 --> Router Class Initialized
INFO - 2018-05-22 21:29:33 --> Output Class Initialized
INFO - 2018-05-22 21:29:33 --> Security Class Initialized
DEBUG - 2018-05-22 21:29:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 21:29:33 --> Input Class Initialized
INFO - 2018-05-22 21:29:33 --> Language Class Initialized
ERROR - 2018-05-22 21:29:33 --> 404 Page Not Found: /index
INFO - 2018-05-22 21:29:34 --> Config Class Initialized
INFO - 2018-05-22 21:29:34 --> Hooks Class Initialized
DEBUG - 2018-05-22 21:29:34 --> UTF-8 Support Enabled
INFO - 2018-05-22 21:29:34 --> Utf8 Class Initialized
INFO - 2018-05-22 21:29:34 --> URI Class Initialized
INFO - 2018-05-22 21:29:34 --> Router Class Initialized
INFO - 2018-05-22 21:29:34 --> Output Class Initialized
INFO - 2018-05-22 21:29:34 --> Security Class Initialized
DEBUG - 2018-05-22 21:29:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 21:29:34 --> Input Class Initialized
INFO - 2018-05-22 21:29:34 --> Language Class Initialized
ERROR - 2018-05-22 21:29:34 --> 404 Page Not Found: /index
INFO - 2018-05-22 21:29:38 --> Config Class Initialized
INFO - 2018-05-22 21:29:38 --> Hooks Class Initialized
DEBUG - 2018-05-22 21:29:38 --> UTF-8 Support Enabled
INFO - 2018-05-22 21:29:38 --> Utf8 Class Initialized
INFO - 2018-05-22 21:29:38 --> URI Class Initialized
INFO - 2018-05-22 21:29:38 --> Router Class Initialized
INFO - 2018-05-22 21:29:38 --> Output Class Initialized
INFO - 2018-05-22 21:29:38 --> Security Class Initialized
DEBUG - 2018-05-22 21:29:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 21:29:38 --> Input Class Initialized
INFO - 2018-05-22 21:29:38 --> Language Class Initialized
ERROR - 2018-05-22 21:29:38 --> 404 Page Not Found: /index
INFO - 2018-05-22 21:29:38 --> Config Class Initialized
INFO - 2018-05-22 21:29:38 --> Hooks Class Initialized
DEBUG - 2018-05-22 21:29:38 --> UTF-8 Support Enabled
INFO - 2018-05-22 21:29:38 --> Utf8 Class Initialized
INFO - 2018-05-22 21:29:38 --> URI Class Initialized
INFO - 2018-05-22 21:29:38 --> Router Class Initialized
INFO - 2018-05-22 21:29:38 --> Output Class Initialized
INFO - 2018-05-22 21:29:38 --> Security Class Initialized
DEBUG - 2018-05-22 21:29:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 21:29:39 --> Input Class Initialized
INFO - 2018-05-22 21:29:39 --> Language Class Initialized
ERROR - 2018-05-22 21:29:39 --> 404 Page Not Found: /index
INFO - 2018-05-22 21:29:39 --> Config Class Initialized
INFO - 2018-05-22 21:29:39 --> Hooks Class Initialized
DEBUG - 2018-05-22 21:29:39 --> UTF-8 Support Enabled
INFO - 2018-05-22 21:29:39 --> Utf8 Class Initialized
INFO - 2018-05-22 21:29:39 --> URI Class Initialized
INFO - 2018-05-22 21:29:39 --> Router Class Initialized
INFO - 2018-05-22 21:29:39 --> Output Class Initialized
INFO - 2018-05-22 21:29:39 --> Security Class Initialized
DEBUG - 2018-05-22 21:29:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 21:29:39 --> Input Class Initialized
INFO - 2018-05-22 21:29:39 --> Language Class Initialized
ERROR - 2018-05-22 21:29:39 --> 404 Page Not Found: /index
INFO - 2018-05-22 21:33:10 --> Config Class Initialized
INFO - 2018-05-22 21:33:10 --> Hooks Class Initialized
DEBUG - 2018-05-22 21:33:10 --> UTF-8 Support Enabled
INFO - 2018-05-22 21:33:10 --> Utf8 Class Initialized
INFO - 2018-05-22 21:33:10 --> URI Class Initialized
INFO - 2018-05-22 21:33:10 --> Router Class Initialized
INFO - 2018-05-22 21:33:10 --> Output Class Initialized
INFO - 2018-05-22 21:33:10 --> Security Class Initialized
DEBUG - 2018-05-22 21:33:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 21:33:10 --> Input Class Initialized
INFO - 2018-05-22 21:33:10 --> Language Class Initialized
INFO - 2018-05-22 21:33:10 --> Language Class Initialized
INFO - 2018-05-22 21:33:10 --> Config Class Initialized
INFO - 2018-05-22 21:33:10 --> Loader Class Initialized
DEBUG - 2018-05-22 21:33:10 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 21:33:10 --> Helper loaded: url_helper
INFO - 2018-05-22 21:33:10 --> Helper loaded: form_helper
INFO - 2018-05-22 21:33:10 --> Helper loaded: date_helper
INFO - 2018-05-22 21:33:10 --> Helper loaded: util_helper
INFO - 2018-05-22 21:33:10 --> Helper loaded: text_helper
INFO - 2018-05-22 21:33:10 --> Helper loaded: string_helper
INFO - 2018-05-22 21:33:10 --> Database Driver Class Initialized
DEBUG - 2018-05-22 21:33:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 21:33:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 21:33:10 --> Email Class Initialized
INFO - 2018-05-22 21:33:10 --> Controller Class Initialized
DEBUG - 2018-05-22 21:33:11 --> Home MX_Controller Initialized
DEBUG - 2018-05-22 21:33:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 21:33:11 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 21:33:11 --> Login MX_Controller Initialized
INFO - 2018-05-22 21:33:11 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 21:33:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 21:33:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-22 21:33:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-22 21:33:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-22 21:33:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-22 21:33:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-22 21:33:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-22 21:33:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-05-22 21:33:11 --> Final output sent to browser
DEBUG - 2018-05-22 21:33:11 --> Total execution time: 1.0822
INFO - 2018-05-22 21:33:12 --> Config Class Initialized
INFO - 2018-05-22 21:33:12 --> Config Class Initialized
INFO - 2018-05-22 21:33:12 --> Hooks Class Initialized
INFO - 2018-05-22 21:33:12 --> Hooks Class Initialized
DEBUG - 2018-05-22 21:33:12 --> UTF-8 Support Enabled
INFO - 2018-05-22 21:33:12 --> Utf8 Class Initialized
INFO - 2018-05-22 21:33:12 --> URI Class Initialized
INFO - 2018-05-22 21:33:12 --> Router Class Initialized
INFO - 2018-05-22 21:33:12 --> Output Class Initialized
DEBUG - 2018-05-22 21:33:12 --> UTF-8 Support Enabled
INFO - 2018-05-22 21:33:12 --> Security Class Initialized
INFO - 2018-05-22 21:33:12 --> Utf8 Class Initialized
INFO - 2018-05-22 21:33:13 --> URI Class Initialized
DEBUG - 2018-05-22 21:33:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 21:33:13 --> Input Class Initialized
INFO - 2018-05-22 21:33:13 --> Router Class Initialized
INFO - 2018-05-22 21:33:13 --> Language Class Initialized
INFO - 2018-05-22 21:33:13 --> Output Class Initialized
ERROR - 2018-05-22 21:33:13 --> 404 Page Not Found: /index
INFO - 2018-05-22 21:33:13 --> Security Class Initialized
DEBUG - 2018-05-22 21:33:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 21:33:13 --> Config Class Initialized
INFO - 2018-05-22 21:33:13 --> Hooks Class Initialized
INFO - 2018-05-22 21:33:13 --> Input Class Initialized
INFO - 2018-05-22 21:33:13 --> Language Class Initialized
DEBUG - 2018-05-22 21:33:13 --> UTF-8 Support Enabled
INFO - 2018-05-22 21:33:13 --> Utf8 Class Initialized
ERROR - 2018-05-22 21:33:13 --> 404 Page Not Found: /index
INFO - 2018-05-22 21:33:13 --> URI Class Initialized
INFO - 2018-05-22 21:33:13 --> Router Class Initialized
INFO - 2018-05-22 21:33:13 --> Output Class Initialized
INFO - 2018-05-22 21:33:13 --> Security Class Initialized
DEBUG - 2018-05-22 21:33:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 21:33:13 --> Input Class Initialized
INFO - 2018-05-22 21:33:13 --> Language Class Initialized
ERROR - 2018-05-22 21:33:13 --> 404 Page Not Found: /index
INFO - 2018-05-22 21:33:13 --> Config Class Initialized
INFO - 2018-05-22 21:33:13 --> Hooks Class Initialized
DEBUG - 2018-05-22 21:33:13 --> UTF-8 Support Enabled
INFO - 2018-05-22 21:33:13 --> Utf8 Class Initialized
INFO - 2018-05-22 21:33:13 --> URI Class Initialized
INFO - 2018-05-22 21:33:13 --> Router Class Initialized
INFO - 2018-05-22 21:33:13 --> Output Class Initialized
INFO - 2018-05-22 21:33:13 --> Security Class Initialized
DEBUG - 2018-05-22 21:33:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 21:33:13 --> Input Class Initialized
INFO - 2018-05-22 21:33:13 --> Language Class Initialized
ERROR - 2018-05-22 21:33:13 --> 404 Page Not Found: /index
INFO - 2018-05-22 21:33:14 --> Config Class Initialized
INFO - 2018-05-22 21:33:14 --> Hooks Class Initialized
DEBUG - 2018-05-22 21:33:14 --> UTF-8 Support Enabled
INFO - 2018-05-22 21:33:14 --> Utf8 Class Initialized
INFO - 2018-05-22 21:33:14 --> URI Class Initialized
INFO - 2018-05-22 21:33:14 --> Router Class Initialized
INFO - 2018-05-22 21:33:14 --> Output Class Initialized
INFO - 2018-05-22 21:33:14 --> Security Class Initialized
DEBUG - 2018-05-22 21:33:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 21:33:14 --> Input Class Initialized
INFO - 2018-05-22 21:33:14 --> Language Class Initialized
INFO - 2018-05-22 21:33:14 --> Language Class Initialized
INFO - 2018-05-22 21:33:14 --> Config Class Initialized
INFO - 2018-05-22 21:33:14 --> Loader Class Initialized
DEBUG - 2018-05-22 21:33:14 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 21:33:14 --> Helper loaded: url_helper
INFO - 2018-05-22 21:33:14 --> Helper loaded: form_helper
INFO - 2018-05-22 21:33:14 --> Helper loaded: date_helper
INFO - 2018-05-22 21:33:15 --> Helper loaded: util_helper
INFO - 2018-05-22 21:33:15 --> Helper loaded: text_helper
INFO - 2018-05-22 21:33:15 --> Helper loaded: string_helper
INFO - 2018-05-22 21:33:15 --> Database Driver Class Initialized
DEBUG - 2018-05-22 21:33:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 21:33:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 21:33:15 --> Email Class Initialized
INFO - 2018-05-22 21:33:15 --> Controller Class Initialized
DEBUG - 2018-05-22 21:33:15 --> Profile MX_Controller Initialized
DEBUG - 2018-05-22 21:33:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 21:33:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 21:33:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-22 21:33:15 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 21:33:15 --> Login MX_Controller Initialized
INFO - 2018-05-22 21:33:15 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 21:33:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-22 21:33:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-22 21:33:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-22 21:33:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-22 21:33:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-05-22 21:33:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-22 21:33:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-22 21:33:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/profile.php
INFO - 2018-05-22 21:33:15 --> Final output sent to browser
DEBUG - 2018-05-22 21:33:15 --> Total execution time: 1.0678
INFO - 2018-05-22 21:33:16 --> Config Class Initialized
INFO - 2018-05-22 21:33:16 --> Hooks Class Initialized
DEBUG - 2018-05-22 21:33:16 --> UTF-8 Support Enabled
INFO - 2018-05-22 21:33:16 --> Utf8 Class Initialized
INFO - 2018-05-22 21:33:16 --> URI Class Initialized
INFO - 2018-05-22 21:33:16 --> Router Class Initialized
INFO - 2018-05-22 21:33:16 --> Output Class Initialized
INFO - 2018-05-22 21:33:16 --> Security Class Initialized
DEBUG - 2018-05-22 21:33:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 21:33:16 --> Input Class Initialized
INFO - 2018-05-22 21:33:16 --> Language Class Initialized
ERROR - 2018-05-22 21:33:16 --> 404 Page Not Found: /index
INFO - 2018-05-22 21:33:16 --> Config Class Initialized
INFO - 2018-05-22 21:33:16 --> Hooks Class Initialized
DEBUG - 2018-05-22 21:33:16 --> UTF-8 Support Enabled
INFO - 2018-05-22 21:33:16 --> Utf8 Class Initialized
INFO - 2018-05-22 21:33:16 --> URI Class Initialized
INFO - 2018-05-22 21:33:16 --> Router Class Initialized
INFO - 2018-05-22 21:33:16 --> Output Class Initialized
INFO - 2018-05-22 21:33:16 --> Security Class Initialized
DEBUG - 2018-05-22 21:33:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 21:33:16 --> Input Class Initialized
INFO - 2018-05-22 21:33:16 --> Language Class Initialized
ERROR - 2018-05-22 21:33:16 --> 404 Page Not Found: /index
INFO - 2018-05-22 21:33:16 --> Config Class Initialized
INFO - 2018-05-22 21:33:16 --> Hooks Class Initialized
DEBUG - 2018-05-22 21:33:16 --> UTF-8 Support Enabled
INFO - 2018-05-22 21:33:17 --> Utf8 Class Initialized
INFO - 2018-05-22 21:33:17 --> URI Class Initialized
INFO - 2018-05-22 21:33:17 --> Router Class Initialized
INFO - 2018-05-22 21:33:17 --> Output Class Initialized
INFO - 2018-05-22 21:33:17 --> Security Class Initialized
DEBUG - 2018-05-22 21:33:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 21:33:17 --> Input Class Initialized
INFO - 2018-05-22 21:33:17 --> Language Class Initialized
ERROR - 2018-05-22 21:33:17 --> 404 Page Not Found: /index
INFO - 2018-05-22 21:33:20 --> Config Class Initialized
INFO - 2018-05-22 21:33:20 --> Hooks Class Initialized
DEBUG - 2018-05-22 21:33:20 --> UTF-8 Support Enabled
INFO - 2018-05-22 21:33:20 --> Utf8 Class Initialized
INFO - 2018-05-22 21:33:20 --> URI Class Initialized
INFO - 2018-05-22 21:33:20 --> Router Class Initialized
INFO - 2018-05-22 21:33:20 --> Output Class Initialized
INFO - 2018-05-22 21:33:20 --> Security Class Initialized
DEBUG - 2018-05-22 21:33:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 21:33:20 --> Input Class Initialized
INFO - 2018-05-22 21:33:20 --> Language Class Initialized
INFO - 2018-05-22 21:33:20 --> Language Class Initialized
INFO - 2018-05-22 21:33:20 --> Config Class Initialized
INFO - 2018-05-22 21:33:20 --> Loader Class Initialized
DEBUG - 2018-05-22 21:33:20 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 21:33:20 --> Helper loaded: url_helper
INFO - 2018-05-22 21:33:20 --> Helper loaded: form_helper
INFO - 2018-05-22 21:33:20 --> Helper loaded: date_helper
INFO - 2018-05-22 21:33:20 --> Helper loaded: util_helper
INFO - 2018-05-22 21:33:20 --> Helper loaded: text_helper
INFO - 2018-05-22 21:33:20 --> Helper loaded: string_helper
INFO - 2018-05-22 21:33:20 --> Database Driver Class Initialized
DEBUG - 2018-05-22 21:33:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 21:33:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 21:33:20 --> Email Class Initialized
INFO - 2018-05-22 21:33:20 --> Controller Class Initialized
DEBUG - 2018-05-22 21:33:20 --> Profile MX_Controller Initialized
DEBUG - 2018-05-22 21:33:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 21:33:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 21:33:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-22 21:33:20 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 21:33:20 --> Login MX_Controller Initialized
INFO - 2018-05-22 21:33:20 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 21:33:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-22 21:33:36 --> Config Class Initialized
INFO - 2018-05-22 21:33:36 --> Hooks Class Initialized
DEBUG - 2018-05-22 21:33:36 --> UTF-8 Support Enabled
INFO - 2018-05-22 21:33:36 --> Utf8 Class Initialized
INFO - 2018-05-22 21:33:36 --> URI Class Initialized
INFO - 2018-05-22 21:33:36 --> Router Class Initialized
INFO - 2018-05-22 21:33:36 --> Output Class Initialized
INFO - 2018-05-22 21:33:36 --> Security Class Initialized
DEBUG - 2018-05-22 21:33:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 21:33:36 --> Input Class Initialized
INFO - 2018-05-22 21:33:36 --> Language Class Initialized
INFO - 2018-05-22 21:33:36 --> Language Class Initialized
INFO - 2018-05-22 21:33:37 --> Config Class Initialized
INFO - 2018-05-22 21:33:37 --> Loader Class Initialized
DEBUG - 2018-05-22 21:33:37 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 21:33:37 --> Helper loaded: url_helper
INFO - 2018-05-22 21:33:37 --> Helper loaded: form_helper
INFO - 2018-05-22 21:33:37 --> Helper loaded: date_helper
INFO - 2018-05-22 21:33:37 --> Helper loaded: util_helper
INFO - 2018-05-22 21:33:37 --> Helper loaded: text_helper
INFO - 2018-05-22 21:33:37 --> Helper loaded: string_helper
INFO - 2018-05-22 21:33:37 --> Database Driver Class Initialized
DEBUG - 2018-05-22 21:33:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 21:33:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 21:33:37 --> Email Class Initialized
INFO - 2018-05-22 21:33:37 --> Controller Class Initialized
DEBUG - 2018-05-22 21:33:37 --> Profile MX_Controller Initialized
DEBUG - 2018-05-22 21:33:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 21:33:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 21:33:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-22 21:33:37 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 21:33:37 --> Login MX_Controller Initialized
INFO - 2018-05-22 21:33:37 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 21:33:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-22 21:33:46 --> Config Class Initialized
INFO - 2018-05-22 21:33:46 --> Hooks Class Initialized
DEBUG - 2018-05-22 21:33:46 --> UTF-8 Support Enabled
INFO - 2018-05-22 21:33:46 --> Utf8 Class Initialized
INFO - 2018-05-22 21:33:46 --> URI Class Initialized
INFO - 2018-05-22 21:33:46 --> Router Class Initialized
INFO - 2018-05-22 21:33:46 --> Output Class Initialized
INFO - 2018-05-22 21:33:46 --> Security Class Initialized
DEBUG - 2018-05-22 21:33:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 21:33:46 --> Input Class Initialized
INFO - 2018-05-22 21:33:46 --> Language Class Initialized
INFO - 2018-05-22 21:33:46 --> Language Class Initialized
INFO - 2018-05-22 21:33:46 --> Config Class Initialized
INFO - 2018-05-22 21:33:46 --> Loader Class Initialized
DEBUG - 2018-05-22 21:33:46 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 21:33:46 --> Helper loaded: url_helper
INFO - 2018-05-22 21:33:46 --> Helper loaded: form_helper
INFO - 2018-05-22 21:33:46 --> Helper loaded: date_helper
INFO - 2018-05-22 21:33:46 --> Helper loaded: util_helper
INFO - 2018-05-22 21:33:46 --> Helper loaded: text_helper
INFO - 2018-05-22 21:33:46 --> Helper loaded: string_helper
INFO - 2018-05-22 21:33:46 --> Database Driver Class Initialized
DEBUG - 2018-05-22 21:33:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 21:33:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 21:33:46 --> Email Class Initialized
INFO - 2018-05-22 21:33:46 --> Controller Class Initialized
DEBUG - 2018-05-22 21:33:46 --> Profile MX_Controller Initialized
DEBUG - 2018-05-22 21:33:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 21:33:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 21:33:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-22 21:33:46 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 21:33:46 --> Login MX_Controller Initialized
INFO - 2018-05-22 21:33:46 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 21:33:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-22 21:34:00 --> Config Class Initialized
INFO - 2018-05-22 21:34:00 --> Hooks Class Initialized
DEBUG - 2018-05-22 21:34:00 --> UTF-8 Support Enabled
INFO - 2018-05-22 21:34:00 --> Utf8 Class Initialized
INFO - 2018-05-22 21:34:00 --> URI Class Initialized
INFO - 2018-05-22 21:34:00 --> Router Class Initialized
INFO - 2018-05-22 21:34:00 --> Output Class Initialized
INFO - 2018-05-22 21:34:00 --> Security Class Initialized
DEBUG - 2018-05-22 21:34:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 21:34:00 --> Input Class Initialized
INFO - 2018-05-22 21:34:00 --> Language Class Initialized
INFO - 2018-05-22 21:34:00 --> Language Class Initialized
INFO - 2018-05-22 21:34:00 --> Config Class Initialized
INFO - 2018-05-22 21:34:00 --> Loader Class Initialized
DEBUG - 2018-05-22 21:34:00 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 21:34:00 --> Helper loaded: url_helper
INFO - 2018-05-22 21:34:00 --> Helper loaded: form_helper
INFO - 2018-05-22 21:34:00 --> Helper loaded: date_helper
INFO - 2018-05-22 21:34:00 --> Helper loaded: util_helper
INFO - 2018-05-22 21:34:00 --> Helper loaded: text_helper
INFO - 2018-05-22 21:34:00 --> Helper loaded: string_helper
INFO - 2018-05-22 21:34:00 --> Database Driver Class Initialized
DEBUG - 2018-05-22 21:34:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 21:34:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 21:34:00 --> Email Class Initialized
INFO - 2018-05-22 21:34:00 --> Controller Class Initialized
DEBUG - 2018-05-22 21:34:00 --> Profile MX_Controller Initialized
DEBUG - 2018-05-22 21:34:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 21:34:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 21:34:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-22 21:34:00 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 21:34:00 --> Login MX_Controller Initialized
INFO - 2018-05-22 21:34:00 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 21:34:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-22 21:34:00 --> Upload Class Initialized
INFO - 2018-05-22 21:34:03 --> Config Class Initialized
INFO - 2018-05-22 21:34:03 --> Hooks Class Initialized
DEBUG - 2018-05-22 21:34:03 --> UTF-8 Support Enabled
INFO - 2018-05-22 21:34:03 --> Utf8 Class Initialized
INFO - 2018-05-22 21:34:03 --> URI Class Initialized
INFO - 2018-05-22 21:34:03 --> Router Class Initialized
INFO - 2018-05-22 21:34:03 --> Output Class Initialized
INFO - 2018-05-22 21:34:03 --> Security Class Initialized
DEBUG - 2018-05-22 21:34:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 21:34:03 --> Input Class Initialized
INFO - 2018-05-22 21:34:03 --> Language Class Initialized
INFO - 2018-05-22 21:34:03 --> Language Class Initialized
INFO - 2018-05-22 21:34:03 --> Config Class Initialized
INFO - 2018-05-22 21:34:03 --> Loader Class Initialized
DEBUG - 2018-05-22 21:34:03 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 21:34:03 --> Helper loaded: url_helper
INFO - 2018-05-22 21:34:03 --> Helper loaded: form_helper
INFO - 2018-05-22 21:34:03 --> Helper loaded: date_helper
INFO - 2018-05-22 21:34:03 --> Helper loaded: util_helper
INFO - 2018-05-22 21:34:03 --> Helper loaded: text_helper
INFO - 2018-05-22 21:34:03 --> Helper loaded: string_helper
INFO - 2018-05-22 21:34:03 --> Database Driver Class Initialized
DEBUG - 2018-05-22 21:34:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 21:34:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 21:34:03 --> Email Class Initialized
INFO - 2018-05-22 21:34:03 --> Controller Class Initialized
DEBUG - 2018-05-22 21:34:03 --> Profile MX_Controller Initialized
DEBUG - 2018-05-22 21:34:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 21:34:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 21:34:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-22 21:34:04 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 21:34:04 --> Login MX_Controller Initialized
INFO - 2018-05-22 21:34:04 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 21:34:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-22 21:34:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-22 21:34:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-22 21:34:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-22 21:34:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-05-22 21:34:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-22 21:34:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-22 21:34:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/profile.php
INFO - 2018-05-22 21:34:04 --> Final output sent to browser
DEBUG - 2018-05-22 21:34:04 --> Total execution time: 0.8740
INFO - 2018-05-22 21:34:05 --> Config Class Initialized
INFO - 2018-05-22 21:34:05 --> Hooks Class Initialized
DEBUG - 2018-05-22 21:34:05 --> UTF-8 Support Enabled
INFO - 2018-05-22 21:34:05 --> Utf8 Class Initialized
INFO - 2018-05-22 21:34:05 --> URI Class Initialized
INFO - 2018-05-22 21:34:05 --> Router Class Initialized
INFO - 2018-05-22 21:34:05 --> Output Class Initialized
INFO - 2018-05-22 21:34:05 --> Security Class Initialized
DEBUG - 2018-05-22 21:34:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 21:34:05 --> Input Class Initialized
INFO - 2018-05-22 21:34:05 --> Language Class Initialized
ERROR - 2018-05-22 21:34:06 --> 404 Page Not Found: /index
INFO - 2018-05-22 21:34:06 --> Config Class Initialized
INFO - 2018-05-22 21:34:06 --> Hooks Class Initialized
DEBUG - 2018-05-22 21:34:06 --> UTF-8 Support Enabled
INFO - 2018-05-22 21:34:06 --> Utf8 Class Initialized
INFO - 2018-05-22 21:34:06 --> URI Class Initialized
INFO - 2018-05-22 21:34:06 --> Router Class Initialized
INFO - 2018-05-22 21:34:06 --> Output Class Initialized
INFO - 2018-05-22 21:34:06 --> Security Class Initialized
DEBUG - 2018-05-22 21:34:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 21:34:06 --> Input Class Initialized
INFO - 2018-05-22 21:34:06 --> Language Class Initialized
ERROR - 2018-05-22 21:34:06 --> 404 Page Not Found: /index
INFO - 2018-05-22 21:34:06 --> Config Class Initialized
INFO - 2018-05-22 21:34:06 --> Hooks Class Initialized
DEBUG - 2018-05-22 21:34:06 --> UTF-8 Support Enabled
INFO - 2018-05-22 21:34:06 --> Utf8 Class Initialized
INFO - 2018-05-22 21:34:06 --> URI Class Initialized
INFO - 2018-05-22 21:34:06 --> Router Class Initialized
INFO - 2018-05-22 21:34:06 --> Output Class Initialized
INFO - 2018-05-22 21:34:06 --> Security Class Initialized
DEBUG - 2018-05-22 21:34:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 21:34:06 --> Input Class Initialized
INFO - 2018-05-22 21:34:06 --> Language Class Initialized
ERROR - 2018-05-22 21:34:06 --> 404 Page Not Found: /index
INFO - 2018-05-22 21:43:35 --> Config Class Initialized
INFO - 2018-05-22 21:43:35 --> Hooks Class Initialized
DEBUG - 2018-05-22 21:43:35 --> UTF-8 Support Enabled
INFO - 2018-05-22 21:43:35 --> Utf8 Class Initialized
INFO - 2018-05-22 21:43:35 --> URI Class Initialized
INFO - 2018-05-22 21:43:35 --> Router Class Initialized
INFO - 2018-05-22 21:43:35 --> Output Class Initialized
INFO - 2018-05-22 21:43:35 --> Security Class Initialized
DEBUG - 2018-05-22 21:43:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 21:43:35 --> Input Class Initialized
INFO - 2018-05-22 21:43:35 --> Language Class Initialized
INFO - 2018-05-22 21:43:35 --> Language Class Initialized
INFO - 2018-05-22 21:43:35 --> Config Class Initialized
INFO - 2018-05-22 21:43:35 --> Loader Class Initialized
DEBUG - 2018-05-22 21:43:35 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 21:43:35 --> Helper loaded: url_helper
INFO - 2018-05-22 21:43:35 --> Helper loaded: form_helper
INFO - 2018-05-22 21:43:35 --> Helper loaded: date_helper
INFO - 2018-05-22 21:43:35 --> Helper loaded: util_helper
INFO - 2018-05-22 21:43:36 --> Helper loaded: text_helper
INFO - 2018-05-22 21:43:36 --> Helper loaded: string_helper
INFO - 2018-05-22 21:43:36 --> Database Driver Class Initialized
DEBUG - 2018-05-22 21:43:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 21:43:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 21:43:36 --> Email Class Initialized
INFO - 2018-05-22 21:43:36 --> Controller Class Initialized
DEBUG - 2018-05-22 21:43:36 --> Profile MX_Controller Initialized
DEBUG - 2018-05-22 21:43:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 21:43:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 21:43:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-22 21:43:36 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 21:43:36 --> Login MX_Controller Initialized
INFO - 2018-05-22 21:43:36 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 21:43:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-22 21:43:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-22 21:43:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-22 21:43:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-22 21:43:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-05-22 21:43:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-22 21:43:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-22 21:43:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/billing.php
INFO - 2018-05-22 21:43:36 --> Final output sent to browser
DEBUG - 2018-05-22 21:43:36 --> Total execution time: 0.8265
INFO - 2018-05-22 21:43:37 --> Config Class Initialized
INFO - 2018-05-22 21:43:37 --> Hooks Class Initialized
DEBUG - 2018-05-22 21:43:37 --> UTF-8 Support Enabled
INFO - 2018-05-22 21:43:37 --> Utf8 Class Initialized
INFO - 2018-05-22 21:43:37 --> URI Class Initialized
INFO - 2018-05-22 21:43:37 --> Router Class Initialized
INFO - 2018-05-22 21:43:37 --> Output Class Initialized
INFO - 2018-05-22 21:43:37 --> Security Class Initialized
DEBUG - 2018-05-22 21:43:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 21:43:37 --> Input Class Initialized
INFO - 2018-05-22 21:43:37 --> Language Class Initialized
ERROR - 2018-05-22 21:43:37 --> 404 Page Not Found: /index
INFO - 2018-05-22 21:43:37 --> Config Class Initialized
INFO - 2018-05-22 21:43:37 --> Hooks Class Initialized
DEBUG - 2018-05-22 21:43:37 --> UTF-8 Support Enabled
INFO - 2018-05-22 21:43:37 --> Utf8 Class Initialized
INFO - 2018-05-22 21:43:37 --> URI Class Initialized
INFO - 2018-05-22 21:43:37 --> Router Class Initialized
INFO - 2018-05-22 21:43:37 --> Output Class Initialized
INFO - 2018-05-22 21:43:37 --> Security Class Initialized
DEBUG - 2018-05-22 21:43:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 21:43:37 --> Input Class Initialized
INFO - 2018-05-22 21:43:37 --> Language Class Initialized
ERROR - 2018-05-22 21:43:37 --> 404 Page Not Found: /index
INFO - 2018-05-22 21:43:37 --> Config Class Initialized
INFO - 2018-05-22 21:43:37 --> Hooks Class Initialized
DEBUG - 2018-05-22 21:43:37 --> UTF-8 Support Enabled
INFO - 2018-05-22 21:43:37 --> Utf8 Class Initialized
INFO - 2018-05-22 21:43:37 --> URI Class Initialized
INFO - 2018-05-22 21:43:37 --> Router Class Initialized
INFO - 2018-05-22 21:43:37 --> Output Class Initialized
INFO - 2018-05-22 21:43:37 --> Security Class Initialized
DEBUG - 2018-05-22 21:43:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 21:43:37 --> Input Class Initialized
INFO - 2018-05-22 21:43:37 --> Language Class Initialized
ERROR - 2018-05-22 21:43:37 --> 404 Page Not Found: /index
INFO - 2018-05-22 21:43:38 --> Config Class Initialized
INFO - 2018-05-22 21:43:38 --> Hooks Class Initialized
DEBUG - 2018-05-22 21:43:38 --> UTF-8 Support Enabled
INFO - 2018-05-22 21:43:38 --> Utf8 Class Initialized
INFO - 2018-05-22 21:43:38 --> URI Class Initialized
INFO - 2018-05-22 21:43:38 --> Router Class Initialized
INFO - 2018-05-22 21:43:38 --> Output Class Initialized
INFO - 2018-05-22 21:43:38 --> Security Class Initialized
DEBUG - 2018-05-22 21:43:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 21:43:38 --> Input Class Initialized
INFO - 2018-05-22 21:43:38 --> Language Class Initialized
INFO - 2018-05-22 21:43:38 --> Language Class Initialized
INFO - 2018-05-22 21:43:38 --> Config Class Initialized
INFO - 2018-05-22 21:43:38 --> Loader Class Initialized
DEBUG - 2018-05-22 21:43:38 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 21:43:38 --> Helper loaded: url_helper
INFO - 2018-05-22 21:43:38 --> Helper loaded: form_helper
INFO - 2018-05-22 21:43:38 --> Helper loaded: date_helper
INFO - 2018-05-22 21:43:38 --> Helper loaded: util_helper
INFO - 2018-05-22 21:43:38 --> Helper loaded: text_helper
INFO - 2018-05-22 21:43:38 --> Helper loaded: string_helper
INFO - 2018-05-22 21:43:38 --> Database Driver Class Initialized
DEBUG - 2018-05-22 21:43:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 21:43:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 21:43:38 --> Email Class Initialized
INFO - 2018-05-22 21:43:38 --> Controller Class Initialized
DEBUG - 2018-05-22 21:43:38 --> Profile MX_Controller Initialized
DEBUG - 2018-05-22 21:43:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 21:43:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 21:43:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-22 21:43:38 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 21:43:38 --> Login MX_Controller Initialized
INFO - 2018-05-22 21:43:38 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 21:43:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-22 21:43:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-22 21:43:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-22 21:43:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-22 21:43:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-05-22 21:43:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-22 21:43:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-22 21:43:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/addresses.php
INFO - 2018-05-22 21:43:39 --> Final output sent to browser
DEBUG - 2018-05-22 21:43:39 --> Total execution time: 0.9210
INFO - 2018-05-22 21:43:39 --> Config Class Initialized
INFO - 2018-05-22 21:43:39 --> Hooks Class Initialized
DEBUG - 2018-05-22 21:43:39 --> UTF-8 Support Enabled
INFO - 2018-05-22 21:43:39 --> Utf8 Class Initialized
INFO - 2018-05-22 21:43:39 --> URI Class Initialized
INFO - 2018-05-22 21:43:39 --> Router Class Initialized
INFO - 2018-05-22 21:43:39 --> Output Class Initialized
INFO - 2018-05-22 21:43:39 --> Security Class Initialized
DEBUG - 2018-05-22 21:43:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 21:43:39 --> Input Class Initialized
INFO - 2018-05-22 21:43:39 --> Language Class Initialized
ERROR - 2018-05-22 21:43:39 --> 404 Page Not Found: /index
INFO - 2018-05-22 21:43:39 --> Config Class Initialized
INFO - 2018-05-22 21:43:39 --> Hooks Class Initialized
DEBUG - 2018-05-22 21:43:39 --> UTF-8 Support Enabled
INFO - 2018-05-22 21:43:39 --> Utf8 Class Initialized
INFO - 2018-05-22 21:43:39 --> URI Class Initialized
INFO - 2018-05-22 21:43:40 --> Router Class Initialized
INFO - 2018-05-22 21:43:40 --> Output Class Initialized
INFO - 2018-05-22 21:43:40 --> Security Class Initialized
DEBUG - 2018-05-22 21:43:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 21:43:40 --> Input Class Initialized
INFO - 2018-05-22 21:43:40 --> Language Class Initialized
ERROR - 2018-05-22 21:43:40 --> 404 Page Not Found: /index
INFO - 2018-05-22 21:43:40 --> Config Class Initialized
INFO - 2018-05-22 21:43:40 --> Hooks Class Initialized
DEBUG - 2018-05-22 21:43:40 --> UTF-8 Support Enabled
INFO - 2018-05-22 21:43:40 --> Utf8 Class Initialized
INFO - 2018-05-22 21:43:40 --> URI Class Initialized
INFO - 2018-05-22 21:43:40 --> Router Class Initialized
INFO - 2018-05-22 21:43:40 --> Output Class Initialized
INFO - 2018-05-22 21:43:40 --> Security Class Initialized
DEBUG - 2018-05-22 21:43:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 21:43:40 --> Input Class Initialized
INFO - 2018-05-22 21:43:40 --> Language Class Initialized
ERROR - 2018-05-22 21:43:40 --> 404 Page Not Found: /index
INFO - 2018-05-22 21:49:31 --> Config Class Initialized
INFO - 2018-05-22 21:49:31 --> Hooks Class Initialized
DEBUG - 2018-05-22 21:49:31 --> UTF-8 Support Enabled
INFO - 2018-05-22 21:49:31 --> Utf8 Class Initialized
INFO - 2018-05-22 21:49:31 --> URI Class Initialized
INFO - 2018-05-22 21:49:32 --> Router Class Initialized
INFO - 2018-05-22 21:49:32 --> Output Class Initialized
INFO - 2018-05-22 21:49:32 --> Security Class Initialized
DEBUG - 2018-05-22 21:49:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 21:49:32 --> Input Class Initialized
INFO - 2018-05-22 21:49:32 --> Language Class Initialized
INFO - 2018-05-22 21:49:32 --> Language Class Initialized
INFO - 2018-05-22 21:49:32 --> Config Class Initialized
INFO - 2018-05-22 21:49:32 --> Loader Class Initialized
DEBUG - 2018-05-22 21:49:32 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 21:49:32 --> Helper loaded: url_helper
INFO - 2018-05-22 21:49:32 --> Helper loaded: form_helper
INFO - 2018-05-22 21:49:32 --> Helper loaded: date_helper
INFO - 2018-05-22 21:49:32 --> Helper loaded: util_helper
INFO - 2018-05-22 21:49:32 --> Helper loaded: text_helper
INFO - 2018-05-22 21:49:32 --> Helper loaded: string_helper
INFO - 2018-05-22 21:49:32 --> Database Driver Class Initialized
DEBUG - 2018-05-22 21:49:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 21:49:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 21:49:32 --> Email Class Initialized
INFO - 2018-05-22 21:49:32 --> Controller Class Initialized
DEBUG - 2018-05-22 21:49:32 --> Profile MX_Controller Initialized
INFO - 2018-05-22 21:49:32 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 21:49:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 21:49:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Profile_model.php
DEBUG - 2018-05-22 21:49:32 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 21:49:32 --> Login MX_Controller Initialized
DEBUG - 2018-05-22 21:49:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-22 21:49:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
INFO - 2018-05-22 21:49:32 --> Config Class Initialized
INFO - 2018-05-22 21:49:33 --> Hooks Class Initialized
DEBUG - 2018-05-22 21:49:33 --> UTF-8 Support Enabled
INFO - 2018-05-22 21:49:33 --> Utf8 Class Initialized
INFO - 2018-05-22 21:49:33 --> URI Class Initialized
INFO - 2018-05-22 21:49:33 --> Router Class Initialized
INFO - 2018-05-22 21:49:33 --> Output Class Initialized
INFO - 2018-05-22 21:49:33 --> Security Class Initialized
DEBUG - 2018-05-22 21:49:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 21:49:33 --> Input Class Initialized
INFO - 2018-05-22 21:49:33 --> Language Class Initialized
ERROR - 2018-05-22 21:49:33 --> 404 Page Not Found: /index
INFO - 2018-05-22 21:49:41 --> Config Class Initialized
INFO - 2018-05-22 21:49:41 --> Hooks Class Initialized
DEBUG - 2018-05-22 21:49:41 --> UTF-8 Support Enabled
INFO - 2018-05-22 21:49:41 --> Utf8 Class Initialized
INFO - 2018-05-22 21:49:41 --> URI Class Initialized
INFO - 2018-05-22 21:49:41 --> Router Class Initialized
INFO - 2018-05-22 21:49:41 --> Output Class Initialized
INFO - 2018-05-22 21:49:41 --> Security Class Initialized
DEBUG - 2018-05-22 21:49:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 21:49:41 --> Input Class Initialized
INFO - 2018-05-22 21:49:41 --> Language Class Initialized
INFO - 2018-05-22 21:49:41 --> Language Class Initialized
INFO - 2018-05-22 21:49:41 --> Config Class Initialized
INFO - 2018-05-22 21:49:41 --> Loader Class Initialized
DEBUG - 2018-05-22 21:49:41 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 21:49:41 --> Helper loaded: url_helper
INFO - 2018-05-22 21:49:41 --> Helper loaded: form_helper
INFO - 2018-05-22 21:49:41 --> Helper loaded: date_helper
INFO - 2018-05-22 21:49:41 --> Helper loaded: util_helper
INFO - 2018-05-22 21:49:41 --> Helper loaded: text_helper
INFO - 2018-05-22 21:49:41 --> Helper loaded: string_helper
INFO - 2018-05-22 21:49:41 --> Database Driver Class Initialized
DEBUG - 2018-05-22 21:49:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 21:49:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 21:49:41 --> Email Class Initialized
INFO - 2018-05-22 21:49:41 --> Controller Class Initialized
DEBUG - 2018-05-22 21:49:41 --> Login MX_Controller Initialized
INFO - 2018-05-22 21:49:41 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 21:49:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 21:49:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-22 21:49:41 --> Email starts for AMDIN@colin.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-05-22 21:49:41 --> Login status AMDIN@colin.com - failure
INFO - 2018-05-22 21:49:41 --> Final output sent to browser
DEBUG - 2018-05-22 21:49:41 --> Total execution time: 0.6582
INFO - 2018-05-22 21:49:45 --> Config Class Initialized
INFO - 2018-05-22 21:49:45 --> Hooks Class Initialized
DEBUG - 2018-05-22 21:49:45 --> UTF-8 Support Enabled
INFO - 2018-05-22 21:49:45 --> Utf8 Class Initialized
INFO - 2018-05-22 21:49:45 --> URI Class Initialized
INFO - 2018-05-22 21:49:45 --> Router Class Initialized
INFO - 2018-05-22 21:49:45 --> Output Class Initialized
INFO - 2018-05-22 21:49:45 --> Security Class Initialized
DEBUG - 2018-05-22 21:49:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 21:49:45 --> Input Class Initialized
INFO - 2018-05-22 21:49:45 --> Language Class Initialized
INFO - 2018-05-22 21:49:45 --> Language Class Initialized
INFO - 2018-05-22 21:49:45 --> Config Class Initialized
INFO - 2018-05-22 21:49:45 --> Loader Class Initialized
DEBUG - 2018-05-22 21:49:45 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 21:49:45 --> Helper loaded: url_helper
INFO - 2018-05-22 21:49:45 --> Helper loaded: form_helper
INFO - 2018-05-22 21:49:45 --> Helper loaded: date_helper
INFO - 2018-05-22 21:49:45 --> Helper loaded: util_helper
INFO - 2018-05-22 21:49:45 --> Helper loaded: text_helper
INFO - 2018-05-22 21:49:45 --> Helper loaded: string_helper
INFO - 2018-05-22 21:49:45 --> Database Driver Class Initialized
DEBUG - 2018-05-22 21:49:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 21:49:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 21:49:45 --> Email Class Initialized
INFO - 2018-05-22 21:49:45 --> Controller Class Initialized
DEBUG - 2018-05-22 21:49:45 --> Login MX_Controller Initialized
INFO - 2018-05-22 21:49:45 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 21:49:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 21:49:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-22 21:49:45 --> Email starts for admin@colin.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-05-22 21:49:45 --> User session created for 1
INFO - 2018-05-22 21:49:45 --> Login status admin@colin.com - success
INFO - 2018-05-22 21:49:45 --> Final output sent to browser
DEBUG - 2018-05-22 21:49:45 --> Total execution time: 0.7042
INFO - 2018-05-22 21:49:45 --> Config Class Initialized
INFO - 2018-05-22 21:49:45 --> Hooks Class Initialized
DEBUG - 2018-05-22 21:49:45 --> UTF-8 Support Enabled
INFO - 2018-05-22 21:49:45 --> Utf8 Class Initialized
INFO - 2018-05-22 21:49:45 --> URI Class Initialized
INFO - 2018-05-22 21:49:45 --> Router Class Initialized
INFO - 2018-05-22 21:49:45 --> Output Class Initialized
INFO - 2018-05-22 21:49:45 --> Security Class Initialized
DEBUG - 2018-05-22 21:49:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 21:49:45 --> Input Class Initialized
INFO - 2018-05-22 21:49:46 --> Language Class Initialized
INFO - 2018-05-22 21:49:46 --> Language Class Initialized
INFO - 2018-05-22 21:49:46 --> Config Class Initialized
INFO - 2018-05-22 21:49:46 --> Loader Class Initialized
DEBUG - 2018-05-22 21:49:46 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 21:49:46 --> Helper loaded: url_helper
INFO - 2018-05-22 21:49:46 --> Helper loaded: form_helper
INFO - 2018-05-22 21:49:46 --> Helper loaded: date_helper
INFO - 2018-05-22 21:49:46 --> Helper loaded: util_helper
INFO - 2018-05-22 21:49:46 --> Helper loaded: text_helper
INFO - 2018-05-22 21:49:46 --> Helper loaded: string_helper
INFO - 2018-05-22 21:49:46 --> Database Driver Class Initialized
DEBUG - 2018-05-22 21:49:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 21:49:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 21:49:46 --> Email Class Initialized
INFO - 2018-05-22 21:49:46 --> Controller Class Initialized
DEBUG - 2018-05-22 21:49:46 --> Admin MX_Controller Initialized
INFO - 2018-05-22 21:49:46 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 21:49:46 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 21:49:46 --> Login MX_Controller Initialized
DEBUG - 2018-05-22 21:49:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 21:49:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-22 21:49:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-22 21:49:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-22 21:49:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-22 21:49:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-22 21:49:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-22 21:49:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/dashboard.php
INFO - 2018-05-22 21:49:46 --> Final output sent to browser
DEBUG - 2018-05-22 21:49:46 --> Total execution time: 1.0925
INFO - 2018-05-22 21:49:47 --> Config Class Initialized
INFO - 2018-05-22 21:49:47 --> Hooks Class Initialized
DEBUG - 2018-05-22 21:49:47 --> UTF-8 Support Enabled
INFO - 2018-05-22 21:49:47 --> Utf8 Class Initialized
INFO - 2018-05-22 21:49:47 --> URI Class Initialized
INFO - 2018-05-22 21:49:47 --> Router Class Initialized
INFO - 2018-05-22 21:49:47 --> Output Class Initialized
INFO - 2018-05-22 21:49:47 --> Security Class Initialized
DEBUG - 2018-05-22 21:49:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 21:49:47 --> Input Class Initialized
INFO - 2018-05-22 21:49:47 --> Language Class Initialized
ERROR - 2018-05-22 21:49:47 --> 404 Page Not Found: /index
INFO - 2018-05-22 21:49:48 --> Config Class Initialized
INFO - 2018-05-22 21:49:48 --> Hooks Class Initialized
DEBUG - 2018-05-22 21:49:48 --> UTF-8 Support Enabled
INFO - 2018-05-22 21:49:48 --> Utf8 Class Initialized
INFO - 2018-05-22 21:49:48 --> URI Class Initialized
INFO - 2018-05-22 21:49:48 --> Router Class Initialized
INFO - 2018-05-22 21:49:49 --> Output Class Initialized
INFO - 2018-05-22 21:49:49 --> Security Class Initialized
DEBUG - 2018-05-22 21:49:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 21:49:49 --> Input Class Initialized
INFO - 2018-05-22 21:49:49 --> Language Class Initialized
ERROR - 2018-05-22 21:49:49 --> 404 Page Not Found: /index
INFO - 2018-05-22 21:50:07 --> Config Class Initialized
INFO - 2018-05-22 21:50:07 --> Hooks Class Initialized
DEBUG - 2018-05-22 21:50:07 --> UTF-8 Support Enabled
INFO - 2018-05-22 21:50:07 --> Utf8 Class Initialized
INFO - 2018-05-22 21:50:07 --> URI Class Initialized
INFO - 2018-05-22 21:50:07 --> Router Class Initialized
INFO - 2018-05-22 21:50:07 --> Output Class Initialized
INFO - 2018-05-22 21:50:07 --> Security Class Initialized
DEBUG - 2018-05-22 21:50:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 21:50:07 --> Input Class Initialized
INFO - 2018-05-22 21:50:07 --> Language Class Initialized
INFO - 2018-05-22 21:50:07 --> Language Class Initialized
INFO - 2018-05-22 21:50:07 --> Config Class Initialized
INFO - 2018-05-22 21:50:07 --> Loader Class Initialized
DEBUG - 2018-05-22 21:50:07 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 21:50:07 --> Helper loaded: url_helper
INFO - 2018-05-22 21:50:07 --> Helper loaded: form_helper
INFO - 2018-05-22 21:50:07 --> Helper loaded: date_helper
INFO - 2018-05-22 21:50:07 --> Helper loaded: util_helper
INFO - 2018-05-22 21:50:07 --> Helper loaded: text_helper
INFO - 2018-05-22 21:50:07 --> Helper loaded: string_helper
INFO - 2018-05-22 21:50:07 --> Database Driver Class Initialized
DEBUG - 2018-05-22 21:50:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 21:50:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 21:50:07 --> Email Class Initialized
INFO - 2018-05-22 21:50:07 --> Controller Class Initialized
DEBUG - 2018-05-22 21:50:07 --> Profile MX_Controller Initialized
INFO - 2018-05-22 21:50:07 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 21:50:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 21:50:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Profile_model.php
DEBUG - 2018-05-22 21:50:07 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 21:50:08 --> Login MX_Controller Initialized
DEBUG - 2018-05-22 21:50:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-22 21:50:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-22 21:50:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-22 21:50:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-22 21:50:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-22 21:50:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-22 21:50:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/admin_password.php
INFO - 2018-05-22 21:50:08 --> Final output sent to browser
DEBUG - 2018-05-22 21:50:08 --> Total execution time: 0.9006
INFO - 2018-05-22 21:50:12 --> Config Class Initialized
INFO - 2018-05-22 21:50:12 --> Hooks Class Initialized
DEBUG - 2018-05-22 21:50:12 --> UTF-8 Support Enabled
INFO - 2018-05-22 21:50:12 --> Utf8 Class Initialized
INFO - 2018-05-22 21:50:12 --> URI Class Initialized
INFO - 2018-05-22 21:50:12 --> Router Class Initialized
INFO - 2018-05-22 21:50:12 --> Output Class Initialized
INFO - 2018-05-22 21:50:12 --> Security Class Initialized
DEBUG - 2018-05-22 21:50:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 21:50:12 --> Input Class Initialized
INFO - 2018-05-22 21:50:12 --> Language Class Initialized
INFO - 2018-05-22 21:50:12 --> Language Class Initialized
INFO - 2018-05-22 21:50:12 --> Config Class Initialized
INFO - 2018-05-22 21:50:12 --> Loader Class Initialized
DEBUG - 2018-05-22 21:50:12 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 21:50:12 --> Helper loaded: url_helper
INFO - 2018-05-22 21:50:12 --> Helper loaded: form_helper
INFO - 2018-05-22 21:50:12 --> Helper loaded: date_helper
INFO - 2018-05-22 21:50:12 --> Helper loaded: util_helper
INFO - 2018-05-22 21:50:13 --> Helper loaded: text_helper
INFO - 2018-05-22 21:50:13 --> Helper loaded: string_helper
INFO - 2018-05-22 21:50:13 --> Database Driver Class Initialized
DEBUG - 2018-05-22 21:50:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 21:50:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 21:50:13 --> Email Class Initialized
INFO - 2018-05-22 21:50:13 --> Controller Class Initialized
DEBUG - 2018-05-22 21:50:13 --> Admin MX_Controller Initialized
INFO - 2018-05-22 21:50:13 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 21:50:13 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 21:50:13 --> Login MX_Controller Initialized
DEBUG - 2018-05-22 21:50:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 21:50:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-22 21:50:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-22 21:50:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-22 21:50:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-22 21:50:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-22 21:50:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-22 21:50:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/dashboard.php
INFO - 2018-05-22 21:50:13 --> Final output sent to browser
DEBUG - 2018-05-22 21:50:13 --> Total execution time: 0.8184
INFO - 2018-05-22 21:50:13 --> Config Class Initialized
INFO - 2018-05-22 21:50:13 --> Hooks Class Initialized
DEBUG - 2018-05-22 21:50:13 --> UTF-8 Support Enabled
INFO - 2018-05-22 21:50:13 --> Utf8 Class Initialized
INFO - 2018-05-22 21:50:13 --> Config Class Initialized
INFO - 2018-05-22 21:50:13 --> Hooks Class Initialized
INFO - 2018-05-22 21:50:13 --> URI Class Initialized
DEBUG - 2018-05-22 21:50:13 --> UTF-8 Support Enabled
INFO - 2018-05-22 21:50:13 --> Utf8 Class Initialized
INFO - 2018-05-22 21:50:13 --> URI Class Initialized
INFO - 2018-05-22 21:50:13 --> Router Class Initialized
INFO - 2018-05-22 21:50:13 --> Router Class Initialized
INFO - 2018-05-22 21:50:13 --> Output Class Initialized
INFO - 2018-05-22 21:50:13 --> Security Class Initialized
DEBUG - 2018-05-22 21:50:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 21:50:13 --> Output Class Initialized
INFO - 2018-05-22 21:50:13 --> Input Class Initialized
INFO - 2018-05-22 21:50:13 --> Security Class Initialized
INFO - 2018-05-22 21:50:13 --> Language Class Initialized
DEBUG - 2018-05-22 21:50:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-05-22 21:50:13 --> 404 Page Not Found: /index
INFO - 2018-05-22 21:50:13 --> Input Class Initialized
INFO - 2018-05-22 21:50:14 --> Language Class Initialized
ERROR - 2018-05-22 21:50:14 --> 404 Page Not Found: /index
INFO - 2018-05-22 21:50:18 --> Config Class Initialized
INFO - 2018-05-22 21:50:18 --> Hooks Class Initialized
DEBUG - 2018-05-22 21:50:18 --> UTF-8 Support Enabled
INFO - 2018-05-22 21:50:18 --> Utf8 Class Initialized
INFO - 2018-05-22 21:50:18 --> URI Class Initialized
INFO - 2018-05-22 21:50:18 --> Router Class Initialized
INFO - 2018-05-22 21:50:18 --> Output Class Initialized
INFO - 2018-05-22 21:50:18 --> Security Class Initialized
DEBUG - 2018-05-22 21:50:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 21:50:18 --> Input Class Initialized
INFO - 2018-05-22 21:50:18 --> Language Class Initialized
INFO - 2018-05-22 21:50:18 --> Language Class Initialized
INFO - 2018-05-22 21:50:18 --> Config Class Initialized
INFO - 2018-05-22 21:50:18 --> Loader Class Initialized
DEBUG - 2018-05-22 21:50:18 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 21:50:18 --> Helper loaded: url_helper
INFO - 2018-05-22 21:50:18 --> Helper loaded: form_helper
INFO - 2018-05-22 21:50:18 --> Helper loaded: date_helper
INFO - 2018-05-22 21:50:18 --> Helper loaded: util_helper
INFO - 2018-05-22 21:50:18 --> Helper loaded: text_helper
INFO - 2018-05-22 21:50:18 --> Helper loaded: string_helper
INFO - 2018-05-22 21:50:18 --> Database Driver Class Initialized
DEBUG - 2018-05-22 21:50:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 21:50:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 21:50:18 --> Email Class Initialized
INFO - 2018-05-22 21:50:18 --> Controller Class Initialized
DEBUG - 2018-05-22 21:50:19 --> Profile MX_Controller Initialized
INFO - 2018-05-22 21:50:19 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 21:50:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 21:50:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Profile_model.php
DEBUG - 2018-05-22 21:50:19 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 21:50:19 --> Login MX_Controller Initialized
DEBUG - 2018-05-22 21:50:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-22 21:50:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-22 21:50:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-22 21:50:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-22 21:50:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-22 21:50:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-22 21:50:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/admin_password.php
INFO - 2018-05-22 21:50:19 --> Final output sent to browser
DEBUG - 2018-05-22 21:50:19 --> Total execution time: 0.9394
INFO - 2018-05-22 21:50:48 --> Config Class Initialized
INFO - 2018-05-22 21:50:48 --> Hooks Class Initialized
DEBUG - 2018-05-22 21:50:48 --> UTF-8 Support Enabled
INFO - 2018-05-22 21:50:48 --> Utf8 Class Initialized
INFO - 2018-05-22 21:50:48 --> URI Class Initialized
INFO - 2018-05-22 21:50:48 --> Router Class Initialized
INFO - 2018-05-22 21:50:48 --> Output Class Initialized
INFO - 2018-05-22 21:50:48 --> Security Class Initialized
DEBUG - 2018-05-22 21:50:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 21:50:48 --> Input Class Initialized
INFO - 2018-05-22 21:50:48 --> Language Class Initialized
INFO - 2018-05-22 21:50:48 --> Language Class Initialized
INFO - 2018-05-22 21:50:48 --> Config Class Initialized
INFO - 2018-05-22 21:50:48 --> Loader Class Initialized
DEBUG - 2018-05-22 21:50:48 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 21:50:48 --> Helper loaded: url_helper
INFO - 2018-05-22 21:50:48 --> Helper loaded: form_helper
INFO - 2018-05-22 21:50:48 --> Helper loaded: date_helper
INFO - 2018-05-22 21:50:48 --> Helper loaded: util_helper
INFO - 2018-05-22 21:50:48 --> Helper loaded: text_helper
INFO - 2018-05-22 21:50:48 --> Helper loaded: string_helper
INFO - 2018-05-22 21:50:48 --> Database Driver Class Initialized
DEBUG - 2018-05-22 21:50:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 21:50:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 21:50:48 --> Email Class Initialized
INFO - 2018-05-22 21:50:48 --> Controller Class Initialized
DEBUG - 2018-05-22 21:50:48 --> Profile MX_Controller Initialized
INFO - 2018-05-22 21:50:48 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 21:50:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 21:50:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Profile_model.php
DEBUG - 2018-05-22 21:50:48 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 21:50:48 --> Login MX_Controller Initialized
DEBUG - 2018-05-22 21:50:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-22 21:50:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-22 21:50:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-22 21:50:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-22 21:50:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-22 21:50:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-22 21:50:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/admin_password.php
INFO - 2018-05-22 21:50:48 --> Final output sent to browser
DEBUG - 2018-05-22 21:50:49 --> Total execution time: 0.8710
INFO - 2018-05-22 21:52:07 --> Config Class Initialized
INFO - 2018-05-22 21:52:07 --> Hooks Class Initialized
DEBUG - 2018-05-22 21:52:07 --> UTF-8 Support Enabled
INFO - 2018-05-22 21:52:07 --> Utf8 Class Initialized
INFO - 2018-05-22 21:52:07 --> URI Class Initialized
INFO - 2018-05-22 21:52:07 --> Router Class Initialized
INFO - 2018-05-22 21:52:07 --> Output Class Initialized
INFO - 2018-05-22 21:52:07 --> Security Class Initialized
DEBUG - 2018-05-22 21:52:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 21:52:07 --> Input Class Initialized
INFO - 2018-05-22 21:52:07 --> Language Class Initialized
INFO - 2018-05-22 21:52:07 --> Language Class Initialized
INFO - 2018-05-22 21:52:07 --> Config Class Initialized
INFO - 2018-05-22 21:52:07 --> Loader Class Initialized
DEBUG - 2018-05-22 21:52:07 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 21:52:07 --> Helper loaded: url_helper
INFO - 2018-05-22 21:52:07 --> Helper loaded: form_helper
INFO - 2018-05-22 21:52:07 --> Helper loaded: date_helper
INFO - 2018-05-22 21:52:07 --> Helper loaded: util_helper
INFO - 2018-05-22 21:52:07 --> Helper loaded: text_helper
INFO - 2018-05-22 21:52:07 --> Helper loaded: string_helper
INFO - 2018-05-22 21:52:08 --> Database Driver Class Initialized
DEBUG - 2018-05-22 21:52:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 21:52:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 21:52:08 --> Email Class Initialized
INFO - 2018-05-22 21:52:08 --> Controller Class Initialized
DEBUG - 2018-05-22 21:52:08 --> Profile MX_Controller Initialized
INFO - 2018-05-22 21:52:08 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 21:52:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 21:52:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Profile_model.php
DEBUG - 2018-05-22 21:52:08 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 21:52:08 --> Login MX_Controller Initialized
DEBUG - 2018-05-22 21:52:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-22 21:52:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-22 21:52:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-22 21:52:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-22 21:52:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-22 21:52:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-22 21:52:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/admin_password.php
INFO - 2018-05-22 21:52:08 --> Final output sent to browser
DEBUG - 2018-05-22 21:52:08 --> Total execution time: 0.8336
INFO - 2018-05-22 21:53:33 --> Config Class Initialized
INFO - 2018-05-22 21:53:33 --> Hooks Class Initialized
DEBUG - 2018-05-22 21:53:33 --> UTF-8 Support Enabled
INFO - 2018-05-22 21:53:33 --> Utf8 Class Initialized
INFO - 2018-05-22 21:53:33 --> URI Class Initialized
INFO - 2018-05-22 21:53:33 --> Router Class Initialized
INFO - 2018-05-22 21:53:34 --> Output Class Initialized
INFO - 2018-05-22 21:53:34 --> Security Class Initialized
DEBUG - 2018-05-22 21:53:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 21:53:34 --> Input Class Initialized
INFO - 2018-05-22 21:53:34 --> Language Class Initialized
INFO - 2018-05-22 21:53:34 --> Language Class Initialized
INFO - 2018-05-22 21:53:34 --> Config Class Initialized
INFO - 2018-05-22 21:53:34 --> Loader Class Initialized
DEBUG - 2018-05-22 21:53:34 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 21:53:34 --> Helper loaded: url_helper
INFO - 2018-05-22 21:53:34 --> Helper loaded: form_helper
INFO - 2018-05-22 21:53:34 --> Helper loaded: date_helper
INFO - 2018-05-22 21:53:34 --> Helper loaded: util_helper
INFO - 2018-05-22 21:53:34 --> Helper loaded: text_helper
INFO - 2018-05-22 21:53:34 --> Helper loaded: string_helper
INFO - 2018-05-22 21:53:34 --> Database Driver Class Initialized
DEBUG - 2018-05-22 21:53:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 21:53:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 21:53:34 --> Email Class Initialized
INFO - 2018-05-22 21:53:34 --> Controller Class Initialized
DEBUG - 2018-05-22 21:53:34 --> Programs MX_Controller Initialized
INFO - 2018-05-22 21:53:34 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 21:53:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-05-22 21:53:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 21:53:34 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 21:53:34 --> Login MX_Controller Initialized
DEBUG - 2018-05-22 21:53:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-22 21:53:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-22 21:53:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-22 21:53:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-22 21:53:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-22 21:53:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-22 21:53:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/programs.php
INFO - 2018-05-22 21:53:34 --> Final output sent to browser
DEBUG - 2018-05-22 21:53:34 --> Total execution time: 0.9863
INFO - 2018-05-22 21:53:35 --> Config Class Initialized
INFO - 2018-05-22 21:53:35 --> Hooks Class Initialized
DEBUG - 2018-05-22 21:53:35 --> UTF-8 Support Enabled
INFO - 2018-05-22 21:53:35 --> Utf8 Class Initialized
INFO - 2018-05-22 21:53:35 --> URI Class Initialized
INFO - 2018-05-22 21:53:35 --> Router Class Initialized
INFO - 2018-05-22 21:53:35 --> Output Class Initialized
INFO - 2018-05-22 21:53:35 --> Security Class Initialized
DEBUG - 2018-05-22 21:53:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 21:53:35 --> Input Class Initialized
INFO - 2018-05-22 21:53:35 --> Language Class Initialized
INFO - 2018-05-22 21:53:35 --> Language Class Initialized
INFO - 2018-05-22 21:53:35 --> Config Class Initialized
INFO - 2018-05-22 21:53:35 --> Loader Class Initialized
DEBUG - 2018-05-22 21:53:35 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 21:53:35 --> Helper loaded: url_helper
INFO - 2018-05-22 21:53:35 --> Helper loaded: form_helper
INFO - 2018-05-22 21:53:36 --> Helper loaded: date_helper
INFO - 2018-05-22 21:53:36 --> Helper loaded: util_helper
INFO - 2018-05-22 21:53:36 --> Helper loaded: text_helper
INFO - 2018-05-22 21:53:36 --> Helper loaded: string_helper
INFO - 2018-05-22 21:53:36 --> Database Driver Class Initialized
DEBUG - 2018-05-22 21:53:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 21:53:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 21:53:36 --> Email Class Initialized
INFO - 2018-05-22 21:53:36 --> Controller Class Initialized
DEBUG - 2018-05-22 21:53:36 --> Programs MX_Controller Initialized
INFO - 2018-05-22 21:53:36 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 21:53:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-05-22 21:53:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 21:53:36 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 21:53:36 --> Login MX_Controller Initialized
DEBUG - 2018-05-22 21:53:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-22 21:53:36 --> Final output sent to browser
DEBUG - 2018-05-22 21:53:36 --> Total execution time: 0.8183
INFO - 2018-05-22 21:53:50 --> Config Class Initialized
INFO - 2018-05-22 21:53:50 --> Hooks Class Initialized
DEBUG - 2018-05-22 21:53:50 --> UTF-8 Support Enabled
INFO - 2018-05-22 21:53:50 --> Utf8 Class Initialized
INFO - 2018-05-22 21:53:50 --> URI Class Initialized
INFO - 2018-05-22 21:53:50 --> Router Class Initialized
INFO - 2018-05-22 21:53:50 --> Output Class Initialized
INFO - 2018-05-22 21:53:50 --> Security Class Initialized
DEBUG - 2018-05-22 21:53:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 21:53:50 --> Input Class Initialized
INFO - 2018-05-22 21:53:50 --> Language Class Initialized
INFO - 2018-05-22 21:53:50 --> Language Class Initialized
INFO - 2018-05-22 21:53:50 --> Config Class Initialized
INFO - 2018-05-22 21:53:50 --> Loader Class Initialized
DEBUG - 2018-05-22 21:53:50 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 21:53:50 --> Helper loaded: url_helper
INFO - 2018-05-22 21:53:50 --> Helper loaded: form_helper
INFO - 2018-05-22 21:53:50 --> Helper loaded: date_helper
INFO - 2018-05-22 21:53:50 --> Helper loaded: util_helper
INFO - 2018-05-22 21:53:50 --> Helper loaded: text_helper
INFO - 2018-05-22 21:53:50 --> Helper loaded: string_helper
INFO - 2018-05-22 21:53:50 --> Database Driver Class Initialized
DEBUG - 2018-05-22 21:53:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 21:53:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 21:53:50 --> Email Class Initialized
INFO - 2018-05-22 21:53:51 --> Controller Class Initialized
DEBUG - 2018-05-22 21:53:51 --> Profile MX_Controller Initialized
INFO - 2018-05-22 21:53:51 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 21:53:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 21:53:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Profile_model.php
DEBUG - 2018-05-22 21:53:51 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 21:53:51 --> Login MX_Controller Initialized
DEBUG - 2018-05-22 21:53:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-22 21:53:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-22 21:53:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-22 21:53:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-22 21:53:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-22 21:53:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-22 21:53:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/admin_password.php
INFO - 2018-05-22 21:53:51 --> Final output sent to browser
DEBUG - 2018-05-22 21:53:51 --> Total execution time: 1.0142
INFO - 2018-05-22 21:55:32 --> Config Class Initialized
INFO - 2018-05-22 21:55:32 --> Hooks Class Initialized
DEBUG - 2018-05-22 21:55:32 --> UTF-8 Support Enabled
INFO - 2018-05-22 21:55:32 --> Utf8 Class Initialized
INFO - 2018-05-22 21:55:32 --> URI Class Initialized
INFO - 2018-05-22 21:55:32 --> Router Class Initialized
INFO - 2018-05-22 21:55:32 --> Output Class Initialized
INFO - 2018-05-22 21:55:32 --> Security Class Initialized
DEBUG - 2018-05-22 21:55:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 21:55:32 --> Input Class Initialized
INFO - 2018-05-22 21:55:32 --> Language Class Initialized
INFO - 2018-05-22 21:55:32 --> Language Class Initialized
INFO - 2018-05-22 21:55:32 --> Config Class Initialized
INFO - 2018-05-22 21:55:32 --> Loader Class Initialized
DEBUG - 2018-05-22 21:55:32 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 21:55:32 --> Helper loaded: url_helper
INFO - 2018-05-22 21:55:32 --> Helper loaded: form_helper
INFO - 2018-05-22 21:55:32 --> Helper loaded: date_helper
INFO - 2018-05-22 21:55:32 --> Helper loaded: util_helper
INFO - 2018-05-22 21:55:33 --> Helper loaded: text_helper
INFO - 2018-05-22 21:55:33 --> Helper loaded: string_helper
INFO - 2018-05-22 21:55:33 --> Database Driver Class Initialized
DEBUG - 2018-05-22 21:55:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 21:55:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 21:55:33 --> Email Class Initialized
INFO - 2018-05-22 21:55:33 --> Controller Class Initialized
DEBUG - 2018-05-22 21:55:33 --> Profile MX_Controller Initialized
INFO - 2018-05-22 21:55:33 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 21:55:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 21:55:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Profile_model.php
DEBUG - 2018-05-22 21:55:33 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 21:55:33 --> Login MX_Controller Initialized
DEBUG - 2018-05-22 21:55:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-22 21:55:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-22 21:55:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-22 21:55:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-22 21:55:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-22 21:55:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-22 21:55:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/admin_password.php
INFO - 2018-05-22 21:55:33 --> Final output sent to browser
DEBUG - 2018-05-22 21:55:33 --> Total execution time: 0.8282
INFO - 2018-05-22 21:56:01 --> Config Class Initialized
INFO - 2018-05-22 21:56:01 --> Hooks Class Initialized
DEBUG - 2018-05-22 21:56:01 --> UTF-8 Support Enabled
INFO - 2018-05-22 21:56:01 --> Utf8 Class Initialized
INFO - 2018-05-22 21:56:01 --> URI Class Initialized
INFO - 2018-05-22 21:56:01 --> Router Class Initialized
INFO - 2018-05-22 21:56:02 --> Output Class Initialized
INFO - 2018-05-22 21:56:02 --> Security Class Initialized
DEBUG - 2018-05-22 21:56:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 21:56:02 --> Input Class Initialized
INFO - 2018-05-22 21:56:02 --> Language Class Initialized
INFO - 2018-05-22 21:56:02 --> Language Class Initialized
INFO - 2018-05-22 21:56:02 --> Config Class Initialized
INFO - 2018-05-22 21:56:02 --> Loader Class Initialized
DEBUG - 2018-05-22 21:56:02 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 21:56:02 --> Helper loaded: url_helper
INFO - 2018-05-22 21:56:02 --> Helper loaded: form_helper
INFO - 2018-05-22 21:56:02 --> Helper loaded: date_helper
INFO - 2018-05-22 21:56:02 --> Helper loaded: util_helper
INFO - 2018-05-22 21:56:02 --> Helper loaded: text_helper
INFO - 2018-05-22 21:56:02 --> Helper loaded: string_helper
INFO - 2018-05-22 21:56:02 --> Database Driver Class Initialized
DEBUG - 2018-05-22 21:56:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 21:56:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 21:56:02 --> Email Class Initialized
INFO - 2018-05-22 21:56:02 --> Controller Class Initialized
DEBUG - 2018-05-22 21:56:02 --> Profile MX_Controller Initialized
DEBUG - 2018-05-22 21:56:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 21:56:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 21:56:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-22 21:56:02 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 21:56:02 --> Login MX_Controller Initialized
INFO - 2018-05-22 21:56:02 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 21:56:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-22 21:56:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-22 21:56:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-22 21:56:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-22 21:56:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-05-22 21:56:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-22 21:56:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-22 21:56:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/addresses.php
INFO - 2018-05-22 21:56:02 --> Final output sent to browser
DEBUG - 2018-05-22 21:56:02 --> Total execution time: 1.0192
INFO - 2018-05-22 21:56:03 --> Config Class Initialized
INFO - 2018-05-22 21:56:03 --> Hooks Class Initialized
DEBUG - 2018-05-22 21:56:03 --> UTF-8 Support Enabled
INFO - 2018-05-22 21:56:03 --> Utf8 Class Initialized
INFO - 2018-05-22 21:56:03 --> URI Class Initialized
INFO - 2018-05-22 21:56:03 --> Router Class Initialized
INFO - 2018-05-22 21:56:03 --> Output Class Initialized
INFO - 2018-05-22 21:56:03 --> Security Class Initialized
DEBUG - 2018-05-22 21:56:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 21:56:03 --> Input Class Initialized
INFO - 2018-05-22 21:56:03 --> Language Class Initialized
ERROR - 2018-05-22 21:56:03 --> 404 Page Not Found: /index
INFO - 2018-05-22 21:56:03 --> Config Class Initialized
INFO - 2018-05-22 21:56:03 --> Hooks Class Initialized
DEBUG - 2018-05-22 21:56:03 --> UTF-8 Support Enabled
INFO - 2018-05-22 21:56:04 --> Utf8 Class Initialized
INFO - 2018-05-22 21:56:04 --> URI Class Initialized
INFO - 2018-05-22 21:56:04 --> Router Class Initialized
INFO - 2018-05-22 21:56:04 --> Output Class Initialized
INFO - 2018-05-22 21:56:04 --> Security Class Initialized
DEBUG - 2018-05-22 21:56:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 21:56:04 --> Input Class Initialized
INFO - 2018-05-22 21:56:04 --> Language Class Initialized
ERROR - 2018-05-22 21:56:04 --> 404 Page Not Found: /index
INFO - 2018-05-22 21:56:04 --> Config Class Initialized
INFO - 2018-05-22 21:56:04 --> Hooks Class Initialized
DEBUG - 2018-05-22 21:56:04 --> UTF-8 Support Enabled
INFO - 2018-05-22 21:56:04 --> Utf8 Class Initialized
INFO - 2018-05-22 21:56:04 --> URI Class Initialized
INFO - 2018-05-22 21:56:04 --> Router Class Initialized
INFO - 2018-05-22 21:56:04 --> Output Class Initialized
INFO - 2018-05-22 21:56:04 --> Security Class Initialized
DEBUG - 2018-05-22 21:56:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 21:56:04 --> Input Class Initialized
INFO - 2018-05-22 21:56:04 --> Language Class Initialized
ERROR - 2018-05-22 21:56:04 --> 404 Page Not Found: /index
INFO - 2018-05-22 22:11:43 --> Config Class Initialized
INFO - 2018-05-22 22:11:43 --> Hooks Class Initialized
DEBUG - 2018-05-22 22:11:43 --> UTF-8 Support Enabled
INFO - 2018-05-22 22:11:43 --> Utf8 Class Initialized
INFO - 2018-05-22 22:11:43 --> URI Class Initialized
INFO - 2018-05-22 22:11:43 --> Router Class Initialized
INFO - 2018-05-22 22:11:43 --> Output Class Initialized
INFO - 2018-05-22 22:11:43 --> Security Class Initialized
DEBUG - 2018-05-22 22:11:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 22:11:43 --> Input Class Initialized
INFO - 2018-05-22 22:11:43 --> Language Class Initialized
INFO - 2018-05-22 22:11:43 --> Language Class Initialized
INFO - 2018-05-22 22:11:43 --> Config Class Initialized
INFO - 2018-05-22 22:11:43 --> Loader Class Initialized
DEBUG - 2018-05-22 22:11:43 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 22:11:43 --> Helper loaded: url_helper
INFO - 2018-05-22 22:11:43 --> Helper loaded: form_helper
INFO - 2018-05-22 22:11:43 --> Helper loaded: date_helper
INFO - 2018-05-22 22:11:43 --> Helper loaded: util_helper
INFO - 2018-05-22 22:11:43 --> Helper loaded: text_helper
INFO - 2018-05-22 22:11:43 --> Helper loaded: string_helper
INFO - 2018-05-22 22:11:43 --> Database Driver Class Initialized
DEBUG - 2018-05-22 22:11:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 22:11:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 22:11:43 --> Email Class Initialized
INFO - 2018-05-22 22:11:43 --> Controller Class Initialized
DEBUG - 2018-05-22 22:11:43 --> Admin MX_Controller Initialized
INFO - 2018-05-22 22:11:43 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 22:11:43 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 22:11:43 --> Login MX_Controller Initialized
DEBUG - 2018-05-22 22:11:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 22:11:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-22 22:11:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-22 22:11:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-22 22:11:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-22 22:11:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-22 22:11:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-22 22:11:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/dashboard.php
INFO - 2018-05-22 22:11:43 --> Final output sent to browser
INFO - 2018-05-22 22:11:44 --> Config Class Initialized
INFO - 2018-05-22 22:11:44 --> Hooks Class Initialized
DEBUG - 2018-05-22 22:11:44 --> Total execution time: 0.7849
INFO - 2018-05-22 22:11:44 --> Config Class Initialized
INFO - 2018-05-22 22:11:44 --> Hooks Class Initialized
DEBUG - 2018-05-22 22:11:44 --> UTF-8 Support Enabled
DEBUG - 2018-05-22 22:11:44 --> UTF-8 Support Enabled
INFO - 2018-05-22 22:11:44 --> Utf8 Class Initialized
INFO - 2018-05-22 22:11:44 --> URI Class Initialized
INFO - 2018-05-22 22:11:44 --> Router Class Initialized
INFO - 2018-05-22 22:11:44 --> Output Class Initialized
INFO - 2018-05-22 22:11:44 --> Utf8 Class Initialized
INFO - 2018-05-22 22:11:44 --> Security Class Initialized
INFO - 2018-05-22 22:11:44 --> URI Class Initialized
DEBUG - 2018-05-22 22:11:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 22:11:44 --> Input Class Initialized
INFO - 2018-05-22 22:11:44 --> Router Class Initialized
INFO - 2018-05-22 22:11:44 --> Language Class Initialized
INFO - 2018-05-22 22:11:44 --> Output Class Initialized
ERROR - 2018-05-22 22:11:44 --> 404 Page Not Found: /index
INFO - 2018-05-22 22:11:44 --> Security Class Initialized
DEBUG - 2018-05-22 22:11:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 22:11:44 --> Input Class Initialized
INFO - 2018-05-22 22:11:44 --> Language Class Initialized
ERROR - 2018-05-22 22:11:44 --> 404 Page Not Found: /index
INFO - 2018-05-22 22:11:44 --> Config Class Initialized
INFO - 2018-05-22 22:11:44 --> Hooks Class Initialized
DEBUG - 2018-05-22 22:11:44 --> UTF-8 Support Enabled
INFO - 2018-05-22 22:11:44 --> Utf8 Class Initialized
INFO - 2018-05-22 22:11:44 --> URI Class Initialized
INFO - 2018-05-22 22:11:44 --> Router Class Initialized
INFO - 2018-05-22 22:11:44 --> Output Class Initialized
INFO - 2018-05-22 22:11:44 --> Security Class Initialized
DEBUG - 2018-05-22 22:11:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 22:11:44 --> Input Class Initialized
INFO - 2018-05-22 22:11:44 --> Language Class Initialized
ERROR - 2018-05-22 22:11:44 --> 404 Page Not Found: /index
INFO - 2018-05-22 22:11:51 --> Config Class Initialized
INFO - 2018-05-22 22:11:51 --> Hooks Class Initialized
DEBUG - 2018-05-22 22:11:51 --> UTF-8 Support Enabled
INFO - 2018-05-22 22:11:51 --> Utf8 Class Initialized
INFO - 2018-05-22 22:11:51 --> URI Class Initialized
INFO - 2018-05-22 22:11:51 --> Router Class Initialized
INFO - 2018-05-22 22:11:51 --> Output Class Initialized
INFO - 2018-05-22 22:11:51 --> Security Class Initialized
DEBUG - 2018-05-22 22:11:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 22:11:51 --> Input Class Initialized
INFO - 2018-05-22 22:11:51 --> Language Class Initialized
INFO - 2018-05-22 22:11:51 --> Language Class Initialized
INFO - 2018-05-22 22:11:51 --> Config Class Initialized
INFO - 2018-05-22 22:11:51 --> Loader Class Initialized
DEBUG - 2018-05-22 22:11:51 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 22:11:51 --> Helper loaded: url_helper
INFO - 2018-05-22 22:11:51 --> Helper loaded: form_helper
INFO - 2018-05-22 22:11:51 --> Helper loaded: date_helper
INFO - 2018-05-22 22:11:51 --> Helper loaded: util_helper
INFO - 2018-05-22 22:11:51 --> Helper loaded: text_helper
INFO - 2018-05-22 22:11:51 --> Helper loaded: string_helper
INFO - 2018-05-22 22:11:51 --> Database Driver Class Initialized
DEBUG - 2018-05-22 22:11:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 22:11:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 22:11:52 --> Email Class Initialized
INFO - 2018-05-22 22:11:52 --> Controller Class Initialized
DEBUG - 2018-05-22 22:11:52 --> Profile MX_Controller Initialized
INFO - 2018-05-22 22:11:52 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 22:11:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 22:11:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Profile_model.php
DEBUG - 2018-05-22 22:11:52 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 22:11:52 --> Login MX_Controller Initialized
DEBUG - 2018-05-22 22:11:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-22 22:11:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-22 22:11:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-22 22:11:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-22 22:11:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-22 22:11:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-22 22:11:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/admin_password.php
INFO - 2018-05-22 22:11:52 --> Final output sent to browser
DEBUG - 2018-05-22 22:11:52 --> Total execution time: 0.8332
INFO - 2018-05-22 22:11:54 --> Config Class Initialized
INFO - 2018-05-22 22:11:54 --> Hooks Class Initialized
DEBUG - 2018-05-22 22:11:54 --> UTF-8 Support Enabled
INFO - 2018-05-22 22:11:54 --> Utf8 Class Initialized
INFO - 2018-05-22 22:11:54 --> URI Class Initialized
INFO - 2018-05-22 22:11:54 --> Router Class Initialized
INFO - 2018-05-22 22:11:54 --> Output Class Initialized
INFO - 2018-05-22 22:11:54 --> Security Class Initialized
DEBUG - 2018-05-22 22:11:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 22:11:54 --> Input Class Initialized
INFO - 2018-05-22 22:11:54 --> Language Class Initialized
INFO - 2018-05-22 22:11:54 --> Language Class Initialized
INFO - 2018-05-22 22:11:54 --> Config Class Initialized
INFO - 2018-05-22 22:11:55 --> Loader Class Initialized
DEBUG - 2018-05-22 22:11:55 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 22:11:55 --> Helper loaded: url_helper
INFO - 2018-05-22 22:11:55 --> Helper loaded: form_helper
INFO - 2018-05-22 22:11:55 --> Helper loaded: date_helper
INFO - 2018-05-22 22:11:55 --> Helper loaded: util_helper
INFO - 2018-05-22 22:11:55 --> Helper loaded: text_helper
INFO - 2018-05-22 22:11:55 --> Helper loaded: string_helper
INFO - 2018-05-22 22:11:55 --> Database Driver Class Initialized
DEBUG - 2018-05-22 22:11:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 22:11:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 22:11:55 --> Email Class Initialized
INFO - 2018-05-22 22:11:55 --> Controller Class Initialized
DEBUG - 2018-05-22 22:11:55 --> Admin MX_Controller Initialized
INFO - 2018-05-22 22:11:55 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 22:11:55 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 22:11:55 --> Login MX_Controller Initialized
DEBUG - 2018-05-22 22:11:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 22:11:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-22 22:11:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-22 22:11:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-22 22:11:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-22 22:11:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-22 22:11:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-22 22:11:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/dashboard.php
INFO - 2018-05-22 22:11:55 --> Final output sent to browser
DEBUG - 2018-05-22 22:11:55 --> Total execution time: 0.8011
INFO - 2018-05-22 22:11:55 --> Config Class Initialized
INFO - 2018-05-22 22:11:55 --> Config Class Initialized
INFO - 2018-05-22 22:11:55 --> Hooks Class Initialized
INFO - 2018-05-22 22:11:55 --> Hooks Class Initialized
DEBUG - 2018-05-22 22:11:55 --> UTF-8 Support Enabled
DEBUG - 2018-05-22 22:11:55 --> UTF-8 Support Enabled
INFO - 2018-05-22 22:11:55 --> Utf8 Class Initialized
INFO - 2018-05-22 22:11:55 --> Utf8 Class Initialized
INFO - 2018-05-22 22:11:55 --> URI Class Initialized
INFO - 2018-05-22 22:11:55 --> Router Class Initialized
INFO - 2018-05-22 22:11:55 --> Output Class Initialized
INFO - 2018-05-22 22:11:55 --> URI Class Initialized
INFO - 2018-05-22 22:11:55 --> Security Class Initialized
INFO - 2018-05-22 22:11:55 --> Router Class Initialized
INFO - 2018-05-22 22:11:55 --> Output Class Initialized
DEBUG - 2018-05-22 22:11:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 22:11:55 --> Security Class Initialized
INFO - 2018-05-22 22:11:55 --> Input Class Initialized
DEBUG - 2018-05-22 22:11:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 22:11:55 --> Input Class Initialized
INFO - 2018-05-22 22:11:55 --> Language Class Initialized
ERROR - 2018-05-22 22:11:55 --> 404 Page Not Found: /index
INFO - 2018-05-22 22:11:55 --> Language Class Initialized
ERROR - 2018-05-22 22:11:55 --> 404 Page Not Found: /index
INFO - 2018-05-22 22:11:56 --> Config Class Initialized
INFO - 2018-05-22 22:11:56 --> Hooks Class Initialized
DEBUG - 2018-05-22 22:11:56 --> UTF-8 Support Enabled
INFO - 2018-05-22 22:11:56 --> Utf8 Class Initialized
INFO - 2018-05-22 22:11:56 --> URI Class Initialized
INFO - 2018-05-22 22:11:56 --> Router Class Initialized
INFO - 2018-05-22 22:11:56 --> Output Class Initialized
INFO - 2018-05-22 22:11:56 --> Security Class Initialized
DEBUG - 2018-05-22 22:11:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 22:11:56 --> Input Class Initialized
INFO - 2018-05-22 22:11:56 --> Language Class Initialized
ERROR - 2018-05-22 22:11:56 --> 404 Page Not Found: /index
INFO - 2018-05-22 22:11:58 --> Config Class Initialized
INFO - 2018-05-22 22:11:58 --> Hooks Class Initialized
DEBUG - 2018-05-22 22:11:58 --> UTF-8 Support Enabled
INFO - 2018-05-22 22:11:58 --> Utf8 Class Initialized
INFO - 2018-05-22 22:11:58 --> URI Class Initialized
INFO - 2018-05-22 22:11:58 --> Router Class Initialized
INFO - 2018-05-22 22:11:58 --> Output Class Initialized
INFO - 2018-05-22 22:11:58 --> Security Class Initialized
DEBUG - 2018-05-22 22:11:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 22:11:58 --> Input Class Initialized
INFO - 2018-05-22 22:11:58 --> Language Class Initialized
INFO - 2018-05-22 22:11:58 --> Language Class Initialized
INFO - 2018-05-22 22:11:58 --> Config Class Initialized
INFO - 2018-05-22 22:11:58 --> Loader Class Initialized
DEBUG - 2018-05-22 22:11:58 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 22:11:58 --> Helper loaded: url_helper
INFO - 2018-05-22 22:11:58 --> Helper loaded: form_helper
INFO - 2018-05-22 22:11:58 --> Helper loaded: date_helper
INFO - 2018-05-22 22:11:58 --> Helper loaded: util_helper
INFO - 2018-05-22 22:11:58 --> Helper loaded: text_helper
INFO - 2018-05-22 22:11:58 --> Helper loaded: string_helper
INFO - 2018-05-22 22:11:58 --> Database Driver Class Initialized
DEBUG - 2018-05-22 22:11:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 22:11:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 22:11:59 --> Email Class Initialized
INFO - 2018-05-22 22:11:59 --> Controller Class Initialized
DEBUG - 2018-05-22 22:11:59 --> Profile MX_Controller Initialized
INFO - 2018-05-22 22:11:59 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 22:11:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 22:11:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Profile_model.php
DEBUG - 2018-05-22 22:11:59 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 22:11:59 --> Login MX_Controller Initialized
DEBUG - 2018-05-22 22:11:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-22 22:11:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-22 22:11:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-22 22:11:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-22 22:11:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-22 22:11:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-22 22:11:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/admin_password.php
INFO - 2018-05-22 22:11:59 --> Final output sent to browser
DEBUG - 2018-05-22 22:11:59 --> Total execution time: 0.8156
INFO - 2018-05-22 22:12:01 --> Config Class Initialized
INFO - 2018-05-22 22:12:01 --> Hooks Class Initialized
DEBUG - 2018-05-22 22:12:01 --> UTF-8 Support Enabled
INFO - 2018-05-22 22:12:01 --> Utf8 Class Initialized
INFO - 2018-05-22 22:12:01 --> URI Class Initialized
INFO - 2018-05-22 22:12:01 --> Router Class Initialized
INFO - 2018-05-22 22:12:01 --> Output Class Initialized
INFO - 2018-05-22 22:12:01 --> Security Class Initialized
DEBUG - 2018-05-22 22:12:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 22:12:01 --> Input Class Initialized
INFO - 2018-05-22 22:12:01 --> Language Class Initialized
INFO - 2018-05-22 22:12:01 --> Language Class Initialized
INFO - 2018-05-22 22:12:01 --> Config Class Initialized
INFO - 2018-05-22 22:12:01 --> Loader Class Initialized
DEBUG - 2018-05-22 22:12:01 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 22:12:01 --> Helper loaded: url_helper
INFO - 2018-05-22 22:12:01 --> Helper loaded: form_helper
INFO - 2018-05-22 22:12:01 --> Helper loaded: date_helper
INFO - 2018-05-22 22:12:01 --> Helper loaded: util_helper
INFO - 2018-05-22 22:12:01 --> Helper loaded: text_helper
INFO - 2018-05-22 22:12:02 --> Helper loaded: string_helper
INFO - 2018-05-22 22:12:02 --> Database Driver Class Initialized
DEBUG - 2018-05-22 22:12:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 22:12:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 22:12:02 --> Email Class Initialized
INFO - 2018-05-22 22:12:02 --> Controller Class Initialized
DEBUG - 2018-05-22 22:12:02 --> Admin MX_Controller Initialized
INFO - 2018-05-22 22:12:02 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 22:12:02 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 22:12:02 --> Login MX_Controller Initialized
DEBUG - 2018-05-22 22:12:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 22:12:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-22 22:12:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-22 22:12:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-22 22:12:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-22 22:12:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-22 22:12:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-22 22:12:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/dashboard.php
INFO - 2018-05-22 22:12:02 --> Final output sent to browser
DEBUG - 2018-05-22 22:12:02 --> Total execution time: 0.8007
INFO - 2018-05-22 22:12:02 --> Config Class Initialized
INFO - 2018-05-22 22:12:02 --> Hooks Class Initialized
INFO - 2018-05-22 22:12:02 --> Config Class Initialized
INFO - 2018-05-22 22:12:02 --> Hooks Class Initialized
DEBUG - 2018-05-22 22:12:02 --> UTF-8 Support Enabled
INFO - 2018-05-22 22:12:02 --> Utf8 Class Initialized
DEBUG - 2018-05-22 22:12:02 --> UTF-8 Support Enabled
INFO - 2018-05-22 22:12:02 --> Utf8 Class Initialized
INFO - 2018-05-22 22:12:02 --> URI Class Initialized
INFO - 2018-05-22 22:12:02 --> URI Class Initialized
INFO - 2018-05-22 22:12:02 --> Router Class Initialized
INFO - 2018-05-22 22:12:02 --> Output Class Initialized
INFO - 2018-05-22 22:12:02 --> Router Class Initialized
INFO - 2018-05-22 22:12:02 --> Security Class Initialized
DEBUG - 2018-05-22 22:12:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 22:12:02 --> Input Class Initialized
INFO - 2018-05-22 22:12:02 --> Language Class Initialized
INFO - 2018-05-22 22:12:02 --> Output Class Initialized
ERROR - 2018-05-22 22:12:02 --> 404 Page Not Found: /index
INFO - 2018-05-22 22:12:02 --> Security Class Initialized
DEBUG - 2018-05-22 22:12:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 22:12:02 --> Input Class Initialized
INFO - 2018-05-22 22:12:02 --> Language Class Initialized
ERROR - 2018-05-22 22:12:02 --> 404 Page Not Found: /index
INFO - 2018-05-22 22:12:05 --> Config Class Initialized
INFO - 2018-05-22 22:12:05 --> Hooks Class Initialized
DEBUG - 2018-05-22 22:12:05 --> UTF-8 Support Enabled
INFO - 2018-05-22 22:12:05 --> Utf8 Class Initialized
INFO - 2018-05-22 22:12:05 --> URI Class Initialized
INFO - 2018-05-22 22:12:05 --> Router Class Initialized
INFO - 2018-05-22 22:12:05 --> Output Class Initialized
INFO - 2018-05-22 22:12:05 --> Security Class Initialized
DEBUG - 2018-05-22 22:12:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 22:12:05 --> Input Class Initialized
INFO - 2018-05-22 22:12:05 --> Language Class Initialized
INFO - 2018-05-22 22:12:05 --> Language Class Initialized
INFO - 2018-05-22 22:12:05 --> Config Class Initialized
INFO - 2018-05-22 22:12:05 --> Loader Class Initialized
DEBUG - 2018-05-22 22:12:05 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 22:12:05 --> Helper loaded: url_helper
INFO - 2018-05-22 22:12:05 --> Helper loaded: form_helper
INFO - 2018-05-22 22:12:05 --> Helper loaded: date_helper
INFO - 2018-05-22 22:12:05 --> Helper loaded: util_helper
INFO - 2018-05-22 22:12:05 --> Helper loaded: text_helper
INFO - 2018-05-22 22:12:05 --> Helper loaded: string_helper
INFO - 2018-05-22 22:12:05 --> Database Driver Class Initialized
DEBUG - 2018-05-22 22:12:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 22:12:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 22:12:05 --> Email Class Initialized
INFO - 2018-05-22 22:12:06 --> Controller Class Initialized
DEBUG - 2018-05-22 22:12:06 --> Profile MX_Controller Initialized
INFO - 2018-05-22 22:12:06 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 22:12:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 22:12:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Profile_model.php
DEBUG - 2018-05-22 22:12:06 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 22:12:06 --> Login MX_Controller Initialized
DEBUG - 2018-05-22 22:12:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-22 22:12:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-22 22:12:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-22 22:12:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-22 22:12:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-22 22:12:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-22 22:12:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/admin_password.php
INFO - 2018-05-22 22:12:06 --> Final output sent to browser
DEBUG - 2018-05-22 22:12:06 --> Total execution time: 0.8236
INFO - 2018-05-22 22:12:24 --> Config Class Initialized
INFO - 2018-05-22 22:12:24 --> Hooks Class Initialized
DEBUG - 2018-05-22 22:12:24 --> UTF-8 Support Enabled
INFO - 2018-05-22 22:12:24 --> Utf8 Class Initialized
INFO - 2018-05-22 22:12:24 --> URI Class Initialized
INFO - 2018-05-22 22:12:24 --> Router Class Initialized
INFO - 2018-05-22 22:12:24 --> Output Class Initialized
INFO - 2018-05-22 22:12:24 --> Security Class Initialized
DEBUG - 2018-05-22 22:12:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 22:12:24 --> Input Class Initialized
INFO - 2018-05-22 22:12:24 --> Language Class Initialized
INFO - 2018-05-22 22:12:24 --> Language Class Initialized
INFO - 2018-05-22 22:12:24 --> Config Class Initialized
INFO - 2018-05-22 22:12:24 --> Loader Class Initialized
DEBUG - 2018-05-22 22:12:24 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 22:12:24 --> Helper loaded: url_helper
INFO - 2018-05-22 22:12:24 --> Helper loaded: form_helper
INFO - 2018-05-22 22:12:24 --> Helper loaded: date_helper
INFO - 2018-05-22 22:12:24 --> Helper loaded: util_helper
INFO - 2018-05-22 22:12:24 --> Helper loaded: text_helper
INFO - 2018-05-22 22:12:24 --> Helper loaded: string_helper
INFO - 2018-05-22 22:12:24 --> Database Driver Class Initialized
DEBUG - 2018-05-22 22:12:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 22:12:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 22:12:24 --> Email Class Initialized
INFO - 2018-05-22 22:12:24 --> Controller Class Initialized
DEBUG - 2018-05-22 22:12:24 --> Admin MX_Controller Initialized
INFO - 2018-05-22 22:12:24 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 22:12:24 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 22:12:24 --> Login MX_Controller Initialized
DEBUG - 2018-05-22 22:12:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 22:12:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-22 22:12:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-22 22:12:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-22 22:12:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-22 22:12:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-22 22:12:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-22 22:12:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/dashboard.php
INFO - 2018-05-22 22:12:24 --> Final output sent to browser
DEBUG - 2018-05-22 22:12:24 --> Total execution time: 0.8128
INFO - 2018-05-22 22:12:25 --> Config Class Initialized
INFO - 2018-05-22 22:12:25 --> Hooks Class Initialized
DEBUG - 2018-05-22 22:12:25 --> UTF-8 Support Enabled
INFO - 2018-05-22 22:12:25 --> Config Class Initialized
INFO - 2018-05-22 22:12:25 --> Hooks Class Initialized
INFO - 2018-05-22 22:12:25 --> Utf8 Class Initialized
DEBUG - 2018-05-22 22:12:25 --> UTF-8 Support Enabled
INFO - 2018-05-22 22:12:25 --> Utf8 Class Initialized
INFO - 2018-05-22 22:12:25 --> URI Class Initialized
INFO - 2018-05-22 22:12:25 --> URI Class Initialized
INFO - 2018-05-22 22:12:25 --> Router Class Initialized
INFO - 2018-05-22 22:12:25 --> Router Class Initialized
INFO - 2018-05-22 22:12:25 --> Output Class Initialized
INFO - 2018-05-22 22:12:25 --> Security Class Initialized
INFO - 2018-05-22 22:12:25 --> Output Class Initialized
DEBUG - 2018-05-22 22:12:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 22:12:25 --> Input Class Initialized
INFO - 2018-05-22 22:12:25 --> Language Class Initialized
INFO - 2018-05-22 22:12:25 --> Security Class Initialized
ERROR - 2018-05-22 22:12:25 --> 404 Page Not Found: /index
DEBUG - 2018-05-22 22:12:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 22:12:25 --> Input Class Initialized
INFO - 2018-05-22 22:12:25 --> Language Class Initialized
ERROR - 2018-05-22 22:12:25 --> 404 Page Not Found: /index
INFO - 2018-05-22 22:12:28 --> Config Class Initialized
INFO - 2018-05-22 22:12:28 --> Hooks Class Initialized
DEBUG - 2018-05-22 22:12:28 --> UTF-8 Support Enabled
INFO - 2018-05-22 22:12:28 --> Utf8 Class Initialized
INFO - 2018-05-22 22:12:28 --> URI Class Initialized
INFO - 2018-05-22 22:12:28 --> Router Class Initialized
INFO - 2018-05-22 22:12:28 --> Output Class Initialized
INFO - 2018-05-22 22:12:28 --> Security Class Initialized
DEBUG - 2018-05-22 22:12:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 22:12:28 --> Input Class Initialized
INFO - 2018-05-22 22:12:28 --> Language Class Initialized
INFO - 2018-05-22 22:12:28 --> Language Class Initialized
INFO - 2018-05-22 22:12:28 --> Config Class Initialized
INFO - 2018-05-22 22:12:28 --> Loader Class Initialized
DEBUG - 2018-05-22 22:12:28 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 22:12:28 --> Helper loaded: url_helper
INFO - 2018-05-22 22:12:28 --> Helper loaded: form_helper
INFO - 2018-05-22 22:12:28 --> Helper loaded: date_helper
INFO - 2018-05-22 22:12:28 --> Helper loaded: util_helper
INFO - 2018-05-22 22:12:28 --> Helper loaded: text_helper
INFO - 2018-05-22 22:12:28 --> Helper loaded: string_helper
INFO - 2018-05-22 22:12:28 --> Database Driver Class Initialized
DEBUG - 2018-05-22 22:12:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 22:12:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 22:12:28 --> Email Class Initialized
INFO - 2018-05-22 22:12:28 --> Controller Class Initialized
DEBUG - 2018-05-22 22:12:28 --> Profile MX_Controller Initialized
INFO - 2018-05-22 22:12:28 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 22:12:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 22:12:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Profile_model.php
DEBUG - 2018-05-22 22:12:28 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 22:12:28 --> Login MX_Controller Initialized
DEBUG - 2018-05-22 22:12:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-22 22:12:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-22 22:12:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-22 22:12:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-22 22:12:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-22 22:12:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-22 22:12:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/admin_password.php
INFO - 2018-05-22 22:12:28 --> Final output sent to browser
DEBUG - 2018-05-22 22:12:28 --> Total execution time: 0.8286
INFO - 2018-05-22 22:12:31 --> Config Class Initialized
INFO - 2018-05-22 22:12:31 --> Hooks Class Initialized
DEBUG - 2018-05-22 22:12:31 --> UTF-8 Support Enabled
INFO - 2018-05-22 22:12:31 --> Utf8 Class Initialized
INFO - 2018-05-22 22:12:31 --> URI Class Initialized
INFO - 2018-05-22 22:12:31 --> Router Class Initialized
INFO - 2018-05-22 22:12:31 --> Output Class Initialized
INFO - 2018-05-22 22:12:31 --> Security Class Initialized
DEBUG - 2018-05-22 22:12:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 22:12:31 --> Input Class Initialized
INFO - 2018-05-22 22:12:31 --> Language Class Initialized
INFO - 2018-05-22 22:12:31 --> Language Class Initialized
INFO - 2018-05-22 22:12:31 --> Config Class Initialized
INFO - 2018-05-22 22:12:31 --> Loader Class Initialized
DEBUG - 2018-05-22 22:12:31 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 22:12:31 --> Helper loaded: url_helper
INFO - 2018-05-22 22:12:31 --> Helper loaded: form_helper
INFO - 2018-05-22 22:12:31 --> Helper loaded: date_helper
INFO - 2018-05-22 22:12:31 --> Helper loaded: util_helper
INFO - 2018-05-22 22:12:31 --> Helper loaded: text_helper
INFO - 2018-05-22 22:12:31 --> Helper loaded: string_helper
INFO - 2018-05-22 22:12:31 --> Database Driver Class Initialized
DEBUG - 2018-05-22 22:12:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 22:12:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 22:12:31 --> Email Class Initialized
INFO - 2018-05-22 22:12:31 --> Controller Class Initialized
DEBUG - 2018-05-22 22:12:31 --> Admin MX_Controller Initialized
INFO - 2018-05-22 22:12:31 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 22:12:31 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 22:12:31 --> Login MX_Controller Initialized
DEBUG - 2018-05-22 22:12:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 22:12:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-22 22:12:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-22 22:12:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-22 22:12:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-22 22:12:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-22 22:12:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-22 22:12:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/dashboard.php
INFO - 2018-05-22 22:12:32 --> Final output sent to browser
DEBUG - 2018-05-22 22:12:32 --> Total execution time: 0.8286
INFO - 2018-05-22 22:12:32 --> Config Class Initialized
INFO - 2018-05-22 22:12:32 --> Hooks Class Initialized
INFO - 2018-05-22 22:12:32 --> Config Class Initialized
INFO - 2018-05-22 22:12:32 --> Hooks Class Initialized
DEBUG - 2018-05-22 22:12:32 --> UTF-8 Support Enabled
INFO - 2018-05-22 22:12:32 --> Utf8 Class Initialized
DEBUG - 2018-05-22 22:12:32 --> UTF-8 Support Enabled
INFO - 2018-05-22 22:12:32 --> Utf8 Class Initialized
INFO - 2018-05-22 22:12:32 --> URI Class Initialized
INFO - 2018-05-22 22:12:32 --> URI Class Initialized
INFO - 2018-05-22 22:12:32 --> Router Class Initialized
INFO - 2018-05-22 22:12:32 --> Router Class Initialized
INFO - 2018-05-22 22:12:32 --> Output Class Initialized
INFO - 2018-05-22 22:12:32 --> Output Class Initialized
INFO - 2018-05-22 22:12:32 --> Security Class Initialized
DEBUG - 2018-05-22 22:12:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 22:12:32 --> Input Class Initialized
INFO - 2018-05-22 22:12:32 --> Language Class Initialized
ERROR - 2018-05-22 22:12:32 --> 404 Page Not Found: /index
INFO - 2018-05-22 22:12:32 --> Security Class Initialized
DEBUG - 2018-05-22 22:12:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 22:12:32 --> Input Class Initialized
INFO - 2018-05-22 22:12:32 --> Language Class Initialized
ERROR - 2018-05-22 22:12:32 --> 404 Page Not Found: /index
INFO - 2018-05-22 22:12:34 --> Config Class Initialized
INFO - 2018-05-22 22:12:34 --> Hooks Class Initialized
DEBUG - 2018-05-22 22:12:34 --> UTF-8 Support Enabled
INFO - 2018-05-22 22:12:34 --> Utf8 Class Initialized
INFO - 2018-05-22 22:12:34 --> URI Class Initialized
INFO - 2018-05-22 22:12:34 --> Router Class Initialized
INFO - 2018-05-22 22:12:34 --> Output Class Initialized
INFO - 2018-05-22 22:12:34 --> Security Class Initialized
DEBUG - 2018-05-22 22:12:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 22:12:34 --> Input Class Initialized
INFO - 2018-05-22 22:12:35 --> Language Class Initialized
INFO - 2018-05-22 22:12:35 --> Language Class Initialized
INFO - 2018-05-22 22:12:35 --> Config Class Initialized
INFO - 2018-05-22 22:12:35 --> Loader Class Initialized
DEBUG - 2018-05-22 22:12:35 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 22:12:35 --> Helper loaded: url_helper
INFO - 2018-05-22 22:12:35 --> Helper loaded: form_helper
INFO - 2018-05-22 22:12:35 --> Helper loaded: date_helper
INFO - 2018-05-22 22:12:35 --> Helper loaded: util_helper
INFO - 2018-05-22 22:12:35 --> Helper loaded: text_helper
INFO - 2018-05-22 22:12:35 --> Helper loaded: string_helper
INFO - 2018-05-22 22:12:35 --> Database Driver Class Initialized
DEBUG - 2018-05-22 22:12:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 22:12:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 22:12:35 --> Email Class Initialized
INFO - 2018-05-22 22:12:35 --> Controller Class Initialized
DEBUG - 2018-05-22 22:12:35 --> Profile MX_Controller Initialized
INFO - 2018-05-22 22:12:35 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 22:12:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 22:12:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Profile_model.php
DEBUG - 2018-05-22 22:12:35 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 22:12:35 --> Login MX_Controller Initialized
DEBUG - 2018-05-22 22:12:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-22 22:12:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-22 22:12:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-22 22:12:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-22 22:12:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-22 22:12:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-22 22:12:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/admin_password.php
INFO - 2018-05-22 22:12:35 --> Final output sent to browser
DEBUG - 2018-05-22 22:12:35 --> Total execution time: 0.8357
INFO - 2018-05-22 22:13:18 --> Config Class Initialized
INFO - 2018-05-22 22:13:18 --> Hooks Class Initialized
DEBUG - 2018-05-22 22:13:18 --> UTF-8 Support Enabled
INFO - 2018-05-22 22:13:18 --> Utf8 Class Initialized
INFO - 2018-05-22 22:13:18 --> URI Class Initialized
DEBUG - 2018-05-22 22:13:18 --> No URI present. Default controller set.
INFO - 2018-05-22 22:13:18 --> Router Class Initialized
INFO - 2018-05-22 22:13:18 --> Output Class Initialized
INFO - 2018-05-22 22:13:19 --> Security Class Initialized
DEBUG - 2018-05-22 22:13:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 22:13:19 --> Input Class Initialized
INFO - 2018-05-22 22:13:19 --> Language Class Initialized
INFO - 2018-05-22 22:13:19 --> Language Class Initialized
INFO - 2018-05-22 22:13:19 --> Config Class Initialized
INFO - 2018-05-22 22:13:19 --> Loader Class Initialized
DEBUG - 2018-05-22 22:13:19 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 22:13:19 --> Helper loaded: url_helper
INFO - 2018-05-22 22:13:19 --> Helper loaded: form_helper
INFO - 2018-05-22 22:13:19 --> Helper loaded: date_helper
INFO - 2018-05-22 22:13:19 --> Helper loaded: util_helper
INFO - 2018-05-22 22:13:19 --> Helper loaded: text_helper
INFO - 2018-05-22 22:13:19 --> Helper loaded: string_helper
INFO - 2018-05-22 22:13:19 --> Database Driver Class Initialized
DEBUG - 2018-05-22 22:13:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 22:13:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 22:13:19 --> Email Class Initialized
INFO - 2018-05-22 22:13:19 --> Controller Class Initialized
DEBUG - 2018-05-22 22:13:19 --> Home MX_Controller Initialized
DEBUG - 2018-05-22 22:13:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 22:13:19 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 22:13:19 --> Login MX_Controller Initialized
INFO - 2018-05-22 22:13:19 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 22:13:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 22:13:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-22 22:13:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-22 22:13:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-22 22:13:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-22 22:13:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-22 22:13:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-22 22:13:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-05-22 22:13:19 --> Final output sent to browser
DEBUG - 2018-05-22 22:13:19 --> Total execution time: 0.9718
INFO - 2018-05-22 22:13:20 --> Config Class Initialized
INFO - 2018-05-22 22:13:20 --> Hooks Class Initialized
DEBUG - 2018-05-22 22:13:20 --> UTF-8 Support Enabled
INFO - 2018-05-22 22:13:20 --> Utf8 Class Initialized
INFO - 2018-05-22 22:13:20 --> URI Class Initialized
INFO - 2018-05-22 22:13:20 --> Router Class Initialized
INFO - 2018-05-22 22:13:20 --> Output Class Initialized
INFO - 2018-05-22 22:13:20 --> Security Class Initialized
DEBUG - 2018-05-22 22:13:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 22:13:20 --> Input Class Initialized
INFO - 2018-05-22 22:13:20 --> Language Class Initialized
ERROR - 2018-05-22 22:13:20 --> 404 Page Not Found: /index
INFO - 2018-05-22 22:13:20 --> Config Class Initialized
INFO - 2018-05-22 22:13:20 --> Hooks Class Initialized
DEBUG - 2018-05-22 22:13:20 --> UTF-8 Support Enabled
INFO - 2018-05-22 22:13:20 --> Utf8 Class Initialized
INFO - 2018-05-22 22:13:20 --> URI Class Initialized
INFO - 2018-05-22 22:13:20 --> Router Class Initialized
INFO - 2018-05-22 22:13:20 --> Output Class Initialized
INFO - 2018-05-22 22:13:20 --> Security Class Initialized
DEBUG - 2018-05-22 22:13:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 22:13:20 --> Input Class Initialized
INFO - 2018-05-22 22:13:20 --> Language Class Initialized
ERROR - 2018-05-22 22:13:20 --> 404 Page Not Found: /index
INFO - 2018-05-22 22:14:33 --> Config Class Initialized
INFO - 2018-05-22 22:14:33 --> Hooks Class Initialized
DEBUG - 2018-05-22 22:14:33 --> UTF-8 Support Enabled
INFO - 2018-05-22 22:14:33 --> Utf8 Class Initialized
INFO - 2018-05-22 22:14:33 --> URI Class Initialized
INFO - 2018-05-22 22:14:33 --> Router Class Initialized
INFO - 2018-05-22 22:14:33 --> Output Class Initialized
INFO - 2018-05-22 22:14:33 --> Security Class Initialized
DEBUG - 2018-05-22 22:14:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 22:14:33 --> Input Class Initialized
INFO - 2018-05-22 22:14:33 --> Language Class Initialized
INFO - 2018-05-22 22:14:33 --> Language Class Initialized
INFO - 2018-05-22 22:14:33 --> Config Class Initialized
INFO - 2018-05-22 22:14:33 --> Loader Class Initialized
DEBUG - 2018-05-22 22:14:33 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 22:14:33 --> Helper loaded: url_helper
INFO - 2018-05-22 22:14:33 --> Helper loaded: form_helper
INFO - 2018-05-22 22:14:33 --> Helper loaded: date_helper
INFO - 2018-05-22 22:14:33 --> Helper loaded: util_helper
INFO - 2018-05-22 22:14:33 --> Helper loaded: text_helper
INFO - 2018-05-22 22:14:33 --> Helper loaded: string_helper
INFO - 2018-05-22 22:14:33 --> Database Driver Class Initialized
DEBUG - 2018-05-22 22:14:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 22:14:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 22:14:34 --> Email Class Initialized
INFO - 2018-05-22 22:14:34 --> Controller Class Initialized
DEBUG - 2018-05-22 22:14:34 --> Login MX_Controller Initialized
INFO - 2018-05-22 22:14:34 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 22:14:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 22:14:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-22 22:14:34 --> 4 Loggedout
INFO - 2018-05-22 22:14:34 --> Config Class Initialized
INFO - 2018-05-22 22:14:34 --> Hooks Class Initialized
DEBUG - 2018-05-22 22:14:34 --> UTF-8 Support Enabled
INFO - 2018-05-22 22:14:34 --> Utf8 Class Initialized
INFO - 2018-05-22 22:14:34 --> URI Class Initialized
INFO - 2018-05-22 22:14:34 --> Router Class Initialized
INFO - 2018-05-22 22:14:34 --> Output Class Initialized
INFO - 2018-05-22 22:14:34 --> Security Class Initialized
DEBUG - 2018-05-22 22:14:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 22:14:34 --> Input Class Initialized
INFO - 2018-05-22 22:14:34 --> Language Class Initialized
INFO - 2018-05-22 22:14:34 --> Language Class Initialized
INFO - 2018-05-22 22:14:34 --> Config Class Initialized
INFO - 2018-05-22 22:14:34 --> Loader Class Initialized
DEBUG - 2018-05-22 22:14:34 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 22:14:34 --> Helper loaded: url_helper
INFO - 2018-05-22 22:14:34 --> Helper loaded: form_helper
INFO - 2018-05-22 22:14:34 --> Helper loaded: date_helper
INFO - 2018-05-22 22:14:34 --> Helper loaded: util_helper
INFO - 2018-05-22 22:14:34 --> Helper loaded: text_helper
INFO - 2018-05-22 22:14:34 --> Helper loaded: string_helper
INFO - 2018-05-22 22:14:34 --> Database Driver Class Initialized
DEBUG - 2018-05-22 22:14:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 22:14:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 22:14:34 --> Email Class Initialized
INFO - 2018-05-22 22:14:34 --> Controller Class Initialized
DEBUG - 2018-05-22 22:14:34 --> Home MX_Controller Initialized
DEBUG - 2018-05-22 22:14:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 22:14:34 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 22:14:34 --> Login MX_Controller Initialized
INFO - 2018-05-22 22:14:34 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 22:14:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 22:14:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-22 22:14:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-05-22 22:14:36 --> Config Class Initialized
INFO - 2018-05-22 22:14:36 --> Hooks Class Initialized
DEBUG - 2018-05-22 22:14:36 --> UTF-8 Support Enabled
INFO - 2018-05-22 22:14:36 --> Utf8 Class Initialized
INFO - 2018-05-22 22:14:36 --> URI Class Initialized
INFO - 2018-05-22 22:14:36 --> Router Class Initialized
INFO - 2018-05-22 22:14:36 --> Output Class Initialized
INFO - 2018-05-22 22:14:36 --> Security Class Initialized
DEBUG - 2018-05-22 22:14:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 22:14:36 --> Input Class Initialized
INFO - 2018-05-22 22:14:36 --> Language Class Initialized
INFO - 2018-05-22 22:14:36 --> Language Class Initialized
INFO - 2018-05-22 22:14:36 --> Config Class Initialized
INFO - 2018-05-22 22:14:36 --> Loader Class Initialized
DEBUG - 2018-05-22 22:14:36 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 22:14:36 --> Helper loaded: url_helper
INFO - 2018-05-22 22:14:36 --> Helper loaded: form_helper
INFO - 2018-05-22 22:14:36 --> Helper loaded: date_helper
INFO - 2018-05-22 22:14:36 --> Helper loaded: util_helper
INFO - 2018-05-22 22:14:36 --> Helper loaded: text_helper
INFO - 2018-05-22 22:14:36 --> Helper loaded: string_helper
INFO - 2018-05-22 22:14:36 --> Database Driver Class Initialized
DEBUG - 2018-05-22 22:14:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 22:14:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 22:14:37 --> Email Class Initialized
INFO - 2018-05-22 22:14:37 --> Controller Class Initialized
DEBUG - 2018-05-22 22:14:37 --> Login MX_Controller Initialized
INFO - 2018-05-22 22:14:37 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 22:14:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 22:14:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-22 22:14:37 --> Email starts for user@colin.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-05-22 22:14:37 --> Login status user@colin.com - failure
INFO - 2018-05-22 22:14:37 --> Final output sent to browser
DEBUG - 2018-05-22 22:14:37 --> Total execution time: 0.6305
INFO - 2018-05-22 22:14:40 --> Config Class Initialized
INFO - 2018-05-22 22:14:40 --> Hooks Class Initialized
DEBUG - 2018-05-22 22:14:40 --> UTF-8 Support Enabled
INFO - 2018-05-22 22:14:40 --> Utf8 Class Initialized
INFO - 2018-05-22 22:14:40 --> URI Class Initialized
INFO - 2018-05-22 22:14:40 --> Router Class Initialized
INFO - 2018-05-22 22:14:40 --> Output Class Initialized
INFO - 2018-05-22 22:14:40 --> Security Class Initialized
DEBUG - 2018-05-22 22:14:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 22:14:40 --> Input Class Initialized
INFO - 2018-05-22 22:14:40 --> Language Class Initialized
INFO - 2018-05-22 22:14:40 --> Language Class Initialized
INFO - 2018-05-22 22:14:40 --> Config Class Initialized
INFO - 2018-05-22 22:14:40 --> Loader Class Initialized
DEBUG - 2018-05-22 22:14:40 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 22:14:40 --> Helper loaded: url_helper
INFO - 2018-05-22 22:14:40 --> Helper loaded: form_helper
INFO - 2018-05-22 22:14:40 --> Helper loaded: date_helper
INFO - 2018-05-22 22:14:40 --> Helper loaded: util_helper
INFO - 2018-05-22 22:14:40 --> Helper loaded: text_helper
INFO - 2018-05-22 22:14:40 --> Helper loaded: string_helper
INFO - 2018-05-22 22:14:40 --> Database Driver Class Initialized
DEBUG - 2018-05-22 22:14:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 22:14:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 22:14:40 --> Email Class Initialized
INFO - 2018-05-22 22:14:40 --> Controller Class Initialized
DEBUG - 2018-05-22 22:14:40 --> Login MX_Controller Initialized
INFO - 2018-05-22 22:14:40 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 22:14:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 22:14:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-22 22:14:41 --> Email starts for user@colin.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-05-22 22:14:41 --> Login status user@colin.com - failure
INFO - 2018-05-22 22:14:41 --> Final output sent to browser
DEBUG - 2018-05-22 22:14:41 --> Total execution time: 0.6378
INFO - 2018-05-22 22:14:42 --> Config Class Initialized
INFO - 2018-05-22 22:14:43 --> Hooks Class Initialized
DEBUG - 2018-05-22 22:14:43 --> UTF-8 Support Enabled
INFO - 2018-05-22 22:14:43 --> Utf8 Class Initialized
INFO - 2018-05-22 22:14:43 --> URI Class Initialized
INFO - 2018-05-22 22:14:43 --> Router Class Initialized
INFO - 2018-05-22 22:14:43 --> Output Class Initialized
INFO - 2018-05-22 22:14:43 --> Security Class Initialized
DEBUG - 2018-05-22 22:14:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 22:14:43 --> Input Class Initialized
INFO - 2018-05-22 22:14:43 --> Language Class Initialized
INFO - 2018-05-22 22:14:43 --> Language Class Initialized
INFO - 2018-05-22 22:14:43 --> Config Class Initialized
INFO - 2018-05-22 22:14:43 --> Loader Class Initialized
DEBUG - 2018-05-22 22:14:43 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 22:14:43 --> Helper loaded: url_helper
INFO - 2018-05-22 22:14:43 --> Helper loaded: form_helper
INFO - 2018-05-22 22:14:43 --> Helper loaded: date_helper
INFO - 2018-05-22 22:14:43 --> Helper loaded: util_helper
INFO - 2018-05-22 22:14:43 --> Helper loaded: text_helper
INFO - 2018-05-22 22:14:43 --> Helper loaded: string_helper
INFO - 2018-05-22 22:14:43 --> Database Driver Class Initialized
DEBUG - 2018-05-22 22:14:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 22:14:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 22:14:43 --> Email Class Initialized
INFO - 2018-05-22 22:14:43 --> Controller Class Initialized
DEBUG - 2018-05-22 22:14:43 --> Login MX_Controller Initialized
INFO - 2018-05-22 22:14:43 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 22:14:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 22:14:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-22 22:14:43 --> Email starts for user@colin.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-05-22 22:14:43 --> User session created for 4
INFO - 2018-05-22 22:14:43 --> Login status user@colin.com - success
INFO - 2018-05-22 22:14:43 --> Final output sent to browser
DEBUG - 2018-05-22 22:14:43 --> Total execution time: 0.6894
INFO - 2018-05-22 22:14:43 --> Config Class Initialized
INFO - 2018-05-22 22:14:43 --> Hooks Class Initialized
DEBUG - 2018-05-22 22:14:43 --> UTF-8 Support Enabled
INFO - 2018-05-22 22:14:43 --> Utf8 Class Initialized
INFO - 2018-05-22 22:14:43 --> URI Class Initialized
INFO - 2018-05-22 22:14:43 --> Router Class Initialized
INFO - 2018-05-22 22:14:43 --> Output Class Initialized
INFO - 2018-05-22 22:14:43 --> Security Class Initialized
DEBUG - 2018-05-22 22:14:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 22:14:43 --> Input Class Initialized
INFO - 2018-05-22 22:14:43 --> Language Class Initialized
INFO - 2018-05-22 22:14:43 --> Language Class Initialized
INFO - 2018-05-22 22:14:43 --> Config Class Initialized
INFO - 2018-05-22 22:14:44 --> Loader Class Initialized
DEBUG - 2018-05-22 22:14:44 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 22:14:44 --> Helper loaded: url_helper
INFO - 2018-05-22 22:14:44 --> Helper loaded: form_helper
INFO - 2018-05-22 22:14:44 --> Helper loaded: date_helper
INFO - 2018-05-22 22:14:44 --> Helper loaded: util_helper
INFO - 2018-05-22 22:14:44 --> Helper loaded: text_helper
INFO - 2018-05-22 22:14:44 --> Helper loaded: string_helper
INFO - 2018-05-22 22:14:44 --> Database Driver Class Initialized
DEBUG - 2018-05-22 22:14:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 22:14:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 22:14:44 --> Email Class Initialized
INFO - 2018-05-22 22:14:44 --> Controller Class Initialized
DEBUG - 2018-05-22 22:14:44 --> Home MX_Controller Initialized
DEBUG - 2018-05-22 22:14:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 22:14:44 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 22:14:44 --> Login MX_Controller Initialized
INFO - 2018-05-22 22:14:44 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 22:14:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 22:14:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-22 22:14:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-22 22:14:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-22 22:14:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-22 22:14:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-22 22:14:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-22 22:14:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-05-22 22:14:44 --> Final output sent to browser
DEBUG - 2018-05-22 22:14:44 --> Total execution time: 0.8146
INFO - 2018-05-22 22:14:44 --> Config Class Initialized
INFO - 2018-05-22 22:14:44 --> Hooks Class Initialized
DEBUG - 2018-05-22 22:14:44 --> UTF-8 Support Enabled
INFO - 2018-05-22 22:14:44 --> Utf8 Class Initialized
INFO - 2018-05-22 22:14:44 --> URI Class Initialized
INFO - 2018-05-22 22:14:44 --> Router Class Initialized
INFO - 2018-05-22 22:14:44 --> Output Class Initialized
INFO - 2018-05-22 22:14:44 --> Security Class Initialized
DEBUG - 2018-05-22 22:14:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 22:14:45 --> Input Class Initialized
INFO - 2018-05-22 22:14:45 --> Language Class Initialized
ERROR - 2018-05-22 22:14:45 --> 404 Page Not Found: /index
INFO - 2018-05-22 22:14:45 --> Config Class Initialized
INFO - 2018-05-22 22:14:45 --> Hooks Class Initialized
DEBUG - 2018-05-22 22:14:45 --> UTF-8 Support Enabled
INFO - 2018-05-22 22:14:45 --> Utf8 Class Initialized
INFO - 2018-05-22 22:14:45 --> URI Class Initialized
INFO - 2018-05-22 22:14:45 --> Router Class Initialized
INFO - 2018-05-22 22:14:45 --> Output Class Initialized
INFO - 2018-05-22 22:14:45 --> Security Class Initialized
DEBUG - 2018-05-22 22:14:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 22:14:45 --> Input Class Initialized
INFO - 2018-05-22 22:14:45 --> Language Class Initialized
ERROR - 2018-05-22 22:14:45 --> 404 Page Not Found: /index
INFO - 2018-05-22 22:14:45 --> Config Class Initialized
INFO - 2018-05-22 22:14:45 --> Hooks Class Initialized
DEBUG - 2018-05-22 22:14:45 --> UTF-8 Support Enabled
INFO - 2018-05-22 22:14:45 --> Utf8 Class Initialized
INFO - 2018-05-22 22:14:45 --> URI Class Initialized
INFO - 2018-05-22 22:14:45 --> Router Class Initialized
INFO - 2018-05-22 22:14:45 --> Output Class Initialized
INFO - 2018-05-22 22:14:45 --> Security Class Initialized
DEBUG - 2018-05-22 22:14:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 22:14:45 --> Input Class Initialized
INFO - 2018-05-22 22:14:45 --> Language Class Initialized
ERROR - 2018-05-22 22:14:45 --> 404 Page Not Found: /index
INFO - 2018-05-22 22:15:06 --> Config Class Initialized
INFO - 2018-05-22 22:15:06 --> Hooks Class Initialized
DEBUG - 2018-05-22 22:15:06 --> UTF-8 Support Enabled
INFO - 2018-05-22 22:15:06 --> Utf8 Class Initialized
INFO - 2018-05-22 22:15:06 --> URI Class Initialized
INFO - 2018-05-22 22:15:06 --> Router Class Initialized
INFO - 2018-05-22 22:15:06 --> Output Class Initialized
INFO - 2018-05-22 22:15:06 --> Security Class Initialized
DEBUG - 2018-05-22 22:15:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 22:15:06 --> Input Class Initialized
INFO - 2018-05-22 22:15:06 --> Language Class Initialized
INFO - 2018-05-22 22:15:06 --> Language Class Initialized
INFO - 2018-05-22 22:15:06 --> Config Class Initialized
INFO - 2018-05-22 22:15:06 --> Loader Class Initialized
DEBUG - 2018-05-22 22:15:06 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 22:15:06 --> Helper loaded: url_helper
INFO - 2018-05-22 22:15:06 --> Helper loaded: form_helper
INFO - 2018-05-22 22:15:06 --> Helper loaded: date_helper
INFO - 2018-05-22 22:15:06 --> Helper loaded: util_helper
INFO - 2018-05-22 22:15:06 --> Helper loaded: text_helper
INFO - 2018-05-22 22:15:06 --> Helper loaded: string_helper
INFO - 2018-05-22 22:15:07 --> Database Driver Class Initialized
DEBUG - 2018-05-22 22:15:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 22:15:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 22:15:07 --> Email Class Initialized
INFO - 2018-05-22 22:15:07 --> Controller Class Initialized
DEBUG - 2018-05-22 22:15:07 --> Home MX_Controller Initialized
DEBUG - 2018-05-22 22:15:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 22:15:07 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 22:15:07 --> Login MX_Controller Initialized
INFO - 2018-05-22 22:15:07 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 22:15:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 22:15:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-22 22:15:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-22 22:15:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-22 22:15:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-22 22:15:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-22 22:15:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-22 22:15:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-05-22 22:15:07 --> Final output sent to browser
DEBUG - 2018-05-22 22:15:07 --> Total execution time: 0.8207
INFO - 2018-05-22 22:15:07 --> Config Class Initialized
INFO - 2018-05-22 22:15:07 --> Config Class Initialized
INFO - 2018-05-22 22:15:07 --> Hooks Class Initialized
INFO - 2018-05-22 22:15:07 --> Hooks Class Initialized
DEBUG - 2018-05-22 22:15:07 --> UTF-8 Support Enabled
DEBUG - 2018-05-22 22:15:07 --> UTF-8 Support Enabled
INFO - 2018-05-22 22:15:07 --> Utf8 Class Initialized
INFO - 2018-05-22 22:15:07 --> Utf8 Class Initialized
INFO - 2018-05-22 22:15:07 --> URI Class Initialized
INFO - 2018-05-22 22:15:07 --> Router Class Initialized
INFO - 2018-05-22 22:15:08 --> URI Class Initialized
INFO - 2018-05-22 22:15:08 --> Output Class Initialized
INFO - 2018-05-22 22:15:08 --> Router Class Initialized
INFO - 2018-05-22 22:15:08 --> Output Class Initialized
INFO - 2018-05-22 22:15:08 --> Security Class Initialized
INFO - 2018-05-22 22:15:08 --> Security Class Initialized
DEBUG - 2018-05-22 22:15:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 22:15:08 --> Input Class Initialized
INFO - 2018-05-22 22:15:08 --> Language Class Initialized
ERROR - 2018-05-22 22:15:08 --> 404 Page Not Found: /index
DEBUG - 2018-05-22 22:15:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 22:15:08 --> Input Class Initialized
INFO - 2018-05-22 22:15:08 --> Language Class Initialized
ERROR - 2018-05-22 22:15:08 --> 404 Page Not Found: /index
INFO - 2018-05-22 22:15:08 --> Config Class Initialized
INFO - 2018-05-22 22:15:08 --> Hooks Class Initialized
DEBUG - 2018-05-22 22:15:08 --> UTF-8 Support Enabled
INFO - 2018-05-22 22:15:08 --> Utf8 Class Initialized
INFO - 2018-05-22 22:15:08 --> URI Class Initialized
INFO - 2018-05-22 22:15:08 --> Router Class Initialized
INFO - 2018-05-22 22:15:08 --> Output Class Initialized
INFO - 2018-05-22 22:15:08 --> Security Class Initialized
DEBUG - 2018-05-22 22:15:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 22:15:08 --> Input Class Initialized
INFO - 2018-05-22 22:15:08 --> Language Class Initialized
ERROR - 2018-05-22 22:15:08 --> 404 Page Not Found: /index
INFO - 2018-05-22 22:15:08 --> Config Class Initialized
INFO - 2018-05-22 22:15:08 --> Hooks Class Initialized
DEBUG - 2018-05-22 22:15:08 --> UTF-8 Support Enabled
INFO - 2018-05-22 22:15:08 --> Utf8 Class Initialized
INFO - 2018-05-22 22:15:08 --> URI Class Initialized
INFO - 2018-05-22 22:15:08 --> Router Class Initialized
INFO - 2018-05-22 22:15:08 --> Output Class Initialized
INFO - 2018-05-22 22:15:08 --> Security Class Initialized
DEBUG - 2018-05-22 22:15:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 22:15:08 --> Input Class Initialized
INFO - 2018-05-22 22:15:08 --> Language Class Initialized
ERROR - 2018-05-22 22:15:08 --> 404 Page Not Found: /index
INFO - 2018-05-22 22:15:16 --> Config Class Initialized
INFO - 2018-05-22 22:15:16 --> Hooks Class Initialized
DEBUG - 2018-05-22 22:15:16 --> UTF-8 Support Enabled
INFO - 2018-05-22 22:15:16 --> Utf8 Class Initialized
INFO - 2018-05-22 22:15:16 --> URI Class Initialized
INFO - 2018-05-22 22:15:16 --> Router Class Initialized
INFO - 2018-05-22 22:15:16 --> Output Class Initialized
INFO - 2018-05-22 22:15:16 --> Security Class Initialized
DEBUG - 2018-05-22 22:15:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 22:15:16 --> Input Class Initialized
INFO - 2018-05-22 22:15:16 --> Language Class Initialized
INFO - 2018-05-22 22:15:16 --> Language Class Initialized
INFO - 2018-05-22 22:15:16 --> Config Class Initialized
INFO - 2018-05-22 22:15:16 --> Loader Class Initialized
DEBUG - 2018-05-22 22:15:16 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 22:15:16 --> Helper loaded: url_helper
INFO - 2018-05-22 22:15:16 --> Helper loaded: form_helper
INFO - 2018-05-22 22:15:16 --> Helper loaded: date_helper
INFO - 2018-05-22 22:15:16 --> Helper loaded: util_helper
INFO - 2018-05-22 22:15:16 --> Helper loaded: text_helper
INFO - 2018-05-22 22:15:16 --> Helper loaded: string_helper
INFO - 2018-05-22 22:15:16 --> Database Driver Class Initialized
DEBUG - 2018-05-22 22:15:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 22:15:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 22:15:16 --> Email Class Initialized
INFO - 2018-05-22 22:15:16 --> Controller Class Initialized
DEBUG - 2018-05-22 22:15:16 --> Home MX_Controller Initialized
DEBUG - 2018-05-22 22:15:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 22:15:16 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 22:15:16 --> Login MX_Controller Initialized
INFO - 2018-05-22 22:15:16 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 22:15:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 22:15:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-22 22:15:16 --> Config Class Initialized
INFO - 2018-05-22 22:15:16 --> Hooks Class Initialized
DEBUG - 2018-05-22 22:15:16 --> UTF-8 Support Enabled
INFO - 2018-05-22 22:15:16 --> Utf8 Class Initialized
INFO - 2018-05-22 22:15:16 --> URI Class Initialized
INFO - 2018-05-22 22:15:16 --> Router Class Initialized
INFO - 2018-05-22 22:15:16 --> Output Class Initialized
INFO - 2018-05-22 22:15:17 --> Security Class Initialized
DEBUG - 2018-05-22 22:15:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 22:15:17 --> Input Class Initialized
INFO - 2018-05-22 22:15:17 --> Language Class Initialized
INFO - 2018-05-22 22:15:17 --> Language Class Initialized
INFO - 2018-05-22 22:15:17 --> Config Class Initialized
INFO - 2018-05-22 22:15:17 --> Loader Class Initialized
DEBUG - 2018-05-22 22:15:17 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 22:15:17 --> Helper loaded: url_helper
INFO - 2018-05-22 22:15:17 --> Helper loaded: form_helper
INFO - 2018-05-22 22:15:17 --> Helper loaded: date_helper
INFO - 2018-05-22 22:15:17 --> Helper loaded: util_helper
INFO - 2018-05-22 22:15:17 --> Helper loaded: text_helper
INFO - 2018-05-22 22:15:17 --> Helper loaded: string_helper
INFO - 2018-05-22 22:15:17 --> Database Driver Class Initialized
DEBUG - 2018-05-22 22:15:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 22:15:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 22:15:17 --> Email Class Initialized
INFO - 2018-05-22 22:15:17 --> Controller Class Initialized
DEBUG - 2018-05-22 22:15:17 --> Home MX_Controller Initialized
DEBUG - 2018-05-22 22:15:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 22:15:17 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 22:15:17 --> Login MX_Controller Initialized
INFO - 2018-05-22 22:15:17 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 22:15:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 22:15:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-22 22:15:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-22 22:15:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-22 22:15:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-22 22:15:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-22 22:15:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-22 22:15:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-05-22 22:15:17 --> Final output sent to browser
DEBUG - 2018-05-22 22:15:17 --> Total execution time: 0.8929
INFO - 2018-05-22 22:15:18 --> Config Class Initialized
INFO - 2018-05-22 22:15:18 --> Hooks Class Initialized
DEBUG - 2018-05-22 22:15:18 --> UTF-8 Support Enabled
INFO - 2018-05-22 22:15:18 --> Utf8 Class Initialized
INFO - 2018-05-22 22:15:18 --> URI Class Initialized
INFO - 2018-05-22 22:15:18 --> Router Class Initialized
INFO - 2018-05-22 22:15:18 --> Output Class Initialized
INFO - 2018-05-22 22:15:18 --> Security Class Initialized
DEBUG - 2018-05-22 22:15:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 22:15:18 --> Input Class Initialized
INFO - 2018-05-22 22:15:18 --> Language Class Initialized
ERROR - 2018-05-22 22:15:18 --> 404 Page Not Found: /index
INFO - 2018-05-22 22:15:18 --> Config Class Initialized
INFO - 2018-05-22 22:15:18 --> Hooks Class Initialized
DEBUG - 2018-05-22 22:15:18 --> UTF-8 Support Enabled
INFO - 2018-05-22 22:15:18 --> Utf8 Class Initialized
INFO - 2018-05-22 22:15:18 --> URI Class Initialized
INFO - 2018-05-22 22:15:18 --> Router Class Initialized
INFO - 2018-05-22 22:15:18 --> Output Class Initialized
INFO - 2018-05-22 22:15:18 --> Security Class Initialized
DEBUG - 2018-05-22 22:15:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 22:15:18 --> Input Class Initialized
INFO - 2018-05-22 22:15:18 --> Language Class Initialized
ERROR - 2018-05-22 22:15:18 --> 404 Page Not Found: /index
INFO - 2018-05-22 22:15:18 --> Config Class Initialized
INFO - 2018-05-22 22:15:18 --> Hooks Class Initialized
DEBUG - 2018-05-22 22:15:18 --> UTF-8 Support Enabled
INFO - 2018-05-22 22:15:18 --> Utf8 Class Initialized
INFO - 2018-05-22 22:15:19 --> URI Class Initialized
INFO - 2018-05-22 22:15:19 --> Router Class Initialized
INFO - 2018-05-22 22:15:19 --> Output Class Initialized
INFO - 2018-05-22 22:15:19 --> Security Class Initialized
DEBUG - 2018-05-22 22:15:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 22:15:19 --> Input Class Initialized
INFO - 2018-05-22 22:15:19 --> Language Class Initialized
ERROR - 2018-05-22 22:15:19 --> 404 Page Not Found: /index
INFO - 2018-05-22 22:15:23 --> Config Class Initialized
INFO - 2018-05-22 22:15:23 --> Hooks Class Initialized
DEBUG - 2018-05-22 22:15:23 --> UTF-8 Support Enabled
INFO - 2018-05-22 22:15:23 --> Utf8 Class Initialized
INFO - 2018-05-22 22:15:23 --> URI Class Initialized
INFO - 2018-05-22 22:15:23 --> Router Class Initialized
INFO - 2018-05-22 22:15:23 --> Output Class Initialized
INFO - 2018-05-22 22:15:23 --> Security Class Initialized
DEBUG - 2018-05-22 22:15:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 22:15:23 --> Input Class Initialized
INFO - 2018-05-22 22:15:23 --> Language Class Initialized
INFO - 2018-05-22 22:15:23 --> Language Class Initialized
INFO - 2018-05-22 22:15:23 --> Config Class Initialized
INFO - 2018-05-22 22:15:23 --> Loader Class Initialized
DEBUG - 2018-05-22 22:15:23 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 22:15:23 --> Helper loaded: url_helper
INFO - 2018-05-22 22:15:23 --> Helper loaded: form_helper
INFO - 2018-05-22 22:15:23 --> Helper loaded: date_helper
INFO - 2018-05-22 22:15:23 --> Helper loaded: util_helper
INFO - 2018-05-22 22:15:23 --> Helper loaded: text_helper
INFO - 2018-05-22 22:15:23 --> Helper loaded: string_helper
INFO - 2018-05-22 22:15:23 --> Database Driver Class Initialized
DEBUG - 2018-05-22 22:15:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 22:15:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 22:15:23 --> Email Class Initialized
INFO - 2018-05-22 22:15:24 --> Controller Class Initialized
DEBUG - 2018-05-22 22:15:24 --> Home MX_Controller Initialized
DEBUG - 2018-05-22 22:15:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 22:15:24 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 22:15:24 --> Login MX_Controller Initialized
INFO - 2018-05-22 22:15:24 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 22:15:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 22:15:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-22 22:15:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-22 22:15:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-22 22:15:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-22 22:15:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-22 22:15:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-22 22:15:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-05-22 22:15:24 --> Final output sent to browser
DEBUG - 2018-05-22 22:15:24 --> Total execution time: 0.8872
INFO - 2018-05-22 22:15:24 --> Config Class Initialized
INFO - 2018-05-22 22:15:24 --> Config Class Initialized
INFO - 2018-05-22 22:15:24 --> Hooks Class Initialized
INFO - 2018-05-22 22:15:24 --> Hooks Class Initialized
DEBUG - 2018-05-22 22:15:24 --> UTF-8 Support Enabled
DEBUG - 2018-05-22 22:15:24 --> UTF-8 Support Enabled
INFO - 2018-05-22 22:15:24 --> Utf8 Class Initialized
INFO - 2018-05-22 22:15:24 --> URI Class Initialized
INFO - 2018-05-22 22:15:24 --> Router Class Initialized
INFO - 2018-05-22 22:15:24 --> Output Class Initialized
INFO - 2018-05-22 22:15:24 --> Utf8 Class Initialized
INFO - 2018-05-22 22:15:24 --> Security Class Initialized
INFO - 2018-05-22 22:15:24 --> URI Class Initialized
DEBUG - 2018-05-22 22:15:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 22:15:24 --> Input Class Initialized
INFO - 2018-05-22 22:15:24 --> Router Class Initialized
INFO - 2018-05-22 22:15:24 --> Language Class Initialized
ERROR - 2018-05-22 22:15:24 --> 404 Page Not Found: /index
INFO - 2018-05-22 22:15:24 --> Output Class Initialized
INFO - 2018-05-22 22:15:25 --> Security Class Initialized
DEBUG - 2018-05-22 22:15:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 22:15:25 --> Config Class Initialized
INFO - 2018-05-22 22:15:25 --> Hooks Class Initialized
INFO - 2018-05-22 22:15:25 --> Input Class Initialized
DEBUG - 2018-05-22 22:15:25 --> UTF-8 Support Enabled
INFO - 2018-05-22 22:15:25 --> Language Class Initialized
INFO - 2018-05-22 22:15:25 --> Utf8 Class Initialized
INFO - 2018-05-22 22:15:25 --> URI Class Initialized
ERROR - 2018-05-22 22:15:25 --> 404 Page Not Found: /index
INFO - 2018-05-22 22:15:25 --> Router Class Initialized
INFO - 2018-05-22 22:15:25 --> Output Class Initialized
INFO - 2018-05-22 22:15:25 --> Security Class Initialized
DEBUG - 2018-05-22 22:15:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 22:15:25 --> Input Class Initialized
INFO - 2018-05-22 22:15:25 --> Language Class Initialized
ERROR - 2018-05-22 22:15:25 --> 404 Page Not Found: /index
INFO - 2018-05-22 22:15:25 --> Config Class Initialized
INFO - 2018-05-22 22:15:25 --> Hooks Class Initialized
DEBUG - 2018-05-22 22:15:26 --> UTF-8 Support Enabled
INFO - 2018-05-22 22:15:26 --> Utf8 Class Initialized
INFO - 2018-05-22 22:15:26 --> URI Class Initialized
INFO - 2018-05-22 22:15:26 --> Router Class Initialized
INFO - 2018-05-22 22:15:26 --> Output Class Initialized
INFO - 2018-05-22 22:15:26 --> Security Class Initialized
DEBUG - 2018-05-22 22:15:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 22:15:26 --> Input Class Initialized
INFO - 2018-05-22 22:15:26 --> Language Class Initialized
ERROR - 2018-05-22 22:15:26 --> 404 Page Not Found: /index
INFO - 2018-05-22 22:15:33 --> Config Class Initialized
INFO - 2018-05-22 22:15:33 --> Hooks Class Initialized
DEBUG - 2018-05-22 22:15:33 --> UTF-8 Support Enabled
INFO - 2018-05-22 22:15:33 --> Utf8 Class Initialized
INFO - 2018-05-22 22:15:33 --> URI Class Initialized
INFO - 2018-05-22 22:15:33 --> Router Class Initialized
INFO - 2018-05-22 22:15:33 --> Output Class Initialized
INFO - 2018-05-22 22:15:33 --> Security Class Initialized
DEBUG - 2018-05-22 22:15:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 22:15:33 --> Input Class Initialized
INFO - 2018-05-22 22:15:33 --> Language Class Initialized
INFO - 2018-05-22 22:15:33 --> Language Class Initialized
INFO - 2018-05-22 22:15:33 --> Config Class Initialized
INFO - 2018-05-22 22:15:33 --> Loader Class Initialized
DEBUG - 2018-05-22 22:15:33 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 22:15:33 --> Helper loaded: url_helper
INFO - 2018-05-22 22:15:33 --> Helper loaded: form_helper
INFO - 2018-05-22 22:15:33 --> Helper loaded: date_helper
INFO - 2018-05-22 22:15:33 --> Helper loaded: util_helper
INFO - 2018-05-22 22:15:33 --> Helper loaded: text_helper
INFO - 2018-05-22 22:15:33 --> Helper loaded: string_helper
INFO - 2018-05-22 22:15:34 --> Database Driver Class Initialized
DEBUG - 2018-05-22 22:15:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 22:15:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 22:15:34 --> Email Class Initialized
INFO - 2018-05-22 22:15:34 --> Controller Class Initialized
DEBUG - 2018-05-22 22:15:34 --> Programs MX_Controller Initialized
INFO - 2018-05-22 22:15:34 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 22:15:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-05-22 22:15:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 22:15:34 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 22:15:34 --> Login MX_Controller Initialized
DEBUG - 2018-05-22 22:15:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-22 22:15:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-22 22:15:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-22 22:15:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-22 22:15:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-22 22:15:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-22 22:15:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/programs.php
INFO - 2018-05-22 22:15:34 --> Final output sent to browser
DEBUG - 2018-05-22 22:15:34 --> Total execution time: 0.8622
INFO - 2018-05-22 22:15:35 --> Config Class Initialized
INFO - 2018-05-22 22:15:35 --> Hooks Class Initialized
DEBUG - 2018-05-22 22:15:35 --> UTF-8 Support Enabled
INFO - 2018-05-22 22:15:35 --> Utf8 Class Initialized
INFO - 2018-05-22 22:15:35 --> URI Class Initialized
INFO - 2018-05-22 22:15:35 --> Router Class Initialized
INFO - 2018-05-22 22:15:35 --> Output Class Initialized
INFO - 2018-05-22 22:15:35 --> Security Class Initialized
DEBUG - 2018-05-22 22:15:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 22:15:35 --> Input Class Initialized
INFO - 2018-05-22 22:15:35 --> Language Class Initialized
INFO - 2018-05-22 22:15:35 --> Language Class Initialized
INFO - 2018-05-22 22:15:35 --> Config Class Initialized
INFO - 2018-05-22 22:15:35 --> Loader Class Initialized
DEBUG - 2018-05-22 22:15:35 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 22:15:35 --> Helper loaded: url_helper
INFO - 2018-05-22 22:15:35 --> Helper loaded: form_helper
INFO - 2018-05-22 22:15:35 --> Helper loaded: date_helper
INFO - 2018-05-22 22:15:35 --> Helper loaded: util_helper
INFO - 2018-05-22 22:15:35 --> Helper loaded: text_helper
INFO - 2018-05-22 22:15:35 --> Helper loaded: string_helper
INFO - 2018-05-22 22:15:35 --> Database Driver Class Initialized
DEBUG - 2018-05-22 22:15:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 22:15:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 22:15:35 --> Email Class Initialized
INFO - 2018-05-22 22:15:35 --> Controller Class Initialized
DEBUG - 2018-05-22 22:15:35 --> Programs MX_Controller Initialized
INFO - 2018-05-22 22:15:35 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 22:15:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-05-22 22:15:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 22:15:35 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 22:15:35 --> Login MX_Controller Initialized
DEBUG - 2018-05-22 22:15:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-22 22:15:35 --> Final output sent to browser
DEBUG - 2018-05-22 22:15:36 --> Total execution time: 0.8817
INFO - 2018-05-22 22:15:41 --> Config Class Initialized
INFO - 2018-05-22 22:15:41 --> Hooks Class Initialized
DEBUG - 2018-05-22 22:15:41 --> UTF-8 Support Enabled
INFO - 2018-05-22 22:15:41 --> Utf8 Class Initialized
INFO - 2018-05-22 22:15:41 --> URI Class Initialized
INFO - 2018-05-22 22:15:41 --> Router Class Initialized
INFO - 2018-05-22 22:15:41 --> Output Class Initialized
INFO - 2018-05-22 22:15:41 --> Security Class Initialized
DEBUG - 2018-05-22 22:15:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 22:15:41 --> Input Class Initialized
INFO - 2018-05-22 22:15:41 --> Language Class Initialized
INFO - 2018-05-22 22:15:41 --> Language Class Initialized
INFO - 2018-05-22 22:15:41 --> Config Class Initialized
INFO - 2018-05-22 22:15:41 --> Loader Class Initialized
DEBUG - 2018-05-22 22:15:41 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 22:15:41 --> Helper loaded: url_helper
INFO - 2018-05-22 22:15:41 --> Helper loaded: form_helper
INFO - 2018-05-22 22:15:41 --> Helper loaded: date_helper
INFO - 2018-05-22 22:15:41 --> Helper loaded: util_helper
INFO - 2018-05-22 22:15:42 --> Helper loaded: text_helper
INFO - 2018-05-22 22:15:42 --> Helper loaded: string_helper
INFO - 2018-05-22 22:15:42 --> Database Driver Class Initialized
DEBUG - 2018-05-22 22:15:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 22:15:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 22:15:42 --> Email Class Initialized
INFO - 2018-05-22 22:15:42 --> Controller Class Initialized
DEBUG - 2018-05-22 22:15:42 --> videos MX_Controller Initialized
INFO - 2018-05-22 22:15:42 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 22:15:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-05-22 22:15:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 22:15:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-22 22:15:42 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 22:15:42 --> Login MX_Controller Initialized
DEBUG - 2018-05-22 22:15:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-22 22:15:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-22 22:15:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-22 22:15:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-22 22:15:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-22 22:15:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-22 22:15:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/videos/videos.php
INFO - 2018-05-22 22:15:42 --> Final output sent to browser
DEBUG - 2018-05-22 22:15:42 --> Total execution time: 0.9152
INFO - 2018-05-22 22:15:42 --> Config Class Initialized
INFO - 2018-05-22 22:15:42 --> Hooks Class Initialized
DEBUG - 2018-05-22 22:15:42 --> UTF-8 Support Enabled
INFO - 2018-05-22 22:15:42 --> Utf8 Class Initialized
INFO - 2018-05-22 22:15:43 --> URI Class Initialized
INFO - 2018-05-22 22:15:43 --> Router Class Initialized
INFO - 2018-05-22 22:15:43 --> Output Class Initialized
INFO - 2018-05-22 22:15:43 --> Security Class Initialized
DEBUG - 2018-05-22 22:15:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 22:15:43 --> Input Class Initialized
INFO - 2018-05-22 22:15:43 --> Language Class Initialized
INFO - 2018-05-22 22:15:43 --> Language Class Initialized
INFO - 2018-05-22 22:15:43 --> Config Class Initialized
INFO - 2018-05-22 22:15:43 --> Loader Class Initialized
DEBUG - 2018-05-22 22:15:43 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 22:15:43 --> Helper loaded: url_helper
INFO - 2018-05-22 22:15:43 --> Helper loaded: form_helper
INFO - 2018-05-22 22:15:43 --> Helper loaded: date_helper
INFO - 2018-05-22 22:15:43 --> Helper loaded: util_helper
INFO - 2018-05-22 22:15:43 --> Helper loaded: text_helper
INFO - 2018-05-22 22:15:43 --> Helper loaded: string_helper
INFO - 2018-05-22 22:15:43 --> Database Driver Class Initialized
DEBUG - 2018-05-22 22:15:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 22:15:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 22:15:43 --> Email Class Initialized
INFO - 2018-05-22 22:15:43 --> Controller Class Initialized
DEBUG - 2018-05-22 22:15:43 --> videos MX_Controller Initialized
INFO - 2018-05-22 22:15:43 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 22:15:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-05-22 22:15:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 22:15:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-22 22:15:43 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 22:15:43 --> Login MX_Controller Initialized
DEBUG - 2018-05-22 22:15:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-22 22:15:43 --> Final output sent to browser
DEBUG - 2018-05-22 22:15:43 --> Total execution time: 0.9049
INFO - 2018-05-22 22:15:47 --> Config Class Initialized
INFO - 2018-05-22 22:15:47 --> Hooks Class Initialized
DEBUG - 2018-05-22 22:15:47 --> UTF-8 Support Enabled
INFO - 2018-05-22 22:15:47 --> Utf8 Class Initialized
INFO - 2018-05-22 22:15:47 --> URI Class Initialized
INFO - 2018-05-22 22:15:47 --> Router Class Initialized
INFO - 2018-05-22 22:15:47 --> Output Class Initialized
INFO - 2018-05-22 22:15:48 --> Security Class Initialized
DEBUG - 2018-05-22 22:15:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 22:15:48 --> Input Class Initialized
INFO - 2018-05-22 22:15:48 --> Language Class Initialized
INFO - 2018-05-22 22:15:48 --> Language Class Initialized
INFO - 2018-05-22 22:15:48 --> Config Class Initialized
INFO - 2018-05-22 22:15:48 --> Loader Class Initialized
DEBUG - 2018-05-22 22:15:48 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 22:15:48 --> Helper loaded: url_helper
INFO - 2018-05-22 22:15:48 --> Helper loaded: form_helper
INFO - 2018-05-22 22:15:48 --> Helper loaded: date_helper
INFO - 2018-05-22 22:15:48 --> Helper loaded: util_helper
INFO - 2018-05-22 22:15:48 --> Helper loaded: text_helper
INFO - 2018-05-22 22:15:48 --> Helper loaded: string_helper
INFO - 2018-05-22 22:15:48 --> Database Driver Class Initialized
DEBUG - 2018-05-22 22:15:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 22:15:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 22:15:48 --> Email Class Initialized
INFO - 2018-05-22 22:15:48 --> Controller Class Initialized
DEBUG - 2018-05-22 22:15:48 --> videos MX_Controller Initialized
INFO - 2018-05-22 22:15:48 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 22:15:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-05-22 22:15:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 22:15:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-22 22:15:48 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 22:15:48 --> Login MX_Controller Initialized
DEBUG - 2018-05-22 22:15:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-22 22:15:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-22 22:15:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-22 22:15:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-22 22:15:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-22 22:15:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-22 22:15:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/videos/create_video.php
INFO - 2018-05-22 22:15:48 --> Final output sent to browser
DEBUG - 2018-05-22 22:15:48 --> Total execution time: 0.8912
INFO - 2018-05-22 22:15:58 --> Config Class Initialized
INFO - 2018-05-22 22:15:58 --> Hooks Class Initialized
DEBUG - 2018-05-22 22:15:58 --> UTF-8 Support Enabled
INFO - 2018-05-22 22:15:58 --> Utf8 Class Initialized
INFO - 2018-05-22 22:15:58 --> URI Class Initialized
INFO - 2018-05-22 22:15:58 --> Router Class Initialized
INFO - 2018-05-22 22:15:58 --> Output Class Initialized
INFO - 2018-05-22 22:15:58 --> Security Class Initialized
DEBUG - 2018-05-22 22:15:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 22:15:58 --> Input Class Initialized
INFO - 2018-05-22 22:15:58 --> Language Class Initialized
INFO - 2018-05-22 22:15:59 --> Language Class Initialized
INFO - 2018-05-22 22:15:59 --> Config Class Initialized
INFO - 2018-05-22 22:15:59 --> Loader Class Initialized
DEBUG - 2018-05-22 22:15:59 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 22:15:59 --> Helper loaded: url_helper
INFO - 2018-05-22 22:15:59 --> Helper loaded: form_helper
INFO - 2018-05-22 22:15:59 --> Helper loaded: date_helper
INFO - 2018-05-22 22:15:59 --> Helper loaded: util_helper
INFO - 2018-05-22 22:15:59 --> Helper loaded: text_helper
INFO - 2018-05-22 22:15:59 --> Helper loaded: string_helper
INFO - 2018-05-22 22:15:59 --> Database Driver Class Initialized
DEBUG - 2018-05-22 22:15:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 22:15:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 22:15:59 --> Email Class Initialized
INFO - 2018-05-22 22:15:59 --> Controller Class Initialized
DEBUG - 2018-05-22 22:15:59 --> videos MX_Controller Initialized
INFO - 2018-05-22 22:15:59 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 22:15:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-05-22 22:15:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 22:15:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-22 22:15:59 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 22:15:59 --> Login MX_Controller Initialized
DEBUG - 2018-05-22 22:15:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-22 22:15:59 --> Config Class Initialized
INFO - 2018-05-22 22:15:59 --> Hooks Class Initialized
DEBUG - 2018-05-22 22:15:59 --> UTF-8 Support Enabled
INFO - 2018-05-22 22:15:59 --> Utf8 Class Initialized
INFO - 2018-05-22 22:15:59 --> URI Class Initialized
INFO - 2018-05-22 22:15:59 --> Router Class Initialized
INFO - 2018-05-22 22:15:59 --> Output Class Initialized
INFO - 2018-05-22 22:15:59 --> Security Class Initialized
DEBUG - 2018-05-22 22:15:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 22:15:59 --> Input Class Initialized
INFO - 2018-05-22 22:15:59 --> Language Class Initialized
INFO - 2018-05-22 22:15:59 --> Language Class Initialized
INFO - 2018-05-22 22:16:00 --> Config Class Initialized
INFO - 2018-05-22 22:16:00 --> Loader Class Initialized
DEBUG - 2018-05-22 22:16:00 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 22:16:00 --> Helper loaded: url_helper
INFO - 2018-05-22 22:16:00 --> Helper loaded: form_helper
INFO - 2018-05-22 22:16:00 --> Helper loaded: date_helper
INFO - 2018-05-22 22:16:00 --> Helper loaded: util_helper
INFO - 2018-05-22 22:16:00 --> Helper loaded: text_helper
INFO - 2018-05-22 22:16:00 --> Helper loaded: string_helper
INFO - 2018-05-22 22:16:00 --> Database Driver Class Initialized
DEBUG - 2018-05-22 22:16:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 22:16:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 22:16:00 --> Email Class Initialized
INFO - 2018-05-22 22:16:00 --> Controller Class Initialized
DEBUG - 2018-05-22 22:16:00 --> videos MX_Controller Initialized
INFO - 2018-05-22 22:16:00 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 22:16:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-05-22 22:16:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 22:16:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-22 22:16:00 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 22:16:00 --> Login MX_Controller Initialized
DEBUG - 2018-05-22 22:16:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-22 22:16:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-05-22 22:16:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-05-22 22:16:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-05-22 22:16:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-05-22 22:16:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-05-22 22:16:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/videos/videos.php
INFO - 2018-05-22 22:16:00 --> Final output sent to browser
DEBUG - 2018-05-22 22:16:00 --> Total execution time: 0.9959
INFO - 2018-05-22 22:16:01 --> Config Class Initialized
INFO - 2018-05-22 22:16:01 --> Hooks Class Initialized
DEBUG - 2018-05-22 22:16:01 --> UTF-8 Support Enabled
INFO - 2018-05-22 22:16:01 --> Utf8 Class Initialized
INFO - 2018-05-22 22:16:01 --> URI Class Initialized
INFO - 2018-05-22 22:16:01 --> Router Class Initialized
INFO - 2018-05-22 22:16:01 --> Output Class Initialized
INFO - 2018-05-22 22:16:01 --> Security Class Initialized
DEBUG - 2018-05-22 22:16:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 22:16:01 --> Input Class Initialized
INFO - 2018-05-22 22:16:01 --> Language Class Initialized
INFO - 2018-05-22 22:16:01 --> Language Class Initialized
INFO - 2018-05-22 22:16:01 --> Config Class Initialized
INFO - 2018-05-22 22:16:01 --> Loader Class Initialized
DEBUG - 2018-05-22 22:16:01 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 22:16:01 --> Helper loaded: url_helper
INFO - 2018-05-22 22:16:01 --> Helper loaded: form_helper
INFO - 2018-05-22 22:16:01 --> Helper loaded: date_helper
INFO - 2018-05-22 22:16:01 --> Helper loaded: util_helper
INFO - 2018-05-22 22:16:01 --> Helper loaded: text_helper
INFO - 2018-05-22 22:16:01 --> Helper loaded: string_helper
INFO - 2018-05-22 22:16:01 --> Database Driver Class Initialized
DEBUG - 2018-05-22 22:16:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 22:16:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 22:16:01 --> Email Class Initialized
INFO - 2018-05-22 22:16:01 --> Controller Class Initialized
DEBUG - 2018-05-22 22:16:01 --> videos MX_Controller Initialized
INFO - 2018-05-22 22:16:01 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 22:16:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-05-22 22:16:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 22:16:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-22 22:16:01 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 22:16:01 --> Login MX_Controller Initialized
DEBUG - 2018-05-22 22:16:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-22 22:16:01 --> Final output sent to browser
DEBUG - 2018-05-22 22:16:01 --> Total execution time: 0.8605
INFO - 2018-05-22 22:16:04 --> Config Class Initialized
INFO - 2018-05-22 22:16:04 --> Hooks Class Initialized
DEBUG - 2018-05-22 22:16:04 --> UTF-8 Support Enabled
INFO - 2018-05-22 22:16:04 --> Utf8 Class Initialized
INFO - 2018-05-22 22:16:04 --> URI Class Initialized
INFO - 2018-05-22 22:16:04 --> Router Class Initialized
INFO - 2018-05-22 22:16:04 --> Output Class Initialized
INFO - 2018-05-22 22:16:04 --> Security Class Initialized
DEBUG - 2018-05-22 22:16:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 22:16:04 --> Input Class Initialized
INFO - 2018-05-22 22:16:04 --> Language Class Initialized
INFO - 2018-05-22 22:16:04 --> Language Class Initialized
INFO - 2018-05-22 22:16:05 --> Config Class Initialized
INFO - 2018-05-22 22:16:05 --> Loader Class Initialized
DEBUG - 2018-05-22 22:16:05 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 22:16:05 --> Helper loaded: url_helper
INFO - 2018-05-22 22:16:05 --> Helper loaded: form_helper
INFO - 2018-05-22 22:16:05 --> Helper loaded: date_helper
INFO - 2018-05-22 22:16:05 --> Helper loaded: util_helper
INFO - 2018-05-22 22:16:05 --> Helper loaded: text_helper
INFO - 2018-05-22 22:16:05 --> Helper loaded: string_helper
INFO - 2018-05-22 22:16:05 --> Database Driver Class Initialized
DEBUG - 2018-05-22 22:16:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 22:16:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 22:16:05 --> Email Class Initialized
INFO - 2018-05-22 22:16:05 --> Controller Class Initialized
DEBUG - 2018-05-22 22:16:05 --> Home MX_Controller Initialized
DEBUG - 2018-05-22 22:16:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 22:16:05 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 22:16:05 --> Login MX_Controller Initialized
INFO - 2018-05-22 22:16:05 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 22:16:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 22:16:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-22 22:16:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-22 22:16:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-22 22:16:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-22 22:16:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-22 22:16:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-22 22:16:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-05-22 22:16:05 --> Final output sent to browser
DEBUG - 2018-05-22 22:16:05 --> Total execution time: 0.9029
INFO - 2018-05-22 22:16:06 --> Config Class Initialized
INFO - 2018-05-22 22:16:06 --> Config Class Initialized
INFO - 2018-05-22 22:16:06 --> Hooks Class Initialized
INFO - 2018-05-22 22:16:06 --> Hooks Class Initialized
DEBUG - 2018-05-22 22:16:06 --> UTF-8 Support Enabled
INFO - 2018-05-22 22:16:06 --> Utf8 Class Initialized
INFO - 2018-05-22 22:16:06 --> URI Class Initialized
DEBUG - 2018-05-22 22:16:06 --> UTF-8 Support Enabled
INFO - 2018-05-22 22:16:06 --> Router Class Initialized
INFO - 2018-05-22 22:16:06 --> Utf8 Class Initialized
INFO - 2018-05-22 22:16:06 --> Output Class Initialized
INFO - 2018-05-22 22:16:06 --> URI Class Initialized
INFO - 2018-05-22 22:16:06 --> Security Class Initialized
INFO - 2018-05-22 22:16:06 --> Router Class Initialized
DEBUG - 2018-05-22 22:16:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 22:16:06 --> Input Class Initialized
INFO - 2018-05-22 22:16:06 --> Output Class Initialized
INFO - 2018-05-22 22:16:06 --> Language Class Initialized
INFO - 2018-05-22 22:16:06 --> Security Class Initialized
ERROR - 2018-05-22 22:16:06 --> 404 Page Not Found: /index
DEBUG - 2018-05-22 22:16:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 22:16:06 --> Input Class Initialized
INFO - 2018-05-22 22:16:06 --> Language Class Initialized
ERROR - 2018-05-22 22:16:06 --> 404 Page Not Found: /index
INFO - 2018-05-22 22:16:06 --> Config Class Initialized
INFO - 2018-05-22 22:16:06 --> Hooks Class Initialized
DEBUG - 2018-05-22 22:16:06 --> UTF-8 Support Enabled
INFO - 2018-05-22 22:16:06 --> Utf8 Class Initialized
INFO - 2018-05-22 22:16:06 --> URI Class Initialized
INFO - 2018-05-22 22:16:06 --> Router Class Initialized
INFO - 2018-05-22 22:16:06 --> Output Class Initialized
INFO - 2018-05-22 22:16:06 --> Security Class Initialized
DEBUG - 2018-05-22 22:16:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 22:16:06 --> Input Class Initialized
INFO - 2018-05-22 22:16:06 --> Language Class Initialized
ERROR - 2018-05-22 22:16:06 --> 404 Page Not Found: /index
INFO - 2018-05-22 22:16:07 --> Config Class Initialized
INFO - 2018-05-22 22:16:07 --> Hooks Class Initialized
DEBUG - 2018-05-22 22:16:07 --> UTF-8 Support Enabled
INFO - 2018-05-22 22:16:07 --> Utf8 Class Initialized
INFO - 2018-05-22 22:16:07 --> URI Class Initialized
INFO - 2018-05-22 22:16:07 --> Router Class Initialized
INFO - 2018-05-22 22:16:07 --> Output Class Initialized
INFO - 2018-05-22 22:16:07 --> Security Class Initialized
DEBUG - 2018-05-22 22:16:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 22:16:07 --> Input Class Initialized
INFO - 2018-05-22 22:16:07 --> Language Class Initialized
ERROR - 2018-05-22 22:16:07 --> 404 Page Not Found: /index
INFO - 2018-05-22 22:56:13 --> Config Class Initialized
INFO - 2018-05-22 22:56:13 --> Hooks Class Initialized
DEBUG - 2018-05-22 22:56:13 --> UTF-8 Support Enabled
INFO - 2018-05-22 22:56:13 --> Utf8 Class Initialized
INFO - 2018-05-22 22:56:13 --> URI Class Initialized
INFO - 2018-05-22 22:56:14 --> Router Class Initialized
INFO - 2018-05-22 22:56:14 --> Output Class Initialized
INFO - 2018-05-22 22:56:14 --> Security Class Initialized
DEBUG - 2018-05-22 22:56:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 22:56:14 --> Input Class Initialized
INFO - 2018-05-22 22:56:14 --> Language Class Initialized
INFO - 2018-05-22 22:56:14 --> Language Class Initialized
INFO - 2018-05-22 22:56:14 --> Config Class Initialized
INFO - 2018-05-22 22:56:14 --> Loader Class Initialized
DEBUG - 2018-05-22 22:56:14 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 22:56:14 --> Helper loaded: url_helper
INFO - 2018-05-22 22:56:14 --> Helper loaded: form_helper
INFO - 2018-05-22 22:56:14 --> Helper loaded: date_helper
INFO - 2018-05-22 22:56:14 --> Helper loaded: util_helper
INFO - 2018-05-22 22:56:14 --> Helper loaded: text_helper
INFO - 2018-05-22 22:56:14 --> Helper loaded: string_helper
INFO - 2018-05-22 22:56:14 --> Database Driver Class Initialized
DEBUG - 2018-05-22 22:56:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 22:56:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 22:56:14 --> Email Class Initialized
INFO - 2018-05-22 22:56:14 --> Controller Class Initialized
DEBUG - 2018-05-22 22:56:14 --> Home MX_Controller Initialized
DEBUG - 2018-05-22 22:56:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 22:56:14 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 22:56:14 --> Login MX_Controller Initialized
INFO - 2018-05-22 22:56:14 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 22:56:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 22:56:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-22 22:56:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-22 22:56:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-22 22:56:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-22 22:56:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-22 22:56:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-22 22:56:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-05-22 22:56:14 --> Final output sent to browser
DEBUG - 2018-05-22 22:56:14 --> Total execution time: 0.8881
INFO - 2018-05-22 22:56:15 --> Config Class Initialized
INFO - 2018-05-22 22:56:15 --> Hooks Class Initialized
DEBUG - 2018-05-22 22:56:15 --> UTF-8 Support Enabled
INFO - 2018-05-22 22:56:15 --> Utf8 Class Initialized
INFO - 2018-05-22 22:56:15 --> URI Class Initialized
INFO - 2018-05-22 22:56:15 --> Router Class Initialized
INFO - 2018-05-22 22:56:15 --> Output Class Initialized
INFO - 2018-05-22 22:56:15 --> Security Class Initialized
DEBUG - 2018-05-22 22:56:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 22:56:15 --> Input Class Initialized
INFO - 2018-05-22 22:56:15 --> Language Class Initialized
ERROR - 2018-05-22 22:56:15 --> 404 Page Not Found: /index
INFO - 2018-05-22 22:56:15 --> Config Class Initialized
INFO - 2018-05-22 22:56:15 --> Hooks Class Initialized
DEBUG - 2018-05-22 22:56:15 --> UTF-8 Support Enabled
INFO - 2018-05-22 22:56:15 --> Utf8 Class Initialized
INFO - 2018-05-22 22:56:15 --> URI Class Initialized
INFO - 2018-05-22 22:56:15 --> Router Class Initialized
INFO - 2018-05-22 22:56:15 --> Output Class Initialized
INFO - 2018-05-22 22:56:16 --> Security Class Initialized
DEBUG - 2018-05-22 22:56:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 22:56:16 --> Input Class Initialized
INFO - 2018-05-22 22:56:16 --> Language Class Initialized
ERROR - 2018-05-22 22:56:16 --> 404 Page Not Found: /index
INFO - 2018-05-22 22:56:16 --> Config Class Initialized
INFO - 2018-05-22 22:56:16 --> Hooks Class Initialized
DEBUG - 2018-05-22 22:56:16 --> UTF-8 Support Enabled
INFO - 2018-05-22 22:56:16 --> Utf8 Class Initialized
INFO - 2018-05-22 22:56:16 --> URI Class Initialized
INFO - 2018-05-22 22:56:16 --> Router Class Initialized
INFO - 2018-05-22 22:56:16 --> Output Class Initialized
INFO - 2018-05-22 22:56:16 --> Security Class Initialized
DEBUG - 2018-05-22 22:56:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 22:56:16 --> Input Class Initialized
INFO - 2018-05-22 22:56:16 --> Language Class Initialized
ERROR - 2018-05-22 22:56:16 --> 404 Page Not Found: /index
INFO - 2018-05-22 22:59:12 --> Config Class Initialized
INFO - 2018-05-22 22:59:12 --> Hooks Class Initialized
DEBUG - 2018-05-22 22:59:12 --> UTF-8 Support Enabled
INFO - 2018-05-22 22:59:12 --> Utf8 Class Initialized
INFO - 2018-05-22 22:59:12 --> URI Class Initialized
INFO - 2018-05-22 22:59:12 --> Router Class Initialized
INFO - 2018-05-22 22:59:12 --> Output Class Initialized
INFO - 2018-05-22 22:59:12 --> Security Class Initialized
DEBUG - 2018-05-22 22:59:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 22:59:12 --> Input Class Initialized
INFO - 2018-05-22 22:59:12 --> Language Class Initialized
INFO - 2018-05-22 22:59:12 --> Language Class Initialized
INFO - 2018-05-22 22:59:12 --> Config Class Initialized
INFO - 2018-05-22 22:59:12 --> Loader Class Initialized
DEBUG - 2018-05-22 22:59:12 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 22:59:12 --> Helper loaded: url_helper
INFO - 2018-05-22 22:59:12 --> Helper loaded: form_helper
INFO - 2018-05-22 22:59:12 --> Helper loaded: date_helper
INFO - 2018-05-22 22:59:12 --> Helper loaded: util_helper
INFO - 2018-05-22 22:59:12 --> Helper loaded: text_helper
INFO - 2018-05-22 22:59:12 --> Helper loaded: string_helper
INFO - 2018-05-22 22:59:12 --> Database Driver Class Initialized
DEBUG - 2018-05-22 22:59:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 22:59:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 22:59:12 --> Email Class Initialized
INFO - 2018-05-22 22:59:12 --> Controller Class Initialized
DEBUG - 2018-05-22 22:59:12 --> Profile MX_Controller Initialized
DEBUG - 2018-05-22 22:59:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 22:59:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 22:59:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-22 22:59:12 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 22:59:13 --> Login MX_Controller Initialized
INFO - 2018-05-22 22:59:13 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 22:59:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-22 22:59:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-22 22:59:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-22 22:59:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-22 22:59:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-05-22 22:59:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-22 22:59:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-22 22:59:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/addresses.php
INFO - 2018-05-22 22:59:13 --> Final output sent to browser
DEBUG - 2018-05-22 22:59:13 --> Total execution time: 0.8839
INFO - 2018-05-22 22:59:13 --> Config Class Initialized
INFO - 2018-05-22 22:59:13 --> Hooks Class Initialized
DEBUG - 2018-05-22 22:59:13 --> UTF-8 Support Enabled
INFO - 2018-05-22 22:59:13 --> Utf8 Class Initialized
INFO - 2018-05-22 22:59:13 --> URI Class Initialized
INFO - 2018-05-22 22:59:13 --> Router Class Initialized
INFO - 2018-05-22 22:59:13 --> Output Class Initialized
INFO - 2018-05-22 22:59:13 --> Security Class Initialized
DEBUG - 2018-05-22 22:59:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 22:59:14 --> Input Class Initialized
INFO - 2018-05-22 22:59:14 --> Language Class Initialized
ERROR - 2018-05-22 22:59:14 --> 404 Page Not Found: /index
INFO - 2018-05-22 22:59:14 --> Config Class Initialized
INFO - 2018-05-22 22:59:14 --> Hooks Class Initialized
DEBUG - 2018-05-22 22:59:14 --> UTF-8 Support Enabled
INFO - 2018-05-22 22:59:14 --> Utf8 Class Initialized
INFO - 2018-05-22 22:59:14 --> URI Class Initialized
INFO - 2018-05-22 22:59:14 --> Router Class Initialized
INFO - 2018-05-22 22:59:14 --> Output Class Initialized
INFO - 2018-05-22 22:59:14 --> Security Class Initialized
DEBUG - 2018-05-22 22:59:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 22:59:14 --> Input Class Initialized
INFO - 2018-05-22 22:59:14 --> Language Class Initialized
ERROR - 2018-05-22 22:59:14 --> 404 Page Not Found: /index
INFO - 2018-05-22 22:59:14 --> Config Class Initialized
INFO - 2018-05-22 22:59:14 --> Hooks Class Initialized
DEBUG - 2018-05-22 22:59:14 --> UTF-8 Support Enabled
INFO - 2018-05-22 22:59:14 --> Utf8 Class Initialized
INFO - 2018-05-22 22:59:14 --> URI Class Initialized
INFO - 2018-05-22 22:59:14 --> Router Class Initialized
INFO - 2018-05-22 22:59:14 --> Output Class Initialized
INFO - 2018-05-22 22:59:14 --> Security Class Initialized
DEBUG - 2018-05-22 22:59:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 22:59:14 --> Input Class Initialized
INFO - 2018-05-22 22:59:14 --> Language Class Initialized
ERROR - 2018-05-22 22:59:14 --> 404 Page Not Found: /index
INFO - 2018-05-22 22:59:40 --> Config Class Initialized
INFO - 2018-05-22 22:59:40 --> Hooks Class Initialized
DEBUG - 2018-05-22 22:59:40 --> UTF-8 Support Enabled
INFO - 2018-05-22 22:59:40 --> Utf8 Class Initialized
INFO - 2018-05-22 22:59:40 --> URI Class Initialized
INFO - 2018-05-22 22:59:40 --> Router Class Initialized
INFO - 2018-05-22 22:59:40 --> Output Class Initialized
INFO - 2018-05-22 22:59:40 --> Security Class Initialized
DEBUG - 2018-05-22 22:59:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 22:59:40 --> Input Class Initialized
INFO - 2018-05-22 22:59:40 --> Language Class Initialized
INFO - 2018-05-22 22:59:40 --> Language Class Initialized
INFO - 2018-05-22 22:59:40 --> Config Class Initialized
INFO - 2018-05-22 22:59:40 --> Loader Class Initialized
DEBUG - 2018-05-22 22:59:40 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 22:59:40 --> Helper loaded: url_helper
INFO - 2018-05-22 22:59:40 --> Helper loaded: form_helper
INFO - 2018-05-22 22:59:40 --> Helper loaded: date_helper
INFO - 2018-05-22 22:59:40 --> Helper loaded: util_helper
INFO - 2018-05-22 22:59:40 --> Helper loaded: text_helper
INFO - 2018-05-22 22:59:40 --> Helper loaded: string_helper
INFO - 2018-05-22 22:59:40 --> Database Driver Class Initialized
DEBUG - 2018-05-22 22:59:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 22:59:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 22:59:40 --> Email Class Initialized
INFO - 2018-05-22 22:59:40 --> Controller Class Initialized
DEBUG - 2018-05-22 22:59:40 --> Profile MX_Controller Initialized
DEBUG - 2018-05-22 22:59:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 22:59:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 22:59:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-22 22:59:40 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 22:59:40 --> Login MX_Controller Initialized
INFO - 2018-05-22 22:59:40 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 22:59:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-22 22:59:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-22 22:59:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-22 22:59:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-22 22:59:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-05-22 22:59:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-22 22:59:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-22 22:59:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/addresses.php
INFO - 2018-05-22 22:59:41 --> Final output sent to browser
DEBUG - 2018-05-22 22:59:41 --> Total execution time: 0.8704
INFO - 2018-05-22 22:59:41 --> Config Class Initialized
INFO - 2018-05-22 22:59:41 --> Hooks Class Initialized
DEBUG - 2018-05-22 22:59:41 --> UTF-8 Support Enabled
INFO - 2018-05-22 22:59:41 --> Utf8 Class Initialized
INFO - 2018-05-22 22:59:41 --> URI Class Initialized
INFO - 2018-05-22 22:59:41 --> Router Class Initialized
INFO - 2018-05-22 22:59:41 --> Output Class Initialized
INFO - 2018-05-22 22:59:41 --> Security Class Initialized
DEBUG - 2018-05-22 22:59:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 22:59:41 --> Input Class Initialized
INFO - 2018-05-22 22:59:41 --> Language Class Initialized
ERROR - 2018-05-22 22:59:41 --> 404 Page Not Found: /index
INFO - 2018-05-22 22:59:41 --> Config Class Initialized
INFO - 2018-05-22 22:59:41 --> Hooks Class Initialized
DEBUG - 2018-05-22 22:59:42 --> UTF-8 Support Enabled
INFO - 2018-05-22 22:59:42 --> Utf8 Class Initialized
INFO - 2018-05-22 22:59:42 --> URI Class Initialized
INFO - 2018-05-22 22:59:42 --> Router Class Initialized
INFO - 2018-05-22 22:59:42 --> Output Class Initialized
INFO - 2018-05-22 22:59:42 --> Security Class Initialized
DEBUG - 2018-05-22 22:59:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 22:59:42 --> Input Class Initialized
INFO - 2018-05-22 22:59:42 --> Language Class Initialized
ERROR - 2018-05-22 22:59:42 --> 404 Page Not Found: /index
INFO - 2018-05-22 22:59:42 --> Config Class Initialized
INFO - 2018-05-22 22:59:42 --> Hooks Class Initialized
DEBUG - 2018-05-22 22:59:42 --> UTF-8 Support Enabled
INFO - 2018-05-22 22:59:42 --> Utf8 Class Initialized
INFO - 2018-05-22 22:59:42 --> URI Class Initialized
INFO - 2018-05-22 22:59:42 --> Router Class Initialized
INFO - 2018-05-22 22:59:42 --> Output Class Initialized
INFO - 2018-05-22 22:59:42 --> Security Class Initialized
DEBUG - 2018-05-22 22:59:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 22:59:42 --> Input Class Initialized
INFO - 2018-05-22 22:59:42 --> Language Class Initialized
ERROR - 2018-05-22 22:59:42 --> 404 Page Not Found: /index
INFO - 2018-05-22 22:59:56 --> Config Class Initialized
INFO - 2018-05-22 22:59:56 --> Hooks Class Initialized
DEBUG - 2018-05-22 22:59:56 --> UTF-8 Support Enabled
INFO - 2018-05-22 22:59:56 --> Utf8 Class Initialized
INFO - 2018-05-22 22:59:56 --> URI Class Initialized
INFO - 2018-05-22 22:59:56 --> Router Class Initialized
INFO - 2018-05-22 22:59:56 --> Output Class Initialized
INFO - 2018-05-22 22:59:56 --> Security Class Initialized
DEBUG - 2018-05-22 22:59:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 22:59:56 --> Input Class Initialized
INFO - 2018-05-22 22:59:56 --> Language Class Initialized
INFO - 2018-05-22 22:59:56 --> Language Class Initialized
INFO - 2018-05-22 22:59:56 --> Config Class Initialized
INFO - 2018-05-22 22:59:56 --> Loader Class Initialized
DEBUG - 2018-05-22 22:59:56 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 22:59:57 --> Helper loaded: url_helper
INFO - 2018-05-22 22:59:57 --> Helper loaded: form_helper
INFO - 2018-05-22 22:59:57 --> Helper loaded: date_helper
INFO - 2018-05-22 22:59:57 --> Helper loaded: util_helper
INFO - 2018-05-22 22:59:57 --> Helper loaded: text_helper
INFO - 2018-05-22 22:59:57 --> Helper loaded: string_helper
INFO - 2018-05-22 22:59:57 --> Database Driver Class Initialized
DEBUG - 2018-05-22 22:59:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 22:59:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 22:59:57 --> Email Class Initialized
INFO - 2018-05-22 22:59:57 --> Controller Class Initialized
DEBUG - 2018-05-22 22:59:57 --> Profile MX_Controller Initialized
DEBUG - 2018-05-22 22:59:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 22:59:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 22:59:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-22 22:59:57 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 22:59:57 --> Login MX_Controller Initialized
INFO - 2018-05-22 22:59:57 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 22:59:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-22 22:59:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-22 22:59:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-22 22:59:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-22 22:59:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-05-22 22:59:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-22 22:59:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-22 22:59:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/profile.php
INFO - 2018-05-22 22:59:57 --> Final output sent to browser
DEBUG - 2018-05-22 22:59:57 --> Total execution time: 0.9126
INFO - 2018-05-22 22:59:58 --> Config Class Initialized
INFO - 2018-05-22 22:59:58 --> Hooks Class Initialized
DEBUG - 2018-05-22 22:59:58 --> UTF-8 Support Enabled
INFO - 2018-05-22 22:59:58 --> Utf8 Class Initialized
INFO - 2018-05-22 22:59:58 --> URI Class Initialized
INFO - 2018-05-22 22:59:58 --> Router Class Initialized
INFO - 2018-05-22 22:59:58 --> Output Class Initialized
INFO - 2018-05-22 22:59:58 --> Security Class Initialized
DEBUG - 2018-05-22 22:59:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 22:59:58 --> Input Class Initialized
INFO - 2018-05-22 22:59:58 --> Language Class Initialized
ERROR - 2018-05-22 22:59:58 --> 404 Page Not Found: /index
INFO - 2018-05-22 22:59:58 --> Config Class Initialized
INFO - 2018-05-22 22:59:58 --> Hooks Class Initialized
DEBUG - 2018-05-22 22:59:58 --> UTF-8 Support Enabled
INFO - 2018-05-22 22:59:58 --> Utf8 Class Initialized
INFO - 2018-05-22 22:59:58 --> URI Class Initialized
INFO - 2018-05-22 22:59:58 --> Router Class Initialized
INFO - 2018-05-22 22:59:58 --> Output Class Initialized
INFO - 2018-05-22 22:59:58 --> Security Class Initialized
DEBUG - 2018-05-22 22:59:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 22:59:58 --> Input Class Initialized
INFO - 2018-05-22 22:59:58 --> Language Class Initialized
ERROR - 2018-05-22 22:59:58 --> 404 Page Not Found: /index
INFO - 2018-05-22 22:59:58 --> Config Class Initialized
INFO - 2018-05-22 22:59:58 --> Hooks Class Initialized
DEBUG - 2018-05-22 22:59:58 --> UTF-8 Support Enabled
INFO - 2018-05-22 22:59:58 --> Utf8 Class Initialized
INFO - 2018-05-22 22:59:58 --> URI Class Initialized
INFO - 2018-05-22 22:59:58 --> Router Class Initialized
INFO - 2018-05-22 22:59:58 --> Output Class Initialized
INFO - 2018-05-22 22:59:59 --> Security Class Initialized
DEBUG - 2018-05-22 22:59:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 22:59:59 --> Input Class Initialized
INFO - 2018-05-22 22:59:59 --> Language Class Initialized
ERROR - 2018-05-22 22:59:59 --> 404 Page Not Found: /index
INFO - 2018-05-22 23:06:17 --> Config Class Initialized
INFO - 2018-05-22 23:06:17 --> Hooks Class Initialized
DEBUG - 2018-05-22 23:06:18 --> UTF-8 Support Enabled
INFO - 2018-05-22 23:06:18 --> Utf8 Class Initialized
INFO - 2018-05-22 23:06:18 --> URI Class Initialized
INFO - 2018-05-22 23:06:18 --> Router Class Initialized
INFO - 2018-05-22 23:06:18 --> Output Class Initialized
INFO - 2018-05-22 23:06:18 --> Security Class Initialized
DEBUG - 2018-05-22 23:06:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 23:06:18 --> Input Class Initialized
INFO - 2018-05-22 23:06:18 --> Language Class Initialized
INFO - 2018-05-22 23:06:18 --> Language Class Initialized
INFO - 2018-05-22 23:06:18 --> Config Class Initialized
INFO - 2018-05-22 23:06:18 --> Loader Class Initialized
DEBUG - 2018-05-22 23:06:18 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-22 23:06:18 --> Helper loaded: url_helper
INFO - 2018-05-22 23:06:18 --> Helper loaded: form_helper
INFO - 2018-05-22 23:06:18 --> Helper loaded: date_helper
INFO - 2018-05-22 23:06:18 --> Helper loaded: util_helper
INFO - 2018-05-22 23:06:18 --> Helper loaded: text_helper
INFO - 2018-05-22 23:06:18 --> Helper loaded: string_helper
INFO - 2018-05-22 23:06:18 --> Database Driver Class Initialized
DEBUG - 2018-05-22 23:06:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-22 23:06:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-22 23:06:18 --> Email Class Initialized
INFO - 2018-05-22 23:06:18 --> Controller Class Initialized
DEBUG - 2018-05-22 23:06:18 --> Profile MX_Controller Initialized
DEBUG - 2018-05-22 23:06:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-22 23:06:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-22 23:06:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-05-22 23:06:18 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-22 23:06:18 --> Login MX_Controller Initialized
INFO - 2018-05-22 23:06:18 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-22 23:06:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-22 23:06:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-22 23:06:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-22 23:06:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-22 23:06:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-05-22 23:06:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-22 23:06:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-22 23:06:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/addresses.php
INFO - 2018-05-22 23:06:18 --> Final output sent to browser
DEBUG - 2018-05-22 23:06:18 --> Total execution time: 0.9338
INFO - 2018-05-22 23:06:19 --> Config Class Initialized
INFO - 2018-05-22 23:06:19 --> Hooks Class Initialized
DEBUG - 2018-05-22 23:06:19 --> UTF-8 Support Enabled
INFO - 2018-05-22 23:06:19 --> Utf8 Class Initialized
INFO - 2018-05-22 23:06:19 --> URI Class Initialized
INFO - 2018-05-22 23:06:19 --> Router Class Initialized
INFO - 2018-05-22 23:06:19 --> Output Class Initialized
INFO - 2018-05-22 23:06:19 --> Security Class Initialized
DEBUG - 2018-05-22 23:06:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 23:06:19 --> Input Class Initialized
INFO - 2018-05-22 23:06:19 --> Language Class Initialized
ERROR - 2018-05-22 23:06:19 --> 404 Page Not Found: /index
INFO - 2018-05-22 23:06:19 --> Config Class Initialized
INFO - 2018-05-22 23:06:19 --> Hooks Class Initialized
DEBUG - 2018-05-22 23:06:19 --> UTF-8 Support Enabled
INFO - 2018-05-22 23:06:19 --> Utf8 Class Initialized
INFO - 2018-05-22 23:06:19 --> URI Class Initialized
INFO - 2018-05-22 23:06:19 --> Router Class Initialized
INFO - 2018-05-22 23:06:20 --> Output Class Initialized
INFO - 2018-05-22 23:06:20 --> Security Class Initialized
DEBUG - 2018-05-22 23:06:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 23:06:20 --> Input Class Initialized
INFO - 2018-05-22 23:06:20 --> Language Class Initialized
ERROR - 2018-05-22 23:06:20 --> 404 Page Not Found: /index
INFO - 2018-05-22 23:06:20 --> Config Class Initialized
INFO - 2018-05-22 23:06:20 --> Hooks Class Initialized
DEBUG - 2018-05-22 23:06:20 --> UTF-8 Support Enabled
INFO - 2018-05-22 23:06:20 --> Utf8 Class Initialized
INFO - 2018-05-22 23:06:20 --> URI Class Initialized
INFO - 2018-05-22 23:06:20 --> Router Class Initialized
INFO - 2018-05-22 23:06:20 --> Output Class Initialized
INFO - 2018-05-22 23:06:20 --> Security Class Initialized
DEBUG - 2018-05-22 23:06:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-22 23:06:20 --> Input Class Initialized
INFO - 2018-05-22 23:06:20 --> Language Class Initialized
ERROR - 2018-05-22 23:06:20 --> 404 Page Not Found: /index
