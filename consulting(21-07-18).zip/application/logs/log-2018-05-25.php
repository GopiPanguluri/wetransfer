<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-05-25 00:55:26 --> Config Class Initialized
INFO - 2018-05-25 00:55:26 --> Hooks Class Initialized
DEBUG - 2018-05-25 00:55:26 --> UTF-8 Support Enabled
INFO - 2018-05-25 00:55:26 --> Utf8 Class Initialized
INFO - 2018-05-25 00:55:26 --> URI Class Initialized
INFO - 2018-05-25 00:55:26 --> Router Class Initialized
INFO - 2018-05-25 00:55:26 --> Output Class Initialized
INFO - 2018-05-25 00:55:26 --> Security Class Initialized
DEBUG - 2018-05-25 00:55:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 00:55:26 --> Input Class Initialized
INFO - 2018-05-25 00:55:26 --> Language Class Initialized
INFO - 2018-05-25 00:55:26 --> Language Class Initialized
INFO - 2018-05-25 00:55:26 --> Config Class Initialized
INFO - 2018-05-25 00:55:26 --> Loader Class Initialized
DEBUG - 2018-05-25 00:55:26 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-25 00:55:26 --> Helper loaded: url_helper
INFO - 2018-05-25 00:55:26 --> Helper loaded: form_helper
INFO - 2018-05-25 00:55:26 --> Helper loaded: date_helper
INFO - 2018-05-25 00:55:26 --> Helper loaded: util_helper
INFO - 2018-05-25 00:55:26 --> Helper loaded: text_helper
INFO - 2018-05-25 00:55:26 --> Helper loaded: string_helper
INFO - 2018-05-25 00:55:26 --> Database Driver Class Initialized
DEBUG - 2018-05-25 00:55:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-25 00:55:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-25 00:55:26 --> Email Class Initialized
INFO - 2018-05-25 00:55:26 --> Controller Class Initialized
DEBUG - 2018-05-25 00:55:26 --> Home MX_Controller Initialized
DEBUG - 2018-05-25 00:55:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-25 00:55:26 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-25 00:55:26 --> Login MX_Controller Initialized
INFO - 2018-05-25 00:55:26 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-25 00:55:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-25 00:55:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-25 00:57:08 --> Config Class Initialized
INFO - 2018-05-25 00:57:08 --> Hooks Class Initialized
DEBUG - 2018-05-25 00:57:09 --> UTF-8 Support Enabled
INFO - 2018-05-25 00:57:09 --> Utf8 Class Initialized
INFO - 2018-05-25 00:57:09 --> URI Class Initialized
INFO - 2018-05-25 00:57:09 --> Router Class Initialized
INFO - 2018-05-25 00:57:09 --> Output Class Initialized
INFO - 2018-05-25 00:57:09 --> Security Class Initialized
DEBUG - 2018-05-25 00:57:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 00:57:09 --> Input Class Initialized
INFO - 2018-05-25 00:57:09 --> Language Class Initialized
INFO - 2018-05-25 00:57:09 --> Language Class Initialized
INFO - 2018-05-25 00:57:09 --> Config Class Initialized
INFO - 2018-05-25 00:57:09 --> Loader Class Initialized
DEBUG - 2018-05-25 00:57:09 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-25 00:57:09 --> Helper loaded: url_helper
INFO - 2018-05-25 00:57:09 --> Helper loaded: form_helper
INFO - 2018-05-25 00:57:09 --> Helper loaded: date_helper
INFO - 2018-05-25 00:57:09 --> Helper loaded: util_helper
INFO - 2018-05-25 00:57:09 --> Helper loaded: text_helper
INFO - 2018-05-25 00:57:09 --> Helper loaded: string_helper
INFO - 2018-05-25 00:57:09 --> Database Driver Class Initialized
DEBUG - 2018-05-25 00:57:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-25 00:57:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-25 00:57:09 --> Email Class Initialized
INFO - 2018-05-25 00:57:09 --> Controller Class Initialized
DEBUG - 2018-05-25 00:57:09 --> Home MX_Controller Initialized
DEBUG - 2018-05-25 00:57:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-25 00:57:09 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-25 00:57:09 --> Login MX_Controller Initialized
INFO - 2018-05-25 00:57:09 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-25 00:57:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-25 00:57:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-25 00:58:58 --> Config Class Initialized
INFO - 2018-05-25 00:58:58 --> Hooks Class Initialized
DEBUG - 2018-05-25 00:58:58 --> UTF-8 Support Enabled
INFO - 2018-05-25 00:58:58 --> Utf8 Class Initialized
INFO - 2018-05-25 00:58:58 --> URI Class Initialized
INFO - 2018-05-25 00:58:58 --> Router Class Initialized
INFO - 2018-05-25 00:58:58 --> Output Class Initialized
INFO - 2018-05-25 00:58:58 --> Security Class Initialized
DEBUG - 2018-05-25 00:58:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 00:58:58 --> Input Class Initialized
INFO - 2018-05-25 00:58:58 --> Language Class Initialized
INFO - 2018-05-25 00:58:58 --> Language Class Initialized
INFO - 2018-05-25 00:58:58 --> Config Class Initialized
INFO - 2018-05-25 00:58:58 --> Loader Class Initialized
DEBUG - 2018-05-25 00:58:58 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-25 00:58:58 --> Helper loaded: url_helper
INFO - 2018-05-25 00:58:58 --> Helper loaded: form_helper
INFO - 2018-05-25 00:58:58 --> Helper loaded: date_helper
INFO - 2018-05-25 00:58:58 --> Helper loaded: util_helper
INFO - 2018-05-25 00:58:58 --> Helper loaded: text_helper
INFO - 2018-05-25 00:58:58 --> Helper loaded: string_helper
INFO - 2018-05-25 00:58:58 --> Database Driver Class Initialized
DEBUG - 2018-05-25 00:58:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-25 00:58:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-25 00:58:58 --> Email Class Initialized
INFO - 2018-05-25 00:58:58 --> Controller Class Initialized
DEBUG - 2018-05-25 00:58:58 --> Home MX_Controller Initialized
DEBUG - 2018-05-25 00:58:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-25 00:58:58 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-25 00:58:58 --> Login MX_Controller Initialized
INFO - 2018-05-25 00:58:58 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-25 00:58:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-25 00:58:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-25 00:59:22 --> Config Class Initialized
INFO - 2018-05-25 00:59:22 --> Hooks Class Initialized
DEBUG - 2018-05-25 00:59:22 --> UTF-8 Support Enabled
INFO - 2018-05-25 00:59:22 --> Utf8 Class Initialized
INFO - 2018-05-25 00:59:22 --> URI Class Initialized
INFO - 2018-05-25 00:59:22 --> Router Class Initialized
INFO - 2018-05-25 00:59:22 --> Output Class Initialized
INFO - 2018-05-25 00:59:22 --> Security Class Initialized
DEBUG - 2018-05-25 00:59:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 00:59:22 --> Input Class Initialized
INFO - 2018-05-25 00:59:22 --> Language Class Initialized
INFO - 2018-05-25 00:59:22 --> Language Class Initialized
INFO - 2018-05-25 00:59:22 --> Config Class Initialized
INFO - 2018-05-25 00:59:22 --> Loader Class Initialized
DEBUG - 2018-05-25 00:59:22 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-25 00:59:22 --> Helper loaded: url_helper
INFO - 2018-05-25 00:59:22 --> Helper loaded: form_helper
INFO - 2018-05-25 00:59:22 --> Helper loaded: date_helper
INFO - 2018-05-25 00:59:22 --> Helper loaded: util_helper
INFO - 2018-05-25 00:59:22 --> Helper loaded: text_helper
INFO - 2018-05-25 00:59:22 --> Helper loaded: string_helper
INFO - 2018-05-25 00:59:22 --> Database Driver Class Initialized
DEBUG - 2018-05-25 00:59:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-25 00:59:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-25 00:59:22 --> Email Class Initialized
INFO - 2018-05-25 00:59:22 --> Controller Class Initialized
DEBUG - 2018-05-25 00:59:22 --> Home MX_Controller Initialized
DEBUG - 2018-05-25 00:59:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-25 00:59:22 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-25 00:59:22 --> Login MX_Controller Initialized
INFO - 2018-05-25 00:59:22 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-25 00:59:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-25 00:59:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-25 00:59:34 --> Config Class Initialized
INFO - 2018-05-25 00:59:34 --> Hooks Class Initialized
DEBUG - 2018-05-25 00:59:34 --> UTF-8 Support Enabled
INFO - 2018-05-25 00:59:34 --> Utf8 Class Initialized
INFO - 2018-05-25 00:59:34 --> URI Class Initialized
INFO - 2018-05-25 00:59:34 --> Router Class Initialized
INFO - 2018-05-25 00:59:34 --> Output Class Initialized
INFO - 2018-05-25 00:59:34 --> Security Class Initialized
DEBUG - 2018-05-25 00:59:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 00:59:34 --> Input Class Initialized
INFO - 2018-05-25 00:59:34 --> Language Class Initialized
INFO - 2018-05-25 00:59:34 --> Language Class Initialized
INFO - 2018-05-25 00:59:34 --> Config Class Initialized
INFO - 2018-05-25 00:59:34 --> Loader Class Initialized
DEBUG - 2018-05-25 00:59:34 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-25 00:59:34 --> Helper loaded: url_helper
INFO - 2018-05-25 00:59:34 --> Helper loaded: form_helper
INFO - 2018-05-25 00:59:34 --> Helper loaded: date_helper
INFO - 2018-05-25 00:59:34 --> Helper loaded: util_helper
INFO - 2018-05-25 00:59:34 --> Helper loaded: text_helper
INFO - 2018-05-25 00:59:34 --> Helper loaded: string_helper
INFO - 2018-05-25 00:59:34 --> Database Driver Class Initialized
DEBUG - 2018-05-25 00:59:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-25 00:59:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-25 00:59:34 --> Email Class Initialized
INFO - 2018-05-25 00:59:34 --> Controller Class Initialized
DEBUG - 2018-05-25 00:59:34 --> Home MX_Controller Initialized
DEBUG - 2018-05-25 00:59:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-25 00:59:34 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-25 00:59:34 --> Login MX_Controller Initialized
INFO - 2018-05-25 00:59:34 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-25 00:59:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-25 00:59:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-25 00:59:44 --> Config Class Initialized
INFO - 2018-05-25 00:59:44 --> Hooks Class Initialized
DEBUG - 2018-05-25 00:59:44 --> UTF-8 Support Enabled
INFO - 2018-05-25 00:59:44 --> Utf8 Class Initialized
INFO - 2018-05-25 00:59:44 --> URI Class Initialized
INFO - 2018-05-25 00:59:44 --> Router Class Initialized
INFO - 2018-05-25 00:59:44 --> Output Class Initialized
INFO - 2018-05-25 00:59:44 --> Security Class Initialized
DEBUG - 2018-05-25 00:59:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 00:59:44 --> Input Class Initialized
INFO - 2018-05-25 00:59:44 --> Language Class Initialized
INFO - 2018-05-25 00:59:44 --> Language Class Initialized
INFO - 2018-05-25 00:59:44 --> Config Class Initialized
INFO - 2018-05-25 00:59:44 --> Loader Class Initialized
DEBUG - 2018-05-25 00:59:44 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-25 00:59:44 --> Helper loaded: url_helper
INFO - 2018-05-25 00:59:44 --> Helper loaded: form_helper
INFO - 2018-05-25 00:59:44 --> Helper loaded: date_helper
INFO - 2018-05-25 00:59:44 --> Helper loaded: util_helper
INFO - 2018-05-25 00:59:44 --> Helper loaded: text_helper
INFO - 2018-05-25 00:59:44 --> Helper loaded: string_helper
INFO - 2018-05-25 00:59:44 --> Database Driver Class Initialized
DEBUG - 2018-05-25 00:59:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-25 00:59:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-25 00:59:44 --> Email Class Initialized
INFO - 2018-05-25 00:59:44 --> Controller Class Initialized
DEBUG - 2018-05-25 00:59:44 --> Home MX_Controller Initialized
DEBUG - 2018-05-25 00:59:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-25 00:59:44 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-25 00:59:44 --> Login MX_Controller Initialized
INFO - 2018-05-25 00:59:44 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-25 00:59:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-25 00:59:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-25 00:59:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-25 00:59:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-25 00:59:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-25 00:59:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-25 00:59:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-25 00:59:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-05-25 00:59:45 --> Final output sent to browser
DEBUG - 2018-05-25 00:59:45 --> Total execution time: 0.4922
INFO - 2018-05-25 00:59:45 --> Config Class Initialized
INFO - 2018-05-25 00:59:45 --> Hooks Class Initialized
DEBUG - 2018-05-25 00:59:45 --> UTF-8 Support Enabled
INFO - 2018-05-25 00:59:45 --> Utf8 Class Initialized
INFO - 2018-05-25 00:59:45 --> URI Class Initialized
INFO - 2018-05-25 00:59:45 --> Config Class Initialized
INFO - 2018-05-25 00:59:45 --> Hooks Class Initialized
INFO - 2018-05-25 00:59:45 --> Router Class Initialized
INFO - 2018-05-25 00:59:45 --> Output Class Initialized
DEBUG - 2018-05-25 00:59:45 --> UTF-8 Support Enabled
INFO - 2018-05-25 00:59:45 --> Security Class Initialized
INFO - 2018-05-25 00:59:45 --> Utf8 Class Initialized
DEBUG - 2018-05-25 00:59:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 00:59:45 --> Input Class Initialized
INFO - 2018-05-25 00:59:45 --> Language Class Initialized
INFO - 2018-05-25 00:59:45 --> URI Class Initialized
ERROR - 2018-05-25 00:59:45 --> 404 Page Not Found: /index
INFO - 2018-05-25 00:59:45 --> Router Class Initialized
INFO - 2018-05-25 00:59:45 --> Output Class Initialized
INFO - 2018-05-25 00:59:45 --> Security Class Initialized
DEBUG - 2018-05-25 00:59:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 00:59:45 --> Input Class Initialized
INFO - 2018-05-25 00:59:45 --> Language Class Initialized
ERROR - 2018-05-25 00:59:45 --> 404 Page Not Found: /index
INFO - 2018-05-25 00:59:46 --> Config Class Initialized
INFO - 2018-05-25 00:59:46 --> Hooks Class Initialized
DEBUG - 2018-05-25 00:59:46 --> UTF-8 Support Enabled
INFO - 2018-05-25 00:59:46 --> Utf8 Class Initialized
INFO - 2018-05-25 00:59:46 --> URI Class Initialized
INFO - 2018-05-25 00:59:46 --> Router Class Initialized
INFO - 2018-05-25 00:59:46 --> Output Class Initialized
INFO - 2018-05-25 00:59:46 --> Security Class Initialized
DEBUG - 2018-05-25 00:59:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 00:59:46 --> Input Class Initialized
INFO - 2018-05-25 00:59:46 --> Language Class Initialized
ERROR - 2018-05-25 00:59:46 --> 404 Page Not Found: /index
INFO - 2018-05-25 00:59:46 --> Config Class Initialized
INFO - 2018-05-25 00:59:46 --> Hooks Class Initialized
DEBUG - 2018-05-25 00:59:46 --> UTF-8 Support Enabled
INFO - 2018-05-25 00:59:46 --> Utf8 Class Initialized
INFO - 2018-05-25 00:59:46 --> URI Class Initialized
INFO - 2018-05-25 00:59:46 --> Router Class Initialized
INFO - 2018-05-25 00:59:46 --> Output Class Initialized
INFO - 2018-05-25 00:59:46 --> Security Class Initialized
DEBUG - 2018-05-25 00:59:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 00:59:46 --> Input Class Initialized
INFO - 2018-05-25 00:59:46 --> Language Class Initialized
ERROR - 2018-05-25 00:59:46 --> 404 Page Not Found: /index
INFO - 2018-05-25 00:59:48 --> Config Class Initialized
INFO - 2018-05-25 00:59:48 --> Hooks Class Initialized
DEBUG - 2018-05-25 00:59:48 --> UTF-8 Support Enabled
INFO - 2018-05-25 00:59:48 --> Utf8 Class Initialized
INFO - 2018-05-25 00:59:48 --> URI Class Initialized
INFO - 2018-05-25 00:59:48 --> Router Class Initialized
INFO - 2018-05-25 00:59:48 --> Output Class Initialized
INFO - 2018-05-25 00:59:48 --> Security Class Initialized
DEBUG - 2018-05-25 00:59:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 00:59:48 --> Input Class Initialized
INFO - 2018-05-25 00:59:48 --> Language Class Initialized
ERROR - 2018-05-25 00:59:48 --> 404 Page Not Found: /index
INFO - 2018-05-25 00:59:48 --> Config Class Initialized
INFO - 2018-05-25 00:59:49 --> Hooks Class Initialized
DEBUG - 2018-05-25 00:59:49 --> UTF-8 Support Enabled
INFO - 2018-05-25 00:59:49 --> Utf8 Class Initialized
INFO - 2018-05-25 00:59:49 --> URI Class Initialized
INFO - 2018-05-25 00:59:49 --> Router Class Initialized
INFO - 2018-05-25 00:59:49 --> Output Class Initialized
INFO - 2018-05-25 00:59:49 --> Security Class Initialized
DEBUG - 2018-05-25 00:59:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 00:59:49 --> Input Class Initialized
INFO - 2018-05-25 00:59:49 --> Language Class Initialized
ERROR - 2018-05-25 00:59:49 --> 404 Page Not Found: /index
INFO - 2018-05-25 00:59:49 --> Config Class Initialized
INFO - 2018-05-25 00:59:49 --> Hooks Class Initialized
DEBUG - 2018-05-25 00:59:49 --> UTF-8 Support Enabled
INFO - 2018-05-25 00:59:49 --> Utf8 Class Initialized
INFO - 2018-05-25 00:59:49 --> URI Class Initialized
INFO - 2018-05-25 00:59:49 --> Router Class Initialized
INFO - 2018-05-25 00:59:49 --> Output Class Initialized
INFO - 2018-05-25 00:59:49 --> Security Class Initialized
DEBUG - 2018-05-25 00:59:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 00:59:49 --> Input Class Initialized
INFO - 2018-05-25 00:59:49 --> Language Class Initialized
ERROR - 2018-05-25 00:59:49 --> 404 Page Not Found: /index
INFO - 2018-05-25 01:02:13 --> Config Class Initialized
INFO - 2018-05-25 01:02:13 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:02:13 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:02:13 --> Utf8 Class Initialized
INFO - 2018-05-25 01:02:13 --> URI Class Initialized
INFO - 2018-05-25 01:02:13 --> Router Class Initialized
INFO - 2018-05-25 01:02:13 --> Output Class Initialized
INFO - 2018-05-25 01:02:13 --> Security Class Initialized
DEBUG - 2018-05-25 01:02:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:02:13 --> Input Class Initialized
INFO - 2018-05-25 01:02:13 --> Language Class Initialized
INFO - 2018-05-25 01:02:13 --> Language Class Initialized
INFO - 2018-05-25 01:02:13 --> Config Class Initialized
INFO - 2018-05-25 01:02:13 --> Loader Class Initialized
DEBUG - 2018-05-25 01:02:13 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-25 01:02:13 --> Helper loaded: url_helper
INFO - 2018-05-25 01:02:13 --> Helper loaded: form_helper
INFO - 2018-05-25 01:02:13 --> Helper loaded: date_helper
INFO - 2018-05-25 01:02:13 --> Helper loaded: util_helper
INFO - 2018-05-25 01:02:13 --> Helper loaded: text_helper
INFO - 2018-05-25 01:02:13 --> Helper loaded: string_helper
INFO - 2018-05-25 01:02:13 --> Database Driver Class Initialized
DEBUG - 2018-05-25 01:02:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-25 01:02:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-25 01:02:13 --> Email Class Initialized
INFO - 2018-05-25 01:02:13 --> Controller Class Initialized
DEBUG - 2018-05-25 01:02:13 --> Home MX_Controller Initialized
DEBUG - 2018-05-25 01:02:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-25 01:02:13 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-25 01:02:13 --> Login MX_Controller Initialized
INFO - 2018-05-25 01:02:13 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-25 01:02:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-25 01:02:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-25 01:02:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-25 01:02:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-25 01:02:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
ERROR - 2018-05-25 01:02:13 --> Severity: Notice --> Undefined index: seen_status E:\xampp\htdocs\consulting\application\modules\home\views\course.php 121
DEBUG - 2018-05-25 01:02:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-25 01:02:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-25 01:02:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-05-25 01:02:13 --> Final output sent to browser
DEBUG - 2018-05-25 01:02:13 --> Total execution time: 0.3951
INFO - 2018-05-25 01:02:13 --> Config Class Initialized
INFO - 2018-05-25 01:02:14 --> Hooks Class Initialized
INFO - 2018-05-25 01:02:14 --> Config Class Initialized
INFO - 2018-05-25 01:02:14 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:02:14 --> UTF-8 Support Enabled
DEBUG - 2018-05-25 01:02:14 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:02:14 --> Utf8 Class Initialized
INFO - 2018-05-25 01:02:14 --> URI Class Initialized
INFO - 2018-05-25 01:02:14 --> Router Class Initialized
INFO - 2018-05-25 01:02:14 --> Output Class Initialized
INFO - 2018-05-25 01:02:14 --> Security Class Initialized
DEBUG - 2018-05-25 01:02:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:02:14 --> Input Class Initialized
INFO - 2018-05-25 01:02:14 --> Language Class Initialized
ERROR - 2018-05-25 01:02:14 --> 404 Page Not Found: /index
INFO - 2018-05-25 01:02:14 --> Utf8 Class Initialized
INFO - 2018-05-25 01:02:14 --> URI Class Initialized
INFO - 2018-05-25 01:02:14 --> Router Class Initialized
INFO - 2018-05-25 01:02:14 --> Output Class Initialized
INFO - 2018-05-25 01:02:14 --> Security Class Initialized
DEBUG - 2018-05-25 01:02:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:02:14 --> Input Class Initialized
INFO - 2018-05-25 01:02:14 --> Config Class Initialized
INFO - 2018-05-25 01:02:14 --> Hooks Class Initialized
INFO - 2018-05-25 01:02:14 --> Language Class Initialized
DEBUG - 2018-05-25 01:02:14 --> UTF-8 Support Enabled
ERROR - 2018-05-25 01:02:14 --> 404 Page Not Found: /index
INFO - 2018-05-25 01:02:14 --> Utf8 Class Initialized
INFO - 2018-05-25 01:02:14 --> URI Class Initialized
INFO - 2018-05-25 01:02:14 --> Router Class Initialized
INFO - 2018-05-25 01:02:14 --> Output Class Initialized
INFO - 2018-05-25 01:02:14 --> Security Class Initialized
DEBUG - 2018-05-25 01:02:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:02:14 --> Input Class Initialized
INFO - 2018-05-25 01:02:14 --> Language Class Initialized
ERROR - 2018-05-25 01:02:14 --> 404 Page Not Found: /index
INFO - 2018-05-25 01:02:14 --> Config Class Initialized
INFO - 2018-05-25 01:02:14 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:02:14 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:02:14 --> Utf8 Class Initialized
INFO - 2018-05-25 01:02:14 --> URI Class Initialized
INFO - 2018-05-25 01:02:14 --> Router Class Initialized
INFO - 2018-05-25 01:02:14 --> Output Class Initialized
INFO - 2018-05-25 01:02:14 --> Security Class Initialized
DEBUG - 2018-05-25 01:02:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:02:14 --> Input Class Initialized
INFO - 2018-05-25 01:02:14 --> Language Class Initialized
ERROR - 2018-05-25 01:02:14 --> 404 Page Not Found: /index
INFO - 2018-05-25 01:02:16 --> Config Class Initialized
INFO - 2018-05-25 01:02:16 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:02:17 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:02:17 --> Utf8 Class Initialized
INFO - 2018-05-25 01:02:17 --> URI Class Initialized
INFO - 2018-05-25 01:02:17 --> Router Class Initialized
INFO - 2018-05-25 01:02:17 --> Output Class Initialized
INFO - 2018-05-25 01:02:17 --> Security Class Initialized
DEBUG - 2018-05-25 01:02:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:02:17 --> Input Class Initialized
INFO - 2018-05-25 01:02:17 --> Language Class Initialized
ERROR - 2018-05-25 01:02:17 --> 404 Page Not Found: /index
INFO - 2018-05-25 01:02:17 --> Config Class Initialized
INFO - 2018-05-25 01:02:17 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:02:17 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:02:17 --> Utf8 Class Initialized
INFO - 2018-05-25 01:02:17 --> URI Class Initialized
INFO - 2018-05-25 01:02:17 --> Router Class Initialized
INFO - 2018-05-25 01:02:17 --> Output Class Initialized
INFO - 2018-05-25 01:02:17 --> Security Class Initialized
DEBUG - 2018-05-25 01:02:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:02:17 --> Input Class Initialized
INFO - 2018-05-25 01:02:17 --> Language Class Initialized
ERROR - 2018-05-25 01:02:17 --> 404 Page Not Found: /index
INFO - 2018-05-25 01:02:17 --> Config Class Initialized
INFO - 2018-05-25 01:02:17 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:02:17 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:02:17 --> Utf8 Class Initialized
INFO - 2018-05-25 01:02:17 --> URI Class Initialized
INFO - 2018-05-25 01:02:17 --> Router Class Initialized
INFO - 2018-05-25 01:02:17 --> Output Class Initialized
INFO - 2018-05-25 01:02:17 --> Security Class Initialized
DEBUG - 2018-05-25 01:02:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:02:17 --> Input Class Initialized
INFO - 2018-05-25 01:02:17 --> Language Class Initialized
ERROR - 2018-05-25 01:02:17 --> 404 Page Not Found: /index
INFO - 2018-05-25 01:02:30 --> Config Class Initialized
INFO - 2018-05-25 01:02:30 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:02:30 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:02:30 --> Utf8 Class Initialized
INFO - 2018-05-25 01:02:30 --> URI Class Initialized
INFO - 2018-05-25 01:02:30 --> Router Class Initialized
INFO - 2018-05-25 01:02:30 --> Output Class Initialized
INFO - 2018-05-25 01:02:30 --> Security Class Initialized
DEBUG - 2018-05-25 01:02:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:02:30 --> Input Class Initialized
INFO - 2018-05-25 01:02:30 --> Language Class Initialized
INFO - 2018-05-25 01:02:30 --> Language Class Initialized
INFO - 2018-05-25 01:02:30 --> Config Class Initialized
INFO - 2018-05-25 01:02:30 --> Loader Class Initialized
DEBUG - 2018-05-25 01:02:30 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-25 01:02:30 --> Helper loaded: url_helper
INFO - 2018-05-25 01:02:30 --> Helper loaded: form_helper
INFO - 2018-05-25 01:02:30 --> Helper loaded: date_helper
INFO - 2018-05-25 01:02:30 --> Helper loaded: util_helper
INFO - 2018-05-25 01:02:30 --> Helper loaded: text_helper
INFO - 2018-05-25 01:02:30 --> Helper loaded: string_helper
INFO - 2018-05-25 01:02:30 --> Database Driver Class Initialized
DEBUG - 2018-05-25 01:02:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-25 01:02:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-25 01:02:30 --> Email Class Initialized
INFO - 2018-05-25 01:02:30 --> Controller Class Initialized
DEBUG - 2018-05-25 01:02:30 --> Home MX_Controller Initialized
DEBUG - 2018-05-25 01:02:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-25 01:02:30 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-25 01:02:30 --> Login MX_Controller Initialized
INFO - 2018-05-25 01:02:30 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-25 01:02:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-25 01:02:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-25 01:03:09 --> Config Class Initialized
INFO - 2018-05-25 01:03:10 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:03:10 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:03:10 --> Utf8 Class Initialized
INFO - 2018-05-25 01:03:10 --> URI Class Initialized
INFO - 2018-05-25 01:03:10 --> Router Class Initialized
INFO - 2018-05-25 01:03:10 --> Output Class Initialized
INFO - 2018-05-25 01:03:10 --> Security Class Initialized
DEBUG - 2018-05-25 01:03:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:03:10 --> Input Class Initialized
INFO - 2018-05-25 01:03:10 --> Language Class Initialized
INFO - 2018-05-25 01:03:10 --> Language Class Initialized
INFO - 2018-05-25 01:03:10 --> Config Class Initialized
INFO - 2018-05-25 01:03:10 --> Loader Class Initialized
DEBUG - 2018-05-25 01:03:10 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-25 01:03:10 --> Helper loaded: url_helper
INFO - 2018-05-25 01:03:10 --> Helper loaded: form_helper
INFO - 2018-05-25 01:03:10 --> Helper loaded: date_helper
INFO - 2018-05-25 01:03:10 --> Helper loaded: util_helper
INFO - 2018-05-25 01:03:10 --> Helper loaded: text_helper
INFO - 2018-05-25 01:03:10 --> Helper loaded: string_helper
INFO - 2018-05-25 01:03:10 --> Database Driver Class Initialized
DEBUG - 2018-05-25 01:03:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-25 01:03:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-25 01:03:10 --> Email Class Initialized
INFO - 2018-05-25 01:03:10 --> Controller Class Initialized
DEBUG - 2018-05-25 01:03:10 --> Home MX_Controller Initialized
DEBUG - 2018-05-25 01:03:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-25 01:03:10 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-25 01:03:10 --> Login MX_Controller Initialized
INFO - 2018-05-25 01:03:10 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-25 01:03:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-25 01:03:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-25 01:03:17 --> Config Class Initialized
INFO - 2018-05-25 01:03:17 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:03:17 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:03:17 --> Utf8 Class Initialized
INFO - 2018-05-25 01:03:17 --> URI Class Initialized
INFO - 2018-05-25 01:03:17 --> Router Class Initialized
INFO - 2018-05-25 01:03:17 --> Output Class Initialized
INFO - 2018-05-25 01:03:17 --> Security Class Initialized
DEBUG - 2018-05-25 01:03:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:03:17 --> Input Class Initialized
INFO - 2018-05-25 01:03:17 --> Language Class Initialized
INFO - 2018-05-25 01:03:17 --> Language Class Initialized
INFO - 2018-05-25 01:03:17 --> Config Class Initialized
INFO - 2018-05-25 01:03:17 --> Loader Class Initialized
DEBUG - 2018-05-25 01:03:17 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-25 01:03:17 --> Helper loaded: url_helper
INFO - 2018-05-25 01:03:17 --> Helper loaded: form_helper
INFO - 2018-05-25 01:03:17 --> Helper loaded: date_helper
INFO - 2018-05-25 01:03:17 --> Helper loaded: util_helper
INFO - 2018-05-25 01:03:17 --> Helper loaded: text_helper
INFO - 2018-05-25 01:03:17 --> Helper loaded: string_helper
INFO - 2018-05-25 01:03:17 --> Database Driver Class Initialized
DEBUG - 2018-05-25 01:03:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-25 01:03:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-25 01:03:17 --> Email Class Initialized
INFO - 2018-05-25 01:03:17 --> Controller Class Initialized
DEBUG - 2018-05-25 01:03:17 --> Home MX_Controller Initialized
DEBUG - 2018-05-25 01:03:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-25 01:03:17 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-25 01:03:17 --> Login MX_Controller Initialized
INFO - 2018-05-25 01:03:17 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-25 01:03:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-25 01:03:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-25 01:03:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-25 01:03:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-25 01:03:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
ERROR - 2018-05-25 01:03:17 --> Severity: Notice --> Undefined index: seen_status E:\xampp\htdocs\consulting\application\modules\home\views\course.php 121
DEBUG - 2018-05-25 01:03:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-25 01:03:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-25 01:03:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-05-25 01:03:17 --> Final output sent to browser
DEBUG - 2018-05-25 01:03:17 --> Total execution time: 0.3960
INFO - 2018-05-25 01:03:18 --> Config Class Initialized
INFO - 2018-05-25 01:03:18 --> Config Class Initialized
INFO - 2018-05-25 01:03:18 --> Hooks Class Initialized
INFO - 2018-05-25 01:03:18 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:03:18 --> UTF-8 Support Enabled
DEBUG - 2018-05-25 01:03:18 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:03:18 --> Utf8 Class Initialized
INFO - 2018-05-25 01:03:18 --> Utf8 Class Initialized
INFO - 2018-05-25 01:03:18 --> URI Class Initialized
INFO - 2018-05-25 01:03:18 --> URI Class Initialized
INFO - 2018-05-25 01:03:18 --> Router Class Initialized
INFO - 2018-05-25 01:03:18 --> Router Class Initialized
INFO - 2018-05-25 01:03:18 --> Output Class Initialized
INFO - 2018-05-25 01:03:18 --> Output Class Initialized
INFO - 2018-05-25 01:03:18 --> Security Class Initialized
INFO - 2018-05-25 01:03:18 --> Security Class Initialized
DEBUG - 2018-05-25 01:03:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-25 01:03:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:03:18 --> Input Class Initialized
INFO - 2018-05-25 01:03:18 --> Input Class Initialized
INFO - 2018-05-25 01:03:18 --> Language Class Initialized
INFO - 2018-05-25 01:03:18 --> Language Class Initialized
ERROR - 2018-05-25 01:03:18 --> 404 Page Not Found: /index
ERROR - 2018-05-25 01:03:18 --> 404 Page Not Found: /index
INFO - 2018-05-25 01:03:18 --> Config Class Initialized
INFO - 2018-05-25 01:03:18 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:03:18 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:03:18 --> Utf8 Class Initialized
INFO - 2018-05-25 01:03:18 --> URI Class Initialized
INFO - 2018-05-25 01:03:18 --> Router Class Initialized
INFO - 2018-05-25 01:03:18 --> Output Class Initialized
INFO - 2018-05-25 01:03:18 --> Security Class Initialized
DEBUG - 2018-05-25 01:03:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:03:18 --> Input Class Initialized
INFO - 2018-05-25 01:03:18 --> Language Class Initialized
ERROR - 2018-05-25 01:03:18 --> 404 Page Not Found: /index
INFO - 2018-05-25 01:03:18 --> Config Class Initialized
INFO - 2018-05-25 01:03:18 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:03:18 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:03:18 --> Utf8 Class Initialized
INFO - 2018-05-25 01:03:18 --> URI Class Initialized
INFO - 2018-05-25 01:03:18 --> Router Class Initialized
INFO - 2018-05-25 01:03:18 --> Output Class Initialized
INFO - 2018-05-25 01:03:18 --> Security Class Initialized
DEBUG - 2018-05-25 01:03:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:03:18 --> Input Class Initialized
INFO - 2018-05-25 01:03:18 --> Language Class Initialized
ERROR - 2018-05-25 01:03:18 --> 404 Page Not Found: /index
INFO - 2018-05-25 01:03:20 --> Config Class Initialized
INFO - 2018-05-25 01:03:20 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:03:20 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:03:20 --> Utf8 Class Initialized
INFO - 2018-05-25 01:03:20 --> URI Class Initialized
INFO - 2018-05-25 01:03:20 --> Router Class Initialized
INFO - 2018-05-25 01:03:20 --> Output Class Initialized
INFO - 2018-05-25 01:03:20 --> Security Class Initialized
DEBUG - 2018-05-25 01:03:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:03:20 --> Input Class Initialized
INFO - 2018-05-25 01:03:20 --> Language Class Initialized
ERROR - 2018-05-25 01:03:20 --> 404 Page Not Found: /index
INFO - 2018-05-25 01:03:20 --> Config Class Initialized
INFO - 2018-05-25 01:03:20 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:03:20 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:03:20 --> Utf8 Class Initialized
INFO - 2018-05-25 01:03:20 --> URI Class Initialized
INFO - 2018-05-25 01:03:20 --> Router Class Initialized
INFO - 2018-05-25 01:03:20 --> Output Class Initialized
INFO - 2018-05-25 01:03:20 --> Security Class Initialized
DEBUG - 2018-05-25 01:03:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:03:20 --> Input Class Initialized
INFO - 2018-05-25 01:03:20 --> Language Class Initialized
ERROR - 2018-05-25 01:03:20 --> 404 Page Not Found: /index
INFO - 2018-05-25 01:03:20 --> Config Class Initialized
INFO - 2018-05-25 01:03:20 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:03:20 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:03:20 --> Utf8 Class Initialized
INFO - 2018-05-25 01:03:20 --> URI Class Initialized
INFO - 2018-05-25 01:03:20 --> Router Class Initialized
INFO - 2018-05-25 01:03:20 --> Output Class Initialized
INFO - 2018-05-25 01:03:20 --> Security Class Initialized
DEBUG - 2018-05-25 01:03:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:03:20 --> Input Class Initialized
INFO - 2018-05-25 01:03:20 --> Language Class Initialized
ERROR - 2018-05-25 01:03:20 --> 404 Page Not Found: /index
INFO - 2018-05-25 01:03:41 --> Config Class Initialized
INFO - 2018-05-25 01:03:41 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:03:41 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:03:41 --> Utf8 Class Initialized
INFO - 2018-05-25 01:03:41 --> URI Class Initialized
INFO - 2018-05-25 01:03:41 --> Router Class Initialized
INFO - 2018-05-25 01:03:41 --> Output Class Initialized
INFO - 2018-05-25 01:03:41 --> Security Class Initialized
DEBUG - 2018-05-25 01:03:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:03:42 --> Input Class Initialized
INFO - 2018-05-25 01:03:42 --> Language Class Initialized
INFO - 2018-05-25 01:03:42 --> Language Class Initialized
INFO - 2018-05-25 01:03:42 --> Config Class Initialized
INFO - 2018-05-25 01:03:42 --> Loader Class Initialized
DEBUG - 2018-05-25 01:03:42 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-25 01:03:42 --> Helper loaded: url_helper
INFO - 2018-05-25 01:03:42 --> Helper loaded: form_helper
INFO - 2018-05-25 01:03:42 --> Helper loaded: date_helper
INFO - 2018-05-25 01:03:42 --> Helper loaded: util_helper
INFO - 2018-05-25 01:03:42 --> Helper loaded: text_helper
INFO - 2018-05-25 01:03:42 --> Helper loaded: string_helper
INFO - 2018-05-25 01:03:42 --> Database Driver Class Initialized
DEBUG - 2018-05-25 01:03:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-25 01:03:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-25 01:03:42 --> Email Class Initialized
INFO - 2018-05-25 01:03:42 --> Controller Class Initialized
DEBUG - 2018-05-25 01:03:42 --> Home MX_Controller Initialized
DEBUG - 2018-05-25 01:03:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-25 01:03:42 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-25 01:03:42 --> Login MX_Controller Initialized
INFO - 2018-05-25 01:03:42 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-25 01:03:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-25 01:03:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-25 01:03:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-25 01:03:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-25 01:03:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
INFO - 2018-05-25 01:03:42 --> Config Class Initialized
INFO - 2018-05-25 01:03:42 --> Config Class Initialized
INFO - 2018-05-25 01:03:42 --> Hooks Class Initialized
INFO - 2018-05-25 01:03:42 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:03:42 --> UTF-8 Support Enabled
DEBUG - 2018-05-25 01:03:42 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:03:42 --> Utf8 Class Initialized
INFO - 2018-05-25 01:03:42 --> Utf8 Class Initialized
INFO - 2018-05-25 01:03:42 --> URI Class Initialized
INFO - 2018-05-25 01:03:42 --> URI Class Initialized
INFO - 2018-05-25 01:03:42 --> Router Class Initialized
INFO - 2018-05-25 01:03:42 --> Router Class Initialized
INFO - 2018-05-25 01:03:42 --> Output Class Initialized
INFO - 2018-05-25 01:03:42 --> Output Class Initialized
INFO - 2018-05-25 01:03:42 --> Security Class Initialized
INFO - 2018-05-25 01:03:42 --> Security Class Initialized
DEBUG - 2018-05-25 01:03:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-25 01:03:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:03:42 --> Input Class Initialized
INFO - 2018-05-25 01:03:42 --> Input Class Initialized
INFO - 2018-05-25 01:03:42 --> Language Class Initialized
INFO - 2018-05-25 01:03:42 --> Language Class Initialized
ERROR - 2018-05-25 01:03:42 --> 404 Page Not Found: /index
ERROR - 2018-05-25 01:03:42 --> 404 Page Not Found: /index
INFO - 2018-05-25 01:03:42 --> Config Class Initialized
INFO - 2018-05-25 01:03:42 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:03:42 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:03:42 --> Utf8 Class Initialized
INFO - 2018-05-25 01:03:42 --> URI Class Initialized
INFO - 2018-05-25 01:03:42 --> Router Class Initialized
INFO - 2018-05-25 01:03:42 --> Output Class Initialized
INFO - 2018-05-25 01:03:42 --> Security Class Initialized
DEBUG - 2018-05-25 01:03:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:03:42 --> Input Class Initialized
INFO - 2018-05-25 01:03:42 --> Language Class Initialized
ERROR - 2018-05-25 01:03:42 --> 404 Page Not Found: /index
INFO - 2018-05-25 01:03:43 --> Config Class Initialized
INFO - 2018-05-25 01:03:43 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:03:43 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:03:43 --> Utf8 Class Initialized
INFO - 2018-05-25 01:03:43 --> URI Class Initialized
INFO - 2018-05-25 01:03:43 --> Router Class Initialized
INFO - 2018-05-25 01:03:43 --> Output Class Initialized
INFO - 2018-05-25 01:03:43 --> Security Class Initialized
DEBUG - 2018-05-25 01:03:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:03:43 --> Input Class Initialized
INFO - 2018-05-25 01:03:43 --> Language Class Initialized
ERROR - 2018-05-25 01:03:43 --> 404 Page Not Found: /index
INFO - 2018-05-25 01:03:43 --> Config Class Initialized
INFO - 2018-05-25 01:03:43 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:03:43 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:03:43 --> Utf8 Class Initialized
INFO - 2018-05-25 01:03:43 --> URI Class Initialized
INFO - 2018-05-25 01:03:43 --> Router Class Initialized
INFO - 2018-05-25 01:03:43 --> Output Class Initialized
INFO - 2018-05-25 01:03:43 --> Security Class Initialized
DEBUG - 2018-05-25 01:03:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:03:43 --> Input Class Initialized
INFO - 2018-05-25 01:03:43 --> Language Class Initialized
ERROR - 2018-05-25 01:03:43 --> 404 Page Not Found: /index
INFO - 2018-05-25 01:03:43 --> Config Class Initialized
INFO - 2018-05-25 01:03:43 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:03:43 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:03:43 --> Utf8 Class Initialized
INFO - 2018-05-25 01:03:43 --> URI Class Initialized
INFO - 2018-05-25 01:03:43 --> Router Class Initialized
INFO - 2018-05-25 01:03:43 --> Output Class Initialized
INFO - 2018-05-25 01:03:43 --> Security Class Initialized
DEBUG - 2018-05-25 01:03:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:03:43 --> Input Class Initialized
INFO - 2018-05-25 01:03:43 --> Language Class Initialized
ERROR - 2018-05-25 01:03:43 --> 404 Page Not Found: /index
INFO - 2018-05-25 01:03:43 --> Config Class Initialized
INFO - 2018-05-25 01:03:43 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:03:43 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:03:43 --> Utf8 Class Initialized
INFO - 2018-05-25 01:03:43 --> URI Class Initialized
INFO - 2018-05-25 01:03:43 --> Router Class Initialized
INFO - 2018-05-25 01:03:43 --> Output Class Initialized
INFO - 2018-05-25 01:03:43 --> Security Class Initialized
DEBUG - 2018-05-25 01:03:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:03:43 --> Input Class Initialized
INFO - 2018-05-25 01:03:43 --> Language Class Initialized
ERROR - 2018-05-25 01:03:43 --> 404 Page Not Found: /index
INFO - 2018-05-25 01:04:12 --> Config Class Initialized
INFO - 2018-05-25 01:04:12 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:04:12 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:04:12 --> Utf8 Class Initialized
INFO - 2018-05-25 01:04:12 --> URI Class Initialized
INFO - 2018-05-25 01:04:12 --> Router Class Initialized
INFO - 2018-05-25 01:04:12 --> Output Class Initialized
INFO - 2018-05-25 01:04:12 --> Security Class Initialized
DEBUG - 2018-05-25 01:04:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:04:12 --> Input Class Initialized
INFO - 2018-05-25 01:04:12 --> Language Class Initialized
INFO - 2018-05-25 01:04:12 --> Language Class Initialized
INFO - 2018-05-25 01:04:12 --> Config Class Initialized
INFO - 2018-05-25 01:04:12 --> Loader Class Initialized
DEBUG - 2018-05-25 01:04:12 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-25 01:04:12 --> Helper loaded: url_helper
INFO - 2018-05-25 01:04:12 --> Helper loaded: form_helper
INFO - 2018-05-25 01:04:12 --> Helper loaded: date_helper
INFO - 2018-05-25 01:04:12 --> Helper loaded: util_helper
INFO - 2018-05-25 01:04:12 --> Helper loaded: text_helper
INFO - 2018-05-25 01:04:12 --> Helper loaded: string_helper
INFO - 2018-05-25 01:04:12 --> Database Driver Class Initialized
DEBUG - 2018-05-25 01:04:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-25 01:04:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-25 01:04:12 --> Email Class Initialized
INFO - 2018-05-25 01:04:12 --> Controller Class Initialized
DEBUG - 2018-05-25 01:04:12 --> Home MX_Controller Initialized
DEBUG - 2018-05-25 01:04:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-25 01:04:12 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-25 01:04:12 --> Login MX_Controller Initialized
INFO - 2018-05-25 01:04:12 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-25 01:04:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-25 01:04:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-25 01:04:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-25 01:04:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-25 01:04:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
INFO - 2018-05-25 01:04:13 --> Config Class Initialized
INFO - 2018-05-25 01:04:13 --> Config Class Initialized
INFO - 2018-05-25 01:04:13 --> Hooks Class Initialized
INFO - 2018-05-25 01:04:13 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:04:13 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:04:13 --> Utf8 Class Initialized
INFO - 2018-05-25 01:04:13 --> URI Class Initialized
INFO - 2018-05-25 01:04:13 --> Router Class Initialized
INFO - 2018-05-25 01:04:13 --> Output Class Initialized
DEBUG - 2018-05-25 01:04:13 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:04:13 --> Security Class Initialized
INFO - 2018-05-25 01:04:13 --> Utf8 Class Initialized
INFO - 2018-05-25 01:04:13 --> URI Class Initialized
INFO - 2018-05-25 01:04:13 --> Router Class Initialized
DEBUG - 2018-05-25 01:04:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:04:13 --> Output Class Initialized
INFO - 2018-05-25 01:04:13 --> Security Class Initialized
DEBUG - 2018-05-25 01:04:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:04:13 --> Input Class Initialized
INFO - 2018-05-25 01:04:13 --> Input Class Initialized
INFO - 2018-05-25 01:04:13 --> Language Class Initialized
INFO - 2018-05-25 01:04:13 --> Language Class Initialized
ERROR - 2018-05-25 01:04:13 --> 404 Page Not Found: /index
ERROR - 2018-05-25 01:04:13 --> 404 Page Not Found: /index
INFO - 2018-05-25 01:04:13 --> Config Class Initialized
INFO - 2018-05-25 01:04:13 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:04:13 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:04:13 --> Utf8 Class Initialized
INFO - 2018-05-25 01:04:13 --> URI Class Initialized
INFO - 2018-05-25 01:04:13 --> Router Class Initialized
INFO - 2018-05-25 01:04:13 --> Output Class Initialized
INFO - 2018-05-25 01:04:13 --> Security Class Initialized
DEBUG - 2018-05-25 01:04:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:04:13 --> Input Class Initialized
INFO - 2018-05-25 01:04:13 --> Language Class Initialized
ERROR - 2018-05-25 01:04:13 --> 404 Page Not Found: /index
INFO - 2018-05-25 01:04:13 --> Config Class Initialized
INFO - 2018-05-25 01:04:13 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:04:13 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:04:13 --> Utf8 Class Initialized
INFO - 2018-05-25 01:04:13 --> URI Class Initialized
INFO - 2018-05-25 01:04:13 --> Router Class Initialized
INFO - 2018-05-25 01:04:13 --> Output Class Initialized
INFO - 2018-05-25 01:04:13 --> Security Class Initialized
DEBUG - 2018-05-25 01:04:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:04:13 --> Input Class Initialized
INFO - 2018-05-25 01:04:13 --> Language Class Initialized
ERROR - 2018-05-25 01:04:13 --> 404 Page Not Found: /index
INFO - 2018-05-25 01:04:13 --> Config Class Initialized
INFO - 2018-05-25 01:04:13 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:04:13 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:04:13 --> Utf8 Class Initialized
INFO - 2018-05-25 01:04:13 --> URI Class Initialized
INFO - 2018-05-25 01:04:13 --> Router Class Initialized
INFO - 2018-05-25 01:04:13 --> Output Class Initialized
INFO - 2018-05-25 01:04:13 --> Security Class Initialized
DEBUG - 2018-05-25 01:04:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:04:13 --> Input Class Initialized
INFO - 2018-05-25 01:04:13 --> Language Class Initialized
ERROR - 2018-05-25 01:04:13 --> 404 Page Not Found: /index
INFO - 2018-05-25 01:04:13 --> Config Class Initialized
INFO - 2018-05-25 01:04:13 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:04:13 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:04:13 --> Utf8 Class Initialized
INFO - 2018-05-25 01:04:13 --> URI Class Initialized
INFO - 2018-05-25 01:04:13 --> Router Class Initialized
INFO - 2018-05-25 01:04:13 --> Output Class Initialized
INFO - 2018-05-25 01:04:13 --> Security Class Initialized
DEBUG - 2018-05-25 01:04:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:04:13 --> Input Class Initialized
INFO - 2018-05-25 01:04:13 --> Language Class Initialized
ERROR - 2018-05-25 01:04:13 --> 404 Page Not Found: /index
INFO - 2018-05-25 01:04:14 --> Config Class Initialized
INFO - 2018-05-25 01:04:14 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:04:14 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:04:14 --> Utf8 Class Initialized
INFO - 2018-05-25 01:04:14 --> URI Class Initialized
INFO - 2018-05-25 01:04:14 --> Router Class Initialized
INFO - 2018-05-25 01:04:14 --> Output Class Initialized
INFO - 2018-05-25 01:04:14 --> Security Class Initialized
DEBUG - 2018-05-25 01:04:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:04:14 --> Input Class Initialized
INFO - 2018-05-25 01:04:14 --> Language Class Initialized
ERROR - 2018-05-25 01:04:14 --> 404 Page Not Found: /index
INFO - 2018-05-25 01:04:24 --> Config Class Initialized
INFO - 2018-05-25 01:04:24 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:04:24 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:04:24 --> Utf8 Class Initialized
INFO - 2018-05-25 01:04:24 --> URI Class Initialized
INFO - 2018-05-25 01:04:24 --> Router Class Initialized
INFO - 2018-05-25 01:04:24 --> Output Class Initialized
INFO - 2018-05-25 01:04:24 --> Security Class Initialized
DEBUG - 2018-05-25 01:04:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:04:24 --> Input Class Initialized
INFO - 2018-05-25 01:04:24 --> Language Class Initialized
INFO - 2018-05-25 01:04:24 --> Language Class Initialized
INFO - 2018-05-25 01:04:24 --> Config Class Initialized
INFO - 2018-05-25 01:04:24 --> Loader Class Initialized
DEBUG - 2018-05-25 01:04:24 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-25 01:04:24 --> Helper loaded: url_helper
INFO - 2018-05-25 01:04:24 --> Helper loaded: form_helper
INFO - 2018-05-25 01:04:24 --> Helper loaded: date_helper
INFO - 2018-05-25 01:04:24 --> Helper loaded: util_helper
INFO - 2018-05-25 01:04:24 --> Helper loaded: text_helper
INFO - 2018-05-25 01:04:24 --> Helper loaded: string_helper
INFO - 2018-05-25 01:04:24 --> Database Driver Class Initialized
DEBUG - 2018-05-25 01:04:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-25 01:04:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-25 01:04:24 --> Email Class Initialized
INFO - 2018-05-25 01:04:24 --> Controller Class Initialized
DEBUG - 2018-05-25 01:04:24 --> Home MX_Controller Initialized
DEBUG - 2018-05-25 01:04:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-25 01:04:24 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-25 01:04:24 --> Login MX_Controller Initialized
INFO - 2018-05-25 01:04:24 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-25 01:04:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-25 01:04:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-25 01:04:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-25 01:04:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-25 01:04:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-25 01:04:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-25 01:04:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-25 01:04:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-05-25 01:04:24 --> Final output sent to browser
DEBUG - 2018-05-25 01:04:24 --> Total execution time: 0.3927
INFO - 2018-05-25 01:04:24 --> Config Class Initialized
INFO - 2018-05-25 01:04:25 --> Config Class Initialized
INFO - 2018-05-25 01:04:25 --> Hooks Class Initialized
INFO - 2018-05-25 01:04:25 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:04:25 --> UTF-8 Support Enabled
DEBUG - 2018-05-25 01:04:25 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:04:25 --> Utf8 Class Initialized
INFO - 2018-05-25 01:04:25 --> URI Class Initialized
INFO - 2018-05-25 01:04:25 --> Router Class Initialized
INFO - 2018-05-25 01:04:25 --> Utf8 Class Initialized
INFO - 2018-05-25 01:04:25 --> Output Class Initialized
INFO - 2018-05-25 01:04:25 --> URI Class Initialized
INFO - 2018-05-25 01:04:25 --> Security Class Initialized
INFO - 2018-05-25 01:04:25 --> Router Class Initialized
INFO - 2018-05-25 01:04:25 --> Output Class Initialized
DEBUG - 2018-05-25 01:04:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:04:25 --> Security Class Initialized
INFO - 2018-05-25 01:04:25 --> Input Class Initialized
DEBUG - 2018-05-25 01:04:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:04:25 --> Language Class Initialized
INFO - 2018-05-25 01:04:25 --> Input Class Initialized
INFO - 2018-05-25 01:04:25 --> Language Class Initialized
ERROR - 2018-05-25 01:04:25 --> 404 Page Not Found: /index
ERROR - 2018-05-25 01:04:25 --> 404 Page Not Found: /index
INFO - 2018-05-25 01:04:25 --> Config Class Initialized
INFO - 2018-05-25 01:04:25 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:04:25 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:04:25 --> Utf8 Class Initialized
INFO - 2018-05-25 01:04:25 --> URI Class Initialized
INFO - 2018-05-25 01:04:25 --> Router Class Initialized
INFO - 2018-05-25 01:04:25 --> Output Class Initialized
INFO - 2018-05-25 01:04:25 --> Security Class Initialized
DEBUG - 2018-05-25 01:04:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:04:25 --> Input Class Initialized
INFO - 2018-05-25 01:04:25 --> Language Class Initialized
ERROR - 2018-05-25 01:04:25 --> 404 Page Not Found: /index
INFO - 2018-05-25 01:04:25 --> Config Class Initialized
INFO - 2018-05-25 01:04:25 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:04:25 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:04:25 --> Utf8 Class Initialized
INFO - 2018-05-25 01:04:25 --> URI Class Initialized
INFO - 2018-05-25 01:04:25 --> Router Class Initialized
INFO - 2018-05-25 01:04:25 --> Output Class Initialized
INFO - 2018-05-25 01:04:25 --> Security Class Initialized
DEBUG - 2018-05-25 01:04:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:04:25 --> Input Class Initialized
INFO - 2018-05-25 01:04:25 --> Language Class Initialized
ERROR - 2018-05-25 01:04:25 --> 404 Page Not Found: /index
INFO - 2018-05-25 01:04:26 --> Config Class Initialized
INFO - 2018-05-25 01:04:26 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:04:26 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:04:26 --> Utf8 Class Initialized
INFO - 2018-05-25 01:04:26 --> URI Class Initialized
INFO - 2018-05-25 01:04:26 --> Router Class Initialized
INFO - 2018-05-25 01:04:26 --> Output Class Initialized
INFO - 2018-05-25 01:04:26 --> Security Class Initialized
DEBUG - 2018-05-25 01:04:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:04:26 --> Input Class Initialized
INFO - 2018-05-25 01:04:26 --> Language Class Initialized
ERROR - 2018-05-25 01:04:26 --> 404 Page Not Found: /index
INFO - 2018-05-25 01:04:26 --> Config Class Initialized
INFO - 2018-05-25 01:04:26 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:04:27 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:04:27 --> Utf8 Class Initialized
INFO - 2018-05-25 01:04:27 --> URI Class Initialized
INFO - 2018-05-25 01:04:27 --> Router Class Initialized
INFO - 2018-05-25 01:04:27 --> Output Class Initialized
INFO - 2018-05-25 01:04:27 --> Security Class Initialized
DEBUG - 2018-05-25 01:04:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:04:27 --> Input Class Initialized
INFO - 2018-05-25 01:04:27 --> Language Class Initialized
ERROR - 2018-05-25 01:04:27 --> 404 Page Not Found: /index
INFO - 2018-05-25 01:04:27 --> Config Class Initialized
INFO - 2018-05-25 01:04:27 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:04:27 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:04:27 --> Utf8 Class Initialized
INFO - 2018-05-25 01:04:27 --> URI Class Initialized
INFO - 2018-05-25 01:04:27 --> Router Class Initialized
INFO - 2018-05-25 01:04:27 --> Output Class Initialized
INFO - 2018-05-25 01:04:27 --> Security Class Initialized
DEBUG - 2018-05-25 01:04:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:04:27 --> Input Class Initialized
INFO - 2018-05-25 01:04:27 --> Language Class Initialized
ERROR - 2018-05-25 01:04:27 --> 404 Page Not Found: /index
INFO - 2018-05-25 01:05:30 --> Config Class Initialized
INFO - 2018-05-25 01:05:30 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:05:30 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:05:30 --> Utf8 Class Initialized
INFO - 2018-05-25 01:05:30 --> URI Class Initialized
INFO - 2018-05-25 01:05:30 --> Router Class Initialized
INFO - 2018-05-25 01:05:30 --> Output Class Initialized
INFO - 2018-05-25 01:05:30 --> Security Class Initialized
DEBUG - 2018-05-25 01:05:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:05:31 --> Input Class Initialized
INFO - 2018-05-25 01:05:31 --> Language Class Initialized
INFO - 2018-05-25 01:05:31 --> Language Class Initialized
INFO - 2018-05-25 01:05:31 --> Config Class Initialized
INFO - 2018-05-25 01:05:31 --> Loader Class Initialized
DEBUG - 2018-05-25 01:05:31 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-25 01:05:31 --> Helper loaded: url_helper
INFO - 2018-05-25 01:05:31 --> Helper loaded: form_helper
INFO - 2018-05-25 01:05:31 --> Helper loaded: date_helper
INFO - 2018-05-25 01:05:31 --> Helper loaded: util_helper
INFO - 2018-05-25 01:05:31 --> Helper loaded: text_helper
INFO - 2018-05-25 01:05:31 --> Helper loaded: string_helper
INFO - 2018-05-25 01:05:31 --> Database Driver Class Initialized
DEBUG - 2018-05-25 01:05:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-25 01:05:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-25 01:05:31 --> Email Class Initialized
INFO - 2018-05-25 01:05:31 --> Controller Class Initialized
DEBUG - 2018-05-25 01:05:31 --> Home MX_Controller Initialized
DEBUG - 2018-05-25 01:05:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-25 01:05:31 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-25 01:05:31 --> Login MX_Controller Initialized
INFO - 2018-05-25 01:05:31 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-25 01:05:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-25 01:05:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-25 01:05:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-25 01:05:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-25 01:05:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
INFO - 2018-05-25 01:06:18 --> Config Class Initialized
INFO - 2018-05-25 01:06:18 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:06:18 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:06:18 --> Utf8 Class Initialized
INFO - 2018-05-25 01:06:18 --> URI Class Initialized
INFO - 2018-05-25 01:06:18 --> Router Class Initialized
INFO - 2018-05-25 01:06:18 --> Output Class Initialized
INFO - 2018-05-25 01:06:18 --> Security Class Initialized
DEBUG - 2018-05-25 01:06:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:06:18 --> Input Class Initialized
INFO - 2018-05-25 01:06:18 --> Language Class Initialized
INFO - 2018-05-25 01:06:18 --> Language Class Initialized
INFO - 2018-05-25 01:06:18 --> Config Class Initialized
INFO - 2018-05-25 01:06:18 --> Loader Class Initialized
DEBUG - 2018-05-25 01:06:19 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-25 01:06:19 --> Helper loaded: url_helper
INFO - 2018-05-25 01:06:19 --> Helper loaded: form_helper
INFO - 2018-05-25 01:06:19 --> Helper loaded: date_helper
INFO - 2018-05-25 01:06:19 --> Helper loaded: util_helper
INFO - 2018-05-25 01:06:19 --> Helper loaded: text_helper
INFO - 2018-05-25 01:06:19 --> Helper loaded: string_helper
INFO - 2018-05-25 01:06:19 --> Database Driver Class Initialized
DEBUG - 2018-05-25 01:06:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-25 01:06:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-25 01:06:19 --> Email Class Initialized
INFO - 2018-05-25 01:06:19 --> Controller Class Initialized
DEBUG - 2018-05-25 01:06:19 --> Home MX_Controller Initialized
DEBUG - 2018-05-25 01:06:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-25 01:06:19 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-25 01:06:19 --> Login MX_Controller Initialized
INFO - 2018-05-25 01:06:19 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-25 01:06:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-25 01:06:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-25 01:06:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-25 01:06:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-25 01:06:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
INFO - 2018-05-25 01:06:19 --> Config Class Initialized
INFO - 2018-05-25 01:06:19 --> Config Class Initialized
INFO - 2018-05-25 01:06:19 --> Hooks Class Initialized
INFO - 2018-05-25 01:06:19 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:06:19 --> UTF-8 Support Enabled
DEBUG - 2018-05-25 01:06:19 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:06:19 --> Utf8 Class Initialized
INFO - 2018-05-25 01:06:19 --> Utf8 Class Initialized
INFO - 2018-05-25 01:06:19 --> URI Class Initialized
INFO - 2018-05-25 01:06:19 --> URI Class Initialized
INFO - 2018-05-25 01:06:19 --> Router Class Initialized
INFO - 2018-05-25 01:06:19 --> Router Class Initialized
INFO - 2018-05-25 01:06:19 --> Output Class Initialized
INFO - 2018-05-25 01:06:19 --> Output Class Initialized
INFO - 2018-05-25 01:06:19 --> Security Class Initialized
INFO - 2018-05-25 01:06:19 --> Security Class Initialized
DEBUG - 2018-05-25 01:06:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:06:19 --> Input Class Initialized
INFO - 2018-05-25 01:06:19 --> Language Class Initialized
DEBUG - 2018-05-25 01:06:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-05-25 01:06:19 --> 404 Page Not Found: /index
INFO - 2018-05-25 01:06:19 --> Input Class Initialized
INFO - 2018-05-25 01:06:19 --> Config Class Initialized
INFO - 2018-05-25 01:06:19 --> Hooks Class Initialized
INFO - 2018-05-25 01:06:19 --> Language Class Initialized
ERROR - 2018-05-25 01:06:20 --> 404 Page Not Found: /index
DEBUG - 2018-05-25 01:06:20 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:06:20 --> Utf8 Class Initialized
INFO - 2018-05-25 01:06:20 --> URI Class Initialized
INFO - 2018-05-25 01:06:20 --> Router Class Initialized
INFO - 2018-05-25 01:06:20 --> Output Class Initialized
INFO - 2018-05-25 01:06:20 --> Security Class Initialized
DEBUG - 2018-05-25 01:06:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:06:20 --> Input Class Initialized
INFO - 2018-05-25 01:06:20 --> Language Class Initialized
ERROR - 2018-05-25 01:06:20 --> 404 Page Not Found: /index
INFO - 2018-05-25 01:06:20 --> Config Class Initialized
INFO - 2018-05-25 01:06:20 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:06:20 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:06:20 --> Utf8 Class Initialized
INFO - 2018-05-25 01:06:20 --> URI Class Initialized
INFO - 2018-05-25 01:06:20 --> Router Class Initialized
INFO - 2018-05-25 01:06:20 --> Output Class Initialized
INFO - 2018-05-25 01:06:20 --> Security Class Initialized
DEBUG - 2018-05-25 01:06:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:06:20 --> Input Class Initialized
INFO - 2018-05-25 01:06:20 --> Language Class Initialized
ERROR - 2018-05-25 01:06:20 --> 404 Page Not Found: /index
INFO - 2018-05-25 01:06:37 --> Config Class Initialized
INFO - 2018-05-25 01:06:37 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:06:37 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:06:37 --> Utf8 Class Initialized
INFO - 2018-05-25 01:06:37 --> URI Class Initialized
INFO - 2018-05-25 01:06:37 --> Router Class Initialized
INFO - 2018-05-25 01:06:37 --> Output Class Initialized
INFO - 2018-05-25 01:06:37 --> Security Class Initialized
DEBUG - 2018-05-25 01:06:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:06:37 --> Input Class Initialized
INFO - 2018-05-25 01:06:37 --> Language Class Initialized
INFO - 2018-05-25 01:06:37 --> Language Class Initialized
INFO - 2018-05-25 01:06:37 --> Config Class Initialized
INFO - 2018-05-25 01:06:37 --> Loader Class Initialized
DEBUG - 2018-05-25 01:06:37 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-25 01:06:37 --> Helper loaded: url_helper
INFO - 2018-05-25 01:06:37 --> Helper loaded: form_helper
INFO - 2018-05-25 01:06:37 --> Helper loaded: date_helper
INFO - 2018-05-25 01:06:37 --> Helper loaded: util_helper
INFO - 2018-05-25 01:06:37 --> Helper loaded: text_helper
INFO - 2018-05-25 01:06:37 --> Helper loaded: string_helper
INFO - 2018-05-25 01:06:37 --> Database Driver Class Initialized
DEBUG - 2018-05-25 01:06:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-25 01:06:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-25 01:06:37 --> Email Class Initialized
INFO - 2018-05-25 01:06:37 --> Controller Class Initialized
DEBUG - 2018-05-25 01:06:37 --> Home MX_Controller Initialized
DEBUG - 2018-05-25 01:06:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-25 01:06:37 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-25 01:06:37 --> Login MX_Controller Initialized
INFO - 2018-05-25 01:06:37 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-25 01:06:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-25 01:06:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-25 01:06:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-25 01:06:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-25 01:06:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-25 01:06:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-25 01:06:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-25 01:06:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-05-25 01:06:37 --> Final output sent to browser
DEBUG - 2018-05-25 01:06:37 --> Total execution time: 0.4582
INFO - 2018-05-25 01:06:38 --> Config Class Initialized
INFO - 2018-05-25 01:06:38 --> Config Class Initialized
INFO - 2018-05-25 01:06:38 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:06:38 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:06:38 --> Utf8 Class Initialized
INFO - 2018-05-25 01:06:38 --> URI Class Initialized
INFO - 2018-05-25 01:06:38 --> Router Class Initialized
INFO - 2018-05-25 01:06:38 --> Output Class Initialized
INFO - 2018-05-25 01:06:38 --> Security Class Initialized
DEBUG - 2018-05-25 01:06:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:06:38 --> Input Class Initialized
INFO - 2018-05-25 01:06:38 --> Hooks Class Initialized
INFO - 2018-05-25 01:06:38 --> Language Class Initialized
DEBUG - 2018-05-25 01:06:38 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:06:38 --> Utf8 Class Initialized
INFO - 2018-05-25 01:06:38 --> URI Class Initialized
INFO - 2018-05-25 01:06:38 --> Router Class Initialized
INFO - 2018-05-25 01:06:38 --> Output Class Initialized
ERROR - 2018-05-25 01:06:38 --> 404 Page Not Found: /index
INFO - 2018-05-25 01:06:38 --> Security Class Initialized
DEBUG - 2018-05-25 01:06:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:06:38 --> Input Class Initialized
INFO - 2018-05-25 01:06:38 --> Language Class Initialized
ERROR - 2018-05-25 01:06:38 --> 404 Page Not Found: /index
INFO - 2018-05-25 01:06:38 --> Config Class Initialized
INFO - 2018-05-25 01:06:39 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:06:39 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:06:39 --> Utf8 Class Initialized
INFO - 2018-05-25 01:06:39 --> URI Class Initialized
INFO - 2018-05-25 01:06:39 --> Router Class Initialized
INFO - 2018-05-25 01:06:39 --> Output Class Initialized
INFO - 2018-05-25 01:06:39 --> Security Class Initialized
DEBUG - 2018-05-25 01:06:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:06:39 --> Input Class Initialized
INFO - 2018-05-25 01:06:39 --> Language Class Initialized
ERROR - 2018-05-25 01:06:39 --> 404 Page Not Found: /index
INFO - 2018-05-25 01:06:39 --> Config Class Initialized
INFO - 2018-05-25 01:06:39 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:06:39 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:06:39 --> Utf8 Class Initialized
INFO - 2018-05-25 01:06:39 --> URI Class Initialized
INFO - 2018-05-25 01:06:39 --> Router Class Initialized
INFO - 2018-05-25 01:06:39 --> Output Class Initialized
INFO - 2018-05-25 01:06:39 --> Security Class Initialized
DEBUG - 2018-05-25 01:06:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:06:39 --> Input Class Initialized
INFO - 2018-05-25 01:06:39 --> Language Class Initialized
ERROR - 2018-05-25 01:06:39 --> 404 Page Not Found: /index
INFO - 2018-05-25 01:07:29 --> Config Class Initialized
INFO - 2018-05-25 01:07:29 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:07:29 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:07:29 --> Utf8 Class Initialized
INFO - 2018-05-25 01:07:29 --> URI Class Initialized
INFO - 2018-05-25 01:07:29 --> Router Class Initialized
INFO - 2018-05-25 01:07:29 --> Output Class Initialized
INFO - 2018-05-25 01:07:29 --> Security Class Initialized
DEBUG - 2018-05-25 01:07:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:07:29 --> Input Class Initialized
INFO - 2018-05-25 01:07:29 --> Language Class Initialized
INFO - 2018-05-25 01:07:29 --> Language Class Initialized
INFO - 2018-05-25 01:07:29 --> Config Class Initialized
INFO - 2018-05-25 01:07:29 --> Loader Class Initialized
DEBUG - 2018-05-25 01:07:29 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-25 01:07:29 --> Helper loaded: url_helper
INFO - 2018-05-25 01:07:29 --> Helper loaded: form_helper
INFO - 2018-05-25 01:07:29 --> Helper loaded: date_helper
INFO - 2018-05-25 01:07:29 --> Helper loaded: util_helper
INFO - 2018-05-25 01:07:29 --> Helper loaded: text_helper
INFO - 2018-05-25 01:07:29 --> Helper loaded: string_helper
INFO - 2018-05-25 01:07:29 --> Database Driver Class Initialized
DEBUG - 2018-05-25 01:07:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-25 01:07:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-25 01:07:29 --> Email Class Initialized
INFO - 2018-05-25 01:07:29 --> Controller Class Initialized
DEBUG - 2018-05-25 01:07:29 --> Home MX_Controller Initialized
DEBUG - 2018-05-25 01:07:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-25 01:07:29 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-25 01:07:29 --> Login MX_Controller Initialized
INFO - 2018-05-25 01:07:29 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-25 01:07:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-25 01:07:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-25 01:07:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-25 01:07:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-25 01:07:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-25 01:07:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-25 01:07:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-25 01:07:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-05-25 01:07:29 --> Final output sent to browser
DEBUG - 2018-05-25 01:07:30 --> Total execution time: 0.4287
INFO - 2018-05-25 01:07:30 --> Config Class Initialized
INFO - 2018-05-25 01:07:30 --> Hooks Class Initialized
INFO - 2018-05-25 01:07:30 --> Config Class Initialized
INFO - 2018-05-25 01:07:30 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:07:30 --> UTF-8 Support Enabled
DEBUG - 2018-05-25 01:07:30 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:07:30 --> Utf8 Class Initialized
INFO - 2018-05-25 01:07:30 --> URI Class Initialized
INFO - 2018-05-25 01:07:30 --> Router Class Initialized
INFO - 2018-05-25 01:07:30 --> Output Class Initialized
INFO - 2018-05-25 01:07:30 --> Security Class Initialized
DEBUG - 2018-05-25 01:07:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:07:30 --> Input Class Initialized
INFO - 2018-05-25 01:07:30 --> Language Class Initialized
INFO - 2018-05-25 01:07:30 --> Utf8 Class Initialized
ERROR - 2018-05-25 01:07:30 --> 404 Page Not Found: /index
INFO - 2018-05-25 01:07:30 --> URI Class Initialized
INFO - 2018-05-25 01:07:30 --> Router Class Initialized
INFO - 2018-05-25 01:07:30 --> Output Class Initialized
INFO - 2018-05-25 01:07:30 --> Security Class Initialized
DEBUG - 2018-05-25 01:07:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:07:30 --> Config Class Initialized
INFO - 2018-05-25 01:07:30 --> Hooks Class Initialized
INFO - 2018-05-25 01:07:30 --> Input Class Initialized
INFO - 2018-05-25 01:07:31 --> Language Class Initialized
DEBUG - 2018-05-25 01:07:31 --> UTF-8 Support Enabled
ERROR - 2018-05-25 01:07:31 --> 404 Page Not Found: /index
INFO - 2018-05-25 01:07:31 --> Utf8 Class Initialized
INFO - 2018-05-25 01:07:31 --> URI Class Initialized
INFO - 2018-05-25 01:07:31 --> Router Class Initialized
INFO - 2018-05-25 01:07:31 --> Output Class Initialized
INFO - 2018-05-25 01:07:31 --> Security Class Initialized
DEBUG - 2018-05-25 01:07:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:07:31 --> Input Class Initialized
INFO - 2018-05-25 01:07:31 --> Language Class Initialized
ERROR - 2018-05-25 01:07:31 --> 404 Page Not Found: /index
INFO - 2018-05-25 01:07:31 --> Config Class Initialized
INFO - 2018-05-25 01:07:31 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:07:31 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:07:31 --> Utf8 Class Initialized
INFO - 2018-05-25 01:07:31 --> URI Class Initialized
INFO - 2018-05-25 01:07:31 --> Router Class Initialized
INFO - 2018-05-25 01:07:31 --> Output Class Initialized
INFO - 2018-05-25 01:07:31 --> Security Class Initialized
DEBUG - 2018-05-25 01:07:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:07:31 --> Input Class Initialized
INFO - 2018-05-25 01:07:31 --> Language Class Initialized
ERROR - 2018-05-25 01:07:31 --> 404 Page Not Found: /index
INFO - 2018-05-25 01:07:40 --> Config Class Initialized
INFO - 2018-05-25 01:07:40 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:07:40 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:07:40 --> Utf8 Class Initialized
INFO - 2018-05-25 01:07:40 --> URI Class Initialized
INFO - 2018-05-25 01:07:40 --> Router Class Initialized
INFO - 2018-05-25 01:07:40 --> Output Class Initialized
INFO - 2018-05-25 01:07:40 --> Security Class Initialized
DEBUG - 2018-05-25 01:07:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:07:40 --> Input Class Initialized
INFO - 2018-05-25 01:07:40 --> Language Class Initialized
INFO - 2018-05-25 01:07:40 --> Language Class Initialized
INFO - 2018-05-25 01:07:40 --> Config Class Initialized
INFO - 2018-05-25 01:07:40 --> Loader Class Initialized
DEBUG - 2018-05-25 01:07:40 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-25 01:07:40 --> Helper loaded: url_helper
INFO - 2018-05-25 01:07:40 --> Helper loaded: form_helper
INFO - 2018-05-25 01:07:40 --> Helper loaded: date_helper
INFO - 2018-05-25 01:07:40 --> Helper loaded: util_helper
INFO - 2018-05-25 01:07:40 --> Helper loaded: text_helper
INFO - 2018-05-25 01:07:40 --> Helper loaded: string_helper
INFO - 2018-05-25 01:07:40 --> Database Driver Class Initialized
DEBUG - 2018-05-25 01:07:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-25 01:07:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-25 01:07:40 --> Email Class Initialized
INFO - 2018-05-25 01:07:40 --> Controller Class Initialized
DEBUG - 2018-05-25 01:07:40 --> Home MX_Controller Initialized
DEBUG - 2018-05-25 01:07:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-25 01:07:40 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-25 01:07:40 --> Login MX_Controller Initialized
INFO - 2018-05-25 01:07:40 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-25 01:07:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-25 01:07:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-25 01:07:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-25 01:07:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-25 01:07:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-25 01:07:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-25 01:07:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-25 01:07:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-05-25 01:07:40 --> Final output sent to browser
DEBUG - 2018-05-25 01:07:40 --> Total execution time: 0.4141
INFO - 2018-05-25 01:07:41 --> Config Class Initialized
INFO - 2018-05-25 01:07:41 --> Hooks Class Initialized
INFO - 2018-05-25 01:07:41 --> Config Class Initialized
INFO - 2018-05-25 01:07:41 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:07:41 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:07:41 --> Utf8 Class Initialized
DEBUG - 2018-05-25 01:07:41 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:07:41 --> Utf8 Class Initialized
INFO - 2018-05-25 01:07:41 --> URI Class Initialized
INFO - 2018-05-25 01:07:41 --> URI Class Initialized
INFO - 2018-05-25 01:07:41 --> Router Class Initialized
INFO - 2018-05-25 01:07:41 --> Output Class Initialized
INFO - 2018-05-25 01:07:41 --> Security Class Initialized
DEBUG - 2018-05-25 01:07:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:07:41 --> Input Class Initialized
INFO - 2018-05-25 01:07:41 --> Language Class Initialized
ERROR - 2018-05-25 01:07:41 --> 404 Page Not Found: /index
INFO - 2018-05-25 01:07:41 --> Router Class Initialized
INFO - 2018-05-25 01:07:41 --> Output Class Initialized
INFO - 2018-05-25 01:07:41 --> Security Class Initialized
INFO - 2018-05-25 01:07:41 --> Config Class Initialized
INFO - 2018-05-25 01:07:41 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:07:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:07:41 --> Input Class Initialized
DEBUG - 2018-05-25 01:07:41 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:07:41 --> Utf8 Class Initialized
INFO - 2018-05-25 01:07:41 --> Language Class Initialized
INFO - 2018-05-25 01:07:41 --> URI Class Initialized
INFO - 2018-05-25 01:07:41 --> Router Class Initialized
INFO - 2018-05-25 01:07:41 --> Output Class Initialized
INFO - 2018-05-25 01:07:41 --> Security Class Initialized
DEBUG - 2018-05-25 01:07:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:07:41 --> Input Class Initialized
ERROR - 2018-05-25 01:07:41 --> 404 Page Not Found: /index
INFO - 2018-05-25 01:07:41 --> Language Class Initialized
ERROR - 2018-05-25 01:07:42 --> 404 Page Not Found: /index
INFO - 2018-05-25 01:07:42 --> Config Class Initialized
INFO - 2018-05-25 01:07:42 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:07:42 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:07:42 --> Utf8 Class Initialized
INFO - 2018-05-25 01:07:42 --> URI Class Initialized
INFO - 2018-05-25 01:07:42 --> Router Class Initialized
INFO - 2018-05-25 01:07:42 --> Output Class Initialized
INFO - 2018-05-25 01:07:42 --> Security Class Initialized
DEBUG - 2018-05-25 01:07:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:07:42 --> Input Class Initialized
INFO - 2018-05-25 01:07:42 --> Language Class Initialized
ERROR - 2018-05-25 01:07:42 --> 404 Page Not Found: /index
INFO - 2018-05-25 01:10:15 --> Config Class Initialized
INFO - 2018-05-25 01:10:15 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:10:15 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:10:15 --> Utf8 Class Initialized
INFO - 2018-05-25 01:10:15 --> URI Class Initialized
INFO - 2018-05-25 01:10:15 --> Router Class Initialized
INFO - 2018-05-25 01:10:15 --> Output Class Initialized
INFO - 2018-05-25 01:10:15 --> Security Class Initialized
DEBUG - 2018-05-25 01:10:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:10:15 --> Input Class Initialized
INFO - 2018-05-25 01:10:15 --> Language Class Initialized
INFO - 2018-05-25 01:10:15 --> Language Class Initialized
INFO - 2018-05-25 01:10:15 --> Config Class Initialized
INFO - 2018-05-25 01:10:15 --> Loader Class Initialized
DEBUG - 2018-05-25 01:10:15 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-25 01:10:15 --> Helper loaded: url_helper
INFO - 2018-05-25 01:10:15 --> Helper loaded: form_helper
INFO - 2018-05-25 01:10:15 --> Helper loaded: date_helper
INFO - 2018-05-25 01:10:15 --> Helper loaded: util_helper
INFO - 2018-05-25 01:10:15 --> Helper loaded: text_helper
INFO - 2018-05-25 01:10:15 --> Helper loaded: string_helper
INFO - 2018-05-25 01:10:15 --> Database Driver Class Initialized
DEBUG - 2018-05-25 01:10:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-25 01:10:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-25 01:10:15 --> Email Class Initialized
INFO - 2018-05-25 01:10:16 --> Controller Class Initialized
DEBUG - 2018-05-25 01:10:16 --> Home MX_Controller Initialized
DEBUG - 2018-05-25 01:10:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-25 01:10:16 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-25 01:10:16 --> Login MX_Controller Initialized
INFO - 2018-05-25 01:10:16 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-25 01:10:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-25 01:10:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-25 01:10:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-25 01:10:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-25 01:10:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-25 01:10:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-25 01:10:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-25 01:10:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-05-25 01:10:16 --> Final output sent to browser
DEBUG - 2018-05-25 01:10:16 --> Total execution time: 0.4060
INFO - 2018-05-25 01:10:16 --> Config Class Initialized
INFO - 2018-05-25 01:10:16 --> Config Class Initialized
INFO - 2018-05-25 01:10:16 --> Hooks Class Initialized
INFO - 2018-05-25 01:10:16 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:10:16 --> UTF-8 Support Enabled
DEBUG - 2018-05-25 01:10:16 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:10:16 --> Utf8 Class Initialized
INFO - 2018-05-25 01:10:16 --> Utf8 Class Initialized
INFO - 2018-05-25 01:10:16 --> URI Class Initialized
INFO - 2018-05-25 01:10:16 --> Router Class Initialized
INFO - 2018-05-25 01:10:16 --> URI Class Initialized
INFO - 2018-05-25 01:10:16 --> Output Class Initialized
INFO - 2018-05-25 01:10:16 --> Router Class Initialized
INFO - 2018-05-25 01:10:16 --> Security Class Initialized
INFO - 2018-05-25 01:10:16 --> Output Class Initialized
INFO - 2018-05-25 01:10:16 --> Security Class Initialized
DEBUG - 2018-05-25 01:10:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:10:16 --> Input Class Initialized
DEBUG - 2018-05-25 01:10:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:10:16 --> Language Class Initialized
INFO - 2018-05-25 01:10:16 --> Input Class Initialized
ERROR - 2018-05-25 01:10:16 --> 404 Page Not Found: /index
INFO - 2018-05-25 01:10:16 --> Language Class Initialized
ERROR - 2018-05-25 01:10:16 --> 404 Page Not Found: /index
INFO - 2018-05-25 01:10:16 --> Config Class Initialized
INFO - 2018-05-25 01:10:16 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:10:17 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:10:17 --> Utf8 Class Initialized
INFO - 2018-05-25 01:10:17 --> URI Class Initialized
INFO - 2018-05-25 01:10:17 --> Router Class Initialized
INFO - 2018-05-25 01:10:17 --> Output Class Initialized
INFO - 2018-05-25 01:10:17 --> Security Class Initialized
DEBUG - 2018-05-25 01:10:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:10:17 --> Input Class Initialized
INFO - 2018-05-25 01:10:17 --> Language Class Initialized
ERROR - 2018-05-25 01:10:17 --> 404 Page Not Found: /index
INFO - 2018-05-25 01:10:17 --> Config Class Initialized
INFO - 2018-05-25 01:10:17 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:10:17 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:10:17 --> Utf8 Class Initialized
INFO - 2018-05-25 01:10:17 --> URI Class Initialized
INFO - 2018-05-25 01:10:17 --> Router Class Initialized
INFO - 2018-05-25 01:10:17 --> Output Class Initialized
INFO - 2018-05-25 01:10:17 --> Security Class Initialized
DEBUG - 2018-05-25 01:10:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:10:17 --> Input Class Initialized
INFO - 2018-05-25 01:10:17 --> Language Class Initialized
ERROR - 2018-05-25 01:10:17 --> 404 Page Not Found: /index
INFO - 2018-05-25 01:10:25 --> Config Class Initialized
INFO - 2018-05-25 01:10:25 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:10:25 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:10:25 --> Utf8 Class Initialized
INFO - 2018-05-25 01:10:25 --> URI Class Initialized
INFO - 2018-05-25 01:10:25 --> Router Class Initialized
INFO - 2018-05-25 01:10:25 --> Output Class Initialized
INFO - 2018-05-25 01:10:25 --> Security Class Initialized
DEBUG - 2018-05-25 01:10:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:10:25 --> Input Class Initialized
INFO - 2018-05-25 01:10:25 --> Language Class Initialized
INFO - 2018-05-25 01:10:25 --> Language Class Initialized
INFO - 2018-05-25 01:10:25 --> Config Class Initialized
INFO - 2018-05-25 01:10:25 --> Loader Class Initialized
DEBUG - 2018-05-25 01:10:25 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-25 01:10:25 --> Helper loaded: url_helper
INFO - 2018-05-25 01:10:25 --> Helper loaded: form_helper
INFO - 2018-05-25 01:10:25 --> Helper loaded: date_helper
INFO - 2018-05-25 01:10:25 --> Helper loaded: util_helper
INFO - 2018-05-25 01:10:25 --> Helper loaded: text_helper
INFO - 2018-05-25 01:10:25 --> Helper loaded: string_helper
INFO - 2018-05-25 01:10:25 --> Database Driver Class Initialized
DEBUG - 2018-05-25 01:10:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-25 01:10:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-25 01:10:25 --> Email Class Initialized
INFO - 2018-05-25 01:10:25 --> Controller Class Initialized
DEBUG - 2018-05-25 01:10:25 --> Home MX_Controller Initialized
DEBUG - 2018-05-25 01:10:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-25 01:10:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-05-25 01:10:25 --> Final output sent to browser
DEBUG - 2018-05-25 01:10:25 --> Total execution time: 0.3597
INFO - 2018-05-25 01:10:25 --> Config Class Initialized
INFO - 2018-05-25 01:10:25 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:10:25 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:10:25 --> Utf8 Class Initialized
INFO - 2018-05-25 01:10:25 --> URI Class Initialized
INFO - 2018-05-25 01:10:25 --> Router Class Initialized
INFO - 2018-05-25 01:10:25 --> Output Class Initialized
INFO - 2018-05-25 01:10:25 --> Security Class Initialized
DEBUG - 2018-05-25 01:10:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:10:25 --> Input Class Initialized
INFO - 2018-05-25 01:10:25 --> Language Class Initialized
INFO - 2018-05-25 01:10:25 --> Language Class Initialized
INFO - 2018-05-25 01:10:25 --> Config Class Initialized
INFO - 2018-05-25 01:10:25 --> Loader Class Initialized
DEBUG - 2018-05-25 01:10:25 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-25 01:10:25 --> Helper loaded: url_helper
INFO - 2018-05-25 01:10:25 --> Helper loaded: form_helper
INFO - 2018-05-25 01:10:25 --> Helper loaded: date_helper
INFO - 2018-05-25 01:10:25 --> Helper loaded: util_helper
INFO - 2018-05-25 01:10:25 --> Helper loaded: text_helper
INFO - 2018-05-25 01:10:25 --> Helper loaded: string_helper
INFO - 2018-05-25 01:10:25 --> Database Driver Class Initialized
DEBUG - 2018-05-25 01:10:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-25 01:10:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-25 01:10:25 --> Email Class Initialized
INFO - 2018-05-25 01:10:25 --> Controller Class Initialized
DEBUG - 2018-05-25 01:10:25 --> Home MX_Controller Initialized
DEBUG - 2018-05-25 01:10:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-05-25 01:10:31 --> Config Class Initialized
INFO - 2018-05-25 01:10:31 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:10:31 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:10:31 --> Utf8 Class Initialized
INFO - 2018-05-25 01:10:31 --> URI Class Initialized
INFO - 2018-05-25 01:10:31 --> Router Class Initialized
INFO - 2018-05-25 01:10:31 --> Output Class Initialized
INFO - 2018-05-25 01:10:31 --> Security Class Initialized
DEBUG - 2018-05-25 01:10:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:10:31 --> Input Class Initialized
INFO - 2018-05-25 01:10:31 --> Language Class Initialized
INFO - 2018-05-25 01:10:31 --> Language Class Initialized
INFO - 2018-05-25 01:10:31 --> Config Class Initialized
INFO - 2018-05-25 01:10:31 --> Loader Class Initialized
DEBUG - 2018-05-25 01:10:31 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-25 01:10:31 --> Helper loaded: url_helper
INFO - 2018-05-25 01:10:31 --> Helper loaded: form_helper
INFO - 2018-05-25 01:10:31 --> Helper loaded: date_helper
INFO - 2018-05-25 01:10:31 --> Helper loaded: util_helper
INFO - 2018-05-25 01:10:31 --> Helper loaded: text_helper
INFO - 2018-05-25 01:10:31 --> Helper loaded: string_helper
INFO - 2018-05-25 01:10:31 --> Database Driver Class Initialized
DEBUG - 2018-05-25 01:10:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-25 01:10:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-25 01:10:31 --> Email Class Initialized
INFO - 2018-05-25 01:10:31 --> Controller Class Initialized
DEBUG - 2018-05-25 01:10:31 --> Home MX_Controller Initialized
DEBUG - 2018-05-25 01:10:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-25 01:10:31 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-25 01:10:31 --> Login MX_Controller Initialized
INFO - 2018-05-25 01:10:31 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-25 01:10:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-25 01:10:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-25 01:10:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-25 01:10:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-25 01:10:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-25 01:10:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-25 01:10:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-25 01:10:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-05-25 01:10:31 --> Final output sent to browser
DEBUG - 2018-05-25 01:10:32 --> Total execution time: 0.4269
INFO - 2018-05-25 01:10:32 --> Config Class Initialized
INFO - 2018-05-25 01:10:32 --> Config Class Initialized
INFO - 2018-05-25 01:10:32 --> Hooks Class Initialized
INFO - 2018-05-25 01:10:32 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:10:32 --> UTF-8 Support Enabled
DEBUG - 2018-05-25 01:10:32 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:10:32 --> Utf8 Class Initialized
INFO - 2018-05-25 01:10:32 --> URI Class Initialized
INFO - 2018-05-25 01:10:32 --> Router Class Initialized
INFO - 2018-05-25 01:10:32 --> Output Class Initialized
INFO - 2018-05-25 01:10:32 --> Utf8 Class Initialized
INFO - 2018-05-25 01:10:32 --> Security Class Initialized
INFO - 2018-05-25 01:10:32 --> URI Class Initialized
INFO - 2018-05-25 01:10:32 --> Router Class Initialized
INFO - 2018-05-25 01:10:32 --> Output Class Initialized
INFO - 2018-05-25 01:10:32 --> Security Class Initialized
DEBUG - 2018-05-25 01:10:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:10:32 --> Input Class Initialized
INFO - 2018-05-25 01:10:32 --> Language Class Initialized
ERROR - 2018-05-25 01:10:32 --> 404 Page Not Found: /index
DEBUG - 2018-05-25 01:10:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:10:32 --> Input Class Initialized
INFO - 2018-05-25 01:10:32 --> Language Class Initialized
ERROR - 2018-05-25 01:10:32 --> 404 Page Not Found: /index
INFO - 2018-05-25 01:10:32 --> Config Class Initialized
INFO - 2018-05-25 01:10:32 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:10:32 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:10:32 --> Utf8 Class Initialized
INFO - 2018-05-25 01:10:33 --> URI Class Initialized
INFO - 2018-05-25 01:10:33 --> Router Class Initialized
INFO - 2018-05-25 01:10:33 --> Output Class Initialized
INFO - 2018-05-25 01:10:33 --> Security Class Initialized
DEBUG - 2018-05-25 01:10:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:10:33 --> Input Class Initialized
INFO - 2018-05-25 01:10:33 --> Language Class Initialized
ERROR - 2018-05-25 01:10:33 --> 404 Page Not Found: /index
INFO - 2018-05-25 01:10:33 --> Config Class Initialized
INFO - 2018-05-25 01:10:33 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:10:33 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:10:33 --> Utf8 Class Initialized
INFO - 2018-05-25 01:10:33 --> URI Class Initialized
INFO - 2018-05-25 01:10:33 --> Router Class Initialized
INFO - 2018-05-25 01:10:33 --> Output Class Initialized
INFO - 2018-05-25 01:10:33 --> Security Class Initialized
DEBUG - 2018-05-25 01:10:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:10:33 --> Input Class Initialized
INFO - 2018-05-25 01:10:33 --> Language Class Initialized
ERROR - 2018-05-25 01:10:33 --> 404 Page Not Found: /index
INFO - 2018-05-25 01:11:23 --> Config Class Initialized
INFO - 2018-05-25 01:11:23 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:11:23 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:11:23 --> Utf8 Class Initialized
INFO - 2018-05-25 01:11:23 --> URI Class Initialized
INFO - 2018-05-25 01:11:23 --> Router Class Initialized
INFO - 2018-05-25 01:11:23 --> Output Class Initialized
INFO - 2018-05-25 01:11:23 --> Security Class Initialized
DEBUG - 2018-05-25 01:11:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:11:23 --> Input Class Initialized
INFO - 2018-05-25 01:11:23 --> Language Class Initialized
INFO - 2018-05-25 01:11:23 --> Language Class Initialized
INFO - 2018-05-25 01:11:23 --> Config Class Initialized
INFO - 2018-05-25 01:11:23 --> Loader Class Initialized
DEBUG - 2018-05-25 01:11:23 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-25 01:11:23 --> Helper loaded: url_helper
INFO - 2018-05-25 01:11:23 --> Helper loaded: form_helper
INFO - 2018-05-25 01:11:23 --> Helper loaded: date_helper
INFO - 2018-05-25 01:11:23 --> Helper loaded: util_helper
INFO - 2018-05-25 01:11:23 --> Helper loaded: text_helper
INFO - 2018-05-25 01:11:23 --> Helper loaded: string_helper
INFO - 2018-05-25 01:11:23 --> Database Driver Class Initialized
DEBUG - 2018-05-25 01:11:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-25 01:11:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-25 01:11:23 --> Email Class Initialized
INFO - 2018-05-25 01:11:23 --> Controller Class Initialized
DEBUG - 2018-05-25 01:11:23 --> Home MX_Controller Initialized
DEBUG - 2018-05-25 01:11:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-25 01:11:23 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-25 01:11:23 --> Login MX_Controller Initialized
INFO - 2018-05-25 01:11:23 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-25 01:11:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-25 01:11:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-25 01:11:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-25 01:11:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-25 01:11:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
INFO - 2018-05-25 01:11:26 --> Config Class Initialized
INFO - 2018-05-25 01:11:26 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:11:26 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:11:26 --> Utf8 Class Initialized
INFO - 2018-05-25 01:11:26 --> URI Class Initialized
INFO - 2018-05-25 01:11:26 --> Router Class Initialized
INFO - 2018-05-25 01:11:26 --> Output Class Initialized
INFO - 2018-05-25 01:11:26 --> Security Class Initialized
DEBUG - 2018-05-25 01:11:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:11:27 --> Input Class Initialized
INFO - 2018-05-25 01:11:27 --> Language Class Initialized
INFO - 2018-05-25 01:11:27 --> Language Class Initialized
INFO - 2018-05-25 01:11:27 --> Config Class Initialized
INFO - 2018-05-25 01:11:27 --> Loader Class Initialized
DEBUG - 2018-05-25 01:11:27 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-25 01:11:27 --> Helper loaded: url_helper
INFO - 2018-05-25 01:11:27 --> Helper loaded: form_helper
INFO - 2018-05-25 01:11:27 --> Helper loaded: date_helper
INFO - 2018-05-25 01:11:27 --> Helper loaded: util_helper
INFO - 2018-05-25 01:11:27 --> Helper loaded: text_helper
INFO - 2018-05-25 01:11:27 --> Helper loaded: string_helper
INFO - 2018-05-25 01:11:27 --> Database Driver Class Initialized
DEBUG - 2018-05-25 01:11:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-25 01:11:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-25 01:11:27 --> Email Class Initialized
INFO - 2018-05-25 01:11:27 --> Controller Class Initialized
DEBUG - 2018-05-25 01:11:27 --> Home MX_Controller Initialized
DEBUG - 2018-05-25 01:11:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-25 01:11:27 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-25 01:11:27 --> Login MX_Controller Initialized
INFO - 2018-05-25 01:11:27 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-25 01:11:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-25 01:11:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-25 01:11:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-25 01:11:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-25 01:11:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
INFO - 2018-05-25 01:11:51 --> Config Class Initialized
INFO - 2018-05-25 01:11:51 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:11:51 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:11:51 --> Utf8 Class Initialized
INFO - 2018-05-25 01:11:51 --> URI Class Initialized
INFO - 2018-05-25 01:11:51 --> Router Class Initialized
INFO - 2018-05-25 01:11:51 --> Output Class Initialized
INFO - 2018-05-25 01:11:51 --> Security Class Initialized
DEBUG - 2018-05-25 01:11:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:11:51 --> Input Class Initialized
INFO - 2018-05-25 01:11:51 --> Language Class Initialized
INFO - 2018-05-25 01:11:51 --> Language Class Initialized
INFO - 2018-05-25 01:11:51 --> Config Class Initialized
INFO - 2018-05-25 01:11:51 --> Loader Class Initialized
DEBUG - 2018-05-25 01:11:51 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-25 01:11:51 --> Helper loaded: url_helper
INFO - 2018-05-25 01:11:51 --> Helper loaded: form_helper
INFO - 2018-05-25 01:11:51 --> Helper loaded: date_helper
INFO - 2018-05-25 01:11:51 --> Helper loaded: util_helper
INFO - 2018-05-25 01:11:51 --> Helper loaded: text_helper
INFO - 2018-05-25 01:11:51 --> Helper loaded: string_helper
INFO - 2018-05-25 01:11:51 --> Database Driver Class Initialized
DEBUG - 2018-05-25 01:11:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-25 01:11:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-25 01:11:51 --> Email Class Initialized
INFO - 2018-05-25 01:11:51 --> Controller Class Initialized
DEBUG - 2018-05-25 01:11:51 --> Home MX_Controller Initialized
DEBUG - 2018-05-25 01:11:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-25 01:11:51 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-25 01:11:51 --> Login MX_Controller Initialized
INFO - 2018-05-25 01:11:51 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-25 01:11:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-25 01:11:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-25 01:11:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-25 01:11:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-25 01:11:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
INFO - 2018-05-25 01:12:08 --> Config Class Initialized
INFO - 2018-05-25 01:12:08 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:12:08 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:12:08 --> Utf8 Class Initialized
INFO - 2018-05-25 01:12:08 --> URI Class Initialized
INFO - 2018-05-25 01:12:08 --> Router Class Initialized
INFO - 2018-05-25 01:12:08 --> Output Class Initialized
INFO - 2018-05-25 01:12:08 --> Security Class Initialized
DEBUG - 2018-05-25 01:12:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:12:08 --> Input Class Initialized
INFO - 2018-05-25 01:12:08 --> Language Class Initialized
INFO - 2018-05-25 01:12:08 --> Language Class Initialized
INFO - 2018-05-25 01:12:08 --> Config Class Initialized
INFO - 2018-05-25 01:12:08 --> Loader Class Initialized
DEBUG - 2018-05-25 01:12:08 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-25 01:12:08 --> Helper loaded: url_helper
INFO - 2018-05-25 01:12:08 --> Helper loaded: form_helper
INFO - 2018-05-25 01:12:08 --> Helper loaded: date_helper
INFO - 2018-05-25 01:12:08 --> Helper loaded: util_helper
INFO - 2018-05-25 01:12:08 --> Helper loaded: text_helper
INFO - 2018-05-25 01:12:08 --> Helper loaded: string_helper
INFO - 2018-05-25 01:12:08 --> Database Driver Class Initialized
DEBUG - 2018-05-25 01:12:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-25 01:12:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-25 01:12:08 --> Email Class Initialized
INFO - 2018-05-25 01:12:08 --> Controller Class Initialized
DEBUG - 2018-05-25 01:12:08 --> Home MX_Controller Initialized
DEBUG - 2018-05-25 01:12:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-25 01:12:08 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-25 01:12:08 --> Login MX_Controller Initialized
INFO - 2018-05-25 01:12:08 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-25 01:12:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-25 01:12:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-25 01:12:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-25 01:12:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-25 01:12:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
INFO - 2018-05-25 01:12:26 --> Config Class Initialized
INFO - 2018-05-25 01:12:26 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:12:26 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:12:26 --> Utf8 Class Initialized
INFO - 2018-05-25 01:12:26 --> URI Class Initialized
INFO - 2018-05-25 01:12:26 --> Router Class Initialized
INFO - 2018-05-25 01:12:26 --> Output Class Initialized
INFO - 2018-05-25 01:12:26 --> Security Class Initialized
DEBUG - 2018-05-25 01:12:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:12:26 --> Input Class Initialized
INFO - 2018-05-25 01:12:26 --> Language Class Initialized
INFO - 2018-05-25 01:12:26 --> Language Class Initialized
INFO - 2018-05-25 01:12:26 --> Config Class Initialized
INFO - 2018-05-25 01:12:26 --> Loader Class Initialized
DEBUG - 2018-05-25 01:12:26 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-25 01:12:26 --> Helper loaded: url_helper
INFO - 2018-05-25 01:12:26 --> Helper loaded: form_helper
INFO - 2018-05-25 01:12:26 --> Helper loaded: date_helper
INFO - 2018-05-25 01:12:26 --> Helper loaded: util_helper
INFO - 2018-05-25 01:12:26 --> Helper loaded: text_helper
INFO - 2018-05-25 01:12:26 --> Helper loaded: string_helper
INFO - 2018-05-25 01:12:26 --> Database Driver Class Initialized
DEBUG - 2018-05-25 01:12:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-25 01:12:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-25 01:12:26 --> Email Class Initialized
INFO - 2018-05-25 01:12:26 --> Controller Class Initialized
DEBUG - 2018-05-25 01:12:26 --> Home MX_Controller Initialized
DEBUG - 2018-05-25 01:12:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-25 01:12:26 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-25 01:12:26 --> Login MX_Controller Initialized
INFO - 2018-05-25 01:12:26 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-25 01:12:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-25 01:12:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-25 01:12:50 --> Config Class Initialized
INFO - 2018-05-25 01:12:50 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:12:50 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:12:50 --> Utf8 Class Initialized
INFO - 2018-05-25 01:12:50 --> URI Class Initialized
INFO - 2018-05-25 01:12:50 --> Router Class Initialized
INFO - 2018-05-25 01:12:50 --> Output Class Initialized
INFO - 2018-05-25 01:12:50 --> Security Class Initialized
DEBUG - 2018-05-25 01:12:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:12:50 --> Input Class Initialized
INFO - 2018-05-25 01:12:50 --> Language Class Initialized
INFO - 2018-05-25 01:12:50 --> Language Class Initialized
INFO - 2018-05-25 01:12:50 --> Config Class Initialized
INFO - 2018-05-25 01:12:50 --> Loader Class Initialized
DEBUG - 2018-05-25 01:12:50 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-25 01:12:50 --> Helper loaded: url_helper
INFO - 2018-05-25 01:12:50 --> Helper loaded: form_helper
INFO - 2018-05-25 01:12:50 --> Helper loaded: date_helper
INFO - 2018-05-25 01:12:50 --> Helper loaded: util_helper
INFO - 2018-05-25 01:12:50 --> Helper loaded: text_helper
INFO - 2018-05-25 01:12:50 --> Helper loaded: string_helper
INFO - 2018-05-25 01:12:50 --> Database Driver Class Initialized
DEBUG - 2018-05-25 01:12:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-25 01:12:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-25 01:12:50 --> Email Class Initialized
INFO - 2018-05-25 01:12:50 --> Controller Class Initialized
DEBUG - 2018-05-25 01:12:50 --> Home MX_Controller Initialized
DEBUG - 2018-05-25 01:12:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-25 01:12:50 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-25 01:12:50 --> Login MX_Controller Initialized
INFO - 2018-05-25 01:12:50 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-25 01:12:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-25 01:12:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-25 01:13:00 --> Config Class Initialized
INFO - 2018-05-25 01:13:00 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:13:00 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:13:00 --> Utf8 Class Initialized
INFO - 2018-05-25 01:13:00 --> URI Class Initialized
INFO - 2018-05-25 01:13:00 --> Router Class Initialized
INFO - 2018-05-25 01:13:00 --> Output Class Initialized
INFO - 2018-05-25 01:13:00 --> Security Class Initialized
DEBUG - 2018-05-25 01:13:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:13:00 --> Input Class Initialized
INFO - 2018-05-25 01:13:00 --> Language Class Initialized
INFO - 2018-05-25 01:13:00 --> Language Class Initialized
INFO - 2018-05-25 01:13:00 --> Config Class Initialized
INFO - 2018-05-25 01:13:00 --> Loader Class Initialized
DEBUG - 2018-05-25 01:13:00 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-25 01:13:00 --> Helper loaded: url_helper
INFO - 2018-05-25 01:13:00 --> Helper loaded: form_helper
INFO - 2018-05-25 01:13:00 --> Helper loaded: date_helper
INFO - 2018-05-25 01:13:00 --> Helper loaded: util_helper
INFO - 2018-05-25 01:13:00 --> Helper loaded: text_helper
INFO - 2018-05-25 01:13:00 --> Helper loaded: string_helper
INFO - 2018-05-25 01:13:00 --> Database Driver Class Initialized
DEBUG - 2018-05-25 01:13:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-25 01:13:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-25 01:13:00 --> Email Class Initialized
INFO - 2018-05-25 01:13:00 --> Controller Class Initialized
DEBUG - 2018-05-25 01:13:00 --> Home MX_Controller Initialized
DEBUG - 2018-05-25 01:13:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-25 01:13:00 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-25 01:13:00 --> Login MX_Controller Initialized
INFO - 2018-05-25 01:13:00 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-25 01:13:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-25 01:13:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-25 01:13:10 --> Config Class Initialized
INFO - 2018-05-25 01:13:10 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:13:11 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:13:11 --> Utf8 Class Initialized
INFO - 2018-05-25 01:13:11 --> URI Class Initialized
INFO - 2018-05-25 01:13:11 --> Router Class Initialized
INFO - 2018-05-25 01:13:11 --> Output Class Initialized
INFO - 2018-05-25 01:13:11 --> Security Class Initialized
DEBUG - 2018-05-25 01:13:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:13:11 --> Input Class Initialized
INFO - 2018-05-25 01:13:11 --> Language Class Initialized
INFO - 2018-05-25 01:13:11 --> Language Class Initialized
INFO - 2018-05-25 01:13:11 --> Config Class Initialized
INFO - 2018-05-25 01:13:11 --> Loader Class Initialized
DEBUG - 2018-05-25 01:13:11 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-25 01:13:11 --> Helper loaded: url_helper
INFO - 2018-05-25 01:13:11 --> Helper loaded: form_helper
INFO - 2018-05-25 01:13:11 --> Helper loaded: date_helper
INFO - 2018-05-25 01:13:11 --> Helper loaded: util_helper
INFO - 2018-05-25 01:13:11 --> Helper loaded: text_helper
INFO - 2018-05-25 01:13:11 --> Helper loaded: string_helper
INFO - 2018-05-25 01:13:11 --> Database Driver Class Initialized
DEBUG - 2018-05-25 01:13:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-25 01:13:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-25 01:13:11 --> Email Class Initialized
INFO - 2018-05-25 01:13:11 --> Controller Class Initialized
DEBUG - 2018-05-25 01:13:11 --> Home MX_Controller Initialized
DEBUG - 2018-05-25 01:13:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-25 01:13:11 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-25 01:13:11 --> Login MX_Controller Initialized
INFO - 2018-05-25 01:13:11 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-25 01:13:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-25 01:13:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-25 01:14:37 --> Config Class Initialized
INFO - 2018-05-25 01:14:37 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:14:37 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:14:37 --> Utf8 Class Initialized
INFO - 2018-05-25 01:14:37 --> URI Class Initialized
INFO - 2018-05-25 01:14:37 --> Router Class Initialized
INFO - 2018-05-25 01:14:37 --> Output Class Initialized
INFO - 2018-05-25 01:14:37 --> Security Class Initialized
DEBUG - 2018-05-25 01:14:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:14:37 --> Input Class Initialized
INFO - 2018-05-25 01:14:37 --> Language Class Initialized
INFO - 2018-05-25 01:14:37 --> Language Class Initialized
INFO - 2018-05-25 01:14:37 --> Config Class Initialized
INFO - 2018-05-25 01:14:37 --> Loader Class Initialized
DEBUG - 2018-05-25 01:14:37 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-25 01:14:37 --> Helper loaded: url_helper
INFO - 2018-05-25 01:14:37 --> Helper loaded: form_helper
INFO - 2018-05-25 01:14:37 --> Helper loaded: date_helper
INFO - 2018-05-25 01:14:37 --> Helper loaded: util_helper
INFO - 2018-05-25 01:14:37 --> Helper loaded: text_helper
INFO - 2018-05-25 01:14:37 --> Helper loaded: string_helper
INFO - 2018-05-25 01:14:37 --> Database Driver Class Initialized
DEBUG - 2018-05-25 01:14:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-25 01:14:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-25 01:14:37 --> Email Class Initialized
INFO - 2018-05-25 01:14:37 --> Controller Class Initialized
DEBUG - 2018-05-25 01:14:37 --> Home MX_Controller Initialized
DEBUG - 2018-05-25 01:14:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-25 01:14:37 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-25 01:14:38 --> Login MX_Controller Initialized
INFO - 2018-05-25 01:14:38 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-25 01:14:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-25 01:14:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-25 01:14:45 --> Config Class Initialized
INFO - 2018-05-25 01:14:45 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:14:45 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:14:45 --> Utf8 Class Initialized
INFO - 2018-05-25 01:14:45 --> URI Class Initialized
INFO - 2018-05-25 01:14:45 --> Router Class Initialized
INFO - 2018-05-25 01:14:45 --> Output Class Initialized
INFO - 2018-05-25 01:14:45 --> Security Class Initialized
DEBUG - 2018-05-25 01:14:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:14:45 --> Input Class Initialized
INFO - 2018-05-25 01:14:45 --> Language Class Initialized
INFO - 2018-05-25 01:14:45 --> Language Class Initialized
INFO - 2018-05-25 01:14:45 --> Config Class Initialized
INFO - 2018-05-25 01:14:45 --> Loader Class Initialized
DEBUG - 2018-05-25 01:14:45 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-25 01:14:45 --> Helper loaded: url_helper
INFO - 2018-05-25 01:14:45 --> Helper loaded: form_helper
INFO - 2018-05-25 01:14:45 --> Helper loaded: date_helper
INFO - 2018-05-25 01:14:45 --> Helper loaded: util_helper
INFO - 2018-05-25 01:14:45 --> Helper loaded: text_helper
INFO - 2018-05-25 01:14:45 --> Helper loaded: string_helper
INFO - 2018-05-25 01:14:45 --> Database Driver Class Initialized
DEBUG - 2018-05-25 01:14:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-25 01:14:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-25 01:14:46 --> Email Class Initialized
INFO - 2018-05-25 01:14:46 --> Controller Class Initialized
DEBUG - 2018-05-25 01:14:46 --> Home MX_Controller Initialized
DEBUG - 2018-05-25 01:14:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-25 01:14:46 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-25 01:14:46 --> Login MX_Controller Initialized
INFO - 2018-05-25 01:14:46 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-25 01:14:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-25 01:14:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-25 01:15:02 --> Config Class Initialized
INFO - 2018-05-25 01:15:02 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:15:02 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:15:02 --> Utf8 Class Initialized
INFO - 2018-05-25 01:15:02 --> URI Class Initialized
INFO - 2018-05-25 01:15:02 --> Router Class Initialized
INFO - 2018-05-25 01:15:02 --> Output Class Initialized
INFO - 2018-05-25 01:15:02 --> Security Class Initialized
DEBUG - 2018-05-25 01:15:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:15:02 --> Input Class Initialized
INFO - 2018-05-25 01:15:02 --> Language Class Initialized
INFO - 2018-05-25 01:15:02 --> Language Class Initialized
INFO - 2018-05-25 01:15:02 --> Config Class Initialized
INFO - 2018-05-25 01:15:02 --> Loader Class Initialized
DEBUG - 2018-05-25 01:15:02 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-25 01:15:02 --> Helper loaded: url_helper
INFO - 2018-05-25 01:15:03 --> Helper loaded: form_helper
INFO - 2018-05-25 01:15:03 --> Helper loaded: date_helper
INFO - 2018-05-25 01:15:03 --> Helper loaded: util_helper
INFO - 2018-05-25 01:15:03 --> Helper loaded: text_helper
INFO - 2018-05-25 01:15:03 --> Helper loaded: string_helper
INFO - 2018-05-25 01:15:03 --> Database Driver Class Initialized
DEBUG - 2018-05-25 01:15:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-25 01:15:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-25 01:15:03 --> Email Class Initialized
INFO - 2018-05-25 01:15:03 --> Controller Class Initialized
DEBUG - 2018-05-25 01:15:03 --> Home MX_Controller Initialized
DEBUG - 2018-05-25 01:15:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-25 01:15:03 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-25 01:15:03 --> Login MX_Controller Initialized
INFO - 2018-05-25 01:15:03 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-25 01:15:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-25 01:15:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-25 01:15:03 --> Config Class Initialized
INFO - 2018-05-25 01:15:03 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:15:03 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:15:03 --> Utf8 Class Initialized
INFO - 2018-05-25 01:15:03 --> URI Class Initialized
INFO - 2018-05-25 01:15:03 --> Router Class Initialized
INFO - 2018-05-25 01:15:03 --> Output Class Initialized
INFO - 2018-05-25 01:15:03 --> Security Class Initialized
DEBUG - 2018-05-25 01:15:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:15:03 --> Input Class Initialized
INFO - 2018-05-25 01:15:03 --> Language Class Initialized
INFO - 2018-05-25 01:15:03 --> Language Class Initialized
INFO - 2018-05-25 01:15:03 --> Config Class Initialized
INFO - 2018-05-25 01:15:03 --> Loader Class Initialized
DEBUG - 2018-05-25 01:15:03 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-25 01:15:03 --> Helper loaded: url_helper
INFO - 2018-05-25 01:15:03 --> Helper loaded: form_helper
INFO - 2018-05-25 01:15:03 --> Helper loaded: date_helper
INFO - 2018-05-25 01:15:03 --> Helper loaded: util_helper
INFO - 2018-05-25 01:15:03 --> Helper loaded: text_helper
INFO - 2018-05-25 01:15:03 --> Helper loaded: string_helper
INFO - 2018-05-25 01:15:03 --> Database Driver Class Initialized
DEBUG - 2018-05-25 01:15:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-25 01:15:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-25 01:15:03 --> Email Class Initialized
INFO - 2018-05-25 01:15:03 --> Controller Class Initialized
DEBUG - 2018-05-25 01:15:03 --> Home MX_Controller Initialized
DEBUG - 2018-05-25 01:15:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-25 01:15:03 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-25 01:15:03 --> Login MX_Controller Initialized
INFO - 2018-05-25 01:15:03 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-25 01:15:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-25 01:15:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-25 01:15:26 --> Config Class Initialized
INFO - 2018-05-25 01:15:26 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:15:26 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:15:26 --> Utf8 Class Initialized
INFO - 2018-05-25 01:15:26 --> URI Class Initialized
INFO - 2018-05-25 01:15:26 --> Router Class Initialized
INFO - 2018-05-25 01:15:26 --> Output Class Initialized
INFO - 2018-05-25 01:15:26 --> Security Class Initialized
DEBUG - 2018-05-25 01:15:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:15:26 --> Input Class Initialized
INFO - 2018-05-25 01:15:26 --> Language Class Initialized
INFO - 2018-05-25 01:15:26 --> Language Class Initialized
INFO - 2018-05-25 01:15:26 --> Config Class Initialized
INFO - 2018-05-25 01:15:26 --> Loader Class Initialized
DEBUG - 2018-05-25 01:15:27 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-25 01:15:27 --> Helper loaded: url_helper
INFO - 2018-05-25 01:15:27 --> Helper loaded: form_helper
INFO - 2018-05-25 01:15:27 --> Helper loaded: date_helper
INFO - 2018-05-25 01:15:27 --> Helper loaded: util_helper
INFO - 2018-05-25 01:15:27 --> Helper loaded: text_helper
INFO - 2018-05-25 01:15:27 --> Helper loaded: string_helper
INFO - 2018-05-25 01:15:27 --> Database Driver Class Initialized
DEBUG - 2018-05-25 01:15:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-25 01:15:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-25 01:15:27 --> Email Class Initialized
INFO - 2018-05-25 01:15:27 --> Controller Class Initialized
DEBUG - 2018-05-25 01:15:27 --> Home MX_Controller Initialized
DEBUG - 2018-05-25 01:15:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-25 01:15:27 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-25 01:15:27 --> Login MX_Controller Initialized
INFO - 2018-05-25 01:15:27 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-25 01:15:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-25 01:15:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-25 01:16:23 --> Config Class Initialized
INFO - 2018-05-25 01:16:23 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:16:23 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:16:23 --> Utf8 Class Initialized
INFO - 2018-05-25 01:16:23 --> URI Class Initialized
INFO - 2018-05-25 01:16:23 --> Router Class Initialized
INFO - 2018-05-25 01:16:23 --> Output Class Initialized
INFO - 2018-05-25 01:16:23 --> Security Class Initialized
DEBUG - 2018-05-25 01:16:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:16:23 --> Input Class Initialized
INFO - 2018-05-25 01:16:23 --> Language Class Initialized
INFO - 2018-05-25 01:16:23 --> Language Class Initialized
INFO - 2018-05-25 01:16:23 --> Config Class Initialized
INFO - 2018-05-25 01:16:23 --> Loader Class Initialized
DEBUG - 2018-05-25 01:16:23 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-25 01:16:23 --> Helper loaded: url_helper
INFO - 2018-05-25 01:16:23 --> Helper loaded: form_helper
INFO - 2018-05-25 01:16:23 --> Helper loaded: date_helper
INFO - 2018-05-25 01:16:23 --> Helper loaded: util_helper
INFO - 2018-05-25 01:16:23 --> Helper loaded: text_helper
INFO - 2018-05-25 01:16:23 --> Helper loaded: string_helper
INFO - 2018-05-25 01:16:23 --> Database Driver Class Initialized
DEBUG - 2018-05-25 01:16:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-25 01:16:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-25 01:16:23 --> Email Class Initialized
INFO - 2018-05-25 01:16:23 --> Controller Class Initialized
DEBUG - 2018-05-25 01:16:23 --> Home MX_Controller Initialized
DEBUG - 2018-05-25 01:16:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-25 01:16:23 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-25 01:16:23 --> Login MX_Controller Initialized
INFO - 2018-05-25 01:16:23 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-25 01:16:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-25 01:16:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-25 01:16:42 --> Config Class Initialized
INFO - 2018-05-25 01:16:42 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:16:42 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:16:42 --> Utf8 Class Initialized
INFO - 2018-05-25 01:16:42 --> URI Class Initialized
INFO - 2018-05-25 01:16:42 --> Router Class Initialized
INFO - 2018-05-25 01:16:42 --> Output Class Initialized
INFO - 2018-05-25 01:16:42 --> Security Class Initialized
DEBUG - 2018-05-25 01:16:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:16:42 --> Input Class Initialized
INFO - 2018-05-25 01:16:42 --> Language Class Initialized
INFO - 2018-05-25 01:16:42 --> Language Class Initialized
INFO - 2018-05-25 01:16:42 --> Config Class Initialized
INFO - 2018-05-25 01:16:42 --> Loader Class Initialized
DEBUG - 2018-05-25 01:16:42 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-25 01:16:42 --> Helper loaded: url_helper
INFO - 2018-05-25 01:16:42 --> Helper loaded: form_helper
INFO - 2018-05-25 01:16:42 --> Helper loaded: date_helper
INFO - 2018-05-25 01:16:42 --> Helper loaded: util_helper
INFO - 2018-05-25 01:16:42 --> Helper loaded: text_helper
INFO - 2018-05-25 01:16:42 --> Helper loaded: string_helper
INFO - 2018-05-25 01:16:42 --> Database Driver Class Initialized
DEBUG - 2018-05-25 01:16:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-25 01:16:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-25 01:16:42 --> Email Class Initialized
INFO - 2018-05-25 01:16:42 --> Controller Class Initialized
DEBUG - 2018-05-25 01:16:42 --> Home MX_Controller Initialized
DEBUG - 2018-05-25 01:16:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-25 01:16:42 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-25 01:16:42 --> Login MX_Controller Initialized
INFO - 2018-05-25 01:16:42 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-25 01:16:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-25 01:16:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
ERROR - 2018-05-25 01:16:42 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'unique(cs.seen_status)
FROM `videos` as `vid`
LEFT JOIN `course_seen` as `cs` ON' at line 1 - Invalid query: SELECT `vid`.*, unique(cs.seen_status)
FROM `videos` as `vid`
LEFT JOIN `course_seen` as `cs` ON `cs`.`video_id` = `vid`.`program_id`
WHERE `vid`.`chapter_id` = '2'
INFO - 2018-05-25 01:16:43 --> Language file loaded: language/english/db_lang.php
INFO - 2018-05-25 01:16:59 --> Config Class Initialized
INFO - 2018-05-25 01:16:59 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:16:59 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:16:59 --> Utf8 Class Initialized
INFO - 2018-05-25 01:16:59 --> URI Class Initialized
INFO - 2018-05-25 01:16:59 --> Router Class Initialized
INFO - 2018-05-25 01:16:59 --> Output Class Initialized
INFO - 2018-05-25 01:16:59 --> Security Class Initialized
DEBUG - 2018-05-25 01:16:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:16:59 --> Input Class Initialized
INFO - 2018-05-25 01:16:59 --> Language Class Initialized
INFO - 2018-05-25 01:16:59 --> Language Class Initialized
INFO - 2018-05-25 01:16:59 --> Config Class Initialized
INFO - 2018-05-25 01:16:59 --> Loader Class Initialized
DEBUG - 2018-05-25 01:16:59 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-25 01:17:00 --> Helper loaded: url_helper
INFO - 2018-05-25 01:17:00 --> Helper loaded: form_helper
INFO - 2018-05-25 01:17:00 --> Helper loaded: date_helper
INFO - 2018-05-25 01:17:00 --> Helper loaded: util_helper
INFO - 2018-05-25 01:17:00 --> Helper loaded: text_helper
INFO - 2018-05-25 01:17:00 --> Helper loaded: string_helper
INFO - 2018-05-25 01:17:00 --> Database Driver Class Initialized
DEBUG - 2018-05-25 01:17:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-25 01:17:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-25 01:17:00 --> Email Class Initialized
INFO - 2018-05-25 01:17:00 --> Controller Class Initialized
DEBUG - 2018-05-25 01:17:00 --> Home MX_Controller Initialized
DEBUG - 2018-05-25 01:17:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-25 01:17:00 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-25 01:17:00 --> Login MX_Controller Initialized
INFO - 2018-05-25 01:17:00 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-25 01:17:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-25 01:17:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
ERROR - 2018-05-25 01:17:00 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'distinct(cs.seen_status)
FROM `videos` as `vid`
LEFT JOIN `course_seen` as `cs` ' at line 1 - Invalid query: SELECT `vid`.*, distinct(cs.seen_status)
FROM `videos` as `vid`
LEFT JOIN `course_seen` as `cs` ON `cs`.`video_id` = `vid`.`program_id`
WHERE `vid`.`chapter_id` = '2'
INFO - 2018-05-25 01:17:00 --> Language file loaded: language/english/db_lang.php
INFO - 2018-05-25 01:17:36 --> Config Class Initialized
INFO - 2018-05-25 01:17:36 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:17:36 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:17:36 --> Utf8 Class Initialized
INFO - 2018-05-25 01:17:36 --> URI Class Initialized
INFO - 2018-05-25 01:17:36 --> Router Class Initialized
INFO - 2018-05-25 01:17:36 --> Output Class Initialized
INFO - 2018-05-25 01:17:36 --> Security Class Initialized
DEBUG - 2018-05-25 01:17:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:17:36 --> Input Class Initialized
INFO - 2018-05-25 01:17:36 --> Language Class Initialized
INFO - 2018-05-25 01:17:36 --> Language Class Initialized
INFO - 2018-05-25 01:17:36 --> Config Class Initialized
INFO - 2018-05-25 01:17:36 --> Loader Class Initialized
DEBUG - 2018-05-25 01:17:36 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-25 01:17:36 --> Helper loaded: url_helper
INFO - 2018-05-25 01:17:36 --> Helper loaded: form_helper
INFO - 2018-05-25 01:17:36 --> Helper loaded: date_helper
INFO - 2018-05-25 01:17:36 --> Helper loaded: util_helper
INFO - 2018-05-25 01:17:36 --> Helper loaded: text_helper
INFO - 2018-05-25 01:17:36 --> Helper loaded: string_helper
INFO - 2018-05-25 01:17:36 --> Database Driver Class Initialized
DEBUG - 2018-05-25 01:17:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-25 01:17:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-25 01:17:36 --> Email Class Initialized
INFO - 2018-05-25 01:17:36 --> Controller Class Initialized
DEBUG - 2018-05-25 01:17:36 --> Home MX_Controller Initialized
DEBUG - 2018-05-25 01:17:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-25 01:17:36 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-25 01:17:36 --> Login MX_Controller Initialized
INFO - 2018-05-25 01:17:36 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-25 01:17:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-25 01:17:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
ERROR - 2018-05-25 01:17:36 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'distinct(cs.seen_status)
FROM `videos` as `vid`
LEFT JOIN `course_seen` as `cs` ' at line 1 - Invalid query: SELECT `vid`.*, distinct(cs.seen_status)
FROM `videos` as `vid`
LEFT JOIN `course_seen` as `cs` ON `cs`.`video_id` = `vid`.`program_id`
WHERE `vid`.`chapter_id` = '2'
INFO - 2018-05-25 01:17:36 --> Language file loaded: language/english/db_lang.php
INFO - 2018-05-25 01:19:21 --> Config Class Initialized
INFO - 2018-05-25 01:19:21 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:19:21 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:19:21 --> Utf8 Class Initialized
INFO - 2018-05-25 01:19:21 --> URI Class Initialized
INFO - 2018-05-25 01:19:21 --> Router Class Initialized
INFO - 2018-05-25 01:19:21 --> Output Class Initialized
INFO - 2018-05-25 01:19:21 --> Security Class Initialized
DEBUG - 2018-05-25 01:19:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:19:21 --> Input Class Initialized
INFO - 2018-05-25 01:19:21 --> Language Class Initialized
INFO - 2018-05-25 01:19:21 --> Language Class Initialized
INFO - 2018-05-25 01:19:21 --> Config Class Initialized
INFO - 2018-05-25 01:19:21 --> Loader Class Initialized
DEBUG - 2018-05-25 01:19:21 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-25 01:19:21 --> Helper loaded: url_helper
INFO - 2018-05-25 01:19:21 --> Helper loaded: form_helper
INFO - 2018-05-25 01:19:21 --> Helper loaded: date_helper
INFO - 2018-05-25 01:19:21 --> Helper loaded: util_helper
INFO - 2018-05-25 01:19:21 --> Helper loaded: text_helper
INFO - 2018-05-25 01:19:21 --> Helper loaded: string_helper
INFO - 2018-05-25 01:19:21 --> Database Driver Class Initialized
DEBUG - 2018-05-25 01:19:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-25 01:19:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-25 01:19:21 --> Email Class Initialized
INFO - 2018-05-25 01:19:21 --> Controller Class Initialized
DEBUG - 2018-05-25 01:19:21 --> Home MX_Controller Initialized
DEBUG - 2018-05-25 01:19:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-25 01:19:21 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-25 01:19:21 --> Login MX_Controller Initialized
INFO - 2018-05-25 01:19:21 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-25 01:19:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-25 01:19:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
ERROR - 2018-05-25 01:19:21 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'distinct(cs.seen_status)
FROM `videos` as `vid`
LEFT JOIN `course_seen` as `cs` ' at line 1 - Invalid query: SELECT `vid`.*, distinct(cs.seen_status)
FROM `videos` as `vid`
LEFT JOIN `course_seen` as `cs` ON `cs`.`video_id` = `vid`.`program_id`
WHERE `vid`.`chapter_id` = '2'
AND `cs`.`user_id` = '4'
INFO - 2018-05-25 01:19:21 --> Language file loaded: language/english/db_lang.php
INFO - 2018-05-25 01:19:42 --> Config Class Initialized
INFO - 2018-05-25 01:19:42 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:19:42 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:19:42 --> Utf8 Class Initialized
INFO - 2018-05-25 01:19:42 --> URI Class Initialized
INFO - 2018-05-25 01:19:42 --> Router Class Initialized
INFO - 2018-05-25 01:19:42 --> Output Class Initialized
INFO - 2018-05-25 01:19:42 --> Security Class Initialized
DEBUG - 2018-05-25 01:19:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:19:42 --> Input Class Initialized
INFO - 2018-05-25 01:19:42 --> Language Class Initialized
INFO - 2018-05-25 01:19:42 --> Language Class Initialized
INFO - 2018-05-25 01:19:42 --> Config Class Initialized
INFO - 2018-05-25 01:19:42 --> Loader Class Initialized
DEBUG - 2018-05-25 01:19:42 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-25 01:19:42 --> Helper loaded: url_helper
INFO - 2018-05-25 01:19:42 --> Helper loaded: form_helper
INFO - 2018-05-25 01:19:42 --> Helper loaded: date_helper
INFO - 2018-05-25 01:19:42 --> Helper loaded: util_helper
INFO - 2018-05-25 01:19:42 --> Helper loaded: text_helper
INFO - 2018-05-25 01:19:42 --> Helper loaded: string_helper
INFO - 2018-05-25 01:19:42 --> Database Driver Class Initialized
DEBUG - 2018-05-25 01:19:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-25 01:19:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-25 01:19:42 --> Email Class Initialized
INFO - 2018-05-25 01:19:42 --> Controller Class Initialized
DEBUG - 2018-05-25 01:19:42 --> Home MX_Controller Initialized
DEBUG - 2018-05-25 01:19:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-25 01:19:43 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-25 01:19:43 --> Login MX_Controller Initialized
INFO - 2018-05-25 01:19:43 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-25 01:19:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-25 01:19:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-25 01:20:07 --> Config Class Initialized
INFO - 2018-05-25 01:20:07 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:20:07 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:20:07 --> Utf8 Class Initialized
INFO - 2018-05-25 01:20:07 --> URI Class Initialized
INFO - 2018-05-25 01:20:07 --> Router Class Initialized
INFO - 2018-05-25 01:20:07 --> Output Class Initialized
INFO - 2018-05-25 01:20:07 --> Security Class Initialized
DEBUG - 2018-05-25 01:20:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:20:07 --> Input Class Initialized
INFO - 2018-05-25 01:20:07 --> Language Class Initialized
INFO - 2018-05-25 01:20:07 --> Language Class Initialized
INFO - 2018-05-25 01:20:07 --> Config Class Initialized
INFO - 2018-05-25 01:20:07 --> Loader Class Initialized
DEBUG - 2018-05-25 01:20:07 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-25 01:20:07 --> Helper loaded: url_helper
INFO - 2018-05-25 01:20:07 --> Helper loaded: form_helper
INFO - 2018-05-25 01:20:07 --> Helper loaded: date_helper
INFO - 2018-05-25 01:20:07 --> Helper loaded: util_helper
INFO - 2018-05-25 01:20:07 --> Helper loaded: text_helper
INFO - 2018-05-25 01:20:07 --> Helper loaded: string_helper
INFO - 2018-05-25 01:20:08 --> Database Driver Class Initialized
DEBUG - 2018-05-25 01:20:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-25 01:20:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-25 01:20:08 --> Email Class Initialized
INFO - 2018-05-25 01:20:08 --> Controller Class Initialized
DEBUG - 2018-05-25 01:20:08 --> Home MX_Controller Initialized
DEBUG - 2018-05-25 01:20:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-25 01:20:08 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-25 01:20:08 --> Login MX_Controller Initialized
INFO - 2018-05-25 01:20:08 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-25 01:20:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-25 01:20:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-25 01:20:19 --> Config Class Initialized
INFO - 2018-05-25 01:20:19 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:20:19 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:20:19 --> Utf8 Class Initialized
INFO - 2018-05-25 01:20:19 --> URI Class Initialized
INFO - 2018-05-25 01:20:19 --> Router Class Initialized
INFO - 2018-05-25 01:20:19 --> Output Class Initialized
INFO - 2018-05-25 01:20:19 --> Security Class Initialized
DEBUG - 2018-05-25 01:20:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:20:19 --> Input Class Initialized
INFO - 2018-05-25 01:20:19 --> Language Class Initialized
INFO - 2018-05-25 01:20:19 --> Language Class Initialized
INFO - 2018-05-25 01:20:19 --> Config Class Initialized
INFO - 2018-05-25 01:20:19 --> Loader Class Initialized
DEBUG - 2018-05-25 01:20:19 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-25 01:20:19 --> Helper loaded: url_helper
INFO - 2018-05-25 01:20:19 --> Helper loaded: form_helper
INFO - 2018-05-25 01:20:19 --> Helper loaded: date_helper
INFO - 2018-05-25 01:20:19 --> Helper loaded: util_helper
INFO - 2018-05-25 01:20:19 --> Helper loaded: text_helper
INFO - 2018-05-25 01:20:19 --> Helper loaded: string_helper
INFO - 2018-05-25 01:20:19 --> Database Driver Class Initialized
DEBUG - 2018-05-25 01:20:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-25 01:20:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-25 01:20:19 --> Email Class Initialized
INFO - 2018-05-25 01:20:19 --> Controller Class Initialized
DEBUG - 2018-05-25 01:20:19 --> Home MX_Controller Initialized
DEBUG - 2018-05-25 01:20:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-25 01:20:20 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-25 01:20:20 --> Login MX_Controller Initialized
INFO - 2018-05-25 01:20:20 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-25 01:20:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-25 01:20:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
ERROR - 2018-05-25 01:20:20 --> Query error: Unknown column 'cs.user_id' in 'where clause' - Invalid query: SELECT `vid`.*
FROM `videos` as `vid`
WHERE `vid`.`chapter_id` = '2'
AND `cs`.`user_id` = '4'
INFO - 2018-05-25 01:20:20 --> Language file loaded: language/english/db_lang.php
INFO - 2018-05-25 01:20:30 --> Config Class Initialized
INFO - 2018-05-25 01:20:30 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:20:30 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:20:30 --> Utf8 Class Initialized
INFO - 2018-05-25 01:20:30 --> URI Class Initialized
INFO - 2018-05-25 01:20:30 --> Router Class Initialized
INFO - 2018-05-25 01:20:30 --> Output Class Initialized
INFO - 2018-05-25 01:20:30 --> Security Class Initialized
DEBUG - 2018-05-25 01:20:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:20:30 --> Input Class Initialized
INFO - 2018-05-25 01:20:30 --> Language Class Initialized
INFO - 2018-05-25 01:20:30 --> Language Class Initialized
INFO - 2018-05-25 01:20:30 --> Config Class Initialized
INFO - 2018-05-25 01:20:30 --> Loader Class Initialized
DEBUG - 2018-05-25 01:20:30 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-25 01:20:30 --> Helper loaded: url_helper
INFO - 2018-05-25 01:20:30 --> Helper loaded: form_helper
INFO - 2018-05-25 01:20:30 --> Helper loaded: date_helper
INFO - 2018-05-25 01:20:30 --> Helper loaded: util_helper
INFO - 2018-05-25 01:20:30 --> Helper loaded: text_helper
INFO - 2018-05-25 01:20:30 --> Helper loaded: string_helper
INFO - 2018-05-25 01:20:30 --> Database Driver Class Initialized
DEBUG - 2018-05-25 01:20:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-25 01:20:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-25 01:20:30 --> Email Class Initialized
INFO - 2018-05-25 01:20:30 --> Controller Class Initialized
DEBUG - 2018-05-25 01:20:30 --> Home MX_Controller Initialized
DEBUG - 2018-05-25 01:20:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-25 01:20:31 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-25 01:20:31 --> Login MX_Controller Initialized
INFO - 2018-05-25 01:20:31 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-25 01:20:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-25 01:20:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-25 01:23:35 --> Config Class Initialized
INFO - 2018-05-25 01:23:35 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:23:35 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:23:35 --> Utf8 Class Initialized
INFO - 2018-05-25 01:23:35 --> URI Class Initialized
INFO - 2018-05-25 01:23:35 --> Router Class Initialized
INFO - 2018-05-25 01:23:35 --> Output Class Initialized
INFO - 2018-05-25 01:23:35 --> Security Class Initialized
DEBUG - 2018-05-25 01:23:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:23:35 --> Input Class Initialized
INFO - 2018-05-25 01:23:35 --> Language Class Initialized
INFO - 2018-05-25 01:23:35 --> Language Class Initialized
INFO - 2018-05-25 01:23:35 --> Config Class Initialized
INFO - 2018-05-25 01:23:35 --> Loader Class Initialized
DEBUG - 2018-05-25 01:23:35 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-25 01:23:35 --> Helper loaded: url_helper
INFO - 2018-05-25 01:23:35 --> Helper loaded: form_helper
INFO - 2018-05-25 01:23:35 --> Helper loaded: date_helper
INFO - 2018-05-25 01:23:35 --> Helper loaded: util_helper
INFO - 2018-05-25 01:23:35 --> Helper loaded: text_helper
INFO - 2018-05-25 01:23:35 --> Helper loaded: string_helper
INFO - 2018-05-25 01:23:35 --> Database Driver Class Initialized
DEBUG - 2018-05-25 01:23:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-25 01:23:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-25 01:23:35 --> Email Class Initialized
INFO - 2018-05-25 01:23:35 --> Controller Class Initialized
DEBUG - 2018-05-25 01:23:35 --> Home MX_Controller Initialized
DEBUG - 2018-05-25 01:23:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-25 01:23:35 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-25 01:23:35 --> Login MX_Controller Initialized
INFO - 2018-05-25 01:23:35 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-25 01:23:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-25 01:23:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
ERROR - 2018-05-25 01:23:35 --> Query error: Unknown column 'chapter_id' in 'where clause' - Invalid query: SELECT `seen_status`
FROM `course_seen`
WHERE `chapter_id` = '2'
AND `user_id` = '4'
INFO - 2018-05-25 01:23:35 --> Language file loaded: language/english/db_lang.php
INFO - 2018-05-25 01:24:08 --> Config Class Initialized
INFO - 2018-05-25 01:24:08 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:24:08 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:24:08 --> Utf8 Class Initialized
INFO - 2018-05-25 01:24:08 --> URI Class Initialized
INFO - 2018-05-25 01:24:08 --> Router Class Initialized
INFO - 2018-05-25 01:24:08 --> Output Class Initialized
INFO - 2018-05-25 01:24:08 --> Security Class Initialized
DEBUG - 2018-05-25 01:24:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:24:08 --> Input Class Initialized
INFO - 2018-05-25 01:24:08 --> Language Class Initialized
INFO - 2018-05-25 01:24:08 --> Language Class Initialized
INFO - 2018-05-25 01:24:08 --> Config Class Initialized
INFO - 2018-05-25 01:24:08 --> Loader Class Initialized
DEBUG - 2018-05-25 01:24:08 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-25 01:24:08 --> Helper loaded: url_helper
INFO - 2018-05-25 01:24:08 --> Helper loaded: form_helper
INFO - 2018-05-25 01:24:08 --> Helper loaded: date_helper
INFO - 2018-05-25 01:24:08 --> Helper loaded: util_helper
INFO - 2018-05-25 01:24:08 --> Helper loaded: text_helper
INFO - 2018-05-25 01:24:08 --> Helper loaded: string_helper
INFO - 2018-05-25 01:24:08 --> Database Driver Class Initialized
DEBUG - 2018-05-25 01:24:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-25 01:24:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-25 01:24:08 --> Email Class Initialized
INFO - 2018-05-25 01:24:08 --> Controller Class Initialized
DEBUG - 2018-05-25 01:24:08 --> Home MX_Controller Initialized
DEBUG - 2018-05-25 01:24:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-25 01:24:08 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-25 01:24:08 --> Login MX_Controller Initialized
INFO - 2018-05-25 01:24:08 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-25 01:24:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-25 01:24:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-25 01:24:42 --> Config Class Initialized
INFO - 2018-05-25 01:24:42 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:24:42 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:24:42 --> Utf8 Class Initialized
INFO - 2018-05-25 01:24:42 --> URI Class Initialized
INFO - 2018-05-25 01:24:42 --> Router Class Initialized
INFO - 2018-05-25 01:24:42 --> Output Class Initialized
INFO - 2018-05-25 01:24:42 --> Security Class Initialized
DEBUG - 2018-05-25 01:24:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:24:42 --> Input Class Initialized
INFO - 2018-05-25 01:24:42 --> Language Class Initialized
INFO - 2018-05-25 01:24:42 --> Language Class Initialized
INFO - 2018-05-25 01:24:42 --> Config Class Initialized
INFO - 2018-05-25 01:24:42 --> Loader Class Initialized
DEBUG - 2018-05-25 01:24:42 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-25 01:24:42 --> Helper loaded: url_helper
INFO - 2018-05-25 01:24:42 --> Helper loaded: form_helper
INFO - 2018-05-25 01:24:42 --> Helper loaded: date_helper
INFO - 2018-05-25 01:24:42 --> Helper loaded: util_helper
INFO - 2018-05-25 01:24:42 --> Helper loaded: text_helper
INFO - 2018-05-25 01:24:42 --> Helper loaded: string_helper
INFO - 2018-05-25 01:24:42 --> Database Driver Class Initialized
DEBUG - 2018-05-25 01:24:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-25 01:24:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-25 01:24:42 --> Email Class Initialized
INFO - 2018-05-25 01:24:42 --> Controller Class Initialized
DEBUG - 2018-05-25 01:24:42 --> Home MX_Controller Initialized
DEBUG - 2018-05-25 01:24:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-25 01:24:42 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-25 01:24:43 --> Login MX_Controller Initialized
INFO - 2018-05-25 01:24:43 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-25 01:24:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-25 01:24:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-25 01:24:57 --> Config Class Initialized
INFO - 2018-05-25 01:24:57 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:24:57 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:24:57 --> Utf8 Class Initialized
INFO - 2018-05-25 01:24:57 --> URI Class Initialized
INFO - 2018-05-25 01:24:57 --> Router Class Initialized
INFO - 2018-05-25 01:24:57 --> Output Class Initialized
INFO - 2018-05-25 01:24:57 --> Security Class Initialized
DEBUG - 2018-05-25 01:24:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:24:57 --> Input Class Initialized
INFO - 2018-05-25 01:24:57 --> Language Class Initialized
INFO - 2018-05-25 01:24:57 --> Language Class Initialized
INFO - 2018-05-25 01:24:57 --> Config Class Initialized
INFO - 2018-05-25 01:24:57 --> Loader Class Initialized
DEBUG - 2018-05-25 01:24:57 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-25 01:24:57 --> Helper loaded: url_helper
INFO - 2018-05-25 01:24:57 --> Helper loaded: form_helper
INFO - 2018-05-25 01:24:57 --> Helper loaded: date_helper
INFO - 2018-05-25 01:24:57 --> Helper loaded: util_helper
INFO - 2018-05-25 01:24:57 --> Helper loaded: text_helper
INFO - 2018-05-25 01:24:57 --> Helper loaded: string_helper
INFO - 2018-05-25 01:24:57 --> Database Driver Class Initialized
DEBUG - 2018-05-25 01:24:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-25 01:24:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-25 01:24:57 --> Email Class Initialized
INFO - 2018-05-25 01:24:57 --> Controller Class Initialized
DEBUG - 2018-05-25 01:24:57 --> Home MX_Controller Initialized
DEBUG - 2018-05-25 01:24:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-25 01:24:57 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-25 01:24:57 --> Login MX_Controller Initialized
INFO - 2018-05-25 01:24:57 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-25 01:24:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-25 01:24:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-25 01:26:07 --> Config Class Initialized
INFO - 2018-05-25 01:26:07 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:26:07 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:26:07 --> Utf8 Class Initialized
INFO - 2018-05-25 01:26:07 --> URI Class Initialized
INFO - 2018-05-25 01:26:07 --> Router Class Initialized
INFO - 2018-05-25 01:26:07 --> Output Class Initialized
INFO - 2018-05-25 01:26:07 --> Security Class Initialized
DEBUG - 2018-05-25 01:26:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:26:07 --> Input Class Initialized
INFO - 2018-05-25 01:26:07 --> Language Class Initialized
INFO - 2018-05-25 01:26:07 --> Language Class Initialized
INFO - 2018-05-25 01:26:07 --> Config Class Initialized
INFO - 2018-05-25 01:26:07 --> Loader Class Initialized
DEBUG - 2018-05-25 01:26:07 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-25 01:26:07 --> Helper loaded: url_helper
INFO - 2018-05-25 01:26:07 --> Helper loaded: form_helper
INFO - 2018-05-25 01:26:07 --> Helper loaded: date_helper
INFO - 2018-05-25 01:26:07 --> Helper loaded: util_helper
INFO - 2018-05-25 01:26:07 --> Helper loaded: text_helper
INFO - 2018-05-25 01:26:07 --> Helper loaded: string_helper
INFO - 2018-05-25 01:26:07 --> Database Driver Class Initialized
DEBUG - 2018-05-25 01:26:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-25 01:26:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-25 01:26:07 --> Email Class Initialized
INFO - 2018-05-25 01:26:07 --> Controller Class Initialized
DEBUG - 2018-05-25 01:26:07 --> Home MX_Controller Initialized
DEBUG - 2018-05-25 01:26:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-25 01:26:07 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-25 01:26:07 --> Login MX_Controller Initialized
INFO - 2018-05-25 01:26:07 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-25 01:26:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-25 01:26:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-25 01:26:20 --> Config Class Initialized
INFO - 2018-05-25 01:26:20 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:26:20 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:26:20 --> Utf8 Class Initialized
INFO - 2018-05-25 01:26:20 --> URI Class Initialized
INFO - 2018-05-25 01:26:20 --> Router Class Initialized
INFO - 2018-05-25 01:26:20 --> Output Class Initialized
INFO - 2018-05-25 01:26:20 --> Security Class Initialized
DEBUG - 2018-05-25 01:26:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:26:20 --> Input Class Initialized
INFO - 2018-05-25 01:26:20 --> Language Class Initialized
INFO - 2018-05-25 01:26:20 --> Language Class Initialized
INFO - 2018-05-25 01:26:20 --> Config Class Initialized
INFO - 2018-05-25 01:26:20 --> Loader Class Initialized
DEBUG - 2018-05-25 01:26:20 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-25 01:26:20 --> Helper loaded: url_helper
INFO - 2018-05-25 01:26:20 --> Helper loaded: form_helper
INFO - 2018-05-25 01:26:20 --> Helper loaded: date_helper
INFO - 2018-05-25 01:26:20 --> Helper loaded: util_helper
INFO - 2018-05-25 01:26:20 --> Helper loaded: text_helper
INFO - 2018-05-25 01:26:20 --> Helper loaded: string_helper
INFO - 2018-05-25 01:26:20 --> Database Driver Class Initialized
DEBUG - 2018-05-25 01:26:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-25 01:26:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-25 01:26:20 --> Email Class Initialized
INFO - 2018-05-25 01:26:20 --> Controller Class Initialized
DEBUG - 2018-05-25 01:26:20 --> Home MX_Controller Initialized
DEBUG - 2018-05-25 01:26:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-25 01:26:20 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-25 01:26:20 --> Login MX_Controller Initialized
INFO - 2018-05-25 01:26:20 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-25 01:26:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-25 01:26:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-25 01:26:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-25 01:26:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-25 01:26:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
ERROR - 2018-05-25 01:26:20 --> Severity: Notice --> Undefined index: seen_status E:\xampp\htdocs\consulting\application\modules\home\views\course.php 121
INFO - 2018-05-25 01:26:25 --> Config Class Initialized
INFO - 2018-05-25 01:26:25 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:26:25 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:26:25 --> Utf8 Class Initialized
INFO - 2018-05-25 01:26:25 --> URI Class Initialized
INFO - 2018-05-25 01:26:25 --> Router Class Initialized
INFO - 2018-05-25 01:26:25 --> Output Class Initialized
INFO - 2018-05-25 01:26:25 --> Security Class Initialized
DEBUG - 2018-05-25 01:26:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:26:25 --> Input Class Initialized
INFO - 2018-05-25 01:26:25 --> Language Class Initialized
INFO - 2018-05-25 01:26:25 --> Language Class Initialized
INFO - 2018-05-25 01:26:25 --> Config Class Initialized
INFO - 2018-05-25 01:26:25 --> Loader Class Initialized
DEBUG - 2018-05-25 01:26:25 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-25 01:26:25 --> Helper loaded: url_helper
INFO - 2018-05-25 01:26:25 --> Helper loaded: form_helper
INFO - 2018-05-25 01:26:25 --> Helper loaded: date_helper
INFO - 2018-05-25 01:26:25 --> Helper loaded: util_helper
INFO - 2018-05-25 01:26:25 --> Helper loaded: text_helper
INFO - 2018-05-25 01:26:25 --> Helper loaded: string_helper
INFO - 2018-05-25 01:26:25 --> Database Driver Class Initialized
DEBUG - 2018-05-25 01:26:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-25 01:26:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-25 01:26:25 --> Email Class Initialized
INFO - 2018-05-25 01:26:25 --> Controller Class Initialized
DEBUG - 2018-05-25 01:26:25 --> Home MX_Controller Initialized
DEBUG - 2018-05-25 01:26:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-25 01:26:25 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-25 01:26:25 --> Login MX_Controller Initialized
INFO - 2018-05-25 01:26:25 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-25 01:26:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-25 01:26:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-25 01:26:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-25 01:26:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-25 01:26:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
ERROR - 2018-05-25 01:26:26 --> Severity: Notice --> Undefined index: seen_status E:\xampp\htdocs\consulting\application\modules\home\views\course.php 121
INFO - 2018-05-25 01:26:26 --> Config Class Initialized
INFO - 2018-05-25 01:26:26 --> Config Class Initialized
INFO - 2018-05-25 01:26:26 --> Hooks Class Initialized
INFO - 2018-05-25 01:26:26 --> Hooks Class Initialized
INFO - 2018-05-25 01:26:26 --> Config Class Initialized
INFO - 2018-05-25 01:26:26 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:26:26 --> UTF-8 Support Enabled
DEBUG - 2018-05-25 01:26:26 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:26:26 --> Utf8 Class Initialized
INFO - 2018-05-25 01:26:26 --> Utf8 Class Initialized
DEBUG - 2018-05-25 01:26:26 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:26:26 --> Utf8 Class Initialized
INFO - 2018-05-25 01:26:26 --> URI Class Initialized
INFO - 2018-05-25 01:26:26 --> URI Class Initialized
INFO - 2018-05-25 01:26:26 --> URI Class Initialized
INFO - 2018-05-25 01:26:26 --> Router Class Initialized
INFO - 2018-05-25 01:26:26 --> Router Class Initialized
INFO - 2018-05-25 01:26:26 --> Output Class Initialized
INFO - 2018-05-25 01:26:26 --> Output Class Initialized
INFO - 2018-05-25 01:26:26 --> Router Class Initialized
INFO - 2018-05-25 01:26:26 --> Security Class Initialized
INFO - 2018-05-25 01:26:26 --> Output Class Initialized
INFO - 2018-05-25 01:26:26 --> Security Class Initialized
DEBUG - 2018-05-25 01:26:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:26:26 --> Security Class Initialized
DEBUG - 2018-05-25 01:26:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:26:26 --> Input Class Initialized
INFO - 2018-05-25 01:26:26 --> Input Class Initialized
DEBUG - 2018-05-25 01:26:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:26:26 --> Language Class Initialized
INFO - 2018-05-25 01:26:26 --> Input Class Initialized
INFO - 2018-05-25 01:26:26 --> Language Class Initialized
ERROR - 2018-05-25 01:26:26 --> 404 Page Not Found: /index
ERROR - 2018-05-25 01:26:26 --> 404 Page Not Found: /index
INFO - 2018-05-25 01:26:26 --> Language Class Initialized
ERROR - 2018-05-25 01:26:26 --> 404 Page Not Found: /index
INFO - 2018-05-25 01:26:26 --> Config Class Initialized
INFO - 2018-05-25 01:26:26 --> Hooks Class Initialized
INFO - 2018-05-25 01:26:26 --> Config Class Initialized
INFO - 2018-05-25 01:26:26 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:26:26 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:26:27 --> Utf8 Class Initialized
DEBUG - 2018-05-25 01:26:27 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:26:27 --> Utf8 Class Initialized
INFO - 2018-05-25 01:26:27 --> URI Class Initialized
INFO - 2018-05-25 01:26:27 --> URI Class Initialized
INFO - 2018-05-25 01:26:27 --> Router Class Initialized
INFO - 2018-05-25 01:26:27 --> Output Class Initialized
INFO - 2018-05-25 01:26:27 --> Router Class Initialized
INFO - 2018-05-25 01:26:27 --> Output Class Initialized
INFO - 2018-05-25 01:26:27 --> Security Class Initialized
DEBUG - 2018-05-25 01:26:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:26:27 --> Security Class Initialized
INFO - 2018-05-25 01:26:27 --> Input Class Initialized
DEBUG - 2018-05-25 01:26:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:26:27 --> Language Class Initialized
INFO - 2018-05-25 01:26:27 --> Input Class Initialized
ERROR - 2018-05-25 01:26:27 --> 404 Page Not Found: /index
INFO - 2018-05-25 01:26:27 --> Language Class Initialized
ERROR - 2018-05-25 01:26:27 --> 404 Page Not Found: /index
INFO - 2018-05-25 01:26:27 --> Config Class Initialized
INFO - 2018-05-25 01:26:27 --> Hooks Class Initialized
INFO - 2018-05-25 01:26:27 --> Config Class Initialized
INFO - 2018-05-25 01:26:27 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:26:27 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:26:27 --> Utf8 Class Initialized
DEBUG - 2018-05-25 01:26:27 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:26:27 --> Utf8 Class Initialized
INFO - 2018-05-25 01:26:27 --> URI Class Initialized
INFO - 2018-05-25 01:26:27 --> URI Class Initialized
INFO - 2018-05-25 01:26:27 --> Router Class Initialized
INFO - 2018-05-25 01:26:27 --> Output Class Initialized
INFO - 2018-05-25 01:26:27 --> Router Class Initialized
INFO - 2018-05-25 01:26:27 --> Security Class Initialized
INFO - 2018-05-25 01:26:27 --> Output Class Initialized
INFO - 2018-05-25 01:26:27 --> Security Class Initialized
DEBUG - 2018-05-25 01:26:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:26:27 --> Input Class Initialized
DEBUG - 2018-05-25 01:26:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:26:27 --> Input Class Initialized
INFO - 2018-05-25 01:26:27 --> Language Class Initialized
ERROR - 2018-05-25 01:26:27 --> 404 Page Not Found: /index
INFO - 2018-05-25 01:26:27 --> Language Class Initialized
ERROR - 2018-05-25 01:26:27 --> 404 Page Not Found: /index
INFO - 2018-05-25 01:26:44 --> Config Class Initialized
INFO - 2018-05-25 01:26:44 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:26:44 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:26:44 --> Utf8 Class Initialized
INFO - 2018-05-25 01:26:44 --> URI Class Initialized
INFO - 2018-05-25 01:26:44 --> Router Class Initialized
INFO - 2018-05-25 01:26:44 --> Output Class Initialized
INFO - 2018-05-25 01:26:44 --> Security Class Initialized
DEBUG - 2018-05-25 01:26:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:26:44 --> Input Class Initialized
INFO - 2018-05-25 01:26:44 --> Language Class Initialized
INFO - 2018-05-25 01:26:44 --> Language Class Initialized
INFO - 2018-05-25 01:26:44 --> Config Class Initialized
INFO - 2018-05-25 01:26:44 --> Loader Class Initialized
DEBUG - 2018-05-25 01:26:44 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-25 01:26:44 --> Helper loaded: url_helper
INFO - 2018-05-25 01:26:44 --> Helper loaded: form_helper
INFO - 2018-05-25 01:26:44 --> Helper loaded: date_helper
INFO - 2018-05-25 01:26:44 --> Helper loaded: util_helper
INFO - 2018-05-25 01:26:45 --> Helper loaded: text_helper
INFO - 2018-05-25 01:26:45 --> Helper loaded: string_helper
INFO - 2018-05-25 01:26:45 --> Database Driver Class Initialized
DEBUG - 2018-05-25 01:26:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-25 01:26:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-25 01:26:45 --> Email Class Initialized
INFO - 2018-05-25 01:26:45 --> Controller Class Initialized
DEBUG - 2018-05-25 01:26:45 --> Home MX_Controller Initialized
DEBUG - 2018-05-25 01:26:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-25 01:26:45 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-25 01:26:45 --> Login MX_Controller Initialized
INFO - 2018-05-25 01:26:45 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-25 01:26:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-25 01:26:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-25 01:28:55 --> Config Class Initialized
INFO - 2018-05-25 01:28:55 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:28:55 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:28:55 --> Utf8 Class Initialized
INFO - 2018-05-25 01:28:55 --> URI Class Initialized
INFO - 2018-05-25 01:28:55 --> Router Class Initialized
INFO - 2018-05-25 01:28:55 --> Output Class Initialized
INFO - 2018-05-25 01:28:55 --> Security Class Initialized
DEBUG - 2018-05-25 01:28:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:28:55 --> Input Class Initialized
INFO - 2018-05-25 01:28:55 --> Language Class Initialized
INFO - 2018-05-25 01:28:55 --> Language Class Initialized
INFO - 2018-05-25 01:28:55 --> Config Class Initialized
INFO - 2018-05-25 01:28:55 --> Loader Class Initialized
DEBUG - 2018-05-25 01:28:55 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-25 01:28:55 --> Helper loaded: url_helper
INFO - 2018-05-25 01:28:55 --> Helper loaded: form_helper
INFO - 2018-05-25 01:28:55 --> Helper loaded: date_helper
INFO - 2018-05-25 01:28:55 --> Helper loaded: util_helper
INFO - 2018-05-25 01:28:55 --> Helper loaded: text_helper
INFO - 2018-05-25 01:28:55 --> Helper loaded: string_helper
INFO - 2018-05-25 01:28:55 --> Database Driver Class Initialized
DEBUG - 2018-05-25 01:28:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-25 01:28:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-25 01:28:55 --> Email Class Initialized
INFO - 2018-05-25 01:28:55 --> Controller Class Initialized
DEBUG - 2018-05-25 01:28:55 --> Home MX_Controller Initialized
DEBUG - 2018-05-25 01:28:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-25 01:28:55 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-25 01:28:55 --> Login MX_Controller Initialized
INFO - 2018-05-25 01:28:55 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-25 01:28:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-25 01:28:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-25 01:28:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-25 01:28:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-25 01:28:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
INFO - 2018-05-25 01:28:58 --> Config Class Initialized
INFO - 2018-05-25 01:28:59 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:28:59 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:28:59 --> Utf8 Class Initialized
INFO - 2018-05-25 01:28:59 --> URI Class Initialized
INFO - 2018-05-25 01:28:59 --> Router Class Initialized
INFO - 2018-05-25 01:28:59 --> Output Class Initialized
INFO - 2018-05-25 01:28:59 --> Security Class Initialized
DEBUG - 2018-05-25 01:28:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:28:59 --> Input Class Initialized
INFO - 2018-05-25 01:28:59 --> Language Class Initialized
INFO - 2018-05-25 01:28:59 --> Language Class Initialized
INFO - 2018-05-25 01:28:59 --> Config Class Initialized
INFO - 2018-05-25 01:28:59 --> Loader Class Initialized
DEBUG - 2018-05-25 01:28:59 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-25 01:28:59 --> Helper loaded: url_helper
INFO - 2018-05-25 01:28:59 --> Helper loaded: form_helper
INFO - 2018-05-25 01:28:59 --> Helper loaded: date_helper
INFO - 2018-05-25 01:28:59 --> Helper loaded: util_helper
INFO - 2018-05-25 01:28:59 --> Helper loaded: text_helper
INFO - 2018-05-25 01:28:59 --> Helper loaded: string_helper
INFO - 2018-05-25 01:28:59 --> Database Driver Class Initialized
DEBUG - 2018-05-25 01:28:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-25 01:28:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-25 01:28:59 --> Email Class Initialized
INFO - 2018-05-25 01:28:59 --> Controller Class Initialized
DEBUG - 2018-05-25 01:28:59 --> Home MX_Controller Initialized
DEBUG - 2018-05-25 01:28:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-25 01:28:59 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-25 01:28:59 --> Login MX_Controller Initialized
INFO - 2018-05-25 01:28:59 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-25 01:28:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-25 01:28:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-25 01:28:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-25 01:28:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-25 01:28:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
INFO - 2018-05-25 01:28:59 --> Config Class Initialized
INFO - 2018-05-25 01:28:59 --> Config Class Initialized
INFO - 2018-05-25 01:28:59 --> Hooks Class Initialized
INFO - 2018-05-25 01:28:59 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:28:59 --> UTF-8 Support Enabled
DEBUG - 2018-05-25 01:28:59 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:28:59 --> Config Class Initialized
INFO - 2018-05-25 01:28:59 --> Hooks Class Initialized
INFO - 2018-05-25 01:28:59 --> Utf8 Class Initialized
INFO - 2018-05-25 01:28:59 --> Utf8 Class Initialized
DEBUG - 2018-05-25 01:29:00 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:29:00 --> Utf8 Class Initialized
INFO - 2018-05-25 01:29:00 --> URI Class Initialized
INFO - 2018-05-25 01:29:00 --> Router Class Initialized
INFO - 2018-05-25 01:29:00 --> URI Class Initialized
INFO - 2018-05-25 01:29:00 --> Output Class Initialized
INFO - 2018-05-25 01:29:00 --> Router Class Initialized
INFO - 2018-05-25 01:29:00 --> Security Class Initialized
INFO - 2018-05-25 01:29:00 --> URI Class Initialized
INFO - 2018-05-25 01:29:00 --> Output Class Initialized
INFO - 2018-05-25 01:29:00 --> Security Class Initialized
DEBUG - 2018-05-25 01:29:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:29:00 --> Input Class Initialized
INFO - 2018-05-25 01:29:00 --> Language Class Initialized
ERROR - 2018-05-25 01:29:00 --> 404 Page Not Found: /index
INFO - 2018-05-25 01:29:00 --> Router Class Initialized
DEBUG - 2018-05-25 01:29:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:29:00 --> Output Class Initialized
INFO - 2018-05-25 01:29:00 --> Input Class Initialized
INFO - 2018-05-25 01:29:00 --> Language Class Initialized
ERROR - 2018-05-25 01:29:00 --> 404 Page Not Found: /index
INFO - 2018-05-25 01:29:00 --> Config Class Initialized
INFO - 2018-05-25 01:29:00 --> Security Class Initialized
INFO - 2018-05-25 01:29:00 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:29:00 --> UTF-8 Support Enabled
DEBUG - 2018-05-25 01:29:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:29:00 --> Utf8 Class Initialized
INFO - 2018-05-25 01:29:00 --> URI Class Initialized
INFO - 2018-05-25 01:29:00 --> Input Class Initialized
INFO - 2018-05-25 01:29:00 --> Router Class Initialized
INFO - 2018-05-25 01:29:00 --> Output Class Initialized
INFO - 2018-05-25 01:29:00 --> Language Class Initialized
INFO - 2018-05-25 01:29:00 --> Security Class Initialized
DEBUG - 2018-05-25 01:29:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:29:00 --> Input Class Initialized
INFO - 2018-05-25 01:29:00 --> Language Class Initialized
ERROR - 2018-05-25 01:29:00 --> 404 Page Not Found: /index
ERROR - 2018-05-25 01:29:00 --> 404 Page Not Found: /index
INFO - 2018-05-25 01:29:00 --> Config Class Initialized
INFO - 2018-05-25 01:29:00 --> Hooks Class Initialized
INFO - 2018-05-25 01:29:00 --> Config Class Initialized
DEBUG - 2018-05-25 01:29:00 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:29:00 --> Hooks Class Initialized
INFO - 2018-05-25 01:29:00 --> Utf8 Class Initialized
INFO - 2018-05-25 01:29:00 --> URI Class Initialized
INFO - 2018-05-25 01:29:00 --> Router Class Initialized
INFO - 2018-05-25 01:29:00 --> Output Class Initialized
INFO - 2018-05-25 01:29:00 --> Security Class Initialized
DEBUG - 2018-05-25 01:29:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:29:00 --> Input Class Initialized
INFO - 2018-05-25 01:29:00 --> Language Class Initialized
ERROR - 2018-05-25 01:29:00 --> 404 Page Not Found: /index
DEBUG - 2018-05-25 01:29:00 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:29:00 --> Utf8 Class Initialized
INFO - 2018-05-25 01:29:00 --> URI Class Initialized
INFO - 2018-05-25 01:29:00 --> Router Class Initialized
INFO - 2018-05-25 01:29:00 --> Output Class Initialized
INFO - 2018-05-25 01:29:00 --> Security Class Initialized
DEBUG - 2018-05-25 01:29:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:29:00 --> Input Class Initialized
INFO - 2018-05-25 01:29:00 --> Language Class Initialized
ERROR - 2018-05-25 01:29:00 --> 404 Page Not Found: /index
INFO - 2018-05-25 01:29:00 --> Config Class Initialized
INFO - 2018-05-25 01:29:00 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:29:00 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:29:00 --> Utf8 Class Initialized
INFO - 2018-05-25 01:29:00 --> URI Class Initialized
INFO - 2018-05-25 01:29:00 --> Router Class Initialized
INFO - 2018-05-25 01:29:00 --> Output Class Initialized
INFO - 2018-05-25 01:29:00 --> Security Class Initialized
DEBUG - 2018-05-25 01:29:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:29:00 --> Input Class Initialized
INFO - 2018-05-25 01:29:00 --> Language Class Initialized
ERROR - 2018-05-25 01:29:00 --> 404 Page Not Found: /index
INFO - 2018-05-25 01:29:14 --> Config Class Initialized
INFO - 2018-05-25 01:29:14 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:29:14 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:29:14 --> Utf8 Class Initialized
INFO - 2018-05-25 01:29:14 --> URI Class Initialized
INFO - 2018-05-25 01:29:14 --> Router Class Initialized
INFO - 2018-05-25 01:29:14 --> Output Class Initialized
INFO - 2018-05-25 01:29:14 --> Security Class Initialized
DEBUG - 2018-05-25 01:29:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:29:14 --> Input Class Initialized
INFO - 2018-05-25 01:29:14 --> Language Class Initialized
INFO - 2018-05-25 01:29:14 --> Language Class Initialized
INFO - 2018-05-25 01:29:14 --> Config Class Initialized
INFO - 2018-05-25 01:29:14 --> Loader Class Initialized
DEBUG - 2018-05-25 01:29:14 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-25 01:29:14 --> Helper loaded: url_helper
INFO - 2018-05-25 01:29:14 --> Helper loaded: form_helper
INFO - 2018-05-25 01:29:14 --> Helper loaded: date_helper
INFO - 2018-05-25 01:29:14 --> Helper loaded: util_helper
INFO - 2018-05-25 01:29:14 --> Helper loaded: text_helper
INFO - 2018-05-25 01:29:14 --> Helper loaded: string_helper
INFO - 2018-05-25 01:29:14 --> Database Driver Class Initialized
DEBUG - 2018-05-25 01:29:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-25 01:29:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-25 01:29:14 --> Email Class Initialized
INFO - 2018-05-25 01:29:14 --> Controller Class Initialized
DEBUG - 2018-05-25 01:29:14 --> Home MX_Controller Initialized
DEBUG - 2018-05-25 01:29:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-25 01:29:14 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-25 01:29:14 --> Login MX_Controller Initialized
INFO - 2018-05-25 01:29:14 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-25 01:29:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-25 01:29:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-25 01:29:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-25 01:29:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-25 01:29:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-25 01:29:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-25 01:29:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-25 01:29:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-05-25 01:29:14 --> Final output sent to browser
DEBUG - 2018-05-25 01:29:15 --> Total execution time: 0.4741
INFO - 2018-05-25 01:29:15 --> Config Class Initialized
INFO - 2018-05-25 01:29:15 --> Config Class Initialized
INFO - 2018-05-25 01:29:15 --> Hooks Class Initialized
INFO - 2018-05-25 01:29:15 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:29:15 --> UTF-8 Support Enabled
DEBUG - 2018-05-25 01:29:15 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:29:15 --> Utf8 Class Initialized
INFO - 2018-05-25 01:29:15 --> Utf8 Class Initialized
INFO - 2018-05-25 01:29:15 --> URI Class Initialized
INFO - 2018-05-25 01:29:15 --> URI Class Initialized
INFO - 2018-05-25 01:29:15 --> Router Class Initialized
INFO - 2018-05-25 01:29:15 --> Output Class Initialized
INFO - 2018-05-25 01:29:15 --> Security Class Initialized
INFO - 2018-05-25 01:29:15 --> Router Class Initialized
DEBUG - 2018-05-25 01:29:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:29:15 --> Output Class Initialized
INFO - 2018-05-25 01:29:15 --> Input Class Initialized
INFO - 2018-05-25 01:29:15 --> Security Class Initialized
INFO - 2018-05-25 01:29:15 --> Language Class Initialized
DEBUG - 2018-05-25 01:29:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-05-25 01:29:15 --> 404 Page Not Found: /index
INFO - 2018-05-25 01:29:15 --> Input Class Initialized
INFO - 2018-05-25 01:29:15 --> Language Class Initialized
ERROR - 2018-05-25 01:29:15 --> 404 Page Not Found: /index
INFO - 2018-05-25 01:29:15 --> Config Class Initialized
INFO - 2018-05-25 01:29:15 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:29:15 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:29:15 --> Utf8 Class Initialized
INFO - 2018-05-25 01:29:15 --> URI Class Initialized
INFO - 2018-05-25 01:29:15 --> Router Class Initialized
INFO - 2018-05-25 01:29:15 --> Output Class Initialized
INFO - 2018-05-25 01:29:15 --> Security Class Initialized
DEBUG - 2018-05-25 01:29:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:29:15 --> Input Class Initialized
INFO - 2018-05-25 01:29:15 --> Language Class Initialized
ERROR - 2018-05-25 01:29:15 --> 404 Page Not Found: /index
INFO - 2018-05-25 01:29:16 --> Config Class Initialized
INFO - 2018-05-25 01:29:16 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:29:16 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:29:16 --> Utf8 Class Initialized
INFO - 2018-05-25 01:29:16 --> URI Class Initialized
INFO - 2018-05-25 01:29:16 --> Router Class Initialized
INFO - 2018-05-25 01:29:16 --> Output Class Initialized
INFO - 2018-05-25 01:29:16 --> Security Class Initialized
DEBUG - 2018-05-25 01:29:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:29:16 --> Input Class Initialized
INFO - 2018-05-25 01:29:16 --> Language Class Initialized
ERROR - 2018-05-25 01:29:16 --> 404 Page Not Found: /index
INFO - 2018-05-25 01:29:23 --> Config Class Initialized
INFO - 2018-05-25 01:29:23 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:29:23 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:29:23 --> Utf8 Class Initialized
INFO - 2018-05-25 01:29:23 --> URI Class Initialized
INFO - 2018-05-25 01:29:23 --> Router Class Initialized
INFO - 2018-05-25 01:29:23 --> Output Class Initialized
INFO - 2018-05-25 01:29:23 --> Security Class Initialized
DEBUG - 2018-05-25 01:29:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:29:23 --> Input Class Initialized
INFO - 2018-05-25 01:29:23 --> Language Class Initialized
INFO - 2018-05-25 01:29:23 --> Language Class Initialized
INFO - 2018-05-25 01:29:23 --> Config Class Initialized
INFO - 2018-05-25 01:29:23 --> Loader Class Initialized
DEBUG - 2018-05-25 01:29:23 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-25 01:29:23 --> Helper loaded: url_helper
INFO - 2018-05-25 01:29:23 --> Helper loaded: form_helper
INFO - 2018-05-25 01:29:23 --> Helper loaded: date_helper
INFO - 2018-05-25 01:29:23 --> Helper loaded: util_helper
INFO - 2018-05-25 01:29:23 --> Helper loaded: text_helper
INFO - 2018-05-25 01:29:23 --> Helper loaded: string_helper
INFO - 2018-05-25 01:29:23 --> Database Driver Class Initialized
DEBUG - 2018-05-25 01:29:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-25 01:29:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-25 01:29:23 --> Email Class Initialized
INFO - 2018-05-25 01:29:23 --> Controller Class Initialized
DEBUG - 2018-05-25 01:29:23 --> Home MX_Controller Initialized
DEBUG - 2018-05-25 01:29:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-25 01:29:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-05-25 01:29:23 --> Final output sent to browser
DEBUG - 2018-05-25 01:29:23 --> Total execution time: 0.3961
INFO - 2018-05-25 01:29:23 --> Config Class Initialized
INFO - 2018-05-25 01:29:23 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:29:23 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:29:23 --> Utf8 Class Initialized
INFO - 2018-05-25 01:29:23 --> URI Class Initialized
INFO - 2018-05-25 01:29:23 --> Router Class Initialized
INFO - 2018-05-25 01:29:23 --> Output Class Initialized
INFO - 2018-05-25 01:29:23 --> Security Class Initialized
DEBUG - 2018-05-25 01:29:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:29:23 --> Input Class Initialized
INFO - 2018-05-25 01:29:23 --> Language Class Initialized
INFO - 2018-05-25 01:29:23 --> Language Class Initialized
INFO - 2018-05-25 01:29:23 --> Config Class Initialized
INFO - 2018-05-25 01:29:23 --> Loader Class Initialized
DEBUG - 2018-05-25 01:29:23 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-25 01:29:23 --> Helper loaded: url_helper
INFO - 2018-05-25 01:29:23 --> Helper loaded: form_helper
INFO - 2018-05-25 01:29:23 --> Helper loaded: date_helper
INFO - 2018-05-25 01:29:23 --> Helper loaded: util_helper
INFO - 2018-05-25 01:29:23 --> Helper loaded: text_helper
INFO - 2018-05-25 01:29:23 --> Helper loaded: string_helper
INFO - 2018-05-25 01:29:23 --> Database Driver Class Initialized
DEBUG - 2018-05-25 01:29:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-25 01:29:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-25 01:29:24 --> Email Class Initialized
INFO - 2018-05-25 01:29:24 --> Controller Class Initialized
DEBUG - 2018-05-25 01:29:24 --> Home MX_Controller Initialized
DEBUG - 2018-05-25 01:29:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-05-25 01:29:25 --> Config Class Initialized
INFO - 2018-05-25 01:29:25 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:29:25 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:29:25 --> Utf8 Class Initialized
INFO - 2018-05-25 01:29:25 --> URI Class Initialized
INFO - 2018-05-25 01:29:25 --> Router Class Initialized
INFO - 2018-05-25 01:29:25 --> Output Class Initialized
INFO - 2018-05-25 01:29:25 --> Security Class Initialized
DEBUG - 2018-05-25 01:29:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:29:25 --> Input Class Initialized
INFO - 2018-05-25 01:29:25 --> Language Class Initialized
INFO - 2018-05-25 01:29:25 --> Language Class Initialized
INFO - 2018-05-25 01:29:25 --> Config Class Initialized
INFO - 2018-05-25 01:29:25 --> Loader Class Initialized
DEBUG - 2018-05-25 01:29:25 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-25 01:29:25 --> Helper loaded: url_helper
INFO - 2018-05-25 01:29:25 --> Helper loaded: form_helper
INFO - 2018-05-25 01:29:25 --> Helper loaded: date_helper
INFO - 2018-05-25 01:29:25 --> Helper loaded: util_helper
INFO - 2018-05-25 01:29:25 --> Helper loaded: text_helper
INFO - 2018-05-25 01:29:25 --> Helper loaded: string_helper
INFO - 2018-05-25 01:29:25 --> Database Driver Class Initialized
DEBUG - 2018-05-25 01:29:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-25 01:29:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-25 01:29:25 --> Email Class Initialized
INFO - 2018-05-25 01:29:25 --> Controller Class Initialized
DEBUG - 2018-05-25 01:29:25 --> Home MX_Controller Initialized
DEBUG - 2018-05-25 01:29:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-25 01:29:25 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-25 01:29:25 --> Login MX_Controller Initialized
INFO - 2018-05-25 01:29:25 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-25 01:29:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-25 01:29:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-25 01:29:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-25 01:29:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-25 01:29:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-25 01:29:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-25 01:29:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-25 01:29:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-05-25 01:29:25 --> Final output sent to browser
DEBUG - 2018-05-25 01:29:25 --> Total execution time: 0.5616
INFO - 2018-05-25 01:29:26 --> Config Class Initialized
INFO - 2018-05-25 01:29:26 --> Config Class Initialized
INFO - 2018-05-25 01:29:26 --> Hooks Class Initialized
INFO - 2018-05-25 01:29:26 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:29:26 --> UTF-8 Support Enabled
DEBUG - 2018-05-25 01:29:26 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:29:26 --> Utf8 Class Initialized
INFO - 2018-05-25 01:29:26 --> Utf8 Class Initialized
INFO - 2018-05-25 01:29:26 --> URI Class Initialized
INFO - 2018-05-25 01:29:26 --> Router Class Initialized
INFO - 2018-05-25 01:29:26 --> URI Class Initialized
INFO - 2018-05-25 01:29:26 --> Output Class Initialized
INFO - 2018-05-25 01:29:26 --> Security Class Initialized
INFO - 2018-05-25 01:29:26 --> Router Class Initialized
DEBUG - 2018-05-25 01:29:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:29:26 --> Output Class Initialized
INFO - 2018-05-25 01:29:26 --> Input Class Initialized
INFO - 2018-05-25 01:29:26 --> Security Class Initialized
INFO - 2018-05-25 01:29:26 --> Language Class Initialized
DEBUG - 2018-05-25 01:29:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-05-25 01:29:26 --> 404 Page Not Found: /index
INFO - 2018-05-25 01:29:26 --> Input Class Initialized
INFO - 2018-05-25 01:29:26 --> Language Class Initialized
ERROR - 2018-05-25 01:29:26 --> 404 Page Not Found: /index
INFO - 2018-05-25 01:29:26 --> Config Class Initialized
INFO - 2018-05-25 01:29:26 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:29:26 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:29:26 --> Utf8 Class Initialized
INFO - 2018-05-25 01:29:26 --> URI Class Initialized
INFO - 2018-05-25 01:29:26 --> Router Class Initialized
INFO - 2018-05-25 01:29:26 --> Output Class Initialized
INFO - 2018-05-25 01:29:26 --> Security Class Initialized
DEBUG - 2018-05-25 01:29:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:29:26 --> Input Class Initialized
INFO - 2018-05-25 01:29:26 --> Language Class Initialized
ERROR - 2018-05-25 01:29:26 --> 404 Page Not Found: /index
INFO - 2018-05-25 01:29:26 --> Config Class Initialized
INFO - 2018-05-25 01:29:26 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:29:26 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:29:26 --> Utf8 Class Initialized
INFO - 2018-05-25 01:29:26 --> URI Class Initialized
INFO - 2018-05-25 01:29:26 --> Router Class Initialized
INFO - 2018-05-25 01:29:26 --> Output Class Initialized
INFO - 2018-05-25 01:29:26 --> Security Class Initialized
DEBUG - 2018-05-25 01:29:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:29:26 --> Input Class Initialized
INFO - 2018-05-25 01:29:26 --> Language Class Initialized
ERROR - 2018-05-25 01:29:26 --> 404 Page Not Found: /index
INFO - 2018-05-25 01:29:27 --> Config Class Initialized
INFO - 2018-05-25 01:29:27 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:29:27 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:29:27 --> Utf8 Class Initialized
INFO - 2018-05-25 01:29:27 --> URI Class Initialized
INFO - 2018-05-25 01:29:27 --> Router Class Initialized
INFO - 2018-05-25 01:29:27 --> Output Class Initialized
INFO - 2018-05-25 01:29:27 --> Security Class Initialized
DEBUG - 2018-05-25 01:29:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:29:27 --> Input Class Initialized
INFO - 2018-05-25 01:29:27 --> Language Class Initialized
INFO - 2018-05-25 01:29:27 --> Language Class Initialized
INFO - 2018-05-25 01:29:27 --> Config Class Initialized
INFO - 2018-05-25 01:29:27 --> Loader Class Initialized
DEBUG - 2018-05-25 01:29:27 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-25 01:29:27 --> Helper loaded: url_helper
INFO - 2018-05-25 01:29:27 --> Helper loaded: form_helper
INFO - 2018-05-25 01:29:27 --> Helper loaded: date_helper
INFO - 2018-05-25 01:29:27 --> Helper loaded: util_helper
INFO - 2018-05-25 01:29:27 --> Helper loaded: text_helper
INFO - 2018-05-25 01:29:27 --> Helper loaded: string_helper
INFO - 2018-05-25 01:29:27 --> Database Driver Class Initialized
DEBUG - 2018-05-25 01:29:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-25 01:29:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-25 01:29:27 --> Email Class Initialized
INFO - 2018-05-25 01:29:27 --> Controller Class Initialized
DEBUG - 2018-05-25 01:29:27 --> Home MX_Controller Initialized
DEBUG - 2018-05-25 01:29:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-25 01:29:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-05-25 01:29:27 --> Final output sent to browser
DEBUG - 2018-05-25 01:29:27 --> Total execution time: 0.4010
INFO - 2018-05-25 01:29:27 --> Config Class Initialized
INFO - 2018-05-25 01:29:27 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:29:27 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:29:27 --> Utf8 Class Initialized
INFO - 2018-05-25 01:29:27 --> URI Class Initialized
INFO - 2018-05-25 01:29:28 --> Router Class Initialized
INFO - 2018-05-25 01:29:28 --> Output Class Initialized
INFO - 2018-05-25 01:29:28 --> Security Class Initialized
DEBUG - 2018-05-25 01:29:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:29:28 --> Input Class Initialized
INFO - 2018-05-25 01:29:28 --> Language Class Initialized
INFO - 2018-05-25 01:29:28 --> Language Class Initialized
INFO - 2018-05-25 01:29:28 --> Config Class Initialized
INFO - 2018-05-25 01:29:28 --> Loader Class Initialized
DEBUG - 2018-05-25 01:29:28 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-25 01:29:28 --> Helper loaded: url_helper
INFO - 2018-05-25 01:29:28 --> Helper loaded: form_helper
INFO - 2018-05-25 01:29:28 --> Helper loaded: date_helper
INFO - 2018-05-25 01:29:28 --> Helper loaded: util_helper
INFO - 2018-05-25 01:29:28 --> Helper loaded: text_helper
INFO - 2018-05-25 01:29:28 --> Helper loaded: string_helper
INFO - 2018-05-25 01:29:28 --> Database Driver Class Initialized
DEBUG - 2018-05-25 01:29:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-25 01:29:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-25 01:29:28 --> Email Class Initialized
INFO - 2018-05-25 01:29:28 --> Controller Class Initialized
DEBUG - 2018-05-25 01:29:28 --> Home MX_Controller Initialized
DEBUG - 2018-05-25 01:29:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-05-25 01:29:30 --> Config Class Initialized
INFO - 2018-05-25 01:29:30 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:29:30 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:29:30 --> Utf8 Class Initialized
INFO - 2018-05-25 01:29:30 --> URI Class Initialized
INFO - 2018-05-25 01:29:30 --> Router Class Initialized
INFO - 2018-05-25 01:29:30 --> Output Class Initialized
INFO - 2018-05-25 01:29:30 --> Security Class Initialized
DEBUG - 2018-05-25 01:29:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:29:30 --> Input Class Initialized
INFO - 2018-05-25 01:29:30 --> Language Class Initialized
INFO - 2018-05-25 01:29:30 --> Language Class Initialized
INFO - 2018-05-25 01:29:30 --> Config Class Initialized
INFO - 2018-05-25 01:29:30 --> Loader Class Initialized
DEBUG - 2018-05-25 01:29:30 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-25 01:29:30 --> Helper loaded: url_helper
INFO - 2018-05-25 01:29:30 --> Helper loaded: form_helper
INFO - 2018-05-25 01:29:30 --> Helper loaded: date_helper
INFO - 2018-05-25 01:29:30 --> Helper loaded: util_helper
INFO - 2018-05-25 01:29:30 --> Helper loaded: text_helper
INFO - 2018-05-25 01:29:30 --> Helper loaded: string_helper
INFO - 2018-05-25 01:29:30 --> Database Driver Class Initialized
DEBUG - 2018-05-25 01:29:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-25 01:29:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-25 01:29:30 --> Email Class Initialized
INFO - 2018-05-25 01:29:31 --> Controller Class Initialized
DEBUG - 2018-05-25 01:29:31 --> Home MX_Controller Initialized
DEBUG - 2018-05-25 01:29:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-25 01:29:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-05-25 01:29:31 --> Final output sent to browser
DEBUG - 2018-05-25 01:29:31 --> Total execution time: 0.4015
INFO - 2018-05-25 01:29:31 --> Config Class Initialized
INFO - 2018-05-25 01:29:31 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:29:31 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:29:31 --> Utf8 Class Initialized
INFO - 2018-05-25 01:29:31 --> URI Class Initialized
INFO - 2018-05-25 01:29:31 --> Router Class Initialized
INFO - 2018-05-25 01:29:31 --> Output Class Initialized
INFO - 2018-05-25 01:29:31 --> Security Class Initialized
DEBUG - 2018-05-25 01:29:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:29:31 --> Input Class Initialized
INFO - 2018-05-25 01:29:31 --> Language Class Initialized
INFO - 2018-05-25 01:29:31 --> Language Class Initialized
INFO - 2018-05-25 01:29:31 --> Config Class Initialized
INFO - 2018-05-25 01:29:31 --> Loader Class Initialized
DEBUG - 2018-05-25 01:29:31 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-25 01:29:31 --> Helper loaded: url_helper
INFO - 2018-05-25 01:29:31 --> Helper loaded: form_helper
INFO - 2018-05-25 01:29:31 --> Helper loaded: date_helper
INFO - 2018-05-25 01:29:31 --> Helper loaded: util_helper
INFO - 2018-05-25 01:29:31 --> Helper loaded: text_helper
INFO - 2018-05-25 01:29:31 --> Helper loaded: string_helper
INFO - 2018-05-25 01:29:31 --> Database Driver Class Initialized
DEBUG - 2018-05-25 01:29:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-25 01:29:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-25 01:29:31 --> Email Class Initialized
INFO - 2018-05-25 01:29:31 --> Controller Class Initialized
DEBUG - 2018-05-25 01:29:31 --> Home MX_Controller Initialized
DEBUG - 2018-05-25 01:29:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-05-25 01:29:32 --> Config Class Initialized
INFO - 2018-05-25 01:29:32 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:29:32 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:29:32 --> Utf8 Class Initialized
INFO - 2018-05-25 01:29:32 --> URI Class Initialized
INFO - 2018-05-25 01:29:32 --> Router Class Initialized
INFO - 2018-05-25 01:29:32 --> Output Class Initialized
INFO - 2018-05-25 01:29:32 --> Security Class Initialized
DEBUG - 2018-05-25 01:29:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:29:32 --> Input Class Initialized
INFO - 2018-05-25 01:29:32 --> Language Class Initialized
INFO - 2018-05-25 01:29:32 --> Language Class Initialized
INFO - 2018-05-25 01:29:32 --> Config Class Initialized
INFO - 2018-05-25 01:29:33 --> Loader Class Initialized
DEBUG - 2018-05-25 01:29:33 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-25 01:29:33 --> Helper loaded: url_helper
INFO - 2018-05-25 01:29:33 --> Helper loaded: form_helper
INFO - 2018-05-25 01:29:33 --> Helper loaded: date_helper
INFO - 2018-05-25 01:29:33 --> Helper loaded: util_helper
INFO - 2018-05-25 01:29:33 --> Helper loaded: text_helper
INFO - 2018-05-25 01:29:33 --> Helper loaded: string_helper
INFO - 2018-05-25 01:29:33 --> Database Driver Class Initialized
DEBUG - 2018-05-25 01:29:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-25 01:29:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-25 01:29:33 --> Email Class Initialized
INFO - 2018-05-25 01:29:33 --> Controller Class Initialized
DEBUG - 2018-05-25 01:29:33 --> Home MX_Controller Initialized
DEBUG - 2018-05-25 01:29:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-25 01:29:33 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-25 01:29:33 --> Login MX_Controller Initialized
INFO - 2018-05-25 01:29:33 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-25 01:29:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-25 01:29:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-25 01:29:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-25 01:29:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-25 01:29:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-25 01:29:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-25 01:29:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-25 01:29:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-05-25 01:29:33 --> Final output sent to browser
DEBUG - 2018-05-25 01:29:33 --> Total execution time: 0.5896
INFO - 2018-05-25 01:29:33 --> Config Class Initialized
INFO - 2018-05-25 01:29:33 --> Config Class Initialized
INFO - 2018-05-25 01:29:33 --> Hooks Class Initialized
INFO - 2018-05-25 01:29:33 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:29:33 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:29:33 --> Utf8 Class Initialized
INFO - 2018-05-25 01:29:33 --> URI Class Initialized
INFO - 2018-05-25 01:29:33 --> Router Class Initialized
INFO - 2018-05-25 01:29:33 --> Output Class Initialized
INFO - 2018-05-25 01:29:34 --> Security Class Initialized
DEBUG - 2018-05-25 01:29:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:29:34 --> Input Class Initialized
INFO - 2018-05-25 01:29:34 --> Language Class Initialized
ERROR - 2018-05-25 01:29:34 --> 404 Page Not Found: /index
DEBUG - 2018-05-25 01:29:34 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:29:34 --> Utf8 Class Initialized
INFO - 2018-05-25 01:29:34 --> URI Class Initialized
INFO - 2018-05-25 01:29:34 --> Router Class Initialized
INFO - 2018-05-25 01:29:34 --> Output Class Initialized
INFO - 2018-05-25 01:29:34 --> Security Class Initialized
DEBUG - 2018-05-25 01:29:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:29:34 --> Input Class Initialized
INFO - 2018-05-25 01:29:34 --> Config Class Initialized
INFO - 2018-05-25 01:29:34 --> Hooks Class Initialized
INFO - 2018-05-25 01:29:34 --> Language Class Initialized
DEBUG - 2018-05-25 01:29:34 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:29:34 --> Utf8 Class Initialized
ERROR - 2018-05-25 01:29:34 --> 404 Page Not Found: /index
INFO - 2018-05-25 01:29:34 --> URI Class Initialized
INFO - 2018-05-25 01:29:34 --> Router Class Initialized
INFO - 2018-05-25 01:29:34 --> Output Class Initialized
INFO - 2018-05-25 01:29:34 --> Security Class Initialized
DEBUG - 2018-05-25 01:29:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:29:34 --> Input Class Initialized
INFO - 2018-05-25 01:29:34 --> Language Class Initialized
ERROR - 2018-05-25 01:29:34 --> 404 Page Not Found: /index
INFO - 2018-05-25 01:29:34 --> Config Class Initialized
INFO - 2018-05-25 01:29:34 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:29:34 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:29:34 --> Utf8 Class Initialized
INFO - 2018-05-25 01:29:34 --> URI Class Initialized
INFO - 2018-05-25 01:29:34 --> Router Class Initialized
INFO - 2018-05-25 01:29:34 --> Output Class Initialized
INFO - 2018-05-25 01:29:34 --> Security Class Initialized
DEBUG - 2018-05-25 01:29:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:29:34 --> Input Class Initialized
INFO - 2018-05-25 01:29:34 --> Language Class Initialized
ERROR - 2018-05-25 01:29:34 --> 404 Page Not Found: /index
INFO - 2018-05-25 01:29:35 --> Config Class Initialized
INFO - 2018-05-25 01:29:35 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:29:35 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:29:35 --> Utf8 Class Initialized
INFO - 2018-05-25 01:29:35 --> URI Class Initialized
INFO - 2018-05-25 01:29:35 --> Router Class Initialized
INFO - 2018-05-25 01:29:35 --> Output Class Initialized
INFO - 2018-05-25 01:29:35 --> Security Class Initialized
DEBUG - 2018-05-25 01:29:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:29:35 --> Input Class Initialized
INFO - 2018-05-25 01:29:35 --> Language Class Initialized
INFO - 2018-05-25 01:29:35 --> Language Class Initialized
INFO - 2018-05-25 01:29:35 --> Config Class Initialized
INFO - 2018-05-25 01:29:35 --> Loader Class Initialized
DEBUG - 2018-05-25 01:29:35 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-25 01:29:35 --> Helper loaded: url_helper
INFO - 2018-05-25 01:29:35 --> Helper loaded: form_helper
INFO - 2018-05-25 01:29:35 --> Helper loaded: date_helper
INFO - 2018-05-25 01:29:35 --> Helper loaded: util_helper
INFO - 2018-05-25 01:29:35 --> Helper loaded: text_helper
INFO - 2018-05-25 01:29:35 --> Helper loaded: string_helper
INFO - 2018-05-25 01:29:35 --> Database Driver Class Initialized
DEBUG - 2018-05-25 01:29:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-25 01:29:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-25 01:29:35 --> Email Class Initialized
INFO - 2018-05-25 01:29:35 --> Controller Class Initialized
DEBUG - 2018-05-25 01:29:35 --> Home MX_Controller Initialized
DEBUG - 2018-05-25 01:29:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-25 01:29:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-05-25 01:29:35 --> Final output sent to browser
DEBUG - 2018-05-25 01:29:35 --> Total execution time: 0.4252
INFO - 2018-05-25 01:29:35 --> Config Class Initialized
INFO - 2018-05-25 01:29:35 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:29:35 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:29:35 --> Utf8 Class Initialized
INFO - 2018-05-25 01:29:35 --> URI Class Initialized
INFO - 2018-05-25 01:29:35 --> Router Class Initialized
INFO - 2018-05-25 01:29:35 --> Output Class Initialized
INFO - 2018-05-25 01:29:35 --> Security Class Initialized
DEBUG - 2018-05-25 01:29:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:29:35 --> Input Class Initialized
INFO - 2018-05-25 01:29:35 --> Language Class Initialized
INFO - 2018-05-25 01:29:35 --> Language Class Initialized
INFO - 2018-05-25 01:29:35 --> Config Class Initialized
INFO - 2018-05-25 01:29:35 --> Loader Class Initialized
DEBUG - 2018-05-25 01:29:35 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-25 01:29:35 --> Helper loaded: url_helper
INFO - 2018-05-25 01:29:35 --> Helper loaded: form_helper
INFO - 2018-05-25 01:29:35 --> Helper loaded: date_helper
INFO - 2018-05-25 01:29:35 --> Helper loaded: util_helper
INFO - 2018-05-25 01:29:35 --> Helper loaded: text_helper
INFO - 2018-05-25 01:29:35 --> Helper loaded: string_helper
INFO - 2018-05-25 01:29:35 --> Database Driver Class Initialized
DEBUG - 2018-05-25 01:29:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-25 01:29:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-25 01:29:36 --> Email Class Initialized
INFO - 2018-05-25 01:29:36 --> Controller Class Initialized
DEBUG - 2018-05-25 01:29:36 --> Home MX_Controller Initialized
DEBUG - 2018-05-25 01:29:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-05-25 01:29:38 --> Config Class Initialized
INFO - 2018-05-25 01:29:38 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:29:38 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:29:38 --> Utf8 Class Initialized
INFO - 2018-05-25 01:29:38 --> URI Class Initialized
INFO - 2018-05-25 01:29:38 --> Router Class Initialized
INFO - 2018-05-25 01:29:38 --> Output Class Initialized
INFO - 2018-05-25 01:29:38 --> Security Class Initialized
DEBUG - 2018-05-25 01:29:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:29:38 --> Input Class Initialized
INFO - 2018-05-25 01:29:38 --> Language Class Initialized
INFO - 2018-05-25 01:29:38 --> Language Class Initialized
INFO - 2018-05-25 01:29:38 --> Config Class Initialized
INFO - 2018-05-25 01:29:38 --> Loader Class Initialized
DEBUG - 2018-05-25 01:29:38 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-25 01:29:38 --> Helper loaded: url_helper
INFO - 2018-05-25 01:29:38 --> Helper loaded: form_helper
INFO - 2018-05-25 01:29:38 --> Helper loaded: date_helper
INFO - 2018-05-25 01:29:38 --> Helper loaded: util_helper
INFO - 2018-05-25 01:29:38 --> Helper loaded: text_helper
INFO - 2018-05-25 01:29:38 --> Helper loaded: string_helper
INFO - 2018-05-25 01:29:38 --> Database Driver Class Initialized
DEBUG - 2018-05-25 01:29:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-25 01:29:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-25 01:29:38 --> Email Class Initialized
INFO - 2018-05-25 01:29:38 --> Controller Class Initialized
DEBUG - 2018-05-25 01:29:38 --> Home MX_Controller Initialized
DEBUG - 2018-05-25 01:29:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-25 01:29:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-05-25 01:29:38 --> Final output sent to browser
DEBUG - 2018-05-25 01:29:38 --> Total execution time: 0.5124
INFO - 2018-05-25 01:29:38 --> Config Class Initialized
INFO - 2018-05-25 01:29:38 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:29:38 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:29:38 --> Utf8 Class Initialized
INFO - 2018-05-25 01:29:38 --> URI Class Initialized
INFO - 2018-05-25 01:29:38 --> Router Class Initialized
INFO - 2018-05-25 01:29:38 --> Output Class Initialized
INFO - 2018-05-25 01:29:38 --> Security Class Initialized
DEBUG - 2018-05-25 01:29:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:29:38 --> Input Class Initialized
INFO - 2018-05-25 01:29:38 --> Language Class Initialized
INFO - 2018-05-25 01:29:38 --> Language Class Initialized
INFO - 2018-05-25 01:29:38 --> Config Class Initialized
INFO - 2018-05-25 01:29:38 --> Loader Class Initialized
DEBUG - 2018-05-25 01:29:38 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-25 01:29:38 --> Helper loaded: url_helper
INFO - 2018-05-25 01:29:38 --> Helper loaded: form_helper
INFO - 2018-05-25 01:29:38 --> Helper loaded: date_helper
INFO - 2018-05-25 01:29:38 --> Helper loaded: util_helper
INFO - 2018-05-25 01:29:38 --> Helper loaded: text_helper
INFO - 2018-05-25 01:29:38 --> Helper loaded: string_helper
INFO - 2018-05-25 01:29:38 --> Database Driver Class Initialized
DEBUG - 2018-05-25 01:29:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-25 01:29:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-25 01:29:39 --> Email Class Initialized
INFO - 2018-05-25 01:29:39 --> Controller Class Initialized
DEBUG - 2018-05-25 01:29:39 --> Home MX_Controller Initialized
DEBUG - 2018-05-25 01:29:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-05-25 01:29:48 --> Config Class Initialized
INFO - 2018-05-25 01:29:48 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:29:48 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:29:48 --> Utf8 Class Initialized
INFO - 2018-05-25 01:29:48 --> URI Class Initialized
INFO - 2018-05-25 01:29:48 --> Router Class Initialized
INFO - 2018-05-25 01:29:48 --> Output Class Initialized
INFO - 2018-05-25 01:29:48 --> Security Class Initialized
DEBUG - 2018-05-25 01:29:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:29:48 --> Input Class Initialized
INFO - 2018-05-25 01:29:48 --> Language Class Initialized
INFO - 2018-05-25 01:29:48 --> Language Class Initialized
INFO - 2018-05-25 01:29:48 --> Config Class Initialized
INFO - 2018-05-25 01:29:48 --> Loader Class Initialized
DEBUG - 2018-05-25 01:29:48 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-25 01:29:48 --> Helper loaded: url_helper
INFO - 2018-05-25 01:29:48 --> Helper loaded: form_helper
INFO - 2018-05-25 01:29:48 --> Helper loaded: date_helper
INFO - 2018-05-25 01:29:48 --> Helper loaded: util_helper
INFO - 2018-05-25 01:29:48 --> Helper loaded: text_helper
INFO - 2018-05-25 01:29:48 --> Helper loaded: string_helper
INFO - 2018-05-25 01:29:48 --> Database Driver Class Initialized
DEBUG - 2018-05-25 01:29:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-25 01:29:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-25 01:29:48 --> Email Class Initialized
INFO - 2018-05-25 01:29:48 --> Controller Class Initialized
DEBUG - 2018-05-25 01:29:48 --> Home MX_Controller Initialized
DEBUG - 2018-05-25 01:29:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-25 01:29:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-05-25 01:29:48 --> Final output sent to browser
DEBUG - 2018-05-25 01:29:48 --> Total execution time: 0.4466
INFO - 2018-05-25 01:29:48 --> Config Class Initialized
INFO - 2018-05-25 01:29:48 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:29:48 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:29:48 --> Utf8 Class Initialized
INFO - 2018-05-25 01:29:48 --> URI Class Initialized
INFO - 2018-05-25 01:29:48 --> Router Class Initialized
INFO - 2018-05-25 01:29:48 --> Output Class Initialized
INFO - 2018-05-25 01:29:48 --> Security Class Initialized
DEBUG - 2018-05-25 01:29:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:29:48 --> Input Class Initialized
INFO - 2018-05-25 01:29:48 --> Language Class Initialized
INFO - 2018-05-25 01:29:48 --> Language Class Initialized
INFO - 2018-05-25 01:29:48 --> Config Class Initialized
INFO - 2018-05-25 01:29:48 --> Loader Class Initialized
DEBUG - 2018-05-25 01:29:48 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-25 01:29:48 --> Helper loaded: url_helper
INFO - 2018-05-25 01:29:48 --> Helper loaded: form_helper
INFO - 2018-05-25 01:29:48 --> Helper loaded: date_helper
INFO - 2018-05-25 01:29:48 --> Helper loaded: util_helper
INFO - 2018-05-25 01:29:48 --> Helper loaded: text_helper
INFO - 2018-05-25 01:29:48 --> Helper loaded: string_helper
INFO - 2018-05-25 01:29:48 --> Database Driver Class Initialized
DEBUG - 2018-05-25 01:29:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-25 01:29:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-25 01:29:48 --> Email Class Initialized
INFO - 2018-05-25 01:29:48 --> Controller Class Initialized
DEBUG - 2018-05-25 01:29:48 --> Home MX_Controller Initialized
DEBUG - 2018-05-25 01:29:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-05-25 01:29:49 --> Config Class Initialized
INFO - 2018-05-25 01:29:49 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:29:49 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:29:49 --> Utf8 Class Initialized
INFO - 2018-05-25 01:29:49 --> URI Class Initialized
INFO - 2018-05-25 01:29:49 --> Router Class Initialized
INFO - 2018-05-25 01:29:49 --> Output Class Initialized
INFO - 2018-05-25 01:29:49 --> Security Class Initialized
DEBUG - 2018-05-25 01:29:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:29:49 --> Input Class Initialized
INFO - 2018-05-25 01:29:49 --> Language Class Initialized
INFO - 2018-05-25 01:29:49 --> Language Class Initialized
INFO - 2018-05-25 01:29:49 --> Config Class Initialized
INFO - 2018-05-25 01:29:49 --> Loader Class Initialized
DEBUG - 2018-05-25 01:29:49 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-25 01:29:49 --> Helper loaded: url_helper
INFO - 2018-05-25 01:29:49 --> Helper loaded: form_helper
INFO - 2018-05-25 01:29:49 --> Helper loaded: date_helper
INFO - 2018-05-25 01:29:49 --> Helper loaded: util_helper
INFO - 2018-05-25 01:29:49 --> Helper loaded: text_helper
INFO - 2018-05-25 01:29:49 --> Helper loaded: string_helper
INFO - 2018-05-25 01:29:49 --> Database Driver Class Initialized
DEBUG - 2018-05-25 01:29:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-25 01:29:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-25 01:29:49 --> Email Class Initialized
INFO - 2018-05-25 01:29:49 --> Controller Class Initialized
DEBUG - 2018-05-25 01:29:49 --> Home MX_Controller Initialized
DEBUG - 2018-05-25 01:29:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-25 01:29:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-05-25 01:29:49 --> Final output sent to browser
DEBUG - 2018-05-25 01:29:49 --> Total execution time: 0.3925
INFO - 2018-05-25 01:29:49 --> Config Class Initialized
INFO - 2018-05-25 01:29:49 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:29:49 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:29:49 --> Utf8 Class Initialized
INFO - 2018-05-25 01:29:49 --> URI Class Initialized
INFO - 2018-05-25 01:29:49 --> Router Class Initialized
INFO - 2018-05-25 01:29:49 --> Output Class Initialized
INFO - 2018-05-25 01:29:49 --> Security Class Initialized
DEBUG - 2018-05-25 01:29:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:29:49 --> Input Class Initialized
INFO - 2018-05-25 01:29:49 --> Language Class Initialized
INFO - 2018-05-25 01:29:49 --> Language Class Initialized
INFO - 2018-05-25 01:29:49 --> Config Class Initialized
INFO - 2018-05-25 01:29:49 --> Loader Class Initialized
DEBUG - 2018-05-25 01:29:49 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-25 01:29:49 --> Helper loaded: url_helper
INFO - 2018-05-25 01:29:49 --> Helper loaded: form_helper
INFO - 2018-05-25 01:29:49 --> Helper loaded: date_helper
INFO - 2018-05-25 01:29:49 --> Helper loaded: util_helper
INFO - 2018-05-25 01:29:49 --> Helper loaded: text_helper
INFO - 2018-05-25 01:29:49 --> Helper loaded: string_helper
INFO - 2018-05-25 01:29:49 --> Database Driver Class Initialized
DEBUG - 2018-05-25 01:29:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-25 01:29:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-25 01:29:49 --> Email Class Initialized
INFO - 2018-05-25 01:29:49 --> Controller Class Initialized
DEBUG - 2018-05-25 01:29:49 --> Home MX_Controller Initialized
DEBUG - 2018-05-25 01:29:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-05-25 01:29:52 --> Config Class Initialized
INFO - 2018-05-25 01:29:52 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:29:52 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:29:52 --> Utf8 Class Initialized
INFO - 2018-05-25 01:29:52 --> URI Class Initialized
INFO - 2018-05-25 01:29:52 --> Router Class Initialized
INFO - 2018-05-25 01:29:52 --> Output Class Initialized
INFO - 2018-05-25 01:29:52 --> Security Class Initialized
DEBUG - 2018-05-25 01:29:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:29:52 --> Input Class Initialized
INFO - 2018-05-25 01:29:52 --> Language Class Initialized
INFO - 2018-05-25 01:29:52 --> Language Class Initialized
INFO - 2018-05-25 01:29:52 --> Config Class Initialized
INFO - 2018-05-25 01:29:52 --> Loader Class Initialized
DEBUG - 2018-05-25 01:29:52 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-25 01:29:52 --> Helper loaded: url_helper
INFO - 2018-05-25 01:29:52 --> Helper loaded: form_helper
INFO - 2018-05-25 01:29:52 --> Helper loaded: date_helper
INFO - 2018-05-25 01:29:52 --> Helper loaded: util_helper
INFO - 2018-05-25 01:29:52 --> Helper loaded: text_helper
INFO - 2018-05-25 01:29:52 --> Helper loaded: string_helper
INFO - 2018-05-25 01:29:52 --> Database Driver Class Initialized
DEBUG - 2018-05-25 01:29:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-25 01:29:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-25 01:29:52 --> Email Class Initialized
INFO - 2018-05-25 01:29:52 --> Controller Class Initialized
DEBUG - 2018-05-25 01:29:52 --> Home MX_Controller Initialized
DEBUG - 2018-05-25 01:29:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-25 01:29:52 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-25 01:29:52 --> Login MX_Controller Initialized
INFO - 2018-05-25 01:29:52 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-25 01:29:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-25 01:29:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-25 01:29:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-25 01:29:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-25 01:29:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-25 01:29:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-25 01:29:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-25 01:29:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-05-25 01:29:52 --> Final output sent to browser
DEBUG - 2018-05-25 01:29:52 --> Total execution time: 0.5243
INFO - 2018-05-25 01:29:52 --> Config Class Initialized
INFO - 2018-05-25 01:29:52 --> Config Class Initialized
INFO - 2018-05-25 01:29:52 --> Hooks Class Initialized
INFO - 2018-05-25 01:29:52 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:29:52 --> UTF-8 Support Enabled
DEBUG - 2018-05-25 01:29:52 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:29:52 --> Utf8 Class Initialized
INFO - 2018-05-25 01:29:52 --> Utf8 Class Initialized
INFO - 2018-05-25 01:29:52 --> URI Class Initialized
INFO - 2018-05-25 01:29:52 --> URI Class Initialized
INFO - 2018-05-25 01:29:52 --> Router Class Initialized
INFO - 2018-05-25 01:29:52 --> Router Class Initialized
INFO - 2018-05-25 01:29:52 --> Output Class Initialized
INFO - 2018-05-25 01:29:52 --> Output Class Initialized
INFO - 2018-05-25 01:29:53 --> Security Class Initialized
DEBUG - 2018-05-25 01:29:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:29:53 --> Input Class Initialized
INFO - 2018-05-25 01:29:53 --> Language Class Initialized
ERROR - 2018-05-25 01:29:53 --> 404 Page Not Found: /index
INFO - 2018-05-25 01:29:53 --> Security Class Initialized
DEBUG - 2018-05-25 01:29:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:29:53 --> Input Class Initialized
INFO - 2018-05-25 01:29:53 --> Language Class Initialized
ERROR - 2018-05-25 01:29:53 --> 404 Page Not Found: /index
INFO - 2018-05-25 01:29:53 --> Config Class Initialized
INFO - 2018-05-25 01:29:53 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:29:53 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:29:53 --> Utf8 Class Initialized
INFO - 2018-05-25 01:29:53 --> URI Class Initialized
INFO - 2018-05-25 01:29:53 --> Router Class Initialized
INFO - 2018-05-25 01:29:53 --> Output Class Initialized
INFO - 2018-05-25 01:29:53 --> Security Class Initialized
DEBUG - 2018-05-25 01:29:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:29:53 --> Input Class Initialized
INFO - 2018-05-25 01:29:53 --> Language Class Initialized
ERROR - 2018-05-25 01:29:53 --> 404 Page Not Found: /index
INFO - 2018-05-25 01:29:53 --> Config Class Initialized
INFO - 2018-05-25 01:29:53 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:29:53 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:29:53 --> Utf8 Class Initialized
INFO - 2018-05-25 01:29:53 --> URI Class Initialized
INFO - 2018-05-25 01:29:53 --> Router Class Initialized
INFO - 2018-05-25 01:29:53 --> Output Class Initialized
INFO - 2018-05-25 01:29:53 --> Security Class Initialized
DEBUG - 2018-05-25 01:29:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:29:53 --> Input Class Initialized
INFO - 2018-05-25 01:29:53 --> Language Class Initialized
ERROR - 2018-05-25 01:29:53 --> 404 Page Not Found: /index
INFO - 2018-05-25 01:29:54 --> Config Class Initialized
INFO - 2018-05-25 01:29:54 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:29:55 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:29:55 --> Utf8 Class Initialized
INFO - 2018-05-25 01:29:55 --> URI Class Initialized
INFO - 2018-05-25 01:29:55 --> Router Class Initialized
INFO - 2018-05-25 01:29:55 --> Output Class Initialized
INFO - 2018-05-25 01:29:55 --> Security Class Initialized
DEBUG - 2018-05-25 01:29:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:29:55 --> Input Class Initialized
INFO - 2018-05-25 01:29:55 --> Language Class Initialized
INFO - 2018-05-25 01:29:55 --> Language Class Initialized
INFO - 2018-05-25 01:29:55 --> Config Class Initialized
INFO - 2018-05-25 01:29:55 --> Loader Class Initialized
DEBUG - 2018-05-25 01:29:55 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-25 01:29:55 --> Helper loaded: url_helper
INFO - 2018-05-25 01:29:55 --> Helper loaded: form_helper
INFO - 2018-05-25 01:29:55 --> Helper loaded: date_helper
INFO - 2018-05-25 01:29:55 --> Helper loaded: util_helper
INFO - 2018-05-25 01:29:55 --> Helper loaded: text_helper
INFO - 2018-05-25 01:29:55 --> Helper loaded: string_helper
INFO - 2018-05-25 01:29:55 --> Database Driver Class Initialized
DEBUG - 2018-05-25 01:29:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-25 01:29:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-25 01:29:55 --> Email Class Initialized
INFO - 2018-05-25 01:29:55 --> Controller Class Initialized
DEBUG - 2018-05-25 01:29:55 --> Home MX_Controller Initialized
DEBUG - 2018-05-25 01:29:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-25 01:29:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-05-25 01:29:55 --> Final output sent to browser
DEBUG - 2018-05-25 01:29:55 --> Total execution time: 0.4050
INFO - 2018-05-25 01:29:55 --> Config Class Initialized
INFO - 2018-05-25 01:29:55 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:29:55 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:29:55 --> Utf8 Class Initialized
INFO - 2018-05-25 01:29:55 --> URI Class Initialized
INFO - 2018-05-25 01:29:55 --> Router Class Initialized
INFO - 2018-05-25 01:29:55 --> Output Class Initialized
INFO - 2018-05-25 01:29:55 --> Security Class Initialized
DEBUG - 2018-05-25 01:29:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:29:55 --> Input Class Initialized
INFO - 2018-05-25 01:29:55 --> Language Class Initialized
INFO - 2018-05-25 01:29:55 --> Language Class Initialized
INFO - 2018-05-25 01:29:55 --> Config Class Initialized
INFO - 2018-05-25 01:29:55 --> Loader Class Initialized
DEBUG - 2018-05-25 01:29:55 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-25 01:29:55 --> Helper loaded: url_helper
INFO - 2018-05-25 01:29:55 --> Helper loaded: form_helper
INFO - 2018-05-25 01:29:55 --> Helper loaded: date_helper
INFO - 2018-05-25 01:29:55 --> Helper loaded: util_helper
INFO - 2018-05-25 01:29:55 --> Helper loaded: text_helper
INFO - 2018-05-25 01:29:55 --> Helper loaded: string_helper
INFO - 2018-05-25 01:29:55 --> Database Driver Class Initialized
DEBUG - 2018-05-25 01:29:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-25 01:29:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-25 01:29:55 --> Email Class Initialized
INFO - 2018-05-25 01:29:55 --> Controller Class Initialized
DEBUG - 2018-05-25 01:29:55 --> Home MX_Controller Initialized
DEBUG - 2018-05-25 01:29:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-05-25 01:29:57 --> Config Class Initialized
INFO - 2018-05-25 01:29:57 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:29:57 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:29:57 --> Utf8 Class Initialized
INFO - 2018-05-25 01:29:57 --> URI Class Initialized
INFO - 2018-05-25 01:29:57 --> Router Class Initialized
INFO - 2018-05-25 01:29:57 --> Output Class Initialized
INFO - 2018-05-25 01:29:57 --> Security Class Initialized
DEBUG - 2018-05-25 01:29:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:29:57 --> Input Class Initialized
INFO - 2018-05-25 01:29:58 --> Language Class Initialized
INFO - 2018-05-25 01:29:58 --> Language Class Initialized
INFO - 2018-05-25 01:29:58 --> Config Class Initialized
INFO - 2018-05-25 01:29:58 --> Loader Class Initialized
DEBUG - 2018-05-25 01:29:58 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-25 01:29:58 --> Helper loaded: url_helper
INFO - 2018-05-25 01:29:58 --> Helper loaded: form_helper
INFO - 2018-05-25 01:29:58 --> Helper loaded: date_helper
INFO - 2018-05-25 01:29:58 --> Helper loaded: util_helper
INFO - 2018-05-25 01:29:58 --> Helper loaded: text_helper
INFO - 2018-05-25 01:29:58 --> Helper loaded: string_helper
INFO - 2018-05-25 01:29:58 --> Database Driver Class Initialized
DEBUG - 2018-05-25 01:29:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-25 01:29:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-25 01:29:58 --> Email Class Initialized
INFO - 2018-05-25 01:29:58 --> Controller Class Initialized
DEBUG - 2018-05-25 01:29:58 --> Home MX_Controller Initialized
DEBUG - 2018-05-25 01:29:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-25 01:29:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-05-25 01:29:58 --> Final output sent to browser
DEBUG - 2018-05-25 01:29:58 --> Total execution time: 0.4929
INFO - 2018-05-25 01:29:58 --> Config Class Initialized
INFO - 2018-05-25 01:29:58 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:29:58 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:29:58 --> Utf8 Class Initialized
INFO - 2018-05-25 01:29:58 --> URI Class Initialized
INFO - 2018-05-25 01:29:58 --> Router Class Initialized
INFO - 2018-05-25 01:29:58 --> Output Class Initialized
INFO - 2018-05-25 01:29:58 --> Security Class Initialized
DEBUG - 2018-05-25 01:29:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:29:58 --> Input Class Initialized
INFO - 2018-05-25 01:29:58 --> Language Class Initialized
INFO - 2018-05-25 01:29:58 --> Language Class Initialized
INFO - 2018-05-25 01:29:58 --> Config Class Initialized
INFO - 2018-05-25 01:29:58 --> Loader Class Initialized
DEBUG - 2018-05-25 01:29:58 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-25 01:29:58 --> Helper loaded: url_helper
INFO - 2018-05-25 01:29:58 --> Helper loaded: form_helper
INFO - 2018-05-25 01:29:58 --> Helper loaded: date_helper
INFO - 2018-05-25 01:29:58 --> Helper loaded: util_helper
INFO - 2018-05-25 01:29:58 --> Helper loaded: text_helper
INFO - 2018-05-25 01:29:58 --> Helper loaded: string_helper
INFO - 2018-05-25 01:29:58 --> Database Driver Class Initialized
DEBUG - 2018-05-25 01:29:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-25 01:29:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-25 01:29:58 --> Email Class Initialized
INFO - 2018-05-25 01:29:58 --> Controller Class Initialized
DEBUG - 2018-05-25 01:29:58 --> Home MX_Controller Initialized
DEBUG - 2018-05-25 01:29:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-05-25 01:47:33 --> Config Class Initialized
INFO - 2018-05-25 01:47:33 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:47:33 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:47:33 --> Utf8 Class Initialized
INFO - 2018-05-25 01:47:33 --> URI Class Initialized
INFO - 2018-05-25 01:47:33 --> Router Class Initialized
INFO - 2018-05-25 01:47:33 --> Output Class Initialized
INFO - 2018-05-25 01:47:33 --> Security Class Initialized
DEBUG - 2018-05-25 01:47:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:47:33 --> Input Class Initialized
INFO - 2018-05-25 01:47:33 --> Language Class Initialized
INFO - 2018-05-25 01:47:34 --> Language Class Initialized
INFO - 2018-05-25 01:47:34 --> Config Class Initialized
INFO - 2018-05-25 01:47:34 --> Loader Class Initialized
DEBUG - 2018-05-25 01:47:34 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-25 01:47:34 --> Helper loaded: url_helper
INFO - 2018-05-25 01:47:34 --> Helper loaded: form_helper
INFO - 2018-05-25 01:47:34 --> Helper loaded: date_helper
INFO - 2018-05-25 01:47:34 --> Helper loaded: util_helper
INFO - 2018-05-25 01:47:34 --> Helper loaded: text_helper
INFO - 2018-05-25 01:47:34 --> Helper loaded: string_helper
INFO - 2018-05-25 01:47:34 --> Database Driver Class Initialized
DEBUG - 2018-05-25 01:47:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-25 01:47:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-25 01:47:34 --> Email Class Initialized
INFO - 2018-05-25 01:47:34 --> Controller Class Initialized
DEBUG - 2018-05-25 01:47:34 --> Home MX_Controller Initialized
DEBUG - 2018-05-25 01:47:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-25 01:47:34 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-25 01:47:34 --> Login MX_Controller Initialized
INFO - 2018-05-25 01:47:34 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-25 01:47:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-25 01:47:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
ERROR - 2018-05-25 01:47:34 --> Severity: Notice --> Undefined variable: res_ls E:\xampp\htdocs\consulting\application\modules\home\models\Home_model.php 51
DEBUG - 2018-05-25 01:47:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-25 01:47:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-25 01:47:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
ERROR - 2018-05-25 01:47:34 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable E:\xampp\htdocs\consulting\application\modules\home\views\course.php 121
DEBUG - 2018-05-25 01:47:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-25 01:47:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-25 01:47:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-05-25 01:47:35 --> Final output sent to browser
DEBUG - 2018-05-25 01:47:35 --> Total execution time: 1.4805
INFO - 2018-05-25 01:47:35 --> Config Class Initialized
INFO - 2018-05-25 01:47:35 --> Config Class Initialized
INFO - 2018-05-25 01:47:35 --> Hooks Class Initialized
INFO - 2018-05-25 01:47:35 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:47:35 --> UTF-8 Support Enabled
DEBUG - 2018-05-25 01:47:35 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:47:35 --> Utf8 Class Initialized
INFO - 2018-05-25 01:47:35 --> Utf8 Class Initialized
INFO - 2018-05-25 01:47:35 --> URI Class Initialized
INFO - 2018-05-25 01:47:35 --> URI Class Initialized
INFO - 2018-05-25 01:47:35 --> Router Class Initialized
INFO - 2018-05-25 01:47:35 --> Router Class Initialized
INFO - 2018-05-25 01:47:35 --> Output Class Initialized
INFO - 2018-05-25 01:47:35 --> Output Class Initialized
INFO - 2018-05-25 01:47:35 --> Security Class Initialized
DEBUG - 2018-05-25 01:47:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:47:35 --> Security Class Initialized
INFO - 2018-05-25 01:47:35 --> Input Class Initialized
DEBUG - 2018-05-25 01:47:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:47:35 --> Language Class Initialized
INFO - 2018-05-25 01:47:35 --> Input Class Initialized
ERROR - 2018-05-25 01:47:35 --> 404 Page Not Found: /index
INFO - 2018-05-25 01:47:35 --> Language Class Initialized
INFO - 2018-05-25 01:47:35 --> Config Class Initialized
INFO - 2018-05-25 01:47:35 --> Hooks Class Initialized
ERROR - 2018-05-25 01:47:35 --> 404 Page Not Found: /index
DEBUG - 2018-05-25 01:47:35 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:47:35 --> Utf8 Class Initialized
INFO - 2018-05-25 01:47:35 --> URI Class Initialized
INFO - 2018-05-25 01:47:35 --> Router Class Initialized
INFO - 2018-05-25 01:47:35 --> Output Class Initialized
INFO - 2018-05-25 01:47:35 --> Security Class Initialized
DEBUG - 2018-05-25 01:47:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:47:35 --> Input Class Initialized
INFO - 2018-05-25 01:47:35 --> Language Class Initialized
ERROR - 2018-05-25 01:47:35 --> 404 Page Not Found: /index
INFO - 2018-05-25 01:47:35 --> Config Class Initialized
INFO - 2018-05-25 01:47:35 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:47:35 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:47:35 --> Utf8 Class Initialized
INFO - 2018-05-25 01:47:35 --> URI Class Initialized
INFO - 2018-05-25 01:47:35 --> Router Class Initialized
INFO - 2018-05-25 01:47:35 --> Output Class Initialized
INFO - 2018-05-25 01:47:35 --> Security Class Initialized
DEBUG - 2018-05-25 01:47:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:47:35 --> Input Class Initialized
INFO - 2018-05-25 01:47:35 --> Language Class Initialized
ERROR - 2018-05-25 01:47:35 --> 404 Page Not Found: /index
INFO - 2018-05-25 01:47:57 --> Config Class Initialized
INFO - 2018-05-25 01:47:57 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:47:57 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:47:57 --> Utf8 Class Initialized
INFO - 2018-05-25 01:47:57 --> URI Class Initialized
INFO - 2018-05-25 01:47:57 --> Router Class Initialized
INFO - 2018-05-25 01:47:57 --> Output Class Initialized
INFO - 2018-05-25 01:47:57 --> Security Class Initialized
DEBUG - 2018-05-25 01:47:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:47:57 --> Input Class Initialized
INFO - 2018-05-25 01:47:57 --> Language Class Initialized
INFO - 2018-05-25 01:47:57 --> Language Class Initialized
INFO - 2018-05-25 01:47:57 --> Config Class Initialized
INFO - 2018-05-25 01:47:57 --> Loader Class Initialized
DEBUG - 2018-05-25 01:47:57 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-25 01:47:57 --> Helper loaded: url_helper
INFO - 2018-05-25 01:47:57 --> Helper loaded: form_helper
INFO - 2018-05-25 01:47:57 --> Helper loaded: date_helper
INFO - 2018-05-25 01:47:57 --> Helper loaded: util_helper
INFO - 2018-05-25 01:47:57 --> Helper loaded: text_helper
INFO - 2018-05-25 01:47:57 --> Helper loaded: string_helper
INFO - 2018-05-25 01:47:57 --> Database Driver Class Initialized
DEBUG - 2018-05-25 01:47:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-25 01:47:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-25 01:47:57 --> Email Class Initialized
INFO - 2018-05-25 01:47:57 --> Controller Class Initialized
DEBUG - 2018-05-25 01:47:57 --> Home MX_Controller Initialized
DEBUG - 2018-05-25 01:47:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-25 01:47:57 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-25 01:47:57 --> Login MX_Controller Initialized
INFO - 2018-05-25 01:47:57 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-25 01:47:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-25 01:47:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-25 01:47:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-25 01:47:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-25 01:47:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
ERROR - 2018-05-25 01:47:57 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable E:\xampp\htdocs\consulting\application\modules\home\views\course.php 121
ERROR - 2018-05-25 01:47:57 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\consulting\application\modules\home\views\course.php 121
DEBUG - 2018-05-25 01:47:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-25 01:47:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-25 01:47:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-05-25 01:47:57 --> Final output sent to browser
DEBUG - 2018-05-25 01:47:57 --> Total execution time: 0.5378
INFO - 2018-05-25 01:47:58 --> Config Class Initialized
INFO - 2018-05-25 01:47:58 --> Config Class Initialized
INFO - 2018-05-25 01:47:58 --> Hooks Class Initialized
INFO - 2018-05-25 01:47:58 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:47:58 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:47:58 --> Utf8 Class Initialized
INFO - 2018-05-25 01:47:58 --> URI Class Initialized
DEBUG - 2018-05-25 01:47:58 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:47:58 --> Utf8 Class Initialized
INFO - 2018-05-25 01:47:58 --> Router Class Initialized
INFO - 2018-05-25 01:47:58 --> URI Class Initialized
INFO - 2018-05-25 01:47:58 --> Output Class Initialized
INFO - 2018-05-25 01:47:58 --> Router Class Initialized
INFO - 2018-05-25 01:47:58 --> Output Class Initialized
INFO - 2018-05-25 01:47:58 --> Security Class Initialized
INFO - 2018-05-25 01:47:58 --> Security Class Initialized
DEBUG - 2018-05-25 01:47:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-05-25 01:47:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:47:58 --> Input Class Initialized
INFO - 2018-05-25 01:47:58 --> Input Class Initialized
INFO - 2018-05-25 01:47:58 --> Language Class Initialized
INFO - 2018-05-25 01:47:58 --> Language Class Initialized
ERROR - 2018-05-25 01:47:58 --> 404 Page Not Found: /index
ERROR - 2018-05-25 01:47:58 --> 404 Page Not Found: /index
INFO - 2018-05-25 01:47:58 --> Config Class Initialized
INFO - 2018-05-25 01:47:58 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:47:58 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:47:58 --> Utf8 Class Initialized
INFO - 2018-05-25 01:47:58 --> URI Class Initialized
INFO - 2018-05-25 01:47:58 --> Router Class Initialized
INFO - 2018-05-25 01:47:58 --> Output Class Initialized
INFO - 2018-05-25 01:47:58 --> Security Class Initialized
DEBUG - 2018-05-25 01:47:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:47:58 --> Input Class Initialized
INFO - 2018-05-25 01:47:58 --> Language Class Initialized
ERROR - 2018-05-25 01:47:58 --> 404 Page Not Found: /index
INFO - 2018-05-25 01:47:58 --> Config Class Initialized
INFO - 2018-05-25 01:47:58 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:47:58 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:47:58 --> Utf8 Class Initialized
INFO - 2018-05-25 01:47:58 --> URI Class Initialized
INFO - 2018-05-25 01:47:58 --> Router Class Initialized
INFO - 2018-05-25 01:47:58 --> Output Class Initialized
INFO - 2018-05-25 01:47:58 --> Security Class Initialized
DEBUG - 2018-05-25 01:47:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:47:58 --> Input Class Initialized
INFO - 2018-05-25 01:47:59 --> Language Class Initialized
ERROR - 2018-05-25 01:47:59 --> 404 Page Not Found: /index
INFO - 2018-05-25 01:47:59 --> Config Class Initialized
INFO - 2018-05-25 01:47:59 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:47:59 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:47:59 --> Utf8 Class Initialized
INFO - 2018-05-25 01:47:59 --> URI Class Initialized
INFO - 2018-05-25 01:47:59 --> Router Class Initialized
INFO - 2018-05-25 01:47:59 --> Output Class Initialized
INFO - 2018-05-25 01:47:59 --> Security Class Initialized
DEBUG - 2018-05-25 01:47:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:47:59 --> Input Class Initialized
INFO - 2018-05-25 01:47:59 --> Language Class Initialized
ERROR - 2018-05-25 01:47:59 --> 404 Page Not Found: /index
INFO - 2018-05-25 01:47:59 --> Config Class Initialized
INFO - 2018-05-25 01:47:59 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:47:59 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:47:59 --> Utf8 Class Initialized
INFO - 2018-05-25 01:47:59 --> URI Class Initialized
INFO - 2018-05-25 01:47:59 --> Router Class Initialized
INFO - 2018-05-25 01:47:59 --> Output Class Initialized
INFO - 2018-05-25 01:47:59 --> Security Class Initialized
DEBUG - 2018-05-25 01:47:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:47:59 --> Input Class Initialized
INFO - 2018-05-25 01:47:59 --> Language Class Initialized
ERROR - 2018-05-25 01:47:59 --> 404 Page Not Found: /index
INFO - 2018-05-25 01:47:59 --> Config Class Initialized
INFO - 2018-05-25 01:47:59 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:47:59 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:47:59 --> Utf8 Class Initialized
INFO - 2018-05-25 01:47:59 --> URI Class Initialized
INFO - 2018-05-25 01:47:59 --> Router Class Initialized
INFO - 2018-05-25 01:47:59 --> Output Class Initialized
INFO - 2018-05-25 01:47:59 --> Security Class Initialized
DEBUG - 2018-05-25 01:47:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:47:59 --> Input Class Initialized
INFO - 2018-05-25 01:47:59 --> Language Class Initialized
ERROR - 2018-05-25 01:47:59 --> 404 Page Not Found: /index
INFO - 2018-05-25 01:48:18 --> Config Class Initialized
INFO - 2018-05-25 01:48:18 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:48:18 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:48:18 --> Utf8 Class Initialized
INFO - 2018-05-25 01:48:18 --> URI Class Initialized
INFO - 2018-05-25 01:48:18 --> Router Class Initialized
INFO - 2018-05-25 01:48:18 --> Output Class Initialized
INFO - 2018-05-25 01:48:18 --> Security Class Initialized
DEBUG - 2018-05-25 01:48:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:48:18 --> Input Class Initialized
INFO - 2018-05-25 01:48:18 --> Language Class Initialized
INFO - 2018-05-25 01:48:18 --> Language Class Initialized
INFO - 2018-05-25 01:48:18 --> Config Class Initialized
INFO - 2018-05-25 01:48:18 --> Loader Class Initialized
DEBUG - 2018-05-25 01:48:18 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-25 01:48:18 --> Helper loaded: url_helper
INFO - 2018-05-25 01:48:18 --> Helper loaded: form_helper
INFO - 2018-05-25 01:48:18 --> Helper loaded: date_helper
INFO - 2018-05-25 01:48:18 --> Helper loaded: util_helper
INFO - 2018-05-25 01:48:18 --> Helper loaded: text_helper
INFO - 2018-05-25 01:48:18 --> Helper loaded: string_helper
INFO - 2018-05-25 01:48:18 --> Database Driver Class Initialized
DEBUG - 2018-05-25 01:48:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-25 01:48:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-25 01:48:18 --> Email Class Initialized
INFO - 2018-05-25 01:48:18 --> Controller Class Initialized
DEBUG - 2018-05-25 01:48:18 --> Home MX_Controller Initialized
DEBUG - 2018-05-25 01:48:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-25 01:48:18 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-25 01:48:18 --> Login MX_Controller Initialized
INFO - 2018-05-25 01:48:18 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-25 01:48:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-25 01:48:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-25 01:48:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-25 01:48:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-25 01:48:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-25 01:48:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-25 01:48:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-25 01:48:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-05-25 01:48:18 --> Final output sent to browser
DEBUG - 2018-05-25 01:48:18 --> Total execution time: 0.5520
INFO - 2018-05-25 01:48:19 --> Config Class Initialized
INFO - 2018-05-25 01:48:19 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:48:19 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:48:19 --> Config Class Initialized
INFO - 2018-05-25 01:48:19 --> Utf8 Class Initialized
INFO - 2018-05-25 01:48:19 --> URI Class Initialized
INFO - 2018-05-25 01:48:19 --> Router Class Initialized
INFO - 2018-05-25 01:48:19 --> Hooks Class Initialized
INFO - 2018-05-25 01:48:19 --> Output Class Initialized
DEBUG - 2018-05-25 01:48:19 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:48:19 --> Utf8 Class Initialized
INFO - 2018-05-25 01:48:19 --> URI Class Initialized
INFO - 2018-05-25 01:48:19 --> Security Class Initialized
INFO - 2018-05-25 01:48:19 --> Router Class Initialized
DEBUG - 2018-05-25 01:48:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:48:19 --> Output Class Initialized
INFO - 2018-05-25 01:48:19 --> Input Class Initialized
INFO - 2018-05-25 01:48:19 --> Security Class Initialized
INFO - 2018-05-25 01:48:19 --> Language Class Initialized
DEBUG - 2018-05-25 01:48:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-05-25 01:48:19 --> 404 Page Not Found: /index
INFO - 2018-05-25 01:48:19 --> Input Class Initialized
INFO - 2018-05-25 01:48:19 --> Language Class Initialized
ERROR - 2018-05-25 01:48:19 --> 404 Page Not Found: /index
INFO - 2018-05-25 01:48:19 --> Config Class Initialized
INFO - 2018-05-25 01:48:19 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:48:19 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:48:19 --> Utf8 Class Initialized
INFO - 2018-05-25 01:48:19 --> URI Class Initialized
INFO - 2018-05-25 01:48:19 --> Router Class Initialized
INFO - 2018-05-25 01:48:19 --> Output Class Initialized
INFO - 2018-05-25 01:48:19 --> Security Class Initialized
DEBUG - 2018-05-25 01:48:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:48:19 --> Input Class Initialized
INFO - 2018-05-25 01:48:19 --> Language Class Initialized
ERROR - 2018-05-25 01:48:19 --> 404 Page Not Found: /index
INFO - 2018-05-25 01:48:19 --> Config Class Initialized
INFO - 2018-05-25 01:48:19 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:48:19 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:48:19 --> Utf8 Class Initialized
INFO - 2018-05-25 01:48:19 --> URI Class Initialized
INFO - 2018-05-25 01:48:19 --> Router Class Initialized
INFO - 2018-05-25 01:48:19 --> Output Class Initialized
INFO - 2018-05-25 01:48:19 --> Security Class Initialized
DEBUG - 2018-05-25 01:48:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:48:19 --> Input Class Initialized
INFO - 2018-05-25 01:48:19 --> Language Class Initialized
ERROR - 2018-05-25 01:48:19 --> 404 Page Not Found: /index
INFO - 2018-05-25 01:48:19 --> Config Class Initialized
INFO - 2018-05-25 01:48:19 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:48:19 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:48:19 --> Utf8 Class Initialized
INFO - 2018-05-25 01:48:19 --> URI Class Initialized
INFO - 2018-05-25 01:48:19 --> Router Class Initialized
INFO - 2018-05-25 01:48:19 --> Output Class Initialized
INFO - 2018-05-25 01:48:19 --> Security Class Initialized
DEBUG - 2018-05-25 01:48:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:48:19 --> Input Class Initialized
INFO - 2018-05-25 01:48:19 --> Language Class Initialized
ERROR - 2018-05-25 01:48:19 --> 404 Page Not Found: /index
INFO - 2018-05-25 01:48:19 --> Config Class Initialized
INFO - 2018-05-25 01:48:19 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:48:19 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:48:19 --> Utf8 Class Initialized
INFO - 2018-05-25 01:48:19 --> URI Class Initialized
INFO - 2018-05-25 01:48:19 --> Router Class Initialized
INFO - 2018-05-25 01:48:19 --> Output Class Initialized
INFO - 2018-05-25 01:48:20 --> Security Class Initialized
DEBUG - 2018-05-25 01:48:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:48:20 --> Input Class Initialized
INFO - 2018-05-25 01:48:20 --> Language Class Initialized
ERROR - 2018-05-25 01:48:20 --> 404 Page Not Found: /index
INFO - 2018-05-25 01:48:20 --> Config Class Initialized
INFO - 2018-05-25 01:48:20 --> Hooks Class Initialized
DEBUG - 2018-05-25 01:48:20 --> UTF-8 Support Enabled
INFO - 2018-05-25 01:48:20 --> Utf8 Class Initialized
INFO - 2018-05-25 01:48:20 --> URI Class Initialized
INFO - 2018-05-25 01:48:20 --> Router Class Initialized
INFO - 2018-05-25 01:48:20 --> Output Class Initialized
INFO - 2018-05-25 01:48:20 --> Security Class Initialized
DEBUG - 2018-05-25 01:48:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-25 01:48:20 --> Input Class Initialized
INFO - 2018-05-25 01:48:20 --> Language Class Initialized
ERROR - 2018-05-25 01:48:20 --> 404 Page Not Found: /index
