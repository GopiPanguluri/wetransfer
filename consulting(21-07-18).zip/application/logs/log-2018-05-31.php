<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-05-31 23:50:31 --> Config Class Initialized
INFO - 2018-05-31 23:50:31 --> Hooks Class Initialized
DEBUG - 2018-05-31 23:50:31 --> UTF-8 Support Enabled
INFO - 2018-05-31 23:50:31 --> Utf8 Class Initialized
INFO - 2018-05-31 23:50:31 --> URI Class Initialized
DEBUG - 2018-05-31 23:50:32 --> No URI present. Default controller set.
INFO - 2018-05-31 23:50:32 --> Router Class Initialized
INFO - 2018-05-31 23:50:32 --> Output Class Initialized
INFO - 2018-05-31 23:50:32 --> Security Class Initialized
DEBUG - 2018-05-31 23:50:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-31 23:50:32 --> Input Class Initialized
INFO - 2018-05-31 23:50:32 --> Language Class Initialized
INFO - 2018-05-31 23:50:32 --> Language Class Initialized
INFO - 2018-05-31 23:50:32 --> Config Class Initialized
INFO - 2018-05-31 23:50:32 --> Loader Class Initialized
DEBUG - 2018-05-31 23:50:32 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-31 23:50:32 --> Helper loaded: url_helper
INFO - 2018-05-31 23:50:32 --> Helper loaded: form_helper
INFO - 2018-05-31 23:50:32 --> Helper loaded: date_helper
INFO - 2018-05-31 23:50:32 --> Helper loaded: util_helper
INFO - 2018-05-31 23:50:32 --> Helper loaded: text_helper
INFO - 2018-05-31 23:50:32 --> Helper loaded: string_helper
INFO - 2018-05-31 23:50:32 --> Database Driver Class Initialized
DEBUG - 2018-05-31 23:50:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-31 23:50:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-31 23:50:32 --> Email Class Initialized
INFO - 2018-05-31 23:50:32 --> Controller Class Initialized
DEBUG - 2018-05-31 23:50:32 --> Home MX_Controller Initialized
DEBUG - 2018-05-31 23:50:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-31 23:50:32 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-31 23:50:32 --> Login MX_Controller Initialized
INFO - 2018-05-31 23:50:32 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-31 23:50:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-31 23:50:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-31 23:50:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-05-31 23:50:34 --> Config Class Initialized
INFO - 2018-05-31 23:50:34 --> Hooks Class Initialized
DEBUG - 2018-05-31 23:50:34 --> UTF-8 Support Enabled
INFO - 2018-05-31 23:50:34 --> Utf8 Class Initialized
INFO - 2018-05-31 23:50:34 --> URI Class Initialized
DEBUG - 2018-05-31 23:50:34 --> No URI present. Default controller set.
INFO - 2018-05-31 23:50:34 --> Router Class Initialized
INFO - 2018-05-31 23:50:34 --> Output Class Initialized
INFO - 2018-05-31 23:50:34 --> Security Class Initialized
DEBUG - 2018-05-31 23:50:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-31 23:50:34 --> Input Class Initialized
INFO - 2018-05-31 23:50:34 --> Language Class Initialized
INFO - 2018-05-31 23:50:34 --> Language Class Initialized
INFO - 2018-05-31 23:50:34 --> Config Class Initialized
INFO - 2018-05-31 23:50:34 --> Loader Class Initialized
DEBUG - 2018-05-31 23:50:34 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-31 23:50:34 --> Helper loaded: url_helper
INFO - 2018-05-31 23:50:34 --> Helper loaded: form_helper
INFO - 2018-05-31 23:50:34 --> Helper loaded: date_helper
INFO - 2018-05-31 23:50:34 --> Helper loaded: util_helper
INFO - 2018-05-31 23:50:34 --> Helper loaded: text_helper
INFO - 2018-05-31 23:50:34 --> Helper loaded: string_helper
INFO - 2018-05-31 23:50:34 --> Database Driver Class Initialized
DEBUG - 2018-05-31 23:50:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-31 23:50:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-31 23:50:34 --> Email Class Initialized
INFO - 2018-05-31 23:50:34 --> Controller Class Initialized
DEBUG - 2018-05-31 23:50:34 --> Home MX_Controller Initialized
DEBUG - 2018-05-31 23:50:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-31 23:50:34 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-31 23:50:34 --> Login MX_Controller Initialized
INFO - 2018-05-31 23:50:34 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-31 23:50:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-31 23:50:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-31 23:50:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-05-31 23:50:38 --> Config Class Initialized
INFO - 2018-05-31 23:50:38 --> Hooks Class Initialized
DEBUG - 2018-05-31 23:50:38 --> UTF-8 Support Enabled
INFO - 2018-05-31 23:50:38 --> Utf8 Class Initialized
INFO - 2018-05-31 23:50:38 --> URI Class Initialized
INFO - 2018-05-31 23:50:38 --> Router Class Initialized
INFO - 2018-05-31 23:50:38 --> Output Class Initialized
INFO - 2018-05-31 23:50:38 --> Security Class Initialized
DEBUG - 2018-05-31 23:50:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-31 23:50:38 --> Input Class Initialized
INFO - 2018-05-31 23:50:38 --> Language Class Initialized
INFO - 2018-05-31 23:50:38 --> Language Class Initialized
INFO - 2018-05-31 23:50:38 --> Config Class Initialized
INFO - 2018-05-31 23:50:38 --> Loader Class Initialized
DEBUG - 2018-05-31 23:50:38 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-31 23:50:38 --> Helper loaded: url_helper
INFO - 2018-05-31 23:50:38 --> Helper loaded: form_helper
INFO - 2018-05-31 23:50:38 --> Helper loaded: date_helper
INFO - 2018-05-31 23:50:38 --> Helper loaded: util_helper
INFO - 2018-05-31 23:50:38 --> Helper loaded: text_helper
INFO - 2018-05-31 23:50:38 --> Helper loaded: string_helper
INFO - 2018-05-31 23:50:38 --> Database Driver Class Initialized
DEBUG - 2018-05-31 23:50:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-31 23:50:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-31 23:50:38 --> Email Class Initialized
INFO - 2018-05-31 23:50:38 --> Controller Class Initialized
DEBUG - 2018-05-31 23:50:38 --> Home MX_Controller Initialized
DEBUG - 2018-05-31 23:50:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-31 23:50:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/register.php
INFO - 2018-05-31 23:50:38 --> Final output sent to browser
DEBUG - 2018-05-31 23:50:38 --> Total execution time: 0.2899
INFO - 2018-05-31 23:50:41 --> Config Class Initialized
INFO - 2018-05-31 23:50:41 --> Hooks Class Initialized
DEBUG - 2018-05-31 23:50:41 --> UTF-8 Support Enabled
INFO - 2018-05-31 23:50:41 --> Utf8 Class Initialized
INFO - 2018-05-31 23:50:41 --> URI Class Initialized
INFO - 2018-05-31 23:50:41 --> Router Class Initialized
INFO - 2018-05-31 23:50:41 --> Output Class Initialized
INFO - 2018-05-31 23:50:41 --> Security Class Initialized
DEBUG - 2018-05-31 23:50:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-31 23:50:41 --> Input Class Initialized
INFO - 2018-05-31 23:50:41 --> Language Class Initialized
INFO - 2018-05-31 23:50:41 --> Language Class Initialized
INFO - 2018-05-31 23:50:41 --> Config Class Initialized
INFO - 2018-05-31 23:50:41 --> Loader Class Initialized
DEBUG - 2018-05-31 23:50:41 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-31 23:50:41 --> Helper loaded: url_helper
INFO - 2018-05-31 23:50:41 --> Helper loaded: form_helper
INFO - 2018-05-31 23:50:41 --> Helper loaded: date_helper
INFO - 2018-05-31 23:50:41 --> Helper loaded: util_helper
INFO - 2018-05-31 23:50:41 --> Helper loaded: text_helper
INFO - 2018-05-31 23:50:41 --> Helper loaded: string_helper
INFO - 2018-05-31 23:50:41 --> Database Driver Class Initialized
DEBUG - 2018-05-31 23:50:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-31 23:50:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-31 23:50:41 --> Email Class Initialized
INFO - 2018-05-31 23:50:41 --> Controller Class Initialized
DEBUG - 2018-05-31 23:50:41 --> Home MX_Controller Initialized
DEBUG - 2018-05-31 23:50:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-31 23:50:41 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-31 23:50:41 --> Login MX_Controller Initialized
INFO - 2018-05-31 23:50:41 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-31 23:50:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-31 23:50:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-31 23:50:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-05-31 23:50:43 --> Config Class Initialized
INFO - 2018-05-31 23:50:43 --> Hooks Class Initialized
DEBUG - 2018-05-31 23:50:43 --> UTF-8 Support Enabled
INFO - 2018-05-31 23:50:43 --> Utf8 Class Initialized
INFO - 2018-05-31 23:50:43 --> URI Class Initialized
INFO - 2018-05-31 23:50:43 --> Router Class Initialized
INFO - 2018-05-31 23:50:43 --> Output Class Initialized
INFO - 2018-05-31 23:50:43 --> Security Class Initialized
DEBUG - 2018-05-31 23:50:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-31 23:50:43 --> Input Class Initialized
INFO - 2018-05-31 23:50:43 --> Language Class Initialized
INFO - 2018-05-31 23:50:43 --> Language Class Initialized
INFO - 2018-05-31 23:50:43 --> Config Class Initialized
INFO - 2018-05-31 23:50:43 --> Loader Class Initialized
DEBUG - 2018-05-31 23:50:43 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-31 23:50:43 --> Helper loaded: url_helper
INFO - 2018-05-31 23:50:43 --> Helper loaded: form_helper
INFO - 2018-05-31 23:50:43 --> Helper loaded: date_helper
INFO - 2018-05-31 23:50:43 --> Helper loaded: util_helper
INFO - 2018-05-31 23:50:43 --> Helper loaded: text_helper
INFO - 2018-05-31 23:50:43 --> Helper loaded: string_helper
INFO - 2018-05-31 23:50:43 --> Database Driver Class Initialized
DEBUG - 2018-05-31 23:50:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-31 23:50:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-31 23:50:43 --> Email Class Initialized
INFO - 2018-05-31 23:50:43 --> Controller Class Initialized
DEBUG - 2018-05-31 23:50:43 --> Login MX_Controller Initialized
INFO - 2018-05-31 23:50:43 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-31 23:50:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-31 23:50:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-31 23:50:43 --> Email starts for gopipanguluri123@gmail.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-05-31 23:50:43 --> Login status gopipanguluri123@gmail.com - failure
INFO - 2018-05-31 23:50:43 --> Final output sent to browser
DEBUG - 2018-05-31 23:50:43 --> Total execution time: 0.2933
INFO - 2018-05-31 23:50:50 --> Config Class Initialized
INFO - 2018-05-31 23:50:50 --> Hooks Class Initialized
DEBUG - 2018-05-31 23:50:50 --> UTF-8 Support Enabled
INFO - 2018-05-31 23:50:50 --> Utf8 Class Initialized
INFO - 2018-05-31 23:50:50 --> URI Class Initialized
INFO - 2018-05-31 23:50:50 --> Router Class Initialized
INFO - 2018-05-31 23:50:50 --> Output Class Initialized
INFO - 2018-05-31 23:50:50 --> Security Class Initialized
DEBUG - 2018-05-31 23:50:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-31 23:50:50 --> Input Class Initialized
INFO - 2018-05-31 23:50:50 --> Language Class Initialized
INFO - 2018-05-31 23:50:50 --> Language Class Initialized
INFO - 2018-05-31 23:50:50 --> Config Class Initialized
INFO - 2018-05-31 23:50:50 --> Loader Class Initialized
DEBUG - 2018-05-31 23:50:50 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-31 23:50:50 --> Helper loaded: url_helper
INFO - 2018-05-31 23:50:50 --> Helper loaded: form_helper
INFO - 2018-05-31 23:50:50 --> Helper loaded: date_helper
INFO - 2018-05-31 23:50:50 --> Helper loaded: util_helper
INFO - 2018-05-31 23:50:50 --> Helper loaded: text_helper
INFO - 2018-05-31 23:50:50 --> Helper loaded: string_helper
INFO - 2018-05-31 23:50:50 --> Database Driver Class Initialized
DEBUG - 2018-05-31 23:50:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-31 23:50:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-31 23:50:50 --> Email Class Initialized
INFO - 2018-05-31 23:50:50 --> Controller Class Initialized
DEBUG - 2018-05-31 23:50:50 --> Login MX_Controller Initialized
INFO - 2018-05-31 23:50:50 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-31 23:50:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-31 23:50:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-05-31 23:50:50 --> Email starts for user@colin.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-05-31 23:50:50 --> User session created for 4
INFO - 2018-05-31 23:50:50 --> Login status user@colin.com - success
INFO - 2018-05-31 23:50:50 --> Final output sent to browser
DEBUG - 2018-05-31 23:50:50 --> Total execution time: 0.3454
INFO - 2018-05-31 23:50:50 --> Config Class Initialized
INFO - 2018-05-31 23:50:50 --> Hooks Class Initialized
DEBUG - 2018-05-31 23:50:50 --> UTF-8 Support Enabled
INFO - 2018-05-31 23:50:50 --> Utf8 Class Initialized
INFO - 2018-05-31 23:50:50 --> URI Class Initialized
INFO - 2018-05-31 23:50:50 --> Router Class Initialized
INFO - 2018-05-31 23:50:50 --> Output Class Initialized
INFO - 2018-05-31 23:50:50 --> Security Class Initialized
DEBUG - 2018-05-31 23:50:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-31 23:50:50 --> Input Class Initialized
INFO - 2018-05-31 23:50:50 --> Language Class Initialized
INFO - 2018-05-31 23:50:50 --> Language Class Initialized
INFO - 2018-05-31 23:50:50 --> Config Class Initialized
INFO - 2018-05-31 23:50:50 --> Loader Class Initialized
DEBUG - 2018-05-31 23:50:50 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-31 23:50:51 --> Helper loaded: url_helper
INFO - 2018-05-31 23:50:51 --> Helper loaded: form_helper
INFO - 2018-05-31 23:50:51 --> Helper loaded: date_helper
INFO - 2018-05-31 23:50:51 --> Helper loaded: util_helper
INFO - 2018-05-31 23:50:51 --> Helper loaded: text_helper
INFO - 2018-05-31 23:50:51 --> Helper loaded: string_helper
INFO - 2018-05-31 23:50:51 --> Database Driver Class Initialized
DEBUG - 2018-05-31 23:50:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-31 23:50:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-31 23:50:51 --> Email Class Initialized
INFO - 2018-05-31 23:50:51 --> Controller Class Initialized
DEBUG - 2018-05-31 23:50:51 --> Home MX_Controller Initialized
DEBUG - 2018-05-31 23:50:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-31 23:50:51 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-31 23:50:51 --> Login MX_Controller Initialized
INFO - 2018-05-31 23:50:51 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-31 23:50:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-31 23:50:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-31 23:50:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-31 23:50:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-31 23:50:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-31 23:50:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-31 23:50:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-31 23:50:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-05-31 23:50:51 --> Final output sent to browser
DEBUG - 2018-05-31 23:50:51 --> Total execution time: 0.5562
INFO - 2018-05-31 23:50:51 --> Config Class Initialized
INFO - 2018-05-31 23:50:51 --> Hooks Class Initialized
DEBUG - 2018-05-31 23:50:51 --> UTF-8 Support Enabled
INFO - 2018-05-31 23:50:51 --> Utf8 Class Initialized
INFO - 2018-05-31 23:50:51 --> URI Class Initialized
INFO - 2018-05-31 23:50:51 --> Router Class Initialized
INFO - 2018-05-31 23:50:51 --> Output Class Initialized
INFO - 2018-05-31 23:50:51 --> Security Class Initialized
DEBUG - 2018-05-31 23:50:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-31 23:50:51 --> Input Class Initialized
INFO - 2018-05-31 23:50:51 --> Language Class Initialized
ERROR - 2018-05-31 23:50:52 --> 404 Page Not Found: /index
INFO - 2018-05-31 23:50:52 --> Config Class Initialized
INFO - 2018-05-31 23:50:52 --> Hooks Class Initialized
DEBUG - 2018-05-31 23:50:52 --> UTF-8 Support Enabled
INFO - 2018-05-31 23:50:52 --> Utf8 Class Initialized
INFO - 2018-05-31 23:50:52 --> URI Class Initialized
INFO - 2018-05-31 23:50:52 --> Router Class Initialized
INFO - 2018-05-31 23:50:52 --> Output Class Initialized
INFO - 2018-05-31 23:50:52 --> Security Class Initialized
DEBUG - 2018-05-31 23:50:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-31 23:50:52 --> Input Class Initialized
INFO - 2018-05-31 23:50:52 --> Language Class Initialized
ERROR - 2018-05-31 23:50:52 --> 404 Page Not Found: /index
INFO - 2018-05-31 23:50:52 --> Config Class Initialized
INFO - 2018-05-31 23:50:52 --> Hooks Class Initialized
DEBUG - 2018-05-31 23:50:52 --> UTF-8 Support Enabled
INFO - 2018-05-31 23:50:52 --> Utf8 Class Initialized
INFO - 2018-05-31 23:50:52 --> URI Class Initialized
INFO - 2018-05-31 23:50:52 --> Router Class Initialized
INFO - 2018-05-31 23:50:52 --> Output Class Initialized
INFO - 2018-05-31 23:50:52 --> Security Class Initialized
DEBUG - 2018-05-31 23:50:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-31 23:50:52 --> Input Class Initialized
INFO - 2018-05-31 23:50:52 --> Language Class Initialized
ERROR - 2018-05-31 23:50:52 --> 404 Page Not Found: /index
INFO - 2018-05-31 23:50:52 --> Config Class Initialized
INFO - 2018-05-31 23:50:52 --> Hooks Class Initialized
DEBUG - 2018-05-31 23:50:52 --> UTF-8 Support Enabled
INFO - 2018-05-31 23:50:52 --> Utf8 Class Initialized
INFO - 2018-05-31 23:50:52 --> URI Class Initialized
INFO - 2018-05-31 23:50:52 --> Router Class Initialized
INFO - 2018-05-31 23:50:52 --> Output Class Initialized
INFO - 2018-05-31 23:50:52 --> Security Class Initialized
DEBUG - 2018-05-31 23:50:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-31 23:50:52 --> Input Class Initialized
INFO - 2018-05-31 23:50:52 --> Language Class Initialized
ERROR - 2018-05-31 23:50:52 --> 404 Page Not Found: /index
INFO - 2018-05-31 23:50:52 --> Config Class Initialized
INFO - 2018-05-31 23:50:52 --> Hooks Class Initialized
DEBUG - 2018-05-31 23:50:52 --> UTF-8 Support Enabled
INFO - 2018-05-31 23:50:52 --> Utf8 Class Initialized
INFO - 2018-05-31 23:50:52 --> URI Class Initialized
INFO - 2018-05-31 23:50:52 --> Router Class Initialized
INFO - 2018-05-31 23:50:52 --> Output Class Initialized
INFO - 2018-05-31 23:50:52 --> Security Class Initialized
DEBUG - 2018-05-31 23:50:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-31 23:50:52 --> Input Class Initialized
INFO - 2018-05-31 23:50:52 --> Language Class Initialized
ERROR - 2018-05-31 23:50:52 --> 404 Page Not Found: /index
INFO - 2018-05-31 23:50:52 --> Config Class Initialized
INFO - 2018-05-31 23:50:52 --> Hooks Class Initialized
DEBUG - 2018-05-31 23:50:52 --> UTF-8 Support Enabled
INFO - 2018-05-31 23:50:52 --> Utf8 Class Initialized
INFO - 2018-05-31 23:50:52 --> URI Class Initialized
INFO - 2018-05-31 23:50:53 --> Router Class Initialized
INFO - 2018-05-31 23:50:53 --> Output Class Initialized
INFO - 2018-05-31 23:50:53 --> Security Class Initialized
DEBUG - 2018-05-31 23:50:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-31 23:50:53 --> Input Class Initialized
INFO - 2018-05-31 23:50:53 --> Language Class Initialized
ERROR - 2018-05-31 23:50:53 --> 404 Page Not Found: /index
INFO - 2018-05-31 23:51:04 --> Config Class Initialized
INFO - 2018-05-31 23:51:04 --> Hooks Class Initialized
DEBUG - 2018-05-31 23:51:04 --> UTF-8 Support Enabled
INFO - 2018-05-31 23:51:04 --> Utf8 Class Initialized
INFO - 2018-05-31 23:51:04 --> URI Class Initialized
INFO - 2018-05-31 23:51:04 --> Router Class Initialized
INFO - 2018-05-31 23:51:04 --> Output Class Initialized
INFO - 2018-05-31 23:51:04 --> Security Class Initialized
DEBUG - 2018-05-31 23:51:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-31 23:51:04 --> Input Class Initialized
INFO - 2018-05-31 23:51:04 --> Language Class Initialized
INFO - 2018-05-31 23:51:04 --> Language Class Initialized
INFO - 2018-05-31 23:51:04 --> Config Class Initialized
INFO - 2018-05-31 23:51:04 --> Loader Class Initialized
DEBUG - 2018-05-31 23:51:04 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-31 23:51:04 --> Helper loaded: url_helper
INFO - 2018-05-31 23:51:04 --> Helper loaded: form_helper
INFO - 2018-05-31 23:51:04 --> Helper loaded: date_helper
INFO - 2018-05-31 23:51:04 --> Helper loaded: util_helper
INFO - 2018-05-31 23:51:04 --> Helper loaded: text_helper
INFO - 2018-05-31 23:51:04 --> Helper loaded: string_helper
INFO - 2018-05-31 23:51:04 --> Database Driver Class Initialized
DEBUG - 2018-05-31 23:51:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-31 23:51:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-31 23:51:04 --> Email Class Initialized
INFO - 2018-05-31 23:51:04 --> Controller Class Initialized
DEBUG - 2018-05-31 23:51:04 --> Home MX_Controller Initialized
DEBUG - 2018-05-31 23:51:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-31 23:51:05 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-05-31 23:51:05 --> Login MX_Controller Initialized
INFO - 2018-05-31 23:51:05 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-05-31 23:51:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-05-31 23:51:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-05-31 23:51:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-05-31 23:51:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-05-31 23:51:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-05-31 23:51:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-05-31 23:51:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-05-31 23:51:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-05-31 23:51:05 --> Final output sent to browser
DEBUG - 2018-05-31 23:51:05 --> Total execution time: 0.4359
INFO - 2018-05-31 23:51:05 --> Config Class Initialized
INFO - 2018-05-31 23:51:05 --> Config Class Initialized
INFO - 2018-05-31 23:51:05 --> Hooks Class Initialized
INFO - 2018-05-31 23:51:05 --> Hooks Class Initialized
DEBUG - 2018-05-31 23:51:05 --> UTF-8 Support Enabled
DEBUG - 2018-05-31 23:51:05 --> UTF-8 Support Enabled
INFO - 2018-05-31 23:51:05 --> Utf8 Class Initialized
INFO - 2018-05-31 23:51:05 --> Utf8 Class Initialized
INFO - 2018-05-31 23:51:05 --> URI Class Initialized
INFO - 2018-05-31 23:51:05 --> URI Class Initialized
INFO - 2018-05-31 23:51:05 --> Router Class Initialized
INFO - 2018-05-31 23:51:05 --> Output Class Initialized
INFO - 2018-05-31 23:51:05 --> Router Class Initialized
INFO - 2018-05-31 23:51:05 --> Security Class Initialized
DEBUG - 2018-05-31 23:51:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-31 23:51:05 --> Input Class Initialized
INFO - 2018-05-31 23:51:05 --> Language Class Initialized
ERROR - 2018-05-31 23:51:05 --> 404 Page Not Found: /index
INFO - 2018-05-31 23:51:05 --> Config Class Initialized
INFO - 2018-05-31 23:51:05 --> Hooks Class Initialized
DEBUG - 2018-05-31 23:51:05 --> UTF-8 Support Enabled
INFO - 2018-05-31 23:51:05 --> Output Class Initialized
INFO - 2018-05-31 23:51:05 --> Utf8 Class Initialized
INFO - 2018-05-31 23:51:05 --> URI Class Initialized
INFO - 2018-05-31 23:51:05 --> Security Class Initialized
DEBUG - 2018-05-31 23:51:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-31 23:51:05 --> Router Class Initialized
INFO - 2018-05-31 23:51:05 --> Input Class Initialized
INFO - 2018-05-31 23:51:05 --> Output Class Initialized
INFO - 2018-05-31 23:51:05 --> Language Class Initialized
INFO - 2018-05-31 23:51:05 --> Security Class Initialized
ERROR - 2018-05-31 23:51:05 --> 404 Page Not Found: /index
DEBUG - 2018-05-31 23:51:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-31 23:51:05 --> Input Class Initialized
INFO - 2018-05-31 23:51:05 --> Language Class Initialized
ERROR - 2018-05-31 23:51:05 --> 404 Page Not Found: /index
INFO - 2018-05-31 23:51:05 --> Config Class Initialized
INFO - 2018-05-31 23:51:05 --> Hooks Class Initialized
DEBUG - 2018-05-31 23:51:05 --> UTF-8 Support Enabled
INFO - 2018-05-31 23:51:05 --> Utf8 Class Initialized
INFO - 2018-05-31 23:51:05 --> URI Class Initialized
INFO - 2018-05-31 23:51:05 --> Router Class Initialized
INFO - 2018-05-31 23:51:05 --> Output Class Initialized
INFO - 2018-05-31 23:51:05 --> Security Class Initialized
DEBUG - 2018-05-31 23:51:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-31 23:51:06 --> Input Class Initialized
INFO - 2018-05-31 23:51:06 --> Language Class Initialized
ERROR - 2018-05-31 23:51:06 --> 404 Page Not Found: /index
INFO - 2018-05-31 23:51:07 --> Config Class Initialized
INFO - 2018-05-31 23:51:07 --> Hooks Class Initialized
DEBUG - 2018-05-31 23:51:07 --> UTF-8 Support Enabled
INFO - 2018-05-31 23:51:07 --> Utf8 Class Initialized
INFO - 2018-05-31 23:51:07 --> URI Class Initialized
INFO - 2018-05-31 23:51:07 --> Router Class Initialized
INFO - 2018-05-31 23:51:07 --> Output Class Initialized
INFO - 2018-05-31 23:51:07 --> Security Class Initialized
DEBUG - 2018-05-31 23:51:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-31 23:51:07 --> Input Class Initialized
INFO - 2018-05-31 23:51:07 --> Language Class Initialized
INFO - 2018-05-31 23:51:07 --> Language Class Initialized
INFO - 2018-05-31 23:51:07 --> Config Class Initialized
INFO - 2018-05-31 23:51:07 --> Loader Class Initialized
DEBUG - 2018-05-31 23:51:07 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-31 23:51:07 --> Helper loaded: url_helper
INFO - 2018-05-31 23:51:07 --> Helper loaded: form_helper
INFO - 2018-05-31 23:51:07 --> Helper loaded: date_helper
INFO - 2018-05-31 23:51:07 --> Helper loaded: util_helper
INFO - 2018-05-31 23:51:07 --> Helper loaded: text_helper
INFO - 2018-05-31 23:51:07 --> Helper loaded: string_helper
INFO - 2018-05-31 23:51:07 --> Database Driver Class Initialized
DEBUG - 2018-05-31 23:51:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-31 23:51:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-31 23:51:07 --> Email Class Initialized
INFO - 2018-05-31 23:51:07 --> Controller Class Initialized
DEBUG - 2018-05-31 23:51:07 --> Home MX_Controller Initialized
DEBUG - 2018-05-31 23:51:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-05-31 23:51:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-05-31 23:51:07 --> Final output sent to browser
DEBUG - 2018-05-31 23:51:07 --> Total execution time: 0.2948
INFO - 2018-05-31 23:51:07 --> Config Class Initialized
INFO - 2018-05-31 23:51:07 --> Hooks Class Initialized
DEBUG - 2018-05-31 23:51:07 --> UTF-8 Support Enabled
INFO - 2018-05-31 23:51:07 --> Utf8 Class Initialized
INFO - 2018-05-31 23:51:07 --> URI Class Initialized
INFO - 2018-05-31 23:51:07 --> Router Class Initialized
INFO - 2018-05-31 23:51:07 --> Output Class Initialized
INFO - 2018-05-31 23:51:07 --> Security Class Initialized
DEBUG - 2018-05-31 23:51:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-31 23:51:07 --> Input Class Initialized
INFO - 2018-05-31 23:51:07 --> Language Class Initialized
INFO - 2018-05-31 23:51:07 --> Language Class Initialized
INFO - 2018-05-31 23:51:07 --> Config Class Initialized
INFO - 2018-05-31 23:51:07 --> Loader Class Initialized
DEBUG - 2018-05-31 23:51:07 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-05-31 23:51:07 --> Helper loaded: url_helper
INFO - 2018-05-31 23:51:07 --> Helper loaded: form_helper
INFO - 2018-05-31 23:51:07 --> Helper loaded: date_helper
INFO - 2018-05-31 23:51:07 --> Helper loaded: util_helper
INFO - 2018-05-31 23:51:07 --> Helper loaded: text_helper
INFO - 2018-05-31 23:51:07 --> Helper loaded: string_helper
INFO - 2018-05-31 23:51:07 --> Database Driver Class Initialized
DEBUG - 2018-05-31 23:51:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-31 23:51:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-31 23:51:07 --> Email Class Initialized
INFO - 2018-05-31 23:51:07 --> Controller Class Initialized
DEBUG - 2018-05-31 23:51:07 --> Home MX_Controller Initialized
DEBUG - 2018-05-31 23:51:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
