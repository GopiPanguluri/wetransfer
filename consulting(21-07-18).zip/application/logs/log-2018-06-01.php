<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-06-01 00:47:14 --> Config Class Initialized
INFO - 2018-06-01 00:47:14 --> Hooks Class Initialized
DEBUG - 2018-06-01 00:47:14 --> UTF-8 Support Enabled
INFO - 2018-06-01 00:47:14 --> Utf8 Class Initialized
INFO - 2018-06-01 00:47:14 --> URI Class Initialized
INFO - 2018-06-01 00:47:14 --> Router Class Initialized
INFO - 2018-06-01 00:47:14 --> Output Class Initialized
INFO - 2018-06-01 00:47:14 --> Security Class Initialized
DEBUG - 2018-06-01 00:47:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 00:47:14 --> Input Class Initialized
INFO - 2018-06-01 00:47:14 --> Language Class Initialized
INFO - 2018-06-01 00:47:14 --> Language Class Initialized
INFO - 2018-06-01 00:47:14 --> Config Class Initialized
INFO - 2018-06-01 00:47:14 --> Loader Class Initialized
DEBUG - 2018-06-01 00:47:14 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-01 00:47:14 --> Helper loaded: url_helper
INFO - 2018-06-01 00:47:14 --> Helper loaded: form_helper
INFO - 2018-06-01 00:47:14 --> Helper loaded: date_helper
INFO - 2018-06-01 00:47:14 --> Helper loaded: util_helper
INFO - 2018-06-01 00:47:14 --> Helper loaded: text_helper
INFO - 2018-06-01 00:47:14 --> Helper loaded: string_helper
INFO - 2018-06-01 00:47:14 --> Database Driver Class Initialized
DEBUG - 2018-06-01 00:47:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-01 00:47:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-01 00:47:14 --> Email Class Initialized
INFO - 2018-06-01 00:47:14 --> Controller Class Initialized
DEBUG - 2018-06-01 00:47:14 --> Home MX_Controller Initialized
DEBUG - 2018-06-01 00:47:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-01 00:47:14 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-01 00:47:14 --> Login MX_Controller Initialized
INFO - 2018-06-01 00:47:14 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-01 00:47:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-01 00:47:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-01 00:47:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-01 00:47:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-01 00:47:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-01 00:47:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-01 00:47:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-01 00:47:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-06-01 00:47:14 --> Final output sent to browser
DEBUG - 2018-06-01 00:47:14 --> Total execution time: 0.4584
INFO - 2018-06-01 00:47:15 --> Config Class Initialized
INFO - 2018-06-01 00:47:15 --> Hooks Class Initialized
INFO - 2018-06-01 00:47:15 --> Config Class Initialized
DEBUG - 2018-06-01 00:47:15 --> UTF-8 Support Enabled
INFO - 2018-06-01 00:47:15 --> Hooks Class Initialized
DEBUG - 2018-06-01 00:47:15 --> UTF-8 Support Enabled
INFO - 2018-06-01 00:47:15 --> Utf8 Class Initialized
INFO - 2018-06-01 00:47:15 --> Utf8 Class Initialized
INFO - 2018-06-01 00:47:15 --> URI Class Initialized
INFO - 2018-06-01 00:47:15 --> Router Class Initialized
INFO - 2018-06-01 00:47:15 --> Output Class Initialized
INFO - 2018-06-01 00:47:15 --> Security Class Initialized
DEBUG - 2018-06-01 00:47:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 00:47:15 --> URI Class Initialized
INFO - 2018-06-01 00:47:15 --> Input Class Initialized
INFO - 2018-06-01 00:47:15 --> Language Class Initialized
ERROR - 2018-06-01 00:47:15 --> 404 Page Not Found: /index
INFO - 2018-06-01 00:47:15 --> Router Class Initialized
INFO - 2018-06-01 00:47:15 --> Output Class Initialized
INFO - 2018-06-01 00:47:15 --> Security Class Initialized
INFO - 2018-06-01 00:47:15 --> Config Class Initialized
INFO - 2018-06-01 00:47:15 --> Hooks Class Initialized
DEBUG - 2018-06-01 00:47:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-06-01 00:47:15 --> UTF-8 Support Enabled
INFO - 2018-06-01 00:47:15 --> Utf8 Class Initialized
INFO - 2018-06-01 00:47:15 --> URI Class Initialized
INFO - 2018-06-01 00:47:15 --> Router Class Initialized
INFO - 2018-06-01 00:47:15 --> Output Class Initialized
INFO - 2018-06-01 00:47:15 --> Security Class Initialized
DEBUG - 2018-06-01 00:47:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 00:47:15 --> Input Class Initialized
INFO - 2018-06-01 00:47:15 --> Input Class Initialized
INFO - 2018-06-01 00:47:15 --> Language Class Initialized
INFO - 2018-06-01 00:47:15 --> Language Class Initialized
ERROR - 2018-06-01 00:47:15 --> 404 Page Not Found: /index
ERROR - 2018-06-01 00:47:15 --> 404 Page Not Found: /index
INFO - 2018-06-01 00:47:16 --> Config Class Initialized
INFO - 2018-06-01 00:47:16 --> Hooks Class Initialized
DEBUG - 2018-06-01 00:47:16 --> UTF-8 Support Enabled
INFO - 2018-06-01 00:47:16 --> Utf8 Class Initialized
INFO - 2018-06-01 00:47:16 --> URI Class Initialized
INFO - 2018-06-01 00:47:16 --> Router Class Initialized
INFO - 2018-06-01 00:47:16 --> Output Class Initialized
INFO - 2018-06-01 00:47:16 --> Security Class Initialized
DEBUG - 2018-06-01 00:47:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 00:47:16 --> Input Class Initialized
INFO - 2018-06-01 00:47:16 --> Language Class Initialized
ERROR - 2018-06-01 00:47:16 --> 404 Page Not Found: /index
INFO - 2018-06-01 00:47:16 --> Config Class Initialized
INFO - 2018-06-01 00:47:16 --> Hooks Class Initialized
DEBUG - 2018-06-01 00:47:16 --> UTF-8 Support Enabled
INFO - 2018-06-01 00:47:16 --> Utf8 Class Initialized
INFO - 2018-06-01 00:47:16 --> URI Class Initialized
INFO - 2018-06-01 00:47:16 --> Router Class Initialized
INFO - 2018-06-01 00:47:16 --> Output Class Initialized
INFO - 2018-06-01 00:47:16 --> Security Class Initialized
DEBUG - 2018-06-01 00:47:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 00:47:16 --> Input Class Initialized
INFO - 2018-06-01 00:47:16 --> Language Class Initialized
ERROR - 2018-06-01 00:47:16 --> 404 Page Not Found: /index
INFO - 2018-06-01 00:47:16 --> Config Class Initialized
INFO - 2018-06-01 00:47:16 --> Hooks Class Initialized
DEBUG - 2018-06-01 00:47:16 --> UTF-8 Support Enabled
INFO - 2018-06-01 00:47:16 --> Utf8 Class Initialized
INFO - 2018-06-01 00:47:16 --> URI Class Initialized
INFO - 2018-06-01 00:47:16 --> Router Class Initialized
INFO - 2018-06-01 00:47:16 --> Output Class Initialized
INFO - 2018-06-01 00:47:16 --> Security Class Initialized
DEBUG - 2018-06-01 00:47:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 00:47:16 --> Input Class Initialized
INFO - 2018-06-01 00:47:16 --> Language Class Initialized
ERROR - 2018-06-01 00:47:16 --> 404 Page Not Found: /index
INFO - 2018-06-01 00:47:16 --> Config Class Initialized
INFO - 2018-06-01 00:47:16 --> Hooks Class Initialized
DEBUG - 2018-06-01 00:47:16 --> UTF-8 Support Enabled
INFO - 2018-06-01 00:47:16 --> Utf8 Class Initialized
INFO - 2018-06-01 00:47:16 --> URI Class Initialized
INFO - 2018-06-01 00:47:16 --> Router Class Initialized
INFO - 2018-06-01 00:47:16 --> Output Class Initialized
INFO - 2018-06-01 00:47:16 --> Security Class Initialized
DEBUG - 2018-06-01 00:47:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 00:47:16 --> Input Class Initialized
INFO - 2018-06-01 00:47:16 --> Language Class Initialized
ERROR - 2018-06-01 00:47:16 --> 404 Page Not Found: /index
INFO - 2018-06-01 00:47:33 --> Config Class Initialized
INFO - 2018-06-01 00:47:33 --> Hooks Class Initialized
DEBUG - 2018-06-01 00:47:33 --> UTF-8 Support Enabled
INFO - 2018-06-01 00:47:33 --> Utf8 Class Initialized
INFO - 2018-06-01 00:47:33 --> URI Class Initialized
INFO - 2018-06-01 00:47:33 --> Router Class Initialized
INFO - 2018-06-01 00:47:33 --> Output Class Initialized
INFO - 2018-06-01 00:47:33 --> Security Class Initialized
DEBUG - 2018-06-01 00:47:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 00:47:33 --> Input Class Initialized
INFO - 2018-06-01 00:47:33 --> Language Class Initialized
INFO - 2018-06-01 00:47:33 --> Language Class Initialized
INFO - 2018-06-01 00:47:33 --> Config Class Initialized
INFO - 2018-06-01 00:47:33 --> Loader Class Initialized
DEBUG - 2018-06-01 00:47:33 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-01 00:47:33 --> Helper loaded: url_helper
INFO - 2018-06-01 00:47:33 --> Helper loaded: form_helper
INFO - 2018-06-01 00:47:33 --> Helper loaded: date_helper
INFO - 2018-06-01 00:47:33 --> Helper loaded: util_helper
INFO - 2018-06-01 00:47:33 --> Helper loaded: text_helper
INFO - 2018-06-01 00:47:33 --> Helper loaded: string_helper
INFO - 2018-06-01 00:47:33 --> Database Driver Class Initialized
DEBUG - 2018-06-01 00:47:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-01 00:47:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-01 00:47:33 --> Email Class Initialized
INFO - 2018-06-01 00:47:33 --> Controller Class Initialized
DEBUG - 2018-06-01 00:47:33 --> Home MX_Controller Initialized
DEBUG - 2018-06-01 00:47:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-01 00:47:33 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-01 00:47:33 --> Login MX_Controller Initialized
INFO - 2018-06-01 00:47:33 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-01 00:47:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-01 00:47:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-01 00:47:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-01 00:47:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-01 00:47:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-01 00:47:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-01 00:47:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-01 00:47:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-06-01 00:47:33 --> Final output sent to browser
DEBUG - 2018-06-01 00:47:33 --> Total execution time: 0.3634
INFO - 2018-06-01 00:47:34 --> Config Class Initialized
INFO - 2018-06-01 00:47:34 --> Hooks Class Initialized
INFO - 2018-06-01 00:47:34 --> Config Class Initialized
DEBUG - 2018-06-01 00:47:34 --> UTF-8 Support Enabled
INFO - 2018-06-01 00:47:34 --> Utf8 Class Initialized
INFO - 2018-06-01 00:47:34 --> Hooks Class Initialized
INFO - 2018-06-01 00:47:34 --> URI Class Initialized
DEBUG - 2018-06-01 00:47:34 --> UTF-8 Support Enabled
INFO - 2018-06-01 00:47:34 --> Utf8 Class Initialized
INFO - 2018-06-01 00:47:34 --> Router Class Initialized
INFO - 2018-06-01 00:47:34 --> URI Class Initialized
INFO - 2018-06-01 00:47:34 --> Router Class Initialized
INFO - 2018-06-01 00:47:34 --> Output Class Initialized
INFO - 2018-06-01 00:47:34 --> Security Class Initialized
INFO - 2018-06-01 00:47:34 --> Output Class Initialized
INFO - 2018-06-01 00:47:34 --> Security Class Initialized
DEBUG - 2018-06-01 00:47:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-06-01 00:47:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 00:47:34 --> Input Class Initialized
INFO - 2018-06-01 00:47:34 --> Input Class Initialized
INFO - 2018-06-01 00:47:34 --> Language Class Initialized
INFO - 2018-06-01 00:47:34 --> Language Class Initialized
ERROR - 2018-06-01 00:47:34 --> 404 Page Not Found: /index
ERROR - 2018-06-01 00:47:34 --> 404 Page Not Found: /index
INFO - 2018-06-01 00:47:34 --> Config Class Initialized
INFO - 2018-06-01 00:47:34 --> Hooks Class Initialized
DEBUG - 2018-06-01 00:47:34 --> UTF-8 Support Enabled
INFO - 2018-06-01 00:47:34 --> Utf8 Class Initialized
INFO - 2018-06-01 00:47:34 --> URI Class Initialized
INFO - 2018-06-01 00:47:34 --> Router Class Initialized
INFO - 2018-06-01 00:47:34 --> Output Class Initialized
INFO - 2018-06-01 00:47:34 --> Security Class Initialized
DEBUG - 2018-06-01 00:47:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 00:47:34 --> Input Class Initialized
INFO - 2018-06-01 00:47:34 --> Language Class Initialized
ERROR - 2018-06-01 00:47:34 --> 404 Page Not Found: /index
INFO - 2018-06-01 00:47:34 --> Config Class Initialized
INFO - 2018-06-01 00:47:34 --> Hooks Class Initialized
DEBUG - 2018-06-01 00:47:34 --> UTF-8 Support Enabled
INFO - 2018-06-01 00:47:34 --> Utf8 Class Initialized
INFO - 2018-06-01 00:47:34 --> URI Class Initialized
INFO - 2018-06-01 00:47:34 --> Router Class Initialized
INFO - 2018-06-01 00:47:34 --> Output Class Initialized
INFO - 2018-06-01 00:47:34 --> Security Class Initialized
DEBUG - 2018-06-01 00:47:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 00:47:34 --> Input Class Initialized
INFO - 2018-06-01 00:47:34 --> Language Class Initialized
ERROR - 2018-06-01 00:47:34 --> 404 Page Not Found: /index
INFO - 2018-06-01 00:47:34 --> Config Class Initialized
INFO - 2018-06-01 00:47:34 --> Hooks Class Initialized
DEBUG - 2018-06-01 00:47:34 --> UTF-8 Support Enabled
INFO - 2018-06-01 00:47:34 --> Utf8 Class Initialized
INFO - 2018-06-01 00:47:34 --> URI Class Initialized
INFO - 2018-06-01 00:47:34 --> Router Class Initialized
INFO - 2018-06-01 00:47:34 --> Output Class Initialized
INFO - 2018-06-01 00:47:34 --> Security Class Initialized
DEBUG - 2018-06-01 00:47:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 00:47:34 --> Input Class Initialized
INFO - 2018-06-01 00:47:34 --> Language Class Initialized
ERROR - 2018-06-01 00:47:34 --> 404 Page Not Found: /index
INFO - 2018-06-01 00:47:34 --> Config Class Initialized
INFO - 2018-06-01 00:47:34 --> Hooks Class Initialized
DEBUG - 2018-06-01 00:47:34 --> UTF-8 Support Enabled
INFO - 2018-06-01 00:47:34 --> Utf8 Class Initialized
INFO - 2018-06-01 00:47:34 --> URI Class Initialized
INFO - 2018-06-01 00:47:34 --> Router Class Initialized
INFO - 2018-06-01 00:47:35 --> Output Class Initialized
INFO - 2018-06-01 00:47:35 --> Security Class Initialized
DEBUG - 2018-06-01 00:47:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 00:47:35 --> Input Class Initialized
INFO - 2018-06-01 00:47:35 --> Language Class Initialized
ERROR - 2018-06-01 00:47:35 --> 404 Page Not Found: /index
INFO - 2018-06-01 00:47:35 --> Config Class Initialized
INFO - 2018-06-01 00:47:35 --> Hooks Class Initialized
DEBUG - 2018-06-01 00:47:35 --> UTF-8 Support Enabled
INFO - 2018-06-01 00:47:35 --> Utf8 Class Initialized
INFO - 2018-06-01 00:47:35 --> URI Class Initialized
INFO - 2018-06-01 00:47:35 --> Router Class Initialized
INFO - 2018-06-01 00:47:35 --> Output Class Initialized
INFO - 2018-06-01 00:47:35 --> Security Class Initialized
DEBUG - 2018-06-01 00:47:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 00:47:35 --> Input Class Initialized
INFO - 2018-06-01 00:47:35 --> Language Class Initialized
ERROR - 2018-06-01 00:47:35 --> 404 Page Not Found: /index
INFO - 2018-06-01 00:47:47 --> Config Class Initialized
INFO - 2018-06-01 00:47:47 --> Hooks Class Initialized
DEBUG - 2018-06-01 00:47:47 --> UTF-8 Support Enabled
INFO - 2018-06-01 00:47:47 --> Utf8 Class Initialized
INFO - 2018-06-01 00:47:47 --> URI Class Initialized
DEBUG - 2018-06-01 00:47:47 --> No URI present. Default controller set.
INFO - 2018-06-01 00:47:47 --> Router Class Initialized
INFO - 2018-06-01 00:47:47 --> Output Class Initialized
INFO - 2018-06-01 00:47:47 --> Security Class Initialized
DEBUG - 2018-06-01 00:47:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 00:47:47 --> Input Class Initialized
INFO - 2018-06-01 00:47:47 --> Language Class Initialized
INFO - 2018-06-01 00:47:47 --> Language Class Initialized
INFO - 2018-06-01 00:47:47 --> Config Class Initialized
INFO - 2018-06-01 00:47:47 --> Loader Class Initialized
DEBUG - 2018-06-01 00:47:47 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-01 00:47:47 --> Helper loaded: url_helper
INFO - 2018-06-01 00:47:47 --> Helper loaded: form_helper
INFO - 2018-06-01 00:47:47 --> Helper loaded: date_helper
INFO - 2018-06-01 00:47:47 --> Helper loaded: util_helper
INFO - 2018-06-01 00:47:47 --> Helper loaded: text_helper
INFO - 2018-06-01 00:47:47 --> Helper loaded: string_helper
INFO - 2018-06-01 00:47:47 --> Database Driver Class Initialized
DEBUG - 2018-06-01 00:47:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-01 00:47:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-01 00:47:47 --> Email Class Initialized
INFO - 2018-06-01 00:47:47 --> Controller Class Initialized
DEBUG - 2018-06-01 00:47:47 --> Home MX_Controller Initialized
DEBUG - 2018-06-01 00:47:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-01 00:47:47 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-01 00:47:47 --> Login MX_Controller Initialized
INFO - 2018-06-01 00:47:47 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-01 00:47:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-01 00:47:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-01 00:47:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-01 00:47:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-01 00:47:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-01 00:47:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-01 00:47:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-01 00:47:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-06-01 00:47:47 --> Final output sent to browser
DEBUG - 2018-06-01 00:47:48 --> Total execution time: 0.3588
INFO - 2018-06-01 00:47:48 --> Config Class Initialized
INFO - 2018-06-01 00:47:48 --> Hooks Class Initialized
DEBUG - 2018-06-01 00:47:48 --> UTF-8 Support Enabled
INFO - 2018-06-01 00:47:48 --> Utf8 Class Initialized
INFO - 2018-06-01 00:47:48 --> URI Class Initialized
INFO - 2018-06-01 00:47:48 --> Router Class Initialized
INFO - 2018-06-01 00:47:48 --> Output Class Initialized
INFO - 2018-06-01 00:47:48 --> Security Class Initialized
DEBUG - 2018-06-01 00:47:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 00:47:48 --> Input Class Initialized
INFO - 2018-06-01 00:47:48 --> Language Class Initialized
ERROR - 2018-06-01 00:47:48 --> 404 Page Not Found: /index
INFO - 2018-06-01 00:47:48 --> Config Class Initialized
INFO - 2018-06-01 00:47:48 --> Hooks Class Initialized
DEBUG - 2018-06-01 00:47:48 --> UTF-8 Support Enabled
INFO - 2018-06-01 00:47:48 --> Utf8 Class Initialized
INFO - 2018-06-01 00:47:48 --> URI Class Initialized
INFO - 2018-06-01 00:47:48 --> Router Class Initialized
INFO - 2018-06-01 00:47:48 --> Output Class Initialized
INFO - 2018-06-01 00:47:48 --> Security Class Initialized
DEBUG - 2018-06-01 00:47:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 00:47:48 --> Input Class Initialized
INFO - 2018-06-01 00:47:48 --> Language Class Initialized
ERROR - 2018-06-01 00:47:48 --> 404 Page Not Found: /index
INFO - 2018-06-01 00:47:48 --> Config Class Initialized
INFO - 2018-06-01 00:47:48 --> Hooks Class Initialized
DEBUG - 2018-06-01 00:47:48 --> UTF-8 Support Enabled
INFO - 2018-06-01 00:47:48 --> Utf8 Class Initialized
INFO - 2018-06-01 00:47:48 --> URI Class Initialized
INFO - 2018-06-01 00:47:48 --> Router Class Initialized
INFO - 2018-06-01 00:47:48 --> Output Class Initialized
INFO - 2018-06-01 00:47:48 --> Security Class Initialized
DEBUG - 2018-06-01 00:47:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 00:47:48 --> Input Class Initialized
INFO - 2018-06-01 00:47:48 --> Language Class Initialized
ERROR - 2018-06-01 00:47:48 --> 404 Page Not Found: /index
INFO - 2018-06-01 00:47:50 --> Config Class Initialized
INFO - 2018-06-01 00:47:50 --> Hooks Class Initialized
DEBUG - 2018-06-01 00:47:50 --> UTF-8 Support Enabled
INFO - 2018-06-01 00:47:50 --> Utf8 Class Initialized
INFO - 2018-06-01 00:47:50 --> URI Class Initialized
INFO - 2018-06-01 00:47:50 --> Router Class Initialized
INFO - 2018-06-01 00:47:50 --> Output Class Initialized
INFO - 2018-06-01 00:47:50 --> Security Class Initialized
DEBUG - 2018-06-01 00:47:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 00:47:50 --> Input Class Initialized
INFO - 2018-06-01 00:47:50 --> Language Class Initialized
INFO - 2018-06-01 00:47:50 --> Language Class Initialized
INFO - 2018-06-01 00:47:50 --> Config Class Initialized
INFO - 2018-06-01 00:47:50 --> Loader Class Initialized
DEBUG - 2018-06-01 00:47:50 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-01 00:47:50 --> Helper loaded: url_helper
INFO - 2018-06-01 00:47:50 --> Helper loaded: form_helper
INFO - 2018-06-01 00:47:50 --> Helper loaded: date_helper
INFO - 2018-06-01 00:47:50 --> Helper loaded: util_helper
INFO - 2018-06-01 00:47:50 --> Helper loaded: text_helper
INFO - 2018-06-01 00:47:50 --> Helper loaded: string_helper
INFO - 2018-06-01 00:47:50 --> Database Driver Class Initialized
DEBUG - 2018-06-01 00:47:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-01 00:47:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-01 00:47:50 --> Email Class Initialized
INFO - 2018-06-01 00:47:50 --> Controller Class Initialized
DEBUG - 2018-06-01 00:47:50 --> Home MX_Controller Initialized
DEBUG - 2018-06-01 00:47:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-01 00:47:50 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-01 00:47:50 --> Login MX_Controller Initialized
INFO - 2018-06-01 00:47:50 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-01 00:47:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-01 00:47:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-01 00:47:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-01 00:47:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-01 00:47:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-01 00:47:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-01 00:47:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-01 00:47:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-06-01 00:47:50 --> Final output sent to browser
DEBUG - 2018-06-01 00:47:51 --> Total execution time: 0.3605
INFO - 2018-06-01 00:47:51 --> Config Class Initialized
INFO - 2018-06-01 00:47:51 --> Config Class Initialized
INFO - 2018-06-01 00:47:51 --> Hooks Class Initialized
INFO - 2018-06-01 00:47:51 --> Hooks Class Initialized
DEBUG - 2018-06-01 00:47:51 --> UTF-8 Support Enabled
DEBUG - 2018-06-01 00:47:51 --> UTF-8 Support Enabled
INFO - 2018-06-01 00:47:51 --> Utf8 Class Initialized
INFO - 2018-06-01 00:47:51 --> Utf8 Class Initialized
INFO - 2018-06-01 00:47:51 --> URI Class Initialized
INFO - 2018-06-01 00:47:51 --> URI Class Initialized
INFO - 2018-06-01 00:47:51 --> Router Class Initialized
INFO - 2018-06-01 00:47:51 --> Output Class Initialized
INFO - 2018-06-01 00:47:51 --> Router Class Initialized
INFO - 2018-06-01 00:47:51 --> Security Class Initialized
DEBUG - 2018-06-01 00:47:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 00:47:51 --> Output Class Initialized
INFO - 2018-06-01 00:47:51 --> Input Class Initialized
INFO - 2018-06-01 00:47:51 --> Security Class Initialized
INFO - 2018-06-01 00:47:51 --> Language Class Initialized
ERROR - 2018-06-01 00:47:51 --> 404 Page Not Found: /index
DEBUG - 2018-06-01 00:47:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 00:47:51 --> Config Class Initialized
INFO - 2018-06-01 00:47:51 --> Hooks Class Initialized
INFO - 2018-06-01 00:47:51 --> Input Class Initialized
DEBUG - 2018-06-01 00:47:51 --> UTF-8 Support Enabled
INFO - 2018-06-01 00:47:51 --> Utf8 Class Initialized
INFO - 2018-06-01 00:47:51 --> URI Class Initialized
INFO - 2018-06-01 00:47:51 --> Language Class Initialized
INFO - 2018-06-01 00:47:51 --> Router Class Initialized
INFO - 2018-06-01 00:47:51 --> Output Class Initialized
ERROR - 2018-06-01 00:47:51 --> 404 Page Not Found: /index
INFO - 2018-06-01 00:47:51 --> Security Class Initialized
DEBUG - 2018-06-01 00:47:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 00:47:51 --> Input Class Initialized
INFO - 2018-06-01 00:47:51 --> Language Class Initialized
ERROR - 2018-06-01 00:47:51 --> 404 Page Not Found: /index
INFO - 2018-06-01 00:47:51 --> Config Class Initialized
INFO - 2018-06-01 00:47:51 --> Hooks Class Initialized
DEBUG - 2018-06-01 00:47:51 --> UTF-8 Support Enabled
INFO - 2018-06-01 00:47:51 --> Utf8 Class Initialized
INFO - 2018-06-01 00:47:51 --> URI Class Initialized
INFO - 2018-06-01 00:47:51 --> Router Class Initialized
INFO - 2018-06-01 00:47:51 --> Output Class Initialized
INFO - 2018-06-01 00:47:51 --> Security Class Initialized
DEBUG - 2018-06-01 00:47:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 00:47:51 --> Input Class Initialized
INFO - 2018-06-01 00:47:51 --> Language Class Initialized
ERROR - 2018-06-01 00:47:51 --> 404 Page Not Found: /index
INFO - 2018-06-01 00:48:26 --> Config Class Initialized
INFO - 2018-06-01 00:48:26 --> Hooks Class Initialized
DEBUG - 2018-06-01 00:48:26 --> UTF-8 Support Enabled
INFO - 2018-06-01 00:48:26 --> Utf8 Class Initialized
INFO - 2018-06-01 00:48:26 --> URI Class Initialized
INFO - 2018-06-01 00:48:26 --> Router Class Initialized
INFO - 2018-06-01 00:48:26 --> Output Class Initialized
INFO - 2018-06-01 00:48:26 --> Security Class Initialized
DEBUG - 2018-06-01 00:48:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 00:48:26 --> Input Class Initialized
INFO - 2018-06-01 00:48:26 --> Language Class Initialized
INFO - 2018-06-01 00:48:26 --> Language Class Initialized
INFO - 2018-06-01 00:48:26 --> Config Class Initialized
INFO - 2018-06-01 00:48:26 --> Loader Class Initialized
DEBUG - 2018-06-01 00:48:26 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-01 00:48:26 --> Helper loaded: url_helper
INFO - 2018-06-01 00:48:26 --> Helper loaded: form_helper
INFO - 2018-06-01 00:48:26 --> Helper loaded: date_helper
INFO - 2018-06-01 00:48:26 --> Helper loaded: util_helper
INFO - 2018-06-01 00:48:26 --> Helper loaded: text_helper
INFO - 2018-06-01 00:48:26 --> Helper loaded: string_helper
INFO - 2018-06-01 00:48:26 --> Database Driver Class Initialized
DEBUG - 2018-06-01 00:48:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-01 00:48:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-01 00:48:26 --> Email Class Initialized
INFO - 2018-06-01 00:48:26 --> Controller Class Initialized
DEBUG - 2018-06-01 00:48:26 --> Home MX_Controller Initialized
DEBUG - 2018-06-01 00:48:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-01 00:48:26 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-01 00:48:26 --> Login MX_Controller Initialized
INFO - 2018-06-01 00:48:26 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-01 00:48:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-01 00:48:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-01 00:48:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-01 00:48:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-01 00:48:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-01 00:48:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-01 00:48:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-01 00:48:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-06-01 00:48:26 --> Final output sent to browser
DEBUG - 2018-06-01 00:48:26 --> Total execution time: 0.3688
INFO - 2018-06-01 00:48:26 --> Config Class Initialized
INFO - 2018-06-01 00:48:26 --> Hooks Class Initialized
DEBUG - 2018-06-01 00:48:26 --> UTF-8 Support Enabled
INFO - 2018-06-01 00:48:26 --> Utf8 Class Initialized
INFO - 2018-06-01 00:48:26 --> Config Class Initialized
INFO - 2018-06-01 00:48:26 --> URI Class Initialized
INFO - 2018-06-01 00:48:26 --> Router Class Initialized
INFO - 2018-06-01 00:48:26 --> Output Class Initialized
INFO - 2018-06-01 00:48:26 --> Security Class Initialized
DEBUG - 2018-06-01 00:48:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 00:48:27 --> Input Class Initialized
INFO - 2018-06-01 00:48:27 --> Language Class Initialized
INFO - 2018-06-01 00:48:27 --> Hooks Class Initialized
ERROR - 2018-06-01 00:48:27 --> 404 Page Not Found: /index
DEBUG - 2018-06-01 00:48:27 --> UTF-8 Support Enabled
INFO - 2018-06-01 00:48:27 --> Utf8 Class Initialized
INFO - 2018-06-01 00:48:27 --> URI Class Initialized
INFO - 2018-06-01 00:48:27 --> Router Class Initialized
INFO - 2018-06-01 00:48:27 --> Output Class Initialized
INFO - 2018-06-01 00:48:27 --> Security Class Initialized
DEBUG - 2018-06-01 00:48:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 00:48:27 --> Input Class Initialized
INFO - 2018-06-01 00:48:27 --> Language Class Initialized
ERROR - 2018-06-01 00:48:27 --> 404 Page Not Found: /index
INFO - 2018-06-01 00:48:27 --> Config Class Initialized
INFO - 2018-06-01 00:48:27 --> Hooks Class Initialized
DEBUG - 2018-06-01 00:48:27 --> UTF-8 Support Enabled
INFO - 2018-06-01 00:48:27 --> Utf8 Class Initialized
INFO - 2018-06-01 00:48:27 --> URI Class Initialized
INFO - 2018-06-01 00:48:27 --> Router Class Initialized
INFO - 2018-06-01 00:48:27 --> Output Class Initialized
INFO - 2018-06-01 00:48:27 --> Security Class Initialized
DEBUG - 2018-06-01 00:48:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 00:48:27 --> Input Class Initialized
INFO - 2018-06-01 00:48:27 --> Language Class Initialized
ERROR - 2018-06-01 00:48:27 --> 404 Page Not Found: /index
INFO - 2018-06-01 00:48:27 --> Config Class Initialized
INFO - 2018-06-01 00:48:27 --> Hooks Class Initialized
DEBUG - 2018-06-01 00:48:27 --> UTF-8 Support Enabled
INFO - 2018-06-01 00:48:27 --> Utf8 Class Initialized
INFO - 2018-06-01 00:48:27 --> URI Class Initialized
INFO - 2018-06-01 00:48:27 --> Router Class Initialized
INFO - 2018-06-01 00:48:27 --> Output Class Initialized
INFO - 2018-06-01 00:48:27 --> Security Class Initialized
DEBUG - 2018-06-01 00:48:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 00:48:27 --> Input Class Initialized
INFO - 2018-06-01 00:48:27 --> Language Class Initialized
ERROR - 2018-06-01 00:48:27 --> 404 Page Not Found: /index
INFO - 2018-06-01 00:48:27 --> Config Class Initialized
INFO - 2018-06-01 00:48:27 --> Hooks Class Initialized
DEBUG - 2018-06-01 00:48:27 --> UTF-8 Support Enabled
INFO - 2018-06-01 00:48:27 --> Utf8 Class Initialized
INFO - 2018-06-01 00:48:27 --> URI Class Initialized
INFO - 2018-06-01 00:48:27 --> Router Class Initialized
INFO - 2018-06-01 00:48:27 --> Output Class Initialized
INFO - 2018-06-01 00:48:27 --> Security Class Initialized
DEBUG - 2018-06-01 00:48:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 00:48:27 --> Input Class Initialized
INFO - 2018-06-01 00:48:27 --> Language Class Initialized
ERROR - 2018-06-01 00:48:27 --> 404 Page Not Found: /index
INFO - 2018-06-01 00:48:27 --> Config Class Initialized
INFO - 2018-06-01 00:48:27 --> Hooks Class Initialized
DEBUG - 2018-06-01 00:48:27 --> UTF-8 Support Enabled
INFO - 2018-06-01 00:48:27 --> Utf8 Class Initialized
INFO - 2018-06-01 00:48:27 --> URI Class Initialized
INFO - 2018-06-01 00:48:27 --> Router Class Initialized
INFO - 2018-06-01 00:48:27 --> Output Class Initialized
INFO - 2018-06-01 00:48:27 --> Security Class Initialized
DEBUG - 2018-06-01 00:48:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 00:48:27 --> Input Class Initialized
INFO - 2018-06-01 00:48:27 --> Language Class Initialized
ERROR - 2018-06-01 00:48:27 --> 404 Page Not Found: /index
INFO - 2018-06-01 00:48:27 --> Config Class Initialized
INFO - 2018-06-01 00:48:27 --> Hooks Class Initialized
DEBUG - 2018-06-01 00:48:27 --> UTF-8 Support Enabled
INFO - 2018-06-01 00:48:27 --> Utf8 Class Initialized
INFO - 2018-06-01 00:48:27 --> URI Class Initialized
INFO - 2018-06-01 00:48:27 --> Router Class Initialized
INFO - 2018-06-01 00:48:27 --> Output Class Initialized
INFO - 2018-06-01 00:48:27 --> Security Class Initialized
DEBUG - 2018-06-01 00:48:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 00:48:27 --> Input Class Initialized
INFO - 2018-06-01 00:48:27 --> Language Class Initialized
ERROR - 2018-06-01 00:48:27 --> 404 Page Not Found: /index
INFO - 2018-06-01 00:49:17 --> Config Class Initialized
INFO - 2018-06-01 00:49:17 --> Hooks Class Initialized
DEBUG - 2018-06-01 00:49:17 --> UTF-8 Support Enabled
INFO - 2018-06-01 00:49:17 --> Utf8 Class Initialized
INFO - 2018-06-01 00:49:17 --> URI Class Initialized
INFO - 2018-06-01 00:49:17 --> Router Class Initialized
INFO - 2018-06-01 00:49:17 --> Output Class Initialized
INFO - 2018-06-01 00:49:17 --> Security Class Initialized
DEBUG - 2018-06-01 00:49:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 00:49:17 --> Input Class Initialized
INFO - 2018-06-01 00:49:17 --> Language Class Initialized
INFO - 2018-06-01 00:49:17 --> Language Class Initialized
INFO - 2018-06-01 00:49:17 --> Config Class Initialized
INFO - 2018-06-01 00:49:17 --> Loader Class Initialized
DEBUG - 2018-06-01 00:49:17 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-01 00:49:17 --> Helper loaded: url_helper
INFO - 2018-06-01 00:49:17 --> Helper loaded: form_helper
INFO - 2018-06-01 00:49:17 --> Helper loaded: date_helper
INFO - 2018-06-01 00:49:17 --> Helper loaded: util_helper
INFO - 2018-06-01 00:49:17 --> Helper loaded: text_helper
INFO - 2018-06-01 00:49:17 --> Helper loaded: string_helper
INFO - 2018-06-01 00:49:17 --> Database Driver Class Initialized
DEBUG - 2018-06-01 00:49:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-01 00:49:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-01 00:49:17 --> Email Class Initialized
INFO - 2018-06-01 00:49:17 --> Controller Class Initialized
DEBUG - 2018-06-01 00:49:17 --> Home MX_Controller Initialized
DEBUG - 2018-06-01 00:49:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-01 00:49:17 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-01 00:49:17 --> Login MX_Controller Initialized
INFO - 2018-06-01 00:49:17 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-01 00:49:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-01 00:49:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-01 00:49:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-01 00:49:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-01 00:49:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-01 00:49:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-01 00:49:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-01 00:49:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-06-01 00:49:17 --> Final output sent to browser
DEBUG - 2018-06-01 00:49:17 --> Total execution time: 0.3743
INFO - 2018-06-01 00:49:18 --> Config Class Initialized
INFO - 2018-06-01 00:49:18 --> Hooks Class Initialized
DEBUG - 2018-06-01 00:49:18 --> UTF-8 Support Enabled
INFO - 2018-06-01 00:49:18 --> Utf8 Class Initialized
INFO - 2018-06-01 00:49:18 --> URI Class Initialized
INFO - 2018-06-01 00:49:18 --> Router Class Initialized
INFO - 2018-06-01 00:49:18 --> Output Class Initialized
INFO - 2018-06-01 00:49:18 --> Config Class Initialized
INFO - 2018-06-01 00:49:18 --> Security Class Initialized
INFO - 2018-06-01 00:49:18 --> Hooks Class Initialized
DEBUG - 2018-06-01 00:49:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-06-01 00:49:18 --> UTF-8 Support Enabled
INFO - 2018-06-01 00:49:18 --> Input Class Initialized
INFO - 2018-06-01 00:49:18 --> Language Class Initialized
INFO - 2018-06-01 00:49:18 --> Utf8 Class Initialized
ERROR - 2018-06-01 00:49:18 --> 404 Page Not Found: /index
INFO - 2018-06-01 00:49:18 --> URI Class Initialized
INFO - 2018-06-01 00:49:18 --> Router Class Initialized
INFO - 2018-06-01 00:49:18 --> Output Class Initialized
INFO - 2018-06-01 00:49:18 --> Security Class Initialized
DEBUG - 2018-06-01 00:49:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 00:49:18 --> Input Class Initialized
INFO - 2018-06-01 00:49:18 --> Language Class Initialized
ERROR - 2018-06-01 00:49:18 --> 404 Page Not Found: /index
INFO - 2018-06-01 00:49:18 --> Config Class Initialized
INFO - 2018-06-01 00:49:18 --> Hooks Class Initialized
DEBUG - 2018-06-01 00:49:18 --> UTF-8 Support Enabled
INFO - 2018-06-01 00:49:18 --> Utf8 Class Initialized
INFO - 2018-06-01 00:49:18 --> URI Class Initialized
INFO - 2018-06-01 00:49:18 --> Router Class Initialized
INFO - 2018-06-01 00:49:18 --> Output Class Initialized
INFO - 2018-06-01 00:49:18 --> Security Class Initialized
DEBUG - 2018-06-01 00:49:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 00:49:18 --> Input Class Initialized
INFO - 2018-06-01 00:49:18 --> Language Class Initialized
ERROR - 2018-06-01 00:49:18 --> 404 Page Not Found: /index
INFO - 2018-06-01 00:49:18 --> Config Class Initialized
INFO - 2018-06-01 00:49:18 --> Hooks Class Initialized
DEBUG - 2018-06-01 00:49:18 --> UTF-8 Support Enabled
INFO - 2018-06-01 00:49:18 --> Utf8 Class Initialized
INFO - 2018-06-01 00:49:18 --> URI Class Initialized
INFO - 2018-06-01 00:49:18 --> Router Class Initialized
INFO - 2018-06-01 00:49:18 --> Output Class Initialized
INFO - 2018-06-01 00:49:18 --> Security Class Initialized
DEBUG - 2018-06-01 00:49:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 00:49:18 --> Input Class Initialized
INFO - 2018-06-01 00:49:18 --> Language Class Initialized
ERROR - 2018-06-01 00:49:18 --> 404 Page Not Found: /index
INFO - 2018-06-01 00:49:18 --> Config Class Initialized
INFO - 2018-06-01 00:49:18 --> Hooks Class Initialized
DEBUG - 2018-06-01 00:49:18 --> UTF-8 Support Enabled
INFO - 2018-06-01 00:49:18 --> Utf8 Class Initialized
INFO - 2018-06-01 00:49:19 --> URI Class Initialized
INFO - 2018-06-01 00:49:19 --> Router Class Initialized
INFO - 2018-06-01 00:49:19 --> Output Class Initialized
INFO - 2018-06-01 00:49:19 --> Security Class Initialized
DEBUG - 2018-06-01 00:49:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 00:49:19 --> Input Class Initialized
INFO - 2018-06-01 00:49:19 --> Language Class Initialized
ERROR - 2018-06-01 00:49:19 --> 404 Page Not Found: /index
INFO - 2018-06-01 00:49:19 --> Config Class Initialized
INFO - 2018-06-01 00:49:19 --> Hooks Class Initialized
DEBUG - 2018-06-01 00:49:19 --> UTF-8 Support Enabled
INFO - 2018-06-01 00:49:19 --> Utf8 Class Initialized
INFO - 2018-06-01 00:49:19 --> URI Class Initialized
INFO - 2018-06-01 00:49:19 --> Router Class Initialized
INFO - 2018-06-01 00:49:19 --> Output Class Initialized
INFO - 2018-06-01 00:49:19 --> Security Class Initialized
DEBUG - 2018-06-01 00:49:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 00:49:19 --> Input Class Initialized
INFO - 2018-06-01 00:49:19 --> Language Class Initialized
ERROR - 2018-06-01 00:49:19 --> 404 Page Not Found: /index
INFO - 2018-06-01 00:49:19 --> Config Class Initialized
INFO - 2018-06-01 00:49:19 --> Hooks Class Initialized
DEBUG - 2018-06-01 00:49:19 --> UTF-8 Support Enabled
INFO - 2018-06-01 00:49:19 --> Utf8 Class Initialized
INFO - 2018-06-01 00:49:19 --> URI Class Initialized
INFO - 2018-06-01 00:49:19 --> Router Class Initialized
INFO - 2018-06-01 00:49:19 --> Output Class Initialized
INFO - 2018-06-01 00:49:19 --> Security Class Initialized
DEBUG - 2018-06-01 00:49:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 00:49:19 --> Input Class Initialized
INFO - 2018-06-01 00:49:19 --> Language Class Initialized
ERROR - 2018-06-01 00:49:19 --> 404 Page Not Found: /index
INFO - 2018-06-01 00:49:21 --> Config Class Initialized
INFO - 2018-06-01 00:49:21 --> Hooks Class Initialized
DEBUG - 2018-06-01 00:49:21 --> UTF-8 Support Enabled
INFO - 2018-06-01 00:49:21 --> Utf8 Class Initialized
INFO - 2018-06-01 00:49:21 --> URI Class Initialized
INFO - 2018-06-01 00:49:21 --> Router Class Initialized
INFO - 2018-06-01 00:49:21 --> Output Class Initialized
INFO - 2018-06-01 00:49:21 --> Security Class Initialized
DEBUG - 2018-06-01 00:49:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 00:49:21 --> Input Class Initialized
INFO - 2018-06-01 00:49:21 --> Language Class Initialized
INFO - 2018-06-01 00:49:21 --> Language Class Initialized
INFO - 2018-06-01 00:49:21 --> Config Class Initialized
INFO - 2018-06-01 00:49:21 --> Loader Class Initialized
DEBUG - 2018-06-01 00:49:21 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-01 00:49:21 --> Helper loaded: url_helper
INFO - 2018-06-01 00:49:21 --> Helper loaded: form_helper
INFO - 2018-06-01 00:49:21 --> Helper loaded: date_helper
INFO - 2018-06-01 00:49:21 --> Helper loaded: util_helper
INFO - 2018-06-01 00:49:21 --> Helper loaded: text_helper
INFO - 2018-06-01 00:49:21 --> Helper loaded: string_helper
INFO - 2018-06-01 00:49:21 --> Database Driver Class Initialized
DEBUG - 2018-06-01 00:49:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-01 00:49:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-01 00:49:21 --> Email Class Initialized
INFO - 2018-06-01 00:49:21 --> Controller Class Initialized
DEBUG - 2018-06-01 00:49:21 --> Home MX_Controller Initialized
DEBUG - 2018-06-01 00:49:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-01 00:49:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-06-01 00:49:21 --> Final output sent to browser
DEBUG - 2018-06-01 00:49:21 --> Total execution time: 0.3166
INFO - 2018-06-01 00:49:21 --> Config Class Initialized
INFO - 2018-06-01 00:49:21 --> Hooks Class Initialized
DEBUG - 2018-06-01 00:49:21 --> UTF-8 Support Enabled
INFO - 2018-06-01 00:49:21 --> Utf8 Class Initialized
INFO - 2018-06-01 00:49:21 --> URI Class Initialized
INFO - 2018-06-01 00:49:21 --> Router Class Initialized
INFO - 2018-06-01 00:49:21 --> Output Class Initialized
INFO - 2018-06-01 00:49:21 --> Security Class Initialized
DEBUG - 2018-06-01 00:49:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 00:49:21 --> Input Class Initialized
INFO - 2018-06-01 00:49:21 --> Language Class Initialized
INFO - 2018-06-01 00:49:21 --> Language Class Initialized
INFO - 2018-06-01 00:49:21 --> Config Class Initialized
INFO - 2018-06-01 00:49:21 --> Loader Class Initialized
DEBUG - 2018-06-01 00:49:21 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-01 00:49:21 --> Helper loaded: url_helper
INFO - 2018-06-01 00:49:21 --> Helper loaded: form_helper
INFO - 2018-06-01 00:49:21 --> Helper loaded: date_helper
INFO - 2018-06-01 00:49:21 --> Helper loaded: util_helper
INFO - 2018-06-01 00:49:21 --> Helper loaded: text_helper
INFO - 2018-06-01 00:49:21 --> Helper loaded: string_helper
INFO - 2018-06-01 00:49:21 --> Database Driver Class Initialized
DEBUG - 2018-06-01 00:49:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-01 00:49:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-01 00:49:21 --> Email Class Initialized
INFO - 2018-06-01 00:49:21 --> Controller Class Initialized
DEBUG - 2018-06-01 00:49:21 --> Home MX_Controller Initialized
DEBUG - 2018-06-01 00:49:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-06-01 00:49:25 --> Config Class Initialized
INFO - 2018-06-01 00:49:25 --> Hooks Class Initialized
DEBUG - 2018-06-01 00:49:25 --> UTF-8 Support Enabled
INFO - 2018-06-01 00:49:25 --> Utf8 Class Initialized
INFO - 2018-06-01 00:49:25 --> URI Class Initialized
INFO - 2018-06-01 00:49:25 --> Router Class Initialized
INFO - 2018-06-01 00:49:25 --> Output Class Initialized
INFO - 2018-06-01 00:49:25 --> Security Class Initialized
DEBUG - 2018-06-01 00:49:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 00:49:25 --> Input Class Initialized
INFO - 2018-06-01 00:49:25 --> Language Class Initialized
INFO - 2018-06-01 00:49:25 --> Language Class Initialized
INFO - 2018-06-01 00:49:25 --> Config Class Initialized
INFO - 2018-06-01 00:49:25 --> Loader Class Initialized
DEBUG - 2018-06-01 00:49:25 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-01 00:49:25 --> Helper loaded: url_helper
INFO - 2018-06-01 00:49:25 --> Helper loaded: form_helper
INFO - 2018-06-01 00:49:25 --> Helper loaded: date_helper
INFO - 2018-06-01 00:49:25 --> Helper loaded: util_helper
INFO - 2018-06-01 00:49:25 --> Helper loaded: text_helper
INFO - 2018-06-01 00:49:25 --> Helper loaded: string_helper
INFO - 2018-06-01 00:49:25 --> Database Driver Class Initialized
DEBUG - 2018-06-01 00:49:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-01 00:49:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-01 00:49:25 --> Email Class Initialized
INFO - 2018-06-01 00:49:25 --> Controller Class Initialized
DEBUG - 2018-06-01 00:49:25 --> Home MX_Controller Initialized
DEBUG - 2018-06-01 00:49:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-01 00:49:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-06-01 00:49:25 --> Final output sent to browser
DEBUG - 2018-06-01 00:49:25 --> Total execution time: 0.3200
INFO - 2018-06-01 00:49:25 --> Config Class Initialized
INFO - 2018-06-01 00:49:25 --> Hooks Class Initialized
DEBUG - 2018-06-01 00:49:25 --> UTF-8 Support Enabled
INFO - 2018-06-01 00:49:25 --> Utf8 Class Initialized
INFO - 2018-06-01 00:49:25 --> URI Class Initialized
INFO - 2018-06-01 00:49:25 --> Router Class Initialized
INFO - 2018-06-01 00:49:25 --> Output Class Initialized
INFO - 2018-06-01 00:49:25 --> Security Class Initialized
DEBUG - 2018-06-01 00:49:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 00:49:25 --> Input Class Initialized
INFO - 2018-06-01 00:49:25 --> Language Class Initialized
INFO - 2018-06-01 00:49:25 --> Language Class Initialized
INFO - 2018-06-01 00:49:25 --> Config Class Initialized
INFO - 2018-06-01 00:49:25 --> Loader Class Initialized
DEBUG - 2018-06-01 00:49:25 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-01 00:49:25 --> Helper loaded: url_helper
INFO - 2018-06-01 00:49:25 --> Helper loaded: form_helper
INFO - 2018-06-01 00:49:25 --> Helper loaded: date_helper
INFO - 2018-06-01 00:49:25 --> Helper loaded: util_helper
INFO - 2018-06-01 00:49:25 --> Helper loaded: text_helper
INFO - 2018-06-01 00:49:25 --> Helper loaded: string_helper
INFO - 2018-06-01 00:49:25 --> Database Driver Class Initialized
DEBUG - 2018-06-01 00:49:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-01 00:49:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-01 00:49:25 --> Email Class Initialized
INFO - 2018-06-01 00:49:25 --> Controller Class Initialized
DEBUG - 2018-06-01 00:49:25 --> Home MX_Controller Initialized
DEBUG - 2018-06-01 00:49:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-06-01 00:50:02 --> Config Class Initialized
INFO - 2018-06-01 00:50:02 --> Hooks Class Initialized
DEBUG - 2018-06-01 00:50:02 --> UTF-8 Support Enabled
INFO - 2018-06-01 00:50:02 --> Utf8 Class Initialized
INFO - 2018-06-01 00:50:02 --> URI Class Initialized
INFO - 2018-06-01 00:50:02 --> Router Class Initialized
INFO - 2018-06-01 00:50:02 --> Output Class Initialized
INFO - 2018-06-01 00:50:02 --> Security Class Initialized
DEBUG - 2018-06-01 00:50:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 00:50:02 --> Input Class Initialized
INFO - 2018-06-01 00:50:02 --> Language Class Initialized
INFO - 2018-06-01 00:50:02 --> Language Class Initialized
INFO - 2018-06-01 00:50:02 --> Config Class Initialized
INFO - 2018-06-01 00:50:02 --> Loader Class Initialized
DEBUG - 2018-06-01 00:50:02 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-01 00:50:02 --> Helper loaded: url_helper
INFO - 2018-06-01 00:50:02 --> Helper loaded: form_helper
INFO - 2018-06-01 00:50:02 --> Helper loaded: date_helper
INFO - 2018-06-01 00:50:02 --> Helper loaded: util_helper
INFO - 2018-06-01 00:50:02 --> Helper loaded: text_helper
INFO - 2018-06-01 00:50:02 --> Helper loaded: string_helper
INFO - 2018-06-01 00:50:02 --> Database Driver Class Initialized
DEBUG - 2018-06-01 00:50:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-01 00:50:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-01 00:50:02 --> Email Class Initialized
INFO - 2018-06-01 00:50:02 --> Controller Class Initialized
DEBUG - 2018-06-01 00:50:02 --> Home MX_Controller Initialized
DEBUG - 2018-06-01 00:50:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-01 00:50:02 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-01 00:50:02 --> Login MX_Controller Initialized
INFO - 2018-06-01 00:50:02 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-01 00:50:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-01 00:50:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-01 00:50:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-01 00:50:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-01 00:50:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-01 00:50:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-01 00:50:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-01 00:50:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-06-01 00:50:02 --> Final output sent to browser
DEBUG - 2018-06-01 00:50:02 --> Total execution time: 0.3912
INFO - 2018-06-01 00:50:02 --> Config Class Initialized
INFO - 2018-06-01 00:50:02 --> Config Class Initialized
INFO - 2018-06-01 00:50:02 --> Hooks Class Initialized
INFO - 2018-06-01 00:50:02 --> Hooks Class Initialized
DEBUG - 2018-06-01 00:50:02 --> UTF-8 Support Enabled
DEBUG - 2018-06-01 00:50:02 --> UTF-8 Support Enabled
INFO - 2018-06-01 00:50:02 --> Utf8 Class Initialized
INFO - 2018-06-01 00:50:02 --> Utf8 Class Initialized
INFO - 2018-06-01 00:50:02 --> URI Class Initialized
INFO - 2018-06-01 00:50:02 --> URI Class Initialized
INFO - 2018-06-01 00:50:03 --> Router Class Initialized
INFO - 2018-06-01 00:50:03 --> Router Class Initialized
INFO - 2018-06-01 00:50:03 --> Output Class Initialized
INFO - 2018-06-01 00:50:03 --> Output Class Initialized
INFO - 2018-06-01 00:50:03 --> Security Class Initialized
DEBUG - 2018-06-01 00:50:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 00:50:03 --> Input Class Initialized
INFO - 2018-06-01 00:50:03 --> Security Class Initialized
INFO - 2018-06-01 00:50:03 --> Language Class Initialized
ERROR - 2018-06-01 00:50:03 --> 404 Page Not Found: /index
DEBUG - 2018-06-01 00:50:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 00:50:03 --> Input Class Initialized
INFO - 2018-06-01 00:50:03 --> Language Class Initialized
ERROR - 2018-06-01 00:50:03 --> 404 Page Not Found: /index
INFO - 2018-06-01 00:50:03 --> Config Class Initialized
INFO - 2018-06-01 00:50:03 --> Hooks Class Initialized
DEBUG - 2018-06-01 00:50:03 --> UTF-8 Support Enabled
INFO - 2018-06-01 00:50:03 --> Utf8 Class Initialized
INFO - 2018-06-01 00:50:03 --> URI Class Initialized
INFO - 2018-06-01 00:50:03 --> Router Class Initialized
INFO - 2018-06-01 00:50:03 --> Output Class Initialized
INFO - 2018-06-01 00:50:03 --> Security Class Initialized
DEBUG - 2018-06-01 00:50:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 00:50:03 --> Input Class Initialized
INFO - 2018-06-01 00:50:03 --> Language Class Initialized
ERROR - 2018-06-01 00:50:03 --> 404 Page Not Found: /index
INFO - 2018-06-01 00:50:03 --> Config Class Initialized
INFO - 2018-06-01 00:50:03 --> Hooks Class Initialized
DEBUG - 2018-06-01 00:50:03 --> UTF-8 Support Enabled
INFO - 2018-06-01 00:50:03 --> Utf8 Class Initialized
INFO - 2018-06-01 00:50:03 --> URI Class Initialized
INFO - 2018-06-01 00:50:03 --> Router Class Initialized
INFO - 2018-06-01 00:50:03 --> Output Class Initialized
INFO - 2018-06-01 00:50:03 --> Security Class Initialized
DEBUG - 2018-06-01 00:50:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 00:50:03 --> Input Class Initialized
INFO - 2018-06-01 00:50:03 --> Language Class Initialized
ERROR - 2018-06-01 00:50:03 --> 404 Page Not Found: /index
INFO - 2018-06-01 00:50:07 --> Config Class Initialized
INFO - 2018-06-01 00:50:07 --> Hooks Class Initialized
DEBUG - 2018-06-01 00:50:07 --> UTF-8 Support Enabled
INFO - 2018-06-01 00:50:07 --> Utf8 Class Initialized
INFO - 2018-06-01 00:50:07 --> URI Class Initialized
INFO - 2018-06-01 00:50:07 --> Router Class Initialized
INFO - 2018-06-01 00:50:07 --> Output Class Initialized
INFO - 2018-06-01 00:50:07 --> Security Class Initialized
DEBUG - 2018-06-01 00:50:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 00:50:07 --> Input Class Initialized
INFO - 2018-06-01 00:50:07 --> Language Class Initialized
INFO - 2018-06-01 00:50:07 --> Language Class Initialized
INFO - 2018-06-01 00:50:07 --> Config Class Initialized
INFO - 2018-06-01 00:50:07 --> Loader Class Initialized
DEBUG - 2018-06-01 00:50:07 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-01 00:50:07 --> Helper loaded: url_helper
INFO - 2018-06-01 00:50:07 --> Helper loaded: form_helper
INFO - 2018-06-01 00:50:07 --> Helper loaded: date_helper
INFO - 2018-06-01 00:50:07 --> Helper loaded: util_helper
INFO - 2018-06-01 00:50:07 --> Helper loaded: text_helper
INFO - 2018-06-01 00:50:07 --> Helper loaded: string_helper
INFO - 2018-06-01 00:50:07 --> Database Driver Class Initialized
DEBUG - 2018-06-01 00:50:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-01 00:50:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-01 00:50:07 --> Email Class Initialized
INFO - 2018-06-01 00:50:07 --> Controller Class Initialized
DEBUG - 2018-06-01 00:50:07 --> Home MX_Controller Initialized
DEBUG - 2018-06-01 00:50:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-01 00:50:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-06-01 00:50:07 --> Final output sent to browser
DEBUG - 2018-06-01 00:50:07 --> Total execution time: 0.3587
INFO - 2018-06-01 00:50:07 --> Config Class Initialized
INFO - 2018-06-01 00:50:07 --> Hooks Class Initialized
DEBUG - 2018-06-01 00:50:07 --> UTF-8 Support Enabled
INFO - 2018-06-01 00:50:07 --> Utf8 Class Initialized
INFO - 2018-06-01 00:50:07 --> URI Class Initialized
INFO - 2018-06-01 00:50:07 --> Router Class Initialized
INFO - 2018-06-01 00:50:07 --> Output Class Initialized
INFO - 2018-06-01 00:50:07 --> Security Class Initialized
DEBUG - 2018-06-01 00:50:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 00:50:07 --> Input Class Initialized
INFO - 2018-06-01 00:50:07 --> Language Class Initialized
INFO - 2018-06-01 00:50:07 --> Language Class Initialized
INFO - 2018-06-01 00:50:07 --> Config Class Initialized
INFO - 2018-06-01 00:50:07 --> Loader Class Initialized
DEBUG - 2018-06-01 00:50:07 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-01 00:50:07 --> Helper loaded: url_helper
INFO - 2018-06-01 00:50:07 --> Helper loaded: form_helper
INFO - 2018-06-01 00:50:07 --> Helper loaded: date_helper
INFO - 2018-06-01 00:50:07 --> Helper loaded: util_helper
INFO - 2018-06-01 00:50:07 --> Helper loaded: text_helper
INFO - 2018-06-01 00:50:07 --> Helper loaded: string_helper
INFO - 2018-06-01 00:50:07 --> Database Driver Class Initialized
DEBUG - 2018-06-01 00:50:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-01 00:50:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-01 00:50:07 --> Email Class Initialized
INFO - 2018-06-01 00:50:07 --> Controller Class Initialized
DEBUG - 2018-06-01 00:50:07 --> Home MX_Controller Initialized
DEBUG - 2018-06-01 00:50:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-06-01 00:50:09 --> Config Class Initialized
INFO - 2018-06-01 00:50:09 --> Hooks Class Initialized
DEBUG - 2018-06-01 00:50:09 --> UTF-8 Support Enabled
INFO - 2018-06-01 00:50:09 --> Utf8 Class Initialized
INFO - 2018-06-01 00:50:09 --> URI Class Initialized
INFO - 2018-06-01 00:50:09 --> Router Class Initialized
INFO - 2018-06-01 00:50:09 --> Output Class Initialized
INFO - 2018-06-01 00:50:10 --> Security Class Initialized
DEBUG - 2018-06-01 00:50:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 00:50:10 --> Input Class Initialized
INFO - 2018-06-01 00:50:10 --> Language Class Initialized
INFO - 2018-06-01 00:50:10 --> Language Class Initialized
INFO - 2018-06-01 00:50:10 --> Config Class Initialized
INFO - 2018-06-01 00:50:10 --> Loader Class Initialized
DEBUG - 2018-06-01 00:50:10 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-01 00:50:10 --> Helper loaded: url_helper
INFO - 2018-06-01 00:50:10 --> Helper loaded: form_helper
INFO - 2018-06-01 00:50:10 --> Helper loaded: date_helper
INFO - 2018-06-01 00:50:10 --> Helper loaded: util_helper
INFO - 2018-06-01 00:50:10 --> Helper loaded: text_helper
INFO - 2018-06-01 00:50:10 --> Helper loaded: string_helper
INFO - 2018-06-01 00:50:10 --> Database Driver Class Initialized
DEBUG - 2018-06-01 00:50:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-01 00:50:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-01 00:50:10 --> Email Class Initialized
INFO - 2018-06-01 00:50:10 --> Controller Class Initialized
DEBUG - 2018-06-01 00:50:10 --> Home MX_Controller Initialized
DEBUG - 2018-06-01 00:50:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-01 00:50:10 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-01 00:50:10 --> Login MX_Controller Initialized
INFO - 2018-06-01 00:50:10 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-01 00:50:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-01 00:50:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-01 00:50:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-01 00:50:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-01 00:50:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-01 00:50:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-01 00:50:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-01 00:50:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-06-01 00:50:10 --> Final output sent to browser
DEBUG - 2018-06-01 00:50:10 --> Total execution time: 0.3877
INFO - 2018-06-01 00:50:10 --> Config Class Initialized
INFO - 2018-06-01 00:50:10 --> Config Class Initialized
INFO - 2018-06-01 00:50:10 --> Hooks Class Initialized
INFO - 2018-06-01 00:50:10 --> Hooks Class Initialized
DEBUG - 2018-06-01 00:50:10 --> UTF-8 Support Enabled
INFO - 2018-06-01 00:50:10 --> Utf8 Class Initialized
DEBUG - 2018-06-01 00:50:10 --> UTF-8 Support Enabled
INFO - 2018-06-01 00:50:10 --> URI Class Initialized
INFO - 2018-06-01 00:50:10 --> Router Class Initialized
INFO - 2018-06-01 00:50:10 --> Utf8 Class Initialized
INFO - 2018-06-01 00:50:10 --> Output Class Initialized
INFO - 2018-06-01 00:50:10 --> URI Class Initialized
INFO - 2018-06-01 00:50:10 --> Security Class Initialized
DEBUG - 2018-06-01 00:50:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 00:50:10 --> Router Class Initialized
INFO - 2018-06-01 00:50:10 --> Input Class Initialized
INFO - 2018-06-01 00:50:10 --> Output Class Initialized
INFO - 2018-06-01 00:50:10 --> Security Class Initialized
INFO - 2018-06-01 00:50:10 --> Language Class Initialized
ERROR - 2018-06-01 00:50:10 --> 404 Page Not Found: /index
DEBUG - 2018-06-01 00:50:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 00:50:10 --> Input Class Initialized
INFO - 2018-06-01 00:50:10 --> Language Class Initialized
ERROR - 2018-06-01 00:50:10 --> 404 Page Not Found: /index
INFO - 2018-06-01 00:50:10 --> Config Class Initialized
INFO - 2018-06-01 00:50:10 --> Hooks Class Initialized
DEBUG - 2018-06-01 00:50:10 --> UTF-8 Support Enabled
INFO - 2018-06-01 00:50:10 --> Utf8 Class Initialized
INFO - 2018-06-01 00:50:10 --> URI Class Initialized
INFO - 2018-06-01 00:50:10 --> Router Class Initialized
INFO - 2018-06-01 00:50:10 --> Output Class Initialized
INFO - 2018-06-01 00:50:10 --> Security Class Initialized
DEBUG - 2018-06-01 00:50:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 00:50:11 --> Input Class Initialized
INFO - 2018-06-01 00:50:11 --> Language Class Initialized
ERROR - 2018-06-01 00:50:11 --> 404 Page Not Found: /index
INFO - 2018-06-01 00:50:11 --> Config Class Initialized
INFO - 2018-06-01 00:50:11 --> Hooks Class Initialized
DEBUG - 2018-06-01 00:50:11 --> UTF-8 Support Enabled
INFO - 2018-06-01 00:50:11 --> Utf8 Class Initialized
INFO - 2018-06-01 00:50:11 --> URI Class Initialized
INFO - 2018-06-01 00:50:11 --> Router Class Initialized
INFO - 2018-06-01 00:50:11 --> Output Class Initialized
INFO - 2018-06-01 00:50:11 --> Security Class Initialized
DEBUG - 2018-06-01 00:50:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 00:50:11 --> Input Class Initialized
INFO - 2018-06-01 00:50:11 --> Language Class Initialized
ERROR - 2018-06-01 00:50:11 --> 404 Page Not Found: /index
INFO - 2018-06-01 00:50:13 --> Config Class Initialized
INFO - 2018-06-01 00:50:13 --> Hooks Class Initialized
DEBUG - 2018-06-01 00:50:13 --> UTF-8 Support Enabled
INFO - 2018-06-01 00:50:13 --> Utf8 Class Initialized
INFO - 2018-06-01 00:50:13 --> URI Class Initialized
INFO - 2018-06-01 00:50:13 --> Router Class Initialized
INFO - 2018-06-01 00:50:13 --> Output Class Initialized
INFO - 2018-06-01 00:50:13 --> Security Class Initialized
DEBUG - 2018-06-01 00:50:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 00:50:13 --> Input Class Initialized
INFO - 2018-06-01 00:50:13 --> Language Class Initialized
INFO - 2018-06-01 00:50:13 --> Language Class Initialized
INFO - 2018-06-01 00:50:13 --> Config Class Initialized
INFO - 2018-06-01 00:50:13 --> Loader Class Initialized
DEBUG - 2018-06-01 00:50:13 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-01 00:50:13 --> Helper loaded: url_helper
INFO - 2018-06-01 00:50:13 --> Helper loaded: form_helper
INFO - 2018-06-01 00:50:13 --> Helper loaded: date_helper
INFO - 2018-06-01 00:50:13 --> Helper loaded: util_helper
INFO - 2018-06-01 00:50:13 --> Helper loaded: text_helper
INFO - 2018-06-01 00:50:13 --> Helper loaded: string_helper
INFO - 2018-06-01 00:50:13 --> Database Driver Class Initialized
DEBUG - 2018-06-01 00:50:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-01 00:50:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-01 00:50:13 --> Email Class Initialized
INFO - 2018-06-01 00:50:13 --> Controller Class Initialized
DEBUG - 2018-06-01 00:50:13 --> Home MX_Controller Initialized
DEBUG - 2018-06-01 00:50:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-01 00:50:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-06-01 00:50:13 --> Final output sent to browser
DEBUG - 2018-06-01 00:50:13 --> Total execution time: 0.3712
INFO - 2018-06-01 00:50:13 --> Config Class Initialized
INFO - 2018-06-01 00:50:13 --> Hooks Class Initialized
DEBUG - 2018-06-01 00:50:13 --> UTF-8 Support Enabled
INFO - 2018-06-01 00:50:13 --> Utf8 Class Initialized
INFO - 2018-06-01 00:50:13 --> URI Class Initialized
INFO - 2018-06-01 00:50:13 --> Router Class Initialized
INFO - 2018-06-01 00:50:13 --> Output Class Initialized
INFO - 2018-06-01 00:50:13 --> Security Class Initialized
DEBUG - 2018-06-01 00:50:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 00:50:13 --> Input Class Initialized
INFO - 2018-06-01 00:50:13 --> Language Class Initialized
INFO - 2018-06-01 00:50:13 --> Language Class Initialized
INFO - 2018-06-01 00:50:13 --> Config Class Initialized
INFO - 2018-06-01 00:50:13 --> Loader Class Initialized
DEBUG - 2018-06-01 00:50:13 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-01 00:50:13 --> Helper loaded: url_helper
INFO - 2018-06-01 00:50:13 --> Helper loaded: form_helper
INFO - 2018-06-01 00:50:13 --> Helper loaded: date_helper
INFO - 2018-06-01 00:50:13 --> Helper loaded: util_helper
INFO - 2018-06-01 00:50:13 --> Helper loaded: text_helper
INFO - 2018-06-01 00:50:13 --> Helper loaded: string_helper
INFO - 2018-06-01 00:50:13 --> Database Driver Class Initialized
DEBUG - 2018-06-01 00:50:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-01 00:50:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-01 00:50:13 --> Email Class Initialized
INFO - 2018-06-01 00:50:13 --> Controller Class Initialized
DEBUG - 2018-06-01 00:50:13 --> Home MX_Controller Initialized
DEBUG - 2018-06-01 00:50:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-06-01 00:50:18 --> Config Class Initialized
INFO - 2018-06-01 00:50:18 --> Hooks Class Initialized
DEBUG - 2018-06-01 00:50:18 --> UTF-8 Support Enabled
INFO - 2018-06-01 00:50:18 --> Utf8 Class Initialized
INFO - 2018-06-01 00:50:18 --> URI Class Initialized
INFO - 2018-06-01 00:50:18 --> Router Class Initialized
INFO - 2018-06-01 00:50:18 --> Output Class Initialized
INFO - 2018-06-01 00:50:18 --> Security Class Initialized
DEBUG - 2018-06-01 00:50:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 00:50:19 --> Input Class Initialized
INFO - 2018-06-01 00:50:19 --> Language Class Initialized
INFO - 2018-06-01 00:50:19 --> Language Class Initialized
INFO - 2018-06-01 00:50:19 --> Config Class Initialized
INFO - 2018-06-01 00:50:19 --> Loader Class Initialized
DEBUG - 2018-06-01 00:50:19 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-01 00:50:19 --> Helper loaded: url_helper
INFO - 2018-06-01 00:50:19 --> Helper loaded: form_helper
INFO - 2018-06-01 00:50:19 --> Helper loaded: date_helper
INFO - 2018-06-01 00:50:19 --> Helper loaded: util_helper
INFO - 2018-06-01 00:50:19 --> Helper loaded: text_helper
INFO - 2018-06-01 00:50:19 --> Helper loaded: string_helper
INFO - 2018-06-01 00:50:19 --> Database Driver Class Initialized
DEBUG - 2018-06-01 00:50:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-01 00:50:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-01 00:50:19 --> Email Class Initialized
INFO - 2018-06-01 00:50:19 --> Controller Class Initialized
DEBUG - 2018-06-01 00:50:19 --> Home MX_Controller Initialized
DEBUG - 2018-06-01 00:50:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-01 00:50:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-06-01 00:50:19 --> Final output sent to browser
DEBUG - 2018-06-01 00:50:19 --> Total execution time: 0.3435
INFO - 2018-06-01 00:50:19 --> Config Class Initialized
INFO - 2018-06-01 00:50:19 --> Hooks Class Initialized
DEBUG - 2018-06-01 00:50:19 --> UTF-8 Support Enabled
INFO - 2018-06-01 00:50:19 --> Utf8 Class Initialized
INFO - 2018-06-01 00:50:19 --> URI Class Initialized
INFO - 2018-06-01 00:50:19 --> Router Class Initialized
INFO - 2018-06-01 00:50:19 --> Output Class Initialized
INFO - 2018-06-01 00:50:19 --> Security Class Initialized
DEBUG - 2018-06-01 00:50:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 00:50:19 --> Input Class Initialized
INFO - 2018-06-01 00:50:19 --> Language Class Initialized
INFO - 2018-06-01 00:50:19 --> Language Class Initialized
INFO - 2018-06-01 00:50:19 --> Config Class Initialized
INFO - 2018-06-01 00:50:19 --> Loader Class Initialized
DEBUG - 2018-06-01 00:50:19 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-01 00:50:19 --> Helper loaded: url_helper
INFO - 2018-06-01 00:50:19 --> Helper loaded: form_helper
INFO - 2018-06-01 00:50:19 --> Helper loaded: date_helper
INFO - 2018-06-01 00:50:19 --> Helper loaded: util_helper
INFO - 2018-06-01 00:50:19 --> Helper loaded: text_helper
INFO - 2018-06-01 00:50:19 --> Helper loaded: string_helper
INFO - 2018-06-01 00:50:19 --> Database Driver Class Initialized
DEBUG - 2018-06-01 00:50:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-01 00:50:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-01 00:50:19 --> Email Class Initialized
INFO - 2018-06-01 00:50:19 --> Controller Class Initialized
DEBUG - 2018-06-01 00:50:19 --> Home MX_Controller Initialized
DEBUG - 2018-06-01 00:50:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-06-01 00:50:20 --> Config Class Initialized
INFO - 2018-06-01 00:50:20 --> Hooks Class Initialized
DEBUG - 2018-06-01 00:50:20 --> UTF-8 Support Enabled
INFO - 2018-06-01 00:50:20 --> Utf8 Class Initialized
INFO - 2018-06-01 00:50:20 --> URI Class Initialized
INFO - 2018-06-01 00:50:20 --> Router Class Initialized
INFO - 2018-06-01 00:50:20 --> Output Class Initialized
INFO - 2018-06-01 00:50:20 --> Security Class Initialized
DEBUG - 2018-06-01 00:50:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 00:50:20 --> Input Class Initialized
INFO - 2018-06-01 00:50:20 --> Language Class Initialized
INFO - 2018-06-01 00:50:20 --> Language Class Initialized
INFO - 2018-06-01 00:50:20 --> Config Class Initialized
INFO - 2018-06-01 00:50:20 --> Loader Class Initialized
DEBUG - 2018-06-01 00:50:20 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-01 00:50:20 --> Helper loaded: url_helper
INFO - 2018-06-01 00:50:20 --> Helper loaded: form_helper
INFO - 2018-06-01 00:50:20 --> Helper loaded: date_helper
INFO - 2018-06-01 00:50:20 --> Helper loaded: util_helper
INFO - 2018-06-01 00:50:20 --> Helper loaded: text_helper
INFO - 2018-06-01 00:50:20 --> Helper loaded: string_helper
INFO - 2018-06-01 00:50:20 --> Database Driver Class Initialized
DEBUG - 2018-06-01 00:50:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-01 00:50:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-01 00:50:20 --> Email Class Initialized
INFO - 2018-06-01 00:50:20 --> Controller Class Initialized
DEBUG - 2018-06-01 00:50:20 --> Home MX_Controller Initialized
DEBUG - 2018-06-01 00:50:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-01 00:50:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-06-01 00:50:20 --> Final output sent to browser
DEBUG - 2018-06-01 00:50:20 --> Total execution time: 0.3241
INFO - 2018-06-01 00:50:20 --> Config Class Initialized
INFO - 2018-06-01 00:50:20 --> Hooks Class Initialized
DEBUG - 2018-06-01 00:50:20 --> UTF-8 Support Enabled
INFO - 2018-06-01 00:50:20 --> Utf8 Class Initialized
INFO - 2018-06-01 00:50:20 --> URI Class Initialized
INFO - 2018-06-01 00:50:20 --> Router Class Initialized
INFO - 2018-06-01 00:50:20 --> Output Class Initialized
INFO - 2018-06-01 00:50:20 --> Security Class Initialized
DEBUG - 2018-06-01 00:50:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 00:50:20 --> Input Class Initialized
INFO - 2018-06-01 00:50:20 --> Language Class Initialized
INFO - 2018-06-01 00:50:20 --> Language Class Initialized
INFO - 2018-06-01 00:50:20 --> Config Class Initialized
INFO - 2018-06-01 00:50:20 --> Loader Class Initialized
DEBUG - 2018-06-01 00:50:20 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-01 00:50:20 --> Helper loaded: url_helper
INFO - 2018-06-01 00:50:20 --> Helper loaded: form_helper
INFO - 2018-06-01 00:50:20 --> Helper loaded: date_helper
INFO - 2018-06-01 00:50:20 --> Helper loaded: util_helper
INFO - 2018-06-01 00:50:20 --> Helper loaded: text_helper
INFO - 2018-06-01 00:50:20 --> Helper loaded: string_helper
INFO - 2018-06-01 00:50:20 --> Database Driver Class Initialized
DEBUG - 2018-06-01 00:50:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-01 00:50:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-01 00:50:20 --> Email Class Initialized
INFO - 2018-06-01 00:50:20 --> Controller Class Initialized
DEBUG - 2018-06-01 00:50:20 --> Home MX_Controller Initialized
DEBUG - 2018-06-01 00:50:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-06-01 00:51:16 --> Config Class Initialized
INFO - 2018-06-01 00:51:16 --> Hooks Class Initialized
DEBUG - 2018-06-01 00:51:16 --> UTF-8 Support Enabled
INFO - 2018-06-01 00:51:16 --> Utf8 Class Initialized
INFO - 2018-06-01 00:51:16 --> URI Class Initialized
INFO - 2018-06-01 00:51:16 --> Router Class Initialized
INFO - 2018-06-01 00:51:16 --> Output Class Initialized
INFO - 2018-06-01 00:51:16 --> Security Class Initialized
DEBUG - 2018-06-01 00:51:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 00:51:16 --> Input Class Initialized
INFO - 2018-06-01 00:51:16 --> Language Class Initialized
INFO - 2018-06-01 00:51:16 --> Language Class Initialized
INFO - 2018-06-01 00:51:16 --> Config Class Initialized
INFO - 2018-06-01 00:51:16 --> Loader Class Initialized
DEBUG - 2018-06-01 00:51:16 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-01 00:51:16 --> Helper loaded: url_helper
INFO - 2018-06-01 00:51:16 --> Helper loaded: form_helper
INFO - 2018-06-01 00:51:16 --> Helper loaded: date_helper
INFO - 2018-06-01 00:51:16 --> Helper loaded: util_helper
INFO - 2018-06-01 00:51:16 --> Helper loaded: text_helper
INFO - 2018-06-01 00:51:16 --> Helper loaded: string_helper
INFO - 2018-06-01 00:51:16 --> Database Driver Class Initialized
DEBUG - 2018-06-01 00:51:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-01 00:51:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-01 00:51:16 --> Email Class Initialized
INFO - 2018-06-01 00:51:16 --> Controller Class Initialized
DEBUG - 2018-06-01 00:51:16 --> Home MX_Controller Initialized
DEBUG - 2018-06-01 00:51:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-01 00:51:16 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-01 00:51:16 --> Login MX_Controller Initialized
INFO - 2018-06-01 00:51:16 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-01 00:51:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-01 00:51:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-01 00:51:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-01 00:51:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-01 00:51:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-01 00:51:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-01 00:51:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-01 00:51:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-06-01 00:51:16 --> Final output sent to browser
DEBUG - 2018-06-01 00:51:16 --> Total execution time: 0.4042
INFO - 2018-06-01 00:51:16 --> Config Class Initialized
INFO - 2018-06-01 00:51:16 --> Hooks Class Initialized
DEBUG - 2018-06-01 00:51:17 --> UTF-8 Support Enabled
INFO - 2018-06-01 00:51:17 --> Utf8 Class Initialized
INFO - 2018-06-01 00:51:17 --> URI Class Initialized
INFO - 2018-06-01 00:51:17 --> Router Class Initialized
INFO - 2018-06-01 00:51:17 --> Output Class Initialized
INFO - 2018-06-01 00:51:17 --> Security Class Initialized
DEBUG - 2018-06-01 00:51:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 00:51:17 --> Input Class Initialized
INFO - 2018-06-01 00:51:17 --> Language Class Initialized
ERROR - 2018-06-01 00:51:17 --> 404 Page Not Found: /index
INFO - 2018-06-01 00:51:17 --> Config Class Initialized
INFO - 2018-06-01 00:51:17 --> Hooks Class Initialized
DEBUG - 2018-06-01 00:51:17 --> UTF-8 Support Enabled
INFO - 2018-06-01 00:51:17 --> Utf8 Class Initialized
INFO - 2018-06-01 00:51:17 --> URI Class Initialized
INFO - 2018-06-01 00:51:17 --> Router Class Initialized
INFO - 2018-06-01 00:51:17 --> Output Class Initialized
INFO - 2018-06-01 00:51:17 --> Security Class Initialized
DEBUG - 2018-06-01 00:51:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 00:51:17 --> Input Class Initialized
INFO - 2018-06-01 00:51:17 --> Language Class Initialized
ERROR - 2018-06-01 00:51:17 --> 404 Page Not Found: /index
INFO - 2018-06-01 00:51:17 --> Config Class Initialized
INFO - 2018-06-01 00:51:17 --> Hooks Class Initialized
DEBUG - 2018-06-01 00:51:17 --> UTF-8 Support Enabled
INFO - 2018-06-01 00:51:17 --> Utf8 Class Initialized
INFO - 2018-06-01 00:51:17 --> URI Class Initialized
INFO - 2018-06-01 00:51:17 --> Router Class Initialized
INFO - 2018-06-01 00:51:17 --> Output Class Initialized
INFO - 2018-06-01 00:51:17 --> Security Class Initialized
DEBUG - 2018-06-01 00:51:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 00:51:17 --> Input Class Initialized
INFO - 2018-06-01 00:51:17 --> Language Class Initialized
ERROR - 2018-06-01 00:51:17 --> 404 Page Not Found: /index
INFO - 2018-06-01 00:51:18 --> Config Class Initialized
INFO - 2018-06-01 00:51:18 --> Hooks Class Initialized
DEBUG - 2018-06-01 00:51:18 --> UTF-8 Support Enabled
INFO - 2018-06-01 00:51:18 --> Utf8 Class Initialized
INFO - 2018-06-01 00:51:18 --> URI Class Initialized
INFO - 2018-06-01 00:51:18 --> Router Class Initialized
INFO - 2018-06-01 00:51:18 --> Output Class Initialized
INFO - 2018-06-01 00:51:18 --> Security Class Initialized
DEBUG - 2018-06-01 00:51:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 00:51:18 --> Input Class Initialized
INFO - 2018-06-01 00:51:18 --> Language Class Initialized
INFO - 2018-06-01 00:51:18 --> Language Class Initialized
INFO - 2018-06-01 00:51:18 --> Config Class Initialized
INFO - 2018-06-01 00:51:18 --> Loader Class Initialized
DEBUG - 2018-06-01 00:51:18 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-01 00:51:18 --> Helper loaded: url_helper
INFO - 2018-06-01 00:51:18 --> Helper loaded: form_helper
INFO - 2018-06-01 00:51:18 --> Helper loaded: date_helper
INFO - 2018-06-01 00:51:18 --> Helper loaded: util_helper
INFO - 2018-06-01 00:51:18 --> Helper loaded: text_helper
INFO - 2018-06-01 00:51:19 --> Helper loaded: string_helper
INFO - 2018-06-01 00:51:19 --> Database Driver Class Initialized
DEBUG - 2018-06-01 00:51:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-01 00:51:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-01 00:51:19 --> Email Class Initialized
INFO - 2018-06-01 00:51:19 --> Controller Class Initialized
DEBUG - 2018-06-01 00:51:19 --> Home MX_Controller Initialized
DEBUG - 2018-06-01 00:51:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-01 00:51:19 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-01 00:51:19 --> Login MX_Controller Initialized
INFO - 2018-06-01 00:51:19 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-01 00:51:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-01 00:51:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-01 00:51:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-01 00:51:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-01 00:51:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-01 00:51:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-01 00:51:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-01 00:51:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/progress.php
INFO - 2018-06-01 00:51:19 --> Final output sent to browser
DEBUG - 2018-06-01 00:51:19 --> Total execution time: 0.4172
INFO - 2018-06-01 00:51:19 --> Config Class Initialized
INFO - 2018-06-01 00:51:19 --> Hooks Class Initialized
DEBUG - 2018-06-01 00:51:19 --> UTF-8 Support Enabled
INFO - 2018-06-01 00:51:19 --> Utf8 Class Initialized
INFO - 2018-06-01 00:51:19 --> URI Class Initialized
INFO - 2018-06-01 00:51:19 --> Router Class Initialized
INFO - 2018-06-01 00:51:19 --> Output Class Initialized
INFO - 2018-06-01 00:51:19 --> Security Class Initialized
DEBUG - 2018-06-01 00:51:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 00:51:19 --> Input Class Initialized
INFO - 2018-06-01 00:51:19 --> Language Class Initialized
ERROR - 2018-06-01 00:51:19 --> 404 Page Not Found: /index
INFO - 2018-06-01 00:51:19 --> Config Class Initialized
INFO - 2018-06-01 00:51:19 --> Hooks Class Initialized
DEBUG - 2018-06-01 00:51:19 --> UTF-8 Support Enabled
INFO - 2018-06-01 00:51:19 --> Utf8 Class Initialized
INFO - 2018-06-01 00:51:19 --> URI Class Initialized
INFO - 2018-06-01 00:51:19 --> Router Class Initialized
INFO - 2018-06-01 00:51:19 --> Output Class Initialized
INFO - 2018-06-01 00:51:19 --> Security Class Initialized
DEBUG - 2018-06-01 00:51:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 00:51:19 --> Input Class Initialized
INFO - 2018-06-01 00:51:19 --> Language Class Initialized
ERROR - 2018-06-01 00:51:19 --> 404 Page Not Found: /index
INFO - 2018-06-01 00:51:19 --> Config Class Initialized
INFO - 2018-06-01 00:51:19 --> Hooks Class Initialized
DEBUG - 2018-06-01 00:51:19 --> UTF-8 Support Enabled
INFO - 2018-06-01 00:51:19 --> Utf8 Class Initialized
INFO - 2018-06-01 00:51:20 --> URI Class Initialized
INFO - 2018-06-01 00:51:20 --> Router Class Initialized
INFO - 2018-06-01 00:51:20 --> Output Class Initialized
INFO - 2018-06-01 00:51:20 --> Security Class Initialized
DEBUG - 2018-06-01 00:51:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 00:51:20 --> Input Class Initialized
INFO - 2018-06-01 00:51:20 --> Language Class Initialized
ERROR - 2018-06-01 00:51:20 --> 404 Page Not Found: /index
INFO - 2018-06-01 00:51:22 --> Config Class Initialized
INFO - 2018-06-01 00:51:22 --> Hooks Class Initialized
DEBUG - 2018-06-01 00:51:22 --> UTF-8 Support Enabled
INFO - 2018-06-01 00:51:22 --> Utf8 Class Initialized
INFO - 2018-06-01 00:51:22 --> URI Class Initialized
INFO - 2018-06-01 00:51:22 --> Router Class Initialized
INFO - 2018-06-01 00:51:22 --> Output Class Initialized
INFO - 2018-06-01 00:51:22 --> Security Class Initialized
DEBUG - 2018-06-01 00:51:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 00:51:22 --> Input Class Initialized
INFO - 2018-06-01 00:51:22 --> Language Class Initialized
INFO - 2018-06-01 00:51:22 --> Language Class Initialized
INFO - 2018-06-01 00:51:22 --> Config Class Initialized
INFO - 2018-06-01 00:51:22 --> Loader Class Initialized
DEBUG - 2018-06-01 00:51:22 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-01 00:51:22 --> Helper loaded: url_helper
INFO - 2018-06-01 00:51:22 --> Helper loaded: form_helper
INFO - 2018-06-01 00:51:22 --> Helper loaded: date_helper
INFO - 2018-06-01 00:51:22 --> Helper loaded: util_helper
INFO - 2018-06-01 00:51:22 --> Helper loaded: text_helper
INFO - 2018-06-01 00:51:22 --> Helper loaded: string_helper
INFO - 2018-06-01 00:51:22 --> Database Driver Class Initialized
DEBUG - 2018-06-01 00:51:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-01 00:51:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-01 00:51:22 --> Email Class Initialized
INFO - 2018-06-01 00:51:22 --> Controller Class Initialized
DEBUG - 2018-06-01 00:51:22 --> Home MX_Controller Initialized
DEBUG - 2018-06-01 00:51:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-01 00:51:22 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-01 00:51:22 --> Login MX_Controller Initialized
INFO - 2018-06-01 00:51:22 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-01 00:51:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-01 00:51:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-01 00:51:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-01 00:51:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-01 00:51:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-01 00:51:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-01 00:51:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-01 00:51:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/progress_product.php
INFO - 2018-06-01 00:51:22 --> Final output sent to browser
DEBUG - 2018-06-01 00:51:22 --> Total execution time: 0.4218
INFO - 2018-06-01 00:51:23 --> Config Class Initialized
INFO - 2018-06-01 00:51:23 --> Hooks Class Initialized
DEBUG - 2018-06-01 00:51:23 --> UTF-8 Support Enabled
INFO - 2018-06-01 00:51:23 --> Utf8 Class Initialized
INFO - 2018-06-01 00:51:23 --> URI Class Initialized
INFO - 2018-06-01 00:51:23 --> Router Class Initialized
INFO - 2018-06-01 00:51:23 --> Output Class Initialized
INFO - 2018-06-01 00:51:23 --> Security Class Initialized
DEBUG - 2018-06-01 00:51:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 00:51:23 --> Input Class Initialized
INFO - 2018-06-01 00:51:23 --> Language Class Initialized
ERROR - 2018-06-01 00:51:23 --> 404 Page Not Found: /index
INFO - 2018-06-01 00:51:23 --> Config Class Initialized
INFO - 2018-06-01 00:51:23 --> Hooks Class Initialized
DEBUG - 2018-06-01 00:51:23 --> UTF-8 Support Enabled
INFO - 2018-06-01 00:51:23 --> Utf8 Class Initialized
INFO - 2018-06-01 00:51:23 --> URI Class Initialized
INFO - 2018-06-01 00:51:23 --> Router Class Initialized
INFO - 2018-06-01 00:51:23 --> Output Class Initialized
INFO - 2018-06-01 00:51:23 --> Security Class Initialized
DEBUG - 2018-06-01 00:51:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 00:51:23 --> Input Class Initialized
INFO - 2018-06-01 00:51:23 --> Language Class Initialized
ERROR - 2018-06-01 00:51:23 --> 404 Page Not Found: /index
INFO - 2018-06-01 00:51:23 --> Config Class Initialized
INFO - 2018-06-01 00:51:23 --> Hooks Class Initialized
DEBUG - 2018-06-01 00:51:23 --> UTF-8 Support Enabled
INFO - 2018-06-01 00:51:23 --> Utf8 Class Initialized
INFO - 2018-06-01 00:51:23 --> URI Class Initialized
INFO - 2018-06-01 00:51:23 --> Router Class Initialized
INFO - 2018-06-01 00:51:23 --> Output Class Initialized
INFO - 2018-06-01 00:51:23 --> Security Class Initialized
DEBUG - 2018-06-01 00:51:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 00:51:23 --> Input Class Initialized
INFO - 2018-06-01 00:51:23 --> Language Class Initialized
ERROR - 2018-06-01 00:51:23 --> 404 Page Not Found: /index
INFO - 2018-06-01 00:52:30 --> Config Class Initialized
INFO - 2018-06-01 00:52:30 --> Hooks Class Initialized
DEBUG - 2018-06-01 00:52:30 --> UTF-8 Support Enabled
INFO - 2018-06-01 00:52:30 --> Utf8 Class Initialized
INFO - 2018-06-01 00:52:30 --> URI Class Initialized
INFO - 2018-06-01 00:52:30 --> Router Class Initialized
INFO - 2018-06-01 00:52:30 --> Output Class Initialized
INFO - 2018-06-01 00:52:30 --> Security Class Initialized
DEBUG - 2018-06-01 00:52:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 00:52:30 --> Input Class Initialized
INFO - 2018-06-01 00:52:30 --> Language Class Initialized
INFO - 2018-06-01 00:52:30 --> Language Class Initialized
INFO - 2018-06-01 00:52:30 --> Config Class Initialized
INFO - 2018-06-01 00:52:30 --> Loader Class Initialized
DEBUG - 2018-06-01 00:52:30 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-01 00:52:30 --> Helper loaded: url_helper
INFO - 2018-06-01 00:52:30 --> Helper loaded: form_helper
INFO - 2018-06-01 00:52:30 --> Helper loaded: date_helper
INFO - 2018-06-01 00:52:30 --> Helper loaded: util_helper
INFO - 2018-06-01 00:52:30 --> Helper loaded: text_helper
INFO - 2018-06-01 00:52:30 --> Helper loaded: string_helper
INFO - 2018-06-01 00:52:30 --> Database Driver Class Initialized
DEBUG - 2018-06-01 00:52:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-01 00:52:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-01 00:52:30 --> Email Class Initialized
INFO - 2018-06-01 00:52:30 --> Controller Class Initialized
DEBUG - 2018-06-01 00:52:30 --> Home MX_Controller Initialized
DEBUG - 2018-06-01 00:52:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-01 00:52:30 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-01 00:52:30 --> Login MX_Controller Initialized
INFO - 2018-06-01 00:52:30 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-01 00:52:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-01 00:52:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-01 00:52:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-01 00:52:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-01 00:52:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-01 00:52:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-01 00:52:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-01 00:52:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-06-01 00:52:30 --> Final output sent to browser
DEBUG - 2018-06-01 00:52:30 --> Total execution time: 0.5120
INFO - 2018-06-01 00:52:31 --> Config Class Initialized
INFO - 2018-06-01 00:52:31 --> Hooks Class Initialized
DEBUG - 2018-06-01 00:52:31 --> UTF-8 Support Enabled
INFO - 2018-06-01 00:52:31 --> Utf8 Class Initialized
INFO - 2018-06-01 00:52:31 --> URI Class Initialized
INFO - 2018-06-01 00:52:31 --> Router Class Initialized
INFO - 2018-06-01 00:52:31 --> Output Class Initialized
INFO - 2018-06-01 00:52:31 --> Security Class Initialized
DEBUG - 2018-06-01 00:52:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 00:52:31 --> Input Class Initialized
INFO - 2018-06-01 00:52:31 --> Language Class Initialized
ERROR - 2018-06-01 00:52:31 --> 404 Page Not Found: /index
INFO - 2018-06-01 00:52:31 --> Config Class Initialized
INFO - 2018-06-01 00:52:31 --> Hooks Class Initialized
DEBUG - 2018-06-01 00:52:31 --> UTF-8 Support Enabled
INFO - 2018-06-01 00:52:31 --> Utf8 Class Initialized
INFO - 2018-06-01 00:52:31 --> URI Class Initialized
INFO - 2018-06-01 00:52:31 --> Router Class Initialized
INFO - 2018-06-01 00:52:31 --> Output Class Initialized
INFO - 2018-06-01 00:52:31 --> Security Class Initialized
DEBUG - 2018-06-01 00:52:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 00:52:31 --> Input Class Initialized
INFO - 2018-06-01 00:52:31 --> Language Class Initialized
ERROR - 2018-06-01 00:52:31 --> 404 Page Not Found: /index
INFO - 2018-06-01 00:52:31 --> Config Class Initialized
INFO - 2018-06-01 00:52:31 --> Hooks Class Initialized
DEBUG - 2018-06-01 00:52:31 --> UTF-8 Support Enabled
INFO - 2018-06-01 00:52:31 --> Utf8 Class Initialized
INFO - 2018-06-01 00:52:31 --> URI Class Initialized
INFO - 2018-06-01 00:52:31 --> Router Class Initialized
INFO - 2018-06-01 00:52:31 --> Output Class Initialized
INFO - 2018-06-01 00:52:31 --> Security Class Initialized
DEBUG - 2018-06-01 00:52:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 00:52:31 --> Input Class Initialized
INFO - 2018-06-01 00:52:31 --> Language Class Initialized
ERROR - 2018-06-01 00:52:31 --> 404 Page Not Found: /index
INFO - 2018-06-01 00:54:26 --> Config Class Initialized
INFO - 2018-06-01 00:54:26 --> Hooks Class Initialized
DEBUG - 2018-06-01 00:54:26 --> UTF-8 Support Enabled
INFO - 2018-06-01 00:54:26 --> Utf8 Class Initialized
INFO - 2018-06-01 00:54:26 --> URI Class Initialized
INFO - 2018-06-01 00:54:26 --> Router Class Initialized
INFO - 2018-06-01 00:54:26 --> Output Class Initialized
INFO - 2018-06-01 00:54:26 --> Security Class Initialized
DEBUG - 2018-06-01 00:54:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 00:54:26 --> Input Class Initialized
INFO - 2018-06-01 00:54:26 --> Language Class Initialized
INFO - 2018-06-01 00:54:26 --> Language Class Initialized
INFO - 2018-06-01 00:54:26 --> Config Class Initialized
INFO - 2018-06-01 00:54:26 --> Loader Class Initialized
DEBUG - 2018-06-01 00:54:26 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-01 00:54:26 --> Helper loaded: url_helper
INFO - 2018-06-01 00:54:26 --> Helper loaded: form_helper
INFO - 2018-06-01 00:54:26 --> Helper loaded: date_helper
INFO - 2018-06-01 00:54:26 --> Helper loaded: util_helper
INFO - 2018-06-01 00:54:26 --> Helper loaded: text_helper
INFO - 2018-06-01 00:54:26 --> Helper loaded: string_helper
INFO - 2018-06-01 00:54:26 --> Database Driver Class Initialized
DEBUG - 2018-06-01 00:54:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-01 00:54:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-01 00:54:26 --> Email Class Initialized
INFO - 2018-06-01 00:54:26 --> Controller Class Initialized
DEBUG - 2018-06-01 00:54:26 --> Home MX_Controller Initialized
DEBUG - 2018-06-01 00:54:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-01 00:54:26 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-01 00:54:26 --> Login MX_Controller Initialized
INFO - 2018-06-01 00:54:26 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-01 00:54:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-01 00:54:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-01 00:54:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-01 00:54:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-01 00:54:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-01 00:54:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-01 00:54:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-01 00:54:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-06-01 00:54:26 --> Final output sent to browser
DEBUG - 2018-06-01 00:54:27 --> Total execution time: 0.4219
INFO - 2018-06-01 00:54:27 --> Config Class Initialized
INFO - 2018-06-01 00:54:27 --> Config Class Initialized
INFO - 2018-06-01 00:54:27 --> Hooks Class Initialized
INFO - 2018-06-01 00:54:27 --> Hooks Class Initialized
DEBUG - 2018-06-01 00:54:27 --> UTF-8 Support Enabled
DEBUG - 2018-06-01 00:54:27 --> UTF-8 Support Enabled
INFO - 2018-06-01 00:54:27 --> Utf8 Class Initialized
INFO - 2018-06-01 00:54:27 --> Utf8 Class Initialized
INFO - 2018-06-01 00:54:27 --> URI Class Initialized
INFO - 2018-06-01 00:54:27 --> Router Class Initialized
INFO - 2018-06-01 00:54:27 --> Output Class Initialized
INFO - 2018-06-01 00:54:27 --> Security Class Initialized
INFO - 2018-06-01 00:54:27 --> URI Class Initialized
DEBUG - 2018-06-01 00:54:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 00:54:27 --> Input Class Initialized
INFO - 2018-06-01 00:54:27 --> Router Class Initialized
INFO - 2018-06-01 00:54:27 --> Language Class Initialized
INFO - 2018-06-01 00:54:27 --> Output Class Initialized
ERROR - 2018-06-01 00:54:27 --> 404 Page Not Found: /index
INFO - 2018-06-01 00:54:27 --> Security Class Initialized
DEBUG - 2018-06-01 00:54:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 00:54:27 --> Input Class Initialized
INFO - 2018-06-01 00:54:27 --> Language Class Initialized
ERROR - 2018-06-01 00:54:27 --> 404 Page Not Found: /index
INFO - 2018-06-01 00:54:27 --> Config Class Initialized
INFO - 2018-06-01 00:54:27 --> Hooks Class Initialized
DEBUG - 2018-06-01 00:54:27 --> UTF-8 Support Enabled
INFO - 2018-06-01 00:54:27 --> Utf8 Class Initialized
INFO - 2018-06-01 00:54:27 --> URI Class Initialized
INFO - 2018-06-01 00:54:27 --> Router Class Initialized
INFO - 2018-06-01 00:54:27 --> Output Class Initialized
INFO - 2018-06-01 00:54:27 --> Security Class Initialized
DEBUG - 2018-06-01 00:54:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 00:54:27 --> Input Class Initialized
INFO - 2018-06-01 00:54:27 --> Language Class Initialized
ERROR - 2018-06-01 00:54:27 --> 404 Page Not Found: /index
INFO - 2018-06-01 00:54:27 --> Config Class Initialized
INFO - 2018-06-01 00:54:27 --> Hooks Class Initialized
DEBUG - 2018-06-01 00:54:27 --> UTF-8 Support Enabled
INFO - 2018-06-01 00:54:27 --> Utf8 Class Initialized
INFO - 2018-06-01 00:54:27 --> URI Class Initialized
INFO - 2018-06-01 00:54:27 --> Router Class Initialized
INFO - 2018-06-01 00:54:27 --> Output Class Initialized
INFO - 2018-06-01 00:54:27 --> Security Class Initialized
DEBUG - 2018-06-01 00:54:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 00:54:27 --> Input Class Initialized
INFO - 2018-06-01 00:54:27 --> Language Class Initialized
ERROR - 2018-06-01 00:54:28 --> 404 Page Not Found: /index
INFO - 2018-06-01 00:55:12 --> Config Class Initialized
INFO - 2018-06-01 00:55:12 --> Hooks Class Initialized
DEBUG - 2018-06-01 00:55:12 --> UTF-8 Support Enabled
INFO - 2018-06-01 00:55:12 --> Utf8 Class Initialized
INFO - 2018-06-01 00:55:12 --> URI Class Initialized
INFO - 2018-06-01 00:55:12 --> Router Class Initialized
INFO - 2018-06-01 00:55:12 --> Output Class Initialized
INFO - 2018-06-01 00:55:12 --> Security Class Initialized
DEBUG - 2018-06-01 00:55:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 00:55:12 --> Input Class Initialized
INFO - 2018-06-01 00:55:12 --> Language Class Initialized
INFO - 2018-06-01 00:55:12 --> Language Class Initialized
INFO - 2018-06-01 00:55:12 --> Config Class Initialized
INFO - 2018-06-01 00:55:13 --> Loader Class Initialized
DEBUG - 2018-06-01 00:55:13 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-01 00:55:13 --> Helper loaded: url_helper
INFO - 2018-06-01 00:55:13 --> Helper loaded: form_helper
INFO - 2018-06-01 00:55:13 --> Helper loaded: date_helper
INFO - 2018-06-01 00:55:13 --> Helper loaded: util_helper
INFO - 2018-06-01 00:55:13 --> Helper loaded: text_helper
INFO - 2018-06-01 00:55:13 --> Helper loaded: string_helper
INFO - 2018-06-01 00:55:13 --> Database Driver Class Initialized
DEBUG - 2018-06-01 00:55:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-01 00:55:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-01 00:55:13 --> Email Class Initialized
INFO - 2018-06-01 00:55:13 --> Controller Class Initialized
DEBUG - 2018-06-01 00:55:13 --> Home MX_Controller Initialized
DEBUG - 2018-06-01 00:55:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-01 00:55:13 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-01 00:55:13 --> Login MX_Controller Initialized
INFO - 2018-06-01 00:55:13 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-01 00:55:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-01 00:55:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-01 00:55:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-01 00:55:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-01 00:55:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-01 00:55:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-01 00:55:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-01 00:55:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-06-01 00:55:13 --> Final output sent to browser
DEBUG - 2018-06-01 00:55:13 --> Total execution time: 0.4264
INFO - 2018-06-01 00:55:13 --> Config Class Initialized
INFO - 2018-06-01 00:55:13 --> Config Class Initialized
INFO - 2018-06-01 00:55:13 --> Hooks Class Initialized
INFO - 2018-06-01 00:55:13 --> Hooks Class Initialized
DEBUG - 2018-06-01 00:55:13 --> UTF-8 Support Enabled
INFO - 2018-06-01 00:55:13 --> Utf8 Class Initialized
INFO - 2018-06-01 00:55:13 --> URI Class Initialized
DEBUG - 2018-06-01 00:55:13 --> UTF-8 Support Enabled
INFO - 2018-06-01 00:55:13 --> Utf8 Class Initialized
INFO - 2018-06-01 00:55:13 --> URI Class Initialized
INFO - 2018-06-01 00:55:13 --> Router Class Initialized
INFO - 2018-06-01 00:55:13 --> Router Class Initialized
INFO - 2018-06-01 00:55:13 --> Output Class Initialized
INFO - 2018-06-01 00:55:13 --> Output Class Initialized
INFO - 2018-06-01 00:55:13 --> Security Class Initialized
INFO - 2018-06-01 00:55:13 --> Security Class Initialized
DEBUG - 2018-06-01 00:55:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-06-01 00:55:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 00:55:13 --> Input Class Initialized
INFO - 2018-06-01 00:55:13 --> Language Class Initialized
ERROR - 2018-06-01 00:55:13 --> 404 Page Not Found: /index
INFO - 2018-06-01 00:55:13 --> Input Class Initialized
INFO - 2018-06-01 00:55:14 --> Language Class Initialized
ERROR - 2018-06-01 00:55:14 --> 404 Page Not Found: /index
INFO - 2018-06-01 00:55:14 --> Config Class Initialized
INFO - 2018-06-01 00:55:14 --> Hooks Class Initialized
DEBUG - 2018-06-01 00:55:14 --> UTF-8 Support Enabled
INFO - 2018-06-01 00:55:14 --> Utf8 Class Initialized
INFO - 2018-06-01 00:55:14 --> URI Class Initialized
INFO - 2018-06-01 00:55:14 --> Router Class Initialized
INFO - 2018-06-01 00:55:14 --> Output Class Initialized
INFO - 2018-06-01 00:55:14 --> Security Class Initialized
DEBUG - 2018-06-01 00:55:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 00:55:14 --> Input Class Initialized
INFO - 2018-06-01 00:55:14 --> Language Class Initialized
ERROR - 2018-06-01 00:55:14 --> 404 Page Not Found: /index
INFO - 2018-06-01 00:55:14 --> Config Class Initialized
INFO - 2018-06-01 00:55:14 --> Hooks Class Initialized
DEBUG - 2018-06-01 00:55:14 --> UTF-8 Support Enabled
INFO - 2018-06-01 00:55:14 --> Utf8 Class Initialized
INFO - 2018-06-01 00:55:14 --> URI Class Initialized
INFO - 2018-06-01 00:55:14 --> Router Class Initialized
INFO - 2018-06-01 00:55:14 --> Output Class Initialized
INFO - 2018-06-01 00:55:14 --> Security Class Initialized
DEBUG - 2018-06-01 00:55:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 00:55:14 --> Input Class Initialized
INFO - 2018-06-01 00:55:14 --> Language Class Initialized
ERROR - 2018-06-01 00:55:14 --> 404 Page Not Found: /index
INFO - 2018-06-01 00:55:14 --> Config Class Initialized
INFO - 2018-06-01 00:55:14 --> Hooks Class Initialized
DEBUG - 2018-06-01 00:55:14 --> UTF-8 Support Enabled
INFO - 2018-06-01 00:55:14 --> Utf8 Class Initialized
INFO - 2018-06-01 00:55:14 --> URI Class Initialized
INFO - 2018-06-01 00:55:14 --> Router Class Initialized
INFO - 2018-06-01 00:55:14 --> Output Class Initialized
INFO - 2018-06-01 00:55:14 --> Security Class Initialized
DEBUG - 2018-06-01 00:55:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 00:55:14 --> Input Class Initialized
INFO - 2018-06-01 00:55:14 --> Language Class Initialized
ERROR - 2018-06-01 00:55:14 --> 404 Page Not Found: /index
INFO - 2018-06-01 00:55:14 --> Config Class Initialized
INFO - 2018-06-01 00:55:14 --> Hooks Class Initialized
DEBUG - 2018-06-01 00:55:14 --> UTF-8 Support Enabled
INFO - 2018-06-01 00:55:14 --> Utf8 Class Initialized
INFO - 2018-06-01 00:55:14 --> URI Class Initialized
INFO - 2018-06-01 00:55:14 --> Router Class Initialized
INFO - 2018-06-01 00:55:14 --> Output Class Initialized
INFO - 2018-06-01 00:55:14 --> Security Class Initialized
DEBUG - 2018-06-01 00:55:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 00:55:14 --> Input Class Initialized
INFO - 2018-06-01 00:55:14 --> Language Class Initialized
ERROR - 2018-06-01 00:55:14 --> 404 Page Not Found: /index
INFO - 2018-06-01 00:55:14 --> Config Class Initialized
INFO - 2018-06-01 00:55:14 --> Hooks Class Initialized
DEBUG - 2018-06-01 00:55:14 --> UTF-8 Support Enabled
INFO - 2018-06-01 00:55:14 --> Utf8 Class Initialized
INFO - 2018-06-01 00:55:14 --> URI Class Initialized
INFO - 2018-06-01 00:55:14 --> Router Class Initialized
INFO - 2018-06-01 00:55:14 --> Output Class Initialized
INFO - 2018-06-01 00:55:14 --> Security Class Initialized
DEBUG - 2018-06-01 00:55:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 00:55:14 --> Input Class Initialized
INFO - 2018-06-01 00:55:14 --> Language Class Initialized
ERROR - 2018-06-01 00:55:14 --> 404 Page Not Found: /index
INFO - 2018-06-01 00:55:37 --> Config Class Initialized
INFO - 2018-06-01 00:55:37 --> Hooks Class Initialized
DEBUG - 2018-06-01 00:55:37 --> UTF-8 Support Enabled
INFO - 2018-06-01 00:55:37 --> Utf8 Class Initialized
INFO - 2018-06-01 00:55:37 --> URI Class Initialized
INFO - 2018-06-01 00:55:37 --> Router Class Initialized
INFO - 2018-06-01 00:55:37 --> Output Class Initialized
INFO - 2018-06-01 00:55:37 --> Security Class Initialized
DEBUG - 2018-06-01 00:55:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 00:55:37 --> Input Class Initialized
INFO - 2018-06-01 00:55:37 --> Language Class Initialized
INFO - 2018-06-01 00:55:37 --> Language Class Initialized
INFO - 2018-06-01 00:55:37 --> Config Class Initialized
INFO - 2018-06-01 00:55:37 --> Loader Class Initialized
DEBUG - 2018-06-01 00:55:37 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-01 00:55:37 --> Helper loaded: url_helper
INFO - 2018-06-01 00:55:37 --> Helper loaded: form_helper
INFO - 2018-06-01 00:55:37 --> Helper loaded: date_helper
INFO - 2018-06-01 00:55:37 --> Helper loaded: util_helper
INFO - 2018-06-01 00:55:37 --> Helper loaded: text_helper
INFO - 2018-06-01 00:55:37 --> Helper loaded: string_helper
INFO - 2018-06-01 00:55:37 --> Database Driver Class Initialized
DEBUG - 2018-06-01 00:55:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-01 00:55:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-01 00:55:37 --> Email Class Initialized
INFO - 2018-06-01 00:55:37 --> Controller Class Initialized
DEBUG - 2018-06-01 00:55:37 --> Home MX_Controller Initialized
DEBUG - 2018-06-01 00:55:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-01 00:55:37 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-01 00:55:37 --> Login MX_Controller Initialized
INFO - 2018-06-01 00:55:37 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-01 00:55:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-01 00:55:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-01 00:55:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-01 00:55:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-01 00:55:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-01 00:55:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-01 00:55:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-01 00:55:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-06-01 00:55:37 --> Final output sent to browser
DEBUG - 2018-06-01 00:55:37 --> Total execution time: 0.4287
INFO - 2018-06-01 00:55:37 --> Config Class Initialized
INFO - 2018-06-01 00:55:37 --> Config Class Initialized
INFO - 2018-06-01 00:55:37 --> Hooks Class Initialized
INFO - 2018-06-01 00:55:37 --> Hooks Class Initialized
DEBUG - 2018-06-01 00:55:37 --> UTF-8 Support Enabled
DEBUG - 2018-06-01 00:55:37 --> UTF-8 Support Enabled
INFO - 2018-06-01 00:55:37 --> Utf8 Class Initialized
INFO - 2018-06-01 00:55:37 --> Utf8 Class Initialized
INFO - 2018-06-01 00:55:37 --> URI Class Initialized
INFO - 2018-06-01 00:55:37 --> Router Class Initialized
INFO - 2018-06-01 00:55:37 --> Output Class Initialized
INFO - 2018-06-01 00:55:38 --> Security Class Initialized
INFO - 2018-06-01 00:55:38 --> URI Class Initialized
DEBUG - 2018-06-01 00:55:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 00:55:38 --> Input Class Initialized
INFO - 2018-06-01 00:55:38 --> Router Class Initialized
INFO - 2018-06-01 00:55:38 --> Language Class Initialized
INFO - 2018-06-01 00:55:38 --> Output Class Initialized
INFO - 2018-06-01 00:55:38 --> Security Class Initialized
ERROR - 2018-06-01 00:55:38 --> 404 Page Not Found: /index
DEBUG - 2018-06-01 00:55:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 00:55:38 --> Input Class Initialized
INFO - 2018-06-01 00:55:38 --> Language Class Initialized
ERROR - 2018-06-01 00:55:38 --> 404 Page Not Found: /index
INFO - 2018-06-01 00:55:38 --> Config Class Initialized
INFO - 2018-06-01 00:55:38 --> Hooks Class Initialized
DEBUG - 2018-06-01 00:55:38 --> UTF-8 Support Enabled
INFO - 2018-06-01 00:55:38 --> Utf8 Class Initialized
INFO - 2018-06-01 00:55:38 --> URI Class Initialized
INFO - 2018-06-01 00:55:38 --> Router Class Initialized
INFO - 2018-06-01 00:55:38 --> Output Class Initialized
INFO - 2018-06-01 00:55:38 --> Security Class Initialized
DEBUG - 2018-06-01 00:55:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 00:55:38 --> Input Class Initialized
INFO - 2018-06-01 00:55:38 --> Language Class Initialized
ERROR - 2018-06-01 00:55:38 --> 404 Page Not Found: /index
INFO - 2018-06-01 00:55:38 --> Config Class Initialized
INFO - 2018-06-01 00:55:38 --> Hooks Class Initialized
DEBUG - 2018-06-01 00:55:38 --> UTF-8 Support Enabled
INFO - 2018-06-01 00:55:38 --> Utf8 Class Initialized
INFO - 2018-06-01 00:55:38 --> URI Class Initialized
INFO - 2018-06-01 00:55:38 --> Router Class Initialized
INFO - 2018-06-01 00:55:38 --> Output Class Initialized
INFO - 2018-06-01 00:55:38 --> Security Class Initialized
DEBUG - 2018-06-01 00:55:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 00:55:38 --> Input Class Initialized
INFO - 2018-06-01 00:55:38 --> Language Class Initialized
ERROR - 2018-06-01 00:55:38 --> 404 Page Not Found: /index
INFO - 2018-06-01 00:55:40 --> Config Class Initialized
INFO - 2018-06-01 00:55:40 --> Hooks Class Initialized
DEBUG - 2018-06-01 00:55:40 --> UTF-8 Support Enabled
INFO - 2018-06-01 00:55:40 --> Utf8 Class Initialized
INFO - 2018-06-01 00:55:40 --> URI Class Initialized
INFO - 2018-06-01 00:55:40 --> Router Class Initialized
INFO - 2018-06-01 00:55:40 --> Output Class Initialized
INFO - 2018-06-01 00:55:40 --> Security Class Initialized
DEBUG - 2018-06-01 00:55:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 00:55:40 --> Input Class Initialized
INFO - 2018-06-01 00:55:40 --> Language Class Initialized
INFO - 2018-06-01 00:55:40 --> Language Class Initialized
INFO - 2018-06-01 00:55:40 --> Config Class Initialized
INFO - 2018-06-01 00:55:40 --> Loader Class Initialized
DEBUG - 2018-06-01 00:55:40 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-01 00:55:40 --> Helper loaded: url_helper
INFO - 2018-06-01 00:55:40 --> Helper loaded: form_helper
INFO - 2018-06-01 00:55:40 --> Helper loaded: date_helper
INFO - 2018-06-01 00:55:40 --> Helper loaded: util_helper
INFO - 2018-06-01 00:55:40 --> Helper loaded: text_helper
INFO - 2018-06-01 00:55:40 --> Helper loaded: string_helper
INFO - 2018-06-01 00:55:40 --> Database Driver Class Initialized
DEBUG - 2018-06-01 00:55:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-01 00:55:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-01 00:55:40 --> Email Class Initialized
INFO - 2018-06-01 00:55:40 --> Controller Class Initialized
DEBUG - 2018-06-01 00:55:40 --> Home MX_Controller Initialized
DEBUG - 2018-06-01 00:55:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-01 00:55:40 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-01 00:55:40 --> Login MX_Controller Initialized
INFO - 2018-06-01 00:55:40 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-01 00:55:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-01 00:55:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-01 00:55:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-01 00:55:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-01 00:55:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-01 00:55:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-01 00:55:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-01 00:55:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-06-01 00:55:40 --> Final output sent to browser
DEBUG - 2018-06-01 00:55:40 --> Total execution time: 0.4397
INFO - 2018-06-01 00:55:40 --> Config Class Initialized
INFO - 2018-06-01 00:55:40 --> Config Class Initialized
INFO - 2018-06-01 00:55:40 --> Hooks Class Initialized
INFO - 2018-06-01 00:55:40 --> Hooks Class Initialized
DEBUG - 2018-06-01 00:55:40 --> UTF-8 Support Enabled
DEBUG - 2018-06-01 00:55:40 --> UTF-8 Support Enabled
INFO - 2018-06-01 00:55:40 --> Utf8 Class Initialized
INFO - 2018-06-01 00:55:40 --> Utf8 Class Initialized
INFO - 2018-06-01 00:55:40 --> URI Class Initialized
INFO - 2018-06-01 00:55:41 --> URI Class Initialized
INFO - 2018-06-01 00:55:41 --> Router Class Initialized
INFO - 2018-06-01 00:55:41 --> Router Class Initialized
INFO - 2018-06-01 00:55:41 --> Output Class Initialized
INFO - 2018-06-01 00:55:41 --> Security Class Initialized
INFO - 2018-06-01 00:55:41 --> Output Class Initialized
DEBUG - 2018-06-01 00:55:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 00:55:41 --> Security Class Initialized
DEBUG - 2018-06-01 00:55:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 00:55:41 --> Input Class Initialized
INFO - 2018-06-01 00:55:41 --> Language Class Initialized
ERROR - 2018-06-01 00:55:41 --> 404 Page Not Found: /index
INFO - 2018-06-01 00:55:41 --> Input Class Initialized
INFO - 2018-06-01 00:55:41 --> Language Class Initialized
ERROR - 2018-06-01 00:55:41 --> 404 Page Not Found: /index
INFO - 2018-06-01 00:55:41 --> Config Class Initialized
INFO - 2018-06-01 00:55:41 --> Hooks Class Initialized
DEBUG - 2018-06-01 00:55:41 --> UTF-8 Support Enabled
INFO - 2018-06-01 00:55:41 --> Utf8 Class Initialized
INFO - 2018-06-01 00:55:41 --> URI Class Initialized
INFO - 2018-06-01 00:55:41 --> Router Class Initialized
INFO - 2018-06-01 00:55:41 --> Output Class Initialized
INFO - 2018-06-01 00:55:41 --> Security Class Initialized
DEBUG - 2018-06-01 00:55:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 00:55:41 --> Input Class Initialized
INFO - 2018-06-01 00:55:41 --> Language Class Initialized
ERROR - 2018-06-01 00:55:41 --> 404 Page Not Found: /index
INFO - 2018-06-01 00:55:41 --> Config Class Initialized
INFO - 2018-06-01 00:55:41 --> Hooks Class Initialized
DEBUG - 2018-06-01 00:55:41 --> UTF-8 Support Enabled
INFO - 2018-06-01 00:55:41 --> Utf8 Class Initialized
INFO - 2018-06-01 00:55:41 --> URI Class Initialized
INFO - 2018-06-01 00:55:41 --> Router Class Initialized
INFO - 2018-06-01 00:55:41 --> Output Class Initialized
INFO - 2018-06-01 00:55:41 --> Security Class Initialized
DEBUG - 2018-06-01 00:55:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 00:55:41 --> Input Class Initialized
INFO - 2018-06-01 00:55:41 --> Language Class Initialized
ERROR - 2018-06-01 00:55:41 --> 404 Page Not Found: /index
INFO - 2018-06-01 00:55:47 --> Config Class Initialized
INFO - 2018-06-01 00:55:47 --> Hooks Class Initialized
DEBUG - 2018-06-01 00:55:47 --> UTF-8 Support Enabled
INFO - 2018-06-01 00:55:47 --> Utf8 Class Initialized
INFO - 2018-06-01 00:55:47 --> URI Class Initialized
INFO - 2018-06-01 00:55:47 --> Router Class Initialized
INFO - 2018-06-01 00:55:47 --> Output Class Initialized
INFO - 2018-06-01 00:55:47 --> Security Class Initialized
DEBUG - 2018-06-01 00:55:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 00:55:47 --> Input Class Initialized
INFO - 2018-06-01 00:55:47 --> Language Class Initialized
INFO - 2018-06-01 00:55:47 --> Language Class Initialized
INFO - 2018-06-01 00:55:47 --> Config Class Initialized
INFO - 2018-06-01 00:55:47 --> Loader Class Initialized
DEBUG - 2018-06-01 00:55:47 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-01 00:55:47 --> Helper loaded: url_helper
INFO - 2018-06-01 00:55:47 --> Helper loaded: form_helper
INFO - 2018-06-01 00:55:47 --> Helper loaded: date_helper
INFO - 2018-06-01 00:55:47 --> Helper loaded: util_helper
INFO - 2018-06-01 00:55:47 --> Helper loaded: text_helper
INFO - 2018-06-01 00:55:47 --> Helper loaded: string_helper
INFO - 2018-06-01 00:55:47 --> Database Driver Class Initialized
DEBUG - 2018-06-01 00:55:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-01 00:55:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-01 00:55:47 --> Email Class Initialized
INFO - 2018-06-01 00:55:47 --> Controller Class Initialized
DEBUG - 2018-06-01 00:55:47 --> Home MX_Controller Initialized
DEBUG - 2018-06-01 00:55:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-01 00:55:47 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-01 00:55:47 --> Login MX_Controller Initialized
INFO - 2018-06-01 00:55:47 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-01 00:55:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-01 00:55:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-01 00:55:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-01 00:55:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-01 00:55:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-01 00:55:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-01 00:55:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-01 00:55:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-06-01 00:55:47 --> Final output sent to browser
DEBUG - 2018-06-01 00:55:47 --> Total execution time: 0.4323
INFO - 2018-06-01 00:55:47 --> Config Class Initialized
INFO - 2018-06-01 00:55:47 --> Config Class Initialized
INFO - 2018-06-01 00:55:47 --> Hooks Class Initialized
INFO - 2018-06-01 00:55:47 --> Hooks Class Initialized
DEBUG - 2018-06-01 00:55:47 --> UTF-8 Support Enabled
DEBUG - 2018-06-01 00:55:47 --> UTF-8 Support Enabled
INFO - 2018-06-01 00:55:47 --> Utf8 Class Initialized
INFO - 2018-06-01 00:55:47 --> Utf8 Class Initialized
INFO - 2018-06-01 00:55:47 --> URI Class Initialized
INFO - 2018-06-01 00:55:47 --> URI Class Initialized
INFO - 2018-06-01 00:55:47 --> Router Class Initialized
INFO - 2018-06-01 00:55:47 --> Router Class Initialized
INFO - 2018-06-01 00:55:47 --> Output Class Initialized
INFO - 2018-06-01 00:55:47 --> Security Class Initialized
DEBUG - 2018-06-01 00:55:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 00:55:47 --> Input Class Initialized
INFO - 2018-06-01 00:55:47 --> Language Class Initialized
INFO - 2018-06-01 00:55:48 --> Output Class Initialized
ERROR - 2018-06-01 00:55:48 --> 404 Page Not Found: /index
INFO - 2018-06-01 00:55:48 --> Security Class Initialized
DEBUG - 2018-06-01 00:55:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 00:55:48 --> Input Class Initialized
INFO - 2018-06-01 00:55:48 --> Language Class Initialized
ERROR - 2018-06-01 00:55:48 --> 404 Page Not Found: /index
INFO - 2018-06-01 00:55:48 --> Config Class Initialized
INFO - 2018-06-01 00:55:48 --> Hooks Class Initialized
DEBUG - 2018-06-01 00:55:48 --> UTF-8 Support Enabled
INFO - 2018-06-01 00:55:48 --> Utf8 Class Initialized
INFO - 2018-06-01 00:55:48 --> URI Class Initialized
INFO - 2018-06-01 00:55:48 --> Router Class Initialized
INFO - 2018-06-01 00:55:48 --> Output Class Initialized
INFO - 2018-06-01 00:55:48 --> Security Class Initialized
DEBUG - 2018-06-01 00:55:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 00:55:48 --> Input Class Initialized
INFO - 2018-06-01 00:55:48 --> Language Class Initialized
ERROR - 2018-06-01 00:55:48 --> 404 Page Not Found: /index
INFO - 2018-06-01 00:55:48 --> Config Class Initialized
INFO - 2018-06-01 00:55:48 --> Hooks Class Initialized
DEBUG - 2018-06-01 00:55:48 --> UTF-8 Support Enabled
INFO - 2018-06-01 00:55:48 --> Utf8 Class Initialized
INFO - 2018-06-01 00:55:48 --> URI Class Initialized
INFO - 2018-06-01 00:55:48 --> Router Class Initialized
INFO - 2018-06-01 00:55:48 --> Output Class Initialized
INFO - 2018-06-01 00:55:48 --> Security Class Initialized
DEBUG - 2018-06-01 00:55:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 00:55:48 --> Input Class Initialized
INFO - 2018-06-01 00:55:48 --> Language Class Initialized
ERROR - 2018-06-01 00:55:48 --> 404 Page Not Found: /index
INFO - 2018-06-01 00:55:56 --> Config Class Initialized
INFO - 2018-06-01 00:55:56 --> Hooks Class Initialized
DEBUG - 2018-06-01 00:55:56 --> UTF-8 Support Enabled
INFO - 2018-06-01 00:55:56 --> Utf8 Class Initialized
INFO - 2018-06-01 00:55:56 --> URI Class Initialized
INFO - 2018-06-01 00:55:56 --> Router Class Initialized
INFO - 2018-06-01 00:55:56 --> Output Class Initialized
INFO - 2018-06-01 00:55:56 --> Security Class Initialized
DEBUG - 2018-06-01 00:55:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 00:55:56 --> Input Class Initialized
INFO - 2018-06-01 00:55:56 --> Language Class Initialized
INFO - 2018-06-01 00:55:56 --> Language Class Initialized
INFO - 2018-06-01 00:55:56 --> Config Class Initialized
INFO - 2018-06-01 00:55:56 --> Loader Class Initialized
DEBUG - 2018-06-01 00:55:56 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-01 00:55:56 --> Helper loaded: url_helper
INFO - 2018-06-01 00:55:56 --> Helper loaded: form_helper
INFO - 2018-06-01 00:55:56 --> Helper loaded: date_helper
INFO - 2018-06-01 00:55:57 --> Helper loaded: util_helper
INFO - 2018-06-01 00:55:57 --> Helper loaded: text_helper
INFO - 2018-06-01 00:55:57 --> Helper loaded: string_helper
INFO - 2018-06-01 00:55:57 --> Database Driver Class Initialized
DEBUG - 2018-06-01 00:55:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-01 00:55:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-01 00:55:57 --> Email Class Initialized
INFO - 2018-06-01 00:55:57 --> Controller Class Initialized
DEBUG - 2018-06-01 00:55:57 --> Home MX_Controller Initialized
DEBUG - 2018-06-01 00:55:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-01 00:55:57 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-01 00:55:57 --> Login MX_Controller Initialized
INFO - 2018-06-01 00:55:57 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-01 00:55:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-01 00:55:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-01 00:55:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-01 00:55:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-01 00:55:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-01 00:55:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-01 00:55:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-01 00:55:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-06-01 00:55:57 --> Final output sent to browser
DEBUG - 2018-06-01 00:55:57 --> Total execution time: 0.5323
INFO - 2018-06-01 00:55:57 --> Config Class Initialized
INFO - 2018-06-01 00:55:57 --> Config Class Initialized
INFO - 2018-06-01 00:55:57 --> Hooks Class Initialized
INFO - 2018-06-01 00:55:57 --> Hooks Class Initialized
DEBUG - 2018-06-01 00:55:57 --> UTF-8 Support Enabled
DEBUG - 2018-06-01 00:55:57 --> UTF-8 Support Enabled
INFO - 2018-06-01 00:55:57 --> Utf8 Class Initialized
INFO - 2018-06-01 00:55:57 --> Utf8 Class Initialized
INFO - 2018-06-01 00:55:57 --> URI Class Initialized
INFO - 2018-06-01 00:55:57 --> URI Class Initialized
INFO - 2018-06-01 00:55:57 --> Router Class Initialized
INFO - 2018-06-01 00:55:57 --> Output Class Initialized
INFO - 2018-06-01 00:55:57 --> Security Class Initialized
DEBUG - 2018-06-01 00:55:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 00:55:57 --> Input Class Initialized
INFO - 2018-06-01 00:55:57 --> Language Class Initialized
INFO - 2018-06-01 00:55:57 --> Router Class Initialized
ERROR - 2018-06-01 00:55:57 --> 404 Page Not Found: /index
INFO - 2018-06-01 00:55:57 --> Output Class Initialized
INFO - 2018-06-01 00:55:57 --> Security Class Initialized
DEBUG - 2018-06-01 00:55:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 00:55:57 --> Config Class Initialized
INFO - 2018-06-01 00:55:57 --> Hooks Class Initialized
INFO - 2018-06-01 00:55:57 --> Input Class Initialized
DEBUG - 2018-06-01 00:55:57 --> UTF-8 Support Enabled
INFO - 2018-06-01 00:55:58 --> Utf8 Class Initialized
INFO - 2018-06-01 00:55:58 --> Language Class Initialized
INFO - 2018-06-01 00:55:58 --> URI Class Initialized
ERROR - 2018-06-01 00:55:58 --> 404 Page Not Found: /index
INFO - 2018-06-01 00:55:58 --> Router Class Initialized
INFO - 2018-06-01 00:55:58 --> Output Class Initialized
INFO - 2018-06-01 00:55:58 --> Security Class Initialized
DEBUG - 2018-06-01 00:55:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 00:55:58 --> Input Class Initialized
INFO - 2018-06-01 00:55:58 --> Language Class Initialized
ERROR - 2018-06-01 00:55:58 --> 404 Page Not Found: /index
INFO - 2018-06-01 00:55:58 --> Config Class Initialized
INFO - 2018-06-01 00:55:58 --> Hooks Class Initialized
DEBUG - 2018-06-01 00:55:58 --> UTF-8 Support Enabled
INFO - 2018-06-01 00:55:58 --> Utf8 Class Initialized
INFO - 2018-06-01 00:55:58 --> URI Class Initialized
INFO - 2018-06-01 00:55:58 --> Router Class Initialized
INFO - 2018-06-01 00:55:58 --> Output Class Initialized
INFO - 2018-06-01 00:55:58 --> Security Class Initialized
DEBUG - 2018-06-01 00:55:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 00:55:58 --> Input Class Initialized
INFO - 2018-06-01 00:55:58 --> Language Class Initialized
ERROR - 2018-06-01 00:55:58 --> 404 Page Not Found: /index
INFO - 2018-06-01 01:23:20 --> Config Class Initialized
INFO - 2018-06-01 01:23:20 --> Hooks Class Initialized
DEBUG - 2018-06-01 01:23:20 --> UTF-8 Support Enabled
INFO - 2018-06-01 01:23:20 --> Utf8 Class Initialized
INFO - 2018-06-01 01:23:20 --> URI Class Initialized
INFO - 2018-06-01 01:23:20 --> Router Class Initialized
INFO - 2018-06-01 01:23:20 --> Output Class Initialized
INFO - 2018-06-01 01:23:20 --> Security Class Initialized
DEBUG - 2018-06-01 01:23:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 01:23:20 --> Input Class Initialized
INFO - 2018-06-01 01:23:20 --> Language Class Initialized
INFO - 2018-06-01 01:23:20 --> Language Class Initialized
INFO - 2018-06-01 01:23:20 --> Config Class Initialized
INFO - 2018-06-01 01:23:20 --> Loader Class Initialized
DEBUG - 2018-06-01 01:23:20 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-01 01:23:20 --> Helper loaded: url_helper
INFO - 2018-06-01 01:23:20 --> Helper loaded: form_helper
INFO - 2018-06-01 01:23:20 --> Helper loaded: date_helper
INFO - 2018-06-01 01:23:20 --> Helper loaded: util_helper
INFO - 2018-06-01 01:23:20 --> Helper loaded: text_helper
INFO - 2018-06-01 01:23:20 --> Helper loaded: string_helper
INFO - 2018-06-01 01:23:20 --> Database Driver Class Initialized
DEBUG - 2018-06-01 01:23:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-01 01:23:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-01 01:23:20 --> Email Class Initialized
INFO - 2018-06-01 01:23:20 --> Controller Class Initialized
DEBUG - 2018-06-01 01:23:20 --> Home MX_Controller Initialized
DEBUG - 2018-06-01 01:23:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-01 01:23:20 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-01 01:23:20 --> Login MX_Controller Initialized
INFO - 2018-06-01 01:23:20 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-01 01:23:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-01 01:23:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-01 01:23:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-01 01:23:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-01 01:23:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-01 01:23:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-01 01:23:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-01 01:23:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-06-01 01:23:20 --> Final output sent to browser
DEBUG - 2018-06-01 01:23:20 --> Total execution time: 0.4949
INFO - 2018-06-01 01:23:20 --> Config Class Initialized
INFO - 2018-06-01 01:23:20 --> Config Class Initialized
INFO - 2018-06-01 01:23:20 --> Hooks Class Initialized
INFO - 2018-06-01 01:23:20 --> Hooks Class Initialized
DEBUG - 2018-06-01 01:23:20 --> UTF-8 Support Enabled
INFO - 2018-06-01 01:23:20 --> Utf8 Class Initialized
DEBUG - 2018-06-01 01:23:20 --> UTF-8 Support Enabled
INFO - 2018-06-01 01:23:20 --> Utf8 Class Initialized
INFO - 2018-06-01 01:23:20 --> URI Class Initialized
INFO - 2018-06-01 01:23:21 --> URI Class Initialized
INFO - 2018-06-01 01:23:21 --> Router Class Initialized
INFO - 2018-06-01 01:23:21 --> Output Class Initialized
INFO - 2018-06-01 01:23:21 --> Router Class Initialized
INFO - 2018-06-01 01:23:21 --> Output Class Initialized
INFO - 2018-06-01 01:23:21 --> Security Class Initialized
INFO - 2018-06-01 01:23:21 --> Security Class Initialized
DEBUG - 2018-06-01 01:23:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 01:23:21 --> Input Class Initialized
DEBUG - 2018-06-01 01:23:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 01:23:21 --> Language Class Initialized
INFO - 2018-06-01 01:23:21 --> Input Class Initialized
ERROR - 2018-06-01 01:23:21 --> 404 Page Not Found: /index
INFO - 2018-06-01 01:23:21 --> Language Class Initialized
ERROR - 2018-06-01 01:23:21 --> 404 Page Not Found: /index
INFO - 2018-06-01 01:23:21 --> Config Class Initialized
INFO - 2018-06-01 01:23:21 --> Hooks Class Initialized
DEBUG - 2018-06-01 01:23:21 --> UTF-8 Support Enabled
INFO - 2018-06-01 01:23:21 --> Utf8 Class Initialized
INFO - 2018-06-01 01:23:21 --> URI Class Initialized
INFO - 2018-06-01 01:23:21 --> Router Class Initialized
INFO - 2018-06-01 01:23:21 --> Output Class Initialized
INFO - 2018-06-01 01:23:21 --> Security Class Initialized
DEBUG - 2018-06-01 01:23:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 01:23:21 --> Input Class Initialized
INFO - 2018-06-01 01:23:21 --> Language Class Initialized
ERROR - 2018-06-01 01:23:21 --> 404 Page Not Found: /index
INFO - 2018-06-01 01:23:21 --> Config Class Initialized
INFO - 2018-06-01 01:23:21 --> Hooks Class Initialized
DEBUG - 2018-06-01 01:23:21 --> UTF-8 Support Enabled
INFO - 2018-06-01 01:23:21 --> Utf8 Class Initialized
INFO - 2018-06-01 01:23:21 --> URI Class Initialized
INFO - 2018-06-01 01:23:21 --> Router Class Initialized
INFO - 2018-06-01 01:23:21 --> Output Class Initialized
INFO - 2018-06-01 01:23:21 --> Security Class Initialized
DEBUG - 2018-06-01 01:23:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 01:23:21 --> Input Class Initialized
INFO - 2018-06-01 01:23:21 --> Language Class Initialized
ERROR - 2018-06-01 01:23:21 --> 404 Page Not Found: /index
INFO - 2018-06-01 01:23:21 --> Config Class Initialized
INFO - 2018-06-01 01:23:21 --> Hooks Class Initialized
DEBUG - 2018-06-01 01:23:21 --> UTF-8 Support Enabled
INFO - 2018-06-01 01:23:21 --> Utf8 Class Initialized
INFO - 2018-06-01 01:23:21 --> URI Class Initialized
INFO - 2018-06-01 01:23:21 --> Router Class Initialized
INFO - 2018-06-01 01:23:21 --> Output Class Initialized
INFO - 2018-06-01 01:23:21 --> Security Class Initialized
DEBUG - 2018-06-01 01:23:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 01:23:21 --> Input Class Initialized
INFO - 2018-06-01 01:23:21 --> Language Class Initialized
ERROR - 2018-06-01 01:23:21 --> 404 Page Not Found: /index
INFO - 2018-06-01 01:23:21 --> Config Class Initialized
INFO - 2018-06-01 01:23:21 --> Hooks Class Initialized
DEBUG - 2018-06-01 01:23:21 --> UTF-8 Support Enabled
INFO - 2018-06-01 01:23:21 --> Utf8 Class Initialized
INFO - 2018-06-01 01:23:21 --> URI Class Initialized
INFO - 2018-06-01 01:23:22 --> Router Class Initialized
INFO - 2018-06-01 01:23:22 --> Output Class Initialized
INFO - 2018-06-01 01:23:22 --> Security Class Initialized
DEBUG - 2018-06-01 01:23:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 01:23:22 --> Input Class Initialized
INFO - 2018-06-01 01:23:22 --> Language Class Initialized
ERROR - 2018-06-01 01:23:22 --> 404 Page Not Found: /index
INFO - 2018-06-01 01:23:22 --> Config Class Initialized
INFO - 2018-06-01 01:23:22 --> Hooks Class Initialized
DEBUG - 2018-06-01 01:23:22 --> UTF-8 Support Enabled
INFO - 2018-06-01 01:23:22 --> Utf8 Class Initialized
INFO - 2018-06-01 01:23:22 --> URI Class Initialized
INFO - 2018-06-01 01:23:22 --> Router Class Initialized
INFO - 2018-06-01 01:23:22 --> Output Class Initialized
INFO - 2018-06-01 01:23:22 --> Security Class Initialized
DEBUG - 2018-06-01 01:23:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 01:23:22 --> Input Class Initialized
INFO - 2018-06-01 01:23:22 --> Language Class Initialized
ERROR - 2018-06-01 01:23:22 --> 404 Page Not Found: /index
INFO - 2018-06-01 01:24:42 --> Config Class Initialized
INFO - 2018-06-01 01:24:42 --> Hooks Class Initialized
DEBUG - 2018-06-01 01:24:42 --> UTF-8 Support Enabled
INFO - 2018-06-01 01:24:42 --> Utf8 Class Initialized
INFO - 2018-06-01 01:24:42 --> URI Class Initialized
INFO - 2018-06-01 01:24:42 --> Router Class Initialized
INFO - 2018-06-01 01:24:42 --> Output Class Initialized
INFO - 2018-06-01 01:24:42 --> Security Class Initialized
DEBUG - 2018-06-01 01:24:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 01:24:42 --> Input Class Initialized
INFO - 2018-06-01 01:24:42 --> Language Class Initialized
INFO - 2018-06-01 01:24:42 --> Language Class Initialized
INFO - 2018-06-01 01:24:42 --> Config Class Initialized
INFO - 2018-06-01 01:24:43 --> Loader Class Initialized
DEBUG - 2018-06-01 01:24:43 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-01 01:24:43 --> Helper loaded: url_helper
INFO - 2018-06-01 01:24:43 --> Helper loaded: form_helper
INFO - 2018-06-01 01:24:43 --> Helper loaded: date_helper
INFO - 2018-06-01 01:24:43 --> Helper loaded: util_helper
INFO - 2018-06-01 01:24:43 --> Helper loaded: text_helper
INFO - 2018-06-01 01:24:43 --> Helper loaded: string_helper
INFO - 2018-06-01 01:24:43 --> Database Driver Class Initialized
DEBUG - 2018-06-01 01:24:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-01 01:24:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-01 01:24:43 --> Email Class Initialized
INFO - 2018-06-01 01:24:43 --> Controller Class Initialized
DEBUG - 2018-06-01 01:24:43 --> Home MX_Controller Initialized
DEBUG - 2018-06-01 01:24:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-01 01:24:43 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-01 01:24:43 --> Login MX_Controller Initialized
INFO - 2018-06-01 01:24:43 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-01 01:24:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-01 01:24:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-01 01:25:24 --> Config Class Initialized
INFO - 2018-06-01 01:25:24 --> Hooks Class Initialized
DEBUG - 2018-06-01 01:25:24 --> UTF-8 Support Enabled
INFO - 2018-06-01 01:25:24 --> Utf8 Class Initialized
INFO - 2018-06-01 01:25:24 --> URI Class Initialized
INFO - 2018-06-01 01:25:24 --> Router Class Initialized
INFO - 2018-06-01 01:25:24 --> Output Class Initialized
INFO - 2018-06-01 01:25:24 --> Security Class Initialized
DEBUG - 2018-06-01 01:25:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 01:25:24 --> Input Class Initialized
INFO - 2018-06-01 01:25:24 --> Language Class Initialized
INFO - 2018-06-01 01:25:24 --> Language Class Initialized
INFO - 2018-06-01 01:25:24 --> Config Class Initialized
INFO - 2018-06-01 01:25:24 --> Loader Class Initialized
DEBUG - 2018-06-01 01:25:24 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-01 01:25:24 --> Helper loaded: url_helper
INFO - 2018-06-01 01:25:24 --> Helper loaded: form_helper
INFO - 2018-06-01 01:25:24 --> Helper loaded: date_helper
INFO - 2018-06-01 01:25:24 --> Helper loaded: util_helper
INFO - 2018-06-01 01:25:24 --> Helper loaded: text_helper
INFO - 2018-06-01 01:25:24 --> Helper loaded: string_helper
INFO - 2018-06-01 01:25:24 --> Database Driver Class Initialized
DEBUG - 2018-06-01 01:25:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-01 01:25:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-01 01:25:24 --> Email Class Initialized
INFO - 2018-06-01 01:25:24 --> Controller Class Initialized
DEBUG - 2018-06-01 01:25:24 --> Home MX_Controller Initialized
DEBUG - 2018-06-01 01:25:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-01 01:25:24 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-01 01:25:24 --> Login MX_Controller Initialized
INFO - 2018-06-01 01:25:24 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-01 01:25:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-01 01:25:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-01 01:25:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-01 01:25:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-01 01:25:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-01 01:25:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-01 01:25:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-01 01:25:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-06-01 01:25:24 --> Final output sent to browser
DEBUG - 2018-06-01 01:25:24 --> Total execution time: 0.4381
INFO - 2018-06-01 01:25:25 --> Config Class Initialized
INFO - 2018-06-01 01:25:25 --> Config Class Initialized
INFO - 2018-06-01 01:25:25 --> Hooks Class Initialized
INFO - 2018-06-01 01:25:25 --> Hooks Class Initialized
DEBUG - 2018-06-01 01:25:25 --> UTF-8 Support Enabled
DEBUG - 2018-06-01 01:25:25 --> UTF-8 Support Enabled
INFO - 2018-06-01 01:25:25 --> Utf8 Class Initialized
INFO - 2018-06-01 01:25:25 --> URI Class Initialized
INFO - 2018-06-01 01:25:25 --> Utf8 Class Initialized
INFO - 2018-06-01 01:25:25 --> Router Class Initialized
INFO - 2018-06-01 01:25:25 --> URI Class Initialized
INFO - 2018-06-01 01:25:25 --> Output Class Initialized
INFO - 2018-06-01 01:25:25 --> Router Class Initialized
INFO - 2018-06-01 01:25:25 --> Security Class Initialized
INFO - 2018-06-01 01:25:25 --> Output Class Initialized
DEBUG - 2018-06-01 01:25:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 01:25:25 --> Security Class Initialized
INFO - 2018-06-01 01:25:25 --> Input Class Initialized
INFO - 2018-06-01 01:25:25 --> Language Class Initialized
ERROR - 2018-06-01 01:25:25 --> 404 Page Not Found: /index
DEBUG - 2018-06-01 01:25:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 01:25:25 --> Input Class Initialized
INFO - 2018-06-01 01:25:25 --> Config Class Initialized
INFO - 2018-06-01 01:25:25 --> Language Class Initialized
INFO - 2018-06-01 01:25:25 --> Hooks Class Initialized
ERROR - 2018-06-01 01:25:25 --> 404 Page Not Found: /index
DEBUG - 2018-06-01 01:25:25 --> UTF-8 Support Enabled
INFO - 2018-06-01 01:25:25 --> Utf8 Class Initialized
INFO - 2018-06-01 01:25:25 --> URI Class Initialized
INFO - 2018-06-01 01:25:25 --> Router Class Initialized
INFO - 2018-06-01 01:25:25 --> Output Class Initialized
INFO - 2018-06-01 01:25:25 --> Security Class Initialized
DEBUG - 2018-06-01 01:25:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 01:25:25 --> Input Class Initialized
INFO - 2018-06-01 01:25:25 --> Language Class Initialized
ERROR - 2018-06-01 01:25:25 --> 404 Page Not Found: /index
INFO - 2018-06-01 01:25:25 --> Config Class Initialized
INFO - 2018-06-01 01:25:25 --> Hooks Class Initialized
DEBUG - 2018-06-01 01:25:25 --> UTF-8 Support Enabled
INFO - 2018-06-01 01:25:25 --> Utf8 Class Initialized
INFO - 2018-06-01 01:25:25 --> URI Class Initialized
INFO - 2018-06-01 01:25:26 --> Router Class Initialized
INFO - 2018-06-01 01:25:26 --> Output Class Initialized
INFO - 2018-06-01 01:25:26 --> Security Class Initialized
DEBUG - 2018-06-01 01:25:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 01:25:26 --> Input Class Initialized
INFO - 2018-06-01 01:25:26 --> Language Class Initialized
ERROR - 2018-06-01 01:25:26 --> 404 Page Not Found: /index
INFO - 2018-06-01 01:25:26 --> Config Class Initialized
INFO - 2018-06-01 01:25:26 --> Hooks Class Initialized
DEBUG - 2018-06-01 01:25:26 --> UTF-8 Support Enabled
INFO - 2018-06-01 01:25:26 --> Utf8 Class Initialized
INFO - 2018-06-01 01:25:26 --> URI Class Initialized
INFO - 2018-06-01 01:25:26 --> Router Class Initialized
INFO - 2018-06-01 01:25:26 --> Output Class Initialized
INFO - 2018-06-01 01:25:26 --> Security Class Initialized
DEBUG - 2018-06-01 01:25:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 01:25:26 --> Input Class Initialized
INFO - 2018-06-01 01:25:26 --> Language Class Initialized
ERROR - 2018-06-01 01:25:26 --> 404 Page Not Found: /index
INFO - 2018-06-01 01:25:26 --> Config Class Initialized
INFO - 2018-06-01 01:25:26 --> Hooks Class Initialized
DEBUG - 2018-06-01 01:25:26 --> UTF-8 Support Enabled
INFO - 2018-06-01 01:25:26 --> Utf8 Class Initialized
INFO - 2018-06-01 01:25:26 --> URI Class Initialized
INFO - 2018-06-01 01:25:26 --> Router Class Initialized
INFO - 2018-06-01 01:25:26 --> Output Class Initialized
INFO - 2018-06-01 01:25:26 --> Security Class Initialized
DEBUG - 2018-06-01 01:25:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 01:25:26 --> Input Class Initialized
INFO - 2018-06-01 01:25:26 --> Language Class Initialized
ERROR - 2018-06-01 01:25:26 --> 404 Page Not Found: /index
INFO - 2018-06-01 01:25:26 --> Config Class Initialized
INFO - 2018-06-01 01:25:26 --> Hooks Class Initialized
DEBUG - 2018-06-01 01:25:26 --> UTF-8 Support Enabled
INFO - 2018-06-01 01:25:26 --> Utf8 Class Initialized
INFO - 2018-06-01 01:25:26 --> URI Class Initialized
INFO - 2018-06-01 01:25:26 --> Router Class Initialized
INFO - 2018-06-01 01:25:26 --> Output Class Initialized
INFO - 2018-06-01 01:25:26 --> Security Class Initialized
DEBUG - 2018-06-01 01:25:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 01:25:26 --> Input Class Initialized
INFO - 2018-06-01 01:25:26 --> Language Class Initialized
ERROR - 2018-06-01 01:25:26 --> 404 Page Not Found: /index
INFO - 2018-06-01 01:25:30 --> Config Class Initialized
INFO - 2018-06-01 01:25:30 --> Hooks Class Initialized
DEBUG - 2018-06-01 01:25:30 --> UTF-8 Support Enabled
INFO - 2018-06-01 01:25:30 --> Utf8 Class Initialized
INFO - 2018-06-01 01:25:30 --> URI Class Initialized
INFO - 2018-06-01 01:25:30 --> Router Class Initialized
INFO - 2018-06-01 01:25:30 --> Output Class Initialized
INFO - 2018-06-01 01:25:30 --> Security Class Initialized
DEBUG - 2018-06-01 01:25:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 01:25:30 --> Input Class Initialized
INFO - 2018-06-01 01:25:30 --> Language Class Initialized
INFO - 2018-06-01 01:25:30 --> Language Class Initialized
INFO - 2018-06-01 01:25:30 --> Config Class Initialized
INFO - 2018-06-01 01:25:30 --> Loader Class Initialized
DEBUG - 2018-06-01 01:25:30 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-01 01:25:30 --> Helper loaded: url_helper
INFO - 2018-06-01 01:25:30 --> Helper loaded: form_helper
INFO - 2018-06-01 01:25:30 --> Helper loaded: date_helper
INFO - 2018-06-01 01:25:30 --> Helper loaded: util_helper
INFO - 2018-06-01 01:25:30 --> Helper loaded: text_helper
INFO - 2018-06-01 01:25:30 --> Helper loaded: string_helper
INFO - 2018-06-01 01:25:30 --> Database Driver Class Initialized
DEBUG - 2018-06-01 01:25:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-01 01:25:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-01 01:25:30 --> Email Class Initialized
INFO - 2018-06-01 01:25:30 --> Controller Class Initialized
DEBUG - 2018-06-01 01:25:30 --> Home MX_Controller Initialized
DEBUG - 2018-06-01 01:25:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-01 01:25:30 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-01 01:25:30 --> Login MX_Controller Initialized
INFO - 2018-06-01 01:25:30 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-01 01:25:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-01 01:25:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-01 01:25:30 --> Config Class Initialized
INFO - 2018-06-01 01:25:30 --> Hooks Class Initialized
DEBUG - 2018-06-01 01:25:30 --> UTF-8 Support Enabled
INFO - 2018-06-01 01:25:30 --> Utf8 Class Initialized
INFO - 2018-06-01 01:25:30 --> URI Class Initialized
INFO - 2018-06-01 01:25:30 --> Router Class Initialized
INFO - 2018-06-01 01:25:30 --> Output Class Initialized
INFO - 2018-06-01 01:25:30 --> Security Class Initialized
DEBUG - 2018-06-01 01:25:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 01:25:30 --> Input Class Initialized
INFO - 2018-06-01 01:25:30 --> Language Class Initialized
INFO - 2018-06-01 01:25:30 --> Language Class Initialized
INFO - 2018-06-01 01:25:30 --> Config Class Initialized
INFO - 2018-06-01 01:25:30 --> Loader Class Initialized
DEBUG - 2018-06-01 01:25:30 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-01 01:25:30 --> Helper loaded: url_helper
INFO - 2018-06-01 01:25:30 --> Helper loaded: form_helper
INFO - 2018-06-01 01:25:30 --> Helper loaded: date_helper
INFO - 2018-06-01 01:25:30 --> Helper loaded: util_helper
INFO - 2018-06-01 01:25:30 --> Helper loaded: text_helper
INFO - 2018-06-01 01:25:30 --> Helper loaded: string_helper
INFO - 2018-06-01 01:25:30 --> Database Driver Class Initialized
DEBUG - 2018-06-01 01:25:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-01 01:25:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-01 01:25:30 --> Email Class Initialized
INFO - 2018-06-01 01:25:30 --> Controller Class Initialized
DEBUG - 2018-06-01 01:25:30 --> Home MX_Controller Initialized
DEBUG - 2018-06-01 01:25:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-01 01:25:30 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-01 01:25:30 --> Login MX_Controller Initialized
INFO - 2018-06-01 01:25:30 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-01 01:25:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-01 01:25:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-01 01:25:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-01 01:25:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-01 01:25:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-01 01:25:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-01 01:25:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-01 01:25:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-06-01 01:25:30 --> Final output sent to browser
DEBUG - 2018-06-01 01:25:30 --> Total execution time: 0.4549
INFO - 2018-06-01 01:25:31 --> Config Class Initialized
INFO - 2018-06-01 01:25:31 --> Hooks Class Initialized
DEBUG - 2018-06-01 01:25:31 --> UTF-8 Support Enabled
INFO - 2018-06-01 01:25:31 --> Utf8 Class Initialized
INFO - 2018-06-01 01:25:31 --> URI Class Initialized
INFO - 2018-06-01 01:25:31 --> Router Class Initialized
INFO - 2018-06-01 01:25:31 --> Output Class Initialized
INFO - 2018-06-01 01:25:31 --> Security Class Initialized
DEBUG - 2018-06-01 01:25:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 01:25:31 --> Input Class Initialized
INFO - 2018-06-01 01:25:31 --> Language Class Initialized
ERROR - 2018-06-01 01:25:31 --> 404 Page Not Found: /index
INFO - 2018-06-01 01:25:31 --> Config Class Initialized
INFO - 2018-06-01 01:25:31 --> Hooks Class Initialized
DEBUG - 2018-06-01 01:25:31 --> UTF-8 Support Enabled
INFO - 2018-06-01 01:25:31 --> Utf8 Class Initialized
INFO - 2018-06-01 01:25:31 --> URI Class Initialized
INFO - 2018-06-01 01:25:31 --> Router Class Initialized
INFO - 2018-06-01 01:25:31 --> Output Class Initialized
INFO - 2018-06-01 01:25:31 --> Security Class Initialized
DEBUG - 2018-06-01 01:25:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 01:25:31 --> Input Class Initialized
INFO - 2018-06-01 01:25:31 --> Language Class Initialized
ERROR - 2018-06-01 01:25:31 --> 404 Page Not Found: /index
INFO - 2018-06-01 01:25:31 --> Config Class Initialized
INFO - 2018-06-01 01:25:31 --> Hooks Class Initialized
DEBUG - 2018-06-01 01:25:31 --> UTF-8 Support Enabled
INFO - 2018-06-01 01:25:31 --> Utf8 Class Initialized
INFO - 2018-06-01 01:25:31 --> URI Class Initialized
INFO - 2018-06-01 01:25:31 --> Router Class Initialized
INFO - 2018-06-01 01:25:31 --> Output Class Initialized
INFO - 2018-06-01 01:25:31 --> Security Class Initialized
DEBUG - 2018-06-01 01:25:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 01:25:31 --> Input Class Initialized
INFO - 2018-06-01 01:25:31 --> Language Class Initialized
ERROR - 2018-06-01 01:25:31 --> 404 Page Not Found: /index
INFO - 2018-06-01 01:25:39 --> Config Class Initialized
INFO - 2018-06-01 01:25:39 --> Hooks Class Initialized
DEBUG - 2018-06-01 01:25:39 --> UTF-8 Support Enabled
INFO - 2018-06-01 01:25:39 --> Utf8 Class Initialized
INFO - 2018-06-01 01:25:39 --> URI Class Initialized
INFO - 2018-06-01 01:25:39 --> Router Class Initialized
INFO - 2018-06-01 01:25:39 --> Output Class Initialized
INFO - 2018-06-01 01:25:39 --> Security Class Initialized
DEBUG - 2018-06-01 01:25:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 01:25:39 --> Input Class Initialized
INFO - 2018-06-01 01:25:39 --> Language Class Initialized
INFO - 2018-06-01 01:25:39 --> Language Class Initialized
INFO - 2018-06-01 01:25:39 --> Config Class Initialized
INFO - 2018-06-01 01:25:39 --> Loader Class Initialized
DEBUG - 2018-06-01 01:25:39 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-01 01:25:39 --> Helper loaded: url_helper
INFO - 2018-06-01 01:25:39 --> Helper loaded: form_helper
INFO - 2018-06-01 01:25:39 --> Helper loaded: date_helper
INFO - 2018-06-01 01:25:39 --> Helper loaded: util_helper
INFO - 2018-06-01 01:25:39 --> Helper loaded: text_helper
INFO - 2018-06-01 01:25:39 --> Helper loaded: string_helper
INFO - 2018-06-01 01:25:39 --> Database Driver Class Initialized
DEBUG - 2018-06-01 01:25:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-01 01:25:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-01 01:25:39 --> Email Class Initialized
INFO - 2018-06-01 01:25:39 --> Controller Class Initialized
DEBUG - 2018-06-01 01:25:39 --> Home MX_Controller Initialized
DEBUG - 2018-06-01 01:25:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-01 01:25:39 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-01 01:25:39 --> Login MX_Controller Initialized
INFO - 2018-06-01 01:25:39 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-01 01:25:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-01 01:25:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-01 01:25:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-01 01:25:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-01 01:25:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-01 01:25:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-01 01:25:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-01 01:25:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-06-01 01:25:39 --> Final output sent to browser
DEBUG - 2018-06-01 01:25:39 --> Total execution time: 0.4902
INFO - 2018-06-01 01:25:40 --> Config Class Initialized
INFO - 2018-06-01 01:25:40 --> Config Class Initialized
INFO - 2018-06-01 01:25:40 --> Hooks Class Initialized
INFO - 2018-06-01 01:25:40 --> Hooks Class Initialized
DEBUG - 2018-06-01 01:25:40 --> UTF-8 Support Enabled
DEBUG - 2018-06-01 01:25:40 --> UTF-8 Support Enabled
INFO - 2018-06-01 01:25:40 --> Utf8 Class Initialized
INFO - 2018-06-01 01:25:40 --> Utf8 Class Initialized
INFO - 2018-06-01 01:25:40 --> URI Class Initialized
INFO - 2018-06-01 01:25:40 --> URI Class Initialized
INFO - 2018-06-01 01:25:40 --> Router Class Initialized
INFO - 2018-06-01 01:25:40 --> Output Class Initialized
INFO - 2018-06-01 01:25:40 --> Router Class Initialized
INFO - 2018-06-01 01:25:40 --> Security Class Initialized
INFO - 2018-06-01 01:25:40 --> Output Class Initialized
DEBUG - 2018-06-01 01:25:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 01:25:40 --> Security Class Initialized
INFO - 2018-06-01 01:25:40 --> Input Class Initialized
DEBUG - 2018-06-01 01:25:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 01:25:40 --> Language Class Initialized
INFO - 2018-06-01 01:25:40 --> Input Class Initialized
INFO - 2018-06-01 01:25:40 --> Language Class Initialized
ERROR - 2018-06-01 01:25:40 --> 404 Page Not Found: /index
ERROR - 2018-06-01 01:25:40 --> 404 Page Not Found: /index
INFO - 2018-06-01 01:25:40 --> Config Class Initialized
INFO - 2018-06-01 01:25:40 --> Hooks Class Initialized
DEBUG - 2018-06-01 01:25:40 --> UTF-8 Support Enabled
INFO - 2018-06-01 01:25:40 --> Utf8 Class Initialized
INFO - 2018-06-01 01:25:40 --> URI Class Initialized
INFO - 2018-06-01 01:25:40 --> Router Class Initialized
INFO - 2018-06-01 01:25:40 --> Output Class Initialized
INFO - 2018-06-01 01:25:40 --> Security Class Initialized
DEBUG - 2018-06-01 01:25:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 01:25:40 --> Input Class Initialized
INFO - 2018-06-01 01:25:40 --> Language Class Initialized
ERROR - 2018-06-01 01:25:40 --> 404 Page Not Found: /index
INFO - 2018-06-01 01:25:40 --> Config Class Initialized
INFO - 2018-06-01 01:25:40 --> Hooks Class Initialized
DEBUG - 2018-06-01 01:25:40 --> UTF-8 Support Enabled
INFO - 2018-06-01 01:25:40 --> Utf8 Class Initialized
INFO - 2018-06-01 01:25:40 --> URI Class Initialized
INFO - 2018-06-01 01:25:40 --> Router Class Initialized
INFO - 2018-06-01 01:25:40 --> Output Class Initialized
INFO - 2018-06-01 01:25:40 --> Security Class Initialized
DEBUG - 2018-06-01 01:25:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 01:25:40 --> Input Class Initialized
INFO - 2018-06-01 01:25:40 --> Language Class Initialized
ERROR - 2018-06-01 01:25:40 --> 404 Page Not Found: /index
INFO - 2018-06-01 01:25:44 --> Config Class Initialized
INFO - 2018-06-01 01:25:44 --> Hooks Class Initialized
DEBUG - 2018-06-01 01:25:44 --> UTF-8 Support Enabled
INFO - 2018-06-01 01:25:44 --> Utf8 Class Initialized
INFO - 2018-06-01 01:25:44 --> URI Class Initialized
INFO - 2018-06-01 01:25:44 --> Router Class Initialized
INFO - 2018-06-01 01:25:44 --> Output Class Initialized
INFO - 2018-06-01 01:25:44 --> Security Class Initialized
DEBUG - 2018-06-01 01:25:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 01:25:44 --> Input Class Initialized
INFO - 2018-06-01 01:25:44 --> Language Class Initialized
INFO - 2018-06-01 01:25:44 --> Language Class Initialized
INFO - 2018-06-01 01:25:44 --> Config Class Initialized
INFO - 2018-06-01 01:25:44 --> Loader Class Initialized
DEBUG - 2018-06-01 01:25:44 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-01 01:25:44 --> Helper loaded: url_helper
INFO - 2018-06-01 01:25:44 --> Helper loaded: form_helper
INFO - 2018-06-01 01:25:44 --> Helper loaded: date_helper
INFO - 2018-06-01 01:25:44 --> Helper loaded: util_helper
INFO - 2018-06-01 01:25:44 --> Helper loaded: text_helper
INFO - 2018-06-01 01:25:44 --> Helper loaded: string_helper
INFO - 2018-06-01 01:25:44 --> Database Driver Class Initialized
DEBUG - 2018-06-01 01:25:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-01 01:25:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-01 01:25:44 --> Email Class Initialized
INFO - 2018-06-01 01:25:45 --> Controller Class Initialized
DEBUG - 2018-06-01 01:25:45 --> Home MX_Controller Initialized
DEBUG - 2018-06-01 01:25:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-01 01:25:45 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-01 01:25:45 --> Login MX_Controller Initialized
INFO - 2018-06-01 01:25:45 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-01 01:25:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-01 01:25:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-01 01:25:45 --> Config Class Initialized
INFO - 2018-06-01 01:25:45 --> Hooks Class Initialized
DEBUG - 2018-06-01 01:25:45 --> UTF-8 Support Enabled
INFO - 2018-06-01 01:25:45 --> Utf8 Class Initialized
INFO - 2018-06-01 01:25:45 --> URI Class Initialized
INFO - 2018-06-01 01:25:45 --> Router Class Initialized
INFO - 2018-06-01 01:25:45 --> Output Class Initialized
INFO - 2018-06-01 01:25:45 --> Security Class Initialized
DEBUG - 2018-06-01 01:25:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 01:25:45 --> Input Class Initialized
INFO - 2018-06-01 01:25:45 --> Language Class Initialized
INFO - 2018-06-01 01:25:45 --> Language Class Initialized
INFO - 2018-06-01 01:25:45 --> Config Class Initialized
INFO - 2018-06-01 01:25:45 --> Loader Class Initialized
DEBUG - 2018-06-01 01:25:45 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-01 01:25:45 --> Helper loaded: url_helper
INFO - 2018-06-01 01:25:45 --> Helper loaded: form_helper
INFO - 2018-06-01 01:25:45 --> Helper loaded: date_helper
INFO - 2018-06-01 01:25:45 --> Helper loaded: util_helper
INFO - 2018-06-01 01:25:45 --> Helper loaded: text_helper
INFO - 2018-06-01 01:25:45 --> Helper loaded: string_helper
INFO - 2018-06-01 01:25:45 --> Database Driver Class Initialized
DEBUG - 2018-06-01 01:25:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-01 01:25:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-01 01:25:45 --> Email Class Initialized
INFO - 2018-06-01 01:25:45 --> Controller Class Initialized
DEBUG - 2018-06-01 01:25:45 --> Home MX_Controller Initialized
DEBUG - 2018-06-01 01:25:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-01 01:25:45 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-01 01:25:45 --> Login MX_Controller Initialized
INFO - 2018-06-01 01:25:45 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-01 01:25:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-01 01:25:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-01 01:25:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-01 01:25:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-01 01:25:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-01 01:25:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-01 01:25:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-01 01:25:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-06-01 01:25:45 --> Final output sent to browser
DEBUG - 2018-06-01 01:25:45 --> Total execution time: 0.4651
INFO - 2018-06-01 01:25:45 --> Config Class Initialized
INFO - 2018-06-01 01:25:45 --> Hooks Class Initialized
DEBUG - 2018-06-01 01:25:45 --> UTF-8 Support Enabled
INFO - 2018-06-01 01:25:45 --> Utf8 Class Initialized
INFO - 2018-06-01 01:25:45 --> URI Class Initialized
INFO - 2018-06-01 01:25:45 --> Router Class Initialized
INFO - 2018-06-01 01:25:45 --> Output Class Initialized
INFO - 2018-06-01 01:25:45 --> Security Class Initialized
DEBUG - 2018-06-01 01:25:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 01:25:46 --> Input Class Initialized
INFO - 2018-06-01 01:25:46 --> Language Class Initialized
ERROR - 2018-06-01 01:25:46 --> 404 Page Not Found: /index
INFO - 2018-06-01 01:25:46 --> Config Class Initialized
INFO - 2018-06-01 01:25:46 --> Hooks Class Initialized
DEBUG - 2018-06-01 01:25:46 --> UTF-8 Support Enabled
INFO - 2018-06-01 01:25:46 --> Utf8 Class Initialized
INFO - 2018-06-01 01:25:46 --> URI Class Initialized
INFO - 2018-06-01 01:25:46 --> Router Class Initialized
INFO - 2018-06-01 01:25:46 --> Output Class Initialized
INFO - 2018-06-01 01:25:46 --> Security Class Initialized
DEBUG - 2018-06-01 01:25:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 01:25:46 --> Input Class Initialized
INFO - 2018-06-01 01:25:46 --> Language Class Initialized
ERROR - 2018-06-01 01:25:46 --> 404 Page Not Found: /index
INFO - 2018-06-01 01:25:46 --> Config Class Initialized
INFO - 2018-06-01 01:25:46 --> Hooks Class Initialized
DEBUG - 2018-06-01 01:25:46 --> UTF-8 Support Enabled
INFO - 2018-06-01 01:25:46 --> Utf8 Class Initialized
INFO - 2018-06-01 01:25:46 --> URI Class Initialized
INFO - 2018-06-01 01:25:46 --> Router Class Initialized
INFO - 2018-06-01 01:25:46 --> Output Class Initialized
INFO - 2018-06-01 01:25:46 --> Security Class Initialized
DEBUG - 2018-06-01 01:25:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 01:25:46 --> Input Class Initialized
INFO - 2018-06-01 01:25:46 --> Language Class Initialized
ERROR - 2018-06-01 01:25:46 --> 404 Page Not Found: /index
INFO - 2018-06-01 01:26:01 --> Config Class Initialized
INFO - 2018-06-01 01:26:01 --> Hooks Class Initialized
DEBUG - 2018-06-01 01:26:01 --> UTF-8 Support Enabled
INFO - 2018-06-01 01:26:01 --> Utf8 Class Initialized
INFO - 2018-06-01 01:26:01 --> URI Class Initialized
INFO - 2018-06-01 01:26:01 --> Router Class Initialized
INFO - 2018-06-01 01:26:01 --> Output Class Initialized
INFO - 2018-06-01 01:26:01 --> Security Class Initialized
DEBUG - 2018-06-01 01:26:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 01:26:01 --> Input Class Initialized
INFO - 2018-06-01 01:26:01 --> Language Class Initialized
INFO - 2018-06-01 01:26:01 --> Language Class Initialized
INFO - 2018-06-01 01:26:01 --> Config Class Initialized
INFO - 2018-06-01 01:26:01 --> Loader Class Initialized
DEBUG - 2018-06-01 01:26:01 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-01 01:26:01 --> Helper loaded: url_helper
INFO - 2018-06-01 01:26:01 --> Helper loaded: form_helper
INFO - 2018-06-01 01:26:01 --> Helper loaded: date_helper
INFO - 2018-06-01 01:26:01 --> Helper loaded: util_helper
INFO - 2018-06-01 01:26:01 --> Helper loaded: text_helper
INFO - 2018-06-01 01:26:01 --> Helper loaded: string_helper
INFO - 2018-06-01 01:26:02 --> Database Driver Class Initialized
DEBUG - 2018-06-01 01:26:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-01 01:26:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-01 01:26:02 --> Email Class Initialized
INFO - 2018-06-01 01:26:02 --> Controller Class Initialized
DEBUG - 2018-06-01 01:26:02 --> Admin MX_Controller Initialized
INFO - 2018-06-01 01:26:02 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-01 01:26:02 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-01 01:26:02 --> Login MX_Controller Initialized
DEBUG - 2018-06-01 01:26:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-01 01:26:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-01 01:26:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
INFO - 2018-06-01 01:26:02 --> Config Class Initialized
INFO - 2018-06-01 01:26:02 --> Hooks Class Initialized
DEBUG - 2018-06-01 01:26:02 --> UTF-8 Support Enabled
INFO - 2018-06-01 01:26:02 --> Utf8 Class Initialized
INFO - 2018-06-01 01:26:02 --> URI Class Initialized
INFO - 2018-06-01 01:26:02 --> Router Class Initialized
INFO - 2018-06-01 01:26:02 --> Output Class Initialized
INFO - 2018-06-01 01:26:02 --> Security Class Initialized
DEBUG - 2018-06-01 01:26:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 01:26:02 --> Input Class Initialized
INFO - 2018-06-01 01:26:02 --> Language Class Initialized
ERROR - 2018-06-01 01:26:02 --> 404 Page Not Found: /index
INFO - 2018-06-01 01:26:06 --> Config Class Initialized
INFO - 2018-06-01 01:26:07 --> Hooks Class Initialized
DEBUG - 2018-06-01 01:26:07 --> UTF-8 Support Enabled
INFO - 2018-06-01 01:26:07 --> Utf8 Class Initialized
INFO - 2018-06-01 01:26:07 --> URI Class Initialized
INFO - 2018-06-01 01:26:07 --> Router Class Initialized
INFO - 2018-06-01 01:26:07 --> Output Class Initialized
INFO - 2018-06-01 01:26:07 --> Security Class Initialized
DEBUG - 2018-06-01 01:26:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 01:26:07 --> Input Class Initialized
INFO - 2018-06-01 01:26:07 --> Language Class Initialized
INFO - 2018-06-01 01:26:07 --> Language Class Initialized
INFO - 2018-06-01 01:26:07 --> Config Class Initialized
INFO - 2018-06-01 01:26:07 --> Loader Class Initialized
DEBUG - 2018-06-01 01:26:07 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-01 01:26:07 --> Helper loaded: url_helper
INFO - 2018-06-01 01:26:07 --> Helper loaded: form_helper
INFO - 2018-06-01 01:26:07 --> Helper loaded: date_helper
INFO - 2018-06-01 01:26:07 --> Helper loaded: util_helper
INFO - 2018-06-01 01:26:07 --> Helper loaded: text_helper
INFO - 2018-06-01 01:26:07 --> Helper loaded: string_helper
INFO - 2018-06-01 01:26:07 --> Database Driver Class Initialized
DEBUG - 2018-06-01 01:26:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-01 01:26:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-01 01:26:07 --> Email Class Initialized
INFO - 2018-06-01 01:26:07 --> Controller Class Initialized
DEBUG - 2018-06-01 01:26:07 --> Login MX_Controller Initialized
INFO - 2018-06-01 01:26:07 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-01 01:26:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-01 01:26:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-01 01:26:07 --> Email starts for admin@colin.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-06-01 01:26:07 --> User session created for 1
INFO - 2018-06-01 01:26:07 --> Login status admin@colin.com - success
INFO - 2018-06-01 01:26:07 --> Final output sent to browser
DEBUG - 2018-06-01 01:26:07 --> Total execution time: 0.5378
INFO - 2018-06-01 01:26:07 --> Config Class Initialized
INFO - 2018-06-01 01:26:07 --> Hooks Class Initialized
DEBUG - 2018-06-01 01:26:07 --> UTF-8 Support Enabled
INFO - 2018-06-01 01:26:07 --> Utf8 Class Initialized
INFO - 2018-06-01 01:26:07 --> URI Class Initialized
INFO - 2018-06-01 01:26:07 --> Router Class Initialized
INFO - 2018-06-01 01:26:07 --> Output Class Initialized
INFO - 2018-06-01 01:26:07 --> Security Class Initialized
DEBUG - 2018-06-01 01:26:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 01:26:07 --> Input Class Initialized
INFO - 2018-06-01 01:26:07 --> Language Class Initialized
INFO - 2018-06-01 01:26:07 --> Language Class Initialized
INFO - 2018-06-01 01:26:07 --> Config Class Initialized
INFO - 2018-06-01 01:26:07 --> Loader Class Initialized
DEBUG - 2018-06-01 01:26:07 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-01 01:26:07 --> Helper loaded: url_helper
INFO - 2018-06-01 01:26:07 --> Helper loaded: form_helper
INFO - 2018-06-01 01:26:07 --> Helper loaded: date_helper
INFO - 2018-06-01 01:26:07 --> Helper loaded: util_helper
INFO - 2018-06-01 01:26:07 --> Helper loaded: text_helper
INFO - 2018-06-01 01:26:07 --> Helper loaded: string_helper
INFO - 2018-06-01 01:26:07 --> Database Driver Class Initialized
DEBUG - 2018-06-01 01:26:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-01 01:26:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-01 01:26:07 --> Email Class Initialized
INFO - 2018-06-01 01:26:07 --> Controller Class Initialized
DEBUG - 2018-06-01 01:26:07 --> Admin MX_Controller Initialized
INFO - 2018-06-01 01:26:07 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-01 01:26:07 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-01 01:26:07 --> Login MX_Controller Initialized
DEBUG - 2018-06-01 01:26:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-01 01:26:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-01 01:26:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-01 01:26:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-01 01:26:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-01 01:26:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-01 01:26:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-01 01:26:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/dashboard.php
INFO - 2018-06-01 01:26:08 --> Final output sent to browser
INFO - 2018-06-01 01:26:08 --> Config Class Initialized
DEBUG - 2018-06-01 01:26:08 --> Total execution time: 0.4749
INFO - 2018-06-01 01:26:08 --> Config Class Initialized
INFO - 2018-06-01 01:26:08 --> Hooks Class Initialized
INFO - 2018-06-01 01:26:08 --> Hooks Class Initialized
DEBUG - 2018-06-01 01:26:08 --> UTF-8 Support Enabled
INFO - 2018-06-01 01:26:08 --> Utf8 Class Initialized
DEBUG - 2018-06-01 01:26:08 --> UTF-8 Support Enabled
INFO - 2018-06-01 01:26:08 --> URI Class Initialized
INFO - 2018-06-01 01:26:08 --> Utf8 Class Initialized
INFO - 2018-06-01 01:26:08 --> Router Class Initialized
INFO - 2018-06-01 01:26:08 --> URI Class Initialized
INFO - 2018-06-01 01:26:08 --> Output Class Initialized
INFO - 2018-06-01 01:26:08 --> Router Class Initialized
INFO - 2018-06-01 01:26:08 --> Security Class Initialized
DEBUG - 2018-06-01 01:26:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 01:26:08 --> Output Class Initialized
INFO - 2018-06-01 01:26:08 --> Input Class Initialized
INFO - 2018-06-01 01:26:08 --> Security Class Initialized
INFO - 2018-06-01 01:26:08 --> Language Class Initialized
DEBUG - 2018-06-01 01:26:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-06-01 01:26:08 --> 404 Page Not Found: /index
INFO - 2018-06-01 01:26:08 --> Input Class Initialized
INFO - 2018-06-01 01:26:08 --> Language Class Initialized
ERROR - 2018-06-01 01:26:08 --> 404 Page Not Found: /index
INFO - 2018-06-01 01:26:08 --> Config Class Initialized
INFO - 2018-06-01 01:26:08 --> Hooks Class Initialized
DEBUG - 2018-06-01 01:26:08 --> UTF-8 Support Enabled
INFO - 2018-06-01 01:26:08 --> Utf8 Class Initialized
INFO - 2018-06-01 01:26:08 --> URI Class Initialized
INFO - 2018-06-01 01:26:08 --> Router Class Initialized
INFO - 2018-06-01 01:26:08 --> Output Class Initialized
INFO - 2018-06-01 01:26:08 --> Security Class Initialized
DEBUG - 2018-06-01 01:26:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 01:26:08 --> Input Class Initialized
INFO - 2018-06-01 01:26:08 --> Language Class Initialized
ERROR - 2018-06-01 01:26:08 --> 404 Page Not Found: /index
INFO - 2018-06-01 01:26:09 --> Config Class Initialized
INFO - 2018-06-01 01:26:09 --> Hooks Class Initialized
DEBUG - 2018-06-01 01:26:09 --> UTF-8 Support Enabled
INFO - 2018-06-01 01:26:09 --> Utf8 Class Initialized
INFO - 2018-06-01 01:26:09 --> URI Class Initialized
INFO - 2018-06-01 01:26:09 --> Router Class Initialized
INFO - 2018-06-01 01:26:10 --> Output Class Initialized
INFO - 2018-06-01 01:26:10 --> Security Class Initialized
DEBUG - 2018-06-01 01:26:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 01:26:10 --> Input Class Initialized
INFO - 2018-06-01 01:26:10 --> Language Class Initialized
INFO - 2018-06-01 01:26:10 --> Language Class Initialized
INFO - 2018-06-01 01:26:10 --> Config Class Initialized
INFO - 2018-06-01 01:26:10 --> Loader Class Initialized
DEBUG - 2018-06-01 01:26:10 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-01 01:26:10 --> Helper loaded: url_helper
INFO - 2018-06-01 01:26:10 --> Helper loaded: form_helper
INFO - 2018-06-01 01:26:10 --> Helper loaded: date_helper
INFO - 2018-06-01 01:26:10 --> Helper loaded: util_helper
INFO - 2018-06-01 01:26:10 --> Helper loaded: text_helper
INFO - 2018-06-01 01:26:10 --> Helper loaded: string_helper
INFO - 2018-06-01 01:26:10 --> Database Driver Class Initialized
DEBUG - 2018-06-01 01:26:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-01 01:26:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-01 01:26:10 --> Email Class Initialized
INFO - 2018-06-01 01:26:10 --> Controller Class Initialized
DEBUG - 2018-06-01 01:26:10 --> Programs MX_Controller Initialized
INFO - 2018-06-01 01:26:10 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-01 01:26:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-06-01 01:26:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-01 01:26:10 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-01 01:26:10 --> Login MX_Controller Initialized
DEBUG - 2018-06-01 01:26:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-01 01:26:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-01 01:26:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-01 01:26:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-01 01:26:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-01 01:26:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-01 01:26:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/programs.php
INFO - 2018-06-01 01:26:10 --> Final output sent to browser
DEBUG - 2018-06-01 01:26:10 --> Total execution time: 0.6838
INFO - 2018-06-01 01:26:10 --> Config Class Initialized
INFO - 2018-06-01 01:26:10 --> Hooks Class Initialized
DEBUG - 2018-06-01 01:26:10 --> UTF-8 Support Enabled
INFO - 2018-06-01 01:26:10 --> Utf8 Class Initialized
INFO - 2018-06-01 01:26:10 --> URI Class Initialized
INFO - 2018-06-01 01:26:10 --> Router Class Initialized
INFO - 2018-06-01 01:26:11 --> Output Class Initialized
INFO - 2018-06-01 01:26:11 --> Security Class Initialized
DEBUG - 2018-06-01 01:26:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 01:26:11 --> Input Class Initialized
INFO - 2018-06-01 01:26:11 --> Language Class Initialized
INFO - 2018-06-01 01:26:11 --> Language Class Initialized
INFO - 2018-06-01 01:26:11 --> Config Class Initialized
INFO - 2018-06-01 01:26:11 --> Loader Class Initialized
DEBUG - 2018-06-01 01:26:11 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-01 01:26:11 --> Helper loaded: url_helper
INFO - 2018-06-01 01:26:11 --> Helper loaded: form_helper
INFO - 2018-06-01 01:26:11 --> Helper loaded: date_helper
INFO - 2018-06-01 01:26:11 --> Helper loaded: util_helper
INFO - 2018-06-01 01:26:11 --> Helper loaded: text_helper
INFO - 2018-06-01 01:26:11 --> Helper loaded: string_helper
INFO - 2018-06-01 01:26:11 --> Database Driver Class Initialized
DEBUG - 2018-06-01 01:26:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-01 01:26:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-01 01:26:11 --> Email Class Initialized
INFO - 2018-06-01 01:26:11 --> Controller Class Initialized
DEBUG - 2018-06-01 01:26:11 --> Programs MX_Controller Initialized
INFO - 2018-06-01 01:26:12 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-01 01:26:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-06-01 01:26:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-01 01:26:12 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-01 01:26:12 --> Login MX_Controller Initialized
DEBUG - 2018-06-01 01:26:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-01 01:26:12 --> Final output sent to browser
DEBUG - 2018-06-01 01:26:12 --> Total execution time: 1.4671
INFO - 2018-06-01 01:26:15 --> Config Class Initialized
INFO - 2018-06-01 01:26:15 --> Hooks Class Initialized
DEBUG - 2018-06-01 01:26:15 --> UTF-8 Support Enabled
INFO - 2018-06-01 01:26:15 --> Utf8 Class Initialized
INFO - 2018-06-01 01:26:15 --> URI Class Initialized
INFO - 2018-06-01 01:26:15 --> Router Class Initialized
INFO - 2018-06-01 01:26:15 --> Output Class Initialized
INFO - 2018-06-01 01:26:15 --> Security Class Initialized
DEBUG - 2018-06-01 01:26:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 01:26:15 --> Input Class Initialized
INFO - 2018-06-01 01:26:15 --> Language Class Initialized
INFO - 2018-06-01 01:26:16 --> Language Class Initialized
INFO - 2018-06-01 01:26:16 --> Config Class Initialized
INFO - 2018-06-01 01:26:16 --> Loader Class Initialized
DEBUG - 2018-06-01 01:26:16 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-01 01:26:16 --> Helper loaded: url_helper
INFO - 2018-06-01 01:26:16 --> Helper loaded: form_helper
INFO - 2018-06-01 01:26:16 --> Helper loaded: date_helper
INFO - 2018-06-01 01:26:16 --> Helper loaded: util_helper
INFO - 2018-06-01 01:26:16 --> Helper loaded: text_helper
INFO - 2018-06-01 01:26:16 --> Helper loaded: string_helper
INFO - 2018-06-01 01:26:16 --> Database Driver Class Initialized
DEBUG - 2018-06-01 01:26:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-01 01:26:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-01 01:26:16 --> Email Class Initialized
INFO - 2018-06-01 01:26:16 --> Controller Class Initialized
DEBUG - 2018-06-01 01:26:16 --> Admin MX_Controller Initialized
INFO - 2018-06-01 01:26:16 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-01 01:26:16 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-01 01:26:16 --> Login MX_Controller Initialized
DEBUG - 2018-06-01 01:26:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-01 01:26:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-01 01:26:16 --> Final output sent to browser
DEBUG - 2018-06-01 01:26:16 --> Total execution time: 0.4836
INFO - 2018-06-01 01:26:19 --> Config Class Initialized
INFO - 2018-06-01 01:26:19 --> Hooks Class Initialized
DEBUG - 2018-06-01 01:26:19 --> UTF-8 Support Enabled
INFO - 2018-06-01 01:26:19 --> Utf8 Class Initialized
INFO - 2018-06-01 01:26:19 --> URI Class Initialized
INFO - 2018-06-01 01:26:19 --> Router Class Initialized
INFO - 2018-06-01 01:26:19 --> Output Class Initialized
INFO - 2018-06-01 01:26:19 --> Security Class Initialized
DEBUG - 2018-06-01 01:26:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 01:26:19 --> Input Class Initialized
INFO - 2018-06-01 01:26:19 --> Language Class Initialized
INFO - 2018-06-01 01:26:19 --> Language Class Initialized
INFO - 2018-06-01 01:26:19 --> Config Class Initialized
INFO - 2018-06-01 01:26:19 --> Loader Class Initialized
DEBUG - 2018-06-01 01:26:19 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-01 01:26:19 --> Helper loaded: url_helper
INFO - 2018-06-01 01:26:19 --> Helper loaded: form_helper
INFO - 2018-06-01 01:26:19 --> Helper loaded: date_helper
INFO - 2018-06-01 01:26:19 --> Helper loaded: util_helper
INFO - 2018-06-01 01:26:19 --> Helper loaded: text_helper
INFO - 2018-06-01 01:26:20 --> Helper loaded: string_helper
INFO - 2018-06-01 01:26:20 --> Database Driver Class Initialized
DEBUG - 2018-06-01 01:26:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-01 01:26:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-01 01:26:20 --> Email Class Initialized
INFO - 2018-06-01 01:26:20 --> Controller Class Initialized
DEBUG - 2018-06-01 01:26:20 --> Home MX_Controller Initialized
DEBUG - 2018-06-01 01:26:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-01 01:26:20 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-01 01:26:20 --> Login MX_Controller Initialized
INFO - 2018-06-01 01:26:20 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-01 01:26:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-01 01:26:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-01 01:26:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-01 01:26:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-01 01:26:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-01 01:26:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-01 01:26:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-01 01:26:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-06-01 01:26:20 --> Final output sent to browser
DEBUG - 2018-06-01 01:26:20 --> Total execution time: 0.5042
INFO - 2018-06-01 01:26:20 --> Config Class Initialized
INFO - 2018-06-01 01:26:20 --> Config Class Initialized
INFO - 2018-06-01 01:26:20 --> Hooks Class Initialized
INFO - 2018-06-01 01:26:20 --> Hooks Class Initialized
DEBUG - 2018-06-01 01:26:20 --> UTF-8 Support Enabled
DEBUG - 2018-06-01 01:26:20 --> UTF-8 Support Enabled
INFO - 2018-06-01 01:26:20 --> Utf8 Class Initialized
INFO - 2018-06-01 01:26:20 --> URI Class Initialized
INFO - 2018-06-01 01:26:20 --> Utf8 Class Initialized
INFO - 2018-06-01 01:26:20 --> Router Class Initialized
INFO - 2018-06-01 01:26:20 --> URI Class Initialized
INFO - 2018-06-01 01:26:20 --> Output Class Initialized
INFO - 2018-06-01 01:26:20 --> Router Class Initialized
INFO - 2018-06-01 01:26:20 --> Security Class Initialized
INFO - 2018-06-01 01:26:20 --> Output Class Initialized
DEBUG - 2018-06-01 01:26:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 01:26:20 --> Security Class Initialized
INFO - 2018-06-01 01:26:20 --> Input Class Initialized
DEBUG - 2018-06-01 01:26:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 01:26:20 --> Input Class Initialized
INFO - 2018-06-01 01:26:20 --> Language Class Initialized
ERROR - 2018-06-01 01:26:20 --> 404 Page Not Found: /index
INFO - 2018-06-01 01:26:20 --> Language Class Initialized
ERROR - 2018-06-01 01:26:20 --> 404 Page Not Found: /index
INFO - 2018-06-01 01:26:21 --> Config Class Initialized
INFO - 2018-06-01 01:26:21 --> Hooks Class Initialized
DEBUG - 2018-06-01 01:26:21 --> UTF-8 Support Enabled
INFO - 2018-06-01 01:26:21 --> Utf8 Class Initialized
INFO - 2018-06-01 01:26:21 --> URI Class Initialized
INFO - 2018-06-01 01:26:21 --> Router Class Initialized
INFO - 2018-06-01 01:26:21 --> Output Class Initialized
INFO - 2018-06-01 01:26:21 --> Security Class Initialized
DEBUG - 2018-06-01 01:26:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 01:26:21 --> Input Class Initialized
INFO - 2018-06-01 01:26:21 --> Language Class Initialized
ERROR - 2018-06-01 01:26:21 --> 404 Page Not Found: /index
INFO - 2018-06-01 01:26:21 --> Config Class Initialized
INFO - 2018-06-01 01:26:21 --> Hooks Class Initialized
DEBUG - 2018-06-01 01:26:21 --> UTF-8 Support Enabled
INFO - 2018-06-01 01:26:21 --> Utf8 Class Initialized
INFO - 2018-06-01 01:26:21 --> URI Class Initialized
INFO - 2018-06-01 01:26:21 --> Router Class Initialized
INFO - 2018-06-01 01:26:21 --> Output Class Initialized
INFO - 2018-06-01 01:26:21 --> Security Class Initialized
DEBUG - 2018-06-01 01:26:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 01:26:21 --> Input Class Initialized
INFO - 2018-06-01 01:26:21 --> Language Class Initialized
ERROR - 2018-06-01 01:26:21 --> 404 Page Not Found: /index
INFO - 2018-06-01 01:26:23 --> Config Class Initialized
INFO - 2018-06-01 01:26:23 --> Hooks Class Initialized
DEBUG - 2018-06-01 01:26:23 --> UTF-8 Support Enabled
INFO - 2018-06-01 01:26:23 --> Utf8 Class Initialized
INFO - 2018-06-01 01:26:23 --> URI Class Initialized
INFO - 2018-06-01 01:26:23 --> Router Class Initialized
INFO - 2018-06-01 01:26:23 --> Output Class Initialized
INFO - 2018-06-01 01:26:23 --> Security Class Initialized
DEBUG - 2018-06-01 01:26:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 01:26:23 --> Input Class Initialized
INFO - 2018-06-01 01:26:23 --> Language Class Initialized
INFO - 2018-06-01 01:26:23 --> Language Class Initialized
INFO - 2018-06-01 01:26:23 --> Config Class Initialized
INFO - 2018-06-01 01:26:23 --> Loader Class Initialized
DEBUG - 2018-06-01 01:26:23 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-01 01:26:23 --> Helper loaded: url_helper
INFO - 2018-06-01 01:26:23 --> Helper loaded: form_helper
INFO - 2018-06-01 01:26:23 --> Helper loaded: date_helper
INFO - 2018-06-01 01:26:23 --> Helper loaded: util_helper
INFO - 2018-06-01 01:26:23 --> Helper loaded: text_helper
INFO - 2018-06-01 01:26:23 --> Helper loaded: string_helper
INFO - 2018-06-01 01:26:23 --> Database Driver Class Initialized
DEBUG - 2018-06-01 01:26:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-01 01:26:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-01 01:26:23 --> Email Class Initialized
INFO - 2018-06-01 01:26:23 --> Controller Class Initialized
DEBUG - 2018-06-01 01:26:23 --> Home MX_Controller Initialized
DEBUG - 2018-06-01 01:26:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-01 01:26:23 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-01 01:26:23 --> Login MX_Controller Initialized
INFO - 2018-06-01 01:26:24 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-01 01:26:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-01 01:26:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-01 01:26:24 --> Config Class Initialized
INFO - 2018-06-01 01:26:24 --> Hooks Class Initialized
DEBUG - 2018-06-01 01:26:24 --> UTF-8 Support Enabled
INFO - 2018-06-01 01:26:24 --> Utf8 Class Initialized
INFO - 2018-06-01 01:26:24 --> URI Class Initialized
INFO - 2018-06-01 01:26:24 --> Router Class Initialized
INFO - 2018-06-01 01:26:24 --> Output Class Initialized
INFO - 2018-06-01 01:26:24 --> Security Class Initialized
DEBUG - 2018-06-01 01:26:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 01:26:24 --> Input Class Initialized
INFO - 2018-06-01 01:26:24 --> Language Class Initialized
INFO - 2018-06-01 01:26:24 --> Language Class Initialized
INFO - 2018-06-01 01:26:24 --> Config Class Initialized
INFO - 2018-06-01 01:26:24 --> Loader Class Initialized
DEBUG - 2018-06-01 01:26:24 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-01 01:26:24 --> Helper loaded: url_helper
INFO - 2018-06-01 01:26:24 --> Helper loaded: form_helper
INFO - 2018-06-01 01:26:24 --> Helper loaded: date_helper
INFO - 2018-06-01 01:26:24 --> Helper loaded: util_helper
INFO - 2018-06-01 01:26:24 --> Helper loaded: text_helper
INFO - 2018-06-01 01:26:24 --> Helper loaded: string_helper
INFO - 2018-06-01 01:26:24 --> Database Driver Class Initialized
DEBUG - 2018-06-01 01:26:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-01 01:26:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-01 01:26:24 --> Email Class Initialized
INFO - 2018-06-01 01:26:24 --> Controller Class Initialized
DEBUG - 2018-06-01 01:26:24 --> Home MX_Controller Initialized
DEBUG - 2018-06-01 01:26:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-01 01:26:24 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-01 01:26:24 --> Login MX_Controller Initialized
INFO - 2018-06-01 01:26:24 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-01 01:26:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-01 01:26:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-01 01:26:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-01 01:26:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-01 01:26:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-01 01:26:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-01 01:26:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-01 01:26:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-06-01 01:26:24 --> Final output sent to browser
DEBUG - 2018-06-01 01:26:24 --> Total execution time: 0.4839
INFO - 2018-06-01 01:26:24 --> Config Class Initialized
INFO - 2018-06-01 01:26:24 --> Hooks Class Initialized
DEBUG - 2018-06-01 01:26:24 --> UTF-8 Support Enabled
INFO - 2018-06-01 01:26:24 --> Utf8 Class Initialized
INFO - 2018-06-01 01:26:24 --> URI Class Initialized
INFO - 2018-06-01 01:26:25 --> Router Class Initialized
INFO - 2018-06-01 01:26:25 --> Output Class Initialized
INFO - 2018-06-01 01:26:25 --> Security Class Initialized
DEBUG - 2018-06-01 01:26:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 01:26:25 --> Input Class Initialized
INFO - 2018-06-01 01:26:25 --> Language Class Initialized
ERROR - 2018-06-01 01:26:25 --> 404 Page Not Found: /index
INFO - 2018-06-01 01:26:25 --> Config Class Initialized
INFO - 2018-06-01 01:26:25 --> Hooks Class Initialized
DEBUG - 2018-06-01 01:26:25 --> UTF-8 Support Enabled
INFO - 2018-06-01 01:26:25 --> Utf8 Class Initialized
INFO - 2018-06-01 01:26:25 --> URI Class Initialized
INFO - 2018-06-01 01:26:25 --> Router Class Initialized
INFO - 2018-06-01 01:26:25 --> Output Class Initialized
INFO - 2018-06-01 01:26:25 --> Security Class Initialized
DEBUG - 2018-06-01 01:26:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 01:26:25 --> Input Class Initialized
INFO - 2018-06-01 01:26:25 --> Language Class Initialized
ERROR - 2018-06-01 01:26:25 --> 404 Page Not Found: /index
INFO - 2018-06-01 01:26:25 --> Config Class Initialized
INFO - 2018-06-01 01:26:25 --> Hooks Class Initialized
DEBUG - 2018-06-01 01:26:25 --> UTF-8 Support Enabled
INFO - 2018-06-01 01:26:25 --> Utf8 Class Initialized
INFO - 2018-06-01 01:26:25 --> URI Class Initialized
INFO - 2018-06-01 01:26:25 --> Router Class Initialized
INFO - 2018-06-01 01:26:25 --> Output Class Initialized
INFO - 2018-06-01 01:26:25 --> Security Class Initialized
DEBUG - 2018-06-01 01:26:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 01:26:25 --> Input Class Initialized
INFO - 2018-06-01 01:26:25 --> Language Class Initialized
ERROR - 2018-06-01 01:26:25 --> 404 Page Not Found: /index
INFO - 2018-06-01 01:26:29 --> Config Class Initialized
INFO - 2018-06-01 01:26:29 --> Hooks Class Initialized
DEBUG - 2018-06-01 01:26:29 --> UTF-8 Support Enabled
INFO - 2018-06-01 01:26:29 --> Utf8 Class Initialized
INFO - 2018-06-01 01:26:29 --> URI Class Initialized
INFO - 2018-06-01 01:26:29 --> Router Class Initialized
INFO - 2018-06-01 01:26:29 --> Output Class Initialized
INFO - 2018-06-01 01:26:30 --> Security Class Initialized
DEBUG - 2018-06-01 01:26:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 01:26:30 --> Input Class Initialized
INFO - 2018-06-01 01:26:30 --> Language Class Initialized
INFO - 2018-06-01 01:26:30 --> Language Class Initialized
INFO - 2018-06-01 01:26:30 --> Config Class Initialized
INFO - 2018-06-01 01:26:30 --> Loader Class Initialized
DEBUG - 2018-06-01 01:26:30 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-01 01:26:30 --> Helper loaded: url_helper
INFO - 2018-06-01 01:26:30 --> Helper loaded: form_helper
INFO - 2018-06-01 01:26:30 --> Helper loaded: date_helper
INFO - 2018-06-01 01:26:30 --> Helper loaded: util_helper
INFO - 2018-06-01 01:26:30 --> Helper loaded: text_helper
INFO - 2018-06-01 01:26:30 --> Helper loaded: string_helper
INFO - 2018-06-01 01:26:30 --> Database Driver Class Initialized
DEBUG - 2018-06-01 01:26:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-01 01:26:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-01 01:26:30 --> Email Class Initialized
INFO - 2018-06-01 01:26:30 --> Controller Class Initialized
DEBUG - 2018-06-01 01:26:30 --> Home MX_Controller Initialized
DEBUG - 2018-06-01 01:26:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-01 01:26:30 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-01 01:26:30 --> Login MX_Controller Initialized
INFO - 2018-06-01 01:26:30 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-01 01:26:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-01 01:26:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-01 01:26:30 --> Config Class Initialized
INFO - 2018-06-01 01:26:30 --> Hooks Class Initialized
DEBUG - 2018-06-01 01:26:30 --> UTF-8 Support Enabled
INFO - 2018-06-01 01:26:30 --> Utf8 Class Initialized
INFO - 2018-06-01 01:26:30 --> URI Class Initialized
INFO - 2018-06-01 01:26:30 --> Router Class Initialized
INFO - 2018-06-01 01:26:30 --> Output Class Initialized
INFO - 2018-06-01 01:26:30 --> Security Class Initialized
DEBUG - 2018-06-01 01:26:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 01:26:30 --> Input Class Initialized
INFO - 2018-06-01 01:26:30 --> Language Class Initialized
INFO - 2018-06-01 01:26:30 --> Language Class Initialized
INFO - 2018-06-01 01:26:30 --> Config Class Initialized
INFO - 2018-06-01 01:26:30 --> Loader Class Initialized
DEBUG - 2018-06-01 01:26:30 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-01 01:26:30 --> Helper loaded: url_helper
INFO - 2018-06-01 01:26:30 --> Helper loaded: form_helper
INFO - 2018-06-01 01:26:30 --> Helper loaded: date_helper
INFO - 2018-06-01 01:26:30 --> Helper loaded: util_helper
INFO - 2018-06-01 01:26:30 --> Helper loaded: text_helper
INFO - 2018-06-01 01:26:30 --> Helper loaded: string_helper
INFO - 2018-06-01 01:26:30 --> Database Driver Class Initialized
DEBUG - 2018-06-01 01:26:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-01 01:26:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-01 01:26:30 --> Email Class Initialized
INFO - 2018-06-01 01:26:30 --> Controller Class Initialized
DEBUG - 2018-06-01 01:26:30 --> Home MX_Controller Initialized
DEBUG - 2018-06-01 01:26:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-01 01:26:30 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-01 01:26:30 --> Login MX_Controller Initialized
INFO - 2018-06-01 01:26:30 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-01 01:26:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-01 01:26:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-01 01:26:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-01 01:26:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-01 01:26:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-01 01:26:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-01 01:26:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-01 01:26:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-06-01 01:26:30 --> Final output sent to browser
DEBUG - 2018-06-01 01:26:30 --> Total execution time: 0.4698
INFO - 2018-06-01 01:26:31 --> Config Class Initialized
INFO - 2018-06-01 01:26:31 --> Hooks Class Initialized
DEBUG - 2018-06-01 01:26:31 --> UTF-8 Support Enabled
INFO - 2018-06-01 01:26:31 --> Utf8 Class Initialized
INFO - 2018-06-01 01:26:31 --> URI Class Initialized
INFO - 2018-06-01 01:26:31 --> Router Class Initialized
INFO - 2018-06-01 01:26:31 --> Output Class Initialized
INFO - 2018-06-01 01:26:31 --> Security Class Initialized
DEBUG - 2018-06-01 01:26:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 01:26:31 --> Input Class Initialized
INFO - 2018-06-01 01:26:31 --> Language Class Initialized
ERROR - 2018-06-01 01:26:31 --> 404 Page Not Found: /index
INFO - 2018-06-01 01:26:31 --> Config Class Initialized
INFO - 2018-06-01 01:26:31 --> Hooks Class Initialized
DEBUG - 2018-06-01 01:26:31 --> UTF-8 Support Enabled
INFO - 2018-06-01 01:26:31 --> Utf8 Class Initialized
INFO - 2018-06-01 01:26:31 --> URI Class Initialized
INFO - 2018-06-01 01:26:31 --> Router Class Initialized
INFO - 2018-06-01 01:26:31 --> Output Class Initialized
INFO - 2018-06-01 01:26:31 --> Security Class Initialized
DEBUG - 2018-06-01 01:26:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 01:26:31 --> Input Class Initialized
INFO - 2018-06-01 01:26:31 --> Language Class Initialized
ERROR - 2018-06-01 01:26:31 --> 404 Page Not Found: /index
INFO - 2018-06-01 01:26:31 --> Config Class Initialized
INFO - 2018-06-01 01:26:31 --> Hooks Class Initialized
DEBUG - 2018-06-01 01:26:31 --> UTF-8 Support Enabled
INFO - 2018-06-01 01:26:31 --> Utf8 Class Initialized
INFO - 2018-06-01 01:26:31 --> URI Class Initialized
INFO - 2018-06-01 01:26:31 --> Router Class Initialized
INFO - 2018-06-01 01:26:31 --> Output Class Initialized
INFO - 2018-06-01 01:26:31 --> Security Class Initialized
DEBUG - 2018-06-01 01:26:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 01:26:31 --> Input Class Initialized
INFO - 2018-06-01 01:26:31 --> Language Class Initialized
ERROR - 2018-06-01 01:26:31 --> 404 Page Not Found: /index
INFO - 2018-06-01 01:26:59 --> Config Class Initialized
INFO - 2018-06-01 01:27:00 --> Hooks Class Initialized
DEBUG - 2018-06-01 01:27:00 --> UTF-8 Support Enabled
INFO - 2018-06-01 01:27:00 --> Utf8 Class Initialized
INFO - 2018-06-01 01:27:00 --> URI Class Initialized
INFO - 2018-06-01 01:27:00 --> Router Class Initialized
INFO - 2018-06-01 01:27:00 --> Output Class Initialized
INFO - 2018-06-01 01:27:00 --> Security Class Initialized
DEBUG - 2018-06-01 01:27:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 01:27:00 --> Input Class Initialized
INFO - 2018-06-01 01:27:00 --> Language Class Initialized
INFO - 2018-06-01 01:27:00 --> Language Class Initialized
INFO - 2018-06-01 01:27:00 --> Config Class Initialized
INFO - 2018-06-01 01:27:00 --> Loader Class Initialized
DEBUG - 2018-06-01 01:27:00 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-01 01:27:00 --> Helper loaded: url_helper
INFO - 2018-06-01 01:27:00 --> Helper loaded: form_helper
INFO - 2018-06-01 01:27:00 --> Helper loaded: date_helper
INFO - 2018-06-01 01:27:00 --> Helper loaded: util_helper
INFO - 2018-06-01 01:27:00 --> Helper loaded: text_helper
INFO - 2018-06-01 01:27:00 --> Helper loaded: string_helper
INFO - 2018-06-01 01:27:00 --> Database Driver Class Initialized
DEBUG - 2018-06-01 01:27:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-01 01:27:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-01 01:27:00 --> Email Class Initialized
INFO - 2018-06-01 01:27:00 --> Controller Class Initialized
DEBUG - 2018-06-01 01:27:00 --> Chapters MX_Controller Initialized
INFO - 2018-06-01 01:27:00 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-01 01:27:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Chapters_model.php
DEBUG - 2018-06-01 01:27:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-01 01:27:00 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-01 01:27:00 --> Login MX_Controller Initialized
DEBUG - 2018-06-01 01:27:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-01 01:27:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-01 01:27:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-01 01:27:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-01 01:27:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-01 01:27:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-01 01:27:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/chapters/chapters.php
INFO - 2018-06-01 01:27:00 --> Final output sent to browser
DEBUG - 2018-06-01 01:27:00 --> Total execution time: 0.4864
INFO - 2018-06-01 01:27:00 --> Config Class Initialized
INFO - 2018-06-01 01:27:00 --> Hooks Class Initialized
DEBUG - 2018-06-01 01:27:00 --> UTF-8 Support Enabled
INFO - 2018-06-01 01:27:00 --> Utf8 Class Initialized
INFO - 2018-06-01 01:27:00 --> URI Class Initialized
INFO - 2018-06-01 01:27:00 --> Router Class Initialized
INFO - 2018-06-01 01:27:00 --> Output Class Initialized
INFO - 2018-06-01 01:27:00 --> Security Class Initialized
DEBUG - 2018-06-01 01:27:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 01:27:00 --> Input Class Initialized
INFO - 2018-06-01 01:27:01 --> Language Class Initialized
INFO - 2018-06-01 01:27:01 --> Language Class Initialized
INFO - 2018-06-01 01:27:01 --> Config Class Initialized
INFO - 2018-06-01 01:27:01 --> Loader Class Initialized
DEBUG - 2018-06-01 01:27:01 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-01 01:27:01 --> Helper loaded: url_helper
INFO - 2018-06-01 01:27:01 --> Helper loaded: form_helper
INFO - 2018-06-01 01:27:01 --> Helper loaded: date_helper
INFO - 2018-06-01 01:27:01 --> Helper loaded: util_helper
INFO - 2018-06-01 01:27:01 --> Helper loaded: text_helper
INFO - 2018-06-01 01:27:01 --> Helper loaded: string_helper
INFO - 2018-06-01 01:27:01 --> Database Driver Class Initialized
DEBUG - 2018-06-01 01:27:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-01 01:27:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-01 01:27:01 --> Email Class Initialized
INFO - 2018-06-01 01:27:01 --> Controller Class Initialized
DEBUG - 2018-06-01 01:27:01 --> Chapters MX_Controller Initialized
INFO - 2018-06-01 01:27:01 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-01 01:27:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Chapters_model.php
DEBUG - 2018-06-01 01:27:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-01 01:27:01 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-01 01:27:01 --> Login MX_Controller Initialized
DEBUG - 2018-06-01 01:27:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-01 01:27:01 --> Final output sent to browser
DEBUG - 2018-06-01 01:27:01 --> Total execution time: 0.5500
INFO - 2018-06-01 01:27:06 --> Config Class Initialized
INFO - 2018-06-01 01:27:06 --> Hooks Class Initialized
DEBUG - 2018-06-01 01:27:06 --> UTF-8 Support Enabled
INFO - 2018-06-01 01:27:06 --> Utf8 Class Initialized
INFO - 2018-06-01 01:27:06 --> URI Class Initialized
INFO - 2018-06-01 01:27:06 --> Router Class Initialized
INFO - 2018-06-01 01:27:06 --> Output Class Initialized
INFO - 2018-06-01 01:27:06 --> Security Class Initialized
DEBUG - 2018-06-01 01:27:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 01:27:06 --> Input Class Initialized
INFO - 2018-06-01 01:27:06 --> Language Class Initialized
INFO - 2018-06-01 01:27:06 --> Language Class Initialized
INFO - 2018-06-01 01:27:06 --> Config Class Initialized
INFO - 2018-06-01 01:27:06 --> Loader Class Initialized
DEBUG - 2018-06-01 01:27:06 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-01 01:27:06 --> Helper loaded: url_helper
INFO - 2018-06-01 01:27:07 --> Helper loaded: form_helper
INFO - 2018-06-01 01:27:07 --> Helper loaded: date_helper
INFO - 2018-06-01 01:27:07 --> Helper loaded: util_helper
INFO - 2018-06-01 01:27:07 --> Helper loaded: text_helper
INFO - 2018-06-01 01:27:07 --> Helper loaded: string_helper
INFO - 2018-06-01 01:27:07 --> Database Driver Class Initialized
DEBUG - 2018-06-01 01:27:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-01 01:27:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-01 01:27:07 --> Email Class Initialized
INFO - 2018-06-01 01:27:07 --> Controller Class Initialized
DEBUG - 2018-06-01 01:27:07 --> Chapters MX_Controller Initialized
INFO - 2018-06-01 01:27:07 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-01 01:27:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Chapters_model.php
DEBUG - 2018-06-01 01:27:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-01 01:27:07 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-01 01:27:07 --> Login MX_Controller Initialized
DEBUG - 2018-06-01 01:27:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-01 01:27:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-01 01:27:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-01 01:27:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-01 01:27:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-01 01:27:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-01 01:27:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/chapters/create_chapter.php
INFO - 2018-06-01 01:27:07 --> Final output sent to browser
DEBUG - 2018-06-01 01:27:07 --> Total execution time: 0.5079
INFO - 2018-06-01 01:27:13 --> Config Class Initialized
INFO - 2018-06-01 01:27:13 --> Hooks Class Initialized
DEBUG - 2018-06-01 01:27:13 --> UTF-8 Support Enabled
INFO - 2018-06-01 01:27:13 --> Utf8 Class Initialized
INFO - 2018-06-01 01:27:13 --> URI Class Initialized
INFO - 2018-06-01 01:27:13 --> Router Class Initialized
INFO - 2018-06-01 01:27:13 --> Output Class Initialized
INFO - 2018-06-01 01:27:13 --> Security Class Initialized
DEBUG - 2018-06-01 01:27:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 01:27:13 --> Input Class Initialized
INFO - 2018-06-01 01:27:13 --> Language Class Initialized
INFO - 2018-06-01 01:27:13 --> Language Class Initialized
INFO - 2018-06-01 01:27:13 --> Config Class Initialized
INFO - 2018-06-01 01:27:13 --> Loader Class Initialized
DEBUG - 2018-06-01 01:27:13 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-01 01:27:13 --> Helper loaded: url_helper
INFO - 2018-06-01 01:27:13 --> Helper loaded: form_helper
INFO - 2018-06-01 01:27:13 --> Helper loaded: date_helper
INFO - 2018-06-01 01:27:13 --> Helper loaded: util_helper
INFO - 2018-06-01 01:27:13 --> Helper loaded: text_helper
INFO - 2018-06-01 01:27:13 --> Helper loaded: string_helper
INFO - 2018-06-01 01:27:13 --> Database Driver Class Initialized
DEBUG - 2018-06-01 01:27:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-01 01:27:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-01 01:27:13 --> Email Class Initialized
INFO - 2018-06-01 01:27:13 --> Controller Class Initialized
DEBUG - 2018-06-01 01:27:13 --> Chapters MX_Controller Initialized
INFO - 2018-06-01 01:27:13 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-01 01:27:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Chapters_model.php
DEBUG - 2018-06-01 01:27:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-01 01:27:13 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-01 01:27:13 --> Login MX_Controller Initialized
DEBUG - 2018-06-01 01:27:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-01 01:27:13 --> Config Class Initialized
INFO - 2018-06-01 01:27:13 --> Hooks Class Initialized
DEBUG - 2018-06-01 01:27:13 --> UTF-8 Support Enabled
INFO - 2018-06-01 01:27:13 --> Utf8 Class Initialized
INFO - 2018-06-01 01:27:13 --> URI Class Initialized
INFO - 2018-06-01 01:27:13 --> Router Class Initialized
INFO - 2018-06-01 01:27:13 --> Output Class Initialized
INFO - 2018-06-01 01:27:13 --> Security Class Initialized
DEBUG - 2018-06-01 01:27:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 01:27:13 --> Input Class Initialized
INFO - 2018-06-01 01:27:14 --> Language Class Initialized
INFO - 2018-06-01 01:27:14 --> Language Class Initialized
INFO - 2018-06-01 01:27:14 --> Config Class Initialized
INFO - 2018-06-01 01:27:14 --> Loader Class Initialized
DEBUG - 2018-06-01 01:27:14 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-01 01:27:14 --> Helper loaded: url_helper
INFO - 2018-06-01 01:27:14 --> Helper loaded: form_helper
INFO - 2018-06-01 01:27:14 --> Helper loaded: date_helper
INFO - 2018-06-01 01:27:14 --> Helper loaded: util_helper
INFO - 2018-06-01 01:27:14 --> Helper loaded: text_helper
INFO - 2018-06-01 01:27:14 --> Helper loaded: string_helper
INFO - 2018-06-01 01:27:14 --> Database Driver Class Initialized
DEBUG - 2018-06-01 01:27:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-01 01:27:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-01 01:27:14 --> Email Class Initialized
INFO - 2018-06-01 01:27:14 --> Controller Class Initialized
DEBUG - 2018-06-01 01:27:14 --> Chapters MX_Controller Initialized
INFO - 2018-06-01 01:27:14 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-01 01:27:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Chapters_model.php
DEBUG - 2018-06-01 01:27:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-01 01:27:14 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-01 01:27:14 --> Login MX_Controller Initialized
DEBUG - 2018-06-01 01:27:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-01 01:27:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-01 01:27:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-01 01:27:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-01 01:27:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-01 01:27:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-01 01:27:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/chapters/chapters.php
INFO - 2018-06-01 01:27:14 --> Final output sent to browser
DEBUG - 2018-06-01 01:27:14 --> Total execution time: 0.5488
INFO - 2018-06-01 01:27:14 --> Config Class Initialized
INFO - 2018-06-01 01:27:14 --> Hooks Class Initialized
DEBUG - 2018-06-01 01:27:14 --> UTF-8 Support Enabled
INFO - 2018-06-01 01:27:14 --> Utf8 Class Initialized
INFO - 2018-06-01 01:27:14 --> URI Class Initialized
INFO - 2018-06-01 01:27:14 --> Router Class Initialized
INFO - 2018-06-01 01:27:14 --> Output Class Initialized
INFO - 2018-06-01 01:27:14 --> Security Class Initialized
DEBUG - 2018-06-01 01:27:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 01:27:14 --> Input Class Initialized
INFO - 2018-06-01 01:27:14 --> Language Class Initialized
INFO - 2018-06-01 01:27:14 --> Language Class Initialized
INFO - 2018-06-01 01:27:14 --> Config Class Initialized
INFO - 2018-06-01 01:27:14 --> Loader Class Initialized
DEBUG - 2018-06-01 01:27:14 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-01 01:27:14 --> Helper loaded: url_helper
INFO - 2018-06-01 01:27:14 --> Helper loaded: form_helper
INFO - 2018-06-01 01:27:14 --> Helper loaded: date_helper
INFO - 2018-06-01 01:27:14 --> Helper loaded: util_helper
INFO - 2018-06-01 01:27:14 --> Helper loaded: text_helper
INFO - 2018-06-01 01:27:14 --> Helper loaded: string_helper
INFO - 2018-06-01 01:27:15 --> Database Driver Class Initialized
DEBUG - 2018-06-01 01:27:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-01 01:27:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-01 01:27:15 --> Email Class Initialized
INFO - 2018-06-01 01:27:15 --> Controller Class Initialized
DEBUG - 2018-06-01 01:27:15 --> Chapters MX_Controller Initialized
INFO - 2018-06-01 01:27:15 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-01 01:27:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Chapters_model.php
DEBUG - 2018-06-01 01:27:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-01 01:27:15 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-01 01:27:15 --> Login MX_Controller Initialized
DEBUG - 2018-06-01 01:27:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-01 01:27:15 --> Final output sent to browser
DEBUG - 2018-06-01 01:27:15 --> Total execution time: 0.5620
INFO - 2018-06-01 01:27:17 --> Config Class Initialized
INFO - 2018-06-01 01:27:17 --> Hooks Class Initialized
DEBUG - 2018-06-01 01:27:17 --> UTF-8 Support Enabled
INFO - 2018-06-01 01:27:17 --> Utf8 Class Initialized
INFO - 2018-06-01 01:27:17 --> URI Class Initialized
INFO - 2018-06-01 01:27:17 --> Router Class Initialized
INFO - 2018-06-01 01:27:17 --> Output Class Initialized
INFO - 2018-06-01 01:27:17 --> Security Class Initialized
DEBUG - 2018-06-01 01:27:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 01:27:17 --> Input Class Initialized
INFO - 2018-06-01 01:27:17 --> Language Class Initialized
INFO - 2018-06-01 01:27:17 --> Language Class Initialized
INFO - 2018-06-01 01:27:17 --> Config Class Initialized
INFO - 2018-06-01 01:27:17 --> Loader Class Initialized
DEBUG - 2018-06-01 01:27:17 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-01 01:27:17 --> Helper loaded: url_helper
INFO - 2018-06-01 01:27:17 --> Helper loaded: form_helper
INFO - 2018-06-01 01:27:17 --> Helper loaded: date_helper
INFO - 2018-06-01 01:27:17 --> Helper loaded: util_helper
INFO - 2018-06-01 01:27:17 --> Helper loaded: text_helper
INFO - 2018-06-01 01:27:17 --> Helper loaded: string_helper
INFO - 2018-06-01 01:27:17 --> Database Driver Class Initialized
DEBUG - 2018-06-01 01:27:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-01 01:27:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-01 01:27:17 --> Email Class Initialized
INFO - 2018-06-01 01:27:17 --> Controller Class Initialized
DEBUG - 2018-06-01 01:27:17 --> Home MX_Controller Initialized
DEBUG - 2018-06-01 01:27:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-01 01:27:17 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-01 01:27:17 --> Login MX_Controller Initialized
INFO - 2018-06-01 01:27:17 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-01 01:27:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-01 01:27:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-01 01:27:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-01 01:27:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-01 01:27:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-01 01:27:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-01 01:27:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-01 01:27:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-06-01 01:27:17 --> Final output sent to browser
DEBUG - 2018-06-01 01:27:17 --> Total execution time: 0.5135
INFO - 2018-06-01 01:27:18 --> Config Class Initialized
INFO - 2018-06-01 01:27:18 --> Config Class Initialized
INFO - 2018-06-01 01:27:18 --> Hooks Class Initialized
INFO - 2018-06-01 01:27:18 --> Hooks Class Initialized
DEBUG - 2018-06-01 01:27:18 --> UTF-8 Support Enabled
DEBUG - 2018-06-01 01:27:18 --> UTF-8 Support Enabled
INFO - 2018-06-01 01:27:18 --> Utf8 Class Initialized
INFO - 2018-06-01 01:27:18 --> Utf8 Class Initialized
INFO - 2018-06-01 01:27:18 --> URI Class Initialized
INFO - 2018-06-01 01:27:18 --> URI Class Initialized
INFO - 2018-06-01 01:27:18 --> Router Class Initialized
INFO - 2018-06-01 01:27:18 --> Output Class Initialized
INFO - 2018-06-01 01:27:18 --> Router Class Initialized
INFO - 2018-06-01 01:27:18 --> Security Class Initialized
DEBUG - 2018-06-01 01:27:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 01:27:18 --> Input Class Initialized
INFO - 2018-06-01 01:27:18 --> Language Class Initialized
ERROR - 2018-06-01 01:27:18 --> 404 Page Not Found: /index
INFO - 2018-06-01 01:27:18 --> Output Class Initialized
INFO - 2018-06-01 01:27:18 --> Config Class Initialized
INFO - 2018-06-01 01:27:18 --> Security Class Initialized
DEBUG - 2018-06-01 01:27:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 01:27:18 --> Input Class Initialized
INFO - 2018-06-01 01:27:18 --> Language Class Initialized
ERROR - 2018-06-01 01:27:18 --> 404 Page Not Found: /index
INFO - 2018-06-01 01:27:18 --> Hooks Class Initialized
DEBUG - 2018-06-01 01:27:18 --> UTF-8 Support Enabled
INFO - 2018-06-01 01:27:18 --> Utf8 Class Initialized
INFO - 2018-06-01 01:27:18 --> URI Class Initialized
INFO - 2018-06-01 01:27:18 --> Router Class Initialized
INFO - 2018-06-01 01:27:18 --> Output Class Initialized
INFO - 2018-06-01 01:27:18 --> Security Class Initialized
DEBUG - 2018-06-01 01:27:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 01:27:18 --> Input Class Initialized
INFO - 2018-06-01 01:27:18 --> Language Class Initialized
ERROR - 2018-06-01 01:27:18 --> 404 Page Not Found: /index
INFO - 2018-06-01 01:27:18 --> Config Class Initialized
INFO - 2018-06-01 01:27:18 --> Hooks Class Initialized
DEBUG - 2018-06-01 01:27:18 --> UTF-8 Support Enabled
INFO - 2018-06-01 01:27:18 --> Utf8 Class Initialized
INFO - 2018-06-01 01:27:18 --> URI Class Initialized
INFO - 2018-06-01 01:27:18 --> Router Class Initialized
INFO - 2018-06-01 01:27:18 --> Output Class Initialized
INFO - 2018-06-01 01:27:18 --> Security Class Initialized
DEBUG - 2018-06-01 01:27:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 01:27:18 --> Input Class Initialized
INFO - 2018-06-01 01:27:18 --> Language Class Initialized
ERROR - 2018-06-01 01:27:18 --> 404 Page Not Found: /index
INFO - 2018-06-01 01:27:23 --> Config Class Initialized
INFO - 2018-06-01 01:27:23 --> Hooks Class Initialized
DEBUG - 2018-06-01 01:27:23 --> UTF-8 Support Enabled
INFO - 2018-06-01 01:27:23 --> Utf8 Class Initialized
INFO - 2018-06-01 01:27:23 --> URI Class Initialized
INFO - 2018-06-01 01:27:23 --> Router Class Initialized
INFO - 2018-06-01 01:27:23 --> Output Class Initialized
INFO - 2018-06-01 01:27:23 --> Security Class Initialized
DEBUG - 2018-06-01 01:27:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 01:27:23 --> Input Class Initialized
INFO - 2018-06-01 01:27:23 --> Language Class Initialized
INFO - 2018-06-01 01:27:23 --> Language Class Initialized
INFO - 2018-06-01 01:27:23 --> Config Class Initialized
INFO - 2018-06-01 01:27:23 --> Loader Class Initialized
DEBUG - 2018-06-01 01:27:23 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-01 01:27:23 --> Helper loaded: url_helper
INFO - 2018-06-01 01:27:23 --> Helper loaded: form_helper
INFO - 2018-06-01 01:27:23 --> Helper loaded: date_helper
INFO - 2018-06-01 01:27:23 --> Helper loaded: util_helper
INFO - 2018-06-01 01:27:23 --> Helper loaded: text_helper
INFO - 2018-06-01 01:27:23 --> Helper loaded: string_helper
INFO - 2018-06-01 01:27:23 --> Database Driver Class Initialized
DEBUG - 2018-06-01 01:27:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-01 01:27:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-01 01:27:23 --> Email Class Initialized
INFO - 2018-06-01 01:27:23 --> Controller Class Initialized
DEBUG - 2018-06-01 01:27:23 --> Home MX_Controller Initialized
DEBUG - 2018-06-01 01:27:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-01 01:27:23 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-01 01:27:23 --> Login MX_Controller Initialized
INFO - 2018-06-01 01:27:23 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-01 01:27:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-01 01:27:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-01 01:27:24 --> Config Class Initialized
INFO - 2018-06-01 01:27:24 --> Hooks Class Initialized
DEBUG - 2018-06-01 01:27:24 --> UTF-8 Support Enabled
INFO - 2018-06-01 01:27:24 --> Utf8 Class Initialized
INFO - 2018-06-01 01:27:24 --> URI Class Initialized
INFO - 2018-06-01 01:27:24 --> Router Class Initialized
INFO - 2018-06-01 01:27:24 --> Output Class Initialized
INFO - 2018-06-01 01:27:24 --> Security Class Initialized
DEBUG - 2018-06-01 01:27:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 01:27:24 --> Input Class Initialized
INFO - 2018-06-01 01:27:24 --> Language Class Initialized
INFO - 2018-06-01 01:27:24 --> Language Class Initialized
INFO - 2018-06-01 01:27:24 --> Config Class Initialized
INFO - 2018-06-01 01:27:24 --> Loader Class Initialized
DEBUG - 2018-06-01 01:27:24 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-01 01:27:24 --> Helper loaded: url_helper
INFO - 2018-06-01 01:27:24 --> Helper loaded: form_helper
INFO - 2018-06-01 01:27:24 --> Helper loaded: date_helper
INFO - 2018-06-01 01:27:24 --> Helper loaded: util_helper
INFO - 2018-06-01 01:27:24 --> Helper loaded: text_helper
INFO - 2018-06-01 01:27:24 --> Helper loaded: string_helper
INFO - 2018-06-01 01:27:24 --> Database Driver Class Initialized
DEBUG - 2018-06-01 01:27:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-01 01:27:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-01 01:27:24 --> Email Class Initialized
INFO - 2018-06-01 01:27:24 --> Controller Class Initialized
DEBUG - 2018-06-01 01:27:24 --> Home MX_Controller Initialized
DEBUG - 2018-06-01 01:27:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-01 01:27:24 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-01 01:27:24 --> Login MX_Controller Initialized
INFO - 2018-06-01 01:27:24 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-01 01:27:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-01 01:27:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-01 01:27:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-01 01:27:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-01 01:27:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-01 01:27:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-01 01:27:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-01 01:27:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-06-01 01:27:24 --> Final output sent to browser
DEBUG - 2018-06-01 01:27:24 --> Total execution time: 0.4870
INFO - 2018-06-01 01:27:24 --> Config Class Initialized
INFO - 2018-06-01 01:27:24 --> Hooks Class Initialized
DEBUG - 2018-06-01 01:27:24 --> UTF-8 Support Enabled
INFO - 2018-06-01 01:27:24 --> Utf8 Class Initialized
INFO - 2018-06-01 01:27:24 --> URI Class Initialized
INFO - 2018-06-01 01:27:24 --> Router Class Initialized
INFO - 2018-06-01 01:27:24 --> Output Class Initialized
INFO - 2018-06-01 01:27:24 --> Security Class Initialized
DEBUG - 2018-06-01 01:27:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 01:27:24 --> Input Class Initialized
INFO - 2018-06-01 01:27:24 --> Language Class Initialized
ERROR - 2018-06-01 01:27:24 --> 404 Page Not Found: /index
INFO - 2018-06-01 01:27:24 --> Config Class Initialized
INFO - 2018-06-01 01:27:24 --> Hooks Class Initialized
DEBUG - 2018-06-01 01:27:25 --> UTF-8 Support Enabled
INFO - 2018-06-01 01:27:25 --> Utf8 Class Initialized
INFO - 2018-06-01 01:27:25 --> URI Class Initialized
INFO - 2018-06-01 01:27:25 --> Router Class Initialized
INFO - 2018-06-01 01:27:25 --> Output Class Initialized
INFO - 2018-06-01 01:27:25 --> Security Class Initialized
DEBUG - 2018-06-01 01:27:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 01:27:25 --> Input Class Initialized
INFO - 2018-06-01 01:27:25 --> Language Class Initialized
ERROR - 2018-06-01 01:27:25 --> 404 Page Not Found: /index
INFO - 2018-06-01 01:27:25 --> Config Class Initialized
INFO - 2018-06-01 01:27:25 --> Hooks Class Initialized
DEBUG - 2018-06-01 01:27:25 --> UTF-8 Support Enabled
INFO - 2018-06-01 01:27:25 --> Utf8 Class Initialized
INFO - 2018-06-01 01:27:25 --> URI Class Initialized
INFO - 2018-06-01 01:27:25 --> Router Class Initialized
INFO - 2018-06-01 01:27:25 --> Output Class Initialized
INFO - 2018-06-01 01:27:25 --> Security Class Initialized
DEBUG - 2018-06-01 01:27:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 01:27:25 --> Input Class Initialized
INFO - 2018-06-01 01:27:25 --> Language Class Initialized
ERROR - 2018-06-01 01:27:25 --> 404 Page Not Found: /index
INFO - 2018-06-01 01:27:28 --> Config Class Initialized
INFO - 2018-06-01 01:27:28 --> Hooks Class Initialized
DEBUG - 2018-06-01 01:27:28 --> UTF-8 Support Enabled
INFO - 2018-06-01 01:27:28 --> Utf8 Class Initialized
INFO - 2018-06-01 01:27:28 --> URI Class Initialized
INFO - 2018-06-01 01:27:28 --> Router Class Initialized
INFO - 2018-06-01 01:27:28 --> Output Class Initialized
INFO - 2018-06-01 01:27:28 --> Security Class Initialized
DEBUG - 2018-06-01 01:27:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 01:27:28 --> Input Class Initialized
INFO - 2018-06-01 01:27:28 --> Language Class Initialized
INFO - 2018-06-01 01:27:28 --> Language Class Initialized
INFO - 2018-06-01 01:27:28 --> Config Class Initialized
INFO - 2018-06-01 01:27:28 --> Loader Class Initialized
DEBUG - 2018-06-01 01:27:28 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-01 01:27:28 --> Helper loaded: url_helper
INFO - 2018-06-01 01:27:28 --> Helper loaded: form_helper
INFO - 2018-06-01 01:27:28 --> Helper loaded: date_helper
INFO - 2018-06-01 01:27:28 --> Helper loaded: util_helper
INFO - 2018-06-01 01:27:28 --> Helper loaded: text_helper
INFO - 2018-06-01 01:27:28 --> Helper loaded: string_helper
INFO - 2018-06-01 01:27:29 --> Database Driver Class Initialized
DEBUG - 2018-06-01 01:27:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-01 01:27:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-01 01:27:29 --> Email Class Initialized
INFO - 2018-06-01 01:27:29 --> Controller Class Initialized
DEBUG - 2018-06-01 01:27:29 --> Home MX_Controller Initialized
DEBUG - 2018-06-01 01:27:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-01 01:27:29 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-01 01:27:29 --> Login MX_Controller Initialized
INFO - 2018-06-01 01:27:29 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-01 01:27:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-01 01:27:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-01 01:27:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-01 01:27:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-01 01:27:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-01 01:27:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-01 01:27:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-01 01:27:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-06-01 01:27:29 --> Final output sent to browser
DEBUG - 2018-06-01 01:27:29 --> Total execution time: 0.5254
INFO - 2018-06-01 01:27:29 --> Config Class Initialized
INFO - 2018-06-01 01:27:29 --> Config Class Initialized
INFO - 2018-06-01 01:27:29 --> Hooks Class Initialized
INFO - 2018-06-01 01:27:29 --> Hooks Class Initialized
DEBUG - 2018-06-01 01:27:29 --> UTF-8 Support Enabled
DEBUG - 2018-06-01 01:27:29 --> UTF-8 Support Enabled
INFO - 2018-06-01 01:27:29 --> Utf8 Class Initialized
INFO - 2018-06-01 01:27:29 --> Utf8 Class Initialized
INFO - 2018-06-01 01:27:29 --> URI Class Initialized
INFO - 2018-06-01 01:27:29 --> Router Class Initialized
INFO - 2018-06-01 01:27:29 --> Output Class Initialized
INFO - 2018-06-01 01:27:29 --> URI Class Initialized
INFO - 2018-06-01 01:27:29 --> Router Class Initialized
INFO - 2018-06-01 01:27:29 --> Security Class Initialized
DEBUG - 2018-06-01 01:27:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 01:27:29 --> Output Class Initialized
INFO - 2018-06-01 01:27:29 --> Input Class Initialized
INFO - 2018-06-01 01:27:29 --> Security Class Initialized
DEBUG - 2018-06-01 01:27:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 01:27:29 --> Language Class Initialized
ERROR - 2018-06-01 01:27:29 --> 404 Page Not Found: /index
INFO - 2018-06-01 01:27:29 --> Input Class Initialized
INFO - 2018-06-01 01:27:29 --> Language Class Initialized
INFO - 2018-06-01 01:27:29 --> Config Class Initialized
INFO - 2018-06-01 01:27:29 --> Hooks Class Initialized
ERROR - 2018-06-01 01:27:29 --> 404 Page Not Found: /index
DEBUG - 2018-06-01 01:27:29 --> UTF-8 Support Enabled
INFO - 2018-06-01 01:27:29 --> Utf8 Class Initialized
INFO - 2018-06-01 01:27:29 --> URI Class Initialized
INFO - 2018-06-01 01:27:29 --> Router Class Initialized
INFO - 2018-06-01 01:27:29 --> Output Class Initialized
INFO - 2018-06-01 01:27:29 --> Security Class Initialized
DEBUG - 2018-06-01 01:27:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 01:27:29 --> Input Class Initialized
INFO - 2018-06-01 01:27:29 --> Language Class Initialized
ERROR - 2018-06-01 01:27:29 --> 404 Page Not Found: /index
INFO - 2018-06-01 01:27:29 --> Config Class Initialized
INFO - 2018-06-01 01:27:29 --> Hooks Class Initialized
DEBUG - 2018-06-01 01:27:29 --> UTF-8 Support Enabled
INFO - 2018-06-01 01:27:29 --> Utf8 Class Initialized
INFO - 2018-06-01 01:27:29 --> URI Class Initialized
INFO - 2018-06-01 01:27:29 --> Router Class Initialized
INFO - 2018-06-01 01:27:29 --> Output Class Initialized
INFO - 2018-06-01 01:27:30 --> Security Class Initialized
DEBUG - 2018-06-01 01:27:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 01:27:30 --> Input Class Initialized
INFO - 2018-06-01 01:27:30 --> Language Class Initialized
ERROR - 2018-06-01 01:27:30 --> 404 Page Not Found: /index
INFO - 2018-06-01 01:27:35 --> Config Class Initialized
INFO - 2018-06-01 01:27:35 --> Hooks Class Initialized
DEBUG - 2018-06-01 01:27:35 --> UTF-8 Support Enabled
INFO - 2018-06-01 01:27:35 --> Utf8 Class Initialized
INFO - 2018-06-01 01:27:35 --> URI Class Initialized
INFO - 2018-06-01 01:27:35 --> Router Class Initialized
INFO - 2018-06-01 01:27:35 --> Output Class Initialized
INFO - 2018-06-01 01:27:35 --> Security Class Initialized
DEBUG - 2018-06-01 01:27:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 01:27:35 --> Input Class Initialized
INFO - 2018-06-01 01:27:35 --> Language Class Initialized
INFO - 2018-06-01 01:27:35 --> Language Class Initialized
INFO - 2018-06-01 01:27:35 --> Config Class Initialized
INFO - 2018-06-01 01:27:35 --> Loader Class Initialized
DEBUG - 2018-06-01 01:27:35 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-01 01:27:35 --> Helper loaded: url_helper
INFO - 2018-06-01 01:27:35 --> Helper loaded: form_helper
INFO - 2018-06-01 01:27:35 --> Helper loaded: date_helper
INFO - 2018-06-01 01:27:35 --> Helper loaded: util_helper
INFO - 2018-06-01 01:27:35 --> Helper loaded: text_helper
INFO - 2018-06-01 01:27:36 --> Helper loaded: string_helper
INFO - 2018-06-01 01:27:36 --> Database Driver Class Initialized
DEBUG - 2018-06-01 01:27:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-01 01:27:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-01 01:27:36 --> Email Class Initialized
INFO - 2018-06-01 01:27:36 --> Controller Class Initialized
DEBUG - 2018-06-01 01:27:36 --> Admin MX_Controller Initialized
INFO - 2018-06-01 01:27:36 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-01 01:27:36 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-01 01:27:36 --> Login MX_Controller Initialized
DEBUG - 2018-06-01 01:27:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-01 01:27:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-01 01:27:36 --> Final output sent to browser
DEBUG - 2018-06-01 01:27:36 --> Total execution time: 0.6250
INFO - 2018-06-01 01:27:37 --> Config Class Initialized
INFO - 2018-06-01 01:27:37 --> Hooks Class Initialized
DEBUG - 2018-06-01 01:27:37 --> UTF-8 Support Enabled
INFO - 2018-06-01 01:27:37 --> Utf8 Class Initialized
INFO - 2018-06-01 01:27:37 --> URI Class Initialized
INFO - 2018-06-01 01:27:37 --> Router Class Initialized
INFO - 2018-06-01 01:27:37 --> Output Class Initialized
INFO - 2018-06-01 01:27:37 --> Security Class Initialized
DEBUG - 2018-06-01 01:27:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 01:27:37 --> Input Class Initialized
INFO - 2018-06-01 01:27:37 --> Language Class Initialized
INFO - 2018-06-01 01:27:37 --> Language Class Initialized
INFO - 2018-06-01 01:27:37 --> Config Class Initialized
INFO - 2018-06-01 01:27:37 --> Loader Class Initialized
DEBUG - 2018-06-01 01:27:37 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-01 01:27:37 --> Helper loaded: url_helper
INFO - 2018-06-01 01:27:37 --> Helper loaded: form_helper
INFO - 2018-06-01 01:27:37 --> Helper loaded: date_helper
INFO - 2018-06-01 01:27:37 --> Helper loaded: util_helper
INFO - 2018-06-01 01:27:37 --> Helper loaded: text_helper
INFO - 2018-06-01 01:27:37 --> Helper loaded: string_helper
INFO - 2018-06-01 01:27:37 --> Database Driver Class Initialized
DEBUG - 2018-06-01 01:27:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-01 01:27:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-01 01:27:37 --> Email Class Initialized
INFO - 2018-06-01 01:27:37 --> Controller Class Initialized
DEBUG - 2018-06-01 01:27:37 --> Chapters MX_Controller Initialized
INFO - 2018-06-01 01:27:37 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-01 01:27:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Chapters_model.php
DEBUG - 2018-06-01 01:27:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-01 01:27:37 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-01 01:27:37 --> Login MX_Controller Initialized
DEBUG - 2018-06-01 01:27:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-01 01:27:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-01 01:27:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-01 01:27:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-01 01:27:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-01 01:27:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-01 01:27:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/chapters/chapters.php
INFO - 2018-06-01 01:27:38 --> Final output sent to browser
DEBUG - 2018-06-01 01:27:38 --> Total execution time: 0.6795
INFO - 2018-06-01 01:27:38 --> Config Class Initialized
INFO - 2018-06-01 01:27:38 --> Hooks Class Initialized
DEBUG - 2018-06-01 01:27:38 --> UTF-8 Support Enabled
INFO - 2018-06-01 01:27:38 --> Utf8 Class Initialized
INFO - 2018-06-01 01:27:38 --> URI Class Initialized
INFO - 2018-06-01 01:27:38 --> Router Class Initialized
INFO - 2018-06-01 01:27:38 --> Output Class Initialized
INFO - 2018-06-01 01:27:38 --> Security Class Initialized
DEBUG - 2018-06-01 01:27:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 01:27:38 --> Input Class Initialized
INFO - 2018-06-01 01:27:38 --> Language Class Initialized
INFO - 2018-06-01 01:27:38 --> Language Class Initialized
INFO - 2018-06-01 01:27:38 --> Config Class Initialized
INFO - 2018-06-01 01:27:38 --> Loader Class Initialized
DEBUG - 2018-06-01 01:27:38 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-01 01:27:38 --> Helper loaded: url_helper
INFO - 2018-06-01 01:27:38 --> Helper loaded: form_helper
INFO - 2018-06-01 01:27:38 --> Helper loaded: date_helper
INFO - 2018-06-01 01:27:38 --> Helper loaded: util_helper
INFO - 2018-06-01 01:27:38 --> Helper loaded: text_helper
INFO - 2018-06-01 01:27:38 --> Helper loaded: string_helper
INFO - 2018-06-01 01:27:38 --> Database Driver Class Initialized
DEBUG - 2018-06-01 01:27:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-01 01:27:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-01 01:27:38 --> Email Class Initialized
INFO - 2018-06-01 01:27:38 --> Controller Class Initialized
DEBUG - 2018-06-01 01:27:38 --> Chapters MX_Controller Initialized
INFO - 2018-06-01 01:27:38 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-01 01:27:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Chapters_model.php
DEBUG - 2018-06-01 01:27:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-01 01:27:38 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-01 01:27:38 --> Login MX_Controller Initialized
DEBUG - 2018-06-01 01:27:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-01 01:27:39 --> Final output sent to browser
DEBUG - 2018-06-01 01:27:39 --> Total execution time: 0.6554
INFO - 2018-06-01 01:27:43 --> Config Class Initialized
INFO - 2018-06-01 01:27:43 --> Hooks Class Initialized
DEBUG - 2018-06-01 01:27:43 --> UTF-8 Support Enabled
INFO - 2018-06-01 01:27:43 --> Utf8 Class Initialized
INFO - 2018-06-01 01:27:43 --> URI Class Initialized
INFO - 2018-06-01 01:27:43 --> Router Class Initialized
INFO - 2018-06-01 01:27:43 --> Output Class Initialized
INFO - 2018-06-01 01:27:43 --> Security Class Initialized
DEBUG - 2018-06-01 01:27:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 01:27:44 --> Input Class Initialized
INFO - 2018-06-01 01:27:44 --> Language Class Initialized
INFO - 2018-06-01 01:27:44 --> Language Class Initialized
INFO - 2018-06-01 01:27:44 --> Config Class Initialized
INFO - 2018-06-01 01:27:44 --> Loader Class Initialized
DEBUG - 2018-06-01 01:27:44 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-01 01:27:44 --> Helper loaded: url_helper
INFO - 2018-06-01 01:27:44 --> Helper loaded: form_helper
INFO - 2018-06-01 01:27:44 --> Helper loaded: date_helper
INFO - 2018-06-01 01:27:44 --> Helper loaded: util_helper
INFO - 2018-06-01 01:27:44 --> Helper loaded: text_helper
INFO - 2018-06-01 01:27:44 --> Helper loaded: string_helper
INFO - 2018-06-01 01:27:44 --> Database Driver Class Initialized
DEBUG - 2018-06-01 01:27:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-01 01:27:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-01 01:27:44 --> Email Class Initialized
INFO - 2018-06-01 01:27:44 --> Controller Class Initialized
DEBUG - 2018-06-01 01:27:44 --> Home MX_Controller Initialized
DEBUG - 2018-06-01 01:27:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-01 01:27:44 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-01 01:27:44 --> Login MX_Controller Initialized
INFO - 2018-06-01 01:27:44 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-01 01:27:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-01 01:27:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-01 01:27:44 --> Config Class Initialized
INFO - 2018-06-01 01:27:44 --> Hooks Class Initialized
DEBUG - 2018-06-01 01:27:44 --> UTF-8 Support Enabled
INFO - 2018-06-01 01:27:44 --> Utf8 Class Initialized
INFO - 2018-06-01 01:27:44 --> URI Class Initialized
INFO - 2018-06-01 01:27:44 --> Router Class Initialized
INFO - 2018-06-01 01:27:44 --> Output Class Initialized
INFO - 2018-06-01 01:27:44 --> Security Class Initialized
DEBUG - 2018-06-01 01:27:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 01:27:44 --> Input Class Initialized
INFO - 2018-06-01 01:27:44 --> Language Class Initialized
INFO - 2018-06-01 01:27:44 --> Language Class Initialized
INFO - 2018-06-01 01:27:44 --> Config Class Initialized
INFO - 2018-06-01 01:27:44 --> Loader Class Initialized
DEBUG - 2018-06-01 01:27:44 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-01 01:27:44 --> Helper loaded: url_helper
INFO - 2018-06-01 01:27:44 --> Helper loaded: form_helper
INFO - 2018-06-01 01:27:44 --> Helper loaded: date_helper
INFO - 2018-06-01 01:27:44 --> Helper loaded: util_helper
INFO - 2018-06-01 01:27:44 --> Helper loaded: text_helper
INFO - 2018-06-01 01:27:44 --> Helper loaded: string_helper
INFO - 2018-06-01 01:27:44 --> Database Driver Class Initialized
DEBUG - 2018-06-01 01:27:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-01 01:27:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-01 01:27:44 --> Email Class Initialized
INFO - 2018-06-01 01:27:44 --> Controller Class Initialized
DEBUG - 2018-06-01 01:27:44 --> Home MX_Controller Initialized
DEBUG - 2018-06-01 01:27:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-01 01:27:44 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-01 01:27:44 --> Login MX_Controller Initialized
INFO - 2018-06-01 01:27:44 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-01 01:27:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-01 01:27:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-01 01:27:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-01 01:27:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-01 01:27:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-01 01:27:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-01 01:27:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-01 01:27:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-06-01 01:27:44 --> Final output sent to browser
DEBUG - 2018-06-01 01:27:44 --> Total execution time: 0.5112
INFO - 2018-06-01 01:27:45 --> Config Class Initialized
INFO - 2018-06-01 01:27:45 --> Hooks Class Initialized
DEBUG - 2018-06-01 01:27:45 --> UTF-8 Support Enabled
INFO - 2018-06-01 01:27:45 --> Utf8 Class Initialized
INFO - 2018-06-01 01:27:45 --> URI Class Initialized
INFO - 2018-06-01 01:27:45 --> Router Class Initialized
INFO - 2018-06-01 01:27:45 --> Output Class Initialized
INFO - 2018-06-01 01:27:45 --> Security Class Initialized
DEBUG - 2018-06-01 01:27:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 01:27:45 --> Input Class Initialized
INFO - 2018-06-01 01:27:45 --> Language Class Initialized
ERROR - 2018-06-01 01:27:45 --> 404 Page Not Found: /index
INFO - 2018-06-01 01:27:45 --> Config Class Initialized
INFO - 2018-06-01 01:27:45 --> Hooks Class Initialized
DEBUG - 2018-06-01 01:27:45 --> UTF-8 Support Enabled
INFO - 2018-06-01 01:27:45 --> Utf8 Class Initialized
INFO - 2018-06-01 01:27:45 --> URI Class Initialized
INFO - 2018-06-01 01:27:45 --> Router Class Initialized
INFO - 2018-06-01 01:27:45 --> Output Class Initialized
INFO - 2018-06-01 01:27:45 --> Security Class Initialized
DEBUG - 2018-06-01 01:27:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 01:27:45 --> Input Class Initialized
INFO - 2018-06-01 01:27:45 --> Language Class Initialized
ERROR - 2018-06-01 01:27:45 --> 404 Page Not Found: /index
INFO - 2018-06-01 01:27:45 --> Config Class Initialized
INFO - 2018-06-01 01:27:45 --> Hooks Class Initialized
DEBUG - 2018-06-01 01:27:45 --> UTF-8 Support Enabled
INFO - 2018-06-01 01:27:45 --> Utf8 Class Initialized
INFO - 2018-06-01 01:27:45 --> URI Class Initialized
INFO - 2018-06-01 01:27:45 --> Router Class Initialized
INFO - 2018-06-01 01:27:45 --> Output Class Initialized
INFO - 2018-06-01 01:27:45 --> Security Class Initialized
DEBUG - 2018-06-01 01:27:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 01:27:45 --> Input Class Initialized
INFO - 2018-06-01 01:27:45 --> Language Class Initialized
ERROR - 2018-06-01 01:27:45 --> 404 Page Not Found: /index
INFO - 2018-06-01 01:27:50 --> Config Class Initialized
INFO - 2018-06-01 01:27:50 --> Hooks Class Initialized
DEBUG - 2018-06-01 01:27:50 --> UTF-8 Support Enabled
INFO - 2018-06-01 01:27:50 --> Utf8 Class Initialized
INFO - 2018-06-01 01:27:50 --> URI Class Initialized
INFO - 2018-06-01 01:27:50 --> Router Class Initialized
INFO - 2018-06-01 01:27:50 --> Output Class Initialized
INFO - 2018-06-01 01:27:50 --> Security Class Initialized
DEBUG - 2018-06-01 01:27:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 01:27:50 --> Input Class Initialized
INFO - 2018-06-01 01:27:50 --> Language Class Initialized
INFO - 2018-06-01 01:27:50 --> Language Class Initialized
INFO - 2018-06-01 01:27:50 --> Config Class Initialized
INFO - 2018-06-01 01:27:50 --> Loader Class Initialized
DEBUG - 2018-06-01 01:27:50 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-01 01:27:50 --> Helper loaded: url_helper
INFO - 2018-06-01 01:27:50 --> Helper loaded: form_helper
INFO - 2018-06-01 01:27:50 --> Helper loaded: date_helper
INFO - 2018-06-01 01:27:50 --> Helper loaded: util_helper
INFO - 2018-06-01 01:27:50 --> Helper loaded: text_helper
INFO - 2018-06-01 01:27:50 --> Helper loaded: string_helper
INFO - 2018-06-01 01:27:50 --> Database Driver Class Initialized
DEBUG - 2018-06-01 01:27:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-01 01:27:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-01 01:27:50 --> Email Class Initialized
INFO - 2018-06-01 01:27:50 --> Controller Class Initialized
DEBUG - 2018-06-01 01:27:50 --> Programs MX_Controller Initialized
INFO - 2018-06-01 01:27:50 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-01 01:27:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-06-01 01:27:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-01 01:27:50 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-01 01:27:51 --> Login MX_Controller Initialized
DEBUG - 2018-06-01 01:27:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-01 01:27:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-01 01:27:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-01 01:27:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-01 01:27:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-01 01:27:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-01 01:27:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/programs.php
INFO - 2018-06-01 01:27:51 --> Final output sent to browser
DEBUG - 2018-06-01 01:27:51 --> Total execution time: 0.5565
INFO - 2018-06-01 01:27:51 --> Config Class Initialized
INFO - 2018-06-01 01:27:51 --> Hooks Class Initialized
DEBUG - 2018-06-01 01:27:51 --> UTF-8 Support Enabled
INFO - 2018-06-01 01:27:51 --> Utf8 Class Initialized
INFO - 2018-06-01 01:27:51 --> URI Class Initialized
INFO - 2018-06-01 01:27:51 --> Router Class Initialized
INFO - 2018-06-01 01:27:51 --> Output Class Initialized
INFO - 2018-06-01 01:27:51 --> Security Class Initialized
DEBUG - 2018-06-01 01:27:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 01:27:51 --> Input Class Initialized
INFO - 2018-06-01 01:27:51 --> Language Class Initialized
INFO - 2018-06-01 01:27:51 --> Language Class Initialized
INFO - 2018-06-01 01:27:51 --> Config Class Initialized
INFO - 2018-06-01 01:27:51 --> Loader Class Initialized
DEBUG - 2018-06-01 01:27:51 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-01 01:27:51 --> Helper loaded: url_helper
INFO - 2018-06-01 01:27:51 --> Helper loaded: form_helper
INFO - 2018-06-01 01:27:51 --> Helper loaded: date_helper
INFO - 2018-06-01 01:27:51 --> Helper loaded: util_helper
INFO - 2018-06-01 01:27:51 --> Helper loaded: text_helper
INFO - 2018-06-01 01:27:51 --> Helper loaded: string_helper
INFO - 2018-06-01 01:27:51 --> Database Driver Class Initialized
DEBUG - 2018-06-01 01:27:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-01 01:27:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-01 01:27:51 --> Email Class Initialized
INFO - 2018-06-01 01:27:51 --> Controller Class Initialized
DEBUG - 2018-06-01 01:27:51 --> Programs MX_Controller Initialized
INFO - 2018-06-01 01:27:51 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-01 01:27:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-06-01 01:27:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-01 01:27:52 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-01 01:27:52 --> Login MX_Controller Initialized
DEBUG - 2018-06-01 01:27:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-01 01:27:52 --> Final output sent to browser
DEBUG - 2018-06-01 01:27:52 --> Total execution time: 0.6136
INFO - 2018-06-01 01:27:53 --> Config Class Initialized
INFO - 2018-06-01 01:27:53 --> Hooks Class Initialized
DEBUG - 2018-06-01 01:27:53 --> UTF-8 Support Enabled
INFO - 2018-06-01 01:27:53 --> Utf8 Class Initialized
INFO - 2018-06-01 01:27:53 --> URI Class Initialized
INFO - 2018-06-01 01:27:53 --> Router Class Initialized
INFO - 2018-06-01 01:27:53 --> Output Class Initialized
INFO - 2018-06-01 01:27:53 --> Security Class Initialized
DEBUG - 2018-06-01 01:27:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 01:27:54 --> Input Class Initialized
INFO - 2018-06-01 01:27:54 --> Language Class Initialized
INFO - 2018-06-01 01:27:54 --> Language Class Initialized
INFO - 2018-06-01 01:27:54 --> Config Class Initialized
INFO - 2018-06-01 01:27:54 --> Loader Class Initialized
DEBUG - 2018-06-01 01:27:54 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-01 01:27:54 --> Helper loaded: url_helper
INFO - 2018-06-01 01:27:54 --> Helper loaded: form_helper
INFO - 2018-06-01 01:27:54 --> Helper loaded: date_helper
INFO - 2018-06-01 01:27:54 --> Helper loaded: util_helper
INFO - 2018-06-01 01:27:54 --> Helper loaded: text_helper
INFO - 2018-06-01 01:27:54 --> Helper loaded: string_helper
INFO - 2018-06-01 01:27:54 --> Database Driver Class Initialized
DEBUG - 2018-06-01 01:27:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-01 01:27:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-01 01:27:54 --> Email Class Initialized
INFO - 2018-06-01 01:27:54 --> Controller Class Initialized
DEBUG - 2018-06-01 01:27:54 --> Admin MX_Controller Initialized
INFO - 2018-06-01 01:27:54 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-01 01:27:54 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-01 01:27:54 --> Login MX_Controller Initialized
DEBUG - 2018-06-01 01:27:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-01 01:27:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-01 01:27:54 --> Final output sent to browser
DEBUG - 2018-06-01 01:27:54 --> Total execution time: 0.5860
INFO - 2018-06-01 01:28:02 --> Config Class Initialized
INFO - 2018-06-01 01:28:02 --> Hooks Class Initialized
DEBUG - 2018-06-01 01:28:02 --> UTF-8 Support Enabled
INFO - 2018-06-01 01:28:02 --> Utf8 Class Initialized
INFO - 2018-06-01 01:28:02 --> URI Class Initialized
INFO - 2018-06-01 01:28:02 --> Router Class Initialized
INFO - 2018-06-01 01:28:02 --> Output Class Initialized
INFO - 2018-06-01 01:28:02 --> Security Class Initialized
DEBUG - 2018-06-01 01:28:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 01:28:03 --> Input Class Initialized
INFO - 2018-06-01 01:28:03 --> Language Class Initialized
INFO - 2018-06-01 01:28:03 --> Language Class Initialized
INFO - 2018-06-01 01:28:03 --> Config Class Initialized
INFO - 2018-06-01 01:28:03 --> Loader Class Initialized
DEBUG - 2018-06-01 01:28:03 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-01 01:28:03 --> Helper loaded: url_helper
INFO - 2018-06-01 01:28:03 --> Helper loaded: form_helper
INFO - 2018-06-01 01:28:03 --> Helper loaded: date_helper
INFO - 2018-06-01 01:28:03 --> Helper loaded: util_helper
INFO - 2018-06-01 01:28:03 --> Helper loaded: text_helper
INFO - 2018-06-01 01:28:03 --> Helper loaded: string_helper
INFO - 2018-06-01 01:28:03 --> Database Driver Class Initialized
DEBUG - 2018-06-01 01:28:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-01 01:28:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-01 01:28:03 --> Email Class Initialized
INFO - 2018-06-01 01:28:03 --> Controller Class Initialized
DEBUG - 2018-06-01 01:28:03 --> Home MX_Controller Initialized
DEBUG - 2018-06-01 01:28:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-01 01:28:03 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-01 01:28:03 --> Login MX_Controller Initialized
INFO - 2018-06-01 01:28:03 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-01 01:28:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-01 01:28:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-01 01:28:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-01 01:28:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-01 01:28:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-01 01:28:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-01 01:28:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-01 01:28:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-06-01 01:28:03 --> Final output sent to browser
DEBUG - 2018-06-01 01:28:03 --> Total execution time: 0.5323
INFO - 2018-06-01 01:28:03 --> Config Class Initialized
INFO - 2018-06-01 01:28:03 --> Config Class Initialized
INFO - 2018-06-01 01:28:03 --> Hooks Class Initialized
INFO - 2018-06-01 01:28:03 --> Hooks Class Initialized
DEBUG - 2018-06-01 01:28:03 --> UTF-8 Support Enabled
DEBUG - 2018-06-01 01:28:03 --> UTF-8 Support Enabled
INFO - 2018-06-01 01:28:03 --> Utf8 Class Initialized
INFO - 2018-06-01 01:28:03 --> Utf8 Class Initialized
INFO - 2018-06-01 01:28:03 --> URI Class Initialized
INFO - 2018-06-01 01:28:03 --> Router Class Initialized
INFO - 2018-06-01 01:28:03 --> URI Class Initialized
INFO - 2018-06-01 01:28:03 --> Output Class Initialized
INFO - 2018-06-01 01:28:03 --> Router Class Initialized
INFO - 2018-06-01 01:28:03 --> Security Class Initialized
DEBUG - 2018-06-01 01:28:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 01:28:03 --> Output Class Initialized
INFO - 2018-06-01 01:28:03 --> Input Class Initialized
INFO - 2018-06-01 01:28:03 --> Security Class Initialized
INFO - 2018-06-01 01:28:04 --> Language Class Initialized
DEBUG - 2018-06-01 01:28:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-06-01 01:28:04 --> 404 Page Not Found: /index
INFO - 2018-06-01 01:28:04 --> Input Class Initialized
INFO - 2018-06-01 01:28:04 --> Config Class Initialized
INFO - 2018-06-01 01:28:04 --> Hooks Class Initialized
INFO - 2018-06-01 01:28:04 --> Language Class Initialized
DEBUG - 2018-06-01 01:28:04 --> UTF-8 Support Enabled
INFO - 2018-06-01 01:28:04 --> Utf8 Class Initialized
ERROR - 2018-06-01 01:28:04 --> 404 Page Not Found: /index
INFO - 2018-06-01 01:28:04 --> URI Class Initialized
INFO - 2018-06-01 01:28:04 --> Router Class Initialized
INFO - 2018-06-01 01:28:04 --> Output Class Initialized
INFO - 2018-06-01 01:28:04 --> Security Class Initialized
DEBUG - 2018-06-01 01:28:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 01:28:04 --> Input Class Initialized
INFO - 2018-06-01 01:28:04 --> Language Class Initialized
ERROR - 2018-06-01 01:28:04 --> 404 Page Not Found: /index
INFO - 2018-06-01 01:28:04 --> Config Class Initialized
INFO - 2018-06-01 01:28:04 --> Hooks Class Initialized
DEBUG - 2018-06-01 01:28:04 --> UTF-8 Support Enabled
INFO - 2018-06-01 01:28:04 --> Utf8 Class Initialized
INFO - 2018-06-01 01:28:04 --> URI Class Initialized
INFO - 2018-06-01 01:28:04 --> Router Class Initialized
INFO - 2018-06-01 01:28:04 --> Output Class Initialized
INFO - 2018-06-01 01:28:04 --> Security Class Initialized
DEBUG - 2018-06-01 01:28:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 01:28:04 --> Input Class Initialized
INFO - 2018-06-01 01:28:04 --> Language Class Initialized
ERROR - 2018-06-01 01:28:04 --> 404 Page Not Found: /index
INFO - 2018-06-01 21:33:18 --> Config Class Initialized
INFO - 2018-06-01 21:33:18 --> Hooks Class Initialized
DEBUG - 2018-06-01 21:33:18 --> UTF-8 Support Enabled
INFO - 2018-06-01 21:33:18 --> Utf8 Class Initialized
INFO - 2018-06-01 21:33:18 --> URI Class Initialized
INFO - 2018-06-01 21:33:18 --> Router Class Initialized
INFO - 2018-06-01 21:33:18 --> Output Class Initialized
INFO - 2018-06-01 21:33:18 --> Security Class Initialized
DEBUG - 2018-06-01 21:33:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 21:33:18 --> Input Class Initialized
INFO - 2018-06-01 21:33:18 --> Language Class Initialized
INFO - 2018-06-01 21:33:18 --> Language Class Initialized
INFO - 2018-06-01 21:33:18 --> Config Class Initialized
INFO - 2018-06-01 21:33:18 --> Loader Class Initialized
DEBUG - 2018-06-01 21:33:18 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-01 21:33:19 --> Helper loaded: url_helper
INFO - 2018-06-01 21:33:19 --> Helper loaded: form_helper
INFO - 2018-06-01 21:33:19 --> Helper loaded: date_helper
INFO - 2018-06-01 21:33:19 --> Helper loaded: util_helper
INFO - 2018-06-01 21:33:19 --> Helper loaded: text_helper
INFO - 2018-06-01 21:33:19 --> Helper loaded: string_helper
INFO - 2018-06-01 21:33:19 --> Database Driver Class Initialized
DEBUG - 2018-06-01 21:33:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-01 21:33:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-01 21:33:19 --> Email Class Initialized
INFO - 2018-06-01 21:33:19 --> Controller Class Initialized
DEBUG - 2018-06-01 21:33:19 --> Home MX_Controller Initialized
DEBUG - 2018-06-01 21:33:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-01 21:33:19 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-01 21:33:19 --> Login MX_Controller Initialized
INFO - 2018-06-01 21:33:19 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-01 21:33:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-01 21:33:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-01 21:33:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-06-01 21:33:22 --> Config Class Initialized
INFO - 2018-06-01 21:33:22 --> Hooks Class Initialized
DEBUG - 2018-06-01 21:33:22 --> UTF-8 Support Enabled
INFO - 2018-06-01 21:33:22 --> Utf8 Class Initialized
INFO - 2018-06-01 21:33:22 --> URI Class Initialized
INFO - 2018-06-01 21:33:22 --> Router Class Initialized
INFO - 2018-06-01 21:33:22 --> Output Class Initialized
INFO - 2018-06-01 21:33:22 --> Security Class Initialized
DEBUG - 2018-06-01 21:33:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 21:33:22 --> Input Class Initialized
INFO - 2018-06-01 21:33:22 --> Language Class Initialized
INFO - 2018-06-01 21:33:22 --> Language Class Initialized
INFO - 2018-06-01 21:33:22 --> Config Class Initialized
INFO - 2018-06-01 21:33:22 --> Loader Class Initialized
DEBUG - 2018-06-01 21:33:22 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-01 21:33:22 --> Helper loaded: url_helper
INFO - 2018-06-01 21:33:22 --> Helper loaded: form_helper
INFO - 2018-06-01 21:33:22 --> Helper loaded: date_helper
INFO - 2018-06-01 21:33:22 --> Helper loaded: util_helper
INFO - 2018-06-01 21:33:22 --> Helper loaded: text_helper
INFO - 2018-06-01 21:33:22 --> Helper loaded: string_helper
INFO - 2018-06-01 21:33:22 --> Database Driver Class Initialized
DEBUG - 2018-06-01 21:33:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-01 21:33:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-01 21:33:23 --> Email Class Initialized
INFO - 2018-06-01 21:33:23 --> Controller Class Initialized
DEBUG - 2018-06-01 21:33:23 --> Login MX_Controller Initialized
INFO - 2018-06-01 21:33:23 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-01 21:33:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-01 21:33:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-01 21:33:23 --> Email starts for gopipanguluri123@gmail.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-06-01 21:33:23 --> Login status gopipanguluri123@gmail.com - failure
INFO - 2018-06-01 21:33:23 --> Final output sent to browser
DEBUG - 2018-06-01 21:33:23 --> Total execution time: 0.4229
INFO - 2018-06-01 21:33:26 --> Config Class Initialized
INFO - 2018-06-01 21:33:26 --> Hooks Class Initialized
DEBUG - 2018-06-01 21:33:26 --> UTF-8 Support Enabled
INFO - 2018-06-01 21:33:26 --> Utf8 Class Initialized
INFO - 2018-06-01 21:33:26 --> URI Class Initialized
INFO - 2018-06-01 21:33:26 --> Router Class Initialized
INFO - 2018-06-01 21:33:26 --> Output Class Initialized
INFO - 2018-06-01 21:33:26 --> Security Class Initialized
DEBUG - 2018-06-01 21:33:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 21:33:26 --> Input Class Initialized
INFO - 2018-06-01 21:33:26 --> Language Class Initialized
INFO - 2018-06-01 21:33:26 --> Language Class Initialized
INFO - 2018-06-01 21:33:26 --> Config Class Initialized
INFO - 2018-06-01 21:33:26 --> Loader Class Initialized
DEBUG - 2018-06-01 21:33:26 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-01 21:33:26 --> Helper loaded: url_helper
INFO - 2018-06-01 21:33:26 --> Helper loaded: form_helper
INFO - 2018-06-01 21:33:26 --> Helper loaded: date_helper
INFO - 2018-06-01 21:33:26 --> Helper loaded: util_helper
INFO - 2018-06-01 21:33:26 --> Helper loaded: text_helper
INFO - 2018-06-01 21:33:26 --> Helper loaded: string_helper
INFO - 2018-06-01 21:33:26 --> Database Driver Class Initialized
DEBUG - 2018-06-01 21:33:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-01 21:33:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-01 21:33:26 --> Email Class Initialized
INFO - 2018-06-01 21:33:26 --> Controller Class Initialized
DEBUG - 2018-06-01 21:33:26 --> Login MX_Controller Initialized
INFO - 2018-06-01 21:33:26 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-01 21:33:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-01 21:33:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-01 21:33:26 --> Email starts for user@colin.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-06-01 21:33:26 --> User session created for 4
INFO - 2018-06-01 21:33:26 --> Login status user@colin.com - success
INFO - 2018-06-01 21:33:27 --> Final output sent to browser
DEBUG - 2018-06-01 21:33:27 --> Total execution time: 0.4811
INFO - 2018-06-01 21:33:27 --> Config Class Initialized
INFO - 2018-06-01 21:33:27 --> Hooks Class Initialized
DEBUG - 2018-06-01 21:33:27 --> UTF-8 Support Enabled
INFO - 2018-06-01 21:33:27 --> Utf8 Class Initialized
INFO - 2018-06-01 21:33:27 --> URI Class Initialized
INFO - 2018-06-01 21:33:27 --> Router Class Initialized
INFO - 2018-06-01 21:33:27 --> Output Class Initialized
INFO - 2018-06-01 21:33:27 --> Security Class Initialized
DEBUG - 2018-06-01 21:33:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 21:33:27 --> Input Class Initialized
INFO - 2018-06-01 21:33:27 --> Language Class Initialized
INFO - 2018-06-01 21:33:27 --> Language Class Initialized
INFO - 2018-06-01 21:33:27 --> Config Class Initialized
INFO - 2018-06-01 21:33:27 --> Loader Class Initialized
DEBUG - 2018-06-01 21:33:27 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-01 21:33:27 --> Helper loaded: url_helper
INFO - 2018-06-01 21:33:27 --> Helper loaded: form_helper
INFO - 2018-06-01 21:33:27 --> Helper loaded: date_helper
INFO - 2018-06-01 21:33:27 --> Helper loaded: util_helper
INFO - 2018-06-01 21:33:27 --> Helper loaded: text_helper
INFO - 2018-06-01 21:33:27 --> Helper loaded: string_helper
INFO - 2018-06-01 21:33:27 --> Database Driver Class Initialized
DEBUG - 2018-06-01 21:33:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-01 21:33:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-01 21:33:27 --> Email Class Initialized
INFO - 2018-06-01 21:33:27 --> Controller Class Initialized
DEBUG - 2018-06-01 21:33:27 --> Home MX_Controller Initialized
DEBUG - 2018-06-01 21:33:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-01 21:33:27 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-01 21:33:27 --> Login MX_Controller Initialized
INFO - 2018-06-01 21:33:27 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-01 21:33:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-01 21:33:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-01 21:33:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-01 21:33:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-01 21:33:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-01 21:33:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-01 21:33:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-01 21:33:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-06-01 21:33:27 --> Final output sent to browser
DEBUG - 2018-06-01 21:33:27 --> Total execution time: 0.7130
INFO - 2018-06-01 21:33:28 --> Config Class Initialized
INFO - 2018-06-01 21:33:28 --> Hooks Class Initialized
DEBUG - 2018-06-01 21:33:28 --> UTF-8 Support Enabled
INFO - 2018-06-01 21:33:28 --> Utf8 Class Initialized
INFO - 2018-06-01 21:33:28 --> URI Class Initialized
INFO - 2018-06-01 21:33:28 --> Router Class Initialized
INFO - 2018-06-01 21:33:28 --> Output Class Initialized
INFO - 2018-06-01 21:33:28 --> Security Class Initialized
DEBUG - 2018-06-01 21:33:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 21:33:28 --> Input Class Initialized
INFO - 2018-06-01 21:33:28 --> Config Class Initialized
INFO - 2018-06-01 21:33:28 --> Hooks Class Initialized
INFO - 2018-06-01 21:33:28 --> Language Class Initialized
DEBUG - 2018-06-01 21:33:28 --> UTF-8 Support Enabled
INFO - 2018-06-01 21:33:28 --> Utf8 Class Initialized
INFO - 2018-06-01 21:33:28 --> URI Class Initialized
INFO - 2018-06-01 21:33:28 --> Router Class Initialized
ERROR - 2018-06-01 21:33:28 --> 404 Page Not Found: /index
INFO - 2018-06-01 21:33:28 --> Output Class Initialized
INFO - 2018-06-01 21:33:28 --> Security Class Initialized
INFO - 2018-06-01 21:33:28 --> Config Class Initialized
INFO - 2018-06-01 21:33:28 --> Hooks Class Initialized
DEBUG - 2018-06-01 21:33:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 21:33:28 --> Input Class Initialized
DEBUG - 2018-06-01 21:33:28 --> UTF-8 Support Enabled
INFO - 2018-06-01 21:33:28 --> Utf8 Class Initialized
INFO - 2018-06-01 21:33:28 --> Language Class Initialized
INFO - 2018-06-01 21:33:28 --> URI Class Initialized
INFO - 2018-06-01 21:33:28 --> Language Class Initialized
INFO - 2018-06-01 21:33:28 --> Config Class Initialized
INFO - 2018-06-01 21:33:28 --> Router Class Initialized
INFO - 2018-06-01 21:33:29 --> Output Class Initialized
INFO - 2018-06-01 21:33:29 --> Loader Class Initialized
DEBUG - 2018-06-01 21:33:29 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-01 21:33:29 --> Security Class Initialized
DEBUG - 2018-06-01 21:33:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 21:33:29 --> Helper loaded: url_helper
INFO - 2018-06-01 21:33:29 --> Input Class Initialized
INFO - 2018-06-01 21:33:29 --> Helper loaded: form_helper
INFO - 2018-06-01 21:33:29 --> Language Class Initialized
INFO - 2018-06-01 21:33:29 --> Helper loaded: date_helper
ERROR - 2018-06-01 21:33:29 --> 404 Page Not Found: /index
INFO - 2018-06-01 21:33:29 --> Helper loaded: util_helper
INFO - 2018-06-01 21:33:29 --> Helper loaded: text_helper
INFO - 2018-06-01 21:33:29 --> Config Class Initialized
INFO - 2018-06-01 21:33:29 --> Hooks Class Initialized
INFO - 2018-06-01 21:33:29 --> Helper loaded: string_helper
DEBUG - 2018-06-01 21:33:29 --> UTF-8 Support Enabled
INFO - 2018-06-01 21:33:29 --> Database Driver Class Initialized
INFO - 2018-06-01 21:33:29 --> Utf8 Class Initialized
DEBUG - 2018-06-01 21:33:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-01 21:33:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-01 21:33:29 --> URI Class Initialized
INFO - 2018-06-01 21:33:29 --> Router Class Initialized
INFO - 2018-06-01 21:33:29 --> Email Class Initialized
INFO - 2018-06-01 21:33:29 --> Controller Class Initialized
INFO - 2018-06-01 21:33:29 --> Output Class Initialized
DEBUG - 2018-06-01 21:33:29 --> Home MX_Controller Initialized
INFO - 2018-06-01 21:33:29 --> Security Class Initialized
DEBUG - 2018-06-01 21:33:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-01 21:33:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 21:33:29 --> Input Class Initialized
DEBUG - 2018-06-01 21:33:29 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-01 21:33:29 --> Login MX_Controller Initialized
INFO - 2018-06-01 21:33:29 --> Language Class Initialized
INFO - 2018-06-01 21:33:29 --> Language file loaded: language/english/data_lang.php
ERROR - 2018-06-01 21:33:29 --> 404 Page Not Found: /index
DEBUG - 2018-06-01 21:33:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-01 21:33:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-01 21:33:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-01 21:33:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-01 21:33:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-01 21:33:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-01 21:33:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-01 21:33:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-06-01 21:33:29 --> Final output sent to browser
DEBUG - 2018-06-01 21:33:29 --> Total execution time: 0.7090
INFO - 2018-06-01 21:33:30 --> Config Class Initialized
INFO - 2018-06-01 21:33:30 --> Hooks Class Initialized
DEBUG - 2018-06-01 21:33:30 --> UTF-8 Support Enabled
INFO - 2018-06-01 21:33:30 --> Utf8 Class Initialized
INFO - 2018-06-01 21:33:30 --> URI Class Initialized
INFO - 2018-06-01 21:33:30 --> Router Class Initialized
INFO - 2018-06-01 21:33:30 --> Output Class Initialized
INFO - 2018-06-01 21:33:30 --> Security Class Initialized
DEBUG - 2018-06-01 21:33:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 21:33:30 --> Input Class Initialized
INFO - 2018-06-01 21:33:30 --> Language Class Initialized
ERROR - 2018-06-01 21:33:30 --> 404 Page Not Found: /index
INFO - 2018-06-01 21:33:30 --> Config Class Initialized
INFO - 2018-06-01 21:33:30 --> Hooks Class Initialized
DEBUG - 2018-06-01 21:33:30 --> UTF-8 Support Enabled
INFO - 2018-06-01 21:33:30 --> Utf8 Class Initialized
INFO - 2018-06-01 21:33:30 --> URI Class Initialized
INFO - 2018-06-01 21:33:30 --> Router Class Initialized
INFO - 2018-06-01 21:33:30 --> Output Class Initialized
INFO - 2018-06-01 21:33:30 --> Security Class Initialized
DEBUG - 2018-06-01 21:33:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 21:33:30 --> Input Class Initialized
INFO - 2018-06-01 21:33:30 --> Language Class Initialized
ERROR - 2018-06-01 21:33:30 --> 404 Page Not Found: /index
INFO - 2018-06-01 21:33:30 --> Config Class Initialized
INFO - 2018-06-01 21:33:30 --> Hooks Class Initialized
DEBUG - 2018-06-01 21:33:30 --> UTF-8 Support Enabled
INFO - 2018-06-01 21:33:30 --> Utf8 Class Initialized
INFO - 2018-06-01 21:33:30 --> URI Class Initialized
INFO - 2018-06-01 21:33:30 --> Router Class Initialized
INFO - 2018-06-01 21:33:30 --> Output Class Initialized
INFO - 2018-06-01 21:33:30 --> Security Class Initialized
DEBUG - 2018-06-01 21:33:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 21:33:30 --> Input Class Initialized
INFO - 2018-06-01 21:33:30 --> Language Class Initialized
ERROR - 2018-06-01 21:33:31 --> 404 Page Not Found: /index
INFO - 2018-06-01 21:33:54 --> Config Class Initialized
INFO - 2018-06-01 21:33:54 --> Hooks Class Initialized
DEBUG - 2018-06-01 21:33:54 --> UTF-8 Support Enabled
INFO - 2018-06-01 21:33:54 --> Utf8 Class Initialized
INFO - 2018-06-01 21:33:54 --> URI Class Initialized
INFO - 2018-06-01 21:33:54 --> Router Class Initialized
INFO - 2018-06-01 21:33:54 --> Output Class Initialized
INFO - 2018-06-01 21:33:54 --> Security Class Initialized
DEBUG - 2018-06-01 21:33:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 21:33:54 --> Input Class Initialized
INFO - 2018-06-01 21:33:54 --> Language Class Initialized
INFO - 2018-06-01 21:33:54 --> Language Class Initialized
INFO - 2018-06-01 21:33:54 --> Config Class Initialized
INFO - 2018-06-01 21:33:54 --> Loader Class Initialized
DEBUG - 2018-06-01 21:33:54 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-01 21:33:54 --> Helper loaded: url_helper
INFO - 2018-06-01 21:33:54 --> Helper loaded: form_helper
INFO - 2018-06-01 21:33:54 --> Helper loaded: date_helper
INFO - 2018-06-01 21:33:54 --> Helper loaded: util_helper
INFO - 2018-06-01 21:33:54 --> Helper loaded: text_helper
INFO - 2018-06-01 21:33:54 --> Helper loaded: string_helper
INFO - 2018-06-01 21:33:54 --> Database Driver Class Initialized
DEBUG - 2018-06-01 21:33:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-01 21:33:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-01 21:33:54 --> Email Class Initialized
INFO - 2018-06-01 21:33:54 --> Controller Class Initialized
DEBUG - 2018-06-01 21:33:54 --> Login MX_Controller Initialized
INFO - 2018-06-01 21:33:54 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-01 21:33:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-01 21:33:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-01 21:33:54 --> 4 Loggedout
INFO - 2018-06-01 21:33:54 --> Config Class Initialized
INFO - 2018-06-01 21:33:54 --> Hooks Class Initialized
DEBUG - 2018-06-01 21:33:54 --> UTF-8 Support Enabled
INFO - 2018-06-01 21:33:54 --> Utf8 Class Initialized
INFO - 2018-06-01 21:33:54 --> URI Class Initialized
INFO - 2018-06-01 21:33:54 --> Router Class Initialized
INFO - 2018-06-01 21:33:54 --> Output Class Initialized
INFO - 2018-06-01 21:33:54 --> Security Class Initialized
DEBUG - 2018-06-01 21:33:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 21:33:54 --> Input Class Initialized
INFO - 2018-06-01 21:33:54 --> Language Class Initialized
INFO - 2018-06-01 21:33:54 --> Language Class Initialized
INFO - 2018-06-01 21:33:54 --> Config Class Initialized
INFO - 2018-06-01 21:33:54 --> Loader Class Initialized
DEBUG - 2018-06-01 21:33:54 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-01 21:33:54 --> Helper loaded: url_helper
INFO - 2018-06-01 21:33:54 --> Helper loaded: form_helper
INFO - 2018-06-01 21:33:54 --> Helper loaded: date_helper
INFO - 2018-06-01 21:33:54 --> Helper loaded: util_helper
INFO - 2018-06-01 21:33:54 --> Helper loaded: text_helper
INFO - 2018-06-01 21:33:54 --> Helper loaded: string_helper
INFO - 2018-06-01 21:33:55 --> Database Driver Class Initialized
DEBUG - 2018-06-01 21:33:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-01 21:33:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-01 21:33:55 --> Email Class Initialized
INFO - 2018-06-01 21:33:55 --> Controller Class Initialized
DEBUG - 2018-06-01 21:33:55 --> Home MX_Controller Initialized
DEBUG - 2018-06-01 21:33:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-01 21:33:55 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-01 21:33:55 --> Login MX_Controller Initialized
INFO - 2018-06-01 21:33:55 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-01 21:33:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-01 21:33:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-01 21:33:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-06-01 21:33:58 --> Config Class Initialized
INFO - 2018-06-01 21:33:58 --> Hooks Class Initialized
DEBUG - 2018-06-01 21:33:58 --> UTF-8 Support Enabled
INFO - 2018-06-01 21:33:58 --> Utf8 Class Initialized
INFO - 2018-06-01 21:33:58 --> URI Class Initialized
INFO - 2018-06-01 21:33:58 --> Router Class Initialized
INFO - 2018-06-01 21:33:58 --> Output Class Initialized
INFO - 2018-06-01 21:33:58 --> Security Class Initialized
DEBUG - 2018-06-01 21:33:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 21:33:58 --> Input Class Initialized
INFO - 2018-06-01 21:33:58 --> Language Class Initialized
INFO - 2018-06-01 21:33:58 --> Language Class Initialized
INFO - 2018-06-01 21:33:58 --> Config Class Initialized
INFO - 2018-06-01 21:33:58 --> Loader Class Initialized
DEBUG - 2018-06-01 21:33:58 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-01 21:33:58 --> Helper loaded: url_helper
INFO - 2018-06-01 21:33:58 --> Helper loaded: form_helper
INFO - 2018-06-01 21:33:58 --> Helper loaded: date_helper
INFO - 2018-06-01 21:33:58 --> Helper loaded: util_helper
INFO - 2018-06-01 21:33:58 --> Helper loaded: text_helper
INFO - 2018-06-01 21:33:58 --> Helper loaded: string_helper
INFO - 2018-06-01 21:33:58 --> Database Driver Class Initialized
DEBUG - 2018-06-01 21:33:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-01 21:33:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-01 21:33:58 --> Email Class Initialized
INFO - 2018-06-01 21:33:58 --> Controller Class Initialized
DEBUG - 2018-06-01 21:33:58 --> Home MX_Controller Initialized
DEBUG - 2018-06-01 21:33:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-01 21:33:58 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-01 21:33:58 --> Login MX_Controller Initialized
INFO - 2018-06-01 21:33:58 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-01 21:33:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-01 21:33:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-01 21:33:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-06-01 21:36:40 --> Config Class Initialized
INFO - 2018-06-01 21:36:40 --> Hooks Class Initialized
DEBUG - 2018-06-01 21:36:40 --> UTF-8 Support Enabled
INFO - 2018-06-01 21:36:40 --> Utf8 Class Initialized
INFO - 2018-06-01 21:36:40 --> URI Class Initialized
INFO - 2018-06-01 21:36:40 --> Router Class Initialized
INFO - 2018-06-01 21:36:40 --> Output Class Initialized
INFO - 2018-06-01 21:36:40 --> Security Class Initialized
DEBUG - 2018-06-01 21:36:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 21:36:40 --> Input Class Initialized
INFO - 2018-06-01 21:36:40 --> Language Class Initialized
INFO - 2018-06-01 21:36:40 --> Language Class Initialized
INFO - 2018-06-01 21:36:40 --> Config Class Initialized
INFO - 2018-06-01 21:36:40 --> Loader Class Initialized
DEBUG - 2018-06-01 21:36:40 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-01 21:36:40 --> Helper loaded: url_helper
INFO - 2018-06-01 21:36:40 --> Helper loaded: form_helper
INFO - 2018-06-01 21:36:40 --> Helper loaded: date_helper
INFO - 2018-06-01 21:36:40 --> Helper loaded: util_helper
INFO - 2018-06-01 21:36:40 --> Helper loaded: text_helper
INFO - 2018-06-01 21:36:40 --> Helper loaded: string_helper
INFO - 2018-06-01 21:36:40 --> Database Driver Class Initialized
DEBUG - 2018-06-01 21:36:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-01 21:36:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-01 21:36:40 --> Email Class Initialized
INFO - 2018-06-01 21:36:40 --> Controller Class Initialized
DEBUG - 2018-06-01 21:36:40 --> Home MX_Controller Initialized
DEBUG - 2018-06-01 21:36:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-01 21:36:41 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-01 21:36:41 --> Login MX_Controller Initialized
INFO - 2018-06-01 21:36:41 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-01 21:36:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-01 21:36:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-01 21:36:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-06-01 21:37:01 --> Config Class Initialized
INFO - 2018-06-01 21:37:01 --> Hooks Class Initialized
DEBUG - 2018-06-01 21:37:01 --> UTF-8 Support Enabled
INFO - 2018-06-01 21:37:01 --> Utf8 Class Initialized
INFO - 2018-06-01 21:37:01 --> URI Class Initialized
INFO - 2018-06-01 21:37:01 --> Router Class Initialized
INFO - 2018-06-01 21:37:01 --> Output Class Initialized
INFO - 2018-06-01 21:37:01 --> Security Class Initialized
DEBUG - 2018-06-01 21:37:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 21:37:01 --> Input Class Initialized
INFO - 2018-06-01 21:37:01 --> Language Class Initialized
INFO - 2018-06-01 21:37:01 --> Language Class Initialized
INFO - 2018-06-01 21:37:01 --> Config Class Initialized
INFO - 2018-06-01 21:37:01 --> Loader Class Initialized
DEBUG - 2018-06-01 21:37:01 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-01 21:37:01 --> Helper loaded: url_helper
INFO - 2018-06-01 21:37:01 --> Helper loaded: form_helper
INFO - 2018-06-01 21:37:01 --> Helper loaded: date_helper
INFO - 2018-06-01 21:37:01 --> Helper loaded: util_helper
INFO - 2018-06-01 21:37:01 --> Helper loaded: text_helper
INFO - 2018-06-01 21:37:01 --> Helper loaded: string_helper
INFO - 2018-06-01 21:37:02 --> Database Driver Class Initialized
DEBUG - 2018-06-01 21:37:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-01 21:37:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-01 21:37:02 --> Email Class Initialized
INFO - 2018-06-01 21:37:02 --> Controller Class Initialized
DEBUG - 2018-06-01 21:37:02 --> Home MX_Controller Initialized
DEBUG - 2018-06-01 21:37:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-01 21:37:02 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-01 21:37:02 --> Login MX_Controller Initialized
INFO - 2018-06-01 21:37:02 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-01 21:37:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-01 21:37:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-01 21:37:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-06-01 21:37:20 --> Config Class Initialized
INFO - 2018-06-01 21:37:20 --> Hooks Class Initialized
DEBUG - 2018-06-01 21:37:20 --> UTF-8 Support Enabled
INFO - 2018-06-01 21:37:20 --> Utf8 Class Initialized
INFO - 2018-06-01 21:37:20 --> URI Class Initialized
INFO - 2018-06-01 21:37:20 --> Router Class Initialized
INFO - 2018-06-01 21:37:20 --> Output Class Initialized
INFO - 2018-06-01 21:37:20 --> Security Class Initialized
DEBUG - 2018-06-01 21:37:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 21:37:20 --> Input Class Initialized
INFO - 2018-06-01 21:37:20 --> Language Class Initialized
INFO - 2018-06-01 21:37:20 --> Language Class Initialized
INFO - 2018-06-01 21:37:20 --> Config Class Initialized
INFO - 2018-06-01 21:37:20 --> Loader Class Initialized
DEBUG - 2018-06-01 21:37:20 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-01 21:37:20 --> Helper loaded: url_helper
INFO - 2018-06-01 21:37:20 --> Helper loaded: form_helper
INFO - 2018-06-01 21:37:20 --> Helper loaded: date_helper
INFO - 2018-06-01 21:37:20 --> Helper loaded: util_helper
INFO - 2018-06-01 21:37:20 --> Helper loaded: text_helper
INFO - 2018-06-01 21:37:20 --> Helper loaded: string_helper
INFO - 2018-06-01 21:37:20 --> Database Driver Class Initialized
DEBUG - 2018-06-01 21:37:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-01 21:37:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-01 21:37:20 --> Email Class Initialized
INFO - 2018-06-01 21:37:20 --> Controller Class Initialized
DEBUG - 2018-06-01 21:37:20 --> Home MX_Controller Initialized
DEBUG - 2018-06-01 21:37:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-01 21:37:20 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-01 21:37:20 --> Login MX_Controller Initialized
INFO - 2018-06-01 21:37:20 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-01 21:37:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-01 21:37:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-01 21:37:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-06-01 21:37:34 --> Config Class Initialized
INFO - 2018-06-01 21:37:34 --> Hooks Class Initialized
DEBUG - 2018-06-01 21:37:34 --> UTF-8 Support Enabled
INFO - 2018-06-01 21:37:34 --> Utf8 Class Initialized
INFO - 2018-06-01 21:37:34 --> URI Class Initialized
INFO - 2018-06-01 21:37:34 --> Router Class Initialized
INFO - 2018-06-01 21:37:34 --> Output Class Initialized
INFO - 2018-06-01 21:37:34 --> Security Class Initialized
DEBUG - 2018-06-01 21:37:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 21:37:35 --> Input Class Initialized
INFO - 2018-06-01 21:37:35 --> Language Class Initialized
INFO - 2018-06-01 21:37:35 --> Language Class Initialized
INFO - 2018-06-01 21:37:35 --> Config Class Initialized
INFO - 2018-06-01 21:37:35 --> Loader Class Initialized
DEBUG - 2018-06-01 21:37:35 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-01 21:37:35 --> Helper loaded: url_helper
INFO - 2018-06-01 21:37:35 --> Helper loaded: form_helper
INFO - 2018-06-01 21:37:35 --> Helper loaded: date_helper
INFO - 2018-06-01 21:37:35 --> Helper loaded: util_helper
INFO - 2018-06-01 21:37:35 --> Helper loaded: text_helper
INFO - 2018-06-01 21:37:35 --> Helper loaded: string_helper
INFO - 2018-06-01 21:37:35 --> Database Driver Class Initialized
DEBUG - 2018-06-01 21:37:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-01 21:37:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-01 21:37:35 --> Email Class Initialized
INFO - 2018-06-01 21:37:35 --> Controller Class Initialized
DEBUG - 2018-06-01 21:37:35 --> Home MX_Controller Initialized
DEBUG - 2018-06-01 21:37:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-01 21:37:35 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-01 21:37:35 --> Login MX_Controller Initialized
INFO - 2018-06-01 21:37:35 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-01 21:37:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-01 21:37:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-01 21:37:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-06-01 21:37:50 --> Config Class Initialized
INFO - 2018-06-01 21:37:50 --> Hooks Class Initialized
DEBUG - 2018-06-01 21:37:50 --> UTF-8 Support Enabled
INFO - 2018-06-01 21:37:50 --> Utf8 Class Initialized
INFO - 2018-06-01 21:37:50 --> URI Class Initialized
INFO - 2018-06-01 21:37:50 --> Router Class Initialized
INFO - 2018-06-01 21:37:50 --> Output Class Initialized
INFO - 2018-06-01 21:37:51 --> Security Class Initialized
DEBUG - 2018-06-01 21:37:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 21:37:51 --> Input Class Initialized
INFO - 2018-06-01 21:37:51 --> Language Class Initialized
INFO - 2018-06-01 21:37:51 --> Language Class Initialized
INFO - 2018-06-01 21:37:51 --> Config Class Initialized
INFO - 2018-06-01 21:37:51 --> Loader Class Initialized
DEBUG - 2018-06-01 21:37:51 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-01 21:37:51 --> Helper loaded: url_helper
INFO - 2018-06-01 21:37:51 --> Helper loaded: form_helper
INFO - 2018-06-01 21:37:51 --> Helper loaded: date_helper
INFO - 2018-06-01 21:37:51 --> Helper loaded: util_helper
INFO - 2018-06-01 21:37:51 --> Helper loaded: text_helper
INFO - 2018-06-01 21:37:51 --> Helper loaded: string_helper
INFO - 2018-06-01 21:37:51 --> Database Driver Class Initialized
DEBUG - 2018-06-01 21:37:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-01 21:37:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-01 21:37:51 --> Email Class Initialized
INFO - 2018-06-01 21:37:51 --> Controller Class Initialized
DEBUG - 2018-06-01 21:37:51 --> Home MX_Controller Initialized
DEBUG - 2018-06-01 21:37:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-01 21:37:51 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-01 21:37:51 --> Login MX_Controller Initialized
INFO - 2018-06-01 21:37:51 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-01 21:37:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-01 21:37:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-01 21:37:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-06-01 21:37:53 --> Config Class Initialized
INFO - 2018-06-01 21:37:53 --> Hooks Class Initialized
DEBUG - 2018-06-01 21:37:53 --> UTF-8 Support Enabled
INFO - 2018-06-01 21:37:53 --> Utf8 Class Initialized
INFO - 2018-06-01 21:37:53 --> URI Class Initialized
DEBUG - 2018-06-01 21:37:53 --> No URI present. Default controller set.
INFO - 2018-06-01 21:37:53 --> Router Class Initialized
INFO - 2018-06-01 21:37:53 --> Output Class Initialized
INFO - 2018-06-01 21:37:53 --> Security Class Initialized
DEBUG - 2018-06-01 21:37:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 21:37:53 --> Input Class Initialized
INFO - 2018-06-01 21:37:53 --> Language Class Initialized
INFO - 2018-06-01 21:37:53 --> Language Class Initialized
INFO - 2018-06-01 21:37:53 --> Config Class Initialized
INFO - 2018-06-01 21:37:53 --> Loader Class Initialized
DEBUG - 2018-06-01 21:37:53 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-01 21:37:53 --> Helper loaded: url_helper
INFO - 2018-06-01 21:37:53 --> Helper loaded: form_helper
INFO - 2018-06-01 21:37:53 --> Helper loaded: date_helper
INFO - 2018-06-01 21:37:53 --> Helper loaded: util_helper
INFO - 2018-06-01 21:37:53 --> Helper loaded: text_helper
INFO - 2018-06-01 21:37:53 --> Helper loaded: string_helper
INFO - 2018-06-01 21:37:53 --> Database Driver Class Initialized
DEBUG - 2018-06-01 21:37:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-01 21:37:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-01 21:37:53 --> Email Class Initialized
INFO - 2018-06-01 21:37:53 --> Controller Class Initialized
DEBUG - 2018-06-01 21:37:53 --> Home MX_Controller Initialized
DEBUG - 2018-06-01 21:37:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-01 21:37:53 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-01 21:37:53 --> Login MX_Controller Initialized
INFO - 2018-06-01 21:37:53 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-01 21:37:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-01 21:37:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-01 21:37:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-06-01 21:44:25 --> Config Class Initialized
INFO - 2018-06-01 21:44:25 --> Hooks Class Initialized
DEBUG - 2018-06-01 21:44:25 --> UTF-8 Support Enabled
INFO - 2018-06-01 21:44:25 --> Utf8 Class Initialized
INFO - 2018-06-01 21:44:25 --> URI Class Initialized
INFO - 2018-06-01 21:44:25 --> Router Class Initialized
INFO - 2018-06-01 21:44:25 --> Output Class Initialized
INFO - 2018-06-01 21:44:25 --> Security Class Initialized
DEBUG - 2018-06-01 21:44:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 21:44:25 --> Input Class Initialized
INFO - 2018-06-01 21:44:26 --> Language Class Initialized
INFO - 2018-06-01 21:44:26 --> Language Class Initialized
INFO - 2018-06-01 21:44:26 --> Config Class Initialized
INFO - 2018-06-01 21:44:26 --> Loader Class Initialized
DEBUG - 2018-06-01 21:44:26 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-01 21:44:26 --> Helper loaded: url_helper
INFO - 2018-06-01 21:44:26 --> Helper loaded: form_helper
INFO - 2018-06-01 21:44:26 --> Helper loaded: date_helper
INFO - 2018-06-01 21:44:26 --> Helper loaded: util_helper
INFO - 2018-06-01 21:44:26 --> Helper loaded: text_helper
INFO - 2018-06-01 21:44:26 --> Helper loaded: string_helper
INFO - 2018-06-01 21:44:26 --> Database Driver Class Initialized
DEBUG - 2018-06-01 21:44:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-01 21:44:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-01 21:44:26 --> Email Class Initialized
INFO - 2018-06-01 21:44:26 --> Controller Class Initialized
DEBUG - 2018-06-01 21:44:26 --> Home MX_Controller Initialized
DEBUG - 2018-06-01 21:44:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-01 21:44:26 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-01 21:44:26 --> Login MX_Controller Initialized
INFO - 2018-06-01 21:44:26 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-01 21:44:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-01 21:44:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-01 21:44:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-06-01 21:44:28 --> Config Class Initialized
INFO - 2018-06-01 21:44:28 --> Hooks Class Initialized
DEBUG - 2018-06-01 21:44:28 --> UTF-8 Support Enabled
INFO - 2018-06-01 21:44:28 --> Utf8 Class Initialized
INFO - 2018-06-01 21:44:28 --> URI Class Initialized
DEBUG - 2018-06-01 21:44:28 --> No URI present. Default controller set.
INFO - 2018-06-01 21:44:28 --> Router Class Initialized
INFO - 2018-06-01 21:44:28 --> Output Class Initialized
INFO - 2018-06-01 21:44:28 --> Security Class Initialized
DEBUG - 2018-06-01 21:44:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 21:44:28 --> Input Class Initialized
INFO - 2018-06-01 21:44:28 --> Language Class Initialized
INFO - 2018-06-01 21:44:28 --> Language Class Initialized
INFO - 2018-06-01 21:44:28 --> Config Class Initialized
INFO - 2018-06-01 21:44:28 --> Loader Class Initialized
DEBUG - 2018-06-01 21:44:28 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-01 21:44:28 --> Helper loaded: url_helper
INFO - 2018-06-01 21:44:28 --> Helper loaded: form_helper
INFO - 2018-06-01 21:44:28 --> Helper loaded: date_helper
INFO - 2018-06-01 21:44:28 --> Helper loaded: util_helper
INFO - 2018-06-01 21:44:28 --> Helper loaded: text_helper
INFO - 2018-06-01 21:44:28 --> Helper loaded: string_helper
INFO - 2018-06-01 21:44:28 --> Database Driver Class Initialized
DEBUG - 2018-06-01 21:44:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-01 21:44:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-01 21:44:28 --> Email Class Initialized
INFO - 2018-06-01 21:44:28 --> Controller Class Initialized
DEBUG - 2018-06-01 21:44:28 --> Home MX_Controller Initialized
DEBUG - 2018-06-01 21:44:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-01 21:44:28 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-01 21:44:28 --> Login MX_Controller Initialized
INFO - 2018-06-01 21:44:28 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-01 21:44:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-01 21:44:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-01 21:44:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-06-01 21:47:32 --> Config Class Initialized
INFO - 2018-06-01 21:47:32 --> Hooks Class Initialized
DEBUG - 2018-06-01 21:47:32 --> UTF-8 Support Enabled
INFO - 2018-06-01 21:47:32 --> Utf8 Class Initialized
INFO - 2018-06-01 21:47:32 --> URI Class Initialized
DEBUG - 2018-06-01 21:47:32 --> No URI present. Default controller set.
INFO - 2018-06-01 21:47:32 --> Router Class Initialized
INFO - 2018-06-01 21:47:32 --> Output Class Initialized
INFO - 2018-06-01 21:47:32 --> Security Class Initialized
DEBUG - 2018-06-01 21:47:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 21:47:32 --> Input Class Initialized
INFO - 2018-06-01 21:47:32 --> Language Class Initialized
INFO - 2018-06-01 21:47:32 --> Language Class Initialized
INFO - 2018-06-01 21:47:33 --> Config Class Initialized
INFO - 2018-06-01 21:47:33 --> Loader Class Initialized
DEBUG - 2018-06-01 21:47:33 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-01 21:47:33 --> Helper loaded: url_helper
INFO - 2018-06-01 21:47:33 --> Helper loaded: form_helper
INFO - 2018-06-01 21:47:33 --> Helper loaded: date_helper
INFO - 2018-06-01 21:47:33 --> Helper loaded: util_helper
INFO - 2018-06-01 21:47:33 --> Helper loaded: text_helper
INFO - 2018-06-01 21:47:33 --> Helper loaded: string_helper
INFO - 2018-06-01 21:47:33 --> Database Driver Class Initialized
DEBUG - 2018-06-01 21:47:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-01 21:47:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-01 21:47:33 --> Email Class Initialized
INFO - 2018-06-01 21:47:33 --> Controller Class Initialized
DEBUG - 2018-06-01 21:47:33 --> Home MX_Controller Initialized
DEBUG - 2018-06-01 21:47:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-01 21:47:33 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-01 21:47:33 --> Login MX_Controller Initialized
INFO - 2018-06-01 21:47:33 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-01 21:47:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-01 21:47:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-01 21:47:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-06-01 21:48:33 --> Config Class Initialized
INFO - 2018-06-01 21:48:33 --> Hooks Class Initialized
DEBUG - 2018-06-01 21:48:33 --> UTF-8 Support Enabled
INFO - 2018-06-01 21:48:33 --> Utf8 Class Initialized
INFO - 2018-06-01 21:48:33 --> URI Class Initialized
DEBUG - 2018-06-01 21:48:33 --> No URI present. Default controller set.
INFO - 2018-06-01 21:48:33 --> Router Class Initialized
INFO - 2018-06-01 21:48:33 --> Output Class Initialized
INFO - 2018-06-01 21:48:33 --> Security Class Initialized
DEBUG - 2018-06-01 21:48:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 21:48:33 --> Input Class Initialized
INFO - 2018-06-01 21:48:33 --> Language Class Initialized
INFO - 2018-06-01 21:48:33 --> Language Class Initialized
INFO - 2018-06-01 21:48:33 --> Config Class Initialized
INFO - 2018-06-01 21:48:33 --> Loader Class Initialized
DEBUG - 2018-06-01 21:48:33 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-01 21:48:33 --> Helper loaded: url_helper
INFO - 2018-06-01 21:48:33 --> Helper loaded: form_helper
INFO - 2018-06-01 21:48:33 --> Helper loaded: date_helper
INFO - 2018-06-01 21:48:33 --> Helper loaded: util_helper
INFO - 2018-06-01 21:48:33 --> Helper loaded: text_helper
INFO - 2018-06-01 21:48:33 --> Helper loaded: string_helper
INFO - 2018-06-01 21:48:33 --> Database Driver Class Initialized
DEBUG - 2018-06-01 21:48:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-01 21:48:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-01 21:48:33 --> Email Class Initialized
INFO - 2018-06-01 21:48:33 --> Controller Class Initialized
DEBUG - 2018-06-01 21:48:33 --> Home MX_Controller Initialized
DEBUG - 2018-06-01 21:48:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-01 21:48:33 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-01 21:48:33 --> Login MX_Controller Initialized
INFO - 2018-06-01 21:48:33 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-01 21:48:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-01 21:48:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-01 21:48:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-06-01 21:49:03 --> Config Class Initialized
INFO - 2018-06-01 21:49:03 --> Hooks Class Initialized
DEBUG - 2018-06-01 21:49:03 --> UTF-8 Support Enabled
INFO - 2018-06-01 21:49:03 --> Utf8 Class Initialized
INFO - 2018-06-01 21:49:03 --> URI Class Initialized
DEBUG - 2018-06-01 21:49:03 --> No URI present. Default controller set.
INFO - 2018-06-01 21:49:03 --> Router Class Initialized
INFO - 2018-06-01 21:49:03 --> Output Class Initialized
INFO - 2018-06-01 21:49:03 --> Security Class Initialized
DEBUG - 2018-06-01 21:49:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 21:49:03 --> Input Class Initialized
INFO - 2018-06-01 21:49:03 --> Language Class Initialized
INFO - 2018-06-01 21:49:03 --> Language Class Initialized
INFO - 2018-06-01 21:49:03 --> Config Class Initialized
INFO - 2018-06-01 21:49:03 --> Loader Class Initialized
DEBUG - 2018-06-01 21:49:03 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-01 21:49:03 --> Helper loaded: url_helper
INFO - 2018-06-01 21:49:03 --> Helper loaded: form_helper
INFO - 2018-06-01 21:49:03 --> Helper loaded: date_helper
INFO - 2018-06-01 21:49:03 --> Helper loaded: util_helper
INFO - 2018-06-01 21:49:03 --> Helper loaded: text_helper
INFO - 2018-06-01 21:49:03 --> Helper loaded: string_helper
INFO - 2018-06-01 21:49:03 --> Database Driver Class Initialized
DEBUG - 2018-06-01 21:49:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-01 21:49:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-01 21:49:03 --> Email Class Initialized
INFO - 2018-06-01 21:49:03 --> Controller Class Initialized
DEBUG - 2018-06-01 21:49:03 --> Home MX_Controller Initialized
DEBUG - 2018-06-01 21:49:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-01 21:49:04 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-01 21:49:04 --> Login MX_Controller Initialized
INFO - 2018-06-01 21:49:04 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-01 21:49:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-01 21:49:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-01 21:49:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-06-01 21:49:30 --> Config Class Initialized
INFO - 2018-06-01 21:49:30 --> Hooks Class Initialized
DEBUG - 2018-06-01 21:49:30 --> UTF-8 Support Enabled
INFO - 2018-06-01 21:49:30 --> Utf8 Class Initialized
INFO - 2018-06-01 21:49:30 --> URI Class Initialized
DEBUG - 2018-06-01 21:49:30 --> No URI present. Default controller set.
INFO - 2018-06-01 21:49:30 --> Router Class Initialized
INFO - 2018-06-01 21:49:30 --> Output Class Initialized
INFO - 2018-06-01 21:49:30 --> Security Class Initialized
DEBUG - 2018-06-01 21:49:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 21:49:30 --> Input Class Initialized
INFO - 2018-06-01 21:49:30 --> Language Class Initialized
INFO - 2018-06-01 21:49:30 --> Language Class Initialized
INFO - 2018-06-01 21:49:30 --> Config Class Initialized
INFO - 2018-06-01 21:49:30 --> Loader Class Initialized
DEBUG - 2018-06-01 21:49:30 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-01 21:49:30 --> Helper loaded: url_helper
INFO - 2018-06-01 21:49:30 --> Helper loaded: form_helper
INFO - 2018-06-01 21:49:30 --> Helper loaded: date_helper
INFO - 2018-06-01 21:49:30 --> Helper loaded: util_helper
INFO - 2018-06-01 21:49:30 --> Helper loaded: text_helper
INFO - 2018-06-01 21:49:30 --> Helper loaded: string_helper
INFO - 2018-06-01 21:49:30 --> Database Driver Class Initialized
DEBUG - 2018-06-01 21:49:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-01 21:49:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-01 21:49:30 --> Email Class Initialized
INFO - 2018-06-01 21:49:30 --> Controller Class Initialized
DEBUG - 2018-06-01 21:49:31 --> Home MX_Controller Initialized
DEBUG - 2018-06-01 21:49:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-01 21:49:31 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-01 21:49:31 --> Login MX_Controller Initialized
INFO - 2018-06-01 21:49:31 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-01 21:49:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-01 21:49:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
ERROR - 2018-06-01 21:49:31 --> Severity: error --> Exception: syntax error, unexpected '=' E:\xampp\htdocs\consulting\application\modules\home\views\login.php 58
INFO - 2018-06-01 21:49:43 --> Config Class Initialized
INFO - 2018-06-01 21:49:43 --> Hooks Class Initialized
DEBUG - 2018-06-01 21:49:43 --> UTF-8 Support Enabled
INFO - 2018-06-01 21:49:43 --> Utf8 Class Initialized
INFO - 2018-06-01 21:49:43 --> URI Class Initialized
DEBUG - 2018-06-01 21:49:43 --> No URI present. Default controller set.
INFO - 2018-06-01 21:49:43 --> Router Class Initialized
INFO - 2018-06-01 21:49:43 --> Output Class Initialized
INFO - 2018-06-01 21:49:43 --> Security Class Initialized
DEBUG - 2018-06-01 21:49:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 21:49:43 --> Input Class Initialized
INFO - 2018-06-01 21:49:43 --> Language Class Initialized
INFO - 2018-06-01 21:49:43 --> Language Class Initialized
INFO - 2018-06-01 21:49:43 --> Config Class Initialized
INFO - 2018-06-01 21:49:43 --> Loader Class Initialized
DEBUG - 2018-06-01 21:49:43 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-01 21:49:43 --> Helper loaded: url_helper
INFO - 2018-06-01 21:49:43 --> Helper loaded: form_helper
INFO - 2018-06-01 21:49:43 --> Helper loaded: date_helper
INFO - 2018-06-01 21:49:43 --> Helper loaded: util_helper
INFO - 2018-06-01 21:49:43 --> Helper loaded: text_helper
INFO - 2018-06-01 21:49:43 --> Helper loaded: string_helper
INFO - 2018-06-01 21:49:43 --> Database Driver Class Initialized
DEBUG - 2018-06-01 21:49:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-01 21:49:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-01 21:49:43 --> Email Class Initialized
INFO - 2018-06-01 21:49:43 --> Controller Class Initialized
DEBUG - 2018-06-01 21:49:43 --> Home MX_Controller Initialized
DEBUG - 2018-06-01 21:49:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-01 21:49:44 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-01 21:49:44 --> Login MX_Controller Initialized
INFO - 2018-06-01 21:49:44 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-01 21:49:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-01 21:49:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-01 21:49:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-06-01 21:50:11 --> Config Class Initialized
INFO - 2018-06-01 21:50:11 --> Hooks Class Initialized
DEBUG - 2018-06-01 21:50:11 --> UTF-8 Support Enabled
INFO - 2018-06-01 21:50:11 --> Utf8 Class Initialized
INFO - 2018-06-01 21:50:11 --> URI Class Initialized
DEBUG - 2018-06-01 21:50:11 --> No URI present. Default controller set.
INFO - 2018-06-01 21:50:11 --> Router Class Initialized
INFO - 2018-06-01 21:50:11 --> Output Class Initialized
INFO - 2018-06-01 21:50:11 --> Security Class Initialized
DEBUG - 2018-06-01 21:50:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 21:50:11 --> Input Class Initialized
INFO - 2018-06-01 21:50:11 --> Language Class Initialized
INFO - 2018-06-01 21:50:11 --> Language Class Initialized
INFO - 2018-06-01 21:50:11 --> Config Class Initialized
INFO - 2018-06-01 21:50:11 --> Loader Class Initialized
DEBUG - 2018-06-01 21:50:11 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-01 21:50:11 --> Helper loaded: url_helper
INFO - 2018-06-01 21:50:11 --> Helper loaded: form_helper
INFO - 2018-06-01 21:50:11 --> Helper loaded: date_helper
INFO - 2018-06-01 21:50:11 --> Helper loaded: util_helper
INFO - 2018-06-01 21:50:11 --> Helper loaded: text_helper
INFO - 2018-06-01 21:50:11 --> Helper loaded: string_helper
INFO - 2018-06-01 21:50:11 --> Database Driver Class Initialized
DEBUG - 2018-06-01 21:50:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-01 21:50:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-01 21:50:11 --> Email Class Initialized
INFO - 2018-06-01 21:50:11 --> Controller Class Initialized
DEBUG - 2018-06-01 21:50:11 --> Home MX_Controller Initialized
DEBUG - 2018-06-01 21:50:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-01 21:50:11 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-01 21:50:11 --> Login MX_Controller Initialized
INFO - 2018-06-01 21:50:11 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-01 21:50:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-01 21:50:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-01 21:50:14 --> Config Class Initialized
INFO - 2018-06-01 21:50:14 --> Hooks Class Initialized
DEBUG - 2018-06-01 21:50:14 --> UTF-8 Support Enabled
INFO - 2018-06-01 21:50:14 --> Utf8 Class Initialized
INFO - 2018-06-01 21:50:14 --> URI Class Initialized
DEBUG - 2018-06-01 21:50:14 --> No URI present. Default controller set.
INFO - 2018-06-01 21:50:14 --> Router Class Initialized
INFO - 2018-06-01 21:50:14 --> Output Class Initialized
INFO - 2018-06-01 21:50:14 --> Security Class Initialized
DEBUG - 2018-06-01 21:50:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 21:50:14 --> Input Class Initialized
INFO - 2018-06-01 21:50:14 --> Language Class Initialized
INFO - 2018-06-01 21:50:14 --> Language Class Initialized
INFO - 2018-06-01 21:50:14 --> Config Class Initialized
INFO - 2018-06-01 21:50:14 --> Loader Class Initialized
DEBUG - 2018-06-01 21:50:14 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-01 21:50:15 --> Helper loaded: url_helper
INFO - 2018-06-01 21:50:15 --> Helper loaded: form_helper
INFO - 2018-06-01 21:50:15 --> Helper loaded: date_helper
INFO - 2018-06-01 21:50:15 --> Helper loaded: util_helper
INFO - 2018-06-01 21:50:15 --> Helper loaded: text_helper
INFO - 2018-06-01 21:50:15 --> Helper loaded: string_helper
INFO - 2018-06-01 21:50:15 --> Database Driver Class Initialized
DEBUG - 2018-06-01 21:50:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-01 21:50:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-01 21:50:15 --> Email Class Initialized
INFO - 2018-06-01 21:50:15 --> Controller Class Initialized
DEBUG - 2018-06-01 21:50:15 --> Home MX_Controller Initialized
DEBUG - 2018-06-01 21:50:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-01 21:50:15 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-01 21:50:15 --> Login MX_Controller Initialized
INFO - 2018-06-01 21:50:15 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-01 21:50:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-01 21:50:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-01 21:50:28 --> Config Class Initialized
INFO - 2018-06-01 21:50:28 --> Hooks Class Initialized
DEBUG - 2018-06-01 21:50:28 --> UTF-8 Support Enabled
INFO - 2018-06-01 21:50:28 --> Utf8 Class Initialized
INFO - 2018-06-01 21:50:28 --> URI Class Initialized
DEBUG - 2018-06-01 21:50:28 --> No URI present. Default controller set.
INFO - 2018-06-01 21:50:28 --> Router Class Initialized
INFO - 2018-06-01 21:50:28 --> Output Class Initialized
INFO - 2018-06-01 21:50:28 --> Security Class Initialized
DEBUG - 2018-06-01 21:50:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 21:50:29 --> Input Class Initialized
INFO - 2018-06-01 21:50:29 --> Language Class Initialized
INFO - 2018-06-01 21:50:29 --> Language Class Initialized
INFO - 2018-06-01 21:50:29 --> Config Class Initialized
INFO - 2018-06-01 21:50:29 --> Loader Class Initialized
DEBUG - 2018-06-01 21:50:29 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-01 21:50:29 --> Helper loaded: url_helper
INFO - 2018-06-01 21:50:29 --> Helper loaded: form_helper
INFO - 2018-06-01 21:50:29 --> Helper loaded: date_helper
INFO - 2018-06-01 21:50:29 --> Helper loaded: util_helper
INFO - 2018-06-01 21:50:29 --> Helper loaded: text_helper
INFO - 2018-06-01 21:50:29 --> Helper loaded: string_helper
INFO - 2018-06-01 21:50:29 --> Database Driver Class Initialized
DEBUG - 2018-06-01 21:50:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-01 21:50:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-01 21:50:29 --> Email Class Initialized
INFO - 2018-06-01 21:50:29 --> Controller Class Initialized
DEBUG - 2018-06-01 21:50:29 --> Home MX_Controller Initialized
DEBUG - 2018-06-01 21:50:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-01 21:50:29 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-01 21:50:29 --> Login MX_Controller Initialized
INFO - 2018-06-01 21:50:29 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-01 21:50:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-01 21:50:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-01 21:51:12 --> Config Class Initialized
INFO - 2018-06-01 21:51:12 --> Hooks Class Initialized
DEBUG - 2018-06-01 21:51:12 --> UTF-8 Support Enabled
INFO - 2018-06-01 21:51:13 --> Utf8 Class Initialized
INFO - 2018-06-01 21:51:13 --> URI Class Initialized
DEBUG - 2018-06-01 21:51:13 --> No URI present. Default controller set.
INFO - 2018-06-01 21:51:13 --> Router Class Initialized
INFO - 2018-06-01 21:51:13 --> Output Class Initialized
INFO - 2018-06-01 21:51:13 --> Security Class Initialized
DEBUG - 2018-06-01 21:51:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 21:51:13 --> Input Class Initialized
INFO - 2018-06-01 21:51:13 --> Language Class Initialized
INFO - 2018-06-01 21:51:13 --> Language Class Initialized
INFO - 2018-06-01 21:51:13 --> Config Class Initialized
INFO - 2018-06-01 21:51:13 --> Loader Class Initialized
DEBUG - 2018-06-01 21:51:13 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-01 21:51:13 --> Helper loaded: url_helper
INFO - 2018-06-01 21:51:13 --> Helper loaded: form_helper
INFO - 2018-06-01 21:51:13 --> Helper loaded: date_helper
INFO - 2018-06-01 21:51:13 --> Helper loaded: util_helper
INFO - 2018-06-01 21:51:13 --> Helper loaded: text_helper
INFO - 2018-06-01 21:51:13 --> Helper loaded: string_helper
INFO - 2018-06-01 21:51:13 --> Database Driver Class Initialized
DEBUG - 2018-06-01 21:51:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-01 21:51:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-01 21:51:13 --> Email Class Initialized
INFO - 2018-06-01 21:51:13 --> Controller Class Initialized
DEBUG - 2018-06-01 21:51:13 --> Home MX_Controller Initialized
DEBUG - 2018-06-01 21:51:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-01 21:51:13 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-01 21:51:13 --> Login MX_Controller Initialized
INFO - 2018-06-01 21:51:13 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-01 21:51:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-01 21:51:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
ERROR - 2018-06-01 21:51:13 --> Severity: error --> Exception: Too few arguments to function CI_URI::segment(), 0 passed in E:\xampp\htdocs\consulting\application\modules\home\views\login.php on line 57 and at least 1 expected E:\xampp\htdocs\consulting\system\core\URI.php 344
INFO - 2018-06-01 21:51:37 --> Config Class Initialized
INFO - 2018-06-01 21:51:37 --> Hooks Class Initialized
DEBUG - 2018-06-01 21:51:37 --> UTF-8 Support Enabled
INFO - 2018-06-01 21:51:37 --> Utf8 Class Initialized
INFO - 2018-06-01 21:51:37 --> URI Class Initialized
DEBUG - 2018-06-01 21:51:37 --> No URI present. Default controller set.
INFO - 2018-06-01 21:51:37 --> Router Class Initialized
INFO - 2018-06-01 21:51:37 --> Output Class Initialized
INFO - 2018-06-01 21:51:37 --> Security Class Initialized
DEBUG - 2018-06-01 21:51:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 21:51:37 --> Input Class Initialized
INFO - 2018-06-01 21:51:37 --> Language Class Initialized
INFO - 2018-06-01 21:51:37 --> Language Class Initialized
INFO - 2018-06-01 21:51:37 --> Config Class Initialized
INFO - 2018-06-01 21:51:37 --> Loader Class Initialized
DEBUG - 2018-06-01 21:51:37 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-01 21:51:37 --> Helper loaded: url_helper
INFO - 2018-06-01 21:51:37 --> Helper loaded: form_helper
INFO - 2018-06-01 21:51:37 --> Helper loaded: date_helper
INFO - 2018-06-01 21:51:37 --> Helper loaded: util_helper
INFO - 2018-06-01 21:51:37 --> Helper loaded: text_helper
INFO - 2018-06-01 21:51:37 --> Helper loaded: string_helper
INFO - 2018-06-01 21:51:37 --> Database Driver Class Initialized
DEBUG - 2018-06-01 21:51:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-01 21:51:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-01 21:51:37 --> Email Class Initialized
INFO - 2018-06-01 21:51:37 --> Controller Class Initialized
DEBUG - 2018-06-01 21:51:37 --> Home MX_Controller Initialized
DEBUG - 2018-06-01 21:51:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-01 21:51:37 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-01 21:51:37 --> Login MX_Controller Initialized
INFO - 2018-06-01 21:51:37 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-01 21:51:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-01 21:51:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
ERROR - 2018-06-01 21:51:37 --> Severity: error --> Exception: Too few arguments to function CI_URI::segment(), 0 passed in E:\xampp\htdocs\consulting\application\modules\home\views\login.php on line 57 and at least 1 expected E:\xampp\htdocs\consulting\system\core\URI.php 344
INFO - 2018-06-01 21:52:40 --> Config Class Initialized
INFO - 2018-06-01 21:52:40 --> Hooks Class Initialized
DEBUG - 2018-06-01 21:52:40 --> UTF-8 Support Enabled
INFO - 2018-06-01 21:52:40 --> Utf8 Class Initialized
INFO - 2018-06-01 21:52:40 --> URI Class Initialized
DEBUG - 2018-06-01 21:52:40 --> No URI present. Default controller set.
INFO - 2018-06-01 21:52:40 --> Router Class Initialized
INFO - 2018-06-01 21:52:40 --> Output Class Initialized
INFO - 2018-06-01 21:52:40 --> Security Class Initialized
DEBUG - 2018-06-01 21:52:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 21:52:40 --> Input Class Initialized
INFO - 2018-06-01 21:52:40 --> Language Class Initialized
INFO - 2018-06-01 21:52:40 --> Language Class Initialized
INFO - 2018-06-01 21:52:40 --> Config Class Initialized
INFO - 2018-06-01 21:52:40 --> Loader Class Initialized
DEBUG - 2018-06-01 21:52:40 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-01 21:52:40 --> Helper loaded: url_helper
INFO - 2018-06-01 21:52:40 --> Helper loaded: form_helper
INFO - 2018-06-01 21:52:40 --> Helper loaded: date_helper
INFO - 2018-06-01 21:52:40 --> Helper loaded: util_helper
INFO - 2018-06-01 21:52:40 --> Helper loaded: text_helper
INFO - 2018-06-01 21:52:40 --> Helper loaded: string_helper
INFO - 2018-06-01 21:52:40 --> Database Driver Class Initialized
DEBUG - 2018-06-01 21:52:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-01 21:52:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-01 21:52:40 --> Email Class Initialized
INFO - 2018-06-01 21:52:40 --> Controller Class Initialized
DEBUG - 2018-06-01 21:52:40 --> Home MX_Controller Initialized
DEBUG - 2018-06-01 21:52:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-01 21:52:40 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-01 21:52:40 --> Login MX_Controller Initialized
INFO - 2018-06-01 21:52:40 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-01 21:52:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-01 21:52:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-01 21:52:46 --> Config Class Initialized
INFO - 2018-06-01 21:52:46 --> Hooks Class Initialized
DEBUG - 2018-06-01 21:52:47 --> UTF-8 Support Enabled
INFO - 2018-06-01 21:52:47 --> Utf8 Class Initialized
INFO - 2018-06-01 21:52:47 --> URI Class Initialized
INFO - 2018-06-01 21:52:47 --> Router Class Initialized
INFO - 2018-06-01 21:52:47 --> Output Class Initialized
INFO - 2018-06-01 21:52:47 --> Security Class Initialized
DEBUG - 2018-06-01 21:52:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 21:52:47 --> Input Class Initialized
INFO - 2018-06-01 21:52:47 --> Language Class Initialized
INFO - 2018-06-01 21:52:47 --> Language Class Initialized
INFO - 2018-06-01 21:52:47 --> Config Class Initialized
INFO - 2018-06-01 21:52:47 --> Loader Class Initialized
DEBUG - 2018-06-01 21:52:47 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-01 21:52:47 --> Helper loaded: url_helper
INFO - 2018-06-01 21:52:47 --> Helper loaded: form_helper
INFO - 2018-06-01 21:52:47 --> Helper loaded: date_helper
INFO - 2018-06-01 21:52:47 --> Helper loaded: util_helper
INFO - 2018-06-01 21:52:47 --> Helper loaded: text_helper
INFO - 2018-06-01 21:52:47 --> Helper loaded: string_helper
INFO - 2018-06-01 21:52:47 --> Database Driver Class Initialized
DEBUG - 2018-06-01 21:52:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-01 21:52:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-01 21:52:47 --> Email Class Initialized
INFO - 2018-06-01 21:52:47 --> Controller Class Initialized
DEBUG - 2018-06-01 21:52:47 --> Home MX_Controller Initialized
DEBUG - 2018-06-01 21:52:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-01 21:52:47 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-01 21:52:47 --> Login MX_Controller Initialized
INFO - 2018-06-01 21:52:47 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-01 21:52:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-01 21:52:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-01 21:52:51 --> Config Class Initialized
INFO - 2018-06-01 21:52:51 --> Hooks Class Initialized
DEBUG - 2018-06-01 21:52:51 --> UTF-8 Support Enabled
INFO - 2018-06-01 21:52:51 --> Utf8 Class Initialized
INFO - 2018-06-01 21:52:51 --> URI Class Initialized
INFO - 2018-06-01 21:52:51 --> Router Class Initialized
INFO - 2018-06-01 21:52:51 --> Output Class Initialized
INFO - 2018-06-01 21:52:51 --> Security Class Initialized
DEBUG - 2018-06-01 21:52:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 21:52:51 --> Input Class Initialized
INFO - 2018-06-01 21:52:51 --> Language Class Initialized
INFO - 2018-06-01 21:52:51 --> Language Class Initialized
INFO - 2018-06-01 21:52:51 --> Config Class Initialized
INFO - 2018-06-01 21:52:51 --> Loader Class Initialized
DEBUG - 2018-06-01 21:52:51 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-01 21:52:51 --> Helper loaded: url_helper
INFO - 2018-06-01 21:52:51 --> Helper loaded: form_helper
INFO - 2018-06-01 21:52:51 --> Helper loaded: date_helper
INFO - 2018-06-01 21:52:51 --> Helper loaded: util_helper
INFO - 2018-06-01 21:52:51 --> Helper loaded: text_helper
INFO - 2018-06-01 21:52:51 --> Helper loaded: string_helper
INFO - 2018-06-01 21:52:51 --> Database Driver Class Initialized
INFO - 2018-06-01 21:52:51 --> Config Class Initialized
INFO - 2018-06-01 21:52:51 --> Hooks Class Initialized
DEBUG - 2018-06-01 21:52:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-01 21:52:51 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-06-01 21:52:51 --> UTF-8 Support Enabled
INFO - 2018-06-01 21:52:51 --> Utf8 Class Initialized
INFO - 2018-06-01 21:52:51 --> Email Class Initialized
INFO - 2018-06-01 21:52:51 --> Controller Class Initialized
INFO - 2018-06-01 21:52:51 --> URI Class Initialized
DEBUG - 2018-06-01 21:52:51 --> Home MX_Controller Initialized
INFO - 2018-06-01 21:52:51 --> Router Class Initialized
DEBUG - 2018-06-01 21:52:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-06-01 21:52:51 --> Output Class Initialized
INFO - 2018-06-01 21:52:51 --> Security Class Initialized
DEBUG - 2018-06-01 21:52:51 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-01 21:52:51 --> Login MX_Controller Initialized
DEBUG - 2018-06-01 21:52:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 21:52:51 --> Input Class Initialized
INFO - 2018-06-01 21:52:51 --> Language file loaded: language/english/data_lang.php
INFO - 2018-06-01 21:52:51 --> Language Class Initialized
DEBUG - 2018-06-01 21:52:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-01 21:52:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-01 21:52:51 --> Language Class Initialized
INFO - 2018-06-01 21:52:51 --> Config Class Initialized
INFO - 2018-06-01 21:52:51 --> Loader Class Initialized
DEBUG - 2018-06-01 21:52:51 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-01 21:52:51 --> Helper loaded: url_helper
INFO - 2018-06-01 21:52:51 --> Helper loaded: form_helper
INFO - 2018-06-01 21:52:51 --> Helper loaded: date_helper
INFO - 2018-06-01 21:52:51 --> Helper loaded: util_helper
INFO - 2018-06-01 21:52:51 --> Helper loaded: text_helper
INFO - 2018-06-01 21:52:51 --> Helper loaded: string_helper
INFO - 2018-06-01 21:52:51 --> Database Driver Class Initialized
DEBUG - 2018-06-01 21:52:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-01 21:52:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-01 21:52:51 --> Email Class Initialized
INFO - 2018-06-01 21:52:51 --> Controller Class Initialized
DEBUG - 2018-06-01 21:52:51 --> Home MX_Controller Initialized
DEBUG - 2018-06-01 21:52:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-01 21:52:51 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-01 21:52:51 --> Login MX_Controller Initialized
INFO - 2018-06-01 21:52:51 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-01 21:52:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-01 21:52:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-01 21:53:40 --> Config Class Initialized
INFO - 2018-06-01 21:53:40 --> Hooks Class Initialized
DEBUG - 2018-06-01 21:53:40 --> UTF-8 Support Enabled
INFO - 2018-06-01 21:53:40 --> Utf8 Class Initialized
INFO - 2018-06-01 21:53:40 --> URI Class Initialized
DEBUG - 2018-06-01 21:53:40 --> No URI present. Default controller set.
INFO - 2018-06-01 21:53:40 --> Router Class Initialized
INFO - 2018-06-01 21:53:40 --> Output Class Initialized
INFO - 2018-06-01 21:53:40 --> Security Class Initialized
DEBUG - 2018-06-01 21:53:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 21:53:40 --> Input Class Initialized
INFO - 2018-06-01 21:53:40 --> Language Class Initialized
INFO - 2018-06-01 21:53:40 --> Language Class Initialized
INFO - 2018-06-01 21:53:40 --> Config Class Initialized
INFO - 2018-06-01 21:53:40 --> Loader Class Initialized
DEBUG - 2018-06-01 21:53:40 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-01 21:53:40 --> Helper loaded: url_helper
INFO - 2018-06-01 21:53:40 --> Helper loaded: form_helper
INFO - 2018-06-01 21:53:40 --> Helper loaded: date_helper
INFO - 2018-06-01 21:53:40 --> Helper loaded: util_helper
INFO - 2018-06-01 21:53:40 --> Helper loaded: text_helper
INFO - 2018-06-01 21:53:40 --> Helper loaded: string_helper
INFO - 2018-06-01 21:53:40 --> Database Driver Class Initialized
DEBUG - 2018-06-01 21:53:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-01 21:53:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-01 21:53:40 --> Email Class Initialized
INFO - 2018-06-01 21:53:40 --> Controller Class Initialized
DEBUG - 2018-06-01 21:53:40 --> Home MX_Controller Initialized
DEBUG - 2018-06-01 21:53:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-01 21:53:40 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-01 21:53:40 --> Login MX_Controller Initialized
INFO - 2018-06-01 21:53:40 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-01 21:53:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-01 21:53:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-01 21:53:43 --> Config Class Initialized
INFO - 2018-06-01 21:53:43 --> Hooks Class Initialized
DEBUG - 2018-06-01 21:53:43 --> UTF-8 Support Enabled
INFO - 2018-06-01 21:53:43 --> Utf8 Class Initialized
INFO - 2018-06-01 21:53:43 --> URI Class Initialized
DEBUG - 2018-06-01 21:53:43 --> No URI present. Default controller set.
INFO - 2018-06-01 21:53:43 --> Router Class Initialized
INFO - 2018-06-01 21:53:43 --> Output Class Initialized
INFO - 2018-06-01 21:53:43 --> Security Class Initialized
DEBUG - 2018-06-01 21:53:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 21:53:43 --> Input Class Initialized
INFO - 2018-06-01 21:53:43 --> Language Class Initialized
INFO - 2018-06-01 21:53:43 --> Language Class Initialized
INFO - 2018-06-01 21:53:43 --> Config Class Initialized
INFO - 2018-06-01 21:53:43 --> Loader Class Initialized
DEBUG - 2018-06-01 21:53:43 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-01 21:53:43 --> Helper loaded: url_helper
INFO - 2018-06-01 21:53:43 --> Helper loaded: form_helper
INFO - 2018-06-01 21:53:43 --> Helper loaded: date_helper
INFO - 2018-06-01 21:53:43 --> Helper loaded: util_helper
INFO - 2018-06-01 21:53:43 --> Helper loaded: text_helper
INFO - 2018-06-01 21:53:43 --> Helper loaded: string_helper
INFO - 2018-06-01 21:53:43 --> Database Driver Class Initialized
DEBUG - 2018-06-01 21:53:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-01 21:53:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-01 21:53:43 --> Email Class Initialized
INFO - 2018-06-01 21:53:43 --> Controller Class Initialized
DEBUG - 2018-06-01 21:53:43 --> Home MX_Controller Initialized
DEBUG - 2018-06-01 21:53:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-01 21:53:43 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-01 21:53:43 --> Login MX_Controller Initialized
INFO - 2018-06-01 21:53:43 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-01 21:53:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-01 21:53:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-01 21:53:48 --> Config Class Initialized
INFO - 2018-06-01 21:53:48 --> Hooks Class Initialized
DEBUG - 2018-06-01 21:53:48 --> UTF-8 Support Enabled
INFO - 2018-06-01 21:53:48 --> Utf8 Class Initialized
INFO - 2018-06-01 21:53:48 --> URI Class Initialized
INFO - 2018-06-01 21:53:48 --> Router Class Initialized
INFO - 2018-06-01 21:53:48 --> Output Class Initialized
INFO - 2018-06-01 21:53:48 --> Security Class Initialized
DEBUG - 2018-06-01 21:53:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 21:53:48 --> Input Class Initialized
INFO - 2018-06-01 21:53:48 --> Language Class Initialized
INFO - 2018-06-01 21:53:48 --> Language Class Initialized
INFO - 2018-06-01 21:53:48 --> Config Class Initialized
INFO - 2018-06-01 21:53:48 --> Loader Class Initialized
DEBUG - 2018-06-01 21:53:48 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-01 21:53:48 --> Helper loaded: url_helper
INFO - 2018-06-01 21:53:48 --> Helper loaded: form_helper
INFO - 2018-06-01 21:53:48 --> Helper loaded: date_helper
INFO - 2018-06-01 21:53:48 --> Helper loaded: util_helper
INFO - 2018-06-01 21:53:48 --> Helper loaded: text_helper
INFO - 2018-06-01 21:53:48 --> Helper loaded: string_helper
INFO - 2018-06-01 21:53:48 --> Database Driver Class Initialized
DEBUG - 2018-06-01 21:53:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-01 21:53:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-01 21:53:48 --> Email Class Initialized
INFO - 2018-06-01 21:53:48 --> Controller Class Initialized
DEBUG - 2018-06-01 21:53:48 --> Home MX_Controller Initialized
DEBUG - 2018-06-01 21:53:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-01 21:53:48 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-01 21:53:48 --> Login MX_Controller Initialized
INFO - 2018-06-01 21:53:48 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-01 21:53:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-01 21:53:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-01 21:54:07 --> Config Class Initialized
INFO - 2018-06-01 21:54:08 --> Hooks Class Initialized
DEBUG - 2018-06-01 21:54:08 --> UTF-8 Support Enabled
INFO - 2018-06-01 21:54:08 --> Utf8 Class Initialized
INFO - 2018-06-01 21:54:08 --> URI Class Initialized
INFO - 2018-06-01 21:54:08 --> Router Class Initialized
INFO - 2018-06-01 21:54:08 --> Output Class Initialized
INFO - 2018-06-01 21:54:08 --> Security Class Initialized
DEBUG - 2018-06-01 21:54:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 21:54:08 --> Input Class Initialized
INFO - 2018-06-01 21:54:08 --> Language Class Initialized
INFO - 2018-06-01 21:54:08 --> Language Class Initialized
INFO - 2018-06-01 21:54:08 --> Config Class Initialized
INFO - 2018-06-01 21:54:08 --> Loader Class Initialized
DEBUG - 2018-06-01 21:54:08 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-01 21:54:08 --> Helper loaded: url_helper
INFO - 2018-06-01 21:54:08 --> Helper loaded: form_helper
INFO - 2018-06-01 21:54:08 --> Helper loaded: date_helper
INFO - 2018-06-01 21:54:08 --> Helper loaded: util_helper
INFO - 2018-06-01 21:54:08 --> Helper loaded: text_helper
INFO - 2018-06-01 21:54:08 --> Helper loaded: string_helper
INFO - 2018-06-01 21:54:08 --> Database Driver Class Initialized
DEBUG - 2018-06-01 21:54:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-01 21:54:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-01 21:54:08 --> Email Class Initialized
INFO - 2018-06-01 21:54:08 --> Controller Class Initialized
DEBUG - 2018-06-01 21:54:08 --> Home MX_Controller Initialized
DEBUG - 2018-06-01 21:54:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-01 21:54:08 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-01 21:54:08 --> Login MX_Controller Initialized
INFO - 2018-06-01 21:54:08 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-01 21:54:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-01 21:54:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-01 22:43:50 --> Config Class Initialized
INFO - 2018-06-01 22:43:50 --> Hooks Class Initialized
DEBUG - 2018-06-01 22:43:50 --> UTF-8 Support Enabled
INFO - 2018-06-01 22:43:50 --> Utf8 Class Initialized
INFO - 2018-06-01 22:43:50 --> URI Class Initialized
INFO - 2018-06-01 22:43:50 --> Router Class Initialized
INFO - 2018-06-01 22:43:50 --> Output Class Initialized
INFO - 2018-06-01 22:43:50 --> Security Class Initialized
DEBUG - 2018-06-01 22:43:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 22:43:50 --> Input Class Initialized
INFO - 2018-06-01 22:43:50 --> Language Class Initialized
INFO - 2018-06-01 22:43:51 --> Language Class Initialized
INFO - 2018-06-01 22:43:51 --> Config Class Initialized
INFO - 2018-06-01 22:43:51 --> Loader Class Initialized
DEBUG - 2018-06-01 22:43:51 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-01 22:43:51 --> Helper loaded: url_helper
INFO - 2018-06-01 22:43:51 --> Helper loaded: form_helper
INFO - 2018-06-01 22:43:51 --> Helper loaded: date_helper
INFO - 2018-06-01 22:43:51 --> Helper loaded: util_helper
INFO - 2018-06-01 22:43:51 --> Helper loaded: text_helper
INFO - 2018-06-01 22:43:51 --> Helper loaded: string_helper
INFO - 2018-06-01 22:43:51 --> Database Driver Class Initialized
DEBUG - 2018-06-01 22:43:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-01 22:43:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-01 22:43:51 --> Email Class Initialized
INFO - 2018-06-01 22:43:51 --> Controller Class Initialized
DEBUG - 2018-06-01 22:43:51 --> Home MX_Controller Initialized
DEBUG - 2018-06-01 22:43:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-01 22:43:51 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-01 22:43:51 --> Login MX_Controller Initialized
INFO - 2018-06-01 22:43:51 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-01 22:43:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-01 22:43:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-01 22:43:51 --> Config Class Initialized
INFO - 2018-06-01 22:43:51 --> Hooks Class Initialized
DEBUG - 2018-06-01 22:43:51 --> UTF-8 Support Enabled
INFO - 2018-06-01 22:43:51 --> Utf8 Class Initialized
INFO - 2018-06-01 22:43:51 --> URI Class Initialized
INFO - 2018-06-01 22:43:51 --> Router Class Initialized
INFO - 2018-06-01 22:43:51 --> Output Class Initialized
INFO - 2018-06-01 22:43:51 --> Security Class Initialized
DEBUG - 2018-06-01 22:43:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-01 22:43:51 --> Input Class Initialized
INFO - 2018-06-01 22:43:51 --> Language Class Initialized
INFO - 2018-06-01 22:43:51 --> Language Class Initialized
INFO - 2018-06-01 22:43:51 --> Config Class Initialized
INFO - 2018-06-01 22:43:51 --> Loader Class Initialized
DEBUG - 2018-06-01 22:43:51 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-01 22:43:52 --> Helper loaded: url_helper
INFO - 2018-06-01 22:43:52 --> Helper loaded: form_helper
INFO - 2018-06-01 22:43:52 --> Helper loaded: date_helper
INFO - 2018-06-01 22:43:52 --> Helper loaded: util_helper
INFO - 2018-06-01 22:43:52 --> Helper loaded: text_helper
INFO - 2018-06-01 22:43:52 --> Helper loaded: string_helper
INFO - 2018-06-01 22:43:52 --> Database Driver Class Initialized
DEBUG - 2018-06-01 22:43:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-01 22:43:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-01 22:43:52 --> Email Class Initialized
INFO - 2018-06-01 22:43:52 --> Controller Class Initialized
DEBUG - 2018-06-01 22:43:52 --> Home MX_Controller Initialized
DEBUG - 2018-06-01 22:43:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-01 22:43:52 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-01 22:43:52 --> Login MX_Controller Initialized
INFO - 2018-06-01 22:43:52 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-01 22:43:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-01 22:43:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
