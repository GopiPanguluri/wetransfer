<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-06-02 05:58:03 --> Config Class Initialized
INFO - 2018-06-02 05:58:03 --> Hooks Class Initialized
DEBUG - 2018-06-02 05:58:03 --> UTF-8 Support Enabled
INFO - 2018-06-02 05:58:03 --> Utf8 Class Initialized
INFO - 2018-06-02 05:58:03 --> URI Class Initialized
INFO - 2018-06-02 05:58:03 --> Router Class Initialized
INFO - 2018-06-02 05:58:03 --> Output Class Initialized
INFO - 2018-06-02 05:58:03 --> Security Class Initialized
DEBUG - 2018-06-02 05:58:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-02 05:58:03 --> Input Class Initialized
INFO - 2018-06-02 05:58:03 --> Language Class Initialized
INFO - 2018-06-02 05:58:03 --> Language Class Initialized
INFO - 2018-06-02 05:58:03 --> Config Class Initialized
INFO - 2018-06-02 05:58:03 --> Loader Class Initialized
DEBUG - 2018-06-02 05:58:03 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-02 05:58:03 --> Helper loaded: url_helper
INFO - 2018-06-02 05:58:03 --> Helper loaded: form_helper
INFO - 2018-06-02 05:58:03 --> Helper loaded: date_helper
INFO - 2018-06-02 05:58:03 --> Helper loaded: util_helper
INFO - 2018-06-02 05:58:03 --> Helper loaded: text_helper
INFO - 2018-06-02 05:58:03 --> Helper loaded: string_helper
INFO - 2018-06-02 05:58:03 --> Database Driver Class Initialized
DEBUG - 2018-06-02 05:58:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-02 05:58:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-02 05:58:03 --> Email Class Initialized
INFO - 2018-06-02 05:58:03 --> Controller Class Initialized
DEBUG - 2018-06-02 05:58:03 --> Home MX_Controller Initialized
DEBUG - 2018-06-02 05:58:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-02 05:58:03 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-02 05:58:03 --> Login MX_Controller Initialized
INFO - 2018-06-02 05:58:03 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-02 05:58:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-02 05:58:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-02 05:58:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-06-02 05:58:04 --> Config Class Initialized
INFO - 2018-06-02 05:58:04 --> Hooks Class Initialized
DEBUG - 2018-06-02 05:58:04 --> UTF-8 Support Enabled
INFO - 2018-06-02 05:58:04 --> Utf8 Class Initialized
INFO - 2018-06-02 05:58:04 --> URI Class Initialized
INFO - 2018-06-02 05:58:04 --> Router Class Initialized
INFO - 2018-06-02 05:58:04 --> Output Class Initialized
INFO - 2018-06-02 05:58:04 --> Security Class Initialized
DEBUG - 2018-06-02 05:58:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-02 05:58:04 --> Input Class Initialized
INFO - 2018-06-02 05:58:04 --> Language Class Initialized
INFO - 2018-06-02 05:58:04 --> Language Class Initialized
INFO - 2018-06-02 05:58:04 --> Config Class Initialized
INFO - 2018-06-02 05:58:04 --> Loader Class Initialized
DEBUG - 2018-06-02 05:58:04 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-02 05:58:04 --> Helper loaded: url_helper
INFO - 2018-06-02 05:58:04 --> Helper loaded: form_helper
INFO - 2018-06-02 05:58:04 --> Helper loaded: date_helper
INFO - 2018-06-02 05:58:04 --> Helper loaded: util_helper
INFO - 2018-06-02 05:58:04 --> Helper loaded: text_helper
INFO - 2018-06-02 05:58:04 --> Helper loaded: string_helper
INFO - 2018-06-02 05:58:04 --> Database Driver Class Initialized
DEBUG - 2018-06-02 05:58:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-02 05:58:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-02 05:58:04 --> Email Class Initialized
INFO - 2018-06-02 05:58:04 --> Controller Class Initialized
DEBUG - 2018-06-02 05:58:04 --> Home MX_Controller Initialized
DEBUG - 2018-06-02 05:58:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-02 05:58:04 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-02 05:58:04 --> Login MX_Controller Initialized
INFO - 2018-06-02 05:58:05 --> Language file loaded: language/english/data_lang.php
INFO - 2018-06-02 05:58:05 --> Config Class Initialized
INFO - 2018-06-02 05:58:05 --> Hooks Class Initialized
DEBUG - 2018-06-02 05:58:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-02 05:58:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-02 05:58:05 --> UTF-8 Support Enabled
INFO - 2018-06-02 05:58:05 --> Utf8 Class Initialized
DEBUG - 2018-06-02 05:58:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-06-02 05:58:05 --> URI Class Initialized
DEBUG - 2018-06-02 05:58:05 --> No URI present. Default controller set.
INFO - 2018-06-02 05:58:05 --> Router Class Initialized
INFO - 2018-06-02 05:58:05 --> Output Class Initialized
INFO - 2018-06-02 05:58:05 --> Security Class Initialized
DEBUG - 2018-06-02 05:58:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-02 05:58:05 --> Input Class Initialized
INFO - 2018-06-02 05:58:05 --> Language Class Initialized
INFO - 2018-06-02 05:58:05 --> Language Class Initialized
INFO - 2018-06-02 05:58:05 --> Config Class Initialized
INFO - 2018-06-02 05:58:05 --> Loader Class Initialized
DEBUG - 2018-06-02 05:58:05 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-02 05:58:05 --> Helper loaded: url_helper
INFO - 2018-06-02 05:58:05 --> Helper loaded: form_helper
INFO - 2018-06-02 05:58:05 --> Helper loaded: date_helper
INFO - 2018-06-02 05:58:05 --> Helper loaded: util_helper
INFO - 2018-06-02 05:58:05 --> Helper loaded: text_helper
INFO - 2018-06-02 05:58:05 --> Helper loaded: string_helper
INFO - 2018-06-02 05:58:05 --> Database Driver Class Initialized
DEBUG - 2018-06-02 05:58:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-02 05:58:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-02 05:58:05 --> Email Class Initialized
INFO - 2018-06-02 05:58:05 --> Controller Class Initialized
DEBUG - 2018-06-02 05:58:05 --> Home MX_Controller Initialized
DEBUG - 2018-06-02 05:58:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-02 05:58:05 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-02 05:58:05 --> Login MX_Controller Initialized
INFO - 2018-06-02 05:58:05 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-02 05:58:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-02 05:58:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-02 05:58:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-06-02 05:58:05 --> Config Class Initialized
INFO - 2018-06-02 05:58:05 --> Hooks Class Initialized
DEBUG - 2018-06-02 05:58:05 --> UTF-8 Support Enabled
INFO - 2018-06-02 05:58:06 --> Utf8 Class Initialized
INFO - 2018-06-02 05:58:06 --> URI Class Initialized
DEBUG - 2018-06-02 05:58:06 --> No URI present. Default controller set.
INFO - 2018-06-02 05:58:06 --> Router Class Initialized
INFO - 2018-06-02 05:58:06 --> Output Class Initialized
INFO - 2018-06-02 05:58:06 --> Security Class Initialized
DEBUG - 2018-06-02 05:58:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-02 05:58:06 --> Input Class Initialized
INFO - 2018-06-02 05:58:06 --> Language Class Initialized
INFO - 2018-06-02 05:58:06 --> Language Class Initialized
INFO - 2018-06-02 05:58:06 --> Config Class Initialized
INFO - 2018-06-02 05:58:06 --> Loader Class Initialized
DEBUG - 2018-06-02 05:58:06 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-02 05:58:06 --> Helper loaded: url_helper
INFO - 2018-06-02 05:58:06 --> Helper loaded: form_helper
INFO - 2018-06-02 05:58:06 --> Helper loaded: date_helper
INFO - 2018-06-02 05:58:06 --> Helper loaded: util_helper
INFO - 2018-06-02 05:58:06 --> Helper loaded: text_helper
INFO - 2018-06-02 05:58:06 --> Helper loaded: string_helper
INFO - 2018-06-02 05:58:06 --> Database Driver Class Initialized
DEBUG - 2018-06-02 05:58:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-02 05:58:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-02 05:58:06 --> Email Class Initialized
INFO - 2018-06-02 05:58:06 --> Controller Class Initialized
DEBUG - 2018-06-02 05:58:06 --> Home MX_Controller Initialized
DEBUG - 2018-06-02 05:58:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-02 05:58:06 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-02 05:58:06 --> Login MX_Controller Initialized
INFO - 2018-06-02 05:58:06 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-02 05:58:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-02 05:58:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-02 05:58:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
