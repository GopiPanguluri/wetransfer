<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-06-04 22:42:14 --> Config Class Initialized
INFO - 2018-06-04 22:42:14 --> Hooks Class Initialized
DEBUG - 2018-06-04 22:42:14 --> UTF-8 Support Enabled
INFO - 2018-06-04 22:42:14 --> Utf8 Class Initialized
INFO - 2018-06-04 22:42:14 --> URI Class Initialized
INFO - 2018-06-04 22:42:14 --> Router Class Initialized
INFO - 2018-06-04 22:42:15 --> Output Class Initialized
INFO - 2018-06-04 22:42:15 --> Security Class Initialized
DEBUG - 2018-06-04 22:42:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-04 22:42:15 --> Input Class Initialized
INFO - 2018-06-04 22:42:15 --> Language Class Initialized
INFO - 2018-06-04 22:42:15 --> Language Class Initialized
INFO - 2018-06-04 22:42:15 --> Config Class Initialized
INFO - 2018-06-04 22:42:15 --> Loader Class Initialized
DEBUG - 2018-06-04 22:42:15 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-04 22:42:15 --> Helper loaded: url_helper
INFO - 2018-06-04 22:42:15 --> Helper loaded: form_helper
INFO - 2018-06-04 22:42:15 --> Helper loaded: date_helper
INFO - 2018-06-04 22:42:15 --> Helper loaded: util_helper
INFO - 2018-06-04 22:42:15 --> Helper loaded: text_helper
INFO - 2018-06-04 22:42:15 --> Helper loaded: string_helper
INFO - 2018-06-04 22:42:16 --> Database Driver Class Initialized
DEBUG - 2018-06-04 22:42:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-04 22:42:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-04 22:42:19 --> Email Class Initialized
INFO - 2018-06-04 22:42:19 --> Controller Class Initialized
DEBUG - 2018-06-04 22:42:19 --> Home MX_Controller Initialized
DEBUG - 2018-06-04 22:42:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-04 22:42:19 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-04 22:42:19 --> Login MX_Controller Initialized
INFO - 2018-06-04 22:42:19 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-04 22:42:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-04 22:42:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-04 22:42:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-06-04 22:42:21 --> Config Class Initialized
INFO - 2018-06-04 22:42:21 --> Hooks Class Initialized
DEBUG - 2018-06-04 22:42:21 --> UTF-8 Support Enabled
INFO - 2018-06-04 22:42:21 --> Utf8 Class Initialized
INFO - 2018-06-04 22:42:21 --> URI Class Initialized
DEBUG - 2018-06-04 22:42:21 --> No URI present. Default controller set.
INFO - 2018-06-04 22:42:21 --> Router Class Initialized
INFO - 2018-06-04 22:42:21 --> Output Class Initialized
INFO - 2018-06-04 22:42:21 --> Security Class Initialized
DEBUG - 2018-06-04 22:42:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-04 22:42:21 --> Input Class Initialized
INFO - 2018-06-04 22:42:21 --> Language Class Initialized
INFO - 2018-06-04 22:42:21 --> Language Class Initialized
INFO - 2018-06-04 22:42:21 --> Config Class Initialized
INFO - 2018-06-04 22:42:21 --> Loader Class Initialized
DEBUG - 2018-06-04 22:42:21 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-04 22:42:21 --> Helper loaded: url_helper
INFO - 2018-06-04 22:42:22 --> Helper loaded: form_helper
INFO - 2018-06-04 22:42:22 --> Helper loaded: date_helper
INFO - 2018-06-04 22:42:22 --> Helper loaded: util_helper
INFO - 2018-06-04 22:42:22 --> Helper loaded: text_helper
INFO - 2018-06-04 22:42:22 --> Helper loaded: string_helper
INFO - 2018-06-04 22:42:22 --> Database Driver Class Initialized
DEBUG - 2018-06-04 22:42:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-04 22:42:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-04 22:42:22 --> Email Class Initialized
INFO - 2018-06-04 22:42:22 --> Controller Class Initialized
DEBUG - 2018-06-04 22:42:22 --> Home MX_Controller Initialized
DEBUG - 2018-06-04 22:42:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-04 22:42:22 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-04 22:42:22 --> Login MX_Controller Initialized
INFO - 2018-06-04 22:42:22 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-04 22:42:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-04 22:42:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-04 22:42:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-06-04 22:42:42 --> Config Class Initialized
INFO - 2018-06-04 22:42:42 --> Hooks Class Initialized
DEBUG - 2018-06-04 22:42:42 --> UTF-8 Support Enabled
INFO - 2018-06-04 22:42:42 --> Utf8 Class Initialized
INFO - 2018-06-04 22:42:42 --> URI Class Initialized
DEBUG - 2018-06-04 22:42:42 --> No URI present. Default controller set.
INFO - 2018-06-04 22:42:42 --> Router Class Initialized
INFO - 2018-06-04 22:42:42 --> Output Class Initialized
INFO - 2018-06-04 22:42:42 --> Security Class Initialized
DEBUG - 2018-06-04 22:42:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-04 22:42:42 --> Input Class Initialized
INFO - 2018-06-04 22:42:42 --> Language Class Initialized
INFO - 2018-06-04 22:42:42 --> Language Class Initialized
INFO - 2018-06-04 22:42:42 --> Config Class Initialized
INFO - 2018-06-04 22:42:42 --> Loader Class Initialized
DEBUG - 2018-06-04 22:42:42 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-04 22:42:42 --> Helper loaded: url_helper
INFO - 2018-06-04 22:42:42 --> Helper loaded: form_helper
INFO - 2018-06-04 22:42:42 --> Helper loaded: date_helper
INFO - 2018-06-04 22:42:42 --> Helper loaded: util_helper
INFO - 2018-06-04 22:42:42 --> Helper loaded: text_helper
INFO - 2018-06-04 22:42:42 --> Helper loaded: string_helper
INFO - 2018-06-04 22:42:42 --> Database Driver Class Initialized
DEBUG - 2018-06-04 22:42:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-04 22:42:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-04 22:42:42 --> Email Class Initialized
INFO - 2018-06-04 22:42:42 --> Controller Class Initialized
DEBUG - 2018-06-04 22:42:42 --> Home MX_Controller Initialized
DEBUG - 2018-06-04 22:42:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-04 22:42:42 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-04 22:42:42 --> Login MX_Controller Initialized
INFO - 2018-06-04 22:42:43 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-04 22:42:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-04 22:42:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-04 22:42:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-06-04 23:44:49 --> Config Class Initialized
INFO - 2018-06-04 23:44:49 --> Hooks Class Initialized
DEBUG - 2018-06-04 23:44:49 --> UTF-8 Support Enabled
INFO - 2018-06-04 23:44:49 --> Utf8 Class Initialized
INFO - 2018-06-04 23:44:49 --> URI Class Initialized
INFO - 2018-06-04 23:44:49 --> Router Class Initialized
INFO - 2018-06-04 23:44:49 --> Output Class Initialized
INFO - 2018-06-04 23:44:49 --> Security Class Initialized
DEBUG - 2018-06-04 23:44:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-04 23:44:49 --> Input Class Initialized
INFO - 2018-06-04 23:44:49 --> Language Class Initialized
INFO - 2018-06-04 23:44:49 --> Language Class Initialized
INFO - 2018-06-04 23:44:49 --> Config Class Initialized
INFO - 2018-06-04 23:44:49 --> Loader Class Initialized
DEBUG - 2018-06-04 23:44:49 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-04 23:44:49 --> Helper loaded: url_helper
INFO - 2018-06-04 23:44:49 --> Helper loaded: form_helper
INFO - 2018-06-04 23:44:49 --> Helper loaded: date_helper
INFO - 2018-06-04 23:44:49 --> Helper loaded: util_helper
INFO - 2018-06-04 23:44:49 --> Helper loaded: text_helper
INFO - 2018-06-04 23:44:49 --> Helper loaded: string_helper
INFO - 2018-06-04 23:44:49 --> Database Driver Class Initialized
DEBUG - 2018-06-04 23:44:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-04 23:44:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-04 23:44:49 --> Email Class Initialized
INFO - 2018-06-04 23:44:49 --> Controller Class Initialized
DEBUG - 2018-06-04 23:44:49 --> Home MX_Controller Initialized
DEBUG - 2018-06-04 23:44:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-04 23:44:49 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-04 23:44:49 --> Login MX_Controller Initialized
INFO - 2018-06-04 23:44:49 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-04 23:44:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-04 23:44:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-04 23:44:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-06-04 23:44:54 --> Config Class Initialized
INFO - 2018-06-04 23:44:54 --> Hooks Class Initialized
DEBUG - 2018-06-04 23:44:54 --> UTF-8 Support Enabled
INFO - 2018-06-04 23:44:54 --> Utf8 Class Initialized
INFO - 2018-06-04 23:44:54 --> URI Class Initialized
INFO - 2018-06-04 23:44:54 --> Router Class Initialized
INFO - 2018-06-04 23:44:54 --> Output Class Initialized
INFO - 2018-06-04 23:44:54 --> Security Class Initialized
DEBUG - 2018-06-04 23:44:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-04 23:44:54 --> Input Class Initialized
INFO - 2018-06-04 23:44:54 --> Language Class Initialized
INFO - 2018-06-04 23:44:54 --> Language Class Initialized
INFO - 2018-06-04 23:44:54 --> Config Class Initialized
INFO - 2018-06-04 23:44:54 --> Loader Class Initialized
DEBUG - 2018-06-04 23:44:54 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-04 23:44:54 --> Helper loaded: url_helper
INFO - 2018-06-04 23:44:54 --> Helper loaded: form_helper
INFO - 2018-06-04 23:44:54 --> Helper loaded: date_helper
INFO - 2018-06-04 23:44:54 --> Helper loaded: util_helper
INFO - 2018-06-04 23:44:54 --> Helper loaded: text_helper
INFO - 2018-06-04 23:44:54 --> Helper loaded: string_helper
INFO - 2018-06-04 23:44:54 --> Database Driver Class Initialized
DEBUG - 2018-06-04 23:44:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-04 23:44:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-04 23:44:54 --> Email Class Initialized
INFO - 2018-06-04 23:44:54 --> Controller Class Initialized
DEBUG - 2018-06-04 23:44:54 --> Login MX_Controller Initialized
INFO - 2018-06-04 23:44:54 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-04 23:44:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-04 23:44:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-04 23:45:35 --> Config Class Initialized
INFO - 2018-06-04 23:45:35 --> Hooks Class Initialized
DEBUG - 2018-06-04 23:45:35 --> UTF-8 Support Enabled
INFO - 2018-06-04 23:45:35 --> Utf8 Class Initialized
INFO - 2018-06-04 23:45:35 --> URI Class Initialized
INFO - 2018-06-04 23:45:35 --> Router Class Initialized
INFO - 2018-06-04 23:45:35 --> Output Class Initialized
INFO - 2018-06-04 23:45:35 --> Security Class Initialized
DEBUG - 2018-06-04 23:45:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-04 23:45:35 --> Input Class Initialized
INFO - 2018-06-04 23:45:35 --> Language Class Initialized
INFO - 2018-06-04 23:45:35 --> Language Class Initialized
INFO - 2018-06-04 23:45:35 --> Config Class Initialized
INFO - 2018-06-04 23:45:35 --> Loader Class Initialized
DEBUG - 2018-06-04 23:45:35 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-04 23:45:35 --> Helper loaded: url_helper
INFO - 2018-06-04 23:45:35 --> Helper loaded: form_helper
INFO - 2018-06-04 23:45:35 --> Helper loaded: date_helper
INFO - 2018-06-04 23:45:35 --> Helper loaded: util_helper
INFO - 2018-06-04 23:45:35 --> Helper loaded: text_helper
INFO - 2018-06-04 23:45:35 --> Helper loaded: string_helper
INFO - 2018-06-04 23:45:35 --> Database Driver Class Initialized
DEBUG - 2018-06-04 23:45:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-04 23:45:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-04 23:45:35 --> Email Class Initialized
INFO - 2018-06-04 23:45:35 --> Controller Class Initialized
DEBUG - 2018-06-04 23:45:35 --> Login MX_Controller Initialized
INFO - 2018-06-04 23:45:35 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-04 23:45:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-04 23:45:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-04 23:45:35 --> Email starts for gopipanguluri123@gmail.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-06-04 23:45:35 --> Login status gopipanguluri123@gmail.com - failure
INFO - 2018-06-04 23:45:35 --> Final output sent to browser
DEBUG - 2018-06-04 23:45:35 --> Total execution time: 0.3043
INFO - 2018-06-04 23:45:44 --> Config Class Initialized
INFO - 2018-06-04 23:45:44 --> Hooks Class Initialized
DEBUG - 2018-06-04 23:45:44 --> UTF-8 Support Enabled
INFO - 2018-06-04 23:45:44 --> Utf8 Class Initialized
INFO - 2018-06-04 23:45:44 --> URI Class Initialized
INFO - 2018-06-04 23:45:44 --> Router Class Initialized
INFO - 2018-06-04 23:45:44 --> Output Class Initialized
INFO - 2018-06-04 23:45:44 --> Security Class Initialized
DEBUG - 2018-06-04 23:45:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-04 23:45:44 --> Input Class Initialized
INFO - 2018-06-04 23:45:44 --> Language Class Initialized
INFO - 2018-06-04 23:45:44 --> Language Class Initialized
INFO - 2018-06-04 23:45:44 --> Config Class Initialized
INFO - 2018-06-04 23:45:44 --> Loader Class Initialized
DEBUG - 2018-06-04 23:45:44 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-04 23:45:44 --> Helper loaded: url_helper
INFO - 2018-06-04 23:45:44 --> Helper loaded: form_helper
INFO - 2018-06-04 23:45:44 --> Helper loaded: date_helper
INFO - 2018-06-04 23:45:44 --> Helper loaded: util_helper
INFO - 2018-06-04 23:45:44 --> Helper loaded: text_helper
INFO - 2018-06-04 23:45:44 --> Helper loaded: string_helper
INFO - 2018-06-04 23:45:44 --> Database Driver Class Initialized
DEBUG - 2018-06-04 23:45:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-04 23:45:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-04 23:45:44 --> Email Class Initialized
INFO - 2018-06-04 23:45:44 --> Controller Class Initialized
DEBUG - 2018-06-04 23:45:44 --> Login MX_Controller Initialized
INFO - 2018-06-04 23:45:44 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-04 23:45:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-04 23:45:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-04 23:45:44 --> Email starts for user@colin.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-06-04 23:45:44 --> User session created for 4
INFO - 2018-06-04 23:45:44 --> Login status user@colin.com - success
INFO - 2018-06-04 23:45:44 --> Final output sent to browser
DEBUG - 2018-06-04 23:45:44 --> Total execution time: 0.3486
INFO - 2018-06-04 23:46:11 --> Config Class Initialized
INFO - 2018-06-04 23:46:11 --> Hooks Class Initialized
DEBUG - 2018-06-04 23:46:11 --> UTF-8 Support Enabled
INFO - 2018-06-04 23:46:11 --> Utf8 Class Initialized
INFO - 2018-06-04 23:46:11 --> URI Class Initialized
DEBUG - 2018-06-04 23:46:11 --> No URI present. Default controller set.
INFO - 2018-06-04 23:46:11 --> Router Class Initialized
INFO - 2018-06-04 23:46:11 --> Output Class Initialized
INFO - 2018-06-04 23:46:11 --> Security Class Initialized
DEBUG - 2018-06-04 23:46:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-04 23:46:11 --> Input Class Initialized
INFO - 2018-06-04 23:46:11 --> Language Class Initialized
INFO - 2018-06-04 23:46:11 --> Language Class Initialized
INFO - 2018-06-04 23:46:11 --> Config Class Initialized
INFO - 2018-06-04 23:46:11 --> Loader Class Initialized
DEBUG - 2018-06-04 23:46:11 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-04 23:46:11 --> Helper loaded: url_helper
INFO - 2018-06-04 23:46:11 --> Helper loaded: form_helper
INFO - 2018-06-04 23:46:11 --> Helper loaded: date_helper
INFO - 2018-06-04 23:46:12 --> Helper loaded: util_helper
INFO - 2018-06-04 23:46:12 --> Helper loaded: text_helper
INFO - 2018-06-04 23:46:12 --> Helper loaded: string_helper
INFO - 2018-06-04 23:46:12 --> Database Driver Class Initialized
DEBUG - 2018-06-04 23:46:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-04 23:46:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-04 23:46:12 --> Email Class Initialized
INFO - 2018-06-04 23:46:12 --> Controller Class Initialized
DEBUG - 2018-06-04 23:46:12 --> Home MX_Controller Initialized
DEBUG - 2018-06-04 23:46:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-04 23:46:12 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-04 23:46:12 --> Login MX_Controller Initialized
INFO - 2018-06-04 23:46:12 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-04 23:46:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-04 23:46:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-04 23:46:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-04 23:46:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-04 23:46:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-04 23:46:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-04 23:46:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-04 23:46:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-06-04 23:46:12 --> Final output sent to browser
DEBUG - 2018-06-04 23:46:12 --> Total execution time: 0.5114
INFO - 2018-06-04 23:46:13 --> Config Class Initialized
INFO - 2018-06-04 23:46:13 --> Hooks Class Initialized
DEBUG - 2018-06-04 23:46:13 --> UTF-8 Support Enabled
INFO - 2018-06-04 23:46:13 --> Utf8 Class Initialized
INFO - 2018-06-04 23:46:13 --> URI Class Initialized
INFO - 2018-06-04 23:46:13 --> Router Class Initialized
INFO - 2018-06-04 23:46:13 --> Output Class Initialized
INFO - 2018-06-04 23:46:13 --> Security Class Initialized
DEBUG - 2018-06-04 23:46:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-04 23:46:13 --> Input Class Initialized
INFO - 2018-06-04 23:46:13 --> Language Class Initialized
ERROR - 2018-06-04 23:46:13 --> 404 Page Not Found: /index
INFO - 2018-06-04 23:46:13 --> Config Class Initialized
INFO - 2018-06-04 23:46:13 --> Hooks Class Initialized
DEBUG - 2018-06-04 23:46:13 --> UTF-8 Support Enabled
INFO - 2018-06-04 23:46:13 --> Utf8 Class Initialized
INFO - 2018-06-04 23:46:13 --> URI Class Initialized
INFO - 2018-06-04 23:46:13 --> Router Class Initialized
INFO - 2018-06-04 23:46:13 --> Output Class Initialized
INFO - 2018-06-04 23:46:13 --> Security Class Initialized
DEBUG - 2018-06-04 23:46:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-04 23:46:13 --> Input Class Initialized
INFO - 2018-06-04 23:46:13 --> Language Class Initialized
ERROR - 2018-06-04 23:46:13 --> 404 Page Not Found: /index
INFO - 2018-06-04 23:46:13 --> Config Class Initialized
INFO - 2018-06-04 23:46:13 --> Hooks Class Initialized
DEBUG - 2018-06-04 23:46:13 --> UTF-8 Support Enabled
INFO - 2018-06-04 23:46:13 --> Utf8 Class Initialized
INFO - 2018-06-04 23:46:13 --> URI Class Initialized
INFO - 2018-06-04 23:46:13 --> Router Class Initialized
INFO - 2018-06-04 23:46:13 --> Output Class Initialized
INFO - 2018-06-04 23:46:13 --> Security Class Initialized
DEBUG - 2018-06-04 23:46:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-04 23:46:13 --> Input Class Initialized
INFO - 2018-06-04 23:46:13 --> Language Class Initialized
ERROR - 2018-06-04 23:46:13 --> 404 Page Not Found: /index
INFO - 2018-06-04 23:46:13 --> Config Class Initialized
INFO - 2018-06-04 23:46:13 --> Hooks Class Initialized
DEBUG - 2018-06-04 23:46:13 --> UTF-8 Support Enabled
INFO - 2018-06-04 23:46:13 --> Utf8 Class Initialized
INFO - 2018-06-04 23:46:13 --> URI Class Initialized
INFO - 2018-06-04 23:46:13 --> Router Class Initialized
INFO - 2018-06-04 23:46:13 --> Output Class Initialized
INFO - 2018-06-04 23:46:13 --> Security Class Initialized
DEBUG - 2018-06-04 23:46:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-04 23:46:13 --> Input Class Initialized
INFO - 2018-06-04 23:46:13 --> Language Class Initialized
ERROR - 2018-06-04 23:46:13 --> 404 Page Not Found: /index
INFO - 2018-06-04 23:46:13 --> Config Class Initialized
INFO - 2018-06-04 23:46:13 --> Hooks Class Initialized
DEBUG - 2018-06-04 23:46:13 --> UTF-8 Support Enabled
INFO - 2018-06-04 23:46:13 --> Utf8 Class Initialized
INFO - 2018-06-04 23:46:13 --> URI Class Initialized
INFO - 2018-06-04 23:46:13 --> Router Class Initialized
INFO - 2018-06-04 23:46:13 --> Output Class Initialized
INFO - 2018-06-04 23:46:13 --> Security Class Initialized
DEBUG - 2018-06-04 23:46:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-04 23:46:13 --> Input Class Initialized
INFO - 2018-06-04 23:46:13 --> Language Class Initialized
ERROR - 2018-06-04 23:46:13 --> 404 Page Not Found: /index
INFO - 2018-06-04 23:46:13 --> Config Class Initialized
INFO - 2018-06-04 23:46:13 --> Hooks Class Initialized
DEBUG - 2018-06-04 23:46:13 --> UTF-8 Support Enabled
INFO - 2018-06-04 23:46:13 --> Utf8 Class Initialized
INFO - 2018-06-04 23:46:13 --> URI Class Initialized
INFO - 2018-06-04 23:46:13 --> Router Class Initialized
INFO - 2018-06-04 23:46:13 --> Output Class Initialized
INFO - 2018-06-04 23:46:13 --> Security Class Initialized
DEBUG - 2018-06-04 23:46:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-04 23:46:13 --> Input Class Initialized
INFO - 2018-06-04 23:46:13 --> Language Class Initialized
ERROR - 2018-06-04 23:46:13 --> 404 Page Not Found: /index
INFO - 2018-06-04 23:48:35 --> Config Class Initialized
INFO - 2018-06-04 23:48:35 --> Hooks Class Initialized
DEBUG - 2018-06-04 23:48:35 --> UTF-8 Support Enabled
INFO - 2018-06-04 23:48:35 --> Utf8 Class Initialized
INFO - 2018-06-04 23:48:35 --> URI Class Initialized
INFO - 2018-06-04 23:48:35 --> Router Class Initialized
INFO - 2018-06-04 23:48:35 --> Output Class Initialized
INFO - 2018-06-04 23:48:35 --> Security Class Initialized
DEBUG - 2018-06-04 23:48:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-04 23:48:35 --> Input Class Initialized
INFO - 2018-06-04 23:48:35 --> Language Class Initialized
INFO - 2018-06-04 23:48:35 --> Language Class Initialized
INFO - 2018-06-04 23:48:35 --> Config Class Initialized
INFO - 2018-06-04 23:48:35 --> Loader Class Initialized
DEBUG - 2018-06-04 23:48:35 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-04 23:48:35 --> Helper loaded: url_helper
INFO - 2018-06-04 23:48:35 --> Helper loaded: form_helper
INFO - 2018-06-04 23:48:35 --> Helper loaded: date_helper
INFO - 2018-06-04 23:48:35 --> Helper loaded: util_helper
INFO - 2018-06-04 23:48:35 --> Helper loaded: text_helper
INFO - 2018-06-04 23:48:35 --> Helper loaded: string_helper
INFO - 2018-06-04 23:48:35 --> Database Driver Class Initialized
DEBUG - 2018-06-04 23:48:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-04 23:48:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-04 23:48:35 --> Email Class Initialized
INFO - 2018-06-04 23:48:35 --> Controller Class Initialized
DEBUG - 2018-06-04 23:48:35 --> Login MX_Controller Initialized
INFO - 2018-06-04 23:48:35 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-04 23:48:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-04 23:48:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-04 23:48:35 --> 4 Loggedout
INFO - 2018-06-04 23:48:35 --> Config Class Initialized
INFO - 2018-06-04 23:48:35 --> Hooks Class Initialized
DEBUG - 2018-06-04 23:48:35 --> UTF-8 Support Enabled
INFO - 2018-06-04 23:48:35 --> Utf8 Class Initialized
INFO - 2018-06-04 23:48:35 --> URI Class Initialized
INFO - 2018-06-04 23:48:35 --> Router Class Initialized
INFO - 2018-06-04 23:48:35 --> Output Class Initialized
INFO - 2018-06-04 23:48:35 --> Security Class Initialized
DEBUG - 2018-06-04 23:48:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-04 23:48:35 --> Input Class Initialized
INFO - 2018-06-04 23:48:35 --> Language Class Initialized
INFO - 2018-06-04 23:48:35 --> Language Class Initialized
INFO - 2018-06-04 23:48:35 --> Config Class Initialized
INFO - 2018-06-04 23:48:35 --> Loader Class Initialized
DEBUG - 2018-06-04 23:48:35 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-04 23:48:35 --> Helper loaded: url_helper
INFO - 2018-06-04 23:48:35 --> Helper loaded: form_helper
INFO - 2018-06-04 23:48:35 --> Helper loaded: date_helper
INFO - 2018-06-04 23:48:35 --> Helper loaded: util_helper
INFO - 2018-06-04 23:48:35 --> Helper loaded: text_helper
INFO - 2018-06-04 23:48:35 --> Helper loaded: string_helper
INFO - 2018-06-04 23:48:35 --> Database Driver Class Initialized
DEBUG - 2018-06-04 23:48:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-04 23:48:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-04 23:48:35 --> Email Class Initialized
INFO - 2018-06-04 23:48:35 --> Controller Class Initialized
DEBUG - 2018-06-04 23:48:35 --> Home MX_Controller Initialized
DEBUG - 2018-06-04 23:48:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-04 23:48:35 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-04 23:48:35 --> Login MX_Controller Initialized
INFO - 2018-06-04 23:48:35 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-04 23:48:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-04 23:48:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-04 23:48:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-06-04 23:48:37 --> Config Class Initialized
INFO - 2018-06-04 23:48:37 --> Hooks Class Initialized
DEBUG - 2018-06-04 23:48:37 --> UTF-8 Support Enabled
INFO - 2018-06-04 23:48:37 --> Utf8 Class Initialized
INFO - 2018-06-04 23:48:37 --> URI Class Initialized
INFO - 2018-06-04 23:48:37 --> Router Class Initialized
INFO - 2018-06-04 23:48:37 --> Output Class Initialized
INFO - 2018-06-04 23:48:37 --> Security Class Initialized
DEBUG - 2018-06-04 23:48:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-04 23:48:37 --> Input Class Initialized
INFO - 2018-06-04 23:48:37 --> Language Class Initialized
INFO - 2018-06-04 23:48:37 --> Language Class Initialized
INFO - 2018-06-04 23:48:37 --> Config Class Initialized
INFO - 2018-06-04 23:48:37 --> Loader Class Initialized
DEBUG - 2018-06-04 23:48:37 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-04 23:48:37 --> Helper loaded: url_helper
INFO - 2018-06-04 23:48:37 --> Helper loaded: form_helper
INFO - 2018-06-04 23:48:37 --> Helper loaded: date_helper
INFO - 2018-06-04 23:48:37 --> Helper loaded: util_helper
INFO - 2018-06-04 23:48:37 --> Helper loaded: text_helper
INFO - 2018-06-04 23:48:37 --> Helper loaded: string_helper
INFO - 2018-06-04 23:48:37 --> Database Driver Class Initialized
DEBUG - 2018-06-04 23:48:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-04 23:48:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-04 23:48:37 --> Email Class Initialized
INFO - 2018-06-04 23:48:37 --> Controller Class Initialized
DEBUG - 2018-06-04 23:48:37 --> Home MX_Controller Initialized
DEBUG - 2018-06-04 23:48:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-04 23:48:37 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-04 23:48:37 --> Login MX_Controller Initialized
INFO - 2018-06-04 23:48:37 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-04 23:48:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-04 23:48:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-04 23:48:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-06-04 23:49:03 --> Config Class Initialized
INFO - 2018-06-04 23:49:03 --> Hooks Class Initialized
DEBUG - 2018-06-04 23:49:03 --> UTF-8 Support Enabled
INFO - 2018-06-04 23:49:03 --> Utf8 Class Initialized
INFO - 2018-06-04 23:49:03 --> URI Class Initialized
INFO - 2018-06-04 23:49:03 --> Router Class Initialized
INFO - 2018-06-04 23:49:03 --> Output Class Initialized
INFO - 2018-06-04 23:49:03 --> Security Class Initialized
DEBUG - 2018-06-04 23:49:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-04 23:49:03 --> Input Class Initialized
INFO - 2018-06-04 23:49:03 --> Language Class Initialized
INFO - 2018-06-04 23:49:03 --> Language Class Initialized
INFO - 2018-06-04 23:49:03 --> Config Class Initialized
INFO - 2018-06-04 23:49:03 --> Loader Class Initialized
DEBUG - 2018-06-04 23:49:03 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-04 23:49:03 --> Helper loaded: url_helper
INFO - 2018-06-04 23:49:03 --> Helper loaded: form_helper
INFO - 2018-06-04 23:49:03 --> Helper loaded: date_helper
INFO - 2018-06-04 23:49:03 --> Helper loaded: util_helper
INFO - 2018-06-04 23:49:03 --> Helper loaded: text_helper
INFO - 2018-06-04 23:49:03 --> Helper loaded: string_helper
INFO - 2018-06-04 23:49:03 --> Database Driver Class Initialized
DEBUG - 2018-06-04 23:49:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-04 23:49:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-04 23:49:03 --> Email Class Initialized
INFO - 2018-06-04 23:49:03 --> Controller Class Initialized
DEBUG - 2018-06-04 23:49:03 --> Home MX_Controller Initialized
DEBUG - 2018-06-04 23:49:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-04 23:49:03 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-04 23:49:03 --> Login MX_Controller Initialized
INFO - 2018-06-04 23:49:04 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-04 23:49:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-04 23:49:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-04 23:49:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-06-04 23:49:09 --> Config Class Initialized
INFO - 2018-06-04 23:49:09 --> Hooks Class Initialized
DEBUG - 2018-06-04 23:49:09 --> UTF-8 Support Enabled
INFO - 2018-06-04 23:49:09 --> Utf8 Class Initialized
INFO - 2018-06-04 23:49:09 --> URI Class Initialized
INFO - 2018-06-04 23:49:09 --> Router Class Initialized
INFO - 2018-06-04 23:49:09 --> Output Class Initialized
INFO - 2018-06-04 23:49:09 --> Security Class Initialized
DEBUG - 2018-06-04 23:49:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-04 23:49:09 --> Input Class Initialized
INFO - 2018-06-04 23:49:09 --> Language Class Initialized
INFO - 2018-06-04 23:49:09 --> Language Class Initialized
INFO - 2018-06-04 23:49:09 --> Config Class Initialized
INFO - 2018-06-04 23:49:09 --> Loader Class Initialized
DEBUG - 2018-06-04 23:49:09 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-04 23:49:09 --> Helper loaded: url_helper
INFO - 2018-06-04 23:49:09 --> Helper loaded: form_helper
INFO - 2018-06-04 23:49:09 --> Helper loaded: date_helper
INFO - 2018-06-04 23:49:09 --> Helper loaded: util_helper
INFO - 2018-06-04 23:49:09 --> Helper loaded: text_helper
INFO - 2018-06-04 23:49:09 --> Helper loaded: string_helper
INFO - 2018-06-04 23:49:10 --> Database Driver Class Initialized
DEBUG - 2018-06-04 23:49:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-04 23:49:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-04 23:49:10 --> Email Class Initialized
INFO - 2018-06-04 23:49:10 --> Controller Class Initialized
DEBUG - 2018-06-04 23:49:10 --> Home MX_Controller Initialized
DEBUG - 2018-06-04 23:49:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-04 23:49:10 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-04 23:49:10 --> Login MX_Controller Initialized
INFO - 2018-06-04 23:49:10 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-04 23:49:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-04 23:49:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-04 23:49:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-06-04 23:49:16 --> Config Class Initialized
INFO - 2018-06-04 23:49:17 --> Hooks Class Initialized
DEBUG - 2018-06-04 23:49:17 --> UTF-8 Support Enabled
INFO - 2018-06-04 23:49:17 --> Utf8 Class Initialized
INFO - 2018-06-04 23:49:17 --> URI Class Initialized
INFO - 2018-06-04 23:49:17 --> Router Class Initialized
INFO - 2018-06-04 23:49:17 --> Output Class Initialized
INFO - 2018-06-04 23:49:17 --> Security Class Initialized
DEBUG - 2018-06-04 23:49:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-04 23:49:17 --> Input Class Initialized
INFO - 2018-06-04 23:49:17 --> Language Class Initialized
INFO - 2018-06-04 23:49:17 --> Language Class Initialized
INFO - 2018-06-04 23:49:17 --> Config Class Initialized
INFO - 2018-06-04 23:49:17 --> Loader Class Initialized
DEBUG - 2018-06-04 23:49:17 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-04 23:49:17 --> Helper loaded: url_helper
INFO - 2018-06-04 23:49:17 --> Helper loaded: form_helper
INFO - 2018-06-04 23:49:17 --> Helper loaded: date_helper
INFO - 2018-06-04 23:49:17 --> Helper loaded: util_helper
INFO - 2018-06-04 23:49:17 --> Helper loaded: text_helper
INFO - 2018-06-04 23:49:17 --> Helper loaded: string_helper
INFO - 2018-06-04 23:49:17 --> Database Driver Class Initialized
DEBUG - 2018-06-04 23:49:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-04 23:49:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-04 23:49:17 --> Email Class Initialized
INFO - 2018-06-04 23:49:17 --> Controller Class Initialized
DEBUG - 2018-06-04 23:49:17 --> Home MX_Controller Initialized
DEBUG - 2018-06-04 23:49:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-04 23:49:17 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-04 23:49:17 --> Login MX_Controller Initialized
INFO - 2018-06-04 23:49:17 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-04 23:49:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-04 23:49:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-04 23:49:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-06-04 23:49:44 --> Config Class Initialized
INFO - 2018-06-04 23:49:44 --> Hooks Class Initialized
DEBUG - 2018-06-04 23:49:44 --> UTF-8 Support Enabled
INFO - 2018-06-04 23:49:44 --> Utf8 Class Initialized
INFO - 2018-06-04 23:49:44 --> URI Class Initialized
INFO - 2018-06-04 23:49:44 --> Router Class Initialized
INFO - 2018-06-04 23:49:44 --> Output Class Initialized
INFO - 2018-06-04 23:49:44 --> Security Class Initialized
DEBUG - 2018-06-04 23:49:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-04 23:49:44 --> Input Class Initialized
INFO - 2018-06-04 23:49:44 --> Language Class Initialized
INFO - 2018-06-04 23:49:44 --> Language Class Initialized
INFO - 2018-06-04 23:49:44 --> Config Class Initialized
INFO - 2018-06-04 23:49:44 --> Loader Class Initialized
DEBUG - 2018-06-04 23:49:44 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-04 23:49:44 --> Helper loaded: url_helper
INFO - 2018-06-04 23:49:44 --> Helper loaded: form_helper
INFO - 2018-06-04 23:49:44 --> Helper loaded: date_helper
INFO - 2018-06-04 23:49:44 --> Helper loaded: util_helper
INFO - 2018-06-04 23:49:44 --> Helper loaded: text_helper
INFO - 2018-06-04 23:49:44 --> Helper loaded: string_helper
INFO - 2018-06-04 23:49:44 --> Database Driver Class Initialized
DEBUG - 2018-06-04 23:49:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-04 23:49:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-04 23:49:44 --> Email Class Initialized
INFO - 2018-06-04 23:49:44 --> Controller Class Initialized
DEBUG - 2018-06-04 23:49:44 --> Login MX_Controller Initialized
INFO - 2018-06-04 23:49:44 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-04 23:49:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-04 23:49:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-04 23:49:44 --> Email starts for user@colin.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-06-04 23:49:44 --> User session created for 4
INFO - 2018-06-04 23:49:44 --> Login status user@colin.com - success
INFO - 2018-06-04 23:49:44 --> Final output sent to browser
DEBUG - 2018-06-04 23:49:44 --> Total execution time: 0.3983
INFO - 2018-06-04 23:49:48 --> Config Class Initialized
INFO - 2018-06-04 23:49:48 --> Hooks Class Initialized
DEBUG - 2018-06-04 23:49:48 --> UTF-8 Support Enabled
INFO - 2018-06-04 23:49:48 --> Utf8 Class Initialized
INFO - 2018-06-04 23:49:48 --> URI Class Initialized
INFO - 2018-06-04 23:49:48 --> Router Class Initialized
INFO - 2018-06-04 23:49:48 --> Output Class Initialized
INFO - 2018-06-04 23:49:48 --> Security Class Initialized
DEBUG - 2018-06-04 23:49:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-04 23:49:48 --> Input Class Initialized
INFO - 2018-06-04 23:49:48 --> Language Class Initialized
INFO - 2018-06-04 23:49:48 --> Language Class Initialized
INFO - 2018-06-04 23:49:48 --> Config Class Initialized
INFO - 2018-06-04 23:49:48 --> Loader Class Initialized
DEBUG - 2018-06-04 23:49:48 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-04 23:49:48 --> Helper loaded: url_helper
INFO - 2018-06-04 23:49:48 --> Helper loaded: form_helper
INFO - 2018-06-04 23:49:48 --> Helper loaded: date_helper
INFO - 2018-06-04 23:49:48 --> Helper loaded: util_helper
INFO - 2018-06-04 23:49:48 --> Helper loaded: text_helper
INFO - 2018-06-04 23:49:48 --> Helper loaded: string_helper
INFO - 2018-06-04 23:49:48 --> Database Driver Class Initialized
DEBUG - 2018-06-04 23:49:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-04 23:49:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-04 23:49:48 --> Email Class Initialized
INFO - 2018-06-04 23:49:48 --> Controller Class Initialized
DEBUG - 2018-06-04 23:49:48 --> Home MX_Controller Initialized
DEBUG - 2018-06-04 23:49:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-04 23:49:48 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-04 23:49:48 --> Login MX_Controller Initialized
INFO - 2018-06-04 23:49:49 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-04 23:49:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-04 23:49:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-04 23:49:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-04 23:49:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-04 23:49:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-04 23:49:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-04 23:49:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-04 23:49:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-06-04 23:49:49 --> Final output sent to browser
DEBUG - 2018-06-04 23:49:49 --> Total execution time: 0.4934
INFO - 2018-06-04 23:49:51 --> Config Class Initialized
INFO - 2018-06-04 23:49:51 --> Hooks Class Initialized
DEBUG - 2018-06-04 23:49:51 --> UTF-8 Support Enabled
INFO - 2018-06-04 23:49:51 --> Utf8 Class Initialized
INFO - 2018-06-04 23:49:51 --> Config Class Initialized
INFO - 2018-06-04 23:49:51 --> Hooks Class Initialized
DEBUG - 2018-06-04 23:49:51 --> UTF-8 Support Enabled
INFO - 2018-06-04 23:49:51 --> Utf8 Class Initialized
INFO - 2018-06-04 23:49:51 --> URI Class Initialized
INFO - 2018-06-04 23:49:51 --> Router Class Initialized
INFO - 2018-06-04 23:49:51 --> Output Class Initialized
INFO - 2018-06-04 23:49:51 --> Security Class Initialized
DEBUG - 2018-06-04 23:49:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-04 23:49:51 --> Input Class Initialized
INFO - 2018-06-04 23:49:51 --> Language Class Initialized
INFO - 2018-06-04 23:49:51 --> URI Class Initialized
ERROR - 2018-06-04 23:49:51 --> 404 Page Not Found: /index
INFO - 2018-06-04 23:49:51 --> Router Class Initialized
INFO - 2018-06-04 23:49:51 --> Output Class Initialized
INFO - 2018-06-04 23:49:51 --> Security Class Initialized
DEBUG - 2018-06-04 23:49:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-04 23:49:51 --> Input Class Initialized
INFO - 2018-06-04 23:49:51 --> Language Class Initialized
ERROR - 2018-06-04 23:49:51 --> 404 Page Not Found: /index
INFO - 2018-06-04 23:49:51 --> Config Class Initialized
INFO - 2018-06-04 23:49:51 --> Config Class Initialized
INFO - 2018-06-04 23:49:51 --> Hooks Class Initialized
INFO - 2018-06-04 23:49:51 --> Hooks Class Initialized
DEBUG - 2018-06-04 23:49:51 --> UTF-8 Support Enabled
INFO - 2018-06-04 23:49:51 --> Utf8 Class Initialized
DEBUG - 2018-06-04 23:49:51 --> UTF-8 Support Enabled
INFO - 2018-06-04 23:49:51 --> URI Class Initialized
INFO - 2018-06-04 23:49:51 --> Utf8 Class Initialized
INFO - 2018-06-04 23:49:51 --> Router Class Initialized
INFO - 2018-06-04 23:49:51 --> Output Class Initialized
INFO - 2018-06-04 23:49:51 --> URI Class Initialized
INFO - 2018-06-04 23:49:51 --> Security Class Initialized
DEBUG - 2018-06-04 23:49:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-04 23:49:51 --> Input Class Initialized
INFO - 2018-06-04 23:49:51 --> Language Class Initialized
ERROR - 2018-06-04 23:49:51 --> 404 Page Not Found: /index
INFO - 2018-06-04 23:49:51 --> Config Class Initialized
INFO - 2018-06-04 23:49:51 --> Router Class Initialized
INFO - 2018-06-04 23:49:51 --> Hooks Class Initialized
DEBUG - 2018-06-04 23:49:52 --> UTF-8 Support Enabled
INFO - 2018-06-04 23:49:52 --> Output Class Initialized
INFO - 2018-06-04 23:49:52 --> Utf8 Class Initialized
INFO - 2018-06-04 23:49:52 --> URI Class Initialized
INFO - 2018-06-04 23:49:52 --> Router Class Initialized
INFO - 2018-06-04 23:49:52 --> Security Class Initialized
INFO - 2018-06-04 23:49:52 --> Output Class Initialized
INFO - 2018-06-04 23:49:52 --> Security Class Initialized
DEBUG - 2018-06-04 23:49:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-04 23:49:52 --> Input Class Initialized
INFO - 2018-06-04 23:49:52 --> Language Class Initialized
ERROR - 2018-06-04 23:49:52 --> 404 Page Not Found: /index
DEBUG - 2018-06-04 23:49:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-04 23:49:52 --> Input Class Initialized
INFO - 2018-06-04 23:49:52 --> Language Class Initialized
ERROR - 2018-06-04 23:49:52 --> 404 Page Not Found: /index
INFO - 2018-06-04 23:49:52 --> Config Class Initialized
INFO - 2018-06-04 23:49:52 --> Hooks Class Initialized
DEBUG - 2018-06-04 23:49:52 --> UTF-8 Support Enabled
INFO - 2018-06-04 23:49:52 --> Utf8 Class Initialized
INFO - 2018-06-04 23:49:52 --> URI Class Initialized
INFO - 2018-06-04 23:49:52 --> Router Class Initialized
INFO - 2018-06-04 23:49:52 --> Output Class Initialized
INFO - 2018-06-04 23:49:52 --> Security Class Initialized
DEBUG - 2018-06-04 23:49:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-04 23:49:52 --> Input Class Initialized
INFO - 2018-06-04 23:49:52 --> Language Class Initialized
ERROR - 2018-06-04 23:49:52 --> 404 Page Not Found: /index
INFO - 2018-06-04 23:49:52 --> Config Class Initialized
INFO - 2018-06-04 23:49:52 --> Hooks Class Initialized
DEBUG - 2018-06-04 23:49:52 --> UTF-8 Support Enabled
INFO - 2018-06-04 23:49:52 --> Utf8 Class Initialized
INFO - 2018-06-04 23:49:52 --> URI Class Initialized
INFO - 2018-06-04 23:49:52 --> Router Class Initialized
INFO - 2018-06-04 23:49:52 --> Output Class Initialized
INFO - 2018-06-04 23:49:52 --> Security Class Initialized
DEBUG - 2018-06-04 23:49:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-04 23:49:52 --> Input Class Initialized
INFO - 2018-06-04 23:49:52 --> Language Class Initialized
ERROR - 2018-06-04 23:49:52 --> 404 Page Not Found: /index
INFO - 2018-06-04 23:49:53 --> Config Class Initialized
INFO - 2018-06-04 23:49:53 --> Hooks Class Initialized
DEBUG - 2018-06-04 23:49:53 --> UTF-8 Support Enabled
INFO - 2018-06-04 23:49:53 --> Utf8 Class Initialized
INFO - 2018-06-04 23:49:53 --> URI Class Initialized
INFO - 2018-06-04 23:49:53 --> Router Class Initialized
INFO - 2018-06-04 23:49:53 --> Output Class Initialized
INFO - 2018-06-04 23:49:53 --> Security Class Initialized
DEBUG - 2018-06-04 23:49:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-04 23:49:53 --> Input Class Initialized
INFO - 2018-06-04 23:49:53 --> Language Class Initialized
INFO - 2018-06-04 23:49:53 --> Language Class Initialized
INFO - 2018-06-04 23:49:53 --> Config Class Initialized
INFO - 2018-06-04 23:49:53 --> Loader Class Initialized
DEBUG - 2018-06-04 23:49:53 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-04 23:49:53 --> Helper loaded: url_helper
INFO - 2018-06-04 23:49:53 --> Helper loaded: form_helper
INFO - 2018-06-04 23:49:53 --> Helper loaded: date_helper
INFO - 2018-06-04 23:49:53 --> Helper loaded: util_helper
INFO - 2018-06-04 23:49:53 --> Helper loaded: text_helper
INFO - 2018-06-04 23:49:53 --> Helper loaded: string_helper
INFO - 2018-06-04 23:49:53 --> Database Driver Class Initialized
DEBUG - 2018-06-04 23:49:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-04 23:49:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-04 23:49:53 --> Email Class Initialized
INFO - 2018-06-04 23:49:53 --> Controller Class Initialized
DEBUG - 2018-06-04 23:49:53 --> Home MX_Controller Initialized
DEBUG - 2018-06-04 23:49:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-04 23:49:53 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-04 23:49:53 --> Login MX_Controller Initialized
INFO - 2018-06-04 23:49:53 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-04 23:49:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-04 23:49:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-04 23:49:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-04 23:49:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-04 23:49:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-04 23:49:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-04 23:49:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-04 23:49:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-06-04 23:49:53 --> Final output sent to browser
DEBUG - 2018-06-04 23:49:54 --> Total execution time: 0.4007
INFO - 2018-06-04 23:49:54 --> Config Class Initialized
INFO - 2018-06-04 23:49:54 --> Hooks Class Initialized
DEBUG - 2018-06-04 23:49:54 --> UTF-8 Support Enabled
INFO - 2018-06-04 23:49:54 --> Utf8 Class Initialized
INFO - 2018-06-04 23:49:54 --> URI Class Initialized
INFO - 2018-06-04 23:49:54 --> Router Class Initialized
INFO - 2018-06-04 23:49:54 --> Output Class Initialized
INFO - 2018-06-04 23:49:54 --> Security Class Initialized
DEBUG - 2018-06-04 23:49:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-04 23:49:54 --> Input Class Initialized
INFO - 2018-06-04 23:49:54 --> Language Class Initialized
ERROR - 2018-06-04 23:49:54 --> 404 Page Not Found: /index
INFO - 2018-06-04 23:49:54 --> Config Class Initialized
INFO - 2018-06-04 23:49:54 --> Hooks Class Initialized
DEBUG - 2018-06-04 23:49:55 --> UTF-8 Support Enabled
INFO - 2018-06-04 23:49:55 --> Utf8 Class Initialized
INFO - 2018-06-04 23:49:55 --> URI Class Initialized
INFO - 2018-06-04 23:49:55 --> Router Class Initialized
INFO - 2018-06-04 23:49:55 --> Output Class Initialized
INFO - 2018-06-04 23:49:55 --> Security Class Initialized
DEBUG - 2018-06-04 23:49:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-04 23:49:55 --> Input Class Initialized
INFO - 2018-06-04 23:49:55 --> Language Class Initialized
ERROR - 2018-06-04 23:49:55 --> 404 Page Not Found: /index
INFO - 2018-06-04 23:49:55 --> Config Class Initialized
INFO - 2018-06-04 23:49:55 --> Hooks Class Initialized
DEBUG - 2018-06-04 23:49:55 --> UTF-8 Support Enabled
INFO - 2018-06-04 23:49:55 --> Utf8 Class Initialized
INFO - 2018-06-04 23:49:55 --> URI Class Initialized
INFO - 2018-06-04 23:49:55 --> Router Class Initialized
INFO - 2018-06-04 23:49:55 --> Output Class Initialized
INFO - 2018-06-04 23:49:55 --> Security Class Initialized
DEBUG - 2018-06-04 23:49:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-04 23:49:55 --> Input Class Initialized
INFO - 2018-06-04 23:49:55 --> Language Class Initialized
ERROR - 2018-06-04 23:49:55 --> 404 Page Not Found: /index
INFO - 2018-06-04 23:49:56 --> Config Class Initialized
INFO - 2018-06-04 23:49:56 --> Hooks Class Initialized
DEBUG - 2018-06-04 23:49:56 --> UTF-8 Support Enabled
INFO - 2018-06-04 23:49:56 --> Utf8 Class Initialized
INFO - 2018-06-04 23:49:56 --> URI Class Initialized
INFO - 2018-06-04 23:49:56 --> Router Class Initialized
INFO - 2018-06-04 23:49:56 --> Output Class Initialized
INFO - 2018-06-04 23:49:56 --> Security Class Initialized
DEBUG - 2018-06-04 23:49:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-04 23:49:56 --> Input Class Initialized
INFO - 2018-06-04 23:49:56 --> Language Class Initialized
INFO - 2018-06-04 23:49:56 --> Language Class Initialized
INFO - 2018-06-04 23:49:56 --> Config Class Initialized
INFO - 2018-06-04 23:49:56 --> Loader Class Initialized
DEBUG - 2018-06-04 23:49:56 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-04 23:49:57 --> Helper loaded: url_helper
INFO - 2018-06-04 23:49:57 --> Helper loaded: form_helper
INFO - 2018-06-04 23:49:57 --> Helper loaded: date_helper
INFO - 2018-06-04 23:49:57 --> Helper loaded: util_helper
INFO - 2018-06-04 23:49:57 --> Helper loaded: text_helper
INFO - 2018-06-04 23:49:57 --> Helper loaded: string_helper
INFO - 2018-06-04 23:49:57 --> Database Driver Class Initialized
DEBUG - 2018-06-04 23:49:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-04 23:49:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-04 23:49:57 --> Email Class Initialized
INFO - 2018-06-04 23:49:57 --> Controller Class Initialized
DEBUG - 2018-06-04 23:49:57 --> Login MX_Controller Initialized
INFO - 2018-06-04 23:49:57 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-04 23:49:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-04 23:49:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-04 23:49:57 --> 4 Loggedout
INFO - 2018-06-04 23:49:57 --> Config Class Initialized
INFO - 2018-06-04 23:49:57 --> Hooks Class Initialized
DEBUG - 2018-06-04 23:49:57 --> UTF-8 Support Enabled
INFO - 2018-06-04 23:49:57 --> Utf8 Class Initialized
INFO - 2018-06-04 23:49:57 --> URI Class Initialized
INFO - 2018-06-04 23:49:57 --> Router Class Initialized
INFO - 2018-06-04 23:49:57 --> Output Class Initialized
INFO - 2018-06-04 23:49:57 --> Security Class Initialized
DEBUG - 2018-06-04 23:49:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-04 23:49:57 --> Input Class Initialized
INFO - 2018-06-04 23:49:57 --> Language Class Initialized
INFO - 2018-06-04 23:49:57 --> Language Class Initialized
INFO - 2018-06-04 23:49:57 --> Config Class Initialized
INFO - 2018-06-04 23:49:57 --> Loader Class Initialized
DEBUG - 2018-06-04 23:49:57 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-04 23:49:57 --> Helper loaded: url_helper
INFO - 2018-06-04 23:49:57 --> Helper loaded: form_helper
INFO - 2018-06-04 23:49:57 --> Helper loaded: date_helper
INFO - 2018-06-04 23:49:57 --> Helper loaded: util_helper
INFO - 2018-06-04 23:49:57 --> Helper loaded: text_helper
INFO - 2018-06-04 23:49:57 --> Helper loaded: string_helper
INFO - 2018-06-04 23:49:57 --> Database Driver Class Initialized
DEBUG - 2018-06-04 23:49:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-04 23:49:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-04 23:49:57 --> Email Class Initialized
INFO - 2018-06-04 23:49:57 --> Controller Class Initialized
DEBUG - 2018-06-04 23:49:57 --> Home MX_Controller Initialized
DEBUG - 2018-06-04 23:49:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-04 23:49:57 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-04 23:49:57 --> Login MX_Controller Initialized
INFO - 2018-06-04 23:49:57 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-04 23:49:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-04 23:49:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-04 23:49:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-06-04 23:50:06 --> Config Class Initialized
INFO - 2018-06-04 23:50:06 --> Hooks Class Initialized
DEBUG - 2018-06-04 23:50:06 --> UTF-8 Support Enabled
INFO - 2018-06-04 23:50:06 --> Utf8 Class Initialized
INFO - 2018-06-04 23:50:06 --> URI Class Initialized
INFO - 2018-06-04 23:50:06 --> Router Class Initialized
INFO - 2018-06-04 23:50:06 --> Output Class Initialized
INFO - 2018-06-04 23:50:06 --> Security Class Initialized
DEBUG - 2018-06-04 23:50:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-04 23:50:06 --> Input Class Initialized
INFO - 2018-06-04 23:50:06 --> Language Class Initialized
INFO - 2018-06-04 23:50:06 --> Language Class Initialized
INFO - 2018-06-04 23:50:06 --> Config Class Initialized
INFO - 2018-06-04 23:50:06 --> Loader Class Initialized
DEBUG - 2018-06-04 23:50:06 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-04 23:50:06 --> Helper loaded: url_helper
INFO - 2018-06-04 23:50:06 --> Helper loaded: form_helper
INFO - 2018-06-04 23:50:06 --> Helper loaded: date_helper
INFO - 2018-06-04 23:50:06 --> Helper loaded: util_helper
INFO - 2018-06-04 23:50:06 --> Helper loaded: text_helper
INFO - 2018-06-04 23:50:06 --> Helper loaded: string_helper
INFO - 2018-06-04 23:50:06 --> Database Driver Class Initialized
DEBUG - 2018-06-04 23:50:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-04 23:50:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-04 23:50:06 --> Email Class Initialized
INFO - 2018-06-04 23:50:06 --> Controller Class Initialized
DEBUG - 2018-06-04 23:50:06 --> Home MX_Controller Initialized
DEBUG - 2018-06-04 23:50:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-04 23:50:06 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-04 23:50:06 --> Login MX_Controller Initialized
INFO - 2018-06-04 23:50:06 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-04 23:50:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-04 23:50:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-04 23:50:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-06-04 23:50:46 --> Config Class Initialized
INFO - 2018-06-04 23:50:46 --> Hooks Class Initialized
DEBUG - 2018-06-04 23:50:46 --> UTF-8 Support Enabled
INFO - 2018-06-04 23:50:47 --> Utf8 Class Initialized
INFO - 2018-06-04 23:50:47 --> URI Class Initialized
INFO - 2018-06-04 23:50:47 --> Router Class Initialized
INFO - 2018-06-04 23:50:47 --> Output Class Initialized
INFO - 2018-06-04 23:50:47 --> Security Class Initialized
DEBUG - 2018-06-04 23:50:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-04 23:50:47 --> Input Class Initialized
INFO - 2018-06-04 23:50:47 --> Language Class Initialized
INFO - 2018-06-04 23:50:47 --> Language Class Initialized
INFO - 2018-06-04 23:50:47 --> Config Class Initialized
INFO - 2018-06-04 23:50:47 --> Loader Class Initialized
DEBUG - 2018-06-04 23:50:47 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-04 23:50:47 --> Helper loaded: url_helper
INFO - 2018-06-04 23:50:47 --> Helper loaded: form_helper
INFO - 2018-06-04 23:50:47 --> Helper loaded: date_helper
INFO - 2018-06-04 23:50:47 --> Helper loaded: util_helper
INFO - 2018-06-04 23:50:47 --> Helper loaded: text_helper
INFO - 2018-06-04 23:50:47 --> Helper loaded: string_helper
INFO - 2018-06-04 23:50:47 --> Database Driver Class Initialized
DEBUG - 2018-06-04 23:50:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-04 23:50:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-04 23:50:47 --> Email Class Initialized
INFO - 2018-06-04 23:50:47 --> Controller Class Initialized
DEBUG - 2018-06-04 23:50:47 --> Login MX_Controller Initialized
INFO - 2018-06-04 23:50:47 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-04 23:50:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-04 23:50:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-04 23:50:47 --> Email starts for gopipanguluri123@gmail.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-06-04 23:50:47 --> Login status gopipanguluri123@gmail.com - failure
INFO - 2018-06-04 23:50:47 --> Final output sent to browser
DEBUG - 2018-06-04 23:50:47 --> Total execution time: 0.3221
INFO - 2018-06-04 23:50:51 --> Config Class Initialized
INFO - 2018-06-04 23:50:51 --> Hooks Class Initialized
DEBUG - 2018-06-04 23:50:51 --> UTF-8 Support Enabled
INFO - 2018-06-04 23:50:51 --> Utf8 Class Initialized
INFO - 2018-06-04 23:50:51 --> URI Class Initialized
INFO - 2018-06-04 23:50:51 --> Router Class Initialized
INFO - 2018-06-04 23:50:51 --> Output Class Initialized
INFO - 2018-06-04 23:50:51 --> Security Class Initialized
DEBUG - 2018-06-04 23:50:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-04 23:50:51 --> Input Class Initialized
INFO - 2018-06-04 23:50:51 --> Language Class Initialized
INFO - 2018-06-04 23:50:51 --> Language Class Initialized
INFO - 2018-06-04 23:50:51 --> Config Class Initialized
INFO - 2018-06-04 23:50:51 --> Loader Class Initialized
DEBUG - 2018-06-04 23:50:51 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-04 23:50:51 --> Helper loaded: url_helper
INFO - 2018-06-04 23:50:51 --> Helper loaded: form_helper
INFO - 2018-06-04 23:50:51 --> Helper loaded: date_helper
INFO - 2018-06-04 23:50:51 --> Helper loaded: util_helper
INFO - 2018-06-04 23:50:51 --> Helper loaded: text_helper
INFO - 2018-06-04 23:50:51 --> Helper loaded: string_helper
INFO - 2018-06-04 23:50:51 --> Database Driver Class Initialized
DEBUG - 2018-06-04 23:50:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-04 23:50:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-04 23:50:51 --> Email Class Initialized
INFO - 2018-06-04 23:50:51 --> Controller Class Initialized
DEBUG - 2018-06-04 23:50:51 --> Login MX_Controller Initialized
INFO - 2018-06-04 23:50:51 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-04 23:50:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-04 23:50:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-04 23:50:51 --> Email starts for user@colin.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-06-04 23:50:51 --> User session created for 4
INFO - 2018-06-04 23:50:51 --> Login status user@colin.com - success
INFO - 2018-06-04 23:50:51 --> Final output sent to browser
DEBUG - 2018-06-04 23:50:51 --> Total execution time: 0.3748
INFO - 2018-06-04 23:50:52 --> Config Class Initialized
INFO - 2018-06-04 23:50:52 --> Hooks Class Initialized
DEBUG - 2018-06-04 23:50:52 --> UTF-8 Support Enabled
INFO - 2018-06-04 23:50:52 --> Utf8 Class Initialized
INFO - 2018-06-04 23:50:52 --> URI Class Initialized
INFO - 2018-06-04 23:50:52 --> Router Class Initialized
INFO - 2018-06-04 23:50:52 --> Output Class Initialized
INFO - 2018-06-04 23:50:52 --> Security Class Initialized
DEBUG - 2018-06-04 23:50:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-04 23:50:52 --> Input Class Initialized
INFO - 2018-06-04 23:50:52 --> Language Class Initialized
INFO - 2018-06-04 23:50:52 --> Language Class Initialized
INFO - 2018-06-04 23:50:52 --> Config Class Initialized
INFO - 2018-06-04 23:50:52 --> Loader Class Initialized
DEBUG - 2018-06-04 23:50:52 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-04 23:50:52 --> Helper loaded: url_helper
INFO - 2018-06-04 23:50:52 --> Helper loaded: form_helper
INFO - 2018-06-04 23:50:52 --> Helper loaded: date_helper
INFO - 2018-06-04 23:50:52 --> Helper loaded: util_helper
INFO - 2018-06-04 23:50:52 --> Helper loaded: text_helper
INFO - 2018-06-04 23:50:52 --> Helper loaded: string_helper
INFO - 2018-06-04 23:50:52 --> Database Driver Class Initialized
DEBUG - 2018-06-04 23:50:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-04 23:50:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-04 23:50:52 --> Email Class Initialized
INFO - 2018-06-04 23:50:52 --> Controller Class Initialized
DEBUG - 2018-06-04 23:50:52 --> Home MX_Controller Initialized
DEBUG - 2018-06-04 23:50:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-04 23:50:52 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-04 23:50:52 --> Login MX_Controller Initialized
INFO - 2018-06-04 23:50:52 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-04 23:50:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-04 23:50:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-04 23:50:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-04 23:50:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-04 23:50:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-04 23:50:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-04 23:50:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-04 23:50:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-06-04 23:50:52 --> Final output sent to browser
DEBUG - 2018-06-04 23:50:52 --> Total execution time: 0.4108
INFO - 2018-06-04 23:50:52 --> Config Class Initialized
INFO - 2018-06-04 23:50:52 --> Config Class Initialized
INFO - 2018-06-04 23:50:52 --> Hooks Class Initialized
INFO - 2018-06-04 23:50:52 --> Hooks Class Initialized
DEBUG - 2018-06-04 23:50:52 --> UTF-8 Support Enabled
DEBUG - 2018-06-04 23:50:52 --> UTF-8 Support Enabled
INFO - 2018-06-04 23:50:52 --> Utf8 Class Initialized
INFO - 2018-06-04 23:50:52 --> Utf8 Class Initialized
INFO - 2018-06-04 23:50:52 --> URI Class Initialized
INFO - 2018-06-04 23:50:52 --> URI Class Initialized
INFO - 2018-06-04 23:50:52 --> Router Class Initialized
INFO - 2018-06-04 23:50:52 --> Router Class Initialized
INFO - 2018-06-04 23:50:52 --> Output Class Initialized
INFO - 2018-06-04 23:50:52 --> Output Class Initialized
INFO - 2018-06-04 23:50:52 --> Security Class Initialized
INFO - 2018-06-04 23:50:52 --> Security Class Initialized
DEBUG - 2018-06-04 23:50:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-04 23:50:52 --> Input Class Initialized
DEBUG - 2018-06-04 23:50:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-04 23:50:52 --> Language Class Initialized
INFO - 2018-06-04 23:50:53 --> Input Class Initialized
INFO - 2018-06-04 23:50:53 --> Language Class Initialized
ERROR - 2018-06-04 23:50:53 --> 404 Page Not Found: /index
ERROR - 2018-06-04 23:50:53 --> 404 Page Not Found: /index
INFO - 2018-06-04 23:50:53 --> Config Class Initialized
INFO - 2018-06-04 23:50:53 --> Hooks Class Initialized
DEBUG - 2018-06-04 23:50:53 --> UTF-8 Support Enabled
INFO - 2018-06-04 23:50:53 --> Utf8 Class Initialized
INFO - 2018-06-04 23:50:53 --> URI Class Initialized
INFO - 2018-06-04 23:50:53 --> Router Class Initialized
INFO - 2018-06-04 23:50:53 --> Output Class Initialized
INFO - 2018-06-04 23:50:53 --> Security Class Initialized
DEBUG - 2018-06-04 23:50:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-04 23:50:53 --> Input Class Initialized
INFO - 2018-06-04 23:50:53 --> Language Class Initialized
ERROR - 2018-06-04 23:50:53 --> 404 Page Not Found: /index
INFO - 2018-06-04 23:50:53 --> Config Class Initialized
INFO - 2018-06-04 23:50:53 --> Hooks Class Initialized
DEBUG - 2018-06-04 23:50:53 --> UTF-8 Support Enabled
INFO - 2018-06-04 23:50:53 --> Utf8 Class Initialized
INFO - 2018-06-04 23:50:53 --> URI Class Initialized
INFO - 2018-06-04 23:50:53 --> Router Class Initialized
INFO - 2018-06-04 23:50:53 --> Output Class Initialized
INFO - 2018-06-04 23:50:53 --> Security Class Initialized
DEBUG - 2018-06-04 23:50:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-04 23:50:53 --> Input Class Initialized
INFO - 2018-06-04 23:50:53 --> Language Class Initialized
ERROR - 2018-06-04 23:50:53 --> 404 Page Not Found: /index
INFO - 2018-06-04 23:50:56 --> Config Class Initialized
INFO - 2018-06-04 23:50:56 --> Hooks Class Initialized
DEBUG - 2018-06-04 23:50:56 --> UTF-8 Support Enabled
INFO - 2018-06-04 23:50:56 --> Utf8 Class Initialized
INFO - 2018-06-04 23:50:56 --> URI Class Initialized
INFO - 2018-06-04 23:50:56 --> Router Class Initialized
INFO - 2018-06-04 23:50:56 --> Output Class Initialized
INFO - 2018-06-04 23:50:56 --> Security Class Initialized
DEBUG - 2018-06-04 23:50:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-04 23:50:56 --> Input Class Initialized
INFO - 2018-06-04 23:50:56 --> Language Class Initialized
INFO - 2018-06-04 23:50:56 --> Language Class Initialized
INFO - 2018-06-04 23:50:56 --> Config Class Initialized
INFO - 2018-06-04 23:50:56 --> Loader Class Initialized
DEBUG - 2018-06-04 23:50:56 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-04 23:50:56 --> Helper loaded: url_helper
INFO - 2018-06-04 23:50:56 --> Helper loaded: form_helper
INFO - 2018-06-04 23:50:56 --> Helper loaded: date_helper
INFO - 2018-06-04 23:50:56 --> Helper loaded: util_helper
INFO - 2018-06-04 23:50:56 --> Helper loaded: text_helper
INFO - 2018-06-04 23:50:56 --> Helper loaded: string_helper
INFO - 2018-06-04 23:50:56 --> Database Driver Class Initialized
DEBUG - 2018-06-04 23:50:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-04 23:50:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-04 23:50:56 --> Email Class Initialized
INFO - 2018-06-04 23:50:56 --> Controller Class Initialized
DEBUG - 2018-06-04 23:50:56 --> Login MX_Controller Initialized
INFO - 2018-06-04 23:50:56 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-04 23:50:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-04 23:50:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-04 23:50:56 --> Email starts for gopipanguluri123@gmail.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-06-04 23:50:56 --> Login status gopipanguluri123@gmail.com - failure
INFO - 2018-06-04 23:50:56 --> Final output sent to browser
DEBUG - 2018-06-04 23:50:56 --> Total execution time: 0.3969
INFO - 2018-06-04 23:51:00 --> Config Class Initialized
INFO - 2018-06-04 23:51:00 --> Hooks Class Initialized
DEBUG - 2018-06-04 23:51:00 --> UTF-8 Support Enabled
INFO - 2018-06-04 23:51:00 --> Utf8 Class Initialized
INFO - 2018-06-04 23:51:00 --> URI Class Initialized
INFO - 2018-06-04 23:51:00 --> Router Class Initialized
INFO - 2018-06-04 23:51:00 --> Output Class Initialized
INFO - 2018-06-04 23:51:00 --> Security Class Initialized
DEBUG - 2018-06-04 23:51:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-04 23:51:00 --> Input Class Initialized
INFO - 2018-06-04 23:51:00 --> Language Class Initialized
INFO - 2018-06-04 23:51:00 --> Language Class Initialized
INFO - 2018-06-04 23:51:00 --> Config Class Initialized
INFO - 2018-06-04 23:51:00 --> Loader Class Initialized
DEBUG - 2018-06-04 23:51:00 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-04 23:51:00 --> Helper loaded: url_helper
INFO - 2018-06-04 23:51:00 --> Helper loaded: form_helper
INFO - 2018-06-04 23:51:00 --> Helper loaded: date_helper
INFO - 2018-06-04 23:51:00 --> Helper loaded: util_helper
INFO - 2018-06-04 23:51:00 --> Helper loaded: text_helper
INFO - 2018-06-04 23:51:00 --> Helper loaded: string_helper
INFO - 2018-06-04 23:51:00 --> Database Driver Class Initialized
DEBUG - 2018-06-04 23:51:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-04 23:51:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-04 23:51:00 --> Email Class Initialized
INFO - 2018-06-04 23:51:00 --> Controller Class Initialized
DEBUG - 2018-06-04 23:51:00 --> Login MX_Controller Initialized
INFO - 2018-06-04 23:51:00 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-04 23:51:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-04 23:51:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-04 23:51:00 --> Email starts for user@colin.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-06-04 23:51:00 --> User session created for 4
INFO - 2018-06-04 23:51:00 --> Login status user@colin.com - success
INFO - 2018-06-04 23:51:00 --> Final output sent to browser
DEBUG - 2018-06-04 23:51:00 --> Total execution time: 0.3518
INFO - 2018-06-04 23:51:00 --> Config Class Initialized
INFO - 2018-06-04 23:51:00 --> Hooks Class Initialized
DEBUG - 2018-06-04 23:51:00 --> UTF-8 Support Enabled
INFO - 2018-06-04 23:51:00 --> Utf8 Class Initialized
INFO - 2018-06-04 23:51:00 --> URI Class Initialized
INFO - 2018-06-04 23:51:00 --> Router Class Initialized
INFO - 2018-06-04 23:51:00 --> Output Class Initialized
INFO - 2018-06-04 23:51:00 --> Security Class Initialized
DEBUG - 2018-06-04 23:51:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-04 23:51:00 --> Input Class Initialized
INFO - 2018-06-04 23:51:00 --> Language Class Initialized
INFO - 2018-06-04 23:51:00 --> Language Class Initialized
INFO - 2018-06-04 23:51:00 --> Config Class Initialized
INFO - 2018-06-04 23:51:00 --> Loader Class Initialized
DEBUG - 2018-06-04 23:51:00 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-04 23:51:00 --> Helper loaded: url_helper
INFO - 2018-06-04 23:51:00 --> Helper loaded: form_helper
INFO - 2018-06-04 23:51:00 --> Helper loaded: date_helper
INFO - 2018-06-04 23:51:00 --> Helper loaded: util_helper
INFO - 2018-06-04 23:51:00 --> Helper loaded: text_helper
INFO - 2018-06-04 23:51:00 --> Helper loaded: string_helper
INFO - 2018-06-04 23:51:00 --> Database Driver Class Initialized
DEBUG - 2018-06-04 23:51:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-04 23:51:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-04 23:51:00 --> Email Class Initialized
INFO - 2018-06-04 23:51:00 --> Controller Class Initialized
DEBUG - 2018-06-04 23:51:00 --> Home MX_Controller Initialized
DEBUG - 2018-06-04 23:51:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-04 23:51:00 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-04 23:51:00 --> Login MX_Controller Initialized
INFO - 2018-06-04 23:51:00 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-04 23:51:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-04 23:51:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-04 23:51:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-04 23:51:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-04 23:51:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-04 23:51:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-04 23:51:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-04 23:51:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-06-04 23:51:00 --> Final output sent to browser
DEBUG - 2018-06-04 23:51:00 --> Total execution time: 0.3967
INFO - 2018-06-04 23:51:01 --> Config Class Initialized
INFO - 2018-06-04 23:51:01 --> Hooks Class Initialized
DEBUG - 2018-06-04 23:51:01 --> UTF-8 Support Enabled
INFO - 2018-06-04 23:51:01 --> Utf8 Class Initialized
INFO - 2018-06-04 23:51:01 --> URI Class Initialized
INFO - 2018-06-04 23:51:01 --> Router Class Initialized
INFO - 2018-06-04 23:51:01 --> Output Class Initialized
INFO - 2018-06-04 23:51:01 --> Security Class Initialized
DEBUG - 2018-06-04 23:51:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-04 23:51:01 --> Input Class Initialized
INFO - 2018-06-04 23:51:01 --> Language Class Initialized
ERROR - 2018-06-04 23:51:01 --> 404 Page Not Found: /index
INFO - 2018-06-04 23:51:01 --> Config Class Initialized
INFO - 2018-06-04 23:51:01 --> Hooks Class Initialized
DEBUG - 2018-06-04 23:51:01 --> UTF-8 Support Enabled
INFO - 2018-06-04 23:51:01 --> Utf8 Class Initialized
INFO - 2018-06-04 23:51:01 --> URI Class Initialized
INFO - 2018-06-04 23:51:01 --> Router Class Initialized
INFO - 2018-06-04 23:51:01 --> Output Class Initialized
INFO - 2018-06-04 23:51:01 --> Security Class Initialized
DEBUG - 2018-06-04 23:51:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-04 23:51:01 --> Input Class Initialized
INFO - 2018-06-04 23:51:01 --> Language Class Initialized
ERROR - 2018-06-04 23:51:02 --> 404 Page Not Found: /index
INFO - 2018-06-04 23:51:02 --> Config Class Initialized
INFO - 2018-06-04 23:51:02 --> Hooks Class Initialized
DEBUG - 2018-06-04 23:51:02 --> UTF-8 Support Enabled
INFO - 2018-06-04 23:51:02 --> Utf8 Class Initialized
INFO - 2018-06-04 23:51:02 --> URI Class Initialized
INFO - 2018-06-04 23:51:02 --> Router Class Initialized
INFO - 2018-06-04 23:51:02 --> Output Class Initialized
INFO - 2018-06-04 23:51:02 --> Security Class Initialized
INFO - 2018-06-04 23:51:02 --> Config Class Initialized
DEBUG - 2018-06-04 23:51:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-04 23:51:02 --> Hooks Class Initialized
INFO - 2018-06-04 23:51:02 --> Input Class Initialized
DEBUG - 2018-06-04 23:51:02 --> UTF-8 Support Enabled
INFO - 2018-06-04 23:51:02 --> Utf8 Class Initialized
INFO - 2018-06-04 23:51:02 --> Language Class Initialized
INFO - 2018-06-04 23:51:02 --> URI Class Initialized
ERROR - 2018-06-04 23:51:02 --> 404 Page Not Found: /index
INFO - 2018-06-04 23:51:02 --> Router Class Initialized
INFO - 2018-06-04 23:51:02 --> Output Class Initialized
INFO - 2018-06-04 23:51:02 --> Security Class Initialized
DEBUG - 2018-06-04 23:51:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-04 23:51:02 --> Input Class Initialized
INFO - 2018-06-04 23:51:02 --> Language Class Initialized
ERROR - 2018-06-04 23:51:02 --> 404 Page Not Found: /index
INFO - 2018-06-04 23:51:02 --> Config Class Initialized
INFO - 2018-06-04 23:51:02 --> Hooks Class Initialized
DEBUG - 2018-06-04 23:51:02 --> UTF-8 Support Enabled
INFO - 2018-06-04 23:51:02 --> Utf8 Class Initialized
INFO - 2018-06-04 23:51:02 --> URI Class Initialized
INFO - 2018-06-04 23:51:02 --> Router Class Initialized
INFO - 2018-06-04 23:51:02 --> Output Class Initialized
INFO - 2018-06-04 23:51:02 --> Security Class Initialized
DEBUG - 2018-06-04 23:51:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-04 23:51:02 --> Input Class Initialized
INFO - 2018-06-04 23:51:02 --> Language Class Initialized
ERROR - 2018-06-04 23:51:02 --> 404 Page Not Found: /index
INFO - 2018-06-04 23:51:02 --> Config Class Initialized
INFO - 2018-06-04 23:51:02 --> Hooks Class Initialized
DEBUG - 2018-06-04 23:51:02 --> UTF-8 Support Enabled
INFO - 2018-06-04 23:51:02 --> Utf8 Class Initialized
INFO - 2018-06-04 23:51:02 --> URI Class Initialized
INFO - 2018-06-04 23:51:02 --> Router Class Initialized
INFO - 2018-06-04 23:51:02 --> Output Class Initialized
INFO - 2018-06-04 23:51:02 --> Security Class Initialized
DEBUG - 2018-06-04 23:51:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-04 23:51:02 --> Input Class Initialized
INFO - 2018-06-04 23:51:02 --> Language Class Initialized
ERROR - 2018-06-04 23:51:02 --> 404 Page Not Found: /index
INFO - 2018-06-04 23:51:02 --> Config Class Initialized
INFO - 2018-06-04 23:51:02 --> Hooks Class Initialized
DEBUG - 2018-06-04 23:51:02 --> UTF-8 Support Enabled
INFO - 2018-06-04 23:51:02 --> Utf8 Class Initialized
INFO - 2018-06-04 23:51:02 --> URI Class Initialized
INFO - 2018-06-04 23:51:02 --> Router Class Initialized
INFO - 2018-06-04 23:51:02 --> Output Class Initialized
INFO - 2018-06-04 23:51:02 --> Security Class Initialized
DEBUG - 2018-06-04 23:51:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-04 23:51:02 --> Input Class Initialized
INFO - 2018-06-04 23:51:02 --> Language Class Initialized
ERROR - 2018-06-04 23:51:02 --> 404 Page Not Found: /index
INFO - 2018-06-04 23:51:10 --> Config Class Initialized
INFO - 2018-06-04 23:51:10 --> Hooks Class Initialized
DEBUG - 2018-06-04 23:51:10 --> UTF-8 Support Enabled
INFO - 2018-06-04 23:51:10 --> Utf8 Class Initialized
INFO - 2018-06-04 23:51:10 --> URI Class Initialized
INFO - 2018-06-04 23:51:10 --> Router Class Initialized
INFO - 2018-06-04 23:51:10 --> Output Class Initialized
INFO - 2018-06-04 23:51:10 --> Security Class Initialized
DEBUG - 2018-06-04 23:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-04 23:51:10 --> Input Class Initialized
INFO - 2018-06-04 23:51:10 --> Language Class Initialized
INFO - 2018-06-04 23:51:10 --> Language Class Initialized
INFO - 2018-06-04 23:51:10 --> Config Class Initialized
INFO - 2018-06-04 23:51:10 --> Loader Class Initialized
DEBUG - 2018-06-04 23:51:10 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-04 23:51:10 --> Helper loaded: url_helper
INFO - 2018-06-04 23:51:10 --> Helper loaded: form_helper
INFO - 2018-06-04 23:51:10 --> Helper loaded: date_helper
INFO - 2018-06-04 23:51:10 --> Helper loaded: util_helper
INFO - 2018-06-04 23:51:10 --> Helper loaded: text_helper
INFO - 2018-06-04 23:51:10 --> Helper loaded: string_helper
INFO - 2018-06-04 23:51:10 --> Database Driver Class Initialized
DEBUG - 2018-06-04 23:51:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-04 23:51:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-04 23:51:10 --> Email Class Initialized
INFO - 2018-06-04 23:51:10 --> Controller Class Initialized
DEBUG - 2018-06-04 23:51:10 --> Login MX_Controller Initialized
INFO - 2018-06-04 23:51:10 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-04 23:51:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-04 23:51:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-04 23:51:10 --> 4 Loggedout
INFO - 2018-06-04 23:51:10 --> Config Class Initialized
INFO - 2018-06-04 23:51:10 --> Hooks Class Initialized
DEBUG - 2018-06-04 23:51:10 --> UTF-8 Support Enabled
INFO - 2018-06-04 23:51:10 --> Utf8 Class Initialized
INFO - 2018-06-04 23:51:10 --> URI Class Initialized
INFO - 2018-06-04 23:51:10 --> Router Class Initialized
INFO - 2018-06-04 23:51:10 --> Output Class Initialized
INFO - 2018-06-04 23:51:10 --> Security Class Initialized
DEBUG - 2018-06-04 23:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-04 23:51:10 --> Input Class Initialized
INFO - 2018-06-04 23:51:10 --> Language Class Initialized
INFO - 2018-06-04 23:51:10 --> Language Class Initialized
INFO - 2018-06-04 23:51:10 --> Config Class Initialized
INFO - 2018-06-04 23:51:10 --> Loader Class Initialized
DEBUG - 2018-06-04 23:51:10 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-04 23:51:10 --> Helper loaded: url_helper
INFO - 2018-06-04 23:51:10 --> Helper loaded: form_helper
INFO - 2018-06-04 23:51:10 --> Helper loaded: date_helper
INFO - 2018-06-04 23:51:10 --> Helper loaded: util_helper
INFO - 2018-06-04 23:51:10 --> Helper loaded: text_helper
INFO - 2018-06-04 23:51:10 --> Helper loaded: string_helper
INFO - 2018-06-04 23:51:10 --> Database Driver Class Initialized
DEBUG - 2018-06-04 23:51:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-04 23:51:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-04 23:51:10 --> Email Class Initialized
INFO - 2018-06-04 23:51:10 --> Controller Class Initialized
DEBUG - 2018-06-04 23:51:10 --> Home MX_Controller Initialized
DEBUG - 2018-06-04 23:51:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-04 23:51:10 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-04 23:51:10 --> Login MX_Controller Initialized
INFO - 2018-06-04 23:51:10 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-04 23:51:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-04 23:51:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-04 23:51:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-06-04 23:51:17 --> Config Class Initialized
INFO - 2018-06-04 23:51:17 --> Hooks Class Initialized
DEBUG - 2018-06-04 23:51:17 --> UTF-8 Support Enabled
INFO - 2018-06-04 23:51:17 --> Utf8 Class Initialized
INFO - 2018-06-04 23:51:17 --> URI Class Initialized
INFO - 2018-06-04 23:51:17 --> Router Class Initialized
INFO - 2018-06-04 23:51:17 --> Output Class Initialized
INFO - 2018-06-04 23:51:17 --> Security Class Initialized
DEBUG - 2018-06-04 23:51:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-04 23:51:17 --> Input Class Initialized
INFO - 2018-06-04 23:51:17 --> Language Class Initialized
INFO - 2018-06-04 23:51:17 --> Language Class Initialized
INFO - 2018-06-04 23:51:17 --> Config Class Initialized
INFO - 2018-06-04 23:51:17 --> Loader Class Initialized
DEBUG - 2018-06-04 23:51:17 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-04 23:51:17 --> Helper loaded: url_helper
INFO - 2018-06-04 23:51:17 --> Helper loaded: form_helper
INFO - 2018-06-04 23:51:17 --> Helper loaded: date_helper
INFO - 2018-06-04 23:51:17 --> Helper loaded: util_helper
INFO - 2018-06-04 23:51:17 --> Helper loaded: text_helper
INFO - 2018-06-04 23:51:17 --> Helper loaded: string_helper
INFO - 2018-06-04 23:51:17 --> Database Driver Class Initialized
DEBUG - 2018-06-04 23:51:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-04 23:51:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-04 23:51:17 --> Email Class Initialized
INFO - 2018-06-04 23:51:17 --> Controller Class Initialized
DEBUG - 2018-06-04 23:51:17 --> Home MX_Controller Initialized
DEBUG - 2018-06-04 23:51:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-04 23:51:17 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-04 23:51:17 --> Login MX_Controller Initialized
INFO - 2018-06-04 23:51:17 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-04 23:51:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-04 23:51:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-04 23:51:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-06-04 23:51:22 --> Config Class Initialized
INFO - 2018-06-04 23:51:22 --> Hooks Class Initialized
DEBUG - 2018-06-04 23:51:22 --> UTF-8 Support Enabled
INFO - 2018-06-04 23:51:22 --> Utf8 Class Initialized
INFO - 2018-06-04 23:51:22 --> URI Class Initialized
INFO - 2018-06-04 23:51:22 --> Router Class Initialized
INFO - 2018-06-04 23:51:22 --> Output Class Initialized
INFO - 2018-06-04 23:51:22 --> Security Class Initialized
DEBUG - 2018-06-04 23:51:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-04 23:51:22 --> Input Class Initialized
INFO - 2018-06-04 23:51:22 --> Language Class Initialized
INFO - 2018-06-04 23:51:22 --> Language Class Initialized
INFO - 2018-06-04 23:51:22 --> Config Class Initialized
INFO - 2018-06-04 23:51:22 --> Loader Class Initialized
DEBUG - 2018-06-04 23:51:22 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-04 23:51:22 --> Helper loaded: url_helper
INFO - 2018-06-04 23:51:22 --> Helper loaded: form_helper
INFO - 2018-06-04 23:51:22 --> Helper loaded: date_helper
INFO - 2018-06-04 23:51:22 --> Helper loaded: util_helper
INFO - 2018-06-04 23:51:22 --> Helper loaded: text_helper
INFO - 2018-06-04 23:51:22 --> Helper loaded: string_helper
INFO - 2018-06-04 23:51:22 --> Database Driver Class Initialized
DEBUG - 2018-06-04 23:51:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-04 23:51:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-04 23:51:22 --> Email Class Initialized
INFO - 2018-06-04 23:51:22 --> Controller Class Initialized
DEBUG - 2018-06-04 23:51:22 --> Login MX_Controller Initialized
INFO - 2018-06-04 23:51:22 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-04 23:51:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-04 23:51:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-04 23:51:22 --> Email starts for user@colin.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-06-04 23:51:22 --> User session created for 4
INFO - 2018-06-04 23:51:23 --> Login status user@colin.com - success
INFO - 2018-06-04 23:51:23 --> Final output sent to browser
DEBUG - 2018-06-04 23:51:23 --> Total execution time: 0.4690
INFO - 2018-06-04 23:51:23 --> Config Class Initialized
INFO - 2018-06-04 23:51:23 --> Hooks Class Initialized
DEBUG - 2018-06-04 23:51:23 --> UTF-8 Support Enabled
INFO - 2018-06-04 23:51:23 --> Utf8 Class Initialized
INFO - 2018-06-04 23:51:23 --> URI Class Initialized
INFO - 2018-06-04 23:51:23 --> Router Class Initialized
INFO - 2018-06-04 23:51:23 --> Output Class Initialized
INFO - 2018-06-04 23:51:23 --> Security Class Initialized
DEBUG - 2018-06-04 23:51:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-04 23:51:23 --> Input Class Initialized
INFO - 2018-06-04 23:51:23 --> Language Class Initialized
INFO - 2018-06-04 23:51:23 --> Language Class Initialized
INFO - 2018-06-04 23:51:23 --> Config Class Initialized
INFO - 2018-06-04 23:51:23 --> Loader Class Initialized
DEBUG - 2018-06-04 23:51:23 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-04 23:51:23 --> Helper loaded: url_helper
INFO - 2018-06-04 23:51:23 --> Helper loaded: form_helper
INFO - 2018-06-04 23:51:23 --> Helper loaded: date_helper
INFO - 2018-06-04 23:51:23 --> Helper loaded: util_helper
INFO - 2018-06-04 23:51:23 --> Helper loaded: text_helper
INFO - 2018-06-04 23:51:23 --> Helper loaded: string_helper
INFO - 2018-06-04 23:51:23 --> Database Driver Class Initialized
DEBUG - 2018-06-04 23:51:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-04 23:51:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-04 23:51:23 --> Email Class Initialized
INFO - 2018-06-04 23:51:23 --> Controller Class Initialized
DEBUG - 2018-06-04 23:51:23 --> Home MX_Controller Initialized
DEBUG - 2018-06-04 23:51:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-04 23:51:23 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-04 23:51:23 --> Login MX_Controller Initialized
INFO - 2018-06-04 23:51:23 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-04 23:51:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-04 23:51:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-04 23:51:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-04 23:51:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-04 23:51:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-04 23:51:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-04 23:51:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-04 23:51:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-06-04 23:51:23 --> Final output sent to browser
DEBUG - 2018-06-04 23:51:23 --> Total execution time: 0.4803
INFO - 2018-06-04 23:51:23 --> Config Class Initialized
INFO - 2018-06-04 23:51:23 --> Config Class Initialized
INFO - 2018-06-04 23:51:23 --> Hooks Class Initialized
INFO - 2018-06-04 23:51:23 --> Hooks Class Initialized
DEBUG - 2018-06-04 23:51:24 --> UTF-8 Support Enabled
DEBUG - 2018-06-04 23:51:24 --> UTF-8 Support Enabled
INFO - 2018-06-04 23:51:24 --> Utf8 Class Initialized
INFO - 2018-06-04 23:51:24 --> URI Class Initialized
INFO - 2018-06-04 23:51:24 --> Router Class Initialized
INFO - 2018-06-04 23:51:24 --> Output Class Initialized
INFO - 2018-06-04 23:51:24 --> Utf8 Class Initialized
INFO - 2018-06-04 23:51:24 --> Security Class Initialized
INFO - 2018-06-04 23:51:24 --> URI Class Initialized
DEBUG - 2018-06-04 23:51:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-04 23:51:24 --> Router Class Initialized
INFO - 2018-06-04 23:51:24 --> Input Class Initialized
INFO - 2018-06-04 23:51:24 --> Language Class Initialized
INFO - 2018-06-04 23:51:24 --> Output Class Initialized
ERROR - 2018-06-04 23:51:24 --> 404 Page Not Found: /index
INFO - 2018-06-04 23:51:24 --> Security Class Initialized
DEBUG - 2018-06-04 23:51:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-04 23:51:24 --> Input Class Initialized
INFO - 2018-06-04 23:51:24 --> Language Class Initialized
ERROR - 2018-06-04 23:51:24 --> 404 Page Not Found: /index
INFO - 2018-06-04 23:51:24 --> Config Class Initialized
INFO - 2018-06-04 23:51:24 --> Hooks Class Initialized
DEBUG - 2018-06-04 23:51:24 --> UTF-8 Support Enabled
INFO - 2018-06-04 23:51:24 --> Utf8 Class Initialized
INFO - 2018-06-04 23:51:24 --> URI Class Initialized
INFO - 2018-06-04 23:51:24 --> Router Class Initialized
INFO - 2018-06-04 23:51:24 --> Output Class Initialized
INFO - 2018-06-04 23:51:24 --> Security Class Initialized
DEBUG - 2018-06-04 23:51:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-04 23:51:24 --> Input Class Initialized
INFO - 2018-06-04 23:51:25 --> Language Class Initialized
ERROR - 2018-06-04 23:51:25 --> 404 Page Not Found: /index
INFO - 2018-06-04 23:51:25 --> Config Class Initialized
INFO - 2018-06-04 23:51:25 --> Hooks Class Initialized
DEBUG - 2018-06-04 23:51:25 --> UTF-8 Support Enabled
INFO - 2018-06-04 23:51:25 --> Utf8 Class Initialized
INFO - 2018-06-04 23:51:25 --> URI Class Initialized
INFO - 2018-06-04 23:51:25 --> Router Class Initialized
INFO - 2018-06-04 23:51:25 --> Output Class Initialized
INFO - 2018-06-04 23:51:25 --> Security Class Initialized
DEBUG - 2018-06-04 23:51:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-04 23:51:25 --> Input Class Initialized
INFO - 2018-06-04 23:51:25 --> Language Class Initialized
ERROR - 2018-06-04 23:51:25 --> 404 Page Not Found: /index
INFO - 2018-06-04 23:51:25 --> Config Class Initialized
INFO - 2018-06-04 23:51:25 --> Hooks Class Initialized
DEBUG - 2018-06-04 23:51:26 --> UTF-8 Support Enabled
INFO - 2018-06-04 23:51:26 --> Utf8 Class Initialized
INFO - 2018-06-04 23:51:26 --> URI Class Initialized
INFO - 2018-06-04 23:51:26 --> Router Class Initialized
INFO - 2018-06-04 23:51:26 --> Output Class Initialized
INFO - 2018-06-04 23:51:26 --> Security Class Initialized
DEBUG - 2018-06-04 23:51:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-04 23:51:26 --> Input Class Initialized
INFO - 2018-06-04 23:51:26 --> Language Class Initialized
ERROR - 2018-06-04 23:51:26 --> 404 Page Not Found: /index
INFO - 2018-06-04 23:51:26 --> Config Class Initialized
INFO - 2018-06-04 23:51:26 --> Hooks Class Initialized
DEBUG - 2018-06-04 23:51:26 --> UTF-8 Support Enabled
INFO - 2018-06-04 23:51:26 --> Utf8 Class Initialized
INFO - 2018-06-04 23:51:26 --> URI Class Initialized
INFO - 2018-06-04 23:51:26 --> Router Class Initialized
INFO - 2018-06-04 23:51:26 --> Output Class Initialized
INFO - 2018-06-04 23:51:26 --> Security Class Initialized
DEBUG - 2018-06-04 23:51:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-04 23:51:26 --> Input Class Initialized
INFO - 2018-06-04 23:51:26 --> Language Class Initialized
ERROR - 2018-06-04 23:51:26 --> 404 Page Not Found: /index
INFO - 2018-06-04 23:51:26 --> Config Class Initialized
INFO - 2018-06-04 23:51:26 --> Hooks Class Initialized
DEBUG - 2018-06-04 23:51:26 --> UTF-8 Support Enabled
INFO - 2018-06-04 23:51:26 --> Utf8 Class Initialized
INFO - 2018-06-04 23:51:26 --> URI Class Initialized
INFO - 2018-06-04 23:51:26 --> Router Class Initialized
INFO - 2018-06-04 23:51:26 --> Output Class Initialized
INFO - 2018-06-04 23:51:26 --> Security Class Initialized
DEBUG - 2018-06-04 23:51:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-04 23:51:26 --> Input Class Initialized
INFO - 2018-06-04 23:51:26 --> Language Class Initialized
ERROR - 2018-06-04 23:51:26 --> 404 Page Not Found: /index
INFO - 2018-06-04 23:51:26 --> Config Class Initialized
INFO - 2018-06-04 23:51:26 --> Hooks Class Initialized
DEBUG - 2018-06-04 23:51:26 --> UTF-8 Support Enabled
INFO - 2018-06-04 23:51:26 --> Utf8 Class Initialized
INFO - 2018-06-04 23:51:26 --> URI Class Initialized
INFO - 2018-06-04 23:51:26 --> Router Class Initialized
INFO - 2018-06-04 23:51:26 --> Output Class Initialized
INFO - 2018-06-04 23:51:26 --> Security Class Initialized
DEBUG - 2018-06-04 23:51:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-04 23:51:26 --> Input Class Initialized
INFO - 2018-06-04 23:51:26 --> Language Class Initialized
ERROR - 2018-06-04 23:51:26 --> 404 Page Not Found: /index
INFO - 2018-06-04 23:51:31 --> Config Class Initialized
INFO - 2018-06-04 23:51:31 --> Hooks Class Initialized
DEBUG - 2018-06-04 23:51:31 --> UTF-8 Support Enabled
INFO - 2018-06-04 23:51:31 --> Utf8 Class Initialized
INFO - 2018-06-04 23:51:31 --> URI Class Initialized
INFO - 2018-06-04 23:51:31 --> Router Class Initialized
INFO - 2018-06-04 23:51:31 --> Output Class Initialized
INFO - 2018-06-04 23:51:31 --> Security Class Initialized
DEBUG - 2018-06-04 23:51:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-04 23:51:31 --> Input Class Initialized
INFO - 2018-06-04 23:51:31 --> Language Class Initialized
INFO - 2018-06-04 23:51:31 --> Language Class Initialized
INFO - 2018-06-04 23:51:31 --> Config Class Initialized
INFO - 2018-06-04 23:51:31 --> Loader Class Initialized
DEBUG - 2018-06-04 23:51:31 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-04 23:51:31 --> Helper loaded: url_helper
INFO - 2018-06-04 23:51:31 --> Helper loaded: form_helper
INFO - 2018-06-04 23:51:31 --> Helper loaded: date_helper
INFO - 2018-06-04 23:51:31 --> Helper loaded: util_helper
INFO - 2018-06-04 23:51:31 --> Helper loaded: text_helper
INFO - 2018-06-04 23:51:31 --> Helper loaded: string_helper
INFO - 2018-06-04 23:51:31 --> Database Driver Class Initialized
DEBUG - 2018-06-04 23:51:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-04 23:51:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-04 23:51:31 --> Email Class Initialized
INFO - 2018-06-04 23:51:31 --> Controller Class Initialized
DEBUG - 2018-06-04 23:51:31 --> Home MX_Controller Initialized
DEBUG - 2018-06-04 23:51:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-04 23:51:31 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-04 23:51:31 --> Login MX_Controller Initialized
INFO - 2018-06-04 23:51:31 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-04 23:51:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-04 23:51:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-04 23:51:31 --> Config Class Initialized
INFO - 2018-06-04 23:51:31 --> Hooks Class Initialized
DEBUG - 2018-06-04 23:51:31 --> UTF-8 Support Enabled
INFO - 2018-06-04 23:51:31 --> Utf8 Class Initialized
INFO - 2018-06-04 23:51:31 --> URI Class Initialized
INFO - 2018-06-04 23:51:31 --> Router Class Initialized
INFO - 2018-06-04 23:51:31 --> Output Class Initialized
INFO - 2018-06-04 23:51:31 --> Security Class Initialized
DEBUG - 2018-06-04 23:51:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-04 23:51:31 --> Input Class Initialized
INFO - 2018-06-04 23:51:31 --> Language Class Initialized
INFO - 2018-06-04 23:51:31 --> Language Class Initialized
INFO - 2018-06-04 23:51:31 --> Config Class Initialized
INFO - 2018-06-04 23:51:31 --> Loader Class Initialized
DEBUG - 2018-06-04 23:51:31 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-04 23:51:31 --> Helper loaded: url_helper
INFO - 2018-06-04 23:51:31 --> Helper loaded: form_helper
INFO - 2018-06-04 23:51:31 --> Helper loaded: date_helper
INFO - 2018-06-04 23:51:31 --> Helper loaded: util_helper
INFO - 2018-06-04 23:51:31 --> Helper loaded: text_helper
INFO - 2018-06-04 23:51:31 --> Helper loaded: string_helper
INFO - 2018-06-04 23:51:32 --> Database Driver Class Initialized
DEBUG - 2018-06-04 23:51:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-04 23:51:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-04 23:51:32 --> Email Class Initialized
INFO - 2018-06-04 23:51:32 --> Controller Class Initialized
DEBUG - 2018-06-04 23:51:32 --> Home MX_Controller Initialized
DEBUG - 2018-06-04 23:51:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-04 23:51:32 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-04 23:51:32 --> Login MX_Controller Initialized
INFO - 2018-06-04 23:51:32 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-04 23:51:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-04 23:51:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-04 23:51:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-04 23:51:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-04 23:51:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-04 23:51:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-04 23:51:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-04 23:51:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-06-04 23:51:32 --> Final output sent to browser
DEBUG - 2018-06-04 23:51:32 --> Total execution time: 0.4454
INFO - 2018-06-04 23:51:32 --> Config Class Initialized
INFO - 2018-06-04 23:51:32 --> Hooks Class Initialized
DEBUG - 2018-06-04 23:51:32 --> UTF-8 Support Enabled
INFO - 2018-06-04 23:51:32 --> Utf8 Class Initialized
INFO - 2018-06-04 23:51:32 --> URI Class Initialized
INFO - 2018-06-04 23:51:32 --> Router Class Initialized
INFO - 2018-06-04 23:51:33 --> Output Class Initialized
INFO - 2018-06-04 23:51:33 --> Security Class Initialized
DEBUG - 2018-06-04 23:51:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-04 23:51:33 --> Input Class Initialized
INFO - 2018-06-04 23:51:33 --> Language Class Initialized
ERROR - 2018-06-04 23:51:33 --> 404 Page Not Found: /index
INFO - 2018-06-04 23:51:33 --> Config Class Initialized
INFO - 2018-06-04 23:51:33 --> Hooks Class Initialized
DEBUG - 2018-06-04 23:51:33 --> UTF-8 Support Enabled
INFO - 2018-06-04 23:51:33 --> Utf8 Class Initialized
INFO - 2018-06-04 23:51:33 --> URI Class Initialized
INFO - 2018-06-04 23:51:33 --> Router Class Initialized
INFO - 2018-06-04 23:51:33 --> Output Class Initialized
INFO - 2018-06-04 23:51:33 --> Security Class Initialized
DEBUG - 2018-06-04 23:51:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-04 23:51:33 --> Input Class Initialized
INFO - 2018-06-04 23:51:33 --> Language Class Initialized
ERROR - 2018-06-04 23:51:33 --> 404 Page Not Found: /index
INFO - 2018-06-04 23:51:33 --> Config Class Initialized
INFO - 2018-06-04 23:51:33 --> Hooks Class Initialized
DEBUG - 2018-06-04 23:51:33 --> UTF-8 Support Enabled
INFO - 2018-06-04 23:51:33 --> Utf8 Class Initialized
INFO - 2018-06-04 23:51:33 --> URI Class Initialized
INFO - 2018-06-04 23:51:33 --> Router Class Initialized
INFO - 2018-06-04 23:51:33 --> Output Class Initialized
INFO - 2018-06-04 23:51:33 --> Security Class Initialized
DEBUG - 2018-06-04 23:51:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-04 23:51:33 --> Input Class Initialized
INFO - 2018-06-04 23:51:33 --> Language Class Initialized
ERROR - 2018-06-04 23:51:33 --> 404 Page Not Found: /index
INFO - 2018-06-04 23:56:30 --> Config Class Initialized
INFO - 2018-06-04 23:56:30 --> Hooks Class Initialized
DEBUG - 2018-06-04 23:56:30 --> UTF-8 Support Enabled
INFO - 2018-06-04 23:56:30 --> Utf8 Class Initialized
INFO - 2018-06-04 23:56:30 --> URI Class Initialized
INFO - 2018-06-04 23:56:30 --> Router Class Initialized
INFO - 2018-06-04 23:56:30 --> Output Class Initialized
INFO - 2018-06-04 23:56:30 --> Security Class Initialized
DEBUG - 2018-06-04 23:56:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-04 23:56:30 --> Input Class Initialized
INFO - 2018-06-04 23:56:30 --> Language Class Initialized
INFO - 2018-06-04 23:56:30 --> Language Class Initialized
INFO - 2018-06-04 23:56:30 --> Config Class Initialized
INFO - 2018-06-04 23:56:30 --> Loader Class Initialized
DEBUG - 2018-06-04 23:56:30 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-04 23:56:30 --> Helper loaded: url_helper
INFO - 2018-06-04 23:56:30 --> Helper loaded: form_helper
INFO - 2018-06-04 23:56:30 --> Helper loaded: date_helper
INFO - 2018-06-04 23:56:30 --> Helper loaded: util_helper
INFO - 2018-06-04 23:56:30 --> Helper loaded: text_helper
INFO - 2018-06-04 23:56:31 --> Helper loaded: string_helper
INFO - 2018-06-04 23:56:31 --> Database Driver Class Initialized
DEBUG - 2018-06-04 23:56:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-04 23:56:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-04 23:56:31 --> Email Class Initialized
INFO - 2018-06-04 23:56:31 --> Controller Class Initialized
DEBUG - 2018-06-04 23:56:31 --> Login MX_Controller Initialized
INFO - 2018-06-04 23:56:31 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-04 23:56:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-04 23:56:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-04 23:56:31 --> Email starts for gopipanguluri123@gmail.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-06-04 23:56:31 --> Login status gopipanguluri123@gmail.com - failure
INFO - 2018-06-04 23:56:31 --> Final output sent to browser
DEBUG - 2018-06-04 23:56:31 --> Total execution time: 0.3207
INFO - 2018-06-04 23:56:34 --> Config Class Initialized
INFO - 2018-06-04 23:56:34 --> Hooks Class Initialized
DEBUG - 2018-06-04 23:56:34 --> UTF-8 Support Enabled
INFO - 2018-06-04 23:56:34 --> Utf8 Class Initialized
INFO - 2018-06-04 23:56:34 --> URI Class Initialized
INFO - 2018-06-04 23:56:34 --> Router Class Initialized
INFO - 2018-06-04 23:56:34 --> Output Class Initialized
INFO - 2018-06-04 23:56:34 --> Security Class Initialized
DEBUG - 2018-06-04 23:56:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-04 23:56:34 --> Input Class Initialized
INFO - 2018-06-04 23:56:34 --> Language Class Initialized
INFO - 2018-06-04 23:56:34 --> Language Class Initialized
INFO - 2018-06-04 23:56:34 --> Config Class Initialized
INFO - 2018-06-04 23:56:34 --> Loader Class Initialized
DEBUG - 2018-06-04 23:56:34 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-04 23:56:34 --> Helper loaded: url_helper
INFO - 2018-06-04 23:56:34 --> Helper loaded: form_helper
INFO - 2018-06-04 23:56:34 --> Helper loaded: date_helper
INFO - 2018-06-04 23:56:34 --> Helper loaded: util_helper
INFO - 2018-06-04 23:56:34 --> Helper loaded: text_helper
INFO - 2018-06-04 23:56:34 --> Helper loaded: string_helper
INFO - 2018-06-04 23:56:34 --> Database Driver Class Initialized
DEBUG - 2018-06-04 23:56:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-04 23:56:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-04 23:56:34 --> Email Class Initialized
INFO - 2018-06-04 23:56:34 --> Controller Class Initialized
DEBUG - 2018-06-04 23:56:34 --> Login MX_Controller Initialized
INFO - 2018-06-04 23:56:34 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-04 23:56:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-04 23:56:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-04 23:56:34 --> Email starts for user@colin.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-06-04 23:56:34 --> User session created for 4
INFO - 2018-06-04 23:56:34 --> Login status user@colin.com - success
INFO - 2018-06-04 23:56:35 --> Final output sent to browser
DEBUG - 2018-06-04 23:56:35 --> Total execution time: 0.4161
INFO - 2018-06-04 23:56:35 --> Config Class Initialized
INFO - 2018-06-04 23:56:35 --> Hooks Class Initialized
DEBUG - 2018-06-04 23:56:35 --> UTF-8 Support Enabled
INFO - 2018-06-04 23:56:35 --> Utf8 Class Initialized
INFO - 2018-06-04 23:56:35 --> URI Class Initialized
INFO - 2018-06-04 23:56:35 --> Router Class Initialized
INFO - 2018-06-04 23:56:35 --> Output Class Initialized
INFO - 2018-06-04 23:56:35 --> Security Class Initialized
DEBUG - 2018-06-04 23:56:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-04 23:56:35 --> Input Class Initialized
INFO - 2018-06-04 23:56:35 --> Language Class Initialized
INFO - 2018-06-04 23:56:35 --> Language Class Initialized
INFO - 2018-06-04 23:56:35 --> Config Class Initialized
INFO - 2018-06-04 23:56:35 --> Loader Class Initialized
DEBUG - 2018-06-04 23:56:35 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-04 23:56:35 --> Helper loaded: url_helper
INFO - 2018-06-04 23:56:35 --> Helper loaded: form_helper
INFO - 2018-06-04 23:56:35 --> Helper loaded: date_helper
INFO - 2018-06-04 23:56:35 --> Helper loaded: util_helper
INFO - 2018-06-04 23:56:35 --> Helper loaded: text_helper
INFO - 2018-06-04 23:56:35 --> Helper loaded: string_helper
INFO - 2018-06-04 23:56:35 --> Database Driver Class Initialized
DEBUG - 2018-06-04 23:56:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-04 23:56:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-04 23:56:35 --> Email Class Initialized
INFO - 2018-06-04 23:56:35 --> Controller Class Initialized
DEBUG - 2018-06-04 23:56:35 --> Home MX_Controller Initialized
DEBUG - 2018-06-04 23:56:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-04 23:56:35 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-04 23:56:35 --> Login MX_Controller Initialized
INFO - 2018-06-04 23:56:35 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-04 23:56:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-04 23:56:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-04 23:56:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-04 23:56:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-04 23:56:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-04 23:56:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-04 23:56:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-04 23:56:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-06-04 23:56:35 --> Final output sent to browser
DEBUG - 2018-06-04 23:56:35 --> Total execution time: 0.4593
INFO - 2018-06-04 23:56:36 --> Config Class Initialized
INFO - 2018-06-04 23:56:36 --> Hooks Class Initialized
DEBUG - 2018-06-04 23:56:36 --> UTF-8 Support Enabled
INFO - 2018-06-04 23:56:36 --> Utf8 Class Initialized
INFO - 2018-06-04 23:56:36 --> URI Class Initialized
INFO - 2018-06-04 23:56:36 --> Router Class Initialized
INFO - 2018-06-04 23:56:36 --> Output Class Initialized
INFO - 2018-06-04 23:56:36 --> Security Class Initialized
DEBUG - 2018-06-04 23:56:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-04 23:56:36 --> Input Class Initialized
INFO - 2018-06-04 23:56:36 --> Language Class Initialized
ERROR - 2018-06-04 23:56:36 --> 404 Page Not Found: /index
INFO - 2018-06-04 23:56:36 --> Config Class Initialized
INFO - 2018-06-04 23:56:36 --> Hooks Class Initialized
DEBUG - 2018-06-04 23:56:36 --> UTF-8 Support Enabled
INFO - 2018-06-04 23:56:36 --> Utf8 Class Initialized
INFO - 2018-06-04 23:56:36 --> URI Class Initialized
INFO - 2018-06-04 23:56:36 --> Router Class Initialized
INFO - 2018-06-04 23:56:36 --> Output Class Initialized
INFO - 2018-06-04 23:56:36 --> Security Class Initialized
DEBUG - 2018-06-04 23:56:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-04 23:56:36 --> Input Class Initialized
INFO - 2018-06-04 23:56:36 --> Language Class Initialized
ERROR - 2018-06-04 23:56:36 --> 404 Page Not Found: /index
INFO - 2018-06-04 23:56:36 --> Config Class Initialized
INFO - 2018-06-04 23:56:37 --> Config Class Initialized
INFO - 2018-06-04 23:56:37 --> Hooks Class Initialized
INFO - 2018-06-04 23:56:37 --> Hooks Class Initialized
DEBUG - 2018-06-04 23:56:37 --> UTF-8 Support Enabled
DEBUG - 2018-06-04 23:56:37 --> UTF-8 Support Enabled
INFO - 2018-06-04 23:56:37 --> Utf8 Class Initialized
INFO - 2018-06-04 23:56:37 --> Utf8 Class Initialized
INFO - 2018-06-04 23:56:37 --> URI Class Initialized
INFO - 2018-06-04 23:56:37 --> URI Class Initialized
INFO - 2018-06-04 23:56:37 --> Router Class Initialized
INFO - 2018-06-04 23:56:37 --> Router Class Initialized
INFO - 2018-06-04 23:56:37 --> Output Class Initialized
INFO - 2018-06-04 23:56:37 --> Security Class Initialized
DEBUG - 2018-06-04 23:56:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-04 23:56:37 --> Input Class Initialized
INFO - 2018-06-04 23:56:37 --> Language Class Initialized
ERROR - 2018-06-04 23:56:37 --> 404 Page Not Found: /index
INFO - 2018-06-04 23:56:37 --> Output Class Initialized
INFO - 2018-06-04 23:56:37 --> Config Class Initialized
INFO - 2018-06-04 23:56:37 --> Hooks Class Initialized
INFO - 2018-06-04 23:56:37 --> Security Class Initialized
DEBUG - 2018-06-04 23:56:37 --> UTF-8 Support Enabled
DEBUG - 2018-06-04 23:56:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-04 23:56:37 --> Utf8 Class Initialized
INFO - 2018-06-04 23:56:37 --> Input Class Initialized
INFO - 2018-06-04 23:56:37 --> URI Class Initialized
INFO - 2018-06-04 23:56:37 --> Language Class Initialized
ERROR - 2018-06-04 23:56:37 --> 404 Page Not Found: /index
INFO - 2018-06-04 23:56:37 --> Router Class Initialized
INFO - 2018-06-04 23:56:37 --> Output Class Initialized
INFO - 2018-06-04 23:56:37 --> Security Class Initialized
DEBUG - 2018-06-04 23:56:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-04 23:56:37 --> Input Class Initialized
INFO - 2018-06-04 23:56:37 --> Language Class Initialized
ERROR - 2018-06-04 23:56:37 --> 404 Page Not Found: /index
INFO - 2018-06-04 23:56:37 --> Config Class Initialized
INFO - 2018-06-04 23:56:37 --> Hooks Class Initialized
DEBUG - 2018-06-04 23:56:37 --> UTF-8 Support Enabled
INFO - 2018-06-04 23:56:37 --> Utf8 Class Initialized
INFO - 2018-06-04 23:56:37 --> URI Class Initialized
INFO - 2018-06-04 23:56:37 --> Router Class Initialized
INFO - 2018-06-04 23:56:37 --> Output Class Initialized
INFO - 2018-06-04 23:56:37 --> Security Class Initialized
DEBUG - 2018-06-04 23:56:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-04 23:56:37 --> Input Class Initialized
INFO - 2018-06-04 23:56:37 --> Language Class Initialized
ERROR - 2018-06-04 23:56:37 --> 404 Page Not Found: /index
INFO - 2018-06-04 23:56:37 --> Config Class Initialized
INFO - 2018-06-04 23:56:37 --> Hooks Class Initialized
DEBUG - 2018-06-04 23:56:37 --> UTF-8 Support Enabled
INFO - 2018-06-04 23:56:37 --> Utf8 Class Initialized
INFO - 2018-06-04 23:56:37 --> URI Class Initialized
INFO - 2018-06-04 23:56:37 --> Router Class Initialized
INFO - 2018-06-04 23:56:37 --> Output Class Initialized
INFO - 2018-06-04 23:56:37 --> Security Class Initialized
DEBUG - 2018-06-04 23:56:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-04 23:56:37 --> Input Class Initialized
INFO - 2018-06-04 23:56:37 --> Language Class Initialized
ERROR - 2018-06-04 23:56:37 --> 404 Page Not Found: /index
INFO - 2018-06-04 23:56:43 --> Config Class Initialized
INFO - 2018-06-04 23:56:43 --> Hooks Class Initialized
DEBUG - 2018-06-04 23:56:43 --> UTF-8 Support Enabled
INFO - 2018-06-04 23:56:43 --> Utf8 Class Initialized
INFO - 2018-06-04 23:56:43 --> URI Class Initialized
INFO - 2018-06-04 23:56:43 --> Router Class Initialized
INFO - 2018-06-04 23:56:43 --> Output Class Initialized
INFO - 2018-06-04 23:56:43 --> Security Class Initialized
DEBUG - 2018-06-04 23:56:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-04 23:56:43 --> Input Class Initialized
INFO - 2018-06-04 23:56:43 --> Language Class Initialized
INFO - 2018-06-04 23:56:43 --> Language Class Initialized
INFO - 2018-06-04 23:56:43 --> Config Class Initialized
INFO - 2018-06-04 23:56:43 --> Loader Class Initialized
DEBUG - 2018-06-04 23:56:43 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-04 23:56:43 --> Helper loaded: url_helper
INFO - 2018-06-04 23:56:43 --> Helper loaded: form_helper
INFO - 2018-06-04 23:56:43 --> Helper loaded: date_helper
INFO - 2018-06-04 23:56:43 --> Helper loaded: util_helper
INFO - 2018-06-04 23:56:43 --> Helper loaded: text_helper
INFO - 2018-06-04 23:56:43 --> Helper loaded: string_helper
INFO - 2018-06-04 23:56:43 --> Database Driver Class Initialized
DEBUG - 2018-06-04 23:56:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-04 23:56:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-04 23:56:43 --> Email Class Initialized
INFO - 2018-06-04 23:56:43 --> Controller Class Initialized
DEBUG - 2018-06-04 23:56:43 --> Home MX_Controller Initialized
DEBUG - 2018-06-04 23:56:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-04 23:56:43 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-04 23:56:43 --> Login MX_Controller Initialized
INFO - 2018-06-04 23:56:43 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-04 23:56:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-04 23:56:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-04 23:56:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-04 23:56:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-04 23:56:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-04 23:56:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-04 23:56:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-04 23:56:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/progress.php
INFO - 2018-06-04 23:56:43 --> Final output sent to browser
DEBUG - 2018-06-04 23:56:43 --> Total execution time: 0.4578
INFO - 2018-06-04 23:56:43 --> Config Class Initialized
INFO - 2018-06-04 23:56:43 --> Hooks Class Initialized
DEBUG - 2018-06-04 23:56:43 --> UTF-8 Support Enabled
INFO - 2018-06-04 23:56:43 --> Utf8 Class Initialized
INFO - 2018-06-04 23:56:43 --> URI Class Initialized
INFO - 2018-06-04 23:56:43 --> Router Class Initialized
INFO - 2018-06-04 23:56:43 --> Output Class Initialized
INFO - 2018-06-04 23:56:43 --> Security Class Initialized
DEBUG - 2018-06-04 23:56:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-04 23:56:43 --> Input Class Initialized
INFO - 2018-06-04 23:56:43 --> Language Class Initialized
ERROR - 2018-06-04 23:56:43 --> 404 Page Not Found: /index
INFO - 2018-06-04 23:56:43 --> Config Class Initialized
INFO - 2018-06-04 23:56:43 --> Hooks Class Initialized
DEBUG - 2018-06-04 23:56:43 --> UTF-8 Support Enabled
INFO - 2018-06-04 23:56:43 --> Utf8 Class Initialized
INFO - 2018-06-04 23:56:43 --> URI Class Initialized
INFO - 2018-06-04 23:56:43 --> Router Class Initialized
INFO - 2018-06-04 23:56:44 --> Output Class Initialized
INFO - 2018-06-04 23:56:44 --> Security Class Initialized
DEBUG - 2018-06-04 23:56:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-04 23:56:44 --> Input Class Initialized
INFO - 2018-06-04 23:56:44 --> Language Class Initialized
ERROR - 2018-06-04 23:56:44 --> 404 Page Not Found: /index
INFO - 2018-06-04 23:56:44 --> Config Class Initialized
INFO - 2018-06-04 23:56:44 --> Hooks Class Initialized
DEBUG - 2018-06-04 23:56:44 --> UTF-8 Support Enabled
INFO - 2018-06-04 23:56:44 --> Utf8 Class Initialized
INFO - 2018-06-04 23:56:44 --> URI Class Initialized
INFO - 2018-06-04 23:56:44 --> Router Class Initialized
INFO - 2018-06-04 23:56:44 --> Output Class Initialized
INFO - 2018-06-04 23:56:44 --> Security Class Initialized
DEBUG - 2018-06-04 23:56:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-04 23:56:44 --> Input Class Initialized
INFO - 2018-06-04 23:56:44 --> Language Class Initialized
ERROR - 2018-06-04 23:56:44 --> 404 Page Not Found: /index
INFO - 2018-06-04 23:56:47 --> Config Class Initialized
INFO - 2018-06-04 23:56:47 --> Hooks Class Initialized
DEBUG - 2018-06-04 23:56:47 --> UTF-8 Support Enabled
INFO - 2018-06-04 23:56:47 --> Utf8 Class Initialized
INFO - 2018-06-04 23:56:47 --> URI Class Initialized
INFO - 2018-06-04 23:56:47 --> Router Class Initialized
INFO - 2018-06-04 23:56:47 --> Output Class Initialized
INFO - 2018-06-04 23:56:47 --> Security Class Initialized
DEBUG - 2018-06-04 23:56:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-04 23:56:47 --> Input Class Initialized
INFO - 2018-06-04 23:56:47 --> Language Class Initialized
INFO - 2018-06-04 23:56:47 --> Language Class Initialized
INFO - 2018-06-04 23:56:47 --> Config Class Initialized
INFO - 2018-06-04 23:56:47 --> Loader Class Initialized
DEBUG - 2018-06-04 23:56:47 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-04 23:56:47 --> Helper loaded: url_helper
INFO - 2018-06-04 23:56:47 --> Helper loaded: form_helper
INFO - 2018-06-04 23:56:47 --> Helper loaded: date_helper
INFO - 2018-06-04 23:56:47 --> Helper loaded: util_helper
INFO - 2018-06-04 23:56:47 --> Helper loaded: text_helper
INFO - 2018-06-04 23:56:47 --> Helper loaded: string_helper
INFO - 2018-06-04 23:56:47 --> Database Driver Class Initialized
DEBUG - 2018-06-04 23:56:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-04 23:56:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-04 23:56:47 --> Email Class Initialized
INFO - 2018-06-04 23:56:47 --> Controller Class Initialized
DEBUG - 2018-06-04 23:56:47 --> Login MX_Controller Initialized
INFO - 2018-06-04 23:56:47 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-04 23:56:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-04 23:56:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-04 23:56:47 --> 4 Loggedout
INFO - 2018-06-04 23:56:48 --> Config Class Initialized
INFO - 2018-06-04 23:56:48 --> Hooks Class Initialized
DEBUG - 2018-06-04 23:56:48 --> UTF-8 Support Enabled
INFO - 2018-06-04 23:56:48 --> Utf8 Class Initialized
INFO - 2018-06-04 23:56:48 --> URI Class Initialized
INFO - 2018-06-04 23:56:48 --> Router Class Initialized
INFO - 2018-06-04 23:56:48 --> Output Class Initialized
INFO - 2018-06-04 23:56:48 --> Security Class Initialized
DEBUG - 2018-06-04 23:56:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-04 23:56:48 --> Input Class Initialized
INFO - 2018-06-04 23:56:48 --> Language Class Initialized
INFO - 2018-06-04 23:56:48 --> Language Class Initialized
INFO - 2018-06-04 23:56:48 --> Config Class Initialized
INFO - 2018-06-04 23:56:48 --> Loader Class Initialized
DEBUG - 2018-06-04 23:56:48 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-04 23:56:48 --> Helper loaded: url_helper
INFO - 2018-06-04 23:56:48 --> Helper loaded: form_helper
INFO - 2018-06-04 23:56:48 --> Helper loaded: date_helper
INFO - 2018-06-04 23:56:48 --> Helper loaded: util_helper
INFO - 2018-06-04 23:56:48 --> Helper loaded: text_helper
INFO - 2018-06-04 23:56:48 --> Helper loaded: string_helper
INFO - 2018-06-04 23:56:48 --> Database Driver Class Initialized
DEBUG - 2018-06-04 23:56:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-04 23:56:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-04 23:56:48 --> Email Class Initialized
INFO - 2018-06-04 23:56:48 --> Controller Class Initialized
DEBUG - 2018-06-04 23:56:48 --> Home MX_Controller Initialized
DEBUG - 2018-06-04 23:56:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-04 23:56:48 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-04 23:56:48 --> Login MX_Controller Initialized
INFO - 2018-06-04 23:56:48 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-04 23:56:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-04 23:56:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-04 23:56:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-06-04 23:56:57 --> Config Class Initialized
INFO - 2018-06-04 23:56:57 --> Hooks Class Initialized
DEBUG - 2018-06-04 23:56:57 --> UTF-8 Support Enabled
INFO - 2018-06-04 23:56:57 --> Utf8 Class Initialized
INFO - 2018-06-04 23:56:57 --> URI Class Initialized
INFO - 2018-06-04 23:56:57 --> Router Class Initialized
INFO - 2018-06-04 23:56:57 --> Output Class Initialized
INFO - 2018-06-04 23:56:57 --> Security Class Initialized
DEBUG - 2018-06-04 23:56:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-04 23:56:57 --> Input Class Initialized
INFO - 2018-06-04 23:56:57 --> Language Class Initialized
INFO - 2018-06-04 23:56:57 --> Language Class Initialized
INFO - 2018-06-04 23:56:57 --> Config Class Initialized
INFO - 2018-06-04 23:56:57 --> Loader Class Initialized
DEBUG - 2018-06-04 23:56:57 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-04 23:56:57 --> Helper loaded: url_helper
INFO - 2018-06-04 23:56:57 --> Helper loaded: form_helper
INFO - 2018-06-04 23:56:57 --> Helper loaded: date_helper
INFO - 2018-06-04 23:56:57 --> Helper loaded: util_helper
INFO - 2018-06-04 23:56:57 --> Helper loaded: text_helper
INFO - 2018-06-04 23:56:57 --> Helper loaded: string_helper
INFO - 2018-06-04 23:56:57 --> Database Driver Class Initialized
DEBUG - 2018-06-04 23:56:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-04 23:56:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-04 23:56:57 --> Email Class Initialized
INFO - 2018-06-04 23:56:57 --> Controller Class Initialized
DEBUG - 2018-06-04 23:56:57 --> Home MX_Controller Initialized
DEBUG - 2018-06-04 23:56:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-04 23:56:57 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-04 23:56:57 --> Login MX_Controller Initialized
INFO - 2018-06-04 23:56:57 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-04 23:56:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-04 23:56:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-04 23:56:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-06-04 23:56:59 --> Config Class Initialized
INFO - 2018-06-04 23:56:59 --> Hooks Class Initialized
DEBUG - 2018-06-04 23:56:59 --> UTF-8 Support Enabled
INFO - 2018-06-04 23:56:59 --> Utf8 Class Initialized
INFO - 2018-06-04 23:56:59 --> URI Class Initialized
INFO - 2018-06-04 23:56:59 --> Router Class Initialized
INFO - 2018-06-04 23:56:59 --> Output Class Initialized
INFO - 2018-06-04 23:56:59 --> Security Class Initialized
DEBUG - 2018-06-04 23:56:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-04 23:56:59 --> Input Class Initialized
INFO - 2018-06-04 23:56:59 --> Language Class Initialized
INFO - 2018-06-04 23:56:59 --> Language Class Initialized
INFO - 2018-06-04 23:56:59 --> Config Class Initialized
INFO - 2018-06-04 23:56:59 --> Loader Class Initialized
DEBUG - 2018-06-04 23:56:59 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-04 23:56:59 --> Helper loaded: url_helper
INFO - 2018-06-04 23:56:59 --> Helper loaded: form_helper
INFO - 2018-06-04 23:56:59 --> Helper loaded: date_helper
INFO - 2018-06-04 23:56:59 --> Helper loaded: util_helper
INFO - 2018-06-04 23:56:59 --> Helper loaded: text_helper
INFO - 2018-06-04 23:56:59 --> Helper loaded: string_helper
INFO - 2018-06-04 23:56:59 --> Database Driver Class Initialized
DEBUG - 2018-06-04 23:56:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-04 23:56:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-04 23:56:59 --> Email Class Initialized
INFO - 2018-06-04 23:56:59 --> Controller Class Initialized
DEBUG - 2018-06-04 23:56:59 --> Login MX_Controller Initialized
INFO - 2018-06-04 23:56:59 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-04 23:56:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-04 23:56:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-04 23:56:59 --> Email starts for gopipanguluri123@gmail.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-06-04 23:56:59 --> Login status gopipanguluri123@gmail.com - failure
INFO - 2018-06-04 23:56:59 --> Final output sent to browser
DEBUG - 2018-06-04 23:56:59 --> Total execution time: 0.3428
INFO - 2018-06-04 23:57:02 --> Config Class Initialized
INFO - 2018-06-04 23:57:02 --> Hooks Class Initialized
DEBUG - 2018-06-04 23:57:02 --> UTF-8 Support Enabled
INFO - 2018-06-04 23:57:02 --> Utf8 Class Initialized
INFO - 2018-06-04 23:57:02 --> URI Class Initialized
INFO - 2018-06-04 23:57:02 --> Router Class Initialized
INFO - 2018-06-04 23:57:02 --> Output Class Initialized
INFO - 2018-06-04 23:57:02 --> Security Class Initialized
DEBUG - 2018-06-04 23:57:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-04 23:57:02 --> Input Class Initialized
INFO - 2018-06-04 23:57:02 --> Language Class Initialized
INFO - 2018-06-04 23:57:02 --> Language Class Initialized
INFO - 2018-06-04 23:57:02 --> Config Class Initialized
INFO - 2018-06-04 23:57:02 --> Loader Class Initialized
DEBUG - 2018-06-04 23:57:02 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-04 23:57:02 --> Helper loaded: url_helper
INFO - 2018-06-04 23:57:02 --> Helper loaded: form_helper
INFO - 2018-06-04 23:57:02 --> Helper loaded: date_helper
INFO - 2018-06-04 23:57:02 --> Helper loaded: util_helper
INFO - 2018-06-04 23:57:02 --> Helper loaded: text_helper
INFO - 2018-06-04 23:57:02 --> Helper loaded: string_helper
INFO - 2018-06-04 23:57:02 --> Database Driver Class Initialized
DEBUG - 2018-06-04 23:57:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-04 23:57:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-04 23:57:02 --> Email Class Initialized
INFO - 2018-06-04 23:57:02 --> Controller Class Initialized
DEBUG - 2018-06-04 23:57:02 --> Login MX_Controller Initialized
INFO - 2018-06-04 23:57:02 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-04 23:57:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-04 23:57:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-04 23:57:02 --> Email starts for user@colin.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-06-04 23:57:02 --> User session created for 4
INFO - 2018-06-04 23:57:02 --> Login status user@colin.com - success
INFO - 2018-06-04 23:57:02 --> Final output sent to browser
DEBUG - 2018-06-04 23:57:02 --> Total execution time: 0.4970
INFO - 2018-06-04 23:57:03 --> Config Class Initialized
INFO - 2018-06-04 23:57:03 --> Hooks Class Initialized
DEBUG - 2018-06-04 23:57:03 --> UTF-8 Support Enabled
INFO - 2018-06-04 23:57:03 --> Utf8 Class Initialized
INFO - 2018-06-04 23:57:03 --> URI Class Initialized
INFO - 2018-06-04 23:57:03 --> Router Class Initialized
INFO - 2018-06-04 23:57:03 --> Output Class Initialized
INFO - 2018-06-04 23:57:03 --> Security Class Initialized
DEBUG - 2018-06-04 23:57:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-04 23:57:03 --> Input Class Initialized
INFO - 2018-06-04 23:57:03 --> Language Class Initialized
INFO - 2018-06-04 23:57:03 --> Language Class Initialized
INFO - 2018-06-04 23:57:03 --> Config Class Initialized
INFO - 2018-06-04 23:57:03 --> Loader Class Initialized
DEBUG - 2018-06-04 23:57:03 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-04 23:57:03 --> Helper loaded: url_helper
INFO - 2018-06-04 23:57:03 --> Helper loaded: form_helper
INFO - 2018-06-04 23:57:03 --> Helper loaded: date_helper
INFO - 2018-06-04 23:57:03 --> Helper loaded: util_helper
INFO - 2018-06-04 23:57:03 --> Helper loaded: text_helper
INFO - 2018-06-04 23:57:03 --> Helper loaded: string_helper
INFO - 2018-06-04 23:57:03 --> Database Driver Class Initialized
DEBUG - 2018-06-04 23:57:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-04 23:57:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-04 23:57:03 --> Email Class Initialized
INFO - 2018-06-04 23:57:03 --> Controller Class Initialized
DEBUG - 2018-06-04 23:57:03 --> Home MX_Controller Initialized
DEBUG - 2018-06-04 23:57:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-04 23:57:03 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-04 23:57:03 --> Login MX_Controller Initialized
INFO - 2018-06-04 23:57:03 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-04 23:57:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-04 23:57:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-04 23:57:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-04 23:57:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-04 23:57:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-04 23:57:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-04 23:57:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-04 23:57:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/progress.php
INFO - 2018-06-04 23:57:03 --> Final output sent to browser
DEBUG - 2018-06-04 23:57:03 --> Total execution time: 0.4681
INFO - 2018-06-04 23:57:03 --> Config Class Initialized
INFO - 2018-06-04 23:57:03 --> Hooks Class Initialized
DEBUG - 2018-06-04 23:57:03 --> UTF-8 Support Enabled
INFO - 2018-06-04 23:57:03 --> Utf8 Class Initialized
INFO - 2018-06-04 23:57:03 --> URI Class Initialized
INFO - 2018-06-04 23:57:03 --> Router Class Initialized
INFO - 2018-06-04 23:57:03 --> Output Class Initialized
INFO - 2018-06-04 23:57:03 --> Security Class Initialized
DEBUG - 2018-06-04 23:57:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-04 23:57:03 --> Input Class Initialized
INFO - 2018-06-04 23:57:04 --> Language Class Initialized
ERROR - 2018-06-04 23:57:04 --> 404 Page Not Found: /index
INFO - 2018-06-04 23:57:04 --> Config Class Initialized
INFO - 2018-06-04 23:57:04 --> Hooks Class Initialized
DEBUG - 2018-06-04 23:57:04 --> UTF-8 Support Enabled
INFO - 2018-06-04 23:57:04 --> Utf8 Class Initialized
INFO - 2018-06-04 23:57:04 --> URI Class Initialized
INFO - 2018-06-04 23:57:04 --> Router Class Initialized
INFO - 2018-06-04 23:57:04 --> Output Class Initialized
INFO - 2018-06-04 23:57:04 --> Security Class Initialized
DEBUG - 2018-06-04 23:57:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-04 23:57:04 --> Input Class Initialized
INFO - 2018-06-04 23:57:04 --> Language Class Initialized
INFO - 2018-06-04 23:57:04 --> Config Class Initialized
ERROR - 2018-06-04 23:57:04 --> 404 Page Not Found: /index
INFO - 2018-06-04 23:57:04 --> Hooks Class Initialized
DEBUG - 2018-06-04 23:57:04 --> UTF-8 Support Enabled
INFO - 2018-06-04 23:57:04 --> Config Class Initialized
INFO - 2018-06-04 23:57:04 --> Hooks Class Initialized
INFO - 2018-06-04 23:57:04 --> Utf8 Class Initialized
DEBUG - 2018-06-04 23:57:04 --> UTF-8 Support Enabled
INFO - 2018-06-04 23:57:04 --> Utf8 Class Initialized
INFO - 2018-06-04 23:57:04 --> URI Class Initialized
INFO - 2018-06-04 23:57:04 --> Router Class Initialized
INFO - 2018-06-04 23:57:04 --> Output Class Initialized
INFO - 2018-06-04 23:57:04 --> Security Class Initialized
DEBUG - 2018-06-04 23:57:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-04 23:57:04 --> Input Class Initialized
INFO - 2018-06-04 23:57:04 --> Language Class Initialized
ERROR - 2018-06-04 23:57:04 --> 404 Page Not Found: /index
INFO - 2018-06-04 23:57:04 --> URI Class Initialized
INFO - 2018-06-04 23:57:04 --> Router Class Initialized
INFO - 2018-06-04 23:57:04 --> Output Class Initialized
INFO - 2018-06-04 23:57:04 --> Security Class Initialized
DEBUG - 2018-06-04 23:57:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-04 23:57:04 --> Input Class Initialized
INFO - 2018-06-04 23:57:04 --> Language Class Initialized
ERROR - 2018-06-04 23:57:04 --> 404 Page Not Found: /index
INFO - 2018-06-04 23:57:04 --> Config Class Initialized
INFO - 2018-06-04 23:57:04 --> Hooks Class Initialized
DEBUG - 2018-06-04 23:57:05 --> UTF-8 Support Enabled
INFO - 2018-06-04 23:57:05 --> Utf8 Class Initialized
INFO - 2018-06-04 23:57:05 --> URI Class Initialized
INFO - 2018-06-04 23:57:05 --> Router Class Initialized
INFO - 2018-06-04 23:57:05 --> Output Class Initialized
INFO - 2018-06-04 23:57:05 --> Security Class Initialized
DEBUG - 2018-06-04 23:57:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-04 23:57:05 --> Input Class Initialized
INFO - 2018-06-04 23:57:05 --> Language Class Initialized
ERROR - 2018-06-04 23:57:05 --> 404 Page Not Found: /index
INFO - 2018-06-04 23:57:05 --> Config Class Initialized
INFO - 2018-06-04 23:57:05 --> Hooks Class Initialized
DEBUG - 2018-06-04 23:57:05 --> UTF-8 Support Enabled
INFO - 2018-06-04 23:57:05 --> Utf8 Class Initialized
INFO - 2018-06-04 23:57:05 --> URI Class Initialized
INFO - 2018-06-04 23:57:05 --> Router Class Initialized
INFO - 2018-06-04 23:57:05 --> Output Class Initialized
INFO - 2018-06-04 23:57:05 --> Security Class Initialized
DEBUG - 2018-06-04 23:57:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-04 23:57:05 --> Input Class Initialized
INFO - 2018-06-04 23:57:05 --> Language Class Initialized
ERROR - 2018-06-04 23:57:05 --> 404 Page Not Found: /index
INFO - 2018-06-04 23:57:05 --> Config Class Initialized
INFO - 2018-06-04 23:57:05 --> Hooks Class Initialized
DEBUG - 2018-06-04 23:57:05 --> UTF-8 Support Enabled
INFO - 2018-06-04 23:57:05 --> Utf8 Class Initialized
INFO - 2018-06-04 23:57:05 --> URI Class Initialized
INFO - 2018-06-04 23:57:05 --> Router Class Initialized
INFO - 2018-06-04 23:57:05 --> Output Class Initialized
INFO - 2018-06-04 23:57:05 --> Security Class Initialized
DEBUG - 2018-06-04 23:57:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-04 23:57:05 --> Input Class Initialized
INFO - 2018-06-04 23:57:05 --> Language Class Initialized
ERROR - 2018-06-04 23:57:05 --> 404 Page Not Found: /index
INFO - 2018-06-04 23:57:17 --> Config Class Initialized
INFO - 2018-06-04 23:57:17 --> Hooks Class Initialized
DEBUG - 2018-06-04 23:57:17 --> UTF-8 Support Enabled
INFO - 2018-06-04 23:57:17 --> Utf8 Class Initialized
INFO - 2018-06-04 23:57:17 --> URI Class Initialized
INFO - 2018-06-04 23:57:17 --> Router Class Initialized
INFO - 2018-06-04 23:57:17 --> Output Class Initialized
INFO - 2018-06-04 23:57:17 --> Security Class Initialized
DEBUG - 2018-06-04 23:57:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-04 23:57:17 --> Input Class Initialized
INFO - 2018-06-04 23:57:17 --> Language Class Initialized
INFO - 2018-06-04 23:57:17 --> Language Class Initialized
INFO - 2018-06-04 23:57:17 --> Config Class Initialized
INFO - 2018-06-04 23:57:17 --> Loader Class Initialized
DEBUG - 2018-06-04 23:57:17 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-04 23:57:17 --> Helper loaded: url_helper
INFO - 2018-06-04 23:57:17 --> Helper loaded: form_helper
INFO - 2018-06-04 23:57:17 --> Helper loaded: date_helper
INFO - 2018-06-04 23:57:17 --> Helper loaded: util_helper
INFO - 2018-06-04 23:57:17 --> Helper loaded: text_helper
INFO - 2018-06-04 23:57:17 --> Helper loaded: string_helper
INFO - 2018-06-04 23:57:17 --> Database Driver Class Initialized
DEBUG - 2018-06-04 23:57:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-04 23:57:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-04 23:57:17 --> Email Class Initialized
INFO - 2018-06-04 23:57:17 --> Controller Class Initialized
DEBUG - 2018-06-04 23:57:17 --> Login MX_Controller Initialized
INFO - 2018-06-04 23:57:17 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-04 23:57:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-04 23:57:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-04 23:57:17 --> 4 Loggedout
INFO - 2018-06-04 23:57:17 --> Config Class Initialized
INFO - 2018-06-04 23:57:17 --> Hooks Class Initialized
DEBUG - 2018-06-04 23:57:17 --> UTF-8 Support Enabled
INFO - 2018-06-04 23:57:17 --> Utf8 Class Initialized
INFO - 2018-06-04 23:57:17 --> URI Class Initialized
INFO - 2018-06-04 23:57:17 --> Router Class Initialized
INFO - 2018-06-04 23:57:17 --> Output Class Initialized
INFO - 2018-06-04 23:57:17 --> Security Class Initialized
DEBUG - 2018-06-04 23:57:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-04 23:57:17 --> Input Class Initialized
INFO - 2018-06-04 23:57:17 --> Language Class Initialized
INFO - 2018-06-04 23:57:17 --> Language Class Initialized
INFO - 2018-06-04 23:57:17 --> Config Class Initialized
INFO - 2018-06-04 23:57:17 --> Loader Class Initialized
DEBUG - 2018-06-04 23:57:17 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-04 23:57:17 --> Helper loaded: url_helper
INFO - 2018-06-04 23:57:17 --> Helper loaded: form_helper
INFO - 2018-06-04 23:57:17 --> Helper loaded: date_helper
INFO - 2018-06-04 23:57:17 --> Helper loaded: util_helper
INFO - 2018-06-04 23:57:17 --> Helper loaded: text_helper
INFO - 2018-06-04 23:57:17 --> Helper loaded: string_helper
INFO - 2018-06-04 23:57:17 --> Database Driver Class Initialized
DEBUG - 2018-06-04 23:57:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-04 23:57:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-04 23:57:17 --> Email Class Initialized
INFO - 2018-06-04 23:57:17 --> Controller Class Initialized
DEBUG - 2018-06-04 23:57:17 --> Home MX_Controller Initialized
DEBUG - 2018-06-04 23:57:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-04 23:57:17 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-04 23:57:17 --> Login MX_Controller Initialized
INFO - 2018-06-04 23:57:17 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-04 23:57:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-04 23:57:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-04 23:57:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-06-04 23:57:44 --> Config Class Initialized
INFO - 2018-06-04 23:57:44 --> Hooks Class Initialized
DEBUG - 2018-06-04 23:57:44 --> UTF-8 Support Enabled
INFO - 2018-06-04 23:57:44 --> Utf8 Class Initialized
INFO - 2018-06-04 23:57:44 --> URI Class Initialized
INFO - 2018-06-04 23:57:44 --> Router Class Initialized
INFO - 2018-06-04 23:57:44 --> Output Class Initialized
INFO - 2018-06-04 23:57:44 --> Security Class Initialized
DEBUG - 2018-06-04 23:57:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-04 23:57:44 --> Input Class Initialized
INFO - 2018-06-04 23:57:44 --> Language Class Initialized
INFO - 2018-06-04 23:57:44 --> Language Class Initialized
INFO - 2018-06-04 23:57:45 --> Config Class Initialized
INFO - 2018-06-04 23:57:45 --> Loader Class Initialized
DEBUG - 2018-06-04 23:57:45 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-04 23:57:45 --> Helper loaded: url_helper
INFO - 2018-06-04 23:57:45 --> Helper loaded: form_helper
INFO - 2018-06-04 23:57:45 --> Helper loaded: date_helper
INFO - 2018-06-04 23:57:45 --> Helper loaded: util_helper
INFO - 2018-06-04 23:57:45 --> Helper loaded: text_helper
INFO - 2018-06-04 23:57:45 --> Helper loaded: string_helper
INFO - 2018-06-04 23:57:45 --> Database Driver Class Initialized
DEBUG - 2018-06-04 23:57:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-04 23:57:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-04 23:57:45 --> Email Class Initialized
INFO - 2018-06-04 23:57:45 --> Controller Class Initialized
DEBUG - 2018-06-04 23:57:45 --> Home MX_Controller Initialized
DEBUG - 2018-06-04 23:57:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-04 23:57:45 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-04 23:57:45 --> Login MX_Controller Initialized
INFO - 2018-06-04 23:57:45 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-04 23:57:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-04 23:57:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-04 23:57:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-06-04 23:57:47 --> Config Class Initialized
INFO - 2018-06-04 23:57:47 --> Hooks Class Initialized
DEBUG - 2018-06-04 23:57:47 --> UTF-8 Support Enabled
INFO - 2018-06-04 23:57:47 --> Utf8 Class Initialized
INFO - 2018-06-04 23:57:47 --> URI Class Initialized
INFO - 2018-06-04 23:57:47 --> Router Class Initialized
INFO - 2018-06-04 23:57:47 --> Output Class Initialized
INFO - 2018-06-04 23:57:47 --> Security Class Initialized
DEBUG - 2018-06-04 23:57:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-04 23:57:47 --> Input Class Initialized
INFO - 2018-06-04 23:57:47 --> Language Class Initialized
INFO - 2018-06-04 23:57:47 --> Language Class Initialized
INFO - 2018-06-04 23:57:47 --> Config Class Initialized
INFO - 2018-06-04 23:57:47 --> Loader Class Initialized
DEBUG - 2018-06-04 23:57:47 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-04 23:57:47 --> Helper loaded: url_helper
INFO - 2018-06-04 23:57:47 --> Helper loaded: form_helper
INFO - 2018-06-04 23:57:47 --> Helper loaded: date_helper
INFO - 2018-06-04 23:57:47 --> Helper loaded: util_helper
INFO - 2018-06-04 23:57:47 --> Helper loaded: text_helper
INFO - 2018-06-04 23:57:47 --> Helper loaded: string_helper
INFO - 2018-06-04 23:57:47 --> Database Driver Class Initialized
DEBUG - 2018-06-04 23:57:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-04 23:57:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-04 23:57:47 --> Email Class Initialized
INFO - 2018-06-04 23:57:47 --> Controller Class Initialized
DEBUG - 2018-06-04 23:57:47 --> Home MX_Controller Initialized
DEBUG - 2018-06-04 23:57:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-04 23:57:47 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-04 23:57:47 --> Login MX_Controller Initialized
INFO - 2018-06-04 23:57:47 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-04 23:57:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-04 23:57:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-04 23:57:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-06-04 23:57:54 --> Config Class Initialized
INFO - 2018-06-04 23:57:54 --> Hooks Class Initialized
DEBUG - 2018-06-04 23:57:54 --> UTF-8 Support Enabled
INFO - 2018-06-04 23:57:54 --> Utf8 Class Initialized
INFO - 2018-06-04 23:57:54 --> URI Class Initialized
INFO - 2018-06-04 23:57:54 --> Router Class Initialized
INFO - 2018-06-04 23:57:54 --> Output Class Initialized
INFO - 2018-06-04 23:57:54 --> Security Class Initialized
DEBUG - 2018-06-04 23:57:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-04 23:57:54 --> Input Class Initialized
INFO - 2018-06-04 23:57:54 --> Language Class Initialized
INFO - 2018-06-04 23:57:54 --> Language Class Initialized
INFO - 2018-06-04 23:57:54 --> Config Class Initialized
INFO - 2018-06-04 23:57:54 --> Loader Class Initialized
DEBUG - 2018-06-04 23:57:54 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-04 23:57:54 --> Helper loaded: url_helper
INFO - 2018-06-04 23:57:54 --> Helper loaded: form_helper
INFO - 2018-06-04 23:57:54 --> Helper loaded: date_helper
INFO - 2018-06-04 23:57:54 --> Helper loaded: util_helper
INFO - 2018-06-04 23:57:54 --> Helper loaded: text_helper
INFO - 2018-06-04 23:57:54 --> Helper loaded: string_helper
INFO - 2018-06-04 23:57:54 --> Database Driver Class Initialized
DEBUG - 2018-06-04 23:57:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-04 23:57:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-04 23:57:54 --> Email Class Initialized
INFO - 2018-06-04 23:57:54 --> Controller Class Initialized
DEBUG - 2018-06-04 23:57:54 --> Home MX_Controller Initialized
DEBUG - 2018-06-04 23:57:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-04 23:57:54 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-04 23:57:54 --> Login MX_Controller Initialized
INFO - 2018-06-04 23:57:54 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-04 23:57:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-04 23:57:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-04 23:57:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-06-04 23:57:58 --> Config Class Initialized
INFO - 2018-06-04 23:57:58 --> Hooks Class Initialized
DEBUG - 2018-06-04 23:57:58 --> UTF-8 Support Enabled
INFO - 2018-06-04 23:57:58 --> Utf8 Class Initialized
INFO - 2018-06-04 23:57:58 --> URI Class Initialized
DEBUG - 2018-06-04 23:57:58 --> No URI present. Default controller set.
INFO - 2018-06-04 23:57:58 --> Router Class Initialized
INFO - 2018-06-04 23:57:58 --> Output Class Initialized
INFO - 2018-06-04 23:57:58 --> Security Class Initialized
DEBUG - 2018-06-04 23:57:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-04 23:57:58 --> Input Class Initialized
INFO - 2018-06-04 23:57:58 --> Language Class Initialized
INFO - 2018-06-04 23:57:58 --> Language Class Initialized
INFO - 2018-06-04 23:57:59 --> Config Class Initialized
INFO - 2018-06-04 23:57:59 --> Loader Class Initialized
DEBUG - 2018-06-04 23:57:59 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-04 23:57:59 --> Helper loaded: url_helper
INFO - 2018-06-04 23:57:59 --> Helper loaded: form_helper
INFO - 2018-06-04 23:57:59 --> Helper loaded: date_helper
INFO - 2018-06-04 23:57:59 --> Helper loaded: util_helper
INFO - 2018-06-04 23:57:59 --> Helper loaded: text_helper
INFO - 2018-06-04 23:57:59 --> Helper loaded: string_helper
INFO - 2018-06-04 23:57:59 --> Database Driver Class Initialized
DEBUG - 2018-06-04 23:57:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-04 23:57:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-04 23:57:59 --> Email Class Initialized
INFO - 2018-06-04 23:57:59 --> Controller Class Initialized
DEBUG - 2018-06-04 23:57:59 --> Home MX_Controller Initialized
DEBUG - 2018-06-04 23:57:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-04 23:57:59 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-04 23:57:59 --> Login MX_Controller Initialized
INFO - 2018-06-04 23:57:59 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-04 23:57:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-04 23:57:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-04 23:57:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-06-04 23:57:59 --> Config Class Initialized
INFO - 2018-06-04 23:57:59 --> Hooks Class Initialized
DEBUG - 2018-06-04 23:57:59 --> UTF-8 Support Enabled
INFO - 2018-06-04 23:57:59 --> Utf8 Class Initialized
INFO - 2018-06-04 23:57:59 --> URI Class Initialized
DEBUG - 2018-06-04 23:57:59 --> No URI present. Default controller set.
INFO - 2018-06-04 23:57:59 --> Router Class Initialized
INFO - 2018-06-04 23:57:59 --> Output Class Initialized
INFO - 2018-06-04 23:57:59 --> Security Class Initialized
DEBUG - 2018-06-04 23:57:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-04 23:57:59 --> Input Class Initialized
INFO - 2018-06-04 23:57:59 --> Language Class Initialized
INFO - 2018-06-04 23:57:59 --> Language Class Initialized
INFO - 2018-06-04 23:57:59 --> Config Class Initialized
INFO - 2018-06-04 23:57:59 --> Loader Class Initialized
DEBUG - 2018-06-04 23:57:59 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-04 23:57:59 --> Helper loaded: url_helper
INFO - 2018-06-04 23:57:59 --> Helper loaded: form_helper
INFO - 2018-06-04 23:57:59 --> Helper loaded: date_helper
INFO - 2018-06-04 23:57:59 --> Helper loaded: util_helper
INFO - 2018-06-04 23:57:59 --> Helper loaded: text_helper
INFO - 2018-06-04 23:57:59 --> Helper loaded: string_helper
INFO - 2018-06-04 23:57:59 --> Database Driver Class Initialized
DEBUG - 2018-06-04 23:57:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-04 23:57:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-04 23:57:59 --> Email Class Initialized
INFO - 2018-06-04 23:57:59 --> Controller Class Initialized
DEBUG - 2018-06-04 23:57:59 --> Home MX_Controller Initialized
DEBUG - 2018-06-04 23:57:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-04 23:57:59 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-04 23:57:59 --> Login MX_Controller Initialized
INFO - 2018-06-04 23:57:59 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-04 23:57:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-04 23:57:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-04 23:57:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-06-04 23:58:01 --> Config Class Initialized
INFO - 2018-06-04 23:58:01 --> Hooks Class Initialized
DEBUG - 2018-06-04 23:58:01 --> UTF-8 Support Enabled
INFO - 2018-06-04 23:58:01 --> Utf8 Class Initialized
INFO - 2018-06-04 23:58:01 --> URI Class Initialized
INFO - 2018-06-04 23:58:01 --> Router Class Initialized
INFO - 2018-06-04 23:58:01 --> Output Class Initialized
INFO - 2018-06-04 23:58:01 --> Security Class Initialized
DEBUG - 2018-06-04 23:58:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-04 23:58:01 --> Input Class Initialized
INFO - 2018-06-04 23:58:01 --> Language Class Initialized
INFO - 2018-06-04 23:58:01 --> Language Class Initialized
INFO - 2018-06-04 23:58:01 --> Config Class Initialized
INFO - 2018-06-04 23:58:01 --> Loader Class Initialized
DEBUG - 2018-06-04 23:58:01 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-04 23:58:01 --> Helper loaded: url_helper
INFO - 2018-06-04 23:58:01 --> Helper loaded: form_helper
INFO - 2018-06-04 23:58:01 --> Helper loaded: date_helper
INFO - 2018-06-04 23:58:01 --> Helper loaded: util_helper
INFO - 2018-06-04 23:58:01 --> Helper loaded: text_helper
INFO - 2018-06-04 23:58:02 --> Helper loaded: string_helper
INFO - 2018-06-04 23:58:02 --> Database Driver Class Initialized
DEBUG - 2018-06-04 23:58:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-04 23:58:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-04 23:58:02 --> Email Class Initialized
INFO - 2018-06-04 23:58:02 --> Controller Class Initialized
DEBUG - 2018-06-04 23:58:02 --> Login MX_Controller Initialized
INFO - 2018-06-04 23:58:02 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-04 23:58:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-04 23:58:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-04 23:58:02 --> Email starts for gopipanguluri123@gmail.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-06-04 23:58:02 --> Login status gopipanguluri123@gmail.com - failure
INFO - 2018-06-04 23:58:02 --> Final output sent to browser
DEBUG - 2018-06-04 23:58:02 --> Total execution time: 0.3684
INFO - 2018-06-04 23:58:04 --> Config Class Initialized
INFO - 2018-06-04 23:58:04 --> Hooks Class Initialized
DEBUG - 2018-06-04 23:58:05 --> UTF-8 Support Enabled
INFO - 2018-06-04 23:58:05 --> Utf8 Class Initialized
INFO - 2018-06-04 23:58:05 --> URI Class Initialized
INFO - 2018-06-04 23:58:05 --> Router Class Initialized
INFO - 2018-06-04 23:58:05 --> Output Class Initialized
INFO - 2018-06-04 23:58:05 --> Security Class Initialized
DEBUG - 2018-06-04 23:58:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-04 23:58:05 --> Input Class Initialized
INFO - 2018-06-04 23:58:05 --> Language Class Initialized
INFO - 2018-06-04 23:58:05 --> Language Class Initialized
INFO - 2018-06-04 23:58:05 --> Config Class Initialized
INFO - 2018-06-04 23:58:05 --> Loader Class Initialized
DEBUG - 2018-06-04 23:58:05 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-04 23:58:05 --> Helper loaded: url_helper
INFO - 2018-06-04 23:58:05 --> Helper loaded: form_helper
INFO - 2018-06-04 23:58:05 --> Helper loaded: date_helper
INFO - 2018-06-04 23:58:05 --> Helper loaded: util_helper
INFO - 2018-06-04 23:58:05 --> Helper loaded: text_helper
INFO - 2018-06-04 23:58:05 --> Helper loaded: string_helper
INFO - 2018-06-04 23:58:05 --> Database Driver Class Initialized
DEBUG - 2018-06-04 23:58:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-04 23:58:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-04 23:58:05 --> Email Class Initialized
INFO - 2018-06-04 23:58:05 --> Controller Class Initialized
DEBUG - 2018-06-04 23:58:05 --> Login MX_Controller Initialized
INFO - 2018-06-04 23:58:05 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-04 23:58:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-04 23:58:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-04 23:58:05 --> Email starts for user@colin.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-06-04 23:58:05 --> User session created for 4
INFO - 2018-06-04 23:58:05 --> Login status user@colin.com - success
INFO - 2018-06-04 23:58:05 --> Final output sent to browser
DEBUG - 2018-06-04 23:58:05 --> Total execution time: 0.4924
INFO - 2018-06-04 23:58:05 --> Config Class Initialized
INFO - 2018-06-04 23:58:05 --> Hooks Class Initialized
DEBUG - 2018-06-04 23:58:05 --> UTF-8 Support Enabled
INFO - 2018-06-04 23:58:05 --> Utf8 Class Initialized
INFO - 2018-06-04 23:58:05 --> URI Class Initialized
DEBUG - 2018-06-04 23:58:05 --> No URI present. Default controller set.
INFO - 2018-06-04 23:58:05 --> Router Class Initialized
INFO - 2018-06-04 23:58:05 --> Output Class Initialized
INFO - 2018-06-04 23:58:05 --> Security Class Initialized
DEBUG - 2018-06-04 23:58:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-04 23:58:05 --> Input Class Initialized
INFO - 2018-06-04 23:58:05 --> Language Class Initialized
INFO - 2018-06-04 23:58:05 --> Language Class Initialized
INFO - 2018-06-04 23:58:05 --> Config Class Initialized
INFO - 2018-06-04 23:58:05 --> Loader Class Initialized
DEBUG - 2018-06-04 23:58:05 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-04 23:58:05 --> Helper loaded: url_helper
INFO - 2018-06-04 23:58:05 --> Helper loaded: form_helper
INFO - 2018-06-04 23:58:05 --> Helper loaded: date_helper
INFO - 2018-06-04 23:58:05 --> Helper loaded: util_helper
INFO - 2018-06-04 23:58:05 --> Helper loaded: text_helper
INFO - 2018-06-04 23:58:05 --> Helper loaded: string_helper
INFO - 2018-06-04 23:58:05 --> Database Driver Class Initialized
DEBUG - 2018-06-04 23:58:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-04 23:58:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-04 23:58:05 --> Email Class Initialized
INFO - 2018-06-04 23:58:05 --> Controller Class Initialized
DEBUG - 2018-06-04 23:58:05 --> Home MX_Controller Initialized
DEBUG - 2018-06-04 23:58:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-04 23:58:05 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-04 23:58:05 --> Login MX_Controller Initialized
INFO - 2018-06-04 23:58:05 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-04 23:58:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-04 23:58:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-04 23:58:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-04 23:58:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-04 23:58:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-04 23:58:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-04 23:58:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-04 23:58:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-06-04 23:58:06 --> Final output sent to browser
DEBUG - 2018-06-04 23:58:06 --> Total execution time: 0.5331
INFO - 2018-06-04 23:58:06 --> Config Class Initialized
INFO - 2018-06-04 23:58:06 --> Hooks Class Initialized
DEBUG - 2018-06-04 23:58:06 --> UTF-8 Support Enabled
INFO - 2018-06-04 23:58:06 --> Utf8 Class Initialized
INFO - 2018-06-04 23:58:06 --> URI Class Initialized
INFO - 2018-06-04 23:58:06 --> Router Class Initialized
INFO - 2018-06-04 23:58:06 --> Output Class Initialized
INFO - 2018-06-04 23:58:06 --> Security Class Initialized
DEBUG - 2018-06-04 23:58:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-04 23:58:06 --> Input Class Initialized
INFO - 2018-06-04 23:58:06 --> Language Class Initialized
ERROR - 2018-06-04 23:58:06 --> 404 Page Not Found: /index
INFO - 2018-06-04 23:58:06 --> Config Class Initialized
INFO - 2018-06-04 23:58:06 --> Hooks Class Initialized
DEBUG - 2018-06-04 23:58:06 --> UTF-8 Support Enabled
INFO - 2018-06-04 23:58:06 --> Utf8 Class Initialized
INFO - 2018-06-04 23:58:06 --> URI Class Initialized
INFO - 2018-06-04 23:58:07 --> Router Class Initialized
INFO - 2018-06-04 23:58:07 --> Output Class Initialized
INFO - 2018-06-04 23:58:07 --> Security Class Initialized
DEBUG - 2018-06-04 23:58:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-04 23:58:07 --> Input Class Initialized
INFO - 2018-06-04 23:58:07 --> Language Class Initialized
ERROR - 2018-06-04 23:58:07 --> 404 Page Not Found: /index
INFO - 2018-06-04 23:58:07 --> Config Class Initialized
INFO - 2018-06-04 23:58:07 --> Hooks Class Initialized
INFO - 2018-06-04 23:58:07 --> Config Class Initialized
INFO - 2018-06-04 23:58:07 --> Hooks Class Initialized
DEBUG - 2018-06-04 23:58:07 --> UTF-8 Support Enabled
INFO - 2018-06-04 23:58:07 --> Utf8 Class Initialized
DEBUG - 2018-06-04 23:58:07 --> UTF-8 Support Enabled
INFO - 2018-06-04 23:58:07 --> Utf8 Class Initialized
INFO - 2018-06-04 23:58:07 --> URI Class Initialized
INFO - 2018-06-04 23:58:07 --> URI Class Initialized
INFO - 2018-06-04 23:58:07 --> Router Class Initialized
INFO - 2018-06-04 23:58:07 --> Router Class Initialized
INFO - 2018-06-04 23:58:07 --> Output Class Initialized
INFO - 2018-06-04 23:58:07 --> Security Class Initialized
DEBUG - 2018-06-04 23:58:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-04 23:58:07 --> Input Class Initialized
INFO - 2018-06-04 23:58:07 --> Language Class Initialized
ERROR - 2018-06-04 23:58:07 --> 404 Page Not Found: /index
INFO - 2018-06-04 23:58:07 --> Output Class Initialized
INFO - 2018-06-04 23:58:07 --> Security Class Initialized
DEBUG - 2018-06-04 23:58:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-04 23:58:07 --> Input Class Initialized
INFO - 2018-06-04 23:58:07 --> Language Class Initialized
ERROR - 2018-06-04 23:58:07 --> 404 Page Not Found: /index
INFO - 2018-06-04 23:58:07 --> Config Class Initialized
INFO - 2018-06-04 23:58:07 --> Hooks Class Initialized
DEBUG - 2018-06-04 23:58:07 --> UTF-8 Support Enabled
INFO - 2018-06-04 23:58:07 --> Utf8 Class Initialized
INFO - 2018-06-04 23:58:07 --> URI Class Initialized
INFO - 2018-06-04 23:58:07 --> Router Class Initialized
INFO - 2018-06-04 23:58:07 --> Output Class Initialized
INFO - 2018-06-04 23:58:07 --> Security Class Initialized
DEBUG - 2018-06-04 23:58:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-04 23:58:07 --> Input Class Initialized
INFO - 2018-06-04 23:58:07 --> Language Class Initialized
ERROR - 2018-06-04 23:58:07 --> 404 Page Not Found: /index
INFO - 2018-06-04 23:58:07 --> Config Class Initialized
INFO - 2018-06-04 23:58:07 --> Hooks Class Initialized
DEBUG - 2018-06-04 23:58:07 --> UTF-8 Support Enabled
INFO - 2018-06-04 23:58:07 --> Utf8 Class Initialized
INFO - 2018-06-04 23:58:07 --> URI Class Initialized
INFO - 2018-06-04 23:58:07 --> Router Class Initialized
INFO - 2018-06-04 23:58:07 --> Output Class Initialized
INFO - 2018-06-04 23:58:07 --> Security Class Initialized
DEBUG - 2018-06-04 23:58:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-04 23:58:07 --> Input Class Initialized
INFO - 2018-06-04 23:58:07 --> Language Class Initialized
ERROR - 2018-06-04 23:58:07 --> 404 Page Not Found: /index
INFO - 2018-06-04 23:58:07 --> Config Class Initialized
INFO - 2018-06-04 23:58:07 --> Hooks Class Initialized
DEBUG - 2018-06-04 23:58:07 --> UTF-8 Support Enabled
INFO - 2018-06-04 23:58:07 --> Utf8 Class Initialized
INFO - 2018-06-04 23:58:07 --> URI Class Initialized
INFO - 2018-06-04 23:58:07 --> Router Class Initialized
INFO - 2018-06-04 23:58:07 --> Output Class Initialized
INFO - 2018-06-04 23:58:07 --> Security Class Initialized
DEBUG - 2018-06-04 23:58:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-04 23:58:07 --> Input Class Initialized
INFO - 2018-06-04 23:58:07 --> Language Class Initialized
ERROR - 2018-06-04 23:58:07 --> 404 Page Not Found: /index
INFO - 2018-06-04 23:58:11 --> Config Class Initialized
INFO - 2018-06-04 23:58:11 --> Hooks Class Initialized
DEBUG - 2018-06-04 23:58:11 --> UTF-8 Support Enabled
INFO - 2018-06-04 23:58:11 --> Utf8 Class Initialized
INFO - 2018-06-04 23:58:11 --> URI Class Initialized
INFO - 2018-06-04 23:58:11 --> Router Class Initialized
INFO - 2018-06-04 23:58:11 --> Output Class Initialized
INFO - 2018-06-04 23:58:11 --> Security Class Initialized
DEBUG - 2018-06-04 23:58:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-04 23:58:11 --> Input Class Initialized
INFO - 2018-06-04 23:58:11 --> Language Class Initialized
INFO - 2018-06-04 23:58:11 --> Language Class Initialized
INFO - 2018-06-04 23:58:11 --> Config Class Initialized
INFO - 2018-06-04 23:58:11 --> Loader Class Initialized
DEBUG - 2018-06-04 23:58:11 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-04 23:58:11 --> Helper loaded: url_helper
INFO - 2018-06-04 23:58:11 --> Helper loaded: form_helper
INFO - 2018-06-04 23:58:11 --> Helper loaded: date_helper
INFO - 2018-06-04 23:58:11 --> Helper loaded: util_helper
INFO - 2018-06-04 23:58:11 --> Helper loaded: text_helper
INFO - 2018-06-04 23:58:11 --> Helper loaded: string_helper
INFO - 2018-06-04 23:58:11 --> Database Driver Class Initialized
DEBUG - 2018-06-04 23:58:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-04 23:58:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-04 23:58:12 --> Email Class Initialized
INFO - 2018-06-04 23:58:12 --> Controller Class Initialized
DEBUG - 2018-06-04 23:58:12 --> Login MX_Controller Initialized
INFO - 2018-06-04 23:58:12 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-04 23:58:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-04 23:58:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-04 23:58:12 --> 4 Loggedout
INFO - 2018-06-04 23:58:12 --> Config Class Initialized
INFO - 2018-06-04 23:58:12 --> Hooks Class Initialized
DEBUG - 2018-06-04 23:58:12 --> UTF-8 Support Enabled
INFO - 2018-06-04 23:58:12 --> Utf8 Class Initialized
INFO - 2018-06-04 23:58:12 --> URI Class Initialized
INFO - 2018-06-04 23:58:12 --> Router Class Initialized
INFO - 2018-06-04 23:58:12 --> Output Class Initialized
INFO - 2018-06-04 23:58:12 --> Security Class Initialized
DEBUG - 2018-06-04 23:58:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-04 23:58:12 --> Input Class Initialized
INFO - 2018-06-04 23:58:12 --> Language Class Initialized
INFO - 2018-06-04 23:58:12 --> Language Class Initialized
INFO - 2018-06-04 23:58:12 --> Config Class Initialized
INFO - 2018-06-04 23:58:12 --> Loader Class Initialized
DEBUG - 2018-06-04 23:58:12 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-04 23:58:12 --> Helper loaded: url_helper
INFO - 2018-06-04 23:58:12 --> Helper loaded: form_helper
INFO - 2018-06-04 23:58:12 --> Helper loaded: date_helper
INFO - 2018-06-04 23:58:12 --> Helper loaded: util_helper
INFO - 2018-06-04 23:58:12 --> Helper loaded: text_helper
INFO - 2018-06-04 23:58:12 --> Helper loaded: string_helper
INFO - 2018-06-04 23:58:12 --> Database Driver Class Initialized
DEBUG - 2018-06-04 23:58:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-04 23:58:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-04 23:58:12 --> Email Class Initialized
INFO - 2018-06-04 23:58:12 --> Controller Class Initialized
DEBUG - 2018-06-04 23:58:12 --> Home MX_Controller Initialized
DEBUG - 2018-06-04 23:58:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-04 23:58:12 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-04 23:58:12 --> Login MX_Controller Initialized
INFO - 2018-06-04 23:58:12 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-04 23:58:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-04 23:58:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-04 23:58:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-06-04 23:58:15 --> Config Class Initialized
INFO - 2018-06-04 23:58:15 --> Hooks Class Initialized
DEBUG - 2018-06-04 23:58:15 --> UTF-8 Support Enabled
INFO - 2018-06-04 23:58:15 --> Utf8 Class Initialized
INFO - 2018-06-04 23:58:15 --> URI Class Initialized
DEBUG - 2018-06-04 23:58:15 --> No URI present. Default controller set.
INFO - 2018-06-04 23:58:15 --> Router Class Initialized
INFO - 2018-06-04 23:58:15 --> Output Class Initialized
INFO - 2018-06-04 23:58:15 --> Security Class Initialized
DEBUG - 2018-06-04 23:58:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-04 23:58:15 --> Input Class Initialized
INFO - 2018-06-04 23:58:15 --> Language Class Initialized
INFO - 2018-06-04 23:58:15 --> Language Class Initialized
INFO - 2018-06-04 23:58:15 --> Config Class Initialized
INFO - 2018-06-04 23:58:15 --> Loader Class Initialized
DEBUG - 2018-06-04 23:58:15 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-04 23:58:15 --> Helper loaded: url_helper
INFO - 2018-06-04 23:58:15 --> Helper loaded: form_helper
INFO - 2018-06-04 23:58:15 --> Helper loaded: date_helper
INFO - 2018-06-04 23:58:15 --> Helper loaded: util_helper
INFO - 2018-06-04 23:58:15 --> Helper loaded: text_helper
INFO - 2018-06-04 23:58:15 --> Helper loaded: string_helper
INFO - 2018-06-04 23:58:15 --> Database Driver Class Initialized
DEBUG - 2018-06-04 23:58:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-04 23:58:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-04 23:58:15 --> Email Class Initialized
INFO - 2018-06-04 23:58:15 --> Controller Class Initialized
DEBUG - 2018-06-04 23:58:15 --> Home MX_Controller Initialized
DEBUG - 2018-06-04 23:58:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-04 23:58:15 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-04 23:58:15 --> Login MX_Controller Initialized
INFO - 2018-06-04 23:58:15 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-04 23:58:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-04 23:58:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-04 23:58:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-06-04 23:58:18 --> Config Class Initialized
INFO - 2018-06-04 23:58:18 --> Hooks Class Initialized
DEBUG - 2018-06-04 23:58:18 --> UTF-8 Support Enabled
INFO - 2018-06-04 23:58:18 --> Utf8 Class Initialized
INFO - 2018-06-04 23:58:18 --> URI Class Initialized
DEBUG - 2018-06-04 23:58:18 --> No URI present. Default controller set.
INFO - 2018-06-04 23:58:18 --> Router Class Initialized
INFO - 2018-06-04 23:58:18 --> Output Class Initialized
INFO - 2018-06-04 23:58:18 --> Security Class Initialized
DEBUG - 2018-06-04 23:58:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-04 23:58:18 --> Input Class Initialized
INFO - 2018-06-04 23:58:18 --> Language Class Initialized
INFO - 2018-06-04 23:58:18 --> Language Class Initialized
INFO - 2018-06-04 23:58:18 --> Config Class Initialized
INFO - 2018-06-04 23:58:18 --> Loader Class Initialized
DEBUG - 2018-06-04 23:58:18 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-04 23:58:18 --> Helper loaded: url_helper
INFO - 2018-06-04 23:58:18 --> Helper loaded: form_helper
INFO - 2018-06-04 23:58:18 --> Helper loaded: date_helper
INFO - 2018-06-04 23:58:18 --> Helper loaded: util_helper
INFO - 2018-06-04 23:58:18 --> Helper loaded: text_helper
INFO - 2018-06-04 23:58:18 --> Helper loaded: string_helper
INFO - 2018-06-04 23:58:18 --> Database Driver Class Initialized
DEBUG - 2018-06-04 23:58:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-04 23:58:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-04 23:58:18 --> Email Class Initialized
INFO - 2018-06-04 23:58:18 --> Controller Class Initialized
DEBUG - 2018-06-04 23:58:18 --> Home MX_Controller Initialized
DEBUG - 2018-06-04 23:58:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-04 23:58:18 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-04 23:58:18 --> Login MX_Controller Initialized
INFO - 2018-06-04 23:58:18 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-04 23:58:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-04 23:58:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-04 23:58:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-06-04 23:58:19 --> Config Class Initialized
INFO - 2018-06-04 23:58:19 --> Hooks Class Initialized
DEBUG - 2018-06-04 23:58:19 --> UTF-8 Support Enabled
INFO - 2018-06-04 23:58:19 --> Utf8 Class Initialized
INFO - 2018-06-04 23:58:19 --> URI Class Initialized
DEBUG - 2018-06-04 23:58:19 --> No URI present. Default controller set.
INFO - 2018-06-04 23:58:19 --> Router Class Initialized
INFO - 2018-06-04 23:58:19 --> Output Class Initialized
INFO - 2018-06-04 23:58:19 --> Security Class Initialized
DEBUG - 2018-06-04 23:58:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-04 23:58:19 --> Input Class Initialized
INFO - 2018-06-04 23:58:19 --> Language Class Initialized
INFO - 2018-06-04 23:58:19 --> Language Class Initialized
INFO - 2018-06-04 23:58:19 --> Config Class Initialized
INFO - 2018-06-04 23:58:19 --> Loader Class Initialized
DEBUG - 2018-06-04 23:58:19 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-04 23:58:19 --> Helper loaded: url_helper
INFO - 2018-06-04 23:58:19 --> Helper loaded: form_helper
INFO - 2018-06-04 23:58:19 --> Helper loaded: date_helper
INFO - 2018-06-04 23:58:19 --> Helper loaded: util_helper
INFO - 2018-06-04 23:58:19 --> Helper loaded: text_helper
INFO - 2018-06-04 23:58:19 --> Helper loaded: string_helper
INFO - 2018-06-04 23:58:19 --> Database Driver Class Initialized
DEBUG - 2018-06-04 23:58:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-04 23:58:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-04 23:58:19 --> Email Class Initialized
INFO - 2018-06-04 23:58:19 --> Controller Class Initialized
DEBUG - 2018-06-04 23:58:19 --> Home MX_Controller Initialized
DEBUG - 2018-06-04 23:58:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-04 23:58:19 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-04 23:58:19 --> Login MX_Controller Initialized
INFO - 2018-06-04 23:58:19 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-04 23:58:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-04 23:58:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-04 23:58:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-06-04 23:58:56 --> Config Class Initialized
INFO - 2018-06-04 23:58:56 --> Hooks Class Initialized
DEBUG - 2018-06-04 23:58:56 --> UTF-8 Support Enabled
INFO - 2018-06-04 23:58:56 --> Utf8 Class Initialized
INFO - 2018-06-04 23:58:56 --> URI Class Initialized
DEBUG - 2018-06-04 23:58:56 --> No URI present. Default controller set.
INFO - 2018-06-04 23:58:56 --> Router Class Initialized
INFO - 2018-06-04 23:58:56 --> Output Class Initialized
INFO - 2018-06-04 23:58:56 --> Security Class Initialized
DEBUG - 2018-06-04 23:58:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-04 23:58:56 --> Input Class Initialized
INFO - 2018-06-04 23:58:56 --> Language Class Initialized
INFO - 2018-06-04 23:58:56 --> Language Class Initialized
INFO - 2018-06-04 23:58:56 --> Config Class Initialized
INFO - 2018-06-04 23:58:56 --> Loader Class Initialized
DEBUG - 2018-06-04 23:58:56 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-04 23:58:56 --> Helper loaded: url_helper
INFO - 2018-06-04 23:58:56 --> Helper loaded: form_helper
INFO - 2018-06-04 23:58:56 --> Helper loaded: date_helper
INFO - 2018-06-04 23:58:56 --> Helper loaded: util_helper
INFO - 2018-06-04 23:58:56 --> Helper loaded: text_helper
INFO - 2018-06-04 23:58:56 --> Helper loaded: string_helper
INFO - 2018-06-04 23:58:56 --> Database Driver Class Initialized
DEBUG - 2018-06-04 23:58:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-04 23:58:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-04 23:58:56 --> Email Class Initialized
INFO - 2018-06-04 23:58:56 --> Controller Class Initialized
DEBUG - 2018-06-04 23:58:56 --> Home MX_Controller Initialized
DEBUG - 2018-06-04 23:58:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-04 23:58:56 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-04 23:58:56 --> Login MX_Controller Initialized
INFO - 2018-06-04 23:58:56 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-04 23:58:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-04 23:58:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-04 23:58:59 --> Config Class Initialized
INFO - 2018-06-04 23:58:59 --> Hooks Class Initialized
DEBUG - 2018-06-04 23:58:59 --> UTF-8 Support Enabled
INFO - 2018-06-04 23:58:59 --> Utf8 Class Initialized
INFO - 2018-06-04 23:58:59 --> URI Class Initialized
DEBUG - 2018-06-04 23:58:59 --> No URI present. Default controller set.
INFO - 2018-06-04 23:58:59 --> Router Class Initialized
INFO - 2018-06-04 23:58:59 --> Output Class Initialized
INFO - 2018-06-04 23:58:59 --> Security Class Initialized
DEBUG - 2018-06-04 23:58:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-04 23:58:59 --> Input Class Initialized
INFO - 2018-06-04 23:58:59 --> Language Class Initialized
INFO - 2018-06-04 23:58:59 --> Language Class Initialized
INFO - 2018-06-04 23:58:59 --> Config Class Initialized
INFO - 2018-06-04 23:58:59 --> Loader Class Initialized
DEBUG - 2018-06-04 23:58:59 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-04 23:58:59 --> Helper loaded: url_helper
INFO - 2018-06-04 23:58:59 --> Helper loaded: form_helper
INFO - 2018-06-04 23:58:59 --> Helper loaded: date_helper
INFO - 2018-06-04 23:58:59 --> Helper loaded: util_helper
INFO - 2018-06-04 23:58:59 --> Helper loaded: text_helper
INFO - 2018-06-04 23:58:59 --> Helper loaded: string_helper
INFO - 2018-06-04 23:58:59 --> Database Driver Class Initialized
DEBUG - 2018-06-04 23:58:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-04 23:58:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-04 23:58:59 --> Email Class Initialized
INFO - 2018-06-04 23:58:59 --> Controller Class Initialized
DEBUG - 2018-06-04 23:58:59 --> Home MX_Controller Initialized
DEBUG - 2018-06-04 23:58:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-04 23:58:59 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-04 23:58:59 --> Login MX_Controller Initialized
INFO - 2018-06-04 23:58:59 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-04 23:58:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-04 23:58:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-04 23:59:22 --> Config Class Initialized
INFO - 2018-06-04 23:59:22 --> Hooks Class Initialized
DEBUG - 2018-06-04 23:59:22 --> UTF-8 Support Enabled
INFO - 2018-06-04 23:59:22 --> Utf8 Class Initialized
INFO - 2018-06-04 23:59:22 --> URI Class Initialized
DEBUG - 2018-06-04 23:59:23 --> No URI present. Default controller set.
INFO - 2018-06-04 23:59:23 --> Router Class Initialized
INFO - 2018-06-04 23:59:23 --> Output Class Initialized
INFO - 2018-06-04 23:59:23 --> Security Class Initialized
DEBUG - 2018-06-04 23:59:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-04 23:59:23 --> Input Class Initialized
INFO - 2018-06-04 23:59:23 --> Language Class Initialized
INFO - 2018-06-04 23:59:23 --> Language Class Initialized
INFO - 2018-06-04 23:59:23 --> Config Class Initialized
INFO - 2018-06-04 23:59:23 --> Loader Class Initialized
DEBUG - 2018-06-04 23:59:23 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-04 23:59:23 --> Helper loaded: url_helper
INFO - 2018-06-04 23:59:23 --> Helper loaded: form_helper
INFO - 2018-06-04 23:59:23 --> Helper loaded: date_helper
INFO - 2018-06-04 23:59:23 --> Helper loaded: util_helper
INFO - 2018-06-04 23:59:23 --> Helper loaded: text_helper
INFO - 2018-06-04 23:59:23 --> Helper loaded: string_helper
INFO - 2018-06-04 23:59:23 --> Database Driver Class Initialized
DEBUG - 2018-06-04 23:59:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-04 23:59:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-04 23:59:23 --> Email Class Initialized
INFO - 2018-06-04 23:59:23 --> Controller Class Initialized
DEBUG - 2018-06-04 23:59:23 --> Home MX_Controller Initialized
DEBUG - 2018-06-04 23:59:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-04 23:59:23 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-04 23:59:23 --> Login MX_Controller Initialized
INFO - 2018-06-04 23:59:23 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-04 23:59:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-04 23:59:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
