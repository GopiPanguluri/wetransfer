<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-06-05 00:31:19 --> Config Class Initialized
INFO - 2018-06-05 00:31:19 --> Hooks Class Initialized
DEBUG - 2018-06-05 00:31:19 --> UTF-8 Support Enabled
INFO - 2018-06-05 00:31:19 --> Utf8 Class Initialized
INFO - 2018-06-05 00:31:19 --> URI Class Initialized
DEBUG - 2018-06-05 00:31:19 --> No URI present. Default controller set.
INFO - 2018-06-05 00:31:19 --> Router Class Initialized
INFO - 2018-06-05 00:31:19 --> Output Class Initialized
INFO - 2018-06-05 00:31:19 --> Security Class Initialized
DEBUG - 2018-06-05 00:31:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-05 00:31:19 --> Input Class Initialized
INFO - 2018-06-05 00:31:19 --> Language Class Initialized
INFO - 2018-06-05 00:31:19 --> Language Class Initialized
INFO - 2018-06-05 00:31:19 --> Config Class Initialized
INFO - 2018-06-05 00:31:19 --> Loader Class Initialized
DEBUG - 2018-06-05 00:31:19 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-05 00:31:19 --> Helper loaded: url_helper
INFO - 2018-06-05 00:31:19 --> Helper loaded: form_helper
INFO - 2018-06-05 00:31:19 --> Helper loaded: date_helper
INFO - 2018-06-05 00:31:19 --> Helper loaded: util_helper
INFO - 2018-06-05 00:31:19 --> Helper loaded: text_helper
INFO - 2018-06-05 00:31:19 --> Helper loaded: string_helper
INFO - 2018-06-05 00:31:19 --> Database Driver Class Initialized
DEBUG - 2018-06-05 00:31:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-05 00:31:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-05 00:31:19 --> Email Class Initialized
INFO - 2018-06-05 00:31:19 --> Controller Class Initialized
DEBUG - 2018-06-05 00:31:19 --> Home MX_Controller Initialized
DEBUG - 2018-06-05 00:31:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-05 00:31:19 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-05 00:31:19 --> Login MX_Controller Initialized
INFO - 2018-06-05 00:31:19 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-05 00:31:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-05 00:31:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-05 00:42:44 --> Config Class Initialized
INFO - 2018-06-05 00:42:44 --> Hooks Class Initialized
DEBUG - 2018-06-05 00:42:45 --> UTF-8 Support Enabled
INFO - 2018-06-05 00:42:45 --> Utf8 Class Initialized
INFO - 2018-06-05 00:42:45 --> URI Class Initialized
INFO - 2018-06-05 00:42:45 --> Router Class Initialized
INFO - 2018-06-05 00:42:45 --> Output Class Initialized
INFO - 2018-06-05 00:42:45 --> Security Class Initialized
DEBUG - 2018-06-05 00:42:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-05 00:42:45 --> Input Class Initialized
INFO - 2018-06-05 00:42:45 --> Language Class Initialized
INFO - 2018-06-05 00:42:45 --> Language Class Initialized
INFO - 2018-06-05 00:42:45 --> Config Class Initialized
INFO - 2018-06-05 00:42:45 --> Loader Class Initialized
DEBUG - 2018-06-05 00:42:45 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-05 00:42:45 --> Helper loaded: url_helper
INFO - 2018-06-05 00:42:45 --> Helper loaded: form_helper
INFO - 2018-06-05 00:42:45 --> Helper loaded: date_helper
INFO - 2018-06-05 00:42:45 --> Helper loaded: util_helper
INFO - 2018-06-05 00:42:45 --> Helper loaded: text_helper
INFO - 2018-06-05 00:42:45 --> Helper loaded: string_helper
INFO - 2018-06-05 00:42:45 --> Database Driver Class Initialized
DEBUG - 2018-06-05 00:42:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-05 00:42:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-05 00:42:45 --> Email Class Initialized
INFO - 2018-06-05 00:42:45 --> Controller Class Initialized
DEBUG - 2018-06-05 00:42:45 --> Home MX_Controller Initialized
DEBUG - 2018-06-05 00:42:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-05 00:42:45 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-05 00:42:45 --> Login MX_Controller Initialized
INFO - 2018-06-05 00:42:45 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-05 00:42:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-05 00:42:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-05 02:03:36 --> Config Class Initialized
INFO - 2018-06-05 02:03:36 --> Hooks Class Initialized
DEBUG - 2018-06-05 02:03:36 --> UTF-8 Support Enabled
INFO - 2018-06-05 02:03:36 --> Utf8 Class Initialized
INFO - 2018-06-05 02:03:36 --> URI Class Initialized
INFO - 2018-06-05 02:03:36 --> Router Class Initialized
INFO - 2018-06-05 02:03:36 --> Output Class Initialized
INFO - 2018-06-05 02:03:36 --> Security Class Initialized
DEBUG - 2018-06-05 02:03:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-05 02:03:36 --> Input Class Initialized
INFO - 2018-06-05 02:03:36 --> Language Class Initialized
INFO - 2018-06-05 02:03:36 --> Language Class Initialized
INFO - 2018-06-05 02:03:36 --> Config Class Initialized
INFO - 2018-06-05 02:03:36 --> Loader Class Initialized
DEBUG - 2018-06-05 02:03:36 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-05 02:03:36 --> Helper loaded: url_helper
INFO - 2018-06-05 02:03:36 --> Helper loaded: form_helper
INFO - 2018-06-05 02:03:36 --> Helper loaded: date_helper
INFO - 2018-06-05 02:03:36 --> Helper loaded: util_helper
INFO - 2018-06-05 02:03:37 --> Helper loaded: text_helper
INFO - 2018-06-05 02:03:37 --> Helper loaded: string_helper
INFO - 2018-06-05 02:03:37 --> Database Driver Class Initialized
DEBUG - 2018-06-05 02:03:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-05 02:03:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-05 02:03:37 --> Email Class Initialized
INFO - 2018-06-05 02:03:37 --> Controller Class Initialized
DEBUG - 2018-06-05 02:03:37 --> Home MX_Controller Initialized
DEBUG - 2018-06-05 02:03:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-05 02:03:37 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-05 02:03:37 --> Login MX_Controller Initialized
INFO - 2018-06-05 02:03:37 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-05 02:03:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-05 02:03:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-05 02:03:41 --> Config Class Initialized
INFO - 2018-06-05 02:03:41 --> Hooks Class Initialized
DEBUG - 2018-06-05 02:03:41 --> UTF-8 Support Enabled
INFO - 2018-06-05 02:03:41 --> Utf8 Class Initialized
INFO - 2018-06-05 02:03:41 --> URI Class Initialized
DEBUG - 2018-06-05 02:03:41 --> No URI present. Default controller set.
INFO - 2018-06-05 02:03:41 --> Router Class Initialized
INFO - 2018-06-05 02:03:41 --> Output Class Initialized
INFO - 2018-06-05 02:03:41 --> Security Class Initialized
DEBUG - 2018-06-05 02:03:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-05 02:03:41 --> Input Class Initialized
INFO - 2018-06-05 02:03:41 --> Language Class Initialized
INFO - 2018-06-05 02:03:41 --> Language Class Initialized
INFO - 2018-06-05 02:03:41 --> Config Class Initialized
INFO - 2018-06-05 02:03:41 --> Loader Class Initialized
DEBUG - 2018-06-05 02:03:41 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-05 02:03:41 --> Helper loaded: url_helper
INFO - 2018-06-05 02:03:41 --> Helper loaded: form_helper
INFO - 2018-06-05 02:03:41 --> Helper loaded: date_helper
INFO - 2018-06-05 02:03:41 --> Helper loaded: util_helper
INFO - 2018-06-05 02:03:42 --> Helper loaded: text_helper
INFO - 2018-06-05 02:03:42 --> Helper loaded: string_helper
INFO - 2018-06-05 02:03:42 --> Database Driver Class Initialized
DEBUG - 2018-06-05 02:03:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-05 02:03:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-05 02:03:42 --> Email Class Initialized
INFO - 2018-06-05 02:03:42 --> Controller Class Initialized
DEBUG - 2018-06-05 02:03:42 --> Home MX_Controller Initialized
DEBUG - 2018-06-05 02:03:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-05 02:03:42 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-05 02:03:42 --> Login MX_Controller Initialized
INFO - 2018-06-05 02:03:42 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-05 02:03:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-05 02:03:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-05 02:04:17 --> Config Class Initialized
INFO - 2018-06-05 02:04:17 --> Hooks Class Initialized
DEBUG - 2018-06-05 02:04:17 --> UTF-8 Support Enabled
INFO - 2018-06-05 02:04:17 --> Utf8 Class Initialized
INFO - 2018-06-05 02:04:17 --> URI Class Initialized
DEBUG - 2018-06-05 02:04:17 --> No URI present. Default controller set.
INFO - 2018-06-05 02:04:17 --> Router Class Initialized
INFO - 2018-06-05 02:04:17 --> Output Class Initialized
INFO - 2018-06-05 02:04:17 --> Security Class Initialized
DEBUG - 2018-06-05 02:04:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-05 02:04:17 --> Input Class Initialized
INFO - 2018-06-05 02:04:17 --> Language Class Initialized
INFO - 2018-06-05 02:04:17 --> Language Class Initialized
INFO - 2018-06-05 02:04:17 --> Config Class Initialized
INFO - 2018-06-05 02:04:17 --> Loader Class Initialized
DEBUG - 2018-06-05 02:04:17 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-05 02:04:17 --> Helper loaded: url_helper
INFO - 2018-06-05 02:04:17 --> Helper loaded: form_helper
INFO - 2018-06-05 02:04:17 --> Helper loaded: date_helper
INFO - 2018-06-05 02:04:17 --> Helper loaded: util_helper
INFO - 2018-06-05 02:04:17 --> Helper loaded: text_helper
INFO - 2018-06-05 02:04:17 --> Helper loaded: string_helper
INFO - 2018-06-05 02:04:17 --> Database Driver Class Initialized
DEBUG - 2018-06-05 02:04:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-05 02:04:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-05 02:04:17 --> Email Class Initialized
INFO - 2018-06-05 02:04:17 --> Controller Class Initialized
DEBUG - 2018-06-05 02:04:17 --> Home MX_Controller Initialized
DEBUG - 2018-06-05 02:04:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-05 02:04:18 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-05 02:04:18 --> Login MX_Controller Initialized
INFO - 2018-06-05 02:04:18 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-05 02:04:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-05 02:04:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
ERROR - 2018-06-05 02:04:18 --> Severity: Notice --> Undefined variable: final_url E:\xampp\htdocs\consulting\application\modules\home\views\login.php 63
DEBUG - 2018-06-05 02:04:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-06-05 02:04:37 --> Config Class Initialized
INFO - 2018-06-05 02:04:37 --> Hooks Class Initialized
DEBUG - 2018-06-05 02:04:37 --> UTF-8 Support Enabled
INFO - 2018-06-05 02:04:37 --> Utf8 Class Initialized
INFO - 2018-06-05 02:04:37 --> URI Class Initialized
DEBUG - 2018-06-05 02:04:37 --> No URI present. Default controller set.
INFO - 2018-06-05 02:04:37 --> Router Class Initialized
INFO - 2018-06-05 02:04:37 --> Output Class Initialized
INFO - 2018-06-05 02:04:37 --> Security Class Initialized
DEBUG - 2018-06-05 02:04:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-05 02:04:37 --> Input Class Initialized
INFO - 2018-06-05 02:04:37 --> Language Class Initialized
INFO - 2018-06-05 02:04:37 --> Language Class Initialized
INFO - 2018-06-05 02:04:37 --> Config Class Initialized
INFO - 2018-06-05 02:04:37 --> Loader Class Initialized
DEBUG - 2018-06-05 02:04:37 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-05 02:04:37 --> Helper loaded: url_helper
INFO - 2018-06-05 02:04:37 --> Helper loaded: form_helper
INFO - 2018-06-05 02:04:37 --> Helper loaded: date_helper
INFO - 2018-06-05 02:04:37 --> Helper loaded: util_helper
INFO - 2018-06-05 02:04:37 --> Helper loaded: text_helper
INFO - 2018-06-05 02:04:37 --> Helper loaded: string_helper
INFO - 2018-06-05 02:04:37 --> Database Driver Class Initialized
DEBUG - 2018-06-05 02:04:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-05 02:04:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-05 02:04:37 --> Email Class Initialized
INFO - 2018-06-05 02:04:37 --> Controller Class Initialized
DEBUG - 2018-06-05 02:04:37 --> Home MX_Controller Initialized
DEBUG - 2018-06-05 02:04:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-05 02:04:37 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-05 02:04:37 --> Login MX_Controller Initialized
INFO - 2018-06-05 02:04:37 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-05 02:04:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-05 02:04:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-05 02:04:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-06-05 02:04:50 --> Config Class Initialized
INFO - 2018-06-05 02:04:50 --> Hooks Class Initialized
DEBUG - 2018-06-05 02:04:50 --> UTF-8 Support Enabled
INFO - 2018-06-05 02:04:50 --> Utf8 Class Initialized
INFO - 2018-06-05 02:04:50 --> URI Class Initialized
DEBUG - 2018-06-05 02:04:50 --> No URI present. Default controller set.
INFO - 2018-06-05 02:04:50 --> Router Class Initialized
INFO - 2018-06-05 02:04:50 --> Output Class Initialized
INFO - 2018-06-05 02:04:50 --> Security Class Initialized
DEBUG - 2018-06-05 02:04:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-05 02:04:50 --> Input Class Initialized
INFO - 2018-06-05 02:04:50 --> Language Class Initialized
INFO - 2018-06-05 02:04:50 --> Language Class Initialized
INFO - 2018-06-05 02:04:50 --> Config Class Initialized
INFO - 2018-06-05 02:04:50 --> Loader Class Initialized
DEBUG - 2018-06-05 02:04:50 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-05 02:04:50 --> Helper loaded: url_helper
INFO - 2018-06-05 02:04:50 --> Helper loaded: form_helper
INFO - 2018-06-05 02:04:50 --> Helper loaded: date_helper
INFO - 2018-06-05 02:04:50 --> Helper loaded: util_helper
INFO - 2018-06-05 02:04:50 --> Helper loaded: text_helper
INFO - 2018-06-05 02:04:50 --> Helper loaded: string_helper
INFO - 2018-06-05 02:04:50 --> Database Driver Class Initialized
DEBUG - 2018-06-05 02:04:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-05 02:04:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-05 02:04:50 --> Email Class Initialized
INFO - 2018-06-05 02:04:50 --> Controller Class Initialized
DEBUG - 2018-06-05 02:04:50 --> Home MX_Controller Initialized
DEBUG - 2018-06-05 02:04:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-05 02:04:50 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-05 02:04:50 --> Login MX_Controller Initialized
INFO - 2018-06-05 02:04:50 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-05 02:04:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-05 02:04:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-05 02:04:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-06-05 02:05:19 --> Config Class Initialized
INFO - 2018-06-05 02:05:19 --> Hooks Class Initialized
DEBUG - 2018-06-05 02:05:19 --> UTF-8 Support Enabled
INFO - 2018-06-05 02:05:19 --> Utf8 Class Initialized
INFO - 2018-06-05 02:05:19 --> URI Class Initialized
DEBUG - 2018-06-05 02:05:19 --> No URI present. Default controller set.
INFO - 2018-06-05 02:05:19 --> Router Class Initialized
INFO - 2018-06-05 02:05:19 --> Output Class Initialized
INFO - 2018-06-05 02:05:19 --> Security Class Initialized
DEBUG - 2018-06-05 02:05:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-05 02:05:19 --> Input Class Initialized
INFO - 2018-06-05 02:05:19 --> Language Class Initialized
INFO - 2018-06-05 02:05:19 --> Language Class Initialized
INFO - 2018-06-05 02:05:19 --> Config Class Initialized
INFO - 2018-06-05 02:05:19 --> Loader Class Initialized
DEBUG - 2018-06-05 02:05:19 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-05 02:05:19 --> Helper loaded: url_helper
INFO - 2018-06-05 02:05:19 --> Helper loaded: form_helper
INFO - 2018-06-05 02:05:19 --> Helper loaded: date_helper
INFO - 2018-06-05 02:05:19 --> Helper loaded: util_helper
INFO - 2018-06-05 02:05:19 --> Helper loaded: text_helper
INFO - 2018-06-05 02:05:19 --> Helper loaded: string_helper
INFO - 2018-06-05 02:05:19 --> Database Driver Class Initialized
DEBUG - 2018-06-05 02:05:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-05 02:05:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-05 02:05:19 --> Email Class Initialized
INFO - 2018-06-05 02:05:19 --> Controller Class Initialized
DEBUG - 2018-06-05 02:05:19 --> Home MX_Controller Initialized
DEBUG - 2018-06-05 02:05:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-05 02:05:19 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-05 02:05:19 --> Login MX_Controller Initialized
INFO - 2018-06-05 02:05:19 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-05 02:05:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-05 02:05:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-05 02:05:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-06-05 02:05:27 --> Config Class Initialized
INFO - 2018-06-05 02:05:27 --> Hooks Class Initialized
DEBUG - 2018-06-05 02:05:27 --> UTF-8 Support Enabled
INFO - 2018-06-05 02:05:27 --> Utf8 Class Initialized
INFO - 2018-06-05 02:05:27 --> URI Class Initialized
DEBUG - 2018-06-05 02:05:27 --> No URI present. Default controller set.
INFO - 2018-06-05 02:05:27 --> Router Class Initialized
INFO - 2018-06-05 02:05:27 --> Output Class Initialized
INFO - 2018-06-05 02:05:27 --> Security Class Initialized
DEBUG - 2018-06-05 02:05:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-05 02:05:27 --> Input Class Initialized
INFO - 2018-06-05 02:05:27 --> Language Class Initialized
INFO - 2018-06-05 02:05:27 --> Language Class Initialized
INFO - 2018-06-05 02:05:27 --> Config Class Initialized
INFO - 2018-06-05 02:05:27 --> Loader Class Initialized
DEBUG - 2018-06-05 02:05:27 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-05 02:05:27 --> Helper loaded: url_helper
INFO - 2018-06-05 02:05:27 --> Helper loaded: form_helper
INFO - 2018-06-05 02:05:27 --> Helper loaded: date_helper
INFO - 2018-06-05 02:05:27 --> Helper loaded: util_helper
INFO - 2018-06-05 02:05:27 --> Helper loaded: text_helper
INFO - 2018-06-05 02:05:27 --> Helper loaded: string_helper
INFO - 2018-06-05 02:05:27 --> Database Driver Class Initialized
DEBUG - 2018-06-05 02:05:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-05 02:05:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-05 02:05:27 --> Email Class Initialized
INFO - 2018-06-05 02:05:27 --> Controller Class Initialized
DEBUG - 2018-06-05 02:05:27 --> Home MX_Controller Initialized
DEBUG - 2018-06-05 02:05:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-05 02:05:27 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-05 02:05:27 --> Login MX_Controller Initialized
INFO - 2018-06-05 02:05:27 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-05 02:05:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-05 02:05:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-05 02:05:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-06-05 02:06:11 --> Config Class Initialized
INFO - 2018-06-05 02:06:11 --> Hooks Class Initialized
DEBUG - 2018-06-05 02:06:11 --> UTF-8 Support Enabled
INFO - 2018-06-05 02:06:11 --> Utf8 Class Initialized
INFO - 2018-06-05 02:06:11 --> URI Class Initialized
DEBUG - 2018-06-05 02:06:11 --> No URI present. Default controller set.
INFO - 2018-06-05 02:06:11 --> Router Class Initialized
INFO - 2018-06-05 02:06:11 --> Output Class Initialized
INFO - 2018-06-05 02:06:11 --> Security Class Initialized
DEBUG - 2018-06-05 02:06:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-05 02:06:11 --> Input Class Initialized
INFO - 2018-06-05 02:06:11 --> Language Class Initialized
INFO - 2018-06-05 02:06:11 --> Language Class Initialized
INFO - 2018-06-05 02:06:11 --> Config Class Initialized
INFO - 2018-06-05 02:06:11 --> Loader Class Initialized
DEBUG - 2018-06-05 02:06:11 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-05 02:06:11 --> Helper loaded: url_helper
INFO - 2018-06-05 02:06:11 --> Helper loaded: form_helper
INFO - 2018-06-05 02:06:11 --> Helper loaded: date_helper
INFO - 2018-06-05 02:06:11 --> Helper loaded: util_helper
INFO - 2018-06-05 02:06:11 --> Helper loaded: text_helper
INFO - 2018-06-05 02:06:11 --> Helper loaded: string_helper
INFO - 2018-06-05 02:06:11 --> Database Driver Class Initialized
DEBUG - 2018-06-05 02:06:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-05 02:06:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-05 02:06:11 --> Email Class Initialized
INFO - 2018-06-05 02:06:11 --> Controller Class Initialized
DEBUG - 2018-06-05 02:06:11 --> Home MX_Controller Initialized
DEBUG - 2018-06-05 02:06:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-05 02:06:11 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-05 02:06:11 --> Login MX_Controller Initialized
INFO - 2018-06-05 02:06:11 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-05 02:06:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-05 02:06:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-05 02:06:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-06-05 02:09:43 --> Config Class Initialized
INFO - 2018-06-05 02:09:43 --> Hooks Class Initialized
DEBUG - 2018-06-05 02:09:43 --> UTF-8 Support Enabled
INFO - 2018-06-05 02:09:43 --> Utf8 Class Initialized
INFO - 2018-06-05 02:09:43 --> URI Class Initialized
DEBUG - 2018-06-05 02:09:43 --> No URI present. Default controller set.
INFO - 2018-06-05 02:09:43 --> Router Class Initialized
INFO - 2018-06-05 02:09:43 --> Output Class Initialized
INFO - 2018-06-05 02:09:43 --> Security Class Initialized
DEBUG - 2018-06-05 02:09:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-05 02:09:43 --> Input Class Initialized
INFO - 2018-06-05 02:09:43 --> Language Class Initialized
INFO - 2018-06-05 02:09:43 --> Language Class Initialized
INFO - 2018-06-05 02:09:43 --> Config Class Initialized
INFO - 2018-06-05 02:09:43 --> Loader Class Initialized
DEBUG - 2018-06-05 02:09:43 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-05 02:09:43 --> Helper loaded: url_helper
INFO - 2018-06-05 02:09:43 --> Helper loaded: form_helper
INFO - 2018-06-05 02:09:43 --> Helper loaded: date_helper
INFO - 2018-06-05 02:09:43 --> Helper loaded: util_helper
INFO - 2018-06-05 02:09:43 --> Helper loaded: text_helper
INFO - 2018-06-05 02:09:43 --> Helper loaded: string_helper
INFO - 2018-06-05 02:09:43 --> Database Driver Class Initialized
DEBUG - 2018-06-05 02:09:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-05 02:09:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-05 02:09:43 --> Email Class Initialized
INFO - 2018-06-05 02:09:43 --> Controller Class Initialized
DEBUG - 2018-06-05 02:09:43 --> Home MX_Controller Initialized
DEBUG - 2018-06-05 02:09:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-05 02:09:43 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-05 02:09:43 --> Login MX_Controller Initialized
INFO - 2018-06-05 02:09:43 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-05 02:09:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-05 02:09:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-05 02:09:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-06-05 02:11:39 --> Config Class Initialized
INFO - 2018-06-05 02:11:39 --> Hooks Class Initialized
DEBUG - 2018-06-05 02:11:39 --> UTF-8 Support Enabled
INFO - 2018-06-05 02:11:39 --> Utf8 Class Initialized
INFO - 2018-06-05 02:11:39 --> URI Class Initialized
INFO - 2018-06-05 02:11:39 --> Router Class Initialized
INFO - 2018-06-05 02:11:39 --> Output Class Initialized
INFO - 2018-06-05 02:11:39 --> Security Class Initialized
DEBUG - 2018-06-05 02:11:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-05 02:11:39 --> Input Class Initialized
INFO - 2018-06-05 02:11:39 --> Language Class Initialized
INFO - 2018-06-05 02:11:39 --> Language Class Initialized
INFO - 2018-06-05 02:11:39 --> Config Class Initialized
INFO - 2018-06-05 02:11:39 --> Loader Class Initialized
DEBUG - 2018-06-05 02:11:39 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-05 02:11:39 --> Helper loaded: url_helper
INFO - 2018-06-05 02:11:39 --> Helper loaded: form_helper
INFO - 2018-06-05 02:11:39 --> Helper loaded: date_helper
INFO - 2018-06-05 02:11:39 --> Helper loaded: util_helper
INFO - 2018-06-05 02:11:39 --> Helper loaded: text_helper
INFO - 2018-06-05 02:11:39 --> Helper loaded: string_helper
INFO - 2018-06-05 02:11:39 --> Database Driver Class Initialized
DEBUG - 2018-06-05 02:11:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-05 02:11:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-05 02:11:39 --> Email Class Initialized
INFO - 2018-06-05 02:11:39 --> Controller Class Initialized
DEBUG - 2018-06-05 02:11:39 --> Home MX_Controller Initialized
DEBUG - 2018-06-05 02:11:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-05 02:11:39 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-05 02:11:39 --> Login MX_Controller Initialized
INFO - 2018-06-05 02:11:39 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-05 02:11:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-05 02:11:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-05 02:11:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-06-05 02:11:47 --> Config Class Initialized
INFO - 2018-06-05 02:11:47 --> Hooks Class Initialized
DEBUG - 2018-06-05 02:11:47 --> UTF-8 Support Enabled
INFO - 2018-06-05 02:11:47 --> Utf8 Class Initialized
INFO - 2018-06-05 02:11:47 --> URI Class Initialized
DEBUG - 2018-06-05 02:11:47 --> No URI present. Default controller set.
INFO - 2018-06-05 02:11:47 --> Router Class Initialized
INFO - 2018-06-05 02:11:47 --> Output Class Initialized
INFO - 2018-06-05 02:11:47 --> Security Class Initialized
DEBUG - 2018-06-05 02:11:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-05 02:11:47 --> Input Class Initialized
INFO - 2018-06-05 02:11:47 --> Language Class Initialized
INFO - 2018-06-05 02:11:47 --> Language Class Initialized
INFO - 2018-06-05 02:11:47 --> Config Class Initialized
INFO - 2018-06-05 02:11:47 --> Loader Class Initialized
DEBUG - 2018-06-05 02:11:47 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-05 02:11:47 --> Helper loaded: url_helper
INFO - 2018-06-05 02:11:47 --> Helper loaded: form_helper
INFO - 2018-06-05 02:11:47 --> Helper loaded: date_helper
INFO - 2018-06-05 02:11:47 --> Helper loaded: util_helper
INFO - 2018-06-05 02:11:47 --> Helper loaded: text_helper
INFO - 2018-06-05 02:11:47 --> Helper loaded: string_helper
INFO - 2018-06-05 02:11:47 --> Database Driver Class Initialized
DEBUG - 2018-06-05 02:11:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-05 02:11:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-05 02:11:47 --> Email Class Initialized
INFO - 2018-06-05 02:11:47 --> Controller Class Initialized
DEBUG - 2018-06-05 02:11:47 --> Home MX_Controller Initialized
DEBUG - 2018-06-05 02:11:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-05 02:11:47 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-05 02:11:47 --> Login MX_Controller Initialized
INFO - 2018-06-05 02:11:47 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-05 02:11:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-05 02:11:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-05 02:11:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-06-05 02:11:56 --> Config Class Initialized
INFO - 2018-06-05 02:11:56 --> Hooks Class Initialized
DEBUG - 2018-06-05 02:11:56 --> UTF-8 Support Enabled
INFO - 2018-06-05 02:11:56 --> Utf8 Class Initialized
INFO - 2018-06-05 02:11:56 --> URI Class Initialized
DEBUG - 2018-06-05 02:11:56 --> No URI present. Default controller set.
INFO - 2018-06-05 02:11:56 --> Router Class Initialized
INFO - 2018-06-05 02:11:56 --> Output Class Initialized
INFO - 2018-06-05 02:11:56 --> Security Class Initialized
DEBUG - 2018-06-05 02:11:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-05 02:11:56 --> Input Class Initialized
INFO - 2018-06-05 02:11:56 --> Language Class Initialized
INFO - 2018-06-05 02:11:56 --> Language Class Initialized
INFO - 2018-06-05 02:11:56 --> Config Class Initialized
INFO - 2018-06-05 02:11:57 --> Loader Class Initialized
DEBUG - 2018-06-05 02:11:57 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-05 02:11:57 --> Helper loaded: url_helper
INFO - 2018-06-05 02:11:57 --> Helper loaded: form_helper
INFO - 2018-06-05 02:11:57 --> Helper loaded: date_helper
INFO - 2018-06-05 02:11:57 --> Helper loaded: util_helper
INFO - 2018-06-05 02:11:57 --> Helper loaded: text_helper
INFO - 2018-06-05 02:11:57 --> Helper loaded: string_helper
INFO - 2018-06-05 02:11:57 --> Database Driver Class Initialized
DEBUG - 2018-06-05 02:11:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-05 02:11:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-05 02:11:57 --> Email Class Initialized
INFO - 2018-06-05 02:11:57 --> Controller Class Initialized
DEBUG - 2018-06-05 02:11:57 --> Home MX_Controller Initialized
DEBUG - 2018-06-05 02:11:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-05 02:11:57 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-05 02:11:57 --> Login MX_Controller Initialized
INFO - 2018-06-05 02:11:57 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-05 02:11:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-05 02:11:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-05 02:12:01 --> Config Class Initialized
INFO - 2018-06-05 02:12:01 --> Hooks Class Initialized
DEBUG - 2018-06-05 02:12:01 --> UTF-8 Support Enabled
INFO - 2018-06-05 02:12:01 --> Utf8 Class Initialized
INFO - 2018-06-05 02:12:01 --> URI Class Initialized
DEBUG - 2018-06-05 02:12:01 --> No URI present. Default controller set.
INFO - 2018-06-05 02:12:01 --> Router Class Initialized
INFO - 2018-06-05 02:12:01 --> Output Class Initialized
INFO - 2018-06-05 02:12:01 --> Security Class Initialized
DEBUG - 2018-06-05 02:12:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-05 02:12:01 --> Input Class Initialized
INFO - 2018-06-05 02:12:01 --> Language Class Initialized
INFO - 2018-06-05 02:12:01 --> Language Class Initialized
INFO - 2018-06-05 02:12:01 --> Config Class Initialized
INFO - 2018-06-05 02:12:01 --> Loader Class Initialized
DEBUG - 2018-06-05 02:12:01 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-05 02:12:01 --> Helper loaded: url_helper
INFO - 2018-06-05 02:12:01 --> Helper loaded: form_helper
INFO - 2018-06-05 02:12:01 --> Helper loaded: date_helper
INFO - 2018-06-05 02:12:01 --> Helper loaded: util_helper
INFO - 2018-06-05 02:12:01 --> Helper loaded: text_helper
INFO - 2018-06-05 02:12:01 --> Helper loaded: string_helper
INFO - 2018-06-05 02:12:01 --> Database Driver Class Initialized
DEBUG - 2018-06-05 02:12:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-05 02:12:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-05 02:12:01 --> Email Class Initialized
INFO - 2018-06-05 02:12:01 --> Controller Class Initialized
DEBUG - 2018-06-05 02:12:01 --> Home MX_Controller Initialized
DEBUG - 2018-06-05 02:12:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-05 02:12:01 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-05 02:12:01 --> Login MX_Controller Initialized
INFO - 2018-06-05 02:12:01 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-05 02:12:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-05 02:12:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-05 02:12:15 --> Config Class Initialized
INFO - 2018-06-05 02:12:15 --> Hooks Class Initialized
DEBUG - 2018-06-05 02:12:15 --> UTF-8 Support Enabled
INFO - 2018-06-05 02:12:15 --> Utf8 Class Initialized
INFO - 2018-06-05 02:12:15 --> URI Class Initialized
INFO - 2018-06-05 02:12:15 --> Router Class Initialized
INFO - 2018-06-05 02:12:15 --> Output Class Initialized
INFO - 2018-06-05 02:12:15 --> Security Class Initialized
DEBUG - 2018-06-05 02:12:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-05 02:12:15 --> Input Class Initialized
INFO - 2018-06-05 02:12:15 --> Language Class Initialized
INFO - 2018-06-05 02:12:15 --> Language Class Initialized
INFO - 2018-06-05 02:12:15 --> Config Class Initialized
INFO - 2018-06-05 02:12:15 --> Loader Class Initialized
DEBUG - 2018-06-05 02:12:15 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-05 02:12:15 --> Helper loaded: url_helper
INFO - 2018-06-05 02:12:15 --> Helper loaded: form_helper
INFO - 2018-06-05 02:12:15 --> Helper loaded: date_helper
INFO - 2018-06-05 02:12:15 --> Helper loaded: util_helper
INFO - 2018-06-05 02:12:15 --> Helper loaded: text_helper
INFO - 2018-06-05 02:12:15 --> Helper loaded: string_helper
INFO - 2018-06-05 02:12:15 --> Database Driver Class Initialized
DEBUG - 2018-06-05 02:12:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-05 02:12:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-05 02:12:15 --> Email Class Initialized
INFO - 2018-06-05 02:12:15 --> Controller Class Initialized
DEBUG - 2018-06-05 02:12:15 --> Home MX_Controller Initialized
DEBUG - 2018-06-05 02:12:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-05 02:12:15 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-05 02:12:15 --> Login MX_Controller Initialized
INFO - 2018-06-05 02:12:15 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-05 02:12:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-05 02:12:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-05 02:12:17 --> Config Class Initialized
INFO - 2018-06-05 02:12:17 --> Hooks Class Initialized
DEBUG - 2018-06-05 02:12:17 --> UTF-8 Support Enabled
INFO - 2018-06-05 02:12:17 --> Utf8 Class Initialized
INFO - 2018-06-05 02:12:17 --> URI Class Initialized
INFO - 2018-06-05 02:12:17 --> Router Class Initialized
INFO - 2018-06-05 02:12:17 --> Output Class Initialized
INFO - 2018-06-05 02:12:17 --> Security Class Initialized
DEBUG - 2018-06-05 02:12:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-05 02:12:17 --> Input Class Initialized
INFO - 2018-06-05 02:12:17 --> Language Class Initialized
INFO - 2018-06-05 02:12:17 --> Language Class Initialized
INFO - 2018-06-05 02:12:17 --> Config Class Initialized
INFO - 2018-06-05 02:12:17 --> Loader Class Initialized
DEBUG - 2018-06-05 02:12:17 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-05 02:12:17 --> Helper loaded: url_helper
INFO - 2018-06-05 02:12:17 --> Helper loaded: form_helper
INFO - 2018-06-05 02:12:17 --> Helper loaded: date_helper
INFO - 2018-06-05 02:12:17 --> Helper loaded: util_helper
INFO - 2018-06-05 02:12:17 --> Helper loaded: text_helper
INFO - 2018-06-05 02:12:17 --> Helper loaded: string_helper
INFO - 2018-06-05 02:12:17 --> Database Driver Class Initialized
DEBUG - 2018-06-05 02:12:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-05 02:12:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-05 02:12:18 --> Email Class Initialized
INFO - 2018-06-05 02:12:18 --> Controller Class Initialized
DEBUG - 2018-06-05 02:12:18 --> Home MX_Controller Initialized
DEBUG - 2018-06-05 02:12:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-05 02:12:18 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-05 02:12:18 --> Login MX_Controller Initialized
INFO - 2018-06-05 02:12:18 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-05 02:12:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-05 02:12:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-05 02:13:24 --> Config Class Initialized
INFO - 2018-06-05 02:13:24 --> Hooks Class Initialized
DEBUG - 2018-06-05 02:13:24 --> UTF-8 Support Enabled
INFO - 2018-06-05 02:13:24 --> Utf8 Class Initialized
INFO - 2018-06-05 02:13:24 --> URI Class Initialized
INFO - 2018-06-05 02:13:24 --> Router Class Initialized
INFO - 2018-06-05 02:13:24 --> Output Class Initialized
INFO - 2018-06-05 02:13:24 --> Security Class Initialized
DEBUG - 2018-06-05 02:13:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-05 02:13:24 --> Input Class Initialized
INFO - 2018-06-05 02:13:24 --> Language Class Initialized
INFO - 2018-06-05 02:13:24 --> Language Class Initialized
INFO - 2018-06-05 02:13:24 --> Config Class Initialized
INFO - 2018-06-05 02:13:24 --> Loader Class Initialized
DEBUG - 2018-06-05 02:13:24 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-05 02:13:24 --> Helper loaded: url_helper
INFO - 2018-06-05 02:13:24 --> Helper loaded: form_helper
INFO - 2018-06-05 02:13:24 --> Helper loaded: date_helper
INFO - 2018-06-05 02:13:24 --> Helper loaded: util_helper
INFO - 2018-06-05 02:13:24 --> Helper loaded: text_helper
INFO - 2018-06-05 02:13:24 --> Helper loaded: string_helper
INFO - 2018-06-05 02:13:24 --> Database Driver Class Initialized
DEBUG - 2018-06-05 02:13:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-05 02:13:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-05 02:13:24 --> Email Class Initialized
INFO - 2018-06-05 02:13:24 --> Controller Class Initialized
DEBUG - 2018-06-05 02:13:24 --> Home MX_Controller Initialized
DEBUG - 2018-06-05 02:13:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-05 02:13:24 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-05 02:13:24 --> Login MX_Controller Initialized
INFO - 2018-06-05 02:13:24 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-05 02:13:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-05 02:13:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-05 02:13:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-06-05 02:17:54 --> Config Class Initialized
INFO - 2018-06-05 02:17:54 --> Hooks Class Initialized
DEBUG - 2018-06-05 02:17:54 --> UTF-8 Support Enabled
INFO - 2018-06-05 02:17:54 --> Utf8 Class Initialized
INFO - 2018-06-05 02:17:54 --> URI Class Initialized
DEBUG - 2018-06-05 02:17:54 --> No URI present. Default controller set.
INFO - 2018-06-05 02:17:54 --> Router Class Initialized
INFO - 2018-06-05 02:17:54 --> Output Class Initialized
INFO - 2018-06-05 02:17:54 --> Security Class Initialized
DEBUG - 2018-06-05 02:17:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-05 02:17:54 --> Input Class Initialized
INFO - 2018-06-05 02:17:54 --> Language Class Initialized
INFO - 2018-06-05 02:17:54 --> Language Class Initialized
INFO - 2018-06-05 02:17:54 --> Config Class Initialized
INFO - 2018-06-05 02:17:54 --> Loader Class Initialized
DEBUG - 2018-06-05 02:17:54 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-05 02:17:54 --> Helper loaded: url_helper
INFO - 2018-06-05 02:17:54 --> Helper loaded: form_helper
INFO - 2018-06-05 02:17:54 --> Helper loaded: date_helper
INFO - 2018-06-05 02:17:54 --> Helper loaded: util_helper
INFO - 2018-06-05 02:17:54 --> Helper loaded: text_helper
INFO - 2018-06-05 02:17:54 --> Helper loaded: string_helper
INFO - 2018-06-05 02:17:54 --> Database Driver Class Initialized
DEBUG - 2018-06-05 02:17:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-05 02:17:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-05 02:17:54 --> Email Class Initialized
INFO - 2018-06-05 02:17:54 --> Controller Class Initialized
DEBUG - 2018-06-05 02:17:54 --> Home MX_Controller Initialized
DEBUG - 2018-06-05 02:17:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-05 02:17:54 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-05 02:17:54 --> Login MX_Controller Initialized
INFO - 2018-06-05 02:17:54 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-05 02:17:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-05 02:17:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-05 02:17:57 --> Config Class Initialized
INFO - 2018-06-05 02:17:57 --> Hooks Class Initialized
DEBUG - 2018-06-05 02:17:57 --> UTF-8 Support Enabled
INFO - 2018-06-05 02:17:57 --> Utf8 Class Initialized
INFO - 2018-06-05 02:17:57 --> URI Class Initialized
DEBUG - 2018-06-05 02:17:57 --> No URI present. Default controller set.
INFO - 2018-06-05 02:17:57 --> Router Class Initialized
INFO - 2018-06-05 02:17:57 --> Output Class Initialized
INFO - 2018-06-05 02:17:57 --> Security Class Initialized
DEBUG - 2018-06-05 02:17:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-05 02:17:57 --> Input Class Initialized
INFO - 2018-06-05 02:17:57 --> Language Class Initialized
INFO - 2018-06-05 02:17:57 --> Language Class Initialized
INFO - 2018-06-05 02:17:57 --> Config Class Initialized
INFO - 2018-06-05 02:17:57 --> Loader Class Initialized
DEBUG - 2018-06-05 02:17:57 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-05 02:17:57 --> Helper loaded: url_helper
INFO - 2018-06-05 02:17:57 --> Helper loaded: form_helper
INFO - 2018-06-05 02:17:58 --> Helper loaded: date_helper
INFO - 2018-06-05 02:17:58 --> Helper loaded: util_helper
INFO - 2018-06-05 02:17:58 --> Helper loaded: text_helper
INFO - 2018-06-05 02:17:58 --> Helper loaded: string_helper
INFO - 2018-06-05 02:17:58 --> Database Driver Class Initialized
DEBUG - 2018-06-05 02:17:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-05 02:17:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-05 02:17:58 --> Email Class Initialized
INFO - 2018-06-05 02:17:58 --> Controller Class Initialized
DEBUG - 2018-06-05 02:17:58 --> Home MX_Controller Initialized
DEBUG - 2018-06-05 02:17:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-05 02:17:58 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-05 02:17:58 --> Login MX_Controller Initialized
INFO - 2018-06-05 02:17:58 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-05 02:17:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-05 02:17:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-05 02:18:05 --> Config Class Initialized
INFO - 2018-06-05 02:18:05 --> Hooks Class Initialized
DEBUG - 2018-06-05 02:18:05 --> UTF-8 Support Enabled
INFO - 2018-06-05 02:18:05 --> Utf8 Class Initialized
INFO - 2018-06-05 02:18:05 --> URI Class Initialized
INFO - 2018-06-05 02:18:05 --> Router Class Initialized
INFO - 2018-06-05 02:18:05 --> Output Class Initialized
INFO - 2018-06-05 02:18:05 --> Security Class Initialized
DEBUG - 2018-06-05 02:18:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-05 02:18:05 --> Input Class Initialized
INFO - 2018-06-05 02:18:05 --> Language Class Initialized
INFO - 2018-06-05 02:18:05 --> Language Class Initialized
INFO - 2018-06-05 02:18:05 --> Config Class Initialized
INFO - 2018-06-05 02:18:05 --> Loader Class Initialized
DEBUG - 2018-06-05 02:18:05 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-05 02:18:05 --> Helper loaded: url_helper
INFO - 2018-06-05 02:18:05 --> Helper loaded: form_helper
INFO - 2018-06-05 02:18:05 --> Helper loaded: date_helper
INFO - 2018-06-05 02:18:05 --> Helper loaded: util_helper
INFO - 2018-06-05 02:18:05 --> Helper loaded: text_helper
INFO - 2018-06-05 02:18:05 --> Helper loaded: string_helper
INFO - 2018-06-05 02:18:05 --> Database Driver Class Initialized
DEBUG - 2018-06-05 02:18:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-05 02:18:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-05 02:18:05 --> Email Class Initialized
INFO - 2018-06-05 02:18:05 --> Controller Class Initialized
DEBUG - 2018-06-05 02:18:05 --> Home MX_Controller Initialized
DEBUG - 2018-06-05 02:18:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-05 02:18:05 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-05 02:18:05 --> Login MX_Controller Initialized
INFO - 2018-06-05 02:18:05 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-05 02:18:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-05 02:18:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-05 02:18:07 --> Config Class Initialized
INFO - 2018-06-05 02:18:07 --> Hooks Class Initialized
DEBUG - 2018-06-05 02:18:07 --> UTF-8 Support Enabled
INFO - 2018-06-05 02:18:07 --> Utf8 Class Initialized
INFO - 2018-06-05 02:18:07 --> URI Class Initialized
INFO - 2018-06-05 02:18:07 --> Router Class Initialized
INFO - 2018-06-05 02:18:07 --> Output Class Initialized
INFO - 2018-06-05 02:18:07 --> Security Class Initialized
DEBUG - 2018-06-05 02:18:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-05 02:18:07 --> Input Class Initialized
INFO - 2018-06-05 02:18:07 --> Language Class Initialized
INFO - 2018-06-05 02:18:07 --> Language Class Initialized
INFO - 2018-06-05 02:18:07 --> Config Class Initialized
INFO - 2018-06-05 02:18:07 --> Loader Class Initialized
DEBUG - 2018-06-05 02:18:07 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-05 02:18:07 --> Helper loaded: url_helper
INFO - 2018-06-05 02:18:07 --> Helper loaded: form_helper
INFO - 2018-06-05 02:18:07 --> Helper loaded: date_helper
INFO - 2018-06-05 02:18:07 --> Helper loaded: util_helper
INFO - 2018-06-05 02:18:07 --> Helper loaded: text_helper
INFO - 2018-06-05 02:18:07 --> Helper loaded: string_helper
INFO - 2018-06-05 02:18:07 --> Database Driver Class Initialized
DEBUG - 2018-06-05 02:18:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-05 02:18:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-05 02:18:07 --> Email Class Initialized
INFO - 2018-06-05 02:18:07 --> Controller Class Initialized
DEBUG - 2018-06-05 02:18:07 --> Home MX_Controller Initialized
DEBUG - 2018-06-05 02:18:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-05 02:18:07 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-05 02:18:07 --> Login MX_Controller Initialized
INFO - 2018-06-05 02:18:07 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-05 02:18:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-05 02:18:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-05 02:24:07 --> Config Class Initialized
INFO - 2018-06-05 02:24:07 --> Hooks Class Initialized
DEBUG - 2018-06-05 02:24:07 --> UTF-8 Support Enabled
INFO - 2018-06-05 02:24:07 --> Utf8 Class Initialized
INFO - 2018-06-05 02:24:07 --> URI Class Initialized
DEBUG - 2018-06-05 02:24:07 --> No URI present. Default controller set.
INFO - 2018-06-05 02:24:07 --> Router Class Initialized
INFO - 2018-06-05 02:24:07 --> Output Class Initialized
INFO - 2018-06-05 02:24:07 --> Security Class Initialized
DEBUG - 2018-06-05 02:24:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-05 02:24:07 --> Input Class Initialized
INFO - 2018-06-05 02:24:07 --> Language Class Initialized
INFO - 2018-06-05 02:24:07 --> Language Class Initialized
INFO - 2018-06-05 02:24:07 --> Config Class Initialized
INFO - 2018-06-05 02:24:07 --> Loader Class Initialized
DEBUG - 2018-06-05 02:24:07 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-05 02:24:07 --> Helper loaded: url_helper
INFO - 2018-06-05 02:24:07 --> Helper loaded: form_helper
INFO - 2018-06-05 02:24:07 --> Helper loaded: date_helper
INFO - 2018-06-05 02:24:07 --> Helper loaded: util_helper
INFO - 2018-06-05 02:24:07 --> Helper loaded: text_helper
INFO - 2018-06-05 02:24:07 --> Helper loaded: string_helper
INFO - 2018-06-05 02:24:08 --> Database Driver Class Initialized
DEBUG - 2018-06-05 02:24:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-05 02:24:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-05 02:24:08 --> Email Class Initialized
INFO - 2018-06-05 02:24:08 --> Controller Class Initialized
DEBUG - 2018-06-05 02:24:08 --> Home MX_Controller Initialized
DEBUG - 2018-06-05 02:24:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-05 02:24:08 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-05 02:24:08 --> Login MX_Controller Initialized
INFO - 2018-06-05 02:24:08 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-05 02:24:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-05 02:24:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-05 02:24:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-06-05 02:24:20 --> Config Class Initialized
INFO - 2018-06-05 02:24:20 --> Hooks Class Initialized
DEBUG - 2018-06-05 02:24:20 --> UTF-8 Support Enabled
INFO - 2018-06-05 02:24:21 --> Utf8 Class Initialized
INFO - 2018-06-05 02:24:21 --> URI Class Initialized
DEBUG - 2018-06-05 02:24:21 --> No URI present. Default controller set.
INFO - 2018-06-05 02:24:21 --> Router Class Initialized
INFO - 2018-06-05 02:24:21 --> Output Class Initialized
INFO - 2018-06-05 02:24:21 --> Security Class Initialized
DEBUG - 2018-06-05 02:24:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-05 02:24:21 --> Input Class Initialized
INFO - 2018-06-05 02:24:21 --> Language Class Initialized
INFO - 2018-06-05 02:24:21 --> Language Class Initialized
INFO - 2018-06-05 02:24:21 --> Config Class Initialized
INFO - 2018-06-05 02:24:21 --> Loader Class Initialized
DEBUG - 2018-06-05 02:24:21 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-05 02:24:21 --> Helper loaded: url_helper
INFO - 2018-06-05 02:24:21 --> Helper loaded: form_helper
INFO - 2018-06-05 02:24:21 --> Helper loaded: date_helper
INFO - 2018-06-05 02:24:21 --> Helper loaded: util_helper
INFO - 2018-06-05 02:24:21 --> Helper loaded: text_helper
INFO - 2018-06-05 02:24:21 --> Helper loaded: string_helper
INFO - 2018-06-05 02:24:21 --> Database Driver Class Initialized
DEBUG - 2018-06-05 02:24:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-05 02:24:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-05 02:24:21 --> Email Class Initialized
INFO - 2018-06-05 02:24:21 --> Controller Class Initialized
DEBUG - 2018-06-05 02:24:21 --> Home MX_Controller Initialized
DEBUG - 2018-06-05 02:24:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-05 02:24:21 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-05 02:24:21 --> Login MX_Controller Initialized
INFO - 2018-06-05 02:24:21 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-05 02:24:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-05 02:24:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-05 02:25:10 --> Config Class Initialized
INFO - 2018-06-05 02:25:10 --> Hooks Class Initialized
DEBUG - 2018-06-05 02:25:10 --> UTF-8 Support Enabled
INFO - 2018-06-05 02:25:10 --> Utf8 Class Initialized
INFO - 2018-06-05 02:25:10 --> URI Class Initialized
DEBUG - 2018-06-05 02:25:10 --> No URI present. Default controller set.
INFO - 2018-06-05 02:25:10 --> Router Class Initialized
INFO - 2018-06-05 02:25:10 --> Output Class Initialized
INFO - 2018-06-05 02:25:10 --> Security Class Initialized
DEBUG - 2018-06-05 02:25:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-05 02:25:10 --> Input Class Initialized
INFO - 2018-06-05 02:25:10 --> Language Class Initialized
INFO - 2018-06-05 02:25:10 --> Language Class Initialized
INFO - 2018-06-05 02:25:10 --> Config Class Initialized
INFO - 2018-06-05 02:25:10 --> Loader Class Initialized
DEBUG - 2018-06-05 02:25:10 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-05 02:25:10 --> Helper loaded: url_helper
INFO - 2018-06-05 02:25:10 --> Helper loaded: form_helper
INFO - 2018-06-05 02:25:10 --> Helper loaded: date_helper
INFO - 2018-06-05 02:25:10 --> Helper loaded: util_helper
INFO - 2018-06-05 02:25:10 --> Helper loaded: text_helper
INFO - 2018-06-05 02:25:10 --> Helper loaded: string_helper
INFO - 2018-06-05 02:25:10 --> Database Driver Class Initialized
DEBUG - 2018-06-05 02:25:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-05 02:25:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-05 02:25:10 --> Email Class Initialized
INFO - 2018-06-05 02:25:10 --> Controller Class Initialized
DEBUG - 2018-06-05 02:25:10 --> Home MX_Controller Initialized
DEBUG - 2018-06-05 02:25:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-05 02:25:10 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-05 02:25:10 --> Login MX_Controller Initialized
INFO - 2018-06-05 02:25:10 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-05 02:25:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-05 02:25:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-05 02:25:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-06-05 02:25:16 --> Config Class Initialized
INFO - 2018-06-05 02:25:16 --> Hooks Class Initialized
DEBUG - 2018-06-05 02:25:16 --> UTF-8 Support Enabled
INFO - 2018-06-05 02:25:16 --> Utf8 Class Initialized
INFO - 2018-06-05 02:25:16 --> URI Class Initialized
DEBUG - 2018-06-05 02:25:16 --> No URI present. Default controller set.
INFO - 2018-06-05 02:25:16 --> Router Class Initialized
INFO - 2018-06-05 02:25:16 --> Output Class Initialized
INFO - 2018-06-05 02:25:17 --> Security Class Initialized
DEBUG - 2018-06-05 02:25:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-05 02:25:17 --> Input Class Initialized
INFO - 2018-06-05 02:25:17 --> Language Class Initialized
INFO - 2018-06-05 02:25:17 --> Language Class Initialized
INFO - 2018-06-05 02:25:17 --> Config Class Initialized
INFO - 2018-06-05 02:25:17 --> Loader Class Initialized
DEBUG - 2018-06-05 02:25:17 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-05 02:25:17 --> Helper loaded: url_helper
INFO - 2018-06-05 02:25:17 --> Helper loaded: form_helper
INFO - 2018-06-05 02:25:17 --> Helper loaded: date_helper
INFO - 2018-06-05 02:25:17 --> Helper loaded: util_helper
INFO - 2018-06-05 02:25:17 --> Helper loaded: text_helper
INFO - 2018-06-05 02:25:17 --> Helper loaded: string_helper
INFO - 2018-06-05 02:25:17 --> Database Driver Class Initialized
DEBUG - 2018-06-05 02:25:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-05 02:25:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-05 02:25:17 --> Email Class Initialized
INFO - 2018-06-05 02:25:17 --> Controller Class Initialized
DEBUG - 2018-06-05 02:25:17 --> Home MX_Controller Initialized
DEBUG - 2018-06-05 02:25:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-05 02:25:17 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-05 02:25:17 --> Login MX_Controller Initialized
INFO - 2018-06-05 02:25:17 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-05 02:25:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-05 02:25:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-05 02:25:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-06-05 02:27:20 --> Config Class Initialized
INFO - 2018-06-05 02:27:20 --> Hooks Class Initialized
DEBUG - 2018-06-05 02:27:20 --> UTF-8 Support Enabled
INFO - 2018-06-05 02:27:20 --> Utf8 Class Initialized
INFO - 2018-06-05 02:27:20 --> URI Class Initialized
DEBUG - 2018-06-05 02:27:20 --> No URI present. Default controller set.
INFO - 2018-06-05 02:27:20 --> Router Class Initialized
INFO - 2018-06-05 02:27:20 --> Output Class Initialized
INFO - 2018-06-05 02:27:20 --> Security Class Initialized
DEBUG - 2018-06-05 02:27:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-05 02:27:20 --> Input Class Initialized
INFO - 2018-06-05 02:27:20 --> Language Class Initialized
INFO - 2018-06-05 02:27:20 --> Language Class Initialized
INFO - 2018-06-05 02:27:20 --> Config Class Initialized
INFO - 2018-06-05 02:27:20 --> Loader Class Initialized
DEBUG - 2018-06-05 02:27:20 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-05 02:27:20 --> Helper loaded: url_helper
INFO - 2018-06-05 02:27:20 --> Helper loaded: form_helper
INFO - 2018-06-05 02:27:20 --> Helper loaded: date_helper
INFO - 2018-06-05 02:27:20 --> Helper loaded: util_helper
INFO - 2018-06-05 02:27:20 --> Helper loaded: text_helper
INFO - 2018-06-05 02:27:20 --> Helper loaded: string_helper
INFO - 2018-06-05 02:27:20 --> Database Driver Class Initialized
DEBUG - 2018-06-05 02:27:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-05 02:27:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-05 02:27:20 --> Email Class Initialized
INFO - 2018-06-05 02:27:20 --> Controller Class Initialized
DEBUG - 2018-06-05 02:27:20 --> Home MX_Controller Initialized
DEBUG - 2018-06-05 02:27:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-05 02:27:20 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-05 02:27:20 --> Login MX_Controller Initialized
INFO - 2018-06-05 02:27:20 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-05 02:27:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-05 02:27:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-05 02:27:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-06-05 02:27:25 --> Config Class Initialized
INFO - 2018-06-05 02:27:25 --> Hooks Class Initialized
DEBUG - 2018-06-05 02:27:25 --> UTF-8 Support Enabled
INFO - 2018-06-05 02:27:25 --> Utf8 Class Initialized
INFO - 2018-06-05 02:27:25 --> URI Class Initialized
INFO - 2018-06-05 02:27:25 --> Router Class Initialized
INFO - 2018-06-05 02:27:25 --> Output Class Initialized
INFO - 2018-06-05 02:27:25 --> Security Class Initialized
DEBUG - 2018-06-05 02:27:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-05 02:27:25 --> Input Class Initialized
INFO - 2018-06-05 02:27:25 --> Language Class Initialized
INFO - 2018-06-05 02:27:25 --> Language Class Initialized
INFO - 2018-06-05 02:27:25 --> Config Class Initialized
INFO - 2018-06-05 02:27:25 --> Loader Class Initialized
DEBUG - 2018-06-05 02:27:25 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-05 02:27:25 --> Helper loaded: url_helper
INFO - 2018-06-05 02:27:25 --> Helper loaded: form_helper
INFO - 2018-06-05 02:27:25 --> Helper loaded: date_helper
INFO - 2018-06-05 02:27:25 --> Helper loaded: util_helper
INFO - 2018-06-05 02:27:25 --> Helper loaded: text_helper
INFO - 2018-06-05 02:27:25 --> Helper loaded: string_helper
INFO - 2018-06-05 02:27:25 --> Database Driver Class Initialized
DEBUG - 2018-06-05 02:27:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-05 02:27:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-05 02:27:25 --> Email Class Initialized
INFO - 2018-06-05 02:27:25 --> Controller Class Initialized
DEBUG - 2018-06-05 02:27:25 --> Home MX_Controller Initialized
DEBUG - 2018-06-05 02:27:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-05 02:27:25 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-05 02:27:25 --> Login MX_Controller Initialized
INFO - 2018-06-05 02:27:25 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-05 02:27:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-05 02:27:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-05 02:27:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-06-05 03:59:36 --> Config Class Initialized
INFO - 2018-06-05 03:59:36 --> Hooks Class Initialized
DEBUG - 2018-06-05 03:59:36 --> UTF-8 Support Enabled
INFO - 2018-06-05 03:59:36 --> Utf8 Class Initialized
INFO - 2018-06-05 03:59:36 --> URI Class Initialized
DEBUG - 2018-06-05 03:59:36 --> No URI present. Default controller set.
INFO - 2018-06-05 03:59:36 --> Router Class Initialized
INFO - 2018-06-05 03:59:36 --> Output Class Initialized
INFO - 2018-06-05 03:59:36 --> Security Class Initialized
DEBUG - 2018-06-05 03:59:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-05 03:59:36 --> Input Class Initialized
INFO - 2018-06-05 03:59:36 --> Language Class Initialized
INFO - 2018-06-05 03:59:36 --> Language Class Initialized
INFO - 2018-06-05 03:59:36 --> Config Class Initialized
INFO - 2018-06-05 03:59:36 --> Loader Class Initialized
DEBUG - 2018-06-05 03:59:36 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-05 03:59:36 --> Helper loaded: url_helper
INFO - 2018-06-05 03:59:36 --> Helper loaded: form_helper
INFO - 2018-06-05 03:59:36 --> Helper loaded: date_helper
INFO - 2018-06-05 03:59:36 --> Helper loaded: util_helper
INFO - 2018-06-05 03:59:36 --> Helper loaded: text_helper
INFO - 2018-06-05 03:59:36 --> Helper loaded: string_helper
INFO - 2018-06-05 03:59:36 --> Database Driver Class Initialized
DEBUG - 2018-06-05 03:59:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-05 03:59:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-05 03:59:36 --> Email Class Initialized
INFO - 2018-06-05 03:59:36 --> Controller Class Initialized
DEBUG - 2018-06-05 03:59:36 --> Home MX_Controller Initialized
DEBUG - 2018-06-05 03:59:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-05 03:59:36 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-05 03:59:36 --> Login MX_Controller Initialized
INFO - 2018-06-05 03:59:36 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-05 03:59:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-05 03:59:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-05 03:59:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-06-05 05:11:06 --> Config Class Initialized
INFO - 2018-06-05 05:11:06 --> Hooks Class Initialized
DEBUG - 2018-06-05 05:11:06 --> UTF-8 Support Enabled
INFO - 2018-06-05 05:11:06 --> Utf8 Class Initialized
INFO - 2018-06-05 05:11:06 --> URI Class Initialized
INFO - 2018-06-05 05:11:06 --> Router Class Initialized
INFO - 2018-06-05 05:11:06 --> Output Class Initialized
INFO - 2018-06-05 05:11:06 --> Security Class Initialized
DEBUG - 2018-06-05 05:11:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-05 05:11:06 --> Input Class Initialized
INFO - 2018-06-05 05:11:06 --> Language Class Initialized
INFO - 2018-06-05 05:11:06 --> Language Class Initialized
INFO - 2018-06-05 05:11:06 --> Config Class Initialized
INFO - 2018-06-05 05:11:06 --> Loader Class Initialized
DEBUG - 2018-06-05 05:11:06 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-05 05:11:06 --> Helper loaded: url_helper
INFO - 2018-06-05 05:11:07 --> Helper loaded: form_helper
INFO - 2018-06-05 05:11:07 --> Helper loaded: date_helper
INFO - 2018-06-05 05:11:07 --> Helper loaded: util_helper
INFO - 2018-06-05 05:11:07 --> Helper loaded: text_helper
INFO - 2018-06-05 05:11:07 --> Helper loaded: string_helper
INFO - 2018-06-05 05:11:07 --> Database Driver Class Initialized
DEBUG - 2018-06-05 05:11:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-05 05:11:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-05 05:11:07 --> Email Class Initialized
INFO - 2018-06-05 05:11:07 --> Controller Class Initialized
DEBUG - 2018-06-05 05:11:07 --> Home MX_Controller Initialized
DEBUG - 2018-06-05 05:11:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-05 05:11:07 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-05 05:11:07 --> Login MX_Controller Initialized
INFO - 2018-06-05 05:11:07 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-05 05:11:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-05 05:11:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-05 05:11:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-06-05 05:11:14 --> Config Class Initialized
INFO - 2018-06-05 05:11:14 --> Hooks Class Initialized
DEBUG - 2018-06-05 05:11:14 --> UTF-8 Support Enabled
INFO - 2018-06-05 05:11:14 --> Utf8 Class Initialized
INFO - 2018-06-05 05:11:14 --> URI Class Initialized
DEBUG - 2018-06-05 05:11:14 --> No URI present. Default controller set.
INFO - 2018-06-05 05:11:14 --> Router Class Initialized
INFO - 2018-06-05 05:11:14 --> Output Class Initialized
INFO - 2018-06-05 05:11:14 --> Security Class Initialized
DEBUG - 2018-06-05 05:11:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-05 05:11:14 --> Input Class Initialized
INFO - 2018-06-05 05:11:14 --> Language Class Initialized
INFO - 2018-06-05 05:11:14 --> Language Class Initialized
INFO - 2018-06-05 05:11:14 --> Config Class Initialized
INFO - 2018-06-05 05:11:14 --> Loader Class Initialized
DEBUG - 2018-06-05 05:11:14 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-05 05:11:14 --> Helper loaded: url_helper
INFO - 2018-06-05 05:11:14 --> Helper loaded: form_helper
INFO - 2018-06-05 05:11:14 --> Helper loaded: date_helper
INFO - 2018-06-05 05:11:14 --> Helper loaded: util_helper
INFO - 2018-06-05 05:11:14 --> Helper loaded: text_helper
INFO - 2018-06-05 05:11:14 --> Helper loaded: string_helper
INFO - 2018-06-05 05:11:14 --> Database Driver Class Initialized
DEBUG - 2018-06-05 05:11:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-05 05:11:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-05 05:11:15 --> Email Class Initialized
INFO - 2018-06-05 05:11:15 --> Controller Class Initialized
DEBUG - 2018-06-05 05:11:15 --> Home MX_Controller Initialized
DEBUG - 2018-06-05 05:11:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-05 05:11:15 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-05 05:11:15 --> Login MX_Controller Initialized
INFO - 2018-06-05 05:11:15 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-05 05:11:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-05 05:11:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-05 05:11:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-06-05 05:11:19 --> Config Class Initialized
INFO - 2018-06-05 05:11:19 --> Hooks Class Initialized
DEBUG - 2018-06-05 05:11:19 --> UTF-8 Support Enabled
INFO - 2018-06-05 05:11:19 --> Utf8 Class Initialized
INFO - 2018-06-05 05:11:19 --> URI Class Initialized
INFO - 2018-06-05 05:11:19 --> Router Class Initialized
INFO - 2018-06-05 05:11:19 --> Output Class Initialized
INFO - 2018-06-05 05:11:19 --> Security Class Initialized
DEBUG - 2018-06-05 05:11:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-05 05:11:19 --> Input Class Initialized
INFO - 2018-06-05 05:11:19 --> Language Class Initialized
INFO - 2018-06-05 05:11:19 --> Language Class Initialized
INFO - 2018-06-05 05:11:19 --> Config Class Initialized
INFO - 2018-06-05 05:11:19 --> Loader Class Initialized
DEBUG - 2018-06-05 05:11:19 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-05 05:11:19 --> Helper loaded: url_helper
INFO - 2018-06-05 05:11:19 --> Helper loaded: form_helper
INFO - 2018-06-05 05:11:19 --> Helper loaded: date_helper
INFO - 2018-06-05 05:11:19 --> Helper loaded: util_helper
INFO - 2018-06-05 05:11:19 --> Helper loaded: text_helper
INFO - 2018-06-05 05:11:19 --> Helper loaded: string_helper
INFO - 2018-06-05 05:11:19 --> Database Driver Class Initialized
DEBUG - 2018-06-05 05:11:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-05 05:11:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-05 05:11:19 --> Email Class Initialized
INFO - 2018-06-05 05:11:19 --> Controller Class Initialized
DEBUG - 2018-06-05 05:11:19 --> Home MX_Controller Initialized
DEBUG - 2018-06-05 05:11:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-05 05:11:19 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-05 05:11:19 --> Login MX_Controller Initialized
INFO - 2018-06-05 05:11:19 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-05 05:11:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-05 05:11:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-05 05:11:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-06-05 05:11:22 --> Config Class Initialized
INFO - 2018-06-05 05:11:22 --> Hooks Class Initialized
DEBUG - 2018-06-05 05:11:22 --> UTF-8 Support Enabled
INFO - 2018-06-05 05:11:22 --> Utf8 Class Initialized
INFO - 2018-06-05 05:11:22 --> URI Class Initialized
INFO - 2018-06-05 05:11:22 --> Router Class Initialized
INFO - 2018-06-05 05:11:22 --> Output Class Initialized
INFO - 2018-06-05 05:11:22 --> Security Class Initialized
DEBUG - 2018-06-05 05:11:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-05 05:11:22 --> Input Class Initialized
INFO - 2018-06-05 05:11:22 --> Language Class Initialized
INFO - 2018-06-05 05:11:22 --> Language Class Initialized
INFO - 2018-06-05 05:11:22 --> Config Class Initialized
INFO - 2018-06-05 05:11:22 --> Loader Class Initialized
DEBUG - 2018-06-05 05:11:22 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-05 05:11:22 --> Helper loaded: url_helper
INFO - 2018-06-05 05:11:22 --> Helper loaded: form_helper
INFO - 2018-06-05 05:11:22 --> Helper loaded: date_helper
INFO - 2018-06-05 05:11:22 --> Helper loaded: util_helper
INFO - 2018-06-05 05:11:22 --> Helper loaded: text_helper
INFO - 2018-06-05 05:11:22 --> Helper loaded: string_helper
INFO - 2018-06-05 05:11:22 --> Database Driver Class Initialized
DEBUG - 2018-06-05 05:11:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-05 05:11:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-05 05:11:22 --> Email Class Initialized
INFO - 2018-06-05 05:11:22 --> Controller Class Initialized
DEBUG - 2018-06-05 05:11:22 --> Home MX_Controller Initialized
DEBUG - 2018-06-05 05:11:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-05 05:11:22 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-05 05:11:22 --> Login MX_Controller Initialized
INFO - 2018-06-05 05:11:22 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-05 05:11:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-05 05:11:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-05 05:11:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-06-05 05:11:40 --> Config Class Initialized
INFO - 2018-06-05 05:11:40 --> Hooks Class Initialized
DEBUG - 2018-06-05 05:11:40 --> UTF-8 Support Enabled
INFO - 2018-06-05 05:11:40 --> Utf8 Class Initialized
INFO - 2018-06-05 05:11:40 --> URI Class Initialized
INFO - 2018-06-05 05:11:40 --> Router Class Initialized
INFO - 2018-06-05 05:11:40 --> Output Class Initialized
INFO - 2018-06-05 05:11:40 --> Security Class Initialized
DEBUG - 2018-06-05 05:11:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-05 05:11:40 --> Input Class Initialized
INFO - 2018-06-05 05:11:40 --> Language Class Initialized
INFO - 2018-06-05 05:11:40 --> Language Class Initialized
INFO - 2018-06-05 05:11:40 --> Config Class Initialized
INFO - 2018-06-05 05:11:40 --> Loader Class Initialized
DEBUG - 2018-06-05 05:11:40 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-05 05:11:41 --> Helper loaded: url_helper
INFO - 2018-06-05 05:11:41 --> Helper loaded: form_helper
INFO - 2018-06-05 05:11:41 --> Helper loaded: date_helper
INFO - 2018-06-05 05:11:41 --> Helper loaded: util_helper
INFO - 2018-06-05 05:11:41 --> Helper loaded: text_helper
INFO - 2018-06-05 05:11:41 --> Helper loaded: string_helper
INFO - 2018-06-05 05:11:41 --> Database Driver Class Initialized
DEBUG - 2018-06-05 05:11:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-05 05:11:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-05 05:11:41 --> Email Class Initialized
INFO - 2018-06-05 05:11:41 --> Controller Class Initialized
DEBUG - 2018-06-05 05:11:41 --> Home MX_Controller Initialized
DEBUG - 2018-06-05 05:11:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-05 05:11:41 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-05 05:11:41 --> Login MX_Controller Initialized
INFO - 2018-06-05 05:11:41 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-05 05:11:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-05 05:11:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-05 05:11:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-06-05 05:11:57 --> Config Class Initialized
INFO - 2018-06-05 05:11:57 --> Hooks Class Initialized
DEBUG - 2018-06-05 05:11:57 --> UTF-8 Support Enabled
INFO - 2018-06-05 05:11:57 --> Utf8 Class Initialized
INFO - 2018-06-05 05:11:57 --> URI Class Initialized
INFO - 2018-06-05 05:11:57 --> Router Class Initialized
INFO - 2018-06-05 05:11:57 --> Output Class Initialized
INFO - 2018-06-05 05:11:57 --> Security Class Initialized
DEBUG - 2018-06-05 05:11:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-05 05:11:57 --> Input Class Initialized
INFO - 2018-06-05 05:11:57 --> Language Class Initialized
INFO - 2018-06-05 05:11:57 --> Language Class Initialized
INFO - 2018-06-05 05:11:57 --> Config Class Initialized
INFO - 2018-06-05 05:11:57 --> Loader Class Initialized
DEBUG - 2018-06-05 05:11:57 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-05 05:11:57 --> Helper loaded: url_helper
INFO - 2018-06-05 05:11:57 --> Helper loaded: form_helper
INFO - 2018-06-05 05:11:57 --> Helper loaded: date_helper
INFO - 2018-06-05 05:11:57 --> Helper loaded: util_helper
INFO - 2018-06-05 05:11:57 --> Helper loaded: text_helper
INFO - 2018-06-05 05:11:57 --> Helper loaded: string_helper
INFO - 2018-06-05 05:11:57 --> Database Driver Class Initialized
DEBUG - 2018-06-05 05:11:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-05 05:11:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-05 05:11:57 --> Email Class Initialized
INFO - 2018-06-05 05:11:57 --> Controller Class Initialized
DEBUG - 2018-06-05 05:11:57 --> Home MX_Controller Initialized
DEBUG - 2018-06-05 05:11:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-05 05:11:57 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-05 05:11:57 --> Login MX_Controller Initialized
INFO - 2018-06-05 05:11:57 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-05 05:11:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-05 05:11:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-05 05:11:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-06-05 05:12:04 --> Config Class Initialized
INFO - 2018-06-05 05:12:04 --> Hooks Class Initialized
DEBUG - 2018-06-05 05:12:04 --> UTF-8 Support Enabled
INFO - 2018-06-05 05:12:04 --> Utf8 Class Initialized
INFO - 2018-06-05 05:12:04 --> URI Class Initialized
INFO - 2018-06-05 05:12:04 --> Router Class Initialized
INFO - 2018-06-05 05:12:04 --> Output Class Initialized
INFO - 2018-06-05 05:12:04 --> Security Class Initialized
DEBUG - 2018-06-05 05:12:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-05 05:12:04 --> Input Class Initialized
INFO - 2018-06-05 05:12:04 --> Language Class Initialized
INFO - 2018-06-05 05:12:04 --> Language Class Initialized
INFO - 2018-06-05 05:12:04 --> Config Class Initialized
INFO - 2018-06-05 05:12:04 --> Loader Class Initialized
DEBUG - 2018-06-05 05:12:04 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-05 05:12:04 --> Helper loaded: url_helper
INFO - 2018-06-05 05:12:04 --> Helper loaded: form_helper
INFO - 2018-06-05 05:12:04 --> Helper loaded: date_helper
INFO - 2018-06-05 05:12:04 --> Helper loaded: util_helper
INFO - 2018-06-05 05:12:04 --> Helper loaded: text_helper
INFO - 2018-06-05 05:12:04 --> Helper loaded: string_helper
INFO - 2018-06-05 05:12:04 --> Database Driver Class Initialized
DEBUG - 2018-06-05 05:12:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-05 05:12:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-05 05:12:04 --> Email Class Initialized
INFO - 2018-06-05 05:12:04 --> Controller Class Initialized
DEBUG - 2018-06-05 05:12:04 --> Home MX_Controller Initialized
DEBUG - 2018-06-05 05:12:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-05 05:12:04 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-05 05:12:04 --> Login MX_Controller Initialized
INFO - 2018-06-05 05:12:04 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-05 05:12:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-05 05:12:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-05 05:12:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-06-05 05:12:08 --> Config Class Initialized
INFO - 2018-06-05 05:12:08 --> Hooks Class Initialized
DEBUG - 2018-06-05 05:12:08 --> UTF-8 Support Enabled
INFO - 2018-06-05 05:12:08 --> Utf8 Class Initialized
INFO - 2018-06-05 05:12:08 --> URI Class Initialized
INFO - 2018-06-05 05:12:08 --> Router Class Initialized
INFO - 2018-06-05 05:12:08 --> Output Class Initialized
INFO - 2018-06-05 05:12:08 --> Security Class Initialized
DEBUG - 2018-06-05 05:12:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-05 05:12:08 --> Input Class Initialized
INFO - 2018-06-05 05:12:08 --> Language Class Initialized
INFO - 2018-06-05 05:12:08 --> Language Class Initialized
INFO - 2018-06-05 05:12:08 --> Config Class Initialized
INFO - 2018-06-05 05:12:08 --> Loader Class Initialized
DEBUG - 2018-06-05 05:12:08 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-05 05:12:08 --> Helper loaded: url_helper
INFO - 2018-06-05 05:12:08 --> Helper loaded: form_helper
INFO - 2018-06-05 05:12:08 --> Helper loaded: date_helper
INFO - 2018-06-05 05:12:08 --> Helper loaded: util_helper
INFO - 2018-06-05 05:12:08 --> Helper loaded: text_helper
INFO - 2018-06-05 05:12:08 --> Helper loaded: string_helper
INFO - 2018-06-05 05:12:08 --> Database Driver Class Initialized
DEBUG - 2018-06-05 05:12:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-05 05:12:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-05 05:12:08 --> Email Class Initialized
INFO - 2018-06-05 05:12:08 --> Controller Class Initialized
DEBUG - 2018-06-05 05:12:08 --> Login MX_Controller Initialized
INFO - 2018-06-05 05:12:08 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-05 05:12:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-05 05:12:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-05 05:12:08 --> Email starts for user@colin.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-06-05 05:12:08 --> User session created for 4
INFO - 2018-06-05 05:12:08 --> Login status user@colin.com - success
INFO - 2018-06-05 05:12:08 --> Final output sent to browser
DEBUG - 2018-06-05 05:12:08 --> Total execution time: 0.4095
INFO - 2018-06-05 05:12:08 --> Config Class Initialized
INFO - 2018-06-05 05:12:08 --> Hooks Class Initialized
DEBUG - 2018-06-05 05:12:08 --> UTF-8 Support Enabled
INFO - 2018-06-05 05:12:08 --> Utf8 Class Initialized
INFO - 2018-06-05 05:12:08 --> URI Class Initialized
INFO - 2018-06-05 05:12:08 --> Router Class Initialized
INFO - 2018-06-05 05:12:08 --> Output Class Initialized
INFO - 2018-06-05 05:12:08 --> Security Class Initialized
DEBUG - 2018-06-05 05:12:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-05 05:12:08 --> Input Class Initialized
INFO - 2018-06-05 05:12:08 --> Language Class Initialized
INFO - 2018-06-05 05:12:08 --> Language Class Initialized
INFO - 2018-06-05 05:12:08 --> Config Class Initialized
INFO - 2018-06-05 05:12:08 --> Loader Class Initialized
DEBUG - 2018-06-05 05:12:08 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-05 05:12:08 --> Helper loaded: url_helper
INFO - 2018-06-05 05:12:08 --> Helper loaded: form_helper
INFO - 2018-06-05 05:12:08 --> Helper loaded: date_helper
INFO - 2018-06-05 05:12:08 --> Helper loaded: util_helper
INFO - 2018-06-05 05:12:08 --> Helper loaded: text_helper
INFO - 2018-06-05 05:12:08 --> Helper loaded: string_helper
INFO - 2018-06-05 05:12:08 --> Database Driver Class Initialized
DEBUG - 2018-06-05 05:12:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-05 05:12:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-05 05:12:08 --> Email Class Initialized
INFO - 2018-06-05 05:12:08 --> Controller Class Initialized
DEBUG - 2018-06-05 05:12:08 --> Home MX_Controller Initialized
DEBUG - 2018-06-05 05:12:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-05 05:12:08 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-05 05:12:08 --> Login MX_Controller Initialized
INFO - 2018-06-05 05:12:08 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-05 05:12:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-05 05:12:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-05 05:12:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-05 05:12:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-05 05:12:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-05 05:12:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-05 05:12:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-05 05:12:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-06-05 05:12:09 --> Final output sent to browser
DEBUG - 2018-06-05 05:12:09 --> Total execution time: 0.5898
INFO - 2018-06-05 05:12:09 --> Config Class Initialized
INFO - 2018-06-05 05:12:09 --> Config Class Initialized
INFO - 2018-06-05 05:12:09 --> Hooks Class Initialized
INFO - 2018-06-05 05:12:09 --> Hooks Class Initialized
DEBUG - 2018-06-05 05:12:09 --> UTF-8 Support Enabled
DEBUG - 2018-06-05 05:12:09 --> UTF-8 Support Enabled
INFO - 2018-06-05 05:12:09 --> Utf8 Class Initialized
INFO - 2018-06-05 05:12:09 --> Utf8 Class Initialized
INFO - 2018-06-05 05:12:09 --> URI Class Initialized
INFO - 2018-06-05 05:12:09 --> Router Class Initialized
INFO - 2018-06-05 05:12:09 --> Output Class Initialized
INFO - 2018-06-05 05:12:09 --> URI Class Initialized
INFO - 2018-06-05 05:12:09 --> Security Class Initialized
DEBUG - 2018-06-05 05:12:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-05 05:12:10 --> Router Class Initialized
INFO - 2018-06-05 05:12:10 --> Input Class Initialized
INFO - 2018-06-05 05:12:10 --> Language Class Initialized
INFO - 2018-06-05 05:12:10 --> Output Class Initialized
ERROR - 2018-06-05 05:12:10 --> 404 Page Not Found: /index
INFO - 2018-06-05 05:12:10 --> Security Class Initialized
DEBUG - 2018-06-05 05:12:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-05 05:12:10 --> Input Class Initialized
INFO - 2018-06-05 05:12:10 --> Language Class Initialized
ERROR - 2018-06-05 05:12:10 --> 404 Page Not Found: /index
INFO - 2018-06-05 05:12:10 --> Config Class Initialized
INFO - 2018-06-05 05:12:10 --> Hooks Class Initialized
DEBUG - 2018-06-05 05:12:10 --> UTF-8 Support Enabled
INFO - 2018-06-05 05:12:10 --> Utf8 Class Initialized
INFO - 2018-06-05 05:12:10 --> URI Class Initialized
INFO - 2018-06-05 05:12:10 --> Router Class Initialized
INFO - 2018-06-05 05:12:10 --> Output Class Initialized
INFO - 2018-06-05 05:12:10 --> Security Class Initialized
DEBUG - 2018-06-05 05:12:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-05 05:12:10 --> Input Class Initialized
INFO - 2018-06-05 05:12:10 --> Language Class Initialized
ERROR - 2018-06-05 05:12:10 --> 404 Page Not Found: /index
INFO - 2018-06-05 05:12:10 --> Config Class Initialized
INFO - 2018-06-05 05:12:10 --> Hooks Class Initialized
DEBUG - 2018-06-05 05:12:10 --> UTF-8 Support Enabled
INFO - 2018-06-05 05:12:10 --> Utf8 Class Initialized
INFO - 2018-06-05 05:12:10 --> URI Class Initialized
INFO - 2018-06-05 05:12:10 --> Router Class Initialized
INFO - 2018-06-05 05:12:10 --> Output Class Initialized
INFO - 2018-06-05 05:12:10 --> Security Class Initialized
DEBUG - 2018-06-05 05:12:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-05 05:12:10 --> Input Class Initialized
INFO - 2018-06-05 05:12:10 --> Language Class Initialized
ERROR - 2018-06-05 05:12:10 --> 404 Page Not Found: /index
INFO - 2018-06-05 05:12:10 --> Config Class Initialized
INFO - 2018-06-05 05:12:10 --> Hooks Class Initialized
DEBUG - 2018-06-05 05:12:10 --> UTF-8 Support Enabled
INFO - 2018-06-05 05:12:10 --> Utf8 Class Initialized
INFO - 2018-06-05 05:12:10 --> URI Class Initialized
INFO - 2018-06-05 05:12:10 --> Router Class Initialized
INFO - 2018-06-05 05:12:10 --> Output Class Initialized
INFO - 2018-06-05 05:12:11 --> Security Class Initialized
DEBUG - 2018-06-05 05:12:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-05 05:12:11 --> Input Class Initialized
INFO - 2018-06-05 05:12:11 --> Language Class Initialized
ERROR - 2018-06-05 05:12:11 --> 404 Page Not Found: /index
INFO - 2018-06-05 05:12:11 --> Config Class Initialized
INFO - 2018-06-05 05:12:11 --> Hooks Class Initialized
DEBUG - 2018-06-05 05:12:11 --> UTF-8 Support Enabled
INFO - 2018-06-05 05:12:11 --> Utf8 Class Initialized
INFO - 2018-06-05 05:12:11 --> URI Class Initialized
INFO - 2018-06-05 05:12:11 --> Router Class Initialized
INFO - 2018-06-05 05:12:11 --> Output Class Initialized
INFO - 2018-06-05 05:12:11 --> Security Class Initialized
DEBUG - 2018-06-05 05:12:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-05 05:12:11 --> Input Class Initialized
INFO - 2018-06-05 05:12:11 --> Language Class Initialized
ERROR - 2018-06-05 05:12:11 --> 404 Page Not Found: /index
INFO - 2018-06-05 05:12:11 --> Config Class Initialized
INFO - 2018-06-05 05:12:11 --> Hooks Class Initialized
DEBUG - 2018-06-05 05:12:11 --> UTF-8 Support Enabled
INFO - 2018-06-05 05:12:11 --> Utf8 Class Initialized
INFO - 2018-06-05 05:12:11 --> URI Class Initialized
INFO - 2018-06-05 05:12:11 --> Router Class Initialized
INFO - 2018-06-05 05:12:11 --> Output Class Initialized
INFO - 2018-06-05 05:12:11 --> Security Class Initialized
DEBUG - 2018-06-05 05:12:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-05 05:12:11 --> Input Class Initialized
INFO - 2018-06-05 05:12:11 --> Language Class Initialized
ERROR - 2018-06-05 05:12:11 --> 404 Page Not Found: /index
INFO - 2018-06-05 06:04:27 --> Config Class Initialized
INFO - 2018-06-05 06:04:27 --> Hooks Class Initialized
DEBUG - 2018-06-05 06:04:27 --> UTF-8 Support Enabled
INFO - 2018-06-05 06:04:27 --> Utf8 Class Initialized
INFO - 2018-06-05 06:04:27 --> URI Class Initialized
INFO - 2018-06-05 06:04:27 --> Router Class Initialized
INFO - 2018-06-05 06:04:27 --> Output Class Initialized
INFO - 2018-06-05 06:04:27 --> Security Class Initialized
DEBUG - 2018-06-05 06:04:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-05 06:04:27 --> Input Class Initialized
INFO - 2018-06-05 06:04:27 --> Language Class Initialized
INFO - 2018-06-05 06:04:27 --> Language Class Initialized
INFO - 2018-06-05 06:04:27 --> Config Class Initialized
INFO - 2018-06-05 06:04:27 --> Loader Class Initialized
DEBUG - 2018-06-05 06:04:27 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-05 06:04:27 --> Helper loaded: url_helper
INFO - 2018-06-05 06:04:27 --> Helper loaded: form_helper
INFO - 2018-06-05 06:04:27 --> Helper loaded: date_helper
INFO - 2018-06-05 06:04:27 --> Helper loaded: util_helper
INFO - 2018-06-05 06:04:27 --> Helper loaded: text_helper
INFO - 2018-06-05 06:04:27 --> Helper loaded: string_helper
INFO - 2018-06-05 06:04:27 --> Database Driver Class Initialized
DEBUG - 2018-06-05 06:04:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-05 06:04:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-05 06:04:27 --> Email Class Initialized
INFO - 2018-06-05 06:04:27 --> Controller Class Initialized
DEBUG - 2018-06-05 06:04:27 --> Home MX_Controller Initialized
DEBUG - 2018-06-05 06:04:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-05 06:04:27 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-05 06:04:27 --> Login MX_Controller Initialized
INFO - 2018-06-05 06:04:27 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-05 06:04:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-05 06:04:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-05 06:04:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-05 06:04:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-05 06:04:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-05 06:04:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-05 06:04:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-05 06:04:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-06-05 06:04:27 --> Final output sent to browser
DEBUG - 2018-06-05 06:04:27 --> Total execution time: 0.4830
INFO - 2018-06-05 06:04:28 --> Config Class Initialized
INFO - 2018-06-05 06:04:28 --> Hooks Class Initialized
INFO - 2018-06-05 06:04:28 --> Config Class Initialized
INFO - 2018-06-05 06:04:28 --> Hooks Class Initialized
DEBUG - 2018-06-05 06:04:28 --> UTF-8 Support Enabled
DEBUG - 2018-06-05 06:04:28 --> UTF-8 Support Enabled
INFO - 2018-06-05 06:04:28 --> Utf8 Class Initialized
INFO - 2018-06-05 06:04:28 --> URI Class Initialized
INFO - 2018-06-05 06:04:28 --> Router Class Initialized
INFO - 2018-06-05 06:04:28 --> Output Class Initialized
INFO - 2018-06-05 06:04:28 --> Security Class Initialized
INFO - 2018-06-05 06:04:28 --> Utf8 Class Initialized
DEBUG - 2018-06-05 06:04:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-05 06:04:28 --> URI Class Initialized
INFO - 2018-06-05 06:04:28 --> Input Class Initialized
INFO - 2018-06-05 06:04:28 --> Router Class Initialized
INFO - 2018-06-05 06:04:28 --> Language Class Initialized
INFO - 2018-06-05 06:04:28 --> Output Class Initialized
ERROR - 2018-06-05 06:04:28 --> 404 Page Not Found: /index
INFO - 2018-06-05 06:04:28 --> Security Class Initialized
DEBUG - 2018-06-05 06:04:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-05 06:04:28 --> Input Class Initialized
INFO - 2018-06-05 06:04:28 --> Language Class Initialized
ERROR - 2018-06-05 06:04:28 --> 404 Page Not Found: /index
INFO - 2018-06-05 06:04:29 --> Config Class Initialized
INFO - 2018-06-05 06:04:29 --> Hooks Class Initialized
DEBUG - 2018-06-05 06:04:29 --> UTF-8 Support Enabled
INFO - 2018-06-05 06:04:29 --> Utf8 Class Initialized
INFO - 2018-06-05 06:04:29 --> URI Class Initialized
INFO - 2018-06-05 06:04:29 --> Router Class Initialized
INFO - 2018-06-05 06:04:29 --> Output Class Initialized
INFO - 2018-06-05 06:04:29 --> Security Class Initialized
DEBUG - 2018-06-05 06:04:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-05 06:04:29 --> Input Class Initialized
INFO - 2018-06-05 06:04:29 --> Language Class Initialized
ERROR - 2018-06-05 06:04:29 --> 404 Page Not Found: /index
INFO - 2018-06-05 06:04:29 --> Config Class Initialized
INFO - 2018-06-05 06:04:29 --> Hooks Class Initialized
DEBUG - 2018-06-05 06:04:29 --> UTF-8 Support Enabled
INFO - 2018-06-05 06:04:29 --> Utf8 Class Initialized
INFO - 2018-06-05 06:04:29 --> URI Class Initialized
INFO - 2018-06-05 06:04:29 --> Router Class Initialized
INFO - 2018-06-05 06:04:29 --> Output Class Initialized
INFO - 2018-06-05 06:04:29 --> Security Class Initialized
DEBUG - 2018-06-05 06:04:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-05 06:04:29 --> Input Class Initialized
INFO - 2018-06-05 06:04:29 --> Language Class Initialized
ERROR - 2018-06-05 06:04:29 --> 404 Page Not Found: /index
INFO - 2018-06-05 06:04:29 --> Config Class Initialized
INFO - 2018-06-05 06:04:29 --> Hooks Class Initialized
DEBUG - 2018-06-05 06:04:29 --> UTF-8 Support Enabled
INFO - 2018-06-05 06:04:29 --> Utf8 Class Initialized
INFO - 2018-06-05 06:04:29 --> URI Class Initialized
INFO - 2018-06-05 06:04:29 --> Router Class Initialized
INFO - 2018-06-05 06:04:29 --> Output Class Initialized
INFO - 2018-06-05 06:04:29 --> Security Class Initialized
DEBUG - 2018-06-05 06:04:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-05 06:04:29 --> Input Class Initialized
INFO - 2018-06-05 06:04:29 --> Language Class Initialized
ERROR - 2018-06-05 06:04:29 --> 404 Page Not Found: /index
INFO - 2018-06-05 06:04:29 --> Config Class Initialized
INFO - 2018-06-05 06:04:29 --> Hooks Class Initialized
DEBUG - 2018-06-05 06:04:29 --> UTF-8 Support Enabled
INFO - 2018-06-05 06:04:29 --> Utf8 Class Initialized
INFO - 2018-06-05 06:04:29 --> URI Class Initialized
INFO - 2018-06-05 06:04:29 --> Router Class Initialized
INFO - 2018-06-05 06:04:29 --> Output Class Initialized
INFO - 2018-06-05 06:04:29 --> Security Class Initialized
DEBUG - 2018-06-05 06:04:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-05 06:04:29 --> Input Class Initialized
INFO - 2018-06-05 06:04:29 --> Language Class Initialized
ERROR - 2018-06-05 06:04:29 --> 404 Page Not Found: /index
INFO - 2018-06-05 06:04:29 --> Config Class Initialized
INFO - 2018-06-05 06:04:29 --> Hooks Class Initialized
DEBUG - 2018-06-05 06:04:29 --> UTF-8 Support Enabled
INFO - 2018-06-05 06:04:29 --> Utf8 Class Initialized
INFO - 2018-06-05 06:04:29 --> URI Class Initialized
INFO - 2018-06-05 06:04:29 --> Router Class Initialized
INFO - 2018-06-05 06:04:29 --> Output Class Initialized
INFO - 2018-06-05 06:04:29 --> Security Class Initialized
DEBUG - 2018-06-05 06:04:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-05 06:04:29 --> Input Class Initialized
INFO - 2018-06-05 06:04:29 --> Language Class Initialized
ERROR - 2018-06-05 06:04:29 --> 404 Page Not Found: /index
INFO - 2018-06-05 06:04:56 --> Config Class Initialized
INFO - 2018-06-05 06:04:56 --> Hooks Class Initialized
DEBUG - 2018-06-05 06:04:56 --> UTF-8 Support Enabled
INFO - 2018-06-05 06:04:56 --> Utf8 Class Initialized
INFO - 2018-06-05 06:04:56 --> URI Class Initialized
INFO - 2018-06-05 06:04:56 --> Router Class Initialized
INFO - 2018-06-05 06:04:56 --> Output Class Initialized
INFO - 2018-06-05 06:04:56 --> Security Class Initialized
DEBUG - 2018-06-05 06:04:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-05 06:04:56 --> Input Class Initialized
INFO - 2018-06-05 06:04:56 --> Language Class Initialized
INFO - 2018-06-05 06:04:56 --> Language Class Initialized
INFO - 2018-06-05 06:04:56 --> Config Class Initialized
INFO - 2018-06-05 06:04:56 --> Loader Class Initialized
DEBUG - 2018-06-05 06:04:56 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-05 06:04:56 --> Helper loaded: url_helper
INFO - 2018-06-05 06:04:56 --> Helper loaded: form_helper
INFO - 2018-06-05 06:04:56 --> Helper loaded: date_helper
INFO - 2018-06-05 06:04:56 --> Helper loaded: util_helper
INFO - 2018-06-05 06:04:56 --> Helper loaded: text_helper
INFO - 2018-06-05 06:04:56 --> Helper loaded: string_helper
INFO - 2018-06-05 06:04:56 --> Database Driver Class Initialized
DEBUG - 2018-06-05 06:04:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-05 06:04:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-05 06:04:56 --> Email Class Initialized
INFO - 2018-06-05 06:04:56 --> Controller Class Initialized
DEBUG - 2018-06-05 06:04:56 --> Login MX_Controller Initialized
INFO - 2018-06-05 06:04:56 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-05 06:04:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-05 06:04:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-05 06:04:56 --> 4 Loggedout
INFO - 2018-06-05 06:04:56 --> Config Class Initialized
INFO - 2018-06-05 06:04:56 --> Hooks Class Initialized
DEBUG - 2018-06-05 06:04:56 --> UTF-8 Support Enabled
INFO - 2018-06-05 06:04:56 --> Utf8 Class Initialized
INFO - 2018-06-05 06:04:56 --> URI Class Initialized
INFO - 2018-06-05 06:04:56 --> Router Class Initialized
INFO - 2018-06-05 06:04:56 --> Output Class Initialized
INFO - 2018-06-05 06:04:56 --> Security Class Initialized
DEBUG - 2018-06-05 06:04:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-05 06:04:56 --> Input Class Initialized
INFO - 2018-06-05 06:04:56 --> Language Class Initialized
INFO - 2018-06-05 06:04:56 --> Language Class Initialized
INFO - 2018-06-05 06:04:56 --> Config Class Initialized
INFO - 2018-06-05 06:04:56 --> Loader Class Initialized
DEBUG - 2018-06-05 06:04:56 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-05 06:04:56 --> Helper loaded: url_helper
INFO - 2018-06-05 06:04:56 --> Helper loaded: form_helper
INFO - 2018-06-05 06:04:56 --> Helper loaded: date_helper
INFO - 2018-06-05 06:04:56 --> Helper loaded: util_helper
INFO - 2018-06-05 06:04:56 --> Helper loaded: text_helper
INFO - 2018-06-05 06:04:56 --> Helper loaded: string_helper
INFO - 2018-06-05 06:04:56 --> Database Driver Class Initialized
DEBUG - 2018-06-05 06:04:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-05 06:04:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-05 06:04:56 --> Email Class Initialized
INFO - 2018-06-05 06:04:56 --> Controller Class Initialized
DEBUG - 2018-06-05 06:04:56 --> Home MX_Controller Initialized
DEBUG - 2018-06-05 06:04:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-05 06:04:56 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-05 06:04:56 --> Login MX_Controller Initialized
INFO - 2018-06-05 06:04:56 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-05 06:04:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-05 06:04:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-05 06:04:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
