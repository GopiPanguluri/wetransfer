<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-06-09 02:28:21 --> Config Class Initialized
INFO - 2018-06-09 02:28:21 --> Hooks Class Initialized
DEBUG - 2018-06-09 02:28:21 --> UTF-8 Support Enabled
INFO - 2018-06-09 02:28:21 --> Utf8 Class Initialized
INFO - 2018-06-09 02:28:21 --> URI Class Initialized
INFO - 2018-06-09 02:28:22 --> Router Class Initialized
INFO - 2018-06-09 02:28:22 --> Output Class Initialized
INFO - 2018-06-09 02:28:22 --> Security Class Initialized
DEBUG - 2018-06-09 02:28:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-09 02:28:22 --> Input Class Initialized
INFO - 2018-06-09 02:28:22 --> Language Class Initialized
INFO - 2018-06-09 02:28:22 --> Language Class Initialized
INFO - 2018-06-09 02:28:22 --> Config Class Initialized
INFO - 2018-06-09 02:28:22 --> Loader Class Initialized
DEBUG - 2018-06-09 02:28:22 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-09 02:28:22 --> Helper loaded: url_helper
INFO - 2018-06-09 02:28:22 --> Helper loaded: form_helper
INFO - 2018-06-09 02:28:22 --> Helper loaded: date_helper
INFO - 2018-06-09 02:28:22 --> Helper loaded: util_helper
INFO - 2018-06-09 02:28:22 --> Helper loaded: text_helper
INFO - 2018-06-09 02:28:22 --> Helper loaded: string_helper
INFO - 2018-06-09 02:28:22 --> Database Driver Class Initialized
DEBUG - 2018-06-09 02:28:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-09 02:28:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-09 02:28:24 --> Email Class Initialized
INFO - 2018-06-09 02:28:24 --> Controller Class Initialized
DEBUG - 2018-06-09 02:28:24 --> Admin MX_Controller Initialized
INFO - 2018-06-09 02:28:24 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-09 02:28:24 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-09 02:28:24 --> Login MX_Controller Initialized
DEBUG - 2018-06-09 02:28:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-09 02:28:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-09 02:28:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
INFO - 2018-06-09 02:28:25 --> Config Class Initialized
INFO - 2018-06-09 02:28:25 --> Hooks Class Initialized
DEBUG - 2018-06-09 02:28:25 --> UTF-8 Support Enabled
INFO - 2018-06-09 02:28:25 --> Utf8 Class Initialized
INFO - 2018-06-09 02:28:25 --> URI Class Initialized
INFO - 2018-06-09 02:28:25 --> Router Class Initialized
INFO - 2018-06-09 02:28:25 --> Output Class Initialized
INFO - 2018-06-09 02:28:25 --> Security Class Initialized
DEBUG - 2018-06-09 02:28:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-09 02:28:25 --> Input Class Initialized
INFO - 2018-06-09 02:28:25 --> Language Class Initialized
ERROR - 2018-06-09 02:28:25 --> 404 Page Not Found: /index
INFO - 2018-06-09 02:29:04 --> Config Class Initialized
INFO - 2018-06-09 02:29:04 --> Hooks Class Initialized
DEBUG - 2018-06-09 02:29:04 --> UTF-8 Support Enabled
INFO - 2018-06-09 02:29:04 --> Utf8 Class Initialized
INFO - 2018-06-09 02:29:04 --> URI Class Initialized
INFO - 2018-06-09 02:29:04 --> Router Class Initialized
INFO - 2018-06-09 02:29:04 --> Output Class Initialized
INFO - 2018-06-09 02:29:04 --> Security Class Initialized
DEBUG - 2018-06-09 02:29:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-09 02:29:04 --> Input Class Initialized
INFO - 2018-06-09 02:29:04 --> Language Class Initialized
INFO - 2018-06-09 02:29:05 --> Language Class Initialized
INFO - 2018-06-09 02:29:05 --> Config Class Initialized
INFO - 2018-06-09 02:29:05 --> Loader Class Initialized
DEBUG - 2018-06-09 02:29:05 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-09 02:29:05 --> Helper loaded: url_helper
INFO - 2018-06-09 02:29:05 --> Helper loaded: form_helper
INFO - 2018-06-09 02:29:05 --> Helper loaded: date_helper
INFO - 2018-06-09 02:29:05 --> Helper loaded: util_helper
INFO - 2018-06-09 02:29:05 --> Helper loaded: text_helper
INFO - 2018-06-09 02:29:05 --> Helper loaded: string_helper
INFO - 2018-06-09 02:29:05 --> Database Driver Class Initialized
DEBUG - 2018-06-09 02:29:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-09 02:29:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-09 02:29:05 --> Email Class Initialized
INFO - 2018-06-09 02:29:05 --> Controller Class Initialized
DEBUG - 2018-06-09 02:29:05 --> Login MX_Controller Initialized
INFO - 2018-06-09 02:29:05 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-09 02:29:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-09 02:29:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-09 02:29:05 --> Email starts for admin@colin.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-06-09 02:29:05 --> User session created for 1
INFO - 2018-06-09 02:29:05 --> Login status admin@colin.com - success
ERROR - 2018-06-09 02:29:05 --> Severity: Notice --> Undefined index: redirect_url E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php 303
INFO - 2018-06-09 02:29:05 --> Final output sent to browser
DEBUG - 2018-06-09 02:29:05 --> Total execution time: 0.5860
INFO - 2018-06-09 02:29:08 --> Config Class Initialized
INFO - 2018-06-09 02:29:08 --> Hooks Class Initialized
DEBUG - 2018-06-09 02:29:08 --> UTF-8 Support Enabled
INFO - 2018-06-09 02:29:08 --> Utf8 Class Initialized
INFO - 2018-06-09 02:29:08 --> URI Class Initialized
INFO - 2018-06-09 02:29:08 --> Router Class Initialized
INFO - 2018-06-09 02:29:08 --> Output Class Initialized
INFO - 2018-06-09 02:29:09 --> Security Class Initialized
DEBUG - 2018-06-09 02:29:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-09 02:29:09 --> Input Class Initialized
INFO - 2018-06-09 02:29:09 --> Language Class Initialized
INFO - 2018-06-09 02:29:09 --> Language Class Initialized
INFO - 2018-06-09 02:29:09 --> Config Class Initialized
INFO - 2018-06-09 02:29:09 --> Loader Class Initialized
DEBUG - 2018-06-09 02:29:09 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-09 02:29:09 --> Helper loaded: url_helper
INFO - 2018-06-09 02:29:09 --> Helper loaded: form_helper
INFO - 2018-06-09 02:29:09 --> Helper loaded: date_helper
INFO - 2018-06-09 02:29:09 --> Helper loaded: util_helper
INFO - 2018-06-09 02:29:09 --> Helper loaded: text_helper
INFO - 2018-06-09 02:29:09 --> Helper loaded: string_helper
INFO - 2018-06-09 02:29:09 --> Database Driver Class Initialized
DEBUG - 2018-06-09 02:29:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-09 02:29:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-09 02:29:09 --> Email Class Initialized
INFO - 2018-06-09 02:29:09 --> Controller Class Initialized
DEBUG - 2018-06-09 02:29:09 --> Admin MX_Controller Initialized
INFO - 2018-06-09 02:29:09 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-09 02:29:09 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-09 02:29:09 --> Login MX_Controller Initialized
DEBUG - 2018-06-09 02:29:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-09 02:29:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-09 02:29:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-09 02:29:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-09 02:29:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-09 02:29:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-09 02:29:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-09 02:29:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/dashboard.php
INFO - 2018-06-09 02:29:09 --> Final output sent to browser
DEBUG - 2018-06-09 02:29:09 --> Total execution time: 0.4744
INFO - 2018-06-09 02:29:09 --> Config Class Initialized
INFO - 2018-06-09 02:29:09 --> Hooks Class Initialized
DEBUG - 2018-06-09 02:29:09 --> UTF-8 Support Enabled
INFO - 2018-06-09 02:29:09 --> Utf8 Class Initialized
INFO - 2018-06-09 02:29:09 --> URI Class Initialized
INFO - 2018-06-09 02:29:09 --> Router Class Initialized
INFO - 2018-06-09 02:29:09 --> Output Class Initialized
INFO - 2018-06-09 02:29:09 --> Security Class Initialized
DEBUG - 2018-06-09 02:29:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-09 02:29:09 --> Input Class Initialized
INFO - 2018-06-09 02:29:09 --> Config Class Initialized
INFO - 2018-06-09 02:29:10 --> Hooks Class Initialized
INFO - 2018-06-09 02:29:10 --> Language Class Initialized
ERROR - 2018-06-09 02:29:10 --> 404 Page Not Found: /index
DEBUG - 2018-06-09 02:29:10 --> UTF-8 Support Enabled
INFO - 2018-06-09 02:29:10 --> Utf8 Class Initialized
INFO - 2018-06-09 02:29:10 --> URI Class Initialized
INFO - 2018-06-09 02:29:10 --> Router Class Initialized
INFO - 2018-06-09 02:29:10 --> Output Class Initialized
INFO - 2018-06-09 02:29:10 --> Security Class Initialized
DEBUG - 2018-06-09 02:29:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-09 02:29:10 --> Input Class Initialized
INFO - 2018-06-09 02:29:10 --> Language Class Initialized
ERROR - 2018-06-09 02:29:10 --> 404 Page Not Found: /index
INFO - 2018-06-09 02:29:14 --> Config Class Initialized
INFO - 2018-06-09 02:29:14 --> Hooks Class Initialized
DEBUG - 2018-06-09 02:29:14 --> UTF-8 Support Enabled
INFO - 2018-06-09 02:29:14 --> Utf8 Class Initialized
INFO - 2018-06-09 02:29:14 --> URI Class Initialized
INFO - 2018-06-09 02:29:14 --> Router Class Initialized
INFO - 2018-06-09 02:29:14 --> Output Class Initialized
INFO - 2018-06-09 02:29:14 --> Security Class Initialized
DEBUG - 2018-06-09 02:29:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-09 02:29:14 --> Input Class Initialized
INFO - 2018-06-09 02:29:14 --> Language Class Initialized
INFO - 2018-06-09 02:29:14 --> Language Class Initialized
INFO - 2018-06-09 02:29:14 --> Config Class Initialized
INFO - 2018-06-09 02:29:14 --> Loader Class Initialized
DEBUG - 2018-06-09 02:29:14 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-09 02:29:14 --> Helper loaded: url_helper
INFO - 2018-06-09 02:29:14 --> Helper loaded: form_helper
INFO - 2018-06-09 02:29:14 --> Helper loaded: date_helper
INFO - 2018-06-09 02:29:14 --> Helper loaded: util_helper
INFO - 2018-06-09 02:29:14 --> Helper loaded: text_helper
INFO - 2018-06-09 02:29:14 --> Helper loaded: string_helper
INFO - 2018-06-09 02:29:14 --> Database Driver Class Initialized
DEBUG - 2018-06-09 02:29:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-09 02:29:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-09 02:29:14 --> Email Class Initialized
INFO - 2018-06-09 02:29:14 --> Controller Class Initialized
DEBUG - 2018-06-09 02:29:14 --> Login MX_Controller Initialized
INFO - 2018-06-09 02:29:14 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-09 02:29:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-09 02:29:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-09 02:29:14 --> 1 Loggedout
INFO - 2018-06-09 02:29:14 --> Config Class Initialized
INFO - 2018-06-09 02:29:14 --> Hooks Class Initialized
DEBUG - 2018-06-09 02:29:15 --> UTF-8 Support Enabled
INFO - 2018-06-09 02:29:15 --> Utf8 Class Initialized
INFO - 2018-06-09 02:29:15 --> URI Class Initialized
INFO - 2018-06-09 02:29:15 --> Router Class Initialized
INFO - 2018-06-09 02:29:15 --> Output Class Initialized
INFO - 2018-06-09 02:29:15 --> Security Class Initialized
DEBUG - 2018-06-09 02:29:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-09 02:29:15 --> Input Class Initialized
INFO - 2018-06-09 02:29:15 --> Language Class Initialized
INFO - 2018-06-09 02:29:15 --> Language Class Initialized
INFO - 2018-06-09 02:29:15 --> Config Class Initialized
INFO - 2018-06-09 02:29:15 --> Loader Class Initialized
DEBUG - 2018-06-09 02:29:15 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-09 02:29:15 --> Helper loaded: url_helper
INFO - 2018-06-09 02:29:15 --> Helper loaded: form_helper
INFO - 2018-06-09 02:29:15 --> Helper loaded: date_helper
INFO - 2018-06-09 02:29:15 --> Helper loaded: util_helper
INFO - 2018-06-09 02:29:15 --> Helper loaded: text_helper
INFO - 2018-06-09 02:29:15 --> Helper loaded: string_helper
INFO - 2018-06-09 02:29:15 --> Database Driver Class Initialized
DEBUG - 2018-06-09 02:29:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-09 02:29:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-09 02:29:15 --> Email Class Initialized
INFO - 2018-06-09 02:29:15 --> Controller Class Initialized
DEBUG - 2018-06-09 02:29:15 --> Admin MX_Controller Initialized
INFO - 2018-06-09 02:29:15 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-09 02:29:15 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-09 02:29:15 --> Login MX_Controller Initialized
DEBUG - 2018-06-09 02:29:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-09 02:29:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-09 02:29:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
INFO - 2018-06-09 02:29:15 --> Config Class Initialized
INFO - 2018-06-09 02:29:15 --> Hooks Class Initialized
DEBUG - 2018-06-09 02:29:15 --> UTF-8 Support Enabled
INFO - 2018-06-09 02:29:15 --> Utf8 Class Initialized
INFO - 2018-06-09 02:29:15 --> URI Class Initialized
INFO - 2018-06-09 02:29:15 --> Router Class Initialized
INFO - 2018-06-09 02:29:15 --> Output Class Initialized
INFO - 2018-06-09 02:29:15 --> Security Class Initialized
DEBUG - 2018-06-09 02:29:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-09 02:29:15 --> Input Class Initialized
INFO - 2018-06-09 02:29:15 --> Language Class Initialized
ERROR - 2018-06-09 02:29:15 --> 404 Page Not Found: /index
INFO - 2018-06-09 02:30:44 --> Config Class Initialized
INFO - 2018-06-09 02:30:44 --> Hooks Class Initialized
DEBUG - 2018-06-09 02:30:44 --> UTF-8 Support Enabled
INFO - 2018-06-09 02:30:44 --> Utf8 Class Initialized
INFO - 2018-06-09 02:30:44 --> URI Class Initialized
INFO - 2018-06-09 02:30:44 --> Router Class Initialized
INFO - 2018-06-09 02:30:44 --> Output Class Initialized
INFO - 2018-06-09 02:30:44 --> Security Class Initialized
DEBUG - 2018-06-09 02:30:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-09 02:30:44 --> Input Class Initialized
INFO - 2018-06-09 02:30:44 --> Language Class Initialized
INFO - 2018-06-09 02:30:44 --> Language Class Initialized
INFO - 2018-06-09 02:30:44 --> Config Class Initialized
INFO - 2018-06-09 02:30:44 --> Loader Class Initialized
DEBUG - 2018-06-09 02:30:44 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-09 02:30:44 --> Helper loaded: url_helper
INFO - 2018-06-09 02:30:44 --> Helper loaded: form_helper
INFO - 2018-06-09 02:30:44 --> Helper loaded: date_helper
INFO - 2018-06-09 02:30:44 --> Helper loaded: util_helper
INFO - 2018-06-09 02:30:44 --> Helper loaded: text_helper
INFO - 2018-06-09 02:30:44 --> Helper loaded: string_helper
INFO - 2018-06-09 02:30:44 --> Database Driver Class Initialized
DEBUG - 2018-06-09 02:30:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-09 02:30:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-09 02:30:44 --> Email Class Initialized
INFO - 2018-06-09 02:30:44 --> Controller Class Initialized
DEBUG - 2018-06-09 02:30:44 --> Admin MX_Controller Initialized
INFO - 2018-06-09 02:30:44 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-09 02:30:44 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-09 02:30:44 --> Login MX_Controller Initialized
DEBUG - 2018-06-09 02:30:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-09 02:30:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-09 02:30:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
INFO - 2018-06-09 02:31:46 --> Config Class Initialized
INFO - 2018-06-09 02:31:46 --> Hooks Class Initialized
DEBUG - 2018-06-09 02:31:46 --> UTF-8 Support Enabled
INFO - 2018-06-09 02:31:46 --> Utf8 Class Initialized
INFO - 2018-06-09 02:31:46 --> URI Class Initialized
INFO - 2018-06-09 02:31:46 --> Router Class Initialized
INFO - 2018-06-09 02:31:46 --> Output Class Initialized
INFO - 2018-06-09 02:31:46 --> Security Class Initialized
DEBUG - 2018-06-09 02:31:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-09 02:31:46 --> Input Class Initialized
INFO - 2018-06-09 02:31:46 --> Language Class Initialized
INFO - 2018-06-09 02:31:46 --> Language Class Initialized
INFO - 2018-06-09 02:31:46 --> Config Class Initialized
INFO - 2018-06-09 02:31:46 --> Loader Class Initialized
DEBUG - 2018-06-09 02:31:46 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-09 02:31:46 --> Helper loaded: url_helper
INFO - 2018-06-09 02:31:46 --> Helper loaded: form_helper
INFO - 2018-06-09 02:31:46 --> Helper loaded: date_helper
INFO - 2018-06-09 02:31:46 --> Helper loaded: util_helper
INFO - 2018-06-09 02:31:46 --> Helper loaded: text_helper
INFO - 2018-06-09 02:31:46 --> Helper loaded: string_helper
INFO - 2018-06-09 02:31:46 --> Database Driver Class Initialized
DEBUG - 2018-06-09 02:31:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-09 02:31:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-09 02:31:46 --> Email Class Initialized
INFO - 2018-06-09 02:31:46 --> Controller Class Initialized
DEBUG - 2018-06-09 02:31:46 --> Admin MX_Controller Initialized
INFO - 2018-06-09 02:31:46 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-09 02:31:46 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-09 02:31:46 --> Login MX_Controller Initialized
DEBUG - 2018-06-09 02:31:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-09 02:31:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-09 02:31:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
INFO - 2018-06-09 02:31:47 --> Config Class Initialized
INFO - 2018-06-09 02:31:47 --> Hooks Class Initialized
DEBUG - 2018-06-09 02:31:47 --> UTF-8 Support Enabled
INFO - 2018-06-09 02:31:47 --> Utf8 Class Initialized
INFO - 2018-06-09 02:31:47 --> URI Class Initialized
INFO - 2018-06-09 02:31:47 --> Router Class Initialized
INFO - 2018-06-09 02:31:47 --> Output Class Initialized
INFO - 2018-06-09 02:31:47 --> Security Class Initialized
DEBUG - 2018-06-09 02:31:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-09 02:31:47 --> Input Class Initialized
INFO - 2018-06-09 02:31:47 --> Language Class Initialized
ERROR - 2018-06-09 02:31:47 --> 404 Page Not Found: /index
INFO - 2018-06-09 02:31:49 --> Config Class Initialized
INFO - 2018-06-09 02:31:49 --> Hooks Class Initialized
DEBUG - 2018-06-09 02:31:49 --> UTF-8 Support Enabled
INFO - 2018-06-09 02:31:49 --> Utf8 Class Initialized
INFO - 2018-06-09 02:31:49 --> URI Class Initialized
INFO - 2018-06-09 02:31:49 --> Router Class Initialized
INFO - 2018-06-09 02:31:49 --> Output Class Initialized
INFO - 2018-06-09 02:31:49 --> Security Class Initialized
DEBUG - 2018-06-09 02:31:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-09 02:31:49 --> Input Class Initialized
INFO - 2018-06-09 02:31:49 --> Language Class Initialized
INFO - 2018-06-09 02:31:49 --> Language Class Initialized
INFO - 2018-06-09 02:31:49 --> Config Class Initialized
INFO - 2018-06-09 02:31:49 --> Loader Class Initialized
DEBUG - 2018-06-09 02:31:49 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-09 02:31:49 --> Helper loaded: url_helper
INFO - 2018-06-09 02:31:49 --> Helper loaded: form_helper
INFO - 2018-06-09 02:31:49 --> Helper loaded: date_helper
INFO - 2018-06-09 02:31:49 --> Helper loaded: util_helper
INFO - 2018-06-09 02:31:49 --> Helper loaded: text_helper
INFO - 2018-06-09 02:31:49 --> Helper loaded: string_helper
INFO - 2018-06-09 02:31:49 --> Database Driver Class Initialized
DEBUG - 2018-06-09 02:31:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-09 02:31:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-09 02:31:49 --> Email Class Initialized
INFO - 2018-06-09 02:31:49 --> Controller Class Initialized
DEBUG - 2018-06-09 02:31:49 --> Login MX_Controller Initialized
INFO - 2018-06-09 02:31:49 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-09 02:31:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-09 02:31:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-09 02:31:49 --> Email starts for gopipanguluri123@gmail.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-06-09 02:31:49 --> Login status gopipanguluri123@gmail.com - failure
INFO - 2018-06-09 02:31:49 --> Final output sent to browser
DEBUG - 2018-06-09 02:31:49 --> Total execution time: 0.2856
INFO - 2018-06-09 02:31:54 --> Config Class Initialized
INFO - 2018-06-09 02:31:54 --> Hooks Class Initialized
DEBUG - 2018-06-09 02:31:54 --> UTF-8 Support Enabled
INFO - 2018-06-09 02:31:54 --> Utf8 Class Initialized
INFO - 2018-06-09 02:31:54 --> URI Class Initialized
INFO - 2018-06-09 02:31:54 --> Router Class Initialized
INFO - 2018-06-09 02:31:54 --> Output Class Initialized
INFO - 2018-06-09 02:31:54 --> Security Class Initialized
DEBUG - 2018-06-09 02:31:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-09 02:31:54 --> Input Class Initialized
INFO - 2018-06-09 02:31:54 --> Language Class Initialized
INFO - 2018-06-09 02:31:54 --> Language Class Initialized
INFO - 2018-06-09 02:31:54 --> Config Class Initialized
INFO - 2018-06-09 02:31:54 --> Loader Class Initialized
DEBUG - 2018-06-09 02:31:54 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-09 02:31:54 --> Helper loaded: url_helper
INFO - 2018-06-09 02:31:54 --> Helper loaded: form_helper
INFO - 2018-06-09 02:31:54 --> Helper loaded: date_helper
INFO - 2018-06-09 02:31:54 --> Helper loaded: util_helper
INFO - 2018-06-09 02:31:54 --> Helper loaded: text_helper
INFO - 2018-06-09 02:31:54 --> Helper loaded: string_helper
INFO - 2018-06-09 02:31:54 --> Database Driver Class Initialized
DEBUG - 2018-06-09 02:31:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-09 02:31:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-09 02:31:54 --> Email Class Initialized
INFO - 2018-06-09 02:31:54 --> Controller Class Initialized
DEBUG - 2018-06-09 02:31:54 --> Login MX_Controller Initialized
INFO - 2018-06-09 02:31:54 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-09 02:31:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-09 02:31:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-09 02:31:54 --> Email starts for admin@colin.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-06-09 02:31:54 --> User session created for 1
INFO - 2018-06-09 02:31:54 --> Login status admin@colin.com - success
INFO - 2018-06-09 02:31:54 --> Final output sent to browser
DEBUG - 2018-06-09 02:31:54 --> Total execution time: 0.3539
INFO - 2018-06-09 02:31:54 --> Config Class Initialized
INFO - 2018-06-09 02:31:54 --> Hooks Class Initialized
DEBUG - 2018-06-09 02:31:54 --> UTF-8 Support Enabled
INFO - 2018-06-09 02:31:54 --> Utf8 Class Initialized
INFO - 2018-06-09 02:31:54 --> URI Class Initialized
INFO - 2018-06-09 02:31:54 --> Router Class Initialized
INFO - 2018-06-09 02:31:54 --> Output Class Initialized
INFO - 2018-06-09 02:31:54 --> Security Class Initialized
DEBUG - 2018-06-09 02:31:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-09 02:31:54 --> Input Class Initialized
INFO - 2018-06-09 02:31:54 --> Language Class Initialized
INFO - 2018-06-09 02:31:54 --> Language Class Initialized
INFO - 2018-06-09 02:31:54 --> Config Class Initialized
INFO - 2018-06-09 02:31:54 --> Loader Class Initialized
DEBUG - 2018-06-09 02:31:54 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-09 02:31:54 --> Helper loaded: url_helper
INFO - 2018-06-09 02:31:54 --> Helper loaded: form_helper
INFO - 2018-06-09 02:31:54 --> Helper loaded: date_helper
INFO - 2018-06-09 02:31:54 --> Helper loaded: util_helper
INFO - 2018-06-09 02:31:54 --> Helper loaded: text_helper
INFO - 2018-06-09 02:31:54 --> Helper loaded: string_helper
INFO - 2018-06-09 02:31:54 --> Database Driver Class Initialized
DEBUG - 2018-06-09 02:31:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-09 02:31:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-09 02:31:54 --> Email Class Initialized
INFO - 2018-06-09 02:31:54 --> Controller Class Initialized
DEBUG - 2018-06-09 02:31:54 --> Admin MX_Controller Initialized
INFO - 2018-06-09 02:31:55 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-09 02:31:55 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-09 02:31:55 --> Login MX_Controller Initialized
DEBUG - 2018-06-09 02:31:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-09 02:31:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-09 02:31:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-09 02:31:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-09 02:31:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-09 02:31:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-09 02:31:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-09 02:31:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/dashboard.php
INFO - 2018-06-09 02:31:55 --> Final output sent to browser
DEBUG - 2018-06-09 02:31:55 --> Total execution time: 0.3490
INFO - 2018-06-09 02:31:55 --> Config Class Initialized
INFO - 2018-06-09 02:31:55 --> Hooks Class Initialized
INFO - 2018-06-09 02:31:55 --> Config Class Initialized
INFO - 2018-06-09 02:31:55 --> Hooks Class Initialized
DEBUG - 2018-06-09 02:31:55 --> UTF-8 Support Enabled
DEBUG - 2018-06-09 02:31:55 --> UTF-8 Support Enabled
INFO - 2018-06-09 02:31:55 --> Utf8 Class Initialized
INFO - 2018-06-09 02:31:55 --> Utf8 Class Initialized
INFO - 2018-06-09 02:31:55 --> URI Class Initialized
INFO - 2018-06-09 02:31:55 --> URI Class Initialized
INFO - 2018-06-09 02:31:55 --> Router Class Initialized
INFO - 2018-06-09 02:31:55 --> Router Class Initialized
INFO - 2018-06-09 02:31:55 --> Output Class Initialized
INFO - 2018-06-09 02:31:55 --> Security Class Initialized
INFO - 2018-06-09 02:31:55 --> Output Class Initialized
DEBUG - 2018-06-09 02:31:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-09 02:31:55 --> Input Class Initialized
INFO - 2018-06-09 02:31:55 --> Language Class Initialized
ERROR - 2018-06-09 02:31:55 --> 404 Page Not Found: /index
INFO - 2018-06-09 02:31:55 --> Security Class Initialized
DEBUG - 2018-06-09 02:31:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-09 02:31:55 --> Input Class Initialized
INFO - 2018-06-09 02:31:55 --> Language Class Initialized
ERROR - 2018-06-09 02:31:55 --> 404 Page Not Found: /index
INFO - 2018-06-09 02:31:57 --> Config Class Initialized
INFO - 2018-06-09 02:31:57 --> Hooks Class Initialized
DEBUG - 2018-06-09 02:31:57 --> UTF-8 Support Enabled
INFO - 2018-06-09 02:31:57 --> Utf8 Class Initialized
INFO - 2018-06-09 02:31:57 --> URI Class Initialized
INFO - 2018-06-09 02:31:57 --> Router Class Initialized
INFO - 2018-06-09 02:31:57 --> Output Class Initialized
INFO - 2018-06-09 02:31:57 --> Security Class Initialized
DEBUG - 2018-06-09 02:31:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-09 02:31:57 --> Input Class Initialized
INFO - 2018-06-09 02:31:57 --> Language Class Initialized
INFO - 2018-06-09 02:31:57 --> Language Class Initialized
INFO - 2018-06-09 02:31:57 --> Config Class Initialized
INFO - 2018-06-09 02:31:57 --> Loader Class Initialized
DEBUG - 2018-06-09 02:31:57 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-09 02:31:57 --> Helper loaded: url_helper
INFO - 2018-06-09 02:31:57 --> Helper loaded: form_helper
INFO - 2018-06-09 02:31:57 --> Helper loaded: date_helper
INFO - 2018-06-09 02:31:57 --> Helper loaded: util_helper
INFO - 2018-06-09 02:31:57 --> Helper loaded: text_helper
INFO - 2018-06-09 02:31:57 --> Helper loaded: string_helper
INFO - 2018-06-09 02:31:57 --> Database Driver Class Initialized
DEBUG - 2018-06-09 02:31:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-09 02:31:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-09 02:31:57 --> Email Class Initialized
INFO - 2018-06-09 02:31:57 --> Controller Class Initialized
DEBUG - 2018-06-09 02:31:57 --> Chapters MX_Controller Initialized
INFO - 2018-06-09 02:31:57 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-09 02:31:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Chapters_model.php
DEBUG - 2018-06-09 02:31:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-09 02:31:57 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-09 02:31:57 --> Login MX_Controller Initialized
DEBUG - 2018-06-09 02:31:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-09 02:31:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-09 02:31:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-09 02:31:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-09 02:31:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-09 02:31:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-09 02:31:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/chapters/chapters.php
INFO - 2018-06-09 02:31:57 --> Final output sent to browser
DEBUG - 2018-06-09 02:31:57 --> Total execution time: 0.4041
INFO - 2018-06-09 02:31:57 --> Config Class Initialized
INFO - 2018-06-09 02:31:57 --> Hooks Class Initialized
DEBUG - 2018-06-09 02:31:57 --> UTF-8 Support Enabled
INFO - 2018-06-09 02:31:57 --> Utf8 Class Initialized
INFO - 2018-06-09 02:31:57 --> URI Class Initialized
INFO - 2018-06-09 02:31:57 --> Router Class Initialized
INFO - 2018-06-09 02:31:57 --> Output Class Initialized
INFO - 2018-06-09 02:31:57 --> Security Class Initialized
DEBUG - 2018-06-09 02:31:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-09 02:31:57 --> Input Class Initialized
INFO - 2018-06-09 02:31:57 --> Language Class Initialized
INFO - 2018-06-09 02:31:57 --> Language Class Initialized
INFO - 2018-06-09 02:31:57 --> Config Class Initialized
INFO - 2018-06-09 02:31:57 --> Loader Class Initialized
DEBUG - 2018-06-09 02:31:57 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-09 02:31:57 --> Helper loaded: url_helper
INFO - 2018-06-09 02:31:57 --> Helper loaded: form_helper
INFO - 2018-06-09 02:31:57 --> Helper loaded: date_helper
INFO - 2018-06-09 02:31:58 --> Helper loaded: util_helper
INFO - 2018-06-09 02:31:58 --> Helper loaded: text_helper
INFO - 2018-06-09 02:31:58 --> Helper loaded: string_helper
INFO - 2018-06-09 02:31:58 --> Database Driver Class Initialized
DEBUG - 2018-06-09 02:31:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-09 02:31:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-09 02:31:58 --> Email Class Initialized
INFO - 2018-06-09 02:31:58 --> Controller Class Initialized
DEBUG - 2018-06-09 02:31:58 --> Chapters MX_Controller Initialized
INFO - 2018-06-09 02:31:58 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-09 02:31:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Chapters_model.php
DEBUG - 2018-06-09 02:31:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-09 02:31:58 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-09 02:31:58 --> Login MX_Controller Initialized
DEBUG - 2018-06-09 02:31:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-09 02:31:58 --> Final output sent to browser
DEBUG - 2018-06-09 02:31:58 --> Total execution time: 0.5968
INFO - 2018-06-09 02:31:59 --> Config Class Initialized
INFO - 2018-06-09 02:31:59 --> Hooks Class Initialized
DEBUG - 2018-06-09 02:31:59 --> UTF-8 Support Enabled
INFO - 2018-06-09 02:31:59 --> Utf8 Class Initialized
INFO - 2018-06-09 02:31:59 --> URI Class Initialized
INFO - 2018-06-09 02:31:59 --> Router Class Initialized
INFO - 2018-06-09 02:31:59 --> Output Class Initialized
INFO - 2018-06-09 02:31:59 --> Security Class Initialized
DEBUG - 2018-06-09 02:31:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-09 02:31:59 --> Input Class Initialized
INFO - 2018-06-09 02:31:59 --> Language Class Initialized
INFO - 2018-06-09 02:31:59 --> Language Class Initialized
INFO - 2018-06-09 02:31:59 --> Config Class Initialized
INFO - 2018-06-09 02:31:59 --> Loader Class Initialized
DEBUG - 2018-06-09 02:31:59 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-09 02:31:59 --> Helper loaded: url_helper
INFO - 2018-06-09 02:31:59 --> Helper loaded: form_helper
INFO - 2018-06-09 02:32:00 --> Helper loaded: date_helper
INFO - 2018-06-09 02:32:00 --> Helper loaded: util_helper
INFO - 2018-06-09 02:32:00 --> Helper loaded: text_helper
INFO - 2018-06-09 02:32:00 --> Helper loaded: string_helper
INFO - 2018-06-09 02:32:00 --> Database Driver Class Initialized
DEBUG - 2018-06-09 02:32:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-09 02:32:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-09 02:32:00 --> Email Class Initialized
INFO - 2018-06-09 02:32:00 --> Controller Class Initialized
DEBUG - 2018-06-09 02:32:00 --> Login MX_Controller Initialized
INFO - 2018-06-09 02:32:00 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-09 02:32:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-09 02:32:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-09 02:32:00 --> 1 Loggedout
INFO - 2018-06-09 02:32:00 --> Config Class Initialized
INFO - 2018-06-09 02:32:00 --> Hooks Class Initialized
DEBUG - 2018-06-09 02:32:00 --> UTF-8 Support Enabled
INFO - 2018-06-09 02:32:00 --> Utf8 Class Initialized
INFO - 2018-06-09 02:32:00 --> URI Class Initialized
INFO - 2018-06-09 02:32:00 --> Router Class Initialized
INFO - 2018-06-09 02:32:00 --> Output Class Initialized
INFO - 2018-06-09 02:32:00 --> Security Class Initialized
DEBUG - 2018-06-09 02:32:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-09 02:32:00 --> Input Class Initialized
INFO - 2018-06-09 02:32:00 --> Language Class Initialized
INFO - 2018-06-09 02:32:00 --> Language Class Initialized
INFO - 2018-06-09 02:32:00 --> Config Class Initialized
INFO - 2018-06-09 02:32:00 --> Loader Class Initialized
DEBUG - 2018-06-09 02:32:00 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-09 02:32:00 --> Helper loaded: url_helper
INFO - 2018-06-09 02:32:00 --> Helper loaded: form_helper
INFO - 2018-06-09 02:32:00 --> Helper loaded: date_helper
INFO - 2018-06-09 02:32:00 --> Helper loaded: util_helper
INFO - 2018-06-09 02:32:00 --> Helper loaded: text_helper
INFO - 2018-06-09 02:32:00 --> Helper loaded: string_helper
INFO - 2018-06-09 02:32:00 --> Database Driver Class Initialized
DEBUG - 2018-06-09 02:32:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-09 02:32:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-09 02:32:00 --> Email Class Initialized
INFO - 2018-06-09 02:32:00 --> Controller Class Initialized
DEBUG - 2018-06-09 02:32:00 --> Admin MX_Controller Initialized
INFO - 2018-06-09 02:32:00 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-09 02:32:00 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-09 02:32:00 --> Login MX_Controller Initialized
DEBUG - 2018-06-09 02:32:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-09 02:32:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-09 02:32:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
INFO - 2018-06-09 02:32:00 --> Config Class Initialized
INFO - 2018-06-09 02:32:00 --> Hooks Class Initialized
DEBUG - 2018-06-09 02:32:00 --> UTF-8 Support Enabled
INFO - 2018-06-09 02:32:00 --> Utf8 Class Initialized
INFO - 2018-06-09 02:32:00 --> URI Class Initialized
INFO - 2018-06-09 02:32:00 --> Router Class Initialized
INFO - 2018-06-09 02:32:00 --> Output Class Initialized
INFO - 2018-06-09 02:32:00 --> Security Class Initialized
DEBUG - 2018-06-09 02:32:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-09 02:32:00 --> Input Class Initialized
INFO - 2018-06-09 02:32:00 --> Language Class Initialized
ERROR - 2018-06-09 02:32:00 --> 404 Page Not Found: /index
INFO - 2018-06-09 02:32:00 --> Config Class Initialized
INFO - 2018-06-09 02:32:00 --> Hooks Class Initialized
DEBUG - 2018-06-09 02:32:00 --> UTF-8 Support Enabled
INFO - 2018-06-09 02:32:00 --> Utf8 Class Initialized
INFO - 2018-06-09 02:32:00 --> URI Class Initialized
INFO - 2018-06-09 02:32:00 --> Router Class Initialized
INFO - 2018-06-09 02:32:00 --> Output Class Initialized
INFO - 2018-06-09 02:32:00 --> Security Class Initialized
DEBUG - 2018-06-09 02:32:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-09 02:32:00 --> Input Class Initialized
INFO - 2018-06-09 02:32:01 --> Language Class Initialized
ERROR - 2018-06-09 02:32:01 --> 404 Page Not Found: /index
INFO - 2018-06-09 02:32:01 --> Config Class Initialized
INFO - 2018-06-09 02:32:01 --> Hooks Class Initialized
DEBUG - 2018-06-09 02:32:01 --> UTF-8 Support Enabled
INFO - 2018-06-09 02:32:01 --> Utf8 Class Initialized
INFO - 2018-06-09 02:32:01 --> URI Class Initialized
INFO - 2018-06-09 02:32:01 --> Router Class Initialized
INFO - 2018-06-09 02:32:01 --> Output Class Initialized
INFO - 2018-06-09 02:32:01 --> Security Class Initialized
DEBUG - 2018-06-09 02:32:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-09 02:32:01 --> Input Class Initialized
INFO - 2018-06-09 02:32:01 --> Language Class Initialized
INFO - 2018-06-09 02:32:01 --> Language Class Initialized
INFO - 2018-06-09 02:32:01 --> Config Class Initialized
INFO - 2018-06-09 02:32:01 --> Loader Class Initialized
DEBUG - 2018-06-09 02:32:01 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-09 02:32:01 --> Helper loaded: url_helper
INFO - 2018-06-09 02:32:01 --> Helper loaded: form_helper
INFO - 2018-06-09 02:32:01 --> Helper loaded: date_helper
INFO - 2018-06-09 02:32:01 --> Helper loaded: util_helper
INFO - 2018-06-09 02:32:01 --> Helper loaded: text_helper
INFO - 2018-06-09 02:32:01 --> Helper loaded: string_helper
INFO - 2018-06-09 02:32:01 --> Database Driver Class Initialized
DEBUG - 2018-06-09 02:32:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-09 02:32:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-09 02:32:01 --> Email Class Initialized
INFO - 2018-06-09 02:32:01 --> Controller Class Initialized
DEBUG - 2018-06-09 02:32:01 --> Chapters MX_Controller Initialized
INFO - 2018-06-09 02:32:01 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-09 02:32:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Chapters_model.php
DEBUG - 2018-06-09 02:32:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-09 02:32:01 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-09 02:32:01 --> Login MX_Controller Initialized
DEBUG - 2018-06-09 02:32:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-09 02:32:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
INFO - 2018-06-09 02:32:02 --> Config Class Initialized
INFO - 2018-06-09 02:32:02 --> Hooks Class Initialized
DEBUG - 2018-06-09 02:32:02 --> UTF-8 Support Enabled
INFO - 2018-06-09 02:32:02 --> Utf8 Class Initialized
INFO - 2018-06-09 02:32:02 --> URI Class Initialized
INFO - 2018-06-09 02:32:02 --> Router Class Initialized
INFO - 2018-06-09 02:32:02 --> Output Class Initialized
INFO - 2018-06-09 02:32:02 --> Security Class Initialized
DEBUG - 2018-06-09 02:32:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-09 02:32:02 --> Input Class Initialized
INFO - 2018-06-09 02:32:02 --> Language Class Initialized
ERROR - 2018-06-09 02:32:02 --> 404 Page Not Found: /index
INFO - 2018-06-09 02:32:02 --> Config Class Initialized
INFO - 2018-06-09 02:32:02 --> Hooks Class Initialized
DEBUG - 2018-06-09 02:32:02 --> UTF-8 Support Enabled
INFO - 2018-06-09 02:32:02 --> Utf8 Class Initialized
INFO - 2018-06-09 02:32:02 --> URI Class Initialized
INFO - 2018-06-09 02:32:02 --> Router Class Initialized
INFO - 2018-06-09 02:32:02 --> Output Class Initialized
INFO - 2018-06-09 02:32:02 --> Security Class Initialized
DEBUG - 2018-06-09 02:32:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-09 02:32:02 --> Input Class Initialized
INFO - 2018-06-09 02:32:02 --> Language Class Initialized
ERROR - 2018-06-09 02:32:02 --> 404 Page Not Found: /index
INFO - 2018-06-09 02:32:04 --> Config Class Initialized
INFO - 2018-06-09 02:32:04 --> Hooks Class Initialized
DEBUG - 2018-06-09 02:32:04 --> UTF-8 Support Enabled
INFO - 2018-06-09 02:32:04 --> Utf8 Class Initialized
INFO - 2018-06-09 02:32:04 --> URI Class Initialized
INFO - 2018-06-09 02:32:04 --> Router Class Initialized
INFO - 2018-06-09 02:32:04 --> Output Class Initialized
INFO - 2018-06-09 02:32:04 --> Security Class Initialized
DEBUG - 2018-06-09 02:32:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-09 02:32:04 --> Input Class Initialized
INFO - 2018-06-09 02:32:04 --> Language Class Initialized
INFO - 2018-06-09 02:32:04 --> Language Class Initialized
INFO - 2018-06-09 02:32:04 --> Config Class Initialized
INFO - 2018-06-09 02:32:04 --> Loader Class Initialized
DEBUG - 2018-06-09 02:32:04 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-09 02:32:04 --> Helper loaded: url_helper
INFO - 2018-06-09 02:32:04 --> Helper loaded: form_helper
INFO - 2018-06-09 02:32:04 --> Helper loaded: date_helper
INFO - 2018-06-09 02:32:04 --> Helper loaded: util_helper
INFO - 2018-06-09 02:32:04 --> Helper loaded: text_helper
INFO - 2018-06-09 02:32:05 --> Helper loaded: string_helper
INFO - 2018-06-09 02:32:05 --> Database Driver Class Initialized
DEBUG - 2018-06-09 02:32:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-09 02:32:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-09 02:32:05 --> Email Class Initialized
INFO - 2018-06-09 02:32:05 --> Controller Class Initialized
DEBUG - 2018-06-09 02:32:05 --> Login MX_Controller Initialized
INFO - 2018-06-09 02:32:05 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-09 02:32:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-09 02:32:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-09 02:32:05 --> Email starts for gopipanguluri123@gmail.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-06-09 02:32:05 --> Login status gopipanguluri123@gmail.com - failure
INFO - 2018-06-09 02:32:05 --> Final output sent to browser
DEBUG - 2018-06-09 02:32:05 --> Total execution time: 0.4991
INFO - 2018-06-09 02:32:10 --> Config Class Initialized
INFO - 2018-06-09 02:32:10 --> Hooks Class Initialized
DEBUG - 2018-06-09 02:32:10 --> UTF-8 Support Enabled
INFO - 2018-06-09 02:32:10 --> Utf8 Class Initialized
INFO - 2018-06-09 02:32:10 --> URI Class Initialized
INFO - 2018-06-09 02:32:10 --> Router Class Initialized
INFO - 2018-06-09 02:32:10 --> Output Class Initialized
INFO - 2018-06-09 02:32:10 --> Security Class Initialized
DEBUG - 2018-06-09 02:32:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-09 02:32:10 --> Input Class Initialized
INFO - 2018-06-09 02:32:10 --> Language Class Initialized
INFO - 2018-06-09 02:32:10 --> Language Class Initialized
INFO - 2018-06-09 02:32:10 --> Config Class Initialized
INFO - 2018-06-09 02:32:10 --> Loader Class Initialized
DEBUG - 2018-06-09 02:32:10 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-09 02:32:10 --> Helper loaded: url_helper
INFO - 2018-06-09 02:32:10 --> Helper loaded: form_helper
INFO - 2018-06-09 02:32:10 --> Helper loaded: date_helper
INFO - 2018-06-09 02:32:10 --> Helper loaded: util_helper
INFO - 2018-06-09 02:32:10 --> Helper loaded: text_helper
INFO - 2018-06-09 02:32:11 --> Helper loaded: string_helper
INFO - 2018-06-09 02:32:11 --> Database Driver Class Initialized
DEBUG - 2018-06-09 02:32:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-09 02:32:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-09 02:32:11 --> Email Class Initialized
INFO - 2018-06-09 02:32:11 --> Controller Class Initialized
DEBUG - 2018-06-09 02:32:11 --> Login MX_Controller Initialized
INFO - 2018-06-09 02:32:11 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-09 02:32:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-09 02:32:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-09 02:32:11 --> Email starts for admin@colin.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-06-09 02:32:11 --> User session created for 1
INFO - 2018-06-09 02:32:11 --> Login status admin@colin.com - success
INFO - 2018-06-09 02:32:11 --> Final output sent to browser
DEBUG - 2018-06-09 02:32:11 --> Total execution time: 0.3592
INFO - 2018-06-09 02:32:11 --> Config Class Initialized
INFO - 2018-06-09 02:32:11 --> Hooks Class Initialized
DEBUG - 2018-06-09 02:32:11 --> UTF-8 Support Enabled
INFO - 2018-06-09 02:32:11 --> Utf8 Class Initialized
INFO - 2018-06-09 02:32:11 --> URI Class Initialized
INFO - 2018-06-09 02:32:11 --> Router Class Initialized
INFO - 2018-06-09 02:32:11 --> Output Class Initialized
INFO - 2018-06-09 02:32:11 --> Security Class Initialized
DEBUG - 2018-06-09 02:32:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-09 02:32:11 --> Input Class Initialized
INFO - 2018-06-09 02:32:11 --> Language Class Initialized
INFO - 2018-06-09 02:32:11 --> Language Class Initialized
INFO - 2018-06-09 02:32:11 --> Config Class Initialized
INFO - 2018-06-09 02:32:11 --> Loader Class Initialized
DEBUG - 2018-06-09 02:32:11 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-09 02:32:11 --> Helper loaded: url_helper
INFO - 2018-06-09 02:32:11 --> Helper loaded: form_helper
INFO - 2018-06-09 02:32:11 --> Helper loaded: date_helper
INFO - 2018-06-09 02:32:11 --> Helper loaded: util_helper
INFO - 2018-06-09 02:32:11 --> Helper loaded: text_helper
INFO - 2018-06-09 02:32:11 --> Helper loaded: string_helper
INFO - 2018-06-09 02:32:11 --> Database Driver Class Initialized
DEBUG - 2018-06-09 02:32:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-09 02:32:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-09 02:32:11 --> Email Class Initialized
INFO - 2018-06-09 02:32:11 --> Controller Class Initialized
DEBUG - 2018-06-09 02:32:11 --> Chapters MX_Controller Initialized
INFO - 2018-06-09 02:32:11 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-09 02:32:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Chapters_model.php
DEBUG - 2018-06-09 02:32:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-09 02:32:11 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-09 02:32:11 --> Login MX_Controller Initialized
DEBUG - 2018-06-09 02:32:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-09 02:32:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-09 02:32:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-09 02:32:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-09 02:32:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-09 02:32:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-09 02:32:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/chapters/chapters.php
INFO - 2018-06-09 02:32:11 --> Final output sent to browser
DEBUG - 2018-06-09 02:32:11 --> Total execution time: 0.4031
INFO - 2018-06-09 02:32:11 --> Config Class Initialized
INFO - 2018-06-09 02:32:11 --> Hooks Class Initialized
DEBUG - 2018-06-09 02:32:11 --> UTF-8 Support Enabled
INFO - 2018-06-09 02:32:12 --> Utf8 Class Initialized
INFO - 2018-06-09 02:32:12 --> URI Class Initialized
INFO - 2018-06-09 02:32:12 --> Router Class Initialized
INFO - 2018-06-09 02:32:12 --> Output Class Initialized
INFO - 2018-06-09 02:32:12 --> Security Class Initialized
DEBUG - 2018-06-09 02:32:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-09 02:32:12 --> Input Class Initialized
INFO - 2018-06-09 02:32:12 --> Language Class Initialized
INFO - 2018-06-09 02:32:12 --> Language Class Initialized
INFO - 2018-06-09 02:32:12 --> Config Class Initialized
INFO - 2018-06-09 02:32:12 --> Loader Class Initialized
DEBUG - 2018-06-09 02:32:12 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-09 02:32:12 --> Helper loaded: url_helper
INFO - 2018-06-09 02:32:12 --> Helper loaded: form_helper
INFO - 2018-06-09 02:32:12 --> Helper loaded: date_helper
INFO - 2018-06-09 02:32:12 --> Helper loaded: util_helper
INFO - 2018-06-09 02:32:12 --> Helper loaded: text_helper
INFO - 2018-06-09 02:32:12 --> Helper loaded: string_helper
INFO - 2018-06-09 02:32:12 --> Database Driver Class Initialized
DEBUG - 2018-06-09 02:32:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-09 02:32:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-09 02:32:12 --> Email Class Initialized
INFO - 2018-06-09 02:32:12 --> Controller Class Initialized
DEBUG - 2018-06-09 02:32:12 --> Chapters MX_Controller Initialized
INFO - 2018-06-09 02:32:12 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-09 02:32:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Chapters_model.php
DEBUG - 2018-06-09 02:32:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-09 02:32:12 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-09 02:32:12 --> Login MX_Controller Initialized
DEBUG - 2018-06-09 02:32:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-09 02:32:12 --> Final output sent to browser
DEBUG - 2018-06-09 02:32:12 --> Total execution time: 0.7904
INFO - 2018-06-09 02:32:17 --> Config Class Initialized
INFO - 2018-06-09 02:32:17 --> Hooks Class Initialized
DEBUG - 2018-06-09 02:32:17 --> UTF-8 Support Enabled
INFO - 2018-06-09 02:32:17 --> Utf8 Class Initialized
INFO - 2018-06-09 02:32:17 --> Config Class Initialized
INFO - 2018-06-09 02:32:17 --> URI Class Initialized
INFO - 2018-06-09 02:32:17 --> Hooks Class Initialized
INFO - 2018-06-09 02:32:17 --> Router Class Initialized
DEBUG - 2018-06-09 02:32:17 --> UTF-8 Support Enabled
INFO - 2018-06-09 02:32:17 --> Output Class Initialized
INFO - 2018-06-09 02:32:17 --> Security Class Initialized
DEBUG - 2018-06-09 02:32:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-09 02:32:17 --> Input Class Initialized
INFO - 2018-06-09 02:32:17 --> Language Class Initialized
INFO - 2018-06-09 02:32:17 --> Utf8 Class Initialized
INFO - 2018-06-09 02:32:17 --> URI Class Initialized
INFO - 2018-06-09 02:32:17 --> Language Class Initialized
INFO - 2018-06-09 02:32:17 --> Router Class Initialized
INFO - 2018-06-09 02:32:17 --> Config Class Initialized
INFO - 2018-06-09 02:32:17 --> Loader Class Initialized
DEBUG - 2018-06-09 02:32:17 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-09 02:32:17 --> Helper loaded: url_helper
INFO - 2018-06-09 02:32:17 --> Helper loaded: form_helper
INFO - 2018-06-09 02:32:17 --> Helper loaded: date_helper
INFO - 2018-06-09 02:32:17 --> Helper loaded: util_helper
INFO - 2018-06-09 02:32:17 --> Helper loaded: text_helper
INFO - 2018-06-09 02:32:17 --> Helper loaded: string_helper
INFO - 2018-06-09 02:32:17 --> Output Class Initialized
INFO - 2018-06-09 02:32:17 --> Database Driver Class Initialized
INFO - 2018-06-09 02:32:17 --> Security Class Initialized
DEBUG - 2018-06-09 02:32:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-09 02:32:17 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-06-09 02:32:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-09 02:32:17 --> Input Class Initialized
INFO - 2018-06-09 02:32:17 --> Email Class Initialized
INFO - 2018-06-09 02:32:17 --> Controller Class Initialized
INFO - 2018-06-09 02:32:17 --> Language Class Initialized
DEBUG - 2018-06-09 02:32:17 --> Programs MX_Controller Initialized
INFO - 2018-06-09 02:32:17 --> Language Class Initialized
INFO - 2018-06-09 02:32:17 --> Config Class Initialized
INFO - 2018-06-09 02:32:17 --> Language file loaded: language/english/data_lang.php
INFO - 2018-06-09 02:32:17 --> Loader Class Initialized
DEBUG - 2018-06-09 02:32:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-06-09 02:32:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-09 02:32:17 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-09 02:32:17 --> Helper loaded: url_helper
DEBUG - 2018-06-09 02:32:17 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-09 02:32:17 --> Login MX_Controller Initialized
INFO - 2018-06-09 02:32:17 --> Helper loaded: form_helper
DEBUG - 2018-06-09 02:32:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-09 02:32:17 --> Helper loaded: date_helper
INFO - 2018-06-09 02:32:17 --> Helper loaded: util_helper
INFO - 2018-06-09 02:32:17 --> Helper loaded: text_helper
INFO - 2018-06-09 02:32:17 --> Helper loaded: string_helper
INFO - 2018-06-09 02:32:17 --> Database Driver Class Initialized
DEBUG - 2018-06-09 02:32:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-09 02:32:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-09 02:32:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-06-09 02:32:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-09 02:32:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-09 02:32:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-09 02:32:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/programs.php
INFO - 2018-06-09 02:32:17 --> Final output sent to browser
DEBUG - 2018-06-09 02:32:17 --> Total execution time: 0.4713
INFO - 2018-06-09 02:32:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-09 02:32:17 --> Email Class Initialized
INFO - 2018-06-09 02:32:17 --> Controller Class Initialized
DEBUG - 2018-06-09 02:32:17 --> Programs MX_Controller Initialized
INFO - 2018-06-09 02:32:17 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-09 02:32:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-06-09 02:32:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-09 02:32:17 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-09 02:32:17 --> Login MX_Controller Initialized
DEBUG - 2018-06-09 02:32:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-09 02:32:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-09 02:32:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-09 02:32:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-09 02:32:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-09 02:32:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-09 02:32:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/programs.php
INFO - 2018-06-09 02:32:17 --> Final output sent to browser
DEBUG - 2018-06-09 02:32:17 --> Total execution time: 0.5805
INFO - 2018-06-09 02:32:18 --> Config Class Initialized
INFO - 2018-06-09 02:32:18 --> Hooks Class Initialized
DEBUG - 2018-06-09 02:32:18 --> UTF-8 Support Enabled
INFO - 2018-06-09 02:32:18 --> Utf8 Class Initialized
INFO - 2018-06-09 02:32:18 --> URI Class Initialized
INFO - 2018-06-09 02:32:18 --> Router Class Initialized
INFO - 2018-06-09 02:32:18 --> Output Class Initialized
INFO - 2018-06-09 02:32:18 --> Security Class Initialized
DEBUG - 2018-06-09 02:32:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-09 02:32:18 --> Input Class Initialized
INFO - 2018-06-09 02:32:18 --> Language Class Initialized
INFO - 2018-06-09 02:32:18 --> Language Class Initialized
INFO - 2018-06-09 02:32:18 --> Config Class Initialized
INFO - 2018-06-09 02:32:18 --> Loader Class Initialized
DEBUG - 2018-06-09 02:32:18 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-09 02:32:18 --> Helper loaded: url_helper
INFO - 2018-06-09 02:32:18 --> Helper loaded: form_helper
INFO - 2018-06-09 02:32:18 --> Helper loaded: date_helper
INFO - 2018-06-09 02:32:18 --> Helper loaded: util_helper
INFO - 2018-06-09 02:32:18 --> Helper loaded: text_helper
INFO - 2018-06-09 02:32:18 --> Helper loaded: string_helper
INFO - 2018-06-09 02:32:18 --> Database Driver Class Initialized
DEBUG - 2018-06-09 02:32:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-09 02:32:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-09 02:32:18 --> Email Class Initialized
INFO - 2018-06-09 02:32:18 --> Controller Class Initialized
DEBUG - 2018-06-09 02:32:18 --> Programs MX_Controller Initialized
INFO - 2018-06-09 02:32:18 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-09 02:32:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-06-09 02:32:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-09 02:32:18 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-09 02:32:18 --> Login MX_Controller Initialized
DEBUG - 2018-06-09 02:32:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-09 02:32:18 --> Final output sent to browser
DEBUG - 2018-06-09 02:32:18 --> Total execution time: 0.5005
INFO - 2018-06-09 03:08:00 --> Config Class Initialized
INFO - 2018-06-09 03:08:00 --> Hooks Class Initialized
DEBUG - 2018-06-09 03:08:00 --> UTF-8 Support Enabled
INFO - 2018-06-09 03:08:00 --> Utf8 Class Initialized
INFO - 2018-06-09 03:08:00 --> URI Class Initialized
INFO - 2018-06-09 03:08:00 --> Router Class Initialized
INFO - 2018-06-09 03:08:00 --> Output Class Initialized
INFO - 2018-06-09 03:08:00 --> Security Class Initialized
DEBUG - 2018-06-09 03:08:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-09 03:08:00 --> Input Class Initialized
INFO - 2018-06-09 03:08:00 --> Language Class Initialized
INFO - 2018-06-09 03:08:00 --> Language Class Initialized
INFO - 2018-06-09 03:08:00 --> Config Class Initialized
INFO - 2018-06-09 03:08:00 --> Loader Class Initialized
DEBUG - 2018-06-09 03:08:00 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-09 03:08:00 --> Helper loaded: url_helper
INFO - 2018-06-09 03:08:00 --> Helper loaded: form_helper
INFO - 2018-06-09 03:08:00 --> Helper loaded: date_helper
INFO - 2018-06-09 03:08:00 --> Helper loaded: util_helper
INFO - 2018-06-09 03:08:00 --> Helper loaded: text_helper
INFO - 2018-06-09 03:08:00 --> Helper loaded: string_helper
INFO - 2018-06-09 03:08:00 --> Database Driver Class Initialized
DEBUG - 2018-06-09 03:08:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-09 03:08:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-09 03:08:00 --> Email Class Initialized
INFO - 2018-06-09 03:08:00 --> Controller Class Initialized
DEBUG - 2018-06-09 03:08:00 --> Admin MX_Controller Initialized
INFO - 2018-06-09 03:08:00 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-09 03:08:00 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-09 03:08:00 --> Login MX_Controller Initialized
DEBUG - 2018-06-09 03:08:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-09 03:08:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-09 03:08:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-09 03:08:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-09 03:08:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-09 03:08:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-09 03:08:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-09 03:08:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/dashboard.php
INFO - 2018-06-09 03:08:00 --> Final output sent to browser
DEBUG - 2018-06-09 03:08:00 --> Total execution time: 0.4273
INFO - 2018-06-09 03:08:00 --> Config Class Initialized
INFO - 2018-06-09 03:08:00 --> Hooks Class Initialized
DEBUG - 2018-06-09 03:08:00 --> UTF-8 Support Enabled
INFO - 2018-06-09 03:08:00 --> Utf8 Class Initialized
INFO - 2018-06-09 03:08:00 --> URI Class Initialized
INFO - 2018-06-09 03:08:00 --> Router Class Initialized
INFO - 2018-06-09 03:08:00 --> Output Class Initialized
INFO - 2018-06-09 03:08:00 --> Config Class Initialized
INFO - 2018-06-09 03:08:00 --> Security Class Initialized
INFO - 2018-06-09 03:08:00 --> Hooks Class Initialized
DEBUG - 2018-06-09 03:08:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-06-09 03:08:00 --> UTF-8 Support Enabled
INFO - 2018-06-09 03:08:00 --> Utf8 Class Initialized
INFO - 2018-06-09 03:08:00 --> Input Class Initialized
INFO - 2018-06-09 03:08:01 --> URI Class Initialized
INFO - 2018-06-09 03:08:01 --> Language Class Initialized
ERROR - 2018-06-09 03:08:01 --> 404 Page Not Found: /index
INFO - 2018-06-09 03:08:01 --> Router Class Initialized
INFO - 2018-06-09 03:08:01 --> Output Class Initialized
INFO - 2018-06-09 03:08:01 --> Security Class Initialized
DEBUG - 2018-06-09 03:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-09 03:08:01 --> Input Class Initialized
INFO - 2018-06-09 03:08:01 --> Language Class Initialized
ERROR - 2018-06-09 03:08:01 --> 404 Page Not Found: /index
INFO - 2018-06-09 03:08:05 --> Config Class Initialized
INFO - 2018-06-09 03:08:05 --> Hooks Class Initialized
DEBUG - 2018-06-09 03:08:05 --> UTF-8 Support Enabled
INFO - 2018-06-09 03:08:05 --> Utf8 Class Initialized
INFO - 2018-06-09 03:08:05 --> URI Class Initialized
INFO - 2018-06-09 03:08:05 --> Router Class Initialized
INFO - 2018-06-09 03:08:05 --> Output Class Initialized
INFO - 2018-06-09 03:08:05 --> Security Class Initialized
DEBUG - 2018-06-09 03:08:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-09 03:08:05 --> Input Class Initialized
INFO - 2018-06-09 03:08:05 --> Language Class Initialized
INFO - 2018-06-09 03:08:05 --> Language Class Initialized
INFO - 2018-06-09 03:08:05 --> Config Class Initialized
INFO - 2018-06-09 03:08:05 --> Loader Class Initialized
DEBUG - 2018-06-09 03:08:05 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-09 03:08:05 --> Helper loaded: url_helper
INFO - 2018-06-09 03:08:05 --> Helper loaded: form_helper
INFO - 2018-06-09 03:08:05 --> Helper loaded: date_helper
INFO - 2018-06-09 03:08:05 --> Helper loaded: util_helper
INFO - 2018-06-09 03:08:05 --> Helper loaded: text_helper
INFO - 2018-06-09 03:08:05 --> Helper loaded: string_helper
INFO - 2018-06-09 03:08:05 --> Database Driver Class Initialized
DEBUG - 2018-06-09 03:08:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-09 03:08:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-09 03:08:05 --> Email Class Initialized
INFO - 2018-06-09 03:08:05 --> Controller Class Initialized
DEBUG - 2018-06-09 03:08:05 --> videos MX_Controller Initialized
INFO - 2018-06-09 03:08:05 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-09 03:08:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-06-09 03:08:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-09 03:08:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-09 03:08:05 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-09 03:08:05 --> Login MX_Controller Initialized
DEBUG - 2018-06-09 03:08:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-09 03:08:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-09 03:08:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-09 03:08:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-09 03:08:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-09 03:08:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-09 03:08:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/videos/videos.php
INFO - 2018-06-09 03:08:05 --> Final output sent to browser
DEBUG - 2018-06-09 03:08:05 --> Total execution time: 0.6134
INFO - 2018-06-09 03:08:05 --> Config Class Initialized
INFO - 2018-06-09 03:08:05 --> Hooks Class Initialized
DEBUG - 2018-06-09 03:08:05 --> UTF-8 Support Enabled
INFO - 2018-06-09 03:08:05 --> Utf8 Class Initialized
INFO - 2018-06-09 03:08:05 --> URI Class Initialized
INFO - 2018-06-09 03:08:05 --> Router Class Initialized
INFO - 2018-06-09 03:08:05 --> Output Class Initialized
INFO - 2018-06-09 03:08:05 --> Security Class Initialized
DEBUG - 2018-06-09 03:08:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-09 03:08:06 --> Input Class Initialized
INFO - 2018-06-09 03:08:06 --> Language Class Initialized
INFO - 2018-06-09 03:08:06 --> Language Class Initialized
INFO - 2018-06-09 03:08:06 --> Config Class Initialized
INFO - 2018-06-09 03:08:06 --> Loader Class Initialized
DEBUG - 2018-06-09 03:08:06 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-09 03:08:06 --> Helper loaded: url_helper
INFO - 2018-06-09 03:08:06 --> Helper loaded: form_helper
INFO - 2018-06-09 03:08:06 --> Helper loaded: date_helper
INFO - 2018-06-09 03:08:06 --> Helper loaded: util_helper
INFO - 2018-06-09 03:08:06 --> Helper loaded: text_helper
INFO - 2018-06-09 03:08:06 --> Helper loaded: string_helper
INFO - 2018-06-09 03:08:06 --> Database Driver Class Initialized
DEBUG - 2018-06-09 03:08:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-09 03:08:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-09 03:08:06 --> Email Class Initialized
INFO - 2018-06-09 03:08:06 --> Controller Class Initialized
DEBUG - 2018-06-09 03:08:06 --> videos MX_Controller Initialized
INFO - 2018-06-09 03:08:06 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-09 03:08:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-06-09 03:08:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-09 03:08:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-09 03:08:06 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-09 03:08:06 --> Login MX_Controller Initialized
DEBUG - 2018-06-09 03:08:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-09 03:08:06 --> Final output sent to browser
DEBUG - 2018-06-09 03:08:06 --> Total execution time: 0.5516
INFO - 2018-06-09 03:08:07 --> Config Class Initialized
INFO - 2018-06-09 03:08:07 --> Hooks Class Initialized
DEBUG - 2018-06-09 03:08:07 --> UTF-8 Support Enabled
INFO - 2018-06-09 03:08:07 --> Utf8 Class Initialized
INFO - 2018-06-09 03:08:07 --> URI Class Initialized
INFO - 2018-06-09 03:08:07 --> Router Class Initialized
INFO - 2018-06-09 03:08:07 --> Output Class Initialized
INFO - 2018-06-09 03:08:07 --> Security Class Initialized
DEBUG - 2018-06-09 03:08:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-09 03:08:07 --> Input Class Initialized
INFO - 2018-06-09 03:08:07 --> Language Class Initialized
INFO - 2018-06-09 03:08:07 --> Language Class Initialized
INFO - 2018-06-09 03:08:07 --> Config Class Initialized
INFO - 2018-06-09 03:08:07 --> Loader Class Initialized
DEBUG - 2018-06-09 03:08:07 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-09 03:08:07 --> Helper loaded: url_helper
INFO - 2018-06-09 03:08:07 --> Helper loaded: form_helper
INFO - 2018-06-09 03:08:07 --> Helper loaded: date_helper
INFO - 2018-06-09 03:08:07 --> Helper loaded: util_helper
INFO - 2018-06-09 03:08:07 --> Helper loaded: text_helper
INFO - 2018-06-09 03:08:07 --> Helper loaded: string_helper
INFO - 2018-06-09 03:08:07 --> Database Driver Class Initialized
DEBUG - 2018-06-09 03:08:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-09 03:08:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-09 03:08:07 --> Email Class Initialized
INFO - 2018-06-09 03:08:07 --> Controller Class Initialized
DEBUG - 2018-06-09 03:08:07 --> videos MX_Controller Initialized
INFO - 2018-06-09 03:08:07 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-09 03:08:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-06-09 03:08:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-09 03:08:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-09 03:08:07 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-09 03:08:07 --> Login MX_Controller Initialized
DEBUG - 2018-06-09 03:08:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-09 03:08:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-09 03:08:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-09 03:08:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-09 03:08:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-09 03:08:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-09 03:08:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/videos/create_video.php
INFO - 2018-06-09 03:08:07 --> Final output sent to browser
DEBUG - 2018-06-09 03:08:07 --> Total execution time: 0.4924
INFO - 2018-06-09 03:11:03 --> Config Class Initialized
INFO - 2018-06-09 03:11:03 --> Hooks Class Initialized
DEBUG - 2018-06-09 03:11:04 --> UTF-8 Support Enabled
INFO - 2018-06-09 03:11:04 --> Utf8 Class Initialized
INFO - 2018-06-09 03:11:04 --> URI Class Initialized
INFO - 2018-06-09 03:11:04 --> Router Class Initialized
INFO - 2018-06-09 03:11:04 --> Output Class Initialized
INFO - 2018-06-09 03:11:04 --> Security Class Initialized
DEBUG - 2018-06-09 03:11:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-09 03:11:04 --> Input Class Initialized
INFO - 2018-06-09 03:11:04 --> Language Class Initialized
ERROR - 2018-06-09 03:11:04 --> 404 Page Not Found: /index
INFO - 2018-06-09 03:11:17 --> Config Class Initialized
INFO - 2018-06-09 03:11:17 --> Hooks Class Initialized
DEBUG - 2018-06-09 03:11:17 --> UTF-8 Support Enabled
INFO - 2018-06-09 03:11:17 --> Utf8 Class Initialized
INFO - 2018-06-09 03:11:17 --> URI Class Initialized
INFO - 2018-06-09 03:11:17 --> Router Class Initialized
INFO - 2018-06-09 03:11:17 --> Output Class Initialized
INFO - 2018-06-09 03:11:17 --> Security Class Initialized
DEBUG - 2018-06-09 03:11:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-09 03:11:17 --> Input Class Initialized
INFO - 2018-06-09 03:11:17 --> Language Class Initialized
INFO - 2018-06-09 03:11:17 --> Language Class Initialized
INFO - 2018-06-09 03:11:17 --> Config Class Initialized
INFO - 2018-06-09 03:11:17 --> Loader Class Initialized
DEBUG - 2018-06-09 03:11:17 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-09 03:11:17 --> Helper loaded: url_helper
INFO - 2018-06-09 03:11:17 --> Helper loaded: form_helper
INFO - 2018-06-09 03:11:17 --> Helper loaded: date_helper
INFO - 2018-06-09 03:11:17 --> Helper loaded: util_helper
INFO - 2018-06-09 03:11:17 --> Helper loaded: text_helper
INFO - 2018-06-09 03:11:17 --> Helper loaded: string_helper
INFO - 2018-06-09 03:11:17 --> Database Driver Class Initialized
DEBUG - 2018-06-09 03:11:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-09 03:11:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-09 03:11:17 --> Email Class Initialized
INFO - 2018-06-09 03:11:17 --> Controller Class Initialized
DEBUG - 2018-06-09 03:11:17 --> videos MX_Controller Initialized
INFO - 2018-06-09 03:11:17 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-09 03:11:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-06-09 03:11:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-09 03:11:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-09 03:11:17 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-09 03:11:17 --> Login MX_Controller Initialized
DEBUG - 2018-06-09 03:11:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-09 03:11:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-09 03:11:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-09 03:11:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-09 03:11:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-09 03:11:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-09 03:11:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/videos/create_video.php
INFO - 2018-06-09 03:11:17 --> Final output sent to browser
DEBUG - 2018-06-09 03:11:17 --> Total execution time: 0.4315
INFO - 2018-06-09 03:14:44 --> Config Class Initialized
INFO - 2018-06-09 03:14:44 --> Hooks Class Initialized
DEBUG - 2018-06-09 03:14:44 --> UTF-8 Support Enabled
INFO - 2018-06-09 03:14:44 --> Utf8 Class Initialized
INFO - 2018-06-09 03:14:44 --> URI Class Initialized
INFO - 2018-06-09 03:14:44 --> Router Class Initialized
INFO - 2018-06-09 03:14:44 --> Output Class Initialized
INFO - 2018-06-09 03:14:44 --> Security Class Initialized
DEBUG - 2018-06-09 03:14:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-09 03:14:44 --> Input Class Initialized
INFO - 2018-06-09 03:14:44 --> Language Class Initialized
INFO - 2018-06-09 03:14:44 --> Language Class Initialized
INFO - 2018-06-09 03:14:44 --> Config Class Initialized
INFO - 2018-06-09 03:14:44 --> Loader Class Initialized
DEBUG - 2018-06-09 03:14:44 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-09 03:14:44 --> Helper loaded: url_helper
INFO - 2018-06-09 03:14:44 --> Helper loaded: form_helper
INFO - 2018-06-09 03:14:44 --> Helper loaded: date_helper
INFO - 2018-06-09 03:14:44 --> Helper loaded: util_helper
INFO - 2018-06-09 03:14:44 --> Helper loaded: text_helper
INFO - 2018-06-09 03:14:44 --> Helper loaded: string_helper
INFO - 2018-06-09 03:14:44 --> Database Driver Class Initialized
DEBUG - 2018-06-09 03:14:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-09 03:14:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-09 03:14:44 --> Email Class Initialized
INFO - 2018-06-09 03:14:44 --> Controller Class Initialized
DEBUG - 2018-06-09 03:14:44 --> videos MX_Controller Initialized
INFO - 2018-06-09 03:14:44 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-09 03:14:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-06-09 03:14:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-09 03:14:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-09 03:14:44 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-09 03:14:44 --> Login MX_Controller Initialized
DEBUG - 2018-06-09 03:14:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-09 03:14:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-09 03:14:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-09 03:14:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-09 03:14:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-09 03:14:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-09 03:14:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/videos/create_video.php
INFO - 2018-06-09 03:14:44 --> Final output sent to browser
DEBUG - 2018-06-09 03:14:44 --> Total execution time: 0.4254
INFO - 2018-06-09 03:14:45 --> Config Class Initialized
INFO - 2018-06-09 03:14:45 --> Hooks Class Initialized
DEBUG - 2018-06-09 03:14:45 --> UTF-8 Support Enabled
INFO - 2018-06-09 03:14:45 --> Utf8 Class Initialized
INFO - 2018-06-09 03:14:45 --> URI Class Initialized
INFO - 2018-06-09 03:14:45 --> Router Class Initialized
INFO - 2018-06-09 03:14:45 --> Output Class Initialized
INFO - 2018-06-09 03:14:45 --> Security Class Initialized
DEBUG - 2018-06-09 03:14:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-09 03:14:45 --> Input Class Initialized
INFO - 2018-06-09 03:14:45 --> Language Class Initialized
ERROR - 2018-06-09 03:14:45 --> 404 Page Not Found: /index
