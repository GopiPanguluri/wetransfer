<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-06-15 00:31:52 --> Config Class Initialized
INFO - 2018-06-15 00:31:52 --> Hooks Class Initialized
DEBUG - 2018-06-15 00:31:52 --> UTF-8 Support Enabled
INFO - 2018-06-15 00:31:52 --> Utf8 Class Initialized
INFO - 2018-06-15 00:31:53 --> URI Class Initialized
DEBUG - 2018-06-15 00:31:53 --> No URI present. Default controller set.
INFO - 2018-06-15 00:31:53 --> Router Class Initialized
INFO - 2018-06-15 00:31:53 --> Output Class Initialized
INFO - 2018-06-15 00:31:53 --> Security Class Initialized
DEBUG - 2018-06-15 00:31:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-15 00:31:53 --> Input Class Initialized
INFO - 2018-06-15 00:31:53 --> Language Class Initialized
INFO - 2018-06-15 00:31:53 --> Language Class Initialized
INFO - 2018-06-15 00:31:53 --> Config Class Initialized
INFO - 2018-06-15 00:31:53 --> Loader Class Initialized
DEBUG - 2018-06-15 00:31:53 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-15 00:31:53 --> Helper loaded: url_helper
INFO - 2018-06-15 00:31:53 --> Helper loaded: form_helper
INFO - 2018-06-15 00:31:53 --> Helper loaded: date_helper
INFO - 2018-06-15 00:31:53 --> Helper loaded: util_helper
INFO - 2018-06-15 00:31:53 --> Helper loaded: text_helper
INFO - 2018-06-15 00:31:54 --> Helper loaded: string_helper
INFO - 2018-06-15 00:31:54 --> Database Driver Class Initialized
DEBUG - 2018-06-15 00:31:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-15 00:31:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-15 00:31:54 --> Email Class Initialized
INFO - 2018-06-15 00:31:54 --> Controller Class Initialized
DEBUG - 2018-06-15 00:31:54 --> Home MX_Controller Initialized
DEBUG - 2018-06-15 00:31:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-15 00:31:55 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-15 00:31:55 --> Login MX_Controller Initialized
INFO - 2018-06-15 00:31:55 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-15 00:31:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-15 00:31:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-15 00:31:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-06-15 00:32:08 --> Config Class Initialized
INFO - 2018-06-15 00:32:08 --> Hooks Class Initialized
DEBUG - 2018-06-15 00:32:08 --> UTF-8 Support Enabled
INFO - 2018-06-15 00:32:08 --> Utf8 Class Initialized
INFO - 2018-06-15 00:32:08 --> URI Class Initialized
INFO - 2018-06-15 00:32:08 --> Router Class Initialized
INFO - 2018-06-15 00:32:08 --> Output Class Initialized
INFO - 2018-06-15 00:32:08 --> Security Class Initialized
DEBUG - 2018-06-15 00:32:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-15 00:32:08 --> Input Class Initialized
INFO - 2018-06-15 00:32:08 --> Language Class Initialized
INFO - 2018-06-15 00:32:08 --> Language Class Initialized
INFO - 2018-06-15 00:32:08 --> Config Class Initialized
INFO - 2018-06-15 00:32:08 --> Loader Class Initialized
DEBUG - 2018-06-15 00:32:08 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-15 00:32:08 --> Helper loaded: url_helper
INFO - 2018-06-15 00:32:08 --> Helper loaded: form_helper
INFO - 2018-06-15 00:32:08 --> Helper loaded: date_helper
INFO - 2018-06-15 00:32:08 --> Helper loaded: util_helper
INFO - 2018-06-15 00:32:08 --> Helper loaded: text_helper
INFO - 2018-06-15 00:32:08 --> Helper loaded: string_helper
INFO - 2018-06-15 00:32:08 --> Database Driver Class Initialized
DEBUG - 2018-06-15 00:32:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-15 00:32:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-15 00:32:09 --> Email Class Initialized
INFO - 2018-06-15 00:32:09 --> Controller Class Initialized
DEBUG - 2018-06-15 00:32:09 --> Login MX_Controller Initialized
INFO - 2018-06-15 00:32:09 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-15 00:32:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-15 00:32:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-15 00:32:09 --> Email starts for user@colin.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-06-15 00:32:09 --> User session created for 4
INFO - 2018-06-15 00:32:09 --> Login status user@colin.com - success
INFO - 2018-06-15 00:32:09 --> Final output sent to browser
DEBUG - 2018-06-15 00:32:09 --> Total execution time: 0.6876
INFO - 2018-06-15 00:32:09 --> Config Class Initialized
INFO - 2018-06-15 00:32:09 --> Hooks Class Initialized
DEBUG - 2018-06-15 00:32:09 --> UTF-8 Support Enabled
INFO - 2018-06-15 00:32:09 --> Utf8 Class Initialized
INFO - 2018-06-15 00:32:09 --> URI Class Initialized
DEBUG - 2018-06-15 00:32:09 --> No URI present. Default controller set.
INFO - 2018-06-15 00:32:09 --> Router Class Initialized
INFO - 2018-06-15 00:32:09 --> Output Class Initialized
INFO - 2018-06-15 00:32:09 --> Security Class Initialized
DEBUG - 2018-06-15 00:32:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-15 00:32:09 --> Input Class Initialized
INFO - 2018-06-15 00:32:09 --> Language Class Initialized
INFO - 2018-06-15 00:32:09 --> Language Class Initialized
INFO - 2018-06-15 00:32:09 --> Config Class Initialized
INFO - 2018-06-15 00:32:09 --> Loader Class Initialized
DEBUG - 2018-06-15 00:32:09 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-15 00:32:09 --> Helper loaded: url_helper
INFO - 2018-06-15 00:32:09 --> Helper loaded: form_helper
INFO - 2018-06-15 00:32:09 --> Helper loaded: date_helper
INFO - 2018-06-15 00:32:09 --> Helper loaded: util_helper
INFO - 2018-06-15 00:32:09 --> Helper loaded: text_helper
INFO - 2018-06-15 00:32:09 --> Helper loaded: string_helper
INFO - 2018-06-15 00:32:09 --> Database Driver Class Initialized
DEBUG - 2018-06-15 00:32:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-15 00:32:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-15 00:32:09 --> Email Class Initialized
INFO - 2018-06-15 00:32:09 --> Controller Class Initialized
DEBUG - 2018-06-15 00:32:09 --> Home MX_Controller Initialized
DEBUG - 2018-06-15 00:32:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-15 00:32:09 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-15 00:32:09 --> Login MX_Controller Initialized
INFO - 2018-06-15 00:32:09 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-15 00:32:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-15 00:32:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-15 00:32:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-15 00:32:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-15 00:32:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-15 00:32:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-15 00:32:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-15 00:32:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-06-15 00:32:11 --> Final output sent to browser
DEBUG - 2018-06-15 00:32:11 --> Total execution time: 1.5480
INFO - 2018-06-15 00:32:12 --> Config Class Initialized
INFO - 2018-06-15 00:32:12 --> Hooks Class Initialized
DEBUG - 2018-06-15 00:32:12 --> UTF-8 Support Enabled
INFO - 2018-06-15 00:32:12 --> Utf8 Class Initialized
INFO - 2018-06-15 00:32:12 --> URI Class Initialized
INFO - 2018-06-15 00:32:12 --> Router Class Initialized
INFO - 2018-06-15 00:32:12 --> Output Class Initialized
INFO - 2018-06-15 00:32:12 --> Security Class Initialized
DEBUG - 2018-06-15 00:32:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-15 00:32:12 --> Input Class Initialized
INFO - 2018-06-15 00:32:12 --> Language Class Initialized
ERROR - 2018-06-15 00:32:12 --> 404 Page Not Found: /index
INFO - 2018-06-15 00:32:12 --> Config Class Initialized
INFO - 2018-06-15 00:32:12 --> Hooks Class Initialized
DEBUG - 2018-06-15 00:32:12 --> UTF-8 Support Enabled
INFO - 2018-06-15 00:32:12 --> Utf8 Class Initialized
INFO - 2018-06-15 00:32:12 --> URI Class Initialized
INFO - 2018-06-15 00:32:12 --> Router Class Initialized
INFO - 2018-06-15 00:32:12 --> Output Class Initialized
INFO - 2018-06-15 00:32:12 --> Security Class Initialized
DEBUG - 2018-06-15 00:32:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-15 00:32:12 --> Input Class Initialized
INFO - 2018-06-15 00:32:12 --> Language Class Initialized
ERROR - 2018-06-15 00:32:13 --> 404 Page Not Found: /index
INFO - 2018-06-15 00:32:13 --> Config Class Initialized
INFO - 2018-06-15 00:32:13 --> Hooks Class Initialized
DEBUG - 2018-06-15 00:32:13 --> UTF-8 Support Enabled
INFO - 2018-06-15 00:32:13 --> Utf8 Class Initialized
INFO - 2018-06-15 00:32:13 --> URI Class Initialized
INFO - 2018-06-15 00:32:13 --> Router Class Initialized
INFO - 2018-06-15 00:32:13 --> Output Class Initialized
INFO - 2018-06-15 00:32:13 --> Security Class Initialized
DEBUG - 2018-06-15 00:32:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-15 00:32:13 --> Input Class Initialized
INFO - 2018-06-15 00:32:13 --> Language Class Initialized
ERROR - 2018-06-15 00:32:13 --> 404 Page Not Found: /index
INFO - 2018-06-15 00:32:13 --> Config Class Initialized
INFO - 2018-06-15 00:32:13 --> Hooks Class Initialized
DEBUG - 2018-06-15 00:32:13 --> UTF-8 Support Enabled
INFO - 2018-06-15 00:32:13 --> Utf8 Class Initialized
INFO - 2018-06-15 00:32:13 --> URI Class Initialized
INFO - 2018-06-15 00:32:13 --> Router Class Initialized
INFO - 2018-06-15 00:32:13 --> Output Class Initialized
INFO - 2018-06-15 00:32:13 --> Security Class Initialized
DEBUG - 2018-06-15 00:32:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-15 00:32:13 --> Input Class Initialized
INFO - 2018-06-15 00:32:13 --> Language Class Initialized
ERROR - 2018-06-15 00:32:13 --> 404 Page Not Found: /index
INFO - 2018-06-15 00:32:13 --> Config Class Initialized
INFO - 2018-06-15 00:32:13 --> Hooks Class Initialized
DEBUG - 2018-06-15 00:32:13 --> UTF-8 Support Enabled
INFO - 2018-06-15 00:32:13 --> Utf8 Class Initialized
INFO - 2018-06-15 00:32:13 --> URI Class Initialized
INFO - 2018-06-15 00:32:13 --> Router Class Initialized
INFO - 2018-06-15 00:32:13 --> Output Class Initialized
INFO - 2018-06-15 00:32:13 --> Security Class Initialized
DEBUG - 2018-06-15 00:32:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-15 00:32:13 --> Input Class Initialized
INFO - 2018-06-15 00:32:13 --> Language Class Initialized
ERROR - 2018-06-15 00:32:13 --> 404 Page Not Found: /index
INFO - 2018-06-15 00:32:13 --> Config Class Initialized
INFO - 2018-06-15 00:32:13 --> Hooks Class Initialized
DEBUG - 2018-06-15 00:32:13 --> UTF-8 Support Enabled
INFO - 2018-06-15 00:32:13 --> Utf8 Class Initialized
INFO - 2018-06-15 00:32:13 --> URI Class Initialized
INFO - 2018-06-15 00:32:13 --> Router Class Initialized
INFO - 2018-06-15 00:32:13 --> Output Class Initialized
INFO - 2018-06-15 00:32:13 --> Security Class Initialized
DEBUG - 2018-06-15 00:32:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-15 00:32:13 --> Input Class Initialized
INFO - 2018-06-15 00:32:13 --> Language Class Initialized
ERROR - 2018-06-15 00:32:13 --> 404 Page Not Found: /index
INFO - 2018-06-15 00:45:46 --> Config Class Initialized
INFO - 2018-06-15 00:45:46 --> Hooks Class Initialized
DEBUG - 2018-06-15 00:45:46 --> UTF-8 Support Enabled
INFO - 2018-06-15 00:45:46 --> Utf8 Class Initialized
INFO - 2018-06-15 00:45:46 --> URI Class Initialized
INFO - 2018-06-15 00:45:46 --> Router Class Initialized
INFO - 2018-06-15 00:45:46 --> Output Class Initialized
INFO - 2018-06-15 00:45:46 --> Security Class Initialized
DEBUG - 2018-06-15 00:45:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-15 00:45:46 --> Input Class Initialized
INFO - 2018-06-15 00:45:46 --> Language Class Initialized
INFO - 2018-06-15 00:45:46 --> Language Class Initialized
INFO - 2018-06-15 00:45:47 --> Config Class Initialized
INFO - 2018-06-15 00:45:47 --> Loader Class Initialized
DEBUG - 2018-06-15 00:45:47 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-15 00:45:47 --> Helper loaded: url_helper
INFO - 2018-06-15 00:45:47 --> Helper loaded: form_helper
INFO - 2018-06-15 00:45:47 --> Helper loaded: date_helper
INFO - 2018-06-15 00:45:47 --> Helper loaded: util_helper
INFO - 2018-06-15 00:45:47 --> Helper loaded: text_helper
INFO - 2018-06-15 00:45:47 --> Helper loaded: string_helper
INFO - 2018-06-15 00:45:47 --> Database Driver Class Initialized
DEBUG - 2018-06-15 00:45:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-15 00:45:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-15 00:45:47 --> Email Class Initialized
INFO - 2018-06-15 00:45:47 --> Controller Class Initialized
DEBUG - 2018-06-15 00:45:47 --> Home MX_Controller Initialized
DEBUG - 2018-06-15 00:45:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-15 00:45:47 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-15 00:45:47 --> Login MX_Controller Initialized
INFO - 2018-06-15 00:45:47 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-15 00:45:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-15 00:45:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-15 00:45:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-15 00:45:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-15 00:45:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-15 00:45:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-15 00:45:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-15 00:45:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-06-15 00:45:47 --> Final output sent to browser
DEBUG - 2018-06-15 00:45:47 --> Total execution time: 0.4508
INFO - 2018-06-15 00:45:47 --> Config Class Initialized
INFO - 2018-06-15 00:45:47 --> Config Class Initialized
INFO - 2018-06-15 00:45:47 --> Hooks Class Initialized
INFO - 2018-06-15 00:45:47 --> Hooks Class Initialized
DEBUG - 2018-06-15 00:45:47 --> UTF-8 Support Enabled
DEBUG - 2018-06-15 00:45:47 --> UTF-8 Support Enabled
INFO - 2018-06-15 00:45:47 --> Utf8 Class Initialized
INFO - 2018-06-15 00:45:47 --> Utf8 Class Initialized
INFO - 2018-06-15 00:45:47 --> URI Class Initialized
INFO - 2018-06-15 00:45:47 --> URI Class Initialized
INFO - 2018-06-15 00:45:48 --> Router Class Initialized
INFO - 2018-06-15 00:45:48 --> Router Class Initialized
INFO - 2018-06-15 00:45:48 --> Output Class Initialized
INFO - 2018-06-15 00:45:48 --> Output Class Initialized
INFO - 2018-06-15 00:45:48 --> Security Class Initialized
INFO - 2018-06-15 00:45:48 --> Security Class Initialized
DEBUG - 2018-06-15 00:45:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-06-15 00:45:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-15 00:45:48 --> Input Class Initialized
INFO - 2018-06-15 00:45:48 --> Input Class Initialized
INFO - 2018-06-15 00:45:48 --> Language Class Initialized
INFO - 2018-06-15 00:45:48 --> Language Class Initialized
ERROR - 2018-06-15 00:45:48 --> 404 Page Not Found: /index
ERROR - 2018-06-15 00:45:48 --> 404 Page Not Found: /index
INFO - 2018-06-15 00:45:48 --> Config Class Initialized
INFO - 2018-06-15 00:45:48 --> Hooks Class Initialized
DEBUG - 2018-06-15 00:45:48 --> UTF-8 Support Enabled
INFO - 2018-06-15 00:45:48 --> Utf8 Class Initialized
INFO - 2018-06-15 00:45:48 --> URI Class Initialized
INFO - 2018-06-15 00:45:48 --> Router Class Initialized
INFO - 2018-06-15 00:45:48 --> Output Class Initialized
INFO - 2018-06-15 00:45:48 --> Security Class Initialized
DEBUG - 2018-06-15 00:45:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-15 00:45:48 --> Input Class Initialized
INFO - 2018-06-15 00:45:48 --> Language Class Initialized
ERROR - 2018-06-15 00:45:48 --> 404 Page Not Found: /index
INFO - 2018-06-15 00:45:48 --> Config Class Initialized
INFO - 2018-06-15 00:45:48 --> Hooks Class Initialized
DEBUG - 2018-06-15 00:45:48 --> UTF-8 Support Enabled
INFO - 2018-06-15 00:45:48 --> Utf8 Class Initialized
INFO - 2018-06-15 00:45:48 --> URI Class Initialized
INFO - 2018-06-15 00:45:48 --> Router Class Initialized
INFO - 2018-06-15 00:45:48 --> Output Class Initialized
INFO - 2018-06-15 00:45:48 --> Security Class Initialized
DEBUG - 2018-06-15 00:45:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-15 00:45:48 --> Input Class Initialized
INFO - 2018-06-15 00:45:48 --> Language Class Initialized
ERROR - 2018-06-15 00:45:48 --> 404 Page Not Found: /index
INFO - 2018-06-15 00:51:53 --> Config Class Initialized
INFO - 2018-06-15 00:51:53 --> Hooks Class Initialized
DEBUG - 2018-06-15 00:51:53 --> UTF-8 Support Enabled
INFO - 2018-06-15 00:51:53 --> Utf8 Class Initialized
INFO - 2018-06-15 00:51:53 --> URI Class Initialized
INFO - 2018-06-15 00:51:53 --> Router Class Initialized
INFO - 2018-06-15 00:51:53 --> Output Class Initialized
INFO - 2018-06-15 00:51:53 --> Security Class Initialized
DEBUG - 2018-06-15 00:51:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-15 00:51:53 --> Input Class Initialized
INFO - 2018-06-15 00:51:53 --> Language Class Initialized
INFO - 2018-06-15 00:51:53 --> Language Class Initialized
INFO - 2018-06-15 00:51:53 --> Config Class Initialized
INFO - 2018-06-15 00:51:53 --> Loader Class Initialized
DEBUG - 2018-06-15 00:51:53 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-15 00:51:53 --> Helper loaded: url_helper
INFO - 2018-06-15 00:51:53 --> Helper loaded: form_helper
INFO - 2018-06-15 00:51:53 --> Helper loaded: date_helper
INFO - 2018-06-15 00:51:53 --> Helper loaded: util_helper
INFO - 2018-06-15 00:51:53 --> Helper loaded: text_helper
INFO - 2018-06-15 00:51:53 --> Helper loaded: string_helper
INFO - 2018-06-15 00:51:53 --> Database Driver Class Initialized
DEBUG - 2018-06-15 00:51:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-15 00:51:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-15 00:51:53 --> Email Class Initialized
INFO - 2018-06-15 00:51:53 --> Controller Class Initialized
DEBUG - 2018-06-15 00:51:53 --> Home MX_Controller Initialized
DEBUG - 2018-06-15 00:51:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-15 00:51:53 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-15 00:51:53 --> Login MX_Controller Initialized
INFO - 2018-06-15 00:51:53 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-15 00:51:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-15 00:51:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-15 00:51:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-15 00:51:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-15 00:51:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-15 00:51:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-15 00:51:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-15 00:51:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-06-15 00:51:53 --> Final output sent to browser
DEBUG - 2018-06-15 00:51:53 --> Total execution time: 0.4024
INFO - 2018-06-15 00:51:54 --> Config Class Initialized
INFO - 2018-06-15 00:51:54 --> Hooks Class Initialized
INFO - 2018-06-15 00:51:54 --> Config Class Initialized
INFO - 2018-06-15 00:51:54 --> Hooks Class Initialized
DEBUG - 2018-06-15 00:51:54 --> UTF-8 Support Enabled
INFO - 2018-06-15 00:51:54 --> Utf8 Class Initialized
DEBUG - 2018-06-15 00:51:54 --> UTF-8 Support Enabled
INFO - 2018-06-15 00:51:54 --> URI Class Initialized
INFO - 2018-06-15 00:51:54 --> Utf8 Class Initialized
INFO - 2018-06-15 00:51:54 --> Router Class Initialized
INFO - 2018-06-15 00:51:54 --> URI Class Initialized
INFO - 2018-06-15 00:51:54 --> Output Class Initialized
INFO - 2018-06-15 00:51:54 --> Security Class Initialized
INFO - 2018-06-15 00:51:54 --> Router Class Initialized
DEBUG - 2018-06-15 00:51:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-15 00:51:54 --> Input Class Initialized
INFO - 2018-06-15 00:51:54 --> Language Class Initialized
ERROR - 2018-06-15 00:51:54 --> 404 Page Not Found: /index
INFO - 2018-06-15 00:51:54 --> Output Class Initialized
INFO - 2018-06-15 00:51:54 --> Security Class Initialized
DEBUG - 2018-06-15 00:51:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-15 00:51:54 --> Input Class Initialized
INFO - 2018-06-15 00:51:54 --> Language Class Initialized
ERROR - 2018-06-15 00:51:54 --> 404 Page Not Found: /index
INFO - 2018-06-15 00:51:54 --> Config Class Initialized
INFO - 2018-06-15 00:51:54 --> Hooks Class Initialized
DEBUG - 2018-06-15 00:51:54 --> UTF-8 Support Enabled
INFO - 2018-06-15 00:51:54 --> Utf8 Class Initialized
INFO - 2018-06-15 00:51:54 --> URI Class Initialized
INFO - 2018-06-15 00:51:54 --> Router Class Initialized
INFO - 2018-06-15 00:51:54 --> Output Class Initialized
INFO - 2018-06-15 00:51:54 --> Security Class Initialized
DEBUG - 2018-06-15 00:51:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-15 00:51:54 --> Input Class Initialized
INFO - 2018-06-15 00:51:54 --> Language Class Initialized
ERROR - 2018-06-15 00:51:54 --> 404 Page Not Found: /index
INFO - 2018-06-15 00:51:54 --> Config Class Initialized
INFO - 2018-06-15 00:51:54 --> Hooks Class Initialized
DEBUG - 2018-06-15 00:51:54 --> UTF-8 Support Enabled
INFO - 2018-06-15 00:51:54 --> Utf8 Class Initialized
INFO - 2018-06-15 00:51:54 --> URI Class Initialized
INFO - 2018-06-15 00:51:54 --> Router Class Initialized
INFO - 2018-06-15 00:51:54 --> Output Class Initialized
INFO - 2018-06-15 00:51:54 --> Security Class Initialized
DEBUG - 2018-06-15 00:51:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-15 00:51:54 --> Input Class Initialized
INFO - 2018-06-15 00:51:54 --> Language Class Initialized
ERROR - 2018-06-15 00:51:54 --> 404 Page Not Found: /index
INFO - 2018-06-15 00:51:59 --> Config Class Initialized
INFO - 2018-06-15 00:51:59 --> Hooks Class Initialized
DEBUG - 2018-06-15 00:51:59 --> UTF-8 Support Enabled
INFO - 2018-06-15 00:51:59 --> Utf8 Class Initialized
INFO - 2018-06-15 00:51:59 --> URI Class Initialized
INFO - 2018-06-15 00:51:59 --> Router Class Initialized
INFO - 2018-06-15 00:51:59 --> Output Class Initialized
INFO - 2018-06-15 00:51:59 --> Security Class Initialized
DEBUG - 2018-06-15 00:51:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-15 00:51:59 --> Input Class Initialized
INFO - 2018-06-15 00:51:59 --> Language Class Initialized
INFO - 2018-06-15 00:51:59 --> Language Class Initialized
INFO - 2018-06-15 00:51:59 --> Config Class Initialized
INFO - 2018-06-15 00:51:59 --> Loader Class Initialized
DEBUG - 2018-06-15 00:51:59 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-15 00:51:59 --> Helper loaded: url_helper
INFO - 2018-06-15 00:51:59 --> Helper loaded: form_helper
INFO - 2018-06-15 00:51:59 --> Helper loaded: date_helper
INFO - 2018-06-15 00:51:59 --> Helper loaded: util_helper
INFO - 2018-06-15 00:51:59 --> Helper loaded: text_helper
INFO - 2018-06-15 00:51:59 --> Helper loaded: string_helper
INFO - 2018-06-15 00:51:59 --> Database Driver Class Initialized
DEBUG - 2018-06-15 00:51:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-15 00:51:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-15 00:51:59 --> Email Class Initialized
INFO - 2018-06-15 00:51:59 --> Controller Class Initialized
DEBUG - 2018-06-15 00:51:59 --> Admin MX_Controller Initialized
INFO - 2018-06-15 00:51:59 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-15 00:51:59 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-15 00:51:59 --> Login MX_Controller Initialized
DEBUG - 2018-06-15 00:51:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-15 00:51:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-15 00:51:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
INFO - 2018-06-15 00:52:00 --> Config Class Initialized
INFO - 2018-06-15 00:52:00 --> Hooks Class Initialized
DEBUG - 2018-06-15 00:52:00 --> UTF-8 Support Enabled
INFO - 2018-06-15 00:52:00 --> Utf8 Class Initialized
INFO - 2018-06-15 00:52:00 --> URI Class Initialized
INFO - 2018-06-15 00:52:00 --> Router Class Initialized
INFO - 2018-06-15 00:52:00 --> Output Class Initialized
INFO - 2018-06-15 00:52:00 --> Security Class Initialized
DEBUG - 2018-06-15 00:52:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-15 00:52:00 --> Input Class Initialized
INFO - 2018-06-15 00:52:00 --> Language Class Initialized
ERROR - 2018-06-15 00:52:00 --> 404 Page Not Found: /index
INFO - 2018-06-15 00:52:04 --> Config Class Initialized
INFO - 2018-06-15 00:52:04 --> Hooks Class Initialized
DEBUG - 2018-06-15 00:52:04 --> UTF-8 Support Enabled
INFO - 2018-06-15 00:52:04 --> Utf8 Class Initialized
INFO - 2018-06-15 00:52:04 --> URI Class Initialized
INFO - 2018-06-15 00:52:04 --> Router Class Initialized
INFO - 2018-06-15 00:52:04 --> Output Class Initialized
INFO - 2018-06-15 00:52:04 --> Security Class Initialized
DEBUG - 2018-06-15 00:52:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-15 00:52:04 --> Input Class Initialized
INFO - 2018-06-15 00:52:04 --> Language Class Initialized
INFO - 2018-06-15 00:52:04 --> Language Class Initialized
INFO - 2018-06-15 00:52:04 --> Config Class Initialized
INFO - 2018-06-15 00:52:04 --> Loader Class Initialized
DEBUG - 2018-06-15 00:52:04 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-15 00:52:04 --> Helper loaded: url_helper
INFO - 2018-06-15 00:52:04 --> Helper loaded: form_helper
INFO - 2018-06-15 00:52:04 --> Helper loaded: date_helper
INFO - 2018-06-15 00:52:04 --> Helper loaded: util_helper
INFO - 2018-06-15 00:52:04 --> Helper loaded: text_helper
INFO - 2018-06-15 00:52:04 --> Helper loaded: string_helper
INFO - 2018-06-15 00:52:04 --> Database Driver Class Initialized
DEBUG - 2018-06-15 00:52:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-15 00:52:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-15 00:52:04 --> Email Class Initialized
INFO - 2018-06-15 00:52:04 --> Controller Class Initialized
DEBUG - 2018-06-15 00:52:04 --> Login MX_Controller Initialized
INFO - 2018-06-15 00:52:04 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-15 00:52:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-15 00:52:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-15 00:52:04 --> Email starts for admin@colin.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-06-15 00:52:04 --> User session created for 1
INFO - 2018-06-15 00:52:04 --> Login status admin@colin.com - success
INFO - 2018-06-15 00:52:04 --> Final output sent to browser
DEBUG - 2018-06-15 00:52:04 --> Total execution time: 0.3942
INFO - 2018-06-15 00:52:04 --> Config Class Initialized
INFO - 2018-06-15 00:52:04 --> Hooks Class Initialized
DEBUG - 2018-06-15 00:52:04 --> UTF-8 Support Enabled
INFO - 2018-06-15 00:52:04 --> Utf8 Class Initialized
INFO - 2018-06-15 00:52:04 --> URI Class Initialized
INFO - 2018-06-15 00:52:04 --> Router Class Initialized
INFO - 2018-06-15 00:52:04 --> Output Class Initialized
INFO - 2018-06-15 00:52:04 --> Security Class Initialized
DEBUG - 2018-06-15 00:52:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-15 00:52:04 --> Input Class Initialized
INFO - 2018-06-15 00:52:04 --> Language Class Initialized
INFO - 2018-06-15 00:52:04 --> Language Class Initialized
INFO - 2018-06-15 00:52:04 --> Config Class Initialized
INFO - 2018-06-15 00:52:04 --> Loader Class Initialized
DEBUG - 2018-06-15 00:52:04 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-15 00:52:04 --> Helper loaded: url_helper
INFO - 2018-06-15 00:52:04 --> Helper loaded: form_helper
INFO - 2018-06-15 00:52:04 --> Helper loaded: date_helper
INFO - 2018-06-15 00:52:05 --> Helper loaded: util_helper
INFO - 2018-06-15 00:52:05 --> Helper loaded: text_helper
INFO - 2018-06-15 00:52:05 --> Helper loaded: string_helper
INFO - 2018-06-15 00:52:05 --> Database Driver Class Initialized
DEBUG - 2018-06-15 00:52:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-15 00:52:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-15 00:52:05 --> Email Class Initialized
INFO - 2018-06-15 00:52:05 --> Controller Class Initialized
DEBUG - 2018-06-15 00:52:05 --> Admin MX_Controller Initialized
INFO - 2018-06-15 00:52:05 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-15 00:52:05 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-15 00:52:05 --> Login MX_Controller Initialized
DEBUG - 2018-06-15 00:52:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-15 00:52:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-15 00:52:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-15 00:52:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-15 00:52:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-15 00:52:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-15 00:52:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-15 00:52:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/dashboard.php
INFO - 2018-06-15 00:52:05 --> Final output sent to browser
DEBUG - 2018-06-15 00:52:05 --> Total execution time: 0.6205
INFO - 2018-06-15 00:52:05 --> Config Class Initialized
INFO - 2018-06-15 00:52:05 --> Hooks Class Initialized
DEBUG - 2018-06-15 00:52:05 --> UTF-8 Support Enabled
INFO - 2018-06-15 00:52:05 --> Utf8 Class Initialized
INFO - 2018-06-15 00:52:05 --> URI Class Initialized
INFO - 2018-06-15 00:52:05 --> Router Class Initialized
INFO - 2018-06-15 00:52:05 --> Output Class Initialized
INFO - 2018-06-15 00:52:05 --> Security Class Initialized
DEBUG - 2018-06-15 00:52:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-15 00:52:05 --> Input Class Initialized
INFO - 2018-06-15 00:52:05 --> Language Class Initialized
ERROR - 2018-06-15 00:52:06 --> 404 Page Not Found: /index
INFO - 2018-06-15 00:52:06 --> Config Class Initialized
INFO - 2018-06-15 00:52:06 --> Hooks Class Initialized
DEBUG - 2018-06-15 00:52:06 --> UTF-8 Support Enabled
INFO - 2018-06-15 00:52:06 --> Utf8 Class Initialized
INFO - 2018-06-15 00:52:06 --> URI Class Initialized
INFO - 2018-06-15 00:52:06 --> Router Class Initialized
INFO - 2018-06-15 00:52:06 --> Output Class Initialized
INFO - 2018-06-15 00:52:06 --> Security Class Initialized
DEBUG - 2018-06-15 00:52:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-15 00:52:06 --> Input Class Initialized
INFO - 2018-06-15 00:52:06 --> Language Class Initialized
ERROR - 2018-06-15 00:52:06 --> 404 Page Not Found: /index
INFO - 2018-06-15 00:52:09 --> Config Class Initialized
INFO - 2018-06-15 00:52:09 --> Hooks Class Initialized
DEBUG - 2018-06-15 00:52:09 --> UTF-8 Support Enabled
INFO - 2018-06-15 00:52:09 --> Utf8 Class Initialized
INFO - 2018-06-15 00:52:09 --> URI Class Initialized
INFO - 2018-06-15 00:52:09 --> Router Class Initialized
INFO - 2018-06-15 00:52:09 --> Output Class Initialized
INFO - 2018-06-15 00:52:09 --> Security Class Initialized
DEBUG - 2018-06-15 00:52:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-15 00:52:09 --> Input Class Initialized
INFO - 2018-06-15 00:52:09 --> Language Class Initialized
INFO - 2018-06-15 00:52:09 --> Language Class Initialized
INFO - 2018-06-15 00:52:09 --> Config Class Initialized
INFO - 2018-06-15 00:52:09 --> Loader Class Initialized
DEBUG - 2018-06-15 00:52:09 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-15 00:52:09 --> Helper loaded: url_helper
INFO - 2018-06-15 00:52:09 --> Helper loaded: form_helper
INFO - 2018-06-15 00:52:09 --> Helper loaded: date_helper
INFO - 2018-06-15 00:52:09 --> Helper loaded: util_helper
INFO - 2018-06-15 00:52:09 --> Helper loaded: text_helper
INFO - 2018-06-15 00:52:09 --> Helper loaded: string_helper
INFO - 2018-06-15 00:52:09 --> Database Driver Class Initialized
DEBUG - 2018-06-15 00:52:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-15 00:52:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-15 00:52:09 --> Email Class Initialized
INFO - 2018-06-15 00:52:09 --> Controller Class Initialized
DEBUG - 2018-06-15 00:52:09 --> videos MX_Controller Initialized
INFO - 2018-06-15 00:52:09 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-15 00:52:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-06-15 00:52:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-15 00:52:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-15 00:52:09 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-15 00:52:09 --> Login MX_Controller Initialized
DEBUG - 2018-06-15 00:52:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-15 00:52:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-15 00:52:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-15 00:52:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-15 00:52:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-15 00:52:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-15 00:52:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/videos/videos.php
INFO - 2018-06-15 00:52:09 --> Final output sent to browser
DEBUG - 2018-06-15 00:52:10 --> Total execution time: 0.5204
INFO - 2018-06-15 00:52:10 --> Config Class Initialized
INFO - 2018-06-15 00:52:10 --> Hooks Class Initialized
DEBUG - 2018-06-15 00:52:10 --> UTF-8 Support Enabled
INFO - 2018-06-15 00:52:10 --> Utf8 Class Initialized
INFO - 2018-06-15 00:52:10 --> URI Class Initialized
INFO - 2018-06-15 00:52:10 --> Router Class Initialized
INFO - 2018-06-15 00:52:10 --> Output Class Initialized
INFO - 2018-06-15 00:52:10 --> Security Class Initialized
DEBUG - 2018-06-15 00:52:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-15 00:52:10 --> Input Class Initialized
INFO - 2018-06-15 00:52:10 --> Language Class Initialized
INFO - 2018-06-15 00:52:10 --> Language Class Initialized
INFO - 2018-06-15 00:52:10 --> Config Class Initialized
INFO - 2018-06-15 00:52:10 --> Loader Class Initialized
DEBUG - 2018-06-15 00:52:10 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-15 00:52:10 --> Helper loaded: url_helper
INFO - 2018-06-15 00:52:10 --> Helper loaded: form_helper
INFO - 2018-06-15 00:52:10 --> Helper loaded: date_helper
INFO - 2018-06-15 00:52:10 --> Helper loaded: util_helper
INFO - 2018-06-15 00:52:10 --> Helper loaded: text_helper
INFO - 2018-06-15 00:52:10 --> Helper loaded: string_helper
INFO - 2018-06-15 00:52:10 --> Database Driver Class Initialized
DEBUG - 2018-06-15 00:52:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-15 00:52:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-15 00:52:10 --> Email Class Initialized
INFO - 2018-06-15 00:52:10 --> Controller Class Initialized
DEBUG - 2018-06-15 00:52:10 --> videos MX_Controller Initialized
INFO - 2018-06-15 00:52:10 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-15 00:52:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-06-15 00:52:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-15 00:52:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-15 00:52:11 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-15 00:52:11 --> Login MX_Controller Initialized
DEBUG - 2018-06-15 00:52:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-15 00:52:11 --> Final output sent to browser
DEBUG - 2018-06-15 00:52:11 --> Total execution time: 0.7343
INFO - 2018-06-15 00:53:17 --> Config Class Initialized
INFO - 2018-06-15 00:53:17 --> Hooks Class Initialized
DEBUG - 2018-06-15 00:53:17 --> UTF-8 Support Enabled
INFO - 2018-06-15 00:53:17 --> Utf8 Class Initialized
INFO - 2018-06-15 00:53:17 --> URI Class Initialized
INFO - 2018-06-15 00:53:17 --> Router Class Initialized
INFO - 2018-06-15 00:53:17 --> Output Class Initialized
INFO - 2018-06-15 00:53:17 --> Security Class Initialized
DEBUG - 2018-06-15 00:53:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-15 00:53:17 --> Input Class Initialized
INFO - 2018-06-15 00:53:17 --> Language Class Initialized
INFO - 2018-06-15 00:53:17 --> Language Class Initialized
INFO - 2018-06-15 00:53:17 --> Config Class Initialized
INFO - 2018-06-15 00:53:17 --> Loader Class Initialized
DEBUG - 2018-06-15 00:53:17 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-15 00:53:17 --> Helper loaded: url_helper
INFO - 2018-06-15 00:53:17 --> Helper loaded: form_helper
INFO - 2018-06-15 00:53:17 --> Helper loaded: date_helper
INFO - 2018-06-15 00:53:17 --> Helper loaded: util_helper
INFO - 2018-06-15 00:53:17 --> Helper loaded: text_helper
INFO - 2018-06-15 00:53:17 --> Helper loaded: string_helper
INFO - 2018-06-15 00:53:17 --> Database Driver Class Initialized
DEBUG - 2018-06-15 00:53:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-15 00:53:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-15 00:53:17 --> Email Class Initialized
INFO - 2018-06-15 00:53:17 --> Controller Class Initialized
DEBUG - 2018-06-15 00:53:17 --> Admin MX_Controller Initialized
INFO - 2018-06-15 00:53:17 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-15 00:53:17 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-15 00:53:17 --> Login MX_Controller Initialized
DEBUG - 2018-06-15 00:53:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-15 00:53:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-15 00:53:17 --> Final output sent to browser
DEBUG - 2018-06-15 00:53:17 --> Total execution time: 0.3605
INFO - 2018-06-15 00:53:18 --> Config Class Initialized
INFO - 2018-06-15 00:53:18 --> Hooks Class Initialized
DEBUG - 2018-06-15 00:53:18 --> UTF-8 Support Enabled
INFO - 2018-06-15 00:53:18 --> Utf8 Class Initialized
INFO - 2018-06-15 00:53:18 --> URI Class Initialized
INFO - 2018-06-15 00:53:18 --> Router Class Initialized
INFO - 2018-06-15 00:53:18 --> Output Class Initialized
INFO - 2018-06-15 00:53:18 --> Security Class Initialized
DEBUG - 2018-06-15 00:53:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-15 00:53:18 --> Input Class Initialized
INFO - 2018-06-15 00:53:18 --> Language Class Initialized
INFO - 2018-06-15 00:53:18 --> Language Class Initialized
INFO - 2018-06-15 00:53:18 --> Config Class Initialized
INFO - 2018-06-15 00:53:18 --> Loader Class Initialized
DEBUG - 2018-06-15 00:53:18 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-15 00:53:18 --> Helper loaded: url_helper
INFO - 2018-06-15 00:53:18 --> Helper loaded: form_helper
INFO - 2018-06-15 00:53:18 --> Helper loaded: date_helper
INFO - 2018-06-15 00:53:18 --> Helper loaded: util_helper
INFO - 2018-06-15 00:53:18 --> Helper loaded: text_helper
INFO - 2018-06-15 00:53:18 --> Helper loaded: string_helper
INFO - 2018-06-15 00:53:18 --> Database Driver Class Initialized
DEBUG - 2018-06-15 00:53:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-15 00:53:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-15 00:53:18 --> Email Class Initialized
INFO - 2018-06-15 00:53:18 --> Controller Class Initialized
DEBUG - 2018-06-15 00:53:18 --> Admin MX_Controller Initialized
INFO - 2018-06-15 00:53:18 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-15 00:53:18 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-15 00:53:18 --> Login MX_Controller Initialized
DEBUG - 2018-06-15 00:53:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-15 00:53:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-15 00:53:18 --> Final output sent to browser
DEBUG - 2018-06-15 00:53:18 --> Total execution time: 0.3469
INFO - 2018-06-15 00:53:22 --> Config Class Initialized
INFO - 2018-06-15 00:53:22 --> Hooks Class Initialized
DEBUG - 2018-06-15 00:53:22 --> UTF-8 Support Enabled
INFO - 2018-06-15 00:53:22 --> Utf8 Class Initialized
INFO - 2018-06-15 00:53:22 --> URI Class Initialized
INFO - 2018-06-15 00:53:22 --> Router Class Initialized
INFO - 2018-06-15 00:53:22 --> Output Class Initialized
INFO - 2018-06-15 00:53:22 --> Security Class Initialized
DEBUG - 2018-06-15 00:53:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-15 00:53:22 --> Input Class Initialized
INFO - 2018-06-15 00:53:22 --> Language Class Initialized
INFO - 2018-06-15 00:53:22 --> Language Class Initialized
INFO - 2018-06-15 00:53:22 --> Config Class Initialized
INFO - 2018-06-15 00:53:22 --> Loader Class Initialized
DEBUG - 2018-06-15 00:53:22 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-15 00:53:22 --> Helper loaded: url_helper
INFO - 2018-06-15 00:53:22 --> Helper loaded: form_helper
INFO - 2018-06-15 00:53:22 --> Helper loaded: date_helper
INFO - 2018-06-15 00:53:22 --> Helper loaded: util_helper
INFO - 2018-06-15 00:53:22 --> Helper loaded: text_helper
INFO - 2018-06-15 00:53:22 --> Helper loaded: string_helper
INFO - 2018-06-15 00:53:22 --> Database Driver Class Initialized
DEBUG - 2018-06-15 00:53:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-15 00:53:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-15 00:53:22 --> Email Class Initialized
INFO - 2018-06-15 00:53:22 --> Controller Class Initialized
DEBUG - 2018-06-15 00:53:22 --> videos MX_Controller Initialized
INFO - 2018-06-15 00:53:22 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-15 00:53:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-06-15 00:53:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-15 00:53:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-15 00:53:22 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-15 00:53:22 --> Login MX_Controller Initialized
DEBUG - 2018-06-15 00:53:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-15 00:53:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-15 00:53:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-15 00:53:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-15 00:53:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-15 00:53:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-15 00:53:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/videos/create_video.php
INFO - 2018-06-15 00:53:22 --> Final output sent to browser
DEBUG - 2018-06-15 00:53:22 --> Total execution time: 0.5325
INFO - 2018-06-15 00:53:23 --> Config Class Initialized
INFO - 2018-06-15 00:53:23 --> Hooks Class Initialized
DEBUG - 2018-06-15 00:53:23 --> UTF-8 Support Enabled
INFO - 2018-06-15 00:53:23 --> Utf8 Class Initialized
INFO - 2018-06-15 00:53:23 --> URI Class Initialized
INFO - 2018-06-15 00:53:23 --> Router Class Initialized
INFO - 2018-06-15 00:53:23 --> Output Class Initialized
INFO - 2018-06-15 00:53:23 --> Security Class Initialized
DEBUG - 2018-06-15 00:53:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-15 00:53:23 --> Input Class Initialized
INFO - 2018-06-15 00:53:23 --> Language Class Initialized
ERROR - 2018-06-15 00:53:23 --> 404 Page Not Found: /index
INFO - 2018-06-15 00:54:44 --> Config Class Initialized
INFO - 2018-06-15 00:54:44 --> Hooks Class Initialized
DEBUG - 2018-06-15 00:54:44 --> UTF-8 Support Enabled
INFO - 2018-06-15 00:54:44 --> Utf8 Class Initialized
INFO - 2018-06-15 00:54:44 --> URI Class Initialized
INFO - 2018-06-15 00:54:44 --> Router Class Initialized
INFO - 2018-06-15 00:54:44 --> Output Class Initialized
INFO - 2018-06-15 00:54:44 --> Security Class Initialized
DEBUG - 2018-06-15 00:54:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-15 00:54:44 --> Input Class Initialized
INFO - 2018-06-15 00:54:44 --> Language Class Initialized
INFO - 2018-06-15 00:54:44 --> Language Class Initialized
INFO - 2018-06-15 00:54:44 --> Config Class Initialized
INFO - 2018-06-15 00:54:44 --> Loader Class Initialized
DEBUG - 2018-06-15 00:54:44 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-15 00:54:44 --> Helper loaded: url_helper
INFO - 2018-06-15 00:54:44 --> Helper loaded: form_helper
INFO - 2018-06-15 00:54:44 --> Helper loaded: date_helper
INFO - 2018-06-15 00:54:44 --> Helper loaded: util_helper
INFO - 2018-06-15 00:54:44 --> Helper loaded: text_helper
INFO - 2018-06-15 00:54:44 --> Helper loaded: string_helper
INFO - 2018-06-15 00:54:44 --> Database Driver Class Initialized
DEBUG - 2018-06-15 00:54:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-15 00:54:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-15 00:54:44 --> Email Class Initialized
INFO - 2018-06-15 00:54:44 --> Controller Class Initialized
DEBUG - 2018-06-15 00:54:44 --> videos MX_Controller Initialized
INFO - 2018-06-15 00:54:44 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-15 00:54:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-06-15 00:54:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-15 00:54:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-15 00:54:44 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-15 00:54:44 --> Login MX_Controller Initialized
DEBUG - 2018-06-15 00:54:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-15 00:54:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-15 00:54:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-15 00:54:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-15 00:54:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-15 00:54:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-15 00:54:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/videos/create_video.php
INFO - 2018-06-15 00:54:45 --> Final output sent to browser
DEBUG - 2018-06-15 00:54:45 --> Total execution time: 0.4975
INFO - 2018-06-15 00:54:45 --> Config Class Initialized
INFO - 2018-06-15 00:54:45 --> Hooks Class Initialized
DEBUG - 2018-06-15 00:54:45 --> UTF-8 Support Enabled
INFO - 2018-06-15 00:54:45 --> Utf8 Class Initialized
INFO - 2018-06-15 00:54:45 --> URI Class Initialized
INFO - 2018-06-15 00:54:45 --> Router Class Initialized
INFO - 2018-06-15 00:54:45 --> Output Class Initialized
INFO - 2018-06-15 00:54:45 --> Security Class Initialized
DEBUG - 2018-06-15 00:54:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-15 00:54:45 --> Input Class Initialized
INFO - 2018-06-15 00:54:45 --> Language Class Initialized
INFO - 2018-06-15 00:54:45 --> Language Class Initialized
INFO - 2018-06-15 00:54:45 --> Config Class Initialized
INFO - 2018-06-15 00:54:45 --> Loader Class Initialized
DEBUG - 2018-06-15 00:54:45 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-15 00:54:46 --> Helper loaded: url_helper
INFO - 2018-06-15 00:54:46 --> Helper loaded: form_helper
INFO - 2018-06-15 00:54:46 --> Helper loaded: date_helper
INFO - 2018-06-15 00:54:46 --> Helper loaded: util_helper
INFO - 2018-06-15 00:54:46 --> Helper loaded: text_helper
INFO - 2018-06-15 00:54:46 --> Helper loaded: string_helper
INFO - 2018-06-15 00:54:46 --> Database Driver Class Initialized
DEBUG - 2018-06-15 00:54:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-15 00:54:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-15 00:54:46 --> Email Class Initialized
INFO - 2018-06-15 00:54:46 --> Controller Class Initialized
DEBUG - 2018-06-15 00:54:46 --> Home MX_Controller Initialized
DEBUG - 2018-06-15 00:54:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-15 00:54:46 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-15 00:54:46 --> Login MX_Controller Initialized
INFO - 2018-06-15 00:54:46 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-15 00:54:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-15 00:54:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-15 00:54:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-15 00:54:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-15 00:54:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-15 00:54:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-15 00:54:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-15 00:54:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-06-15 00:54:46 --> Final output sent to browser
DEBUG - 2018-06-15 00:54:46 --> Total execution time: 0.5019
INFO - 2018-06-15 00:54:49 --> Config Class Initialized
INFO - 2018-06-15 00:54:49 --> Hooks Class Initialized
DEBUG - 2018-06-15 00:54:49 --> UTF-8 Support Enabled
INFO - 2018-06-15 00:54:49 --> Utf8 Class Initialized
INFO - 2018-06-15 00:54:49 --> URI Class Initialized
INFO - 2018-06-15 00:54:49 --> Router Class Initialized
INFO - 2018-06-15 00:54:49 --> Output Class Initialized
INFO - 2018-06-15 00:54:49 --> Security Class Initialized
DEBUG - 2018-06-15 00:54:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-15 00:54:49 --> Input Class Initialized
INFO - 2018-06-15 00:54:49 --> Language Class Initialized
ERROR - 2018-06-15 00:54:49 --> 404 Page Not Found: /index
INFO - 2018-06-15 00:54:49 --> Config Class Initialized
INFO - 2018-06-15 00:54:49 --> Hooks Class Initialized
DEBUG - 2018-06-15 00:54:49 --> UTF-8 Support Enabled
INFO - 2018-06-15 00:54:49 --> Utf8 Class Initialized
INFO - 2018-06-15 00:54:49 --> URI Class Initialized
INFO - 2018-06-15 00:54:49 --> Router Class Initialized
INFO - 2018-06-15 00:54:49 --> Output Class Initialized
INFO - 2018-06-15 00:54:49 --> Security Class Initialized
DEBUG - 2018-06-15 00:54:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-15 00:54:49 --> Input Class Initialized
INFO - 2018-06-15 00:54:49 --> Language Class Initialized
ERROR - 2018-06-15 00:54:49 --> 404 Page Not Found: /index
INFO - 2018-06-15 00:54:49 --> Config Class Initialized
INFO - 2018-06-15 00:54:49 --> Hooks Class Initialized
DEBUG - 2018-06-15 00:54:49 --> UTF-8 Support Enabled
INFO - 2018-06-15 00:54:49 --> Utf8 Class Initialized
INFO - 2018-06-15 00:54:49 --> URI Class Initialized
INFO - 2018-06-15 00:54:49 --> Router Class Initialized
INFO - 2018-06-15 00:54:50 --> Output Class Initialized
INFO - 2018-06-15 00:54:50 --> Security Class Initialized
DEBUG - 2018-06-15 00:54:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-15 00:54:50 --> Input Class Initialized
INFO - 2018-06-15 00:54:50 --> Language Class Initialized
ERROR - 2018-06-15 00:54:50 --> 404 Page Not Found: /index
INFO - 2018-06-15 00:58:00 --> Config Class Initialized
INFO - 2018-06-15 00:58:00 --> Hooks Class Initialized
DEBUG - 2018-06-15 00:58:00 --> UTF-8 Support Enabled
INFO - 2018-06-15 00:58:00 --> Utf8 Class Initialized
INFO - 2018-06-15 00:58:00 --> URI Class Initialized
INFO - 2018-06-15 00:58:01 --> Router Class Initialized
INFO - 2018-06-15 00:58:01 --> Output Class Initialized
INFO - 2018-06-15 00:58:01 --> Security Class Initialized
DEBUG - 2018-06-15 00:58:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-15 00:58:01 --> Input Class Initialized
INFO - 2018-06-15 00:58:01 --> Language Class Initialized
INFO - 2018-06-15 00:58:01 --> Language Class Initialized
INFO - 2018-06-15 00:58:01 --> Config Class Initialized
INFO - 2018-06-15 00:58:01 --> Loader Class Initialized
DEBUG - 2018-06-15 00:58:01 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-15 00:58:01 --> Helper loaded: url_helper
INFO - 2018-06-15 00:58:01 --> Helper loaded: form_helper
INFO - 2018-06-15 00:58:01 --> Helper loaded: date_helper
INFO - 2018-06-15 00:58:01 --> Helper loaded: util_helper
INFO - 2018-06-15 00:58:01 --> Helper loaded: text_helper
INFO - 2018-06-15 00:58:01 --> Helper loaded: string_helper
INFO - 2018-06-15 00:58:01 --> Database Driver Class Initialized
DEBUG - 2018-06-15 00:58:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-15 00:58:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-15 00:58:01 --> Email Class Initialized
INFO - 2018-06-15 00:58:01 --> Controller Class Initialized
DEBUG - 2018-06-15 00:58:01 --> videos MX_Controller Initialized
INFO - 2018-06-15 00:58:01 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-15 00:58:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-06-15 00:58:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-15 00:58:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-15 00:58:01 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-15 00:58:01 --> Login MX_Controller Initialized
DEBUG - 2018-06-15 00:58:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-15 00:58:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-15 00:58:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-15 00:58:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-15 00:58:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-15 00:58:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-15 00:58:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/videos/create_video.php
INFO - 2018-06-15 00:58:01 --> Final output sent to browser
DEBUG - 2018-06-15 00:58:01 --> Total execution time: 0.3777
INFO - 2018-06-15 00:58:01 --> Config Class Initialized
INFO - 2018-06-15 00:58:01 --> Hooks Class Initialized
DEBUG - 2018-06-15 00:58:01 --> UTF-8 Support Enabled
INFO - 2018-06-15 00:58:01 --> Utf8 Class Initialized
INFO - 2018-06-15 00:58:01 --> URI Class Initialized
INFO - 2018-06-15 00:58:01 --> Router Class Initialized
INFO - 2018-06-15 00:58:01 --> Output Class Initialized
INFO - 2018-06-15 00:58:01 --> Security Class Initialized
DEBUG - 2018-06-15 00:58:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-15 00:58:01 --> Input Class Initialized
INFO - 2018-06-15 00:58:01 --> Language Class Initialized
ERROR - 2018-06-15 00:58:01 --> 404 Page Not Found: /index
INFO - 2018-06-15 00:58:09 --> Config Class Initialized
INFO - 2018-06-15 00:58:09 --> Hooks Class Initialized
DEBUG - 2018-06-15 00:58:09 --> UTF-8 Support Enabled
INFO - 2018-06-15 00:58:09 --> Utf8 Class Initialized
INFO - 2018-06-15 00:58:09 --> URI Class Initialized
INFO - 2018-06-15 00:58:09 --> Router Class Initialized
INFO - 2018-06-15 00:58:09 --> Output Class Initialized
INFO - 2018-06-15 00:58:09 --> Security Class Initialized
DEBUG - 2018-06-15 00:58:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-15 00:58:09 --> Input Class Initialized
INFO - 2018-06-15 00:58:09 --> Language Class Initialized
INFO - 2018-06-15 00:58:09 --> Language Class Initialized
INFO - 2018-06-15 00:58:09 --> Config Class Initialized
INFO - 2018-06-15 00:58:09 --> Loader Class Initialized
DEBUG - 2018-06-15 00:58:09 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-15 00:58:09 --> Helper loaded: url_helper
INFO - 2018-06-15 00:58:09 --> Helper loaded: form_helper
INFO - 2018-06-15 00:58:09 --> Helper loaded: date_helper
INFO - 2018-06-15 00:58:09 --> Helper loaded: util_helper
INFO - 2018-06-15 00:58:09 --> Helper loaded: text_helper
INFO - 2018-06-15 00:58:09 --> Helper loaded: string_helper
INFO - 2018-06-15 00:58:09 --> Database Driver Class Initialized
DEBUG - 2018-06-15 00:58:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-15 00:58:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-15 00:58:09 --> Email Class Initialized
INFO - 2018-06-15 00:58:09 --> Controller Class Initialized
DEBUG - 2018-06-15 00:58:09 --> videos MX_Controller Initialized
INFO - 2018-06-15 00:58:09 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-15 00:58:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-06-15 00:58:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-15 00:58:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-15 00:58:09 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-15 00:58:09 --> Login MX_Controller Initialized
DEBUG - 2018-06-15 00:58:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-15 00:58:09 --> Config Class Initialized
INFO - 2018-06-15 00:58:09 --> Hooks Class Initialized
DEBUG - 2018-06-15 00:58:09 --> UTF-8 Support Enabled
INFO - 2018-06-15 00:58:09 --> Utf8 Class Initialized
INFO - 2018-06-15 00:58:09 --> URI Class Initialized
INFO - 2018-06-15 00:58:09 --> Router Class Initialized
INFO - 2018-06-15 00:58:09 --> Output Class Initialized
INFO - 2018-06-15 00:58:09 --> Security Class Initialized
DEBUG - 2018-06-15 00:58:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-15 00:58:09 --> Input Class Initialized
INFO - 2018-06-15 00:58:09 --> Language Class Initialized
INFO - 2018-06-15 00:58:09 --> Language Class Initialized
INFO - 2018-06-15 00:58:09 --> Config Class Initialized
INFO - 2018-06-15 00:58:09 --> Loader Class Initialized
DEBUG - 2018-06-15 00:58:09 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-15 00:58:09 --> Helper loaded: url_helper
INFO - 2018-06-15 00:58:09 --> Helper loaded: form_helper
INFO - 2018-06-15 00:58:09 --> Helper loaded: date_helper
INFO - 2018-06-15 00:58:09 --> Helper loaded: util_helper
INFO - 2018-06-15 00:58:09 --> Helper loaded: text_helper
INFO - 2018-06-15 00:58:09 --> Helper loaded: string_helper
INFO - 2018-06-15 00:58:09 --> Database Driver Class Initialized
DEBUG - 2018-06-15 00:58:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-15 00:58:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-15 00:58:09 --> Email Class Initialized
INFO - 2018-06-15 00:58:09 --> Controller Class Initialized
DEBUG - 2018-06-15 00:58:09 --> videos MX_Controller Initialized
INFO - 2018-06-15 00:58:09 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-15 00:58:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-06-15 00:58:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-15 00:58:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-15 00:58:09 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-15 00:58:09 --> Login MX_Controller Initialized
DEBUG - 2018-06-15 00:58:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-15 00:58:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-15 00:58:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-15 00:58:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-15 00:58:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-15 00:58:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-15 00:58:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/videos/videos.php
INFO - 2018-06-15 00:58:09 --> Final output sent to browser
DEBUG - 2018-06-15 00:58:09 --> Total execution time: 0.3998
INFO - 2018-06-15 00:58:10 --> Config Class Initialized
INFO - 2018-06-15 00:58:10 --> Hooks Class Initialized
DEBUG - 2018-06-15 00:58:10 --> UTF-8 Support Enabled
INFO - 2018-06-15 00:58:10 --> Utf8 Class Initialized
INFO - 2018-06-15 00:58:10 --> URI Class Initialized
INFO - 2018-06-15 00:58:10 --> Router Class Initialized
INFO - 2018-06-15 00:58:10 --> Output Class Initialized
INFO - 2018-06-15 00:58:10 --> Security Class Initialized
DEBUG - 2018-06-15 00:58:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-15 00:58:10 --> Input Class Initialized
INFO - 2018-06-15 00:58:10 --> Language Class Initialized
INFO - 2018-06-15 00:58:10 --> Language Class Initialized
INFO - 2018-06-15 00:58:10 --> Config Class Initialized
INFO - 2018-06-15 00:58:10 --> Loader Class Initialized
DEBUG - 2018-06-15 00:58:10 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-15 00:58:10 --> Helper loaded: url_helper
INFO - 2018-06-15 00:58:10 --> Helper loaded: form_helper
INFO - 2018-06-15 00:58:10 --> Helper loaded: date_helper
INFO - 2018-06-15 00:58:10 --> Helper loaded: util_helper
INFO - 2018-06-15 00:58:10 --> Helper loaded: text_helper
INFO - 2018-06-15 00:58:10 --> Helper loaded: string_helper
INFO - 2018-06-15 00:58:10 --> Database Driver Class Initialized
DEBUG - 2018-06-15 00:58:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-15 00:58:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-15 00:58:10 --> Email Class Initialized
INFO - 2018-06-15 00:58:10 --> Controller Class Initialized
DEBUG - 2018-06-15 00:58:10 --> videos MX_Controller Initialized
INFO - 2018-06-15 00:58:10 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-15 00:58:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-06-15 00:58:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-15 00:58:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-15 00:58:10 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-15 00:58:10 --> Login MX_Controller Initialized
DEBUG - 2018-06-15 00:58:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-15 00:58:10 --> Final output sent to browser
DEBUG - 2018-06-15 00:58:10 --> Total execution time: 0.4525
INFO - 2018-06-15 00:58:12 --> Config Class Initialized
INFO - 2018-06-15 00:58:12 --> Hooks Class Initialized
DEBUG - 2018-06-15 00:58:12 --> UTF-8 Support Enabled
INFO - 2018-06-15 00:58:12 --> Utf8 Class Initialized
INFO - 2018-06-15 00:58:12 --> URI Class Initialized
INFO - 2018-06-15 00:58:12 --> Config Class Initialized
INFO - 2018-06-15 00:58:12 --> Hooks Class Initialized
INFO - 2018-06-15 00:58:12 --> Router Class Initialized
INFO - 2018-06-15 00:58:12 --> Output Class Initialized
DEBUG - 2018-06-15 00:58:12 --> UTF-8 Support Enabled
INFO - 2018-06-15 00:58:12 --> Utf8 Class Initialized
INFO - 2018-06-15 00:58:12 --> Security Class Initialized
INFO - 2018-06-15 00:58:12 --> URI Class Initialized
DEBUG - 2018-06-15 00:58:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-15 00:58:12 --> Input Class Initialized
INFO - 2018-06-15 00:58:12 --> Router Class Initialized
INFO - 2018-06-15 00:58:12 --> Language Class Initialized
INFO - 2018-06-15 00:58:12 --> Output Class Initialized
INFO - 2018-06-15 00:58:12 --> Security Class Initialized
INFO - 2018-06-15 00:58:12 --> Language Class Initialized
INFO - 2018-06-15 00:58:12 --> Config Class Initialized
DEBUG - 2018-06-15 00:58:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-15 00:58:12 --> Input Class Initialized
INFO - 2018-06-15 00:58:12 --> Loader Class Initialized
DEBUG - 2018-06-15 00:58:12 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-15 00:58:12 --> Language Class Initialized
INFO - 2018-06-15 00:58:12 --> Helper loaded: url_helper
INFO - 2018-06-15 00:58:12 --> Language Class Initialized
INFO - 2018-06-15 00:58:12 --> Config Class Initialized
INFO - 2018-06-15 00:58:12 --> Helper loaded: form_helper
INFO - 2018-06-15 00:58:12 --> Helper loaded: date_helper
INFO - 2018-06-15 00:58:12 --> Loader Class Initialized
INFO - 2018-06-15 00:58:12 --> Helper loaded: util_helper
DEBUG - 2018-06-15 00:58:12 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-15 00:58:12 --> Helper loaded: url_helper
INFO - 2018-06-15 00:58:12 --> Helper loaded: text_helper
INFO - 2018-06-15 00:58:12 --> Helper loaded: string_helper
INFO - 2018-06-15 00:58:12 --> Database Driver Class Initialized
INFO - 2018-06-15 00:58:12 --> Helper loaded: form_helper
INFO - 2018-06-15 00:58:12 --> Helper loaded: date_helper
DEBUG - 2018-06-15 00:58:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-15 00:58:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-15 00:58:12 --> Helper loaded: util_helper
INFO - 2018-06-15 00:58:12 --> Helper loaded: text_helper
INFO - 2018-06-15 00:58:12 --> Email Class Initialized
INFO - 2018-06-15 00:58:12 --> Controller Class Initialized
INFO - 2018-06-15 00:58:12 --> Helper loaded: string_helper
DEBUG - 2018-06-15 00:58:12 --> videos MX_Controller Initialized
INFO - 2018-06-15 00:58:12 --> Database Driver Class Initialized
INFO - 2018-06-15 00:58:12 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-15 00:58:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-06-15 00:58:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-06-15 00:58:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-15 00:58:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-15 00:58:12 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-15 00:58:12 --> Login MX_Controller Initialized
DEBUG - 2018-06-15 00:58:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-15 00:58:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-15 00:58:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-15 00:58:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-15 00:58:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-15 00:58:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-15 00:58:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/videos/create_video.php
INFO - 2018-06-15 00:58:12 --> Final output sent to browser
DEBUG - 2018-06-15 00:58:12 --> Total execution time: 0.3832
INFO - 2018-06-15 00:58:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-15 00:58:12 --> Email Class Initialized
INFO - 2018-06-15 00:58:12 --> Controller Class Initialized
DEBUG - 2018-06-15 00:58:12 --> videos MX_Controller Initialized
INFO - 2018-06-15 00:58:12 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-15 00:58:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-06-15 00:58:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-15 00:58:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-15 00:58:12 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-15 00:58:12 --> Login MX_Controller Initialized
DEBUG - 2018-06-15 00:58:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-15 00:58:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-15 00:58:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-15 00:58:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-15 00:58:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-15 00:58:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-15 00:58:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/videos/videos.php
INFO - 2018-06-15 00:58:12 --> Final output sent to browser
DEBUG - 2018-06-15 00:58:12 --> Total execution time: 0.5050
INFO - 2018-06-15 00:58:13 --> Config Class Initialized
INFO - 2018-06-15 00:58:13 --> Hooks Class Initialized
DEBUG - 2018-06-15 00:58:13 --> UTF-8 Support Enabled
INFO - 2018-06-15 00:58:13 --> Utf8 Class Initialized
INFO - 2018-06-15 00:58:13 --> URI Class Initialized
INFO - 2018-06-15 00:58:13 --> Router Class Initialized
INFO - 2018-06-15 00:58:13 --> Output Class Initialized
INFO - 2018-06-15 00:58:13 --> Security Class Initialized
DEBUG - 2018-06-15 00:58:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-15 00:58:13 --> Input Class Initialized
INFO - 2018-06-15 00:58:13 --> Language Class Initialized
INFO - 2018-06-15 00:58:13 --> Language Class Initialized
INFO - 2018-06-15 00:58:13 --> Config Class Initialized
INFO - 2018-06-15 00:58:13 --> Loader Class Initialized
DEBUG - 2018-06-15 00:58:13 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-15 00:58:13 --> Helper loaded: url_helper
INFO - 2018-06-15 00:58:13 --> Helper loaded: form_helper
INFO - 2018-06-15 00:58:13 --> Helper loaded: date_helper
INFO - 2018-06-15 00:58:13 --> Helper loaded: util_helper
INFO - 2018-06-15 00:58:13 --> Helper loaded: text_helper
INFO - 2018-06-15 00:58:13 --> Helper loaded: string_helper
INFO - 2018-06-15 00:58:13 --> Database Driver Class Initialized
DEBUG - 2018-06-15 00:58:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-15 00:58:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-15 00:58:13 --> Email Class Initialized
INFO - 2018-06-15 00:58:13 --> Controller Class Initialized
DEBUG - 2018-06-15 00:58:13 --> videos MX_Controller Initialized
INFO - 2018-06-15 00:58:13 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-15 00:58:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-06-15 00:58:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-15 00:58:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-15 00:58:13 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-15 00:58:13 --> Login MX_Controller Initialized
DEBUG - 2018-06-15 00:58:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-15 00:58:13 --> Final output sent to browser
DEBUG - 2018-06-15 00:58:13 --> Total execution time: 0.4750
INFO - 2018-06-15 00:58:15 --> Config Class Initialized
INFO - 2018-06-15 00:58:15 --> Hooks Class Initialized
DEBUG - 2018-06-15 00:58:15 --> UTF-8 Support Enabled
INFO - 2018-06-15 00:58:15 --> Utf8 Class Initialized
INFO - 2018-06-15 00:58:15 --> URI Class Initialized
INFO - 2018-06-15 00:58:15 --> Router Class Initialized
INFO - 2018-06-15 00:58:15 --> Output Class Initialized
INFO - 2018-06-15 00:58:15 --> Security Class Initialized
DEBUG - 2018-06-15 00:58:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-15 00:58:15 --> Input Class Initialized
INFO - 2018-06-15 00:58:15 --> Language Class Initialized
INFO - 2018-06-15 00:58:15 --> Language Class Initialized
INFO - 2018-06-15 00:58:15 --> Config Class Initialized
INFO - 2018-06-15 00:58:15 --> Loader Class Initialized
DEBUG - 2018-06-15 00:58:15 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-15 00:58:15 --> Helper loaded: url_helper
INFO - 2018-06-15 00:58:15 --> Helper loaded: form_helper
INFO - 2018-06-15 00:58:15 --> Helper loaded: date_helper
INFO - 2018-06-15 00:58:15 --> Helper loaded: util_helper
INFO - 2018-06-15 00:58:15 --> Helper loaded: text_helper
INFO - 2018-06-15 00:58:15 --> Helper loaded: string_helper
INFO - 2018-06-15 00:58:15 --> Database Driver Class Initialized
DEBUG - 2018-06-15 00:58:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-15 00:58:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-15 00:58:15 --> Email Class Initialized
INFO - 2018-06-15 00:58:15 --> Controller Class Initialized
DEBUG - 2018-06-15 00:58:15 --> Admin MX_Controller Initialized
INFO - 2018-06-15 00:58:15 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-15 00:58:15 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-15 00:58:15 --> Login MX_Controller Initialized
DEBUG - 2018-06-15 00:58:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-15 00:58:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-15 00:58:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-15 00:58:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-15 00:58:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-15 00:58:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-15 00:58:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-15 00:58:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/dashboard.php
INFO - 2018-06-15 00:58:15 --> Final output sent to browser
DEBUG - 2018-06-15 00:58:15 --> Total execution time: 0.3697
INFO - 2018-06-15 00:58:15 --> Config Class Initialized
INFO - 2018-06-15 00:58:15 --> Hooks Class Initialized
DEBUG - 2018-06-15 00:58:15 --> UTF-8 Support Enabled
INFO - 2018-06-15 00:58:15 --> Config Class Initialized
INFO - 2018-06-15 00:58:15 --> Utf8 Class Initialized
INFO - 2018-06-15 00:58:15 --> Hooks Class Initialized
INFO - 2018-06-15 00:58:15 --> URI Class Initialized
DEBUG - 2018-06-15 00:58:15 --> UTF-8 Support Enabled
INFO - 2018-06-15 00:58:15 --> Utf8 Class Initialized
INFO - 2018-06-15 00:58:15 --> Router Class Initialized
INFO - 2018-06-15 00:58:15 --> URI Class Initialized
INFO - 2018-06-15 00:58:15 --> Output Class Initialized
INFO - 2018-06-15 00:58:15 --> Security Class Initialized
INFO - 2018-06-15 00:58:15 --> Router Class Initialized
DEBUG - 2018-06-15 00:58:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-15 00:58:15 --> Output Class Initialized
INFO - 2018-06-15 00:58:16 --> Input Class Initialized
INFO - 2018-06-15 00:58:16 --> Security Class Initialized
INFO - 2018-06-15 00:58:16 --> Language Class Initialized
DEBUG - 2018-06-15 00:58:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-15 00:58:16 --> Input Class Initialized
ERROR - 2018-06-15 00:58:16 --> 404 Page Not Found: /index
INFO - 2018-06-15 00:58:16 --> Language Class Initialized
ERROR - 2018-06-15 00:58:16 --> 404 Page Not Found: /index
INFO - 2018-06-15 00:58:17 --> Config Class Initialized
INFO - 2018-06-15 00:58:17 --> Hooks Class Initialized
DEBUG - 2018-06-15 00:58:17 --> UTF-8 Support Enabled
INFO - 2018-06-15 00:58:17 --> Utf8 Class Initialized
INFO - 2018-06-15 00:58:17 --> URI Class Initialized
INFO - 2018-06-15 00:58:17 --> Router Class Initialized
INFO - 2018-06-15 00:58:17 --> Output Class Initialized
INFO - 2018-06-15 00:58:17 --> Security Class Initialized
DEBUG - 2018-06-15 00:58:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-15 00:58:17 --> Input Class Initialized
INFO - 2018-06-15 00:58:17 --> Language Class Initialized
INFO - 2018-06-15 00:58:17 --> Language Class Initialized
INFO - 2018-06-15 00:58:17 --> Config Class Initialized
INFO - 2018-06-15 00:58:17 --> Loader Class Initialized
DEBUG - 2018-06-15 00:58:17 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-15 00:58:17 --> Helper loaded: url_helper
INFO - 2018-06-15 00:58:17 --> Helper loaded: form_helper
INFO - 2018-06-15 00:58:17 --> Helper loaded: date_helper
INFO - 2018-06-15 00:58:17 --> Helper loaded: util_helper
INFO - 2018-06-15 00:58:17 --> Helper loaded: text_helper
INFO - 2018-06-15 00:58:17 --> Helper loaded: string_helper
INFO - 2018-06-15 00:58:17 --> Database Driver Class Initialized
DEBUG - 2018-06-15 00:58:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-15 00:58:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-15 00:58:17 --> Email Class Initialized
INFO - 2018-06-15 00:58:17 --> Controller Class Initialized
DEBUG - 2018-06-15 00:58:17 --> videos MX_Controller Initialized
INFO - 2018-06-15 00:58:17 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-15 00:58:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-06-15 00:58:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-15 00:58:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-15 00:58:17 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-15 00:58:17 --> Login MX_Controller Initialized
DEBUG - 2018-06-15 00:58:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-15 00:58:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-15 00:58:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-15 00:58:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-15 00:58:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-15 00:58:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-15 00:58:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/videos/videos.php
INFO - 2018-06-15 00:58:17 --> Final output sent to browser
DEBUG - 2018-06-15 00:58:17 --> Total execution time: 0.3925
INFO - 2018-06-15 00:58:18 --> Config Class Initialized
INFO - 2018-06-15 00:58:18 --> Hooks Class Initialized
DEBUG - 2018-06-15 00:58:18 --> UTF-8 Support Enabled
INFO - 2018-06-15 00:58:18 --> Utf8 Class Initialized
INFO - 2018-06-15 00:58:18 --> URI Class Initialized
INFO - 2018-06-15 00:58:18 --> Router Class Initialized
INFO - 2018-06-15 00:58:18 --> Output Class Initialized
INFO - 2018-06-15 00:58:18 --> Security Class Initialized
DEBUG - 2018-06-15 00:58:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-15 00:58:18 --> Input Class Initialized
INFO - 2018-06-15 00:58:18 --> Language Class Initialized
INFO - 2018-06-15 00:58:18 --> Language Class Initialized
INFO - 2018-06-15 00:58:18 --> Config Class Initialized
INFO - 2018-06-15 00:58:18 --> Loader Class Initialized
DEBUG - 2018-06-15 00:58:18 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-15 00:58:18 --> Helper loaded: url_helper
INFO - 2018-06-15 00:58:18 --> Helper loaded: form_helper
INFO - 2018-06-15 00:58:18 --> Helper loaded: date_helper
INFO - 2018-06-15 00:58:18 --> Helper loaded: util_helper
INFO - 2018-06-15 00:58:18 --> Helper loaded: text_helper
INFO - 2018-06-15 00:58:18 --> Helper loaded: string_helper
INFO - 2018-06-15 00:58:18 --> Database Driver Class Initialized
DEBUG - 2018-06-15 00:58:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-15 00:58:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-15 00:58:18 --> Email Class Initialized
INFO - 2018-06-15 00:58:18 --> Controller Class Initialized
DEBUG - 2018-06-15 00:58:18 --> videos MX_Controller Initialized
INFO - 2018-06-15 00:58:18 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-15 00:58:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-06-15 00:58:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-15 00:58:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-15 00:58:18 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-15 00:58:18 --> Login MX_Controller Initialized
DEBUG - 2018-06-15 00:58:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-15 00:58:18 --> Final output sent to browser
DEBUG - 2018-06-15 00:58:18 --> Total execution time: 0.4156
INFO - 2018-06-15 00:58:18 --> Config Class Initialized
INFO - 2018-06-15 00:58:18 --> Hooks Class Initialized
INFO - 2018-06-15 00:58:18 --> Config Class Initialized
INFO - 2018-06-15 00:58:18 --> Hooks Class Initialized
DEBUG - 2018-06-15 00:58:18 --> UTF-8 Support Enabled
INFO - 2018-06-15 00:58:18 --> Utf8 Class Initialized
DEBUG - 2018-06-15 00:58:18 --> UTF-8 Support Enabled
INFO - 2018-06-15 00:58:18 --> Utf8 Class Initialized
INFO - 2018-06-15 00:58:18 --> URI Class Initialized
INFO - 2018-06-15 00:58:18 --> URI Class Initialized
INFO - 2018-06-15 00:58:18 --> Router Class Initialized
INFO - 2018-06-15 00:58:18 --> Output Class Initialized
INFO - 2018-06-15 00:58:18 --> Router Class Initialized
INFO - 2018-06-15 00:58:18 --> Security Class Initialized
INFO - 2018-06-15 00:58:18 --> Output Class Initialized
INFO - 2018-06-15 00:58:18 --> Security Class Initialized
DEBUG - 2018-06-15 00:58:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-15 00:58:18 --> Input Class Initialized
DEBUG - 2018-06-15 00:58:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-15 00:58:18 --> Input Class Initialized
INFO - 2018-06-15 00:58:18 --> Language Class Initialized
INFO - 2018-06-15 00:58:18 --> Language Class Initialized
INFO - 2018-06-15 00:58:18 --> Language Class Initialized
INFO - 2018-06-15 00:58:18 --> Config Class Initialized
INFO - 2018-06-15 00:58:18 --> Language Class Initialized
INFO - 2018-06-15 00:58:18 --> Config Class Initialized
INFO - 2018-06-15 00:58:18 --> Loader Class Initialized
INFO - 2018-06-15 00:58:18 --> Loader Class Initialized
DEBUG - 2018-06-15 00:58:18 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
DEBUG - 2018-06-15 00:58:18 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-15 00:58:18 --> Helper loaded: url_helper
INFO - 2018-06-15 00:58:18 --> Helper loaded: url_helper
INFO - 2018-06-15 00:58:18 --> Helper loaded: form_helper
INFO - 2018-06-15 00:58:18 --> Helper loaded: form_helper
INFO - 2018-06-15 00:58:18 --> Helper loaded: date_helper
INFO - 2018-06-15 00:58:18 --> Helper loaded: date_helper
INFO - 2018-06-15 00:58:18 --> Helper loaded: util_helper
INFO - 2018-06-15 00:58:18 --> Helper loaded: util_helper
INFO - 2018-06-15 00:58:18 --> Helper loaded: text_helper
INFO - 2018-06-15 00:58:18 --> Helper loaded: text_helper
INFO - 2018-06-15 00:58:18 --> Helper loaded: string_helper
INFO - 2018-06-15 00:58:18 --> Helper loaded: string_helper
INFO - 2018-06-15 00:58:18 --> Database Driver Class Initialized
INFO - 2018-06-15 00:58:18 --> Database Driver Class Initialized
DEBUG - 2018-06-15 00:58:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-06-15 00:58:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-15 00:58:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-15 00:58:18 --> Email Class Initialized
INFO - 2018-06-15 00:58:18 --> Controller Class Initialized
DEBUG - 2018-06-15 00:58:18 --> videos MX_Controller Initialized
INFO - 2018-06-15 00:58:18 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-15 00:58:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-06-15 00:58:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-15 00:58:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-15 00:58:18 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-15 00:58:18 --> Login MX_Controller Initialized
DEBUG - 2018-06-15 00:58:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-15 00:58:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-15 00:58:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-15 00:58:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-15 00:58:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-15 00:58:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-15 00:58:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/videos/videos.php
INFO - 2018-06-15 00:58:18 --> Final output sent to browser
DEBUG - 2018-06-15 00:58:19 --> Total execution time: 0.4261
INFO - 2018-06-15 00:58:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-15 00:58:19 --> Email Class Initialized
INFO - 2018-06-15 00:58:19 --> Controller Class Initialized
DEBUG - 2018-06-15 00:58:19 --> videos MX_Controller Initialized
INFO - 2018-06-15 00:58:19 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-15 00:58:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-06-15 00:58:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-15 00:58:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-15 00:58:19 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-15 00:58:19 --> Login MX_Controller Initialized
DEBUG - 2018-06-15 00:58:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-15 00:58:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-15 00:58:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-15 00:58:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-15 00:58:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
INFO - 2018-06-15 00:58:19 --> Config Class Initialized
INFO - 2018-06-15 00:58:19 --> Hooks Class Initialized
DEBUG - 2018-06-15 00:58:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-15 00:58:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/videos/create_video.php
DEBUG - 2018-06-15 00:58:19 --> UTF-8 Support Enabled
INFO - 2018-06-15 00:58:19 --> Utf8 Class Initialized
INFO - 2018-06-15 00:58:19 --> Final output sent to browser
INFO - 2018-06-15 00:58:19 --> URI Class Initialized
DEBUG - 2018-06-15 00:58:19 --> Total execution time: 0.7862
INFO - 2018-06-15 00:58:19 --> Router Class Initialized
INFO - 2018-06-15 00:58:19 --> Output Class Initialized
INFO - 2018-06-15 00:58:19 --> Security Class Initialized
DEBUG - 2018-06-15 00:58:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-15 00:58:19 --> Input Class Initialized
INFO - 2018-06-15 00:58:19 --> Language Class Initialized
INFO - 2018-06-15 00:58:19 --> Language Class Initialized
INFO - 2018-06-15 00:58:19 --> Config Class Initialized
INFO - 2018-06-15 00:58:19 --> Loader Class Initialized
DEBUG - 2018-06-15 00:58:19 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-15 00:58:19 --> Helper loaded: url_helper
INFO - 2018-06-15 00:58:19 --> Helper loaded: form_helper
INFO - 2018-06-15 00:58:19 --> Helper loaded: date_helper
INFO - 2018-06-15 00:58:19 --> Helper loaded: util_helper
INFO - 2018-06-15 00:58:19 --> Helper loaded: text_helper
INFO - 2018-06-15 00:58:19 --> Helper loaded: string_helper
INFO - 2018-06-15 00:58:19 --> Database Driver Class Initialized
DEBUG - 2018-06-15 00:58:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-15 00:58:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-15 00:58:19 --> Email Class Initialized
INFO - 2018-06-15 00:58:19 --> Controller Class Initialized
DEBUG - 2018-06-15 00:58:19 --> videos MX_Controller Initialized
INFO - 2018-06-15 00:58:19 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-15 00:58:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-06-15 00:58:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-15 00:58:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-15 00:58:19 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-15 00:58:19 --> Login MX_Controller Initialized
DEBUG - 2018-06-15 00:58:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-15 00:58:19 --> Final output sent to browser
DEBUG - 2018-06-15 00:58:19 --> Total execution time: 0.4166
INFO - 2018-06-15 00:58:21 --> Config Class Initialized
INFO - 2018-06-15 00:58:21 --> Hooks Class Initialized
DEBUG - 2018-06-15 00:58:21 --> UTF-8 Support Enabled
INFO - 2018-06-15 00:58:21 --> Utf8 Class Initialized
INFO - 2018-06-15 00:58:21 --> URI Class Initialized
INFO - 2018-06-15 00:58:21 --> Router Class Initialized
INFO - 2018-06-15 00:58:21 --> Output Class Initialized
INFO - 2018-06-15 00:58:21 --> Security Class Initialized
DEBUG - 2018-06-15 00:58:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-15 00:58:21 --> Input Class Initialized
INFO - 2018-06-15 00:58:21 --> Language Class Initialized
INFO - 2018-06-15 00:58:21 --> Language Class Initialized
INFO - 2018-06-15 00:58:21 --> Config Class Initialized
INFO - 2018-06-15 00:58:21 --> Loader Class Initialized
DEBUG - 2018-06-15 00:58:21 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-15 00:58:21 --> Helper loaded: url_helper
INFO - 2018-06-15 00:58:21 --> Helper loaded: form_helper
INFO - 2018-06-15 00:58:21 --> Helper loaded: date_helper
INFO - 2018-06-15 00:58:21 --> Helper loaded: util_helper
INFO - 2018-06-15 00:58:21 --> Helper loaded: text_helper
INFO - 2018-06-15 00:58:21 --> Helper loaded: string_helper
INFO - 2018-06-15 00:58:21 --> Database Driver Class Initialized
DEBUG - 2018-06-15 00:58:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-15 00:58:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-15 00:58:21 --> Email Class Initialized
INFO - 2018-06-15 00:58:21 --> Controller Class Initialized
DEBUG - 2018-06-15 00:58:21 --> videos MX_Controller Initialized
INFO - 2018-06-15 00:58:21 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-15 00:58:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-06-15 00:58:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-15 00:58:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-15 00:58:21 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-15 00:58:21 --> Login MX_Controller Initialized
DEBUG - 2018-06-15 00:58:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-15 00:58:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-15 00:58:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-15 00:58:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-15 00:58:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-15 00:58:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-15 00:58:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/videos/create_video.php
INFO - 2018-06-15 00:58:21 --> Final output sent to browser
DEBUG - 2018-06-15 00:58:21 --> Total execution time: 0.3873
INFO - 2018-06-15 00:58:22 --> Config Class Initialized
INFO - 2018-06-15 00:58:22 --> Hooks Class Initialized
DEBUG - 2018-06-15 00:58:22 --> UTF-8 Support Enabled
INFO - 2018-06-15 00:58:22 --> Utf8 Class Initialized
INFO - 2018-06-15 00:58:22 --> URI Class Initialized
INFO - 2018-06-15 00:58:22 --> Router Class Initialized
INFO - 2018-06-15 00:58:22 --> Output Class Initialized
INFO - 2018-06-15 00:58:22 --> Security Class Initialized
DEBUG - 2018-06-15 00:58:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-15 00:58:22 --> Input Class Initialized
INFO - 2018-06-15 00:58:22 --> Language Class Initialized
ERROR - 2018-06-15 00:58:22 --> 404 Page Not Found: /index
INFO - 2018-06-15 00:58:25 --> Config Class Initialized
INFO - 2018-06-15 00:58:25 --> Hooks Class Initialized
DEBUG - 2018-06-15 00:58:25 --> UTF-8 Support Enabled
INFO - 2018-06-15 00:58:25 --> Utf8 Class Initialized
INFO - 2018-06-15 00:58:25 --> URI Class Initialized
INFO - 2018-06-15 00:58:25 --> Router Class Initialized
INFO - 2018-06-15 00:58:25 --> Output Class Initialized
INFO - 2018-06-15 00:58:25 --> Security Class Initialized
DEBUG - 2018-06-15 00:58:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-15 00:58:25 --> Input Class Initialized
INFO - 2018-06-15 00:58:25 --> Language Class Initialized
INFO - 2018-06-15 00:58:25 --> Language Class Initialized
INFO - 2018-06-15 00:58:25 --> Config Class Initialized
INFO - 2018-06-15 00:58:25 --> Loader Class Initialized
DEBUG - 2018-06-15 00:58:25 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-15 00:58:25 --> Helper loaded: url_helper
INFO - 2018-06-15 00:58:25 --> Helper loaded: form_helper
INFO - 2018-06-15 00:58:25 --> Helper loaded: date_helper
INFO - 2018-06-15 00:58:25 --> Helper loaded: util_helper
INFO - 2018-06-15 00:58:25 --> Helper loaded: text_helper
INFO - 2018-06-15 00:58:25 --> Helper loaded: string_helper
INFO - 2018-06-15 00:58:25 --> Database Driver Class Initialized
DEBUG - 2018-06-15 00:58:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-15 00:58:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-15 00:58:25 --> Email Class Initialized
INFO - 2018-06-15 00:58:25 --> Controller Class Initialized
DEBUG - 2018-06-15 00:58:25 --> videos MX_Controller Initialized
INFO - 2018-06-15 00:58:25 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-15 00:58:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-06-15 00:58:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-15 00:58:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-15 00:58:25 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-15 00:58:25 --> Login MX_Controller Initialized
DEBUG - 2018-06-15 00:58:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-15 00:58:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-15 00:58:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-15 00:58:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-15 00:58:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-15 00:58:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-15 00:58:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/videos/videos.php
INFO - 2018-06-15 00:58:25 --> Final output sent to browser
DEBUG - 2018-06-15 00:58:25 --> Total execution time: 0.3911
INFO - 2018-06-15 00:58:26 --> Config Class Initialized
INFO - 2018-06-15 00:58:26 --> Hooks Class Initialized
DEBUG - 2018-06-15 00:58:26 --> UTF-8 Support Enabled
INFO - 2018-06-15 00:58:26 --> Utf8 Class Initialized
INFO - 2018-06-15 00:58:26 --> URI Class Initialized
INFO - 2018-06-15 00:58:26 --> Router Class Initialized
INFO - 2018-06-15 00:58:26 --> Output Class Initialized
INFO - 2018-06-15 00:58:26 --> Security Class Initialized
DEBUG - 2018-06-15 00:58:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-15 00:58:26 --> Input Class Initialized
INFO - 2018-06-15 00:58:26 --> Language Class Initialized
INFO - 2018-06-15 00:58:26 --> Language Class Initialized
INFO - 2018-06-15 00:58:26 --> Config Class Initialized
INFO - 2018-06-15 00:58:26 --> Loader Class Initialized
DEBUG - 2018-06-15 00:58:26 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-15 00:58:26 --> Helper loaded: url_helper
INFO - 2018-06-15 00:58:26 --> Helper loaded: form_helper
INFO - 2018-06-15 00:58:26 --> Helper loaded: date_helper
INFO - 2018-06-15 00:58:26 --> Helper loaded: util_helper
INFO - 2018-06-15 00:58:26 --> Helper loaded: text_helper
INFO - 2018-06-15 00:58:26 --> Helper loaded: string_helper
INFO - 2018-06-15 00:58:26 --> Database Driver Class Initialized
DEBUG - 2018-06-15 00:58:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-15 00:58:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-15 00:58:26 --> Email Class Initialized
INFO - 2018-06-15 00:58:26 --> Controller Class Initialized
DEBUG - 2018-06-15 00:58:26 --> videos MX_Controller Initialized
INFO - 2018-06-15 00:58:26 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-15 00:58:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-06-15 00:58:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-15 00:58:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-15 00:58:26 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-15 00:58:26 --> Login MX_Controller Initialized
DEBUG - 2018-06-15 00:58:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-15 00:58:26 --> Final output sent to browser
DEBUG - 2018-06-15 00:58:26 --> Total execution time: 0.4226
INFO - 2018-06-15 01:00:17 --> Config Class Initialized
INFO - 2018-06-15 01:00:17 --> Hooks Class Initialized
DEBUG - 2018-06-15 01:00:17 --> UTF-8 Support Enabled
INFO - 2018-06-15 01:00:17 --> Utf8 Class Initialized
INFO - 2018-06-15 01:00:17 --> URI Class Initialized
INFO - 2018-06-15 01:00:17 --> Router Class Initialized
INFO - 2018-06-15 01:00:17 --> Output Class Initialized
INFO - 2018-06-15 01:00:17 --> Security Class Initialized
DEBUG - 2018-06-15 01:00:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-15 01:00:17 --> Input Class Initialized
INFO - 2018-06-15 01:00:17 --> Language Class Initialized
INFO - 2018-06-15 01:00:17 --> Language Class Initialized
INFO - 2018-06-15 01:00:17 --> Config Class Initialized
INFO - 2018-06-15 01:00:17 --> Loader Class Initialized
DEBUG - 2018-06-15 01:00:17 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-15 01:00:17 --> Helper loaded: url_helper
INFO - 2018-06-15 01:00:17 --> Helper loaded: form_helper
INFO - 2018-06-15 01:00:17 --> Helper loaded: date_helper
INFO - 2018-06-15 01:00:17 --> Helper loaded: util_helper
INFO - 2018-06-15 01:00:17 --> Helper loaded: text_helper
INFO - 2018-06-15 01:00:17 --> Helper loaded: string_helper
INFO - 2018-06-15 01:00:17 --> Database Driver Class Initialized
DEBUG - 2018-06-15 01:00:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-15 01:00:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-15 01:00:18 --> Email Class Initialized
INFO - 2018-06-15 01:00:18 --> Controller Class Initialized
DEBUG - 2018-06-15 01:00:18 --> Admin MX_Controller Initialized
INFO - 2018-06-15 01:00:18 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-15 01:00:18 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-15 01:00:18 --> Login MX_Controller Initialized
DEBUG - 2018-06-15 01:00:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-15 01:00:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-15 01:00:18 --> Final output sent to browser
DEBUG - 2018-06-15 01:00:18 --> Total execution time: 0.4468
INFO - 2018-06-15 01:00:18 --> Config Class Initialized
INFO - 2018-06-15 01:00:18 --> Hooks Class Initialized
DEBUG - 2018-06-15 01:00:18 --> UTF-8 Support Enabled
INFO - 2018-06-15 01:00:18 --> Utf8 Class Initialized
INFO - 2018-06-15 01:00:18 --> URI Class Initialized
INFO - 2018-06-15 01:00:18 --> Router Class Initialized
INFO - 2018-06-15 01:00:18 --> Output Class Initialized
INFO - 2018-06-15 01:00:18 --> Security Class Initialized
DEBUG - 2018-06-15 01:00:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-15 01:00:18 --> Input Class Initialized
INFO - 2018-06-15 01:00:18 --> Language Class Initialized
INFO - 2018-06-15 01:00:18 --> Language Class Initialized
INFO - 2018-06-15 01:00:18 --> Config Class Initialized
INFO - 2018-06-15 01:00:18 --> Loader Class Initialized
DEBUG - 2018-06-15 01:00:18 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-15 01:00:18 --> Helper loaded: url_helper
INFO - 2018-06-15 01:00:18 --> Helper loaded: form_helper
INFO - 2018-06-15 01:00:18 --> Helper loaded: date_helper
INFO - 2018-06-15 01:00:18 --> Helper loaded: util_helper
INFO - 2018-06-15 01:00:18 --> Helper loaded: text_helper
INFO - 2018-06-15 01:00:18 --> Helper loaded: string_helper
INFO - 2018-06-15 01:00:18 --> Database Driver Class Initialized
DEBUG - 2018-06-15 01:00:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-15 01:00:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-15 01:00:18 --> Email Class Initialized
INFO - 2018-06-15 01:00:18 --> Controller Class Initialized
DEBUG - 2018-06-15 01:00:18 --> Admin MX_Controller Initialized
INFO - 2018-06-15 01:00:18 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-15 01:00:18 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-15 01:00:18 --> Login MX_Controller Initialized
DEBUG - 2018-06-15 01:00:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-15 01:00:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-15 01:00:19 --> Final output sent to browser
DEBUG - 2018-06-15 01:00:19 --> Total execution time: 0.3860
INFO - 2018-06-15 01:01:40 --> Config Class Initialized
INFO - 2018-06-15 01:01:40 --> Hooks Class Initialized
DEBUG - 2018-06-15 01:01:40 --> UTF-8 Support Enabled
INFO - 2018-06-15 01:01:40 --> Utf8 Class Initialized
INFO - 2018-06-15 01:01:40 --> URI Class Initialized
INFO - 2018-06-15 01:01:40 --> Router Class Initialized
INFO - 2018-06-15 01:01:40 --> Output Class Initialized
INFO - 2018-06-15 01:01:40 --> Security Class Initialized
DEBUG - 2018-06-15 01:01:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-15 01:01:40 --> Input Class Initialized
INFO - 2018-06-15 01:01:40 --> Language Class Initialized
INFO - 2018-06-15 01:01:40 --> Language Class Initialized
INFO - 2018-06-15 01:01:40 --> Config Class Initialized
INFO - 2018-06-15 01:01:40 --> Loader Class Initialized
DEBUG - 2018-06-15 01:01:40 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-15 01:01:40 --> Helper loaded: url_helper
INFO - 2018-06-15 01:01:40 --> Helper loaded: form_helper
INFO - 2018-06-15 01:01:40 --> Helper loaded: date_helper
INFO - 2018-06-15 01:01:40 --> Helper loaded: util_helper
INFO - 2018-06-15 01:01:40 --> Helper loaded: text_helper
INFO - 2018-06-15 01:01:40 --> Helper loaded: string_helper
INFO - 2018-06-15 01:01:40 --> Database Driver Class Initialized
DEBUG - 2018-06-15 01:01:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-15 01:01:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-15 01:01:40 --> Email Class Initialized
INFO - 2018-06-15 01:01:40 --> Controller Class Initialized
DEBUG - 2018-06-15 01:01:40 --> Admin MX_Controller Initialized
INFO - 2018-06-15 01:01:40 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-15 01:01:40 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-15 01:01:40 --> Login MX_Controller Initialized
DEBUG - 2018-06-15 01:01:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-15 01:01:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-15 01:01:40 --> Final output sent to browser
DEBUG - 2018-06-15 01:01:40 --> Total execution time: 0.4053
INFO - 2018-06-15 01:01:41 --> Config Class Initialized
INFO - 2018-06-15 01:01:41 --> Hooks Class Initialized
DEBUG - 2018-06-15 01:01:41 --> UTF-8 Support Enabled
INFO - 2018-06-15 01:01:41 --> Utf8 Class Initialized
INFO - 2018-06-15 01:01:41 --> URI Class Initialized
INFO - 2018-06-15 01:01:41 --> Router Class Initialized
INFO - 2018-06-15 01:01:41 --> Output Class Initialized
INFO - 2018-06-15 01:01:41 --> Security Class Initialized
DEBUG - 2018-06-15 01:01:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-15 01:01:41 --> Input Class Initialized
INFO - 2018-06-15 01:01:41 --> Language Class Initialized
INFO - 2018-06-15 01:01:41 --> Language Class Initialized
INFO - 2018-06-15 01:01:41 --> Config Class Initialized
INFO - 2018-06-15 01:01:41 --> Loader Class Initialized
DEBUG - 2018-06-15 01:01:41 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-15 01:01:41 --> Helper loaded: url_helper
INFO - 2018-06-15 01:01:41 --> Helper loaded: form_helper
INFO - 2018-06-15 01:01:41 --> Helper loaded: date_helper
INFO - 2018-06-15 01:01:41 --> Helper loaded: util_helper
INFO - 2018-06-15 01:01:41 --> Helper loaded: text_helper
INFO - 2018-06-15 01:01:41 --> Helper loaded: string_helper
INFO - 2018-06-15 01:01:41 --> Database Driver Class Initialized
DEBUG - 2018-06-15 01:01:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-15 01:01:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-15 01:01:41 --> Email Class Initialized
INFO - 2018-06-15 01:01:41 --> Controller Class Initialized
DEBUG - 2018-06-15 01:01:41 --> Admin MX_Controller Initialized
INFO - 2018-06-15 01:01:41 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-15 01:01:41 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-15 01:01:41 --> Login MX_Controller Initialized
DEBUG - 2018-06-15 01:01:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-15 01:01:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-15 01:01:41 --> Final output sent to browser
DEBUG - 2018-06-15 01:01:41 --> Total execution time: 0.3675
INFO - 2018-06-15 01:01:45 --> Config Class Initialized
INFO - 2018-06-15 01:01:45 --> Hooks Class Initialized
DEBUG - 2018-06-15 01:01:45 --> UTF-8 Support Enabled
INFO - 2018-06-15 01:01:45 --> Utf8 Class Initialized
INFO - 2018-06-15 01:01:45 --> URI Class Initialized
INFO - 2018-06-15 01:01:45 --> Router Class Initialized
INFO - 2018-06-15 01:01:45 --> Output Class Initialized
INFO - 2018-06-15 01:01:45 --> Security Class Initialized
DEBUG - 2018-06-15 01:01:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-15 01:01:45 --> Input Class Initialized
INFO - 2018-06-15 01:01:45 --> Language Class Initialized
INFO - 2018-06-15 01:01:45 --> Language Class Initialized
INFO - 2018-06-15 01:01:45 --> Config Class Initialized
INFO - 2018-06-15 01:01:45 --> Loader Class Initialized
DEBUG - 2018-06-15 01:01:45 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-15 01:01:45 --> Helper loaded: url_helper
INFO - 2018-06-15 01:01:45 --> Helper loaded: form_helper
INFO - 2018-06-15 01:01:45 --> Helper loaded: date_helper
INFO - 2018-06-15 01:01:45 --> Helper loaded: util_helper
INFO - 2018-06-15 01:01:45 --> Helper loaded: text_helper
INFO - 2018-06-15 01:01:45 --> Helper loaded: string_helper
INFO - 2018-06-15 01:01:45 --> Database Driver Class Initialized
DEBUG - 2018-06-15 01:01:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-15 01:01:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-15 01:01:45 --> Email Class Initialized
INFO - 2018-06-15 01:01:45 --> Controller Class Initialized
DEBUG - 2018-06-15 01:01:45 --> Admin MX_Controller Initialized
INFO - 2018-06-15 01:01:45 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-15 01:01:45 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-15 01:01:45 --> Login MX_Controller Initialized
DEBUG - 2018-06-15 01:01:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-15 01:01:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-15 01:01:45 --> Final output sent to browser
DEBUG - 2018-06-15 01:01:45 --> Total execution time: 0.3948
INFO - 2018-06-15 01:01:46 --> Config Class Initialized
INFO - 2018-06-15 01:01:46 --> Hooks Class Initialized
DEBUG - 2018-06-15 01:01:46 --> UTF-8 Support Enabled
INFO - 2018-06-15 01:01:46 --> Utf8 Class Initialized
INFO - 2018-06-15 01:01:46 --> URI Class Initialized
INFO - 2018-06-15 01:01:46 --> Router Class Initialized
INFO - 2018-06-15 01:01:46 --> Output Class Initialized
INFO - 2018-06-15 01:01:46 --> Security Class Initialized
DEBUG - 2018-06-15 01:01:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-15 01:01:46 --> Input Class Initialized
INFO - 2018-06-15 01:01:46 --> Language Class Initialized
INFO - 2018-06-15 01:01:46 --> Language Class Initialized
INFO - 2018-06-15 01:01:46 --> Config Class Initialized
INFO - 2018-06-15 01:01:46 --> Loader Class Initialized
DEBUG - 2018-06-15 01:01:46 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-15 01:01:46 --> Helper loaded: url_helper
INFO - 2018-06-15 01:01:46 --> Helper loaded: form_helper
INFO - 2018-06-15 01:01:46 --> Helper loaded: date_helper
INFO - 2018-06-15 01:01:46 --> Helper loaded: util_helper
INFO - 2018-06-15 01:01:46 --> Helper loaded: text_helper
INFO - 2018-06-15 01:01:46 --> Helper loaded: string_helper
INFO - 2018-06-15 01:01:46 --> Database Driver Class Initialized
DEBUG - 2018-06-15 01:01:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-15 01:01:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-15 01:01:46 --> Email Class Initialized
INFO - 2018-06-15 01:01:46 --> Controller Class Initialized
DEBUG - 2018-06-15 01:01:46 --> Admin MX_Controller Initialized
INFO - 2018-06-15 01:01:46 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-15 01:01:46 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-15 01:01:46 --> Login MX_Controller Initialized
DEBUG - 2018-06-15 01:01:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-15 01:01:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-15 01:01:46 --> Final output sent to browser
DEBUG - 2018-06-15 01:01:46 --> Total execution time: 0.3821
INFO - 2018-06-15 01:02:02 --> Config Class Initialized
INFO - 2018-06-15 01:02:02 --> Hooks Class Initialized
DEBUG - 2018-06-15 01:02:02 --> UTF-8 Support Enabled
INFO - 2018-06-15 01:02:02 --> Utf8 Class Initialized
INFO - 2018-06-15 01:02:02 --> URI Class Initialized
INFO - 2018-06-15 01:02:02 --> Router Class Initialized
INFO - 2018-06-15 01:02:02 --> Output Class Initialized
INFO - 2018-06-15 01:02:02 --> Security Class Initialized
DEBUG - 2018-06-15 01:02:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-15 01:02:02 --> Input Class Initialized
INFO - 2018-06-15 01:02:02 --> Language Class Initialized
INFO - 2018-06-15 01:02:02 --> Language Class Initialized
INFO - 2018-06-15 01:02:02 --> Config Class Initialized
INFO - 2018-06-15 01:02:02 --> Loader Class Initialized
DEBUG - 2018-06-15 01:02:02 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-15 01:02:02 --> Helper loaded: url_helper
INFO - 2018-06-15 01:02:02 --> Helper loaded: form_helper
INFO - 2018-06-15 01:02:02 --> Helper loaded: date_helper
INFO - 2018-06-15 01:02:02 --> Helper loaded: util_helper
INFO - 2018-06-15 01:02:02 --> Helper loaded: text_helper
INFO - 2018-06-15 01:02:02 --> Helper loaded: string_helper
INFO - 2018-06-15 01:02:02 --> Database Driver Class Initialized
DEBUG - 2018-06-15 01:02:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-15 01:02:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-15 01:02:02 --> Email Class Initialized
INFO - 2018-06-15 01:02:02 --> Controller Class Initialized
DEBUG - 2018-06-15 01:02:02 --> Admin MX_Controller Initialized
INFO - 2018-06-15 01:02:02 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-15 01:02:02 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-15 01:02:02 --> Login MX_Controller Initialized
DEBUG - 2018-06-15 01:02:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-15 01:02:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-15 01:02:02 --> Final output sent to browser
DEBUG - 2018-06-15 01:02:02 --> Total execution time: 0.4351
INFO - 2018-06-15 01:02:03 --> Config Class Initialized
INFO - 2018-06-15 01:02:03 --> Hooks Class Initialized
DEBUG - 2018-06-15 01:02:03 --> UTF-8 Support Enabled
INFO - 2018-06-15 01:02:03 --> Utf8 Class Initialized
INFO - 2018-06-15 01:02:03 --> URI Class Initialized
INFO - 2018-06-15 01:02:03 --> Router Class Initialized
INFO - 2018-06-15 01:02:03 --> Output Class Initialized
INFO - 2018-06-15 01:02:03 --> Security Class Initialized
DEBUG - 2018-06-15 01:02:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-15 01:02:03 --> Input Class Initialized
INFO - 2018-06-15 01:02:03 --> Language Class Initialized
INFO - 2018-06-15 01:02:03 --> Language Class Initialized
INFO - 2018-06-15 01:02:03 --> Config Class Initialized
INFO - 2018-06-15 01:02:03 --> Loader Class Initialized
DEBUG - 2018-06-15 01:02:03 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-15 01:02:03 --> Helper loaded: url_helper
INFO - 2018-06-15 01:02:03 --> Helper loaded: form_helper
INFO - 2018-06-15 01:02:03 --> Helper loaded: date_helper
INFO - 2018-06-15 01:02:03 --> Helper loaded: util_helper
INFO - 2018-06-15 01:02:03 --> Helper loaded: text_helper
INFO - 2018-06-15 01:02:03 --> Helper loaded: string_helper
INFO - 2018-06-15 01:02:03 --> Database Driver Class Initialized
DEBUG - 2018-06-15 01:02:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-15 01:02:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-15 01:02:03 --> Email Class Initialized
INFO - 2018-06-15 01:02:03 --> Controller Class Initialized
DEBUG - 2018-06-15 01:02:03 --> Admin MX_Controller Initialized
INFO - 2018-06-15 01:02:03 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-15 01:02:03 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-15 01:02:03 --> Login MX_Controller Initialized
DEBUG - 2018-06-15 01:02:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-15 01:02:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-15 01:02:03 --> Final output sent to browser
DEBUG - 2018-06-15 01:02:03 --> Total execution time: 0.3979
INFO - 2018-06-15 01:02:08 --> Config Class Initialized
INFO - 2018-06-15 01:02:08 --> Hooks Class Initialized
DEBUG - 2018-06-15 01:02:08 --> UTF-8 Support Enabled
INFO - 2018-06-15 01:02:08 --> Utf8 Class Initialized
INFO - 2018-06-15 01:02:08 --> URI Class Initialized
INFO - 2018-06-15 01:02:08 --> Router Class Initialized
INFO - 2018-06-15 01:02:08 --> Output Class Initialized
INFO - 2018-06-15 01:02:08 --> Security Class Initialized
DEBUG - 2018-06-15 01:02:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-15 01:02:08 --> Input Class Initialized
INFO - 2018-06-15 01:02:08 --> Language Class Initialized
INFO - 2018-06-15 01:02:08 --> Language Class Initialized
INFO - 2018-06-15 01:02:08 --> Config Class Initialized
INFO - 2018-06-15 01:02:08 --> Loader Class Initialized
DEBUG - 2018-06-15 01:02:08 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-15 01:02:08 --> Helper loaded: url_helper
INFO - 2018-06-15 01:02:08 --> Helper loaded: form_helper
INFO - 2018-06-15 01:02:08 --> Helper loaded: date_helper
INFO - 2018-06-15 01:02:08 --> Helper loaded: util_helper
INFO - 2018-06-15 01:02:08 --> Helper loaded: text_helper
INFO - 2018-06-15 01:02:08 --> Helper loaded: string_helper
INFO - 2018-06-15 01:02:08 --> Database Driver Class Initialized
DEBUG - 2018-06-15 01:02:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-15 01:02:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-15 01:02:08 --> Email Class Initialized
INFO - 2018-06-15 01:02:08 --> Controller Class Initialized
DEBUG - 2018-06-15 01:02:08 --> Admin MX_Controller Initialized
INFO - 2018-06-15 01:02:08 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-15 01:02:08 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-15 01:02:08 --> Login MX_Controller Initialized
DEBUG - 2018-06-15 01:02:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-15 01:02:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-15 01:02:08 --> Final output sent to browser
DEBUG - 2018-06-15 01:02:08 --> Total execution time: 0.3986
INFO - 2018-06-15 01:02:08 --> Config Class Initialized
INFO - 2018-06-15 01:02:08 --> Hooks Class Initialized
DEBUG - 2018-06-15 01:02:08 --> UTF-8 Support Enabled
INFO - 2018-06-15 01:02:08 --> Utf8 Class Initialized
INFO - 2018-06-15 01:02:08 --> URI Class Initialized
INFO - 2018-06-15 01:02:08 --> Router Class Initialized
INFO - 2018-06-15 01:02:08 --> Output Class Initialized
INFO - 2018-06-15 01:02:09 --> Security Class Initialized
DEBUG - 2018-06-15 01:02:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-15 01:02:09 --> Input Class Initialized
INFO - 2018-06-15 01:02:09 --> Language Class Initialized
INFO - 2018-06-15 01:02:09 --> Language Class Initialized
INFO - 2018-06-15 01:02:09 --> Config Class Initialized
INFO - 2018-06-15 01:02:09 --> Loader Class Initialized
DEBUG - 2018-06-15 01:02:09 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-15 01:02:09 --> Helper loaded: url_helper
INFO - 2018-06-15 01:02:09 --> Helper loaded: form_helper
INFO - 2018-06-15 01:02:09 --> Helper loaded: date_helper
INFO - 2018-06-15 01:02:09 --> Helper loaded: util_helper
INFO - 2018-06-15 01:02:09 --> Helper loaded: text_helper
INFO - 2018-06-15 01:02:09 --> Helper loaded: string_helper
INFO - 2018-06-15 01:02:09 --> Database Driver Class Initialized
DEBUG - 2018-06-15 01:02:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-15 01:02:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-15 01:02:09 --> Email Class Initialized
INFO - 2018-06-15 01:02:09 --> Controller Class Initialized
DEBUG - 2018-06-15 01:02:09 --> Admin MX_Controller Initialized
INFO - 2018-06-15 01:02:09 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-15 01:02:09 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-15 01:02:09 --> Login MX_Controller Initialized
DEBUG - 2018-06-15 01:02:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-15 01:02:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-15 01:02:09 --> Final output sent to browser
DEBUG - 2018-06-15 01:02:09 --> Total execution time: 0.4041
INFO - 2018-06-15 01:02:57 --> Config Class Initialized
INFO - 2018-06-15 01:02:57 --> Hooks Class Initialized
DEBUG - 2018-06-15 01:02:57 --> UTF-8 Support Enabled
INFO - 2018-06-15 01:02:57 --> Utf8 Class Initialized
INFO - 2018-06-15 01:02:57 --> URI Class Initialized
INFO - 2018-06-15 01:02:57 --> Router Class Initialized
INFO - 2018-06-15 01:02:57 --> Output Class Initialized
INFO - 2018-06-15 01:02:57 --> Security Class Initialized
DEBUG - 2018-06-15 01:02:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-15 01:02:57 --> Input Class Initialized
INFO - 2018-06-15 01:02:57 --> Language Class Initialized
INFO - 2018-06-15 01:02:57 --> Language Class Initialized
INFO - 2018-06-15 01:02:57 --> Config Class Initialized
INFO - 2018-06-15 01:02:57 --> Loader Class Initialized
DEBUG - 2018-06-15 01:02:57 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-15 01:02:57 --> Helper loaded: url_helper
INFO - 2018-06-15 01:02:57 --> Helper loaded: form_helper
INFO - 2018-06-15 01:02:57 --> Helper loaded: date_helper
INFO - 2018-06-15 01:02:57 --> Helper loaded: util_helper
INFO - 2018-06-15 01:02:57 --> Helper loaded: text_helper
INFO - 2018-06-15 01:02:57 --> Helper loaded: string_helper
INFO - 2018-06-15 01:02:57 --> Database Driver Class Initialized
DEBUG - 2018-06-15 01:02:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-15 01:02:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-15 01:02:57 --> Email Class Initialized
INFO - 2018-06-15 01:02:57 --> Controller Class Initialized
DEBUG - 2018-06-15 01:02:57 --> Admin MX_Controller Initialized
INFO - 2018-06-15 01:02:57 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-15 01:02:57 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-15 01:02:57 --> Login MX_Controller Initialized
DEBUG - 2018-06-15 01:02:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-15 01:02:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-15 01:02:57 --> Final output sent to browser
DEBUG - 2018-06-15 01:02:57 --> Total execution time: 0.4038
INFO - 2018-06-15 01:02:58 --> Config Class Initialized
INFO - 2018-06-15 01:02:58 --> Hooks Class Initialized
DEBUG - 2018-06-15 01:02:58 --> UTF-8 Support Enabled
INFO - 2018-06-15 01:02:58 --> Utf8 Class Initialized
INFO - 2018-06-15 01:02:58 --> URI Class Initialized
INFO - 2018-06-15 01:02:58 --> Router Class Initialized
INFO - 2018-06-15 01:02:58 --> Output Class Initialized
INFO - 2018-06-15 01:02:58 --> Security Class Initialized
DEBUG - 2018-06-15 01:02:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-15 01:02:58 --> Input Class Initialized
INFO - 2018-06-15 01:02:58 --> Language Class Initialized
INFO - 2018-06-15 01:02:58 --> Language Class Initialized
INFO - 2018-06-15 01:02:58 --> Config Class Initialized
INFO - 2018-06-15 01:02:58 --> Loader Class Initialized
DEBUG - 2018-06-15 01:02:58 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-15 01:02:58 --> Helper loaded: url_helper
INFO - 2018-06-15 01:02:58 --> Helper loaded: form_helper
INFO - 2018-06-15 01:02:58 --> Helper loaded: date_helper
INFO - 2018-06-15 01:02:58 --> Helper loaded: util_helper
INFO - 2018-06-15 01:02:58 --> Helper loaded: text_helper
INFO - 2018-06-15 01:02:58 --> Helper loaded: string_helper
INFO - 2018-06-15 01:02:58 --> Database Driver Class Initialized
DEBUG - 2018-06-15 01:02:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-15 01:02:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-15 01:02:58 --> Email Class Initialized
INFO - 2018-06-15 01:02:58 --> Controller Class Initialized
DEBUG - 2018-06-15 01:02:58 --> Admin MX_Controller Initialized
INFO - 2018-06-15 01:02:58 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-15 01:02:58 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-15 01:02:58 --> Login MX_Controller Initialized
DEBUG - 2018-06-15 01:02:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-15 01:02:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-15 01:02:58 --> Final output sent to browser
DEBUG - 2018-06-15 01:02:58 --> Total execution time: 0.3978
INFO - 2018-06-15 01:03:00 --> Config Class Initialized
INFO - 2018-06-15 01:03:00 --> Hooks Class Initialized
DEBUG - 2018-06-15 01:03:00 --> UTF-8 Support Enabled
INFO - 2018-06-15 01:03:00 --> Utf8 Class Initialized
INFO - 2018-06-15 01:03:00 --> URI Class Initialized
INFO - 2018-06-15 01:03:00 --> Router Class Initialized
INFO - 2018-06-15 01:03:00 --> Output Class Initialized
INFO - 2018-06-15 01:03:00 --> Security Class Initialized
DEBUG - 2018-06-15 01:03:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-15 01:03:00 --> Input Class Initialized
INFO - 2018-06-15 01:03:00 --> Language Class Initialized
INFO - 2018-06-15 01:03:00 --> Language Class Initialized
INFO - 2018-06-15 01:03:00 --> Config Class Initialized
INFO - 2018-06-15 01:03:00 --> Loader Class Initialized
DEBUG - 2018-06-15 01:03:00 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-15 01:03:00 --> Helper loaded: url_helper
INFO - 2018-06-15 01:03:00 --> Helper loaded: form_helper
INFO - 2018-06-15 01:03:00 --> Helper loaded: date_helper
INFO - 2018-06-15 01:03:00 --> Helper loaded: util_helper
INFO - 2018-06-15 01:03:00 --> Helper loaded: text_helper
INFO - 2018-06-15 01:03:00 --> Helper loaded: string_helper
INFO - 2018-06-15 01:03:00 --> Database Driver Class Initialized
DEBUG - 2018-06-15 01:03:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-15 01:03:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-15 01:03:00 --> Email Class Initialized
INFO - 2018-06-15 01:03:00 --> Controller Class Initialized
DEBUG - 2018-06-15 01:03:00 --> Admin MX_Controller Initialized
INFO - 2018-06-15 01:03:00 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-15 01:03:00 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-15 01:03:00 --> Login MX_Controller Initialized
DEBUG - 2018-06-15 01:03:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-15 01:03:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-15 01:03:00 --> Final output sent to browser
DEBUG - 2018-06-15 01:03:00 --> Total execution time: 0.3862
INFO - 2018-06-15 01:03:00 --> Config Class Initialized
INFO - 2018-06-15 01:03:00 --> Hooks Class Initialized
DEBUG - 2018-06-15 01:03:01 --> UTF-8 Support Enabled
INFO - 2018-06-15 01:03:01 --> Utf8 Class Initialized
INFO - 2018-06-15 01:03:01 --> URI Class Initialized
INFO - 2018-06-15 01:03:01 --> Router Class Initialized
INFO - 2018-06-15 01:03:01 --> Output Class Initialized
INFO - 2018-06-15 01:03:01 --> Security Class Initialized
DEBUG - 2018-06-15 01:03:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-15 01:03:01 --> Input Class Initialized
INFO - 2018-06-15 01:03:01 --> Language Class Initialized
INFO - 2018-06-15 01:03:01 --> Language Class Initialized
INFO - 2018-06-15 01:03:01 --> Config Class Initialized
INFO - 2018-06-15 01:03:01 --> Loader Class Initialized
DEBUG - 2018-06-15 01:03:01 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-15 01:03:01 --> Helper loaded: url_helper
INFO - 2018-06-15 01:03:01 --> Helper loaded: form_helper
INFO - 2018-06-15 01:03:01 --> Helper loaded: date_helper
INFO - 2018-06-15 01:03:01 --> Helper loaded: util_helper
INFO - 2018-06-15 01:03:01 --> Helper loaded: text_helper
INFO - 2018-06-15 01:03:01 --> Helper loaded: string_helper
INFO - 2018-06-15 01:03:01 --> Database Driver Class Initialized
DEBUG - 2018-06-15 01:03:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-15 01:03:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-15 01:03:01 --> Email Class Initialized
INFO - 2018-06-15 01:03:01 --> Controller Class Initialized
DEBUG - 2018-06-15 01:03:01 --> Admin MX_Controller Initialized
INFO - 2018-06-15 01:03:01 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-15 01:03:01 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-15 01:03:01 --> Login MX_Controller Initialized
DEBUG - 2018-06-15 01:03:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-15 01:03:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-15 01:03:01 --> Final output sent to browser
DEBUG - 2018-06-15 01:03:01 --> Total execution time: 0.3852
INFO - 2018-06-15 01:03:36 --> Config Class Initialized
INFO - 2018-06-15 01:03:36 --> Hooks Class Initialized
DEBUG - 2018-06-15 01:03:36 --> UTF-8 Support Enabled
INFO - 2018-06-15 01:03:36 --> Utf8 Class Initialized
INFO - 2018-06-15 01:03:36 --> URI Class Initialized
INFO - 2018-06-15 01:03:36 --> Router Class Initialized
INFO - 2018-06-15 01:03:36 --> Output Class Initialized
INFO - 2018-06-15 01:03:36 --> Security Class Initialized
DEBUG - 2018-06-15 01:03:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-15 01:03:36 --> Input Class Initialized
INFO - 2018-06-15 01:03:36 --> Language Class Initialized
INFO - 2018-06-15 01:03:36 --> Language Class Initialized
INFO - 2018-06-15 01:03:36 --> Config Class Initialized
INFO - 2018-06-15 01:03:36 --> Loader Class Initialized
DEBUG - 2018-06-15 01:03:36 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-15 01:03:36 --> Helper loaded: url_helper
INFO - 2018-06-15 01:03:36 --> Helper loaded: form_helper
INFO - 2018-06-15 01:03:36 --> Helper loaded: date_helper
INFO - 2018-06-15 01:03:36 --> Helper loaded: util_helper
INFO - 2018-06-15 01:03:36 --> Helper loaded: text_helper
INFO - 2018-06-15 01:03:36 --> Helper loaded: string_helper
INFO - 2018-06-15 01:03:36 --> Database Driver Class Initialized
DEBUG - 2018-06-15 01:03:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-15 01:03:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-15 01:03:36 --> Email Class Initialized
INFO - 2018-06-15 01:03:36 --> Controller Class Initialized
DEBUG - 2018-06-15 01:03:36 --> Admin MX_Controller Initialized
INFO - 2018-06-15 01:03:36 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-15 01:03:36 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-15 01:03:36 --> Login MX_Controller Initialized
DEBUG - 2018-06-15 01:03:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-15 01:03:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-15 01:03:36 --> Final output sent to browser
DEBUG - 2018-06-15 01:03:36 --> Total execution time: 0.4051
INFO - 2018-06-15 01:03:37 --> Config Class Initialized
INFO - 2018-06-15 01:03:37 --> Hooks Class Initialized
DEBUG - 2018-06-15 01:03:37 --> UTF-8 Support Enabled
INFO - 2018-06-15 01:03:37 --> Utf8 Class Initialized
INFO - 2018-06-15 01:03:37 --> URI Class Initialized
INFO - 2018-06-15 01:03:37 --> Router Class Initialized
INFO - 2018-06-15 01:03:37 --> Output Class Initialized
INFO - 2018-06-15 01:03:37 --> Security Class Initialized
DEBUG - 2018-06-15 01:03:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-15 01:03:37 --> Input Class Initialized
INFO - 2018-06-15 01:03:37 --> Language Class Initialized
INFO - 2018-06-15 01:03:37 --> Language Class Initialized
INFO - 2018-06-15 01:03:37 --> Config Class Initialized
INFO - 2018-06-15 01:03:37 --> Loader Class Initialized
DEBUG - 2018-06-15 01:03:37 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-15 01:03:37 --> Helper loaded: url_helper
INFO - 2018-06-15 01:03:37 --> Helper loaded: form_helper
INFO - 2018-06-15 01:03:37 --> Helper loaded: date_helper
INFO - 2018-06-15 01:03:37 --> Helper loaded: util_helper
INFO - 2018-06-15 01:03:37 --> Helper loaded: text_helper
INFO - 2018-06-15 01:03:37 --> Helper loaded: string_helper
INFO - 2018-06-15 01:03:37 --> Database Driver Class Initialized
DEBUG - 2018-06-15 01:03:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-15 01:03:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-15 01:03:37 --> Email Class Initialized
INFO - 2018-06-15 01:03:37 --> Controller Class Initialized
DEBUG - 2018-06-15 01:03:37 --> Admin MX_Controller Initialized
INFO - 2018-06-15 01:03:37 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-15 01:03:37 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-15 01:03:37 --> Login MX_Controller Initialized
DEBUG - 2018-06-15 01:03:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-15 01:03:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-15 01:03:37 --> Final output sent to browser
DEBUG - 2018-06-15 01:03:37 --> Total execution time: 0.3974
INFO - 2018-06-15 01:03:38 --> Config Class Initialized
INFO - 2018-06-15 01:03:38 --> Hooks Class Initialized
DEBUG - 2018-06-15 01:03:38 --> UTF-8 Support Enabled
INFO - 2018-06-15 01:03:38 --> Utf8 Class Initialized
INFO - 2018-06-15 01:03:38 --> URI Class Initialized
INFO - 2018-06-15 01:03:38 --> Router Class Initialized
INFO - 2018-06-15 01:03:38 --> Output Class Initialized
INFO - 2018-06-15 01:03:38 --> Security Class Initialized
DEBUG - 2018-06-15 01:03:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-15 01:03:38 --> Input Class Initialized
INFO - 2018-06-15 01:03:38 --> Language Class Initialized
INFO - 2018-06-15 01:03:38 --> Language Class Initialized
INFO - 2018-06-15 01:03:38 --> Config Class Initialized
INFO - 2018-06-15 01:03:38 --> Loader Class Initialized
DEBUG - 2018-06-15 01:03:38 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-15 01:03:38 --> Helper loaded: url_helper
INFO - 2018-06-15 01:03:38 --> Helper loaded: form_helper
INFO - 2018-06-15 01:03:38 --> Helper loaded: date_helper
INFO - 2018-06-15 01:03:38 --> Helper loaded: util_helper
INFO - 2018-06-15 01:03:39 --> Helper loaded: text_helper
INFO - 2018-06-15 01:03:39 --> Helper loaded: string_helper
INFO - 2018-06-15 01:03:39 --> Database Driver Class Initialized
DEBUG - 2018-06-15 01:03:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-15 01:03:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-15 01:03:39 --> Email Class Initialized
INFO - 2018-06-15 01:03:39 --> Controller Class Initialized
DEBUG - 2018-06-15 01:03:39 --> Admin MX_Controller Initialized
INFO - 2018-06-15 01:03:39 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-15 01:03:39 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-15 01:03:39 --> Login MX_Controller Initialized
DEBUG - 2018-06-15 01:03:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-15 01:03:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-15 01:03:39 --> Final output sent to browser
DEBUG - 2018-06-15 01:03:39 --> Total execution time: 0.4723
INFO - 2018-06-15 01:03:39 --> Config Class Initialized
INFO - 2018-06-15 01:03:39 --> Hooks Class Initialized
DEBUG - 2018-06-15 01:03:39 --> UTF-8 Support Enabled
INFO - 2018-06-15 01:03:40 --> Utf8 Class Initialized
INFO - 2018-06-15 01:03:40 --> URI Class Initialized
INFO - 2018-06-15 01:03:40 --> Router Class Initialized
INFO - 2018-06-15 01:03:40 --> Output Class Initialized
INFO - 2018-06-15 01:03:40 --> Security Class Initialized
DEBUG - 2018-06-15 01:03:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-15 01:03:40 --> Input Class Initialized
INFO - 2018-06-15 01:03:40 --> Language Class Initialized
INFO - 2018-06-15 01:03:40 --> Language Class Initialized
INFO - 2018-06-15 01:03:40 --> Config Class Initialized
INFO - 2018-06-15 01:03:40 --> Loader Class Initialized
DEBUG - 2018-06-15 01:03:40 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-15 01:03:40 --> Helper loaded: url_helper
INFO - 2018-06-15 01:03:40 --> Helper loaded: form_helper
INFO - 2018-06-15 01:03:40 --> Helper loaded: date_helper
INFO - 2018-06-15 01:03:40 --> Helper loaded: util_helper
INFO - 2018-06-15 01:03:40 --> Helper loaded: text_helper
INFO - 2018-06-15 01:03:40 --> Helper loaded: string_helper
INFO - 2018-06-15 01:03:40 --> Database Driver Class Initialized
DEBUG - 2018-06-15 01:03:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-15 01:03:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-15 01:03:40 --> Email Class Initialized
INFO - 2018-06-15 01:03:40 --> Controller Class Initialized
DEBUG - 2018-06-15 01:03:40 --> Admin MX_Controller Initialized
INFO - 2018-06-15 01:03:40 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-15 01:03:40 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-15 01:03:40 --> Login MX_Controller Initialized
DEBUG - 2018-06-15 01:03:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-15 01:03:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-15 01:03:40 --> Final output sent to browser
DEBUG - 2018-06-15 01:03:40 --> Total execution time: 0.4348
INFO - 2018-06-15 01:05:03 --> Config Class Initialized
INFO - 2018-06-15 01:05:03 --> Hooks Class Initialized
DEBUG - 2018-06-15 01:05:03 --> UTF-8 Support Enabled
INFO - 2018-06-15 01:05:03 --> Utf8 Class Initialized
INFO - 2018-06-15 01:05:03 --> URI Class Initialized
INFO - 2018-06-15 01:05:03 --> Router Class Initialized
INFO - 2018-06-15 01:05:03 --> Output Class Initialized
INFO - 2018-06-15 01:05:03 --> Security Class Initialized
DEBUG - 2018-06-15 01:05:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-15 01:05:03 --> Input Class Initialized
INFO - 2018-06-15 01:05:03 --> Language Class Initialized
INFO - 2018-06-15 01:05:03 --> Language Class Initialized
INFO - 2018-06-15 01:05:03 --> Config Class Initialized
INFO - 2018-06-15 01:05:03 --> Loader Class Initialized
DEBUG - 2018-06-15 01:05:03 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-15 01:05:03 --> Helper loaded: url_helper
INFO - 2018-06-15 01:05:03 --> Helper loaded: form_helper
INFO - 2018-06-15 01:05:03 --> Helper loaded: date_helper
INFO - 2018-06-15 01:05:03 --> Helper loaded: util_helper
INFO - 2018-06-15 01:05:03 --> Helper loaded: text_helper
INFO - 2018-06-15 01:05:03 --> Helper loaded: string_helper
INFO - 2018-06-15 01:05:03 --> Database Driver Class Initialized
DEBUG - 2018-06-15 01:05:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-15 01:05:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-15 01:05:03 --> Email Class Initialized
INFO - 2018-06-15 01:05:03 --> Controller Class Initialized
DEBUG - 2018-06-15 01:05:03 --> Admin MX_Controller Initialized
INFO - 2018-06-15 01:05:03 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-15 01:05:03 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-15 01:05:03 --> Login MX_Controller Initialized
DEBUG - 2018-06-15 01:05:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-15 01:05:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-15 01:05:03 --> Final output sent to browser
DEBUG - 2018-06-15 01:05:03 --> Total execution time: 0.4347
INFO - 2018-06-15 01:05:04 --> Config Class Initialized
INFO - 2018-06-15 01:05:04 --> Hooks Class Initialized
DEBUG - 2018-06-15 01:05:04 --> UTF-8 Support Enabled
INFO - 2018-06-15 01:05:04 --> Utf8 Class Initialized
INFO - 2018-06-15 01:05:04 --> URI Class Initialized
INFO - 2018-06-15 01:05:04 --> Router Class Initialized
INFO - 2018-06-15 01:05:04 --> Output Class Initialized
INFO - 2018-06-15 01:05:04 --> Security Class Initialized
DEBUG - 2018-06-15 01:05:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-15 01:05:04 --> Input Class Initialized
INFO - 2018-06-15 01:05:04 --> Language Class Initialized
INFO - 2018-06-15 01:05:04 --> Language Class Initialized
INFO - 2018-06-15 01:05:04 --> Config Class Initialized
INFO - 2018-06-15 01:05:04 --> Loader Class Initialized
DEBUG - 2018-06-15 01:05:04 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-15 01:05:04 --> Helper loaded: url_helper
INFO - 2018-06-15 01:05:04 --> Helper loaded: form_helper
INFO - 2018-06-15 01:05:04 --> Helper loaded: date_helper
INFO - 2018-06-15 01:05:04 --> Helper loaded: util_helper
INFO - 2018-06-15 01:05:04 --> Helper loaded: text_helper
INFO - 2018-06-15 01:05:04 --> Helper loaded: string_helper
INFO - 2018-06-15 01:05:04 --> Database Driver Class Initialized
DEBUG - 2018-06-15 01:05:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-15 01:05:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-15 01:05:04 --> Email Class Initialized
INFO - 2018-06-15 01:05:04 --> Controller Class Initialized
DEBUG - 2018-06-15 01:05:04 --> Admin MX_Controller Initialized
INFO - 2018-06-15 01:05:04 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-15 01:05:04 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-15 01:05:04 --> Login MX_Controller Initialized
DEBUG - 2018-06-15 01:05:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-15 01:05:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-15 01:05:04 --> Final output sent to browser
DEBUG - 2018-06-15 01:05:04 --> Total execution time: 0.4321
INFO - 2018-06-15 01:07:04 --> Config Class Initialized
INFO - 2018-06-15 01:07:04 --> Hooks Class Initialized
DEBUG - 2018-06-15 01:07:04 --> UTF-8 Support Enabled
INFO - 2018-06-15 01:07:04 --> Utf8 Class Initialized
INFO - 2018-06-15 01:07:04 --> URI Class Initialized
INFO - 2018-06-15 01:07:04 --> Router Class Initialized
INFO - 2018-06-15 01:07:04 --> Output Class Initialized
INFO - 2018-06-15 01:07:04 --> Security Class Initialized
DEBUG - 2018-06-15 01:07:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-15 01:07:04 --> Input Class Initialized
INFO - 2018-06-15 01:07:04 --> Language Class Initialized
INFO - 2018-06-15 01:07:04 --> Language Class Initialized
INFO - 2018-06-15 01:07:04 --> Config Class Initialized
INFO - 2018-06-15 01:07:04 --> Loader Class Initialized
DEBUG - 2018-06-15 01:07:04 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-15 01:07:04 --> Helper loaded: url_helper
INFO - 2018-06-15 01:07:04 --> Helper loaded: form_helper
INFO - 2018-06-15 01:07:04 --> Helper loaded: date_helper
INFO - 2018-06-15 01:07:04 --> Helper loaded: util_helper
INFO - 2018-06-15 01:07:04 --> Helper loaded: text_helper
INFO - 2018-06-15 01:07:04 --> Helper loaded: string_helper
INFO - 2018-06-15 01:07:04 --> Database Driver Class Initialized
DEBUG - 2018-06-15 01:07:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-15 01:07:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-15 01:07:04 --> Email Class Initialized
INFO - 2018-06-15 01:07:04 --> Controller Class Initialized
DEBUG - 2018-06-15 01:07:04 --> Admin MX_Controller Initialized
INFO - 2018-06-15 01:07:04 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-15 01:07:04 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-15 01:07:04 --> Login MX_Controller Initialized
DEBUG - 2018-06-15 01:07:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-15 01:07:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-15 01:07:04 --> Final output sent to browser
DEBUG - 2018-06-15 01:07:04 --> Total execution time: 0.4667
INFO - 2018-06-15 01:07:05 --> Config Class Initialized
INFO - 2018-06-15 01:07:05 --> Hooks Class Initialized
DEBUG - 2018-06-15 01:07:05 --> UTF-8 Support Enabled
INFO - 2018-06-15 01:07:05 --> Utf8 Class Initialized
INFO - 2018-06-15 01:07:05 --> URI Class Initialized
INFO - 2018-06-15 01:07:05 --> Router Class Initialized
INFO - 2018-06-15 01:07:05 --> Output Class Initialized
INFO - 2018-06-15 01:07:05 --> Security Class Initialized
DEBUG - 2018-06-15 01:07:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-15 01:07:05 --> Input Class Initialized
INFO - 2018-06-15 01:07:05 --> Language Class Initialized
INFO - 2018-06-15 01:07:05 --> Language Class Initialized
INFO - 2018-06-15 01:07:05 --> Config Class Initialized
INFO - 2018-06-15 01:07:05 --> Loader Class Initialized
DEBUG - 2018-06-15 01:07:05 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-15 01:07:05 --> Helper loaded: url_helper
INFO - 2018-06-15 01:07:05 --> Helper loaded: form_helper
INFO - 2018-06-15 01:07:05 --> Helper loaded: date_helper
INFO - 2018-06-15 01:07:05 --> Helper loaded: util_helper
INFO - 2018-06-15 01:07:05 --> Helper loaded: text_helper
INFO - 2018-06-15 01:07:05 --> Helper loaded: string_helper
INFO - 2018-06-15 01:07:05 --> Database Driver Class Initialized
DEBUG - 2018-06-15 01:07:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-15 01:07:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-15 01:07:05 --> Email Class Initialized
INFO - 2018-06-15 01:07:05 --> Controller Class Initialized
DEBUG - 2018-06-15 01:07:05 --> Admin MX_Controller Initialized
INFO - 2018-06-15 01:07:05 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-15 01:07:05 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-15 01:07:05 --> Login MX_Controller Initialized
DEBUG - 2018-06-15 01:07:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-15 01:07:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-15 01:07:05 --> Final output sent to browser
DEBUG - 2018-06-15 01:07:05 --> Total execution time: 0.4310
INFO - 2018-06-15 01:07:27 --> Config Class Initialized
INFO - 2018-06-15 01:07:27 --> Hooks Class Initialized
DEBUG - 2018-06-15 01:07:27 --> UTF-8 Support Enabled
INFO - 2018-06-15 01:07:27 --> Utf8 Class Initialized
INFO - 2018-06-15 01:07:27 --> URI Class Initialized
INFO - 2018-06-15 01:07:27 --> Router Class Initialized
INFO - 2018-06-15 01:07:27 --> Output Class Initialized
INFO - 2018-06-15 01:07:27 --> Security Class Initialized
DEBUG - 2018-06-15 01:07:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-15 01:07:27 --> Input Class Initialized
INFO - 2018-06-15 01:07:27 --> Language Class Initialized
INFO - 2018-06-15 01:07:27 --> Language Class Initialized
INFO - 2018-06-15 01:07:27 --> Config Class Initialized
INFO - 2018-06-15 01:07:27 --> Loader Class Initialized
DEBUG - 2018-06-15 01:07:27 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-15 01:07:27 --> Helper loaded: url_helper
INFO - 2018-06-15 01:07:27 --> Helper loaded: form_helper
INFO - 2018-06-15 01:07:27 --> Helper loaded: date_helper
INFO - 2018-06-15 01:07:27 --> Helper loaded: util_helper
INFO - 2018-06-15 01:07:27 --> Helper loaded: text_helper
INFO - 2018-06-15 01:07:27 --> Helper loaded: string_helper
INFO - 2018-06-15 01:07:27 --> Database Driver Class Initialized
DEBUG - 2018-06-15 01:07:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-15 01:07:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-15 01:07:27 --> Email Class Initialized
INFO - 2018-06-15 01:07:27 --> Controller Class Initialized
DEBUG - 2018-06-15 01:07:27 --> videos MX_Controller Initialized
INFO - 2018-06-15 01:07:27 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-15 01:07:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-06-15 01:07:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-15 01:07:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-15 01:07:27 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-15 01:07:27 --> Login MX_Controller Initialized
DEBUG - 2018-06-15 01:07:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-15 01:07:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-15 01:07:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-15 01:07:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-15 01:07:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-15 01:07:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-15 01:07:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/videos/create_video.php
INFO - 2018-06-15 01:07:27 --> Final output sent to browser
DEBUG - 2018-06-15 01:07:28 --> Total execution time: 0.4467
INFO - 2018-06-15 01:07:28 --> Config Class Initialized
INFO - 2018-06-15 01:07:28 --> Hooks Class Initialized
DEBUG - 2018-06-15 01:07:28 --> UTF-8 Support Enabled
INFO - 2018-06-15 01:07:28 --> Utf8 Class Initialized
INFO - 2018-06-15 01:07:28 --> URI Class Initialized
INFO - 2018-06-15 01:07:28 --> Router Class Initialized
INFO - 2018-06-15 01:07:28 --> Output Class Initialized
INFO - 2018-06-15 01:07:28 --> Security Class Initialized
DEBUG - 2018-06-15 01:07:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-15 01:07:28 --> Input Class Initialized
INFO - 2018-06-15 01:07:28 --> Language Class Initialized
ERROR - 2018-06-15 01:07:28 --> 404 Page Not Found: /index
INFO - 2018-06-15 01:29:12 --> Config Class Initialized
INFO - 2018-06-15 01:29:12 --> Hooks Class Initialized
DEBUG - 2018-06-15 01:29:12 --> UTF-8 Support Enabled
INFO - 2018-06-15 01:29:12 --> Utf8 Class Initialized
INFO - 2018-06-15 01:29:12 --> URI Class Initialized
INFO - 2018-06-15 01:29:12 --> Router Class Initialized
INFO - 2018-06-15 01:29:12 --> Output Class Initialized
INFO - 2018-06-15 01:29:12 --> Security Class Initialized
DEBUG - 2018-06-15 01:29:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-15 01:29:12 --> Input Class Initialized
INFO - 2018-06-15 01:29:12 --> Language Class Initialized
INFO - 2018-06-15 01:29:12 --> Language Class Initialized
INFO - 2018-06-15 01:29:12 --> Config Class Initialized
INFO - 2018-06-15 01:29:12 --> Loader Class Initialized
DEBUG - 2018-06-15 01:29:12 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-15 01:29:12 --> Helper loaded: url_helper
INFO - 2018-06-15 01:29:12 --> Helper loaded: form_helper
INFO - 2018-06-15 01:29:12 --> Helper loaded: date_helper
INFO - 2018-06-15 01:29:12 --> Helper loaded: util_helper
INFO - 2018-06-15 01:29:12 --> Helper loaded: text_helper
INFO - 2018-06-15 01:29:12 --> Helper loaded: string_helper
INFO - 2018-06-15 01:29:12 --> Database Driver Class Initialized
DEBUG - 2018-06-15 01:29:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-15 01:29:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-15 01:29:12 --> Email Class Initialized
INFO - 2018-06-15 01:29:12 --> Controller Class Initialized
DEBUG - 2018-06-15 01:29:12 --> Chapters MX_Controller Initialized
INFO - 2018-06-15 01:29:12 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-15 01:29:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Chapters_model.php
DEBUG - 2018-06-15 01:29:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-15 01:29:12 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-15 01:29:12 --> Login MX_Controller Initialized
DEBUG - 2018-06-15 01:29:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-15 01:29:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-15 01:29:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-15 01:29:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-15 01:29:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-15 01:29:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-15 01:29:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/chapters/chapters.php
INFO - 2018-06-15 01:29:12 --> Final output sent to browser
DEBUG - 2018-06-15 01:29:12 --> Total execution time: 0.4708
INFO - 2018-06-15 01:29:13 --> Config Class Initialized
INFO - 2018-06-15 01:29:13 --> Hooks Class Initialized
DEBUG - 2018-06-15 01:29:13 --> UTF-8 Support Enabled
INFO - 2018-06-15 01:29:13 --> Utf8 Class Initialized
INFO - 2018-06-15 01:29:13 --> URI Class Initialized
INFO - 2018-06-15 01:29:13 --> Router Class Initialized
INFO - 2018-06-15 01:29:13 --> Output Class Initialized
INFO - 2018-06-15 01:29:13 --> Security Class Initialized
DEBUG - 2018-06-15 01:29:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-15 01:29:13 --> Input Class Initialized
INFO - 2018-06-15 01:29:13 --> Language Class Initialized
INFO - 2018-06-15 01:29:13 --> Language Class Initialized
INFO - 2018-06-15 01:29:13 --> Config Class Initialized
INFO - 2018-06-15 01:29:13 --> Loader Class Initialized
DEBUG - 2018-06-15 01:29:13 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-15 01:29:13 --> Helper loaded: url_helper
INFO - 2018-06-15 01:29:13 --> Helper loaded: form_helper
INFO - 2018-06-15 01:29:13 --> Helper loaded: date_helper
INFO - 2018-06-15 01:29:13 --> Helper loaded: util_helper
INFO - 2018-06-15 01:29:13 --> Helper loaded: text_helper
INFO - 2018-06-15 01:29:13 --> Helper loaded: string_helper
INFO - 2018-06-15 01:29:13 --> Database Driver Class Initialized
DEBUG - 2018-06-15 01:29:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-15 01:29:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-15 01:29:13 --> Email Class Initialized
INFO - 2018-06-15 01:29:13 --> Controller Class Initialized
DEBUG - 2018-06-15 01:29:13 --> Chapters MX_Controller Initialized
INFO - 2018-06-15 01:29:13 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-15 01:29:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Chapters_model.php
DEBUG - 2018-06-15 01:29:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-15 01:29:13 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-15 01:29:13 --> Login MX_Controller Initialized
DEBUG - 2018-06-15 01:29:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-15 01:29:13 --> Final output sent to browser
DEBUG - 2018-06-15 01:29:13 --> Total execution time: 0.4979
INFO - 2018-06-15 01:44:34 --> Config Class Initialized
INFO - 2018-06-15 01:44:34 --> Hooks Class Initialized
DEBUG - 2018-06-15 01:44:34 --> UTF-8 Support Enabled
INFO - 2018-06-15 01:44:34 --> Utf8 Class Initialized
INFO - 2018-06-15 01:44:34 --> URI Class Initialized
DEBUG - 2018-06-15 01:44:34 --> No URI present. Default controller set.
INFO - 2018-06-15 01:44:34 --> Router Class Initialized
INFO - 2018-06-15 01:44:34 --> Output Class Initialized
INFO - 2018-06-15 01:44:34 --> Security Class Initialized
DEBUG - 2018-06-15 01:44:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-15 01:44:34 --> Input Class Initialized
INFO - 2018-06-15 01:44:34 --> Language Class Initialized
INFO - 2018-06-15 01:44:34 --> Language Class Initialized
INFO - 2018-06-15 01:44:34 --> Config Class Initialized
INFO - 2018-06-15 01:44:34 --> Loader Class Initialized
DEBUG - 2018-06-15 01:44:34 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-15 01:44:34 --> Helper loaded: url_helper
INFO - 2018-06-15 01:44:34 --> Helper loaded: form_helper
INFO - 2018-06-15 01:44:34 --> Helper loaded: date_helper
INFO - 2018-06-15 01:44:34 --> Helper loaded: util_helper
INFO - 2018-06-15 01:44:34 --> Helper loaded: text_helper
INFO - 2018-06-15 01:44:34 --> Helper loaded: string_helper
INFO - 2018-06-15 01:44:34 --> Database Driver Class Initialized
DEBUG - 2018-06-15 01:44:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-15 01:44:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-15 01:44:34 --> Email Class Initialized
INFO - 2018-06-15 01:44:34 --> Controller Class Initialized
DEBUG - 2018-06-15 01:44:34 --> Home MX_Controller Initialized
DEBUG - 2018-06-15 01:44:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-15 01:44:34 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-15 01:44:34 --> Login MX_Controller Initialized
INFO - 2018-06-15 01:44:34 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-15 01:44:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-15 01:44:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-15 01:44:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-06-15 02:45:11 --> Config Class Initialized
INFO - 2018-06-15 02:45:11 --> Hooks Class Initialized
DEBUG - 2018-06-15 02:45:11 --> UTF-8 Support Enabled
INFO - 2018-06-15 02:45:11 --> Utf8 Class Initialized
INFO - 2018-06-15 02:45:11 --> URI Class Initialized
INFO - 2018-06-15 02:45:11 --> Router Class Initialized
INFO - 2018-06-15 02:45:11 --> Output Class Initialized
INFO - 2018-06-15 02:45:11 --> Security Class Initialized
DEBUG - 2018-06-15 02:45:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-15 02:45:11 --> Input Class Initialized
INFO - 2018-06-15 02:45:11 --> Language Class Initialized
INFO - 2018-06-15 02:45:11 --> Language Class Initialized
INFO - 2018-06-15 02:45:11 --> Config Class Initialized
INFO - 2018-06-15 02:45:11 --> Loader Class Initialized
DEBUG - 2018-06-15 02:45:11 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-15 02:45:11 --> Helper loaded: url_helper
INFO - 2018-06-15 02:45:11 --> Helper loaded: form_helper
INFO - 2018-06-15 02:45:11 --> Helper loaded: date_helper
INFO - 2018-06-15 02:45:11 --> Helper loaded: util_helper
INFO - 2018-06-15 02:45:11 --> Helper loaded: text_helper
INFO - 2018-06-15 02:45:11 --> Helper loaded: string_helper
INFO - 2018-06-15 02:45:11 --> Database Driver Class Initialized
DEBUG - 2018-06-15 02:45:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-15 02:45:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-15 02:45:12 --> Email Class Initialized
INFO - 2018-06-15 02:45:12 --> Controller Class Initialized
DEBUG - 2018-06-15 02:45:12 --> Chapters MX_Controller Initialized
INFO - 2018-06-15 02:45:12 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-15 02:45:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Chapters_model.php
DEBUG - 2018-06-15 02:45:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-15 02:45:12 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-15 02:45:12 --> Login MX_Controller Initialized
DEBUG - 2018-06-15 02:45:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-15 02:45:12 --> Final output sent to browser
DEBUG - 2018-06-15 02:45:12 --> Total execution time: 0.4206
INFO - 2018-06-15 02:45:12 --> Config Class Initialized
INFO - 2018-06-15 02:45:12 --> Hooks Class Initialized
DEBUG - 2018-06-15 02:45:12 --> UTF-8 Support Enabled
INFO - 2018-06-15 02:45:12 --> Utf8 Class Initialized
INFO - 2018-06-15 02:45:12 --> URI Class Initialized
INFO - 2018-06-15 02:45:12 --> Router Class Initialized
INFO - 2018-06-15 02:45:12 --> Output Class Initialized
INFO - 2018-06-15 02:45:12 --> Security Class Initialized
DEBUG - 2018-06-15 02:45:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-15 02:45:12 --> Input Class Initialized
INFO - 2018-06-15 02:45:12 --> Language Class Initialized
INFO - 2018-06-15 02:45:12 --> Language Class Initialized
INFO - 2018-06-15 02:45:12 --> Config Class Initialized
INFO - 2018-06-15 02:45:12 --> Loader Class Initialized
DEBUG - 2018-06-15 02:45:12 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-15 02:45:12 --> Helper loaded: url_helper
INFO - 2018-06-15 02:45:12 --> Helper loaded: form_helper
INFO - 2018-06-15 02:45:12 --> Helper loaded: date_helper
INFO - 2018-06-15 02:45:12 --> Helper loaded: util_helper
INFO - 2018-06-15 02:45:12 --> Helper loaded: text_helper
INFO - 2018-06-15 02:45:12 --> Helper loaded: string_helper
INFO - 2018-06-15 02:45:12 --> Database Driver Class Initialized
DEBUG - 2018-06-15 02:45:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-15 02:45:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-15 02:45:12 --> Email Class Initialized
INFO - 2018-06-15 02:45:12 --> Controller Class Initialized
DEBUG - 2018-06-15 02:45:12 --> Chapters MX_Controller Initialized
INFO - 2018-06-15 02:45:12 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-15 02:45:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Chapters_model.php
DEBUG - 2018-06-15 02:45:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-15 02:45:12 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-15 02:45:12 --> Login MX_Controller Initialized
DEBUG - 2018-06-15 02:45:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-15 02:45:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-15 02:45:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-15 02:45:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-15 02:45:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-15 02:45:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-15 02:45:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/chapters/chapters.php
INFO - 2018-06-15 02:45:13 --> Final output sent to browser
DEBUG - 2018-06-15 02:45:13 --> Total execution time: 0.4554
INFO - 2018-06-15 02:45:13 --> Config Class Initialized
INFO - 2018-06-15 02:45:13 --> Hooks Class Initialized
DEBUG - 2018-06-15 02:45:13 --> UTF-8 Support Enabled
INFO - 2018-06-15 02:45:13 --> Utf8 Class Initialized
INFO - 2018-06-15 02:45:13 --> URI Class Initialized
INFO - 2018-06-15 02:45:13 --> Router Class Initialized
INFO - 2018-06-15 02:45:13 --> Output Class Initialized
INFO - 2018-06-15 02:45:13 --> Security Class Initialized
DEBUG - 2018-06-15 02:45:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-15 02:45:13 --> Input Class Initialized
INFO - 2018-06-15 02:45:13 --> Language Class Initialized
INFO - 2018-06-15 02:45:13 --> Language Class Initialized
INFO - 2018-06-15 02:45:13 --> Config Class Initialized
INFO - 2018-06-15 02:45:13 --> Loader Class Initialized
DEBUG - 2018-06-15 02:45:13 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-15 02:45:13 --> Helper loaded: url_helper
INFO - 2018-06-15 02:45:13 --> Helper loaded: form_helper
INFO - 2018-06-15 02:45:13 --> Helper loaded: date_helper
INFO - 2018-06-15 02:45:13 --> Helper loaded: util_helper
INFO - 2018-06-15 02:45:13 --> Helper loaded: text_helper
INFO - 2018-06-15 02:45:13 --> Helper loaded: string_helper
INFO - 2018-06-15 02:45:13 --> Database Driver Class Initialized
DEBUG - 2018-06-15 02:45:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-15 02:45:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-15 02:45:13 --> Email Class Initialized
INFO - 2018-06-15 02:45:13 --> Controller Class Initialized
DEBUG - 2018-06-15 02:45:13 --> Chapters MX_Controller Initialized
INFO - 2018-06-15 02:45:13 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-15 02:45:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Chapters_model.php
DEBUG - 2018-06-15 02:45:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-15 02:45:13 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-15 02:45:13 --> Login MX_Controller Initialized
DEBUG - 2018-06-15 02:45:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-15 02:45:13 --> Final output sent to browser
DEBUG - 2018-06-15 02:45:13 --> Total execution time: 0.5228
INFO - 2018-06-15 03:12:22 --> Config Class Initialized
INFO - 2018-06-15 03:12:22 --> Hooks Class Initialized
DEBUG - 2018-06-15 03:12:22 --> UTF-8 Support Enabled
INFO - 2018-06-15 03:12:22 --> Utf8 Class Initialized
INFO - 2018-06-15 03:12:22 --> URI Class Initialized
DEBUG - 2018-06-15 03:12:22 --> No URI present. Default controller set.
INFO - 2018-06-15 03:12:22 --> Router Class Initialized
INFO - 2018-06-15 03:12:22 --> Output Class Initialized
INFO - 2018-06-15 03:12:22 --> Security Class Initialized
DEBUG - 2018-06-15 03:12:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-15 03:12:22 --> Input Class Initialized
INFO - 2018-06-15 03:12:22 --> Language Class Initialized
INFO - 2018-06-15 03:12:22 --> Language Class Initialized
INFO - 2018-06-15 03:12:22 --> Config Class Initialized
INFO - 2018-06-15 03:12:22 --> Loader Class Initialized
DEBUG - 2018-06-15 03:12:22 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-15 03:12:22 --> Helper loaded: url_helper
INFO - 2018-06-15 03:12:22 --> Helper loaded: form_helper
INFO - 2018-06-15 03:12:22 --> Helper loaded: date_helper
INFO - 2018-06-15 03:12:22 --> Helper loaded: util_helper
INFO - 2018-06-15 03:12:22 --> Helper loaded: text_helper
INFO - 2018-06-15 03:12:22 --> Helper loaded: string_helper
INFO - 2018-06-15 03:12:22 --> Database Driver Class Initialized
DEBUG - 2018-06-15 03:12:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-15 03:12:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-15 03:12:22 --> Email Class Initialized
INFO - 2018-06-15 03:12:22 --> Controller Class Initialized
DEBUG - 2018-06-15 03:12:22 --> Home MX_Controller Initialized
DEBUG - 2018-06-15 03:12:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-15 03:12:22 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-15 03:12:22 --> Login MX_Controller Initialized
INFO - 2018-06-15 03:12:22 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-15 03:12:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-15 03:12:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-15 03:12:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-15 03:12:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-15 03:12:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-15 03:12:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-15 03:12:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-15 03:12:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-06-15 03:12:22 --> Final output sent to browser
DEBUG - 2018-06-15 03:12:22 --> Total execution time: 0.5350
INFO - 2018-06-15 03:12:23 --> Config Class Initialized
INFO - 2018-06-15 03:12:23 --> Hooks Class Initialized
DEBUG - 2018-06-15 03:12:23 --> UTF-8 Support Enabled
INFO - 2018-06-15 03:12:23 --> Utf8 Class Initialized
INFO - 2018-06-15 03:12:23 --> URI Class Initialized
INFO - 2018-06-15 03:12:23 --> Router Class Initialized
INFO - 2018-06-15 03:12:23 --> Output Class Initialized
INFO - 2018-06-15 03:12:23 --> Security Class Initialized
DEBUG - 2018-06-15 03:12:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-15 03:12:23 --> Input Class Initialized
INFO - 2018-06-15 03:12:23 --> Language Class Initialized
ERROR - 2018-06-15 03:12:23 --> 404 Page Not Found: /index
INFO - 2018-06-15 03:12:23 --> Config Class Initialized
INFO - 2018-06-15 03:12:23 --> Hooks Class Initialized
DEBUG - 2018-06-15 03:12:23 --> UTF-8 Support Enabled
INFO - 2018-06-15 03:12:23 --> Utf8 Class Initialized
INFO - 2018-06-15 03:12:23 --> URI Class Initialized
INFO - 2018-06-15 03:12:23 --> Router Class Initialized
INFO - 2018-06-15 03:12:23 --> Output Class Initialized
INFO - 2018-06-15 03:12:23 --> Security Class Initialized
DEBUG - 2018-06-15 03:12:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-15 03:12:23 --> Input Class Initialized
INFO - 2018-06-15 03:12:23 --> Language Class Initialized
ERROR - 2018-06-15 03:12:23 --> 404 Page Not Found: /index
INFO - 2018-06-15 03:12:23 --> Config Class Initialized
INFO - 2018-06-15 03:12:23 --> Hooks Class Initialized
DEBUG - 2018-06-15 03:12:23 --> UTF-8 Support Enabled
INFO - 2018-06-15 03:12:23 --> Utf8 Class Initialized
INFO - 2018-06-15 03:12:23 --> URI Class Initialized
INFO - 2018-06-15 03:12:23 --> Router Class Initialized
INFO - 2018-06-15 03:12:23 --> Output Class Initialized
INFO - 2018-06-15 03:12:23 --> Security Class Initialized
DEBUG - 2018-06-15 03:12:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-15 03:12:23 --> Input Class Initialized
INFO - 2018-06-15 03:12:23 --> Language Class Initialized
ERROR - 2018-06-15 03:12:23 --> 404 Page Not Found: /index
INFO - 2018-06-15 03:19:22 --> Config Class Initialized
INFO - 2018-06-15 03:19:22 --> Hooks Class Initialized
DEBUG - 2018-06-15 03:19:22 --> UTF-8 Support Enabled
INFO - 2018-06-15 03:19:22 --> Utf8 Class Initialized
INFO - 2018-06-15 03:19:22 --> URI Class Initialized
INFO - 2018-06-15 03:19:22 --> Router Class Initialized
INFO - 2018-06-15 03:19:22 --> Output Class Initialized
INFO - 2018-06-15 03:19:22 --> Security Class Initialized
DEBUG - 2018-06-15 03:19:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-15 03:19:22 --> Input Class Initialized
INFO - 2018-06-15 03:19:22 --> Language Class Initialized
INFO - 2018-06-15 03:19:22 --> Language Class Initialized
INFO - 2018-06-15 03:19:22 --> Config Class Initialized
INFO - 2018-06-15 03:19:22 --> Loader Class Initialized
DEBUG - 2018-06-15 03:19:22 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-15 03:19:22 --> Helper loaded: url_helper
INFO - 2018-06-15 03:19:22 --> Helper loaded: form_helper
INFO - 2018-06-15 03:19:22 --> Helper loaded: date_helper
INFO - 2018-06-15 03:19:22 --> Helper loaded: util_helper
INFO - 2018-06-15 03:19:22 --> Helper loaded: text_helper
INFO - 2018-06-15 03:19:22 --> Helper loaded: string_helper
INFO - 2018-06-15 03:19:22 --> Database Driver Class Initialized
DEBUG - 2018-06-15 03:19:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-15 03:19:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-15 03:19:22 --> Email Class Initialized
INFO - 2018-06-15 03:19:22 --> Controller Class Initialized
DEBUG - 2018-06-15 03:19:22 --> videos MX_Controller Initialized
INFO - 2018-06-15 03:19:23 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-15 03:19:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-06-15 03:19:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-15 03:19:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-15 03:19:23 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-15 03:19:23 --> Login MX_Controller Initialized
DEBUG - 2018-06-15 03:19:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-15 03:19:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-15 03:19:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-15 03:19:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-15 03:19:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-15 03:19:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-15 03:19:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/videos/videos.php
INFO - 2018-06-15 03:19:23 --> Final output sent to browser
DEBUG - 2018-06-15 03:19:23 --> Total execution time: 0.4808
INFO - 2018-06-15 03:19:23 --> Config Class Initialized
INFO - 2018-06-15 03:19:23 --> Hooks Class Initialized
DEBUG - 2018-06-15 03:19:23 --> UTF-8 Support Enabled
INFO - 2018-06-15 03:19:23 --> Utf8 Class Initialized
INFO - 2018-06-15 03:19:23 --> URI Class Initialized
INFO - 2018-06-15 03:19:23 --> Router Class Initialized
INFO - 2018-06-15 03:19:23 --> Output Class Initialized
INFO - 2018-06-15 03:19:23 --> Security Class Initialized
DEBUG - 2018-06-15 03:19:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-15 03:19:23 --> Input Class Initialized
INFO - 2018-06-15 03:19:24 --> Language Class Initialized
INFO - 2018-06-15 03:19:24 --> Language Class Initialized
INFO - 2018-06-15 03:19:24 --> Config Class Initialized
INFO - 2018-06-15 03:19:24 --> Loader Class Initialized
DEBUG - 2018-06-15 03:19:24 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-15 03:19:24 --> Helper loaded: url_helper
INFO - 2018-06-15 03:19:24 --> Helper loaded: form_helper
INFO - 2018-06-15 03:19:24 --> Helper loaded: date_helper
INFO - 2018-06-15 03:19:24 --> Helper loaded: util_helper
INFO - 2018-06-15 03:19:24 --> Helper loaded: text_helper
INFO - 2018-06-15 03:19:24 --> Helper loaded: string_helper
INFO - 2018-06-15 03:19:24 --> Database Driver Class Initialized
DEBUG - 2018-06-15 03:19:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-15 03:19:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-15 03:19:24 --> Email Class Initialized
INFO - 2018-06-15 03:19:24 --> Controller Class Initialized
DEBUG - 2018-06-15 03:19:24 --> videos MX_Controller Initialized
INFO - 2018-06-15 03:19:24 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-15 03:19:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-06-15 03:19:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-15 03:19:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-15 03:19:24 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-15 03:19:24 --> Login MX_Controller Initialized
DEBUG - 2018-06-15 03:19:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-15 03:19:24 --> Final output sent to browser
DEBUG - 2018-06-15 03:19:24 --> Total execution time: 0.5710
INFO - 2018-06-15 03:22:17 --> Config Class Initialized
INFO - 2018-06-15 03:22:17 --> Hooks Class Initialized
DEBUG - 2018-06-15 03:22:17 --> UTF-8 Support Enabled
INFO - 2018-06-15 03:22:17 --> Utf8 Class Initialized
INFO - 2018-06-15 03:22:17 --> URI Class Initialized
INFO - 2018-06-15 03:22:17 --> Router Class Initialized
INFO - 2018-06-15 03:22:17 --> Output Class Initialized
INFO - 2018-06-15 03:22:17 --> Security Class Initialized
DEBUG - 2018-06-15 03:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-15 03:22:17 --> Input Class Initialized
INFO - 2018-06-15 03:22:17 --> Language Class Initialized
INFO - 2018-06-15 03:22:17 --> Language Class Initialized
INFO - 2018-06-15 03:22:17 --> Config Class Initialized
INFO - 2018-06-15 03:22:17 --> Loader Class Initialized
DEBUG - 2018-06-15 03:22:17 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-15 03:22:17 --> Helper loaded: url_helper
INFO - 2018-06-15 03:22:17 --> Helper loaded: form_helper
INFO - 2018-06-15 03:22:17 --> Helper loaded: date_helper
INFO - 2018-06-15 03:22:17 --> Helper loaded: util_helper
INFO - 2018-06-15 03:22:17 --> Helper loaded: text_helper
INFO - 2018-06-15 03:22:17 --> Helper loaded: string_helper
INFO - 2018-06-15 03:22:17 --> Database Driver Class Initialized
DEBUG - 2018-06-15 03:22:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-15 03:22:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-15 03:22:17 --> Email Class Initialized
INFO - 2018-06-15 03:22:17 --> Controller Class Initialized
DEBUG - 2018-06-15 03:22:17 --> videos MX_Controller Initialized
INFO - 2018-06-15 03:22:17 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-15 03:22:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-06-15 03:22:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-15 03:22:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-15 03:22:17 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-15 03:22:17 --> Login MX_Controller Initialized
DEBUG - 2018-06-15 03:22:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-15 03:22:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-15 03:22:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-15 03:22:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-15 03:22:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-15 03:22:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-15 03:22:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/videos/videos.php
INFO - 2018-06-15 03:22:18 --> Final output sent to browser
DEBUG - 2018-06-15 03:22:18 --> Total execution time: 0.5607
INFO - 2018-06-15 03:22:18 --> Config Class Initialized
INFO - 2018-06-15 03:22:18 --> Hooks Class Initialized
DEBUG - 2018-06-15 03:22:18 --> UTF-8 Support Enabled
INFO - 2018-06-15 03:22:18 --> Utf8 Class Initialized
INFO - 2018-06-15 03:22:18 --> URI Class Initialized
INFO - 2018-06-15 03:22:18 --> Router Class Initialized
INFO - 2018-06-15 03:22:18 --> Output Class Initialized
INFO - 2018-06-15 03:22:18 --> Security Class Initialized
DEBUG - 2018-06-15 03:22:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-15 03:22:18 --> Input Class Initialized
INFO - 2018-06-15 03:22:18 --> Language Class Initialized
INFO - 2018-06-15 03:22:18 --> Language Class Initialized
INFO - 2018-06-15 03:22:18 --> Config Class Initialized
INFO - 2018-06-15 03:22:18 --> Loader Class Initialized
DEBUG - 2018-06-15 03:22:18 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-15 03:22:18 --> Helper loaded: url_helper
INFO - 2018-06-15 03:22:18 --> Helper loaded: form_helper
INFO - 2018-06-15 03:22:18 --> Helper loaded: date_helper
INFO - 2018-06-15 03:22:18 --> Helper loaded: util_helper
INFO - 2018-06-15 03:22:18 --> Helper loaded: text_helper
INFO - 2018-06-15 03:22:18 --> Helper loaded: string_helper
INFO - 2018-06-15 03:22:18 --> Database Driver Class Initialized
DEBUG - 2018-06-15 03:22:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-15 03:22:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-15 03:22:18 --> Config Class Initialized
INFO - 2018-06-15 03:22:18 --> Hooks Class Initialized
INFO - 2018-06-15 03:22:18 --> Email Class Initialized
DEBUG - 2018-06-15 03:22:18 --> UTF-8 Support Enabled
INFO - 2018-06-15 03:22:18 --> Utf8 Class Initialized
INFO - 2018-06-15 03:22:18 --> Controller Class Initialized
DEBUG - 2018-06-15 03:22:19 --> videos MX_Controller Initialized
INFO - 2018-06-15 03:22:19 --> URI Class Initialized
INFO - 2018-06-15 03:22:19 --> Language file loaded: language/english/data_lang.php
INFO - 2018-06-15 03:22:19 --> Router Class Initialized
INFO - 2018-06-15 03:22:19 --> Output Class Initialized
DEBUG - 2018-06-15 03:22:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-06-15 03:22:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-06-15 03:22:19 --> Security Class Initialized
DEBUG - 2018-06-15 03:22:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-06-15 03:22:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
INFO - 2018-06-15 03:22:19 --> Input Class Initialized
DEBUG - 2018-06-15 03:22:19 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
INFO - 2018-06-15 03:22:19 --> Language Class Initialized
DEBUG - 2018-06-15 03:22:19 --> Login MX_Controller Initialized
INFO - 2018-06-15 03:22:19 --> Language Class Initialized
INFO - 2018-06-15 03:22:19 --> Config Class Initialized
DEBUG - 2018-06-15 03:22:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-15 03:22:19 --> Loader Class Initialized
INFO - 2018-06-15 03:22:19 --> Final output sent to browser
DEBUG - 2018-06-15 03:22:19 --> Total execution time: 0.5223
DEBUG - 2018-06-15 03:22:19 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-15 03:22:19 --> Helper loaded: url_helper
INFO - 2018-06-15 03:22:19 --> Helper loaded: form_helper
INFO - 2018-06-15 03:22:19 --> Helper loaded: date_helper
INFO - 2018-06-15 03:22:19 --> Helper loaded: util_helper
INFO - 2018-06-15 03:22:19 --> Helper loaded: text_helper
INFO - 2018-06-15 03:22:19 --> Helper loaded: string_helper
INFO - 2018-06-15 03:22:19 --> Database Driver Class Initialized
DEBUG - 2018-06-15 03:22:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-15 03:22:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-15 03:22:19 --> Email Class Initialized
INFO - 2018-06-15 03:22:19 --> Controller Class Initialized
DEBUG - 2018-06-15 03:22:19 --> Home MX_Controller Initialized
DEBUG - 2018-06-15 03:22:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-15 03:22:19 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-15 03:22:19 --> Login MX_Controller Initialized
INFO - 2018-06-15 03:22:19 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-15 03:22:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-15 03:22:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-15 03:22:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-15 03:22:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-15 03:22:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-15 03:22:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-15 03:22:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-15 03:22:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-06-15 03:22:19 --> Final output sent to browser
DEBUG - 2018-06-15 03:22:19 --> Total execution time: 0.5398
INFO - 2018-06-15 03:22:19 --> Config Class Initialized
INFO - 2018-06-15 03:22:19 --> Config Class Initialized
INFO - 2018-06-15 03:22:20 --> Hooks Class Initialized
INFO - 2018-06-15 03:22:20 --> Hooks Class Initialized
DEBUG - 2018-06-15 03:22:20 --> UTF-8 Support Enabled
DEBUG - 2018-06-15 03:22:20 --> UTF-8 Support Enabled
INFO - 2018-06-15 03:22:20 --> Utf8 Class Initialized
INFO - 2018-06-15 03:22:20 --> Utf8 Class Initialized
INFO - 2018-06-15 03:22:20 --> URI Class Initialized
INFO - 2018-06-15 03:22:20 --> URI Class Initialized
INFO - 2018-06-15 03:22:20 --> Router Class Initialized
INFO - 2018-06-15 03:22:20 --> Router Class Initialized
INFO - 2018-06-15 03:22:20 --> Output Class Initialized
INFO - 2018-06-15 03:22:20 --> Security Class Initialized
INFO - 2018-06-15 03:22:20 --> Output Class Initialized
DEBUG - 2018-06-15 03:22:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-15 03:22:20 --> Input Class Initialized
INFO - 2018-06-15 03:22:20 --> Language Class Initialized
ERROR - 2018-06-15 03:22:20 --> 404 Page Not Found: /index
INFO - 2018-06-15 03:22:20 --> Security Class Initialized
DEBUG - 2018-06-15 03:22:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-15 03:22:20 --> Input Class Initialized
INFO - 2018-06-15 03:22:20 --> Language Class Initialized
ERROR - 2018-06-15 03:22:20 --> 404 Page Not Found: /index
INFO - 2018-06-15 03:22:20 --> Config Class Initialized
INFO - 2018-06-15 03:22:20 --> Hooks Class Initialized
DEBUG - 2018-06-15 03:22:20 --> UTF-8 Support Enabled
INFO - 2018-06-15 03:22:20 --> Utf8 Class Initialized
INFO - 2018-06-15 03:22:20 --> URI Class Initialized
INFO - 2018-06-15 03:22:20 --> Router Class Initialized
INFO - 2018-06-15 03:22:20 --> Output Class Initialized
INFO - 2018-06-15 03:22:20 --> Security Class Initialized
DEBUG - 2018-06-15 03:22:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-15 03:22:20 --> Input Class Initialized
INFO - 2018-06-15 03:22:20 --> Language Class Initialized
ERROR - 2018-06-15 03:22:20 --> 404 Page Not Found: /index
INFO - 2018-06-15 03:22:20 --> Config Class Initialized
INFO - 2018-06-15 03:22:20 --> Hooks Class Initialized
DEBUG - 2018-06-15 03:22:20 --> UTF-8 Support Enabled
INFO - 2018-06-15 03:22:20 --> Utf8 Class Initialized
INFO - 2018-06-15 03:22:20 --> URI Class Initialized
INFO - 2018-06-15 03:22:20 --> Router Class Initialized
INFO - 2018-06-15 03:22:21 --> Output Class Initialized
INFO - 2018-06-15 03:22:21 --> Security Class Initialized
DEBUG - 2018-06-15 03:22:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-15 03:22:21 --> Input Class Initialized
INFO - 2018-06-15 03:22:21 --> Language Class Initialized
ERROR - 2018-06-15 03:22:21 --> 404 Page Not Found: /index
INFO - 2018-06-15 04:39:31 --> Config Class Initialized
INFO - 2018-06-15 04:39:31 --> Hooks Class Initialized
DEBUG - 2018-06-15 04:39:31 --> UTF-8 Support Enabled
INFO - 2018-06-15 04:39:31 --> Utf8 Class Initialized
INFO - 2018-06-15 04:39:31 --> URI Class Initialized
DEBUG - 2018-06-15 04:39:31 --> No URI present. Default controller set.
INFO - 2018-06-15 04:39:31 --> Router Class Initialized
INFO - 2018-06-15 04:39:31 --> Output Class Initialized
INFO - 2018-06-15 04:39:31 --> Security Class Initialized
DEBUG - 2018-06-15 04:39:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-15 04:39:31 --> Input Class Initialized
INFO - 2018-06-15 04:39:31 --> Language Class Initialized
INFO - 2018-06-15 04:39:31 --> Language Class Initialized
INFO - 2018-06-15 04:39:31 --> Config Class Initialized
INFO - 2018-06-15 04:39:31 --> Loader Class Initialized
DEBUG - 2018-06-15 04:39:31 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-15 04:39:31 --> Helper loaded: url_helper
INFO - 2018-06-15 04:39:31 --> Helper loaded: form_helper
INFO - 2018-06-15 04:39:31 --> Helper loaded: date_helper
INFO - 2018-06-15 04:39:31 --> Helper loaded: util_helper
INFO - 2018-06-15 04:39:31 --> Helper loaded: text_helper
INFO - 2018-06-15 04:39:31 --> Helper loaded: string_helper
INFO - 2018-06-15 04:39:31 --> Database Driver Class Initialized
DEBUG - 2018-06-15 04:39:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-15 04:39:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-15 04:39:31 --> Email Class Initialized
INFO - 2018-06-15 04:39:31 --> Controller Class Initialized
DEBUG - 2018-06-15 04:39:31 --> Home MX_Controller Initialized
DEBUG - 2018-06-15 04:39:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-15 04:39:31 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-15 04:39:31 --> Login MX_Controller Initialized
INFO - 2018-06-15 04:39:31 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-15 04:39:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-15 04:39:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-15 04:39:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-06-15 04:39:33 --> Config Class Initialized
INFO - 2018-06-15 04:39:33 --> Hooks Class Initialized
DEBUG - 2018-06-15 04:39:33 --> UTF-8 Support Enabled
INFO - 2018-06-15 04:39:33 --> Utf8 Class Initialized
INFO - 2018-06-15 04:39:33 --> URI Class Initialized
INFO - 2018-06-15 04:39:33 --> Router Class Initialized
INFO - 2018-06-15 04:39:33 --> Output Class Initialized
INFO - 2018-06-15 04:39:33 --> Security Class Initialized
DEBUG - 2018-06-15 04:39:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-15 04:39:33 --> Input Class Initialized
INFO - 2018-06-15 04:39:33 --> Language Class Initialized
ERROR - 2018-06-15 04:39:33 --> 404 Page Not Found: /index
