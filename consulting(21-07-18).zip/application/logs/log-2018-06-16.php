<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-06-16 00:45:58 --> Config Class Initialized
INFO - 2018-06-16 00:45:58 --> Hooks Class Initialized
DEBUG - 2018-06-16 00:45:58 --> UTF-8 Support Enabled
INFO - 2018-06-16 00:45:58 --> Utf8 Class Initialized
INFO - 2018-06-16 00:45:58 --> URI Class Initialized
INFO - 2018-06-16 00:45:58 --> Router Class Initialized
INFO - 2018-06-16 00:45:58 --> Output Class Initialized
INFO - 2018-06-16 00:45:58 --> Security Class Initialized
DEBUG - 2018-06-16 00:45:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-16 00:45:58 --> Input Class Initialized
INFO - 2018-06-16 00:45:59 --> Language Class Initialized
INFO - 2018-06-16 00:45:59 --> Language Class Initialized
INFO - 2018-06-16 00:45:59 --> Config Class Initialized
INFO - 2018-06-16 00:45:59 --> Loader Class Initialized
DEBUG - 2018-06-16 00:45:59 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-16 00:45:59 --> Helper loaded: url_helper
INFO - 2018-06-16 00:45:59 --> Helper loaded: form_helper
INFO - 2018-06-16 00:45:59 --> Helper loaded: date_helper
INFO - 2018-06-16 00:45:59 --> Helper loaded: util_helper
INFO - 2018-06-16 00:45:59 --> Helper loaded: text_helper
INFO - 2018-06-16 00:45:59 --> Helper loaded: string_helper
INFO - 2018-06-16 00:45:59 --> Config Class Initialized
INFO - 2018-06-16 00:45:59 --> Hooks Class Initialized
DEBUG - 2018-06-16 00:45:59 --> UTF-8 Support Enabled
INFO - 2018-06-16 00:45:59 --> Database Driver Class Initialized
INFO - 2018-06-16 00:45:59 --> Utf8 Class Initialized
INFO - 2018-06-16 00:45:59 --> URI Class Initialized
INFO - 2018-06-16 00:45:59 --> Router Class Initialized
INFO - 2018-06-16 00:45:59 --> Output Class Initialized
INFO - 2018-06-16 00:45:59 --> Security Class Initialized
DEBUG - 2018-06-16 00:45:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-16 00:45:59 --> Input Class Initialized
INFO - 2018-06-16 00:45:59 --> Language Class Initialized
INFO - 2018-06-16 00:45:59 --> Language Class Initialized
INFO - 2018-06-16 00:45:59 --> Config Class Initialized
INFO - 2018-06-16 00:45:59 --> Loader Class Initialized
DEBUG - 2018-06-16 00:45:59 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
DEBUG - 2018-06-16 00:45:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-16 00:45:59 --> Helper loaded: url_helper
INFO - 2018-06-16 00:45:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-16 00:45:59 --> Helper loaded: form_helper
INFO - 2018-06-16 00:45:59 --> Helper loaded: date_helper
INFO - 2018-06-16 00:45:59 --> Email Class Initialized
INFO - 2018-06-16 00:45:59 --> Controller Class Initialized
INFO - 2018-06-16 00:45:59 --> Helper loaded: util_helper
DEBUG - 2018-06-16 00:45:59 --> videos MX_Controller Initialized
INFO - 2018-06-16 00:45:59 --> Helper loaded: text_helper
INFO - 2018-06-16 00:45:59 --> Language file loaded: language/english/data_lang.php
INFO - 2018-06-16 00:45:59 --> Helper loaded: string_helper
INFO - 2018-06-16 00:45:59 --> Database Driver Class Initialized
DEBUG - 2018-06-16 00:45:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-16 00:45:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-16 00:45:59 --> Email Class Initialized
INFO - 2018-06-16 00:45:59 --> Controller Class Initialized
DEBUG - 2018-06-16 00:45:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-06-16 00:45:59 --> Home MX_Controller Initialized
DEBUG - 2018-06-16 00:45:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-16 00:46:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-16 00:46:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-16 00:46:00 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-16 00:46:00 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-16 00:46:00 --> Login MX_Controller Initialized
DEBUG - 2018-06-16 00:46:00 --> Login MX_Controller Initialized
INFO - 2018-06-16 00:46:00 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-16 00:46:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-16 00:46:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-16 00:46:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-16 00:46:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
DEBUG - 2018-06-16 00:46:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
INFO - 2018-06-16 00:46:00 --> Config Class Initialized
INFO - 2018-06-16 00:46:00 --> Hooks Class Initialized
DEBUG - 2018-06-16 00:46:00 --> UTF-8 Support Enabled
INFO - 2018-06-16 00:46:01 --> Utf8 Class Initialized
INFO - 2018-06-16 00:46:01 --> URI Class Initialized
INFO - 2018-06-16 00:46:01 --> Router Class Initialized
INFO - 2018-06-16 00:46:01 --> Output Class Initialized
INFO - 2018-06-16 00:46:01 --> Security Class Initialized
DEBUG - 2018-06-16 00:46:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-16 00:46:01 --> Input Class Initialized
INFO - 2018-06-16 00:46:01 --> Language Class Initialized
ERROR - 2018-06-16 00:46:01 --> 404 Page Not Found: /index
INFO - 2018-06-16 00:46:01 --> Config Class Initialized
INFO - 2018-06-16 00:46:01 --> Hooks Class Initialized
DEBUG - 2018-06-16 00:46:01 --> UTF-8 Support Enabled
INFO - 2018-06-16 00:46:01 --> Utf8 Class Initialized
INFO - 2018-06-16 00:46:01 --> URI Class Initialized
INFO - 2018-06-16 00:46:01 --> Router Class Initialized
INFO - 2018-06-16 00:46:01 --> Output Class Initialized
INFO - 2018-06-16 00:46:01 --> Security Class Initialized
DEBUG - 2018-06-16 00:46:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-16 00:46:01 --> Input Class Initialized
INFO - 2018-06-16 00:46:01 --> Language Class Initialized
ERROR - 2018-06-16 00:46:01 --> 404 Page Not Found: /index
INFO - 2018-06-16 00:46:04 --> Config Class Initialized
INFO - 2018-06-16 00:46:04 --> Hooks Class Initialized
DEBUG - 2018-06-16 00:46:04 --> UTF-8 Support Enabled
INFO - 2018-06-16 00:46:04 --> Utf8 Class Initialized
INFO - 2018-06-16 00:46:04 --> URI Class Initialized
INFO - 2018-06-16 00:46:04 --> Router Class Initialized
INFO - 2018-06-16 00:46:04 --> Output Class Initialized
INFO - 2018-06-16 00:46:04 --> Security Class Initialized
DEBUG - 2018-06-16 00:46:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-16 00:46:04 --> Input Class Initialized
INFO - 2018-06-16 00:46:04 --> Language Class Initialized
INFO - 2018-06-16 00:46:04 --> Language Class Initialized
INFO - 2018-06-16 00:46:04 --> Config Class Initialized
INFO - 2018-06-16 00:46:04 --> Loader Class Initialized
DEBUG - 2018-06-16 00:46:04 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-16 00:46:04 --> Helper loaded: url_helper
INFO - 2018-06-16 00:46:04 --> Helper loaded: form_helper
INFO - 2018-06-16 00:46:04 --> Helper loaded: date_helper
INFO - 2018-06-16 00:46:04 --> Helper loaded: util_helper
INFO - 2018-06-16 00:46:04 --> Helper loaded: text_helper
INFO - 2018-06-16 00:46:04 --> Helper loaded: string_helper
INFO - 2018-06-16 00:46:04 --> Database Driver Class Initialized
DEBUG - 2018-06-16 00:46:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-16 00:46:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-16 00:46:04 --> Email Class Initialized
INFO - 2018-06-16 00:46:04 --> Controller Class Initialized
DEBUG - 2018-06-16 00:46:04 --> Login MX_Controller Initialized
INFO - 2018-06-16 00:46:04 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-16 00:46:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-16 00:46:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-16 00:46:04 --> Email starts for user@colin.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-06-16 00:46:04 --> User session created for 4
INFO - 2018-06-16 00:46:04 --> Login status user@colin.com - success
INFO - 2018-06-16 00:46:04 --> Final output sent to browser
DEBUG - 2018-06-16 00:46:04 --> Total execution time: 0.4242
INFO - 2018-06-16 00:46:04 --> Config Class Initialized
INFO - 2018-06-16 00:46:04 --> Hooks Class Initialized
DEBUG - 2018-06-16 00:46:04 --> UTF-8 Support Enabled
INFO - 2018-06-16 00:46:04 --> Utf8 Class Initialized
INFO - 2018-06-16 00:46:04 --> URI Class Initialized
INFO - 2018-06-16 00:46:04 --> Router Class Initialized
INFO - 2018-06-16 00:46:04 --> Output Class Initialized
INFO - 2018-06-16 00:46:04 --> Security Class Initialized
DEBUG - 2018-06-16 00:46:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-16 00:46:04 --> Input Class Initialized
INFO - 2018-06-16 00:46:04 --> Language Class Initialized
INFO - 2018-06-16 00:46:04 --> Language Class Initialized
INFO - 2018-06-16 00:46:04 --> Config Class Initialized
INFO - 2018-06-16 00:46:04 --> Loader Class Initialized
DEBUG - 2018-06-16 00:46:04 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-16 00:46:04 --> Helper loaded: url_helper
INFO - 2018-06-16 00:46:05 --> Helper loaded: form_helper
INFO - 2018-06-16 00:46:05 --> Helper loaded: date_helper
INFO - 2018-06-16 00:46:05 --> Helper loaded: util_helper
INFO - 2018-06-16 00:46:05 --> Helper loaded: text_helper
INFO - 2018-06-16 00:46:05 --> Helper loaded: string_helper
INFO - 2018-06-16 00:46:05 --> Database Driver Class Initialized
DEBUG - 2018-06-16 00:46:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-16 00:46:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-16 00:46:05 --> Email Class Initialized
INFO - 2018-06-16 00:46:05 --> Controller Class Initialized
DEBUG - 2018-06-16 00:46:05 --> Home MX_Controller Initialized
DEBUG - 2018-06-16 00:46:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-16 00:46:05 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-16 00:46:05 --> Login MX_Controller Initialized
INFO - 2018-06-16 00:46:05 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-16 00:46:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-16 00:46:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-16 00:46:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-16 00:46:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-16 00:46:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-16 00:46:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-16 00:46:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-16 00:46:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-06-16 00:46:05 --> Final output sent to browser
DEBUG - 2018-06-16 00:46:05 --> Total execution time: 0.6898
INFO - 2018-06-16 00:46:06 --> Config Class Initialized
INFO - 2018-06-16 00:46:06 --> Config Class Initialized
INFO - 2018-06-16 00:46:06 --> Hooks Class Initialized
INFO - 2018-06-16 00:46:06 --> Hooks Class Initialized
DEBUG - 2018-06-16 00:46:06 --> UTF-8 Support Enabled
DEBUG - 2018-06-16 00:46:06 --> UTF-8 Support Enabled
INFO - 2018-06-16 00:46:06 --> Utf8 Class Initialized
INFO - 2018-06-16 00:46:06 --> Utf8 Class Initialized
INFO - 2018-06-16 00:46:06 --> URI Class Initialized
INFO - 2018-06-16 00:46:06 --> URI Class Initialized
INFO - 2018-06-16 00:46:06 --> Router Class Initialized
INFO - 2018-06-16 00:46:06 --> Router Class Initialized
INFO - 2018-06-16 00:46:06 --> Output Class Initialized
INFO - 2018-06-16 00:46:06 --> Output Class Initialized
INFO - 2018-06-16 00:46:06 --> Security Class Initialized
INFO - 2018-06-16 00:46:06 --> Security Class Initialized
DEBUG - 2018-06-16 00:46:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-06-16 00:46:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-16 00:46:06 --> Input Class Initialized
INFO - 2018-06-16 00:46:06 --> Input Class Initialized
INFO - 2018-06-16 00:46:06 --> Language Class Initialized
INFO - 2018-06-16 00:46:06 --> Language Class Initialized
ERROR - 2018-06-16 00:46:06 --> 404 Page Not Found: /index
ERROR - 2018-06-16 00:46:06 --> 404 Page Not Found: /index
INFO - 2018-06-16 00:46:06 --> Config Class Initialized
INFO - 2018-06-16 00:46:07 --> Hooks Class Initialized
DEBUG - 2018-06-16 00:46:07 --> UTF-8 Support Enabled
INFO - 2018-06-16 00:46:07 --> Utf8 Class Initialized
INFO - 2018-06-16 00:46:07 --> URI Class Initialized
INFO - 2018-06-16 00:46:07 --> Router Class Initialized
INFO - 2018-06-16 00:46:07 --> Output Class Initialized
INFO - 2018-06-16 00:46:07 --> Security Class Initialized
DEBUG - 2018-06-16 00:46:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-16 00:46:07 --> Input Class Initialized
INFO - 2018-06-16 00:46:07 --> Language Class Initialized
ERROR - 2018-06-16 00:46:07 --> 404 Page Not Found: /index
INFO - 2018-06-16 00:46:07 --> Config Class Initialized
INFO - 2018-06-16 00:46:07 --> Hooks Class Initialized
DEBUG - 2018-06-16 00:46:07 --> UTF-8 Support Enabled
INFO - 2018-06-16 00:46:07 --> Utf8 Class Initialized
INFO - 2018-06-16 00:46:07 --> URI Class Initialized
INFO - 2018-06-16 00:46:07 --> Router Class Initialized
INFO - 2018-06-16 00:46:07 --> Output Class Initialized
INFO - 2018-06-16 00:46:07 --> Security Class Initialized
DEBUG - 2018-06-16 00:46:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-16 00:46:07 --> Input Class Initialized
INFO - 2018-06-16 00:46:07 --> Language Class Initialized
ERROR - 2018-06-16 00:46:07 --> 404 Page Not Found: /index
INFO - 2018-06-16 00:46:07 --> Config Class Initialized
INFO - 2018-06-16 00:46:07 --> Hooks Class Initialized
DEBUG - 2018-06-16 00:46:07 --> UTF-8 Support Enabled
INFO - 2018-06-16 00:46:07 --> Utf8 Class Initialized
INFO - 2018-06-16 00:46:07 --> URI Class Initialized
INFO - 2018-06-16 00:46:07 --> Router Class Initialized
INFO - 2018-06-16 00:46:07 --> Output Class Initialized
INFO - 2018-06-16 00:46:07 --> Security Class Initialized
DEBUG - 2018-06-16 00:46:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-16 00:46:07 --> Input Class Initialized
INFO - 2018-06-16 00:46:07 --> Language Class Initialized
ERROR - 2018-06-16 00:46:07 --> 404 Page Not Found: /index
INFO - 2018-06-16 00:46:07 --> Config Class Initialized
INFO - 2018-06-16 00:46:07 --> Hooks Class Initialized
DEBUG - 2018-06-16 00:46:07 --> UTF-8 Support Enabled
INFO - 2018-06-16 00:46:07 --> Utf8 Class Initialized
INFO - 2018-06-16 00:46:07 --> URI Class Initialized
INFO - 2018-06-16 00:46:07 --> Router Class Initialized
INFO - 2018-06-16 00:46:07 --> Output Class Initialized
INFO - 2018-06-16 00:46:07 --> Security Class Initialized
DEBUG - 2018-06-16 00:46:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-16 00:46:07 --> Input Class Initialized
INFO - 2018-06-16 00:46:07 --> Language Class Initialized
ERROR - 2018-06-16 00:46:07 --> 404 Page Not Found: /index
INFO - 2018-06-16 00:46:07 --> Config Class Initialized
INFO - 2018-06-16 00:46:07 --> Hooks Class Initialized
DEBUG - 2018-06-16 00:46:07 --> UTF-8 Support Enabled
INFO - 2018-06-16 00:46:07 --> Utf8 Class Initialized
INFO - 2018-06-16 00:46:07 --> URI Class Initialized
INFO - 2018-06-16 00:46:07 --> Router Class Initialized
INFO - 2018-06-16 00:46:07 --> Output Class Initialized
INFO - 2018-06-16 00:46:07 --> Security Class Initialized
DEBUG - 2018-06-16 00:46:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-16 00:46:07 --> Input Class Initialized
INFO - 2018-06-16 00:46:07 --> Language Class Initialized
ERROR - 2018-06-16 00:46:07 --> 404 Page Not Found: /index
INFO - 2018-06-16 00:46:12 --> Config Class Initialized
INFO - 2018-06-16 00:46:12 --> Hooks Class Initialized
DEBUG - 2018-06-16 00:46:12 --> UTF-8 Support Enabled
INFO - 2018-06-16 00:46:12 --> Utf8 Class Initialized
INFO - 2018-06-16 00:46:12 --> URI Class Initialized
INFO - 2018-06-16 00:46:12 --> Router Class Initialized
INFO - 2018-06-16 00:46:12 --> Output Class Initialized
INFO - 2018-06-16 00:46:12 --> Security Class Initialized
DEBUG - 2018-06-16 00:46:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-16 00:46:12 --> Input Class Initialized
INFO - 2018-06-16 00:46:12 --> Language Class Initialized
INFO - 2018-06-16 00:46:12 --> Language Class Initialized
INFO - 2018-06-16 00:46:12 --> Config Class Initialized
INFO - 2018-06-16 00:46:12 --> Loader Class Initialized
DEBUG - 2018-06-16 00:46:12 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-16 00:46:12 --> Helper loaded: url_helper
INFO - 2018-06-16 00:46:12 --> Helper loaded: form_helper
INFO - 2018-06-16 00:46:12 --> Helper loaded: date_helper
INFO - 2018-06-16 00:46:12 --> Helper loaded: util_helper
INFO - 2018-06-16 00:46:12 --> Helper loaded: text_helper
INFO - 2018-06-16 00:46:12 --> Helper loaded: string_helper
INFO - 2018-06-16 00:46:12 --> Database Driver Class Initialized
DEBUG - 2018-06-16 00:46:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-16 00:46:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-16 00:46:12 --> Email Class Initialized
INFO - 2018-06-16 00:46:12 --> Controller Class Initialized
DEBUG - 2018-06-16 00:46:12 --> Login MX_Controller Initialized
INFO - 2018-06-16 00:46:12 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-16 00:46:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-16 00:46:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-16 00:46:12 --> Email starts for admin@colin.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-06-16 00:46:12 --> User session created for 1
INFO - 2018-06-16 00:46:12 --> Login status admin@colin.com - success
INFO - 2018-06-16 00:46:12 --> Final output sent to browser
DEBUG - 2018-06-16 00:46:12 --> Total execution time: 0.3615
INFO - 2018-06-16 00:46:12 --> Config Class Initialized
INFO - 2018-06-16 00:46:12 --> Hooks Class Initialized
DEBUG - 2018-06-16 00:46:12 --> UTF-8 Support Enabled
INFO - 2018-06-16 00:46:12 --> Utf8 Class Initialized
INFO - 2018-06-16 00:46:12 --> URI Class Initialized
INFO - 2018-06-16 00:46:12 --> Router Class Initialized
INFO - 2018-06-16 00:46:12 --> Output Class Initialized
INFO - 2018-06-16 00:46:12 --> Security Class Initialized
DEBUG - 2018-06-16 00:46:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-16 00:46:12 --> Input Class Initialized
INFO - 2018-06-16 00:46:12 --> Language Class Initialized
INFO - 2018-06-16 00:46:12 --> Language Class Initialized
INFO - 2018-06-16 00:46:12 --> Config Class Initialized
INFO - 2018-06-16 00:46:12 --> Loader Class Initialized
DEBUG - 2018-06-16 00:46:12 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-16 00:46:12 --> Helper loaded: url_helper
INFO - 2018-06-16 00:46:12 --> Helper loaded: form_helper
INFO - 2018-06-16 00:46:12 --> Helper loaded: date_helper
INFO - 2018-06-16 00:46:12 --> Helper loaded: util_helper
INFO - 2018-06-16 00:46:12 --> Helper loaded: text_helper
INFO - 2018-06-16 00:46:12 --> Helper loaded: string_helper
INFO - 2018-06-16 00:46:12 --> Database Driver Class Initialized
DEBUG - 2018-06-16 00:46:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-16 00:46:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-16 00:46:12 --> Email Class Initialized
INFO - 2018-06-16 00:46:12 --> Controller Class Initialized
DEBUG - 2018-06-16 00:46:12 --> videos MX_Controller Initialized
INFO - 2018-06-16 00:46:12 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-16 00:46:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-06-16 00:46:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-16 00:46:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-16 00:46:12 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-16 00:46:12 --> Login MX_Controller Initialized
DEBUG - 2018-06-16 00:46:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-16 00:46:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-16 00:46:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-16 00:46:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-16 00:46:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-16 00:46:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-16 00:46:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/videos/videos.php
INFO - 2018-06-16 00:46:13 --> Final output sent to browser
DEBUG - 2018-06-16 00:46:13 --> Total execution time: 0.7289
INFO - 2018-06-16 00:46:15 --> Config Class Initialized
INFO - 2018-06-16 00:46:15 --> Hooks Class Initialized
DEBUG - 2018-06-16 00:46:15 --> UTF-8 Support Enabled
INFO - 2018-06-16 00:46:15 --> Utf8 Class Initialized
INFO - 2018-06-16 00:46:15 --> URI Class Initialized
INFO - 2018-06-16 00:46:15 --> Router Class Initialized
INFO - 2018-06-16 00:46:15 --> Output Class Initialized
INFO - 2018-06-16 00:46:15 --> Security Class Initialized
DEBUG - 2018-06-16 00:46:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-16 00:46:15 --> Input Class Initialized
INFO - 2018-06-16 00:46:15 --> Language Class Initialized
INFO - 2018-06-16 00:46:15 --> Language Class Initialized
INFO - 2018-06-16 00:46:15 --> Config Class Initialized
INFO - 2018-06-16 00:46:15 --> Loader Class Initialized
DEBUG - 2018-06-16 00:46:15 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-16 00:46:15 --> Helper loaded: url_helper
INFO - 2018-06-16 00:46:15 --> Helper loaded: form_helper
INFO - 2018-06-16 00:46:16 --> Helper loaded: date_helper
INFO - 2018-06-16 00:46:16 --> Helper loaded: util_helper
INFO - 2018-06-16 00:46:16 --> Helper loaded: text_helper
INFO - 2018-06-16 00:46:16 --> Helper loaded: string_helper
INFO - 2018-06-16 00:46:16 --> Database Driver Class Initialized
DEBUG - 2018-06-16 00:46:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-16 00:46:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-16 00:46:16 --> Email Class Initialized
INFO - 2018-06-16 00:46:16 --> Controller Class Initialized
DEBUG - 2018-06-16 00:46:16 --> videos MX_Controller Initialized
INFO - 2018-06-16 00:46:16 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-16 00:46:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-06-16 00:46:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-16 00:46:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-16 00:46:16 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-16 00:46:16 --> Login MX_Controller Initialized
DEBUG - 2018-06-16 00:46:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-16 00:46:16 --> Final output sent to browser
DEBUG - 2018-06-16 00:46:16 --> Total execution time: 0.7076
INFO - 2018-06-16 01:29:58 --> Config Class Initialized
INFO - 2018-06-16 01:29:58 --> Hooks Class Initialized
DEBUG - 2018-06-16 01:29:58 --> UTF-8 Support Enabled
INFO - 2018-06-16 01:29:58 --> Utf8 Class Initialized
INFO - 2018-06-16 01:29:58 --> URI Class Initialized
INFO - 2018-06-16 01:29:58 --> Router Class Initialized
INFO - 2018-06-16 01:29:58 --> Output Class Initialized
INFO - 2018-06-16 01:29:58 --> Security Class Initialized
DEBUG - 2018-06-16 01:29:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-16 01:29:59 --> Input Class Initialized
INFO - 2018-06-16 01:29:59 --> Language Class Initialized
INFO - 2018-06-16 01:29:59 --> Language Class Initialized
INFO - 2018-06-16 01:29:59 --> Config Class Initialized
INFO - 2018-06-16 01:29:59 --> Loader Class Initialized
DEBUG - 2018-06-16 01:29:59 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-16 01:29:59 --> Helper loaded: url_helper
INFO - 2018-06-16 01:29:59 --> Helper loaded: form_helper
INFO - 2018-06-16 01:29:59 --> Helper loaded: date_helper
INFO - 2018-06-16 01:29:59 --> Helper loaded: util_helper
INFO - 2018-06-16 01:29:59 --> Helper loaded: text_helper
INFO - 2018-06-16 01:29:59 --> Helper loaded: string_helper
INFO - 2018-06-16 01:29:59 --> Database Driver Class Initialized
DEBUG - 2018-06-16 01:29:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-16 01:29:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-16 01:29:59 --> Email Class Initialized
INFO - 2018-06-16 01:29:59 --> Controller Class Initialized
DEBUG - 2018-06-16 01:29:59 --> Home MX_Controller Initialized
DEBUG - 2018-06-16 01:29:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-16 01:29:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-06-16 01:29:59 --> Final output sent to browser
DEBUG - 2018-06-16 01:29:59 --> Total execution time: 0.3886
INFO - 2018-06-16 01:29:59 --> Config Class Initialized
INFO - 2018-06-16 01:29:59 --> Hooks Class Initialized
DEBUG - 2018-06-16 01:29:59 --> UTF-8 Support Enabled
INFO - 2018-06-16 01:29:59 --> Utf8 Class Initialized
INFO - 2018-06-16 01:29:59 --> URI Class Initialized
INFO - 2018-06-16 01:29:59 --> Router Class Initialized
INFO - 2018-06-16 01:29:59 --> Output Class Initialized
INFO - 2018-06-16 01:29:59 --> Security Class Initialized
DEBUG - 2018-06-16 01:29:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-16 01:29:59 --> Input Class Initialized
INFO - 2018-06-16 01:29:59 --> Language Class Initialized
INFO - 2018-06-16 01:29:59 --> Language Class Initialized
INFO - 2018-06-16 01:29:59 --> Config Class Initialized
INFO - 2018-06-16 01:29:59 --> Loader Class Initialized
DEBUG - 2018-06-16 01:29:59 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-16 01:29:59 --> Helper loaded: url_helper
INFO - 2018-06-16 01:29:59 --> Helper loaded: form_helper
INFO - 2018-06-16 01:29:59 --> Helper loaded: date_helper
INFO - 2018-06-16 01:29:59 --> Helper loaded: util_helper
INFO - 2018-06-16 01:29:59 --> Helper loaded: text_helper
INFO - 2018-06-16 01:29:59 --> Helper loaded: string_helper
INFO - 2018-06-16 01:29:59 --> Database Driver Class Initialized
DEBUG - 2018-06-16 01:29:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-16 01:29:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-16 01:29:59 --> Email Class Initialized
INFO - 2018-06-16 01:29:59 --> Controller Class Initialized
DEBUG - 2018-06-16 01:29:59 --> Home MX_Controller Initialized
DEBUG - 2018-06-16 01:29:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-06-16 01:30:00 --> Config Class Initialized
INFO - 2018-06-16 01:30:00 --> Hooks Class Initialized
DEBUG - 2018-06-16 01:30:00 --> UTF-8 Support Enabled
INFO - 2018-06-16 01:30:00 --> Utf8 Class Initialized
INFO - 2018-06-16 01:30:00 --> URI Class Initialized
INFO - 2018-06-16 01:30:00 --> Router Class Initialized
INFO - 2018-06-16 01:30:00 --> Output Class Initialized
INFO - 2018-06-16 01:30:00 --> Security Class Initialized
DEBUG - 2018-06-16 01:30:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-16 01:30:00 --> Input Class Initialized
INFO - 2018-06-16 01:30:00 --> Language Class Initialized
INFO - 2018-06-16 01:30:00 --> Language Class Initialized
INFO - 2018-06-16 01:30:00 --> Config Class Initialized
INFO - 2018-06-16 01:30:00 --> Loader Class Initialized
DEBUG - 2018-06-16 01:30:00 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-16 01:30:00 --> Helper loaded: url_helper
INFO - 2018-06-16 01:30:00 --> Helper loaded: form_helper
INFO - 2018-06-16 01:30:00 --> Helper loaded: date_helper
INFO - 2018-06-16 01:30:00 --> Helper loaded: util_helper
INFO - 2018-06-16 01:30:00 --> Helper loaded: text_helper
INFO - 2018-06-16 01:30:00 --> Helper loaded: string_helper
INFO - 2018-06-16 01:30:00 --> Database Driver Class Initialized
DEBUG - 2018-06-16 01:30:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-16 01:30:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-16 01:30:00 --> Email Class Initialized
INFO - 2018-06-16 01:30:00 --> Controller Class Initialized
DEBUG - 2018-06-16 01:30:00 --> Home MX_Controller Initialized
DEBUG - 2018-06-16 01:30:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-16 01:30:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-06-16 01:30:01 --> Final output sent to browser
DEBUG - 2018-06-16 01:30:01 --> Total execution time: 0.3188
INFO - 2018-06-16 01:30:01 --> Config Class Initialized
INFO - 2018-06-16 01:30:01 --> Hooks Class Initialized
DEBUG - 2018-06-16 01:30:01 --> UTF-8 Support Enabled
INFO - 2018-06-16 01:30:01 --> Utf8 Class Initialized
INFO - 2018-06-16 01:30:01 --> URI Class Initialized
INFO - 2018-06-16 01:30:01 --> Router Class Initialized
INFO - 2018-06-16 01:30:01 --> Output Class Initialized
INFO - 2018-06-16 01:30:01 --> Security Class Initialized
DEBUG - 2018-06-16 01:30:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-16 01:30:01 --> Input Class Initialized
INFO - 2018-06-16 01:30:01 --> Language Class Initialized
INFO - 2018-06-16 01:30:01 --> Language Class Initialized
INFO - 2018-06-16 01:30:01 --> Config Class Initialized
INFO - 2018-06-16 01:30:01 --> Loader Class Initialized
DEBUG - 2018-06-16 01:30:01 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-16 01:30:01 --> Helper loaded: url_helper
INFO - 2018-06-16 01:30:01 --> Helper loaded: form_helper
INFO - 2018-06-16 01:30:01 --> Helper loaded: date_helper
INFO - 2018-06-16 01:30:01 --> Helper loaded: util_helper
INFO - 2018-06-16 01:30:01 --> Helper loaded: text_helper
INFO - 2018-06-16 01:30:01 --> Helper loaded: string_helper
INFO - 2018-06-16 01:30:01 --> Database Driver Class Initialized
DEBUG - 2018-06-16 01:30:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-16 01:30:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-16 01:30:01 --> Email Class Initialized
INFO - 2018-06-16 01:30:01 --> Controller Class Initialized
DEBUG - 2018-06-16 01:30:01 --> Home MX_Controller Initialized
DEBUG - 2018-06-16 01:30:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-06-16 01:30:03 --> Config Class Initialized
INFO - 2018-06-16 01:30:03 --> Hooks Class Initialized
DEBUG - 2018-06-16 01:30:03 --> UTF-8 Support Enabled
INFO - 2018-06-16 01:30:03 --> Utf8 Class Initialized
INFO - 2018-06-16 01:30:03 --> URI Class Initialized
INFO - 2018-06-16 01:30:03 --> Router Class Initialized
INFO - 2018-06-16 01:30:03 --> Output Class Initialized
INFO - 2018-06-16 01:30:03 --> Security Class Initialized
DEBUG - 2018-06-16 01:30:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-16 01:30:03 --> Input Class Initialized
INFO - 2018-06-16 01:30:03 --> Language Class Initialized
INFO - 2018-06-16 01:30:03 --> Language Class Initialized
INFO - 2018-06-16 01:30:03 --> Config Class Initialized
INFO - 2018-06-16 01:30:03 --> Loader Class Initialized
DEBUG - 2018-06-16 01:30:03 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-16 01:30:03 --> Helper loaded: url_helper
INFO - 2018-06-16 01:30:03 --> Helper loaded: form_helper
INFO - 2018-06-16 01:30:03 --> Helper loaded: date_helper
INFO - 2018-06-16 01:30:03 --> Helper loaded: util_helper
INFO - 2018-06-16 01:30:03 --> Helper loaded: text_helper
INFO - 2018-06-16 01:30:03 --> Helper loaded: string_helper
INFO - 2018-06-16 01:30:03 --> Database Driver Class Initialized
DEBUG - 2018-06-16 01:30:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-16 01:30:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-16 01:30:03 --> Email Class Initialized
INFO - 2018-06-16 01:30:03 --> Controller Class Initialized
DEBUG - 2018-06-16 01:30:03 --> Home MX_Controller Initialized
DEBUG - 2018-06-16 01:30:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-16 01:30:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-06-16 01:30:03 --> Final output sent to browser
DEBUG - 2018-06-16 01:30:03 --> Total execution time: 0.3131
INFO - 2018-06-16 01:30:03 --> Config Class Initialized
INFO - 2018-06-16 01:30:03 --> Hooks Class Initialized
DEBUG - 2018-06-16 01:30:03 --> UTF-8 Support Enabled
INFO - 2018-06-16 01:30:03 --> Utf8 Class Initialized
INFO - 2018-06-16 01:30:03 --> URI Class Initialized
INFO - 2018-06-16 01:30:03 --> Router Class Initialized
INFO - 2018-06-16 01:30:03 --> Output Class Initialized
INFO - 2018-06-16 01:30:03 --> Security Class Initialized
DEBUG - 2018-06-16 01:30:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-16 01:30:03 --> Input Class Initialized
INFO - 2018-06-16 01:30:03 --> Language Class Initialized
INFO - 2018-06-16 01:30:03 --> Language Class Initialized
INFO - 2018-06-16 01:30:03 --> Config Class Initialized
INFO - 2018-06-16 01:30:03 --> Loader Class Initialized
DEBUG - 2018-06-16 01:30:03 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-16 01:30:03 --> Helper loaded: url_helper
INFO - 2018-06-16 01:30:03 --> Helper loaded: form_helper
INFO - 2018-06-16 01:30:03 --> Helper loaded: date_helper
INFO - 2018-06-16 01:30:03 --> Helper loaded: util_helper
INFO - 2018-06-16 01:30:03 --> Helper loaded: text_helper
INFO - 2018-06-16 01:30:03 --> Helper loaded: string_helper
INFO - 2018-06-16 01:30:04 --> Database Driver Class Initialized
DEBUG - 2018-06-16 01:30:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-16 01:30:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-16 01:30:04 --> Email Class Initialized
INFO - 2018-06-16 01:30:04 --> Controller Class Initialized
DEBUG - 2018-06-16 01:30:04 --> Home MX_Controller Initialized
DEBUG - 2018-06-16 01:30:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-06-16 01:30:05 --> Config Class Initialized
INFO - 2018-06-16 01:30:05 --> Hooks Class Initialized
DEBUG - 2018-06-16 01:30:05 --> UTF-8 Support Enabled
INFO - 2018-06-16 01:30:05 --> Utf8 Class Initialized
INFO - 2018-06-16 01:30:05 --> URI Class Initialized
INFO - 2018-06-16 01:30:05 --> Router Class Initialized
INFO - 2018-06-16 01:30:05 --> Output Class Initialized
INFO - 2018-06-16 01:30:05 --> Security Class Initialized
DEBUG - 2018-06-16 01:30:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-16 01:30:05 --> Input Class Initialized
INFO - 2018-06-16 01:30:05 --> Language Class Initialized
INFO - 2018-06-16 01:30:05 --> Language Class Initialized
INFO - 2018-06-16 01:30:05 --> Config Class Initialized
INFO - 2018-06-16 01:30:05 --> Loader Class Initialized
DEBUG - 2018-06-16 01:30:05 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-16 01:30:05 --> Config Class Initialized
INFO - 2018-06-16 01:30:05 --> Helper loaded: url_helper
INFO - 2018-06-16 01:30:05 --> Helper loaded: form_helper
INFO - 2018-06-16 01:30:05 --> Helper loaded: date_helper
INFO - 2018-06-16 01:30:05 --> Helper loaded: util_helper
INFO - 2018-06-16 01:30:05 --> Helper loaded: text_helper
INFO - 2018-06-16 01:30:05 --> Helper loaded: string_helper
INFO - 2018-06-16 01:30:05 --> Hooks Class Initialized
INFO - 2018-06-16 01:30:05 --> Database Driver Class Initialized
DEBUG - 2018-06-16 01:30:05 --> UTF-8 Support Enabled
DEBUG - 2018-06-16 01:30:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-16 01:30:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-16 01:30:05 --> Utf8 Class Initialized
INFO - 2018-06-16 01:30:05 --> URI Class Initialized
INFO - 2018-06-16 01:30:05 --> Email Class Initialized
INFO - 2018-06-16 01:30:05 --> Controller Class Initialized
INFO - 2018-06-16 01:30:05 --> Router Class Initialized
DEBUG - 2018-06-16 01:30:05 --> Home MX_Controller Initialized
INFO - 2018-06-16 01:30:05 --> Output Class Initialized
DEBUG - 2018-06-16 01:30:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-06-16 01:30:05 --> Security Class Initialized
DEBUG - 2018-06-16 01:30:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-06-16 01:30:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-06-16 01:30:05 --> Input Class Initialized
INFO - 2018-06-16 01:30:05 --> Language Class Initialized
INFO - 2018-06-16 01:30:05 --> Language Class Initialized
INFO - 2018-06-16 01:30:05 --> Config Class Initialized
INFO - 2018-06-16 01:30:05 --> Loader Class Initialized
DEBUG - 2018-06-16 01:30:05 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-16 01:30:05 --> Final output sent to browser
DEBUG - 2018-06-16 01:30:05 --> Total execution time: 0.3298
INFO - 2018-06-16 01:30:05 --> Helper loaded: url_helper
INFO - 2018-06-16 01:30:05 --> Helper loaded: form_helper
INFO - 2018-06-16 01:30:05 --> Config Class Initialized
INFO - 2018-06-16 01:30:05 --> Hooks Class Initialized
INFO - 2018-06-16 01:30:05 --> Helper loaded: date_helper
INFO - 2018-06-16 01:30:05 --> Helper loaded: util_helper
DEBUG - 2018-06-16 01:30:05 --> UTF-8 Support Enabled
INFO - 2018-06-16 01:30:05 --> Utf8 Class Initialized
INFO - 2018-06-16 01:30:05 --> Helper loaded: text_helper
INFO - 2018-06-16 01:30:05 --> Helper loaded: string_helper
INFO - 2018-06-16 01:30:05 --> URI Class Initialized
INFO - 2018-06-16 01:30:05 --> Router Class Initialized
INFO - 2018-06-16 01:30:05 --> Database Driver Class Initialized
INFO - 2018-06-16 01:30:05 --> Output Class Initialized
DEBUG - 2018-06-16 01:30:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-16 01:30:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-16 01:30:05 --> Security Class Initialized
DEBUG - 2018-06-16 01:30:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-16 01:30:05 --> Email Class Initialized
INFO - 2018-06-16 01:30:05 --> Input Class Initialized
INFO - 2018-06-16 01:30:05 --> Controller Class Initialized
INFO - 2018-06-16 01:30:05 --> Language Class Initialized
DEBUG - 2018-06-16 01:30:05 --> Home MX_Controller Initialized
INFO - 2018-06-16 01:30:05 --> Language Class Initialized
INFO - 2018-06-16 01:30:05 --> Config Class Initialized
DEBUG - 2018-06-16 01:30:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-06-16 01:30:05 --> Loader Class Initialized
DEBUG - 2018-06-16 01:30:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-16 01:30:05 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-16 01:30:05 --> Helper loaded: url_helper
INFO - 2018-06-16 01:30:05 --> Helper loaded: form_helper
INFO - 2018-06-16 01:30:05 --> Helper loaded: date_helper
INFO - 2018-06-16 01:30:05 --> Final output sent to browser
DEBUG - 2018-06-16 01:30:05 --> Total execution time: 0.3840
INFO - 2018-06-16 01:30:05 --> Helper loaded: util_helper
INFO - 2018-06-16 01:30:05 --> Helper loaded: text_helper
INFO - 2018-06-16 01:30:05 --> Config Class Initialized
INFO - 2018-06-16 01:30:05 --> Hooks Class Initialized
INFO - 2018-06-16 01:30:05 --> Helper loaded: string_helper
DEBUG - 2018-06-16 01:30:05 --> UTF-8 Support Enabled
INFO - 2018-06-16 01:30:05 --> Database Driver Class Initialized
INFO - 2018-06-16 01:30:05 --> Utf8 Class Initialized
DEBUG - 2018-06-16 01:30:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-16 01:30:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-16 01:30:05 --> URI Class Initialized
INFO - 2018-06-16 01:30:05 --> Router Class Initialized
INFO - 2018-06-16 01:30:05 --> Email Class Initialized
INFO - 2018-06-16 01:30:05 --> Controller Class Initialized
INFO - 2018-06-16 01:30:05 --> Output Class Initialized
DEBUG - 2018-06-16 01:30:05 --> Home MX_Controller Initialized
INFO - 2018-06-16 01:30:05 --> Security Class Initialized
DEBUG - 2018-06-16 01:30:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-16 01:30:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-16 01:30:05 --> Input Class Initialized
INFO - 2018-06-16 01:30:05 --> Language Class Initialized
INFO - 2018-06-16 01:30:05 --> Language Class Initialized
INFO - 2018-06-16 01:30:05 --> Config Class Initialized
INFO - 2018-06-16 01:30:05 --> Loader Class Initialized
DEBUG - 2018-06-16 01:30:05 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-16 01:30:05 --> Helper loaded: url_helper
INFO - 2018-06-16 01:30:05 --> Helper loaded: form_helper
INFO - 2018-06-16 01:30:05 --> Helper loaded: date_helper
INFO - 2018-06-16 01:30:05 --> Helper loaded: util_helper
INFO - 2018-06-16 01:30:05 --> Helper loaded: text_helper
INFO - 2018-06-16 01:30:05 --> Helper loaded: string_helper
INFO - 2018-06-16 01:30:05 --> Database Driver Class Initialized
DEBUG - 2018-06-16 01:30:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-16 01:30:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-16 01:30:06 --> Email Class Initialized
INFO - 2018-06-16 01:30:06 --> Controller Class Initialized
DEBUG - 2018-06-16 01:30:06 --> Home MX_Controller Initialized
DEBUG - 2018-06-16 01:30:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-06-16 01:30:07 --> Config Class Initialized
INFO - 2018-06-16 01:30:07 --> Hooks Class Initialized
DEBUG - 2018-06-16 01:30:07 --> UTF-8 Support Enabled
INFO - 2018-06-16 01:30:07 --> Utf8 Class Initialized
INFO - 2018-06-16 01:30:07 --> URI Class Initialized
INFO - 2018-06-16 01:30:07 --> Router Class Initialized
INFO - 2018-06-16 01:30:07 --> Output Class Initialized
INFO - 2018-06-16 01:30:07 --> Security Class Initialized
DEBUG - 2018-06-16 01:30:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-16 01:30:07 --> Input Class Initialized
INFO - 2018-06-16 01:30:07 --> Language Class Initialized
INFO - 2018-06-16 01:30:07 --> Language Class Initialized
INFO - 2018-06-16 01:30:07 --> Config Class Initialized
INFO - 2018-06-16 01:30:07 --> Loader Class Initialized
DEBUG - 2018-06-16 01:30:07 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-16 01:30:07 --> Helper loaded: url_helper
INFO - 2018-06-16 01:30:07 --> Helper loaded: form_helper
INFO - 2018-06-16 01:30:07 --> Helper loaded: date_helper
INFO - 2018-06-16 01:30:07 --> Helper loaded: util_helper
INFO - 2018-06-16 01:30:07 --> Helper loaded: text_helper
INFO - 2018-06-16 01:30:07 --> Helper loaded: string_helper
INFO - 2018-06-16 01:30:07 --> Database Driver Class Initialized
DEBUG - 2018-06-16 01:30:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-16 01:30:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-16 01:30:07 --> Email Class Initialized
INFO - 2018-06-16 01:30:07 --> Controller Class Initialized
DEBUG - 2018-06-16 01:30:07 --> Home MX_Controller Initialized
DEBUG - 2018-06-16 01:30:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-16 01:30:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-06-16 01:30:07 --> Final output sent to browser
DEBUG - 2018-06-16 01:30:07 --> Total execution time: 0.3117
INFO - 2018-06-16 01:30:07 --> Config Class Initialized
INFO - 2018-06-16 01:30:07 --> Hooks Class Initialized
DEBUG - 2018-06-16 01:30:08 --> UTF-8 Support Enabled
INFO - 2018-06-16 01:30:08 --> Utf8 Class Initialized
INFO - 2018-06-16 01:30:08 --> URI Class Initialized
INFO - 2018-06-16 01:30:08 --> Router Class Initialized
INFO - 2018-06-16 01:30:08 --> Output Class Initialized
INFO - 2018-06-16 01:30:08 --> Security Class Initialized
DEBUG - 2018-06-16 01:30:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-16 01:30:08 --> Input Class Initialized
INFO - 2018-06-16 01:30:08 --> Language Class Initialized
INFO - 2018-06-16 01:30:08 --> Language Class Initialized
INFO - 2018-06-16 01:30:08 --> Config Class Initialized
INFO - 2018-06-16 01:30:08 --> Loader Class Initialized
DEBUG - 2018-06-16 01:30:08 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-16 01:30:08 --> Helper loaded: url_helper
INFO - 2018-06-16 01:30:08 --> Helper loaded: form_helper
INFO - 2018-06-16 01:30:08 --> Helper loaded: date_helper
INFO - 2018-06-16 01:30:08 --> Helper loaded: util_helper
INFO - 2018-06-16 01:30:08 --> Helper loaded: text_helper
INFO - 2018-06-16 01:30:08 --> Helper loaded: string_helper
INFO - 2018-06-16 01:30:08 --> Database Driver Class Initialized
DEBUG - 2018-06-16 01:30:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-16 01:30:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-16 01:30:08 --> Email Class Initialized
INFO - 2018-06-16 01:30:08 --> Controller Class Initialized
DEBUG - 2018-06-16 01:30:08 --> Home MX_Controller Initialized
DEBUG - 2018-06-16 01:30:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-06-16 01:30:09 --> Config Class Initialized
INFO - 2018-06-16 01:30:09 --> Hooks Class Initialized
DEBUG - 2018-06-16 01:30:09 --> UTF-8 Support Enabled
INFO - 2018-06-16 01:30:09 --> Utf8 Class Initialized
INFO - 2018-06-16 01:30:09 --> URI Class Initialized
INFO - 2018-06-16 01:30:09 --> Router Class Initialized
INFO - 2018-06-16 01:30:09 --> Output Class Initialized
INFO - 2018-06-16 01:30:09 --> Security Class Initialized
DEBUG - 2018-06-16 01:30:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-16 01:30:09 --> Input Class Initialized
INFO - 2018-06-16 01:30:09 --> Language Class Initialized
INFO - 2018-06-16 01:30:09 --> Language Class Initialized
INFO - 2018-06-16 01:30:09 --> Config Class Initialized
INFO - 2018-06-16 01:30:09 --> Loader Class Initialized
DEBUG - 2018-06-16 01:30:09 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-16 01:30:09 --> Helper loaded: url_helper
INFO - 2018-06-16 01:30:09 --> Helper loaded: form_helper
INFO - 2018-06-16 01:30:09 --> Helper loaded: date_helper
INFO - 2018-06-16 01:30:09 --> Helper loaded: util_helper
INFO - 2018-06-16 01:30:09 --> Helper loaded: text_helper
INFO - 2018-06-16 01:30:09 --> Helper loaded: string_helper
INFO - 2018-06-16 01:30:09 --> Database Driver Class Initialized
DEBUG - 2018-06-16 01:30:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-16 01:30:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-16 01:30:09 --> Email Class Initialized
INFO - 2018-06-16 01:30:09 --> Controller Class Initialized
DEBUG - 2018-06-16 01:30:09 --> Home MX_Controller Initialized
DEBUG - 2018-06-16 01:30:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-16 01:30:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-06-16 01:30:09 --> Final output sent to browser
DEBUG - 2018-06-16 01:30:09 --> Total execution time: 0.3091
INFO - 2018-06-16 01:30:09 --> Config Class Initialized
INFO - 2018-06-16 01:30:09 --> Hooks Class Initialized
DEBUG - 2018-06-16 01:30:09 --> UTF-8 Support Enabled
INFO - 2018-06-16 01:30:09 --> Utf8 Class Initialized
INFO - 2018-06-16 01:30:09 --> URI Class Initialized
INFO - 2018-06-16 01:30:09 --> Router Class Initialized
INFO - 2018-06-16 01:30:09 --> Output Class Initialized
INFO - 2018-06-16 01:30:09 --> Security Class Initialized
DEBUG - 2018-06-16 01:30:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-16 01:30:09 --> Input Class Initialized
INFO - 2018-06-16 01:30:09 --> Language Class Initialized
INFO - 2018-06-16 01:30:09 --> Language Class Initialized
INFO - 2018-06-16 01:30:09 --> Config Class Initialized
INFO - 2018-06-16 01:30:09 --> Loader Class Initialized
DEBUG - 2018-06-16 01:30:09 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-16 01:30:09 --> Helper loaded: url_helper
INFO - 2018-06-16 01:30:09 --> Helper loaded: form_helper
INFO - 2018-06-16 01:30:09 --> Helper loaded: date_helper
INFO - 2018-06-16 01:30:09 --> Helper loaded: util_helper
INFO - 2018-06-16 01:30:09 --> Helper loaded: text_helper
INFO - 2018-06-16 01:30:09 --> Helper loaded: string_helper
INFO - 2018-06-16 01:30:09 --> Database Driver Class Initialized
DEBUG - 2018-06-16 01:30:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-16 01:30:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-16 01:30:09 --> Email Class Initialized
INFO - 2018-06-16 01:30:09 --> Controller Class Initialized
DEBUG - 2018-06-16 01:30:09 --> Home MX_Controller Initialized
DEBUG - 2018-06-16 01:30:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-06-16 01:30:11 --> Config Class Initialized
INFO - 2018-06-16 01:30:11 --> Hooks Class Initialized
DEBUG - 2018-06-16 01:30:11 --> UTF-8 Support Enabled
INFO - 2018-06-16 01:30:11 --> Utf8 Class Initialized
INFO - 2018-06-16 01:30:11 --> URI Class Initialized
INFO - 2018-06-16 01:30:11 --> Router Class Initialized
INFO - 2018-06-16 01:30:11 --> Output Class Initialized
INFO - 2018-06-16 01:30:11 --> Security Class Initialized
DEBUG - 2018-06-16 01:30:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-16 01:30:11 --> Input Class Initialized
INFO - 2018-06-16 01:30:11 --> Language Class Initialized
INFO - 2018-06-16 01:30:11 --> Language Class Initialized
INFO - 2018-06-16 01:30:11 --> Config Class Initialized
INFO - 2018-06-16 01:30:11 --> Loader Class Initialized
DEBUG - 2018-06-16 01:30:11 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-16 01:30:11 --> Helper loaded: url_helper
INFO - 2018-06-16 01:30:11 --> Helper loaded: form_helper
INFO - 2018-06-16 01:30:11 --> Helper loaded: date_helper
INFO - 2018-06-16 01:30:11 --> Helper loaded: util_helper
INFO - 2018-06-16 01:30:11 --> Helper loaded: text_helper
INFO - 2018-06-16 01:30:11 --> Helper loaded: string_helper
INFO - 2018-06-16 01:30:11 --> Database Driver Class Initialized
DEBUG - 2018-06-16 01:30:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-16 01:30:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-16 01:30:11 --> Email Class Initialized
INFO - 2018-06-16 01:30:11 --> Controller Class Initialized
DEBUG - 2018-06-16 01:30:11 --> Home MX_Controller Initialized
DEBUG - 2018-06-16 01:30:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-16 01:30:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-06-16 01:30:11 --> Final output sent to browser
DEBUG - 2018-06-16 01:30:11 --> Total execution time: 0.3623
INFO - 2018-06-16 01:30:11 --> Config Class Initialized
INFO - 2018-06-16 01:30:11 --> Hooks Class Initialized
DEBUG - 2018-06-16 01:30:11 --> UTF-8 Support Enabled
INFO - 2018-06-16 01:30:11 --> Utf8 Class Initialized
INFO - 2018-06-16 01:30:11 --> URI Class Initialized
INFO - 2018-06-16 01:30:11 --> Router Class Initialized
INFO - 2018-06-16 01:30:11 --> Output Class Initialized
INFO - 2018-06-16 01:30:11 --> Security Class Initialized
DEBUG - 2018-06-16 01:30:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-16 01:30:11 --> Input Class Initialized
INFO - 2018-06-16 01:30:11 --> Language Class Initialized
INFO - 2018-06-16 01:30:11 --> Language Class Initialized
INFO - 2018-06-16 01:30:11 --> Config Class Initialized
INFO - 2018-06-16 01:30:11 --> Loader Class Initialized
DEBUG - 2018-06-16 01:30:11 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-16 01:30:11 --> Helper loaded: url_helper
INFO - 2018-06-16 01:30:11 --> Helper loaded: form_helper
INFO - 2018-06-16 01:30:11 --> Helper loaded: date_helper
INFO - 2018-06-16 01:30:11 --> Helper loaded: util_helper
INFO - 2018-06-16 01:30:11 --> Helper loaded: text_helper
INFO - 2018-06-16 01:30:11 --> Helper loaded: string_helper
INFO - 2018-06-16 01:30:11 --> Database Driver Class Initialized
DEBUG - 2018-06-16 01:30:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-16 01:30:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-16 01:30:11 --> Email Class Initialized
INFO - 2018-06-16 01:30:11 --> Controller Class Initialized
DEBUG - 2018-06-16 01:30:11 --> Home MX_Controller Initialized
DEBUG - 2018-06-16 01:30:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-06-16 03:02:19 --> Config Class Initialized
INFO - 2018-06-16 03:02:19 --> Hooks Class Initialized
DEBUG - 2018-06-16 03:02:19 --> UTF-8 Support Enabled
INFO - 2018-06-16 03:02:19 --> Utf8 Class Initialized
INFO - 2018-06-16 03:02:19 --> URI Class Initialized
INFO - 2018-06-16 03:02:19 --> Router Class Initialized
INFO - 2018-06-16 03:02:19 --> Output Class Initialized
INFO - 2018-06-16 03:02:19 --> Security Class Initialized
DEBUG - 2018-06-16 03:02:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-16 03:02:19 --> Input Class Initialized
INFO - 2018-06-16 03:02:19 --> Language Class Initialized
INFO - 2018-06-16 03:02:19 --> Language Class Initialized
INFO - 2018-06-16 03:02:19 --> Config Class Initialized
INFO - 2018-06-16 03:02:19 --> Loader Class Initialized
DEBUG - 2018-06-16 03:02:19 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-16 03:02:19 --> Helper loaded: url_helper
INFO - 2018-06-16 03:02:19 --> Helper loaded: form_helper
INFO - 2018-06-16 03:02:19 --> Helper loaded: date_helper
INFO - 2018-06-16 03:02:19 --> Helper loaded: util_helper
INFO - 2018-06-16 03:02:19 --> Helper loaded: text_helper
INFO - 2018-06-16 03:02:19 --> Helper loaded: string_helper
INFO - 2018-06-16 03:02:19 --> Database Driver Class Initialized
DEBUG - 2018-06-16 03:02:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-16 03:02:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-16 03:02:19 --> Email Class Initialized
INFO - 2018-06-16 03:02:19 --> Controller Class Initialized
DEBUG - 2018-06-16 03:02:19 --> Lessions MX_Controller Initialized
INFO - 2018-06-16 03:02:19 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-16 03:02:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Lessions_model.php
DEBUG - 2018-06-16 03:02:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-16 03:02:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-16 03:02:19 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-16 03:02:19 --> Login MX_Controller Initialized
DEBUG - 2018-06-16 03:02:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-16 03:02:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-16 03:02:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-16 03:02:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-16 03:02:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-16 03:02:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-16 03:02:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/lessions/lessions.php
INFO - 2018-06-16 03:02:19 --> Final output sent to browser
DEBUG - 2018-06-16 03:02:19 --> Total execution time: 0.4207
INFO - 2018-06-16 03:02:20 --> Config Class Initialized
INFO - 2018-06-16 03:02:20 --> Hooks Class Initialized
DEBUG - 2018-06-16 03:02:20 --> UTF-8 Support Enabled
INFO - 2018-06-16 03:02:20 --> Utf8 Class Initialized
INFO - 2018-06-16 03:02:20 --> URI Class Initialized
INFO - 2018-06-16 03:02:20 --> Router Class Initialized
INFO - 2018-06-16 03:02:20 --> Output Class Initialized
INFO - 2018-06-16 03:02:20 --> Security Class Initialized
DEBUG - 2018-06-16 03:02:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-16 03:02:20 --> Input Class Initialized
INFO - 2018-06-16 03:02:20 --> Language Class Initialized
INFO - 2018-06-16 03:02:20 --> Language Class Initialized
INFO - 2018-06-16 03:02:20 --> Config Class Initialized
INFO - 2018-06-16 03:02:20 --> Loader Class Initialized
DEBUG - 2018-06-16 03:02:20 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-16 03:02:20 --> Helper loaded: url_helper
INFO - 2018-06-16 03:02:20 --> Helper loaded: form_helper
INFO - 2018-06-16 03:02:20 --> Helper loaded: date_helper
INFO - 2018-06-16 03:02:20 --> Helper loaded: util_helper
INFO - 2018-06-16 03:02:20 --> Helper loaded: text_helper
INFO - 2018-06-16 03:02:20 --> Helper loaded: string_helper
INFO - 2018-06-16 03:02:20 --> Database Driver Class Initialized
DEBUG - 2018-06-16 03:02:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-16 03:02:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-16 03:02:20 --> Email Class Initialized
INFO - 2018-06-16 03:02:20 --> Controller Class Initialized
DEBUG - 2018-06-16 03:02:20 --> Lessions MX_Controller Initialized
INFO - 2018-06-16 03:02:20 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-16 03:02:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Lessions_model.php
DEBUG - 2018-06-16 03:02:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-16 03:02:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-16 03:02:20 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-16 03:02:20 --> Login MX_Controller Initialized
DEBUG - 2018-06-16 03:02:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
ERROR - 2018-06-16 03:02:20 --> Query error: Unknown column 'lessions.added_date' in 'field list' - Invalid query: SELECT  lessions.lession_id,lessions.lession_name,chapters.chapter_name,programs.program_name,lessions.added_date,lessions.status,lessions.lession_id FROM   lessions left join chapters on lessions.chapter_id = chapters.chapter_id left join programs on lessions.program_id = programs.program_id  WHERE lessions.lession_id!= ''     LIMIT 0, 10
INFO - 2018-06-16 03:02:20 --> Language file loaded: language/english/db_lang.php
INFO - 2018-06-16 03:04:32 --> Config Class Initialized
INFO - 2018-06-16 03:04:32 --> Hooks Class Initialized
DEBUG - 2018-06-16 03:04:32 --> UTF-8 Support Enabled
INFO - 2018-06-16 03:04:32 --> Utf8 Class Initialized
INFO - 2018-06-16 03:04:32 --> URI Class Initialized
INFO - 2018-06-16 03:04:32 --> Router Class Initialized
INFO - 2018-06-16 03:04:32 --> Output Class Initialized
INFO - 2018-06-16 03:04:32 --> Security Class Initialized
DEBUG - 2018-06-16 03:04:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-16 03:04:32 --> Input Class Initialized
INFO - 2018-06-16 03:04:32 --> Language Class Initialized
INFO - 2018-06-16 03:04:32 --> Language Class Initialized
INFO - 2018-06-16 03:04:32 --> Config Class Initialized
INFO - 2018-06-16 03:04:33 --> Loader Class Initialized
DEBUG - 2018-06-16 03:04:33 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-16 03:04:33 --> Helper loaded: url_helper
INFO - 2018-06-16 03:04:33 --> Helper loaded: form_helper
INFO - 2018-06-16 03:04:33 --> Helper loaded: date_helper
INFO - 2018-06-16 03:04:33 --> Helper loaded: util_helper
INFO - 2018-06-16 03:04:33 --> Helper loaded: text_helper
INFO - 2018-06-16 03:04:33 --> Helper loaded: string_helper
INFO - 2018-06-16 03:04:33 --> Database Driver Class Initialized
DEBUG - 2018-06-16 03:04:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-16 03:04:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-16 03:04:33 --> Email Class Initialized
INFO - 2018-06-16 03:04:33 --> Controller Class Initialized
DEBUG - 2018-06-16 03:04:33 --> Lessions MX_Controller Initialized
INFO - 2018-06-16 03:04:33 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-16 03:04:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Lessions_model.php
DEBUG - 2018-06-16 03:04:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-16 03:04:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-16 03:04:33 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-16 03:04:33 --> Login MX_Controller Initialized
DEBUG - 2018-06-16 03:04:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-16 03:04:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-16 03:04:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-16 03:04:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-16 03:04:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-16 03:04:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-16 03:04:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/lessions/lessions.php
INFO - 2018-06-16 03:04:33 --> Final output sent to browser
DEBUG - 2018-06-16 03:04:33 --> Total execution time: 0.4553
INFO - 2018-06-16 03:04:33 --> Config Class Initialized
INFO - 2018-06-16 03:04:33 --> Hooks Class Initialized
DEBUG - 2018-06-16 03:04:33 --> UTF-8 Support Enabled
INFO - 2018-06-16 03:04:33 --> Utf8 Class Initialized
INFO - 2018-06-16 03:04:33 --> URI Class Initialized
INFO - 2018-06-16 03:04:33 --> Router Class Initialized
INFO - 2018-06-16 03:04:33 --> Output Class Initialized
INFO - 2018-06-16 03:04:33 --> Security Class Initialized
DEBUG - 2018-06-16 03:04:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-16 03:04:33 --> Input Class Initialized
INFO - 2018-06-16 03:04:34 --> Language Class Initialized
INFO - 2018-06-16 03:04:34 --> Language Class Initialized
INFO - 2018-06-16 03:04:34 --> Config Class Initialized
INFO - 2018-06-16 03:04:34 --> Loader Class Initialized
DEBUG - 2018-06-16 03:04:34 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-16 03:04:34 --> Helper loaded: url_helper
INFO - 2018-06-16 03:04:34 --> Helper loaded: form_helper
INFO - 2018-06-16 03:04:34 --> Helper loaded: date_helper
INFO - 2018-06-16 03:04:34 --> Helper loaded: util_helper
INFO - 2018-06-16 03:04:34 --> Helper loaded: text_helper
INFO - 2018-06-16 03:04:34 --> Helper loaded: string_helper
INFO - 2018-06-16 03:04:34 --> Database Driver Class Initialized
DEBUG - 2018-06-16 03:04:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-16 03:04:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-16 03:04:34 --> Email Class Initialized
INFO - 2018-06-16 03:04:34 --> Controller Class Initialized
DEBUG - 2018-06-16 03:04:34 --> Lessions MX_Controller Initialized
INFO - 2018-06-16 03:04:34 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-16 03:04:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Lessions_model.php
DEBUG - 2018-06-16 03:04:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-16 03:04:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-16 03:04:34 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-16 03:04:34 --> Login MX_Controller Initialized
DEBUG - 2018-06-16 03:04:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
ERROR - 2018-06-16 03:04:34 --> Query error: Unknown column 'lessions.status' in 'field list' - Invalid query: SELECT  lessions.lession_id,lessions.lession_name,chapters.chapter_name,programs.program_name,lessions.added_date,lessions.status,lessions.lession_id FROM   lessions left join chapters on lessions.chapter_id = chapters.chapter_id left join programs on lessions.program_id = programs.program_id  WHERE lessions.lession_id!= ''     LIMIT 0, 10
INFO - 2018-06-16 03:04:34 --> Language file loaded: language/english/db_lang.php
INFO - 2018-06-16 03:05:33 --> Config Class Initialized
INFO - 2018-06-16 03:05:33 --> Hooks Class Initialized
DEBUG - 2018-06-16 03:05:33 --> UTF-8 Support Enabled
INFO - 2018-06-16 03:05:33 --> Utf8 Class Initialized
INFO - 2018-06-16 03:05:33 --> URI Class Initialized
INFO - 2018-06-16 03:05:33 --> Router Class Initialized
INFO - 2018-06-16 03:05:33 --> Output Class Initialized
INFO - 2018-06-16 03:05:33 --> Security Class Initialized
DEBUG - 2018-06-16 03:05:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-16 03:05:33 --> Input Class Initialized
INFO - 2018-06-16 03:05:33 --> Language Class Initialized
INFO - 2018-06-16 03:05:33 --> Language Class Initialized
INFO - 2018-06-16 03:05:33 --> Config Class Initialized
INFO - 2018-06-16 03:05:33 --> Loader Class Initialized
DEBUG - 2018-06-16 03:05:33 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-16 03:05:34 --> Helper loaded: url_helper
INFO - 2018-06-16 03:05:34 --> Helper loaded: form_helper
INFO - 2018-06-16 03:05:34 --> Helper loaded: date_helper
INFO - 2018-06-16 03:05:34 --> Helper loaded: util_helper
INFO - 2018-06-16 03:05:34 --> Helper loaded: text_helper
INFO - 2018-06-16 03:05:34 --> Helper loaded: string_helper
INFO - 2018-06-16 03:05:34 --> Database Driver Class Initialized
DEBUG - 2018-06-16 03:05:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-16 03:05:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-16 03:05:34 --> Email Class Initialized
INFO - 2018-06-16 03:05:34 --> Controller Class Initialized
DEBUG - 2018-06-16 03:05:34 --> Lessions MX_Controller Initialized
INFO - 2018-06-16 03:05:34 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-16 03:05:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Lessions_model.php
DEBUG - 2018-06-16 03:05:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-16 03:05:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-16 03:05:34 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-16 03:05:34 --> Login MX_Controller Initialized
DEBUG - 2018-06-16 03:05:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-16 03:05:34 --> Final output sent to browser
DEBUG - 2018-06-16 03:05:34 --> Total execution time: 0.4849
INFO - 2018-06-16 03:05:47 --> Config Class Initialized
INFO - 2018-06-16 03:05:47 --> Hooks Class Initialized
DEBUG - 2018-06-16 03:05:47 --> UTF-8 Support Enabled
INFO - 2018-06-16 03:05:47 --> Utf8 Class Initialized
INFO - 2018-06-16 03:05:47 --> URI Class Initialized
INFO - 2018-06-16 03:05:47 --> Router Class Initialized
INFO - 2018-06-16 03:05:47 --> Output Class Initialized
INFO - 2018-06-16 03:05:47 --> Security Class Initialized
DEBUG - 2018-06-16 03:05:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-16 03:05:47 --> Input Class Initialized
INFO - 2018-06-16 03:05:47 --> Language Class Initialized
INFO - 2018-06-16 03:05:47 --> Language Class Initialized
INFO - 2018-06-16 03:05:47 --> Config Class Initialized
INFO - 2018-06-16 03:05:47 --> Loader Class Initialized
DEBUG - 2018-06-16 03:05:47 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-16 03:05:47 --> Helper loaded: url_helper
INFO - 2018-06-16 03:05:47 --> Helper loaded: form_helper
INFO - 2018-06-16 03:05:47 --> Helper loaded: date_helper
INFO - 2018-06-16 03:05:47 --> Helper loaded: util_helper
INFO - 2018-06-16 03:05:47 --> Helper loaded: text_helper
INFO - 2018-06-16 03:05:47 --> Helper loaded: string_helper
INFO - 2018-06-16 03:05:47 --> Database Driver Class Initialized
DEBUG - 2018-06-16 03:05:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-16 03:05:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-16 03:05:47 --> Email Class Initialized
INFO - 2018-06-16 03:05:47 --> Controller Class Initialized
DEBUG - 2018-06-16 03:05:47 --> Lessions MX_Controller Initialized
INFO - 2018-06-16 03:05:47 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-16 03:05:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Lessions_model.php
DEBUG - 2018-06-16 03:05:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-16 03:05:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-16 03:05:47 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-16 03:05:47 --> Login MX_Controller Initialized
DEBUG - 2018-06-16 03:05:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-16 03:05:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-16 03:05:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-16 03:05:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-16 03:05:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-16 03:05:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-16 03:05:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/lessions/create_lession.php
INFO - 2018-06-16 03:05:47 --> Final output sent to browser
DEBUG - 2018-06-16 03:05:47 --> Total execution time: 0.4090
INFO - 2018-06-16 03:05:48 --> Config Class Initialized
INFO - 2018-06-16 03:05:48 --> Hooks Class Initialized
DEBUG - 2018-06-16 03:05:48 --> UTF-8 Support Enabled
INFO - 2018-06-16 03:05:48 --> Utf8 Class Initialized
INFO - 2018-06-16 03:05:48 --> URI Class Initialized
INFO - 2018-06-16 03:05:48 --> Router Class Initialized
INFO - 2018-06-16 03:05:48 --> Output Class Initialized
INFO - 2018-06-16 03:05:48 --> Security Class Initialized
DEBUG - 2018-06-16 03:05:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-16 03:05:48 --> Input Class Initialized
INFO - 2018-06-16 03:05:48 --> Language Class Initialized
ERROR - 2018-06-16 03:05:48 --> 404 Page Not Found: /index
INFO - 2018-06-16 03:06:10 --> Config Class Initialized
INFO - 2018-06-16 03:06:10 --> Hooks Class Initialized
DEBUG - 2018-06-16 03:06:10 --> UTF-8 Support Enabled
INFO - 2018-06-16 03:06:10 --> Utf8 Class Initialized
INFO - 2018-06-16 03:06:10 --> URI Class Initialized
INFO - 2018-06-16 03:06:10 --> Router Class Initialized
INFO - 2018-06-16 03:06:10 --> Output Class Initialized
INFO - 2018-06-16 03:06:10 --> Security Class Initialized
DEBUG - 2018-06-16 03:06:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-16 03:06:10 --> Input Class Initialized
INFO - 2018-06-16 03:06:10 --> Language Class Initialized
INFO - 2018-06-16 03:06:10 --> Language Class Initialized
INFO - 2018-06-16 03:06:10 --> Config Class Initialized
INFO - 2018-06-16 03:06:10 --> Loader Class Initialized
DEBUG - 2018-06-16 03:06:10 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-16 03:06:10 --> Helper loaded: url_helper
INFO - 2018-06-16 03:06:10 --> Helper loaded: form_helper
INFO - 2018-06-16 03:06:10 --> Helper loaded: date_helper
INFO - 2018-06-16 03:06:10 --> Helper loaded: util_helper
INFO - 2018-06-16 03:06:10 --> Helper loaded: text_helper
INFO - 2018-06-16 03:06:10 --> Helper loaded: string_helper
INFO - 2018-06-16 03:06:10 --> Database Driver Class Initialized
DEBUG - 2018-06-16 03:06:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-16 03:06:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-16 03:06:10 --> Email Class Initialized
INFO - 2018-06-16 03:06:10 --> Controller Class Initialized
DEBUG - 2018-06-16 03:06:10 --> Lessions MX_Controller Initialized
INFO - 2018-06-16 03:06:10 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-16 03:06:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Lessions_model.php
DEBUG - 2018-06-16 03:06:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-16 03:06:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-16 03:06:10 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-16 03:06:10 --> Login MX_Controller Initialized
DEBUG - 2018-06-16 03:06:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-16 03:06:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-16 03:06:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-16 03:06:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-16 03:06:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-16 03:06:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-16 03:06:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/lessions/create_lession.php
INFO - 2018-06-16 03:06:10 --> Final output sent to browser
DEBUG - 2018-06-16 03:06:10 --> Total execution time: 0.4068
INFO - 2018-06-16 03:06:12 --> Config Class Initialized
INFO - 2018-06-16 03:06:12 --> Hooks Class Initialized
DEBUG - 2018-06-16 03:06:12 --> UTF-8 Support Enabled
INFO - 2018-06-16 03:06:12 --> Utf8 Class Initialized
INFO - 2018-06-16 03:06:12 --> URI Class Initialized
INFO - 2018-06-16 03:06:12 --> Router Class Initialized
INFO - 2018-06-16 03:06:12 --> Output Class Initialized
INFO - 2018-06-16 03:06:12 --> Security Class Initialized
DEBUG - 2018-06-16 03:06:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-16 03:06:13 --> Input Class Initialized
INFO - 2018-06-16 03:06:13 --> Language Class Initialized
ERROR - 2018-06-16 03:06:13 --> 404 Page Not Found: /index
INFO - 2018-06-16 03:08:08 --> Config Class Initialized
INFO - 2018-06-16 03:08:08 --> Hooks Class Initialized
DEBUG - 2018-06-16 03:08:08 --> UTF-8 Support Enabled
INFO - 2018-06-16 03:08:08 --> Utf8 Class Initialized
INFO - 2018-06-16 03:08:08 --> URI Class Initialized
INFO - 2018-06-16 03:08:08 --> Router Class Initialized
INFO - 2018-06-16 03:08:08 --> Output Class Initialized
INFO - 2018-06-16 03:08:08 --> Security Class Initialized
DEBUG - 2018-06-16 03:08:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-16 03:08:08 --> Input Class Initialized
INFO - 2018-06-16 03:08:08 --> Language Class Initialized
INFO - 2018-06-16 03:08:08 --> Language Class Initialized
INFO - 2018-06-16 03:08:08 --> Config Class Initialized
INFO - 2018-06-16 03:08:08 --> Loader Class Initialized
DEBUG - 2018-06-16 03:08:08 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-16 03:08:08 --> Helper loaded: url_helper
INFO - 2018-06-16 03:08:08 --> Helper loaded: form_helper
INFO - 2018-06-16 03:08:08 --> Helper loaded: date_helper
INFO - 2018-06-16 03:08:08 --> Helper loaded: util_helper
INFO - 2018-06-16 03:08:08 --> Helper loaded: text_helper
INFO - 2018-06-16 03:08:08 --> Helper loaded: string_helper
INFO - 2018-06-16 03:08:08 --> Database Driver Class Initialized
DEBUG - 2018-06-16 03:08:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-16 03:08:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-16 03:08:08 --> Email Class Initialized
INFO - 2018-06-16 03:08:08 --> Controller Class Initialized
DEBUG - 2018-06-16 03:08:08 --> Lessions MX_Controller Initialized
INFO - 2018-06-16 03:08:08 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-16 03:08:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Lessions_model.php
DEBUG - 2018-06-16 03:08:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-16 03:08:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-16 03:08:08 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-16 03:08:08 --> Login MX_Controller Initialized
DEBUG - 2018-06-16 03:08:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-16 03:08:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-16 03:08:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-16 03:08:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-16 03:08:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-16 03:08:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-16 03:08:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/lessions/create_lession.php
INFO - 2018-06-16 03:08:08 --> Final output sent to browser
DEBUG - 2018-06-16 03:08:08 --> Total execution time: 0.4260
INFO - 2018-06-16 03:08:09 --> Config Class Initialized
INFO - 2018-06-16 03:08:09 --> Hooks Class Initialized
DEBUG - 2018-06-16 03:08:09 --> UTF-8 Support Enabled
INFO - 2018-06-16 03:08:09 --> Utf8 Class Initialized
INFO - 2018-06-16 03:08:09 --> URI Class Initialized
INFO - 2018-06-16 03:08:09 --> Router Class Initialized
INFO - 2018-06-16 03:08:09 --> Output Class Initialized
INFO - 2018-06-16 03:08:09 --> Security Class Initialized
DEBUG - 2018-06-16 03:08:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-16 03:08:09 --> Input Class Initialized
INFO - 2018-06-16 03:08:09 --> Language Class Initialized
ERROR - 2018-06-16 03:08:09 --> 404 Page Not Found: /index
INFO - 2018-06-16 03:08:19 --> Config Class Initialized
INFO - 2018-06-16 03:08:19 --> Hooks Class Initialized
DEBUG - 2018-06-16 03:08:19 --> UTF-8 Support Enabled
INFO - 2018-06-16 03:08:19 --> Utf8 Class Initialized
INFO - 2018-06-16 03:08:19 --> URI Class Initialized
INFO - 2018-06-16 03:08:19 --> Router Class Initialized
INFO - 2018-06-16 03:08:19 --> Output Class Initialized
INFO - 2018-06-16 03:08:19 --> Security Class Initialized
DEBUG - 2018-06-16 03:08:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-16 03:08:19 --> Input Class Initialized
INFO - 2018-06-16 03:08:19 --> Language Class Initialized
INFO - 2018-06-16 03:08:19 --> Language Class Initialized
INFO - 2018-06-16 03:08:19 --> Config Class Initialized
INFO - 2018-06-16 03:08:19 --> Loader Class Initialized
DEBUG - 2018-06-16 03:08:19 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-16 03:08:19 --> Helper loaded: url_helper
INFO - 2018-06-16 03:08:19 --> Helper loaded: form_helper
INFO - 2018-06-16 03:08:19 --> Helper loaded: date_helper
INFO - 2018-06-16 03:08:19 --> Helper loaded: util_helper
INFO - 2018-06-16 03:08:19 --> Helper loaded: text_helper
INFO - 2018-06-16 03:08:19 --> Helper loaded: string_helper
INFO - 2018-06-16 03:08:19 --> Database Driver Class Initialized
DEBUG - 2018-06-16 03:08:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-16 03:08:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-16 03:08:19 --> Email Class Initialized
INFO - 2018-06-16 03:08:19 --> Controller Class Initialized
DEBUG - 2018-06-16 03:08:19 --> Lessions MX_Controller Initialized
INFO - 2018-06-16 03:08:19 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-16 03:08:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Lessions_model.php
DEBUG - 2018-06-16 03:08:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-16 03:08:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-16 03:08:19 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-16 03:08:19 --> Login MX_Controller Initialized
DEBUG - 2018-06-16 03:08:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-16 03:29:30 --> Config Class Initialized
INFO - 2018-06-16 03:29:30 --> Hooks Class Initialized
DEBUG - 2018-06-16 03:29:30 --> UTF-8 Support Enabled
INFO - 2018-06-16 03:29:30 --> Utf8 Class Initialized
INFO - 2018-06-16 03:29:30 --> URI Class Initialized
INFO - 2018-06-16 03:29:30 --> Router Class Initialized
INFO - 2018-06-16 03:29:30 --> Output Class Initialized
INFO - 2018-06-16 03:29:30 --> Security Class Initialized
DEBUG - 2018-06-16 03:29:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-16 03:29:30 --> Input Class Initialized
INFO - 2018-06-16 03:29:30 --> Language Class Initialized
INFO - 2018-06-16 03:29:30 --> Language Class Initialized
INFO - 2018-06-16 03:29:30 --> Config Class Initialized
INFO - 2018-06-16 03:29:30 --> Loader Class Initialized
DEBUG - 2018-06-16 03:29:30 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-16 03:29:30 --> Helper loaded: url_helper
INFO - 2018-06-16 03:29:30 --> Helper loaded: form_helper
INFO - 2018-06-16 03:29:30 --> Helper loaded: date_helper
INFO - 2018-06-16 03:29:30 --> Helper loaded: util_helper
INFO - 2018-06-16 03:29:30 --> Helper loaded: text_helper
INFO - 2018-06-16 03:29:30 --> Helper loaded: string_helper
INFO - 2018-06-16 03:29:30 --> Database Driver Class Initialized
DEBUG - 2018-06-16 03:29:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-16 03:29:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-16 03:29:30 --> Email Class Initialized
INFO - 2018-06-16 03:29:30 --> Controller Class Initialized
DEBUG - 2018-06-16 03:29:30 --> Lessions MX_Controller Initialized
INFO - 2018-06-16 03:29:30 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-16 03:29:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Lessions_model.php
DEBUG - 2018-06-16 03:29:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-16 03:29:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-16 03:29:30 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-16 03:29:30 --> Login MX_Controller Initialized
DEBUG - 2018-06-16 03:29:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-16 03:29:30 --> Config Class Initialized
INFO - 2018-06-16 03:29:30 --> Hooks Class Initialized
DEBUG - 2018-06-16 03:29:30 --> UTF-8 Support Enabled
INFO - 2018-06-16 03:29:30 --> Utf8 Class Initialized
INFO - 2018-06-16 03:29:30 --> URI Class Initialized
INFO - 2018-06-16 03:29:30 --> Router Class Initialized
INFO - 2018-06-16 03:29:30 --> Output Class Initialized
INFO - 2018-06-16 03:29:30 --> Security Class Initialized
DEBUG - 2018-06-16 03:29:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-16 03:29:30 --> Input Class Initialized
INFO - 2018-06-16 03:29:30 --> Language Class Initialized
INFO - 2018-06-16 03:29:30 --> Language Class Initialized
INFO - 2018-06-16 03:29:30 --> Config Class Initialized
INFO - 2018-06-16 03:29:30 --> Loader Class Initialized
DEBUG - 2018-06-16 03:29:30 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-16 03:29:30 --> Helper loaded: url_helper
INFO - 2018-06-16 03:29:30 --> Helper loaded: form_helper
INFO - 2018-06-16 03:29:30 --> Helper loaded: date_helper
INFO - 2018-06-16 03:29:30 --> Helper loaded: util_helper
INFO - 2018-06-16 03:29:30 --> Helper loaded: text_helper
INFO - 2018-06-16 03:29:30 --> Helper loaded: string_helper
INFO - 2018-06-16 03:29:31 --> Database Driver Class Initialized
DEBUG - 2018-06-16 03:29:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-16 03:29:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-16 03:29:31 --> Email Class Initialized
INFO - 2018-06-16 03:29:31 --> Controller Class Initialized
DEBUG - 2018-06-16 03:29:31 --> Lessions MX_Controller Initialized
INFO - 2018-06-16 03:29:31 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-16 03:29:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Lessions_model.php
DEBUG - 2018-06-16 03:29:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-16 03:29:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-16 03:29:31 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-16 03:29:31 --> Login MX_Controller Initialized
DEBUG - 2018-06-16 03:29:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-16 03:29:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-16 03:29:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-16 03:29:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-16 03:29:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-16 03:29:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-16 03:29:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/lessions/lessions.php
INFO - 2018-06-16 03:29:31 --> Final output sent to browser
DEBUG - 2018-06-16 03:29:31 --> Total execution time: 0.4713
INFO - 2018-06-16 03:29:31 --> Config Class Initialized
INFO - 2018-06-16 03:29:31 --> Hooks Class Initialized
DEBUG - 2018-06-16 03:29:31 --> UTF-8 Support Enabled
INFO - 2018-06-16 03:29:31 --> Utf8 Class Initialized
INFO - 2018-06-16 03:29:31 --> URI Class Initialized
INFO - 2018-06-16 03:29:32 --> Router Class Initialized
INFO - 2018-06-16 03:29:32 --> Output Class Initialized
INFO - 2018-06-16 03:29:32 --> Security Class Initialized
DEBUG - 2018-06-16 03:29:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-16 03:29:32 --> Input Class Initialized
INFO - 2018-06-16 03:29:32 --> Language Class Initialized
INFO - 2018-06-16 03:29:32 --> Language Class Initialized
INFO - 2018-06-16 03:29:32 --> Config Class Initialized
INFO - 2018-06-16 03:29:32 --> Loader Class Initialized
DEBUG - 2018-06-16 03:29:32 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-16 03:29:32 --> Helper loaded: url_helper
INFO - 2018-06-16 03:29:32 --> Helper loaded: form_helper
INFO - 2018-06-16 03:29:32 --> Helper loaded: date_helper
INFO - 2018-06-16 03:29:32 --> Helper loaded: util_helper
INFO - 2018-06-16 03:29:32 --> Helper loaded: text_helper
INFO - 2018-06-16 03:29:32 --> Helper loaded: string_helper
INFO - 2018-06-16 03:29:32 --> Database Driver Class Initialized
DEBUG - 2018-06-16 03:29:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-16 03:29:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-16 03:29:32 --> Email Class Initialized
INFO - 2018-06-16 03:29:32 --> Controller Class Initialized
DEBUG - 2018-06-16 03:29:32 --> Lessions MX_Controller Initialized
INFO - 2018-06-16 03:29:32 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-16 03:29:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Lessions_model.php
DEBUG - 2018-06-16 03:29:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-16 03:29:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-16 03:29:32 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-16 03:29:32 --> Login MX_Controller Initialized
DEBUG - 2018-06-16 03:29:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-16 03:29:32 --> Final output sent to browser
DEBUG - 2018-06-16 03:29:32 --> Total execution time: 0.6113
INFO - 2018-06-16 03:29:34 --> Config Class Initialized
INFO - 2018-06-16 03:29:34 --> Hooks Class Initialized
DEBUG - 2018-06-16 03:29:34 --> UTF-8 Support Enabled
INFO - 2018-06-16 03:29:34 --> Utf8 Class Initialized
INFO - 2018-06-16 03:29:34 --> URI Class Initialized
INFO - 2018-06-16 03:29:34 --> Router Class Initialized
INFO - 2018-06-16 03:29:34 --> Output Class Initialized
INFO - 2018-06-16 03:29:34 --> Security Class Initialized
DEBUG - 2018-06-16 03:29:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-16 03:29:34 --> Input Class Initialized
INFO - 2018-06-16 03:29:34 --> Language Class Initialized
INFO - 2018-06-16 03:29:34 --> Language Class Initialized
INFO - 2018-06-16 03:29:34 --> Config Class Initialized
INFO - 2018-06-16 03:29:34 --> Loader Class Initialized
DEBUG - 2018-06-16 03:29:34 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-16 03:29:34 --> Helper loaded: url_helper
INFO - 2018-06-16 03:29:34 --> Helper loaded: form_helper
INFO - 2018-06-16 03:29:34 --> Helper loaded: date_helper
INFO - 2018-06-16 03:29:34 --> Helper loaded: util_helper
INFO - 2018-06-16 03:29:34 --> Helper loaded: text_helper
INFO - 2018-06-16 03:29:34 --> Helper loaded: string_helper
INFO - 2018-06-16 03:29:34 --> Database Driver Class Initialized
DEBUG - 2018-06-16 03:29:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-16 03:29:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-16 03:29:34 --> Email Class Initialized
INFO - 2018-06-16 03:29:34 --> Controller Class Initialized
DEBUG - 2018-06-16 03:29:34 --> Lessions MX_Controller Initialized
INFO - 2018-06-16 03:29:34 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-16 03:29:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Lessions_model.php
DEBUG - 2018-06-16 03:29:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-16 03:29:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-16 03:29:34 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-16 03:29:34 --> Login MX_Controller Initialized
DEBUG - 2018-06-16 03:29:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-16 03:29:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-16 03:29:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-16 03:29:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
ERROR - 2018-06-16 03:29:34 --> Severity: Notice --> Undefined index: lession_act E:\xampp\htdocs\consulting\application\modules\admin\views\lessions\create_lession.php 76
DEBUG - 2018-06-16 03:29:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-16 03:29:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-16 03:29:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/lessions/create_lession.php
INFO - 2018-06-16 03:29:35 --> Final output sent to browser
DEBUG - 2018-06-16 03:29:35 --> Total execution time: 0.4749
INFO - 2018-06-16 03:29:36 --> Config Class Initialized
INFO - 2018-06-16 03:29:36 --> Hooks Class Initialized
DEBUG - 2018-06-16 03:29:36 --> UTF-8 Support Enabled
INFO - 2018-06-16 03:29:36 --> Utf8 Class Initialized
INFO - 2018-06-16 03:29:36 --> URI Class Initialized
INFO - 2018-06-16 03:29:36 --> Router Class Initialized
INFO - 2018-06-16 03:29:36 --> Output Class Initialized
INFO - 2018-06-16 03:29:36 --> Security Class Initialized
DEBUG - 2018-06-16 03:29:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-16 03:29:36 --> Input Class Initialized
INFO - 2018-06-16 03:29:36 --> Language Class Initialized
ERROR - 2018-06-16 03:29:36 --> 404 Page Not Found: /index
INFO - 2018-06-16 03:29:55 --> Config Class Initialized
INFO - 2018-06-16 03:29:55 --> Hooks Class Initialized
DEBUG - 2018-06-16 03:29:55 --> UTF-8 Support Enabled
INFO - 2018-06-16 03:29:55 --> Utf8 Class Initialized
INFO - 2018-06-16 03:29:55 --> URI Class Initialized
INFO - 2018-06-16 03:29:55 --> Router Class Initialized
INFO - 2018-06-16 03:29:55 --> Output Class Initialized
INFO - 2018-06-16 03:29:55 --> Security Class Initialized
DEBUG - 2018-06-16 03:29:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-16 03:29:55 --> Input Class Initialized
INFO - 2018-06-16 03:29:55 --> Language Class Initialized
INFO - 2018-06-16 03:29:55 --> Language Class Initialized
INFO - 2018-06-16 03:29:55 --> Config Class Initialized
INFO - 2018-06-16 03:29:55 --> Loader Class Initialized
DEBUG - 2018-06-16 03:29:55 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-16 03:29:55 --> Helper loaded: url_helper
INFO - 2018-06-16 03:29:55 --> Helper loaded: form_helper
INFO - 2018-06-16 03:29:55 --> Helper loaded: date_helper
INFO - 2018-06-16 03:29:55 --> Helper loaded: util_helper
INFO - 2018-06-16 03:29:55 --> Helper loaded: text_helper
INFO - 2018-06-16 03:29:55 --> Helper loaded: string_helper
INFO - 2018-06-16 03:29:55 --> Database Driver Class Initialized
DEBUG - 2018-06-16 03:29:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-16 03:29:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-16 03:29:55 --> Email Class Initialized
INFO - 2018-06-16 03:29:55 --> Controller Class Initialized
DEBUG - 2018-06-16 03:29:55 --> Lessions MX_Controller Initialized
INFO - 2018-06-16 03:29:55 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-16 03:29:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Lessions_model.php
DEBUG - 2018-06-16 03:29:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-16 03:29:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-16 03:29:55 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-16 03:29:55 --> Login MX_Controller Initialized
DEBUG - 2018-06-16 03:29:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-16 03:29:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-16 03:29:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-16 03:29:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-16 03:29:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-16 03:29:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-16 03:29:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/lessions/create_lession.php
INFO - 2018-06-16 03:29:56 --> Final output sent to browser
DEBUG - 2018-06-16 03:29:56 --> Total execution time: 0.4312
INFO - 2018-06-16 03:29:56 --> Config Class Initialized
INFO - 2018-06-16 03:29:57 --> Hooks Class Initialized
DEBUG - 2018-06-16 03:29:57 --> UTF-8 Support Enabled
INFO - 2018-06-16 03:29:57 --> Utf8 Class Initialized
INFO - 2018-06-16 03:29:57 --> URI Class Initialized
INFO - 2018-06-16 03:29:57 --> Router Class Initialized
INFO - 2018-06-16 03:29:57 --> Output Class Initialized
INFO - 2018-06-16 03:29:57 --> Security Class Initialized
DEBUG - 2018-06-16 03:29:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-16 03:29:57 --> Input Class Initialized
INFO - 2018-06-16 03:29:57 --> Language Class Initialized
ERROR - 2018-06-16 03:29:57 --> 404 Page Not Found: /index
INFO - 2018-06-16 03:30:06 --> Config Class Initialized
INFO - 2018-06-16 03:30:06 --> Hooks Class Initialized
DEBUG - 2018-06-16 03:30:06 --> UTF-8 Support Enabled
INFO - 2018-06-16 03:30:06 --> Utf8 Class Initialized
INFO - 2018-06-16 03:30:06 --> URI Class Initialized
INFO - 2018-06-16 03:30:06 --> Router Class Initialized
INFO - 2018-06-16 03:30:06 --> Output Class Initialized
INFO - 2018-06-16 03:30:06 --> Security Class Initialized
DEBUG - 2018-06-16 03:30:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-16 03:30:06 --> Input Class Initialized
INFO - 2018-06-16 03:30:06 --> Language Class Initialized
INFO - 2018-06-16 03:30:06 --> Language Class Initialized
INFO - 2018-06-16 03:30:06 --> Config Class Initialized
INFO - 2018-06-16 03:30:06 --> Loader Class Initialized
DEBUG - 2018-06-16 03:30:06 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-16 03:30:06 --> Helper loaded: url_helper
INFO - 2018-06-16 03:30:07 --> Helper loaded: form_helper
INFO - 2018-06-16 03:30:07 --> Helper loaded: date_helper
INFO - 2018-06-16 03:30:07 --> Helper loaded: util_helper
INFO - 2018-06-16 03:30:07 --> Helper loaded: text_helper
INFO - 2018-06-16 03:30:07 --> Helper loaded: string_helper
INFO - 2018-06-16 03:30:07 --> Database Driver Class Initialized
DEBUG - 2018-06-16 03:30:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-16 03:30:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-16 03:30:07 --> Email Class Initialized
INFO - 2018-06-16 03:30:07 --> Controller Class Initialized
DEBUG - 2018-06-16 03:30:07 --> Lessions MX_Controller Initialized
INFO - 2018-06-16 03:30:07 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-16 03:30:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Lessions_model.php
DEBUG - 2018-06-16 03:30:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-16 03:30:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-16 03:30:07 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-16 03:30:07 --> Login MX_Controller Initialized
DEBUG - 2018-06-16 03:30:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-16 03:30:07 --> Config Class Initialized
INFO - 2018-06-16 03:30:07 --> Hooks Class Initialized
DEBUG - 2018-06-16 03:30:07 --> UTF-8 Support Enabled
INFO - 2018-06-16 03:30:07 --> Utf8 Class Initialized
INFO - 2018-06-16 03:30:07 --> URI Class Initialized
INFO - 2018-06-16 03:30:07 --> Router Class Initialized
INFO - 2018-06-16 03:30:07 --> Output Class Initialized
INFO - 2018-06-16 03:30:07 --> Security Class Initialized
DEBUG - 2018-06-16 03:30:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-16 03:30:07 --> Input Class Initialized
INFO - 2018-06-16 03:30:07 --> Language Class Initialized
INFO - 2018-06-16 03:30:07 --> Language Class Initialized
INFO - 2018-06-16 03:30:07 --> Config Class Initialized
INFO - 2018-06-16 03:30:07 --> Loader Class Initialized
DEBUG - 2018-06-16 03:30:07 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-16 03:30:07 --> Helper loaded: url_helper
INFO - 2018-06-16 03:30:07 --> Helper loaded: form_helper
INFO - 2018-06-16 03:30:07 --> Helper loaded: date_helper
INFO - 2018-06-16 03:30:07 --> Helper loaded: util_helper
INFO - 2018-06-16 03:30:07 --> Helper loaded: text_helper
INFO - 2018-06-16 03:30:07 --> Helper loaded: string_helper
INFO - 2018-06-16 03:30:07 --> Database Driver Class Initialized
DEBUG - 2018-06-16 03:30:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-16 03:30:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-16 03:30:07 --> Email Class Initialized
INFO - 2018-06-16 03:30:07 --> Controller Class Initialized
DEBUG - 2018-06-16 03:30:07 --> Lessions MX_Controller Initialized
INFO - 2018-06-16 03:30:07 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-16 03:30:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Lessions_model.php
DEBUG - 2018-06-16 03:30:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-16 03:30:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-16 03:30:07 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-16 03:30:07 --> Login MX_Controller Initialized
DEBUG - 2018-06-16 03:30:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-16 03:30:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-16 03:30:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-16 03:30:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-16 03:30:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-16 03:30:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-16 03:30:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/lessions/lessions.php
INFO - 2018-06-16 03:30:07 --> Final output sent to browser
DEBUG - 2018-06-16 03:30:07 --> Total execution time: 0.4592
INFO - 2018-06-16 03:30:08 --> Config Class Initialized
INFO - 2018-06-16 03:30:08 --> Hooks Class Initialized
DEBUG - 2018-06-16 03:30:08 --> UTF-8 Support Enabled
INFO - 2018-06-16 03:30:08 --> Utf8 Class Initialized
INFO - 2018-06-16 03:30:08 --> URI Class Initialized
INFO - 2018-06-16 03:30:08 --> Router Class Initialized
INFO - 2018-06-16 03:30:08 --> Output Class Initialized
INFO - 2018-06-16 03:30:08 --> Security Class Initialized
DEBUG - 2018-06-16 03:30:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-16 03:30:08 --> Input Class Initialized
INFO - 2018-06-16 03:30:08 --> Language Class Initialized
INFO - 2018-06-16 03:30:08 --> Language Class Initialized
INFO - 2018-06-16 03:30:08 --> Config Class Initialized
INFO - 2018-06-16 03:30:08 --> Loader Class Initialized
DEBUG - 2018-06-16 03:30:08 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-16 03:30:08 --> Helper loaded: url_helper
INFO - 2018-06-16 03:30:08 --> Helper loaded: form_helper
INFO - 2018-06-16 03:30:08 --> Helper loaded: date_helper
INFO - 2018-06-16 03:30:08 --> Helper loaded: util_helper
INFO - 2018-06-16 03:30:08 --> Helper loaded: text_helper
INFO - 2018-06-16 03:30:08 --> Helper loaded: string_helper
INFO - 2018-06-16 03:30:09 --> Database Driver Class Initialized
DEBUG - 2018-06-16 03:30:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-16 03:30:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-16 03:30:09 --> Email Class Initialized
INFO - 2018-06-16 03:30:09 --> Controller Class Initialized
DEBUG - 2018-06-16 03:30:09 --> Lessions MX_Controller Initialized
INFO - 2018-06-16 03:30:09 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-16 03:30:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Lessions_model.php
DEBUG - 2018-06-16 03:30:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-16 03:30:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-16 03:30:09 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-16 03:30:09 --> Login MX_Controller Initialized
DEBUG - 2018-06-16 03:30:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-16 03:30:09 --> Final output sent to browser
DEBUG - 2018-06-16 03:30:09 --> Total execution time: 0.6249
INFO - 2018-06-16 03:30:11 --> Config Class Initialized
INFO - 2018-06-16 03:30:11 --> Hooks Class Initialized
DEBUG - 2018-06-16 03:30:11 --> UTF-8 Support Enabled
INFO - 2018-06-16 03:30:11 --> Utf8 Class Initialized
INFO - 2018-06-16 03:30:11 --> URI Class Initialized
INFO - 2018-06-16 03:30:11 --> Router Class Initialized
INFO - 2018-06-16 03:30:11 --> Output Class Initialized
INFO - 2018-06-16 03:30:11 --> Security Class Initialized
DEBUG - 2018-06-16 03:30:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-16 03:30:11 --> Input Class Initialized
INFO - 2018-06-16 03:30:11 --> Language Class Initialized
INFO - 2018-06-16 03:30:11 --> Language Class Initialized
INFO - 2018-06-16 03:30:11 --> Config Class Initialized
INFO - 2018-06-16 03:30:11 --> Loader Class Initialized
DEBUG - 2018-06-16 03:30:11 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-16 03:30:11 --> Helper loaded: url_helper
INFO - 2018-06-16 03:30:11 --> Helper loaded: form_helper
INFO - 2018-06-16 03:30:11 --> Helper loaded: date_helper
INFO - 2018-06-16 03:30:11 --> Helper loaded: util_helper
INFO - 2018-06-16 03:30:11 --> Helper loaded: text_helper
INFO - 2018-06-16 03:30:11 --> Helper loaded: string_helper
INFO - 2018-06-16 03:30:11 --> Database Driver Class Initialized
DEBUG - 2018-06-16 03:30:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-16 03:30:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-16 03:30:11 --> Email Class Initialized
INFO - 2018-06-16 03:30:12 --> Controller Class Initialized
DEBUG - 2018-06-16 03:30:12 --> Admin MX_Controller Initialized
INFO - 2018-06-16 03:30:12 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-16 03:30:12 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-16 03:30:12 --> Login MX_Controller Initialized
DEBUG - 2018-06-16 03:30:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-16 03:30:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-16 03:30:12 --> Final output sent to browser
DEBUG - 2018-06-16 03:30:12 --> Total execution time: 0.5671
INFO - 2018-06-16 03:30:18 --> Config Class Initialized
INFO - 2018-06-16 03:30:18 --> Hooks Class Initialized
DEBUG - 2018-06-16 03:30:18 --> UTF-8 Support Enabled
INFO - 2018-06-16 03:30:18 --> Utf8 Class Initialized
INFO - 2018-06-16 03:30:18 --> URI Class Initialized
INFO - 2018-06-16 03:30:18 --> Router Class Initialized
INFO - 2018-06-16 03:30:18 --> Output Class Initialized
INFO - 2018-06-16 03:30:18 --> Security Class Initialized
DEBUG - 2018-06-16 03:30:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-16 03:30:18 --> Input Class Initialized
INFO - 2018-06-16 03:30:18 --> Language Class Initialized
INFO - 2018-06-16 03:30:18 --> Language Class Initialized
INFO - 2018-06-16 03:30:18 --> Config Class Initialized
INFO - 2018-06-16 03:30:18 --> Loader Class Initialized
DEBUG - 2018-06-16 03:30:18 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-16 03:30:18 --> Helper loaded: url_helper
INFO - 2018-06-16 03:30:18 --> Helper loaded: form_helper
INFO - 2018-06-16 03:30:18 --> Helper loaded: date_helper
INFO - 2018-06-16 03:30:18 --> Helper loaded: util_helper
INFO - 2018-06-16 03:30:18 --> Helper loaded: text_helper
INFO - 2018-06-16 03:30:18 --> Helper loaded: string_helper
INFO - 2018-06-16 03:30:18 --> Database Driver Class Initialized
DEBUG - 2018-06-16 03:30:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-16 03:30:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-16 03:30:18 --> Email Class Initialized
INFO - 2018-06-16 03:30:18 --> Controller Class Initialized
DEBUG - 2018-06-16 03:30:18 --> Lessions MX_Controller Initialized
INFO - 2018-06-16 03:30:18 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-16 03:30:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Lessions_model.php
DEBUG - 2018-06-16 03:30:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-16 03:30:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-16 03:30:18 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-16 03:30:18 --> Login MX_Controller Initialized
DEBUG - 2018-06-16 03:30:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-16 03:30:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-16 03:30:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-16 03:30:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-16 03:30:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-16 03:30:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-16 03:30:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/lessions/create_lession.php
INFO - 2018-06-16 03:30:18 --> Final output sent to browser
DEBUG - 2018-06-16 03:30:18 --> Total execution time: 0.4329
INFO - 2018-06-16 03:30:19 --> Config Class Initialized
INFO - 2018-06-16 03:30:19 --> Hooks Class Initialized
DEBUG - 2018-06-16 03:30:19 --> UTF-8 Support Enabled
INFO - 2018-06-16 03:30:19 --> Utf8 Class Initialized
INFO - 2018-06-16 03:30:19 --> URI Class Initialized
INFO - 2018-06-16 03:30:19 --> Router Class Initialized
INFO - 2018-06-16 03:30:19 --> Output Class Initialized
INFO - 2018-06-16 03:30:19 --> Security Class Initialized
DEBUG - 2018-06-16 03:30:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-16 03:30:19 --> Input Class Initialized
INFO - 2018-06-16 03:30:19 --> Language Class Initialized
ERROR - 2018-06-16 03:30:19 --> 404 Page Not Found: /index
INFO - 2018-06-16 03:30:21 --> Config Class Initialized
INFO - 2018-06-16 03:30:21 --> Hooks Class Initialized
DEBUG - 2018-06-16 03:30:21 --> UTF-8 Support Enabled
INFO - 2018-06-16 03:30:21 --> Utf8 Class Initialized
INFO - 2018-06-16 03:30:21 --> URI Class Initialized
INFO - 2018-06-16 03:30:21 --> Router Class Initialized
INFO - 2018-06-16 03:30:21 --> Output Class Initialized
INFO - 2018-06-16 03:30:21 --> Security Class Initialized
DEBUG - 2018-06-16 03:30:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-16 03:30:21 --> Input Class Initialized
INFO - 2018-06-16 03:30:21 --> Language Class Initialized
INFO - 2018-06-16 03:30:21 --> Language Class Initialized
INFO - 2018-06-16 03:30:21 --> Config Class Initialized
INFO - 2018-06-16 03:30:21 --> Loader Class Initialized
DEBUG - 2018-06-16 03:30:21 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-16 03:30:21 --> Helper loaded: url_helper
INFO - 2018-06-16 03:30:21 --> Helper loaded: form_helper
INFO - 2018-06-16 03:30:21 --> Helper loaded: date_helper
INFO - 2018-06-16 03:30:21 --> Helper loaded: util_helper
INFO - 2018-06-16 03:30:21 --> Helper loaded: text_helper
INFO - 2018-06-16 03:30:21 --> Helper loaded: string_helper
INFO - 2018-06-16 03:30:21 --> Database Driver Class Initialized
DEBUG - 2018-06-16 03:30:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-16 03:30:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-16 03:30:21 --> Email Class Initialized
INFO - 2018-06-16 03:30:21 --> Controller Class Initialized
DEBUG - 2018-06-16 03:30:21 --> Lessions MX_Controller Initialized
INFO - 2018-06-16 03:30:21 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-16 03:30:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Lessions_model.php
DEBUG - 2018-06-16 03:30:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-16 03:30:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-16 03:30:21 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-16 03:30:21 --> Login MX_Controller Initialized
DEBUG - 2018-06-16 03:30:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-16 03:30:24 --> Config Class Initialized
INFO - 2018-06-16 03:30:24 --> Hooks Class Initialized
DEBUG - 2018-06-16 03:30:24 --> UTF-8 Support Enabled
INFO - 2018-06-16 03:30:24 --> Utf8 Class Initialized
INFO - 2018-06-16 03:30:24 --> URI Class Initialized
INFO - 2018-06-16 03:30:24 --> Router Class Initialized
INFO - 2018-06-16 03:30:24 --> Output Class Initialized
INFO - 2018-06-16 03:30:24 --> Security Class Initialized
DEBUG - 2018-06-16 03:30:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-16 03:30:24 --> Input Class Initialized
INFO - 2018-06-16 03:30:24 --> Language Class Initialized
INFO - 2018-06-16 03:30:24 --> Language Class Initialized
INFO - 2018-06-16 03:30:24 --> Config Class Initialized
INFO - 2018-06-16 03:30:24 --> Loader Class Initialized
DEBUG - 2018-06-16 03:30:24 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-16 03:30:24 --> Helper loaded: url_helper
INFO - 2018-06-16 03:30:24 --> Helper loaded: form_helper
INFO - 2018-06-16 03:30:25 --> Helper loaded: date_helper
INFO - 2018-06-16 03:30:25 --> Helper loaded: util_helper
INFO - 2018-06-16 03:30:25 --> Helper loaded: text_helper
INFO - 2018-06-16 03:30:25 --> Helper loaded: string_helper
INFO - 2018-06-16 03:30:25 --> Database Driver Class Initialized
DEBUG - 2018-06-16 03:30:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-16 03:30:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-16 03:30:25 --> Email Class Initialized
INFO - 2018-06-16 03:30:25 --> Controller Class Initialized
DEBUG - 2018-06-16 03:30:25 --> Lessions MX_Controller Initialized
INFO - 2018-06-16 03:30:25 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-16 03:30:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Lessions_model.php
DEBUG - 2018-06-16 03:30:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-16 03:30:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-16 03:30:25 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-16 03:30:25 --> Login MX_Controller Initialized
DEBUG - 2018-06-16 03:30:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-16 03:30:28 --> Config Class Initialized
INFO - 2018-06-16 03:30:29 --> Hooks Class Initialized
DEBUG - 2018-06-16 03:30:29 --> UTF-8 Support Enabled
INFO - 2018-06-16 03:30:29 --> Utf8 Class Initialized
INFO - 2018-06-16 03:30:29 --> URI Class Initialized
INFO - 2018-06-16 03:30:29 --> Router Class Initialized
INFO - 2018-06-16 03:30:29 --> Output Class Initialized
INFO - 2018-06-16 03:30:29 --> Security Class Initialized
DEBUG - 2018-06-16 03:30:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-16 03:30:29 --> Input Class Initialized
INFO - 2018-06-16 03:30:29 --> Language Class Initialized
INFO - 2018-06-16 03:30:29 --> Language Class Initialized
INFO - 2018-06-16 03:30:29 --> Config Class Initialized
INFO - 2018-06-16 03:30:29 --> Loader Class Initialized
DEBUG - 2018-06-16 03:30:29 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-16 03:30:29 --> Helper loaded: url_helper
INFO - 2018-06-16 03:30:29 --> Helper loaded: form_helper
INFO - 2018-06-16 03:30:29 --> Helper loaded: date_helper
INFO - 2018-06-16 03:30:29 --> Helper loaded: util_helper
INFO - 2018-06-16 03:30:29 --> Helper loaded: text_helper
INFO - 2018-06-16 03:30:29 --> Helper loaded: string_helper
INFO - 2018-06-16 03:30:29 --> Database Driver Class Initialized
DEBUG - 2018-06-16 03:30:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-16 03:30:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-16 03:30:29 --> Email Class Initialized
INFO - 2018-06-16 03:30:29 --> Controller Class Initialized
DEBUG - 2018-06-16 03:30:29 --> Lessions MX_Controller Initialized
INFO - 2018-06-16 03:30:29 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-16 03:30:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Lessions_model.php
DEBUG - 2018-06-16 03:30:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-16 03:30:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-16 03:30:29 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-16 03:30:29 --> Login MX_Controller Initialized
DEBUG - 2018-06-16 03:30:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-16 03:30:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-16 03:30:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-16 03:30:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-16 03:30:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-16 03:30:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-16 03:30:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/lessions/lessions.php
INFO - 2018-06-16 03:30:29 --> Final output sent to browser
DEBUG - 2018-06-16 03:30:29 --> Total execution time: 0.4851
INFO - 2018-06-16 03:30:30 --> Config Class Initialized
INFO - 2018-06-16 03:30:30 --> Hooks Class Initialized
DEBUG - 2018-06-16 03:30:30 --> UTF-8 Support Enabled
INFO - 2018-06-16 03:30:30 --> Utf8 Class Initialized
INFO - 2018-06-16 03:30:30 --> URI Class Initialized
INFO - 2018-06-16 03:30:30 --> Router Class Initialized
INFO - 2018-06-16 03:30:30 --> Output Class Initialized
INFO - 2018-06-16 03:30:30 --> Security Class Initialized
DEBUG - 2018-06-16 03:30:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-16 03:30:30 --> Input Class Initialized
INFO - 2018-06-16 03:30:30 --> Language Class Initialized
INFO - 2018-06-16 03:30:30 --> Language Class Initialized
INFO - 2018-06-16 03:30:30 --> Config Class Initialized
INFO - 2018-06-16 03:30:30 --> Loader Class Initialized
DEBUG - 2018-06-16 03:30:30 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-16 03:30:30 --> Helper loaded: url_helper
INFO - 2018-06-16 03:30:30 --> Helper loaded: form_helper
INFO - 2018-06-16 03:30:30 --> Helper loaded: date_helper
INFO - 2018-06-16 03:30:30 --> Helper loaded: util_helper
INFO - 2018-06-16 03:30:30 --> Helper loaded: text_helper
INFO - 2018-06-16 03:30:30 --> Helper loaded: string_helper
INFO - 2018-06-16 03:30:30 --> Database Driver Class Initialized
DEBUG - 2018-06-16 03:30:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-16 03:30:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-16 03:30:30 --> Email Class Initialized
INFO - 2018-06-16 03:30:30 --> Controller Class Initialized
DEBUG - 2018-06-16 03:30:30 --> Lessions MX_Controller Initialized
INFO - 2018-06-16 03:30:30 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-16 03:30:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Lessions_model.php
DEBUG - 2018-06-16 03:30:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-16 03:30:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-16 03:30:30 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-16 03:30:30 --> Login MX_Controller Initialized
DEBUG - 2018-06-16 03:30:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-16 03:30:30 --> Final output sent to browser
DEBUG - 2018-06-16 03:30:30 --> Total execution time: 0.6543
INFO - 2018-06-16 03:30:33 --> Config Class Initialized
INFO - 2018-06-16 03:30:33 --> Hooks Class Initialized
DEBUG - 2018-06-16 03:30:33 --> UTF-8 Support Enabled
INFO - 2018-06-16 03:30:33 --> Utf8 Class Initialized
INFO - 2018-06-16 03:30:33 --> URI Class Initialized
INFO - 2018-06-16 03:30:33 --> Router Class Initialized
INFO - 2018-06-16 03:30:33 --> Output Class Initialized
INFO - 2018-06-16 03:30:33 --> Security Class Initialized
DEBUG - 2018-06-16 03:30:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-16 03:30:33 --> Input Class Initialized
INFO - 2018-06-16 03:30:33 --> Language Class Initialized
INFO - 2018-06-16 03:30:33 --> Language Class Initialized
INFO - 2018-06-16 03:30:33 --> Config Class Initialized
INFO - 2018-06-16 03:30:33 --> Loader Class Initialized
DEBUG - 2018-06-16 03:30:33 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-16 03:30:33 --> Helper loaded: url_helper
INFO - 2018-06-16 03:30:33 --> Helper loaded: form_helper
INFO - 2018-06-16 03:30:33 --> Helper loaded: date_helper
INFO - 2018-06-16 03:30:33 --> Helper loaded: util_helper
INFO - 2018-06-16 03:30:33 --> Helper loaded: text_helper
INFO - 2018-06-16 03:30:33 --> Helper loaded: string_helper
INFO - 2018-06-16 03:30:33 --> Database Driver Class Initialized
DEBUG - 2018-06-16 03:30:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-16 03:30:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-16 03:30:33 --> Email Class Initialized
INFO - 2018-06-16 03:30:33 --> Controller Class Initialized
DEBUG - 2018-06-16 03:30:33 --> Admin MX_Controller Initialized
INFO - 2018-06-16 03:30:33 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-16 03:30:33 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-16 03:30:33 --> Login MX_Controller Initialized
DEBUG - 2018-06-16 03:30:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-16 03:30:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-16 03:30:33 --> Final output sent to browser
DEBUG - 2018-06-16 03:30:33 --> Total execution time: 0.4556
INFO - 2018-06-16 03:30:37 --> Config Class Initialized
INFO - 2018-06-16 03:30:37 --> Hooks Class Initialized
DEBUG - 2018-06-16 03:30:37 --> UTF-8 Support Enabled
INFO - 2018-06-16 03:30:37 --> Utf8 Class Initialized
INFO - 2018-06-16 03:30:37 --> URI Class Initialized
INFO - 2018-06-16 03:30:37 --> Router Class Initialized
INFO - 2018-06-16 03:30:37 --> Output Class Initialized
INFO - 2018-06-16 03:30:37 --> Security Class Initialized
DEBUG - 2018-06-16 03:30:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-16 03:30:37 --> Input Class Initialized
INFO - 2018-06-16 03:30:37 --> Language Class Initialized
INFO - 2018-06-16 03:30:37 --> Language Class Initialized
INFO - 2018-06-16 03:30:37 --> Config Class Initialized
INFO - 2018-06-16 03:30:37 --> Loader Class Initialized
DEBUG - 2018-06-16 03:30:37 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-16 03:30:37 --> Helper loaded: url_helper
INFO - 2018-06-16 03:30:37 --> Helper loaded: form_helper
INFO - 2018-06-16 03:30:37 --> Helper loaded: date_helper
INFO - 2018-06-16 03:30:37 --> Helper loaded: util_helper
INFO - 2018-06-16 03:30:37 --> Helper loaded: text_helper
INFO - 2018-06-16 03:30:37 --> Helper loaded: string_helper
INFO - 2018-06-16 03:30:37 --> Database Driver Class Initialized
DEBUG - 2018-06-16 03:30:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-16 03:30:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-16 03:30:37 --> Email Class Initialized
INFO - 2018-06-16 03:30:37 --> Controller Class Initialized
DEBUG - 2018-06-16 03:30:37 --> Lessions MX_Controller Initialized
INFO - 2018-06-16 03:30:37 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-16 03:30:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Lessions_model.php
DEBUG - 2018-06-16 03:30:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-16 03:30:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-16 03:30:37 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-16 03:30:37 --> Login MX_Controller Initialized
DEBUG - 2018-06-16 03:30:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-16 03:30:37 --> Final output sent to browser
DEBUG - 2018-06-16 03:30:37 --> Total execution time: 0.4359
INFO - 2018-06-16 03:30:37 --> Config Class Initialized
INFO - 2018-06-16 03:30:37 --> Hooks Class Initialized
DEBUG - 2018-06-16 03:30:37 --> UTF-8 Support Enabled
INFO - 2018-06-16 03:30:37 --> Utf8 Class Initialized
INFO - 2018-06-16 03:30:37 --> URI Class Initialized
INFO - 2018-06-16 03:30:37 --> Router Class Initialized
INFO - 2018-06-16 03:30:37 --> Output Class Initialized
INFO - 2018-06-16 03:30:37 --> Security Class Initialized
DEBUG - 2018-06-16 03:30:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-16 03:30:37 --> Input Class Initialized
INFO - 2018-06-16 03:30:37 --> Language Class Initialized
INFO - 2018-06-16 03:30:37 --> Language Class Initialized
INFO - 2018-06-16 03:30:38 --> Config Class Initialized
INFO - 2018-06-16 03:30:38 --> Loader Class Initialized
DEBUG - 2018-06-16 03:30:38 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-16 03:30:38 --> Helper loaded: url_helper
INFO - 2018-06-16 03:30:38 --> Helper loaded: form_helper
INFO - 2018-06-16 03:30:38 --> Helper loaded: date_helper
INFO - 2018-06-16 03:30:38 --> Helper loaded: util_helper
INFO - 2018-06-16 03:30:38 --> Helper loaded: text_helper
INFO - 2018-06-16 03:30:38 --> Helper loaded: string_helper
INFO - 2018-06-16 03:30:38 --> Database Driver Class Initialized
DEBUG - 2018-06-16 03:30:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-16 03:30:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-16 03:30:38 --> Email Class Initialized
INFO - 2018-06-16 03:30:38 --> Controller Class Initialized
DEBUG - 2018-06-16 03:30:38 --> Lessions MX_Controller Initialized
INFO - 2018-06-16 03:30:38 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-16 03:30:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Lessions_model.php
DEBUG - 2018-06-16 03:30:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-16 03:30:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-16 03:30:38 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-16 03:30:38 --> Login MX_Controller Initialized
DEBUG - 2018-06-16 03:30:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-16 03:30:38 --> Final output sent to browser
DEBUG - 2018-06-16 03:30:38 --> Total execution time: 0.4542
INFO - 2018-06-16 03:30:44 --> Config Class Initialized
INFO - 2018-06-16 03:30:44 --> Hooks Class Initialized
DEBUG - 2018-06-16 03:30:44 --> UTF-8 Support Enabled
INFO - 2018-06-16 03:30:44 --> Utf8 Class Initialized
INFO - 2018-06-16 03:30:44 --> URI Class Initialized
INFO - 2018-06-16 03:30:44 --> Router Class Initialized
INFO - 2018-06-16 03:30:44 --> Output Class Initialized
INFO - 2018-06-16 03:30:44 --> Security Class Initialized
DEBUG - 2018-06-16 03:30:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-16 03:30:44 --> Input Class Initialized
INFO - 2018-06-16 03:30:44 --> Language Class Initialized
INFO - 2018-06-16 03:30:44 --> Language Class Initialized
INFO - 2018-06-16 03:30:44 --> Config Class Initialized
INFO - 2018-06-16 03:30:44 --> Loader Class Initialized
DEBUG - 2018-06-16 03:30:44 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-16 03:30:44 --> Helper loaded: url_helper
INFO - 2018-06-16 03:30:44 --> Helper loaded: form_helper
INFO - 2018-06-16 03:30:44 --> Helper loaded: date_helper
INFO - 2018-06-16 03:30:44 --> Helper loaded: util_helper
INFO - 2018-06-16 03:30:44 --> Helper loaded: text_helper
INFO - 2018-06-16 03:30:44 --> Helper loaded: string_helper
INFO - 2018-06-16 03:30:44 --> Database Driver Class Initialized
DEBUG - 2018-06-16 03:30:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-16 03:30:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-16 03:30:44 --> Email Class Initialized
INFO - 2018-06-16 03:30:44 --> Controller Class Initialized
DEBUG - 2018-06-16 03:30:44 --> videos MX_Controller Initialized
INFO - 2018-06-16 03:30:44 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-16 03:30:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-06-16 03:30:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-16 03:30:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-16 03:30:44 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-16 03:30:44 --> Login MX_Controller Initialized
DEBUG - 2018-06-16 03:30:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-16 03:30:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-16 03:30:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-16 03:30:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-16 03:30:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-16 03:30:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-16 03:30:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/videos/videos.php
INFO - 2018-06-16 03:30:44 --> Final output sent to browser
DEBUG - 2018-06-16 03:30:44 --> Total execution time: 0.4588
INFO - 2018-06-16 03:30:45 --> Config Class Initialized
INFO - 2018-06-16 03:30:45 --> Hooks Class Initialized
DEBUG - 2018-06-16 03:30:45 --> UTF-8 Support Enabled
INFO - 2018-06-16 03:30:45 --> Utf8 Class Initialized
INFO - 2018-06-16 03:30:45 --> URI Class Initialized
INFO - 2018-06-16 03:30:45 --> Router Class Initialized
INFO - 2018-06-16 03:30:45 --> Output Class Initialized
INFO - 2018-06-16 03:30:45 --> Security Class Initialized
DEBUG - 2018-06-16 03:30:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-16 03:30:45 --> Input Class Initialized
INFO - 2018-06-16 03:30:45 --> Language Class Initialized
INFO - 2018-06-16 03:30:45 --> Language Class Initialized
INFO - 2018-06-16 03:30:45 --> Config Class Initialized
INFO - 2018-06-16 03:30:45 --> Loader Class Initialized
DEBUG - 2018-06-16 03:30:45 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-16 03:30:45 --> Helper loaded: url_helper
INFO - 2018-06-16 03:30:45 --> Helper loaded: form_helper
INFO - 2018-06-16 03:30:45 --> Helper loaded: date_helper
INFO - 2018-06-16 03:30:45 --> Helper loaded: util_helper
INFO - 2018-06-16 03:30:45 --> Helper loaded: text_helper
INFO - 2018-06-16 03:30:45 --> Helper loaded: string_helper
INFO - 2018-06-16 03:30:45 --> Database Driver Class Initialized
DEBUG - 2018-06-16 03:30:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-16 03:30:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-16 03:30:45 --> Email Class Initialized
INFO - 2018-06-16 03:30:45 --> Controller Class Initialized
DEBUG - 2018-06-16 03:30:45 --> videos MX_Controller Initialized
INFO - 2018-06-16 03:30:45 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-16 03:30:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-06-16 03:30:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-16 03:30:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-16 03:30:45 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-16 03:30:45 --> Login MX_Controller Initialized
DEBUG - 2018-06-16 03:30:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-16 03:30:45 --> Final output sent to browser
DEBUG - 2018-06-16 03:30:45 --> Total execution time: 0.6279
