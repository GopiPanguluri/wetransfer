<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-06-18 21:23:33 --> Config Class Initialized
INFO - 2018-06-18 21:23:33 --> Hooks Class Initialized
DEBUG - 2018-06-18 21:23:33 --> UTF-8 Support Enabled
INFO - 2018-06-18 21:23:33 --> Utf8 Class Initialized
INFO - 2018-06-18 21:23:33 --> URI Class Initialized
INFO - 2018-06-18 21:23:33 --> Router Class Initialized
INFO - 2018-06-18 21:23:33 --> Output Class Initialized
INFO - 2018-06-18 21:23:33 --> Security Class Initialized
DEBUG - 2018-06-18 21:23:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 21:23:33 --> Input Class Initialized
INFO - 2018-06-18 21:23:33 --> Language Class Initialized
INFO - 2018-06-18 21:23:34 --> Language Class Initialized
INFO - 2018-06-18 21:23:34 --> Config Class Initialized
INFO - 2018-06-18 21:23:34 --> Loader Class Initialized
DEBUG - 2018-06-18 21:23:34 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-18 21:23:34 --> Helper loaded: url_helper
INFO - 2018-06-18 21:23:34 --> Helper loaded: form_helper
INFO - 2018-06-18 21:23:34 --> Helper loaded: date_helper
INFO - 2018-06-18 21:23:34 --> Helper loaded: util_helper
INFO - 2018-06-18 21:23:34 --> Helper loaded: text_helper
INFO - 2018-06-18 21:23:34 --> Helper loaded: string_helper
INFO - 2018-06-18 21:23:34 --> Database Driver Class Initialized
DEBUG - 2018-06-18 21:23:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 21:23:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 21:23:35 --> Email Class Initialized
INFO - 2018-06-18 21:23:35 --> Controller Class Initialized
DEBUG - 2018-06-18 21:23:35 --> Home MX_Controller Initialized
DEBUG - 2018-06-18 21:23:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-18 21:23:35 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-18 21:23:35 --> Login MX_Controller Initialized
INFO - 2018-06-18 21:23:35 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-18 21:23:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-18 21:23:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-18 21:23:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-06-18 21:26:15 --> Config Class Initialized
INFO - 2018-06-18 21:26:15 --> Hooks Class Initialized
DEBUG - 2018-06-18 21:26:15 --> UTF-8 Support Enabled
INFO - 2018-06-18 21:26:15 --> Utf8 Class Initialized
INFO - 2018-06-18 21:26:15 --> URI Class Initialized
INFO - 2018-06-18 21:26:15 --> Router Class Initialized
INFO - 2018-06-18 21:26:15 --> Output Class Initialized
INFO - 2018-06-18 21:26:15 --> Security Class Initialized
DEBUG - 2018-06-18 21:26:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 21:26:15 --> Input Class Initialized
INFO - 2018-06-18 21:26:15 --> Language Class Initialized
INFO - 2018-06-18 21:26:15 --> Language Class Initialized
INFO - 2018-06-18 21:26:15 --> Config Class Initialized
INFO - 2018-06-18 21:26:15 --> Loader Class Initialized
DEBUG - 2018-06-18 21:26:15 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-18 21:26:15 --> Helper loaded: url_helper
INFO - 2018-06-18 21:26:15 --> Helper loaded: form_helper
INFO - 2018-06-18 21:26:15 --> Helper loaded: date_helper
INFO - 2018-06-18 21:26:15 --> Helper loaded: util_helper
INFO - 2018-06-18 21:26:15 --> Helper loaded: text_helper
INFO - 2018-06-18 21:26:15 --> Helper loaded: string_helper
INFO - 2018-06-18 21:26:15 --> Database Driver Class Initialized
DEBUG - 2018-06-18 21:26:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 21:26:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 21:26:15 --> Email Class Initialized
INFO - 2018-06-18 21:26:15 --> Controller Class Initialized
DEBUG - 2018-06-18 21:26:15 --> videos MX_Controller Initialized
INFO - 2018-06-18 21:26:15 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-18 21:26:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-06-18 21:26:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-18 21:26:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-18 21:26:15 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-18 21:26:15 --> Login MX_Controller Initialized
DEBUG - 2018-06-18 21:26:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-18 21:26:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
INFO - 2018-06-18 21:26:15 --> Config Class Initialized
INFO - 2018-06-18 21:26:15 --> Hooks Class Initialized
DEBUG - 2018-06-18 21:26:15 --> UTF-8 Support Enabled
INFO - 2018-06-18 21:26:15 --> Utf8 Class Initialized
INFO - 2018-06-18 21:26:15 --> URI Class Initialized
INFO - 2018-06-18 21:26:15 --> Router Class Initialized
INFO - 2018-06-18 21:26:16 --> Output Class Initialized
INFO - 2018-06-18 21:26:16 --> Security Class Initialized
DEBUG - 2018-06-18 21:26:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 21:26:16 --> Input Class Initialized
INFO - 2018-06-18 21:26:16 --> Language Class Initialized
ERROR - 2018-06-18 21:26:16 --> 404 Page Not Found: /index
INFO - 2018-06-18 21:26:17 --> Config Class Initialized
INFO - 2018-06-18 21:26:17 --> Hooks Class Initialized
DEBUG - 2018-06-18 21:26:17 --> UTF-8 Support Enabled
INFO - 2018-06-18 21:26:17 --> Utf8 Class Initialized
INFO - 2018-06-18 21:26:17 --> URI Class Initialized
INFO - 2018-06-18 21:26:17 --> Router Class Initialized
INFO - 2018-06-18 21:26:17 --> Output Class Initialized
INFO - 2018-06-18 21:26:17 --> Security Class Initialized
DEBUG - 2018-06-18 21:26:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 21:26:17 --> Input Class Initialized
INFO - 2018-06-18 21:26:17 --> Language Class Initialized
ERROR - 2018-06-18 21:26:17 --> 404 Page Not Found: /index
INFO - 2018-06-18 21:26:23 --> Config Class Initialized
INFO - 2018-06-18 21:26:23 --> Hooks Class Initialized
DEBUG - 2018-06-18 21:26:23 --> UTF-8 Support Enabled
INFO - 2018-06-18 21:26:23 --> Utf8 Class Initialized
INFO - 2018-06-18 21:26:23 --> URI Class Initialized
INFO - 2018-06-18 21:26:23 --> Router Class Initialized
INFO - 2018-06-18 21:26:23 --> Output Class Initialized
INFO - 2018-06-18 21:26:23 --> Security Class Initialized
DEBUG - 2018-06-18 21:26:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 21:26:23 --> Input Class Initialized
INFO - 2018-06-18 21:26:23 --> Language Class Initialized
INFO - 2018-06-18 21:26:23 --> Language Class Initialized
INFO - 2018-06-18 21:26:23 --> Config Class Initialized
INFO - 2018-06-18 21:26:23 --> Loader Class Initialized
DEBUG - 2018-06-18 21:26:23 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-18 21:26:23 --> Helper loaded: url_helper
INFO - 2018-06-18 21:26:23 --> Helper loaded: form_helper
INFO - 2018-06-18 21:26:23 --> Helper loaded: date_helper
INFO - 2018-06-18 21:26:23 --> Helper loaded: util_helper
INFO - 2018-06-18 21:26:23 --> Helper loaded: text_helper
INFO - 2018-06-18 21:26:23 --> Helper loaded: string_helper
INFO - 2018-06-18 21:26:23 --> Database Driver Class Initialized
DEBUG - 2018-06-18 21:26:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 21:26:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 21:26:23 --> Email Class Initialized
INFO - 2018-06-18 21:26:23 --> Controller Class Initialized
DEBUG - 2018-06-18 21:26:23 --> Login MX_Controller Initialized
INFO - 2018-06-18 21:26:23 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-18 21:26:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-18 21:26:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-18 21:26:23 --> Email starts for user@colin.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-06-18 21:26:24 --> User session created for 4
INFO - 2018-06-18 21:26:24 --> Login status user@colin.com - success
INFO - 2018-06-18 21:26:24 --> Final output sent to browser
DEBUG - 2018-06-18 21:26:24 --> Total execution time: 1.1249
INFO - 2018-06-18 21:26:24 --> Config Class Initialized
INFO - 2018-06-18 21:26:24 --> Hooks Class Initialized
DEBUG - 2018-06-18 21:26:24 --> UTF-8 Support Enabled
INFO - 2018-06-18 21:26:24 --> Utf8 Class Initialized
INFO - 2018-06-18 21:26:24 --> URI Class Initialized
INFO - 2018-06-18 21:26:24 --> Router Class Initialized
INFO - 2018-06-18 21:26:24 --> Output Class Initialized
INFO - 2018-06-18 21:26:24 --> Security Class Initialized
DEBUG - 2018-06-18 21:26:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 21:26:24 --> Input Class Initialized
INFO - 2018-06-18 21:26:24 --> Language Class Initialized
INFO - 2018-06-18 21:26:24 --> Language Class Initialized
INFO - 2018-06-18 21:26:24 --> Config Class Initialized
INFO - 2018-06-18 21:26:25 --> Loader Class Initialized
DEBUG - 2018-06-18 21:26:25 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-18 21:26:25 --> Helper loaded: url_helper
INFO - 2018-06-18 21:26:25 --> Helper loaded: form_helper
INFO - 2018-06-18 21:26:25 --> Helper loaded: date_helper
INFO - 2018-06-18 21:26:25 --> Helper loaded: util_helper
INFO - 2018-06-18 21:26:25 --> Helper loaded: text_helper
INFO - 2018-06-18 21:26:25 --> Helper loaded: string_helper
INFO - 2018-06-18 21:26:25 --> Database Driver Class Initialized
DEBUG - 2018-06-18 21:26:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 21:26:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 21:26:25 --> Email Class Initialized
INFO - 2018-06-18 21:26:25 --> Controller Class Initialized
DEBUG - 2018-06-18 21:26:25 --> Home MX_Controller Initialized
DEBUG - 2018-06-18 21:26:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-18 21:26:25 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-18 21:26:25 --> Login MX_Controller Initialized
INFO - 2018-06-18 21:26:25 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-18 21:26:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-18 21:26:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-18 21:26:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-18 21:26:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-18 21:26:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-18 21:26:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-18 21:26:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-18 21:26:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-06-18 21:26:26 --> Final output sent to browser
DEBUG - 2018-06-18 21:26:26 --> Total execution time: 1.8273
INFO - 2018-06-18 21:26:28 --> Config Class Initialized
INFO - 2018-06-18 21:26:28 --> Hooks Class Initialized
DEBUG - 2018-06-18 21:26:28 --> UTF-8 Support Enabled
INFO - 2018-06-18 21:26:28 --> Utf8 Class Initialized
INFO - 2018-06-18 21:26:28 --> URI Class Initialized
INFO - 2018-06-18 21:26:28 --> Router Class Initialized
INFO - 2018-06-18 21:26:28 --> Output Class Initialized
INFO - 2018-06-18 21:26:28 --> Security Class Initialized
DEBUG - 2018-06-18 21:26:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 21:26:28 --> Input Class Initialized
INFO - 2018-06-18 21:26:28 --> Language Class Initialized
INFO - 2018-06-18 21:26:28 --> Language Class Initialized
INFO - 2018-06-18 21:26:28 --> Config Class Initialized
INFO - 2018-06-18 21:26:28 --> Loader Class Initialized
DEBUG - 2018-06-18 21:26:28 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-18 21:26:28 --> Helper loaded: url_helper
INFO - 2018-06-18 21:26:28 --> Helper loaded: form_helper
INFO - 2018-06-18 21:26:28 --> Helper loaded: date_helper
INFO - 2018-06-18 21:26:28 --> Helper loaded: util_helper
INFO - 2018-06-18 21:26:28 --> Helper loaded: text_helper
INFO - 2018-06-18 21:26:28 --> Helper loaded: string_helper
INFO - 2018-06-18 21:26:28 --> Database Driver Class Initialized
DEBUG - 2018-06-18 21:26:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 21:26:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 21:26:28 --> Email Class Initialized
INFO - 2018-06-18 21:26:28 --> Controller Class Initialized
DEBUG - 2018-06-18 21:26:28 --> Login MX_Controller Initialized
INFO - 2018-06-18 21:26:28 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-18 21:26:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-18 21:26:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-18 21:26:28 --> Email starts for admin@colin.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-06-18 21:26:28 --> User session created for 1
INFO - 2018-06-18 21:26:28 --> Login status admin@colin.com - success
INFO - 2018-06-18 21:26:28 --> Final output sent to browser
DEBUG - 2018-06-18 21:26:28 --> Total execution time: 0.3892
INFO - 2018-06-18 21:26:28 --> Config Class Initialized
INFO - 2018-06-18 21:26:28 --> Hooks Class Initialized
DEBUG - 2018-06-18 21:26:28 --> UTF-8 Support Enabled
INFO - 2018-06-18 21:26:28 --> Utf8 Class Initialized
INFO - 2018-06-18 21:26:28 --> URI Class Initialized
INFO - 2018-06-18 21:26:28 --> Router Class Initialized
INFO - 2018-06-18 21:26:28 --> Output Class Initialized
INFO - 2018-06-18 21:26:28 --> Security Class Initialized
DEBUG - 2018-06-18 21:26:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 21:26:28 --> Input Class Initialized
INFO - 2018-06-18 21:26:28 --> Language Class Initialized
INFO - 2018-06-18 21:26:28 --> Language Class Initialized
INFO - 2018-06-18 21:26:28 --> Config Class Initialized
INFO - 2018-06-18 21:26:28 --> Loader Class Initialized
DEBUG - 2018-06-18 21:26:28 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-18 21:26:28 --> Helper loaded: url_helper
INFO - 2018-06-18 21:26:28 --> Helper loaded: form_helper
INFO - 2018-06-18 21:26:28 --> Helper loaded: date_helper
INFO - 2018-06-18 21:26:28 --> Helper loaded: util_helper
INFO - 2018-06-18 21:26:28 --> Helper loaded: text_helper
INFO - 2018-06-18 21:26:28 --> Helper loaded: string_helper
INFO - 2018-06-18 21:26:28 --> Database Driver Class Initialized
DEBUG - 2018-06-18 21:26:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 21:26:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 21:26:28 --> Email Class Initialized
INFO - 2018-06-18 21:26:28 --> Controller Class Initialized
DEBUG - 2018-06-18 21:26:28 --> videos MX_Controller Initialized
INFO - 2018-06-18 21:26:28 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-18 21:26:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-06-18 21:26:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-18 21:26:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-18 21:26:28 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-18 21:26:28 --> Login MX_Controller Initialized
DEBUG - 2018-06-18 21:26:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-18 21:26:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-18 21:26:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-18 21:26:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-18 21:26:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
INFO - 2018-06-18 21:26:29 --> Config Class Initialized
INFO - 2018-06-18 21:26:29 --> Hooks Class Initialized
DEBUG - 2018-06-18 21:26:29 --> UTF-8 Support Enabled
INFO - 2018-06-18 21:26:29 --> Utf8 Class Initialized
INFO - 2018-06-18 21:26:29 --> URI Class Initialized
INFO - 2018-06-18 21:26:29 --> Router Class Initialized
INFO - 2018-06-18 21:26:29 --> Config Class Initialized
INFO - 2018-06-18 21:26:29 --> Hooks Class Initialized
INFO - 2018-06-18 21:26:29 --> Output Class Initialized
INFO - 2018-06-18 21:26:29 --> Security Class Initialized
DEBUG - 2018-06-18 21:26:29 --> UTF-8 Support Enabled
DEBUG - 2018-06-18 21:26:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 21:26:29 --> Input Class Initialized
INFO - 2018-06-18 21:26:29 --> Language Class Initialized
ERROR - 2018-06-18 21:26:29 --> 404 Page Not Found: /index
INFO - 2018-06-18 21:26:29 --> Utf8 Class Initialized
INFO - 2018-06-18 21:26:29 --> URI Class Initialized
INFO - 2018-06-18 21:26:29 --> Router Class Initialized
INFO - 2018-06-18 21:26:29 --> Output Class Initialized
INFO - 2018-06-18 21:26:29 --> Security Class Initialized
DEBUG - 2018-06-18 21:26:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 21:26:29 --> Input Class Initialized
INFO - 2018-06-18 21:26:29 --> Language Class Initialized
ERROR - 2018-06-18 21:26:29 --> 404 Page Not Found: /index
DEBUG - 2018-06-18 21:26:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-18 21:26:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/videos/videos.php
INFO - 2018-06-18 21:26:29 --> Final output sent to browser
DEBUG - 2018-06-18 21:26:29 --> Total execution time: 1.2123
INFO - 2018-06-18 21:26:30 --> Config Class Initialized
INFO - 2018-06-18 21:26:30 --> Hooks Class Initialized
DEBUG - 2018-06-18 21:26:30 --> UTF-8 Support Enabled
INFO - 2018-06-18 21:26:30 --> Utf8 Class Initialized
INFO - 2018-06-18 21:26:30 --> URI Class Initialized
INFO - 2018-06-18 21:26:30 --> Router Class Initialized
INFO - 2018-06-18 21:26:30 --> Output Class Initialized
INFO - 2018-06-18 21:26:30 --> Security Class Initialized
DEBUG - 2018-06-18 21:26:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 21:26:30 --> Input Class Initialized
INFO - 2018-06-18 21:26:30 --> Language Class Initialized
ERROR - 2018-06-18 21:26:30 --> 404 Page Not Found: /index
INFO - 2018-06-18 21:26:30 --> Config Class Initialized
INFO - 2018-06-18 21:26:30 --> Hooks Class Initialized
DEBUG - 2018-06-18 21:26:30 --> UTF-8 Support Enabled
INFO - 2018-06-18 21:26:30 --> Utf8 Class Initialized
INFO - 2018-06-18 21:26:30 --> URI Class Initialized
INFO - 2018-06-18 21:26:30 --> Router Class Initialized
INFO - 2018-06-18 21:26:30 --> Output Class Initialized
INFO - 2018-06-18 21:26:30 --> Security Class Initialized
DEBUG - 2018-06-18 21:26:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 21:26:30 --> Input Class Initialized
INFO - 2018-06-18 21:26:30 --> Language Class Initialized
ERROR - 2018-06-18 21:26:30 --> 404 Page Not Found: /index
INFO - 2018-06-18 21:26:30 --> Config Class Initialized
INFO - 2018-06-18 21:26:30 --> Hooks Class Initialized
DEBUG - 2018-06-18 21:26:30 --> UTF-8 Support Enabled
INFO - 2018-06-18 21:26:30 --> Utf8 Class Initialized
INFO - 2018-06-18 21:26:30 --> URI Class Initialized
INFO - 2018-06-18 21:26:30 --> Router Class Initialized
INFO - 2018-06-18 21:26:30 --> Output Class Initialized
INFO - 2018-06-18 21:26:30 --> Security Class Initialized
DEBUG - 2018-06-18 21:26:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 21:26:30 --> Input Class Initialized
INFO - 2018-06-18 21:26:30 --> Language Class Initialized
ERROR - 2018-06-18 21:26:30 --> 404 Page Not Found: /index
INFO - 2018-06-18 21:26:31 --> Config Class Initialized
INFO - 2018-06-18 21:26:31 --> Hooks Class Initialized
DEBUG - 2018-06-18 21:26:31 --> UTF-8 Support Enabled
INFO - 2018-06-18 21:26:31 --> Utf8 Class Initialized
INFO - 2018-06-18 21:26:31 --> URI Class Initialized
INFO - 2018-06-18 21:26:31 --> Router Class Initialized
INFO - 2018-06-18 21:26:31 --> Output Class Initialized
INFO - 2018-06-18 21:26:31 --> Security Class Initialized
DEBUG - 2018-06-18 21:26:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 21:26:31 --> Input Class Initialized
INFO - 2018-06-18 21:26:31 --> Language Class Initialized
ERROR - 2018-06-18 21:26:31 --> 404 Page Not Found: /index
INFO - 2018-06-18 21:26:31 --> Config Class Initialized
INFO - 2018-06-18 21:26:31 --> Hooks Class Initialized
DEBUG - 2018-06-18 21:26:31 --> UTF-8 Support Enabled
INFO - 2018-06-18 21:26:31 --> Utf8 Class Initialized
INFO - 2018-06-18 21:26:31 --> URI Class Initialized
INFO - 2018-06-18 21:26:31 --> Router Class Initialized
INFO - 2018-06-18 21:26:31 --> Output Class Initialized
INFO - 2018-06-18 21:26:31 --> Security Class Initialized
DEBUG - 2018-06-18 21:26:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 21:26:31 --> Input Class Initialized
INFO - 2018-06-18 21:26:31 --> Language Class Initialized
ERROR - 2018-06-18 21:26:31 --> 404 Page Not Found: /index
INFO - 2018-06-18 21:26:32 --> Config Class Initialized
INFO - 2018-06-18 21:26:32 --> Hooks Class Initialized
DEBUG - 2018-06-18 21:26:32 --> UTF-8 Support Enabled
INFO - 2018-06-18 21:26:32 --> Utf8 Class Initialized
INFO - 2018-06-18 21:26:32 --> URI Class Initialized
INFO - 2018-06-18 21:26:32 --> Router Class Initialized
INFO - 2018-06-18 21:26:32 --> Output Class Initialized
INFO - 2018-06-18 21:26:32 --> Security Class Initialized
DEBUG - 2018-06-18 21:26:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 21:26:32 --> Input Class Initialized
INFO - 2018-06-18 21:26:32 --> Language Class Initialized
INFO - 2018-06-18 21:26:32 --> Language Class Initialized
INFO - 2018-06-18 21:26:32 --> Config Class Initialized
INFO - 2018-06-18 21:26:32 --> Loader Class Initialized
DEBUG - 2018-06-18 21:26:32 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-18 21:26:32 --> Helper loaded: url_helper
INFO - 2018-06-18 21:26:32 --> Helper loaded: form_helper
INFO - 2018-06-18 21:26:32 --> Helper loaded: date_helper
INFO - 2018-06-18 21:26:32 --> Helper loaded: util_helper
INFO - 2018-06-18 21:26:32 --> Helper loaded: text_helper
INFO - 2018-06-18 21:26:32 --> Helper loaded: string_helper
INFO - 2018-06-18 21:26:32 --> Database Driver Class Initialized
DEBUG - 2018-06-18 21:26:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 21:26:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 21:26:32 --> Email Class Initialized
INFO - 2018-06-18 21:26:32 --> Controller Class Initialized
DEBUG - 2018-06-18 21:26:32 --> videos MX_Controller Initialized
INFO - 2018-06-18 21:26:32 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-18 21:26:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-06-18 21:26:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-18 21:26:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-18 21:26:32 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-18 21:26:32 --> Login MX_Controller Initialized
DEBUG - 2018-06-18 21:26:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-18 21:26:32 --> Final output sent to browser
DEBUG - 2018-06-18 21:26:32 --> Total execution time: 0.6925
INFO - 2018-06-18 21:26:50 --> Config Class Initialized
INFO - 2018-06-18 21:26:50 --> Hooks Class Initialized
DEBUG - 2018-06-18 21:26:50 --> UTF-8 Support Enabled
INFO - 2018-06-18 21:26:50 --> Utf8 Class Initialized
INFO - 2018-06-18 21:26:50 --> URI Class Initialized
INFO - 2018-06-18 21:26:50 --> Router Class Initialized
INFO - 2018-06-18 21:26:50 --> Output Class Initialized
INFO - 2018-06-18 21:26:50 --> Security Class Initialized
DEBUG - 2018-06-18 21:26:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 21:26:50 --> Input Class Initialized
INFO - 2018-06-18 21:26:50 --> Language Class Initialized
INFO - 2018-06-18 21:26:50 --> Language Class Initialized
INFO - 2018-06-18 21:26:50 --> Config Class Initialized
INFO - 2018-06-18 21:26:50 --> Loader Class Initialized
DEBUG - 2018-06-18 21:26:50 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-18 21:26:50 --> Helper loaded: url_helper
INFO - 2018-06-18 21:26:50 --> Helper loaded: form_helper
INFO - 2018-06-18 21:26:50 --> Helper loaded: date_helper
INFO - 2018-06-18 21:26:50 --> Helper loaded: util_helper
INFO - 2018-06-18 21:26:50 --> Helper loaded: text_helper
INFO - 2018-06-18 21:26:51 --> Helper loaded: string_helper
INFO - 2018-06-18 21:26:51 --> Database Driver Class Initialized
DEBUG - 2018-06-18 21:26:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 21:26:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 21:26:51 --> Email Class Initialized
INFO - 2018-06-18 21:26:51 --> Controller Class Initialized
DEBUG - 2018-06-18 21:26:51 --> Lessions MX_Controller Initialized
INFO - 2018-06-18 21:26:51 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-18 21:26:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Lessions_model.php
DEBUG - 2018-06-18 21:26:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-18 21:26:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-18 21:26:51 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-18 21:26:51 --> Login MX_Controller Initialized
DEBUG - 2018-06-18 21:26:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-18 21:26:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-18 21:26:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-18 21:26:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-18 21:26:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-18 21:26:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-18 21:26:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/lessions/lessions.php
INFO - 2018-06-18 21:26:51 --> Final output sent to browser
DEBUG - 2018-06-18 21:26:51 --> Total execution time: 0.5151
INFO - 2018-06-18 21:26:51 --> Config Class Initialized
INFO - 2018-06-18 21:26:51 --> Hooks Class Initialized
DEBUG - 2018-06-18 21:26:51 --> UTF-8 Support Enabled
INFO - 2018-06-18 21:26:51 --> Utf8 Class Initialized
INFO - 2018-06-18 21:26:51 --> URI Class Initialized
INFO - 2018-06-18 21:26:51 --> Router Class Initialized
INFO - 2018-06-18 21:26:51 --> Output Class Initialized
INFO - 2018-06-18 21:26:51 --> Security Class Initialized
DEBUG - 2018-06-18 21:26:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 21:26:51 --> Input Class Initialized
INFO - 2018-06-18 21:26:51 --> Language Class Initialized
INFO - 2018-06-18 21:26:51 --> Language Class Initialized
INFO - 2018-06-18 21:26:51 --> Config Class Initialized
INFO - 2018-06-18 21:26:51 --> Loader Class Initialized
DEBUG - 2018-06-18 21:26:51 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-18 21:26:51 --> Helper loaded: url_helper
INFO - 2018-06-18 21:26:51 --> Helper loaded: form_helper
INFO - 2018-06-18 21:26:51 --> Helper loaded: date_helper
INFO - 2018-06-18 21:26:51 --> Helper loaded: util_helper
INFO - 2018-06-18 21:26:51 --> Helper loaded: text_helper
INFO - 2018-06-18 21:26:51 --> Helper loaded: string_helper
INFO - 2018-06-18 21:26:51 --> Database Driver Class Initialized
DEBUG - 2018-06-18 21:26:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 21:26:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 21:26:51 --> Email Class Initialized
INFO - 2018-06-18 21:26:51 --> Controller Class Initialized
DEBUG - 2018-06-18 21:26:51 --> Lessions MX_Controller Initialized
INFO - 2018-06-18 21:26:51 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-18 21:26:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Lessions_model.php
DEBUG - 2018-06-18 21:26:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-18 21:26:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-18 21:26:52 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-18 21:26:52 --> Login MX_Controller Initialized
DEBUG - 2018-06-18 21:26:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-18 21:26:52 --> Final output sent to browser
DEBUG - 2018-06-18 21:26:52 --> Total execution time: 0.4493
INFO - 2018-06-18 21:28:28 --> Config Class Initialized
INFO - 2018-06-18 21:28:28 --> Hooks Class Initialized
DEBUG - 2018-06-18 21:28:28 --> UTF-8 Support Enabled
INFO - 2018-06-18 21:28:28 --> Utf8 Class Initialized
INFO - 2018-06-18 21:28:28 --> URI Class Initialized
INFO - 2018-06-18 21:28:28 --> Router Class Initialized
INFO - 2018-06-18 21:28:28 --> Output Class Initialized
INFO - 2018-06-18 21:28:28 --> Security Class Initialized
DEBUG - 2018-06-18 21:28:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 21:28:28 --> Input Class Initialized
INFO - 2018-06-18 21:28:28 --> Language Class Initialized
INFO - 2018-06-18 21:28:28 --> Language Class Initialized
INFO - 2018-06-18 21:28:28 --> Config Class Initialized
INFO - 2018-06-18 21:28:28 --> Loader Class Initialized
DEBUG - 2018-06-18 21:28:28 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-18 21:28:28 --> Helper loaded: url_helper
INFO - 2018-06-18 21:28:28 --> Helper loaded: form_helper
INFO - 2018-06-18 21:28:28 --> Helper loaded: date_helper
INFO - 2018-06-18 21:28:28 --> Helper loaded: util_helper
INFO - 2018-06-18 21:28:28 --> Helper loaded: text_helper
INFO - 2018-06-18 21:28:28 --> Helper loaded: string_helper
INFO - 2018-06-18 21:28:28 --> Database Driver Class Initialized
DEBUG - 2018-06-18 21:28:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 21:28:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 21:28:28 --> Email Class Initialized
INFO - 2018-06-18 21:28:28 --> Controller Class Initialized
DEBUG - 2018-06-18 21:28:28 --> Lessions MX_Controller Initialized
INFO - 2018-06-18 21:28:28 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-18 21:28:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Lessions_model.php
DEBUG - 2018-06-18 21:28:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-18 21:28:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-18 21:28:28 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-18 21:28:28 --> Login MX_Controller Initialized
DEBUG - 2018-06-18 21:28:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-18 21:28:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-18 21:28:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-18 21:28:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-18 21:28:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-18 21:28:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-18 21:28:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/lessions/lessions.php
INFO - 2018-06-18 21:28:29 --> Final output sent to browser
DEBUG - 2018-06-18 21:28:29 --> Total execution time: 0.3665
INFO - 2018-06-18 21:28:29 --> Config Class Initialized
INFO - 2018-06-18 21:28:29 --> Hooks Class Initialized
DEBUG - 2018-06-18 21:28:29 --> UTF-8 Support Enabled
INFO - 2018-06-18 21:28:29 --> Utf8 Class Initialized
INFO - 2018-06-18 21:28:29 --> URI Class Initialized
INFO - 2018-06-18 21:28:29 --> Router Class Initialized
INFO - 2018-06-18 21:28:29 --> Output Class Initialized
INFO - 2018-06-18 21:28:29 --> Security Class Initialized
DEBUG - 2018-06-18 21:28:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 21:28:30 --> Input Class Initialized
INFO - 2018-06-18 21:28:30 --> Language Class Initialized
INFO - 2018-06-18 21:28:30 --> Language Class Initialized
INFO - 2018-06-18 21:28:30 --> Config Class Initialized
INFO - 2018-06-18 21:28:30 --> Loader Class Initialized
DEBUG - 2018-06-18 21:28:30 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-18 21:28:30 --> Helper loaded: url_helper
INFO - 2018-06-18 21:28:30 --> Helper loaded: form_helper
INFO - 2018-06-18 21:28:30 --> Helper loaded: date_helper
INFO - 2018-06-18 21:28:30 --> Helper loaded: util_helper
INFO - 2018-06-18 21:28:30 --> Helper loaded: text_helper
INFO - 2018-06-18 21:28:30 --> Helper loaded: string_helper
INFO - 2018-06-18 21:28:30 --> Database Driver Class Initialized
DEBUG - 2018-06-18 21:28:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 21:28:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 21:28:30 --> Email Class Initialized
INFO - 2018-06-18 21:28:30 --> Controller Class Initialized
DEBUG - 2018-06-18 21:28:30 --> Lessions MX_Controller Initialized
INFO - 2018-06-18 21:28:30 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-18 21:28:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Lessions_model.php
DEBUG - 2018-06-18 21:28:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-18 21:28:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-18 21:28:30 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-18 21:28:30 --> Login MX_Controller Initialized
DEBUG - 2018-06-18 21:28:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-18 21:28:30 --> Final output sent to browser
DEBUG - 2018-06-18 21:28:30 --> Total execution time: 0.4663
INFO - 2018-06-18 21:28:33 --> Config Class Initialized
INFO - 2018-06-18 21:28:33 --> Hooks Class Initialized
DEBUG - 2018-06-18 21:28:33 --> UTF-8 Support Enabled
INFO - 2018-06-18 21:28:33 --> Utf8 Class Initialized
INFO - 2018-06-18 21:28:33 --> URI Class Initialized
INFO - 2018-06-18 21:28:33 --> Router Class Initialized
INFO - 2018-06-18 21:28:33 --> Output Class Initialized
INFO - 2018-06-18 21:28:33 --> Security Class Initialized
DEBUG - 2018-06-18 21:28:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 21:28:33 --> Input Class Initialized
INFO - 2018-06-18 21:28:33 --> Language Class Initialized
INFO - 2018-06-18 21:28:33 --> Language Class Initialized
INFO - 2018-06-18 21:28:33 --> Config Class Initialized
INFO - 2018-06-18 21:28:33 --> Loader Class Initialized
DEBUG - 2018-06-18 21:28:34 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-18 21:28:34 --> Helper loaded: url_helper
INFO - 2018-06-18 21:28:34 --> Helper loaded: form_helper
INFO - 2018-06-18 21:28:34 --> Helper loaded: date_helper
INFO - 2018-06-18 21:28:34 --> Helper loaded: util_helper
INFO - 2018-06-18 21:28:34 --> Helper loaded: text_helper
INFO - 2018-06-18 21:28:34 --> Helper loaded: string_helper
INFO - 2018-06-18 21:28:34 --> Database Driver Class Initialized
DEBUG - 2018-06-18 21:28:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 21:28:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 21:28:34 --> Email Class Initialized
INFO - 2018-06-18 21:28:34 --> Controller Class Initialized
DEBUG - 2018-06-18 21:28:34 --> Lessions MX_Controller Initialized
INFO - 2018-06-18 21:28:34 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-18 21:28:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Lessions_model.php
DEBUG - 2018-06-18 21:28:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-18 21:28:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-18 21:28:34 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-18 21:28:34 --> Login MX_Controller Initialized
DEBUG - 2018-06-18 21:28:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-18 21:28:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-18 21:28:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-18 21:28:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-18 21:28:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-18 21:28:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-18 21:28:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/lessions/create_lession.php
INFO - 2018-06-18 21:28:34 --> Final output sent to browser
DEBUG - 2018-06-18 21:28:34 --> Total execution time: 0.5065
INFO - 2018-06-18 21:28:35 --> Config Class Initialized
INFO - 2018-06-18 21:28:35 --> Hooks Class Initialized
DEBUG - 2018-06-18 21:28:35 --> UTF-8 Support Enabled
INFO - 2018-06-18 21:28:35 --> Utf8 Class Initialized
INFO - 2018-06-18 21:28:35 --> URI Class Initialized
INFO - 2018-06-18 21:28:35 --> Router Class Initialized
INFO - 2018-06-18 21:28:35 --> Output Class Initialized
INFO - 2018-06-18 21:28:35 --> Security Class Initialized
DEBUG - 2018-06-18 21:28:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 21:28:35 --> Input Class Initialized
INFO - 2018-06-18 21:28:35 --> Language Class Initialized
INFO - 2018-06-18 21:28:35 --> Language Class Initialized
INFO - 2018-06-18 21:28:35 --> Config Class Initialized
INFO - 2018-06-18 21:28:35 --> Loader Class Initialized
DEBUG - 2018-06-18 21:28:36 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-18 21:28:36 --> Helper loaded: url_helper
INFO - 2018-06-18 21:28:36 --> Helper loaded: form_helper
INFO - 2018-06-18 21:28:36 --> Helper loaded: date_helper
INFO - 2018-06-18 21:28:36 --> Helper loaded: util_helper
INFO - 2018-06-18 21:28:36 --> Helper loaded: text_helper
INFO - 2018-06-18 21:28:36 --> Helper loaded: string_helper
INFO - 2018-06-18 21:28:36 --> Database Driver Class Initialized
DEBUG - 2018-06-18 21:28:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 21:28:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 21:28:36 --> Email Class Initialized
INFO - 2018-06-18 21:28:36 --> Controller Class Initialized
DEBUG - 2018-06-18 21:28:36 --> Lessions MX_Controller Initialized
INFO - 2018-06-18 21:28:36 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-18 21:28:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Lessions_model.php
DEBUG - 2018-06-18 21:28:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-18 21:28:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-18 21:28:36 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-18 21:28:36 --> Login MX_Controller Initialized
DEBUG - 2018-06-18 21:28:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-18 21:28:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-18 21:28:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-18 21:28:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-18 21:28:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-18 21:28:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-18 21:28:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/lessions/lessions.php
INFO - 2018-06-18 21:28:36 --> Final output sent to browser
DEBUG - 2018-06-18 21:28:36 --> Total execution time: 0.3855
INFO - 2018-06-18 21:28:36 --> Config Class Initialized
INFO - 2018-06-18 21:28:36 --> Hooks Class Initialized
DEBUG - 2018-06-18 21:28:36 --> UTF-8 Support Enabled
INFO - 2018-06-18 21:28:36 --> Utf8 Class Initialized
INFO - 2018-06-18 21:28:36 --> URI Class Initialized
INFO - 2018-06-18 21:28:36 --> Router Class Initialized
INFO - 2018-06-18 21:28:36 --> Output Class Initialized
INFO - 2018-06-18 21:28:36 --> Security Class Initialized
DEBUG - 2018-06-18 21:28:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 21:28:36 --> Input Class Initialized
INFO - 2018-06-18 21:28:36 --> Language Class Initialized
INFO - 2018-06-18 21:28:36 --> Language Class Initialized
INFO - 2018-06-18 21:28:36 --> Config Class Initialized
INFO - 2018-06-18 21:28:36 --> Loader Class Initialized
DEBUG - 2018-06-18 21:28:36 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-18 21:28:36 --> Helper loaded: url_helper
INFO - 2018-06-18 21:28:36 --> Helper loaded: form_helper
INFO - 2018-06-18 21:28:36 --> Helper loaded: date_helper
INFO - 2018-06-18 21:28:36 --> Helper loaded: util_helper
INFO - 2018-06-18 21:28:36 --> Helper loaded: text_helper
INFO - 2018-06-18 21:28:36 --> Helper loaded: string_helper
INFO - 2018-06-18 21:28:36 --> Database Driver Class Initialized
DEBUG - 2018-06-18 21:28:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 21:28:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 21:28:36 --> Email Class Initialized
INFO - 2018-06-18 21:28:36 --> Controller Class Initialized
DEBUG - 2018-06-18 21:28:36 --> Lessions MX_Controller Initialized
INFO - 2018-06-18 21:28:36 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-18 21:28:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Lessions_model.php
DEBUG - 2018-06-18 21:28:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-18 21:28:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-18 21:28:36 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-18 21:28:36 --> Login MX_Controller Initialized
DEBUG - 2018-06-18 21:28:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-18 21:28:36 --> Final output sent to browser
DEBUG - 2018-06-18 21:28:36 --> Total execution time: 0.4099
INFO - 2018-06-18 21:29:07 --> Config Class Initialized
INFO - 2018-06-18 21:29:07 --> Hooks Class Initialized
DEBUG - 2018-06-18 21:29:07 --> UTF-8 Support Enabled
INFO - 2018-06-18 21:29:07 --> Utf8 Class Initialized
INFO - 2018-06-18 21:29:07 --> URI Class Initialized
DEBUG - 2018-06-18 21:29:07 --> No URI present. Default controller set.
INFO - 2018-06-18 21:29:07 --> Router Class Initialized
INFO - 2018-06-18 21:29:07 --> Output Class Initialized
INFO - 2018-06-18 21:29:07 --> Security Class Initialized
DEBUG - 2018-06-18 21:29:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 21:29:07 --> Input Class Initialized
INFO - 2018-06-18 21:29:07 --> Language Class Initialized
INFO - 2018-06-18 21:29:07 --> Language Class Initialized
INFO - 2018-06-18 21:29:07 --> Config Class Initialized
INFO - 2018-06-18 21:29:07 --> Loader Class Initialized
DEBUG - 2018-06-18 21:29:07 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-18 21:29:07 --> Helper loaded: url_helper
INFO - 2018-06-18 21:29:07 --> Helper loaded: form_helper
INFO - 2018-06-18 21:29:07 --> Helper loaded: date_helper
INFO - 2018-06-18 21:29:07 --> Helper loaded: util_helper
INFO - 2018-06-18 21:29:07 --> Helper loaded: text_helper
INFO - 2018-06-18 21:29:07 --> Helper loaded: string_helper
INFO - 2018-06-18 21:29:07 --> Database Driver Class Initialized
DEBUG - 2018-06-18 21:29:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 21:29:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 21:29:07 --> Email Class Initialized
INFO - 2018-06-18 21:29:07 --> Controller Class Initialized
DEBUG - 2018-06-18 21:29:07 --> Home MX_Controller Initialized
DEBUG - 2018-06-18 21:29:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-18 21:29:07 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-18 21:29:07 --> Login MX_Controller Initialized
INFO - 2018-06-18 21:29:07 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-18 21:29:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-18 21:29:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-18 21:29:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-18 21:29:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-18 21:29:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-18 21:29:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-18 21:29:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-18 21:29:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-06-18 21:29:08 --> Final output sent to browser
DEBUG - 2018-06-18 21:29:08 --> Total execution time: 0.4498
INFO - 2018-06-18 21:29:09 --> Config Class Initialized
INFO - 2018-06-18 21:29:09 --> Hooks Class Initialized
DEBUG - 2018-06-18 21:29:09 --> UTF-8 Support Enabled
INFO - 2018-06-18 21:29:09 --> Utf8 Class Initialized
INFO - 2018-06-18 21:29:09 --> URI Class Initialized
INFO - 2018-06-18 21:29:09 --> Router Class Initialized
INFO - 2018-06-18 21:29:09 --> Output Class Initialized
INFO - 2018-06-18 21:29:09 --> Security Class Initialized
DEBUG - 2018-06-18 21:29:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 21:29:09 --> Input Class Initialized
INFO - 2018-06-18 21:29:09 --> Language Class Initialized
ERROR - 2018-06-18 21:29:09 --> 404 Page Not Found: /index
INFO - 2018-06-18 21:29:16 --> Config Class Initialized
INFO - 2018-06-18 21:29:16 --> Hooks Class Initialized
DEBUG - 2018-06-18 21:29:16 --> UTF-8 Support Enabled
INFO - 2018-06-18 21:29:16 --> Utf8 Class Initialized
INFO - 2018-06-18 21:29:16 --> URI Class Initialized
INFO - 2018-06-18 21:29:16 --> Router Class Initialized
INFO - 2018-06-18 21:29:16 --> Output Class Initialized
INFO - 2018-06-18 21:29:16 --> Security Class Initialized
DEBUG - 2018-06-18 21:29:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 21:29:16 --> Input Class Initialized
INFO - 2018-06-18 21:29:16 --> Language Class Initialized
INFO - 2018-06-18 21:29:16 --> Language Class Initialized
INFO - 2018-06-18 21:29:16 --> Config Class Initialized
INFO - 2018-06-18 21:29:16 --> Loader Class Initialized
DEBUG - 2018-06-18 21:29:16 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-18 21:29:16 --> Helper loaded: url_helper
INFO - 2018-06-18 21:29:16 --> Helper loaded: form_helper
INFO - 2018-06-18 21:29:16 --> Helper loaded: date_helper
INFO - 2018-06-18 21:29:16 --> Helper loaded: util_helper
INFO - 2018-06-18 21:29:16 --> Helper loaded: text_helper
INFO - 2018-06-18 21:29:16 --> Helper loaded: string_helper
INFO - 2018-06-18 21:29:16 --> Database Driver Class Initialized
DEBUG - 2018-06-18 21:29:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 21:29:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 21:29:16 --> Email Class Initialized
INFO - 2018-06-18 21:29:16 --> Controller Class Initialized
DEBUG - 2018-06-18 21:29:16 --> Profile MX_Controller Initialized
INFO - 2018-06-18 21:29:16 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-18 21:29:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-18 21:29:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Profile_model.php
DEBUG - 2018-06-18 21:29:16 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-18 21:29:16 --> Login MX_Controller Initialized
DEBUG - 2018-06-18 21:29:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-18 21:29:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-18 21:29:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-18 21:29:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-18 21:29:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-18 21:29:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-18 21:29:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/admin_password.php
INFO - 2018-06-18 21:29:16 --> Final output sent to browser
DEBUG - 2018-06-18 21:29:16 --> Total execution time: 0.3954
INFO - 2018-06-18 21:29:17 --> Config Class Initialized
INFO - 2018-06-18 21:29:17 --> Hooks Class Initialized
DEBUG - 2018-06-18 21:29:17 --> UTF-8 Support Enabled
INFO - 2018-06-18 21:29:17 --> Utf8 Class Initialized
INFO - 2018-06-18 21:29:17 --> URI Class Initialized
INFO - 2018-06-18 21:29:17 --> Router Class Initialized
INFO - 2018-06-18 21:29:17 --> Output Class Initialized
INFO - 2018-06-18 21:29:17 --> Security Class Initialized
DEBUG - 2018-06-18 21:29:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 21:29:17 --> Input Class Initialized
INFO - 2018-06-18 21:29:17 --> Language Class Initialized
INFO - 2018-06-18 21:29:17 --> Language Class Initialized
INFO - 2018-06-18 21:29:17 --> Config Class Initialized
INFO - 2018-06-18 21:29:17 --> Loader Class Initialized
DEBUG - 2018-06-18 21:29:17 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-18 21:29:17 --> Helper loaded: url_helper
INFO - 2018-06-18 21:29:17 --> Helper loaded: form_helper
INFO - 2018-06-18 21:29:17 --> Helper loaded: date_helper
INFO - 2018-06-18 21:29:17 --> Helper loaded: util_helper
INFO - 2018-06-18 21:29:17 --> Helper loaded: text_helper
INFO - 2018-06-18 21:29:17 --> Helper loaded: string_helper
INFO - 2018-06-18 21:29:17 --> Database Driver Class Initialized
DEBUG - 2018-06-18 21:29:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 21:29:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 21:29:17 --> Email Class Initialized
INFO - 2018-06-18 21:29:17 --> Controller Class Initialized
DEBUG - 2018-06-18 21:29:17 --> Profile MX_Controller Initialized
INFO - 2018-06-18 21:29:17 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-18 21:29:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-18 21:29:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Profile_model.php
DEBUG - 2018-06-18 21:29:17 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-18 21:29:17 --> Login MX_Controller Initialized
DEBUG - 2018-06-18 21:29:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-18 21:29:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-18 21:29:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-18 21:29:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-18 21:29:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-18 21:29:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-18 21:29:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/profile.php
INFO - 2018-06-18 21:29:17 --> Final output sent to browser
DEBUG - 2018-06-18 21:29:17 --> Total execution time: 0.4167
INFO - 2018-06-18 21:29:20 --> Config Class Initialized
INFO - 2018-06-18 21:29:20 --> Hooks Class Initialized
DEBUG - 2018-06-18 21:29:20 --> UTF-8 Support Enabled
INFO - 2018-06-18 21:29:20 --> Utf8 Class Initialized
INFO - 2018-06-18 21:29:20 --> URI Class Initialized
INFO - 2018-06-18 21:29:20 --> Router Class Initialized
INFO - 2018-06-18 21:29:20 --> Output Class Initialized
INFO - 2018-06-18 21:29:20 --> Security Class Initialized
DEBUG - 2018-06-18 21:29:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 21:29:20 --> Input Class Initialized
INFO - 2018-06-18 21:29:20 --> Language Class Initialized
INFO - 2018-06-18 21:29:20 --> Language Class Initialized
INFO - 2018-06-18 21:29:20 --> Config Class Initialized
INFO - 2018-06-18 21:29:20 --> Loader Class Initialized
DEBUG - 2018-06-18 21:29:20 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-18 21:29:20 --> Helper loaded: url_helper
INFO - 2018-06-18 21:29:20 --> Helper loaded: form_helper
INFO - 2018-06-18 21:29:20 --> Helper loaded: date_helper
INFO - 2018-06-18 21:29:20 --> Helper loaded: util_helper
INFO - 2018-06-18 21:29:20 --> Helper loaded: text_helper
INFO - 2018-06-18 21:29:20 --> Helper loaded: string_helper
INFO - 2018-06-18 21:29:21 --> Database Driver Class Initialized
DEBUG - 2018-06-18 21:29:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 21:29:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 21:29:21 --> Email Class Initialized
INFO - 2018-06-18 21:29:21 --> Controller Class Initialized
DEBUG - 2018-06-18 21:29:21 --> Profile MX_Controller Initialized
INFO - 2018-06-18 21:29:21 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-18 21:29:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-18 21:29:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Profile_model.php
DEBUG - 2018-06-18 21:29:21 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-18 21:29:21 --> Login MX_Controller Initialized
DEBUG - 2018-06-18 21:29:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-18 21:29:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-18 21:29:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-18 21:29:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-18 21:29:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-18 21:29:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-18 21:29:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/admin_password.php
INFO - 2018-06-18 21:29:21 --> Final output sent to browser
DEBUG - 2018-06-18 21:29:21 --> Total execution time: 0.4012
INFO - 2018-06-18 21:30:21 --> Config Class Initialized
INFO - 2018-06-18 21:30:21 --> Hooks Class Initialized
DEBUG - 2018-06-18 21:30:21 --> UTF-8 Support Enabled
INFO - 2018-06-18 21:30:21 --> Utf8 Class Initialized
INFO - 2018-06-18 21:30:21 --> URI Class Initialized
INFO - 2018-06-18 21:30:22 --> Router Class Initialized
INFO - 2018-06-18 21:30:22 --> Output Class Initialized
INFO - 2018-06-18 21:30:22 --> Security Class Initialized
DEBUG - 2018-06-18 21:30:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 21:30:22 --> Input Class Initialized
INFO - 2018-06-18 21:30:22 --> Language Class Initialized
INFO - 2018-06-18 21:30:22 --> Language Class Initialized
INFO - 2018-06-18 21:30:22 --> Config Class Initialized
INFO - 2018-06-18 21:30:22 --> Loader Class Initialized
DEBUG - 2018-06-18 21:30:22 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-18 21:30:22 --> Helper loaded: url_helper
INFO - 2018-06-18 21:30:22 --> Helper loaded: form_helper
INFO - 2018-06-18 21:30:22 --> Helper loaded: date_helper
INFO - 2018-06-18 21:30:22 --> Helper loaded: util_helper
INFO - 2018-06-18 21:30:22 --> Helper loaded: text_helper
INFO - 2018-06-18 21:30:22 --> Helper loaded: string_helper
INFO - 2018-06-18 21:30:22 --> Database Driver Class Initialized
DEBUG - 2018-06-18 21:30:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 21:30:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 21:30:22 --> Email Class Initialized
INFO - 2018-06-18 21:30:22 --> Controller Class Initialized
DEBUG - 2018-06-18 21:30:22 --> Admin MX_Controller Initialized
INFO - 2018-06-18 21:30:22 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-18 21:30:22 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-18 21:30:22 --> Login MX_Controller Initialized
DEBUG - 2018-06-18 21:30:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-18 21:30:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-18 21:30:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-18 21:30:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-18 21:30:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-18 21:30:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-18 21:30:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-18 21:30:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/dashboard.php
INFO - 2018-06-18 21:30:22 --> Final output sent to browser
DEBUG - 2018-06-18 21:30:22 --> Total execution time: 0.4112
INFO - 2018-06-18 21:30:22 --> Config Class Initialized
INFO - 2018-06-18 21:30:22 --> Hooks Class Initialized
DEBUG - 2018-06-18 21:30:22 --> UTF-8 Support Enabled
INFO - 2018-06-18 21:30:22 --> Utf8 Class Initialized
INFO - 2018-06-18 21:30:22 --> URI Class Initialized
INFO - 2018-06-18 21:30:22 --> Router Class Initialized
INFO - 2018-06-18 21:30:22 --> Config Class Initialized
INFO - 2018-06-18 21:30:22 --> Hooks Class Initialized
INFO - 2018-06-18 21:30:22 --> Output Class Initialized
INFO - 2018-06-18 21:30:22 --> Security Class Initialized
DEBUG - 2018-06-18 21:30:22 --> UTF-8 Support Enabled
INFO - 2018-06-18 21:30:22 --> Utf8 Class Initialized
DEBUG - 2018-06-18 21:30:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 21:30:22 --> Input Class Initialized
INFO - 2018-06-18 21:30:22 --> URI Class Initialized
INFO - 2018-06-18 21:30:22 --> Language Class Initialized
INFO - 2018-06-18 21:30:22 --> Router Class Initialized
INFO - 2018-06-18 21:30:22 --> Output Class Initialized
ERROR - 2018-06-18 21:30:22 --> 404 Page Not Found: /index
INFO - 2018-06-18 21:30:22 --> Security Class Initialized
DEBUG - 2018-06-18 21:30:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 21:30:22 --> Input Class Initialized
INFO - 2018-06-18 21:30:22 --> Language Class Initialized
ERROR - 2018-06-18 21:30:22 --> 404 Page Not Found: /index
INFO - 2018-06-18 21:32:31 --> Config Class Initialized
INFO - 2018-06-18 21:32:31 --> Hooks Class Initialized
DEBUG - 2018-06-18 21:32:31 --> UTF-8 Support Enabled
INFO - 2018-06-18 21:32:31 --> Utf8 Class Initialized
INFO - 2018-06-18 21:32:31 --> URI Class Initialized
INFO - 2018-06-18 21:32:31 --> Router Class Initialized
INFO - 2018-06-18 21:32:31 --> Output Class Initialized
INFO - 2018-06-18 21:32:31 --> Security Class Initialized
DEBUG - 2018-06-18 21:32:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 21:32:31 --> Input Class Initialized
INFO - 2018-06-18 21:32:31 --> Language Class Initialized
INFO - 2018-06-18 21:32:31 --> Language Class Initialized
INFO - 2018-06-18 21:32:31 --> Config Class Initialized
INFO - 2018-06-18 21:32:31 --> Loader Class Initialized
DEBUG - 2018-06-18 21:32:31 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-18 21:32:31 --> Helper loaded: url_helper
INFO - 2018-06-18 21:32:31 --> Helper loaded: form_helper
INFO - 2018-06-18 21:32:31 --> Helper loaded: date_helper
INFO - 2018-06-18 21:32:31 --> Helper loaded: util_helper
INFO - 2018-06-18 21:32:32 --> Helper loaded: text_helper
INFO - 2018-06-18 21:32:32 --> Helper loaded: string_helper
INFO - 2018-06-18 21:32:32 --> Database Driver Class Initialized
DEBUG - 2018-06-18 21:32:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 21:32:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 21:32:32 --> Email Class Initialized
INFO - 2018-06-18 21:32:32 --> Controller Class Initialized
DEBUG - 2018-06-18 21:32:32 --> Home MX_Controller Initialized
DEBUG - 2018-06-18 21:32:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-18 21:32:32 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-18 21:32:32 --> Login MX_Controller Initialized
INFO - 2018-06-18 21:32:32 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-18 21:32:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-18 21:32:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-18 21:32:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-18 21:32:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-18 21:32:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-18 21:32:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-18 21:32:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-18 21:32:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-06-18 21:32:32 --> Final output sent to browser
DEBUG - 2018-06-18 21:32:32 --> Total execution time: 0.4941
INFO - 2018-06-18 21:32:37 --> Config Class Initialized
INFO - 2018-06-18 21:32:37 --> Config Class Initialized
INFO - 2018-06-18 21:32:37 --> Hooks Class Initialized
DEBUG - 2018-06-18 21:32:37 --> UTF-8 Support Enabled
INFO - 2018-06-18 21:32:37 --> Hooks Class Initialized
INFO - 2018-06-18 21:32:37 --> Utf8 Class Initialized
DEBUG - 2018-06-18 21:32:37 --> UTF-8 Support Enabled
INFO - 2018-06-18 21:32:37 --> Utf8 Class Initialized
INFO - 2018-06-18 21:32:37 --> URI Class Initialized
INFO - 2018-06-18 21:32:37 --> Router Class Initialized
INFO - 2018-06-18 21:32:38 --> Output Class Initialized
INFO - 2018-06-18 21:32:38 --> Security Class Initialized
DEBUG - 2018-06-18 21:32:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 21:32:38 --> Input Class Initialized
INFO - 2018-06-18 21:32:38 --> Language Class Initialized
ERROR - 2018-06-18 21:32:38 --> 404 Page Not Found: /index
INFO - 2018-06-18 21:32:38 --> URI Class Initialized
INFO - 2018-06-18 21:32:38 --> Router Class Initialized
INFO - 2018-06-18 21:32:38 --> Output Class Initialized
INFO - 2018-06-18 21:32:38 --> Config Class Initialized
INFO - 2018-06-18 21:32:38 --> Hooks Class Initialized
INFO - 2018-06-18 21:32:38 --> Security Class Initialized
DEBUG - 2018-06-18 21:32:38 --> UTF-8 Support Enabled
INFO - 2018-06-18 21:32:38 --> Utf8 Class Initialized
INFO - 2018-06-18 21:32:38 --> URI Class Initialized
INFO - 2018-06-18 21:32:38 --> Router Class Initialized
DEBUG - 2018-06-18 21:32:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 21:32:38 --> Output Class Initialized
INFO - 2018-06-18 21:32:38 --> Security Class Initialized
INFO - 2018-06-18 21:32:38 --> Input Class Initialized
DEBUG - 2018-06-18 21:32:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 21:32:38 --> Language Class Initialized
INFO - 2018-06-18 21:32:38 --> Input Class Initialized
INFO - 2018-06-18 21:32:38 --> Language Class Initialized
ERROR - 2018-06-18 21:32:38 --> 404 Page Not Found: /index
ERROR - 2018-06-18 21:32:38 --> 404 Page Not Found: /index
INFO - 2018-06-18 21:32:38 --> Config Class Initialized
INFO - 2018-06-18 21:32:38 --> Hooks Class Initialized
DEBUG - 2018-06-18 21:32:38 --> UTF-8 Support Enabled
INFO - 2018-06-18 21:32:38 --> Utf8 Class Initialized
INFO - 2018-06-18 21:32:38 --> URI Class Initialized
INFO - 2018-06-18 21:32:38 --> Router Class Initialized
INFO - 2018-06-18 21:32:38 --> Output Class Initialized
INFO - 2018-06-18 21:32:38 --> Security Class Initialized
DEBUG - 2018-06-18 21:32:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 21:32:38 --> Input Class Initialized
INFO - 2018-06-18 21:32:38 --> Language Class Initialized
ERROR - 2018-06-18 21:32:38 --> 404 Page Not Found: /index
INFO - 2018-06-18 21:32:38 --> Config Class Initialized
INFO - 2018-06-18 21:32:38 --> Hooks Class Initialized
DEBUG - 2018-06-18 21:32:38 --> UTF-8 Support Enabled
INFO - 2018-06-18 21:32:38 --> Utf8 Class Initialized
INFO - 2018-06-18 21:32:38 --> URI Class Initialized
INFO - 2018-06-18 21:32:38 --> Router Class Initialized
INFO - 2018-06-18 21:32:38 --> Output Class Initialized
INFO - 2018-06-18 21:32:38 --> Security Class Initialized
DEBUG - 2018-06-18 21:32:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 21:32:38 --> Input Class Initialized
INFO - 2018-06-18 21:32:38 --> Language Class Initialized
ERROR - 2018-06-18 21:32:38 --> 404 Page Not Found: /index
INFO - 2018-06-18 21:32:38 --> Config Class Initialized
INFO - 2018-06-18 21:32:38 --> Hooks Class Initialized
DEBUG - 2018-06-18 21:32:38 --> UTF-8 Support Enabled
INFO - 2018-06-18 21:32:38 --> Utf8 Class Initialized
INFO - 2018-06-18 21:32:38 --> URI Class Initialized
INFO - 2018-06-18 21:32:38 --> Router Class Initialized
INFO - 2018-06-18 21:32:38 --> Output Class Initialized
INFO - 2018-06-18 21:32:38 --> Security Class Initialized
DEBUG - 2018-06-18 21:32:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 21:32:38 --> Input Class Initialized
INFO - 2018-06-18 21:32:38 --> Language Class Initialized
ERROR - 2018-06-18 21:32:38 --> 404 Page Not Found: /index
INFO - 2018-06-18 21:32:38 --> Config Class Initialized
INFO - 2018-06-18 21:32:38 --> Hooks Class Initialized
DEBUG - 2018-06-18 21:32:38 --> UTF-8 Support Enabled
INFO - 2018-06-18 21:32:38 --> Utf8 Class Initialized
INFO - 2018-06-18 21:32:38 --> URI Class Initialized
INFO - 2018-06-18 21:32:38 --> Router Class Initialized
INFO - 2018-06-18 21:32:38 --> Output Class Initialized
INFO - 2018-06-18 21:32:38 --> Security Class Initialized
DEBUG - 2018-06-18 21:32:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 21:32:38 --> Input Class Initialized
INFO - 2018-06-18 21:32:38 --> Language Class Initialized
ERROR - 2018-06-18 21:32:38 --> 404 Page Not Found: /index
INFO - 2018-06-18 21:34:07 --> Config Class Initialized
INFO - 2018-06-18 21:34:07 --> Hooks Class Initialized
DEBUG - 2018-06-18 21:34:07 --> UTF-8 Support Enabled
INFO - 2018-06-18 21:34:07 --> Utf8 Class Initialized
INFO - 2018-06-18 21:34:07 --> URI Class Initialized
INFO - 2018-06-18 21:34:07 --> Router Class Initialized
INFO - 2018-06-18 21:34:07 --> Output Class Initialized
INFO - 2018-06-18 21:34:07 --> Security Class Initialized
DEBUG - 2018-06-18 21:34:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 21:34:07 --> Input Class Initialized
INFO - 2018-06-18 21:34:07 --> Language Class Initialized
INFO - 2018-06-18 21:34:07 --> Language Class Initialized
INFO - 2018-06-18 21:34:07 --> Config Class Initialized
INFO - 2018-06-18 21:34:07 --> Loader Class Initialized
DEBUG - 2018-06-18 21:34:07 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-18 21:34:07 --> Helper loaded: url_helper
INFO - 2018-06-18 21:34:07 --> Helper loaded: form_helper
INFO - 2018-06-18 21:34:07 --> Helper loaded: date_helper
INFO - 2018-06-18 21:34:07 --> Helper loaded: util_helper
INFO - 2018-06-18 21:34:07 --> Helper loaded: text_helper
INFO - 2018-06-18 21:34:07 --> Helper loaded: string_helper
INFO - 2018-06-18 21:34:07 --> Database Driver Class Initialized
DEBUG - 2018-06-18 21:34:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 21:34:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 21:34:08 --> Email Class Initialized
INFO - 2018-06-18 21:34:08 --> Controller Class Initialized
DEBUG - 2018-06-18 21:34:08 --> Chapters MX_Controller Initialized
INFO - 2018-06-18 21:34:08 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-18 21:34:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Chapters_model.php
DEBUG - 2018-06-18 21:34:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-18 21:34:08 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-18 21:34:08 --> Login MX_Controller Initialized
DEBUG - 2018-06-18 21:34:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-18 21:34:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-18 21:34:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-18 21:34:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-18 21:34:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-18 21:34:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-18 21:34:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/chapters/chapters.php
INFO - 2018-06-18 21:34:08 --> Final output sent to browser
DEBUG - 2018-06-18 21:34:08 --> Total execution time: 0.5536
INFO - 2018-06-18 21:34:08 --> Config Class Initialized
INFO - 2018-06-18 21:34:08 --> Hooks Class Initialized
DEBUG - 2018-06-18 21:34:08 --> UTF-8 Support Enabled
INFO - 2018-06-18 21:34:08 --> Utf8 Class Initialized
INFO - 2018-06-18 21:34:08 --> URI Class Initialized
INFO - 2018-06-18 21:34:08 --> Router Class Initialized
INFO - 2018-06-18 21:34:08 --> Output Class Initialized
INFO - 2018-06-18 21:34:08 --> Security Class Initialized
DEBUG - 2018-06-18 21:34:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 21:34:08 --> Input Class Initialized
INFO - 2018-06-18 21:34:08 --> Language Class Initialized
INFO - 2018-06-18 21:34:08 --> Language Class Initialized
INFO - 2018-06-18 21:34:08 --> Config Class Initialized
INFO - 2018-06-18 21:34:08 --> Loader Class Initialized
DEBUG - 2018-06-18 21:34:09 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-18 21:34:09 --> Helper loaded: url_helper
INFO - 2018-06-18 21:34:09 --> Helper loaded: form_helper
INFO - 2018-06-18 21:34:09 --> Helper loaded: date_helper
INFO - 2018-06-18 21:34:09 --> Helper loaded: util_helper
INFO - 2018-06-18 21:34:09 --> Helper loaded: text_helper
INFO - 2018-06-18 21:34:09 --> Helper loaded: string_helper
INFO - 2018-06-18 21:34:09 --> Database Driver Class Initialized
DEBUG - 2018-06-18 21:34:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 21:34:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 21:34:09 --> Email Class Initialized
INFO - 2018-06-18 21:34:09 --> Controller Class Initialized
DEBUG - 2018-06-18 21:34:09 --> Chapters MX_Controller Initialized
INFO - 2018-06-18 21:34:09 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-18 21:34:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Chapters_model.php
DEBUG - 2018-06-18 21:34:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-18 21:34:09 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-18 21:34:09 --> Login MX_Controller Initialized
DEBUG - 2018-06-18 21:34:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-18 21:34:09 --> Final output sent to browser
DEBUG - 2018-06-18 21:34:09 --> Total execution time: 0.4538
INFO - 2018-06-18 21:34:11 --> Config Class Initialized
INFO - 2018-06-18 21:34:11 --> Hooks Class Initialized
DEBUG - 2018-06-18 21:34:11 --> UTF-8 Support Enabled
INFO - 2018-06-18 21:34:11 --> Utf8 Class Initialized
INFO - 2018-06-18 21:34:11 --> URI Class Initialized
INFO - 2018-06-18 21:34:11 --> Router Class Initialized
INFO - 2018-06-18 21:34:11 --> Output Class Initialized
INFO - 2018-06-18 21:34:11 --> Security Class Initialized
DEBUG - 2018-06-18 21:34:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 21:34:11 --> Input Class Initialized
INFO - 2018-06-18 21:34:11 --> Language Class Initialized
INFO - 2018-06-18 21:34:11 --> Language Class Initialized
INFO - 2018-06-18 21:34:11 --> Config Class Initialized
INFO - 2018-06-18 21:34:11 --> Loader Class Initialized
DEBUG - 2018-06-18 21:34:11 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-18 21:34:11 --> Helper loaded: url_helper
INFO - 2018-06-18 21:34:11 --> Helper loaded: form_helper
INFO - 2018-06-18 21:34:11 --> Helper loaded: date_helper
INFO - 2018-06-18 21:34:11 --> Helper loaded: util_helper
INFO - 2018-06-18 21:34:11 --> Helper loaded: text_helper
INFO - 2018-06-18 21:34:11 --> Helper loaded: string_helper
INFO - 2018-06-18 21:34:11 --> Database Driver Class Initialized
DEBUG - 2018-06-18 21:34:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 21:34:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 21:34:11 --> Email Class Initialized
INFO - 2018-06-18 21:34:11 --> Controller Class Initialized
DEBUG - 2018-06-18 21:34:11 --> Lessions MX_Controller Initialized
INFO - 2018-06-18 21:34:11 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-18 21:34:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Lessions_model.php
DEBUG - 2018-06-18 21:34:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-18 21:34:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-18 21:34:11 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-18 21:34:11 --> Login MX_Controller Initialized
DEBUG - 2018-06-18 21:34:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-18 21:34:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-18 21:34:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-18 21:34:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-18 21:34:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-18 21:34:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-18 21:34:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/lessions/lessions.php
INFO - 2018-06-18 21:34:12 --> Final output sent to browser
DEBUG - 2018-06-18 21:34:12 --> Total execution time: 0.4176
INFO - 2018-06-18 21:34:12 --> Config Class Initialized
INFO - 2018-06-18 21:34:12 --> Hooks Class Initialized
DEBUG - 2018-06-18 21:34:12 --> UTF-8 Support Enabled
INFO - 2018-06-18 21:34:12 --> Utf8 Class Initialized
INFO - 2018-06-18 21:34:12 --> URI Class Initialized
INFO - 2018-06-18 21:34:12 --> Router Class Initialized
INFO - 2018-06-18 21:34:12 --> Output Class Initialized
INFO - 2018-06-18 21:34:12 --> Security Class Initialized
DEBUG - 2018-06-18 21:34:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 21:34:12 --> Input Class Initialized
INFO - 2018-06-18 21:34:12 --> Language Class Initialized
INFO - 2018-06-18 21:34:12 --> Language Class Initialized
INFO - 2018-06-18 21:34:12 --> Config Class Initialized
INFO - 2018-06-18 21:34:12 --> Loader Class Initialized
DEBUG - 2018-06-18 21:34:12 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-18 21:34:12 --> Helper loaded: url_helper
INFO - 2018-06-18 21:34:12 --> Helper loaded: form_helper
INFO - 2018-06-18 21:34:12 --> Helper loaded: date_helper
INFO - 2018-06-18 21:34:12 --> Helper loaded: util_helper
INFO - 2018-06-18 21:34:12 --> Helper loaded: text_helper
INFO - 2018-06-18 21:34:12 --> Helper loaded: string_helper
INFO - 2018-06-18 21:34:12 --> Database Driver Class Initialized
DEBUG - 2018-06-18 21:34:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 21:34:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 21:34:12 --> Email Class Initialized
INFO - 2018-06-18 21:34:12 --> Controller Class Initialized
DEBUG - 2018-06-18 21:34:12 --> Lessions MX_Controller Initialized
INFO - 2018-06-18 21:34:12 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-18 21:34:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Lessions_model.php
DEBUG - 2018-06-18 21:34:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-18 21:34:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-18 21:34:12 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-18 21:34:12 --> Login MX_Controller Initialized
DEBUG - 2018-06-18 21:34:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-18 21:34:12 --> Final output sent to browser
DEBUG - 2018-06-18 21:34:13 --> Total execution time: 0.5924
INFO - 2018-06-18 21:34:13 --> Config Class Initialized
INFO - 2018-06-18 21:34:13 --> Hooks Class Initialized
DEBUG - 2018-06-18 21:34:13 --> UTF-8 Support Enabled
INFO - 2018-06-18 21:34:13 --> Utf8 Class Initialized
INFO - 2018-06-18 21:34:13 --> URI Class Initialized
INFO - 2018-06-18 21:34:13 --> Router Class Initialized
INFO - 2018-06-18 21:34:13 --> Output Class Initialized
INFO - 2018-06-18 21:34:13 --> Security Class Initialized
DEBUG - 2018-06-18 21:34:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 21:34:13 --> Input Class Initialized
INFO - 2018-06-18 21:34:13 --> Language Class Initialized
INFO - 2018-06-18 21:34:13 --> Language Class Initialized
INFO - 2018-06-18 21:34:13 --> Config Class Initialized
INFO - 2018-06-18 21:34:13 --> Loader Class Initialized
DEBUG - 2018-06-18 21:34:13 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-18 21:34:13 --> Helper loaded: url_helper
INFO - 2018-06-18 21:34:13 --> Helper loaded: form_helper
INFO - 2018-06-18 21:34:13 --> Helper loaded: date_helper
INFO - 2018-06-18 21:34:13 --> Helper loaded: util_helper
INFO - 2018-06-18 21:34:13 --> Helper loaded: text_helper
INFO - 2018-06-18 21:34:13 --> Helper loaded: string_helper
INFO - 2018-06-18 21:34:13 --> Database Driver Class Initialized
DEBUG - 2018-06-18 21:34:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 21:34:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 21:34:13 --> Email Class Initialized
INFO - 2018-06-18 21:34:13 --> Controller Class Initialized
DEBUG - 2018-06-18 21:34:13 --> Lessions MX_Controller Initialized
INFO - 2018-06-18 21:34:13 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-18 21:34:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Lessions_model.php
DEBUG - 2018-06-18 21:34:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-18 21:34:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-18 21:34:13 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-18 21:34:13 --> Login MX_Controller Initialized
DEBUG - 2018-06-18 21:34:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-18 21:34:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-18 21:34:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-18 21:34:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-18 21:34:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-18 21:34:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-18 21:34:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/lessions/create_lession.php
INFO - 2018-06-18 21:34:13 --> Final output sent to browser
DEBUG - 2018-06-18 21:34:14 --> Total execution time: 0.4145
INFO - 2018-06-18 21:34:17 --> Config Class Initialized
INFO - 2018-06-18 21:34:17 --> Hooks Class Initialized
DEBUG - 2018-06-18 21:34:17 --> UTF-8 Support Enabled
INFO - 2018-06-18 21:34:17 --> Utf8 Class Initialized
INFO - 2018-06-18 21:34:17 --> URI Class Initialized
INFO - 2018-06-18 21:34:17 --> Router Class Initialized
INFO - 2018-06-18 21:34:17 --> Output Class Initialized
INFO - 2018-06-18 21:34:17 --> Security Class Initialized
DEBUG - 2018-06-18 21:34:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 21:34:17 --> Input Class Initialized
INFO - 2018-06-18 21:34:17 --> Language Class Initialized
INFO - 2018-06-18 21:34:17 --> Language Class Initialized
INFO - 2018-06-18 21:34:17 --> Config Class Initialized
INFO - 2018-06-18 21:34:17 --> Loader Class Initialized
DEBUG - 2018-06-18 21:34:17 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-18 21:34:17 --> Helper loaded: url_helper
INFO - 2018-06-18 21:34:17 --> Helper loaded: form_helper
INFO - 2018-06-18 21:34:17 --> Helper loaded: date_helper
INFO - 2018-06-18 21:34:17 --> Helper loaded: util_helper
INFO - 2018-06-18 21:34:17 --> Helper loaded: text_helper
INFO - 2018-06-18 21:34:17 --> Helper loaded: string_helper
INFO - 2018-06-18 21:34:17 --> Database Driver Class Initialized
DEBUG - 2018-06-18 21:34:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 21:34:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 21:34:17 --> Email Class Initialized
INFO - 2018-06-18 21:34:17 --> Controller Class Initialized
DEBUG - 2018-06-18 21:34:17 --> Lessions MX_Controller Initialized
INFO - 2018-06-18 21:34:17 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-18 21:34:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Lessions_model.php
DEBUG - 2018-06-18 21:34:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-18 21:34:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-18 21:34:17 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-18 21:34:17 --> Login MX_Controller Initialized
DEBUG - 2018-06-18 21:34:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-18 21:34:31 --> Config Class Initialized
INFO - 2018-06-18 21:34:31 --> Hooks Class Initialized
DEBUG - 2018-06-18 21:34:31 --> UTF-8 Support Enabled
INFO - 2018-06-18 21:34:32 --> Utf8 Class Initialized
INFO - 2018-06-18 21:34:32 --> URI Class Initialized
INFO - 2018-06-18 21:34:32 --> Router Class Initialized
INFO - 2018-06-18 21:34:32 --> Output Class Initialized
INFO - 2018-06-18 21:34:32 --> Security Class Initialized
DEBUG - 2018-06-18 21:34:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 21:34:32 --> Input Class Initialized
INFO - 2018-06-18 21:34:32 --> Language Class Initialized
INFO - 2018-06-18 21:34:32 --> Language Class Initialized
INFO - 2018-06-18 21:34:32 --> Config Class Initialized
INFO - 2018-06-18 21:34:32 --> Loader Class Initialized
DEBUG - 2018-06-18 21:34:32 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-18 21:34:32 --> Helper loaded: url_helper
INFO - 2018-06-18 21:34:32 --> Helper loaded: form_helper
INFO - 2018-06-18 21:34:32 --> Helper loaded: date_helper
INFO - 2018-06-18 21:34:32 --> Helper loaded: util_helper
INFO - 2018-06-18 21:34:32 --> Helper loaded: text_helper
INFO - 2018-06-18 21:34:32 --> Helper loaded: string_helper
INFO - 2018-06-18 21:34:32 --> Database Driver Class Initialized
DEBUG - 2018-06-18 21:34:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 21:34:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 21:34:32 --> Email Class Initialized
INFO - 2018-06-18 21:34:32 --> Controller Class Initialized
DEBUG - 2018-06-18 21:34:32 --> Lessions MX_Controller Initialized
INFO - 2018-06-18 21:34:32 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-18 21:34:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Lessions_model.php
DEBUG - 2018-06-18 21:34:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-18 21:34:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-18 21:34:32 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-18 21:34:32 --> Login MX_Controller Initialized
DEBUG - 2018-06-18 21:34:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-18 21:34:32 --> Config Class Initialized
INFO - 2018-06-18 21:34:32 --> Hooks Class Initialized
DEBUG - 2018-06-18 21:34:32 --> UTF-8 Support Enabled
INFO - 2018-06-18 21:34:32 --> Utf8 Class Initialized
INFO - 2018-06-18 21:34:32 --> URI Class Initialized
INFO - 2018-06-18 21:34:32 --> Router Class Initialized
INFO - 2018-06-18 21:34:32 --> Output Class Initialized
INFO - 2018-06-18 21:34:32 --> Security Class Initialized
DEBUG - 2018-06-18 21:34:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 21:34:32 --> Input Class Initialized
INFO - 2018-06-18 21:34:32 --> Language Class Initialized
INFO - 2018-06-18 21:34:32 --> Language Class Initialized
INFO - 2018-06-18 21:34:32 --> Config Class Initialized
INFO - 2018-06-18 21:34:32 --> Loader Class Initialized
DEBUG - 2018-06-18 21:34:32 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-18 21:34:32 --> Helper loaded: url_helper
INFO - 2018-06-18 21:34:32 --> Helper loaded: form_helper
INFO - 2018-06-18 21:34:32 --> Helper loaded: date_helper
INFO - 2018-06-18 21:34:32 --> Helper loaded: util_helper
INFO - 2018-06-18 21:34:32 --> Helper loaded: text_helper
INFO - 2018-06-18 21:34:32 --> Helper loaded: string_helper
INFO - 2018-06-18 21:34:32 --> Database Driver Class Initialized
DEBUG - 2018-06-18 21:34:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 21:34:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 21:34:32 --> Email Class Initialized
INFO - 2018-06-18 21:34:32 --> Controller Class Initialized
DEBUG - 2018-06-18 21:34:32 --> Lessions MX_Controller Initialized
INFO - 2018-06-18 21:34:32 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-18 21:34:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Lessions_model.php
DEBUG - 2018-06-18 21:34:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-18 21:34:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-18 21:34:32 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-18 21:34:32 --> Login MX_Controller Initialized
DEBUG - 2018-06-18 21:34:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-18 21:34:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-18 21:34:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-18 21:34:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-18 21:34:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-18 21:34:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-18 21:34:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/lessions/lessions.php
INFO - 2018-06-18 21:34:32 --> Final output sent to browser
DEBUG - 2018-06-18 21:34:32 --> Total execution time: 0.4713
INFO - 2018-06-18 21:34:33 --> Config Class Initialized
INFO - 2018-06-18 21:34:33 --> Hooks Class Initialized
DEBUG - 2018-06-18 21:34:33 --> UTF-8 Support Enabled
INFO - 2018-06-18 21:34:33 --> Utf8 Class Initialized
INFO - 2018-06-18 21:34:33 --> URI Class Initialized
INFO - 2018-06-18 21:34:33 --> Router Class Initialized
INFO - 2018-06-18 21:34:33 --> Output Class Initialized
INFO - 2018-06-18 21:34:33 --> Security Class Initialized
DEBUG - 2018-06-18 21:34:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 21:34:33 --> Input Class Initialized
INFO - 2018-06-18 21:34:33 --> Language Class Initialized
INFO - 2018-06-18 21:34:33 --> Language Class Initialized
INFO - 2018-06-18 21:34:33 --> Config Class Initialized
INFO - 2018-06-18 21:34:33 --> Loader Class Initialized
DEBUG - 2018-06-18 21:34:33 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-18 21:34:33 --> Helper loaded: url_helper
INFO - 2018-06-18 21:34:33 --> Helper loaded: form_helper
INFO - 2018-06-18 21:34:33 --> Helper loaded: date_helper
INFO - 2018-06-18 21:34:33 --> Helper loaded: util_helper
INFO - 2018-06-18 21:34:33 --> Helper loaded: text_helper
INFO - 2018-06-18 21:34:33 --> Helper loaded: string_helper
INFO - 2018-06-18 21:34:33 --> Database Driver Class Initialized
DEBUG - 2018-06-18 21:34:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 21:34:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 21:34:33 --> Email Class Initialized
INFO - 2018-06-18 21:34:33 --> Controller Class Initialized
DEBUG - 2018-06-18 21:34:33 --> Lessions MX_Controller Initialized
INFO - 2018-06-18 21:34:33 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-18 21:34:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Lessions_model.php
DEBUG - 2018-06-18 21:34:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-18 21:34:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-18 21:34:33 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-18 21:34:33 --> Login MX_Controller Initialized
DEBUG - 2018-06-18 21:34:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-18 21:34:33 --> Final output sent to browser
DEBUG - 2018-06-18 21:34:33 --> Total execution time: 0.4654
INFO - 2018-06-18 21:34:36 --> Config Class Initialized
INFO - 2018-06-18 21:34:36 --> Hooks Class Initialized
DEBUG - 2018-06-18 21:34:36 --> UTF-8 Support Enabled
INFO - 2018-06-18 21:34:36 --> Utf8 Class Initialized
INFO - 2018-06-18 21:34:36 --> URI Class Initialized
INFO - 2018-06-18 21:34:36 --> Router Class Initialized
INFO - 2018-06-18 21:34:36 --> Output Class Initialized
INFO - 2018-06-18 21:34:36 --> Security Class Initialized
DEBUG - 2018-06-18 21:34:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 21:34:36 --> Input Class Initialized
INFO - 2018-06-18 21:34:36 --> Language Class Initialized
INFO - 2018-06-18 21:34:36 --> Language Class Initialized
INFO - 2018-06-18 21:34:36 --> Config Class Initialized
INFO - 2018-06-18 21:34:36 --> Loader Class Initialized
DEBUG - 2018-06-18 21:34:36 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-18 21:34:36 --> Helper loaded: url_helper
INFO - 2018-06-18 21:34:36 --> Helper loaded: form_helper
INFO - 2018-06-18 21:34:36 --> Helper loaded: date_helper
INFO - 2018-06-18 21:34:36 --> Helper loaded: util_helper
INFO - 2018-06-18 21:34:36 --> Helper loaded: text_helper
INFO - 2018-06-18 21:34:36 --> Helper loaded: string_helper
INFO - 2018-06-18 21:34:36 --> Database Driver Class Initialized
DEBUG - 2018-06-18 21:34:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 21:34:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 21:34:36 --> Email Class Initialized
INFO - 2018-06-18 21:34:36 --> Controller Class Initialized
DEBUG - 2018-06-18 21:34:36 --> Admin MX_Controller Initialized
INFO - 2018-06-18 21:34:36 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-18 21:34:36 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-18 21:34:36 --> Login MX_Controller Initialized
DEBUG - 2018-06-18 21:34:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-18 21:34:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-18 21:34:36 --> Final output sent to browser
DEBUG - 2018-06-18 21:34:36 --> Total execution time: 0.4498
INFO - 2018-06-18 21:34:37 --> Config Class Initialized
INFO - 2018-06-18 21:34:37 --> Hooks Class Initialized
DEBUG - 2018-06-18 21:34:37 --> UTF-8 Support Enabled
INFO - 2018-06-18 21:34:37 --> Utf8 Class Initialized
INFO - 2018-06-18 21:34:37 --> URI Class Initialized
INFO - 2018-06-18 21:34:37 --> Router Class Initialized
INFO - 2018-06-18 21:34:37 --> Output Class Initialized
INFO - 2018-06-18 21:34:37 --> Security Class Initialized
DEBUG - 2018-06-18 21:34:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 21:34:37 --> Input Class Initialized
INFO - 2018-06-18 21:34:37 --> Language Class Initialized
INFO - 2018-06-18 21:34:37 --> Language Class Initialized
INFO - 2018-06-18 21:34:37 --> Config Class Initialized
INFO - 2018-06-18 21:34:37 --> Loader Class Initialized
DEBUG - 2018-06-18 21:34:37 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-18 21:34:37 --> Helper loaded: url_helper
INFO - 2018-06-18 21:34:37 --> Helper loaded: form_helper
INFO - 2018-06-18 21:34:37 --> Helper loaded: date_helper
INFO - 2018-06-18 21:34:37 --> Helper loaded: util_helper
INFO - 2018-06-18 21:34:37 --> Helper loaded: text_helper
INFO - 2018-06-18 21:34:37 --> Helper loaded: string_helper
INFO - 2018-06-18 21:34:37 --> Database Driver Class Initialized
DEBUG - 2018-06-18 21:34:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 21:34:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 21:34:37 --> Email Class Initialized
INFO - 2018-06-18 21:34:37 --> Controller Class Initialized
DEBUG - 2018-06-18 21:34:37 --> Lessions MX_Controller Initialized
INFO - 2018-06-18 21:34:37 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-18 21:34:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Lessions_model.php
DEBUG - 2018-06-18 21:34:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-18 21:34:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-18 21:34:37 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-18 21:34:37 --> Login MX_Controller Initialized
DEBUG - 2018-06-18 21:34:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-18 21:34:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-18 21:34:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-18 21:34:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-18 21:34:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-18 21:34:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-18 21:34:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/lessions/create_lession.php
INFO - 2018-06-18 21:34:38 --> Final output sent to browser
DEBUG - 2018-06-18 21:34:38 --> Total execution time: 0.4381
INFO - 2018-06-18 21:34:41 --> Config Class Initialized
INFO - 2018-06-18 21:34:41 --> Hooks Class Initialized
DEBUG - 2018-06-18 21:34:41 --> UTF-8 Support Enabled
INFO - 2018-06-18 21:34:41 --> Utf8 Class Initialized
INFO - 2018-06-18 21:34:41 --> URI Class Initialized
INFO - 2018-06-18 21:34:41 --> Router Class Initialized
INFO - 2018-06-18 21:34:41 --> Output Class Initialized
INFO - 2018-06-18 21:34:41 --> Security Class Initialized
DEBUG - 2018-06-18 21:34:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 21:34:41 --> Input Class Initialized
INFO - 2018-06-18 21:34:41 --> Language Class Initialized
INFO - 2018-06-18 21:34:41 --> Language Class Initialized
INFO - 2018-06-18 21:34:41 --> Config Class Initialized
INFO - 2018-06-18 21:34:41 --> Loader Class Initialized
DEBUG - 2018-06-18 21:34:41 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-18 21:34:41 --> Helper loaded: url_helper
INFO - 2018-06-18 21:34:41 --> Helper loaded: form_helper
INFO - 2018-06-18 21:34:41 --> Helper loaded: date_helper
INFO - 2018-06-18 21:34:41 --> Helper loaded: util_helper
INFO - 2018-06-18 21:34:41 --> Helper loaded: text_helper
INFO - 2018-06-18 21:34:41 --> Helper loaded: string_helper
INFO - 2018-06-18 21:34:41 --> Database Driver Class Initialized
DEBUG - 2018-06-18 21:34:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 21:34:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 21:34:41 --> Email Class Initialized
INFO - 2018-06-18 21:34:41 --> Controller Class Initialized
DEBUG - 2018-06-18 21:34:41 --> Lessions MX_Controller Initialized
INFO - 2018-06-18 21:34:41 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-18 21:34:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Lessions_model.php
DEBUG - 2018-06-18 21:34:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-18 21:34:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-18 21:34:41 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-18 21:34:41 --> Login MX_Controller Initialized
DEBUG - 2018-06-18 21:34:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-18 21:34:44 --> Config Class Initialized
INFO - 2018-06-18 21:34:44 --> Hooks Class Initialized
DEBUG - 2018-06-18 21:34:44 --> UTF-8 Support Enabled
INFO - 2018-06-18 21:34:44 --> Utf8 Class Initialized
INFO - 2018-06-18 21:34:44 --> URI Class Initialized
INFO - 2018-06-18 21:34:44 --> Router Class Initialized
INFO - 2018-06-18 21:34:44 --> Output Class Initialized
INFO - 2018-06-18 21:34:44 --> Security Class Initialized
DEBUG - 2018-06-18 21:34:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 21:34:44 --> Input Class Initialized
INFO - 2018-06-18 21:34:44 --> Language Class Initialized
INFO - 2018-06-18 21:34:44 --> Language Class Initialized
INFO - 2018-06-18 21:34:44 --> Config Class Initialized
INFO - 2018-06-18 21:34:44 --> Loader Class Initialized
DEBUG - 2018-06-18 21:34:44 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-18 21:34:44 --> Helper loaded: url_helper
INFO - 2018-06-18 21:34:44 --> Helper loaded: form_helper
INFO - 2018-06-18 21:34:44 --> Helper loaded: date_helper
INFO - 2018-06-18 21:34:44 --> Helper loaded: util_helper
INFO - 2018-06-18 21:34:44 --> Helper loaded: text_helper
INFO - 2018-06-18 21:34:44 --> Helper loaded: string_helper
INFO - 2018-06-18 21:34:44 --> Database Driver Class Initialized
DEBUG - 2018-06-18 21:34:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 21:34:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 21:34:44 --> Email Class Initialized
INFO - 2018-06-18 21:34:44 --> Controller Class Initialized
DEBUG - 2018-06-18 21:34:44 --> Lessions MX_Controller Initialized
INFO - 2018-06-18 21:34:44 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-18 21:34:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Lessions_model.php
DEBUG - 2018-06-18 21:34:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-18 21:34:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-18 21:34:44 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-18 21:34:44 --> Login MX_Controller Initialized
DEBUG - 2018-06-18 21:34:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-18 21:34:51 --> Config Class Initialized
INFO - 2018-06-18 21:34:51 --> Hooks Class Initialized
DEBUG - 2018-06-18 21:34:51 --> UTF-8 Support Enabled
INFO - 2018-06-18 21:34:51 --> Utf8 Class Initialized
INFO - 2018-06-18 21:34:51 --> URI Class Initialized
INFO - 2018-06-18 21:34:51 --> Router Class Initialized
INFO - 2018-06-18 21:34:51 --> Output Class Initialized
INFO - 2018-06-18 21:34:51 --> Security Class Initialized
DEBUG - 2018-06-18 21:34:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 21:34:51 --> Input Class Initialized
INFO - 2018-06-18 21:34:51 --> Language Class Initialized
INFO - 2018-06-18 21:34:51 --> Language Class Initialized
INFO - 2018-06-18 21:34:51 --> Config Class Initialized
INFO - 2018-06-18 21:34:51 --> Loader Class Initialized
DEBUG - 2018-06-18 21:34:51 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-18 21:34:51 --> Helper loaded: url_helper
INFO - 2018-06-18 21:34:51 --> Helper loaded: form_helper
INFO - 2018-06-18 21:34:51 --> Helper loaded: date_helper
INFO - 2018-06-18 21:34:51 --> Helper loaded: util_helper
INFO - 2018-06-18 21:34:51 --> Helper loaded: text_helper
INFO - 2018-06-18 21:34:51 --> Helper loaded: string_helper
INFO - 2018-06-18 21:34:51 --> Database Driver Class Initialized
DEBUG - 2018-06-18 21:34:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 21:34:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 21:34:51 --> Email Class Initialized
INFO - 2018-06-18 21:34:51 --> Controller Class Initialized
DEBUG - 2018-06-18 21:34:51 --> Lessions MX_Controller Initialized
INFO - 2018-06-18 21:34:51 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-18 21:34:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Lessions_model.php
DEBUG - 2018-06-18 21:34:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-18 21:34:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-18 21:34:51 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-18 21:34:51 --> Login MX_Controller Initialized
DEBUG - 2018-06-18 21:34:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-18 21:34:51 --> Config Class Initialized
INFO - 2018-06-18 21:34:51 --> Hooks Class Initialized
DEBUG - 2018-06-18 21:34:51 --> UTF-8 Support Enabled
INFO - 2018-06-18 21:34:51 --> Utf8 Class Initialized
INFO - 2018-06-18 21:34:51 --> URI Class Initialized
INFO - 2018-06-18 21:34:51 --> Router Class Initialized
INFO - 2018-06-18 21:34:51 --> Output Class Initialized
INFO - 2018-06-18 21:34:51 --> Security Class Initialized
DEBUG - 2018-06-18 21:34:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 21:34:51 --> Input Class Initialized
INFO - 2018-06-18 21:34:51 --> Language Class Initialized
INFO - 2018-06-18 21:34:51 --> Language Class Initialized
INFO - 2018-06-18 21:34:51 --> Config Class Initialized
INFO - 2018-06-18 21:34:51 --> Loader Class Initialized
DEBUG - 2018-06-18 21:34:51 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-18 21:34:51 --> Helper loaded: url_helper
INFO - 2018-06-18 21:34:51 --> Helper loaded: form_helper
INFO - 2018-06-18 21:34:51 --> Helper loaded: date_helper
INFO - 2018-06-18 21:34:51 --> Helper loaded: util_helper
INFO - 2018-06-18 21:34:51 --> Helper loaded: text_helper
INFO - 2018-06-18 21:34:51 --> Helper loaded: string_helper
INFO - 2018-06-18 21:34:51 --> Database Driver Class Initialized
DEBUG - 2018-06-18 21:34:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 21:34:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 21:34:51 --> Email Class Initialized
INFO - 2018-06-18 21:34:51 --> Controller Class Initialized
DEBUG - 2018-06-18 21:34:51 --> Lessions MX_Controller Initialized
INFO - 2018-06-18 21:34:51 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-18 21:34:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Lessions_model.php
DEBUG - 2018-06-18 21:34:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-18 21:34:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-18 21:34:51 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-18 21:34:51 --> Login MX_Controller Initialized
DEBUG - 2018-06-18 21:34:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-18 21:34:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-18 21:34:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-18 21:34:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-18 21:34:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-18 21:34:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-18 21:34:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/lessions/lessions.php
INFO - 2018-06-18 21:34:51 --> Final output sent to browser
DEBUG - 2018-06-18 21:34:51 --> Total execution time: 0.4597
INFO - 2018-06-18 21:34:52 --> Config Class Initialized
INFO - 2018-06-18 21:34:52 --> Hooks Class Initialized
DEBUG - 2018-06-18 21:34:52 --> UTF-8 Support Enabled
INFO - 2018-06-18 21:34:52 --> Utf8 Class Initialized
INFO - 2018-06-18 21:34:52 --> URI Class Initialized
INFO - 2018-06-18 21:34:52 --> Router Class Initialized
INFO - 2018-06-18 21:34:52 --> Output Class Initialized
INFO - 2018-06-18 21:34:52 --> Security Class Initialized
DEBUG - 2018-06-18 21:34:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 21:34:52 --> Input Class Initialized
INFO - 2018-06-18 21:34:52 --> Language Class Initialized
INFO - 2018-06-18 21:34:52 --> Language Class Initialized
INFO - 2018-06-18 21:34:52 --> Config Class Initialized
INFO - 2018-06-18 21:34:52 --> Loader Class Initialized
DEBUG - 2018-06-18 21:34:52 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-18 21:34:52 --> Helper loaded: url_helper
INFO - 2018-06-18 21:34:52 --> Helper loaded: form_helper
INFO - 2018-06-18 21:34:52 --> Helper loaded: date_helper
INFO - 2018-06-18 21:34:52 --> Helper loaded: util_helper
INFO - 2018-06-18 21:34:52 --> Helper loaded: text_helper
INFO - 2018-06-18 21:34:52 --> Helper loaded: string_helper
INFO - 2018-06-18 21:34:52 --> Database Driver Class Initialized
DEBUG - 2018-06-18 21:34:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 21:34:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 21:34:52 --> Email Class Initialized
INFO - 2018-06-18 21:34:52 --> Controller Class Initialized
DEBUG - 2018-06-18 21:34:52 --> Lessions MX_Controller Initialized
INFO - 2018-06-18 21:34:52 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-18 21:34:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Lessions_model.php
DEBUG - 2018-06-18 21:34:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-18 21:34:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-18 21:34:52 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-18 21:34:52 --> Login MX_Controller Initialized
DEBUG - 2018-06-18 21:34:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-18 21:34:52 --> Final output sent to browser
DEBUG - 2018-06-18 21:34:52 --> Total execution time: 0.4729
INFO - 2018-06-18 21:34:55 --> Config Class Initialized
INFO - 2018-06-18 21:34:55 --> Hooks Class Initialized
DEBUG - 2018-06-18 21:34:55 --> UTF-8 Support Enabled
INFO - 2018-06-18 21:34:55 --> Utf8 Class Initialized
INFO - 2018-06-18 21:34:55 --> URI Class Initialized
INFO - 2018-06-18 21:34:55 --> Router Class Initialized
INFO - 2018-06-18 21:34:55 --> Output Class Initialized
INFO - 2018-06-18 21:34:55 --> Security Class Initialized
DEBUG - 2018-06-18 21:34:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 21:34:55 --> Input Class Initialized
INFO - 2018-06-18 21:34:55 --> Language Class Initialized
INFO - 2018-06-18 21:34:55 --> Language Class Initialized
INFO - 2018-06-18 21:34:55 --> Config Class Initialized
INFO - 2018-06-18 21:34:55 --> Loader Class Initialized
DEBUG - 2018-06-18 21:34:55 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-18 21:34:55 --> Helper loaded: url_helper
INFO - 2018-06-18 21:34:55 --> Helper loaded: form_helper
INFO - 2018-06-18 21:34:55 --> Helper loaded: date_helper
INFO - 2018-06-18 21:34:55 --> Helper loaded: util_helper
INFO - 2018-06-18 21:34:55 --> Helper loaded: text_helper
INFO - 2018-06-18 21:34:55 --> Helper loaded: string_helper
INFO - 2018-06-18 21:34:55 --> Database Driver Class Initialized
DEBUG - 2018-06-18 21:34:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 21:34:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 21:34:55 --> Email Class Initialized
INFO - 2018-06-18 21:34:55 --> Controller Class Initialized
DEBUG - 2018-06-18 21:34:55 --> Lessions MX_Controller Initialized
INFO - 2018-06-18 21:34:55 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-18 21:34:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Lessions_model.php
DEBUG - 2018-06-18 21:34:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-18 21:34:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-18 21:34:55 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-18 21:34:55 --> Login MX_Controller Initialized
DEBUG - 2018-06-18 21:34:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-18 21:34:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-18 21:34:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-18 21:34:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-18 21:34:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-18 21:34:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-18 21:34:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/lessions/create_lession.php
INFO - 2018-06-18 21:34:56 --> Final output sent to browser
DEBUG - 2018-06-18 21:34:56 --> Total execution time: 0.4347
INFO - 2018-06-18 21:34:59 --> Config Class Initialized
INFO - 2018-06-18 21:34:59 --> Hooks Class Initialized
DEBUG - 2018-06-18 21:34:59 --> UTF-8 Support Enabled
INFO - 2018-06-18 21:34:59 --> Utf8 Class Initialized
INFO - 2018-06-18 21:35:00 --> URI Class Initialized
INFO - 2018-06-18 21:35:00 --> Router Class Initialized
INFO - 2018-06-18 21:35:00 --> Output Class Initialized
INFO - 2018-06-18 21:35:00 --> Security Class Initialized
DEBUG - 2018-06-18 21:35:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 21:35:00 --> Input Class Initialized
INFO - 2018-06-18 21:35:00 --> Language Class Initialized
INFO - 2018-06-18 21:35:00 --> Language Class Initialized
INFO - 2018-06-18 21:35:00 --> Config Class Initialized
INFO - 2018-06-18 21:35:00 --> Loader Class Initialized
DEBUG - 2018-06-18 21:35:00 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-18 21:35:00 --> Helper loaded: url_helper
INFO - 2018-06-18 21:35:00 --> Helper loaded: form_helper
INFO - 2018-06-18 21:35:00 --> Helper loaded: date_helper
INFO - 2018-06-18 21:35:00 --> Helper loaded: util_helper
INFO - 2018-06-18 21:35:00 --> Helper loaded: text_helper
INFO - 2018-06-18 21:35:00 --> Helper loaded: string_helper
INFO - 2018-06-18 21:35:00 --> Database Driver Class Initialized
DEBUG - 2018-06-18 21:35:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 21:35:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 21:35:00 --> Email Class Initialized
INFO - 2018-06-18 21:35:00 --> Controller Class Initialized
DEBUG - 2018-06-18 21:35:00 --> Lessions MX_Controller Initialized
INFO - 2018-06-18 21:35:00 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-18 21:35:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Lessions_model.php
DEBUG - 2018-06-18 21:35:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-18 21:35:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-18 21:35:00 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-18 21:35:00 --> Login MX_Controller Initialized
DEBUG - 2018-06-18 21:35:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-18 21:35:02 --> Config Class Initialized
INFO - 2018-06-18 21:35:02 --> Hooks Class Initialized
DEBUG - 2018-06-18 21:35:02 --> UTF-8 Support Enabled
INFO - 2018-06-18 21:35:02 --> Utf8 Class Initialized
INFO - 2018-06-18 21:35:02 --> URI Class Initialized
INFO - 2018-06-18 21:35:02 --> Router Class Initialized
INFO - 2018-06-18 21:35:02 --> Output Class Initialized
INFO - 2018-06-18 21:35:02 --> Security Class Initialized
DEBUG - 2018-06-18 21:35:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 21:35:02 --> Input Class Initialized
INFO - 2018-06-18 21:35:02 --> Language Class Initialized
INFO - 2018-06-18 21:35:02 --> Language Class Initialized
INFO - 2018-06-18 21:35:02 --> Config Class Initialized
INFO - 2018-06-18 21:35:02 --> Loader Class Initialized
DEBUG - 2018-06-18 21:35:02 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-18 21:35:02 --> Helper loaded: url_helper
INFO - 2018-06-18 21:35:02 --> Helper loaded: form_helper
INFO - 2018-06-18 21:35:02 --> Helper loaded: date_helper
INFO - 2018-06-18 21:35:02 --> Helper loaded: util_helper
INFO - 2018-06-18 21:35:02 --> Helper loaded: text_helper
INFO - 2018-06-18 21:35:02 --> Helper loaded: string_helper
INFO - 2018-06-18 21:35:02 --> Database Driver Class Initialized
DEBUG - 2018-06-18 21:35:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 21:35:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 21:35:02 --> Email Class Initialized
INFO - 2018-06-18 21:35:02 --> Controller Class Initialized
DEBUG - 2018-06-18 21:35:02 --> Lessions MX_Controller Initialized
INFO - 2018-06-18 21:35:02 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-18 21:35:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Lessions_model.php
DEBUG - 2018-06-18 21:35:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-18 21:35:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-18 21:35:02 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-18 21:35:02 --> Login MX_Controller Initialized
DEBUG - 2018-06-18 21:35:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-18 21:35:02 --> Config Class Initialized
INFO - 2018-06-18 21:35:02 --> Hooks Class Initialized
DEBUG - 2018-06-18 21:35:02 --> UTF-8 Support Enabled
INFO - 2018-06-18 21:35:02 --> Utf8 Class Initialized
INFO - 2018-06-18 21:35:02 --> URI Class Initialized
INFO - 2018-06-18 21:35:02 --> Router Class Initialized
INFO - 2018-06-18 21:35:02 --> Output Class Initialized
INFO - 2018-06-18 21:35:02 --> Security Class Initialized
DEBUG - 2018-06-18 21:35:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 21:35:02 --> Input Class Initialized
INFO - 2018-06-18 21:35:02 --> Language Class Initialized
INFO - 2018-06-18 21:35:02 --> Language Class Initialized
INFO - 2018-06-18 21:35:02 --> Config Class Initialized
INFO - 2018-06-18 21:35:02 --> Loader Class Initialized
DEBUG - 2018-06-18 21:35:02 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-18 21:35:02 --> Helper loaded: url_helper
INFO - 2018-06-18 21:35:02 --> Helper loaded: form_helper
INFO - 2018-06-18 21:35:02 --> Helper loaded: date_helper
INFO - 2018-06-18 21:35:02 --> Helper loaded: util_helper
INFO - 2018-06-18 21:35:02 --> Helper loaded: text_helper
INFO - 2018-06-18 21:35:02 --> Helper loaded: string_helper
INFO - 2018-06-18 21:35:02 --> Database Driver Class Initialized
DEBUG - 2018-06-18 21:35:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 21:35:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 21:35:02 --> Email Class Initialized
INFO - 2018-06-18 21:35:02 --> Controller Class Initialized
DEBUG - 2018-06-18 21:35:02 --> Lessions MX_Controller Initialized
INFO - 2018-06-18 21:35:02 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-18 21:35:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Lessions_model.php
DEBUG - 2018-06-18 21:35:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-18 21:35:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-18 21:35:03 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-18 21:35:03 --> Login MX_Controller Initialized
DEBUG - 2018-06-18 21:35:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-18 21:35:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-18 21:35:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-18 21:35:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-18 21:35:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-18 21:35:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-18 21:35:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/lessions/lessions.php
INFO - 2018-06-18 21:35:03 --> Final output sent to browser
DEBUG - 2018-06-18 21:35:03 --> Total execution time: 0.4853
INFO - 2018-06-18 21:35:03 --> Config Class Initialized
INFO - 2018-06-18 21:35:03 --> Hooks Class Initialized
DEBUG - 2018-06-18 21:35:03 --> UTF-8 Support Enabled
INFO - 2018-06-18 21:35:03 --> Utf8 Class Initialized
INFO - 2018-06-18 21:35:03 --> URI Class Initialized
INFO - 2018-06-18 21:35:03 --> Router Class Initialized
INFO - 2018-06-18 21:35:03 --> Output Class Initialized
INFO - 2018-06-18 21:35:03 --> Security Class Initialized
DEBUG - 2018-06-18 21:35:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 21:35:03 --> Input Class Initialized
INFO - 2018-06-18 21:35:03 --> Language Class Initialized
INFO - 2018-06-18 21:35:03 --> Language Class Initialized
INFO - 2018-06-18 21:35:03 --> Config Class Initialized
INFO - 2018-06-18 21:35:03 --> Loader Class Initialized
DEBUG - 2018-06-18 21:35:03 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-18 21:35:03 --> Helper loaded: url_helper
INFO - 2018-06-18 21:35:03 --> Helper loaded: form_helper
INFO - 2018-06-18 21:35:03 --> Helper loaded: date_helper
INFO - 2018-06-18 21:35:03 --> Helper loaded: util_helper
INFO - 2018-06-18 21:35:03 --> Helper loaded: text_helper
INFO - 2018-06-18 21:35:03 --> Helper loaded: string_helper
INFO - 2018-06-18 21:35:03 --> Database Driver Class Initialized
DEBUG - 2018-06-18 21:35:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 21:35:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 21:35:03 --> Email Class Initialized
INFO - 2018-06-18 21:35:03 --> Controller Class Initialized
DEBUG - 2018-06-18 21:35:03 --> Lessions MX_Controller Initialized
INFO - 2018-06-18 21:35:03 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-18 21:35:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Lessions_model.php
DEBUG - 2018-06-18 21:35:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-18 21:35:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-18 21:35:03 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-18 21:35:03 --> Login MX_Controller Initialized
DEBUG - 2018-06-18 21:35:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-18 21:35:03 --> Final output sent to browser
DEBUG - 2018-06-18 21:35:03 --> Total execution time: 0.4649
INFO - 2018-06-18 21:35:06 --> Config Class Initialized
INFO - 2018-06-18 21:35:06 --> Hooks Class Initialized
DEBUG - 2018-06-18 21:35:06 --> UTF-8 Support Enabled
INFO - 2018-06-18 21:35:06 --> Utf8 Class Initialized
INFO - 2018-06-18 21:35:06 --> URI Class Initialized
INFO - 2018-06-18 21:35:06 --> Router Class Initialized
INFO - 2018-06-18 21:35:06 --> Output Class Initialized
INFO - 2018-06-18 21:35:06 --> Security Class Initialized
DEBUG - 2018-06-18 21:35:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 21:35:06 --> Input Class Initialized
INFO - 2018-06-18 21:35:06 --> Language Class Initialized
INFO - 2018-06-18 21:35:06 --> Language Class Initialized
INFO - 2018-06-18 21:35:06 --> Config Class Initialized
INFO - 2018-06-18 21:35:06 --> Loader Class Initialized
DEBUG - 2018-06-18 21:35:06 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-18 21:35:06 --> Helper loaded: url_helper
INFO - 2018-06-18 21:35:06 --> Helper loaded: form_helper
INFO - 2018-06-18 21:35:06 --> Helper loaded: date_helper
INFO - 2018-06-18 21:35:06 --> Helper loaded: util_helper
INFO - 2018-06-18 21:35:06 --> Helper loaded: text_helper
INFO - 2018-06-18 21:35:06 --> Helper loaded: string_helper
INFO - 2018-06-18 21:35:06 --> Database Driver Class Initialized
DEBUG - 2018-06-18 21:35:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 21:35:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 21:35:06 --> Email Class Initialized
INFO - 2018-06-18 21:35:06 --> Controller Class Initialized
DEBUG - 2018-06-18 21:35:06 --> Lessions MX_Controller Initialized
INFO - 2018-06-18 21:35:06 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-18 21:35:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Lessions_model.php
DEBUG - 2018-06-18 21:35:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-18 21:35:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-18 21:35:06 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-18 21:35:06 --> Login MX_Controller Initialized
DEBUG - 2018-06-18 21:35:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-18 21:35:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-18 21:35:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-18 21:35:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-18 21:35:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-18 21:35:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-18 21:35:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/lessions/create_lession.php
INFO - 2018-06-18 21:35:06 --> Final output sent to browser
DEBUG - 2018-06-18 21:35:07 --> Total execution time: 0.4659
INFO - 2018-06-18 21:35:16 --> Config Class Initialized
INFO - 2018-06-18 21:35:16 --> Hooks Class Initialized
DEBUG - 2018-06-18 21:35:16 --> UTF-8 Support Enabled
INFO - 2018-06-18 21:35:16 --> Utf8 Class Initialized
INFO - 2018-06-18 21:35:16 --> URI Class Initialized
INFO - 2018-06-18 21:35:16 --> Router Class Initialized
INFO - 2018-06-18 21:35:16 --> Output Class Initialized
INFO - 2018-06-18 21:35:16 --> Security Class Initialized
DEBUG - 2018-06-18 21:35:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 21:35:16 --> Input Class Initialized
INFO - 2018-06-18 21:35:16 --> Language Class Initialized
INFO - 2018-06-18 21:35:16 --> Language Class Initialized
INFO - 2018-06-18 21:35:16 --> Config Class Initialized
INFO - 2018-06-18 21:35:16 --> Loader Class Initialized
DEBUG - 2018-06-18 21:35:16 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-18 21:35:16 --> Helper loaded: url_helper
INFO - 2018-06-18 21:35:16 --> Helper loaded: form_helper
INFO - 2018-06-18 21:35:16 --> Helper loaded: date_helper
INFO - 2018-06-18 21:35:16 --> Helper loaded: util_helper
INFO - 2018-06-18 21:35:16 --> Helper loaded: text_helper
INFO - 2018-06-18 21:35:16 --> Helper loaded: string_helper
INFO - 2018-06-18 21:35:16 --> Database Driver Class Initialized
DEBUG - 2018-06-18 21:35:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 21:35:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 21:35:16 --> Email Class Initialized
INFO - 2018-06-18 21:35:16 --> Controller Class Initialized
DEBUG - 2018-06-18 21:35:16 --> Lessions MX_Controller Initialized
INFO - 2018-06-18 21:35:16 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-18 21:35:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Lessions_model.php
DEBUG - 2018-06-18 21:35:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-18 21:35:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-18 21:35:16 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-18 21:35:16 --> Login MX_Controller Initialized
DEBUG - 2018-06-18 21:35:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-18 21:35:18 --> Config Class Initialized
INFO - 2018-06-18 21:35:18 --> Hooks Class Initialized
DEBUG - 2018-06-18 21:35:18 --> UTF-8 Support Enabled
INFO - 2018-06-18 21:35:18 --> Utf8 Class Initialized
INFO - 2018-06-18 21:35:18 --> URI Class Initialized
INFO - 2018-06-18 21:35:18 --> Router Class Initialized
INFO - 2018-06-18 21:35:18 --> Output Class Initialized
INFO - 2018-06-18 21:35:18 --> Security Class Initialized
DEBUG - 2018-06-18 21:35:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 21:35:18 --> Input Class Initialized
INFO - 2018-06-18 21:35:18 --> Language Class Initialized
INFO - 2018-06-18 21:35:18 --> Language Class Initialized
INFO - 2018-06-18 21:35:18 --> Config Class Initialized
INFO - 2018-06-18 21:35:18 --> Loader Class Initialized
DEBUG - 2018-06-18 21:35:18 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-18 21:35:18 --> Helper loaded: url_helper
INFO - 2018-06-18 21:35:18 --> Helper loaded: form_helper
INFO - 2018-06-18 21:35:18 --> Helper loaded: date_helper
INFO - 2018-06-18 21:35:18 --> Helper loaded: util_helper
INFO - 2018-06-18 21:35:18 --> Helper loaded: text_helper
INFO - 2018-06-18 21:35:18 --> Helper loaded: string_helper
INFO - 2018-06-18 21:35:18 --> Database Driver Class Initialized
DEBUG - 2018-06-18 21:35:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 21:35:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 21:35:18 --> Email Class Initialized
INFO - 2018-06-18 21:35:18 --> Controller Class Initialized
DEBUG - 2018-06-18 21:35:19 --> Lessions MX_Controller Initialized
INFO - 2018-06-18 21:35:19 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-18 21:35:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Lessions_model.php
DEBUG - 2018-06-18 21:35:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-18 21:35:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-18 21:35:19 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-18 21:35:19 --> Login MX_Controller Initialized
DEBUG - 2018-06-18 21:35:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-18 21:35:19 --> Config Class Initialized
INFO - 2018-06-18 21:35:19 --> Hooks Class Initialized
DEBUG - 2018-06-18 21:35:19 --> UTF-8 Support Enabled
INFO - 2018-06-18 21:35:19 --> Utf8 Class Initialized
INFO - 2018-06-18 21:35:19 --> URI Class Initialized
INFO - 2018-06-18 21:35:19 --> Router Class Initialized
INFO - 2018-06-18 21:35:19 --> Output Class Initialized
INFO - 2018-06-18 21:35:19 --> Security Class Initialized
DEBUG - 2018-06-18 21:35:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 21:35:19 --> Input Class Initialized
INFO - 2018-06-18 21:35:19 --> Language Class Initialized
INFO - 2018-06-18 21:35:19 --> Language Class Initialized
INFO - 2018-06-18 21:35:19 --> Config Class Initialized
INFO - 2018-06-18 21:35:19 --> Loader Class Initialized
DEBUG - 2018-06-18 21:35:19 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-18 21:35:19 --> Helper loaded: url_helper
INFO - 2018-06-18 21:35:19 --> Helper loaded: form_helper
INFO - 2018-06-18 21:35:19 --> Helper loaded: date_helper
INFO - 2018-06-18 21:35:19 --> Helper loaded: util_helper
INFO - 2018-06-18 21:35:19 --> Helper loaded: text_helper
INFO - 2018-06-18 21:35:19 --> Helper loaded: string_helper
INFO - 2018-06-18 21:35:19 --> Database Driver Class Initialized
DEBUG - 2018-06-18 21:35:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 21:35:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 21:35:19 --> Email Class Initialized
INFO - 2018-06-18 21:35:19 --> Controller Class Initialized
DEBUG - 2018-06-18 21:35:19 --> Lessions MX_Controller Initialized
INFO - 2018-06-18 21:35:19 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-18 21:35:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Lessions_model.php
DEBUG - 2018-06-18 21:35:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-18 21:35:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-18 21:35:19 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-18 21:35:19 --> Login MX_Controller Initialized
DEBUG - 2018-06-18 21:35:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-18 21:35:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-18 21:35:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-18 21:35:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-18 21:35:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-18 21:35:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-18 21:35:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/lessions/lessions.php
INFO - 2018-06-18 21:35:19 --> Final output sent to browser
DEBUG - 2018-06-18 21:35:19 --> Total execution time: 0.4714
INFO - 2018-06-18 21:35:20 --> Config Class Initialized
INFO - 2018-06-18 21:35:20 --> Hooks Class Initialized
DEBUG - 2018-06-18 21:35:20 --> UTF-8 Support Enabled
INFO - 2018-06-18 21:35:20 --> Utf8 Class Initialized
INFO - 2018-06-18 21:35:20 --> URI Class Initialized
INFO - 2018-06-18 21:35:20 --> Router Class Initialized
INFO - 2018-06-18 21:35:20 --> Output Class Initialized
INFO - 2018-06-18 21:35:20 --> Security Class Initialized
DEBUG - 2018-06-18 21:35:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 21:35:20 --> Input Class Initialized
INFO - 2018-06-18 21:35:20 --> Language Class Initialized
INFO - 2018-06-18 21:35:20 --> Language Class Initialized
INFO - 2018-06-18 21:35:20 --> Config Class Initialized
INFO - 2018-06-18 21:35:20 --> Loader Class Initialized
DEBUG - 2018-06-18 21:35:20 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-18 21:35:20 --> Helper loaded: url_helper
INFO - 2018-06-18 21:35:20 --> Helper loaded: form_helper
INFO - 2018-06-18 21:35:20 --> Helper loaded: date_helper
INFO - 2018-06-18 21:35:20 --> Helper loaded: util_helper
INFO - 2018-06-18 21:35:20 --> Helper loaded: text_helper
INFO - 2018-06-18 21:35:20 --> Helper loaded: string_helper
INFO - 2018-06-18 21:35:20 --> Database Driver Class Initialized
DEBUG - 2018-06-18 21:35:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 21:35:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 21:35:20 --> Email Class Initialized
INFO - 2018-06-18 21:35:20 --> Controller Class Initialized
DEBUG - 2018-06-18 21:35:20 --> Lessions MX_Controller Initialized
INFO - 2018-06-18 21:35:20 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-18 21:35:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Lessions_model.php
DEBUG - 2018-06-18 21:35:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-18 21:35:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-18 21:35:20 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-18 21:35:20 --> Login MX_Controller Initialized
DEBUG - 2018-06-18 21:35:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-18 21:35:20 --> Final output sent to browser
DEBUG - 2018-06-18 21:35:20 --> Total execution time: 0.5171
INFO - 2018-06-18 21:35:26 --> Config Class Initialized
INFO - 2018-06-18 21:35:26 --> Hooks Class Initialized
DEBUG - 2018-06-18 21:35:26 --> UTF-8 Support Enabled
INFO - 2018-06-18 21:35:26 --> Utf8 Class Initialized
INFO - 2018-06-18 21:35:26 --> URI Class Initialized
INFO - 2018-06-18 21:35:26 --> Router Class Initialized
INFO - 2018-06-18 21:35:26 --> Output Class Initialized
INFO - 2018-06-18 21:35:26 --> Security Class Initialized
DEBUG - 2018-06-18 21:35:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 21:35:26 --> Input Class Initialized
INFO - 2018-06-18 21:35:26 --> Language Class Initialized
INFO - 2018-06-18 21:35:26 --> Language Class Initialized
INFO - 2018-06-18 21:35:26 --> Config Class Initialized
INFO - 2018-06-18 21:35:26 --> Loader Class Initialized
DEBUG - 2018-06-18 21:35:26 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-18 21:35:26 --> Helper loaded: url_helper
INFO - 2018-06-18 21:35:26 --> Helper loaded: form_helper
INFO - 2018-06-18 21:35:26 --> Helper loaded: date_helper
INFO - 2018-06-18 21:35:26 --> Helper loaded: util_helper
INFO - 2018-06-18 21:35:26 --> Helper loaded: text_helper
INFO - 2018-06-18 21:35:26 --> Helper loaded: string_helper
INFO - 2018-06-18 21:35:26 --> Database Driver Class Initialized
DEBUG - 2018-06-18 21:35:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 21:35:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 21:35:26 --> Email Class Initialized
INFO - 2018-06-18 21:35:26 --> Controller Class Initialized
DEBUG - 2018-06-18 21:35:26 --> videos MX_Controller Initialized
INFO - 2018-06-18 21:35:26 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-18 21:35:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-06-18 21:35:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-18 21:35:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-18 21:35:26 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-18 21:35:26 --> Login MX_Controller Initialized
DEBUG - 2018-06-18 21:35:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-18 21:35:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-18 21:35:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-18 21:35:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-18 21:35:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-18 21:35:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-18 21:35:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/videos/videos.php
INFO - 2018-06-18 21:35:26 --> Final output sent to browser
DEBUG - 2018-06-18 21:35:26 --> Total execution time: 0.4586
INFO - 2018-06-18 21:35:27 --> Config Class Initialized
INFO - 2018-06-18 21:35:27 --> Hooks Class Initialized
DEBUG - 2018-06-18 21:35:27 --> UTF-8 Support Enabled
INFO - 2018-06-18 21:35:27 --> Utf8 Class Initialized
INFO - 2018-06-18 21:35:27 --> URI Class Initialized
INFO - 2018-06-18 21:35:27 --> Router Class Initialized
INFO - 2018-06-18 21:35:27 --> Output Class Initialized
INFO - 2018-06-18 21:35:27 --> Security Class Initialized
DEBUG - 2018-06-18 21:35:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 21:35:27 --> Input Class Initialized
INFO - 2018-06-18 21:35:27 --> Language Class Initialized
INFO - 2018-06-18 21:35:27 --> Language Class Initialized
INFO - 2018-06-18 21:35:27 --> Config Class Initialized
INFO - 2018-06-18 21:35:27 --> Loader Class Initialized
DEBUG - 2018-06-18 21:35:27 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-18 21:35:27 --> Helper loaded: url_helper
INFO - 2018-06-18 21:35:27 --> Helper loaded: form_helper
INFO - 2018-06-18 21:35:27 --> Helper loaded: date_helper
INFO - 2018-06-18 21:35:27 --> Helper loaded: util_helper
INFO - 2018-06-18 21:35:27 --> Helper loaded: text_helper
INFO - 2018-06-18 21:35:27 --> Helper loaded: string_helper
INFO - 2018-06-18 21:35:27 --> Database Driver Class Initialized
DEBUG - 2018-06-18 21:35:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 21:35:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 21:35:27 --> Email Class Initialized
INFO - 2018-06-18 21:35:27 --> Controller Class Initialized
DEBUG - 2018-06-18 21:35:27 --> videos MX_Controller Initialized
INFO - 2018-06-18 21:35:27 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-18 21:35:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-06-18 21:35:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-18 21:35:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-18 21:35:27 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-18 21:35:27 --> Login MX_Controller Initialized
DEBUG - 2018-06-18 21:35:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-18 21:35:27 --> Final output sent to browser
DEBUG - 2018-06-18 21:35:27 --> Total execution time: 0.5180
INFO - 2018-06-18 21:35:28 --> Config Class Initialized
INFO - 2018-06-18 21:35:28 --> Hooks Class Initialized
DEBUG - 2018-06-18 21:35:28 --> UTF-8 Support Enabled
INFO - 2018-06-18 21:35:28 --> Utf8 Class Initialized
INFO - 2018-06-18 21:35:28 --> URI Class Initialized
INFO - 2018-06-18 21:35:28 --> Router Class Initialized
INFO - 2018-06-18 21:35:28 --> Output Class Initialized
INFO - 2018-06-18 21:35:28 --> Security Class Initialized
DEBUG - 2018-06-18 21:35:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 21:35:28 --> Input Class Initialized
INFO - 2018-06-18 21:35:28 --> Language Class Initialized
INFO - 2018-06-18 21:35:28 --> Language Class Initialized
INFO - 2018-06-18 21:35:28 --> Config Class Initialized
INFO - 2018-06-18 21:35:28 --> Loader Class Initialized
DEBUG - 2018-06-18 21:35:28 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-18 21:35:28 --> Helper loaded: url_helper
INFO - 2018-06-18 21:35:28 --> Helper loaded: form_helper
INFO - 2018-06-18 21:35:28 --> Helper loaded: date_helper
INFO - 2018-06-18 21:35:28 --> Helper loaded: util_helper
INFO - 2018-06-18 21:35:28 --> Helper loaded: text_helper
INFO - 2018-06-18 21:35:28 --> Helper loaded: string_helper
INFO - 2018-06-18 21:35:28 --> Database Driver Class Initialized
DEBUG - 2018-06-18 21:35:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 21:35:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 21:35:28 --> Email Class Initialized
INFO - 2018-06-18 21:35:28 --> Controller Class Initialized
DEBUG - 2018-06-18 21:35:28 --> videos MX_Controller Initialized
INFO - 2018-06-18 21:35:28 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-18 21:35:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-06-18 21:35:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-18 21:35:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-18 21:35:28 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-18 21:35:28 --> Login MX_Controller Initialized
DEBUG - 2018-06-18 21:35:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-18 21:35:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-18 21:35:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-18 21:35:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-18 21:35:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-18 21:35:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-18 21:35:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/videos/create_video.php
INFO - 2018-06-18 21:35:28 --> Final output sent to browser
DEBUG - 2018-06-18 21:35:28 --> Total execution time: 0.4470
INFO - 2018-06-18 21:35:28 --> Config Class Initialized
INFO - 2018-06-18 21:35:28 --> Hooks Class Initialized
DEBUG - 2018-06-18 21:35:28 --> UTF-8 Support Enabled
INFO - 2018-06-18 21:35:28 --> Utf8 Class Initialized
INFO - 2018-06-18 21:35:28 --> URI Class Initialized
INFO - 2018-06-18 21:35:28 --> Router Class Initialized
INFO - 2018-06-18 21:35:28 --> Output Class Initialized
INFO - 2018-06-18 21:35:29 --> Security Class Initialized
DEBUG - 2018-06-18 21:35:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 21:35:29 --> Input Class Initialized
INFO - 2018-06-18 21:35:29 --> Language Class Initialized
ERROR - 2018-06-18 21:35:29 --> 404 Page Not Found: /index
INFO - 2018-06-18 21:35:32 --> Config Class Initialized
INFO - 2018-06-18 21:35:32 --> Hooks Class Initialized
DEBUG - 2018-06-18 21:35:32 --> UTF-8 Support Enabled
INFO - 2018-06-18 21:35:32 --> Utf8 Class Initialized
INFO - 2018-06-18 21:35:32 --> URI Class Initialized
INFO - 2018-06-18 21:35:32 --> Router Class Initialized
INFO - 2018-06-18 21:35:32 --> Output Class Initialized
INFO - 2018-06-18 21:35:32 --> Security Class Initialized
DEBUG - 2018-06-18 21:35:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 21:35:32 --> Input Class Initialized
INFO - 2018-06-18 21:35:32 --> Language Class Initialized
INFO - 2018-06-18 21:35:32 --> Language Class Initialized
INFO - 2018-06-18 21:35:32 --> Config Class Initialized
INFO - 2018-06-18 21:35:32 --> Loader Class Initialized
DEBUG - 2018-06-18 21:35:32 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-18 21:35:32 --> Helper loaded: url_helper
INFO - 2018-06-18 21:35:32 --> Helper loaded: form_helper
INFO - 2018-06-18 21:35:32 --> Helper loaded: date_helper
INFO - 2018-06-18 21:35:32 --> Helper loaded: util_helper
INFO - 2018-06-18 21:35:32 --> Helper loaded: text_helper
INFO - 2018-06-18 21:35:32 --> Helper loaded: string_helper
INFO - 2018-06-18 21:35:32 --> Database Driver Class Initialized
DEBUG - 2018-06-18 21:35:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 21:35:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 21:35:32 --> Email Class Initialized
INFO - 2018-06-18 21:35:32 --> Controller Class Initialized
DEBUG - 2018-06-18 21:35:32 --> videos MX_Controller Initialized
INFO - 2018-06-18 21:35:32 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-18 21:35:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-06-18 21:35:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-18 21:35:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-18 21:35:32 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-18 21:35:32 --> Login MX_Controller Initialized
DEBUG - 2018-06-18 21:35:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-18 21:57:45 --> Config Class Initialized
INFO - 2018-06-18 21:57:45 --> Hooks Class Initialized
DEBUG - 2018-06-18 21:57:45 --> UTF-8 Support Enabled
INFO - 2018-06-18 21:57:45 --> Utf8 Class Initialized
INFO - 2018-06-18 21:57:45 --> URI Class Initialized
INFO - 2018-06-18 21:57:45 --> Router Class Initialized
INFO - 2018-06-18 21:57:45 --> Output Class Initialized
INFO - 2018-06-18 21:57:45 --> Security Class Initialized
DEBUG - 2018-06-18 21:57:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 21:57:45 --> Input Class Initialized
INFO - 2018-06-18 21:57:45 --> Language Class Initialized
INFO - 2018-06-18 21:57:45 --> Language Class Initialized
INFO - 2018-06-18 21:57:45 --> Config Class Initialized
INFO - 2018-06-18 21:57:45 --> Loader Class Initialized
DEBUG - 2018-06-18 21:57:45 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-18 21:57:45 --> Helper loaded: url_helper
INFO - 2018-06-18 21:57:45 --> Helper loaded: form_helper
INFO - 2018-06-18 21:57:45 --> Helper loaded: date_helper
INFO - 2018-06-18 21:57:45 --> Helper loaded: util_helper
INFO - 2018-06-18 21:57:45 --> Helper loaded: text_helper
INFO - 2018-06-18 21:57:45 --> Helper loaded: string_helper
INFO - 2018-06-18 21:57:45 --> Database Driver Class Initialized
DEBUG - 2018-06-18 21:57:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 21:57:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 21:57:45 --> Email Class Initialized
INFO - 2018-06-18 21:57:45 --> Controller Class Initialized
DEBUG - 2018-06-18 21:57:45 --> videos MX_Controller Initialized
INFO - 2018-06-18 21:57:45 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-18 21:57:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-06-18 21:57:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-18 21:57:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-18 21:57:45 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-18 21:57:45 --> Login MX_Controller Initialized
DEBUG - 2018-06-18 21:57:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-18 21:57:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-18 21:57:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-18 21:57:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-18 21:57:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-18 21:57:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-18 21:57:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/videos/videos.php
INFO - 2018-06-18 21:57:45 --> Final output sent to browser
DEBUG - 2018-06-18 21:57:45 --> Total execution time: 0.5030
INFO - 2018-06-18 21:57:46 --> Config Class Initialized
INFO - 2018-06-18 21:57:46 --> Hooks Class Initialized
DEBUG - 2018-06-18 21:57:46 --> UTF-8 Support Enabled
INFO - 2018-06-18 21:57:46 --> Utf8 Class Initialized
INFO - 2018-06-18 21:57:46 --> URI Class Initialized
INFO - 2018-06-18 21:57:46 --> Router Class Initialized
INFO - 2018-06-18 21:57:46 --> Output Class Initialized
INFO - 2018-06-18 21:57:46 --> Security Class Initialized
DEBUG - 2018-06-18 21:57:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 21:57:46 --> Input Class Initialized
INFO - 2018-06-18 21:57:46 --> Language Class Initialized
INFO - 2018-06-18 21:57:46 --> Language Class Initialized
INFO - 2018-06-18 21:57:46 --> Config Class Initialized
INFO - 2018-06-18 21:57:46 --> Loader Class Initialized
DEBUG - 2018-06-18 21:57:46 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-18 21:57:46 --> Helper loaded: url_helper
INFO - 2018-06-18 21:57:46 --> Helper loaded: form_helper
INFO - 2018-06-18 21:57:46 --> Helper loaded: date_helper
INFO - 2018-06-18 21:57:46 --> Helper loaded: util_helper
INFO - 2018-06-18 21:57:46 --> Helper loaded: text_helper
INFO - 2018-06-18 21:57:46 --> Helper loaded: string_helper
INFO - 2018-06-18 21:57:46 --> Database Driver Class Initialized
DEBUG - 2018-06-18 21:57:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 21:57:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 21:57:46 --> Email Class Initialized
INFO - 2018-06-18 21:57:46 --> Controller Class Initialized
DEBUG - 2018-06-18 21:57:46 --> videos MX_Controller Initialized
INFO - 2018-06-18 21:57:46 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-18 21:57:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-06-18 21:57:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-18 21:57:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-18 21:57:46 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-18 21:57:46 --> Login MX_Controller Initialized
DEBUG - 2018-06-18 21:57:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-18 21:57:46 --> Final output sent to browser
DEBUG - 2018-06-18 21:57:46 --> Total execution time: 0.5000
INFO - 2018-06-18 21:58:11 --> Config Class Initialized
INFO - 2018-06-18 21:58:11 --> Hooks Class Initialized
DEBUG - 2018-06-18 21:58:11 --> UTF-8 Support Enabled
INFO - 2018-06-18 21:58:11 --> Utf8 Class Initialized
INFO - 2018-06-18 21:58:11 --> URI Class Initialized
INFO - 2018-06-18 21:58:11 --> Router Class Initialized
INFO - 2018-06-18 21:58:11 --> Output Class Initialized
INFO - 2018-06-18 21:58:11 --> Security Class Initialized
DEBUG - 2018-06-18 21:58:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 21:58:11 --> Input Class Initialized
INFO - 2018-06-18 21:58:11 --> Language Class Initialized
INFO - 2018-06-18 21:58:11 --> Language Class Initialized
INFO - 2018-06-18 21:58:11 --> Config Class Initialized
INFO - 2018-06-18 21:58:11 --> Loader Class Initialized
DEBUG - 2018-06-18 21:58:11 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-18 21:58:11 --> Helper loaded: url_helper
INFO - 2018-06-18 21:58:11 --> Helper loaded: form_helper
INFO - 2018-06-18 21:58:11 --> Helper loaded: date_helper
INFO - 2018-06-18 21:58:11 --> Helper loaded: util_helper
INFO - 2018-06-18 21:58:11 --> Helper loaded: text_helper
INFO - 2018-06-18 21:58:11 --> Helper loaded: string_helper
INFO - 2018-06-18 21:58:11 --> Database Driver Class Initialized
DEBUG - 2018-06-18 21:58:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 21:58:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 21:58:11 --> Email Class Initialized
INFO - 2018-06-18 21:58:11 --> Controller Class Initialized
DEBUG - 2018-06-18 21:58:11 --> videos MX_Controller Initialized
INFO - 2018-06-18 21:58:11 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-18 21:58:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-06-18 21:58:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-18 21:58:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-18 21:58:11 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-18 21:58:11 --> Login MX_Controller Initialized
DEBUG - 2018-06-18 21:58:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-18 21:58:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-18 21:58:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-18 21:58:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-18 21:58:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-18 21:58:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-18 21:58:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/videos/videos.php
INFO - 2018-06-18 21:58:11 --> Final output sent to browser
DEBUG - 2018-06-18 21:58:12 --> Total execution time: 0.4383
INFO - 2018-06-18 21:58:12 --> Config Class Initialized
INFO - 2018-06-18 21:58:12 --> Hooks Class Initialized
DEBUG - 2018-06-18 21:58:12 --> UTF-8 Support Enabled
INFO - 2018-06-18 21:58:12 --> Utf8 Class Initialized
INFO - 2018-06-18 21:58:12 --> URI Class Initialized
INFO - 2018-06-18 21:58:12 --> Router Class Initialized
INFO - 2018-06-18 21:58:12 --> Output Class Initialized
INFO - 2018-06-18 21:58:12 --> Security Class Initialized
DEBUG - 2018-06-18 21:58:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 21:58:12 --> Input Class Initialized
INFO - 2018-06-18 21:58:12 --> Language Class Initialized
INFO - 2018-06-18 21:58:12 --> Language Class Initialized
INFO - 2018-06-18 21:58:12 --> Config Class Initialized
INFO - 2018-06-18 21:58:12 --> Loader Class Initialized
DEBUG - 2018-06-18 21:58:12 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-18 21:58:12 --> Helper loaded: url_helper
INFO - 2018-06-18 21:58:12 --> Helper loaded: form_helper
INFO - 2018-06-18 21:58:12 --> Helper loaded: date_helper
INFO - 2018-06-18 21:58:12 --> Helper loaded: util_helper
INFO - 2018-06-18 21:58:12 --> Helper loaded: text_helper
INFO - 2018-06-18 21:58:12 --> Helper loaded: string_helper
INFO - 2018-06-18 21:58:12 --> Database Driver Class Initialized
DEBUG - 2018-06-18 21:58:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 21:58:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 21:58:12 --> Email Class Initialized
INFO - 2018-06-18 21:58:12 --> Controller Class Initialized
DEBUG - 2018-06-18 21:58:12 --> videos MX_Controller Initialized
INFO - 2018-06-18 21:58:12 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-18 21:58:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-06-18 21:58:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-18 21:58:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-18 21:58:12 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-18 21:58:12 --> Login MX_Controller Initialized
DEBUG - 2018-06-18 21:58:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-18 21:58:12 --> Final output sent to browser
DEBUG - 2018-06-18 21:58:12 --> Total execution time: 0.5009
INFO - 2018-06-18 22:59:57 --> Config Class Initialized
INFO - 2018-06-18 22:59:57 --> Hooks Class Initialized
DEBUG - 2018-06-18 22:59:57 --> UTF-8 Support Enabled
INFO - 2018-06-18 22:59:57 --> Utf8 Class Initialized
INFO - 2018-06-18 22:59:57 --> URI Class Initialized
INFO - 2018-06-18 22:59:57 --> Router Class Initialized
INFO - 2018-06-18 22:59:57 --> Output Class Initialized
INFO - 2018-06-18 22:59:57 --> Security Class Initialized
DEBUG - 2018-06-18 22:59:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 22:59:57 --> Input Class Initialized
INFO - 2018-06-18 22:59:57 --> Language Class Initialized
INFO - 2018-06-18 22:59:57 --> Language Class Initialized
INFO - 2018-06-18 22:59:57 --> Config Class Initialized
INFO - 2018-06-18 22:59:57 --> Loader Class Initialized
DEBUG - 2018-06-18 22:59:57 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-18 22:59:57 --> Helper loaded: url_helper
INFO - 2018-06-18 22:59:57 --> Helper loaded: form_helper
INFO - 2018-06-18 22:59:57 --> Helper loaded: date_helper
INFO - 2018-06-18 22:59:57 --> Helper loaded: util_helper
INFO - 2018-06-18 22:59:57 --> Helper loaded: text_helper
INFO - 2018-06-18 22:59:57 --> Helper loaded: string_helper
INFO - 2018-06-18 22:59:57 --> Database Driver Class Initialized
DEBUG - 2018-06-18 22:59:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 22:59:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 22:59:57 --> Email Class Initialized
INFO - 2018-06-18 22:59:57 --> Controller Class Initialized
DEBUG - 2018-06-18 22:59:57 --> videos MX_Controller Initialized
INFO - 2018-06-18 22:59:57 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-18 22:59:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-06-18 22:59:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-18 22:59:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-18 22:59:57 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-18 22:59:57 --> Login MX_Controller Initialized
DEBUG - 2018-06-18 22:59:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-18 22:59:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-18 22:59:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-18 22:59:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-18 22:59:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-18 22:59:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-18 22:59:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/videos/create_video.php
INFO - 2018-06-18 22:59:57 --> Final output sent to browser
DEBUG - 2018-06-18 22:59:58 --> Total execution time: 0.4522
INFO - 2018-06-18 22:59:58 --> Config Class Initialized
INFO - 2018-06-18 22:59:58 --> Hooks Class Initialized
DEBUG - 2018-06-18 22:59:58 --> UTF-8 Support Enabled
INFO - 2018-06-18 22:59:58 --> Utf8 Class Initialized
INFO - 2018-06-18 22:59:58 --> URI Class Initialized
INFO - 2018-06-18 22:59:58 --> Router Class Initialized
INFO - 2018-06-18 22:59:58 --> Output Class Initialized
INFO - 2018-06-18 22:59:58 --> Security Class Initialized
DEBUG - 2018-06-18 22:59:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 22:59:58 --> Input Class Initialized
INFO - 2018-06-18 22:59:58 --> Language Class Initialized
ERROR - 2018-06-18 22:59:58 --> 404 Page Not Found: /index
INFO - 2018-06-18 23:01:20 --> Config Class Initialized
INFO - 2018-06-18 23:01:20 --> Hooks Class Initialized
DEBUG - 2018-06-18 23:01:20 --> UTF-8 Support Enabled
INFO - 2018-06-18 23:01:20 --> Utf8 Class Initialized
INFO - 2018-06-18 23:01:20 --> URI Class Initialized
INFO - 2018-06-18 23:01:20 --> Router Class Initialized
INFO - 2018-06-18 23:01:20 --> Output Class Initialized
INFO - 2018-06-18 23:01:20 --> Security Class Initialized
DEBUG - 2018-06-18 23:01:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 23:01:20 --> Input Class Initialized
INFO - 2018-06-18 23:01:20 --> Language Class Initialized
INFO - 2018-06-18 23:01:20 --> Language Class Initialized
INFO - 2018-06-18 23:01:20 --> Config Class Initialized
INFO - 2018-06-18 23:01:20 --> Loader Class Initialized
DEBUG - 2018-06-18 23:01:21 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-18 23:01:21 --> Helper loaded: url_helper
INFO - 2018-06-18 23:01:21 --> Helper loaded: form_helper
INFO - 2018-06-18 23:01:21 --> Helper loaded: date_helper
INFO - 2018-06-18 23:01:21 --> Helper loaded: util_helper
INFO - 2018-06-18 23:01:21 --> Helper loaded: text_helper
INFO - 2018-06-18 23:01:21 --> Helper loaded: string_helper
INFO - 2018-06-18 23:01:21 --> Database Driver Class Initialized
DEBUG - 2018-06-18 23:01:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 23:01:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 23:01:21 --> Email Class Initialized
INFO - 2018-06-18 23:01:21 --> Controller Class Initialized
DEBUG - 2018-06-18 23:01:21 --> videos MX_Controller Initialized
INFO - 2018-06-18 23:01:21 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-18 23:01:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-06-18 23:01:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-18 23:01:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-18 23:01:21 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-18 23:01:21 --> Login MX_Controller Initialized
DEBUG - 2018-06-18 23:01:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-18 23:01:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-18 23:01:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-18 23:01:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-18 23:01:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-18 23:01:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-18 23:01:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/videos/videos.php
INFO - 2018-06-18 23:01:21 --> Final output sent to browser
DEBUG - 2018-06-18 23:01:21 --> Total execution time: 0.4496
INFO - 2018-06-18 23:01:21 --> Config Class Initialized
INFO - 2018-06-18 23:01:21 --> Hooks Class Initialized
DEBUG - 2018-06-18 23:01:21 --> UTF-8 Support Enabled
INFO - 2018-06-18 23:01:21 --> Utf8 Class Initialized
INFO - 2018-06-18 23:01:21 --> URI Class Initialized
INFO - 2018-06-18 23:01:21 --> Router Class Initialized
INFO - 2018-06-18 23:01:21 --> Output Class Initialized
INFO - 2018-06-18 23:01:21 --> Security Class Initialized
DEBUG - 2018-06-18 23:01:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 23:01:21 --> Input Class Initialized
INFO - 2018-06-18 23:01:21 --> Language Class Initialized
INFO - 2018-06-18 23:01:21 --> Language Class Initialized
INFO - 2018-06-18 23:01:22 --> Config Class Initialized
INFO - 2018-06-18 23:01:22 --> Loader Class Initialized
DEBUG - 2018-06-18 23:01:22 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-18 23:01:22 --> Helper loaded: url_helper
INFO - 2018-06-18 23:01:22 --> Helper loaded: form_helper
INFO - 2018-06-18 23:01:22 --> Helper loaded: date_helper
INFO - 2018-06-18 23:01:22 --> Helper loaded: util_helper
INFO - 2018-06-18 23:01:22 --> Helper loaded: text_helper
INFO - 2018-06-18 23:01:22 --> Helper loaded: string_helper
INFO - 2018-06-18 23:01:22 --> Database Driver Class Initialized
DEBUG - 2018-06-18 23:01:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 23:01:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 23:01:22 --> Email Class Initialized
INFO - 2018-06-18 23:01:22 --> Controller Class Initialized
DEBUG - 2018-06-18 23:01:22 --> videos MX_Controller Initialized
INFO - 2018-06-18 23:01:22 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-18 23:01:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-06-18 23:01:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-18 23:01:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-18 23:01:22 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-18 23:01:22 --> Login MX_Controller Initialized
DEBUG - 2018-06-18 23:01:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-18 23:01:22 --> Final output sent to browser
DEBUG - 2018-06-18 23:01:22 --> Total execution time: 0.4952
INFO - 2018-06-18 23:01:29 --> Config Class Initialized
INFO - 2018-06-18 23:01:29 --> Hooks Class Initialized
DEBUG - 2018-06-18 23:01:29 --> UTF-8 Support Enabled
INFO - 2018-06-18 23:01:29 --> Utf8 Class Initialized
INFO - 2018-06-18 23:01:29 --> URI Class Initialized
INFO - 2018-06-18 23:01:29 --> Router Class Initialized
INFO - 2018-06-18 23:01:29 --> Output Class Initialized
INFO - 2018-06-18 23:01:29 --> Security Class Initialized
DEBUG - 2018-06-18 23:01:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 23:01:29 --> Input Class Initialized
INFO - 2018-06-18 23:01:29 --> Language Class Initialized
INFO - 2018-06-18 23:01:29 --> Language Class Initialized
INFO - 2018-06-18 23:01:29 --> Config Class Initialized
INFO - 2018-06-18 23:01:29 --> Loader Class Initialized
DEBUG - 2018-06-18 23:01:29 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-18 23:01:29 --> Helper loaded: url_helper
INFO - 2018-06-18 23:01:29 --> Helper loaded: form_helper
INFO - 2018-06-18 23:01:29 --> Helper loaded: date_helper
INFO - 2018-06-18 23:01:29 --> Helper loaded: util_helper
INFO - 2018-06-18 23:01:29 --> Helper loaded: text_helper
INFO - 2018-06-18 23:01:29 --> Helper loaded: string_helper
INFO - 2018-06-18 23:01:29 --> Database Driver Class Initialized
DEBUG - 2018-06-18 23:01:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 23:01:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 23:01:29 --> Email Class Initialized
INFO - 2018-06-18 23:01:29 --> Controller Class Initialized
DEBUG - 2018-06-18 23:01:29 --> videos MX_Controller Initialized
INFO - 2018-06-18 23:01:29 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-18 23:01:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-06-18 23:01:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-18 23:01:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-18 23:01:29 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-18 23:01:29 --> Login MX_Controller Initialized
DEBUG - 2018-06-18 23:01:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-18 23:01:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-18 23:01:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-18 23:01:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-18 23:01:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-18 23:01:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-18 23:01:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/videos/create_video.php
INFO - 2018-06-18 23:01:29 --> Final output sent to browser
DEBUG - 2018-06-18 23:01:30 --> Total execution time: 0.4499
INFO - 2018-06-18 23:01:30 --> Config Class Initialized
INFO - 2018-06-18 23:01:30 --> Hooks Class Initialized
DEBUG - 2018-06-18 23:01:30 --> UTF-8 Support Enabled
INFO - 2018-06-18 23:01:30 --> Utf8 Class Initialized
INFO - 2018-06-18 23:01:30 --> URI Class Initialized
INFO - 2018-06-18 23:01:30 --> Router Class Initialized
INFO - 2018-06-18 23:01:30 --> Output Class Initialized
INFO - 2018-06-18 23:01:30 --> Security Class Initialized
DEBUG - 2018-06-18 23:01:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 23:01:30 --> Input Class Initialized
INFO - 2018-06-18 23:01:30 --> Language Class Initialized
ERROR - 2018-06-18 23:01:30 --> 404 Page Not Found: /index
INFO - 2018-06-18 23:06:26 --> Config Class Initialized
INFO - 2018-06-18 23:06:26 --> Hooks Class Initialized
DEBUG - 2018-06-18 23:06:26 --> UTF-8 Support Enabled
INFO - 2018-06-18 23:06:26 --> Utf8 Class Initialized
INFO - 2018-06-18 23:06:26 --> URI Class Initialized
INFO - 2018-06-18 23:06:26 --> Router Class Initialized
INFO - 2018-06-18 23:06:26 --> Output Class Initialized
INFO - 2018-06-18 23:06:26 --> Security Class Initialized
DEBUG - 2018-06-18 23:06:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 23:06:26 --> Input Class Initialized
INFO - 2018-06-18 23:06:26 --> Language Class Initialized
INFO - 2018-06-18 23:06:26 --> Language Class Initialized
INFO - 2018-06-18 23:06:26 --> Config Class Initialized
INFO - 2018-06-18 23:06:26 --> Loader Class Initialized
DEBUG - 2018-06-18 23:06:26 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-18 23:06:26 --> Helper loaded: url_helper
INFO - 2018-06-18 23:06:26 --> Helper loaded: form_helper
INFO - 2018-06-18 23:06:26 --> Helper loaded: date_helper
INFO - 2018-06-18 23:06:26 --> Helper loaded: util_helper
INFO - 2018-06-18 23:06:26 --> Helper loaded: text_helper
INFO - 2018-06-18 23:06:26 --> Helper loaded: string_helper
INFO - 2018-06-18 23:06:26 --> Database Driver Class Initialized
DEBUG - 2018-06-18 23:06:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 23:06:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 23:06:26 --> Email Class Initialized
INFO - 2018-06-18 23:06:26 --> Controller Class Initialized
DEBUG - 2018-06-18 23:06:26 --> videos MX_Controller Initialized
INFO - 2018-06-18 23:06:26 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-18 23:06:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-06-18 23:06:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-18 23:06:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-18 23:06:26 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-18 23:06:26 --> Login MX_Controller Initialized
DEBUG - 2018-06-18 23:06:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-18 23:06:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-18 23:06:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-18 23:06:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-18 23:06:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-18 23:06:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-18 23:06:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/videos/create_video.php
INFO - 2018-06-18 23:06:26 --> Final output sent to browser
DEBUG - 2018-06-18 23:06:27 --> Total execution time: 0.4757
INFO - 2018-06-18 23:06:27 --> Config Class Initialized
INFO - 2018-06-18 23:06:27 --> Hooks Class Initialized
DEBUG - 2018-06-18 23:06:27 --> UTF-8 Support Enabled
INFO - 2018-06-18 23:06:27 --> Utf8 Class Initialized
INFO - 2018-06-18 23:06:27 --> URI Class Initialized
INFO - 2018-06-18 23:06:27 --> Router Class Initialized
INFO - 2018-06-18 23:06:27 --> Output Class Initialized
INFO - 2018-06-18 23:06:27 --> Security Class Initialized
DEBUG - 2018-06-18 23:06:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 23:06:27 --> Input Class Initialized
INFO - 2018-06-18 23:06:27 --> Language Class Initialized
ERROR - 2018-06-18 23:06:27 --> 404 Page Not Found: /index
INFO - 2018-06-18 23:16:58 --> Config Class Initialized
INFO - 2018-06-18 23:16:58 --> Hooks Class Initialized
DEBUG - 2018-06-18 23:16:58 --> UTF-8 Support Enabled
INFO - 2018-06-18 23:16:58 --> Utf8 Class Initialized
INFO - 2018-06-18 23:16:58 --> URI Class Initialized
INFO - 2018-06-18 23:16:58 --> Router Class Initialized
INFO - 2018-06-18 23:16:59 --> Output Class Initialized
INFO - 2018-06-18 23:16:59 --> Security Class Initialized
DEBUG - 2018-06-18 23:16:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 23:16:59 --> Input Class Initialized
INFO - 2018-06-18 23:16:59 --> Language Class Initialized
INFO - 2018-06-18 23:16:59 --> Language Class Initialized
INFO - 2018-06-18 23:16:59 --> Config Class Initialized
INFO - 2018-06-18 23:16:59 --> Loader Class Initialized
DEBUG - 2018-06-18 23:16:59 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-18 23:16:59 --> Helper loaded: url_helper
INFO - 2018-06-18 23:16:59 --> Helper loaded: form_helper
INFO - 2018-06-18 23:16:59 --> Helper loaded: date_helper
INFO - 2018-06-18 23:16:59 --> Helper loaded: util_helper
INFO - 2018-06-18 23:16:59 --> Helper loaded: text_helper
INFO - 2018-06-18 23:16:59 --> Helper loaded: string_helper
INFO - 2018-06-18 23:16:59 --> Database Driver Class Initialized
DEBUG - 2018-06-18 23:16:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 23:16:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 23:16:59 --> Email Class Initialized
INFO - 2018-06-18 23:16:59 --> Controller Class Initialized
DEBUG - 2018-06-18 23:16:59 --> videos MX_Controller Initialized
INFO - 2018-06-18 23:16:59 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-18 23:16:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-06-18 23:16:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-18 23:16:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-18 23:16:59 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-18 23:16:59 --> Login MX_Controller Initialized
DEBUG - 2018-06-18 23:16:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-18 23:18:41 --> Config Class Initialized
INFO - 2018-06-18 23:18:41 --> Hooks Class Initialized
DEBUG - 2018-06-18 23:18:41 --> UTF-8 Support Enabled
INFO - 2018-06-18 23:18:41 --> Utf8 Class Initialized
INFO - 2018-06-18 23:18:41 --> URI Class Initialized
INFO - 2018-06-18 23:18:41 --> Router Class Initialized
INFO - 2018-06-18 23:18:41 --> Output Class Initialized
INFO - 2018-06-18 23:18:41 --> Security Class Initialized
DEBUG - 2018-06-18 23:18:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 23:18:41 --> Input Class Initialized
INFO - 2018-06-18 23:18:41 --> Language Class Initialized
INFO - 2018-06-18 23:18:41 --> Language Class Initialized
INFO - 2018-06-18 23:18:41 --> Config Class Initialized
INFO - 2018-06-18 23:18:41 --> Loader Class Initialized
DEBUG - 2018-06-18 23:18:41 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-18 23:18:41 --> Helper loaded: url_helper
INFO - 2018-06-18 23:18:41 --> Helper loaded: form_helper
INFO - 2018-06-18 23:18:41 --> Helper loaded: date_helper
INFO - 2018-06-18 23:18:41 --> Helper loaded: util_helper
INFO - 2018-06-18 23:18:41 --> Helper loaded: text_helper
INFO - 2018-06-18 23:18:41 --> Helper loaded: string_helper
INFO - 2018-06-18 23:18:41 --> Database Driver Class Initialized
DEBUG - 2018-06-18 23:18:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 23:18:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 23:18:41 --> Email Class Initialized
INFO - 2018-06-18 23:18:41 --> Controller Class Initialized
DEBUG - 2018-06-18 23:18:41 --> videos MX_Controller Initialized
INFO - 2018-06-18 23:18:41 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-18 23:18:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-06-18 23:18:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-18 23:18:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-18 23:18:41 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-18 23:18:41 --> Login MX_Controller Initialized
DEBUG - 2018-06-18 23:18:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-18 23:18:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-18 23:18:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-18 23:18:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-18 23:18:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-18 23:18:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-18 23:18:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/videos/create_video.php
INFO - 2018-06-18 23:18:41 --> Final output sent to browser
DEBUG - 2018-06-18 23:18:41 --> Total execution time: 0.4881
INFO - 2018-06-18 23:18:42 --> Config Class Initialized
INFO - 2018-06-18 23:18:42 --> Hooks Class Initialized
DEBUG - 2018-06-18 23:18:42 --> UTF-8 Support Enabled
INFO - 2018-06-18 23:18:42 --> Utf8 Class Initialized
INFO - 2018-06-18 23:18:42 --> URI Class Initialized
INFO - 2018-06-18 23:18:42 --> Router Class Initialized
INFO - 2018-06-18 23:18:42 --> Output Class Initialized
INFO - 2018-06-18 23:18:42 --> Security Class Initialized
DEBUG - 2018-06-18 23:18:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 23:18:42 --> Input Class Initialized
INFO - 2018-06-18 23:18:42 --> Language Class Initialized
ERROR - 2018-06-18 23:18:42 --> 404 Page Not Found: /index
INFO - 2018-06-18 23:19:23 --> Config Class Initialized
INFO - 2018-06-18 23:19:23 --> Hooks Class Initialized
DEBUG - 2018-06-18 23:19:23 --> UTF-8 Support Enabled
INFO - 2018-06-18 23:19:23 --> Utf8 Class Initialized
INFO - 2018-06-18 23:19:23 --> URI Class Initialized
INFO - 2018-06-18 23:19:23 --> Router Class Initialized
INFO - 2018-06-18 23:19:23 --> Output Class Initialized
INFO - 2018-06-18 23:19:23 --> Security Class Initialized
DEBUG - 2018-06-18 23:19:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 23:19:23 --> Input Class Initialized
INFO - 2018-06-18 23:19:23 --> Language Class Initialized
INFO - 2018-06-18 23:19:23 --> Language Class Initialized
INFO - 2018-06-18 23:19:23 --> Config Class Initialized
INFO - 2018-06-18 23:19:23 --> Loader Class Initialized
DEBUG - 2018-06-18 23:19:23 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-18 23:19:23 --> Helper loaded: url_helper
INFO - 2018-06-18 23:19:23 --> Helper loaded: form_helper
INFO - 2018-06-18 23:19:23 --> Helper loaded: date_helper
INFO - 2018-06-18 23:19:23 --> Helper loaded: util_helper
INFO - 2018-06-18 23:19:23 --> Helper loaded: text_helper
INFO - 2018-06-18 23:19:23 --> Helper loaded: string_helper
INFO - 2018-06-18 23:19:23 --> Database Driver Class Initialized
DEBUG - 2018-06-18 23:19:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 23:19:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 23:19:23 --> Email Class Initialized
INFO - 2018-06-18 23:19:23 --> Controller Class Initialized
DEBUG - 2018-06-18 23:19:23 --> videos MX_Controller Initialized
INFO - 2018-06-18 23:19:23 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-18 23:19:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-06-18 23:19:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-18 23:19:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-18 23:19:23 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-18 23:19:23 --> Login MX_Controller Initialized
DEBUG - 2018-06-18 23:19:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-18 23:19:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-18 23:19:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-18 23:19:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-18 23:19:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-18 23:19:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-18 23:19:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/videos/create_video.php
INFO - 2018-06-18 23:19:24 --> Final output sent to browser
DEBUG - 2018-06-18 23:19:24 --> Total execution time: 0.4851
INFO - 2018-06-18 23:19:24 --> Config Class Initialized
INFO - 2018-06-18 23:19:24 --> Hooks Class Initialized
DEBUG - 2018-06-18 23:19:24 --> UTF-8 Support Enabled
INFO - 2018-06-18 23:19:24 --> Utf8 Class Initialized
INFO - 2018-06-18 23:19:24 --> URI Class Initialized
INFO - 2018-06-18 23:19:24 --> Router Class Initialized
INFO - 2018-06-18 23:19:25 --> Output Class Initialized
INFO - 2018-06-18 23:19:25 --> Security Class Initialized
DEBUG - 2018-06-18 23:19:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 23:19:25 --> Input Class Initialized
INFO - 2018-06-18 23:19:25 --> Language Class Initialized
ERROR - 2018-06-18 23:19:25 --> 404 Page Not Found: /index
INFO - 2018-06-18 23:19:51 --> Config Class Initialized
INFO - 2018-06-18 23:19:51 --> Hooks Class Initialized
DEBUG - 2018-06-18 23:19:51 --> UTF-8 Support Enabled
INFO - 2018-06-18 23:19:51 --> Utf8 Class Initialized
INFO - 2018-06-18 23:19:51 --> URI Class Initialized
INFO - 2018-06-18 23:19:51 --> Router Class Initialized
INFO - 2018-06-18 23:19:51 --> Output Class Initialized
INFO - 2018-06-18 23:19:51 --> Security Class Initialized
DEBUG - 2018-06-18 23:19:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 23:19:51 --> Input Class Initialized
INFO - 2018-06-18 23:19:51 --> Language Class Initialized
INFO - 2018-06-18 23:19:51 --> Language Class Initialized
INFO - 2018-06-18 23:19:51 --> Config Class Initialized
INFO - 2018-06-18 23:19:51 --> Loader Class Initialized
DEBUG - 2018-06-18 23:19:51 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-18 23:19:51 --> Helper loaded: url_helper
INFO - 2018-06-18 23:19:52 --> Helper loaded: form_helper
INFO - 2018-06-18 23:19:52 --> Helper loaded: date_helper
INFO - 2018-06-18 23:19:52 --> Helper loaded: util_helper
INFO - 2018-06-18 23:19:52 --> Helper loaded: text_helper
INFO - 2018-06-18 23:19:52 --> Helper loaded: string_helper
INFO - 2018-06-18 23:19:52 --> Database Driver Class Initialized
DEBUG - 2018-06-18 23:19:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 23:19:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 23:19:52 --> Email Class Initialized
INFO - 2018-06-18 23:19:52 --> Controller Class Initialized
DEBUG - 2018-06-18 23:19:52 --> videos MX_Controller Initialized
INFO - 2018-06-18 23:19:52 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-18 23:19:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-06-18 23:19:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-18 23:19:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-18 23:19:52 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-18 23:19:52 --> Login MX_Controller Initialized
DEBUG - 2018-06-18 23:19:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-18 23:19:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-18 23:19:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-18 23:19:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-18 23:19:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-18 23:19:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-18 23:19:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/videos/create_video.php
INFO - 2018-06-18 23:19:52 --> Final output sent to browser
DEBUG - 2018-06-18 23:19:52 --> Total execution time: 0.5170
INFO - 2018-06-18 23:19:53 --> Config Class Initialized
INFO - 2018-06-18 23:19:53 --> Hooks Class Initialized
DEBUG - 2018-06-18 23:19:53 --> UTF-8 Support Enabled
INFO - 2018-06-18 23:19:53 --> Utf8 Class Initialized
INFO - 2018-06-18 23:19:53 --> URI Class Initialized
INFO - 2018-06-18 23:19:53 --> Router Class Initialized
INFO - 2018-06-18 23:19:53 --> Output Class Initialized
INFO - 2018-06-18 23:19:53 --> Security Class Initialized
DEBUG - 2018-06-18 23:19:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 23:19:53 --> Input Class Initialized
INFO - 2018-06-18 23:19:53 --> Language Class Initialized
ERROR - 2018-06-18 23:19:53 --> 404 Page Not Found: /index
INFO - 2018-06-18 23:20:04 --> Config Class Initialized
INFO - 2018-06-18 23:20:04 --> Hooks Class Initialized
DEBUG - 2018-06-18 23:20:04 --> UTF-8 Support Enabled
INFO - 2018-06-18 23:20:04 --> Utf8 Class Initialized
INFO - 2018-06-18 23:20:04 --> URI Class Initialized
INFO - 2018-06-18 23:20:04 --> Router Class Initialized
INFO - 2018-06-18 23:20:04 --> Output Class Initialized
INFO - 2018-06-18 23:20:04 --> Security Class Initialized
DEBUG - 2018-06-18 23:20:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 23:20:04 --> Input Class Initialized
INFO - 2018-06-18 23:20:04 --> Language Class Initialized
INFO - 2018-06-18 23:20:04 --> Language Class Initialized
INFO - 2018-06-18 23:20:04 --> Config Class Initialized
INFO - 2018-06-18 23:20:04 --> Loader Class Initialized
DEBUG - 2018-06-18 23:20:04 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-18 23:20:04 --> Helper loaded: url_helper
INFO - 2018-06-18 23:20:04 --> Helper loaded: form_helper
INFO - 2018-06-18 23:20:04 --> Helper loaded: date_helper
INFO - 2018-06-18 23:20:04 --> Helper loaded: util_helper
INFO - 2018-06-18 23:20:04 --> Helper loaded: text_helper
INFO - 2018-06-18 23:20:04 --> Helper loaded: string_helper
INFO - 2018-06-18 23:20:04 --> Database Driver Class Initialized
DEBUG - 2018-06-18 23:20:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 23:20:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 23:20:04 --> Email Class Initialized
INFO - 2018-06-18 23:20:04 --> Controller Class Initialized
DEBUG - 2018-06-18 23:20:04 --> videos MX_Controller Initialized
INFO - 2018-06-18 23:20:04 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-18 23:20:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-06-18 23:20:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-18 23:20:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-18 23:20:04 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-18 23:20:04 --> Login MX_Controller Initialized
DEBUG - 2018-06-18 23:20:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-18 23:20:06 --> Config Class Initialized
INFO - 2018-06-18 23:20:06 --> Hooks Class Initialized
DEBUG - 2018-06-18 23:20:06 --> UTF-8 Support Enabled
INFO - 2018-06-18 23:20:06 --> Utf8 Class Initialized
INFO - 2018-06-18 23:20:06 --> URI Class Initialized
INFO - 2018-06-18 23:20:06 --> Router Class Initialized
INFO - 2018-06-18 23:20:06 --> Output Class Initialized
INFO - 2018-06-18 23:20:06 --> Security Class Initialized
DEBUG - 2018-06-18 23:20:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 23:20:06 --> Input Class Initialized
INFO - 2018-06-18 23:20:06 --> Language Class Initialized
INFO - 2018-06-18 23:20:06 --> Language Class Initialized
INFO - 2018-06-18 23:20:06 --> Config Class Initialized
INFO - 2018-06-18 23:20:06 --> Loader Class Initialized
DEBUG - 2018-06-18 23:20:06 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-18 23:20:06 --> Helper loaded: url_helper
INFO - 2018-06-18 23:20:06 --> Helper loaded: form_helper
INFO - 2018-06-18 23:20:06 --> Helper loaded: date_helper
INFO - 2018-06-18 23:20:06 --> Helper loaded: util_helper
INFO - 2018-06-18 23:20:06 --> Helper loaded: text_helper
INFO - 2018-06-18 23:20:06 --> Helper loaded: string_helper
INFO - 2018-06-18 23:20:06 --> Database Driver Class Initialized
DEBUG - 2018-06-18 23:20:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 23:20:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 23:20:06 --> Email Class Initialized
INFO - 2018-06-18 23:20:06 --> Controller Class Initialized
DEBUG - 2018-06-18 23:20:06 --> videos MX_Controller Initialized
INFO - 2018-06-18 23:20:06 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-18 23:20:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-06-18 23:20:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-18 23:20:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-18 23:20:06 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-18 23:20:06 --> Login MX_Controller Initialized
DEBUG - 2018-06-18 23:20:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-18 23:20:10 --> Config Class Initialized
INFO - 2018-06-18 23:20:10 --> Hooks Class Initialized
DEBUG - 2018-06-18 23:20:10 --> UTF-8 Support Enabled
INFO - 2018-06-18 23:20:10 --> Utf8 Class Initialized
INFO - 2018-06-18 23:20:10 --> URI Class Initialized
INFO - 2018-06-18 23:20:10 --> Router Class Initialized
INFO - 2018-06-18 23:20:10 --> Output Class Initialized
INFO - 2018-06-18 23:20:10 --> Security Class Initialized
DEBUG - 2018-06-18 23:20:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 23:20:10 --> Input Class Initialized
INFO - 2018-06-18 23:20:10 --> Language Class Initialized
ERROR - 2018-06-18 23:20:10 --> 404 Page Not Found: /index
INFO - 2018-06-18 23:20:15 --> Config Class Initialized
INFO - 2018-06-18 23:20:16 --> Hooks Class Initialized
DEBUG - 2018-06-18 23:20:16 --> UTF-8 Support Enabled
INFO - 2018-06-18 23:20:16 --> Utf8 Class Initialized
INFO - 2018-06-18 23:20:16 --> URI Class Initialized
INFO - 2018-06-18 23:20:16 --> Router Class Initialized
INFO - 2018-06-18 23:20:16 --> Output Class Initialized
INFO - 2018-06-18 23:20:16 --> Security Class Initialized
DEBUG - 2018-06-18 23:20:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 23:20:16 --> Input Class Initialized
INFO - 2018-06-18 23:20:16 --> Language Class Initialized
INFO - 2018-06-18 23:20:16 --> Language Class Initialized
INFO - 2018-06-18 23:20:16 --> Config Class Initialized
INFO - 2018-06-18 23:20:16 --> Loader Class Initialized
DEBUG - 2018-06-18 23:20:16 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-18 23:20:16 --> Helper loaded: url_helper
INFO - 2018-06-18 23:20:16 --> Helper loaded: form_helper
INFO - 2018-06-18 23:20:16 --> Helper loaded: date_helper
INFO - 2018-06-18 23:20:16 --> Helper loaded: util_helper
INFO - 2018-06-18 23:20:16 --> Helper loaded: text_helper
INFO - 2018-06-18 23:20:16 --> Helper loaded: string_helper
INFO - 2018-06-18 23:20:16 --> Database Driver Class Initialized
DEBUG - 2018-06-18 23:20:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 23:20:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 23:20:16 --> Email Class Initialized
INFO - 2018-06-18 23:20:16 --> Controller Class Initialized
DEBUG - 2018-06-18 23:20:16 --> videos MX_Controller Initialized
INFO - 2018-06-18 23:20:16 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-18 23:20:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-06-18 23:20:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-18 23:20:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-18 23:20:16 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-18 23:20:16 --> Login MX_Controller Initialized
DEBUG - 2018-06-18 23:20:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-18 23:20:42 --> Config Class Initialized
INFO - 2018-06-18 23:20:42 --> Hooks Class Initialized
DEBUG - 2018-06-18 23:20:42 --> UTF-8 Support Enabled
INFO - 2018-06-18 23:20:42 --> Utf8 Class Initialized
INFO - 2018-06-18 23:20:42 --> URI Class Initialized
INFO - 2018-06-18 23:20:42 --> Router Class Initialized
INFO - 2018-06-18 23:20:42 --> Output Class Initialized
INFO - 2018-06-18 23:20:42 --> Security Class Initialized
DEBUG - 2018-06-18 23:20:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 23:20:42 --> Input Class Initialized
INFO - 2018-06-18 23:20:42 --> Language Class Initialized
INFO - 2018-06-18 23:20:42 --> Language Class Initialized
INFO - 2018-06-18 23:20:42 --> Config Class Initialized
INFO - 2018-06-18 23:20:42 --> Loader Class Initialized
DEBUG - 2018-06-18 23:20:42 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-18 23:20:42 --> Helper loaded: url_helper
INFO - 2018-06-18 23:20:42 --> Helper loaded: form_helper
INFO - 2018-06-18 23:20:42 --> Helper loaded: date_helper
INFO - 2018-06-18 23:20:42 --> Helper loaded: util_helper
INFO - 2018-06-18 23:20:42 --> Helper loaded: text_helper
INFO - 2018-06-18 23:20:42 --> Helper loaded: string_helper
INFO - 2018-06-18 23:20:43 --> Database Driver Class Initialized
DEBUG - 2018-06-18 23:20:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 23:20:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 23:20:43 --> Email Class Initialized
INFO - 2018-06-18 23:20:43 --> Controller Class Initialized
DEBUG - 2018-06-18 23:20:43 --> videos MX_Controller Initialized
INFO - 2018-06-18 23:20:43 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-18 23:20:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-06-18 23:20:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-18 23:20:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-18 23:20:43 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-18 23:20:43 --> Login MX_Controller Initialized
DEBUG - 2018-06-18 23:20:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-18 23:20:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-18 23:20:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-18 23:20:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-18 23:20:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-18 23:20:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-18 23:20:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/videos/create_video.php
INFO - 2018-06-18 23:20:43 --> Final output sent to browser
DEBUG - 2018-06-18 23:20:43 --> Total execution time: 0.5066
INFO - 2018-06-18 23:20:44 --> Config Class Initialized
INFO - 2018-06-18 23:20:44 --> Hooks Class Initialized
DEBUG - 2018-06-18 23:20:44 --> UTF-8 Support Enabled
INFO - 2018-06-18 23:20:44 --> Utf8 Class Initialized
INFO - 2018-06-18 23:20:44 --> URI Class Initialized
INFO - 2018-06-18 23:20:44 --> Config Class Initialized
INFO - 2018-06-18 23:20:44 --> Hooks Class Initialized
INFO - 2018-06-18 23:20:44 --> Router Class Initialized
DEBUG - 2018-06-18 23:20:44 --> UTF-8 Support Enabled
INFO - 2018-06-18 23:20:44 --> Output Class Initialized
INFO - 2018-06-18 23:20:44 --> Utf8 Class Initialized
INFO - 2018-06-18 23:20:44 --> Security Class Initialized
INFO - 2018-06-18 23:20:44 --> URI Class Initialized
DEBUG - 2018-06-18 23:20:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 23:20:44 --> Input Class Initialized
INFO - 2018-06-18 23:20:44 --> Router Class Initialized
INFO - 2018-06-18 23:20:44 --> Output Class Initialized
INFO - 2018-06-18 23:20:44 --> Language Class Initialized
INFO - 2018-06-18 23:20:44 --> Security Class Initialized
ERROR - 2018-06-18 23:20:44 --> 404 Page Not Found: /index
DEBUG - 2018-06-18 23:20:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 23:20:44 --> Input Class Initialized
INFO - 2018-06-18 23:20:44 --> Language Class Initialized
ERROR - 2018-06-18 23:20:44 --> 404 Page Not Found: /index
INFO - 2018-06-18 23:20:47 --> Config Class Initialized
INFO - 2018-06-18 23:20:47 --> Hooks Class Initialized
DEBUG - 2018-06-18 23:20:47 --> UTF-8 Support Enabled
INFO - 2018-06-18 23:20:47 --> Utf8 Class Initialized
INFO - 2018-06-18 23:20:47 --> URI Class Initialized
INFO - 2018-06-18 23:20:47 --> Router Class Initialized
INFO - 2018-06-18 23:20:47 --> Output Class Initialized
INFO - 2018-06-18 23:20:47 --> Security Class Initialized
DEBUG - 2018-06-18 23:20:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 23:20:47 --> Input Class Initialized
INFO - 2018-06-18 23:20:47 --> Language Class Initialized
INFO - 2018-06-18 23:20:47 --> Language Class Initialized
INFO - 2018-06-18 23:20:47 --> Config Class Initialized
INFO - 2018-06-18 23:20:47 --> Loader Class Initialized
DEBUG - 2018-06-18 23:20:47 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-18 23:20:47 --> Helper loaded: url_helper
INFO - 2018-06-18 23:20:47 --> Helper loaded: form_helper
INFO - 2018-06-18 23:20:47 --> Helper loaded: date_helper
INFO - 2018-06-18 23:20:47 --> Helper loaded: util_helper
INFO - 2018-06-18 23:20:47 --> Helper loaded: text_helper
INFO - 2018-06-18 23:20:47 --> Helper loaded: string_helper
INFO - 2018-06-18 23:20:47 --> Database Driver Class Initialized
DEBUG - 2018-06-18 23:20:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 23:20:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 23:20:48 --> Email Class Initialized
INFO - 2018-06-18 23:20:48 --> Controller Class Initialized
DEBUG - 2018-06-18 23:20:48 --> videos MX_Controller Initialized
INFO - 2018-06-18 23:20:48 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-18 23:20:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-06-18 23:20:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-18 23:20:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-18 23:20:48 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-18 23:20:48 --> Login MX_Controller Initialized
DEBUG - 2018-06-18 23:20:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-18 23:20:49 --> Config Class Initialized
INFO - 2018-06-18 23:20:49 --> Hooks Class Initialized
DEBUG - 2018-06-18 23:20:49 --> UTF-8 Support Enabled
INFO - 2018-06-18 23:20:49 --> Utf8 Class Initialized
INFO - 2018-06-18 23:20:49 --> URI Class Initialized
INFO - 2018-06-18 23:20:49 --> Router Class Initialized
INFO - 2018-06-18 23:20:49 --> Output Class Initialized
INFO - 2018-06-18 23:20:49 --> Security Class Initialized
DEBUG - 2018-06-18 23:20:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 23:20:49 --> Input Class Initialized
INFO - 2018-06-18 23:20:49 --> Language Class Initialized
INFO - 2018-06-18 23:20:49 --> Language Class Initialized
INFO - 2018-06-18 23:20:49 --> Config Class Initialized
INFO - 2018-06-18 23:20:49 --> Loader Class Initialized
DEBUG - 2018-06-18 23:20:49 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-18 23:20:49 --> Helper loaded: url_helper
INFO - 2018-06-18 23:20:49 --> Helper loaded: form_helper
INFO - 2018-06-18 23:20:49 --> Helper loaded: date_helper
INFO - 2018-06-18 23:20:49 --> Helper loaded: util_helper
INFO - 2018-06-18 23:20:49 --> Helper loaded: text_helper
INFO - 2018-06-18 23:20:49 --> Helper loaded: string_helper
INFO - 2018-06-18 23:20:49 --> Database Driver Class Initialized
DEBUG - 2018-06-18 23:20:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 23:20:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 23:20:49 --> Email Class Initialized
INFO - 2018-06-18 23:20:49 --> Controller Class Initialized
DEBUG - 2018-06-18 23:20:49 --> videos MX_Controller Initialized
INFO - 2018-06-18 23:20:49 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-18 23:20:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-06-18 23:20:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-18 23:20:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-18 23:20:49 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-18 23:20:49 --> Login MX_Controller Initialized
DEBUG - 2018-06-18 23:20:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
ERROR - 2018-06-18 23:20:49 --> Severity: Notice --> Undefined index: chapters E:\xampp\htdocs\consulting\application\modules\admin\controllers\Videos.php 423
INFO - 2018-06-18 23:22:19 --> Config Class Initialized
INFO - 2018-06-18 23:22:19 --> Hooks Class Initialized
DEBUG - 2018-06-18 23:22:19 --> UTF-8 Support Enabled
INFO - 2018-06-18 23:22:19 --> Utf8 Class Initialized
INFO - 2018-06-18 23:22:19 --> URI Class Initialized
INFO - 2018-06-18 23:22:19 --> Router Class Initialized
INFO - 2018-06-18 23:22:19 --> Output Class Initialized
INFO - 2018-06-18 23:22:19 --> Security Class Initialized
DEBUG - 2018-06-18 23:22:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 23:22:19 --> Input Class Initialized
INFO - 2018-06-18 23:22:19 --> Language Class Initialized
INFO - 2018-06-18 23:22:19 --> Language Class Initialized
INFO - 2018-06-18 23:22:19 --> Config Class Initialized
INFO - 2018-06-18 23:22:19 --> Loader Class Initialized
DEBUG - 2018-06-18 23:22:19 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-18 23:22:19 --> Helper loaded: url_helper
INFO - 2018-06-18 23:22:19 --> Helper loaded: form_helper
INFO - 2018-06-18 23:22:19 --> Helper loaded: date_helper
INFO - 2018-06-18 23:22:19 --> Helper loaded: util_helper
INFO - 2018-06-18 23:22:19 --> Helper loaded: text_helper
INFO - 2018-06-18 23:22:19 --> Helper loaded: string_helper
INFO - 2018-06-18 23:22:19 --> Database Driver Class Initialized
DEBUG - 2018-06-18 23:22:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 23:22:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 23:22:19 --> Email Class Initialized
INFO - 2018-06-18 23:22:19 --> Controller Class Initialized
DEBUG - 2018-06-18 23:22:19 --> videos MX_Controller Initialized
INFO - 2018-06-18 23:22:19 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-18 23:22:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-06-18 23:22:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-18 23:22:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-18 23:22:19 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-18 23:22:19 --> Login MX_Controller Initialized
DEBUG - 2018-06-18 23:22:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-18 23:23:01 --> Config Class Initialized
INFO - 2018-06-18 23:23:01 --> Hooks Class Initialized
DEBUG - 2018-06-18 23:23:01 --> UTF-8 Support Enabled
INFO - 2018-06-18 23:23:01 --> Utf8 Class Initialized
INFO - 2018-06-18 23:23:01 --> URI Class Initialized
INFO - 2018-06-18 23:23:01 --> Router Class Initialized
INFO - 2018-06-18 23:23:01 --> Output Class Initialized
INFO - 2018-06-18 23:23:01 --> Security Class Initialized
DEBUG - 2018-06-18 23:23:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 23:23:01 --> Input Class Initialized
INFO - 2018-06-18 23:23:01 --> Language Class Initialized
INFO - 2018-06-18 23:23:01 --> Language Class Initialized
INFO - 2018-06-18 23:23:01 --> Config Class Initialized
INFO - 2018-06-18 23:23:01 --> Loader Class Initialized
DEBUG - 2018-06-18 23:23:01 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-18 23:23:01 --> Helper loaded: url_helper
INFO - 2018-06-18 23:23:01 --> Helper loaded: form_helper
INFO - 2018-06-18 23:23:01 --> Helper loaded: date_helper
INFO - 2018-06-18 23:23:01 --> Helper loaded: util_helper
INFO - 2018-06-18 23:23:01 --> Helper loaded: text_helper
INFO - 2018-06-18 23:23:01 --> Helper loaded: string_helper
INFO - 2018-06-18 23:23:01 --> Database Driver Class Initialized
DEBUG - 2018-06-18 23:23:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 23:23:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 23:23:01 --> Email Class Initialized
INFO - 2018-06-18 23:23:01 --> Controller Class Initialized
DEBUG - 2018-06-18 23:23:01 --> videos MX_Controller Initialized
INFO - 2018-06-18 23:23:01 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-18 23:23:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-06-18 23:23:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-18 23:23:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-18 23:23:01 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-18 23:23:01 --> Login MX_Controller Initialized
DEBUG - 2018-06-18 23:23:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-18 23:23:17 --> Config Class Initialized
INFO - 2018-06-18 23:23:17 --> Hooks Class Initialized
DEBUG - 2018-06-18 23:23:18 --> UTF-8 Support Enabled
INFO - 2018-06-18 23:23:18 --> Utf8 Class Initialized
INFO - 2018-06-18 23:23:18 --> URI Class Initialized
INFO - 2018-06-18 23:23:18 --> Router Class Initialized
INFO - 2018-06-18 23:23:18 --> Output Class Initialized
INFO - 2018-06-18 23:23:18 --> Security Class Initialized
DEBUG - 2018-06-18 23:23:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 23:23:18 --> Input Class Initialized
INFO - 2018-06-18 23:23:18 --> Language Class Initialized
INFO - 2018-06-18 23:23:18 --> Language Class Initialized
INFO - 2018-06-18 23:23:18 --> Config Class Initialized
INFO - 2018-06-18 23:23:18 --> Loader Class Initialized
DEBUG - 2018-06-18 23:23:18 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-18 23:23:18 --> Helper loaded: url_helper
INFO - 2018-06-18 23:23:18 --> Helper loaded: form_helper
INFO - 2018-06-18 23:23:18 --> Helper loaded: date_helper
INFO - 2018-06-18 23:23:18 --> Helper loaded: util_helper
INFO - 2018-06-18 23:23:18 --> Helper loaded: text_helper
INFO - 2018-06-18 23:23:18 --> Helper loaded: string_helper
INFO - 2018-06-18 23:23:18 --> Database Driver Class Initialized
DEBUG - 2018-06-18 23:23:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 23:23:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 23:23:18 --> Email Class Initialized
INFO - 2018-06-18 23:23:18 --> Controller Class Initialized
DEBUG - 2018-06-18 23:23:18 --> videos MX_Controller Initialized
INFO - 2018-06-18 23:23:18 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-18 23:23:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-06-18 23:23:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-18 23:23:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-18 23:23:18 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-18 23:23:18 --> Login MX_Controller Initialized
DEBUG - 2018-06-18 23:23:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-18 23:23:20 --> Config Class Initialized
INFO - 2018-06-18 23:23:20 --> Hooks Class Initialized
DEBUG - 2018-06-18 23:23:20 --> UTF-8 Support Enabled
INFO - 2018-06-18 23:23:20 --> Utf8 Class Initialized
INFO - 2018-06-18 23:23:20 --> URI Class Initialized
INFO - 2018-06-18 23:23:20 --> Router Class Initialized
INFO - 2018-06-18 23:23:20 --> Output Class Initialized
INFO - 2018-06-18 23:23:20 --> Security Class Initialized
DEBUG - 2018-06-18 23:23:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 23:23:20 --> Input Class Initialized
INFO - 2018-06-18 23:23:20 --> Language Class Initialized
INFO - 2018-06-18 23:23:20 --> Language Class Initialized
INFO - 2018-06-18 23:23:20 --> Config Class Initialized
INFO - 2018-06-18 23:23:20 --> Loader Class Initialized
DEBUG - 2018-06-18 23:23:20 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-18 23:23:20 --> Helper loaded: url_helper
INFO - 2018-06-18 23:23:20 --> Helper loaded: form_helper
INFO - 2018-06-18 23:23:20 --> Helper loaded: date_helper
INFO - 2018-06-18 23:23:20 --> Helper loaded: util_helper
INFO - 2018-06-18 23:23:20 --> Helper loaded: text_helper
INFO - 2018-06-18 23:23:20 --> Helper loaded: string_helper
INFO - 2018-06-18 23:23:20 --> Database Driver Class Initialized
DEBUG - 2018-06-18 23:23:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 23:23:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 23:23:20 --> Email Class Initialized
INFO - 2018-06-18 23:23:20 --> Controller Class Initialized
DEBUG - 2018-06-18 23:23:20 --> videos MX_Controller Initialized
INFO - 2018-06-18 23:23:20 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-18 23:23:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-06-18 23:23:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-18 23:23:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-18 23:23:20 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-18 23:23:20 --> Login MX_Controller Initialized
DEBUG - 2018-06-18 23:23:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-18 23:23:28 --> Config Class Initialized
INFO - 2018-06-18 23:23:28 --> Hooks Class Initialized
DEBUG - 2018-06-18 23:23:28 --> UTF-8 Support Enabled
INFO - 2018-06-18 23:23:28 --> Utf8 Class Initialized
INFO - 2018-06-18 23:23:28 --> URI Class Initialized
INFO - 2018-06-18 23:23:28 --> Router Class Initialized
INFO - 2018-06-18 23:23:28 --> Output Class Initialized
INFO - 2018-06-18 23:23:28 --> Security Class Initialized
DEBUG - 2018-06-18 23:23:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 23:23:28 --> Input Class Initialized
INFO - 2018-06-18 23:23:28 --> Language Class Initialized
INFO - 2018-06-18 23:23:28 --> Language Class Initialized
INFO - 2018-06-18 23:23:28 --> Config Class Initialized
INFO - 2018-06-18 23:23:28 --> Loader Class Initialized
DEBUG - 2018-06-18 23:23:28 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-18 23:23:28 --> Helper loaded: url_helper
INFO - 2018-06-18 23:23:28 --> Helper loaded: form_helper
INFO - 2018-06-18 23:23:28 --> Helper loaded: date_helper
INFO - 2018-06-18 23:23:28 --> Helper loaded: util_helper
INFO - 2018-06-18 23:23:28 --> Helper loaded: text_helper
INFO - 2018-06-18 23:23:28 --> Helper loaded: string_helper
INFO - 2018-06-18 23:23:28 --> Database Driver Class Initialized
DEBUG - 2018-06-18 23:23:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 23:23:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 23:23:28 --> Email Class Initialized
INFO - 2018-06-18 23:23:28 --> Controller Class Initialized
DEBUG - 2018-06-18 23:23:28 --> videos MX_Controller Initialized
INFO - 2018-06-18 23:23:28 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-18 23:23:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-06-18 23:23:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-18 23:23:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-18 23:23:28 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-18 23:23:28 --> Login MX_Controller Initialized
DEBUG - 2018-06-18 23:23:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-18 23:23:34 --> Config Class Initialized
INFO - 2018-06-18 23:23:34 --> Hooks Class Initialized
DEBUG - 2018-06-18 23:23:34 --> UTF-8 Support Enabled
INFO - 2018-06-18 23:23:34 --> Utf8 Class Initialized
INFO - 2018-06-18 23:23:34 --> URI Class Initialized
INFO - 2018-06-18 23:23:34 --> Router Class Initialized
INFO - 2018-06-18 23:23:34 --> Output Class Initialized
INFO - 2018-06-18 23:23:34 --> Security Class Initialized
DEBUG - 2018-06-18 23:23:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 23:23:34 --> Input Class Initialized
INFO - 2018-06-18 23:23:34 --> Language Class Initialized
INFO - 2018-06-18 23:23:34 --> Language Class Initialized
INFO - 2018-06-18 23:23:34 --> Config Class Initialized
INFO - 2018-06-18 23:23:34 --> Loader Class Initialized
DEBUG - 2018-06-18 23:23:34 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-18 23:23:34 --> Helper loaded: url_helper
INFO - 2018-06-18 23:23:34 --> Helper loaded: form_helper
INFO - 2018-06-18 23:23:34 --> Helper loaded: date_helper
INFO - 2018-06-18 23:23:34 --> Helper loaded: util_helper
INFO - 2018-06-18 23:23:34 --> Helper loaded: text_helper
INFO - 2018-06-18 23:23:34 --> Helper loaded: string_helper
INFO - 2018-06-18 23:23:34 --> Database Driver Class Initialized
DEBUG - 2018-06-18 23:23:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 23:23:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 23:23:34 --> Email Class Initialized
INFO - 2018-06-18 23:23:34 --> Controller Class Initialized
DEBUG - 2018-06-18 23:23:34 --> videos MX_Controller Initialized
INFO - 2018-06-18 23:23:34 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-18 23:23:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-06-18 23:23:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-18 23:23:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-18 23:23:34 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-18 23:23:34 --> Login MX_Controller Initialized
DEBUG - 2018-06-18 23:23:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-18 23:24:05 --> Config Class Initialized
INFO - 2018-06-18 23:24:05 --> Hooks Class Initialized
DEBUG - 2018-06-18 23:24:05 --> UTF-8 Support Enabled
INFO - 2018-06-18 23:24:05 --> Utf8 Class Initialized
INFO - 2018-06-18 23:24:05 --> URI Class Initialized
INFO - 2018-06-18 23:24:05 --> Router Class Initialized
INFO - 2018-06-18 23:24:05 --> Output Class Initialized
INFO - 2018-06-18 23:24:05 --> Security Class Initialized
DEBUG - 2018-06-18 23:24:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 23:24:05 --> Input Class Initialized
INFO - 2018-06-18 23:24:05 --> Language Class Initialized
INFO - 2018-06-18 23:24:05 --> Language Class Initialized
INFO - 2018-06-18 23:24:05 --> Config Class Initialized
INFO - 2018-06-18 23:24:05 --> Loader Class Initialized
DEBUG - 2018-06-18 23:24:05 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-18 23:24:05 --> Helper loaded: url_helper
INFO - 2018-06-18 23:24:05 --> Helper loaded: form_helper
INFO - 2018-06-18 23:24:05 --> Helper loaded: date_helper
INFO - 2018-06-18 23:24:05 --> Helper loaded: util_helper
INFO - 2018-06-18 23:24:05 --> Helper loaded: text_helper
INFO - 2018-06-18 23:24:05 --> Helper loaded: string_helper
INFO - 2018-06-18 23:24:05 --> Database Driver Class Initialized
DEBUG - 2018-06-18 23:24:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 23:24:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 23:24:05 --> Email Class Initialized
INFO - 2018-06-18 23:24:05 --> Controller Class Initialized
DEBUG - 2018-06-18 23:24:05 --> videos MX_Controller Initialized
INFO - 2018-06-18 23:24:05 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-18 23:24:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-06-18 23:24:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-18 23:24:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-18 23:24:05 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-18 23:24:05 --> Login MX_Controller Initialized
DEBUG - 2018-06-18 23:24:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-18 23:24:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-18 23:24:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-18 23:24:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-18 23:24:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-18 23:24:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-18 23:24:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/videos/create_video.php
INFO - 2018-06-18 23:24:05 --> Final output sent to browser
DEBUG - 2018-06-18 23:24:05 --> Total execution time: 0.5359
INFO - 2018-06-18 23:24:06 --> Config Class Initialized
INFO - 2018-06-18 23:24:06 --> Hooks Class Initialized
INFO - 2018-06-18 23:24:06 --> Config Class Initialized
INFO - 2018-06-18 23:24:06 --> Hooks Class Initialized
DEBUG - 2018-06-18 23:24:06 --> UTF-8 Support Enabled
INFO - 2018-06-18 23:24:06 --> Utf8 Class Initialized
DEBUG - 2018-06-18 23:24:06 --> UTF-8 Support Enabled
INFO - 2018-06-18 23:24:06 --> Utf8 Class Initialized
INFO - 2018-06-18 23:24:06 --> URI Class Initialized
INFO - 2018-06-18 23:24:06 --> URI Class Initialized
INFO - 2018-06-18 23:24:07 --> Router Class Initialized
INFO - 2018-06-18 23:24:07 --> Router Class Initialized
INFO - 2018-06-18 23:24:07 --> Output Class Initialized
INFO - 2018-06-18 23:24:07 --> Output Class Initialized
INFO - 2018-06-18 23:24:07 --> Security Class Initialized
INFO - 2018-06-18 23:24:07 --> Security Class Initialized
DEBUG - 2018-06-18 23:24:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-06-18 23:24:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 23:24:07 --> Input Class Initialized
INFO - 2018-06-18 23:24:07 --> Input Class Initialized
INFO - 2018-06-18 23:24:07 --> Language Class Initialized
ERROR - 2018-06-18 23:24:07 --> 404 Page Not Found: /index
INFO - 2018-06-18 23:24:07 --> Language Class Initialized
ERROR - 2018-06-18 23:24:07 --> 404 Page Not Found: /index
INFO - 2018-06-18 23:24:22 --> Config Class Initialized
INFO - 2018-06-18 23:24:22 --> Hooks Class Initialized
DEBUG - 2018-06-18 23:24:22 --> UTF-8 Support Enabled
INFO - 2018-06-18 23:24:22 --> Utf8 Class Initialized
INFO - 2018-06-18 23:24:22 --> URI Class Initialized
INFO - 2018-06-18 23:24:22 --> Router Class Initialized
INFO - 2018-06-18 23:24:22 --> Output Class Initialized
INFO - 2018-06-18 23:24:22 --> Security Class Initialized
DEBUG - 2018-06-18 23:24:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 23:24:22 --> Input Class Initialized
INFO - 2018-06-18 23:24:22 --> Language Class Initialized
INFO - 2018-06-18 23:24:22 --> Language Class Initialized
INFO - 2018-06-18 23:24:22 --> Config Class Initialized
INFO - 2018-06-18 23:24:22 --> Loader Class Initialized
DEBUG - 2018-06-18 23:24:22 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-18 23:24:22 --> Helper loaded: url_helper
INFO - 2018-06-18 23:24:22 --> Helper loaded: form_helper
INFO - 2018-06-18 23:24:22 --> Helper loaded: date_helper
INFO - 2018-06-18 23:24:22 --> Helper loaded: util_helper
INFO - 2018-06-18 23:24:22 --> Helper loaded: text_helper
INFO - 2018-06-18 23:24:22 --> Helper loaded: string_helper
INFO - 2018-06-18 23:24:22 --> Database Driver Class Initialized
DEBUG - 2018-06-18 23:24:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 23:24:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 23:24:22 --> Email Class Initialized
INFO - 2018-06-18 23:24:22 --> Controller Class Initialized
DEBUG - 2018-06-18 23:24:22 --> videos MX_Controller Initialized
INFO - 2018-06-18 23:24:22 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-18 23:24:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-06-18 23:24:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-18 23:24:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-18 23:24:22 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-18 23:24:22 --> Login MX_Controller Initialized
DEBUG - 2018-06-18 23:24:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-18 23:24:24 --> Config Class Initialized
INFO - 2018-06-18 23:24:24 --> Hooks Class Initialized
DEBUG - 2018-06-18 23:24:24 --> UTF-8 Support Enabled
INFO - 2018-06-18 23:24:24 --> Utf8 Class Initialized
INFO - 2018-06-18 23:24:24 --> URI Class Initialized
INFO - 2018-06-18 23:24:24 --> Router Class Initialized
INFO - 2018-06-18 23:24:24 --> Output Class Initialized
INFO - 2018-06-18 23:24:24 --> Security Class Initialized
DEBUG - 2018-06-18 23:24:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 23:24:24 --> Input Class Initialized
INFO - 2018-06-18 23:24:24 --> Language Class Initialized
INFO - 2018-06-18 23:24:24 --> Language Class Initialized
INFO - 2018-06-18 23:24:24 --> Config Class Initialized
INFO - 2018-06-18 23:24:24 --> Loader Class Initialized
DEBUG - 2018-06-18 23:24:24 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-18 23:24:24 --> Helper loaded: url_helper
INFO - 2018-06-18 23:24:24 --> Helper loaded: form_helper
INFO - 2018-06-18 23:24:24 --> Helper loaded: date_helper
INFO - 2018-06-18 23:24:24 --> Helper loaded: util_helper
INFO - 2018-06-18 23:24:24 --> Helper loaded: text_helper
INFO - 2018-06-18 23:24:24 --> Helper loaded: string_helper
INFO - 2018-06-18 23:24:24 --> Database Driver Class Initialized
DEBUG - 2018-06-18 23:24:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 23:24:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 23:24:24 --> Email Class Initialized
INFO - 2018-06-18 23:24:24 --> Controller Class Initialized
DEBUG - 2018-06-18 23:24:24 --> videos MX_Controller Initialized
INFO - 2018-06-18 23:24:24 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-18 23:24:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-06-18 23:24:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-18 23:24:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-18 23:24:24 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-18 23:24:24 --> Login MX_Controller Initialized
DEBUG - 2018-06-18 23:24:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-18 23:25:16 --> Config Class Initialized
INFO - 2018-06-18 23:25:16 --> Hooks Class Initialized
DEBUG - 2018-06-18 23:25:16 --> UTF-8 Support Enabled
INFO - 2018-06-18 23:25:16 --> Utf8 Class Initialized
INFO - 2018-06-18 23:25:16 --> URI Class Initialized
INFO - 2018-06-18 23:25:16 --> Router Class Initialized
INFO - 2018-06-18 23:25:16 --> Output Class Initialized
INFO - 2018-06-18 23:25:16 --> Security Class Initialized
DEBUG - 2018-06-18 23:25:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 23:25:16 --> Input Class Initialized
INFO - 2018-06-18 23:25:16 --> Language Class Initialized
INFO - 2018-06-18 23:25:16 --> Language Class Initialized
INFO - 2018-06-18 23:25:16 --> Config Class Initialized
INFO - 2018-06-18 23:25:16 --> Loader Class Initialized
DEBUG - 2018-06-18 23:25:16 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-18 23:25:16 --> Helper loaded: url_helper
INFO - 2018-06-18 23:25:16 --> Helper loaded: form_helper
INFO - 2018-06-18 23:25:16 --> Helper loaded: date_helper
INFO - 2018-06-18 23:25:16 --> Helper loaded: util_helper
INFO - 2018-06-18 23:25:16 --> Helper loaded: text_helper
INFO - 2018-06-18 23:25:16 --> Helper loaded: string_helper
INFO - 2018-06-18 23:25:16 --> Database Driver Class Initialized
DEBUG - 2018-06-18 23:25:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 23:25:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 23:25:16 --> Email Class Initialized
INFO - 2018-06-18 23:25:16 --> Controller Class Initialized
DEBUG - 2018-06-18 23:25:16 --> videos MX_Controller Initialized
INFO - 2018-06-18 23:25:16 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-18 23:25:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-06-18 23:25:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-18 23:25:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-18 23:25:16 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-18 23:25:16 --> Login MX_Controller Initialized
DEBUG - 2018-06-18 23:25:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-18 23:25:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-18 23:25:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-18 23:25:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-18 23:25:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-18 23:25:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-18 23:25:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/videos/create_video.php
INFO - 2018-06-18 23:25:16 --> Final output sent to browser
DEBUG - 2018-06-18 23:25:16 --> Total execution time: 0.5444
INFO - 2018-06-18 23:25:18 --> Config Class Initialized
INFO - 2018-06-18 23:25:18 --> Hooks Class Initialized
DEBUG - 2018-06-18 23:25:18 --> UTF-8 Support Enabled
INFO - 2018-06-18 23:25:18 --> Utf8 Class Initialized
INFO - 2018-06-18 23:25:18 --> Config Class Initialized
INFO - 2018-06-18 23:25:18 --> Hooks Class Initialized
INFO - 2018-06-18 23:25:18 --> URI Class Initialized
DEBUG - 2018-06-18 23:25:18 --> UTF-8 Support Enabled
INFO - 2018-06-18 23:25:18 --> Utf8 Class Initialized
INFO - 2018-06-18 23:25:18 --> URI Class Initialized
INFO - 2018-06-18 23:25:18 --> Router Class Initialized
INFO - 2018-06-18 23:25:18 --> Router Class Initialized
INFO - 2018-06-18 23:25:18 --> Output Class Initialized
INFO - 2018-06-18 23:25:18 --> Output Class Initialized
INFO - 2018-06-18 23:25:18 --> Security Class Initialized
INFO - 2018-06-18 23:25:18 --> Security Class Initialized
DEBUG - 2018-06-18 23:25:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-06-18 23:25:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 23:25:18 --> Input Class Initialized
INFO - 2018-06-18 23:25:18 --> Input Class Initialized
INFO - 2018-06-18 23:25:18 --> Language Class Initialized
INFO - 2018-06-18 23:25:18 --> Language Class Initialized
ERROR - 2018-06-18 23:25:18 --> 404 Page Not Found: /index
ERROR - 2018-06-18 23:25:18 --> 404 Page Not Found: /index
INFO - 2018-06-18 23:25:23 --> Config Class Initialized
INFO - 2018-06-18 23:25:23 --> Hooks Class Initialized
DEBUG - 2018-06-18 23:25:23 --> UTF-8 Support Enabled
INFO - 2018-06-18 23:25:23 --> Utf8 Class Initialized
INFO - 2018-06-18 23:25:23 --> URI Class Initialized
INFO - 2018-06-18 23:25:23 --> Router Class Initialized
INFO - 2018-06-18 23:25:23 --> Output Class Initialized
INFO - 2018-06-18 23:25:23 --> Security Class Initialized
DEBUG - 2018-06-18 23:25:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 23:25:23 --> Input Class Initialized
INFO - 2018-06-18 23:25:23 --> Language Class Initialized
INFO - 2018-06-18 23:25:23 --> Language Class Initialized
INFO - 2018-06-18 23:25:23 --> Config Class Initialized
INFO - 2018-06-18 23:25:23 --> Loader Class Initialized
DEBUG - 2018-06-18 23:25:23 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-18 23:25:23 --> Helper loaded: url_helper
INFO - 2018-06-18 23:25:23 --> Helper loaded: form_helper
INFO - 2018-06-18 23:25:23 --> Helper loaded: date_helper
INFO - 2018-06-18 23:25:23 --> Helper loaded: util_helper
INFO - 2018-06-18 23:25:23 --> Helper loaded: text_helper
INFO - 2018-06-18 23:25:23 --> Helper loaded: string_helper
INFO - 2018-06-18 23:25:23 --> Database Driver Class Initialized
DEBUG - 2018-06-18 23:25:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 23:25:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 23:25:23 --> Email Class Initialized
INFO - 2018-06-18 23:25:23 --> Controller Class Initialized
DEBUG - 2018-06-18 23:25:23 --> videos MX_Controller Initialized
INFO - 2018-06-18 23:25:23 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-18 23:25:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-06-18 23:25:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-18 23:25:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-18 23:25:23 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-18 23:25:23 --> Login MX_Controller Initialized
DEBUG - 2018-06-18 23:25:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-18 23:25:24 --> Config Class Initialized
INFO - 2018-06-18 23:25:24 --> Hooks Class Initialized
DEBUG - 2018-06-18 23:25:24 --> UTF-8 Support Enabled
INFO - 2018-06-18 23:25:24 --> Utf8 Class Initialized
INFO - 2018-06-18 23:25:24 --> URI Class Initialized
INFO - 2018-06-18 23:25:24 --> Router Class Initialized
INFO - 2018-06-18 23:25:24 --> Output Class Initialized
INFO - 2018-06-18 23:25:24 --> Security Class Initialized
DEBUG - 2018-06-18 23:25:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 23:25:24 --> Input Class Initialized
INFO - 2018-06-18 23:25:25 --> Language Class Initialized
INFO - 2018-06-18 23:25:25 --> Language Class Initialized
INFO - 2018-06-18 23:25:25 --> Config Class Initialized
INFO - 2018-06-18 23:25:25 --> Loader Class Initialized
DEBUG - 2018-06-18 23:25:25 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-18 23:25:25 --> Helper loaded: url_helper
INFO - 2018-06-18 23:25:25 --> Helper loaded: form_helper
INFO - 2018-06-18 23:25:25 --> Helper loaded: date_helper
INFO - 2018-06-18 23:25:25 --> Helper loaded: util_helper
INFO - 2018-06-18 23:25:25 --> Helper loaded: text_helper
INFO - 2018-06-18 23:25:25 --> Helper loaded: string_helper
INFO - 2018-06-18 23:25:25 --> Database Driver Class Initialized
DEBUG - 2018-06-18 23:25:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 23:25:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 23:25:25 --> Email Class Initialized
INFO - 2018-06-18 23:25:25 --> Controller Class Initialized
DEBUG - 2018-06-18 23:25:25 --> videos MX_Controller Initialized
INFO - 2018-06-18 23:25:25 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-18 23:25:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-06-18 23:25:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-18 23:25:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-18 23:25:25 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-18 23:25:25 --> Login MX_Controller Initialized
DEBUG - 2018-06-18 23:25:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-18 23:25:50 --> Config Class Initialized
INFO - 2018-06-18 23:25:50 --> Hooks Class Initialized
DEBUG - 2018-06-18 23:25:50 --> UTF-8 Support Enabled
INFO - 2018-06-18 23:25:50 --> Utf8 Class Initialized
INFO - 2018-06-18 23:25:50 --> URI Class Initialized
INFO - 2018-06-18 23:25:51 --> Router Class Initialized
INFO - 2018-06-18 23:25:51 --> Output Class Initialized
INFO - 2018-06-18 23:25:51 --> Security Class Initialized
DEBUG - 2018-06-18 23:25:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 23:25:51 --> Input Class Initialized
INFO - 2018-06-18 23:25:51 --> Language Class Initialized
INFO - 2018-06-18 23:25:51 --> Language Class Initialized
INFO - 2018-06-18 23:25:51 --> Config Class Initialized
INFO - 2018-06-18 23:25:51 --> Loader Class Initialized
DEBUG - 2018-06-18 23:25:51 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-18 23:25:51 --> Helper loaded: url_helper
INFO - 2018-06-18 23:25:51 --> Helper loaded: form_helper
INFO - 2018-06-18 23:25:51 --> Helper loaded: date_helper
INFO - 2018-06-18 23:25:51 --> Helper loaded: util_helper
INFO - 2018-06-18 23:25:51 --> Helper loaded: text_helper
INFO - 2018-06-18 23:25:51 --> Helper loaded: string_helper
INFO - 2018-06-18 23:25:51 --> Database Driver Class Initialized
DEBUG - 2018-06-18 23:25:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 23:25:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 23:25:51 --> Email Class Initialized
INFO - 2018-06-18 23:25:51 --> Controller Class Initialized
DEBUG - 2018-06-18 23:25:51 --> videos MX_Controller Initialized
INFO - 2018-06-18 23:25:51 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-18 23:25:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-06-18 23:25:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-18 23:25:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-18 23:25:51 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-18 23:25:51 --> Login MX_Controller Initialized
DEBUG - 2018-06-18 23:25:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-18 23:25:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-18 23:25:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-18 23:25:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-18 23:25:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-18 23:25:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-18 23:25:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/videos/create_video.php
INFO - 2018-06-18 23:25:51 --> Final output sent to browser
DEBUG - 2018-06-18 23:25:51 --> Total execution time: 0.6495
INFO - 2018-06-18 23:25:52 --> Config Class Initialized
INFO - 2018-06-18 23:25:52 --> Hooks Class Initialized
INFO - 2018-06-18 23:25:52 --> Config Class Initialized
INFO - 2018-06-18 23:25:52 --> Hooks Class Initialized
DEBUG - 2018-06-18 23:25:52 --> UTF-8 Support Enabled
DEBUG - 2018-06-18 23:25:52 --> UTF-8 Support Enabled
INFO - 2018-06-18 23:25:52 --> Utf8 Class Initialized
INFO - 2018-06-18 23:25:52 --> URI Class Initialized
INFO - 2018-06-18 23:25:52 --> Router Class Initialized
INFO - 2018-06-18 23:25:52 --> Utf8 Class Initialized
INFO - 2018-06-18 23:25:52 --> Output Class Initialized
INFO - 2018-06-18 23:25:52 --> URI Class Initialized
INFO - 2018-06-18 23:25:52 --> Router Class Initialized
INFO - 2018-06-18 23:25:52 --> Output Class Initialized
INFO - 2018-06-18 23:25:52 --> Security Class Initialized
DEBUG - 2018-06-18 23:25:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 23:25:52 --> Input Class Initialized
INFO - 2018-06-18 23:25:52 --> Language Class Initialized
ERROR - 2018-06-18 23:25:52 --> 404 Page Not Found: /index
INFO - 2018-06-18 23:25:52 --> Security Class Initialized
DEBUG - 2018-06-18 23:25:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 23:25:52 --> Input Class Initialized
INFO - 2018-06-18 23:25:52 --> Language Class Initialized
ERROR - 2018-06-18 23:25:52 --> 404 Page Not Found: /index
INFO - 2018-06-18 23:25:57 --> Config Class Initialized
INFO - 2018-06-18 23:25:57 --> Hooks Class Initialized
DEBUG - 2018-06-18 23:25:57 --> UTF-8 Support Enabled
INFO - 2018-06-18 23:25:57 --> Utf8 Class Initialized
INFO - 2018-06-18 23:25:57 --> URI Class Initialized
INFO - 2018-06-18 23:25:57 --> Router Class Initialized
INFO - 2018-06-18 23:25:57 --> Output Class Initialized
INFO - 2018-06-18 23:25:57 --> Security Class Initialized
DEBUG - 2018-06-18 23:25:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 23:25:57 --> Input Class Initialized
INFO - 2018-06-18 23:25:57 --> Language Class Initialized
INFO - 2018-06-18 23:25:57 --> Language Class Initialized
INFO - 2018-06-18 23:25:57 --> Config Class Initialized
INFO - 2018-06-18 23:25:57 --> Loader Class Initialized
DEBUG - 2018-06-18 23:25:57 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-18 23:25:57 --> Helper loaded: url_helper
INFO - 2018-06-18 23:25:57 --> Helper loaded: form_helper
INFO - 2018-06-18 23:25:57 --> Helper loaded: date_helper
INFO - 2018-06-18 23:25:57 --> Helper loaded: util_helper
INFO - 2018-06-18 23:25:57 --> Helper loaded: text_helper
INFO - 2018-06-18 23:25:57 --> Helper loaded: string_helper
INFO - 2018-06-18 23:25:57 --> Database Driver Class Initialized
DEBUG - 2018-06-18 23:25:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 23:25:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 23:25:57 --> Email Class Initialized
INFO - 2018-06-18 23:25:57 --> Controller Class Initialized
DEBUG - 2018-06-18 23:25:57 --> videos MX_Controller Initialized
INFO - 2018-06-18 23:25:57 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-18 23:25:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-06-18 23:25:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-18 23:25:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-18 23:25:57 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-18 23:25:57 --> Login MX_Controller Initialized
DEBUG - 2018-06-18 23:25:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-18 23:25:59 --> Config Class Initialized
INFO - 2018-06-18 23:25:59 --> Hooks Class Initialized
DEBUG - 2018-06-18 23:25:59 --> UTF-8 Support Enabled
INFO - 2018-06-18 23:25:59 --> Utf8 Class Initialized
INFO - 2018-06-18 23:25:59 --> URI Class Initialized
INFO - 2018-06-18 23:25:59 --> Router Class Initialized
INFO - 2018-06-18 23:25:59 --> Output Class Initialized
INFO - 2018-06-18 23:25:59 --> Security Class Initialized
DEBUG - 2018-06-18 23:25:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 23:25:59 --> Input Class Initialized
INFO - 2018-06-18 23:25:59 --> Language Class Initialized
INFO - 2018-06-18 23:25:59 --> Language Class Initialized
INFO - 2018-06-18 23:25:59 --> Config Class Initialized
INFO - 2018-06-18 23:25:59 --> Loader Class Initialized
DEBUG - 2018-06-18 23:25:59 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-18 23:25:59 --> Helper loaded: url_helper
INFO - 2018-06-18 23:25:59 --> Helper loaded: form_helper
INFO - 2018-06-18 23:25:59 --> Helper loaded: date_helper
INFO - 2018-06-18 23:25:59 --> Helper loaded: util_helper
INFO - 2018-06-18 23:25:59 --> Helper loaded: text_helper
INFO - 2018-06-18 23:25:59 --> Helper loaded: string_helper
INFO - 2018-06-18 23:25:59 --> Database Driver Class Initialized
DEBUG - 2018-06-18 23:25:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 23:25:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 23:25:59 --> Email Class Initialized
INFO - 2018-06-18 23:25:59 --> Controller Class Initialized
DEBUG - 2018-06-18 23:25:59 --> videos MX_Controller Initialized
INFO - 2018-06-18 23:25:59 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-18 23:25:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-06-18 23:25:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-18 23:25:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-18 23:25:59 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-18 23:25:59 --> Login MX_Controller Initialized
DEBUG - 2018-06-18 23:25:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-18 23:30:49 --> Config Class Initialized
INFO - 2018-06-18 23:30:49 --> Hooks Class Initialized
DEBUG - 2018-06-18 23:30:49 --> UTF-8 Support Enabled
INFO - 2018-06-18 23:30:49 --> Utf8 Class Initialized
INFO - 2018-06-18 23:30:49 --> URI Class Initialized
INFO - 2018-06-18 23:30:49 --> Router Class Initialized
INFO - 2018-06-18 23:30:49 --> Output Class Initialized
INFO - 2018-06-18 23:30:49 --> Security Class Initialized
DEBUG - 2018-06-18 23:30:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 23:30:49 --> Input Class Initialized
INFO - 2018-06-18 23:30:49 --> Language Class Initialized
INFO - 2018-06-18 23:30:49 --> Language Class Initialized
INFO - 2018-06-18 23:30:49 --> Config Class Initialized
INFO - 2018-06-18 23:30:49 --> Loader Class Initialized
DEBUG - 2018-06-18 23:30:49 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-18 23:30:49 --> Helper loaded: url_helper
INFO - 2018-06-18 23:30:49 --> Helper loaded: form_helper
INFO - 2018-06-18 23:30:49 --> Helper loaded: date_helper
INFO - 2018-06-18 23:30:49 --> Helper loaded: util_helper
INFO - 2018-06-18 23:30:49 --> Helper loaded: text_helper
INFO - 2018-06-18 23:30:49 --> Helper loaded: string_helper
INFO - 2018-06-18 23:30:49 --> Database Driver Class Initialized
DEBUG - 2018-06-18 23:30:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 23:30:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 23:30:49 --> Email Class Initialized
INFO - 2018-06-18 23:30:49 --> Controller Class Initialized
DEBUG - 2018-06-18 23:30:49 --> videos MX_Controller Initialized
INFO - 2018-06-18 23:30:49 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-18 23:30:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-06-18 23:30:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-18 23:30:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-18 23:30:49 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-18 23:30:49 --> Login MX_Controller Initialized
DEBUG - 2018-06-18 23:30:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-18 23:30:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-18 23:30:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-18 23:30:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-18 23:30:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-18 23:30:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-18 23:30:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/videos/videos.php
INFO - 2018-06-18 23:30:49 --> Final output sent to browser
DEBUG - 2018-06-18 23:30:49 --> Total execution time: 0.5582
INFO - 2018-06-18 23:30:50 --> Config Class Initialized
INFO - 2018-06-18 23:30:50 --> Hooks Class Initialized
DEBUG - 2018-06-18 23:30:50 --> UTF-8 Support Enabled
INFO - 2018-06-18 23:30:50 --> Utf8 Class Initialized
INFO - 2018-06-18 23:30:50 --> URI Class Initialized
INFO - 2018-06-18 23:30:50 --> Router Class Initialized
INFO - 2018-06-18 23:30:50 --> Output Class Initialized
INFO - 2018-06-18 23:30:50 --> Security Class Initialized
DEBUG - 2018-06-18 23:30:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 23:30:50 --> Input Class Initialized
INFO - 2018-06-18 23:30:51 --> Language Class Initialized
INFO - 2018-06-18 23:30:51 --> Language Class Initialized
INFO - 2018-06-18 23:30:51 --> Config Class Initialized
INFO - 2018-06-18 23:30:51 --> Loader Class Initialized
DEBUG - 2018-06-18 23:30:51 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-18 23:30:51 --> Helper loaded: url_helper
INFO - 2018-06-18 23:30:51 --> Helper loaded: form_helper
INFO - 2018-06-18 23:30:51 --> Helper loaded: date_helper
INFO - 2018-06-18 23:30:51 --> Helper loaded: util_helper
INFO - 2018-06-18 23:30:51 --> Helper loaded: text_helper
INFO - 2018-06-18 23:30:51 --> Helper loaded: string_helper
INFO - 2018-06-18 23:30:51 --> Database Driver Class Initialized
DEBUG - 2018-06-18 23:30:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 23:30:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 23:30:51 --> Email Class Initialized
INFO - 2018-06-18 23:30:51 --> Controller Class Initialized
DEBUG - 2018-06-18 23:30:51 --> videos MX_Controller Initialized
INFO - 2018-06-18 23:30:51 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-18 23:30:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-06-18 23:30:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-18 23:30:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-18 23:30:51 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-18 23:30:51 --> Login MX_Controller Initialized
DEBUG - 2018-06-18 23:30:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-18 23:30:51 --> Final output sent to browser
DEBUG - 2018-06-18 23:30:51 --> Total execution time: 0.7724
INFO - 2018-06-18 23:30:55 --> Config Class Initialized
INFO - 2018-06-18 23:30:55 --> Hooks Class Initialized
DEBUG - 2018-06-18 23:30:55 --> UTF-8 Support Enabled
INFO - 2018-06-18 23:30:55 --> Utf8 Class Initialized
INFO - 2018-06-18 23:30:55 --> URI Class Initialized
INFO - 2018-06-18 23:30:55 --> Router Class Initialized
INFO - 2018-06-18 23:30:55 --> Output Class Initialized
INFO - 2018-06-18 23:30:55 --> Security Class Initialized
DEBUG - 2018-06-18 23:30:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 23:30:56 --> Input Class Initialized
INFO - 2018-06-18 23:30:56 --> Language Class Initialized
INFO - 2018-06-18 23:30:56 --> Language Class Initialized
INFO - 2018-06-18 23:30:56 --> Config Class Initialized
INFO - 2018-06-18 23:30:56 --> Loader Class Initialized
DEBUG - 2018-06-18 23:30:56 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-18 23:30:56 --> Helper loaded: url_helper
INFO - 2018-06-18 23:30:56 --> Helper loaded: form_helper
INFO - 2018-06-18 23:30:56 --> Helper loaded: date_helper
INFO - 2018-06-18 23:30:56 --> Helper loaded: util_helper
INFO - 2018-06-18 23:30:56 --> Helper loaded: text_helper
INFO - 2018-06-18 23:30:56 --> Helper loaded: string_helper
INFO - 2018-06-18 23:30:56 --> Database Driver Class Initialized
DEBUG - 2018-06-18 23:30:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 23:30:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 23:30:56 --> Email Class Initialized
INFO - 2018-06-18 23:30:56 --> Controller Class Initialized
DEBUG - 2018-06-18 23:30:56 --> videos MX_Controller Initialized
INFO - 2018-06-18 23:30:56 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-18 23:30:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-06-18 23:30:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-18 23:30:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-18 23:30:56 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-18 23:30:56 --> Login MX_Controller Initialized
DEBUG - 2018-06-18 23:30:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-18 23:30:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-18 23:30:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-18 23:30:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-18 23:30:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-18 23:30:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-18 23:30:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/videos/create_video.php
INFO - 2018-06-18 23:30:56 --> Final output sent to browser
DEBUG - 2018-06-18 23:30:56 --> Total execution time: 0.5823
INFO - 2018-06-18 23:30:57 --> Config Class Initialized
INFO - 2018-06-18 23:30:57 --> Hooks Class Initialized
DEBUG - 2018-06-18 23:30:57 --> UTF-8 Support Enabled
INFO - 2018-06-18 23:30:57 --> Utf8 Class Initialized
INFO - 2018-06-18 23:30:57 --> URI Class Initialized
INFO - 2018-06-18 23:30:57 --> Router Class Initialized
INFO - 2018-06-18 23:30:57 --> Output Class Initialized
INFO - 2018-06-18 23:30:57 --> Security Class Initialized
DEBUG - 2018-06-18 23:30:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 23:30:57 --> Input Class Initialized
INFO - 2018-06-18 23:30:57 --> Language Class Initialized
ERROR - 2018-06-18 23:30:57 --> 404 Page Not Found: /index
INFO - 2018-06-18 23:31:06 --> Config Class Initialized
INFO - 2018-06-18 23:31:06 --> Hooks Class Initialized
DEBUG - 2018-06-18 23:31:06 --> UTF-8 Support Enabled
INFO - 2018-06-18 23:31:06 --> Utf8 Class Initialized
INFO - 2018-06-18 23:31:06 --> URI Class Initialized
INFO - 2018-06-18 23:31:06 --> Router Class Initialized
INFO - 2018-06-18 23:31:06 --> Output Class Initialized
INFO - 2018-06-18 23:31:06 --> Security Class Initialized
DEBUG - 2018-06-18 23:31:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 23:31:06 --> Input Class Initialized
INFO - 2018-06-18 23:31:06 --> Language Class Initialized
INFO - 2018-06-18 23:31:06 --> Language Class Initialized
INFO - 2018-06-18 23:31:06 --> Config Class Initialized
INFO - 2018-06-18 23:31:06 --> Loader Class Initialized
DEBUG - 2018-06-18 23:31:06 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-18 23:31:06 --> Helper loaded: url_helper
INFO - 2018-06-18 23:31:06 --> Helper loaded: form_helper
INFO - 2018-06-18 23:31:06 --> Helper loaded: date_helper
INFO - 2018-06-18 23:31:06 --> Helper loaded: util_helper
INFO - 2018-06-18 23:31:06 --> Helper loaded: text_helper
INFO - 2018-06-18 23:31:06 --> Helper loaded: string_helper
INFO - 2018-06-18 23:31:06 --> Database Driver Class Initialized
DEBUG - 2018-06-18 23:31:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 23:31:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 23:31:06 --> Email Class Initialized
INFO - 2018-06-18 23:31:06 --> Controller Class Initialized
DEBUG - 2018-06-18 23:31:06 --> videos MX_Controller Initialized
INFO - 2018-06-18 23:31:06 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-18 23:31:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-06-18 23:31:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-18 23:31:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-18 23:31:06 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-18 23:31:06 --> Login MX_Controller Initialized
DEBUG - 2018-06-18 23:31:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-18 23:31:08 --> Config Class Initialized
INFO - 2018-06-18 23:31:08 --> Hooks Class Initialized
DEBUG - 2018-06-18 23:31:08 --> UTF-8 Support Enabled
INFO - 2018-06-18 23:31:08 --> Utf8 Class Initialized
INFO - 2018-06-18 23:31:08 --> URI Class Initialized
INFO - 2018-06-18 23:31:08 --> Router Class Initialized
INFO - 2018-06-18 23:31:08 --> Output Class Initialized
INFO - 2018-06-18 23:31:08 --> Security Class Initialized
DEBUG - 2018-06-18 23:31:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 23:31:08 --> Input Class Initialized
INFO - 2018-06-18 23:31:08 --> Language Class Initialized
INFO - 2018-06-18 23:31:08 --> Language Class Initialized
INFO - 2018-06-18 23:31:08 --> Config Class Initialized
INFO - 2018-06-18 23:31:08 --> Loader Class Initialized
DEBUG - 2018-06-18 23:31:08 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-18 23:31:08 --> Helper loaded: url_helper
INFO - 2018-06-18 23:31:09 --> Helper loaded: form_helper
INFO - 2018-06-18 23:31:09 --> Helper loaded: date_helper
INFO - 2018-06-18 23:31:09 --> Helper loaded: util_helper
INFO - 2018-06-18 23:31:09 --> Helper loaded: text_helper
INFO - 2018-06-18 23:31:09 --> Helper loaded: string_helper
INFO - 2018-06-18 23:31:09 --> Database Driver Class Initialized
DEBUG - 2018-06-18 23:31:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 23:31:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 23:31:09 --> Email Class Initialized
INFO - 2018-06-18 23:31:09 --> Controller Class Initialized
DEBUG - 2018-06-18 23:31:09 --> videos MX_Controller Initialized
INFO - 2018-06-18 23:31:09 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-18 23:31:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-06-18 23:31:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-18 23:31:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-18 23:31:09 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-18 23:31:09 --> Login MX_Controller Initialized
DEBUG - 2018-06-18 23:31:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-18 23:31:13 --> Config Class Initialized
INFO - 2018-06-18 23:31:13 --> Hooks Class Initialized
DEBUG - 2018-06-18 23:31:13 --> UTF-8 Support Enabled
INFO - 2018-06-18 23:31:13 --> Utf8 Class Initialized
INFO - 2018-06-18 23:31:13 --> URI Class Initialized
INFO - 2018-06-18 23:31:13 --> Router Class Initialized
INFO - 2018-06-18 23:31:13 --> Output Class Initialized
INFO - 2018-06-18 23:31:13 --> Security Class Initialized
DEBUG - 2018-06-18 23:31:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 23:31:13 --> Input Class Initialized
INFO - 2018-06-18 23:31:13 --> Language Class Initialized
INFO - 2018-06-18 23:31:13 --> Language Class Initialized
INFO - 2018-06-18 23:31:13 --> Config Class Initialized
INFO - 2018-06-18 23:31:13 --> Loader Class Initialized
DEBUG - 2018-06-18 23:31:13 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-18 23:31:13 --> Helper loaded: url_helper
INFO - 2018-06-18 23:31:13 --> Helper loaded: form_helper
INFO - 2018-06-18 23:31:13 --> Helper loaded: date_helper
INFO - 2018-06-18 23:31:13 --> Helper loaded: util_helper
INFO - 2018-06-18 23:31:13 --> Helper loaded: text_helper
INFO - 2018-06-18 23:31:13 --> Helper loaded: string_helper
INFO - 2018-06-18 23:31:13 --> Database Driver Class Initialized
DEBUG - 2018-06-18 23:31:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 23:31:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 23:31:13 --> Email Class Initialized
INFO - 2018-06-18 23:31:13 --> Controller Class Initialized
DEBUG - 2018-06-18 23:31:13 --> videos MX_Controller Initialized
INFO - 2018-06-18 23:31:13 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-18 23:31:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-06-18 23:31:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-18 23:31:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-18 23:31:13 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-18 23:31:13 --> Login MX_Controller Initialized
DEBUG - 2018-06-18 23:31:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-18 23:31:13 --> Config Class Initialized
INFO - 2018-06-18 23:31:13 --> Hooks Class Initialized
DEBUG - 2018-06-18 23:31:13 --> UTF-8 Support Enabled
INFO - 2018-06-18 23:31:13 --> Utf8 Class Initialized
INFO - 2018-06-18 23:31:13 --> URI Class Initialized
INFO - 2018-06-18 23:31:13 --> Router Class Initialized
INFO - 2018-06-18 23:31:14 --> Output Class Initialized
INFO - 2018-06-18 23:31:14 --> Security Class Initialized
DEBUG - 2018-06-18 23:31:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 23:31:14 --> Input Class Initialized
INFO - 2018-06-18 23:31:14 --> Language Class Initialized
INFO - 2018-06-18 23:31:14 --> Language Class Initialized
INFO - 2018-06-18 23:31:14 --> Config Class Initialized
INFO - 2018-06-18 23:31:14 --> Loader Class Initialized
DEBUG - 2018-06-18 23:31:14 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-18 23:31:14 --> Helper loaded: url_helper
INFO - 2018-06-18 23:31:14 --> Helper loaded: form_helper
INFO - 2018-06-18 23:31:14 --> Helper loaded: date_helper
INFO - 2018-06-18 23:31:14 --> Helper loaded: util_helper
INFO - 2018-06-18 23:31:14 --> Helper loaded: text_helper
INFO - 2018-06-18 23:31:14 --> Helper loaded: string_helper
INFO - 2018-06-18 23:31:14 --> Database Driver Class Initialized
DEBUG - 2018-06-18 23:31:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 23:31:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 23:31:14 --> Email Class Initialized
INFO - 2018-06-18 23:31:14 --> Controller Class Initialized
DEBUG - 2018-06-18 23:31:14 --> videos MX_Controller Initialized
INFO - 2018-06-18 23:31:14 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-18 23:31:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-06-18 23:31:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-18 23:31:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-18 23:31:14 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-18 23:31:14 --> Login MX_Controller Initialized
DEBUG - 2018-06-18 23:31:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-18 23:31:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-18 23:31:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-18 23:31:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-18 23:31:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-18 23:31:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-18 23:31:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/videos/videos.php
INFO - 2018-06-18 23:31:14 --> Final output sent to browser
DEBUG - 2018-06-18 23:31:14 --> Total execution time: 0.5926
INFO - 2018-06-18 23:31:14 --> Config Class Initialized
INFO - 2018-06-18 23:31:14 --> Hooks Class Initialized
DEBUG - 2018-06-18 23:31:14 --> UTF-8 Support Enabled
INFO - 2018-06-18 23:31:14 --> Utf8 Class Initialized
INFO - 2018-06-18 23:31:15 --> URI Class Initialized
INFO - 2018-06-18 23:31:15 --> Router Class Initialized
INFO - 2018-06-18 23:31:15 --> Output Class Initialized
INFO - 2018-06-18 23:31:15 --> Security Class Initialized
DEBUG - 2018-06-18 23:31:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 23:31:15 --> Input Class Initialized
INFO - 2018-06-18 23:31:15 --> Language Class Initialized
INFO - 2018-06-18 23:31:15 --> Language Class Initialized
INFO - 2018-06-18 23:31:15 --> Config Class Initialized
INFO - 2018-06-18 23:31:15 --> Loader Class Initialized
DEBUG - 2018-06-18 23:31:15 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-18 23:31:15 --> Helper loaded: url_helper
INFO - 2018-06-18 23:31:15 --> Helper loaded: form_helper
INFO - 2018-06-18 23:31:15 --> Helper loaded: date_helper
INFO - 2018-06-18 23:31:15 --> Helper loaded: util_helper
INFO - 2018-06-18 23:31:15 --> Helper loaded: text_helper
INFO - 2018-06-18 23:31:15 --> Helper loaded: string_helper
INFO - 2018-06-18 23:31:15 --> Database Driver Class Initialized
DEBUG - 2018-06-18 23:31:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 23:31:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 23:31:15 --> Email Class Initialized
INFO - 2018-06-18 23:31:15 --> Controller Class Initialized
DEBUG - 2018-06-18 23:31:15 --> videos MX_Controller Initialized
INFO - 2018-06-18 23:31:15 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-18 23:31:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-06-18 23:31:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-18 23:31:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-18 23:31:15 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-18 23:31:15 --> Login MX_Controller Initialized
DEBUG - 2018-06-18 23:31:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-18 23:31:15 --> Final output sent to browser
DEBUG - 2018-06-18 23:31:15 --> Total execution time: 0.6114
INFO - 2018-06-18 23:31:15 --> Config Class Initialized
INFO - 2018-06-18 23:31:15 --> Hooks Class Initialized
DEBUG - 2018-06-18 23:31:15 --> UTF-8 Support Enabled
INFO - 2018-06-18 23:31:15 --> Utf8 Class Initialized
INFO - 2018-06-18 23:31:15 --> URI Class Initialized
INFO - 2018-06-18 23:31:15 --> Router Class Initialized
INFO - 2018-06-18 23:31:15 --> Output Class Initialized
INFO - 2018-06-18 23:31:15 --> Security Class Initialized
DEBUG - 2018-06-18 23:31:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 23:31:15 --> Input Class Initialized
INFO - 2018-06-18 23:31:15 --> Language Class Initialized
INFO - 2018-06-18 23:31:15 --> Language Class Initialized
INFO - 2018-06-18 23:31:15 --> Config Class Initialized
INFO - 2018-06-18 23:31:15 --> Loader Class Initialized
DEBUG - 2018-06-18 23:31:15 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-18 23:31:15 --> Helper loaded: url_helper
INFO - 2018-06-18 23:31:15 --> Helper loaded: form_helper
INFO - 2018-06-18 23:31:15 --> Helper loaded: date_helper
INFO - 2018-06-18 23:31:15 --> Helper loaded: util_helper
INFO - 2018-06-18 23:31:15 --> Helper loaded: text_helper
INFO - 2018-06-18 23:31:16 --> Helper loaded: string_helper
INFO - 2018-06-18 23:31:16 --> Database Driver Class Initialized
DEBUG - 2018-06-18 23:31:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 23:31:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 23:31:16 --> Email Class Initialized
INFO - 2018-06-18 23:31:16 --> Controller Class Initialized
DEBUG - 2018-06-18 23:31:16 --> videos MX_Controller Initialized
INFO - 2018-06-18 23:31:16 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-18 23:31:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-06-18 23:31:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-18 23:31:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-18 23:31:16 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-18 23:31:16 --> Login MX_Controller Initialized
DEBUG - 2018-06-18 23:31:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-18 23:31:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-18 23:31:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-18 23:31:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-18 23:31:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-18 23:31:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-18 23:31:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/videos/create_video.php
INFO - 2018-06-18 23:31:16 --> Final output sent to browser
DEBUG - 2018-06-18 23:31:16 --> Total execution time: 0.5768
INFO - 2018-06-18 23:31:32 --> Config Class Initialized
INFO - 2018-06-18 23:31:32 --> Hooks Class Initialized
DEBUG - 2018-06-18 23:31:32 --> UTF-8 Support Enabled
INFO - 2018-06-18 23:31:32 --> Utf8 Class Initialized
INFO - 2018-06-18 23:31:32 --> URI Class Initialized
INFO - 2018-06-18 23:31:33 --> Router Class Initialized
INFO - 2018-06-18 23:31:33 --> Output Class Initialized
INFO - 2018-06-18 23:31:33 --> Security Class Initialized
DEBUG - 2018-06-18 23:31:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 23:31:33 --> Input Class Initialized
INFO - 2018-06-18 23:31:33 --> Language Class Initialized
INFO - 2018-06-18 23:31:33 --> Language Class Initialized
INFO - 2018-06-18 23:31:33 --> Config Class Initialized
INFO - 2018-06-18 23:31:33 --> Loader Class Initialized
DEBUG - 2018-06-18 23:31:33 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-18 23:31:33 --> Helper loaded: url_helper
INFO - 2018-06-18 23:31:33 --> Helper loaded: form_helper
INFO - 2018-06-18 23:31:33 --> Helper loaded: date_helper
INFO - 2018-06-18 23:31:33 --> Helper loaded: util_helper
INFO - 2018-06-18 23:31:33 --> Helper loaded: text_helper
INFO - 2018-06-18 23:31:33 --> Helper loaded: string_helper
INFO - 2018-06-18 23:31:33 --> Database Driver Class Initialized
DEBUG - 2018-06-18 23:31:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 23:31:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 23:31:33 --> Email Class Initialized
INFO - 2018-06-18 23:31:33 --> Controller Class Initialized
DEBUG - 2018-06-18 23:31:33 --> videos MX_Controller Initialized
INFO - 2018-06-18 23:31:33 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-18 23:31:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-06-18 23:31:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-18 23:31:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-18 23:31:33 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-18 23:31:33 --> Login MX_Controller Initialized
DEBUG - 2018-06-18 23:31:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-18 23:31:33 --> Config Class Initialized
INFO - 2018-06-18 23:31:33 --> Hooks Class Initialized
DEBUG - 2018-06-18 23:31:33 --> UTF-8 Support Enabled
INFO - 2018-06-18 23:31:33 --> Utf8 Class Initialized
INFO - 2018-06-18 23:31:33 --> URI Class Initialized
INFO - 2018-06-18 23:31:33 --> Router Class Initialized
INFO - 2018-06-18 23:31:33 --> Output Class Initialized
INFO - 2018-06-18 23:31:33 --> Security Class Initialized
DEBUG - 2018-06-18 23:31:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 23:31:33 --> Input Class Initialized
INFO - 2018-06-18 23:31:33 --> Language Class Initialized
INFO - 2018-06-18 23:31:33 --> Language Class Initialized
INFO - 2018-06-18 23:31:33 --> Config Class Initialized
INFO - 2018-06-18 23:31:33 --> Loader Class Initialized
DEBUG - 2018-06-18 23:31:33 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-18 23:31:33 --> Helper loaded: url_helper
INFO - 2018-06-18 23:31:33 --> Helper loaded: form_helper
INFO - 2018-06-18 23:31:33 --> Helper loaded: date_helper
INFO - 2018-06-18 23:31:33 --> Helper loaded: util_helper
INFO - 2018-06-18 23:31:33 --> Helper loaded: text_helper
INFO - 2018-06-18 23:31:33 --> Helper loaded: string_helper
INFO - 2018-06-18 23:31:33 --> Database Driver Class Initialized
DEBUG - 2018-06-18 23:31:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 23:31:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 23:31:33 --> Email Class Initialized
INFO - 2018-06-18 23:31:33 --> Controller Class Initialized
DEBUG - 2018-06-18 23:31:33 --> videos MX_Controller Initialized
INFO - 2018-06-18 23:31:33 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-18 23:31:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-06-18 23:31:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-18 23:31:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-18 23:31:33 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-18 23:31:33 --> Login MX_Controller Initialized
DEBUG - 2018-06-18 23:31:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-18 23:31:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-18 23:31:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-18 23:31:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-18 23:31:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-18 23:31:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-18 23:31:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/videos/videos.php
INFO - 2018-06-18 23:31:34 --> Final output sent to browser
DEBUG - 2018-06-18 23:31:34 --> Total execution time: 0.6018
INFO - 2018-06-18 23:31:34 --> Config Class Initialized
INFO - 2018-06-18 23:31:34 --> Hooks Class Initialized
DEBUG - 2018-06-18 23:31:34 --> UTF-8 Support Enabled
INFO - 2018-06-18 23:31:34 --> Utf8 Class Initialized
INFO - 2018-06-18 23:31:34 --> URI Class Initialized
INFO - 2018-06-18 23:31:34 --> Router Class Initialized
INFO - 2018-06-18 23:31:34 --> Output Class Initialized
INFO - 2018-06-18 23:31:34 --> Security Class Initialized
DEBUG - 2018-06-18 23:31:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 23:31:34 --> Input Class Initialized
INFO - 2018-06-18 23:31:34 --> Language Class Initialized
INFO - 2018-06-18 23:31:34 --> Language Class Initialized
INFO - 2018-06-18 23:31:34 --> Config Class Initialized
INFO - 2018-06-18 23:31:34 --> Loader Class Initialized
DEBUG - 2018-06-18 23:31:34 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-18 23:31:34 --> Helper loaded: url_helper
INFO - 2018-06-18 23:31:34 --> Helper loaded: form_helper
INFO - 2018-06-18 23:31:34 --> Helper loaded: date_helper
INFO - 2018-06-18 23:31:34 --> Helper loaded: util_helper
INFO - 2018-06-18 23:31:34 --> Helper loaded: text_helper
INFO - 2018-06-18 23:31:34 --> Helper loaded: string_helper
INFO - 2018-06-18 23:31:34 --> Database Driver Class Initialized
DEBUG - 2018-06-18 23:31:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 23:31:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 23:31:34 --> Email Class Initialized
INFO - 2018-06-18 23:31:34 --> Controller Class Initialized
DEBUG - 2018-06-18 23:31:34 --> videos MX_Controller Initialized
INFO - 2018-06-18 23:31:34 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-18 23:31:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-06-18 23:31:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-18 23:31:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-18 23:31:34 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-18 23:31:34 --> Login MX_Controller Initialized
DEBUG - 2018-06-18 23:31:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-18 23:31:34 --> Final output sent to browser
DEBUG - 2018-06-18 23:31:35 --> Total execution time: 0.5729
INFO - 2018-06-18 23:31:42 --> Config Class Initialized
INFO - 2018-06-18 23:31:42 --> Hooks Class Initialized
DEBUG - 2018-06-18 23:31:42 --> UTF-8 Support Enabled
INFO - 2018-06-18 23:31:42 --> Utf8 Class Initialized
INFO - 2018-06-18 23:31:42 --> URI Class Initialized
INFO - 2018-06-18 23:31:42 --> Router Class Initialized
INFO - 2018-06-18 23:31:42 --> Output Class Initialized
INFO - 2018-06-18 23:31:42 --> Security Class Initialized
DEBUG - 2018-06-18 23:31:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 23:31:42 --> Input Class Initialized
INFO - 2018-06-18 23:31:42 --> Language Class Initialized
INFO - 2018-06-18 23:31:42 --> Language Class Initialized
INFO - 2018-06-18 23:31:42 --> Config Class Initialized
INFO - 2018-06-18 23:31:42 --> Loader Class Initialized
DEBUG - 2018-06-18 23:31:42 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-18 23:31:42 --> Helper loaded: url_helper
INFO - 2018-06-18 23:31:42 --> Helper loaded: form_helper
INFO - 2018-06-18 23:31:42 --> Helper loaded: date_helper
INFO - 2018-06-18 23:31:42 --> Helper loaded: util_helper
INFO - 2018-06-18 23:31:42 --> Helper loaded: text_helper
INFO - 2018-06-18 23:31:42 --> Helper loaded: string_helper
INFO - 2018-06-18 23:31:42 --> Database Driver Class Initialized
DEBUG - 2018-06-18 23:31:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 23:31:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 23:31:42 --> Email Class Initialized
INFO - 2018-06-18 23:31:42 --> Controller Class Initialized
DEBUG - 2018-06-18 23:31:43 --> videos MX_Controller Initialized
INFO - 2018-06-18 23:31:43 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-18 23:31:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-06-18 23:31:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-18 23:31:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-18 23:31:43 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-18 23:31:43 --> Login MX_Controller Initialized
DEBUG - 2018-06-18 23:31:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-18 23:31:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-18 23:31:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-18 23:31:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-18 23:31:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-18 23:31:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-18 23:31:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/videos/create_video.php
INFO - 2018-06-18 23:31:43 --> Final output sent to browser
DEBUG - 2018-06-18 23:31:43 --> Total execution time: 0.5662
INFO - 2018-06-18 23:31:48 --> Config Class Initialized
INFO - 2018-06-18 23:31:48 --> Hooks Class Initialized
DEBUG - 2018-06-18 23:31:48 --> UTF-8 Support Enabled
INFO - 2018-06-18 23:31:48 --> Utf8 Class Initialized
INFO - 2018-06-18 23:31:48 --> URI Class Initialized
INFO - 2018-06-18 23:31:48 --> Router Class Initialized
INFO - 2018-06-18 23:31:48 --> Output Class Initialized
INFO - 2018-06-18 23:31:48 --> Security Class Initialized
DEBUG - 2018-06-18 23:31:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 23:31:48 --> Input Class Initialized
INFO - 2018-06-18 23:31:48 --> Language Class Initialized
INFO - 2018-06-18 23:31:48 --> Language Class Initialized
INFO - 2018-06-18 23:31:48 --> Config Class Initialized
INFO - 2018-06-18 23:31:48 --> Loader Class Initialized
DEBUG - 2018-06-18 23:31:48 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-18 23:31:48 --> Helper loaded: url_helper
INFO - 2018-06-18 23:31:48 --> Helper loaded: form_helper
INFO - 2018-06-18 23:31:48 --> Helper loaded: date_helper
INFO - 2018-06-18 23:31:48 --> Helper loaded: util_helper
INFO - 2018-06-18 23:31:48 --> Helper loaded: text_helper
INFO - 2018-06-18 23:31:48 --> Helper loaded: string_helper
INFO - 2018-06-18 23:31:48 --> Database Driver Class Initialized
DEBUG - 2018-06-18 23:31:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 23:31:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 23:31:48 --> Email Class Initialized
INFO - 2018-06-18 23:31:48 --> Controller Class Initialized
DEBUG - 2018-06-18 23:31:48 --> videos MX_Controller Initialized
INFO - 2018-06-18 23:31:48 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-18 23:31:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-06-18 23:31:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-18 23:31:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-18 23:31:48 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-18 23:31:48 --> Login MX_Controller Initialized
DEBUG - 2018-06-18 23:31:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-18 23:31:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-18 23:31:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-18 23:31:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-18 23:31:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-18 23:31:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-18 23:31:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/videos/videos.php
INFO - 2018-06-18 23:31:48 --> Final output sent to browser
DEBUG - 2018-06-18 23:31:48 --> Total execution time: 0.5791
INFO - 2018-06-18 23:31:48 --> Config Class Initialized
INFO - 2018-06-18 23:31:48 --> Hooks Class Initialized
DEBUG - 2018-06-18 23:31:48 --> UTF-8 Support Enabled
INFO - 2018-06-18 23:31:49 --> Utf8 Class Initialized
INFO - 2018-06-18 23:31:49 --> URI Class Initialized
INFO - 2018-06-18 23:31:49 --> Router Class Initialized
INFO - 2018-06-18 23:31:49 --> Output Class Initialized
INFO - 2018-06-18 23:31:49 --> Security Class Initialized
DEBUG - 2018-06-18 23:31:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 23:31:49 --> Input Class Initialized
INFO - 2018-06-18 23:31:49 --> Language Class Initialized
INFO - 2018-06-18 23:31:49 --> Language Class Initialized
INFO - 2018-06-18 23:31:49 --> Config Class Initialized
INFO - 2018-06-18 23:31:49 --> Loader Class Initialized
DEBUG - 2018-06-18 23:31:49 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-18 23:31:49 --> Helper loaded: url_helper
INFO - 2018-06-18 23:31:49 --> Helper loaded: form_helper
INFO - 2018-06-18 23:31:49 --> Helper loaded: date_helper
INFO - 2018-06-18 23:31:49 --> Helper loaded: util_helper
INFO - 2018-06-18 23:31:49 --> Helper loaded: text_helper
INFO - 2018-06-18 23:31:49 --> Helper loaded: string_helper
INFO - 2018-06-18 23:31:49 --> Database Driver Class Initialized
DEBUG - 2018-06-18 23:31:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 23:31:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 23:31:49 --> Email Class Initialized
INFO - 2018-06-18 23:31:49 --> Controller Class Initialized
DEBUG - 2018-06-18 23:31:49 --> videos MX_Controller Initialized
INFO - 2018-06-18 23:31:49 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-18 23:31:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-06-18 23:31:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-18 23:31:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-18 23:31:49 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-18 23:31:49 --> Login MX_Controller Initialized
DEBUG - 2018-06-18 23:31:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-18 23:31:49 --> Final output sent to browser
DEBUG - 2018-06-18 23:31:49 --> Total execution time: 0.6115
INFO - 2018-06-18 23:32:44 --> Config Class Initialized
INFO - 2018-06-18 23:32:44 --> Hooks Class Initialized
DEBUG - 2018-06-18 23:32:44 --> UTF-8 Support Enabled
INFO - 2018-06-18 23:32:44 --> Utf8 Class Initialized
INFO - 2018-06-18 23:32:44 --> URI Class Initialized
INFO - 2018-06-18 23:32:44 --> Router Class Initialized
INFO - 2018-06-18 23:32:44 --> Output Class Initialized
INFO - 2018-06-18 23:32:44 --> Security Class Initialized
DEBUG - 2018-06-18 23:32:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 23:32:44 --> Input Class Initialized
INFO - 2018-06-18 23:32:44 --> Language Class Initialized
INFO - 2018-06-18 23:32:44 --> Language Class Initialized
INFO - 2018-06-18 23:32:44 --> Config Class Initialized
INFO - 2018-06-18 23:32:44 --> Loader Class Initialized
DEBUG - 2018-06-18 23:32:44 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-18 23:32:44 --> Helper loaded: url_helper
INFO - 2018-06-18 23:32:44 --> Helper loaded: form_helper
INFO - 2018-06-18 23:32:44 --> Helper loaded: date_helper
INFO - 2018-06-18 23:32:44 --> Helper loaded: util_helper
INFO - 2018-06-18 23:32:44 --> Helper loaded: text_helper
INFO - 2018-06-18 23:32:44 --> Helper loaded: string_helper
INFO - 2018-06-18 23:32:44 --> Database Driver Class Initialized
DEBUG - 2018-06-18 23:32:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 23:32:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 23:32:44 --> Email Class Initialized
INFO - 2018-06-18 23:32:44 --> Controller Class Initialized
DEBUG - 2018-06-18 23:32:44 --> videos MX_Controller Initialized
INFO - 2018-06-18 23:32:44 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-18 23:32:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-06-18 23:32:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-18 23:32:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-18 23:32:44 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-18 23:32:44 --> Login MX_Controller Initialized
DEBUG - 2018-06-18 23:32:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-18 23:32:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-18 23:32:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-18 23:32:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-18 23:32:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-18 23:32:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-18 23:32:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/videos/create_video.php
INFO - 2018-06-18 23:32:45 --> Final output sent to browser
DEBUG - 2018-06-18 23:32:45 --> Total execution time: 0.5754
INFO - 2018-06-18 23:32:46 --> Config Class Initialized
INFO - 2018-06-18 23:32:46 --> Hooks Class Initialized
DEBUG - 2018-06-18 23:32:46 --> UTF-8 Support Enabled
INFO - 2018-06-18 23:32:46 --> Utf8 Class Initialized
INFO - 2018-06-18 23:32:46 --> URI Class Initialized
INFO - 2018-06-18 23:32:46 --> Router Class Initialized
INFO - 2018-06-18 23:32:46 --> Output Class Initialized
INFO - 2018-06-18 23:32:46 --> Security Class Initialized
DEBUG - 2018-06-18 23:32:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 23:32:46 --> Input Class Initialized
INFO - 2018-06-18 23:32:46 --> Language Class Initialized
INFO - 2018-06-18 23:32:46 --> Language Class Initialized
INFO - 2018-06-18 23:32:46 --> Config Class Initialized
INFO - 2018-06-18 23:32:46 --> Loader Class Initialized
DEBUG - 2018-06-18 23:32:46 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-18 23:32:46 --> Helper loaded: url_helper
INFO - 2018-06-18 23:32:46 --> Helper loaded: form_helper
INFO - 2018-06-18 23:32:47 --> Helper loaded: date_helper
INFO - 2018-06-18 23:32:47 --> Helper loaded: util_helper
INFO - 2018-06-18 23:32:47 --> Helper loaded: text_helper
INFO - 2018-06-18 23:32:47 --> Helper loaded: string_helper
INFO - 2018-06-18 23:32:47 --> Database Driver Class Initialized
DEBUG - 2018-06-18 23:32:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 23:32:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 23:32:47 --> Email Class Initialized
INFO - 2018-06-18 23:32:47 --> Controller Class Initialized
DEBUG - 2018-06-18 23:32:47 --> videos MX_Controller Initialized
INFO - 2018-06-18 23:32:47 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-18 23:32:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-06-18 23:32:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-18 23:32:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-18 23:32:47 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-18 23:32:47 --> Login MX_Controller Initialized
DEBUG - 2018-06-18 23:32:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-18 23:32:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-18 23:32:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-18 23:32:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-18 23:32:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-18 23:32:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-18 23:32:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/videos/create_video.php
INFO - 2018-06-18 23:32:47 --> Final output sent to browser
DEBUG - 2018-06-18 23:32:47 --> Total execution time: 0.5442
INFO - 2018-06-18 23:32:47 --> Config Class Initialized
INFO - 2018-06-18 23:32:47 --> Hooks Class Initialized
DEBUG - 2018-06-18 23:32:47 --> UTF-8 Support Enabled
INFO - 2018-06-18 23:32:47 --> Utf8 Class Initialized
INFO - 2018-06-18 23:32:47 --> URI Class Initialized
INFO - 2018-06-18 23:32:47 --> Router Class Initialized
INFO - 2018-06-18 23:32:47 --> Output Class Initialized
INFO - 2018-06-18 23:32:47 --> Security Class Initialized
DEBUG - 2018-06-18 23:32:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 23:32:47 --> Input Class Initialized
INFO - 2018-06-18 23:32:47 --> Language Class Initialized
ERROR - 2018-06-18 23:32:47 --> 404 Page Not Found: /index
INFO - 2018-06-18 23:33:19 --> Config Class Initialized
INFO - 2018-06-18 23:33:19 --> Hooks Class Initialized
DEBUG - 2018-06-18 23:33:19 --> UTF-8 Support Enabled
INFO - 2018-06-18 23:33:19 --> Utf8 Class Initialized
INFO - 2018-06-18 23:33:19 --> URI Class Initialized
INFO - 2018-06-18 23:33:19 --> Router Class Initialized
INFO - 2018-06-18 23:33:19 --> Output Class Initialized
INFO - 2018-06-18 23:33:19 --> Security Class Initialized
DEBUG - 2018-06-18 23:33:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 23:33:19 --> Input Class Initialized
INFO - 2018-06-18 23:33:19 --> Language Class Initialized
INFO - 2018-06-18 23:33:19 --> Language Class Initialized
INFO - 2018-06-18 23:33:19 --> Config Class Initialized
INFO - 2018-06-18 23:33:19 --> Loader Class Initialized
DEBUG - 2018-06-18 23:33:19 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-18 23:33:19 --> Helper loaded: url_helper
INFO - 2018-06-18 23:33:19 --> Helper loaded: form_helper
INFO - 2018-06-18 23:33:19 --> Helper loaded: date_helper
INFO - 2018-06-18 23:33:19 --> Helper loaded: util_helper
INFO - 2018-06-18 23:33:19 --> Helper loaded: text_helper
INFO - 2018-06-18 23:33:19 --> Helper loaded: string_helper
INFO - 2018-06-18 23:33:19 --> Database Driver Class Initialized
DEBUG - 2018-06-18 23:33:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 23:33:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 23:33:19 --> Email Class Initialized
INFO - 2018-06-18 23:33:19 --> Controller Class Initialized
DEBUG - 2018-06-18 23:33:20 --> videos MX_Controller Initialized
INFO - 2018-06-18 23:33:20 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-18 23:33:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-06-18 23:33:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-18 23:33:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-18 23:33:20 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-18 23:33:20 --> Login MX_Controller Initialized
DEBUG - 2018-06-18 23:33:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-18 23:33:22 --> Config Class Initialized
INFO - 2018-06-18 23:33:22 --> Hooks Class Initialized
DEBUG - 2018-06-18 23:33:22 --> UTF-8 Support Enabled
INFO - 2018-06-18 23:33:22 --> Utf8 Class Initialized
INFO - 2018-06-18 23:33:22 --> URI Class Initialized
INFO - 2018-06-18 23:33:22 --> Router Class Initialized
INFO - 2018-06-18 23:33:22 --> Output Class Initialized
INFO - 2018-06-18 23:33:22 --> Security Class Initialized
DEBUG - 2018-06-18 23:33:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 23:33:22 --> Input Class Initialized
INFO - 2018-06-18 23:33:22 --> Language Class Initialized
INFO - 2018-06-18 23:33:22 --> Language Class Initialized
INFO - 2018-06-18 23:33:22 --> Config Class Initialized
INFO - 2018-06-18 23:33:22 --> Loader Class Initialized
DEBUG - 2018-06-18 23:33:22 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-18 23:33:22 --> Helper loaded: url_helper
INFO - 2018-06-18 23:33:22 --> Helper loaded: form_helper
INFO - 2018-06-18 23:33:22 --> Helper loaded: date_helper
INFO - 2018-06-18 23:33:22 --> Helper loaded: util_helper
INFO - 2018-06-18 23:33:22 --> Helper loaded: text_helper
INFO - 2018-06-18 23:33:22 --> Helper loaded: string_helper
INFO - 2018-06-18 23:33:22 --> Database Driver Class Initialized
DEBUG - 2018-06-18 23:33:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 23:33:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 23:33:22 --> Email Class Initialized
INFO - 2018-06-18 23:33:22 --> Controller Class Initialized
DEBUG - 2018-06-18 23:33:22 --> videos MX_Controller Initialized
INFO - 2018-06-18 23:33:22 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-18 23:33:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-06-18 23:33:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-18 23:33:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-18 23:33:22 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-18 23:33:22 --> Login MX_Controller Initialized
DEBUG - 2018-06-18 23:33:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-18 23:33:22 --> Config Class Initialized
INFO - 2018-06-18 23:33:22 --> Hooks Class Initialized
DEBUG - 2018-06-18 23:33:22 --> UTF-8 Support Enabled
INFO - 2018-06-18 23:33:22 --> Utf8 Class Initialized
INFO - 2018-06-18 23:33:22 --> URI Class Initialized
INFO - 2018-06-18 23:33:22 --> Router Class Initialized
INFO - 2018-06-18 23:33:22 --> Output Class Initialized
INFO - 2018-06-18 23:33:22 --> Security Class Initialized
DEBUG - 2018-06-18 23:33:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 23:33:22 --> Input Class Initialized
INFO - 2018-06-18 23:33:22 --> Language Class Initialized
INFO - 2018-06-18 23:33:22 --> Language Class Initialized
INFO - 2018-06-18 23:33:22 --> Config Class Initialized
INFO - 2018-06-18 23:33:22 --> Loader Class Initialized
DEBUG - 2018-06-18 23:33:22 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-18 23:33:22 --> Helper loaded: url_helper
INFO - 2018-06-18 23:33:22 --> Helper loaded: form_helper
INFO - 2018-06-18 23:33:22 --> Helper loaded: date_helper
INFO - 2018-06-18 23:33:22 --> Helper loaded: util_helper
INFO - 2018-06-18 23:33:22 --> Helper loaded: text_helper
INFO - 2018-06-18 23:33:22 --> Helper loaded: string_helper
INFO - 2018-06-18 23:33:22 --> Database Driver Class Initialized
DEBUG - 2018-06-18 23:33:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 23:33:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 23:33:23 --> Email Class Initialized
INFO - 2018-06-18 23:33:23 --> Controller Class Initialized
DEBUG - 2018-06-18 23:33:23 --> videos MX_Controller Initialized
INFO - 2018-06-18 23:33:23 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-18 23:33:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-06-18 23:33:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-18 23:33:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-18 23:33:23 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-18 23:33:23 --> Login MX_Controller Initialized
DEBUG - 2018-06-18 23:33:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-18 23:33:23 --> Config Class Initialized
INFO - 2018-06-18 23:33:23 --> Hooks Class Initialized
DEBUG - 2018-06-18 23:33:23 --> UTF-8 Support Enabled
INFO - 2018-06-18 23:33:23 --> Utf8 Class Initialized
INFO - 2018-06-18 23:33:23 --> URI Class Initialized
INFO - 2018-06-18 23:33:23 --> Router Class Initialized
INFO - 2018-06-18 23:33:23 --> Output Class Initialized
INFO - 2018-06-18 23:33:23 --> Security Class Initialized
DEBUG - 2018-06-18 23:33:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 23:33:23 --> Input Class Initialized
INFO - 2018-06-18 23:33:23 --> Language Class Initialized
INFO - 2018-06-18 23:33:23 --> Language Class Initialized
INFO - 2018-06-18 23:33:23 --> Config Class Initialized
INFO - 2018-06-18 23:33:23 --> Loader Class Initialized
DEBUG - 2018-06-18 23:33:23 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-18 23:33:23 --> Helper loaded: url_helper
INFO - 2018-06-18 23:33:23 --> Helper loaded: form_helper
INFO - 2018-06-18 23:33:23 --> Helper loaded: date_helper
INFO - 2018-06-18 23:33:23 --> Helper loaded: util_helper
INFO - 2018-06-18 23:33:23 --> Helper loaded: text_helper
INFO - 2018-06-18 23:33:23 --> Helper loaded: string_helper
INFO - 2018-06-18 23:33:23 --> Database Driver Class Initialized
DEBUG - 2018-06-18 23:33:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 23:33:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 23:33:23 --> Email Class Initialized
INFO - 2018-06-18 23:33:23 --> Controller Class Initialized
DEBUG - 2018-06-18 23:33:23 --> videos MX_Controller Initialized
INFO - 2018-06-18 23:33:23 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-18 23:33:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-06-18 23:33:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-18 23:33:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-18 23:33:23 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-18 23:33:23 --> Login MX_Controller Initialized
DEBUG - 2018-06-18 23:33:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-18 23:33:23 --> Config Class Initialized
INFO - 2018-06-18 23:33:23 --> Hooks Class Initialized
DEBUG - 2018-06-18 23:33:23 --> UTF-8 Support Enabled
INFO - 2018-06-18 23:33:23 --> Utf8 Class Initialized
INFO - 2018-06-18 23:33:23 --> URI Class Initialized
INFO - 2018-06-18 23:33:23 --> Router Class Initialized
INFO - 2018-06-18 23:33:23 --> Output Class Initialized
INFO - 2018-06-18 23:33:23 --> Security Class Initialized
DEBUG - 2018-06-18 23:33:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 23:33:23 --> Input Class Initialized
INFO - 2018-06-18 23:33:23 --> Language Class Initialized
INFO - 2018-06-18 23:33:23 --> Language Class Initialized
INFO - 2018-06-18 23:33:23 --> Config Class Initialized
INFO - 2018-06-18 23:33:23 --> Loader Class Initialized
DEBUG - 2018-06-18 23:33:23 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-18 23:33:23 --> Helper loaded: url_helper
INFO - 2018-06-18 23:33:23 --> Helper loaded: form_helper
INFO - 2018-06-18 23:33:23 --> Helper loaded: date_helper
INFO - 2018-06-18 23:33:23 --> Helper loaded: util_helper
INFO - 2018-06-18 23:33:23 --> Helper loaded: text_helper
INFO - 2018-06-18 23:33:23 --> Helper loaded: string_helper
INFO - 2018-06-18 23:33:24 --> Database Driver Class Initialized
DEBUG - 2018-06-18 23:33:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 23:33:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 23:33:24 --> Email Class Initialized
INFO - 2018-06-18 23:33:24 --> Controller Class Initialized
DEBUG - 2018-06-18 23:33:24 --> videos MX_Controller Initialized
INFO - 2018-06-18 23:33:24 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-18 23:33:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-06-18 23:33:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-18 23:33:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-18 23:33:24 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-18 23:33:24 --> Login MX_Controller Initialized
DEBUG - 2018-06-18 23:33:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-18 23:33:26 --> Config Class Initialized
INFO - 2018-06-18 23:33:26 --> Hooks Class Initialized
DEBUG - 2018-06-18 23:33:26 --> UTF-8 Support Enabled
INFO - 2018-06-18 23:33:26 --> Utf8 Class Initialized
INFO - 2018-06-18 23:33:26 --> URI Class Initialized
INFO - 2018-06-18 23:33:26 --> Router Class Initialized
INFO - 2018-06-18 23:33:26 --> Output Class Initialized
INFO - 2018-06-18 23:33:26 --> Security Class Initialized
DEBUG - 2018-06-18 23:33:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 23:33:26 --> Input Class Initialized
INFO - 2018-06-18 23:33:26 --> Language Class Initialized
ERROR - 2018-06-18 23:33:26 --> 404 Page Not Found: /index
INFO - 2018-06-18 23:33:33 --> Config Class Initialized
INFO - 2018-06-18 23:33:33 --> Hooks Class Initialized
DEBUG - 2018-06-18 23:33:33 --> UTF-8 Support Enabled
INFO - 2018-06-18 23:33:33 --> Utf8 Class Initialized
INFO - 2018-06-18 23:33:33 --> URI Class Initialized
INFO - 2018-06-18 23:33:33 --> Router Class Initialized
INFO - 2018-06-18 23:33:33 --> Output Class Initialized
INFO - 2018-06-18 23:33:33 --> Security Class Initialized
DEBUG - 2018-06-18 23:33:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 23:33:33 --> Input Class Initialized
INFO - 2018-06-18 23:33:33 --> Language Class Initialized
INFO - 2018-06-18 23:33:33 --> Language Class Initialized
INFO - 2018-06-18 23:33:33 --> Config Class Initialized
INFO - 2018-06-18 23:33:33 --> Loader Class Initialized
DEBUG - 2018-06-18 23:33:33 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-18 23:33:33 --> Helper loaded: url_helper
INFO - 2018-06-18 23:33:33 --> Helper loaded: form_helper
INFO - 2018-06-18 23:33:33 --> Helper loaded: date_helper
INFO - 2018-06-18 23:33:33 --> Helper loaded: util_helper
INFO - 2018-06-18 23:33:33 --> Helper loaded: text_helper
INFO - 2018-06-18 23:33:33 --> Helper loaded: string_helper
INFO - 2018-06-18 23:33:33 --> Database Driver Class Initialized
DEBUG - 2018-06-18 23:33:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 23:33:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 23:33:33 --> Email Class Initialized
INFO - 2018-06-18 23:33:33 --> Controller Class Initialized
DEBUG - 2018-06-18 23:33:33 --> videos MX_Controller Initialized
INFO - 2018-06-18 23:33:33 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-18 23:33:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-06-18 23:33:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-18 23:33:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-18 23:33:33 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-18 23:33:33 --> Login MX_Controller Initialized
DEBUG - 2018-06-18 23:33:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-18 23:34:54 --> Config Class Initialized
INFO - 2018-06-18 23:34:54 --> Hooks Class Initialized
DEBUG - 2018-06-18 23:34:54 --> UTF-8 Support Enabled
INFO - 2018-06-18 23:34:54 --> Utf8 Class Initialized
INFO - 2018-06-18 23:34:54 --> URI Class Initialized
INFO - 2018-06-18 23:34:54 --> Router Class Initialized
INFO - 2018-06-18 23:34:54 --> Output Class Initialized
INFO - 2018-06-18 23:34:54 --> Security Class Initialized
DEBUG - 2018-06-18 23:34:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 23:34:54 --> Input Class Initialized
INFO - 2018-06-18 23:34:54 --> Language Class Initialized
INFO - 2018-06-18 23:34:54 --> Language Class Initialized
INFO - 2018-06-18 23:34:54 --> Config Class Initialized
INFO - 2018-06-18 23:34:54 --> Loader Class Initialized
DEBUG - 2018-06-18 23:34:54 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-18 23:34:54 --> Helper loaded: url_helper
INFO - 2018-06-18 23:34:54 --> Helper loaded: form_helper
INFO - 2018-06-18 23:34:54 --> Helper loaded: date_helper
INFO - 2018-06-18 23:34:54 --> Helper loaded: util_helper
INFO - 2018-06-18 23:34:54 --> Helper loaded: text_helper
INFO - 2018-06-18 23:34:54 --> Helper loaded: string_helper
INFO - 2018-06-18 23:34:54 --> Database Driver Class Initialized
DEBUG - 2018-06-18 23:34:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 23:34:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 23:34:54 --> Email Class Initialized
INFO - 2018-06-18 23:34:54 --> Controller Class Initialized
DEBUG - 2018-06-18 23:34:54 --> videos MX_Controller Initialized
INFO - 2018-06-18 23:34:54 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-18 23:34:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-06-18 23:34:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-18 23:34:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-18 23:34:54 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-18 23:34:54 --> Login MX_Controller Initialized
DEBUG - 2018-06-18 23:34:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-18 23:34:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-18 23:34:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-18 23:34:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-18 23:34:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-18 23:34:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-18 23:34:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/videos/create_video.php
INFO - 2018-06-18 23:34:54 --> Final output sent to browser
DEBUG - 2018-06-18 23:34:54 --> Total execution time: 0.6027
INFO - 2018-06-18 23:34:55 --> Config Class Initialized
INFO - 2018-06-18 23:34:55 --> Hooks Class Initialized
DEBUG - 2018-06-18 23:34:55 --> UTF-8 Support Enabled
INFO - 2018-06-18 23:34:55 --> Utf8 Class Initialized
INFO - 2018-06-18 23:34:55 --> Config Class Initialized
INFO - 2018-06-18 23:34:55 --> Hooks Class Initialized
INFO - 2018-06-18 23:34:55 --> URI Class Initialized
DEBUG - 2018-06-18 23:34:55 --> UTF-8 Support Enabled
INFO - 2018-06-18 23:34:55 --> Utf8 Class Initialized
INFO - 2018-06-18 23:34:55 --> URI Class Initialized
INFO - 2018-06-18 23:34:55 --> Router Class Initialized
INFO - 2018-06-18 23:34:55 --> Router Class Initialized
INFO - 2018-06-18 23:34:55 --> Output Class Initialized
INFO - 2018-06-18 23:34:55 --> Security Class Initialized
INFO - 2018-06-18 23:34:55 --> Output Class Initialized
DEBUG - 2018-06-18 23:34:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 23:34:55 --> Security Class Initialized
DEBUG - 2018-06-18 23:34:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 23:34:55 --> Input Class Initialized
INFO - 2018-06-18 23:34:55 --> Language Class Initialized
ERROR - 2018-06-18 23:34:55 --> 404 Page Not Found: /index
INFO - 2018-06-18 23:34:55 --> Input Class Initialized
INFO - 2018-06-18 23:34:55 --> Language Class Initialized
ERROR - 2018-06-18 23:34:56 --> 404 Page Not Found: /index
INFO - 2018-06-18 23:35:14 --> Config Class Initialized
INFO - 2018-06-18 23:35:14 --> Hooks Class Initialized
DEBUG - 2018-06-18 23:35:14 --> UTF-8 Support Enabled
INFO - 2018-06-18 23:35:14 --> Utf8 Class Initialized
INFO - 2018-06-18 23:35:14 --> URI Class Initialized
INFO - 2018-06-18 23:35:14 --> Router Class Initialized
INFO - 2018-06-18 23:35:14 --> Output Class Initialized
INFO - 2018-06-18 23:35:14 --> Security Class Initialized
DEBUG - 2018-06-18 23:35:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-18 23:35:14 --> Input Class Initialized
INFO - 2018-06-18 23:35:14 --> Language Class Initialized
INFO - 2018-06-18 23:35:14 --> Language Class Initialized
INFO - 2018-06-18 23:35:14 --> Config Class Initialized
INFO - 2018-06-18 23:35:14 --> Loader Class Initialized
DEBUG - 2018-06-18 23:35:14 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-18 23:35:14 --> Helper loaded: url_helper
INFO - 2018-06-18 23:35:14 --> Helper loaded: form_helper
INFO - 2018-06-18 23:35:14 --> Helper loaded: date_helper
INFO - 2018-06-18 23:35:14 --> Helper loaded: util_helper
INFO - 2018-06-18 23:35:14 --> Helper loaded: text_helper
INFO - 2018-06-18 23:35:14 --> Helper loaded: string_helper
INFO - 2018-06-18 23:35:14 --> Database Driver Class Initialized
DEBUG - 2018-06-18 23:35:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-18 23:35:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-18 23:35:14 --> Email Class Initialized
INFO - 2018-06-18 23:35:14 --> Controller Class Initialized
DEBUG - 2018-06-18 23:35:14 --> videos MX_Controller Initialized
INFO - 2018-06-18 23:35:14 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-18 23:35:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-06-18 23:35:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-18 23:35:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-18 23:35:14 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-18 23:35:14 --> Login MX_Controller Initialized
DEBUG - 2018-06-18 23:35:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
