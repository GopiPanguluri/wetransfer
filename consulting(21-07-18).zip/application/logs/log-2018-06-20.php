<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-06-20 01:29:19 --> Config Class Initialized
INFO - 2018-06-20 01:29:19 --> Hooks Class Initialized
DEBUG - 2018-06-20 01:29:19 --> UTF-8 Support Enabled
INFO - 2018-06-20 01:29:19 --> Utf8 Class Initialized
INFO - 2018-06-20 01:29:19 --> URI Class Initialized
INFO - 2018-06-20 01:29:19 --> Router Class Initialized
INFO - 2018-06-20 01:29:19 --> Output Class Initialized
INFO - 2018-06-20 01:29:19 --> Security Class Initialized
DEBUG - 2018-06-20 01:29:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 01:29:19 --> Input Class Initialized
INFO - 2018-06-20 01:29:19 --> Language Class Initialized
INFO - 2018-06-20 01:29:19 --> Language Class Initialized
INFO - 2018-06-20 01:29:19 --> Config Class Initialized
INFO - 2018-06-20 01:29:19 --> Loader Class Initialized
DEBUG - 2018-06-20 01:29:19 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-20 01:29:19 --> Helper loaded: url_helper
INFO - 2018-06-20 01:29:19 --> Helper loaded: form_helper
INFO - 2018-06-20 01:29:19 --> Helper loaded: date_helper
INFO - 2018-06-20 01:29:19 --> Helper loaded: util_helper
INFO - 2018-06-20 01:29:19 --> Helper loaded: text_helper
INFO - 2018-06-20 01:29:19 --> Helper loaded: string_helper
INFO - 2018-06-20 01:29:19 --> Database Driver Class Initialized
DEBUG - 2018-06-20 01:29:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 01:29:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 01:29:19 --> Email Class Initialized
INFO - 2018-06-20 01:29:19 --> Controller Class Initialized
DEBUG - 2018-06-20 01:29:19 --> Login MX_Controller Initialized
INFO - 2018-06-20 01:29:19 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-20 01:29:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-20 01:29:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-20 01:29:20 --> Email starts for user@colin.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-06-20 01:29:20 --> User session created for 4
INFO - 2018-06-20 01:29:20 --> Login status user@colin.com - success
INFO - 2018-06-20 01:29:20 --> Final output sent to browser
DEBUG - 2018-06-20 01:29:20 --> Total execution time: 0.4141
INFO - 2018-06-20 01:29:20 --> Config Class Initialized
INFO - 2018-06-20 01:29:20 --> Hooks Class Initialized
DEBUG - 2018-06-20 01:29:20 --> UTF-8 Support Enabled
INFO - 2018-06-20 01:29:20 --> Utf8 Class Initialized
INFO - 2018-06-20 01:29:20 --> URI Class Initialized
INFO - 2018-06-20 01:29:20 --> Router Class Initialized
INFO - 2018-06-20 01:29:20 --> Output Class Initialized
INFO - 2018-06-20 01:29:20 --> Security Class Initialized
DEBUG - 2018-06-20 01:29:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 01:29:20 --> Input Class Initialized
INFO - 2018-06-20 01:29:20 --> Language Class Initialized
INFO - 2018-06-20 01:29:20 --> Language Class Initialized
INFO - 2018-06-20 01:29:20 --> Config Class Initialized
INFO - 2018-06-20 01:29:20 --> Loader Class Initialized
DEBUG - 2018-06-20 01:29:20 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-20 01:29:20 --> Helper loaded: url_helper
INFO - 2018-06-20 01:29:20 --> Helper loaded: form_helper
INFO - 2018-06-20 01:29:20 --> Helper loaded: date_helper
INFO - 2018-06-20 01:29:20 --> Helper loaded: util_helper
INFO - 2018-06-20 01:29:20 --> Helper loaded: text_helper
INFO - 2018-06-20 01:29:20 --> Helper loaded: string_helper
INFO - 2018-06-20 01:29:20 --> Database Driver Class Initialized
DEBUG - 2018-06-20 01:29:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 01:29:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 01:29:20 --> Email Class Initialized
INFO - 2018-06-20 01:29:20 --> Controller Class Initialized
DEBUG - 2018-06-20 01:29:20 --> Home MX_Controller Initialized
DEBUG - 2018-06-20 01:29:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-20 01:29:20 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-20 01:29:20 --> Login MX_Controller Initialized
INFO - 2018-06-20 01:29:20 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-20 01:29:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-20 01:29:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-20 01:29:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-20 01:29:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-20 01:29:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-20 01:29:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-20 01:29:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-20 01:29:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-06-20 01:29:20 --> Final output sent to browser
DEBUG - 2018-06-20 01:29:20 --> Total execution time: 0.4075
INFO - 2018-06-20 01:29:21 --> Config Class Initialized
INFO - 2018-06-20 01:29:21 --> Hooks Class Initialized
DEBUG - 2018-06-20 01:29:21 --> UTF-8 Support Enabled
INFO - 2018-06-20 01:29:21 --> Config Class Initialized
INFO - 2018-06-20 01:29:21 --> Hooks Class Initialized
INFO - 2018-06-20 01:29:21 --> Utf8 Class Initialized
INFO - 2018-06-20 01:29:21 --> URI Class Initialized
DEBUG - 2018-06-20 01:29:21 --> UTF-8 Support Enabled
INFO - 2018-06-20 01:29:21 --> Router Class Initialized
INFO - 2018-06-20 01:29:21 --> Output Class Initialized
INFO - 2018-06-20 01:29:21 --> Security Class Initialized
DEBUG - 2018-06-20 01:29:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 01:29:21 --> Input Class Initialized
INFO - 2018-06-20 01:29:21 --> Language Class Initialized
ERROR - 2018-06-20 01:29:21 --> 404 Page Not Found: /index
INFO - 2018-06-20 01:29:21 --> Utf8 Class Initialized
INFO - 2018-06-20 01:29:21 --> URI Class Initialized
INFO - 2018-06-20 01:29:21 --> Router Class Initialized
INFO - 2018-06-20 01:29:21 --> Output Class Initialized
INFO - 2018-06-20 01:29:21 --> Security Class Initialized
DEBUG - 2018-06-20 01:29:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 01:29:21 --> Input Class Initialized
INFO - 2018-06-20 01:29:21 --> Language Class Initialized
ERROR - 2018-06-20 01:29:21 --> 404 Page Not Found: /index
INFO - 2018-06-20 01:29:21 --> Config Class Initialized
INFO - 2018-06-20 01:29:21 --> Hooks Class Initialized
DEBUG - 2018-06-20 01:29:21 --> UTF-8 Support Enabled
INFO - 2018-06-20 01:29:21 --> Utf8 Class Initialized
INFO - 2018-06-20 01:29:21 --> URI Class Initialized
INFO - 2018-06-20 01:29:21 --> Router Class Initialized
INFO - 2018-06-20 01:29:21 --> Output Class Initialized
INFO - 2018-06-20 01:29:21 --> Security Class Initialized
DEBUG - 2018-06-20 01:29:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 01:29:21 --> Input Class Initialized
INFO - 2018-06-20 01:29:21 --> Language Class Initialized
ERROR - 2018-06-20 01:29:21 --> 404 Page Not Found: /index
INFO - 2018-06-20 01:29:21 --> Config Class Initialized
INFO - 2018-06-20 01:29:21 --> Hooks Class Initialized
DEBUG - 2018-06-20 01:29:21 --> UTF-8 Support Enabled
INFO - 2018-06-20 01:29:21 --> Utf8 Class Initialized
INFO - 2018-06-20 01:29:21 --> URI Class Initialized
INFO - 2018-06-20 01:29:21 --> Router Class Initialized
INFO - 2018-06-20 01:29:21 --> Output Class Initialized
INFO - 2018-06-20 01:29:21 --> Security Class Initialized
DEBUG - 2018-06-20 01:29:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 01:29:21 --> Input Class Initialized
INFO - 2018-06-20 01:29:21 --> Language Class Initialized
ERROR - 2018-06-20 01:29:21 --> 404 Page Not Found: /index
INFO - 2018-06-20 01:29:21 --> Config Class Initialized
INFO - 2018-06-20 01:29:21 --> Hooks Class Initialized
DEBUG - 2018-06-20 01:29:22 --> UTF-8 Support Enabled
INFO - 2018-06-20 01:29:22 --> Utf8 Class Initialized
INFO - 2018-06-20 01:29:22 --> URI Class Initialized
INFO - 2018-06-20 01:29:22 --> Router Class Initialized
INFO - 2018-06-20 01:29:22 --> Output Class Initialized
INFO - 2018-06-20 01:29:22 --> Security Class Initialized
DEBUG - 2018-06-20 01:29:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 01:29:22 --> Input Class Initialized
INFO - 2018-06-20 01:29:22 --> Language Class Initialized
ERROR - 2018-06-20 01:29:22 --> 404 Page Not Found: /index
INFO - 2018-06-20 01:29:22 --> Config Class Initialized
INFO - 2018-06-20 01:29:22 --> Hooks Class Initialized
DEBUG - 2018-06-20 01:29:22 --> UTF-8 Support Enabled
INFO - 2018-06-20 01:29:22 --> Utf8 Class Initialized
INFO - 2018-06-20 01:29:22 --> URI Class Initialized
INFO - 2018-06-20 01:29:22 --> Router Class Initialized
INFO - 2018-06-20 01:29:22 --> Output Class Initialized
INFO - 2018-06-20 01:29:22 --> Security Class Initialized
DEBUG - 2018-06-20 01:29:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 01:29:22 --> Input Class Initialized
INFO - 2018-06-20 01:29:22 --> Language Class Initialized
ERROR - 2018-06-20 01:29:22 --> 404 Page Not Found: /index
INFO - 2018-06-20 01:29:22 --> Config Class Initialized
INFO - 2018-06-20 01:29:22 --> Hooks Class Initialized
DEBUG - 2018-06-20 01:29:22 --> UTF-8 Support Enabled
INFO - 2018-06-20 01:29:22 --> Utf8 Class Initialized
INFO - 2018-06-20 01:29:22 --> URI Class Initialized
INFO - 2018-06-20 01:29:22 --> Router Class Initialized
INFO - 2018-06-20 01:29:22 --> Output Class Initialized
INFO - 2018-06-20 01:29:22 --> Security Class Initialized
DEBUG - 2018-06-20 01:29:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 01:29:22 --> Input Class Initialized
INFO - 2018-06-20 01:29:22 --> Language Class Initialized
ERROR - 2018-06-20 01:29:22 --> 404 Page Not Found: /index
INFO - 2018-06-20 01:29:22 --> Config Class Initialized
INFO - 2018-06-20 01:29:22 --> Hooks Class Initialized
DEBUG - 2018-06-20 01:29:22 --> UTF-8 Support Enabled
INFO - 2018-06-20 01:29:22 --> Utf8 Class Initialized
INFO - 2018-06-20 01:29:22 --> URI Class Initialized
INFO - 2018-06-20 01:29:22 --> Router Class Initialized
INFO - 2018-06-20 01:29:22 --> Output Class Initialized
INFO - 2018-06-20 01:29:22 --> Security Class Initialized
DEBUG - 2018-06-20 01:29:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 01:29:22 --> Input Class Initialized
INFO - 2018-06-20 01:29:22 --> Language Class Initialized
INFO - 2018-06-20 01:29:22 --> Language Class Initialized
INFO - 2018-06-20 01:29:22 --> Config Class Initialized
INFO - 2018-06-20 01:29:22 --> Loader Class Initialized
DEBUG - 2018-06-20 01:29:22 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-20 01:29:22 --> Helper loaded: url_helper
INFO - 2018-06-20 01:29:22 --> Helper loaded: form_helper
INFO - 2018-06-20 01:29:22 --> Helper loaded: date_helper
INFO - 2018-06-20 01:29:22 --> Helper loaded: util_helper
INFO - 2018-06-20 01:29:22 --> Helper loaded: text_helper
INFO - 2018-06-20 01:29:22 --> Helper loaded: string_helper
INFO - 2018-06-20 01:29:22 --> Database Driver Class Initialized
DEBUG - 2018-06-20 01:29:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 01:29:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 01:29:22 --> Email Class Initialized
INFO - 2018-06-20 01:29:23 --> Controller Class Initialized
DEBUG - 2018-06-20 01:29:23 --> Home MX_Controller Initialized
DEBUG - 2018-06-20 01:29:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-20 01:29:23 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-20 01:29:23 --> Login MX_Controller Initialized
INFO - 2018-06-20 01:29:23 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-20 01:29:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-20 01:29:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-20 01:29:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-20 01:29:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-20 01:29:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-20 01:29:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-20 01:29:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-20 01:29:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-06-20 01:29:23 --> Final output sent to browser
DEBUG - 2018-06-20 01:29:23 --> Total execution time: 0.4135
INFO - 2018-06-20 01:29:27 --> Config Class Initialized
INFO - 2018-06-20 01:29:27 --> Hooks Class Initialized
DEBUG - 2018-06-20 01:29:27 --> UTF-8 Support Enabled
INFO - 2018-06-20 01:29:27 --> Utf8 Class Initialized
INFO - 2018-06-20 01:29:27 --> URI Class Initialized
INFO - 2018-06-20 01:29:27 --> Router Class Initialized
INFO - 2018-06-20 01:29:27 --> Output Class Initialized
INFO - 2018-06-20 01:29:27 --> Security Class Initialized
DEBUG - 2018-06-20 01:29:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 01:29:27 --> Input Class Initialized
INFO - 2018-06-20 01:29:27 --> Language Class Initialized
INFO - 2018-06-20 01:29:27 --> Language Class Initialized
INFO - 2018-06-20 01:29:27 --> Config Class Initialized
INFO - 2018-06-20 01:29:27 --> Loader Class Initialized
DEBUG - 2018-06-20 01:29:27 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-20 01:29:27 --> Helper loaded: url_helper
INFO - 2018-06-20 01:29:27 --> Helper loaded: form_helper
INFO - 2018-06-20 01:29:27 --> Helper loaded: date_helper
INFO - 2018-06-20 01:29:27 --> Helper loaded: util_helper
INFO - 2018-06-20 01:29:27 --> Helper loaded: text_helper
INFO - 2018-06-20 01:29:27 --> Helper loaded: string_helper
INFO - 2018-06-20 01:29:27 --> Database Driver Class Initialized
DEBUG - 2018-06-20 01:29:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 01:29:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 01:29:27 --> Email Class Initialized
INFO - 2018-06-20 01:29:27 --> Controller Class Initialized
DEBUG - 2018-06-20 01:29:27 --> Home MX_Controller Initialized
DEBUG - 2018-06-20 01:29:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-20 01:29:27 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-20 01:29:27 --> Login MX_Controller Initialized
INFO - 2018-06-20 01:29:27 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-20 01:29:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-20 01:29:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-20 01:29:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-20 01:29:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-20 01:29:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-20 01:29:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-20 01:29:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-20 01:29:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-06-20 01:29:28 --> Final output sent to browser
DEBUG - 2018-06-20 01:29:28 --> Total execution time: 0.3960
INFO - 2018-06-20 01:29:28 --> Config Class Initialized
INFO - 2018-06-20 01:29:28 --> Hooks Class Initialized
INFO - 2018-06-20 01:29:28 --> Config Class Initialized
INFO - 2018-06-20 01:29:28 --> Hooks Class Initialized
DEBUG - 2018-06-20 01:29:28 --> UTF-8 Support Enabled
INFO - 2018-06-20 01:29:28 --> Utf8 Class Initialized
DEBUG - 2018-06-20 01:29:28 --> UTF-8 Support Enabled
INFO - 2018-06-20 01:29:28 --> URI Class Initialized
INFO - 2018-06-20 01:29:28 --> Utf8 Class Initialized
INFO - 2018-06-20 01:29:28 --> URI Class Initialized
INFO - 2018-06-20 01:29:28 --> Router Class Initialized
INFO - 2018-06-20 01:29:28 --> Output Class Initialized
INFO - 2018-06-20 01:29:28 --> Router Class Initialized
INFO - 2018-06-20 01:29:28 --> Security Class Initialized
DEBUG - 2018-06-20 01:29:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 01:29:28 --> Output Class Initialized
INFO - 2018-06-20 01:29:28 --> Input Class Initialized
INFO - 2018-06-20 01:29:28 --> Security Class Initialized
INFO - 2018-06-20 01:29:28 --> Language Class Initialized
DEBUG - 2018-06-20 01:29:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-06-20 01:29:28 --> 404 Page Not Found: /index
INFO - 2018-06-20 01:29:28 --> Input Class Initialized
INFO - 2018-06-20 01:29:28 --> Language Class Initialized
ERROR - 2018-06-20 01:29:28 --> 404 Page Not Found: /index
INFO - 2018-06-20 01:29:28 --> Config Class Initialized
INFO - 2018-06-20 01:29:28 --> Hooks Class Initialized
DEBUG - 2018-06-20 01:29:28 --> UTF-8 Support Enabled
INFO - 2018-06-20 01:29:28 --> Utf8 Class Initialized
INFO - 2018-06-20 01:29:28 --> URI Class Initialized
INFO - 2018-06-20 01:29:28 --> Router Class Initialized
INFO - 2018-06-20 01:29:28 --> Output Class Initialized
INFO - 2018-06-20 01:29:28 --> Security Class Initialized
DEBUG - 2018-06-20 01:29:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 01:29:28 --> Input Class Initialized
INFO - 2018-06-20 01:29:28 --> Language Class Initialized
ERROR - 2018-06-20 01:29:28 --> 404 Page Not Found: /index
INFO - 2018-06-20 01:29:29 --> Config Class Initialized
INFO - 2018-06-20 01:29:29 --> Hooks Class Initialized
DEBUG - 2018-06-20 01:29:29 --> UTF-8 Support Enabled
INFO - 2018-06-20 01:29:29 --> Utf8 Class Initialized
INFO - 2018-06-20 01:29:29 --> URI Class Initialized
INFO - 2018-06-20 01:29:29 --> Router Class Initialized
INFO - 2018-06-20 01:29:29 --> Output Class Initialized
INFO - 2018-06-20 01:29:29 --> Security Class Initialized
DEBUG - 2018-06-20 01:29:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 01:29:29 --> Input Class Initialized
INFO - 2018-06-20 01:29:29 --> Language Class Initialized
ERROR - 2018-06-20 01:29:29 --> 404 Page Not Found: /index
INFO - 2018-06-20 01:29:33 --> Config Class Initialized
INFO - 2018-06-20 01:29:33 --> Hooks Class Initialized
DEBUG - 2018-06-20 01:29:33 --> UTF-8 Support Enabled
INFO - 2018-06-20 01:29:33 --> Utf8 Class Initialized
INFO - 2018-06-20 01:29:33 --> URI Class Initialized
INFO - 2018-06-20 01:29:33 --> Router Class Initialized
INFO - 2018-06-20 01:29:33 --> Config Class Initialized
INFO - 2018-06-20 01:29:33 --> Output Class Initialized
INFO - 2018-06-20 01:29:33 --> Hooks Class Initialized
INFO - 2018-06-20 01:29:33 --> Security Class Initialized
DEBUG - 2018-06-20 01:29:33 --> UTF-8 Support Enabled
DEBUG - 2018-06-20 01:29:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 01:29:33 --> Utf8 Class Initialized
INFO - 2018-06-20 01:29:33 --> URI Class Initialized
INFO - 2018-06-20 01:29:34 --> Router Class Initialized
INFO - 2018-06-20 01:29:34 --> Output Class Initialized
INFO - 2018-06-20 01:29:34 --> Security Class Initialized
DEBUG - 2018-06-20 01:29:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 01:29:34 --> Input Class Initialized
INFO - 2018-06-20 01:29:34 --> Language Class Initialized
INFO - 2018-06-20 01:29:34 --> Input Class Initialized
INFO - 2018-06-20 01:29:34 --> Language Class Initialized
INFO - 2018-06-20 01:29:34 --> Config Class Initialized
INFO - 2018-06-20 01:29:34 --> Language Class Initialized
INFO - 2018-06-20 01:29:34 --> Loader Class Initialized
INFO - 2018-06-20 01:29:34 --> Language Class Initialized
DEBUG - 2018-06-20 01:29:34 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-20 01:29:34 --> Config Class Initialized
INFO - 2018-06-20 01:29:34 --> Helper loaded: url_helper
INFO - 2018-06-20 01:29:34 --> Helper loaded: form_helper
INFO - 2018-06-20 01:29:34 --> Helper loaded: date_helper
INFO - 2018-06-20 01:29:34 --> Helper loaded: util_helper
INFO - 2018-06-20 01:29:34 --> Helper loaded: text_helper
INFO - 2018-06-20 01:29:34 --> Helper loaded: string_helper
INFO - 2018-06-20 01:29:34 --> Loader Class Initialized
INFO - 2018-06-20 01:29:34 --> Database Driver Class Initialized
DEBUG - 2018-06-20 01:29:34 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
DEBUG - 2018-06-20 01:29:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 01:29:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 01:29:34 --> Helper loaded: url_helper
INFO - 2018-06-20 01:29:34 --> Email Class Initialized
INFO - 2018-06-20 01:29:34 --> Helper loaded: form_helper
INFO - 2018-06-20 01:29:34 --> Controller Class Initialized
DEBUG - 2018-06-20 01:29:34 --> Home MX_Controller Initialized
INFO - 2018-06-20 01:29:34 --> Helper loaded: date_helper
INFO - 2018-06-20 01:29:34 --> Helper loaded: util_helper
DEBUG - 2018-06-20 01:29:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-06-20 01:29:34 --> Helper loaded: text_helper
DEBUG - 2018-06-20 01:29:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-06-20 01:29:34 --> Helper loaded: string_helper
INFO - 2018-06-20 01:29:34 --> Final output sent to browser
DEBUG - 2018-06-20 01:29:34 --> Total execution time: 0.2745
INFO - 2018-06-20 01:29:34 --> Database Driver Class Initialized
DEBUG - 2018-06-20 01:29:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 01:29:34 --> Config Class Initialized
INFO - 2018-06-20 01:29:34 --> Hooks Class Initialized
INFO - 2018-06-20 01:29:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 01:29:34 --> Email Class Initialized
DEBUG - 2018-06-20 01:29:34 --> UTF-8 Support Enabled
INFO - 2018-06-20 01:29:34 --> Utf8 Class Initialized
INFO - 2018-06-20 01:29:34 --> Controller Class Initialized
DEBUG - 2018-06-20 01:29:34 --> Home MX_Controller Initialized
INFO - 2018-06-20 01:29:34 --> URI Class Initialized
DEBUG - 2018-06-20 01:29:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-06-20 01:29:34 --> Router Class Initialized
INFO - 2018-06-20 01:29:34 --> Output Class Initialized
DEBUG - 2018-06-20 01:29:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-06-20 01:29:34 --> Security Class Initialized
DEBUG - 2018-06-20 01:29:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 01:29:34 --> Input Class Initialized
INFO - 2018-06-20 01:29:34 --> Language Class Initialized
INFO - 2018-06-20 01:29:34 --> Language Class Initialized
INFO - 2018-06-20 01:29:34 --> Final output sent to browser
DEBUG - 2018-06-20 01:29:34 --> Total execution time: 0.4698
INFO - 2018-06-20 01:29:34 --> Config Class Initialized
INFO - 2018-06-20 01:29:34 --> Loader Class Initialized
INFO - 2018-06-20 01:29:34 --> Config Class Initialized
INFO - 2018-06-20 01:29:34 --> Hooks Class Initialized
DEBUG - 2018-06-20 01:29:34 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-20 01:29:34 --> Helper loaded: url_helper
DEBUG - 2018-06-20 01:29:34 --> UTF-8 Support Enabled
INFO - 2018-06-20 01:29:34 --> Utf8 Class Initialized
INFO - 2018-06-20 01:29:34 --> Helper loaded: form_helper
INFO - 2018-06-20 01:29:34 --> URI Class Initialized
INFO - 2018-06-20 01:29:34 --> Helper loaded: date_helper
INFO - 2018-06-20 01:29:34 --> Helper loaded: util_helper
INFO - 2018-06-20 01:29:34 --> Router Class Initialized
INFO - 2018-06-20 01:29:34 --> Output Class Initialized
INFO - 2018-06-20 01:29:34 --> Helper loaded: text_helper
INFO - 2018-06-20 01:29:34 --> Helper loaded: string_helper
INFO - 2018-06-20 01:29:34 --> Security Class Initialized
DEBUG - 2018-06-20 01:29:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 01:29:34 --> Database Driver Class Initialized
INFO - 2018-06-20 01:29:34 --> Input Class Initialized
DEBUG - 2018-06-20 01:29:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 01:29:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 01:29:34 --> Language Class Initialized
INFO - 2018-06-20 01:29:34 --> Language Class Initialized
INFO - 2018-06-20 01:29:34 --> Email Class Initialized
INFO - 2018-06-20 01:29:34 --> Config Class Initialized
INFO - 2018-06-20 01:29:34 --> Controller Class Initialized
DEBUG - 2018-06-20 01:29:34 --> Home MX_Controller Initialized
INFO - 2018-06-20 01:29:34 --> Loader Class Initialized
DEBUG - 2018-06-20 01:29:34 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
DEBUG - 2018-06-20 01:29:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-06-20 01:29:34 --> Helper loaded: url_helper
INFO - 2018-06-20 01:29:34 --> Helper loaded: form_helper
INFO - 2018-06-20 01:29:34 --> Helper loaded: date_helper
INFO - 2018-06-20 01:29:34 --> Helper loaded: util_helper
INFO - 2018-06-20 01:29:34 --> Helper loaded: text_helper
INFO - 2018-06-20 01:29:34 --> Helper loaded: string_helper
INFO - 2018-06-20 01:29:34 --> Database Driver Class Initialized
DEBUG - 2018-06-20 01:29:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 01:29:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 01:29:34 --> Email Class Initialized
INFO - 2018-06-20 01:29:34 --> Controller Class Initialized
DEBUG - 2018-06-20 01:29:34 --> Home MX_Controller Initialized
DEBUG - 2018-06-20 01:29:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-06-20 01:29:36 --> Config Class Initialized
INFO - 2018-06-20 01:29:36 --> Hooks Class Initialized
DEBUG - 2018-06-20 01:29:36 --> UTF-8 Support Enabled
INFO - 2018-06-20 01:29:36 --> Utf8 Class Initialized
INFO - 2018-06-20 01:29:36 --> URI Class Initialized
INFO - 2018-06-20 01:29:36 --> Router Class Initialized
INFO - 2018-06-20 01:29:36 --> Output Class Initialized
INFO - 2018-06-20 01:29:36 --> Security Class Initialized
DEBUG - 2018-06-20 01:29:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 01:29:36 --> Input Class Initialized
INFO - 2018-06-20 01:29:36 --> Language Class Initialized
INFO - 2018-06-20 01:29:36 --> Language Class Initialized
INFO - 2018-06-20 01:29:36 --> Config Class Initialized
INFO - 2018-06-20 01:29:36 --> Loader Class Initialized
DEBUG - 2018-06-20 01:29:36 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-20 01:29:36 --> Helper loaded: url_helper
INFO - 2018-06-20 01:29:36 --> Helper loaded: form_helper
INFO - 2018-06-20 01:29:36 --> Helper loaded: date_helper
INFO - 2018-06-20 01:29:36 --> Helper loaded: util_helper
INFO - 2018-06-20 01:29:36 --> Helper loaded: text_helper
INFO - 2018-06-20 01:29:36 --> Helper loaded: string_helper
INFO - 2018-06-20 01:29:36 --> Database Driver Class Initialized
DEBUG - 2018-06-20 01:29:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 01:29:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 01:29:36 --> Email Class Initialized
INFO - 2018-06-20 01:29:36 --> Controller Class Initialized
DEBUG - 2018-06-20 01:29:36 --> Home MX_Controller Initialized
DEBUG - 2018-06-20 01:29:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-20 01:29:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-06-20 01:29:36 --> Final output sent to browser
DEBUG - 2018-06-20 01:29:36 --> Total execution time: 0.2935
INFO - 2018-06-20 01:29:36 --> Config Class Initialized
INFO - 2018-06-20 01:29:36 --> Hooks Class Initialized
DEBUG - 2018-06-20 01:29:36 --> UTF-8 Support Enabled
INFO - 2018-06-20 01:29:36 --> Utf8 Class Initialized
INFO - 2018-06-20 01:29:36 --> URI Class Initialized
INFO - 2018-06-20 01:29:36 --> Router Class Initialized
INFO - 2018-06-20 01:29:36 --> Output Class Initialized
INFO - 2018-06-20 01:29:36 --> Security Class Initialized
DEBUG - 2018-06-20 01:29:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 01:29:36 --> Input Class Initialized
INFO - 2018-06-20 01:29:36 --> Language Class Initialized
INFO - 2018-06-20 01:29:36 --> Language Class Initialized
INFO - 2018-06-20 01:29:36 --> Config Class Initialized
INFO - 2018-06-20 01:29:36 --> Loader Class Initialized
DEBUG - 2018-06-20 01:29:36 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-20 01:29:36 --> Helper loaded: url_helper
INFO - 2018-06-20 01:29:36 --> Helper loaded: form_helper
INFO - 2018-06-20 01:29:36 --> Helper loaded: date_helper
INFO - 2018-06-20 01:29:36 --> Helper loaded: util_helper
INFO - 2018-06-20 01:29:36 --> Helper loaded: text_helper
INFO - 2018-06-20 01:29:36 --> Helper loaded: string_helper
INFO - 2018-06-20 01:29:36 --> Database Driver Class Initialized
DEBUG - 2018-06-20 01:29:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 01:29:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 01:29:36 --> Email Class Initialized
INFO - 2018-06-20 01:29:36 --> Controller Class Initialized
DEBUG - 2018-06-20 01:29:36 --> Home MX_Controller Initialized
DEBUG - 2018-06-20 01:29:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-06-20 01:29:39 --> Config Class Initialized
INFO - 2018-06-20 01:29:39 --> Hooks Class Initialized
DEBUG - 2018-06-20 01:29:39 --> UTF-8 Support Enabled
INFO - 2018-06-20 01:29:39 --> Utf8 Class Initialized
INFO - 2018-06-20 01:29:39 --> URI Class Initialized
INFO - 2018-06-20 01:29:39 --> Config Class Initialized
INFO - 2018-06-20 01:29:39 --> Hooks Class Initialized
INFO - 2018-06-20 01:29:39 --> Router Class Initialized
INFO - 2018-06-20 01:29:39 --> Output Class Initialized
DEBUG - 2018-06-20 01:29:39 --> UTF-8 Support Enabled
INFO - 2018-06-20 01:29:39 --> Utf8 Class Initialized
INFO - 2018-06-20 01:29:39 --> Security Class Initialized
DEBUG - 2018-06-20 01:29:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 01:29:39 --> URI Class Initialized
INFO - 2018-06-20 01:29:39 --> Input Class Initialized
INFO - 2018-06-20 01:29:39 --> Language Class Initialized
INFO - 2018-06-20 01:29:39 --> Language Class Initialized
INFO - 2018-06-20 01:29:39 --> Config Class Initialized
INFO - 2018-06-20 01:29:39 --> Loader Class Initialized
INFO - 2018-06-20 01:29:39 --> Router Class Initialized
DEBUG - 2018-06-20 01:29:39 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-20 01:29:39 --> Helper loaded: url_helper
INFO - 2018-06-20 01:29:39 --> Helper loaded: form_helper
INFO - 2018-06-20 01:29:39 --> Helper loaded: date_helper
INFO - 2018-06-20 01:29:39 --> Helper loaded: util_helper
INFO - 2018-06-20 01:29:39 --> Helper loaded: text_helper
INFO - 2018-06-20 01:29:39 --> Helper loaded: string_helper
INFO - 2018-06-20 01:29:39 --> Output Class Initialized
INFO - 2018-06-20 01:29:39 --> Database Driver Class Initialized
INFO - 2018-06-20 01:29:39 --> Security Class Initialized
DEBUG - 2018-06-20 01:29:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 01:29:39 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-06-20 01:29:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 01:29:39 --> Input Class Initialized
INFO - 2018-06-20 01:29:39 --> Email Class Initialized
INFO - 2018-06-20 01:29:39 --> Controller Class Initialized
INFO - 2018-06-20 01:29:39 --> Language Class Initialized
DEBUG - 2018-06-20 01:29:39 --> Home MX_Controller Initialized
INFO - 2018-06-20 01:29:39 --> Language Class Initialized
DEBUG - 2018-06-20 01:29:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-06-20 01:29:39 --> Config Class Initialized
INFO - 2018-06-20 01:29:39 --> Loader Class Initialized
DEBUG - 2018-06-20 01:29:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-20 01:29:39 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-20 01:29:39 --> Helper loaded: url_helper
INFO - 2018-06-20 01:29:39 --> Helper loaded: form_helper
INFO - 2018-06-20 01:29:39 --> Helper loaded: date_helper
INFO - 2018-06-20 01:29:39 --> Helper loaded: util_helper
INFO - 2018-06-20 01:29:39 --> Final output sent to browser
DEBUG - 2018-06-20 01:29:39 --> Total execution time: 0.3867
INFO - 2018-06-20 01:29:39 --> Helper loaded: text_helper
INFO - 2018-06-20 01:29:39 --> Helper loaded: string_helper
INFO - 2018-06-20 01:29:39 --> Config Class Initialized
INFO - 2018-06-20 01:29:39 --> Hooks Class Initialized
INFO - 2018-06-20 01:29:39 --> Database Driver Class Initialized
DEBUG - 2018-06-20 01:29:39 --> UTF-8 Support Enabled
DEBUG - 2018-06-20 01:29:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 01:29:39 --> Utf8 Class Initialized
INFO - 2018-06-20 01:29:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 01:29:39 --> URI Class Initialized
INFO - 2018-06-20 01:29:39 --> Email Class Initialized
INFO - 2018-06-20 01:29:39 --> Controller Class Initialized
INFO - 2018-06-20 01:29:39 --> Router Class Initialized
DEBUG - 2018-06-20 01:29:39 --> Home MX_Controller Initialized
INFO - 2018-06-20 01:29:39 --> Output Class Initialized
DEBUG - 2018-06-20 01:29:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-06-20 01:29:39 --> Security Class Initialized
DEBUG - 2018-06-20 01:29:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-06-20 01:29:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-06-20 01:29:39 --> Input Class Initialized
INFO - 2018-06-20 01:29:39 --> Language Class Initialized
INFO - 2018-06-20 01:29:39 --> Language Class Initialized
INFO - 2018-06-20 01:29:39 --> Config Class Initialized
INFO - 2018-06-20 01:29:39 --> Final output sent to browser
DEBUG - 2018-06-20 01:29:39 --> Total execution time: 0.4889
INFO - 2018-06-20 01:29:39 --> Loader Class Initialized
DEBUG - 2018-06-20 01:29:39 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-20 01:29:39 --> Config Class Initialized
INFO - 2018-06-20 01:29:39 --> Hooks Class Initialized
INFO - 2018-06-20 01:29:39 --> Helper loaded: url_helper
DEBUG - 2018-06-20 01:29:39 --> UTF-8 Support Enabled
INFO - 2018-06-20 01:29:39 --> Helper loaded: form_helper
INFO - 2018-06-20 01:29:39 --> Utf8 Class Initialized
INFO - 2018-06-20 01:29:39 --> Helper loaded: date_helper
INFO - 2018-06-20 01:29:39 --> URI Class Initialized
INFO - 2018-06-20 01:29:39 --> Helper loaded: util_helper
INFO - 2018-06-20 01:29:39 --> Router Class Initialized
INFO - 2018-06-20 01:29:39 --> Helper loaded: text_helper
INFO - 2018-06-20 01:29:39 --> Helper loaded: string_helper
INFO - 2018-06-20 01:29:39 --> Output Class Initialized
INFO - 2018-06-20 01:29:39 --> Security Class Initialized
INFO - 2018-06-20 01:29:40 --> Database Driver Class Initialized
DEBUG - 2018-06-20 01:29:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-06-20 01:29:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 01:29:40 --> Input Class Initialized
INFO - 2018-06-20 01:29:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 01:29:40 --> Language Class Initialized
INFO - 2018-06-20 01:29:40 --> Email Class Initialized
INFO - 2018-06-20 01:29:40 --> Controller Class Initialized
INFO - 2018-06-20 01:29:40 --> Language Class Initialized
DEBUG - 2018-06-20 01:29:40 --> Home MX_Controller Initialized
INFO - 2018-06-20 01:29:40 --> Config Class Initialized
DEBUG - 2018-06-20 01:29:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-06-20 01:29:40 --> Loader Class Initialized
DEBUG - 2018-06-20 01:29:40 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-20 01:29:40 --> Helper loaded: url_helper
INFO - 2018-06-20 01:29:40 --> Helper loaded: form_helper
INFO - 2018-06-20 01:29:40 --> Helper loaded: date_helper
INFO - 2018-06-20 01:29:40 --> Helper loaded: util_helper
INFO - 2018-06-20 01:29:40 --> Helper loaded: text_helper
INFO - 2018-06-20 01:29:40 --> Helper loaded: string_helper
INFO - 2018-06-20 01:29:40 --> Database Driver Class Initialized
DEBUG - 2018-06-20 01:29:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 01:29:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 01:29:40 --> Email Class Initialized
INFO - 2018-06-20 01:29:40 --> Controller Class Initialized
DEBUG - 2018-06-20 01:29:40 --> Home MX_Controller Initialized
DEBUG - 2018-06-20 01:29:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-06-20 02:09:09 --> Config Class Initialized
INFO - 2018-06-20 02:09:09 --> Hooks Class Initialized
DEBUG - 2018-06-20 02:09:09 --> UTF-8 Support Enabled
INFO - 2018-06-20 02:09:09 --> Utf8 Class Initialized
INFO - 2018-06-20 02:09:09 --> URI Class Initialized
INFO - 2018-06-20 02:09:09 --> Router Class Initialized
INFO - 2018-06-20 02:09:09 --> Output Class Initialized
INFO - 2018-06-20 02:09:09 --> Security Class Initialized
DEBUG - 2018-06-20 02:09:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 02:09:09 --> Input Class Initialized
INFO - 2018-06-20 02:09:09 --> Language Class Initialized
INFO - 2018-06-20 02:09:09 --> Language Class Initialized
INFO - 2018-06-20 02:09:09 --> Config Class Initialized
INFO - 2018-06-20 02:09:09 --> Loader Class Initialized
DEBUG - 2018-06-20 02:09:09 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-20 02:09:09 --> Helper loaded: url_helper
INFO - 2018-06-20 02:09:09 --> Helper loaded: form_helper
INFO - 2018-06-20 02:09:09 --> Helper loaded: date_helper
INFO - 2018-06-20 02:09:09 --> Helper loaded: util_helper
INFO - 2018-06-20 02:09:09 --> Helper loaded: text_helper
INFO - 2018-06-20 02:09:09 --> Helper loaded: string_helper
INFO - 2018-06-20 02:09:09 --> Database Driver Class Initialized
DEBUG - 2018-06-20 02:09:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 02:09:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 02:09:09 --> Email Class Initialized
INFO - 2018-06-20 02:09:09 --> Controller Class Initialized
DEBUG - 2018-06-20 02:09:09 --> Home MX_Controller Initialized
DEBUG - 2018-06-20 02:09:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-20 02:09:09 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-20 02:09:10 --> Login MX_Controller Initialized
INFO - 2018-06-20 02:09:10 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-20 02:09:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-20 02:09:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-20 02:09:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-20 02:09:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-20 02:09:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-20 02:09:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-20 02:09:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-20 02:09:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-06-20 02:09:10 --> Final output sent to browser
DEBUG - 2018-06-20 02:09:10 --> Total execution time: 0.4579
INFO - 2018-06-20 02:09:10 --> Config Class Initialized
INFO - 2018-06-20 02:09:10 --> Config Class Initialized
INFO - 2018-06-20 02:09:10 --> Hooks Class Initialized
INFO - 2018-06-20 02:09:10 --> Hooks Class Initialized
DEBUG - 2018-06-20 02:09:10 --> UTF-8 Support Enabled
INFO - 2018-06-20 02:09:10 --> Utf8 Class Initialized
INFO - 2018-06-20 02:09:10 --> URI Class Initialized
INFO - 2018-06-20 02:09:10 --> Router Class Initialized
INFO - 2018-06-20 02:09:10 --> Output Class Initialized
INFO - 2018-06-20 02:09:10 --> Security Class Initialized
DEBUG - 2018-06-20 02:09:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 02:09:10 --> Input Class Initialized
INFO - 2018-06-20 02:09:10 --> Language Class Initialized
ERROR - 2018-06-20 02:09:10 --> 404 Page Not Found: /index
DEBUG - 2018-06-20 02:09:10 --> UTF-8 Support Enabled
INFO - 2018-06-20 02:09:10 --> Utf8 Class Initialized
INFO - 2018-06-20 02:09:10 --> URI Class Initialized
INFO - 2018-06-20 02:09:10 --> Router Class Initialized
INFO - 2018-06-20 02:09:10 --> Output Class Initialized
INFO - 2018-06-20 02:09:10 --> Security Class Initialized
DEBUG - 2018-06-20 02:09:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 02:09:10 --> Input Class Initialized
INFO - 2018-06-20 02:09:10 --> Language Class Initialized
ERROR - 2018-06-20 02:09:10 --> 404 Page Not Found: /index
INFO - 2018-06-20 02:09:10 --> Config Class Initialized
INFO - 2018-06-20 02:09:10 --> Hooks Class Initialized
DEBUG - 2018-06-20 02:09:10 --> UTF-8 Support Enabled
INFO - 2018-06-20 02:09:10 --> Utf8 Class Initialized
INFO - 2018-06-20 02:09:10 --> URI Class Initialized
INFO - 2018-06-20 02:09:10 --> Router Class Initialized
INFO - 2018-06-20 02:09:10 --> Output Class Initialized
INFO - 2018-06-20 02:09:10 --> Security Class Initialized
DEBUG - 2018-06-20 02:09:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 02:09:10 --> Input Class Initialized
INFO - 2018-06-20 02:09:10 --> Language Class Initialized
ERROR - 2018-06-20 02:09:10 --> 404 Page Not Found: /index
INFO - 2018-06-20 02:09:10 --> Config Class Initialized
INFO - 2018-06-20 02:09:10 --> Hooks Class Initialized
DEBUG - 2018-06-20 02:09:10 --> UTF-8 Support Enabled
INFO - 2018-06-20 02:09:11 --> Utf8 Class Initialized
INFO - 2018-06-20 02:09:11 --> URI Class Initialized
INFO - 2018-06-20 02:09:11 --> Router Class Initialized
INFO - 2018-06-20 02:09:11 --> Output Class Initialized
INFO - 2018-06-20 02:09:11 --> Security Class Initialized
DEBUG - 2018-06-20 02:09:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 02:09:11 --> Input Class Initialized
INFO - 2018-06-20 02:09:11 --> Language Class Initialized
ERROR - 2018-06-20 02:09:11 --> 404 Page Not Found: /index
INFO - 2018-06-20 02:09:21 --> Config Class Initialized
INFO - 2018-06-20 02:09:21 --> Hooks Class Initialized
DEBUG - 2018-06-20 02:09:21 --> UTF-8 Support Enabled
INFO - 2018-06-20 02:09:21 --> Utf8 Class Initialized
INFO - 2018-06-20 02:09:21 --> URI Class Initialized
INFO - 2018-06-20 02:09:21 --> Router Class Initialized
INFO - 2018-06-20 02:09:21 --> Output Class Initialized
INFO - 2018-06-20 02:09:21 --> Security Class Initialized
DEBUG - 2018-06-20 02:09:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 02:09:21 --> Input Class Initialized
INFO - 2018-06-20 02:09:21 --> Language Class Initialized
INFO - 2018-06-20 02:09:21 --> Language Class Initialized
INFO - 2018-06-20 02:09:21 --> Config Class Initialized
INFO - 2018-06-20 02:09:21 --> Loader Class Initialized
DEBUG - 2018-06-20 02:09:21 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-20 02:09:21 --> Helper loaded: url_helper
INFO - 2018-06-20 02:09:21 --> Helper loaded: form_helper
INFO - 2018-06-20 02:09:21 --> Helper loaded: date_helper
INFO - 2018-06-20 02:09:21 --> Helper loaded: util_helper
INFO - 2018-06-20 02:09:21 --> Helper loaded: text_helper
INFO - 2018-06-20 02:09:21 --> Helper loaded: string_helper
INFO - 2018-06-20 02:09:21 --> Database Driver Class Initialized
DEBUG - 2018-06-20 02:09:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 02:09:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 02:09:21 --> Email Class Initialized
INFO - 2018-06-20 02:09:21 --> Controller Class Initialized
DEBUG - 2018-06-20 02:09:21 --> Home MX_Controller Initialized
DEBUG - 2018-06-20 02:09:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-20 02:09:21 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-20 02:09:21 --> Login MX_Controller Initialized
INFO - 2018-06-20 02:09:21 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-20 02:09:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-20 02:09:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-20 02:09:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-20 02:09:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-20 02:09:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-20 02:09:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-20 02:09:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-20 02:09:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-06-20 02:09:21 --> Final output sent to browser
DEBUG - 2018-06-20 02:09:21 --> Total execution time: 0.4499
INFO - 2018-06-20 02:09:22 --> Config Class Initialized
INFO - 2018-06-20 02:09:22 --> Config Class Initialized
INFO - 2018-06-20 02:09:22 --> Hooks Class Initialized
INFO - 2018-06-20 02:09:22 --> Hooks Class Initialized
DEBUG - 2018-06-20 02:09:22 --> UTF-8 Support Enabled
DEBUG - 2018-06-20 02:09:22 --> UTF-8 Support Enabled
INFO - 2018-06-20 02:09:22 --> Utf8 Class Initialized
INFO - 2018-06-20 02:09:22 --> Utf8 Class Initialized
INFO - 2018-06-20 02:09:22 --> URI Class Initialized
INFO - 2018-06-20 02:09:22 --> URI Class Initialized
INFO - 2018-06-20 02:09:22 --> Router Class Initialized
INFO - 2018-06-20 02:09:22 --> Router Class Initialized
INFO - 2018-06-20 02:09:22 --> Output Class Initialized
INFO - 2018-06-20 02:09:22 --> Output Class Initialized
INFO - 2018-06-20 02:09:22 --> Security Class Initialized
INFO - 2018-06-20 02:09:22 --> Security Class Initialized
DEBUG - 2018-06-20 02:09:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-06-20 02:09:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 02:09:22 --> Input Class Initialized
INFO - 2018-06-20 02:09:22 --> Input Class Initialized
INFO - 2018-06-20 02:09:22 --> Language Class Initialized
INFO - 2018-06-20 02:09:22 --> Language Class Initialized
ERROR - 2018-06-20 02:09:22 --> 404 Page Not Found: /index
ERROR - 2018-06-20 02:09:22 --> 404 Page Not Found: /index
INFO - 2018-06-20 02:09:22 --> Config Class Initialized
INFO - 2018-06-20 02:09:22 --> Hooks Class Initialized
DEBUG - 2018-06-20 02:09:22 --> UTF-8 Support Enabled
INFO - 2018-06-20 02:09:22 --> Utf8 Class Initialized
INFO - 2018-06-20 02:09:22 --> URI Class Initialized
INFO - 2018-06-20 02:09:22 --> Router Class Initialized
INFO - 2018-06-20 02:09:22 --> Output Class Initialized
INFO - 2018-06-20 02:09:22 --> Security Class Initialized
DEBUG - 2018-06-20 02:09:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 02:09:22 --> Input Class Initialized
INFO - 2018-06-20 02:09:22 --> Language Class Initialized
ERROR - 2018-06-20 02:09:22 --> 404 Page Not Found: /index
INFO - 2018-06-20 02:09:22 --> Config Class Initialized
INFO - 2018-06-20 02:09:22 --> Hooks Class Initialized
DEBUG - 2018-06-20 02:09:22 --> UTF-8 Support Enabled
INFO - 2018-06-20 02:09:22 --> Utf8 Class Initialized
INFO - 2018-06-20 02:09:22 --> URI Class Initialized
INFO - 2018-06-20 02:09:22 --> Router Class Initialized
INFO - 2018-06-20 02:09:22 --> Output Class Initialized
INFO - 2018-06-20 02:09:22 --> Security Class Initialized
DEBUG - 2018-06-20 02:09:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 02:09:22 --> Input Class Initialized
INFO - 2018-06-20 02:09:22 --> Language Class Initialized
ERROR - 2018-06-20 02:09:22 --> 404 Page Not Found: /index
INFO - 2018-06-20 02:09:24 --> Config Class Initialized
INFO - 2018-06-20 02:09:24 --> Hooks Class Initialized
DEBUG - 2018-06-20 02:09:24 --> UTF-8 Support Enabled
INFO - 2018-06-20 02:09:24 --> Utf8 Class Initialized
INFO - 2018-06-20 02:09:24 --> URI Class Initialized
INFO - 2018-06-20 02:09:25 --> Router Class Initialized
INFO - 2018-06-20 02:09:25 --> Output Class Initialized
INFO - 2018-06-20 02:09:25 --> Security Class Initialized
DEBUG - 2018-06-20 02:09:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 02:09:25 --> Input Class Initialized
INFO - 2018-06-20 02:09:25 --> Language Class Initialized
INFO - 2018-06-20 02:09:25 --> Language Class Initialized
INFO - 2018-06-20 02:09:25 --> Config Class Initialized
INFO - 2018-06-20 02:09:25 --> Loader Class Initialized
DEBUG - 2018-06-20 02:09:25 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-20 02:09:25 --> Helper loaded: url_helper
INFO - 2018-06-20 02:09:25 --> Helper loaded: form_helper
INFO - 2018-06-20 02:09:25 --> Helper loaded: date_helper
INFO - 2018-06-20 02:09:25 --> Helper loaded: util_helper
INFO - 2018-06-20 02:09:25 --> Helper loaded: text_helper
INFO - 2018-06-20 02:09:25 --> Helper loaded: string_helper
INFO - 2018-06-20 02:09:25 --> Database Driver Class Initialized
DEBUG - 2018-06-20 02:09:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 02:09:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 02:09:25 --> Email Class Initialized
INFO - 2018-06-20 02:09:25 --> Controller Class Initialized
DEBUG - 2018-06-20 02:09:25 --> Home MX_Controller Initialized
DEBUG - 2018-06-20 02:09:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-20 02:09:25 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-20 02:09:25 --> Login MX_Controller Initialized
INFO - 2018-06-20 02:09:25 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-20 02:09:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-20 02:09:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-20 02:09:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-20 02:09:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-20 02:09:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-20 02:09:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-20 02:09:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-20 02:09:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-06-20 02:09:25 --> Final output sent to browser
DEBUG - 2018-06-20 02:09:25 --> Total execution time: 0.4227
INFO - 2018-06-20 02:09:25 --> Config Class Initialized
INFO - 2018-06-20 02:09:25 --> Config Class Initialized
INFO - 2018-06-20 02:09:25 --> Hooks Class Initialized
INFO - 2018-06-20 02:09:25 --> Hooks Class Initialized
DEBUG - 2018-06-20 02:09:25 --> UTF-8 Support Enabled
DEBUG - 2018-06-20 02:09:25 --> UTF-8 Support Enabled
INFO - 2018-06-20 02:09:25 --> Utf8 Class Initialized
INFO - 2018-06-20 02:09:25 --> Utf8 Class Initialized
INFO - 2018-06-20 02:09:25 --> URI Class Initialized
INFO - 2018-06-20 02:09:25 --> URI Class Initialized
INFO - 2018-06-20 02:09:25 --> Router Class Initialized
INFO - 2018-06-20 02:09:25 --> Router Class Initialized
INFO - 2018-06-20 02:09:25 --> Output Class Initialized
INFO - 2018-06-20 02:09:25 --> Output Class Initialized
INFO - 2018-06-20 02:09:25 --> Security Class Initialized
INFO - 2018-06-20 02:09:25 --> Security Class Initialized
DEBUG - 2018-06-20 02:09:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-06-20 02:09:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 02:09:25 --> Input Class Initialized
INFO - 2018-06-20 02:09:25 --> Input Class Initialized
INFO - 2018-06-20 02:09:25 --> Language Class Initialized
ERROR - 2018-06-20 02:09:25 --> 404 Page Not Found: /index
INFO - 2018-06-20 02:09:25 --> Language Class Initialized
ERROR - 2018-06-20 02:09:25 --> 404 Page Not Found: /index
INFO - 2018-06-20 02:09:26 --> Config Class Initialized
INFO - 2018-06-20 02:09:26 --> Hooks Class Initialized
DEBUG - 2018-06-20 02:09:26 --> UTF-8 Support Enabled
INFO - 2018-06-20 02:09:26 --> Utf8 Class Initialized
INFO - 2018-06-20 02:09:26 --> URI Class Initialized
INFO - 2018-06-20 02:09:26 --> Router Class Initialized
INFO - 2018-06-20 02:09:26 --> Output Class Initialized
INFO - 2018-06-20 02:09:26 --> Security Class Initialized
DEBUG - 2018-06-20 02:09:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 02:09:26 --> Input Class Initialized
INFO - 2018-06-20 02:09:26 --> Language Class Initialized
ERROR - 2018-06-20 02:09:26 --> 404 Page Not Found: /index
INFO - 2018-06-20 02:09:26 --> Config Class Initialized
INFO - 2018-06-20 02:09:26 --> Hooks Class Initialized
DEBUG - 2018-06-20 02:09:26 --> UTF-8 Support Enabled
INFO - 2018-06-20 02:09:26 --> Utf8 Class Initialized
INFO - 2018-06-20 02:09:26 --> URI Class Initialized
INFO - 2018-06-20 02:09:26 --> Router Class Initialized
INFO - 2018-06-20 02:09:26 --> Output Class Initialized
INFO - 2018-06-20 02:09:26 --> Security Class Initialized
DEBUG - 2018-06-20 02:09:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 02:09:26 --> Input Class Initialized
INFO - 2018-06-20 02:09:26 --> Language Class Initialized
ERROR - 2018-06-20 02:09:26 --> 404 Page Not Found: /index
INFO - 2018-06-20 02:09:28 --> Config Class Initialized
INFO - 2018-06-20 02:09:28 --> Hooks Class Initialized
DEBUG - 2018-06-20 02:09:28 --> UTF-8 Support Enabled
INFO - 2018-06-20 02:09:28 --> Utf8 Class Initialized
INFO - 2018-06-20 02:09:28 --> URI Class Initialized
INFO - 2018-06-20 02:09:28 --> Router Class Initialized
INFO - 2018-06-20 02:09:28 --> Output Class Initialized
INFO - 2018-06-20 02:09:28 --> Security Class Initialized
DEBUG - 2018-06-20 02:09:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 02:09:28 --> Input Class Initialized
INFO - 2018-06-20 02:09:28 --> Language Class Initialized
INFO - 2018-06-20 02:09:28 --> Language Class Initialized
INFO - 2018-06-20 02:09:28 --> Config Class Initialized
INFO - 2018-06-20 02:09:28 --> Loader Class Initialized
DEBUG - 2018-06-20 02:09:28 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-20 02:09:28 --> Helper loaded: url_helper
INFO - 2018-06-20 02:09:28 --> Helper loaded: form_helper
INFO - 2018-06-20 02:09:28 --> Helper loaded: date_helper
INFO - 2018-06-20 02:09:28 --> Helper loaded: util_helper
INFO - 2018-06-20 02:09:28 --> Helper loaded: text_helper
INFO - 2018-06-20 02:09:28 --> Helper loaded: string_helper
INFO - 2018-06-20 02:09:28 --> Database Driver Class Initialized
DEBUG - 2018-06-20 02:09:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 02:09:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 02:09:28 --> Email Class Initialized
INFO - 2018-06-20 02:09:28 --> Controller Class Initialized
DEBUG - 2018-06-20 02:09:28 --> Home MX_Controller Initialized
DEBUG - 2018-06-20 02:09:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-20 02:09:28 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-20 02:09:28 --> Login MX_Controller Initialized
INFO - 2018-06-20 02:09:28 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-20 02:09:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-20 02:09:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-20 02:09:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-20 02:09:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-20 02:09:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-20 02:09:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-20 02:09:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-20 02:09:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-06-20 02:09:28 --> Final output sent to browser
DEBUG - 2018-06-20 02:09:28 --> Total execution time: 0.4879
INFO - 2018-06-20 02:09:29 --> Config Class Initialized
INFO - 2018-06-20 02:09:29 --> Config Class Initialized
INFO - 2018-06-20 02:09:29 --> Hooks Class Initialized
INFO - 2018-06-20 02:09:29 --> Hooks Class Initialized
DEBUG - 2018-06-20 02:09:29 --> UTF-8 Support Enabled
INFO - 2018-06-20 02:09:29 --> Utf8 Class Initialized
INFO - 2018-06-20 02:09:29 --> URI Class Initialized
INFO - 2018-06-20 02:09:29 --> Router Class Initialized
DEBUG - 2018-06-20 02:09:29 --> UTF-8 Support Enabled
INFO - 2018-06-20 02:09:29 --> Output Class Initialized
INFO - 2018-06-20 02:09:29 --> Security Class Initialized
INFO - 2018-06-20 02:09:29 --> Utf8 Class Initialized
DEBUG - 2018-06-20 02:09:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 02:09:29 --> Input Class Initialized
INFO - 2018-06-20 02:09:29 --> URI Class Initialized
INFO - 2018-06-20 02:09:29 --> Language Class Initialized
INFO - 2018-06-20 02:09:29 --> Router Class Initialized
INFO - 2018-06-20 02:09:29 --> Output Class Initialized
ERROR - 2018-06-20 02:09:29 --> 404 Page Not Found: /index
INFO - 2018-06-20 02:09:29 --> Security Class Initialized
DEBUG - 2018-06-20 02:09:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 02:09:29 --> Input Class Initialized
INFO - 2018-06-20 02:09:29 --> Language Class Initialized
INFO - 2018-06-20 02:09:29 --> Config Class Initialized
INFO - 2018-06-20 02:09:29 --> Hooks Class Initialized
ERROR - 2018-06-20 02:09:29 --> 404 Page Not Found: /index
DEBUG - 2018-06-20 02:09:29 --> UTF-8 Support Enabled
INFO - 2018-06-20 02:09:29 --> Utf8 Class Initialized
INFO - 2018-06-20 02:09:29 --> URI Class Initialized
INFO - 2018-06-20 02:09:29 --> Router Class Initialized
INFO - 2018-06-20 02:09:29 --> Output Class Initialized
INFO - 2018-06-20 02:09:29 --> Security Class Initialized
DEBUG - 2018-06-20 02:09:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 02:09:29 --> Input Class Initialized
INFO - 2018-06-20 02:09:29 --> Language Class Initialized
ERROR - 2018-06-20 02:09:29 --> 404 Page Not Found: /index
INFO - 2018-06-20 02:09:29 --> Config Class Initialized
INFO - 2018-06-20 02:09:29 --> Hooks Class Initialized
DEBUG - 2018-06-20 02:09:29 --> UTF-8 Support Enabled
INFO - 2018-06-20 02:09:29 --> Utf8 Class Initialized
INFO - 2018-06-20 02:09:29 --> URI Class Initialized
INFO - 2018-06-20 02:09:29 --> Router Class Initialized
INFO - 2018-06-20 02:09:29 --> Output Class Initialized
INFO - 2018-06-20 02:09:29 --> Security Class Initialized
DEBUG - 2018-06-20 02:09:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 02:09:30 --> Input Class Initialized
INFO - 2018-06-20 02:09:30 --> Language Class Initialized
ERROR - 2018-06-20 02:09:30 --> 404 Page Not Found: /index
INFO - 2018-06-20 02:09:31 --> Config Class Initialized
INFO - 2018-06-20 02:09:31 --> Hooks Class Initialized
DEBUG - 2018-06-20 02:09:31 --> UTF-8 Support Enabled
INFO - 2018-06-20 02:09:31 --> Utf8 Class Initialized
INFO - 2018-06-20 02:09:31 --> URI Class Initialized
INFO - 2018-06-20 02:09:31 --> Router Class Initialized
INFO - 2018-06-20 02:09:31 --> Output Class Initialized
INFO - 2018-06-20 02:09:31 --> Security Class Initialized
DEBUG - 2018-06-20 02:09:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 02:09:31 --> Input Class Initialized
INFO - 2018-06-20 02:09:31 --> Language Class Initialized
INFO - 2018-06-20 02:09:31 --> Language Class Initialized
INFO - 2018-06-20 02:09:31 --> Config Class Initialized
INFO - 2018-06-20 02:09:31 --> Loader Class Initialized
DEBUG - 2018-06-20 02:09:31 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-20 02:09:31 --> Helper loaded: url_helper
INFO - 2018-06-20 02:09:31 --> Helper loaded: form_helper
INFO - 2018-06-20 02:09:31 --> Helper loaded: date_helper
INFO - 2018-06-20 02:09:31 --> Helper loaded: util_helper
INFO - 2018-06-20 02:09:31 --> Helper loaded: text_helper
INFO - 2018-06-20 02:09:31 --> Helper loaded: string_helper
INFO - 2018-06-20 02:09:31 --> Database Driver Class Initialized
DEBUG - 2018-06-20 02:09:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 02:09:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 02:09:31 --> Email Class Initialized
INFO - 2018-06-20 02:09:31 --> Controller Class Initialized
DEBUG - 2018-06-20 02:09:31 --> Home MX_Controller Initialized
DEBUG - 2018-06-20 02:09:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-20 02:09:31 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-20 02:09:31 --> Login MX_Controller Initialized
INFO - 2018-06-20 02:09:31 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-20 02:09:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-20 02:09:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-20 02:09:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-20 02:09:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-20 02:09:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-20 02:09:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-20 02:09:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-20 02:09:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-06-20 02:09:31 --> Final output sent to browser
DEBUG - 2018-06-20 02:09:31 --> Total execution time: 0.4263
INFO - 2018-06-20 02:09:31 --> Config Class Initialized
INFO - 2018-06-20 02:09:31 --> Config Class Initialized
INFO - 2018-06-20 02:09:32 --> Hooks Class Initialized
INFO - 2018-06-20 02:09:32 --> Hooks Class Initialized
DEBUG - 2018-06-20 02:09:32 --> UTF-8 Support Enabled
INFO - 2018-06-20 02:09:32 --> Utf8 Class Initialized
INFO - 2018-06-20 02:09:32 --> URI Class Initialized
DEBUG - 2018-06-20 02:09:32 --> UTF-8 Support Enabled
INFO - 2018-06-20 02:09:32 --> Router Class Initialized
INFO - 2018-06-20 02:09:32 --> Utf8 Class Initialized
INFO - 2018-06-20 02:09:32 --> Output Class Initialized
INFO - 2018-06-20 02:09:32 --> Security Class Initialized
INFO - 2018-06-20 02:09:32 --> URI Class Initialized
DEBUG - 2018-06-20 02:09:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 02:09:32 --> Router Class Initialized
INFO - 2018-06-20 02:09:32 --> Input Class Initialized
INFO - 2018-06-20 02:09:32 --> Output Class Initialized
INFO - 2018-06-20 02:09:32 --> Security Class Initialized
INFO - 2018-06-20 02:09:32 --> Language Class Initialized
DEBUG - 2018-06-20 02:09:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 02:09:32 --> Input Class Initialized
ERROR - 2018-06-20 02:09:32 --> 404 Page Not Found: /index
INFO - 2018-06-20 02:09:32 --> Language Class Initialized
INFO - 2018-06-20 02:09:32 --> Config Class Initialized
INFO - 2018-06-20 02:09:32 --> Hooks Class Initialized
ERROR - 2018-06-20 02:09:32 --> 404 Page Not Found: /index
DEBUG - 2018-06-20 02:09:32 --> UTF-8 Support Enabled
INFO - 2018-06-20 02:09:32 --> Utf8 Class Initialized
INFO - 2018-06-20 02:09:32 --> URI Class Initialized
INFO - 2018-06-20 02:09:32 --> Router Class Initialized
INFO - 2018-06-20 02:09:32 --> Output Class Initialized
INFO - 2018-06-20 02:09:32 --> Security Class Initialized
DEBUG - 2018-06-20 02:09:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 02:09:32 --> Input Class Initialized
INFO - 2018-06-20 02:09:32 --> Language Class Initialized
ERROR - 2018-06-20 02:09:32 --> 404 Page Not Found: /index
INFO - 2018-06-20 02:09:32 --> Config Class Initialized
INFO - 2018-06-20 02:09:32 --> Hooks Class Initialized
DEBUG - 2018-06-20 02:09:32 --> UTF-8 Support Enabled
INFO - 2018-06-20 02:09:32 --> Utf8 Class Initialized
INFO - 2018-06-20 02:09:32 --> URI Class Initialized
INFO - 2018-06-20 02:09:32 --> Router Class Initialized
INFO - 2018-06-20 02:09:32 --> Output Class Initialized
INFO - 2018-06-20 02:09:32 --> Security Class Initialized
DEBUG - 2018-06-20 02:09:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 02:09:32 --> Input Class Initialized
INFO - 2018-06-20 02:09:32 --> Language Class Initialized
ERROR - 2018-06-20 02:09:32 --> 404 Page Not Found: /index
INFO - 2018-06-20 02:37:31 --> Config Class Initialized
INFO - 2018-06-20 02:37:31 --> Hooks Class Initialized
DEBUG - 2018-06-20 02:37:31 --> UTF-8 Support Enabled
INFO - 2018-06-20 02:37:31 --> Utf8 Class Initialized
INFO - 2018-06-20 02:37:31 --> URI Class Initialized
INFO - 2018-06-20 02:37:31 --> Router Class Initialized
INFO - 2018-06-20 02:37:31 --> Output Class Initialized
INFO - 2018-06-20 02:37:31 --> Security Class Initialized
DEBUG - 2018-06-20 02:37:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 02:37:31 --> Input Class Initialized
INFO - 2018-06-20 02:37:31 --> Language Class Initialized
INFO - 2018-06-20 02:37:31 --> Language Class Initialized
INFO - 2018-06-20 02:37:31 --> Config Class Initialized
INFO - 2018-06-20 02:37:31 --> Loader Class Initialized
DEBUG - 2018-06-20 02:37:31 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-20 02:37:31 --> Helper loaded: url_helper
INFO - 2018-06-20 02:37:31 --> Helper loaded: form_helper
INFO - 2018-06-20 02:37:31 --> Helper loaded: date_helper
INFO - 2018-06-20 02:37:31 --> Helper loaded: util_helper
INFO - 2018-06-20 02:37:31 --> Helper loaded: text_helper
INFO - 2018-06-20 02:37:31 --> Helper loaded: string_helper
INFO - 2018-06-20 02:37:31 --> Database Driver Class Initialized
DEBUG - 2018-06-20 02:37:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 02:37:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 02:37:31 --> Email Class Initialized
INFO - 2018-06-20 02:37:31 --> Controller Class Initialized
DEBUG - 2018-06-20 02:37:31 --> Home MX_Controller Initialized
DEBUG - 2018-06-20 02:37:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-20 02:37:31 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-20 02:37:31 --> Login MX_Controller Initialized
INFO - 2018-06-20 02:37:31 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-20 02:37:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-20 02:37:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-20 02:37:42 --> Config Class Initialized
INFO - 2018-06-20 02:37:42 --> Hooks Class Initialized
DEBUG - 2018-06-20 02:37:42 --> UTF-8 Support Enabled
INFO - 2018-06-20 02:37:42 --> Utf8 Class Initialized
INFO - 2018-06-20 02:37:42 --> URI Class Initialized
INFO - 2018-06-20 02:37:42 --> Router Class Initialized
INFO - 2018-06-20 02:37:42 --> Output Class Initialized
INFO - 2018-06-20 02:37:42 --> Security Class Initialized
DEBUG - 2018-06-20 02:37:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 02:37:42 --> Input Class Initialized
INFO - 2018-06-20 02:37:42 --> Language Class Initialized
INFO - 2018-06-20 02:37:42 --> Language Class Initialized
INFO - 2018-06-20 02:37:42 --> Config Class Initialized
INFO - 2018-06-20 02:37:42 --> Loader Class Initialized
DEBUG - 2018-06-20 02:37:42 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-20 02:37:42 --> Helper loaded: url_helper
INFO - 2018-06-20 02:37:42 --> Helper loaded: form_helper
INFO - 2018-06-20 02:37:42 --> Helper loaded: date_helper
INFO - 2018-06-20 02:37:42 --> Helper loaded: util_helper
INFO - 2018-06-20 02:37:42 --> Helper loaded: text_helper
INFO - 2018-06-20 02:37:42 --> Helper loaded: string_helper
INFO - 2018-06-20 02:37:42 --> Database Driver Class Initialized
DEBUG - 2018-06-20 02:37:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 02:37:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 02:37:42 --> Email Class Initialized
INFO - 2018-06-20 02:37:42 --> Controller Class Initialized
DEBUG - 2018-06-20 02:37:42 --> Home MX_Controller Initialized
DEBUG - 2018-06-20 02:37:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-20 02:37:42 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-20 02:37:42 --> Login MX_Controller Initialized
INFO - 2018-06-20 02:37:42 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-20 02:37:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-20 02:37:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-20 02:37:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-20 02:37:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-20 02:37:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-20 02:37:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-20 02:37:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-20 02:37:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-06-20 02:37:43 --> Final output sent to browser
DEBUG - 2018-06-20 02:37:43 --> Total execution time: 0.4340
INFO - 2018-06-20 02:37:43 --> Config Class Initialized
INFO - 2018-06-20 02:37:43 --> Config Class Initialized
INFO - 2018-06-20 02:37:43 --> Hooks Class Initialized
INFO - 2018-06-20 02:37:43 --> Hooks Class Initialized
DEBUG - 2018-06-20 02:37:43 --> UTF-8 Support Enabled
INFO - 2018-06-20 02:37:43 --> Utf8 Class Initialized
INFO - 2018-06-20 02:37:43 --> URI Class Initialized
INFO - 2018-06-20 02:37:43 --> Router Class Initialized
INFO - 2018-06-20 02:37:43 --> Output Class Initialized
INFO - 2018-06-20 02:37:43 --> Security Class Initialized
DEBUG - 2018-06-20 02:37:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-06-20 02:37:43 --> UTF-8 Support Enabled
INFO - 2018-06-20 02:37:43 --> Input Class Initialized
INFO - 2018-06-20 02:37:43 --> Language Class Initialized
ERROR - 2018-06-20 02:37:43 --> 404 Page Not Found: /index
INFO - 2018-06-20 02:37:43 --> Utf8 Class Initialized
INFO - 2018-06-20 02:37:43 --> Config Class Initialized
INFO - 2018-06-20 02:37:43 --> Hooks Class Initialized
INFO - 2018-06-20 02:37:44 --> URI Class Initialized
DEBUG - 2018-06-20 02:37:44 --> UTF-8 Support Enabled
INFO - 2018-06-20 02:37:44 --> Utf8 Class Initialized
INFO - 2018-06-20 02:37:44 --> URI Class Initialized
INFO - 2018-06-20 02:37:44 --> Router Class Initialized
INFO - 2018-06-20 02:37:44 --> Router Class Initialized
INFO - 2018-06-20 02:37:44 --> Output Class Initialized
INFO - 2018-06-20 02:37:44 --> Security Class Initialized
DEBUG - 2018-06-20 02:37:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 02:37:44 --> Input Class Initialized
INFO - 2018-06-20 02:37:44 --> Output Class Initialized
INFO - 2018-06-20 02:37:44 --> Language Class Initialized
ERROR - 2018-06-20 02:37:44 --> 404 Page Not Found: /index
INFO - 2018-06-20 02:37:44 --> Security Class Initialized
INFO - 2018-06-20 02:37:44 --> Config Class Initialized
INFO - 2018-06-20 02:37:44 --> Hooks Class Initialized
DEBUG - 2018-06-20 02:37:44 --> UTF-8 Support Enabled
INFO - 2018-06-20 02:37:44 --> Utf8 Class Initialized
DEBUG - 2018-06-20 02:37:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 02:37:44 --> URI Class Initialized
INFO - 2018-06-20 02:37:44 --> Input Class Initialized
INFO - 2018-06-20 02:37:44 --> Language Class Initialized
INFO - 2018-06-20 02:37:44 --> Router Class Initialized
ERROR - 2018-06-20 02:37:44 --> 404 Page Not Found: /index
INFO - 2018-06-20 02:37:44 --> Output Class Initialized
INFO - 2018-06-20 02:37:44 --> Security Class Initialized
DEBUG - 2018-06-20 02:37:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 02:37:44 --> Input Class Initialized
INFO - 2018-06-20 02:37:44 --> Language Class Initialized
ERROR - 2018-06-20 02:37:44 --> 404 Page Not Found: /index
INFO - 2018-06-20 02:37:44 --> Config Class Initialized
INFO - 2018-06-20 02:37:44 --> Hooks Class Initialized
DEBUG - 2018-06-20 02:37:44 --> UTF-8 Support Enabled
INFO - 2018-06-20 02:37:44 --> Utf8 Class Initialized
INFO - 2018-06-20 02:37:44 --> URI Class Initialized
INFO - 2018-06-20 02:37:44 --> Router Class Initialized
INFO - 2018-06-20 02:37:44 --> Output Class Initialized
INFO - 2018-06-20 02:37:44 --> Security Class Initialized
DEBUG - 2018-06-20 02:37:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 02:37:44 --> Input Class Initialized
INFO - 2018-06-20 02:37:44 --> Language Class Initialized
ERROR - 2018-06-20 02:37:44 --> 404 Page Not Found: /index
INFO - 2018-06-20 02:37:44 --> Config Class Initialized
INFO - 2018-06-20 02:37:44 --> Hooks Class Initialized
DEBUG - 2018-06-20 02:37:44 --> UTF-8 Support Enabled
INFO - 2018-06-20 02:37:44 --> Utf8 Class Initialized
INFO - 2018-06-20 02:37:44 --> URI Class Initialized
INFO - 2018-06-20 02:37:44 --> Router Class Initialized
INFO - 2018-06-20 02:37:44 --> Output Class Initialized
INFO - 2018-06-20 02:37:44 --> Security Class Initialized
DEBUG - 2018-06-20 02:37:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 02:37:44 --> Input Class Initialized
INFO - 2018-06-20 02:37:44 --> Language Class Initialized
ERROR - 2018-06-20 02:37:44 --> 404 Page Not Found: /index
INFO - 2018-06-20 02:37:44 --> Config Class Initialized
INFO - 2018-06-20 02:37:44 --> Hooks Class Initialized
DEBUG - 2018-06-20 02:37:44 --> UTF-8 Support Enabled
INFO - 2018-06-20 02:37:44 --> Utf8 Class Initialized
INFO - 2018-06-20 02:37:44 --> URI Class Initialized
INFO - 2018-06-20 02:37:44 --> Router Class Initialized
INFO - 2018-06-20 02:37:44 --> Output Class Initialized
INFO - 2018-06-20 02:37:44 --> Security Class Initialized
DEBUG - 2018-06-20 02:37:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 02:37:44 --> Input Class Initialized
INFO - 2018-06-20 02:37:44 --> Language Class Initialized
ERROR - 2018-06-20 02:37:44 --> 404 Page Not Found: /index
INFO - 2018-06-20 02:53:07 --> Config Class Initialized
INFO - 2018-06-20 02:53:07 --> Hooks Class Initialized
DEBUG - 2018-06-20 02:53:07 --> UTF-8 Support Enabled
INFO - 2018-06-20 02:53:07 --> Utf8 Class Initialized
INFO - 2018-06-20 02:53:07 --> URI Class Initialized
INFO - 2018-06-20 02:53:07 --> Router Class Initialized
INFO - 2018-06-20 02:53:07 --> Output Class Initialized
INFO - 2018-06-20 02:53:07 --> Security Class Initialized
DEBUG - 2018-06-20 02:53:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 02:53:07 --> Input Class Initialized
INFO - 2018-06-20 02:53:07 --> Language Class Initialized
INFO - 2018-06-20 02:53:07 --> Language Class Initialized
INFO - 2018-06-20 02:53:07 --> Config Class Initialized
INFO - 2018-06-20 02:53:07 --> Loader Class Initialized
DEBUG - 2018-06-20 02:53:07 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-20 02:53:07 --> Helper loaded: url_helper
INFO - 2018-06-20 02:53:07 --> Helper loaded: form_helper
INFO - 2018-06-20 02:53:07 --> Helper loaded: date_helper
INFO - 2018-06-20 02:53:07 --> Helper loaded: util_helper
INFO - 2018-06-20 02:53:07 --> Helper loaded: text_helper
INFO - 2018-06-20 02:53:07 --> Helper loaded: string_helper
INFO - 2018-06-20 02:53:07 --> Database Driver Class Initialized
DEBUG - 2018-06-20 02:53:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 02:53:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 02:53:07 --> Email Class Initialized
INFO - 2018-06-20 02:53:07 --> Controller Class Initialized
DEBUG - 2018-06-20 02:53:07 --> Home MX_Controller Initialized
DEBUG - 2018-06-20 02:53:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-20 02:53:07 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-20 02:53:07 --> Login MX_Controller Initialized
INFO - 2018-06-20 02:53:07 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-20 02:53:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-20 02:53:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-20 02:53:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-20 02:53:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-20 02:53:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-20 02:53:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-20 02:53:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-20 02:53:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-06-20 02:53:07 --> Final output sent to browser
DEBUG - 2018-06-20 02:53:07 --> Total execution time: 0.4364
INFO - 2018-06-20 02:53:08 --> Config Class Initialized
INFO - 2018-06-20 02:53:08 --> Config Class Initialized
INFO - 2018-06-20 02:53:08 --> Hooks Class Initialized
INFO - 2018-06-20 02:53:08 --> Hooks Class Initialized
DEBUG - 2018-06-20 02:53:08 --> UTF-8 Support Enabled
INFO - 2018-06-20 02:53:08 --> Utf8 Class Initialized
DEBUG - 2018-06-20 02:53:08 --> UTF-8 Support Enabled
INFO - 2018-06-20 02:53:08 --> URI Class Initialized
INFO - 2018-06-20 02:53:08 --> Router Class Initialized
INFO - 2018-06-20 02:53:08 --> Output Class Initialized
INFO - 2018-06-20 02:53:08 --> Security Class Initialized
DEBUG - 2018-06-20 02:53:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 02:53:08 --> Input Class Initialized
INFO - 2018-06-20 02:53:08 --> Language Class Initialized
ERROR - 2018-06-20 02:53:08 --> 404 Page Not Found: /index
INFO - 2018-06-20 02:53:08 --> Utf8 Class Initialized
INFO - 2018-06-20 02:53:08 --> URI Class Initialized
INFO - 2018-06-20 02:53:08 --> Router Class Initialized
INFO - 2018-06-20 02:53:08 --> Output Class Initialized
INFO - 2018-06-20 02:53:08 --> Security Class Initialized
DEBUG - 2018-06-20 02:53:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 02:53:08 --> Input Class Initialized
INFO - 2018-06-20 02:53:08 --> Language Class Initialized
ERROR - 2018-06-20 02:53:08 --> 404 Page Not Found: /index
INFO - 2018-06-20 02:53:08 --> Config Class Initialized
INFO - 2018-06-20 02:53:08 --> Hooks Class Initialized
DEBUG - 2018-06-20 02:53:08 --> UTF-8 Support Enabled
INFO - 2018-06-20 02:53:08 --> Utf8 Class Initialized
INFO - 2018-06-20 02:53:08 --> URI Class Initialized
INFO - 2018-06-20 02:53:08 --> Router Class Initialized
INFO - 2018-06-20 02:53:08 --> Output Class Initialized
INFO - 2018-06-20 02:53:09 --> Security Class Initialized
DEBUG - 2018-06-20 02:53:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 02:53:09 --> Input Class Initialized
INFO - 2018-06-20 02:53:09 --> Language Class Initialized
ERROR - 2018-06-20 02:53:09 --> 404 Page Not Found: /index
INFO - 2018-06-20 02:53:09 --> Config Class Initialized
INFO - 2018-06-20 02:53:09 --> Hooks Class Initialized
DEBUG - 2018-06-20 02:53:09 --> UTF-8 Support Enabled
INFO - 2018-06-20 02:53:09 --> Utf8 Class Initialized
INFO - 2018-06-20 02:53:09 --> URI Class Initialized
INFO - 2018-06-20 02:53:09 --> Router Class Initialized
INFO - 2018-06-20 02:53:09 --> Output Class Initialized
INFO - 2018-06-20 02:53:09 --> Security Class Initialized
DEBUG - 2018-06-20 02:53:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 02:53:09 --> Input Class Initialized
INFO - 2018-06-20 02:53:09 --> Language Class Initialized
ERROR - 2018-06-20 02:53:09 --> 404 Page Not Found: /index
INFO - 2018-06-20 02:54:47 --> Config Class Initialized
INFO - 2018-06-20 02:54:47 --> Hooks Class Initialized
DEBUG - 2018-06-20 02:54:47 --> UTF-8 Support Enabled
INFO - 2018-06-20 02:54:47 --> Utf8 Class Initialized
INFO - 2018-06-20 02:54:47 --> URI Class Initialized
INFO - 2018-06-20 02:54:47 --> Router Class Initialized
INFO - 2018-06-20 02:54:47 --> Output Class Initialized
INFO - 2018-06-20 02:54:47 --> Security Class Initialized
DEBUG - 2018-06-20 02:54:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 02:54:47 --> Input Class Initialized
INFO - 2018-06-20 02:54:47 --> Language Class Initialized
INFO - 2018-06-20 02:54:47 --> Language Class Initialized
INFO - 2018-06-20 02:54:47 --> Config Class Initialized
INFO - 2018-06-20 02:54:47 --> Loader Class Initialized
DEBUG - 2018-06-20 02:54:47 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-20 02:54:48 --> Helper loaded: url_helper
INFO - 2018-06-20 02:54:48 --> Helper loaded: form_helper
INFO - 2018-06-20 02:54:48 --> Helper loaded: date_helper
INFO - 2018-06-20 02:54:48 --> Helper loaded: util_helper
INFO - 2018-06-20 02:54:48 --> Helper loaded: text_helper
INFO - 2018-06-20 02:54:48 --> Helper loaded: string_helper
INFO - 2018-06-20 02:54:48 --> Database Driver Class Initialized
DEBUG - 2018-06-20 02:54:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 02:54:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 02:54:48 --> Email Class Initialized
INFO - 2018-06-20 02:54:48 --> Controller Class Initialized
DEBUG - 2018-06-20 02:54:48 --> Home MX_Controller Initialized
DEBUG - 2018-06-20 02:54:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-20 02:54:48 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-20 02:54:48 --> Login MX_Controller Initialized
INFO - 2018-06-20 02:54:48 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-20 02:54:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-20 02:54:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-20 02:54:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-20 02:54:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-20 02:54:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
ERROR - 2018-06-20 02:54:48 --> Severity: Notice --> Array to string conversion E:\xampp\htdocs\consulting\application\modules\home\views\course.php 132
INFO - 2018-06-20 02:55:39 --> Config Class Initialized
INFO - 2018-06-20 02:55:39 --> Hooks Class Initialized
DEBUG - 2018-06-20 02:55:39 --> UTF-8 Support Enabled
INFO - 2018-06-20 02:55:39 --> Utf8 Class Initialized
INFO - 2018-06-20 02:55:39 --> URI Class Initialized
INFO - 2018-06-20 02:55:39 --> Router Class Initialized
INFO - 2018-06-20 02:55:39 --> Output Class Initialized
INFO - 2018-06-20 02:55:40 --> Security Class Initialized
DEBUG - 2018-06-20 02:55:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 02:55:40 --> Input Class Initialized
INFO - 2018-06-20 02:55:40 --> Language Class Initialized
INFO - 2018-06-20 02:55:40 --> Language Class Initialized
INFO - 2018-06-20 02:55:40 --> Config Class Initialized
INFO - 2018-06-20 02:55:40 --> Loader Class Initialized
DEBUG - 2018-06-20 02:55:40 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-20 02:55:40 --> Helper loaded: url_helper
INFO - 2018-06-20 02:55:40 --> Helper loaded: form_helper
INFO - 2018-06-20 02:55:40 --> Helper loaded: date_helper
INFO - 2018-06-20 02:55:40 --> Helper loaded: util_helper
INFO - 2018-06-20 02:55:40 --> Helper loaded: text_helper
INFO - 2018-06-20 02:55:40 --> Helper loaded: string_helper
INFO - 2018-06-20 02:55:40 --> Database Driver Class Initialized
DEBUG - 2018-06-20 02:55:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 02:55:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 02:55:40 --> Email Class Initialized
INFO - 2018-06-20 02:55:40 --> Controller Class Initialized
DEBUG - 2018-06-20 02:55:40 --> Home MX_Controller Initialized
DEBUG - 2018-06-20 02:55:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-20 02:55:40 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-20 02:55:40 --> Login MX_Controller Initialized
INFO - 2018-06-20 02:55:40 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-20 02:55:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-20 02:55:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-20 02:55:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-20 02:55:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-20 02:55:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
INFO - 2018-06-20 02:55:54 --> Config Class Initialized
INFO - 2018-06-20 02:55:54 --> Hooks Class Initialized
DEBUG - 2018-06-20 02:55:54 --> UTF-8 Support Enabled
INFO - 2018-06-20 02:55:54 --> Utf8 Class Initialized
INFO - 2018-06-20 02:55:55 --> URI Class Initialized
INFO - 2018-06-20 02:55:55 --> Router Class Initialized
INFO - 2018-06-20 02:55:55 --> Output Class Initialized
INFO - 2018-06-20 02:55:55 --> Security Class Initialized
DEBUG - 2018-06-20 02:55:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 02:55:55 --> Input Class Initialized
INFO - 2018-06-20 02:55:55 --> Language Class Initialized
INFO - 2018-06-20 02:55:55 --> Language Class Initialized
INFO - 2018-06-20 02:55:55 --> Config Class Initialized
INFO - 2018-06-20 02:55:55 --> Loader Class Initialized
DEBUG - 2018-06-20 02:55:55 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-20 02:55:55 --> Helper loaded: url_helper
INFO - 2018-06-20 02:55:55 --> Helper loaded: form_helper
INFO - 2018-06-20 02:55:55 --> Helper loaded: date_helper
INFO - 2018-06-20 02:55:55 --> Helper loaded: util_helper
INFO - 2018-06-20 02:55:55 --> Helper loaded: text_helper
INFO - 2018-06-20 02:55:55 --> Helper loaded: string_helper
INFO - 2018-06-20 02:55:55 --> Database Driver Class Initialized
DEBUG - 2018-06-20 02:55:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 02:55:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 02:55:55 --> Email Class Initialized
INFO - 2018-06-20 02:55:55 --> Controller Class Initialized
DEBUG - 2018-06-20 02:55:55 --> Home MX_Controller Initialized
DEBUG - 2018-06-20 02:55:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-20 02:55:55 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-20 02:55:55 --> Login MX_Controller Initialized
INFO - 2018-06-20 02:55:55 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-20 02:55:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-20 02:55:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-20 02:55:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-20 02:55:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-20 02:55:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
INFO - 2018-06-20 02:57:46 --> Config Class Initialized
INFO - 2018-06-20 02:57:46 --> Hooks Class Initialized
DEBUG - 2018-06-20 02:57:47 --> UTF-8 Support Enabled
INFO - 2018-06-20 02:57:47 --> Utf8 Class Initialized
INFO - 2018-06-20 02:57:47 --> URI Class Initialized
INFO - 2018-06-20 02:57:47 --> Router Class Initialized
INFO - 2018-06-20 02:57:47 --> Output Class Initialized
INFO - 2018-06-20 02:57:47 --> Security Class Initialized
DEBUG - 2018-06-20 02:57:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 02:57:47 --> Input Class Initialized
INFO - 2018-06-20 02:57:47 --> Language Class Initialized
INFO - 2018-06-20 02:57:47 --> Language Class Initialized
INFO - 2018-06-20 02:57:47 --> Config Class Initialized
INFO - 2018-06-20 02:57:47 --> Loader Class Initialized
DEBUG - 2018-06-20 02:57:47 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-20 02:57:47 --> Helper loaded: url_helper
INFO - 2018-06-20 02:57:47 --> Helper loaded: form_helper
INFO - 2018-06-20 02:57:47 --> Helper loaded: date_helper
INFO - 2018-06-20 02:57:47 --> Helper loaded: util_helper
INFO - 2018-06-20 02:57:47 --> Helper loaded: text_helper
INFO - 2018-06-20 02:57:47 --> Helper loaded: string_helper
INFO - 2018-06-20 02:57:47 --> Database Driver Class Initialized
DEBUG - 2018-06-20 02:57:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 02:57:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 02:57:47 --> Email Class Initialized
INFO - 2018-06-20 02:57:47 --> Controller Class Initialized
DEBUG - 2018-06-20 02:57:47 --> Home MX_Controller Initialized
DEBUG - 2018-06-20 02:57:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-20 02:57:47 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-20 02:57:47 --> Login MX_Controller Initialized
INFO - 2018-06-20 02:57:47 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-20 02:57:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-20 02:57:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-20 02:57:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-20 02:57:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-20 02:57:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-20 02:57:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-20 02:57:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-20 02:57:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-06-20 02:57:47 --> Final output sent to browser
DEBUG - 2018-06-20 02:57:47 --> Total execution time: 0.4437
INFO - 2018-06-20 02:57:48 --> Config Class Initialized
INFO - 2018-06-20 02:57:48 --> Config Class Initialized
INFO - 2018-06-20 02:57:48 --> Hooks Class Initialized
DEBUG - 2018-06-20 02:57:48 --> UTF-8 Support Enabled
INFO - 2018-06-20 02:57:48 --> Utf8 Class Initialized
INFO - 2018-06-20 02:57:48 --> Hooks Class Initialized
INFO - 2018-06-20 02:57:48 --> URI Class Initialized
DEBUG - 2018-06-20 02:57:48 --> UTF-8 Support Enabled
INFO - 2018-06-20 02:57:48 --> Utf8 Class Initialized
INFO - 2018-06-20 02:57:48 --> URI Class Initialized
INFO - 2018-06-20 02:57:48 --> Router Class Initialized
INFO - 2018-06-20 02:57:48 --> Output Class Initialized
INFO - 2018-06-20 02:57:48 --> Router Class Initialized
INFO - 2018-06-20 02:57:48 --> Security Class Initialized
INFO - 2018-06-20 02:57:48 --> Output Class Initialized
DEBUG - 2018-06-20 02:57:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 02:57:49 --> Input Class Initialized
INFO - 2018-06-20 02:57:49 --> Language Class Initialized
ERROR - 2018-06-20 02:57:49 --> 404 Page Not Found: /index
INFO - 2018-06-20 02:57:49 --> Security Class Initialized
INFO - 2018-06-20 02:57:49 --> Config Class Initialized
INFO - 2018-06-20 02:57:49 --> Hooks Class Initialized
DEBUG - 2018-06-20 02:57:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 02:57:49 --> Input Class Initialized
DEBUG - 2018-06-20 02:57:49 --> UTF-8 Support Enabled
INFO - 2018-06-20 02:57:49 --> Utf8 Class Initialized
INFO - 2018-06-20 02:57:49 --> Language Class Initialized
ERROR - 2018-06-20 02:57:49 --> 404 Page Not Found: /index
INFO - 2018-06-20 02:57:49 --> URI Class Initialized
INFO - 2018-06-20 02:57:49 --> Router Class Initialized
INFO - 2018-06-20 02:57:49 --> Output Class Initialized
INFO - 2018-06-20 02:57:49 --> Security Class Initialized
DEBUG - 2018-06-20 02:57:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 02:57:49 --> Input Class Initialized
INFO - 2018-06-20 02:57:49 --> Language Class Initialized
ERROR - 2018-06-20 02:57:49 --> 404 Page Not Found: /index
INFO - 2018-06-20 02:57:49 --> Config Class Initialized
INFO - 2018-06-20 02:57:49 --> Hooks Class Initialized
DEBUG - 2018-06-20 02:57:49 --> UTF-8 Support Enabled
INFO - 2018-06-20 02:57:49 --> Utf8 Class Initialized
INFO - 2018-06-20 02:57:49 --> URI Class Initialized
INFO - 2018-06-20 02:57:49 --> Router Class Initialized
INFO - 2018-06-20 02:57:49 --> Output Class Initialized
INFO - 2018-06-20 02:57:49 --> Security Class Initialized
DEBUG - 2018-06-20 02:57:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 02:57:49 --> Input Class Initialized
INFO - 2018-06-20 02:57:49 --> Language Class Initialized
ERROR - 2018-06-20 02:57:49 --> 404 Page Not Found: /index
INFO - 2018-06-20 02:57:49 --> Config Class Initialized
INFO - 2018-06-20 02:57:49 --> Hooks Class Initialized
DEBUG - 2018-06-20 02:57:49 --> UTF-8 Support Enabled
INFO - 2018-06-20 02:57:49 --> Utf8 Class Initialized
INFO - 2018-06-20 02:57:49 --> URI Class Initialized
INFO - 2018-06-20 02:57:49 --> Router Class Initialized
INFO - 2018-06-20 02:57:49 --> Output Class Initialized
INFO - 2018-06-20 02:57:49 --> Security Class Initialized
DEBUG - 2018-06-20 02:57:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 02:57:49 --> Input Class Initialized
INFO - 2018-06-20 02:57:49 --> Language Class Initialized
ERROR - 2018-06-20 02:57:49 --> 404 Page Not Found: /index
INFO - 2018-06-20 02:57:49 --> Config Class Initialized
INFO - 2018-06-20 02:57:49 --> Hooks Class Initialized
DEBUG - 2018-06-20 02:57:49 --> UTF-8 Support Enabled
INFO - 2018-06-20 02:57:49 --> Utf8 Class Initialized
INFO - 2018-06-20 02:57:49 --> URI Class Initialized
INFO - 2018-06-20 02:57:50 --> Router Class Initialized
INFO - 2018-06-20 02:57:50 --> Output Class Initialized
INFO - 2018-06-20 02:57:50 --> Security Class Initialized
DEBUG - 2018-06-20 02:57:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 02:57:50 --> Input Class Initialized
INFO - 2018-06-20 02:57:50 --> Language Class Initialized
ERROR - 2018-06-20 02:57:50 --> 404 Page Not Found: /index
INFO - 2018-06-20 02:57:50 --> Config Class Initialized
INFO - 2018-06-20 02:57:50 --> Hooks Class Initialized
DEBUG - 2018-06-20 02:57:50 --> UTF-8 Support Enabled
INFO - 2018-06-20 02:57:50 --> Utf8 Class Initialized
INFO - 2018-06-20 02:57:50 --> URI Class Initialized
INFO - 2018-06-20 02:57:50 --> Router Class Initialized
INFO - 2018-06-20 02:57:50 --> Output Class Initialized
INFO - 2018-06-20 02:57:50 --> Security Class Initialized
DEBUG - 2018-06-20 02:57:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 02:57:50 --> Input Class Initialized
INFO - 2018-06-20 02:57:50 --> Language Class Initialized
ERROR - 2018-06-20 02:57:50 --> 404 Page Not Found: /index
INFO - 2018-06-20 02:57:51 --> Config Class Initialized
INFO - 2018-06-20 02:57:51 --> Hooks Class Initialized
DEBUG - 2018-06-20 02:57:51 --> UTF-8 Support Enabled
INFO - 2018-06-20 02:57:51 --> Utf8 Class Initialized
INFO - 2018-06-20 02:57:51 --> URI Class Initialized
INFO - 2018-06-20 02:57:51 --> Router Class Initialized
INFO - 2018-06-20 02:57:51 --> Output Class Initialized
INFO - 2018-06-20 02:57:51 --> Security Class Initialized
DEBUG - 2018-06-20 02:57:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 02:57:51 --> Input Class Initialized
INFO - 2018-06-20 02:57:51 --> Language Class Initialized
INFO - 2018-06-20 02:57:51 --> Language Class Initialized
INFO - 2018-06-20 02:57:51 --> Config Class Initialized
INFO - 2018-06-20 02:57:51 --> Loader Class Initialized
DEBUG - 2018-06-20 02:57:51 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-20 02:57:51 --> Helper loaded: url_helper
INFO - 2018-06-20 02:57:51 --> Helper loaded: form_helper
INFO - 2018-06-20 02:57:51 --> Helper loaded: date_helper
INFO - 2018-06-20 02:57:51 --> Helper loaded: util_helper
INFO - 2018-06-20 02:57:51 --> Helper loaded: text_helper
INFO - 2018-06-20 02:57:51 --> Helper loaded: string_helper
INFO - 2018-06-20 02:57:51 --> Database Driver Class Initialized
DEBUG - 2018-06-20 02:57:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 02:57:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 02:57:51 --> Email Class Initialized
INFO - 2018-06-20 02:57:51 --> Controller Class Initialized
DEBUG - 2018-06-20 02:57:51 --> Home MX_Controller Initialized
DEBUG - 2018-06-20 02:57:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-20 02:57:51 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-20 02:57:52 --> Login MX_Controller Initialized
INFO - 2018-06-20 02:57:52 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-20 02:57:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-20 02:57:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-20 02:57:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-20 02:57:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-20 02:57:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-20 02:57:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-20 02:57:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-20 02:57:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-06-20 02:57:52 --> Final output sent to browser
DEBUG - 2018-06-20 02:57:52 --> Total execution time: 0.5370
INFO - 2018-06-20 02:57:52 --> Config Class Initialized
INFO - 2018-06-20 02:57:52 --> Config Class Initialized
INFO - 2018-06-20 02:57:52 --> Hooks Class Initialized
INFO - 2018-06-20 02:57:52 --> Hooks Class Initialized
DEBUG - 2018-06-20 02:57:52 --> UTF-8 Support Enabled
DEBUG - 2018-06-20 02:57:52 --> UTF-8 Support Enabled
INFO - 2018-06-20 02:57:52 --> Utf8 Class Initialized
INFO - 2018-06-20 02:57:52 --> URI Class Initialized
INFO - 2018-06-20 02:57:52 --> Router Class Initialized
INFO - 2018-06-20 02:57:52 --> Utf8 Class Initialized
INFO - 2018-06-20 02:57:52 --> Output Class Initialized
INFO - 2018-06-20 02:57:52 --> URI Class Initialized
INFO - 2018-06-20 02:57:52 --> Security Class Initialized
DEBUG - 2018-06-20 02:57:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 02:57:52 --> Router Class Initialized
INFO - 2018-06-20 02:57:52 --> Input Class Initialized
INFO - 2018-06-20 02:57:52 --> Output Class Initialized
INFO - 2018-06-20 02:57:52 --> Language Class Initialized
ERROR - 2018-06-20 02:57:52 --> 404 Page Not Found: /index
INFO - 2018-06-20 02:57:52 --> Security Class Initialized
DEBUG - 2018-06-20 02:57:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 02:57:52 --> Input Class Initialized
INFO - 2018-06-20 02:57:52 --> Language Class Initialized
ERROR - 2018-06-20 02:57:52 --> 404 Page Not Found: /index
INFO - 2018-06-20 02:57:52 --> Config Class Initialized
INFO - 2018-06-20 02:57:52 --> Hooks Class Initialized
DEBUG - 2018-06-20 02:57:52 --> UTF-8 Support Enabled
INFO - 2018-06-20 02:57:52 --> Utf8 Class Initialized
INFO - 2018-06-20 02:57:53 --> URI Class Initialized
INFO - 2018-06-20 02:57:53 --> Router Class Initialized
INFO - 2018-06-20 02:57:53 --> Output Class Initialized
INFO - 2018-06-20 02:57:53 --> Security Class Initialized
DEBUG - 2018-06-20 02:57:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 02:57:53 --> Input Class Initialized
INFO - 2018-06-20 02:57:53 --> Language Class Initialized
ERROR - 2018-06-20 02:57:53 --> 404 Page Not Found: /index
INFO - 2018-06-20 02:57:53 --> Config Class Initialized
INFO - 2018-06-20 02:57:53 --> Hooks Class Initialized
DEBUG - 2018-06-20 02:57:53 --> UTF-8 Support Enabled
INFO - 2018-06-20 02:57:53 --> Utf8 Class Initialized
INFO - 2018-06-20 02:57:53 --> URI Class Initialized
INFO - 2018-06-20 02:57:53 --> Router Class Initialized
INFO - 2018-06-20 02:57:53 --> Output Class Initialized
INFO - 2018-06-20 02:57:53 --> Security Class Initialized
DEBUG - 2018-06-20 02:57:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 02:57:53 --> Input Class Initialized
INFO - 2018-06-20 02:57:53 --> Language Class Initialized
ERROR - 2018-06-20 02:57:53 --> 404 Page Not Found: /index
INFO - 2018-06-20 02:57:55 --> Config Class Initialized
INFO - 2018-06-20 02:57:55 --> Hooks Class Initialized
DEBUG - 2018-06-20 02:57:55 --> UTF-8 Support Enabled
INFO - 2018-06-20 02:57:55 --> Utf8 Class Initialized
INFO - 2018-06-20 02:57:55 --> URI Class Initialized
INFO - 2018-06-20 02:57:55 --> Router Class Initialized
INFO - 2018-06-20 02:57:55 --> Output Class Initialized
INFO - 2018-06-20 02:57:55 --> Security Class Initialized
DEBUG - 2018-06-20 02:57:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 02:57:55 --> Input Class Initialized
INFO - 2018-06-20 02:57:55 --> Language Class Initialized
INFO - 2018-06-20 02:57:55 --> Language Class Initialized
INFO - 2018-06-20 02:57:55 --> Config Class Initialized
INFO - 2018-06-20 02:57:55 --> Loader Class Initialized
DEBUG - 2018-06-20 02:57:55 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-20 02:57:55 --> Helper loaded: url_helper
INFO - 2018-06-20 02:57:55 --> Helper loaded: form_helper
INFO - 2018-06-20 02:57:55 --> Helper loaded: date_helper
INFO - 2018-06-20 02:57:55 --> Helper loaded: util_helper
INFO - 2018-06-20 02:57:55 --> Helper loaded: text_helper
INFO - 2018-06-20 02:57:55 --> Helper loaded: string_helper
INFO - 2018-06-20 02:57:55 --> Database Driver Class Initialized
DEBUG - 2018-06-20 02:57:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 02:57:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 02:57:55 --> Email Class Initialized
INFO - 2018-06-20 02:57:55 --> Controller Class Initialized
DEBUG - 2018-06-20 02:57:56 --> Home MX_Controller Initialized
DEBUG - 2018-06-20 02:57:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-20 02:57:56 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-20 02:57:56 --> Login MX_Controller Initialized
INFO - 2018-06-20 02:57:56 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-20 02:57:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-20 02:57:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-20 02:57:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-20 02:57:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-20 02:57:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-20 02:57:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-20 02:57:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-20 02:57:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-06-20 02:57:56 --> Final output sent to browser
DEBUG - 2018-06-20 02:57:56 --> Total execution time: 0.4773
INFO - 2018-06-20 02:57:56 --> Config Class Initialized
INFO - 2018-06-20 02:57:56 --> Hooks Class Initialized
INFO - 2018-06-20 02:57:56 --> Config Class Initialized
INFO - 2018-06-20 02:57:56 --> Hooks Class Initialized
DEBUG - 2018-06-20 02:57:56 --> UTF-8 Support Enabled
INFO - 2018-06-20 02:57:56 --> Utf8 Class Initialized
DEBUG - 2018-06-20 02:57:56 --> UTF-8 Support Enabled
INFO - 2018-06-20 02:57:56 --> URI Class Initialized
INFO - 2018-06-20 02:57:56 --> Router Class Initialized
INFO - 2018-06-20 02:57:56 --> Output Class Initialized
INFO - 2018-06-20 02:57:56 --> Utf8 Class Initialized
INFO - 2018-06-20 02:57:56 --> Security Class Initialized
INFO - 2018-06-20 02:57:56 --> URI Class Initialized
DEBUG - 2018-06-20 02:57:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 02:57:56 --> Router Class Initialized
INFO - 2018-06-20 02:57:56 --> Input Class Initialized
INFO - 2018-06-20 02:57:56 --> Language Class Initialized
ERROR - 2018-06-20 02:57:56 --> 404 Page Not Found: /index
INFO - 2018-06-20 02:57:56 --> Output Class Initialized
INFO - 2018-06-20 02:57:56 --> Security Class Initialized
DEBUG - 2018-06-20 02:57:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 02:57:56 --> Input Class Initialized
INFO - 2018-06-20 02:57:56 --> Language Class Initialized
ERROR - 2018-06-20 02:57:56 --> 404 Page Not Found: /index
INFO - 2018-06-20 02:57:56 --> Config Class Initialized
INFO - 2018-06-20 02:57:56 --> Hooks Class Initialized
DEBUG - 2018-06-20 02:57:56 --> UTF-8 Support Enabled
INFO - 2018-06-20 02:57:56 --> Utf8 Class Initialized
INFO - 2018-06-20 02:57:56 --> URI Class Initialized
INFO - 2018-06-20 02:57:56 --> Router Class Initialized
INFO - 2018-06-20 02:57:57 --> Output Class Initialized
INFO - 2018-06-20 02:57:57 --> Security Class Initialized
DEBUG - 2018-06-20 02:57:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 02:57:57 --> Input Class Initialized
INFO - 2018-06-20 02:57:57 --> Language Class Initialized
ERROR - 2018-06-20 02:57:57 --> 404 Page Not Found: /index
INFO - 2018-06-20 02:57:57 --> Config Class Initialized
INFO - 2018-06-20 02:57:57 --> Hooks Class Initialized
DEBUG - 2018-06-20 02:57:57 --> UTF-8 Support Enabled
INFO - 2018-06-20 02:57:57 --> Utf8 Class Initialized
INFO - 2018-06-20 02:57:57 --> URI Class Initialized
INFO - 2018-06-20 02:57:57 --> Router Class Initialized
INFO - 2018-06-20 02:57:57 --> Output Class Initialized
INFO - 2018-06-20 02:57:57 --> Security Class Initialized
DEBUG - 2018-06-20 02:57:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 02:57:57 --> Input Class Initialized
INFO - 2018-06-20 02:57:57 --> Language Class Initialized
ERROR - 2018-06-20 02:57:57 --> 404 Page Not Found: /index
INFO - 2018-06-20 02:57:59 --> Config Class Initialized
INFO - 2018-06-20 02:57:59 --> Hooks Class Initialized
DEBUG - 2018-06-20 02:57:59 --> UTF-8 Support Enabled
INFO - 2018-06-20 02:57:59 --> Utf8 Class Initialized
INFO - 2018-06-20 02:57:59 --> URI Class Initialized
INFO - 2018-06-20 02:57:59 --> Router Class Initialized
INFO - 2018-06-20 02:57:59 --> Output Class Initialized
INFO - 2018-06-20 02:57:59 --> Security Class Initialized
DEBUG - 2018-06-20 02:58:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 02:58:00 --> Input Class Initialized
INFO - 2018-06-20 02:58:00 --> Language Class Initialized
INFO - 2018-06-20 02:58:00 --> Language Class Initialized
INFO - 2018-06-20 02:58:00 --> Config Class Initialized
INFO - 2018-06-20 02:58:00 --> Loader Class Initialized
DEBUG - 2018-06-20 02:58:00 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-20 02:58:00 --> Helper loaded: url_helper
INFO - 2018-06-20 02:58:00 --> Helper loaded: form_helper
INFO - 2018-06-20 02:58:00 --> Helper loaded: date_helper
INFO - 2018-06-20 02:58:00 --> Helper loaded: util_helper
INFO - 2018-06-20 02:58:00 --> Helper loaded: text_helper
INFO - 2018-06-20 02:58:00 --> Helper loaded: string_helper
INFO - 2018-06-20 02:58:00 --> Database Driver Class Initialized
DEBUG - 2018-06-20 02:58:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 02:58:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 02:58:00 --> Email Class Initialized
INFO - 2018-06-20 02:58:00 --> Controller Class Initialized
DEBUG - 2018-06-20 02:58:00 --> Home MX_Controller Initialized
DEBUG - 2018-06-20 02:58:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-20 02:58:00 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-20 02:58:00 --> Login MX_Controller Initialized
INFO - 2018-06-20 02:58:00 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-20 02:58:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-20 02:58:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-20 02:58:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-20 02:58:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-20 02:58:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-20 02:58:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-20 02:58:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-20 02:58:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-06-20 02:58:00 --> Final output sent to browser
DEBUG - 2018-06-20 02:58:00 --> Total execution time: 0.4696
INFO - 2018-06-20 02:58:00 --> Config Class Initialized
INFO - 2018-06-20 02:58:00 --> Config Class Initialized
INFO - 2018-06-20 02:58:00 --> Hooks Class Initialized
INFO - 2018-06-20 02:58:00 --> Hooks Class Initialized
DEBUG - 2018-06-20 02:58:00 --> UTF-8 Support Enabled
DEBUG - 2018-06-20 02:58:00 --> UTF-8 Support Enabled
INFO - 2018-06-20 02:58:00 --> Utf8 Class Initialized
INFO - 2018-06-20 02:58:00 --> Utf8 Class Initialized
INFO - 2018-06-20 02:58:00 --> URI Class Initialized
INFO - 2018-06-20 02:58:00 --> URI Class Initialized
INFO - 2018-06-20 02:58:00 --> Router Class Initialized
INFO - 2018-06-20 02:58:00 --> Router Class Initialized
INFO - 2018-06-20 02:58:00 --> Output Class Initialized
INFO - 2018-06-20 02:58:00 --> Output Class Initialized
INFO - 2018-06-20 02:58:00 --> Security Class Initialized
DEBUG - 2018-06-20 02:58:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 02:58:01 --> Input Class Initialized
INFO - 2018-06-20 02:58:01 --> Language Class Initialized
ERROR - 2018-06-20 02:58:01 --> 404 Page Not Found: /index
INFO - 2018-06-20 02:58:01 --> Security Class Initialized
DEBUG - 2018-06-20 02:58:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 02:58:01 --> Input Class Initialized
INFO - 2018-06-20 02:58:01 --> Language Class Initialized
ERROR - 2018-06-20 02:58:01 --> 404 Page Not Found: /index
INFO - 2018-06-20 02:58:01 --> Config Class Initialized
INFO - 2018-06-20 02:58:01 --> Hooks Class Initialized
DEBUG - 2018-06-20 02:58:01 --> UTF-8 Support Enabled
INFO - 2018-06-20 02:58:01 --> Utf8 Class Initialized
INFO - 2018-06-20 02:58:01 --> URI Class Initialized
INFO - 2018-06-20 02:58:01 --> Router Class Initialized
INFO - 2018-06-20 02:58:01 --> Output Class Initialized
INFO - 2018-06-20 02:58:01 --> Security Class Initialized
DEBUG - 2018-06-20 02:58:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 02:58:01 --> Input Class Initialized
INFO - 2018-06-20 02:58:01 --> Language Class Initialized
ERROR - 2018-06-20 02:58:01 --> 404 Page Not Found: /index
INFO - 2018-06-20 02:58:01 --> Config Class Initialized
INFO - 2018-06-20 02:58:01 --> Hooks Class Initialized
DEBUG - 2018-06-20 02:58:01 --> UTF-8 Support Enabled
INFO - 2018-06-20 02:58:01 --> Utf8 Class Initialized
INFO - 2018-06-20 02:58:01 --> URI Class Initialized
INFO - 2018-06-20 02:58:01 --> Router Class Initialized
INFO - 2018-06-20 02:58:01 --> Output Class Initialized
INFO - 2018-06-20 02:58:01 --> Security Class Initialized
DEBUG - 2018-06-20 02:58:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 02:58:01 --> Input Class Initialized
INFO - 2018-06-20 02:58:01 --> Language Class Initialized
ERROR - 2018-06-20 02:58:01 --> 404 Page Not Found: /index
INFO - 2018-06-20 02:58:40 --> Config Class Initialized
INFO - 2018-06-20 02:58:40 --> Hooks Class Initialized
DEBUG - 2018-06-20 02:58:40 --> UTF-8 Support Enabled
INFO - 2018-06-20 02:58:40 --> Utf8 Class Initialized
INFO - 2018-06-20 02:58:40 --> URI Class Initialized
INFO - 2018-06-20 02:58:40 --> Router Class Initialized
INFO - 2018-06-20 02:58:40 --> Output Class Initialized
INFO - 2018-06-20 02:58:40 --> Security Class Initialized
DEBUG - 2018-06-20 02:58:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 02:58:40 --> Input Class Initialized
INFO - 2018-06-20 02:58:40 --> Language Class Initialized
INFO - 2018-06-20 02:58:40 --> Language Class Initialized
INFO - 2018-06-20 02:58:40 --> Config Class Initialized
INFO - 2018-06-20 02:58:40 --> Loader Class Initialized
DEBUG - 2018-06-20 02:58:40 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-20 02:58:40 --> Helper loaded: url_helper
INFO - 2018-06-20 02:58:40 --> Helper loaded: form_helper
INFO - 2018-06-20 02:58:40 --> Helper loaded: date_helper
INFO - 2018-06-20 02:58:40 --> Helper loaded: util_helper
INFO - 2018-06-20 02:58:40 --> Helper loaded: text_helper
INFO - 2018-06-20 02:58:40 --> Helper loaded: string_helper
INFO - 2018-06-20 02:58:40 --> Database Driver Class Initialized
DEBUG - 2018-06-20 02:58:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 02:58:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 02:58:40 --> Email Class Initialized
INFO - 2018-06-20 02:58:40 --> Controller Class Initialized
DEBUG - 2018-06-20 02:58:40 --> Home MX_Controller Initialized
DEBUG - 2018-06-20 02:58:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-20 02:58:40 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-20 02:58:40 --> Login MX_Controller Initialized
INFO - 2018-06-20 02:58:40 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-20 02:58:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-20 02:58:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-20 02:58:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-20 02:58:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-20 02:58:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
INFO - 2018-06-20 02:58:47 --> Config Class Initialized
INFO - 2018-06-20 02:58:47 --> Hooks Class Initialized
DEBUG - 2018-06-20 02:58:47 --> UTF-8 Support Enabled
INFO - 2018-06-20 02:58:47 --> Utf8 Class Initialized
INFO - 2018-06-20 02:58:47 --> URI Class Initialized
INFO - 2018-06-20 02:58:47 --> Router Class Initialized
INFO - 2018-06-20 02:58:47 --> Output Class Initialized
INFO - 2018-06-20 02:58:47 --> Security Class Initialized
DEBUG - 2018-06-20 02:58:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 02:58:47 --> Input Class Initialized
INFO - 2018-06-20 02:58:47 --> Language Class Initialized
INFO - 2018-06-20 02:58:47 --> Language Class Initialized
INFO - 2018-06-20 02:58:47 --> Config Class Initialized
INFO - 2018-06-20 02:58:47 --> Loader Class Initialized
DEBUG - 2018-06-20 02:58:47 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-20 02:58:47 --> Helper loaded: url_helper
INFO - 2018-06-20 02:58:47 --> Helper loaded: form_helper
INFO - 2018-06-20 02:58:47 --> Helper loaded: date_helper
INFO - 2018-06-20 02:58:47 --> Helper loaded: util_helper
INFO - 2018-06-20 02:58:47 --> Helper loaded: text_helper
INFO - 2018-06-20 02:58:47 --> Helper loaded: string_helper
INFO - 2018-06-20 02:58:47 --> Database Driver Class Initialized
DEBUG - 2018-06-20 02:58:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 02:58:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 02:58:48 --> Email Class Initialized
INFO - 2018-06-20 02:58:48 --> Controller Class Initialized
DEBUG - 2018-06-20 02:58:48 --> Home MX_Controller Initialized
DEBUG - 2018-06-20 02:58:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-20 02:58:48 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-20 02:58:48 --> Login MX_Controller Initialized
INFO - 2018-06-20 02:58:48 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-20 02:58:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-20 02:58:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-20 02:58:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-20 02:58:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-20 02:58:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
INFO - 2018-06-20 03:06:08 --> Config Class Initialized
INFO - 2018-06-20 03:06:08 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:06:08 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:06:08 --> Utf8 Class Initialized
INFO - 2018-06-20 03:06:08 --> URI Class Initialized
DEBUG - 2018-06-20 03:06:08 --> No URI present. Default controller set.
INFO - 2018-06-20 03:06:08 --> Router Class Initialized
INFO - 2018-06-20 03:06:08 --> Output Class Initialized
INFO - 2018-06-20 03:06:08 --> Security Class Initialized
DEBUG - 2018-06-20 03:06:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:06:08 --> Input Class Initialized
INFO - 2018-06-20 03:06:08 --> Language Class Initialized
INFO - 2018-06-20 03:06:08 --> Language Class Initialized
INFO - 2018-06-20 03:06:08 --> Config Class Initialized
INFO - 2018-06-20 03:06:08 --> Loader Class Initialized
DEBUG - 2018-06-20 03:06:08 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-20 03:06:08 --> Helper loaded: url_helper
INFO - 2018-06-20 03:06:08 --> Helper loaded: form_helper
INFO - 2018-06-20 03:06:08 --> Helper loaded: date_helper
INFO - 2018-06-20 03:06:08 --> Helper loaded: util_helper
INFO - 2018-06-20 03:06:08 --> Helper loaded: text_helper
INFO - 2018-06-20 03:06:08 --> Helper loaded: string_helper
INFO - 2018-06-20 03:06:08 --> Database Driver Class Initialized
DEBUG - 2018-06-20 03:06:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 03:06:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 03:06:08 --> Email Class Initialized
INFO - 2018-06-20 03:06:08 --> Controller Class Initialized
DEBUG - 2018-06-20 03:06:08 --> Home MX_Controller Initialized
DEBUG - 2018-06-20 03:06:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-20 03:06:08 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-20 03:06:08 --> Login MX_Controller Initialized
INFO - 2018-06-20 03:06:08 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-20 03:06:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-20 03:06:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-20 03:06:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-06-20 03:14:55 --> Config Class Initialized
INFO - 2018-06-20 03:14:55 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:14:55 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:14:55 --> Utf8 Class Initialized
INFO - 2018-06-20 03:14:55 --> URI Class Initialized
INFO - 2018-06-20 03:14:55 --> Router Class Initialized
INFO - 2018-06-20 03:14:55 --> Output Class Initialized
INFO - 2018-06-20 03:14:55 --> Security Class Initialized
DEBUG - 2018-06-20 03:14:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:14:55 --> Input Class Initialized
INFO - 2018-06-20 03:14:55 --> Language Class Initialized
INFO - 2018-06-20 03:14:55 --> Language Class Initialized
INFO - 2018-06-20 03:14:55 --> Config Class Initialized
INFO - 2018-06-20 03:14:55 --> Loader Class Initialized
DEBUG - 2018-06-20 03:14:55 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-20 03:14:55 --> Helper loaded: url_helper
INFO - 2018-06-20 03:14:55 --> Helper loaded: form_helper
INFO - 2018-06-20 03:14:55 --> Helper loaded: date_helper
INFO - 2018-06-20 03:14:55 --> Helper loaded: util_helper
INFO - 2018-06-20 03:14:55 --> Helper loaded: text_helper
INFO - 2018-06-20 03:14:55 --> Helper loaded: string_helper
INFO - 2018-06-20 03:14:55 --> Database Driver Class Initialized
DEBUG - 2018-06-20 03:14:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 03:14:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 03:14:55 --> Email Class Initialized
INFO - 2018-06-20 03:14:55 --> Controller Class Initialized
DEBUG - 2018-06-20 03:14:55 --> Home MX_Controller Initialized
DEBUG - 2018-06-20 03:14:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-20 03:14:55 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-20 03:14:55 --> Login MX_Controller Initialized
INFO - 2018-06-20 03:14:55 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-20 03:14:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-20 03:14:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-20 03:14:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-20 03:14:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-20 03:14:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
INFO - 2018-06-20 03:15:50 --> Config Class Initialized
INFO - 2018-06-20 03:15:50 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:15:50 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:15:50 --> Utf8 Class Initialized
INFO - 2018-06-20 03:15:50 --> URI Class Initialized
INFO - 2018-06-20 03:15:50 --> Router Class Initialized
INFO - 2018-06-20 03:15:50 --> Output Class Initialized
INFO - 2018-06-20 03:15:50 --> Security Class Initialized
DEBUG - 2018-06-20 03:15:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:15:50 --> Input Class Initialized
INFO - 2018-06-20 03:15:50 --> Language Class Initialized
INFO - 2018-06-20 03:15:50 --> Language Class Initialized
INFO - 2018-06-20 03:15:50 --> Config Class Initialized
INFO - 2018-06-20 03:15:50 --> Loader Class Initialized
DEBUG - 2018-06-20 03:15:50 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-20 03:15:50 --> Helper loaded: url_helper
INFO - 2018-06-20 03:15:50 --> Helper loaded: form_helper
INFO - 2018-06-20 03:15:50 --> Helper loaded: date_helper
INFO - 2018-06-20 03:15:50 --> Helper loaded: util_helper
INFO - 2018-06-20 03:15:50 --> Helper loaded: text_helper
INFO - 2018-06-20 03:15:50 --> Helper loaded: string_helper
INFO - 2018-06-20 03:15:50 --> Database Driver Class Initialized
DEBUG - 2018-06-20 03:15:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 03:15:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 03:15:50 --> Email Class Initialized
INFO - 2018-06-20 03:15:50 --> Controller Class Initialized
DEBUG - 2018-06-20 03:15:50 --> Home MX_Controller Initialized
DEBUG - 2018-06-20 03:15:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-20 03:15:50 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-20 03:15:50 --> Login MX_Controller Initialized
INFO - 2018-06-20 03:15:50 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-20 03:15:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-20 03:15:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-20 03:15:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-20 03:15:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-20 03:15:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
INFO - 2018-06-20 03:16:28 --> Config Class Initialized
INFO - 2018-06-20 03:16:28 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:16:28 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:16:28 --> Utf8 Class Initialized
INFO - 2018-06-20 03:16:28 --> URI Class Initialized
INFO - 2018-06-20 03:16:28 --> Router Class Initialized
INFO - 2018-06-20 03:16:28 --> Output Class Initialized
INFO - 2018-06-20 03:16:28 --> Security Class Initialized
DEBUG - 2018-06-20 03:16:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:16:28 --> Input Class Initialized
INFO - 2018-06-20 03:16:28 --> Language Class Initialized
INFO - 2018-06-20 03:16:28 --> Language Class Initialized
INFO - 2018-06-20 03:16:28 --> Config Class Initialized
INFO - 2018-06-20 03:16:28 --> Loader Class Initialized
DEBUG - 2018-06-20 03:16:28 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-20 03:16:28 --> Helper loaded: url_helper
INFO - 2018-06-20 03:16:28 --> Helper loaded: form_helper
INFO - 2018-06-20 03:16:28 --> Helper loaded: date_helper
INFO - 2018-06-20 03:16:28 --> Helper loaded: util_helper
INFO - 2018-06-20 03:16:28 --> Helper loaded: text_helper
INFO - 2018-06-20 03:16:28 --> Helper loaded: string_helper
INFO - 2018-06-20 03:16:28 --> Database Driver Class Initialized
DEBUG - 2018-06-20 03:16:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 03:16:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 03:16:28 --> Email Class Initialized
INFO - 2018-06-20 03:16:28 --> Controller Class Initialized
DEBUG - 2018-06-20 03:16:28 --> Home MX_Controller Initialized
DEBUG - 2018-06-20 03:16:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-20 03:16:28 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-20 03:16:28 --> Login MX_Controller Initialized
INFO - 2018-06-20 03:16:28 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-20 03:16:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-20 03:16:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-20 03:16:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-20 03:16:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-20 03:16:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-20 03:16:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-20 03:16:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-20 03:16:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-06-20 03:16:28 --> Final output sent to browser
DEBUG - 2018-06-20 03:16:28 --> Total execution time: 0.5279
INFO - 2018-06-20 03:16:29 --> Config Class Initialized
INFO - 2018-06-20 03:16:29 --> Hooks Class Initialized
INFO - 2018-06-20 03:16:29 --> Config Class Initialized
INFO - 2018-06-20 03:16:29 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:16:29 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:16:29 --> Utf8 Class Initialized
DEBUG - 2018-06-20 03:16:29 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:16:29 --> URI Class Initialized
INFO - 2018-06-20 03:16:29 --> Utf8 Class Initialized
INFO - 2018-06-20 03:16:29 --> Router Class Initialized
INFO - 2018-06-20 03:16:29 --> URI Class Initialized
INFO - 2018-06-20 03:16:29 --> Output Class Initialized
INFO - 2018-06-20 03:16:29 --> Router Class Initialized
INFO - 2018-06-20 03:16:29 --> Security Class Initialized
INFO - 2018-06-20 03:16:29 --> Output Class Initialized
INFO - 2018-06-20 03:16:29 --> Security Class Initialized
DEBUG - 2018-06-20 03:16:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-06-20 03:16:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:16:29 --> Input Class Initialized
INFO - 2018-06-20 03:16:29 --> Input Class Initialized
INFO - 2018-06-20 03:16:29 --> Language Class Initialized
INFO - 2018-06-20 03:16:29 --> Language Class Initialized
ERROR - 2018-06-20 03:16:29 --> 404 Page Not Found: /index
ERROR - 2018-06-20 03:16:29 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:16:29 --> Config Class Initialized
INFO - 2018-06-20 03:16:29 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:16:29 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:16:29 --> Utf8 Class Initialized
INFO - 2018-06-20 03:16:29 --> URI Class Initialized
INFO - 2018-06-20 03:16:29 --> Router Class Initialized
INFO - 2018-06-20 03:16:29 --> Output Class Initialized
INFO - 2018-06-20 03:16:29 --> Security Class Initialized
DEBUG - 2018-06-20 03:16:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:16:29 --> Input Class Initialized
INFO - 2018-06-20 03:16:29 --> Language Class Initialized
ERROR - 2018-06-20 03:16:29 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:16:29 --> Config Class Initialized
INFO - 2018-06-20 03:16:29 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:16:29 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:16:29 --> Utf8 Class Initialized
INFO - 2018-06-20 03:16:30 --> URI Class Initialized
INFO - 2018-06-20 03:16:30 --> Router Class Initialized
INFO - 2018-06-20 03:16:30 --> Output Class Initialized
INFO - 2018-06-20 03:16:30 --> Security Class Initialized
DEBUG - 2018-06-20 03:16:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:16:30 --> Input Class Initialized
INFO - 2018-06-20 03:16:30 --> Language Class Initialized
ERROR - 2018-06-20 03:16:30 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:16:30 --> Config Class Initialized
INFO - 2018-06-20 03:16:30 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:16:30 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:16:30 --> Utf8 Class Initialized
INFO - 2018-06-20 03:16:30 --> URI Class Initialized
INFO - 2018-06-20 03:16:30 --> Router Class Initialized
INFO - 2018-06-20 03:16:30 --> Output Class Initialized
INFO - 2018-06-20 03:16:30 --> Security Class Initialized
DEBUG - 2018-06-20 03:16:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:16:30 --> Input Class Initialized
INFO - 2018-06-20 03:16:30 --> Language Class Initialized
ERROR - 2018-06-20 03:16:30 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:16:30 --> Config Class Initialized
INFO - 2018-06-20 03:16:30 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:16:30 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:16:30 --> Utf8 Class Initialized
INFO - 2018-06-20 03:16:30 --> URI Class Initialized
INFO - 2018-06-20 03:16:30 --> Router Class Initialized
INFO - 2018-06-20 03:16:30 --> Output Class Initialized
INFO - 2018-06-20 03:16:30 --> Security Class Initialized
DEBUG - 2018-06-20 03:16:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:16:30 --> Input Class Initialized
INFO - 2018-06-20 03:16:30 --> Language Class Initialized
ERROR - 2018-06-20 03:16:30 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:16:30 --> Config Class Initialized
INFO - 2018-06-20 03:16:30 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:16:30 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:16:30 --> Utf8 Class Initialized
INFO - 2018-06-20 03:16:30 --> URI Class Initialized
INFO - 2018-06-20 03:16:30 --> Router Class Initialized
INFO - 2018-06-20 03:16:30 --> Output Class Initialized
INFO - 2018-06-20 03:16:30 --> Security Class Initialized
DEBUG - 2018-06-20 03:16:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:16:30 --> Input Class Initialized
INFO - 2018-06-20 03:16:30 --> Language Class Initialized
ERROR - 2018-06-20 03:16:30 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:16:32 --> Config Class Initialized
INFO - 2018-06-20 03:16:32 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:16:32 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:16:32 --> Utf8 Class Initialized
INFO - 2018-06-20 03:16:32 --> URI Class Initialized
INFO - 2018-06-20 03:16:32 --> Router Class Initialized
INFO - 2018-06-20 03:16:32 --> Output Class Initialized
INFO - 2018-06-20 03:16:32 --> Security Class Initialized
DEBUG - 2018-06-20 03:16:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:16:32 --> Input Class Initialized
INFO - 2018-06-20 03:16:32 --> Language Class Initialized
INFO - 2018-06-20 03:16:32 --> Language Class Initialized
INFO - 2018-06-20 03:16:32 --> Config Class Initialized
INFO - 2018-06-20 03:16:32 --> Loader Class Initialized
DEBUG - 2018-06-20 03:16:32 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-20 03:16:32 --> Helper loaded: url_helper
INFO - 2018-06-20 03:16:32 --> Helper loaded: form_helper
INFO - 2018-06-20 03:16:32 --> Helper loaded: date_helper
INFO - 2018-06-20 03:16:32 --> Helper loaded: util_helper
INFO - 2018-06-20 03:16:32 --> Helper loaded: text_helper
INFO - 2018-06-20 03:16:32 --> Helper loaded: string_helper
INFO - 2018-06-20 03:16:32 --> Database Driver Class Initialized
DEBUG - 2018-06-20 03:16:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 03:16:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 03:16:32 --> Email Class Initialized
INFO - 2018-06-20 03:16:32 --> Controller Class Initialized
DEBUG - 2018-06-20 03:16:32 --> Home MX_Controller Initialized
DEBUG - 2018-06-20 03:16:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-20 03:16:32 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-20 03:16:32 --> Login MX_Controller Initialized
INFO - 2018-06-20 03:16:32 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-20 03:16:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-20 03:16:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-20 03:16:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-20 03:16:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-20 03:16:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
ERROR - 2018-06-20 03:16:32 --> Severity: Notice --> Undefined offset: 3 E:\xampp\htdocs\consulting\application\modules\home\views\course.php 192
DEBUG - 2018-06-20 03:16:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-20 03:16:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-20 03:16:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-06-20 03:16:32 --> Final output sent to browser
DEBUG - 2018-06-20 03:16:32 --> Total execution time: 0.4843
INFO - 2018-06-20 03:16:32 --> Config Class Initialized
INFO - 2018-06-20 03:16:32 --> Config Class Initialized
INFO - 2018-06-20 03:16:32 --> Hooks Class Initialized
INFO - 2018-06-20 03:16:32 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:16:32 --> UTF-8 Support Enabled
DEBUG - 2018-06-20 03:16:32 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:16:32 --> Utf8 Class Initialized
INFO - 2018-06-20 03:16:32 --> Utf8 Class Initialized
INFO - 2018-06-20 03:16:32 --> URI Class Initialized
INFO - 2018-06-20 03:16:32 --> URI Class Initialized
INFO - 2018-06-20 03:16:32 --> Router Class Initialized
INFO - 2018-06-20 03:16:32 --> Router Class Initialized
INFO - 2018-06-20 03:16:32 --> Output Class Initialized
INFO - 2018-06-20 03:16:32 --> Output Class Initialized
INFO - 2018-06-20 03:16:32 --> Security Class Initialized
DEBUG - 2018-06-20 03:16:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:16:32 --> Security Class Initialized
DEBUG - 2018-06-20 03:16:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:16:33 --> Input Class Initialized
INFO - 2018-06-20 03:16:33 --> Input Class Initialized
INFO - 2018-06-20 03:16:33 --> Language Class Initialized
INFO - 2018-06-20 03:16:33 --> Language Class Initialized
ERROR - 2018-06-20 03:16:33 --> 404 Page Not Found: /index
ERROR - 2018-06-20 03:16:33 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:16:33 --> Config Class Initialized
INFO - 2018-06-20 03:16:33 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:16:33 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:16:33 --> Utf8 Class Initialized
INFO - 2018-06-20 03:16:33 --> URI Class Initialized
INFO - 2018-06-20 03:16:33 --> Router Class Initialized
INFO - 2018-06-20 03:16:33 --> Output Class Initialized
INFO - 2018-06-20 03:16:33 --> Security Class Initialized
DEBUG - 2018-06-20 03:16:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:16:33 --> Input Class Initialized
INFO - 2018-06-20 03:16:33 --> Language Class Initialized
ERROR - 2018-06-20 03:16:33 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:16:33 --> Config Class Initialized
INFO - 2018-06-20 03:16:33 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:16:33 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:16:33 --> Utf8 Class Initialized
INFO - 2018-06-20 03:16:33 --> URI Class Initialized
INFO - 2018-06-20 03:16:33 --> Router Class Initialized
INFO - 2018-06-20 03:16:33 --> Output Class Initialized
INFO - 2018-06-20 03:16:33 --> Security Class Initialized
DEBUG - 2018-06-20 03:16:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:16:33 --> Input Class Initialized
INFO - 2018-06-20 03:16:33 --> Language Class Initialized
ERROR - 2018-06-20 03:16:33 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:17:35 --> Config Class Initialized
INFO - 2018-06-20 03:17:35 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:17:35 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:17:35 --> Utf8 Class Initialized
INFO - 2018-06-20 03:17:35 --> URI Class Initialized
INFO - 2018-06-20 03:17:35 --> Router Class Initialized
INFO - 2018-06-20 03:17:35 --> Output Class Initialized
INFO - 2018-06-20 03:17:35 --> Security Class Initialized
DEBUG - 2018-06-20 03:17:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:17:35 --> Input Class Initialized
INFO - 2018-06-20 03:17:35 --> Language Class Initialized
INFO - 2018-06-20 03:17:35 --> Language Class Initialized
INFO - 2018-06-20 03:17:35 --> Config Class Initialized
INFO - 2018-06-20 03:17:35 --> Loader Class Initialized
DEBUG - 2018-06-20 03:17:35 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-20 03:17:35 --> Helper loaded: url_helper
INFO - 2018-06-20 03:17:35 --> Helper loaded: form_helper
INFO - 2018-06-20 03:17:35 --> Helper loaded: date_helper
INFO - 2018-06-20 03:17:35 --> Helper loaded: util_helper
INFO - 2018-06-20 03:17:35 --> Helper loaded: text_helper
INFO - 2018-06-20 03:17:35 --> Helper loaded: string_helper
INFO - 2018-06-20 03:17:35 --> Database Driver Class Initialized
DEBUG - 2018-06-20 03:17:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 03:17:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 03:17:35 --> Email Class Initialized
INFO - 2018-06-20 03:17:35 --> Controller Class Initialized
DEBUG - 2018-06-20 03:17:35 --> Home MX_Controller Initialized
DEBUG - 2018-06-20 03:17:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-20 03:17:35 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-20 03:17:35 --> Login MX_Controller Initialized
INFO - 2018-06-20 03:17:35 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-20 03:17:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-20 03:17:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-20 03:17:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-20 03:17:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-20 03:17:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
ERROR - 2018-06-20 03:17:35 --> Severity: Notice --> Undefined offset: 3 E:\xampp\htdocs\consulting\application\modules\home\views\course.php 192
ERROR - 2018-06-20 03:17:35 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable E:\xampp\htdocs\consulting\application\modules\home\views\course.php 193
DEBUG - 2018-06-20 03:17:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-20 03:17:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-20 03:17:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-06-20 03:17:35 --> Final output sent to browser
DEBUG - 2018-06-20 03:17:35 --> Total execution time: 0.5078
INFO - 2018-06-20 03:17:35 --> Config Class Initialized
INFO - 2018-06-20 03:17:35 --> Hooks Class Initialized
INFO - 2018-06-20 03:17:36 --> Config Class Initialized
DEBUG - 2018-06-20 03:17:36 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:17:36 --> Hooks Class Initialized
INFO - 2018-06-20 03:17:36 --> Utf8 Class Initialized
INFO - 2018-06-20 03:17:36 --> URI Class Initialized
DEBUG - 2018-06-20 03:17:36 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:17:36 --> Utf8 Class Initialized
INFO - 2018-06-20 03:17:36 --> Router Class Initialized
INFO - 2018-06-20 03:17:36 --> Output Class Initialized
INFO - 2018-06-20 03:17:36 --> URI Class Initialized
INFO - 2018-06-20 03:17:36 --> Security Class Initialized
INFO - 2018-06-20 03:17:36 --> Router Class Initialized
DEBUG - 2018-06-20 03:17:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:17:36 --> Input Class Initialized
INFO - 2018-06-20 03:17:36 --> Output Class Initialized
INFO - 2018-06-20 03:17:36 --> Language Class Initialized
INFO - 2018-06-20 03:17:36 --> Security Class Initialized
DEBUG - 2018-06-20 03:17:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-06-20 03:17:36 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:17:36 --> Input Class Initialized
INFO - 2018-06-20 03:17:36 --> Language Class Initialized
ERROR - 2018-06-20 03:17:36 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:17:36 --> Config Class Initialized
INFO - 2018-06-20 03:17:36 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:17:36 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:17:36 --> Utf8 Class Initialized
INFO - 2018-06-20 03:17:36 --> URI Class Initialized
INFO - 2018-06-20 03:17:36 --> Router Class Initialized
INFO - 2018-06-20 03:17:36 --> Output Class Initialized
INFO - 2018-06-20 03:17:36 --> Security Class Initialized
DEBUG - 2018-06-20 03:17:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:17:36 --> Input Class Initialized
INFO - 2018-06-20 03:17:36 --> Language Class Initialized
ERROR - 2018-06-20 03:17:36 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:17:36 --> Config Class Initialized
INFO - 2018-06-20 03:17:36 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:17:36 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:17:36 --> Utf8 Class Initialized
INFO - 2018-06-20 03:17:36 --> URI Class Initialized
INFO - 2018-06-20 03:17:36 --> Router Class Initialized
INFO - 2018-06-20 03:17:36 --> Output Class Initialized
INFO - 2018-06-20 03:17:36 --> Security Class Initialized
DEBUG - 2018-06-20 03:17:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:17:36 --> Input Class Initialized
INFO - 2018-06-20 03:17:36 --> Language Class Initialized
ERROR - 2018-06-20 03:17:36 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:17:36 --> Config Class Initialized
INFO - 2018-06-20 03:17:36 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:17:36 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:17:36 --> Utf8 Class Initialized
INFO - 2018-06-20 03:17:36 --> URI Class Initialized
INFO - 2018-06-20 03:17:36 --> Router Class Initialized
INFO - 2018-06-20 03:17:36 --> Output Class Initialized
INFO - 2018-06-20 03:17:36 --> Security Class Initialized
DEBUG - 2018-06-20 03:17:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:17:36 --> Input Class Initialized
INFO - 2018-06-20 03:17:36 --> Language Class Initialized
ERROR - 2018-06-20 03:17:36 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:17:36 --> Config Class Initialized
INFO - 2018-06-20 03:17:37 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:17:37 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:17:37 --> Utf8 Class Initialized
INFO - 2018-06-20 03:17:37 --> URI Class Initialized
INFO - 2018-06-20 03:17:37 --> Router Class Initialized
INFO - 2018-06-20 03:17:37 --> Output Class Initialized
INFO - 2018-06-20 03:17:37 --> Security Class Initialized
DEBUG - 2018-06-20 03:17:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:17:37 --> Input Class Initialized
INFO - 2018-06-20 03:17:37 --> Language Class Initialized
ERROR - 2018-06-20 03:17:37 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:17:37 --> Config Class Initialized
INFO - 2018-06-20 03:17:37 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:17:37 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:17:37 --> Utf8 Class Initialized
INFO - 2018-06-20 03:17:37 --> URI Class Initialized
INFO - 2018-06-20 03:17:37 --> Router Class Initialized
INFO - 2018-06-20 03:17:37 --> Output Class Initialized
INFO - 2018-06-20 03:17:37 --> Security Class Initialized
DEBUG - 2018-06-20 03:17:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:17:37 --> Input Class Initialized
INFO - 2018-06-20 03:17:37 --> Language Class Initialized
ERROR - 2018-06-20 03:17:37 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:17:55 --> Config Class Initialized
INFO - 2018-06-20 03:17:55 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:17:55 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:17:55 --> Utf8 Class Initialized
INFO - 2018-06-20 03:17:55 --> URI Class Initialized
INFO - 2018-06-20 03:17:55 --> Router Class Initialized
INFO - 2018-06-20 03:17:55 --> Output Class Initialized
INFO - 2018-06-20 03:17:55 --> Security Class Initialized
DEBUG - 2018-06-20 03:17:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:17:55 --> Input Class Initialized
INFO - 2018-06-20 03:17:55 --> Language Class Initialized
INFO - 2018-06-20 03:17:55 --> Language Class Initialized
INFO - 2018-06-20 03:17:55 --> Config Class Initialized
INFO - 2018-06-20 03:17:55 --> Loader Class Initialized
DEBUG - 2018-06-20 03:17:55 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-20 03:17:55 --> Helper loaded: url_helper
INFO - 2018-06-20 03:17:55 --> Helper loaded: form_helper
INFO - 2018-06-20 03:17:55 --> Helper loaded: date_helper
INFO - 2018-06-20 03:17:55 --> Helper loaded: util_helper
INFO - 2018-06-20 03:17:55 --> Helper loaded: text_helper
INFO - 2018-06-20 03:17:55 --> Helper loaded: string_helper
INFO - 2018-06-20 03:17:55 --> Database Driver Class Initialized
DEBUG - 2018-06-20 03:17:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 03:17:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 03:17:55 --> Email Class Initialized
INFO - 2018-06-20 03:17:55 --> Controller Class Initialized
DEBUG - 2018-06-20 03:17:55 --> Home MX_Controller Initialized
DEBUG - 2018-06-20 03:17:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-20 03:17:55 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-20 03:17:55 --> Login MX_Controller Initialized
INFO - 2018-06-20 03:17:55 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-20 03:17:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-20 03:17:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-20 03:17:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-20 03:17:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-20 03:17:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
ERROR - 2018-06-20 03:17:55 --> Severity: Notice --> Undefined offset: 3 E:\xampp\htdocs\consulting\application\modules\home\views\course.php 192
DEBUG - 2018-06-20 03:17:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-20 03:17:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-20 03:17:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-06-20 03:17:55 --> Final output sent to browser
DEBUG - 2018-06-20 03:17:55 --> Total execution time: 0.4925
INFO - 2018-06-20 03:17:56 --> Config Class Initialized
INFO - 2018-06-20 03:17:56 --> Config Class Initialized
INFO - 2018-06-20 03:17:56 --> Hooks Class Initialized
INFO - 2018-06-20 03:17:56 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:17:56 --> UTF-8 Support Enabled
DEBUG - 2018-06-20 03:17:56 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:17:56 --> Utf8 Class Initialized
INFO - 2018-06-20 03:17:56 --> Utf8 Class Initialized
INFO - 2018-06-20 03:17:56 --> URI Class Initialized
INFO - 2018-06-20 03:17:56 --> Router Class Initialized
INFO - 2018-06-20 03:17:56 --> Output Class Initialized
INFO - 2018-06-20 03:17:56 --> URI Class Initialized
INFO - 2018-06-20 03:17:56 --> Security Class Initialized
INFO - 2018-06-20 03:17:56 --> Router Class Initialized
DEBUG - 2018-06-20 03:17:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:17:56 --> Output Class Initialized
INFO - 2018-06-20 03:17:56 --> Input Class Initialized
INFO - 2018-06-20 03:17:56 --> Security Class Initialized
INFO - 2018-06-20 03:17:56 --> Language Class Initialized
DEBUG - 2018-06-20 03:17:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-06-20 03:17:56 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:17:56 --> Input Class Initialized
INFO - 2018-06-20 03:17:56 --> Config Class Initialized
INFO - 2018-06-20 03:17:56 --> Hooks Class Initialized
INFO - 2018-06-20 03:17:56 --> Language Class Initialized
DEBUG - 2018-06-20 03:17:56 --> UTF-8 Support Enabled
ERROR - 2018-06-20 03:17:56 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:17:56 --> Utf8 Class Initialized
INFO - 2018-06-20 03:17:56 --> URI Class Initialized
INFO - 2018-06-20 03:17:56 --> Router Class Initialized
INFO - 2018-06-20 03:17:56 --> Output Class Initialized
INFO - 2018-06-20 03:17:56 --> Security Class Initialized
DEBUG - 2018-06-20 03:17:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:17:56 --> Input Class Initialized
INFO - 2018-06-20 03:17:56 --> Language Class Initialized
ERROR - 2018-06-20 03:17:56 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:17:56 --> Config Class Initialized
INFO - 2018-06-20 03:17:56 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:17:56 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:17:56 --> Utf8 Class Initialized
INFO - 2018-06-20 03:17:56 --> URI Class Initialized
INFO - 2018-06-20 03:17:56 --> Router Class Initialized
INFO - 2018-06-20 03:17:56 --> Output Class Initialized
INFO - 2018-06-20 03:17:56 --> Security Class Initialized
DEBUG - 2018-06-20 03:17:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:17:56 --> Input Class Initialized
INFO - 2018-06-20 03:17:56 --> Language Class Initialized
ERROR - 2018-06-20 03:17:56 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:17:57 --> Config Class Initialized
INFO - 2018-06-20 03:17:57 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:17:57 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:17:57 --> Utf8 Class Initialized
INFO - 2018-06-20 03:17:57 --> URI Class Initialized
INFO - 2018-06-20 03:17:57 --> Router Class Initialized
INFO - 2018-06-20 03:17:57 --> Output Class Initialized
INFO - 2018-06-20 03:17:57 --> Security Class Initialized
DEBUG - 2018-06-20 03:17:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:17:57 --> Input Class Initialized
INFO - 2018-06-20 03:17:57 --> Language Class Initialized
ERROR - 2018-06-20 03:17:57 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:17:57 --> Config Class Initialized
INFO - 2018-06-20 03:17:57 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:17:57 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:17:57 --> Utf8 Class Initialized
INFO - 2018-06-20 03:17:57 --> URI Class Initialized
INFO - 2018-06-20 03:17:57 --> Router Class Initialized
INFO - 2018-06-20 03:17:57 --> Output Class Initialized
INFO - 2018-06-20 03:17:57 --> Security Class Initialized
DEBUG - 2018-06-20 03:17:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:17:57 --> Input Class Initialized
INFO - 2018-06-20 03:17:57 --> Language Class Initialized
ERROR - 2018-06-20 03:17:57 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:17:57 --> Config Class Initialized
INFO - 2018-06-20 03:17:57 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:17:57 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:17:57 --> Utf8 Class Initialized
INFO - 2018-06-20 03:17:57 --> URI Class Initialized
INFO - 2018-06-20 03:17:57 --> Router Class Initialized
INFO - 2018-06-20 03:17:57 --> Output Class Initialized
INFO - 2018-06-20 03:17:57 --> Security Class Initialized
DEBUG - 2018-06-20 03:17:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:17:57 --> Input Class Initialized
INFO - 2018-06-20 03:17:57 --> Language Class Initialized
ERROR - 2018-06-20 03:17:57 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:19:41 --> Config Class Initialized
INFO - 2018-06-20 03:19:41 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:19:41 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:19:41 --> Utf8 Class Initialized
INFO - 2018-06-20 03:19:41 --> URI Class Initialized
INFO - 2018-06-20 03:19:41 --> Router Class Initialized
INFO - 2018-06-20 03:19:41 --> Output Class Initialized
INFO - 2018-06-20 03:19:41 --> Security Class Initialized
DEBUG - 2018-06-20 03:19:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:19:41 --> Input Class Initialized
INFO - 2018-06-20 03:19:41 --> Language Class Initialized
INFO - 2018-06-20 03:19:41 --> Language Class Initialized
INFO - 2018-06-20 03:19:41 --> Config Class Initialized
INFO - 2018-06-20 03:19:41 --> Loader Class Initialized
DEBUG - 2018-06-20 03:19:41 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-20 03:19:41 --> Helper loaded: url_helper
INFO - 2018-06-20 03:19:41 --> Helper loaded: form_helper
INFO - 2018-06-20 03:19:41 --> Helper loaded: date_helper
INFO - 2018-06-20 03:19:41 --> Helper loaded: util_helper
INFO - 2018-06-20 03:19:41 --> Helper loaded: text_helper
INFO - 2018-06-20 03:19:41 --> Helper loaded: string_helper
INFO - 2018-06-20 03:19:41 --> Database Driver Class Initialized
DEBUG - 2018-06-20 03:19:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 03:19:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 03:19:41 --> Email Class Initialized
INFO - 2018-06-20 03:19:41 --> Controller Class Initialized
DEBUG - 2018-06-20 03:19:41 --> Home MX_Controller Initialized
DEBUG - 2018-06-20 03:19:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-20 03:19:41 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-20 03:19:41 --> Login MX_Controller Initialized
INFO - 2018-06-20 03:19:41 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-20 03:19:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-20 03:19:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-20 03:19:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-20 03:19:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-20 03:19:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
ERROR - 2018-06-20 03:19:41 --> Severity: Notice --> Undefined offset: 3 E:\xampp\htdocs\consulting\application\modules\home\views\course.php 195
DEBUG - 2018-06-20 03:19:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-20 03:19:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-20 03:19:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-06-20 03:19:41 --> Final output sent to browser
DEBUG - 2018-06-20 03:19:41 --> Total execution time: 0.5181
INFO - 2018-06-20 03:19:42 --> Config Class Initialized
INFO - 2018-06-20 03:19:42 --> Config Class Initialized
INFO - 2018-06-20 03:19:42 --> Hooks Class Initialized
INFO - 2018-06-20 03:19:42 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:19:42 --> UTF-8 Support Enabled
DEBUG - 2018-06-20 03:19:42 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:19:42 --> Utf8 Class Initialized
INFO - 2018-06-20 03:19:42 --> Utf8 Class Initialized
INFO - 2018-06-20 03:19:42 --> URI Class Initialized
INFO - 2018-06-20 03:19:42 --> URI Class Initialized
INFO - 2018-06-20 03:19:42 --> Router Class Initialized
INFO - 2018-06-20 03:19:42 --> Router Class Initialized
INFO - 2018-06-20 03:19:42 --> Output Class Initialized
INFO - 2018-06-20 03:19:42 --> Output Class Initialized
INFO - 2018-06-20 03:19:42 --> Security Class Initialized
INFO - 2018-06-20 03:19:42 --> Security Class Initialized
DEBUG - 2018-06-20 03:19:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-06-20 03:19:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:19:42 --> Input Class Initialized
INFO - 2018-06-20 03:19:42 --> Input Class Initialized
INFO - 2018-06-20 03:19:42 --> Language Class Initialized
ERROR - 2018-06-20 03:19:42 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:19:42 --> Config Class Initialized
INFO - 2018-06-20 03:19:42 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:19:42 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:19:42 --> Language Class Initialized
INFO - 2018-06-20 03:19:42 --> Utf8 Class Initialized
ERROR - 2018-06-20 03:19:42 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:19:42 --> URI Class Initialized
INFO - 2018-06-20 03:19:42 --> Router Class Initialized
INFO - 2018-06-20 03:19:42 --> Output Class Initialized
INFO - 2018-06-20 03:19:42 --> Security Class Initialized
DEBUG - 2018-06-20 03:19:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:19:42 --> Input Class Initialized
INFO - 2018-06-20 03:19:42 --> Language Class Initialized
ERROR - 2018-06-20 03:19:42 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:19:42 --> Config Class Initialized
INFO - 2018-06-20 03:19:42 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:19:42 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:19:42 --> Utf8 Class Initialized
INFO - 2018-06-20 03:19:42 --> URI Class Initialized
INFO - 2018-06-20 03:19:42 --> Router Class Initialized
INFO - 2018-06-20 03:19:42 --> Output Class Initialized
INFO - 2018-06-20 03:19:42 --> Security Class Initialized
DEBUG - 2018-06-20 03:19:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:19:42 --> Input Class Initialized
INFO - 2018-06-20 03:19:42 --> Language Class Initialized
ERROR - 2018-06-20 03:19:42 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:19:43 --> Config Class Initialized
INFO - 2018-06-20 03:19:43 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:19:43 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:19:43 --> Utf8 Class Initialized
INFO - 2018-06-20 03:19:43 --> URI Class Initialized
INFO - 2018-06-20 03:19:43 --> Router Class Initialized
INFO - 2018-06-20 03:19:43 --> Output Class Initialized
INFO - 2018-06-20 03:19:43 --> Security Class Initialized
DEBUG - 2018-06-20 03:19:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:19:43 --> Input Class Initialized
INFO - 2018-06-20 03:19:43 --> Language Class Initialized
ERROR - 2018-06-20 03:19:43 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:19:43 --> Config Class Initialized
INFO - 2018-06-20 03:19:43 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:19:43 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:19:43 --> Utf8 Class Initialized
INFO - 2018-06-20 03:19:43 --> URI Class Initialized
INFO - 2018-06-20 03:19:43 --> Router Class Initialized
INFO - 2018-06-20 03:19:43 --> Output Class Initialized
INFO - 2018-06-20 03:19:43 --> Security Class Initialized
DEBUG - 2018-06-20 03:19:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:19:43 --> Input Class Initialized
INFO - 2018-06-20 03:19:43 --> Language Class Initialized
ERROR - 2018-06-20 03:19:43 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:19:43 --> Config Class Initialized
INFO - 2018-06-20 03:19:43 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:19:43 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:19:43 --> Utf8 Class Initialized
INFO - 2018-06-20 03:19:43 --> URI Class Initialized
INFO - 2018-06-20 03:19:43 --> Router Class Initialized
INFO - 2018-06-20 03:19:43 --> Output Class Initialized
INFO - 2018-06-20 03:19:43 --> Security Class Initialized
DEBUG - 2018-06-20 03:19:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:19:43 --> Input Class Initialized
INFO - 2018-06-20 03:19:43 --> Language Class Initialized
ERROR - 2018-06-20 03:19:43 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:19:56 --> Config Class Initialized
INFO - 2018-06-20 03:19:56 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:19:56 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:19:56 --> Utf8 Class Initialized
INFO - 2018-06-20 03:19:56 --> URI Class Initialized
INFO - 2018-06-20 03:19:56 --> Router Class Initialized
INFO - 2018-06-20 03:19:56 --> Output Class Initialized
INFO - 2018-06-20 03:19:56 --> Security Class Initialized
DEBUG - 2018-06-20 03:19:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:19:56 --> Input Class Initialized
INFO - 2018-06-20 03:19:56 --> Language Class Initialized
INFO - 2018-06-20 03:19:56 --> Language Class Initialized
INFO - 2018-06-20 03:19:56 --> Config Class Initialized
INFO - 2018-06-20 03:19:56 --> Loader Class Initialized
DEBUG - 2018-06-20 03:19:56 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-20 03:19:56 --> Helper loaded: url_helper
INFO - 2018-06-20 03:19:56 --> Helper loaded: form_helper
INFO - 2018-06-20 03:19:56 --> Helper loaded: date_helper
INFO - 2018-06-20 03:19:56 --> Helper loaded: util_helper
INFO - 2018-06-20 03:19:56 --> Helper loaded: text_helper
INFO - 2018-06-20 03:19:56 --> Helper loaded: string_helper
INFO - 2018-06-20 03:19:56 --> Database Driver Class Initialized
DEBUG - 2018-06-20 03:19:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 03:19:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 03:19:56 --> Email Class Initialized
INFO - 2018-06-20 03:19:56 --> Controller Class Initialized
DEBUG - 2018-06-20 03:19:56 --> Home MX_Controller Initialized
DEBUG - 2018-06-20 03:19:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-20 03:19:56 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-20 03:19:56 --> Login MX_Controller Initialized
INFO - 2018-06-20 03:19:56 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-20 03:19:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-20 03:19:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-20 03:19:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-20 03:19:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-20 03:19:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-20 03:19:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-20 03:19:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-20 03:19:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-06-20 03:19:56 --> Final output sent to browser
DEBUG - 2018-06-20 03:19:56 --> Total execution time: 0.5138
INFO - 2018-06-20 03:19:57 --> Config Class Initialized
INFO - 2018-06-20 03:19:57 --> Config Class Initialized
INFO - 2018-06-20 03:19:57 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:19:57 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:19:57 --> Utf8 Class Initialized
INFO - 2018-06-20 03:19:57 --> URI Class Initialized
INFO - 2018-06-20 03:19:57 --> Router Class Initialized
INFO - 2018-06-20 03:19:57 --> Output Class Initialized
INFO - 2018-06-20 03:19:57 --> Security Class Initialized
DEBUG - 2018-06-20 03:19:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:19:57 --> Input Class Initialized
INFO - 2018-06-20 03:19:57 --> Language Class Initialized
ERROR - 2018-06-20 03:19:57 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:19:57 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:19:57 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:19:57 --> Utf8 Class Initialized
INFO - 2018-06-20 03:19:57 --> URI Class Initialized
INFO - 2018-06-20 03:19:57 --> Router Class Initialized
INFO - 2018-06-20 03:19:57 --> Output Class Initialized
INFO - 2018-06-20 03:19:57 --> Security Class Initialized
DEBUG - 2018-06-20 03:19:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:19:57 --> Input Class Initialized
INFO - 2018-06-20 03:19:57 --> Language Class Initialized
ERROR - 2018-06-20 03:19:57 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:19:57 --> Config Class Initialized
INFO - 2018-06-20 03:19:57 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:19:57 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:19:57 --> Utf8 Class Initialized
INFO - 2018-06-20 03:19:57 --> URI Class Initialized
INFO - 2018-06-20 03:19:58 --> Router Class Initialized
INFO - 2018-06-20 03:19:58 --> Output Class Initialized
INFO - 2018-06-20 03:19:58 --> Security Class Initialized
DEBUG - 2018-06-20 03:19:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:19:58 --> Input Class Initialized
INFO - 2018-06-20 03:19:58 --> Language Class Initialized
ERROR - 2018-06-20 03:19:58 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:19:58 --> Config Class Initialized
INFO - 2018-06-20 03:19:58 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:19:58 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:19:58 --> Utf8 Class Initialized
INFO - 2018-06-20 03:19:58 --> URI Class Initialized
INFO - 2018-06-20 03:19:58 --> Router Class Initialized
INFO - 2018-06-20 03:19:58 --> Output Class Initialized
INFO - 2018-06-20 03:19:58 --> Security Class Initialized
DEBUG - 2018-06-20 03:19:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:19:58 --> Input Class Initialized
INFO - 2018-06-20 03:19:58 --> Language Class Initialized
ERROR - 2018-06-20 03:19:58 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:19:58 --> Config Class Initialized
INFO - 2018-06-20 03:19:58 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:19:58 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:19:58 --> Utf8 Class Initialized
INFO - 2018-06-20 03:19:58 --> URI Class Initialized
INFO - 2018-06-20 03:19:58 --> Router Class Initialized
INFO - 2018-06-20 03:19:58 --> Output Class Initialized
INFO - 2018-06-20 03:19:58 --> Security Class Initialized
DEBUG - 2018-06-20 03:19:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:19:58 --> Input Class Initialized
INFO - 2018-06-20 03:19:58 --> Language Class Initialized
ERROR - 2018-06-20 03:19:58 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:19:58 --> Config Class Initialized
INFO - 2018-06-20 03:19:58 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:19:58 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:19:58 --> Utf8 Class Initialized
INFO - 2018-06-20 03:19:58 --> URI Class Initialized
INFO - 2018-06-20 03:19:58 --> Router Class Initialized
INFO - 2018-06-20 03:19:58 --> Output Class Initialized
INFO - 2018-06-20 03:19:58 --> Security Class Initialized
DEBUG - 2018-06-20 03:19:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:19:58 --> Input Class Initialized
INFO - 2018-06-20 03:19:58 --> Language Class Initialized
ERROR - 2018-06-20 03:19:58 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:19:58 --> Config Class Initialized
INFO - 2018-06-20 03:19:58 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:19:58 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:19:58 --> Utf8 Class Initialized
INFO - 2018-06-20 03:19:58 --> URI Class Initialized
INFO - 2018-06-20 03:19:58 --> Router Class Initialized
INFO - 2018-06-20 03:19:58 --> Output Class Initialized
INFO - 2018-06-20 03:19:58 --> Security Class Initialized
DEBUG - 2018-06-20 03:19:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:19:58 --> Input Class Initialized
INFO - 2018-06-20 03:19:58 --> Language Class Initialized
ERROR - 2018-06-20 03:19:58 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:20:25 --> Config Class Initialized
INFO - 2018-06-20 03:20:25 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:20:25 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:20:25 --> Utf8 Class Initialized
INFO - 2018-06-20 03:20:25 --> URI Class Initialized
INFO - 2018-06-20 03:20:25 --> Router Class Initialized
INFO - 2018-06-20 03:20:25 --> Output Class Initialized
INFO - 2018-06-20 03:20:25 --> Security Class Initialized
DEBUG - 2018-06-20 03:20:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:20:25 --> Input Class Initialized
INFO - 2018-06-20 03:20:25 --> Language Class Initialized
INFO - 2018-06-20 03:20:25 --> Language Class Initialized
INFO - 2018-06-20 03:20:25 --> Config Class Initialized
INFO - 2018-06-20 03:20:25 --> Loader Class Initialized
DEBUG - 2018-06-20 03:20:25 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-20 03:20:25 --> Helper loaded: url_helper
INFO - 2018-06-20 03:20:25 --> Helper loaded: form_helper
INFO - 2018-06-20 03:20:26 --> Helper loaded: date_helper
INFO - 2018-06-20 03:20:26 --> Helper loaded: util_helper
INFO - 2018-06-20 03:20:26 --> Helper loaded: text_helper
INFO - 2018-06-20 03:20:26 --> Helper loaded: string_helper
INFO - 2018-06-20 03:20:26 --> Database Driver Class Initialized
DEBUG - 2018-06-20 03:20:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 03:20:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 03:20:26 --> Email Class Initialized
INFO - 2018-06-20 03:20:26 --> Controller Class Initialized
DEBUG - 2018-06-20 03:20:26 --> Home MX_Controller Initialized
DEBUG - 2018-06-20 03:20:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-20 03:20:26 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-20 03:20:26 --> Login MX_Controller Initialized
INFO - 2018-06-20 03:20:26 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-20 03:20:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-20 03:20:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-20 03:20:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-20 03:20:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-20 03:20:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-20 03:20:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-20 03:20:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-20 03:20:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-06-20 03:20:26 --> Final output sent to browser
DEBUG - 2018-06-20 03:20:26 --> Total execution time: 0.5214
INFO - 2018-06-20 03:20:26 --> Config Class Initialized
INFO - 2018-06-20 03:20:26 --> Config Class Initialized
INFO - 2018-06-20 03:20:26 --> Hooks Class Initialized
INFO - 2018-06-20 03:20:26 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:20:26 --> UTF-8 Support Enabled
DEBUG - 2018-06-20 03:20:26 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:20:26 --> Utf8 Class Initialized
INFO - 2018-06-20 03:20:26 --> Utf8 Class Initialized
INFO - 2018-06-20 03:20:26 --> URI Class Initialized
INFO - 2018-06-20 03:20:26 --> Router Class Initialized
INFO - 2018-06-20 03:20:26 --> URI Class Initialized
INFO - 2018-06-20 03:20:26 --> Output Class Initialized
INFO - 2018-06-20 03:20:26 --> Router Class Initialized
INFO - 2018-06-20 03:20:26 --> Output Class Initialized
INFO - 2018-06-20 03:20:26 --> Security Class Initialized
INFO - 2018-06-20 03:20:26 --> Security Class Initialized
DEBUG - 2018-06-20 03:20:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:20:26 --> Input Class Initialized
INFO - 2018-06-20 03:20:27 --> Language Class Initialized
DEBUG - 2018-06-20 03:20:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:20:27 --> Input Class Initialized
ERROR - 2018-06-20 03:20:27 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:20:27 --> Language Class Initialized
INFO - 2018-06-20 03:20:27 --> Config Class Initialized
INFO - 2018-06-20 03:20:27 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:20:27 --> UTF-8 Support Enabled
ERROR - 2018-06-20 03:20:27 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:20:27 --> Utf8 Class Initialized
INFO - 2018-06-20 03:20:27 --> URI Class Initialized
INFO - 2018-06-20 03:20:27 --> Router Class Initialized
INFO - 2018-06-20 03:20:27 --> Output Class Initialized
INFO - 2018-06-20 03:20:27 --> Security Class Initialized
DEBUG - 2018-06-20 03:20:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:20:27 --> Input Class Initialized
INFO - 2018-06-20 03:20:27 --> Language Class Initialized
ERROR - 2018-06-20 03:20:27 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:20:27 --> Config Class Initialized
INFO - 2018-06-20 03:20:27 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:20:27 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:20:27 --> Utf8 Class Initialized
INFO - 2018-06-20 03:20:27 --> URI Class Initialized
INFO - 2018-06-20 03:20:27 --> Router Class Initialized
INFO - 2018-06-20 03:20:27 --> Output Class Initialized
INFO - 2018-06-20 03:20:27 --> Security Class Initialized
DEBUG - 2018-06-20 03:20:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:20:27 --> Input Class Initialized
INFO - 2018-06-20 03:20:27 --> Language Class Initialized
ERROR - 2018-06-20 03:20:27 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:20:56 --> Config Class Initialized
INFO - 2018-06-20 03:20:56 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:20:56 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:20:56 --> Utf8 Class Initialized
INFO - 2018-06-20 03:20:56 --> URI Class Initialized
INFO - 2018-06-20 03:20:56 --> Router Class Initialized
INFO - 2018-06-20 03:20:56 --> Output Class Initialized
INFO - 2018-06-20 03:20:56 --> Security Class Initialized
DEBUG - 2018-06-20 03:20:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:20:56 --> Input Class Initialized
INFO - 2018-06-20 03:20:56 --> Language Class Initialized
INFO - 2018-06-20 03:20:57 --> Language Class Initialized
INFO - 2018-06-20 03:20:57 --> Config Class Initialized
INFO - 2018-06-20 03:20:57 --> Loader Class Initialized
DEBUG - 2018-06-20 03:20:57 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-20 03:20:57 --> Helper loaded: url_helper
INFO - 2018-06-20 03:20:57 --> Helper loaded: form_helper
INFO - 2018-06-20 03:20:57 --> Helper loaded: date_helper
INFO - 2018-06-20 03:20:57 --> Helper loaded: util_helper
INFO - 2018-06-20 03:20:57 --> Helper loaded: text_helper
INFO - 2018-06-20 03:20:57 --> Helper loaded: string_helper
INFO - 2018-06-20 03:20:57 --> Database Driver Class Initialized
DEBUG - 2018-06-20 03:20:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 03:20:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 03:20:57 --> Email Class Initialized
INFO - 2018-06-20 03:20:57 --> Controller Class Initialized
DEBUG - 2018-06-20 03:20:57 --> Home MX_Controller Initialized
DEBUG - 2018-06-20 03:20:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-20 03:20:57 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-20 03:20:57 --> Login MX_Controller Initialized
INFO - 2018-06-20 03:20:57 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-20 03:20:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-20 03:20:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-20 03:20:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-20 03:20:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-20 03:20:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
INFO - 2018-06-20 03:21:23 --> Config Class Initialized
INFO - 2018-06-20 03:21:23 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:21:23 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:21:23 --> Utf8 Class Initialized
INFO - 2018-06-20 03:21:23 --> URI Class Initialized
INFO - 2018-06-20 03:21:23 --> Router Class Initialized
INFO - 2018-06-20 03:21:23 --> Output Class Initialized
INFO - 2018-06-20 03:21:23 --> Security Class Initialized
DEBUG - 2018-06-20 03:21:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:21:23 --> Input Class Initialized
INFO - 2018-06-20 03:21:23 --> Language Class Initialized
INFO - 2018-06-20 03:21:23 --> Language Class Initialized
INFO - 2018-06-20 03:21:23 --> Config Class Initialized
INFO - 2018-06-20 03:21:23 --> Loader Class Initialized
DEBUG - 2018-06-20 03:21:23 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-20 03:21:23 --> Helper loaded: url_helper
INFO - 2018-06-20 03:21:23 --> Helper loaded: form_helper
INFO - 2018-06-20 03:21:23 --> Helper loaded: date_helper
INFO - 2018-06-20 03:21:23 --> Helper loaded: util_helper
INFO - 2018-06-20 03:21:23 --> Helper loaded: text_helper
INFO - 2018-06-20 03:21:23 --> Helper loaded: string_helper
INFO - 2018-06-20 03:21:23 --> Database Driver Class Initialized
DEBUG - 2018-06-20 03:21:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 03:21:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 03:21:23 --> Email Class Initialized
INFO - 2018-06-20 03:21:23 --> Controller Class Initialized
DEBUG - 2018-06-20 03:21:23 --> Home MX_Controller Initialized
DEBUG - 2018-06-20 03:21:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-20 03:21:23 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-20 03:21:23 --> Login MX_Controller Initialized
INFO - 2018-06-20 03:21:23 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-20 03:21:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-20 03:21:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-20 03:21:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-20 03:21:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-20 03:21:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-20 03:21:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-20 03:21:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-20 03:21:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-06-20 03:21:23 --> Final output sent to browser
DEBUG - 2018-06-20 03:21:23 --> Total execution time: 0.5166
INFO - 2018-06-20 03:21:26 --> Config Class Initialized
INFO - 2018-06-20 03:21:26 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:21:26 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:21:26 --> Utf8 Class Initialized
INFO - 2018-06-20 03:21:26 --> URI Class Initialized
INFO - 2018-06-20 03:21:26 --> Router Class Initialized
INFO - 2018-06-20 03:21:26 --> Output Class Initialized
INFO - 2018-06-20 03:21:26 --> Security Class Initialized
DEBUG - 2018-06-20 03:21:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:21:26 --> Input Class Initialized
INFO - 2018-06-20 03:21:26 --> Language Class Initialized
INFO - 2018-06-20 03:21:26 --> Language Class Initialized
INFO - 2018-06-20 03:21:26 --> Config Class Initialized
INFO - 2018-06-20 03:21:26 --> Loader Class Initialized
DEBUG - 2018-06-20 03:21:26 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-20 03:21:26 --> Helper loaded: url_helper
INFO - 2018-06-20 03:21:26 --> Helper loaded: form_helper
INFO - 2018-06-20 03:21:26 --> Helper loaded: date_helper
INFO - 2018-06-20 03:21:26 --> Helper loaded: util_helper
INFO - 2018-06-20 03:21:26 --> Helper loaded: text_helper
INFO - 2018-06-20 03:21:26 --> Helper loaded: string_helper
INFO - 2018-06-20 03:21:26 --> Database Driver Class Initialized
DEBUG - 2018-06-20 03:21:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 03:21:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 03:21:26 --> Email Class Initialized
INFO - 2018-06-20 03:21:26 --> Controller Class Initialized
DEBUG - 2018-06-20 03:21:26 --> Home MX_Controller Initialized
DEBUG - 2018-06-20 03:21:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-20 03:21:26 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-20 03:21:26 --> Login MX_Controller Initialized
INFO - 2018-06-20 03:21:26 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-20 03:21:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-20 03:21:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-20 03:21:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-20 03:21:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-20 03:21:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-20 03:21:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-20 03:21:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-20 03:21:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-06-20 03:21:26 --> Final output sent to browser
DEBUG - 2018-06-20 03:21:26 --> Total execution time: 0.5871
INFO - 2018-06-20 03:21:26 --> Config Class Initialized
INFO - 2018-06-20 03:21:26 --> Hooks Class Initialized
INFO - 2018-06-20 03:21:27 --> Config Class Initialized
DEBUG - 2018-06-20 03:21:27 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:21:27 --> Utf8 Class Initialized
INFO - 2018-06-20 03:21:27 --> URI Class Initialized
INFO - 2018-06-20 03:21:27 --> Router Class Initialized
INFO - 2018-06-20 03:21:27 --> Output Class Initialized
INFO - 2018-06-20 03:21:27 --> Hooks Class Initialized
INFO - 2018-06-20 03:21:27 --> Security Class Initialized
DEBUG - 2018-06-20 03:21:27 --> UTF-8 Support Enabled
DEBUG - 2018-06-20 03:21:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:21:27 --> Utf8 Class Initialized
INFO - 2018-06-20 03:21:27 --> Input Class Initialized
INFO - 2018-06-20 03:21:27 --> URI Class Initialized
INFO - 2018-06-20 03:21:27 --> Language Class Initialized
INFO - 2018-06-20 03:21:27 --> Router Class Initialized
ERROR - 2018-06-20 03:21:27 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:21:27 --> Output Class Initialized
INFO - 2018-06-20 03:21:27 --> Security Class Initialized
DEBUG - 2018-06-20 03:21:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:21:27 --> Input Class Initialized
INFO - 2018-06-20 03:21:27 --> Language Class Initialized
ERROR - 2018-06-20 03:21:27 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:21:27 --> Config Class Initialized
INFO - 2018-06-20 03:21:27 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:21:27 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:21:27 --> Utf8 Class Initialized
INFO - 2018-06-20 03:21:27 --> URI Class Initialized
INFO - 2018-06-20 03:21:27 --> Router Class Initialized
INFO - 2018-06-20 03:21:27 --> Output Class Initialized
INFO - 2018-06-20 03:21:27 --> Security Class Initialized
DEBUG - 2018-06-20 03:21:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:21:27 --> Input Class Initialized
INFO - 2018-06-20 03:21:27 --> Language Class Initialized
ERROR - 2018-06-20 03:21:27 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:21:27 --> Config Class Initialized
INFO - 2018-06-20 03:21:27 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:21:27 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:21:27 --> Utf8 Class Initialized
INFO - 2018-06-20 03:21:27 --> URI Class Initialized
INFO - 2018-06-20 03:21:27 --> Router Class Initialized
INFO - 2018-06-20 03:21:27 --> Output Class Initialized
INFO - 2018-06-20 03:21:27 --> Security Class Initialized
DEBUG - 2018-06-20 03:21:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:21:27 --> Input Class Initialized
INFO - 2018-06-20 03:21:27 --> Language Class Initialized
ERROR - 2018-06-20 03:21:27 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:21:27 --> Config Class Initialized
INFO - 2018-06-20 03:21:27 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:21:28 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:21:28 --> Utf8 Class Initialized
INFO - 2018-06-20 03:21:28 --> URI Class Initialized
INFO - 2018-06-20 03:21:28 --> Router Class Initialized
INFO - 2018-06-20 03:21:28 --> Output Class Initialized
INFO - 2018-06-20 03:21:28 --> Security Class Initialized
DEBUG - 2018-06-20 03:21:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:21:28 --> Input Class Initialized
INFO - 2018-06-20 03:21:28 --> Language Class Initialized
ERROR - 2018-06-20 03:21:28 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:21:28 --> Config Class Initialized
INFO - 2018-06-20 03:21:28 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:21:28 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:21:28 --> Utf8 Class Initialized
INFO - 2018-06-20 03:21:28 --> URI Class Initialized
INFO - 2018-06-20 03:21:28 --> Router Class Initialized
INFO - 2018-06-20 03:21:28 --> Output Class Initialized
INFO - 2018-06-20 03:21:28 --> Security Class Initialized
DEBUG - 2018-06-20 03:21:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:21:28 --> Input Class Initialized
INFO - 2018-06-20 03:21:28 --> Language Class Initialized
ERROR - 2018-06-20 03:21:28 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:21:28 --> Config Class Initialized
INFO - 2018-06-20 03:21:28 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:21:28 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:21:28 --> Utf8 Class Initialized
INFO - 2018-06-20 03:21:28 --> URI Class Initialized
INFO - 2018-06-20 03:21:28 --> Router Class Initialized
INFO - 2018-06-20 03:21:28 --> Output Class Initialized
INFO - 2018-06-20 03:21:28 --> Security Class Initialized
DEBUG - 2018-06-20 03:21:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:21:28 --> Input Class Initialized
INFO - 2018-06-20 03:21:28 --> Language Class Initialized
ERROR - 2018-06-20 03:21:28 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:21:29 --> Config Class Initialized
INFO - 2018-06-20 03:21:29 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:21:29 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:21:29 --> Utf8 Class Initialized
INFO - 2018-06-20 03:21:29 --> URI Class Initialized
INFO - 2018-06-20 03:21:29 --> Router Class Initialized
INFO - 2018-06-20 03:21:29 --> Output Class Initialized
INFO - 2018-06-20 03:21:29 --> Security Class Initialized
DEBUG - 2018-06-20 03:21:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:21:29 --> Input Class Initialized
INFO - 2018-06-20 03:21:29 --> Language Class Initialized
INFO - 2018-06-20 03:21:29 --> Language Class Initialized
INFO - 2018-06-20 03:21:29 --> Config Class Initialized
INFO - 2018-06-20 03:21:29 --> Loader Class Initialized
DEBUG - 2018-06-20 03:21:29 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-20 03:21:29 --> Helper loaded: url_helper
INFO - 2018-06-20 03:21:29 --> Helper loaded: form_helper
INFO - 2018-06-20 03:21:29 --> Helper loaded: date_helper
INFO - 2018-06-20 03:21:29 --> Helper loaded: util_helper
INFO - 2018-06-20 03:21:29 --> Helper loaded: text_helper
INFO - 2018-06-20 03:21:29 --> Helper loaded: string_helper
INFO - 2018-06-20 03:21:29 --> Database Driver Class Initialized
DEBUG - 2018-06-20 03:21:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 03:21:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 03:21:29 --> Email Class Initialized
INFO - 2018-06-20 03:21:29 --> Controller Class Initialized
DEBUG - 2018-06-20 03:21:29 --> Home MX_Controller Initialized
DEBUG - 2018-06-20 03:21:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-20 03:21:29 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-20 03:21:30 --> Login MX_Controller Initialized
INFO - 2018-06-20 03:21:30 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-20 03:21:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-20 03:21:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-20 03:21:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-20 03:21:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-20 03:21:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-20 03:21:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-20 03:21:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-20 03:21:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-06-20 03:21:30 --> Final output sent to browser
DEBUG - 2018-06-20 03:21:30 --> Total execution time: 0.5295
INFO - 2018-06-20 03:21:30 --> Config Class Initialized
INFO - 2018-06-20 03:21:30 --> Config Class Initialized
INFO - 2018-06-20 03:21:30 --> Hooks Class Initialized
INFO - 2018-06-20 03:21:30 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:21:30 --> UTF-8 Support Enabled
DEBUG - 2018-06-20 03:21:30 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:21:30 --> Utf8 Class Initialized
INFO - 2018-06-20 03:21:30 --> Utf8 Class Initialized
INFO - 2018-06-20 03:21:30 --> URI Class Initialized
INFO - 2018-06-20 03:21:30 --> URI Class Initialized
INFO - 2018-06-20 03:21:30 --> Router Class Initialized
INFO - 2018-06-20 03:21:30 --> Output Class Initialized
INFO - 2018-06-20 03:21:30 --> Router Class Initialized
INFO - 2018-06-20 03:21:30 --> Output Class Initialized
INFO - 2018-06-20 03:21:30 --> Security Class Initialized
DEBUG - 2018-06-20 03:21:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:21:30 --> Security Class Initialized
INFO - 2018-06-20 03:21:30 --> Input Class Initialized
INFO - 2018-06-20 03:21:30 --> Language Class Initialized
ERROR - 2018-06-20 03:21:30 --> 404 Page Not Found: /index
DEBUG - 2018-06-20 03:21:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:21:30 --> Config Class Initialized
INFO - 2018-06-20 03:21:30 --> Hooks Class Initialized
INFO - 2018-06-20 03:21:30 --> Input Class Initialized
INFO - 2018-06-20 03:21:30 --> Language Class Initialized
DEBUG - 2018-06-20 03:21:30 --> UTF-8 Support Enabled
ERROR - 2018-06-20 03:21:30 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:21:30 --> Utf8 Class Initialized
INFO - 2018-06-20 03:21:30 --> URI Class Initialized
INFO - 2018-06-20 03:21:30 --> Router Class Initialized
INFO - 2018-06-20 03:21:30 --> Output Class Initialized
INFO - 2018-06-20 03:21:30 --> Security Class Initialized
DEBUG - 2018-06-20 03:21:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:21:30 --> Input Class Initialized
INFO - 2018-06-20 03:21:30 --> Language Class Initialized
ERROR - 2018-06-20 03:21:30 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:21:30 --> Config Class Initialized
INFO - 2018-06-20 03:21:30 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:21:30 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:21:30 --> Utf8 Class Initialized
INFO - 2018-06-20 03:21:30 --> URI Class Initialized
INFO - 2018-06-20 03:21:31 --> Router Class Initialized
INFO - 2018-06-20 03:21:31 --> Output Class Initialized
INFO - 2018-06-20 03:21:31 --> Security Class Initialized
DEBUG - 2018-06-20 03:21:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:21:31 --> Input Class Initialized
INFO - 2018-06-20 03:21:31 --> Language Class Initialized
ERROR - 2018-06-20 03:21:31 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:21:35 --> Config Class Initialized
INFO - 2018-06-20 03:21:35 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:21:35 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:21:35 --> Utf8 Class Initialized
INFO - 2018-06-20 03:21:35 --> URI Class Initialized
INFO - 2018-06-20 03:21:35 --> Router Class Initialized
INFO - 2018-06-20 03:21:35 --> Output Class Initialized
INFO - 2018-06-20 03:21:35 --> Security Class Initialized
DEBUG - 2018-06-20 03:21:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:21:35 --> Input Class Initialized
INFO - 2018-06-20 03:21:35 --> Language Class Initialized
INFO - 2018-06-20 03:21:35 --> Language Class Initialized
INFO - 2018-06-20 03:21:35 --> Config Class Initialized
INFO - 2018-06-20 03:21:35 --> Loader Class Initialized
DEBUG - 2018-06-20 03:21:35 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-20 03:21:35 --> Helper loaded: url_helper
INFO - 2018-06-20 03:21:35 --> Helper loaded: form_helper
INFO - 2018-06-20 03:21:35 --> Helper loaded: date_helper
INFO - 2018-06-20 03:21:35 --> Helper loaded: util_helper
INFO - 2018-06-20 03:21:35 --> Helper loaded: text_helper
INFO - 2018-06-20 03:21:35 --> Helper loaded: string_helper
INFO - 2018-06-20 03:21:35 --> Database Driver Class Initialized
DEBUG - 2018-06-20 03:21:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 03:21:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 03:21:35 --> Email Class Initialized
INFO - 2018-06-20 03:21:35 --> Controller Class Initialized
DEBUG - 2018-06-20 03:21:35 --> Home MX_Controller Initialized
DEBUG - 2018-06-20 03:21:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-20 03:21:35 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-20 03:21:35 --> Login MX_Controller Initialized
INFO - 2018-06-20 03:21:35 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-20 03:21:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-20 03:21:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-20 03:21:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-20 03:21:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-20 03:21:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-20 03:21:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-20 03:21:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-20 03:21:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-06-20 03:21:35 --> Final output sent to browser
DEBUG - 2018-06-20 03:21:35 --> Total execution time: 0.5413
INFO - 2018-06-20 03:21:35 --> Config Class Initialized
INFO - 2018-06-20 03:21:35 --> Config Class Initialized
INFO - 2018-06-20 03:21:35 --> Hooks Class Initialized
INFO - 2018-06-20 03:21:35 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:21:35 --> UTF-8 Support Enabled
DEBUG - 2018-06-20 03:21:35 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:21:35 --> Utf8 Class Initialized
INFO - 2018-06-20 03:21:36 --> URI Class Initialized
INFO - 2018-06-20 03:21:36 --> Utf8 Class Initialized
INFO - 2018-06-20 03:21:36 --> Router Class Initialized
INFO - 2018-06-20 03:21:36 --> Output Class Initialized
INFO - 2018-06-20 03:21:36 --> URI Class Initialized
INFO - 2018-06-20 03:21:36 --> Security Class Initialized
DEBUG - 2018-06-20 03:21:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:21:36 --> Router Class Initialized
INFO - 2018-06-20 03:21:36 --> Input Class Initialized
INFO - 2018-06-20 03:21:36 --> Output Class Initialized
INFO - 2018-06-20 03:21:36 --> Language Class Initialized
ERROR - 2018-06-20 03:21:36 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:21:36 --> Security Class Initialized
DEBUG - 2018-06-20 03:21:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:21:36 --> Input Class Initialized
INFO - 2018-06-20 03:21:36 --> Language Class Initialized
ERROR - 2018-06-20 03:21:36 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:21:36 --> Config Class Initialized
INFO - 2018-06-20 03:21:36 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:21:36 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:21:36 --> Utf8 Class Initialized
INFO - 2018-06-20 03:21:36 --> URI Class Initialized
INFO - 2018-06-20 03:21:36 --> Router Class Initialized
INFO - 2018-06-20 03:21:36 --> Output Class Initialized
INFO - 2018-06-20 03:21:36 --> Security Class Initialized
DEBUG - 2018-06-20 03:21:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:21:36 --> Input Class Initialized
INFO - 2018-06-20 03:21:36 --> Language Class Initialized
ERROR - 2018-06-20 03:21:36 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:21:36 --> Config Class Initialized
INFO - 2018-06-20 03:21:36 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:21:36 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:21:36 --> Utf8 Class Initialized
INFO - 2018-06-20 03:21:36 --> URI Class Initialized
INFO - 2018-06-20 03:21:36 --> Router Class Initialized
INFO - 2018-06-20 03:21:36 --> Output Class Initialized
INFO - 2018-06-20 03:21:36 --> Security Class Initialized
DEBUG - 2018-06-20 03:21:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:21:36 --> Input Class Initialized
INFO - 2018-06-20 03:21:36 --> Language Class Initialized
ERROR - 2018-06-20 03:21:36 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:21:39 --> Config Class Initialized
INFO - 2018-06-20 03:21:39 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:21:39 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:21:40 --> Utf8 Class Initialized
INFO - 2018-06-20 03:21:40 --> URI Class Initialized
INFO - 2018-06-20 03:21:40 --> Router Class Initialized
INFO - 2018-06-20 03:21:40 --> Output Class Initialized
INFO - 2018-06-20 03:21:40 --> Security Class Initialized
DEBUG - 2018-06-20 03:21:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:21:40 --> Input Class Initialized
INFO - 2018-06-20 03:21:40 --> Language Class Initialized
INFO - 2018-06-20 03:21:40 --> Language Class Initialized
INFO - 2018-06-20 03:21:40 --> Config Class Initialized
INFO - 2018-06-20 03:21:40 --> Loader Class Initialized
DEBUG - 2018-06-20 03:21:40 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-20 03:21:40 --> Helper loaded: url_helper
INFO - 2018-06-20 03:21:40 --> Helper loaded: form_helper
INFO - 2018-06-20 03:21:40 --> Helper loaded: date_helper
INFO - 2018-06-20 03:21:40 --> Helper loaded: util_helper
INFO - 2018-06-20 03:21:40 --> Helper loaded: text_helper
INFO - 2018-06-20 03:21:40 --> Helper loaded: string_helper
INFO - 2018-06-20 03:21:40 --> Database Driver Class Initialized
DEBUG - 2018-06-20 03:21:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 03:21:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 03:21:40 --> Email Class Initialized
INFO - 2018-06-20 03:21:40 --> Controller Class Initialized
DEBUG - 2018-06-20 03:21:40 --> Home MX_Controller Initialized
DEBUG - 2018-06-20 03:21:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-20 03:21:40 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-20 03:21:40 --> Login MX_Controller Initialized
INFO - 2018-06-20 03:21:40 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-20 03:21:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-20 03:21:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-20 03:21:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-20 03:21:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-20 03:21:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-20 03:21:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-20 03:21:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-20 03:21:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-06-20 03:21:40 --> Final output sent to browser
DEBUG - 2018-06-20 03:21:40 --> Total execution time: 0.6026
INFO - 2018-06-20 03:21:40 --> Config Class Initialized
INFO - 2018-06-20 03:21:40 --> Config Class Initialized
INFO - 2018-06-20 03:21:40 --> Hooks Class Initialized
INFO - 2018-06-20 03:21:40 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:21:40 --> UTF-8 Support Enabled
DEBUG - 2018-06-20 03:21:40 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:21:40 --> Utf8 Class Initialized
INFO - 2018-06-20 03:21:40 --> Utf8 Class Initialized
INFO - 2018-06-20 03:21:40 --> URI Class Initialized
INFO - 2018-06-20 03:21:40 --> URI Class Initialized
INFO - 2018-06-20 03:21:40 --> Router Class Initialized
INFO - 2018-06-20 03:21:40 --> Output Class Initialized
INFO - 2018-06-20 03:21:40 --> Router Class Initialized
INFO - 2018-06-20 03:21:40 --> Security Class Initialized
DEBUG - 2018-06-20 03:21:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:21:41 --> Output Class Initialized
INFO - 2018-06-20 03:21:41 --> Input Class Initialized
INFO - 2018-06-20 03:21:41 --> Security Class Initialized
DEBUG - 2018-06-20 03:21:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:21:41 --> Input Class Initialized
INFO - 2018-06-20 03:21:41 --> Language Class Initialized
ERROR - 2018-06-20 03:21:41 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:21:41 --> Config Class Initialized
INFO - 2018-06-20 03:21:41 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:21:41 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:21:41 --> Utf8 Class Initialized
INFO - 2018-06-20 03:21:41 --> URI Class Initialized
INFO - 2018-06-20 03:21:41 --> Router Class Initialized
INFO - 2018-06-20 03:21:41 --> Language Class Initialized
INFO - 2018-06-20 03:21:41 --> Output Class Initialized
INFO - 2018-06-20 03:21:41 --> Security Class Initialized
DEBUG - 2018-06-20 03:21:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:21:41 --> Input Class Initialized
ERROR - 2018-06-20 03:21:41 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:21:41 --> Language Class Initialized
ERROR - 2018-06-20 03:21:41 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:21:41 --> Config Class Initialized
INFO - 2018-06-20 03:21:41 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:21:41 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:21:41 --> Utf8 Class Initialized
INFO - 2018-06-20 03:21:41 --> URI Class Initialized
INFO - 2018-06-20 03:21:41 --> Router Class Initialized
INFO - 2018-06-20 03:21:41 --> Output Class Initialized
INFO - 2018-06-20 03:21:41 --> Security Class Initialized
DEBUG - 2018-06-20 03:21:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:21:41 --> Input Class Initialized
INFO - 2018-06-20 03:21:41 --> Language Class Initialized
ERROR - 2018-06-20 03:21:41 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:21:43 --> Config Class Initialized
INFO - 2018-06-20 03:21:43 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:21:43 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:21:43 --> Utf8 Class Initialized
INFO - 2018-06-20 03:21:43 --> URI Class Initialized
INFO - 2018-06-20 03:21:43 --> Router Class Initialized
INFO - 2018-06-20 03:21:43 --> Output Class Initialized
INFO - 2018-06-20 03:21:43 --> Security Class Initialized
DEBUG - 2018-06-20 03:21:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:21:43 --> Input Class Initialized
INFO - 2018-06-20 03:21:43 --> Language Class Initialized
INFO - 2018-06-20 03:21:43 --> Language Class Initialized
INFO - 2018-06-20 03:21:43 --> Config Class Initialized
INFO - 2018-06-20 03:21:43 --> Loader Class Initialized
DEBUG - 2018-06-20 03:21:43 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-20 03:21:43 --> Helper loaded: url_helper
INFO - 2018-06-20 03:21:43 --> Helper loaded: form_helper
INFO - 2018-06-20 03:21:43 --> Helper loaded: date_helper
INFO - 2018-06-20 03:21:43 --> Helper loaded: util_helper
INFO - 2018-06-20 03:21:43 --> Helper loaded: text_helper
INFO - 2018-06-20 03:21:43 --> Helper loaded: string_helper
INFO - 2018-06-20 03:21:43 --> Database Driver Class Initialized
DEBUG - 2018-06-20 03:21:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 03:21:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 03:21:43 --> Email Class Initialized
INFO - 2018-06-20 03:21:43 --> Controller Class Initialized
DEBUG - 2018-06-20 03:21:43 --> Home MX_Controller Initialized
DEBUG - 2018-06-20 03:21:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-20 03:21:43 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-20 03:21:43 --> Login MX_Controller Initialized
INFO - 2018-06-20 03:21:43 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-20 03:21:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-20 03:21:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-20 03:21:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-20 03:21:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-20 03:21:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-20 03:21:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-20 03:21:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-20 03:21:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-06-20 03:21:43 --> Final output sent to browser
DEBUG - 2018-06-20 03:21:43 --> Total execution time: 0.5407
INFO - 2018-06-20 03:21:43 --> Config Class Initialized
INFO - 2018-06-20 03:21:43 --> Config Class Initialized
INFO - 2018-06-20 03:21:43 --> Hooks Class Initialized
INFO - 2018-06-20 03:21:43 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:21:43 --> UTF-8 Support Enabled
DEBUG - 2018-06-20 03:21:43 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:21:44 --> Utf8 Class Initialized
INFO - 2018-06-20 03:21:44 --> Utf8 Class Initialized
INFO - 2018-06-20 03:21:44 --> URI Class Initialized
INFO - 2018-06-20 03:21:44 --> URI Class Initialized
INFO - 2018-06-20 03:21:44 --> Router Class Initialized
INFO - 2018-06-20 03:21:44 --> Output Class Initialized
INFO - 2018-06-20 03:21:44 --> Router Class Initialized
INFO - 2018-06-20 03:21:44 --> Security Class Initialized
DEBUG - 2018-06-20 03:21:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:21:44 --> Input Class Initialized
INFO - 2018-06-20 03:21:44 --> Output Class Initialized
INFO - 2018-06-20 03:21:44 --> Language Class Initialized
ERROR - 2018-06-20 03:21:44 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:21:44 --> Security Class Initialized
DEBUG - 2018-06-20 03:21:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:21:44 --> Config Class Initialized
INFO - 2018-06-20 03:21:44 --> Hooks Class Initialized
INFO - 2018-06-20 03:21:44 --> Input Class Initialized
INFO - 2018-06-20 03:21:44 --> Language Class Initialized
DEBUG - 2018-06-20 03:21:44 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:21:44 --> Utf8 Class Initialized
ERROR - 2018-06-20 03:21:44 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:21:44 --> URI Class Initialized
INFO - 2018-06-20 03:21:44 --> Router Class Initialized
INFO - 2018-06-20 03:21:44 --> Output Class Initialized
INFO - 2018-06-20 03:21:44 --> Security Class Initialized
DEBUG - 2018-06-20 03:21:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:21:44 --> Input Class Initialized
INFO - 2018-06-20 03:21:44 --> Language Class Initialized
ERROR - 2018-06-20 03:21:44 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:21:44 --> Config Class Initialized
INFO - 2018-06-20 03:21:44 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:21:44 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:21:44 --> Utf8 Class Initialized
INFO - 2018-06-20 03:21:44 --> URI Class Initialized
INFO - 2018-06-20 03:21:44 --> Router Class Initialized
INFO - 2018-06-20 03:21:44 --> Output Class Initialized
INFO - 2018-06-20 03:21:44 --> Security Class Initialized
DEBUG - 2018-06-20 03:21:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:21:44 --> Input Class Initialized
INFO - 2018-06-20 03:21:44 --> Language Class Initialized
ERROR - 2018-06-20 03:21:44 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:21:46 --> Config Class Initialized
INFO - 2018-06-20 03:21:46 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:21:46 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:21:46 --> Utf8 Class Initialized
INFO - 2018-06-20 03:21:46 --> URI Class Initialized
INFO - 2018-06-20 03:21:46 --> Router Class Initialized
INFO - 2018-06-20 03:21:46 --> Output Class Initialized
INFO - 2018-06-20 03:21:46 --> Security Class Initialized
DEBUG - 2018-06-20 03:21:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:21:46 --> Input Class Initialized
INFO - 2018-06-20 03:21:46 --> Language Class Initialized
INFO - 2018-06-20 03:21:46 --> Language Class Initialized
INFO - 2018-06-20 03:21:46 --> Config Class Initialized
INFO - 2018-06-20 03:21:46 --> Loader Class Initialized
DEBUG - 2018-06-20 03:21:46 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-20 03:21:46 --> Helper loaded: url_helper
INFO - 2018-06-20 03:21:46 --> Helper loaded: form_helper
INFO - 2018-06-20 03:21:46 --> Helper loaded: date_helper
INFO - 2018-06-20 03:21:46 --> Helper loaded: util_helper
INFO - 2018-06-20 03:21:46 --> Helper loaded: text_helper
INFO - 2018-06-20 03:21:46 --> Helper loaded: string_helper
INFO - 2018-06-20 03:21:46 --> Database Driver Class Initialized
DEBUG - 2018-06-20 03:21:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 03:21:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 03:21:46 --> Email Class Initialized
INFO - 2018-06-20 03:21:46 --> Controller Class Initialized
DEBUG - 2018-06-20 03:21:46 --> Home MX_Controller Initialized
DEBUG - 2018-06-20 03:21:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-20 03:21:46 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-20 03:21:46 --> Login MX_Controller Initialized
INFO - 2018-06-20 03:21:46 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-20 03:21:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-20 03:21:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-20 03:21:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-20 03:21:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-20 03:21:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-20 03:21:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-20 03:21:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-20 03:21:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-06-20 03:21:47 --> Final output sent to browser
DEBUG - 2018-06-20 03:21:47 --> Total execution time: 0.5569
INFO - 2018-06-20 03:21:47 --> Config Class Initialized
INFO - 2018-06-20 03:21:47 --> Config Class Initialized
INFO - 2018-06-20 03:21:47 --> Hooks Class Initialized
INFO - 2018-06-20 03:21:47 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:21:47 --> UTF-8 Support Enabled
DEBUG - 2018-06-20 03:21:47 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:21:47 --> Utf8 Class Initialized
INFO - 2018-06-20 03:21:47 --> Utf8 Class Initialized
INFO - 2018-06-20 03:21:47 --> URI Class Initialized
INFO - 2018-06-20 03:21:47 --> URI Class Initialized
INFO - 2018-06-20 03:21:47 --> Router Class Initialized
INFO - 2018-06-20 03:21:47 --> Router Class Initialized
INFO - 2018-06-20 03:21:47 --> Output Class Initialized
INFO - 2018-06-20 03:21:47 --> Output Class Initialized
INFO - 2018-06-20 03:21:47 --> Security Class Initialized
INFO - 2018-06-20 03:21:47 --> Security Class Initialized
DEBUG - 2018-06-20 03:21:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:21:47 --> Input Class Initialized
INFO - 2018-06-20 03:21:47 --> Language Class Initialized
DEBUG - 2018-06-20 03:21:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-06-20 03:21:47 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:21:47 --> Input Class Initialized
INFO - 2018-06-20 03:21:47 --> Language Class Initialized
ERROR - 2018-06-20 03:21:47 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:21:47 --> Config Class Initialized
INFO - 2018-06-20 03:21:47 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:21:47 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:21:47 --> Utf8 Class Initialized
INFO - 2018-06-20 03:21:47 --> URI Class Initialized
INFO - 2018-06-20 03:21:47 --> Router Class Initialized
INFO - 2018-06-20 03:21:47 --> Output Class Initialized
INFO - 2018-06-20 03:21:47 --> Security Class Initialized
DEBUG - 2018-06-20 03:21:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:21:47 --> Input Class Initialized
INFO - 2018-06-20 03:21:47 --> Language Class Initialized
ERROR - 2018-06-20 03:21:47 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:21:47 --> Config Class Initialized
INFO - 2018-06-20 03:21:47 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:21:47 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:21:47 --> Utf8 Class Initialized
INFO - 2018-06-20 03:21:47 --> URI Class Initialized
INFO - 2018-06-20 03:21:47 --> Router Class Initialized
INFO - 2018-06-20 03:21:48 --> Output Class Initialized
INFO - 2018-06-20 03:21:48 --> Security Class Initialized
DEBUG - 2018-06-20 03:21:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:21:48 --> Input Class Initialized
INFO - 2018-06-20 03:21:48 --> Language Class Initialized
ERROR - 2018-06-20 03:21:48 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:24:42 --> Config Class Initialized
INFO - 2018-06-20 03:24:42 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:24:42 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:24:42 --> Utf8 Class Initialized
INFO - 2018-06-20 03:24:42 --> URI Class Initialized
INFO - 2018-06-20 03:24:42 --> Router Class Initialized
INFO - 2018-06-20 03:24:42 --> Output Class Initialized
INFO - 2018-06-20 03:24:42 --> Security Class Initialized
DEBUG - 2018-06-20 03:24:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:24:42 --> Input Class Initialized
INFO - 2018-06-20 03:24:42 --> Language Class Initialized
INFO - 2018-06-20 03:24:42 --> Language Class Initialized
INFO - 2018-06-20 03:24:42 --> Config Class Initialized
INFO - 2018-06-20 03:24:42 --> Loader Class Initialized
DEBUG - 2018-06-20 03:24:42 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-20 03:24:42 --> Helper loaded: url_helper
INFO - 2018-06-20 03:24:42 --> Helper loaded: form_helper
INFO - 2018-06-20 03:24:42 --> Helper loaded: date_helper
INFO - 2018-06-20 03:24:42 --> Helper loaded: util_helper
INFO - 2018-06-20 03:24:42 --> Helper loaded: text_helper
INFO - 2018-06-20 03:24:42 --> Helper loaded: string_helper
INFO - 2018-06-20 03:24:42 --> Database Driver Class Initialized
DEBUG - 2018-06-20 03:24:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 03:24:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 03:24:42 --> Email Class Initialized
INFO - 2018-06-20 03:24:42 --> Controller Class Initialized
DEBUG - 2018-06-20 03:24:42 --> Home MX_Controller Initialized
DEBUG - 2018-06-20 03:24:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-20 03:24:42 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-20 03:24:42 --> Login MX_Controller Initialized
INFO - 2018-06-20 03:24:42 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-20 03:24:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-20 03:24:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-20 03:24:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-20 03:24:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-20 03:24:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-20 03:24:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-20 03:24:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-20 03:24:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-06-20 03:24:42 --> Final output sent to browser
DEBUG - 2018-06-20 03:24:42 --> Total execution time: 0.5789
INFO - 2018-06-20 03:24:43 --> Config Class Initialized
INFO - 2018-06-20 03:24:43 --> Config Class Initialized
INFO - 2018-06-20 03:24:43 --> Hooks Class Initialized
INFO - 2018-06-20 03:24:43 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:24:43 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:24:43 --> Utf8 Class Initialized
DEBUG - 2018-06-20 03:24:43 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:24:43 --> Utf8 Class Initialized
INFO - 2018-06-20 03:24:43 --> URI Class Initialized
INFO - 2018-06-20 03:24:43 --> URI Class Initialized
INFO - 2018-06-20 03:24:43 --> Router Class Initialized
INFO - 2018-06-20 03:24:43 --> Router Class Initialized
INFO - 2018-06-20 03:24:43 --> Output Class Initialized
INFO - 2018-06-20 03:24:43 --> Security Class Initialized
DEBUG - 2018-06-20 03:24:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:24:43 --> Output Class Initialized
INFO - 2018-06-20 03:24:43 --> Security Class Initialized
INFO - 2018-06-20 03:24:43 --> Input Class Initialized
DEBUG - 2018-06-20 03:24:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:24:43 --> Language Class Initialized
INFO - 2018-06-20 03:24:43 --> Input Class Initialized
INFO - 2018-06-20 03:24:43 --> Language Class Initialized
ERROR - 2018-06-20 03:24:43 --> 404 Page Not Found: /index
ERROR - 2018-06-20 03:24:43 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:24:43 --> Config Class Initialized
INFO - 2018-06-20 03:24:43 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:24:43 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:24:43 --> Utf8 Class Initialized
INFO - 2018-06-20 03:24:43 --> URI Class Initialized
INFO - 2018-06-20 03:24:43 --> Router Class Initialized
INFO - 2018-06-20 03:24:43 --> Output Class Initialized
INFO - 2018-06-20 03:24:43 --> Security Class Initialized
DEBUG - 2018-06-20 03:24:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:24:43 --> Input Class Initialized
INFO - 2018-06-20 03:24:43 --> Language Class Initialized
ERROR - 2018-06-20 03:24:43 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:24:43 --> Config Class Initialized
INFO - 2018-06-20 03:24:43 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:24:43 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:24:43 --> Utf8 Class Initialized
INFO - 2018-06-20 03:24:43 --> URI Class Initialized
INFO - 2018-06-20 03:24:43 --> Router Class Initialized
INFO - 2018-06-20 03:24:43 --> Output Class Initialized
INFO - 2018-06-20 03:24:43 --> Security Class Initialized
DEBUG - 2018-06-20 03:24:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:24:44 --> Input Class Initialized
INFO - 2018-06-20 03:24:44 --> Language Class Initialized
ERROR - 2018-06-20 03:24:44 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:24:44 --> Config Class Initialized
INFO - 2018-06-20 03:24:44 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:24:44 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:24:44 --> Utf8 Class Initialized
INFO - 2018-06-20 03:24:44 --> URI Class Initialized
INFO - 2018-06-20 03:24:44 --> Router Class Initialized
INFO - 2018-06-20 03:24:44 --> Output Class Initialized
INFO - 2018-06-20 03:24:44 --> Security Class Initialized
DEBUG - 2018-06-20 03:24:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:24:44 --> Input Class Initialized
INFO - 2018-06-20 03:24:44 --> Language Class Initialized
ERROR - 2018-06-20 03:24:44 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:24:44 --> Config Class Initialized
INFO - 2018-06-20 03:24:44 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:24:44 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:24:44 --> Utf8 Class Initialized
INFO - 2018-06-20 03:24:44 --> URI Class Initialized
INFO - 2018-06-20 03:24:44 --> Router Class Initialized
INFO - 2018-06-20 03:24:44 --> Output Class Initialized
INFO - 2018-06-20 03:24:44 --> Security Class Initialized
DEBUG - 2018-06-20 03:24:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:24:44 --> Input Class Initialized
INFO - 2018-06-20 03:24:44 --> Language Class Initialized
ERROR - 2018-06-20 03:24:44 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:24:44 --> Config Class Initialized
INFO - 2018-06-20 03:24:44 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:24:44 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:24:44 --> Utf8 Class Initialized
INFO - 2018-06-20 03:24:44 --> URI Class Initialized
INFO - 2018-06-20 03:24:44 --> Router Class Initialized
INFO - 2018-06-20 03:24:44 --> Output Class Initialized
INFO - 2018-06-20 03:24:44 --> Security Class Initialized
DEBUG - 2018-06-20 03:24:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:24:44 --> Input Class Initialized
INFO - 2018-06-20 03:24:44 --> Language Class Initialized
ERROR - 2018-06-20 03:24:44 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:24:57 --> Config Class Initialized
INFO - 2018-06-20 03:24:57 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:24:57 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:24:57 --> Utf8 Class Initialized
INFO - 2018-06-20 03:24:57 --> URI Class Initialized
INFO - 2018-06-20 03:24:57 --> Router Class Initialized
INFO - 2018-06-20 03:24:57 --> Output Class Initialized
INFO - 2018-06-20 03:24:57 --> Security Class Initialized
DEBUG - 2018-06-20 03:24:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:24:57 --> Input Class Initialized
INFO - 2018-06-20 03:24:57 --> Language Class Initialized
INFO - 2018-06-20 03:24:57 --> Language Class Initialized
INFO - 2018-06-20 03:24:57 --> Config Class Initialized
INFO - 2018-06-20 03:24:57 --> Loader Class Initialized
DEBUG - 2018-06-20 03:24:57 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-20 03:24:57 --> Helper loaded: url_helper
INFO - 2018-06-20 03:24:57 --> Helper loaded: form_helper
INFO - 2018-06-20 03:24:57 --> Helper loaded: date_helper
INFO - 2018-06-20 03:24:57 --> Helper loaded: util_helper
INFO - 2018-06-20 03:24:57 --> Helper loaded: text_helper
INFO - 2018-06-20 03:24:57 --> Helper loaded: string_helper
INFO - 2018-06-20 03:24:57 --> Database Driver Class Initialized
DEBUG - 2018-06-20 03:24:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 03:24:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 03:24:57 --> Email Class Initialized
INFO - 2018-06-20 03:24:57 --> Controller Class Initialized
DEBUG - 2018-06-20 03:24:57 --> Home MX_Controller Initialized
DEBUG - 2018-06-20 03:24:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-20 03:24:57 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-20 03:24:57 --> Login MX_Controller Initialized
INFO - 2018-06-20 03:24:57 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-20 03:24:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-20 03:24:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-20 03:24:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-20 03:24:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-20 03:24:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-20 03:24:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-20 03:24:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-20 03:24:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-06-20 03:24:57 --> Final output sent to browser
DEBUG - 2018-06-20 03:24:58 --> Total execution time: 0.5288
INFO - 2018-06-20 03:24:58 --> Config Class Initialized
INFO - 2018-06-20 03:24:58 --> Config Class Initialized
INFO - 2018-06-20 03:24:58 --> Hooks Class Initialized
INFO - 2018-06-20 03:24:58 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:24:58 --> UTF-8 Support Enabled
DEBUG - 2018-06-20 03:24:58 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:24:58 --> Utf8 Class Initialized
INFO - 2018-06-20 03:24:58 --> URI Class Initialized
INFO - 2018-06-20 03:24:58 --> Utf8 Class Initialized
INFO - 2018-06-20 03:24:58 --> Router Class Initialized
INFO - 2018-06-20 03:24:58 --> URI Class Initialized
INFO - 2018-06-20 03:24:58 --> Output Class Initialized
INFO - 2018-06-20 03:24:58 --> Router Class Initialized
INFO - 2018-06-20 03:24:58 --> Security Class Initialized
DEBUG - 2018-06-20 03:24:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:24:58 --> Output Class Initialized
INFO - 2018-06-20 03:24:58 --> Security Class Initialized
INFO - 2018-06-20 03:24:58 --> Input Class Initialized
DEBUG - 2018-06-20 03:24:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:24:58 --> Input Class Initialized
INFO - 2018-06-20 03:24:58 --> Language Class Initialized
INFO - 2018-06-20 03:24:58 --> Language Class Initialized
ERROR - 2018-06-20 03:24:58 --> 404 Page Not Found: /index
ERROR - 2018-06-20 03:24:58 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:24:58 --> Config Class Initialized
INFO - 2018-06-20 03:24:58 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:24:58 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:24:58 --> Utf8 Class Initialized
INFO - 2018-06-20 03:24:58 --> URI Class Initialized
INFO - 2018-06-20 03:24:58 --> Router Class Initialized
INFO - 2018-06-20 03:24:59 --> Output Class Initialized
INFO - 2018-06-20 03:24:59 --> Security Class Initialized
DEBUG - 2018-06-20 03:24:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:24:59 --> Input Class Initialized
INFO - 2018-06-20 03:24:59 --> Language Class Initialized
ERROR - 2018-06-20 03:24:59 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:24:59 --> Config Class Initialized
INFO - 2018-06-20 03:24:59 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:24:59 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:24:59 --> Utf8 Class Initialized
INFO - 2018-06-20 03:24:59 --> URI Class Initialized
INFO - 2018-06-20 03:24:59 --> Router Class Initialized
INFO - 2018-06-20 03:24:59 --> Output Class Initialized
INFO - 2018-06-20 03:24:59 --> Security Class Initialized
DEBUG - 2018-06-20 03:24:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:24:59 --> Input Class Initialized
INFO - 2018-06-20 03:24:59 --> Language Class Initialized
ERROR - 2018-06-20 03:24:59 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:24:59 --> Config Class Initialized
INFO - 2018-06-20 03:24:59 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:24:59 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:24:59 --> Utf8 Class Initialized
INFO - 2018-06-20 03:24:59 --> URI Class Initialized
INFO - 2018-06-20 03:24:59 --> Router Class Initialized
INFO - 2018-06-20 03:24:59 --> Output Class Initialized
INFO - 2018-06-20 03:24:59 --> Security Class Initialized
DEBUG - 2018-06-20 03:24:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:24:59 --> Input Class Initialized
INFO - 2018-06-20 03:24:59 --> Language Class Initialized
ERROR - 2018-06-20 03:24:59 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:24:59 --> Config Class Initialized
INFO - 2018-06-20 03:24:59 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:24:59 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:24:59 --> Utf8 Class Initialized
INFO - 2018-06-20 03:24:59 --> URI Class Initialized
INFO - 2018-06-20 03:24:59 --> Router Class Initialized
INFO - 2018-06-20 03:24:59 --> Output Class Initialized
INFO - 2018-06-20 03:24:59 --> Security Class Initialized
DEBUG - 2018-06-20 03:24:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:24:59 --> Input Class Initialized
INFO - 2018-06-20 03:24:59 --> Language Class Initialized
ERROR - 2018-06-20 03:24:59 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:24:59 --> Config Class Initialized
INFO - 2018-06-20 03:24:59 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:24:59 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:24:59 --> Utf8 Class Initialized
INFO - 2018-06-20 03:24:59 --> URI Class Initialized
INFO - 2018-06-20 03:24:59 --> Router Class Initialized
INFO - 2018-06-20 03:24:59 --> Output Class Initialized
INFO - 2018-06-20 03:24:59 --> Security Class Initialized
DEBUG - 2018-06-20 03:24:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:24:59 --> Input Class Initialized
INFO - 2018-06-20 03:24:59 --> Language Class Initialized
ERROR - 2018-06-20 03:24:59 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:26:10 --> Config Class Initialized
INFO - 2018-06-20 03:26:10 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:26:10 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:26:10 --> Utf8 Class Initialized
INFO - 2018-06-20 03:26:10 --> URI Class Initialized
INFO - 2018-06-20 03:26:10 --> Router Class Initialized
INFO - 2018-06-20 03:26:10 --> Output Class Initialized
INFO - 2018-06-20 03:26:10 --> Security Class Initialized
DEBUG - 2018-06-20 03:26:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:26:10 --> Input Class Initialized
INFO - 2018-06-20 03:26:10 --> Language Class Initialized
INFO - 2018-06-20 03:26:10 --> Language Class Initialized
INFO - 2018-06-20 03:26:10 --> Config Class Initialized
INFO - 2018-06-20 03:26:10 --> Loader Class Initialized
DEBUG - 2018-06-20 03:26:10 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-20 03:26:10 --> Helper loaded: url_helper
INFO - 2018-06-20 03:26:10 --> Helper loaded: form_helper
INFO - 2018-06-20 03:26:10 --> Helper loaded: date_helper
INFO - 2018-06-20 03:26:10 --> Helper loaded: util_helper
INFO - 2018-06-20 03:26:10 --> Helper loaded: text_helper
INFO - 2018-06-20 03:26:10 --> Helper loaded: string_helper
INFO - 2018-06-20 03:26:10 --> Database Driver Class Initialized
DEBUG - 2018-06-20 03:26:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 03:26:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 03:26:10 --> Email Class Initialized
INFO - 2018-06-20 03:26:10 --> Controller Class Initialized
DEBUG - 2018-06-20 03:26:10 --> Home MX_Controller Initialized
DEBUG - 2018-06-20 03:26:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-20 03:26:10 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-20 03:26:10 --> Login MX_Controller Initialized
INFO - 2018-06-20 03:26:10 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-20 03:26:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-20 03:26:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-20 03:26:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-20 03:26:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-20 03:26:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-20 03:26:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-20 03:26:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-20 03:26:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-06-20 03:26:10 --> Final output sent to browser
DEBUG - 2018-06-20 03:26:10 --> Total execution time: 0.5418
INFO - 2018-06-20 03:26:11 --> Config Class Initialized
INFO - 2018-06-20 03:26:11 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:26:11 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:26:11 --> Utf8 Class Initialized
INFO - 2018-06-20 03:26:11 --> Config Class Initialized
INFO - 2018-06-20 03:26:11 --> Hooks Class Initialized
INFO - 2018-06-20 03:26:11 --> URI Class Initialized
DEBUG - 2018-06-20 03:26:11 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:26:11 --> Utf8 Class Initialized
INFO - 2018-06-20 03:26:11 --> Router Class Initialized
INFO - 2018-06-20 03:26:11 --> URI Class Initialized
INFO - 2018-06-20 03:26:11 --> Output Class Initialized
INFO - 2018-06-20 03:26:11 --> Security Class Initialized
DEBUG - 2018-06-20 03:26:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:26:11 --> Router Class Initialized
INFO - 2018-06-20 03:26:11 --> Input Class Initialized
INFO - 2018-06-20 03:26:11 --> Output Class Initialized
INFO - 2018-06-20 03:26:11 --> Language Class Initialized
INFO - 2018-06-20 03:26:11 --> Security Class Initialized
ERROR - 2018-06-20 03:26:11 --> 404 Page Not Found: /index
DEBUG - 2018-06-20 03:26:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:26:11 --> Input Class Initialized
INFO - 2018-06-20 03:26:11 --> Language Class Initialized
ERROR - 2018-06-20 03:26:11 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:26:11 --> Config Class Initialized
INFO - 2018-06-20 03:26:12 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:26:12 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:26:12 --> Utf8 Class Initialized
INFO - 2018-06-20 03:26:12 --> URI Class Initialized
INFO - 2018-06-20 03:26:12 --> Router Class Initialized
INFO - 2018-06-20 03:26:12 --> Output Class Initialized
INFO - 2018-06-20 03:26:12 --> Security Class Initialized
DEBUG - 2018-06-20 03:26:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:26:12 --> Input Class Initialized
INFO - 2018-06-20 03:26:12 --> Language Class Initialized
ERROR - 2018-06-20 03:26:12 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:26:12 --> Config Class Initialized
INFO - 2018-06-20 03:26:12 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:26:12 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:26:12 --> Utf8 Class Initialized
INFO - 2018-06-20 03:26:12 --> URI Class Initialized
INFO - 2018-06-20 03:26:12 --> Router Class Initialized
INFO - 2018-06-20 03:26:12 --> Output Class Initialized
INFO - 2018-06-20 03:26:12 --> Security Class Initialized
DEBUG - 2018-06-20 03:26:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:26:12 --> Input Class Initialized
INFO - 2018-06-20 03:26:12 --> Language Class Initialized
ERROR - 2018-06-20 03:26:12 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:27:12 --> Config Class Initialized
INFO - 2018-06-20 03:27:12 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:27:12 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:27:12 --> Utf8 Class Initialized
INFO - 2018-06-20 03:27:13 --> URI Class Initialized
INFO - 2018-06-20 03:27:13 --> Router Class Initialized
INFO - 2018-06-20 03:27:13 --> Output Class Initialized
INFO - 2018-06-20 03:27:13 --> Security Class Initialized
DEBUG - 2018-06-20 03:27:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:27:13 --> Input Class Initialized
INFO - 2018-06-20 03:27:13 --> Language Class Initialized
INFO - 2018-06-20 03:27:13 --> Language Class Initialized
INFO - 2018-06-20 03:27:13 --> Config Class Initialized
INFO - 2018-06-20 03:27:13 --> Loader Class Initialized
DEBUG - 2018-06-20 03:27:13 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-20 03:27:13 --> Helper loaded: url_helper
INFO - 2018-06-20 03:27:13 --> Helper loaded: form_helper
INFO - 2018-06-20 03:27:13 --> Helper loaded: date_helper
INFO - 2018-06-20 03:27:13 --> Helper loaded: util_helper
INFO - 2018-06-20 03:27:13 --> Helper loaded: text_helper
INFO - 2018-06-20 03:27:13 --> Helper loaded: string_helper
INFO - 2018-06-20 03:27:13 --> Database Driver Class Initialized
DEBUG - 2018-06-20 03:27:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 03:27:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 03:27:13 --> Email Class Initialized
INFO - 2018-06-20 03:27:13 --> Controller Class Initialized
DEBUG - 2018-06-20 03:27:13 --> Home MX_Controller Initialized
DEBUG - 2018-06-20 03:27:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-20 03:27:13 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-20 03:27:13 --> Login MX_Controller Initialized
INFO - 2018-06-20 03:27:13 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-20 03:27:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-20 03:27:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-20 03:27:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-20 03:27:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-20 03:27:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-20 03:27:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-20 03:27:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-20 03:27:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-06-20 03:27:13 --> Final output sent to browser
DEBUG - 2018-06-20 03:27:13 --> Total execution time: 0.6618
INFO - 2018-06-20 03:27:14 --> Config Class Initialized
INFO - 2018-06-20 03:27:14 --> Hooks Class Initialized
INFO - 2018-06-20 03:27:14 --> Config Class Initialized
INFO - 2018-06-20 03:27:14 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:27:14 --> UTF-8 Support Enabled
DEBUG - 2018-06-20 03:27:14 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:27:14 --> Utf8 Class Initialized
INFO - 2018-06-20 03:27:14 --> URI Class Initialized
INFO - 2018-06-20 03:27:14 --> Router Class Initialized
INFO - 2018-06-20 03:27:14 --> Output Class Initialized
INFO - 2018-06-20 03:27:14 --> Security Class Initialized
DEBUG - 2018-06-20 03:27:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:27:14 --> Input Class Initialized
INFO - 2018-06-20 03:27:14 --> Language Class Initialized
ERROR - 2018-06-20 03:27:14 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:27:14 --> Utf8 Class Initialized
INFO - 2018-06-20 03:27:14 --> Config Class Initialized
INFO - 2018-06-20 03:27:14 --> URI Class Initialized
INFO - 2018-06-20 03:27:14 --> Router Class Initialized
INFO - 2018-06-20 03:27:14 --> Hooks Class Initialized
INFO - 2018-06-20 03:27:14 --> Output Class Initialized
DEBUG - 2018-06-20 03:27:14 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:27:14 --> Security Class Initialized
INFO - 2018-06-20 03:27:14 --> Utf8 Class Initialized
DEBUG - 2018-06-20 03:27:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:27:14 --> URI Class Initialized
INFO - 2018-06-20 03:27:14 --> Input Class Initialized
INFO - 2018-06-20 03:27:14 --> Language Class Initialized
INFO - 2018-06-20 03:27:14 --> Router Class Initialized
INFO - 2018-06-20 03:27:14 --> Output Class Initialized
ERROR - 2018-06-20 03:27:14 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:27:14 --> Security Class Initialized
DEBUG - 2018-06-20 03:27:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:27:14 --> Input Class Initialized
INFO - 2018-06-20 03:27:14 --> Language Class Initialized
ERROR - 2018-06-20 03:27:14 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:27:14 --> Config Class Initialized
INFO - 2018-06-20 03:27:14 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:27:14 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:27:14 --> Utf8 Class Initialized
INFO - 2018-06-20 03:27:14 --> URI Class Initialized
INFO - 2018-06-20 03:27:14 --> Router Class Initialized
INFO - 2018-06-20 03:27:14 --> Output Class Initialized
INFO - 2018-06-20 03:27:14 --> Security Class Initialized
DEBUG - 2018-06-20 03:27:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:27:15 --> Input Class Initialized
INFO - 2018-06-20 03:27:15 --> Language Class Initialized
ERROR - 2018-06-20 03:27:15 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:27:37 --> Config Class Initialized
INFO - 2018-06-20 03:27:37 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:27:37 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:27:37 --> Utf8 Class Initialized
INFO - 2018-06-20 03:27:37 --> URI Class Initialized
INFO - 2018-06-20 03:27:37 --> Router Class Initialized
INFO - 2018-06-20 03:27:37 --> Output Class Initialized
INFO - 2018-06-20 03:27:37 --> Security Class Initialized
DEBUG - 2018-06-20 03:27:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:27:37 --> Input Class Initialized
INFO - 2018-06-20 03:27:37 --> Language Class Initialized
INFO - 2018-06-20 03:27:37 --> Language Class Initialized
INFO - 2018-06-20 03:27:37 --> Config Class Initialized
INFO - 2018-06-20 03:27:37 --> Loader Class Initialized
DEBUG - 2018-06-20 03:27:37 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-20 03:27:37 --> Helper loaded: url_helper
INFO - 2018-06-20 03:27:37 --> Helper loaded: form_helper
INFO - 2018-06-20 03:27:37 --> Helper loaded: date_helper
INFO - 2018-06-20 03:27:37 --> Helper loaded: util_helper
INFO - 2018-06-20 03:27:37 --> Helper loaded: text_helper
INFO - 2018-06-20 03:27:37 --> Helper loaded: string_helper
INFO - 2018-06-20 03:27:37 --> Database Driver Class Initialized
DEBUG - 2018-06-20 03:27:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 03:27:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 03:27:37 --> Email Class Initialized
INFO - 2018-06-20 03:27:37 --> Controller Class Initialized
DEBUG - 2018-06-20 03:27:37 --> Home MX_Controller Initialized
DEBUG - 2018-06-20 03:27:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-20 03:27:37 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-20 03:27:37 --> Login MX_Controller Initialized
INFO - 2018-06-20 03:27:37 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-20 03:27:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-20 03:27:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-20 03:27:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-20 03:27:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-20 03:27:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-20 03:27:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-20 03:27:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-20 03:27:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-06-20 03:27:38 --> Final output sent to browser
DEBUG - 2018-06-20 03:27:38 --> Total execution time: 0.5615
INFO - 2018-06-20 03:27:38 --> Config Class Initialized
INFO - 2018-06-20 03:27:38 --> Hooks Class Initialized
INFO - 2018-06-20 03:27:38 --> Config Class Initialized
INFO - 2018-06-20 03:27:38 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:27:38 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:27:38 --> Utf8 Class Initialized
DEBUG - 2018-06-20 03:27:38 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:27:38 --> URI Class Initialized
INFO - 2018-06-20 03:27:38 --> Router Class Initialized
INFO - 2018-06-20 03:27:38 --> Output Class Initialized
INFO - 2018-06-20 03:27:38 --> Utf8 Class Initialized
INFO - 2018-06-20 03:27:38 --> Security Class Initialized
DEBUG - 2018-06-20 03:27:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:27:38 --> URI Class Initialized
INFO - 2018-06-20 03:27:38 --> Input Class Initialized
INFO - 2018-06-20 03:27:38 --> Language Class Initialized
ERROR - 2018-06-20 03:27:38 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:27:38 --> Router Class Initialized
INFO - 2018-06-20 03:27:39 --> Output Class Initialized
INFO - 2018-06-20 03:27:39 --> Security Class Initialized
DEBUG - 2018-06-20 03:27:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:27:39 --> Input Class Initialized
INFO - 2018-06-20 03:27:39 --> Language Class Initialized
ERROR - 2018-06-20 03:27:39 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:27:39 --> Config Class Initialized
INFO - 2018-06-20 03:27:39 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:27:39 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:27:39 --> Utf8 Class Initialized
INFO - 2018-06-20 03:27:39 --> URI Class Initialized
INFO - 2018-06-20 03:27:39 --> Router Class Initialized
INFO - 2018-06-20 03:27:39 --> Output Class Initialized
INFO - 2018-06-20 03:27:39 --> Security Class Initialized
DEBUG - 2018-06-20 03:27:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:27:39 --> Input Class Initialized
INFO - 2018-06-20 03:27:39 --> Language Class Initialized
ERROR - 2018-06-20 03:27:39 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:27:39 --> Config Class Initialized
INFO - 2018-06-20 03:27:39 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:27:39 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:27:39 --> Utf8 Class Initialized
INFO - 2018-06-20 03:27:39 --> URI Class Initialized
INFO - 2018-06-20 03:27:39 --> Router Class Initialized
INFO - 2018-06-20 03:27:39 --> Output Class Initialized
INFO - 2018-06-20 03:27:39 --> Security Class Initialized
DEBUG - 2018-06-20 03:27:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:27:39 --> Input Class Initialized
INFO - 2018-06-20 03:27:39 --> Language Class Initialized
ERROR - 2018-06-20 03:27:39 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:27:44 --> Config Class Initialized
INFO - 2018-06-20 03:27:44 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:27:44 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:27:44 --> Utf8 Class Initialized
INFO - 2018-06-20 03:27:44 --> URI Class Initialized
INFO - 2018-06-20 03:27:44 --> Router Class Initialized
INFO - 2018-06-20 03:27:44 --> Output Class Initialized
INFO - 2018-06-20 03:27:44 --> Security Class Initialized
DEBUG - 2018-06-20 03:27:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:27:44 --> Input Class Initialized
INFO - 2018-06-20 03:27:44 --> Language Class Initialized
INFO - 2018-06-20 03:27:44 --> Language Class Initialized
INFO - 2018-06-20 03:27:44 --> Config Class Initialized
INFO - 2018-06-20 03:27:44 --> Loader Class Initialized
DEBUG - 2018-06-20 03:27:44 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-20 03:27:44 --> Helper loaded: url_helper
INFO - 2018-06-20 03:27:44 --> Helper loaded: form_helper
INFO - 2018-06-20 03:27:44 --> Helper loaded: date_helper
INFO - 2018-06-20 03:27:44 --> Helper loaded: util_helper
INFO - 2018-06-20 03:27:44 --> Helper loaded: text_helper
INFO - 2018-06-20 03:27:44 --> Helper loaded: string_helper
INFO - 2018-06-20 03:27:44 --> Database Driver Class Initialized
DEBUG - 2018-06-20 03:27:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 03:27:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 03:27:44 --> Email Class Initialized
INFO - 2018-06-20 03:27:44 --> Controller Class Initialized
DEBUG - 2018-06-20 03:27:44 --> Home MX_Controller Initialized
DEBUG - 2018-06-20 03:27:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-20 03:27:44 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-20 03:27:44 --> Login MX_Controller Initialized
INFO - 2018-06-20 03:27:44 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-20 03:27:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-20 03:27:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-20 03:27:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-20 03:27:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-20 03:27:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-20 03:27:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-20 03:27:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-20 03:27:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-06-20 03:27:44 --> Final output sent to browser
DEBUG - 2018-06-20 03:27:44 --> Total execution time: 0.5471
INFO - 2018-06-20 03:27:44 --> Config Class Initialized
INFO - 2018-06-20 03:27:44 --> Config Class Initialized
INFO - 2018-06-20 03:27:44 --> Hooks Class Initialized
INFO - 2018-06-20 03:27:44 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:27:44 --> UTF-8 Support Enabled
DEBUG - 2018-06-20 03:27:44 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:27:44 --> Utf8 Class Initialized
INFO - 2018-06-20 03:27:44 --> URI Class Initialized
INFO - 2018-06-20 03:27:44 --> Router Class Initialized
INFO - 2018-06-20 03:27:45 --> Utf8 Class Initialized
INFO - 2018-06-20 03:27:45 --> URI Class Initialized
INFO - 2018-06-20 03:27:45 --> Output Class Initialized
INFO - 2018-06-20 03:27:45 --> Router Class Initialized
INFO - 2018-06-20 03:27:45 --> Security Class Initialized
INFO - 2018-06-20 03:27:45 --> Output Class Initialized
DEBUG - 2018-06-20 03:27:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:27:45 --> Security Class Initialized
INFO - 2018-06-20 03:27:45 --> Input Class Initialized
DEBUG - 2018-06-20 03:27:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:27:45 --> Input Class Initialized
INFO - 2018-06-20 03:27:45 --> Language Class Initialized
INFO - 2018-06-20 03:27:45 --> Language Class Initialized
ERROR - 2018-06-20 03:27:45 --> 404 Page Not Found: /index
ERROR - 2018-06-20 03:27:45 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:27:45 --> Config Class Initialized
INFO - 2018-06-20 03:27:45 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:27:45 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:27:45 --> Utf8 Class Initialized
INFO - 2018-06-20 03:27:45 --> URI Class Initialized
INFO - 2018-06-20 03:27:45 --> Router Class Initialized
INFO - 2018-06-20 03:27:45 --> Output Class Initialized
INFO - 2018-06-20 03:27:45 --> Security Class Initialized
DEBUG - 2018-06-20 03:27:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:27:45 --> Input Class Initialized
INFO - 2018-06-20 03:27:45 --> Language Class Initialized
ERROR - 2018-06-20 03:27:45 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:27:45 --> Config Class Initialized
INFO - 2018-06-20 03:27:45 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:27:45 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:27:45 --> Utf8 Class Initialized
INFO - 2018-06-20 03:27:45 --> URI Class Initialized
INFO - 2018-06-20 03:27:45 --> Router Class Initialized
INFO - 2018-06-20 03:27:45 --> Output Class Initialized
INFO - 2018-06-20 03:27:45 --> Security Class Initialized
DEBUG - 2018-06-20 03:27:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:27:45 --> Input Class Initialized
INFO - 2018-06-20 03:27:45 --> Language Class Initialized
ERROR - 2018-06-20 03:27:45 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:27:47 --> Config Class Initialized
INFO - 2018-06-20 03:27:47 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:27:47 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:27:47 --> Utf8 Class Initialized
INFO - 2018-06-20 03:27:47 --> URI Class Initialized
INFO - 2018-06-20 03:27:47 --> Router Class Initialized
INFO - 2018-06-20 03:27:47 --> Output Class Initialized
INFO - 2018-06-20 03:27:47 --> Security Class Initialized
DEBUG - 2018-06-20 03:27:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:27:47 --> Input Class Initialized
INFO - 2018-06-20 03:27:47 --> Language Class Initialized
INFO - 2018-06-20 03:27:47 --> Language Class Initialized
INFO - 2018-06-20 03:27:47 --> Config Class Initialized
INFO - 2018-06-20 03:27:47 --> Loader Class Initialized
DEBUG - 2018-06-20 03:27:47 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-20 03:27:47 --> Helper loaded: url_helper
INFO - 2018-06-20 03:27:47 --> Helper loaded: form_helper
INFO - 2018-06-20 03:27:47 --> Helper loaded: date_helper
INFO - 2018-06-20 03:27:47 --> Helper loaded: util_helper
INFO - 2018-06-20 03:27:47 --> Helper loaded: text_helper
INFO - 2018-06-20 03:27:47 --> Helper loaded: string_helper
INFO - 2018-06-20 03:27:47 --> Database Driver Class Initialized
DEBUG - 2018-06-20 03:27:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 03:27:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 03:27:47 --> Email Class Initialized
INFO - 2018-06-20 03:27:47 --> Controller Class Initialized
DEBUG - 2018-06-20 03:27:47 --> Home MX_Controller Initialized
DEBUG - 2018-06-20 03:27:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-20 03:27:47 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-20 03:27:47 --> Login MX_Controller Initialized
INFO - 2018-06-20 03:27:47 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-20 03:27:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-20 03:27:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-20 03:27:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-20 03:27:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-20 03:27:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-20 03:27:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-20 03:27:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-20 03:27:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-06-20 03:27:47 --> Final output sent to browser
DEBUG - 2018-06-20 03:27:47 --> Total execution time: 0.5420
INFO - 2018-06-20 03:27:48 --> Config Class Initialized
INFO - 2018-06-20 03:27:48 --> Config Class Initialized
INFO - 2018-06-20 03:27:48 --> Hooks Class Initialized
INFO - 2018-06-20 03:27:48 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:27:48 --> UTF-8 Support Enabled
DEBUG - 2018-06-20 03:27:48 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:27:48 --> Utf8 Class Initialized
INFO - 2018-06-20 03:27:48 --> URI Class Initialized
INFO - 2018-06-20 03:27:48 --> Router Class Initialized
INFO - 2018-06-20 03:27:48 --> Output Class Initialized
INFO - 2018-06-20 03:27:48 --> Security Class Initialized
DEBUG - 2018-06-20 03:27:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:27:48 --> Utf8 Class Initialized
INFO - 2018-06-20 03:27:48 --> Input Class Initialized
INFO - 2018-06-20 03:27:48 --> Language Class Initialized
INFO - 2018-06-20 03:27:48 --> URI Class Initialized
ERROR - 2018-06-20 03:27:48 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:27:48 --> Router Class Initialized
INFO - 2018-06-20 03:27:48 --> Config Class Initialized
INFO - 2018-06-20 03:27:48 --> Hooks Class Initialized
INFO - 2018-06-20 03:27:48 --> Output Class Initialized
DEBUG - 2018-06-20 03:27:48 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:27:48 --> Utf8 Class Initialized
INFO - 2018-06-20 03:27:48 --> URI Class Initialized
INFO - 2018-06-20 03:27:48 --> Security Class Initialized
INFO - 2018-06-20 03:27:48 --> Router Class Initialized
INFO - 2018-06-20 03:27:48 --> Output Class Initialized
DEBUG - 2018-06-20 03:27:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:27:48 --> Security Class Initialized
INFO - 2018-06-20 03:27:48 --> Input Class Initialized
DEBUG - 2018-06-20 03:27:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:27:48 --> Language Class Initialized
INFO - 2018-06-20 03:27:48 --> Input Class Initialized
ERROR - 2018-06-20 03:27:48 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:27:48 --> Language Class Initialized
ERROR - 2018-06-20 03:27:48 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:27:48 --> Config Class Initialized
INFO - 2018-06-20 03:27:48 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:27:48 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:27:48 --> Utf8 Class Initialized
INFO - 2018-06-20 03:27:48 --> URI Class Initialized
INFO - 2018-06-20 03:27:48 --> Router Class Initialized
INFO - 2018-06-20 03:27:48 --> Output Class Initialized
INFO - 2018-06-20 03:27:48 --> Security Class Initialized
DEBUG - 2018-06-20 03:27:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:27:48 --> Input Class Initialized
INFO - 2018-06-20 03:27:48 --> Language Class Initialized
ERROR - 2018-06-20 03:27:48 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:27:53 --> Config Class Initialized
INFO - 2018-06-20 03:27:53 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:27:53 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:27:53 --> Utf8 Class Initialized
INFO - 2018-06-20 03:27:53 --> URI Class Initialized
INFO - 2018-06-20 03:27:53 --> Router Class Initialized
INFO - 2018-06-20 03:27:53 --> Output Class Initialized
INFO - 2018-06-20 03:27:53 --> Security Class Initialized
DEBUG - 2018-06-20 03:27:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:27:53 --> Input Class Initialized
INFO - 2018-06-20 03:27:53 --> Language Class Initialized
INFO - 2018-06-20 03:27:53 --> Language Class Initialized
INFO - 2018-06-20 03:27:53 --> Config Class Initialized
INFO - 2018-06-20 03:27:53 --> Loader Class Initialized
DEBUG - 2018-06-20 03:27:53 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-20 03:27:53 --> Helper loaded: url_helper
INFO - 2018-06-20 03:27:53 --> Helper loaded: form_helper
INFO - 2018-06-20 03:27:53 --> Helper loaded: date_helper
INFO - 2018-06-20 03:27:53 --> Helper loaded: util_helper
INFO - 2018-06-20 03:27:53 --> Helper loaded: text_helper
INFO - 2018-06-20 03:27:53 --> Helper loaded: string_helper
INFO - 2018-06-20 03:27:53 --> Database Driver Class Initialized
DEBUG - 2018-06-20 03:27:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 03:27:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 03:27:53 --> Email Class Initialized
INFO - 2018-06-20 03:27:53 --> Controller Class Initialized
DEBUG - 2018-06-20 03:27:53 --> Home MX_Controller Initialized
DEBUG - 2018-06-20 03:27:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-20 03:27:53 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-20 03:27:53 --> Login MX_Controller Initialized
INFO - 2018-06-20 03:27:53 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-20 03:27:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-20 03:27:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-20 03:27:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-20 03:27:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-20 03:27:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-20 03:27:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-20 03:27:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-20 03:27:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-06-20 03:27:54 --> Final output sent to browser
DEBUG - 2018-06-20 03:27:54 --> Total execution time: 0.5618
INFO - 2018-06-20 03:27:54 --> Config Class Initialized
INFO - 2018-06-20 03:27:54 --> Config Class Initialized
INFO - 2018-06-20 03:27:54 --> Hooks Class Initialized
INFO - 2018-06-20 03:27:54 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:27:54 --> UTF-8 Support Enabled
DEBUG - 2018-06-20 03:27:54 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:27:54 --> Utf8 Class Initialized
INFO - 2018-06-20 03:27:54 --> Utf8 Class Initialized
INFO - 2018-06-20 03:27:54 --> URI Class Initialized
INFO - 2018-06-20 03:27:54 --> Router Class Initialized
INFO - 2018-06-20 03:27:54 --> Output Class Initialized
INFO - 2018-06-20 03:27:54 --> Security Class Initialized
DEBUG - 2018-06-20 03:27:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:27:54 --> Input Class Initialized
INFO - 2018-06-20 03:27:54 --> URI Class Initialized
INFO - 2018-06-20 03:27:54 --> Language Class Initialized
INFO - 2018-06-20 03:27:54 --> Router Class Initialized
ERROR - 2018-06-20 03:27:54 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:27:54 --> Output Class Initialized
INFO - 2018-06-20 03:27:54 --> Security Class Initialized
DEBUG - 2018-06-20 03:27:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:27:54 --> Input Class Initialized
INFO - 2018-06-20 03:27:54 --> Language Class Initialized
ERROR - 2018-06-20 03:27:54 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:27:54 --> Config Class Initialized
INFO - 2018-06-20 03:27:54 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:27:54 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:27:54 --> Utf8 Class Initialized
INFO - 2018-06-20 03:27:54 --> URI Class Initialized
INFO - 2018-06-20 03:27:54 --> Router Class Initialized
INFO - 2018-06-20 03:27:54 --> Output Class Initialized
INFO - 2018-06-20 03:27:54 --> Security Class Initialized
DEBUG - 2018-06-20 03:27:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:27:54 --> Input Class Initialized
INFO - 2018-06-20 03:27:54 --> Language Class Initialized
ERROR - 2018-06-20 03:27:54 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:27:54 --> Config Class Initialized
INFO - 2018-06-20 03:27:54 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:27:54 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:27:54 --> Utf8 Class Initialized
INFO - 2018-06-20 03:27:54 --> URI Class Initialized
INFO - 2018-06-20 03:27:54 --> Router Class Initialized
INFO - 2018-06-20 03:27:54 --> Output Class Initialized
INFO - 2018-06-20 03:27:54 --> Security Class Initialized
DEBUG - 2018-06-20 03:27:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:27:55 --> Input Class Initialized
INFO - 2018-06-20 03:27:55 --> Language Class Initialized
ERROR - 2018-06-20 03:27:55 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:27:57 --> Config Class Initialized
INFO - 2018-06-20 03:27:57 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:27:57 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:27:57 --> Utf8 Class Initialized
INFO - 2018-06-20 03:27:57 --> URI Class Initialized
INFO - 2018-06-20 03:27:57 --> Router Class Initialized
INFO - 2018-06-20 03:27:57 --> Output Class Initialized
INFO - 2018-06-20 03:27:57 --> Security Class Initialized
DEBUG - 2018-06-20 03:27:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:27:57 --> Input Class Initialized
INFO - 2018-06-20 03:27:57 --> Language Class Initialized
INFO - 2018-06-20 03:27:57 --> Language Class Initialized
INFO - 2018-06-20 03:27:57 --> Config Class Initialized
INFO - 2018-06-20 03:27:57 --> Loader Class Initialized
DEBUG - 2018-06-20 03:27:57 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-20 03:27:57 --> Helper loaded: url_helper
INFO - 2018-06-20 03:27:57 --> Helper loaded: form_helper
INFO - 2018-06-20 03:27:57 --> Helper loaded: date_helper
INFO - 2018-06-20 03:27:57 --> Helper loaded: util_helper
INFO - 2018-06-20 03:27:57 --> Helper loaded: text_helper
INFO - 2018-06-20 03:27:57 --> Helper loaded: string_helper
INFO - 2018-06-20 03:27:57 --> Database Driver Class Initialized
DEBUG - 2018-06-20 03:27:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 03:27:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 03:27:57 --> Email Class Initialized
INFO - 2018-06-20 03:27:57 --> Controller Class Initialized
DEBUG - 2018-06-20 03:27:57 --> Home MX_Controller Initialized
DEBUG - 2018-06-20 03:27:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-20 03:27:57 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-20 03:27:57 --> Login MX_Controller Initialized
INFO - 2018-06-20 03:27:57 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-20 03:27:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-20 03:27:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-20 03:27:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-20 03:27:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-20 03:27:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-20 03:27:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-20 03:27:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-20 03:27:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-06-20 03:27:57 --> Final output sent to browser
DEBUG - 2018-06-20 03:27:57 --> Total execution time: 0.5837
INFO - 2018-06-20 03:27:58 --> Config Class Initialized
INFO - 2018-06-20 03:27:58 --> Config Class Initialized
INFO - 2018-06-20 03:27:58 --> Hooks Class Initialized
INFO - 2018-06-20 03:27:58 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:27:58 --> UTF-8 Support Enabled
DEBUG - 2018-06-20 03:27:58 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:27:58 --> Utf8 Class Initialized
INFO - 2018-06-20 03:27:58 --> Utf8 Class Initialized
INFO - 2018-06-20 03:27:58 --> URI Class Initialized
INFO - 2018-06-20 03:27:58 --> URI Class Initialized
INFO - 2018-06-20 03:27:58 --> Router Class Initialized
INFO - 2018-06-20 03:27:58 --> Router Class Initialized
INFO - 2018-06-20 03:27:58 --> Output Class Initialized
INFO - 2018-06-20 03:27:58 --> Output Class Initialized
INFO - 2018-06-20 03:27:58 --> Security Class Initialized
DEBUG - 2018-06-20 03:27:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:27:58 --> Security Class Initialized
INFO - 2018-06-20 03:27:58 --> Input Class Initialized
DEBUG - 2018-06-20 03:27:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:27:58 --> Language Class Initialized
INFO - 2018-06-20 03:27:58 --> Input Class Initialized
ERROR - 2018-06-20 03:27:58 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:27:58 --> Language Class Initialized
ERROR - 2018-06-20 03:27:58 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:27:58 --> Config Class Initialized
INFO - 2018-06-20 03:27:58 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:27:58 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:27:58 --> Utf8 Class Initialized
INFO - 2018-06-20 03:27:58 --> URI Class Initialized
INFO - 2018-06-20 03:27:58 --> Router Class Initialized
INFO - 2018-06-20 03:27:58 --> Output Class Initialized
INFO - 2018-06-20 03:27:58 --> Security Class Initialized
DEBUG - 2018-06-20 03:27:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:27:58 --> Input Class Initialized
INFO - 2018-06-20 03:27:58 --> Language Class Initialized
ERROR - 2018-06-20 03:27:58 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:27:58 --> Config Class Initialized
INFO - 2018-06-20 03:27:58 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:27:58 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:27:58 --> Utf8 Class Initialized
INFO - 2018-06-20 03:27:58 --> URI Class Initialized
INFO - 2018-06-20 03:27:58 --> Router Class Initialized
INFO - 2018-06-20 03:27:58 --> Output Class Initialized
INFO - 2018-06-20 03:27:58 --> Security Class Initialized
DEBUG - 2018-06-20 03:27:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:27:58 --> Input Class Initialized
INFO - 2018-06-20 03:27:58 --> Language Class Initialized
ERROR - 2018-06-20 03:27:58 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:28:00 --> Config Class Initialized
INFO - 2018-06-20 03:28:00 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:28:00 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:28:00 --> Utf8 Class Initialized
INFO - 2018-06-20 03:28:00 --> URI Class Initialized
INFO - 2018-06-20 03:28:00 --> Router Class Initialized
INFO - 2018-06-20 03:28:00 --> Output Class Initialized
INFO - 2018-06-20 03:28:00 --> Security Class Initialized
DEBUG - 2018-06-20 03:28:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:28:00 --> Input Class Initialized
INFO - 2018-06-20 03:28:00 --> Language Class Initialized
INFO - 2018-06-20 03:28:00 --> Language Class Initialized
INFO - 2018-06-20 03:28:00 --> Config Class Initialized
INFO - 2018-06-20 03:28:00 --> Loader Class Initialized
DEBUG - 2018-06-20 03:28:00 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-20 03:28:00 --> Helper loaded: url_helper
INFO - 2018-06-20 03:28:00 --> Helper loaded: form_helper
INFO - 2018-06-20 03:28:00 --> Helper loaded: date_helper
INFO - 2018-06-20 03:28:00 --> Helper loaded: util_helper
INFO - 2018-06-20 03:28:00 --> Helper loaded: text_helper
INFO - 2018-06-20 03:28:00 --> Helper loaded: string_helper
INFO - 2018-06-20 03:28:00 --> Database Driver Class Initialized
DEBUG - 2018-06-20 03:28:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 03:28:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 03:28:00 --> Email Class Initialized
INFO - 2018-06-20 03:28:00 --> Controller Class Initialized
DEBUG - 2018-06-20 03:28:00 --> Home MX_Controller Initialized
DEBUG - 2018-06-20 03:28:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-20 03:28:00 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-20 03:28:00 --> Login MX_Controller Initialized
INFO - 2018-06-20 03:28:00 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-20 03:28:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-20 03:28:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-20 03:28:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-20 03:28:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-20 03:28:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-20 03:28:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-20 03:28:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-20 03:28:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-06-20 03:28:00 --> Final output sent to browser
DEBUG - 2018-06-20 03:28:00 --> Total execution time: 0.5633
INFO - 2018-06-20 03:28:00 --> Config Class Initialized
INFO - 2018-06-20 03:28:00 --> Config Class Initialized
INFO - 2018-06-20 03:28:00 --> Hooks Class Initialized
INFO - 2018-06-20 03:28:00 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:28:00 --> UTF-8 Support Enabled
DEBUG - 2018-06-20 03:28:00 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:28:01 --> Utf8 Class Initialized
INFO - 2018-06-20 03:28:01 --> Utf8 Class Initialized
INFO - 2018-06-20 03:28:01 --> URI Class Initialized
INFO - 2018-06-20 03:28:01 --> Router Class Initialized
INFO - 2018-06-20 03:28:01 --> URI Class Initialized
INFO - 2018-06-20 03:28:01 --> Output Class Initialized
INFO - 2018-06-20 03:28:01 --> Security Class Initialized
INFO - 2018-06-20 03:28:01 --> Router Class Initialized
DEBUG - 2018-06-20 03:28:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:28:01 --> Input Class Initialized
INFO - 2018-06-20 03:28:01 --> Output Class Initialized
INFO - 2018-06-20 03:28:01 --> Security Class Initialized
INFO - 2018-06-20 03:28:01 --> Language Class Initialized
DEBUG - 2018-06-20 03:28:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:28:01 --> Input Class Initialized
ERROR - 2018-06-20 03:28:01 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:28:01 --> Language Class Initialized
ERROR - 2018-06-20 03:28:01 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:28:01 --> Config Class Initialized
INFO - 2018-06-20 03:28:01 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:28:01 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:28:01 --> Utf8 Class Initialized
INFO - 2018-06-20 03:28:01 --> URI Class Initialized
INFO - 2018-06-20 03:28:01 --> Router Class Initialized
INFO - 2018-06-20 03:28:01 --> Output Class Initialized
INFO - 2018-06-20 03:28:01 --> Security Class Initialized
DEBUG - 2018-06-20 03:28:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:28:01 --> Input Class Initialized
INFO - 2018-06-20 03:28:01 --> Language Class Initialized
ERROR - 2018-06-20 03:28:01 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:28:01 --> Config Class Initialized
INFO - 2018-06-20 03:28:01 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:28:01 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:28:01 --> Utf8 Class Initialized
INFO - 2018-06-20 03:28:01 --> URI Class Initialized
INFO - 2018-06-20 03:28:01 --> Router Class Initialized
INFO - 2018-06-20 03:28:01 --> Output Class Initialized
INFO - 2018-06-20 03:28:01 --> Security Class Initialized
DEBUG - 2018-06-20 03:28:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:28:01 --> Input Class Initialized
INFO - 2018-06-20 03:28:01 --> Language Class Initialized
ERROR - 2018-06-20 03:28:01 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:28:03 --> Config Class Initialized
INFO - 2018-06-20 03:28:03 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:28:03 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:28:03 --> Utf8 Class Initialized
INFO - 2018-06-20 03:28:04 --> URI Class Initialized
INFO - 2018-06-20 03:28:04 --> Router Class Initialized
INFO - 2018-06-20 03:28:04 --> Output Class Initialized
INFO - 2018-06-20 03:28:04 --> Security Class Initialized
DEBUG - 2018-06-20 03:28:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:28:04 --> Input Class Initialized
INFO - 2018-06-20 03:28:04 --> Language Class Initialized
INFO - 2018-06-20 03:28:04 --> Language Class Initialized
INFO - 2018-06-20 03:28:04 --> Config Class Initialized
INFO - 2018-06-20 03:28:04 --> Loader Class Initialized
DEBUG - 2018-06-20 03:28:04 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-20 03:28:04 --> Helper loaded: url_helper
INFO - 2018-06-20 03:28:04 --> Helper loaded: form_helper
INFO - 2018-06-20 03:28:04 --> Helper loaded: date_helper
INFO - 2018-06-20 03:28:04 --> Helper loaded: util_helper
INFO - 2018-06-20 03:28:04 --> Helper loaded: text_helper
INFO - 2018-06-20 03:28:04 --> Helper loaded: string_helper
INFO - 2018-06-20 03:28:04 --> Database Driver Class Initialized
DEBUG - 2018-06-20 03:28:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 03:28:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 03:28:04 --> Email Class Initialized
INFO - 2018-06-20 03:28:04 --> Controller Class Initialized
DEBUG - 2018-06-20 03:28:04 --> Home MX_Controller Initialized
DEBUG - 2018-06-20 03:28:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-20 03:28:04 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-20 03:28:04 --> Login MX_Controller Initialized
INFO - 2018-06-20 03:28:04 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-20 03:28:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-20 03:28:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-20 03:28:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-20 03:28:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-20 03:28:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-20 03:28:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-20 03:28:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-20 03:28:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-06-20 03:28:04 --> Final output sent to browser
DEBUG - 2018-06-20 03:28:04 --> Total execution time: 0.6080
INFO - 2018-06-20 03:28:04 --> Config Class Initialized
INFO - 2018-06-20 03:28:04 --> Config Class Initialized
INFO - 2018-06-20 03:28:04 --> Hooks Class Initialized
INFO - 2018-06-20 03:28:04 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:28:04 --> UTF-8 Support Enabled
DEBUG - 2018-06-20 03:28:04 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:28:04 --> Utf8 Class Initialized
INFO - 2018-06-20 03:28:04 --> Utf8 Class Initialized
INFO - 2018-06-20 03:28:04 --> URI Class Initialized
INFO - 2018-06-20 03:28:04 --> URI Class Initialized
INFO - 2018-06-20 03:28:04 --> Router Class Initialized
INFO - 2018-06-20 03:28:04 --> Router Class Initialized
INFO - 2018-06-20 03:28:04 --> Output Class Initialized
INFO - 2018-06-20 03:28:04 --> Security Class Initialized
INFO - 2018-06-20 03:28:04 --> Output Class Initialized
DEBUG - 2018-06-20 03:28:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:28:05 --> Input Class Initialized
INFO - 2018-06-20 03:28:05 --> Language Class Initialized
ERROR - 2018-06-20 03:28:05 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:28:05 --> Config Class Initialized
INFO - 2018-06-20 03:28:05 --> Hooks Class Initialized
INFO - 2018-06-20 03:28:05 --> Security Class Initialized
DEBUG - 2018-06-20 03:28:05 --> UTF-8 Support Enabled
DEBUG - 2018-06-20 03:28:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:28:05 --> Utf8 Class Initialized
INFO - 2018-06-20 03:28:05 --> Input Class Initialized
INFO - 2018-06-20 03:28:05 --> URI Class Initialized
INFO - 2018-06-20 03:28:05 --> Language Class Initialized
INFO - 2018-06-20 03:28:05 --> Router Class Initialized
ERROR - 2018-06-20 03:28:05 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:28:05 --> Output Class Initialized
INFO - 2018-06-20 03:28:05 --> Security Class Initialized
DEBUG - 2018-06-20 03:28:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:28:05 --> Input Class Initialized
INFO - 2018-06-20 03:28:05 --> Language Class Initialized
ERROR - 2018-06-20 03:28:05 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:28:05 --> Config Class Initialized
INFO - 2018-06-20 03:28:05 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:28:05 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:28:05 --> Utf8 Class Initialized
INFO - 2018-06-20 03:28:05 --> URI Class Initialized
INFO - 2018-06-20 03:28:05 --> Router Class Initialized
INFO - 2018-06-20 03:28:05 --> Output Class Initialized
INFO - 2018-06-20 03:28:05 --> Security Class Initialized
DEBUG - 2018-06-20 03:28:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:28:05 --> Input Class Initialized
INFO - 2018-06-20 03:28:05 --> Language Class Initialized
ERROR - 2018-06-20 03:28:05 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:28:07 --> Config Class Initialized
INFO - 2018-06-20 03:28:07 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:28:07 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:28:07 --> Utf8 Class Initialized
INFO - 2018-06-20 03:28:07 --> URI Class Initialized
INFO - 2018-06-20 03:28:07 --> Router Class Initialized
INFO - 2018-06-20 03:28:07 --> Output Class Initialized
INFO - 2018-06-20 03:28:07 --> Security Class Initialized
DEBUG - 2018-06-20 03:28:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:28:07 --> Input Class Initialized
INFO - 2018-06-20 03:28:07 --> Language Class Initialized
INFO - 2018-06-20 03:28:07 --> Language Class Initialized
INFO - 2018-06-20 03:28:07 --> Config Class Initialized
INFO - 2018-06-20 03:28:07 --> Loader Class Initialized
DEBUG - 2018-06-20 03:28:07 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-20 03:28:07 --> Helper loaded: url_helper
INFO - 2018-06-20 03:28:07 --> Helper loaded: form_helper
INFO - 2018-06-20 03:28:07 --> Helper loaded: date_helper
INFO - 2018-06-20 03:28:07 --> Helper loaded: util_helper
INFO - 2018-06-20 03:28:07 --> Helper loaded: text_helper
INFO - 2018-06-20 03:28:07 --> Helper loaded: string_helper
INFO - 2018-06-20 03:28:07 --> Database Driver Class Initialized
DEBUG - 2018-06-20 03:28:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 03:28:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 03:28:07 --> Email Class Initialized
INFO - 2018-06-20 03:28:07 --> Controller Class Initialized
DEBUG - 2018-06-20 03:28:07 --> Home MX_Controller Initialized
DEBUG - 2018-06-20 03:28:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-20 03:28:07 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-20 03:28:07 --> Login MX_Controller Initialized
INFO - 2018-06-20 03:28:07 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-20 03:28:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-20 03:28:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-20 03:28:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-20 03:28:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-20 03:28:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-20 03:28:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-20 03:28:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-20 03:28:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-06-20 03:28:07 --> Final output sent to browser
DEBUG - 2018-06-20 03:28:08 --> Total execution time: 0.5673
INFO - 2018-06-20 03:28:08 --> Config Class Initialized
INFO - 2018-06-20 03:28:08 --> Config Class Initialized
INFO - 2018-06-20 03:28:08 --> Hooks Class Initialized
INFO - 2018-06-20 03:28:08 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:28:08 --> UTF-8 Support Enabled
DEBUG - 2018-06-20 03:28:08 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:28:08 --> Utf8 Class Initialized
INFO - 2018-06-20 03:28:08 --> URI Class Initialized
INFO - 2018-06-20 03:28:08 --> Utf8 Class Initialized
INFO - 2018-06-20 03:28:08 --> Router Class Initialized
INFO - 2018-06-20 03:28:08 --> Output Class Initialized
INFO - 2018-06-20 03:28:08 --> URI Class Initialized
INFO - 2018-06-20 03:28:08 --> Security Class Initialized
DEBUG - 2018-06-20 03:28:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:28:08 --> Router Class Initialized
INFO - 2018-06-20 03:28:08 --> Output Class Initialized
INFO - 2018-06-20 03:28:08 --> Input Class Initialized
INFO - 2018-06-20 03:28:08 --> Language Class Initialized
INFO - 2018-06-20 03:28:08 --> Security Class Initialized
DEBUG - 2018-06-20 03:28:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-06-20 03:28:08 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:28:08 --> Input Class Initialized
INFO - 2018-06-20 03:28:08 --> Language Class Initialized
ERROR - 2018-06-20 03:28:08 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:28:08 --> Config Class Initialized
INFO - 2018-06-20 03:28:08 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:28:08 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:28:08 --> Utf8 Class Initialized
INFO - 2018-06-20 03:28:08 --> URI Class Initialized
INFO - 2018-06-20 03:28:08 --> Router Class Initialized
INFO - 2018-06-20 03:28:08 --> Output Class Initialized
INFO - 2018-06-20 03:28:08 --> Security Class Initialized
DEBUG - 2018-06-20 03:28:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:28:08 --> Input Class Initialized
INFO - 2018-06-20 03:28:08 --> Language Class Initialized
ERROR - 2018-06-20 03:28:08 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:28:08 --> Config Class Initialized
INFO - 2018-06-20 03:28:08 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:28:08 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:28:08 --> Utf8 Class Initialized
INFO - 2018-06-20 03:28:08 --> URI Class Initialized
INFO - 2018-06-20 03:28:08 --> Router Class Initialized
INFO - 2018-06-20 03:28:08 --> Output Class Initialized
INFO - 2018-06-20 03:28:08 --> Security Class Initialized
DEBUG - 2018-06-20 03:28:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:28:09 --> Input Class Initialized
INFO - 2018-06-20 03:28:09 --> Language Class Initialized
ERROR - 2018-06-20 03:28:09 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:28:56 --> Config Class Initialized
INFO - 2018-06-20 03:28:56 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:28:56 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:28:56 --> Utf8 Class Initialized
INFO - 2018-06-20 03:28:56 --> URI Class Initialized
INFO - 2018-06-20 03:28:56 --> Router Class Initialized
INFO - 2018-06-20 03:28:56 --> Output Class Initialized
INFO - 2018-06-20 03:28:56 --> Security Class Initialized
DEBUG - 2018-06-20 03:28:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:28:56 --> Input Class Initialized
INFO - 2018-06-20 03:28:56 --> Language Class Initialized
INFO - 2018-06-20 03:28:56 --> Language Class Initialized
INFO - 2018-06-20 03:28:56 --> Config Class Initialized
INFO - 2018-06-20 03:28:56 --> Loader Class Initialized
DEBUG - 2018-06-20 03:28:56 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-20 03:28:56 --> Helper loaded: url_helper
INFO - 2018-06-20 03:28:56 --> Helper loaded: form_helper
INFO - 2018-06-20 03:28:56 --> Helper loaded: date_helper
INFO - 2018-06-20 03:28:56 --> Helper loaded: util_helper
INFO - 2018-06-20 03:28:56 --> Helper loaded: text_helper
INFO - 2018-06-20 03:28:56 --> Helper loaded: string_helper
INFO - 2018-06-20 03:28:56 --> Database Driver Class Initialized
DEBUG - 2018-06-20 03:28:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 03:28:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 03:28:56 --> Email Class Initialized
INFO - 2018-06-20 03:28:56 --> Controller Class Initialized
DEBUG - 2018-06-20 03:28:57 --> Home MX_Controller Initialized
DEBUG - 2018-06-20 03:28:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-20 03:28:57 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-20 03:28:57 --> Login MX_Controller Initialized
INFO - 2018-06-20 03:28:57 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-20 03:28:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-20 03:28:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-20 03:28:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-20 03:28:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-20 03:28:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-20 03:28:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-20 03:28:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-20 03:28:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-06-20 03:28:57 --> Final output sent to browser
DEBUG - 2018-06-20 03:28:57 --> Total execution time: 0.5616
INFO - 2018-06-20 03:28:57 --> Config Class Initialized
INFO - 2018-06-20 03:28:57 --> Hooks Class Initialized
INFO - 2018-06-20 03:28:57 --> Config Class Initialized
INFO - 2018-06-20 03:28:57 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:28:57 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:28:57 --> Utf8 Class Initialized
DEBUG - 2018-06-20 03:28:57 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:28:57 --> Utf8 Class Initialized
INFO - 2018-06-20 03:28:57 --> URI Class Initialized
INFO - 2018-06-20 03:28:57 --> URI Class Initialized
INFO - 2018-06-20 03:28:57 --> Router Class Initialized
INFO - 2018-06-20 03:28:57 --> Router Class Initialized
INFO - 2018-06-20 03:28:57 --> Output Class Initialized
INFO - 2018-06-20 03:28:57 --> Security Class Initialized
INFO - 2018-06-20 03:28:57 --> Output Class Initialized
DEBUG - 2018-06-20 03:28:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:28:57 --> Input Class Initialized
INFO - 2018-06-20 03:28:57 --> Language Class Initialized
ERROR - 2018-06-20 03:28:57 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:28:57 --> Security Class Initialized
DEBUG - 2018-06-20 03:28:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:28:57 --> Config Class Initialized
INFO - 2018-06-20 03:28:57 --> Hooks Class Initialized
INFO - 2018-06-20 03:28:57 --> Input Class Initialized
INFO - 2018-06-20 03:28:57 --> Language Class Initialized
DEBUG - 2018-06-20 03:28:57 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:28:57 --> Utf8 Class Initialized
ERROR - 2018-06-20 03:28:57 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:28:57 --> URI Class Initialized
INFO - 2018-06-20 03:28:57 --> Router Class Initialized
INFO - 2018-06-20 03:28:58 --> Output Class Initialized
INFO - 2018-06-20 03:28:58 --> Security Class Initialized
DEBUG - 2018-06-20 03:28:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:28:58 --> Input Class Initialized
INFO - 2018-06-20 03:28:58 --> Language Class Initialized
ERROR - 2018-06-20 03:28:58 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:28:58 --> Config Class Initialized
INFO - 2018-06-20 03:28:58 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:28:58 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:28:58 --> Utf8 Class Initialized
INFO - 2018-06-20 03:28:58 --> URI Class Initialized
INFO - 2018-06-20 03:28:58 --> Router Class Initialized
INFO - 2018-06-20 03:28:58 --> Output Class Initialized
INFO - 2018-06-20 03:28:58 --> Security Class Initialized
DEBUG - 2018-06-20 03:28:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:28:58 --> Input Class Initialized
INFO - 2018-06-20 03:28:58 --> Language Class Initialized
ERROR - 2018-06-20 03:28:58 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:28:58 --> Config Class Initialized
INFO - 2018-06-20 03:28:58 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:28:58 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:28:58 --> Utf8 Class Initialized
INFO - 2018-06-20 03:28:58 --> URI Class Initialized
INFO - 2018-06-20 03:28:58 --> Router Class Initialized
INFO - 2018-06-20 03:28:59 --> Output Class Initialized
INFO - 2018-06-20 03:28:59 --> Security Class Initialized
DEBUG - 2018-06-20 03:28:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:28:59 --> Input Class Initialized
INFO - 2018-06-20 03:28:59 --> Language Class Initialized
ERROR - 2018-06-20 03:28:59 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:28:59 --> Config Class Initialized
INFO - 2018-06-20 03:28:59 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:28:59 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:28:59 --> Utf8 Class Initialized
INFO - 2018-06-20 03:28:59 --> URI Class Initialized
INFO - 2018-06-20 03:28:59 --> Router Class Initialized
INFO - 2018-06-20 03:28:59 --> Output Class Initialized
INFO - 2018-06-20 03:28:59 --> Security Class Initialized
DEBUG - 2018-06-20 03:28:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:28:59 --> Input Class Initialized
INFO - 2018-06-20 03:28:59 --> Language Class Initialized
ERROR - 2018-06-20 03:28:59 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:28:59 --> Config Class Initialized
INFO - 2018-06-20 03:28:59 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:28:59 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:28:59 --> Utf8 Class Initialized
INFO - 2018-06-20 03:28:59 --> URI Class Initialized
INFO - 2018-06-20 03:28:59 --> Router Class Initialized
INFO - 2018-06-20 03:28:59 --> Output Class Initialized
INFO - 2018-06-20 03:28:59 --> Security Class Initialized
DEBUG - 2018-06-20 03:28:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:28:59 --> Input Class Initialized
INFO - 2018-06-20 03:28:59 --> Language Class Initialized
ERROR - 2018-06-20 03:28:59 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:28:59 --> Config Class Initialized
INFO - 2018-06-20 03:28:59 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:28:59 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:28:59 --> Utf8 Class Initialized
INFO - 2018-06-20 03:28:59 --> URI Class Initialized
INFO - 2018-06-20 03:29:00 --> Router Class Initialized
INFO - 2018-06-20 03:29:00 --> Output Class Initialized
INFO - 2018-06-20 03:29:00 --> Security Class Initialized
DEBUG - 2018-06-20 03:29:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:29:00 --> Input Class Initialized
INFO - 2018-06-20 03:29:00 --> Language Class Initialized
INFO - 2018-06-20 03:29:00 --> Language Class Initialized
INFO - 2018-06-20 03:29:00 --> Config Class Initialized
INFO - 2018-06-20 03:29:00 --> Loader Class Initialized
DEBUG - 2018-06-20 03:29:00 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-20 03:29:00 --> Helper loaded: url_helper
INFO - 2018-06-20 03:29:00 --> Helper loaded: form_helper
INFO - 2018-06-20 03:29:00 --> Helper loaded: date_helper
INFO - 2018-06-20 03:29:00 --> Helper loaded: util_helper
INFO - 2018-06-20 03:29:00 --> Helper loaded: text_helper
INFO - 2018-06-20 03:29:00 --> Helper loaded: string_helper
INFO - 2018-06-20 03:29:00 --> Database Driver Class Initialized
DEBUG - 2018-06-20 03:29:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 03:29:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 03:29:00 --> Email Class Initialized
INFO - 2018-06-20 03:29:00 --> Controller Class Initialized
DEBUG - 2018-06-20 03:29:00 --> Home MX_Controller Initialized
DEBUG - 2018-06-20 03:29:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-20 03:29:00 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-20 03:29:00 --> Login MX_Controller Initialized
INFO - 2018-06-20 03:29:00 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-20 03:29:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-20 03:29:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-20 03:29:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-20 03:29:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-20 03:29:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-20 03:29:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-20 03:29:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-20 03:29:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-06-20 03:29:00 --> Final output sent to browser
DEBUG - 2018-06-20 03:29:00 --> Total execution time: 0.5886
INFO - 2018-06-20 03:29:00 --> Config Class Initialized
INFO - 2018-06-20 03:29:00 --> Config Class Initialized
INFO - 2018-06-20 03:29:00 --> Hooks Class Initialized
INFO - 2018-06-20 03:29:00 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:29:00 --> UTF-8 Support Enabled
DEBUG - 2018-06-20 03:29:00 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:29:00 --> Utf8 Class Initialized
INFO - 2018-06-20 03:29:00 --> Utf8 Class Initialized
INFO - 2018-06-20 03:29:00 --> URI Class Initialized
INFO - 2018-06-20 03:29:00 --> Router Class Initialized
INFO - 2018-06-20 03:29:00 --> Output Class Initialized
INFO - 2018-06-20 03:29:00 --> URI Class Initialized
INFO - 2018-06-20 03:29:00 --> Security Class Initialized
INFO - 2018-06-20 03:29:00 --> Router Class Initialized
DEBUG - 2018-06-20 03:29:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:29:01 --> Output Class Initialized
INFO - 2018-06-20 03:29:01 --> Security Class Initialized
INFO - 2018-06-20 03:29:01 --> Input Class Initialized
DEBUG - 2018-06-20 03:29:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:29:01 --> Language Class Initialized
INFO - 2018-06-20 03:29:01 --> Input Class Initialized
INFO - 2018-06-20 03:29:01 --> Language Class Initialized
ERROR - 2018-06-20 03:29:01 --> 404 Page Not Found: /index
ERROR - 2018-06-20 03:29:01 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:29:01 --> Config Class Initialized
INFO - 2018-06-20 03:29:01 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:29:01 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:29:01 --> Utf8 Class Initialized
INFO - 2018-06-20 03:29:01 --> URI Class Initialized
INFO - 2018-06-20 03:29:01 --> Router Class Initialized
INFO - 2018-06-20 03:29:01 --> Output Class Initialized
INFO - 2018-06-20 03:29:01 --> Security Class Initialized
DEBUG - 2018-06-20 03:29:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:29:01 --> Input Class Initialized
INFO - 2018-06-20 03:29:01 --> Language Class Initialized
ERROR - 2018-06-20 03:29:01 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:29:01 --> Config Class Initialized
INFO - 2018-06-20 03:29:01 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:29:01 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:29:01 --> Utf8 Class Initialized
INFO - 2018-06-20 03:29:01 --> URI Class Initialized
INFO - 2018-06-20 03:29:01 --> Router Class Initialized
INFO - 2018-06-20 03:29:01 --> Output Class Initialized
INFO - 2018-06-20 03:29:01 --> Security Class Initialized
DEBUG - 2018-06-20 03:29:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:29:01 --> Input Class Initialized
INFO - 2018-06-20 03:29:01 --> Language Class Initialized
ERROR - 2018-06-20 03:29:01 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:29:40 --> Config Class Initialized
INFO - 2018-06-20 03:29:40 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:29:40 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:29:40 --> Utf8 Class Initialized
INFO - 2018-06-20 03:29:40 --> URI Class Initialized
INFO - 2018-06-20 03:29:40 --> Router Class Initialized
INFO - 2018-06-20 03:29:40 --> Output Class Initialized
INFO - 2018-06-20 03:29:40 --> Security Class Initialized
DEBUG - 2018-06-20 03:29:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:29:40 --> Input Class Initialized
INFO - 2018-06-20 03:29:40 --> Language Class Initialized
INFO - 2018-06-20 03:29:40 --> Language Class Initialized
INFO - 2018-06-20 03:29:40 --> Config Class Initialized
INFO - 2018-06-20 03:29:40 --> Loader Class Initialized
DEBUG - 2018-06-20 03:29:40 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-20 03:29:40 --> Helper loaded: url_helper
INFO - 2018-06-20 03:29:40 --> Helper loaded: form_helper
INFO - 2018-06-20 03:29:40 --> Helper loaded: date_helper
INFO - 2018-06-20 03:29:40 --> Helper loaded: util_helper
INFO - 2018-06-20 03:29:40 --> Helper loaded: text_helper
INFO - 2018-06-20 03:29:40 --> Helper loaded: string_helper
INFO - 2018-06-20 03:29:40 --> Database Driver Class Initialized
DEBUG - 2018-06-20 03:29:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 03:29:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 03:29:40 --> Email Class Initialized
INFO - 2018-06-20 03:29:40 --> Controller Class Initialized
DEBUG - 2018-06-20 03:29:40 --> Home MX_Controller Initialized
DEBUG - 2018-06-20 03:29:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-20 03:29:40 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-20 03:29:40 --> Login MX_Controller Initialized
INFO - 2018-06-20 03:29:40 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-20 03:29:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-20 03:29:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
ERROR - 2018-06-20 03:29:40 --> Severity: error --> Exception: syntax error, unexpected end of file E:\xampp\htdocs\consulting\application\modules\home\views\course.php 476
INFO - 2018-06-20 03:29:54 --> Config Class Initialized
INFO - 2018-06-20 03:29:54 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:29:54 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:29:54 --> Utf8 Class Initialized
INFO - 2018-06-20 03:29:54 --> URI Class Initialized
INFO - 2018-06-20 03:29:54 --> Router Class Initialized
INFO - 2018-06-20 03:29:54 --> Output Class Initialized
INFO - 2018-06-20 03:29:54 --> Security Class Initialized
DEBUG - 2018-06-20 03:29:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:29:54 --> Input Class Initialized
INFO - 2018-06-20 03:29:54 --> Language Class Initialized
INFO - 2018-06-20 03:29:54 --> Language Class Initialized
INFO - 2018-06-20 03:29:54 --> Config Class Initialized
INFO - 2018-06-20 03:29:54 --> Loader Class Initialized
DEBUG - 2018-06-20 03:29:54 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-20 03:29:54 --> Helper loaded: url_helper
INFO - 2018-06-20 03:29:54 --> Helper loaded: form_helper
INFO - 2018-06-20 03:29:54 --> Helper loaded: date_helper
INFO - 2018-06-20 03:29:54 --> Helper loaded: util_helper
INFO - 2018-06-20 03:29:54 --> Helper loaded: text_helper
INFO - 2018-06-20 03:29:54 --> Helper loaded: string_helper
INFO - 2018-06-20 03:29:54 --> Database Driver Class Initialized
DEBUG - 2018-06-20 03:29:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 03:29:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 03:29:54 --> Email Class Initialized
INFO - 2018-06-20 03:29:54 --> Controller Class Initialized
DEBUG - 2018-06-20 03:29:54 --> Home MX_Controller Initialized
DEBUG - 2018-06-20 03:29:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-20 03:29:54 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-20 03:29:54 --> Login MX_Controller Initialized
INFO - 2018-06-20 03:29:54 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-20 03:29:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-20 03:29:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-20 03:29:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-20 03:29:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-20 03:29:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
INFO - 2018-06-20 03:30:11 --> Config Class Initialized
INFO - 2018-06-20 03:30:11 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:30:11 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:30:11 --> Utf8 Class Initialized
INFO - 2018-06-20 03:30:11 --> URI Class Initialized
INFO - 2018-06-20 03:30:11 --> Router Class Initialized
INFO - 2018-06-20 03:30:11 --> Output Class Initialized
INFO - 2018-06-20 03:30:11 --> Security Class Initialized
DEBUG - 2018-06-20 03:30:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:30:11 --> Input Class Initialized
INFO - 2018-06-20 03:30:11 --> Language Class Initialized
INFO - 2018-06-20 03:30:11 --> Language Class Initialized
INFO - 2018-06-20 03:30:11 --> Config Class Initialized
INFO - 2018-06-20 03:30:11 --> Loader Class Initialized
DEBUG - 2018-06-20 03:30:11 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-20 03:30:11 --> Helper loaded: url_helper
INFO - 2018-06-20 03:30:11 --> Helper loaded: form_helper
INFO - 2018-06-20 03:30:11 --> Helper loaded: date_helper
INFO - 2018-06-20 03:30:11 --> Helper loaded: util_helper
INFO - 2018-06-20 03:30:11 --> Helper loaded: text_helper
INFO - 2018-06-20 03:30:11 --> Helper loaded: string_helper
INFO - 2018-06-20 03:30:11 --> Database Driver Class Initialized
DEBUG - 2018-06-20 03:30:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 03:30:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 03:30:11 --> Email Class Initialized
INFO - 2018-06-20 03:30:11 --> Controller Class Initialized
DEBUG - 2018-06-20 03:30:11 --> Home MX_Controller Initialized
DEBUG - 2018-06-20 03:30:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-20 03:30:11 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-20 03:30:11 --> Login MX_Controller Initialized
INFO - 2018-06-20 03:30:11 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-20 03:30:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-20 03:30:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-20 03:30:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-20 03:30:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-20 03:30:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
INFO - 2018-06-20 03:30:22 --> Config Class Initialized
INFO - 2018-06-20 03:30:22 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:30:22 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:30:22 --> Utf8 Class Initialized
INFO - 2018-06-20 03:30:22 --> URI Class Initialized
INFO - 2018-06-20 03:30:22 --> Router Class Initialized
INFO - 2018-06-20 03:30:22 --> Output Class Initialized
INFO - 2018-06-20 03:30:22 --> Security Class Initialized
DEBUG - 2018-06-20 03:30:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:30:22 --> Input Class Initialized
INFO - 2018-06-20 03:30:22 --> Language Class Initialized
INFO - 2018-06-20 03:30:22 --> Language Class Initialized
INFO - 2018-06-20 03:30:22 --> Config Class Initialized
INFO - 2018-06-20 03:30:22 --> Loader Class Initialized
DEBUG - 2018-06-20 03:30:22 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-20 03:30:22 --> Helper loaded: url_helper
INFO - 2018-06-20 03:30:22 --> Helper loaded: form_helper
INFO - 2018-06-20 03:30:22 --> Helper loaded: date_helper
INFO - 2018-06-20 03:30:22 --> Helper loaded: util_helper
INFO - 2018-06-20 03:30:22 --> Helper loaded: text_helper
INFO - 2018-06-20 03:30:22 --> Helper loaded: string_helper
INFO - 2018-06-20 03:30:22 --> Database Driver Class Initialized
DEBUG - 2018-06-20 03:30:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 03:30:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 03:30:22 --> Email Class Initialized
INFO - 2018-06-20 03:30:22 --> Controller Class Initialized
DEBUG - 2018-06-20 03:30:22 --> Home MX_Controller Initialized
DEBUG - 2018-06-20 03:30:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-20 03:30:22 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-20 03:30:22 --> Login MX_Controller Initialized
INFO - 2018-06-20 03:30:22 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-20 03:30:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-20 03:30:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-20 03:30:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-20 03:30:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-20 03:30:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
INFO - 2018-06-20 03:31:11 --> Config Class Initialized
INFO - 2018-06-20 03:31:11 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:31:11 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:31:11 --> Utf8 Class Initialized
INFO - 2018-06-20 03:31:11 --> URI Class Initialized
INFO - 2018-06-20 03:31:11 --> Router Class Initialized
INFO - 2018-06-20 03:31:11 --> Output Class Initialized
INFO - 2018-06-20 03:31:11 --> Security Class Initialized
DEBUG - 2018-06-20 03:31:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:31:11 --> Input Class Initialized
INFO - 2018-06-20 03:31:11 --> Language Class Initialized
INFO - 2018-06-20 03:31:11 --> Language Class Initialized
INFO - 2018-06-20 03:31:11 --> Config Class Initialized
INFO - 2018-06-20 03:31:11 --> Loader Class Initialized
DEBUG - 2018-06-20 03:31:11 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-20 03:31:11 --> Helper loaded: url_helper
INFO - 2018-06-20 03:31:11 --> Helper loaded: form_helper
INFO - 2018-06-20 03:31:11 --> Helper loaded: date_helper
INFO - 2018-06-20 03:31:11 --> Helper loaded: util_helper
INFO - 2018-06-20 03:31:11 --> Helper loaded: text_helper
INFO - 2018-06-20 03:31:11 --> Helper loaded: string_helper
INFO - 2018-06-20 03:31:11 --> Database Driver Class Initialized
DEBUG - 2018-06-20 03:31:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 03:31:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 03:31:11 --> Email Class Initialized
INFO - 2018-06-20 03:31:11 --> Controller Class Initialized
DEBUG - 2018-06-20 03:31:11 --> Home MX_Controller Initialized
DEBUG - 2018-06-20 03:31:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-20 03:31:11 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-20 03:31:12 --> Login MX_Controller Initialized
INFO - 2018-06-20 03:31:12 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-20 03:31:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-20 03:31:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-20 03:31:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-20 03:31:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-20 03:31:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
ERROR - 2018-06-20 03:31:12 --> Severity: Notice --> Undefined variable: next_vid E:\xampp\htdocs\consulting\application\modules\home\views\course.php 201
INFO - 2018-06-20 03:31:32 --> Config Class Initialized
INFO - 2018-06-20 03:31:32 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:31:32 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:31:32 --> Utf8 Class Initialized
INFO - 2018-06-20 03:31:32 --> URI Class Initialized
INFO - 2018-06-20 03:31:33 --> Router Class Initialized
INFO - 2018-06-20 03:31:33 --> Output Class Initialized
INFO - 2018-06-20 03:31:33 --> Security Class Initialized
DEBUG - 2018-06-20 03:31:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:31:33 --> Input Class Initialized
INFO - 2018-06-20 03:31:33 --> Language Class Initialized
INFO - 2018-06-20 03:31:33 --> Language Class Initialized
INFO - 2018-06-20 03:31:33 --> Config Class Initialized
INFO - 2018-06-20 03:31:33 --> Loader Class Initialized
DEBUG - 2018-06-20 03:31:33 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-20 03:31:33 --> Helper loaded: url_helper
INFO - 2018-06-20 03:31:33 --> Helper loaded: form_helper
INFO - 2018-06-20 03:31:33 --> Helper loaded: date_helper
INFO - 2018-06-20 03:31:33 --> Helper loaded: util_helper
INFO - 2018-06-20 03:31:33 --> Helper loaded: text_helper
INFO - 2018-06-20 03:31:33 --> Helper loaded: string_helper
INFO - 2018-06-20 03:31:33 --> Database Driver Class Initialized
DEBUG - 2018-06-20 03:31:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 03:31:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 03:31:33 --> Email Class Initialized
INFO - 2018-06-20 03:31:33 --> Controller Class Initialized
DEBUG - 2018-06-20 03:31:33 --> Home MX_Controller Initialized
DEBUG - 2018-06-20 03:31:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-20 03:31:33 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-20 03:31:33 --> Login MX_Controller Initialized
INFO - 2018-06-20 03:31:33 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-20 03:31:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-20 03:31:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-20 03:31:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-20 03:31:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-20 03:31:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
INFO - 2018-06-20 03:31:47 --> Config Class Initialized
INFO - 2018-06-20 03:31:47 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:31:47 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:31:47 --> Utf8 Class Initialized
INFO - 2018-06-20 03:31:47 --> URI Class Initialized
INFO - 2018-06-20 03:31:47 --> Router Class Initialized
INFO - 2018-06-20 03:31:47 --> Output Class Initialized
INFO - 2018-06-20 03:31:47 --> Security Class Initialized
DEBUG - 2018-06-20 03:31:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:31:47 --> Input Class Initialized
INFO - 2018-06-20 03:31:47 --> Language Class Initialized
INFO - 2018-06-20 03:31:47 --> Language Class Initialized
INFO - 2018-06-20 03:31:47 --> Config Class Initialized
INFO - 2018-06-20 03:31:47 --> Loader Class Initialized
DEBUG - 2018-06-20 03:31:47 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-20 03:31:47 --> Helper loaded: url_helper
INFO - 2018-06-20 03:31:47 --> Helper loaded: form_helper
INFO - 2018-06-20 03:31:47 --> Helper loaded: date_helper
INFO - 2018-06-20 03:31:47 --> Helper loaded: util_helper
INFO - 2018-06-20 03:31:47 --> Helper loaded: text_helper
INFO - 2018-06-20 03:31:47 --> Helper loaded: string_helper
INFO - 2018-06-20 03:31:47 --> Database Driver Class Initialized
DEBUG - 2018-06-20 03:31:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 03:31:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 03:31:47 --> Email Class Initialized
INFO - 2018-06-20 03:31:47 --> Controller Class Initialized
DEBUG - 2018-06-20 03:31:47 --> Home MX_Controller Initialized
DEBUG - 2018-06-20 03:31:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-20 03:31:47 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-20 03:31:47 --> Login MX_Controller Initialized
INFO - 2018-06-20 03:31:47 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-20 03:31:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-20 03:31:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-20 03:31:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-20 03:31:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-20 03:31:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
ERROR - 2018-06-20 03:31:48 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable E:\xampp\htdocs\consulting\application\modules\home\views\course.php 205
ERROR - 2018-06-20 03:31:48 --> Severity: Warning --> Illegal string offset 'video_id' E:\xampp\htdocs\consulting\application\modules\home\views\course.php 205
ERROR - 2018-06-20 03:31:48 --> Severity: Notice --> Uninitialized string offset: 0 E:\xampp\htdocs\consulting\application\modules\home\views\course.php 205
DEBUG - 2018-06-20 03:31:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-20 03:31:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-20 03:31:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-06-20 03:31:48 --> Final output sent to browser
DEBUG - 2018-06-20 03:31:48 --> Total execution time: 0.7193
INFO - 2018-06-20 03:31:49 --> Config Class Initialized
INFO - 2018-06-20 03:31:49 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:31:49 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:31:49 --> Utf8 Class Initialized
INFO - 2018-06-20 03:31:49 --> URI Class Initialized
INFO - 2018-06-20 03:31:49 --> Router Class Initialized
INFO - 2018-06-20 03:31:49 --> Output Class Initialized
INFO - 2018-06-20 03:31:49 --> Security Class Initialized
DEBUG - 2018-06-20 03:31:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:31:49 --> Input Class Initialized
INFO - 2018-06-20 03:31:49 --> Language Class Initialized
INFO - 2018-06-20 03:31:49 --> Language Class Initialized
INFO - 2018-06-20 03:31:49 --> Config Class Initialized
INFO - 2018-06-20 03:31:49 --> Loader Class Initialized
DEBUG - 2018-06-20 03:31:49 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-20 03:31:49 --> Helper loaded: url_helper
INFO - 2018-06-20 03:31:49 --> Helper loaded: form_helper
INFO - 2018-06-20 03:31:49 --> Helper loaded: date_helper
INFO - 2018-06-20 03:31:49 --> Helper loaded: util_helper
INFO - 2018-06-20 03:31:49 --> Helper loaded: text_helper
INFO - 2018-06-20 03:31:49 --> Helper loaded: string_helper
INFO - 2018-06-20 03:31:49 --> Database Driver Class Initialized
DEBUG - 2018-06-20 03:31:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 03:31:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 03:31:49 --> Email Class Initialized
INFO - 2018-06-20 03:31:49 --> Controller Class Initialized
DEBUG - 2018-06-20 03:31:49 --> Home MX_Controller Initialized
DEBUG - 2018-06-20 03:31:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-20 03:31:49 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-20 03:31:49 --> Login MX_Controller Initialized
INFO - 2018-06-20 03:31:49 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-20 03:31:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-20 03:31:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-20 03:31:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-20 03:31:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-20 03:31:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
ERROR - 2018-06-20 03:31:49 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable E:\xampp\htdocs\consulting\application\modules\home\views\course.php 205
ERROR - 2018-06-20 03:31:49 --> Severity: Warning --> Illegal string offset 'video_id' E:\xampp\htdocs\consulting\application\modules\home\views\course.php 205
ERROR - 2018-06-20 03:31:49 --> Severity: Notice --> Uninitialized string offset: 0 E:\xampp\htdocs\consulting\application\modules\home\views\course.php 205
DEBUG - 2018-06-20 03:31:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-20 03:31:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-20 03:31:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-06-20 03:31:50 --> Final output sent to browser
DEBUG - 2018-06-20 03:31:50 --> Total execution time: 0.6434
INFO - 2018-06-20 03:31:50 --> Config Class Initialized
INFO - 2018-06-20 03:31:50 --> Hooks Class Initialized
INFO - 2018-06-20 03:31:50 --> Config Class Initialized
DEBUG - 2018-06-20 03:31:50 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:31:50 --> Utf8 Class Initialized
INFO - 2018-06-20 03:31:50 --> Hooks Class Initialized
INFO - 2018-06-20 03:31:50 --> URI Class Initialized
DEBUG - 2018-06-20 03:31:50 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:31:50 --> Utf8 Class Initialized
INFO - 2018-06-20 03:31:50 --> URI Class Initialized
INFO - 2018-06-20 03:31:50 --> Router Class Initialized
INFO - 2018-06-20 03:31:50 --> Output Class Initialized
INFO - 2018-06-20 03:31:50 --> Security Class Initialized
DEBUG - 2018-06-20 03:31:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:31:50 --> Input Class Initialized
INFO - 2018-06-20 03:31:50 --> Router Class Initialized
INFO - 2018-06-20 03:31:50 --> Language Class Initialized
ERROR - 2018-06-20 03:31:50 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:31:50 --> Output Class Initialized
INFO - 2018-06-20 03:31:50 --> Security Class Initialized
INFO - 2018-06-20 03:31:50 --> Config Class Initialized
DEBUG - 2018-06-20 03:31:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:31:50 --> Hooks Class Initialized
INFO - 2018-06-20 03:31:51 --> Input Class Initialized
DEBUG - 2018-06-20 03:31:51 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:31:51 --> Language Class Initialized
ERROR - 2018-06-20 03:31:51 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:31:51 --> Utf8 Class Initialized
INFO - 2018-06-20 03:31:51 --> URI Class Initialized
INFO - 2018-06-20 03:31:51 --> Router Class Initialized
INFO - 2018-06-20 03:31:51 --> Output Class Initialized
INFO - 2018-06-20 03:31:51 --> Security Class Initialized
DEBUG - 2018-06-20 03:31:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:31:51 --> Input Class Initialized
INFO - 2018-06-20 03:31:51 --> Language Class Initialized
ERROR - 2018-06-20 03:31:51 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:31:51 --> Config Class Initialized
INFO - 2018-06-20 03:31:51 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:31:51 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:31:51 --> Utf8 Class Initialized
INFO - 2018-06-20 03:31:51 --> URI Class Initialized
INFO - 2018-06-20 03:31:51 --> Router Class Initialized
INFO - 2018-06-20 03:31:51 --> Output Class Initialized
INFO - 2018-06-20 03:31:51 --> Security Class Initialized
DEBUG - 2018-06-20 03:31:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:31:51 --> Input Class Initialized
INFO - 2018-06-20 03:31:51 --> Language Class Initialized
ERROR - 2018-06-20 03:31:51 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:31:51 --> Config Class Initialized
INFO - 2018-06-20 03:31:51 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:31:51 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:31:51 --> Utf8 Class Initialized
INFO - 2018-06-20 03:31:51 --> URI Class Initialized
INFO - 2018-06-20 03:31:51 --> Router Class Initialized
INFO - 2018-06-20 03:31:51 --> Output Class Initialized
INFO - 2018-06-20 03:31:51 --> Security Class Initialized
DEBUG - 2018-06-20 03:31:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:31:51 --> Input Class Initialized
INFO - 2018-06-20 03:31:51 --> Language Class Initialized
ERROR - 2018-06-20 03:31:51 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:31:51 --> Config Class Initialized
INFO - 2018-06-20 03:31:51 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:31:51 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:31:51 --> Utf8 Class Initialized
INFO - 2018-06-20 03:31:51 --> URI Class Initialized
INFO - 2018-06-20 03:31:51 --> Router Class Initialized
INFO - 2018-06-20 03:31:51 --> Output Class Initialized
INFO - 2018-06-20 03:31:51 --> Security Class Initialized
DEBUG - 2018-06-20 03:31:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:31:51 --> Input Class Initialized
INFO - 2018-06-20 03:31:51 --> Language Class Initialized
ERROR - 2018-06-20 03:31:51 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:31:51 --> Config Class Initialized
INFO - 2018-06-20 03:31:51 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:31:51 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:31:51 --> Utf8 Class Initialized
INFO - 2018-06-20 03:31:51 --> URI Class Initialized
INFO - 2018-06-20 03:31:51 --> Router Class Initialized
INFO - 2018-06-20 03:31:52 --> Output Class Initialized
INFO - 2018-06-20 03:31:52 --> Security Class Initialized
DEBUG - 2018-06-20 03:31:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:31:52 --> Input Class Initialized
INFO - 2018-06-20 03:31:52 --> Language Class Initialized
ERROR - 2018-06-20 03:31:52 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:31:58 --> Config Class Initialized
INFO - 2018-06-20 03:31:58 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:31:58 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:31:58 --> Utf8 Class Initialized
INFO - 2018-06-20 03:31:59 --> URI Class Initialized
INFO - 2018-06-20 03:31:59 --> Router Class Initialized
INFO - 2018-06-20 03:31:59 --> Output Class Initialized
INFO - 2018-06-20 03:31:59 --> Security Class Initialized
DEBUG - 2018-06-20 03:31:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:31:59 --> Input Class Initialized
INFO - 2018-06-20 03:31:59 --> Language Class Initialized
INFO - 2018-06-20 03:31:59 --> Language Class Initialized
INFO - 2018-06-20 03:31:59 --> Config Class Initialized
INFO - 2018-06-20 03:31:59 --> Loader Class Initialized
DEBUG - 2018-06-20 03:31:59 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-20 03:31:59 --> Helper loaded: url_helper
INFO - 2018-06-20 03:31:59 --> Helper loaded: form_helper
INFO - 2018-06-20 03:31:59 --> Helper loaded: date_helper
INFO - 2018-06-20 03:31:59 --> Helper loaded: util_helper
INFO - 2018-06-20 03:31:59 --> Helper loaded: text_helper
INFO - 2018-06-20 03:31:59 --> Helper loaded: string_helper
INFO - 2018-06-20 03:31:59 --> Database Driver Class Initialized
DEBUG - 2018-06-20 03:31:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 03:31:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 03:31:59 --> Email Class Initialized
INFO - 2018-06-20 03:31:59 --> Controller Class Initialized
DEBUG - 2018-06-20 03:31:59 --> Home MX_Controller Initialized
DEBUG - 2018-06-20 03:31:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-20 03:31:59 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-20 03:31:59 --> Login MX_Controller Initialized
INFO - 2018-06-20 03:31:59 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-20 03:31:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-20 03:31:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-20 03:31:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-20 03:31:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-20 03:31:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
ERROR - 2018-06-20 03:31:59 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable E:\xampp\htdocs\consulting\application\modules\home\views\course.php 205
ERROR - 2018-06-20 03:31:59 --> Severity: Warning --> Illegal string offset 'video_id' E:\xampp\htdocs\consulting\application\modules\home\views\course.php 205
ERROR - 2018-06-20 03:31:59 --> Severity: Notice --> Uninitialized string offset: 0 E:\xampp\htdocs\consulting\application\modules\home\views\course.php 205
DEBUG - 2018-06-20 03:31:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-20 03:31:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-20 03:31:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-06-20 03:31:59 --> Final output sent to browser
DEBUG - 2018-06-20 03:31:59 --> Total execution time: 0.7539
INFO - 2018-06-20 03:32:56 --> Config Class Initialized
INFO - 2018-06-20 03:32:56 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:32:56 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:32:56 --> Utf8 Class Initialized
INFO - 2018-06-20 03:32:56 --> URI Class Initialized
INFO - 2018-06-20 03:32:56 --> Router Class Initialized
INFO - 2018-06-20 03:32:56 --> Output Class Initialized
INFO - 2018-06-20 03:32:56 --> Security Class Initialized
DEBUG - 2018-06-20 03:32:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:32:56 --> Input Class Initialized
INFO - 2018-06-20 03:32:56 --> Language Class Initialized
INFO - 2018-06-20 03:32:56 --> Language Class Initialized
INFO - 2018-06-20 03:32:56 --> Config Class Initialized
INFO - 2018-06-20 03:32:56 --> Loader Class Initialized
DEBUG - 2018-06-20 03:32:56 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-20 03:32:56 --> Helper loaded: url_helper
INFO - 2018-06-20 03:32:56 --> Helper loaded: form_helper
INFO - 2018-06-20 03:32:56 --> Helper loaded: date_helper
INFO - 2018-06-20 03:32:56 --> Helper loaded: util_helper
INFO - 2018-06-20 03:32:56 --> Helper loaded: text_helper
INFO - 2018-06-20 03:32:56 --> Helper loaded: string_helper
INFO - 2018-06-20 03:32:56 --> Database Driver Class Initialized
DEBUG - 2018-06-20 03:32:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 03:32:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 03:32:56 --> Email Class Initialized
INFO - 2018-06-20 03:32:56 --> Controller Class Initialized
DEBUG - 2018-06-20 03:32:56 --> Home MX_Controller Initialized
DEBUG - 2018-06-20 03:32:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-20 03:32:56 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-20 03:32:56 --> Login MX_Controller Initialized
INFO - 2018-06-20 03:32:56 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-20 03:32:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-20 03:32:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-20 03:32:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-20 03:32:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-20 03:32:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-20 03:32:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-20 03:32:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-20 03:32:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-06-20 03:32:56 --> Final output sent to browser
DEBUG - 2018-06-20 03:32:56 --> Total execution time: 0.6919
INFO - 2018-06-20 03:32:58 --> Config Class Initialized
INFO - 2018-06-20 03:32:58 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:32:58 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:32:58 --> Utf8 Class Initialized
INFO - 2018-06-20 03:32:58 --> URI Class Initialized
INFO - 2018-06-20 03:32:58 --> Router Class Initialized
INFO - 2018-06-20 03:32:58 --> Output Class Initialized
INFO - 2018-06-20 03:32:58 --> Security Class Initialized
DEBUG - 2018-06-20 03:32:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:32:58 --> Input Class Initialized
INFO - 2018-06-20 03:32:58 --> Language Class Initialized
INFO - 2018-06-20 03:32:58 --> Language Class Initialized
INFO - 2018-06-20 03:32:58 --> Config Class Initialized
INFO - 2018-06-20 03:32:58 --> Loader Class Initialized
DEBUG - 2018-06-20 03:32:58 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-20 03:32:58 --> Helper loaded: url_helper
INFO - 2018-06-20 03:32:58 --> Helper loaded: form_helper
INFO - 2018-06-20 03:32:58 --> Helper loaded: date_helper
INFO - 2018-06-20 03:32:58 --> Helper loaded: util_helper
INFO - 2018-06-20 03:32:58 --> Helper loaded: text_helper
INFO - 2018-06-20 03:32:58 --> Helper loaded: string_helper
INFO - 2018-06-20 03:32:58 --> Database Driver Class Initialized
DEBUG - 2018-06-20 03:32:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 03:32:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 03:32:58 --> Email Class Initialized
INFO - 2018-06-20 03:32:58 --> Controller Class Initialized
DEBUG - 2018-06-20 03:32:58 --> Home MX_Controller Initialized
DEBUG - 2018-06-20 03:32:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-20 03:32:58 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-20 03:32:58 --> Login MX_Controller Initialized
INFO - 2018-06-20 03:32:58 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-20 03:32:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-20 03:32:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-20 03:32:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-20 03:32:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-20 03:32:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-20 03:32:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-20 03:32:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-20 03:32:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-06-20 03:32:59 --> Final output sent to browser
DEBUG - 2018-06-20 03:32:59 --> Total execution time: 0.5984
INFO - 2018-06-20 03:32:59 --> Config Class Initialized
INFO - 2018-06-20 03:32:59 --> Config Class Initialized
INFO - 2018-06-20 03:32:59 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:32:59 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:32:59 --> Utf8 Class Initialized
INFO - 2018-06-20 03:32:59 --> Hooks Class Initialized
INFO - 2018-06-20 03:32:59 --> URI Class Initialized
DEBUG - 2018-06-20 03:32:59 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:32:59 --> Utf8 Class Initialized
INFO - 2018-06-20 03:32:59 --> URI Class Initialized
INFO - 2018-06-20 03:32:59 --> Router Class Initialized
INFO - 2018-06-20 03:32:59 --> Router Class Initialized
INFO - 2018-06-20 03:32:59 --> Output Class Initialized
INFO - 2018-06-20 03:32:59 --> Security Class Initialized
DEBUG - 2018-06-20 03:32:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:32:59 --> Input Class Initialized
INFO - 2018-06-20 03:32:59 --> Language Class Initialized
ERROR - 2018-06-20 03:32:59 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:32:59 --> Output Class Initialized
INFO - 2018-06-20 03:32:59 --> Config Class Initialized
INFO - 2018-06-20 03:32:59 --> Security Class Initialized
INFO - 2018-06-20 03:32:59 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:32:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-06-20 03:32:59 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:32:59 --> Input Class Initialized
INFO - 2018-06-20 03:32:59 --> Language Class Initialized
INFO - 2018-06-20 03:32:59 --> Utf8 Class Initialized
ERROR - 2018-06-20 03:32:59 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:32:59 --> URI Class Initialized
INFO - 2018-06-20 03:32:59 --> Router Class Initialized
INFO - 2018-06-20 03:32:59 --> Output Class Initialized
INFO - 2018-06-20 03:32:59 --> Security Class Initialized
DEBUG - 2018-06-20 03:32:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:33:00 --> Input Class Initialized
INFO - 2018-06-20 03:33:00 --> Language Class Initialized
ERROR - 2018-06-20 03:33:00 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:33:00 --> Config Class Initialized
INFO - 2018-06-20 03:33:00 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:33:00 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:33:00 --> Utf8 Class Initialized
INFO - 2018-06-20 03:33:00 --> URI Class Initialized
INFO - 2018-06-20 03:33:00 --> Router Class Initialized
INFO - 2018-06-20 03:33:00 --> Output Class Initialized
INFO - 2018-06-20 03:33:00 --> Security Class Initialized
DEBUG - 2018-06-20 03:33:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:33:00 --> Input Class Initialized
INFO - 2018-06-20 03:33:00 --> Language Class Initialized
ERROR - 2018-06-20 03:33:00 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:33:00 --> Config Class Initialized
INFO - 2018-06-20 03:33:00 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:33:00 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:33:00 --> Utf8 Class Initialized
INFO - 2018-06-20 03:33:00 --> URI Class Initialized
INFO - 2018-06-20 03:33:00 --> Router Class Initialized
INFO - 2018-06-20 03:33:00 --> Output Class Initialized
INFO - 2018-06-20 03:33:00 --> Security Class Initialized
DEBUG - 2018-06-20 03:33:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:33:00 --> Input Class Initialized
INFO - 2018-06-20 03:33:00 --> Language Class Initialized
ERROR - 2018-06-20 03:33:00 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:33:00 --> Config Class Initialized
INFO - 2018-06-20 03:33:00 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:33:00 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:33:00 --> Utf8 Class Initialized
INFO - 2018-06-20 03:33:00 --> URI Class Initialized
INFO - 2018-06-20 03:33:00 --> Router Class Initialized
INFO - 2018-06-20 03:33:00 --> Output Class Initialized
INFO - 2018-06-20 03:33:00 --> Security Class Initialized
DEBUG - 2018-06-20 03:33:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:33:00 --> Input Class Initialized
INFO - 2018-06-20 03:33:00 --> Language Class Initialized
ERROR - 2018-06-20 03:33:00 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:33:00 --> Config Class Initialized
INFO - 2018-06-20 03:33:00 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:33:00 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:33:00 --> Utf8 Class Initialized
INFO - 2018-06-20 03:33:00 --> URI Class Initialized
INFO - 2018-06-20 03:33:00 --> Router Class Initialized
INFO - 2018-06-20 03:33:00 --> Output Class Initialized
INFO - 2018-06-20 03:33:00 --> Security Class Initialized
DEBUG - 2018-06-20 03:33:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:33:00 --> Input Class Initialized
INFO - 2018-06-20 03:33:00 --> Language Class Initialized
ERROR - 2018-06-20 03:33:00 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:33:05 --> Config Class Initialized
INFO - 2018-06-20 03:33:05 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:33:05 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:33:05 --> Utf8 Class Initialized
INFO - 2018-06-20 03:33:05 --> URI Class Initialized
INFO - 2018-06-20 03:33:05 --> Router Class Initialized
INFO - 2018-06-20 03:33:05 --> Output Class Initialized
INFO - 2018-06-20 03:33:05 --> Security Class Initialized
DEBUG - 2018-06-20 03:33:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:33:05 --> Input Class Initialized
INFO - 2018-06-20 03:33:05 --> Language Class Initialized
INFO - 2018-06-20 03:33:05 --> Language Class Initialized
INFO - 2018-06-20 03:33:05 --> Config Class Initialized
INFO - 2018-06-20 03:33:05 --> Loader Class Initialized
DEBUG - 2018-06-20 03:33:05 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-20 03:33:05 --> Helper loaded: url_helper
INFO - 2018-06-20 03:33:05 --> Helper loaded: form_helper
INFO - 2018-06-20 03:33:05 --> Helper loaded: date_helper
INFO - 2018-06-20 03:33:05 --> Helper loaded: util_helper
INFO - 2018-06-20 03:33:05 --> Helper loaded: text_helper
INFO - 2018-06-20 03:33:05 --> Helper loaded: string_helper
INFO - 2018-06-20 03:33:05 --> Database Driver Class Initialized
DEBUG - 2018-06-20 03:33:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 03:33:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 03:33:05 --> Email Class Initialized
INFO - 2018-06-20 03:33:05 --> Controller Class Initialized
DEBUG - 2018-06-20 03:33:05 --> Home MX_Controller Initialized
DEBUG - 2018-06-20 03:33:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-20 03:33:05 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-20 03:33:05 --> Login MX_Controller Initialized
INFO - 2018-06-20 03:33:05 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-20 03:33:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-20 03:33:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-20 03:33:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-20 03:33:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-20 03:33:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-20 03:33:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-20 03:33:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-20 03:33:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-06-20 03:33:05 --> Final output sent to browser
DEBUG - 2018-06-20 03:33:06 --> Total execution time: 0.5958
INFO - 2018-06-20 03:33:06 --> Config Class Initialized
INFO - 2018-06-20 03:33:06 --> Config Class Initialized
INFO - 2018-06-20 03:33:06 --> Hooks Class Initialized
INFO - 2018-06-20 03:33:06 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:33:06 --> UTF-8 Support Enabled
DEBUG - 2018-06-20 03:33:06 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:33:06 --> Utf8 Class Initialized
INFO - 2018-06-20 03:33:06 --> Utf8 Class Initialized
INFO - 2018-06-20 03:33:06 --> URI Class Initialized
INFO - 2018-06-20 03:33:06 --> URI Class Initialized
INFO - 2018-06-20 03:33:06 --> Router Class Initialized
INFO - 2018-06-20 03:33:06 --> Router Class Initialized
INFO - 2018-06-20 03:33:06 --> Output Class Initialized
INFO - 2018-06-20 03:33:06 --> Output Class Initialized
INFO - 2018-06-20 03:33:06 --> Security Class Initialized
INFO - 2018-06-20 03:33:06 --> Security Class Initialized
DEBUG - 2018-06-20 03:33:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-06-20 03:33:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:33:06 --> Input Class Initialized
INFO - 2018-06-20 03:33:06 --> Input Class Initialized
INFO - 2018-06-20 03:33:06 --> Language Class Initialized
ERROR - 2018-06-20 03:33:06 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:33:06 --> Language Class Initialized
INFO - 2018-06-20 03:33:06 --> Config Class Initialized
INFO - 2018-06-20 03:33:06 --> Hooks Class Initialized
ERROR - 2018-06-20 03:33:06 --> 404 Page Not Found: /index
DEBUG - 2018-06-20 03:33:06 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:33:06 --> Utf8 Class Initialized
INFO - 2018-06-20 03:33:06 --> URI Class Initialized
INFO - 2018-06-20 03:33:06 --> Router Class Initialized
INFO - 2018-06-20 03:33:06 --> Output Class Initialized
INFO - 2018-06-20 03:33:06 --> Security Class Initialized
DEBUG - 2018-06-20 03:33:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:33:06 --> Input Class Initialized
INFO - 2018-06-20 03:33:06 --> Language Class Initialized
ERROR - 2018-06-20 03:33:06 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:33:06 --> Config Class Initialized
INFO - 2018-06-20 03:33:06 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:33:06 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:33:06 --> Utf8 Class Initialized
INFO - 2018-06-20 03:33:06 --> URI Class Initialized
INFO - 2018-06-20 03:33:07 --> Router Class Initialized
INFO - 2018-06-20 03:33:07 --> Output Class Initialized
INFO - 2018-06-20 03:33:07 --> Security Class Initialized
DEBUG - 2018-06-20 03:33:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:33:07 --> Input Class Initialized
INFO - 2018-06-20 03:33:07 --> Language Class Initialized
ERROR - 2018-06-20 03:33:07 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:33:08 --> Config Class Initialized
INFO - 2018-06-20 03:33:08 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:33:08 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:33:08 --> Utf8 Class Initialized
INFO - 2018-06-20 03:33:08 --> URI Class Initialized
INFO - 2018-06-20 03:33:08 --> Router Class Initialized
INFO - 2018-06-20 03:33:08 --> Output Class Initialized
INFO - 2018-06-20 03:33:08 --> Security Class Initialized
DEBUG - 2018-06-20 03:33:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:33:08 --> Input Class Initialized
INFO - 2018-06-20 03:33:08 --> Language Class Initialized
INFO - 2018-06-20 03:33:08 --> Language Class Initialized
INFO - 2018-06-20 03:33:08 --> Config Class Initialized
INFO - 2018-06-20 03:33:08 --> Loader Class Initialized
DEBUG - 2018-06-20 03:33:08 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-20 03:33:08 --> Helper loaded: url_helper
INFO - 2018-06-20 03:33:08 --> Helper loaded: form_helper
INFO - 2018-06-20 03:33:08 --> Helper loaded: date_helper
INFO - 2018-06-20 03:33:08 --> Helper loaded: util_helper
INFO - 2018-06-20 03:33:08 --> Helper loaded: text_helper
INFO - 2018-06-20 03:33:08 --> Helper loaded: string_helper
INFO - 2018-06-20 03:33:08 --> Database Driver Class Initialized
DEBUG - 2018-06-20 03:33:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 03:33:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 03:33:08 --> Email Class Initialized
INFO - 2018-06-20 03:33:08 --> Controller Class Initialized
DEBUG - 2018-06-20 03:33:08 --> Home MX_Controller Initialized
DEBUG - 2018-06-20 03:33:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-20 03:33:08 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-20 03:33:08 --> Login MX_Controller Initialized
INFO - 2018-06-20 03:33:08 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-20 03:33:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-20 03:33:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-20 03:33:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-20 03:33:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-20 03:33:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-20 03:33:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-20 03:33:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-20 03:33:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-06-20 03:33:09 --> Final output sent to browser
DEBUG - 2018-06-20 03:33:09 --> Total execution time: 0.6203
INFO - 2018-06-20 03:33:09 --> Config Class Initialized
INFO - 2018-06-20 03:33:09 --> Config Class Initialized
INFO - 2018-06-20 03:33:09 --> Hooks Class Initialized
INFO - 2018-06-20 03:33:09 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:33:09 --> UTF-8 Support Enabled
DEBUG - 2018-06-20 03:33:09 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:33:09 --> Utf8 Class Initialized
INFO - 2018-06-20 03:33:09 --> URI Class Initialized
INFO - 2018-06-20 03:33:09 --> Utf8 Class Initialized
INFO - 2018-06-20 03:33:09 --> Router Class Initialized
INFO - 2018-06-20 03:33:09 --> URI Class Initialized
INFO - 2018-06-20 03:33:09 --> Router Class Initialized
INFO - 2018-06-20 03:33:09 --> Output Class Initialized
INFO - 2018-06-20 03:33:09 --> Output Class Initialized
INFO - 2018-06-20 03:33:09 --> Security Class Initialized
DEBUG - 2018-06-20 03:33:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:33:09 --> Input Class Initialized
INFO - 2018-06-20 03:33:09 --> Language Class Initialized
INFO - 2018-06-20 03:33:09 --> Security Class Initialized
ERROR - 2018-06-20 03:33:09 --> 404 Page Not Found: /index
DEBUG - 2018-06-20 03:33:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:33:09 --> Input Class Initialized
INFO - 2018-06-20 03:33:09 --> Language Class Initialized
ERROR - 2018-06-20 03:33:09 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:33:09 --> Config Class Initialized
INFO - 2018-06-20 03:33:09 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:33:09 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:33:09 --> Utf8 Class Initialized
INFO - 2018-06-20 03:33:09 --> URI Class Initialized
INFO - 2018-06-20 03:33:09 --> Router Class Initialized
INFO - 2018-06-20 03:33:09 --> Output Class Initialized
INFO - 2018-06-20 03:33:09 --> Security Class Initialized
DEBUG - 2018-06-20 03:33:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:33:09 --> Input Class Initialized
INFO - 2018-06-20 03:33:09 --> Language Class Initialized
ERROR - 2018-06-20 03:33:10 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:33:10 --> Config Class Initialized
INFO - 2018-06-20 03:33:10 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:33:10 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:33:10 --> Utf8 Class Initialized
INFO - 2018-06-20 03:33:10 --> URI Class Initialized
INFO - 2018-06-20 03:33:10 --> Router Class Initialized
INFO - 2018-06-20 03:33:10 --> Output Class Initialized
INFO - 2018-06-20 03:33:10 --> Security Class Initialized
DEBUG - 2018-06-20 03:33:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:33:10 --> Input Class Initialized
INFO - 2018-06-20 03:33:10 --> Language Class Initialized
ERROR - 2018-06-20 03:33:10 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:33:11 --> Config Class Initialized
INFO - 2018-06-20 03:33:11 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:33:11 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:33:11 --> Utf8 Class Initialized
INFO - 2018-06-20 03:33:11 --> URI Class Initialized
INFO - 2018-06-20 03:33:11 --> Router Class Initialized
INFO - 2018-06-20 03:33:11 --> Output Class Initialized
INFO - 2018-06-20 03:33:11 --> Security Class Initialized
DEBUG - 2018-06-20 03:33:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:33:11 --> Input Class Initialized
INFO - 2018-06-20 03:33:11 --> Language Class Initialized
INFO - 2018-06-20 03:33:11 --> Language Class Initialized
INFO - 2018-06-20 03:33:11 --> Config Class Initialized
INFO - 2018-06-20 03:33:11 --> Loader Class Initialized
DEBUG - 2018-06-20 03:33:11 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-20 03:33:11 --> Helper loaded: url_helper
INFO - 2018-06-20 03:33:11 --> Helper loaded: form_helper
INFO - 2018-06-20 03:33:11 --> Helper loaded: date_helper
INFO - 2018-06-20 03:33:11 --> Helper loaded: util_helper
INFO - 2018-06-20 03:33:11 --> Helper loaded: text_helper
INFO - 2018-06-20 03:33:11 --> Helper loaded: string_helper
INFO - 2018-06-20 03:33:11 --> Database Driver Class Initialized
DEBUG - 2018-06-20 03:33:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 03:33:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 03:33:12 --> Email Class Initialized
INFO - 2018-06-20 03:33:12 --> Controller Class Initialized
DEBUG - 2018-06-20 03:33:12 --> Home MX_Controller Initialized
DEBUG - 2018-06-20 03:33:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-20 03:33:12 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-20 03:33:12 --> Login MX_Controller Initialized
INFO - 2018-06-20 03:33:12 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-20 03:33:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-20 03:33:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-20 03:33:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-20 03:33:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-20 03:33:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-20 03:33:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-20 03:33:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-20 03:33:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-06-20 03:33:12 --> Final output sent to browser
DEBUG - 2018-06-20 03:33:12 --> Total execution time: 0.6346
INFO - 2018-06-20 03:33:12 --> Config Class Initialized
INFO - 2018-06-20 03:33:12 --> Config Class Initialized
INFO - 2018-06-20 03:33:12 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:33:12 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:33:12 --> Utf8 Class Initialized
INFO - 2018-06-20 03:33:12 --> Hooks Class Initialized
INFO - 2018-06-20 03:33:12 --> URI Class Initialized
INFO - 2018-06-20 03:33:12 --> Router Class Initialized
DEBUG - 2018-06-20 03:33:12 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:33:12 --> Utf8 Class Initialized
INFO - 2018-06-20 03:33:12 --> Output Class Initialized
INFO - 2018-06-20 03:33:12 --> URI Class Initialized
INFO - 2018-06-20 03:33:12 --> Security Class Initialized
INFO - 2018-06-20 03:33:12 --> Router Class Initialized
INFO - 2018-06-20 03:33:12 --> Output Class Initialized
INFO - 2018-06-20 03:33:12 --> Security Class Initialized
DEBUG - 2018-06-20 03:33:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:33:12 --> Input Class Initialized
DEBUG - 2018-06-20 03:33:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:33:12 --> Language Class Initialized
ERROR - 2018-06-20 03:33:12 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:33:12 --> Input Class Initialized
INFO - 2018-06-20 03:33:12 --> Language Class Initialized
ERROR - 2018-06-20 03:33:12 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:33:12 --> Config Class Initialized
INFO - 2018-06-20 03:33:12 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:33:12 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:33:12 --> Utf8 Class Initialized
INFO - 2018-06-20 03:33:13 --> URI Class Initialized
INFO - 2018-06-20 03:33:13 --> Router Class Initialized
INFO - 2018-06-20 03:33:13 --> Output Class Initialized
INFO - 2018-06-20 03:33:13 --> Security Class Initialized
DEBUG - 2018-06-20 03:33:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:33:13 --> Input Class Initialized
INFO - 2018-06-20 03:33:13 --> Language Class Initialized
ERROR - 2018-06-20 03:33:13 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:33:13 --> Config Class Initialized
INFO - 2018-06-20 03:33:13 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:33:13 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:33:13 --> Utf8 Class Initialized
INFO - 2018-06-20 03:33:13 --> URI Class Initialized
INFO - 2018-06-20 03:33:13 --> Router Class Initialized
INFO - 2018-06-20 03:33:13 --> Output Class Initialized
INFO - 2018-06-20 03:33:13 --> Security Class Initialized
DEBUG - 2018-06-20 03:33:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:33:13 --> Input Class Initialized
INFO - 2018-06-20 03:33:13 --> Language Class Initialized
ERROR - 2018-06-20 03:33:13 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:33:14 --> Config Class Initialized
INFO - 2018-06-20 03:33:14 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:33:14 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:33:14 --> Utf8 Class Initialized
INFO - 2018-06-20 03:33:14 --> URI Class Initialized
INFO - 2018-06-20 03:33:14 --> Router Class Initialized
INFO - 2018-06-20 03:33:14 --> Output Class Initialized
INFO - 2018-06-20 03:33:14 --> Security Class Initialized
DEBUG - 2018-06-20 03:33:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:33:14 --> Input Class Initialized
INFO - 2018-06-20 03:33:14 --> Language Class Initialized
INFO - 2018-06-20 03:33:14 --> Language Class Initialized
INFO - 2018-06-20 03:33:14 --> Config Class Initialized
INFO - 2018-06-20 03:33:14 --> Loader Class Initialized
DEBUG - 2018-06-20 03:33:14 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-20 03:33:14 --> Helper loaded: url_helper
INFO - 2018-06-20 03:33:14 --> Helper loaded: form_helper
INFO - 2018-06-20 03:33:14 --> Helper loaded: date_helper
INFO - 2018-06-20 03:33:14 --> Helper loaded: util_helper
INFO - 2018-06-20 03:33:14 --> Helper loaded: text_helper
INFO - 2018-06-20 03:33:14 --> Helper loaded: string_helper
INFO - 2018-06-20 03:33:14 --> Database Driver Class Initialized
DEBUG - 2018-06-20 03:33:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 03:33:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 03:33:14 --> Email Class Initialized
INFO - 2018-06-20 03:33:14 --> Controller Class Initialized
DEBUG - 2018-06-20 03:33:14 --> Home MX_Controller Initialized
DEBUG - 2018-06-20 03:33:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-20 03:33:14 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-20 03:33:14 --> Login MX_Controller Initialized
INFO - 2018-06-20 03:33:14 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-20 03:33:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-20 03:33:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-20 03:33:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-20 03:33:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-20 03:33:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-20 03:33:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-20 03:33:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-20 03:33:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-06-20 03:33:14 --> Final output sent to browser
DEBUG - 2018-06-20 03:33:15 --> Total execution time: 0.6169
INFO - 2018-06-20 03:33:15 --> Config Class Initialized
INFO - 2018-06-20 03:33:15 --> Config Class Initialized
INFO - 2018-06-20 03:33:15 --> Hooks Class Initialized
INFO - 2018-06-20 03:33:15 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:33:15 --> UTF-8 Support Enabled
DEBUG - 2018-06-20 03:33:15 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:33:15 --> Utf8 Class Initialized
INFO - 2018-06-20 03:33:15 --> URI Class Initialized
INFO - 2018-06-20 03:33:15 --> Router Class Initialized
INFO - 2018-06-20 03:33:15 --> Utf8 Class Initialized
INFO - 2018-06-20 03:33:15 --> Output Class Initialized
INFO - 2018-06-20 03:33:15 --> URI Class Initialized
INFO - 2018-06-20 03:33:15 --> Router Class Initialized
INFO - 2018-06-20 03:33:15 --> Security Class Initialized
INFO - 2018-06-20 03:33:15 --> Output Class Initialized
INFO - 2018-06-20 03:33:15 --> Security Class Initialized
DEBUG - 2018-06-20 03:33:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-06-20 03:33:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:33:15 --> Input Class Initialized
INFO - 2018-06-20 03:33:15 --> Language Class Initialized
ERROR - 2018-06-20 03:33:15 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:33:15 --> Input Class Initialized
INFO - 2018-06-20 03:33:15 --> Language Class Initialized
ERROR - 2018-06-20 03:33:15 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:33:15 --> Config Class Initialized
INFO - 2018-06-20 03:33:15 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:33:15 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:33:15 --> Utf8 Class Initialized
INFO - 2018-06-20 03:33:15 --> URI Class Initialized
INFO - 2018-06-20 03:33:15 --> Router Class Initialized
INFO - 2018-06-20 03:33:15 --> Output Class Initialized
INFO - 2018-06-20 03:33:15 --> Security Class Initialized
DEBUG - 2018-06-20 03:33:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:33:15 --> Input Class Initialized
INFO - 2018-06-20 03:33:15 --> Language Class Initialized
ERROR - 2018-06-20 03:33:15 --> 404 Page Not Found: /index
INFO - 2018-06-20 03:33:15 --> Config Class Initialized
INFO - 2018-06-20 03:33:15 --> Hooks Class Initialized
DEBUG - 2018-06-20 03:33:15 --> UTF-8 Support Enabled
INFO - 2018-06-20 03:33:15 --> Utf8 Class Initialized
INFO - 2018-06-20 03:33:15 --> URI Class Initialized
INFO - 2018-06-20 03:33:15 --> Router Class Initialized
INFO - 2018-06-20 03:33:16 --> Output Class Initialized
INFO - 2018-06-20 03:33:16 --> Security Class Initialized
DEBUG - 2018-06-20 03:33:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 03:33:16 --> Input Class Initialized
INFO - 2018-06-20 03:33:16 --> Language Class Initialized
ERROR - 2018-06-20 03:33:16 --> 404 Page Not Found: /index
INFO - 2018-06-20 04:18:02 --> Config Class Initialized
INFO - 2018-06-20 04:18:02 --> Hooks Class Initialized
DEBUG - 2018-06-20 04:18:02 --> UTF-8 Support Enabled
INFO - 2018-06-20 04:18:02 --> Utf8 Class Initialized
INFO - 2018-06-20 04:18:02 --> URI Class Initialized
INFO - 2018-06-20 04:18:02 --> Router Class Initialized
INFO - 2018-06-20 04:18:02 --> Output Class Initialized
INFO - 2018-06-20 04:18:02 --> Security Class Initialized
DEBUG - 2018-06-20 04:18:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 04:18:02 --> Input Class Initialized
INFO - 2018-06-20 04:18:02 --> Language Class Initialized
INFO - 2018-06-20 04:18:02 --> Language Class Initialized
INFO - 2018-06-20 04:18:02 --> Config Class Initialized
INFO - 2018-06-20 04:18:02 --> Loader Class Initialized
DEBUG - 2018-06-20 04:18:02 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-20 04:18:02 --> Helper loaded: url_helper
INFO - 2018-06-20 04:18:02 --> Helper loaded: form_helper
INFO - 2018-06-20 04:18:02 --> Helper loaded: date_helper
INFO - 2018-06-20 04:18:02 --> Helper loaded: util_helper
INFO - 2018-06-20 04:18:02 --> Helper loaded: text_helper
INFO - 2018-06-20 04:18:02 --> Helper loaded: string_helper
INFO - 2018-06-20 04:18:02 --> Database Driver Class Initialized
DEBUG - 2018-06-20 04:18:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 04:18:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 04:18:02 --> Email Class Initialized
INFO - 2018-06-20 04:18:02 --> Controller Class Initialized
DEBUG - 2018-06-20 04:18:02 --> Home MX_Controller Initialized
DEBUG - 2018-06-20 04:18:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-20 04:18:02 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-20 04:18:02 --> Login MX_Controller Initialized
INFO - 2018-06-20 04:18:02 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-20 04:18:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-20 04:18:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-20 04:18:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-20 04:18:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-20 04:18:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-20 04:18:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-20 04:18:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-20 04:18:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-06-20 04:18:02 --> Final output sent to browser
DEBUG - 2018-06-20 04:18:02 --> Total execution time: 0.6811
INFO - 2018-06-20 04:18:03 --> Config Class Initialized
INFO - 2018-06-20 04:18:03 --> Config Class Initialized
INFO - 2018-06-20 04:18:03 --> Hooks Class Initialized
INFO - 2018-06-20 04:18:03 --> Hooks Class Initialized
DEBUG - 2018-06-20 04:18:03 --> UTF-8 Support Enabled
INFO - 2018-06-20 04:18:03 --> Utf8 Class Initialized
INFO - 2018-06-20 04:18:03 --> URI Class Initialized
INFO - 2018-06-20 04:18:03 --> Router Class Initialized
INFO - 2018-06-20 04:18:03 --> Output Class Initialized
INFO - 2018-06-20 04:18:03 --> Security Class Initialized
DEBUG - 2018-06-20 04:18:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 04:18:03 --> Input Class Initialized
INFO - 2018-06-20 04:18:03 --> Language Class Initialized
ERROR - 2018-06-20 04:18:03 --> 404 Page Not Found: /index
DEBUG - 2018-06-20 04:18:03 --> UTF-8 Support Enabled
INFO - 2018-06-20 04:18:03 --> Utf8 Class Initialized
INFO - 2018-06-20 04:18:03 --> URI Class Initialized
INFO - 2018-06-20 04:18:03 --> Router Class Initialized
INFO - 2018-06-20 04:18:03 --> Output Class Initialized
INFO - 2018-06-20 04:18:03 --> Security Class Initialized
DEBUG - 2018-06-20 04:18:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 04:18:03 --> Input Class Initialized
INFO - 2018-06-20 04:18:03 --> Language Class Initialized
ERROR - 2018-06-20 04:18:03 --> 404 Page Not Found: /index
INFO - 2018-06-20 04:18:03 --> Config Class Initialized
INFO - 2018-06-20 04:18:03 --> Hooks Class Initialized
DEBUG - 2018-06-20 04:18:03 --> UTF-8 Support Enabled
INFO - 2018-06-20 04:18:03 --> Utf8 Class Initialized
INFO - 2018-06-20 04:18:03 --> URI Class Initialized
INFO - 2018-06-20 04:18:03 --> Router Class Initialized
INFO - 2018-06-20 04:18:03 --> Output Class Initialized
INFO - 2018-06-20 04:18:03 --> Security Class Initialized
DEBUG - 2018-06-20 04:18:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 04:18:03 --> Input Class Initialized
INFO - 2018-06-20 04:18:03 --> Language Class Initialized
ERROR - 2018-06-20 04:18:03 --> 404 Page Not Found: /index
INFO - 2018-06-20 04:18:03 --> Config Class Initialized
INFO - 2018-06-20 04:18:03 --> Hooks Class Initialized
DEBUG - 2018-06-20 04:18:03 --> UTF-8 Support Enabled
INFO - 2018-06-20 04:18:04 --> Utf8 Class Initialized
INFO - 2018-06-20 04:18:04 --> URI Class Initialized
INFO - 2018-06-20 04:18:04 --> Router Class Initialized
INFO - 2018-06-20 04:18:04 --> Output Class Initialized
INFO - 2018-06-20 04:18:04 --> Security Class Initialized
DEBUG - 2018-06-20 04:18:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 04:18:04 --> Input Class Initialized
INFO - 2018-06-20 04:18:04 --> Language Class Initialized
ERROR - 2018-06-20 04:18:04 --> 404 Page Not Found: /index
INFO - 2018-06-20 04:18:04 --> Config Class Initialized
INFO - 2018-06-20 04:18:04 --> Hooks Class Initialized
DEBUG - 2018-06-20 04:18:04 --> UTF-8 Support Enabled
INFO - 2018-06-20 04:18:04 --> Utf8 Class Initialized
INFO - 2018-06-20 04:18:04 --> URI Class Initialized
INFO - 2018-06-20 04:18:04 --> Router Class Initialized
INFO - 2018-06-20 04:18:04 --> Output Class Initialized
INFO - 2018-06-20 04:18:04 --> Security Class Initialized
DEBUG - 2018-06-20 04:18:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 04:18:04 --> Input Class Initialized
INFO - 2018-06-20 04:18:04 --> Language Class Initialized
ERROR - 2018-06-20 04:18:04 --> 404 Page Not Found: /index
INFO - 2018-06-20 04:18:04 --> Config Class Initialized
INFO - 2018-06-20 04:18:04 --> Hooks Class Initialized
DEBUG - 2018-06-20 04:18:04 --> UTF-8 Support Enabled
INFO - 2018-06-20 04:18:04 --> Utf8 Class Initialized
INFO - 2018-06-20 04:18:04 --> URI Class Initialized
INFO - 2018-06-20 04:18:04 --> Router Class Initialized
INFO - 2018-06-20 04:18:04 --> Output Class Initialized
INFO - 2018-06-20 04:18:04 --> Security Class Initialized
DEBUG - 2018-06-20 04:18:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 04:18:04 --> Input Class Initialized
INFO - 2018-06-20 04:18:04 --> Language Class Initialized
ERROR - 2018-06-20 04:18:04 --> 404 Page Not Found: /index
INFO - 2018-06-20 04:18:04 --> Config Class Initialized
INFO - 2018-06-20 04:18:04 --> Hooks Class Initialized
DEBUG - 2018-06-20 04:18:04 --> UTF-8 Support Enabled
INFO - 2018-06-20 04:18:04 --> Utf8 Class Initialized
INFO - 2018-06-20 04:18:04 --> URI Class Initialized
INFO - 2018-06-20 04:18:04 --> Router Class Initialized
INFO - 2018-06-20 04:18:04 --> Output Class Initialized
INFO - 2018-06-20 04:18:04 --> Security Class Initialized
DEBUG - 2018-06-20 04:18:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 04:18:04 --> Input Class Initialized
INFO - 2018-06-20 04:18:04 --> Language Class Initialized
ERROR - 2018-06-20 04:18:04 --> 404 Page Not Found: /index
INFO - 2018-06-20 04:18:06 --> Config Class Initialized
INFO - 2018-06-20 04:18:06 --> Hooks Class Initialized
DEBUG - 2018-06-20 04:18:06 --> UTF-8 Support Enabled
INFO - 2018-06-20 04:18:06 --> Utf8 Class Initialized
INFO - 2018-06-20 04:18:06 --> URI Class Initialized
INFO - 2018-06-20 04:18:06 --> Router Class Initialized
INFO - 2018-06-20 04:18:06 --> Output Class Initialized
INFO - 2018-06-20 04:18:06 --> Security Class Initialized
DEBUG - 2018-06-20 04:18:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 04:18:06 --> Input Class Initialized
INFO - 2018-06-20 04:18:06 --> Language Class Initialized
INFO - 2018-06-20 04:18:06 --> Language Class Initialized
INFO - 2018-06-20 04:18:06 --> Config Class Initialized
INFO - 2018-06-20 04:18:06 --> Loader Class Initialized
DEBUG - 2018-06-20 04:18:06 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-20 04:18:06 --> Helper loaded: url_helper
INFO - 2018-06-20 04:18:06 --> Helper loaded: form_helper
INFO - 2018-06-20 04:18:06 --> Helper loaded: date_helper
INFO - 2018-06-20 04:18:06 --> Helper loaded: util_helper
INFO - 2018-06-20 04:18:06 --> Helper loaded: text_helper
INFO - 2018-06-20 04:18:06 --> Helper loaded: string_helper
INFO - 2018-06-20 04:18:06 --> Database Driver Class Initialized
DEBUG - 2018-06-20 04:18:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 04:18:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 04:18:06 --> Email Class Initialized
INFO - 2018-06-20 04:18:06 --> Controller Class Initialized
DEBUG - 2018-06-20 04:18:06 --> Home MX_Controller Initialized
DEBUG - 2018-06-20 04:18:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-20 04:18:06 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-20 04:18:06 --> Login MX_Controller Initialized
INFO - 2018-06-20 04:18:06 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-20 04:18:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-20 04:18:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-20 04:18:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-20 04:18:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-20 04:18:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-20 04:18:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-20 04:18:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-20 04:18:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-06-20 04:18:07 --> Final output sent to browser
DEBUG - 2018-06-20 04:18:07 --> Total execution time: 0.6280
INFO - 2018-06-20 04:18:07 --> Config Class Initialized
INFO - 2018-06-20 04:18:07 --> Config Class Initialized
INFO - 2018-06-20 04:18:07 --> Hooks Class Initialized
DEBUG - 2018-06-20 04:18:07 --> UTF-8 Support Enabled
INFO - 2018-06-20 04:18:07 --> Utf8 Class Initialized
INFO - 2018-06-20 04:18:07 --> URI Class Initialized
INFO - 2018-06-20 04:18:07 --> Router Class Initialized
INFO - 2018-06-20 04:18:07 --> Hooks Class Initialized
INFO - 2018-06-20 04:18:07 --> Output Class Initialized
DEBUG - 2018-06-20 04:18:07 --> UTF-8 Support Enabled
INFO - 2018-06-20 04:18:07 --> Utf8 Class Initialized
INFO - 2018-06-20 04:18:07 --> Security Class Initialized
INFO - 2018-06-20 04:18:07 --> URI Class Initialized
INFO - 2018-06-20 04:18:07 --> Router Class Initialized
DEBUG - 2018-06-20 04:18:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 04:18:07 --> Input Class Initialized
INFO - 2018-06-20 04:18:07 --> Output Class Initialized
INFO - 2018-06-20 04:18:07 --> Language Class Initialized
ERROR - 2018-06-20 04:18:07 --> 404 Page Not Found: /index
INFO - 2018-06-20 04:18:07 --> Security Class Initialized
DEBUG - 2018-06-20 04:18:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 04:18:07 --> Input Class Initialized
INFO - 2018-06-20 04:18:07 --> Language Class Initialized
ERROR - 2018-06-20 04:18:07 --> 404 Page Not Found: /index
INFO - 2018-06-20 04:18:07 --> Config Class Initialized
INFO - 2018-06-20 04:18:07 --> Hooks Class Initialized
DEBUG - 2018-06-20 04:18:07 --> UTF-8 Support Enabled
INFO - 2018-06-20 04:18:07 --> Utf8 Class Initialized
INFO - 2018-06-20 04:18:07 --> URI Class Initialized
INFO - 2018-06-20 04:18:07 --> Router Class Initialized
INFO - 2018-06-20 04:18:07 --> Output Class Initialized
INFO - 2018-06-20 04:18:08 --> Security Class Initialized
DEBUG - 2018-06-20 04:18:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 04:18:08 --> Input Class Initialized
INFO - 2018-06-20 04:18:08 --> Language Class Initialized
ERROR - 2018-06-20 04:18:08 --> 404 Page Not Found: /index
INFO - 2018-06-20 04:18:08 --> Config Class Initialized
INFO - 2018-06-20 04:18:08 --> Hooks Class Initialized
DEBUG - 2018-06-20 04:18:08 --> UTF-8 Support Enabled
INFO - 2018-06-20 04:18:08 --> Utf8 Class Initialized
INFO - 2018-06-20 04:18:08 --> URI Class Initialized
INFO - 2018-06-20 04:18:08 --> Router Class Initialized
INFO - 2018-06-20 04:18:08 --> Output Class Initialized
INFO - 2018-06-20 04:18:08 --> Security Class Initialized
DEBUG - 2018-06-20 04:18:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 04:18:08 --> Input Class Initialized
INFO - 2018-06-20 04:18:08 --> Language Class Initialized
ERROR - 2018-06-20 04:18:08 --> 404 Page Not Found: /index
INFO - 2018-06-20 04:18:11 --> Config Class Initialized
INFO - 2018-06-20 04:18:11 --> Hooks Class Initialized
DEBUG - 2018-06-20 04:18:11 --> UTF-8 Support Enabled
INFO - 2018-06-20 04:18:11 --> Utf8 Class Initialized
INFO - 2018-06-20 04:18:11 --> URI Class Initialized
INFO - 2018-06-20 04:18:11 --> Router Class Initialized
INFO - 2018-06-20 04:18:11 --> Output Class Initialized
INFO - 2018-06-20 04:18:11 --> Security Class Initialized
DEBUG - 2018-06-20 04:18:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 04:18:11 --> Input Class Initialized
INFO - 2018-06-20 04:18:11 --> Language Class Initialized
INFO - 2018-06-20 04:18:11 --> Language Class Initialized
INFO - 2018-06-20 04:18:11 --> Config Class Initialized
INFO - 2018-06-20 04:18:11 --> Loader Class Initialized
DEBUG - 2018-06-20 04:18:11 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-20 04:18:11 --> Helper loaded: url_helper
INFO - 2018-06-20 04:18:11 --> Helper loaded: form_helper
INFO - 2018-06-20 04:18:11 --> Helper loaded: date_helper
INFO - 2018-06-20 04:18:11 --> Helper loaded: util_helper
INFO - 2018-06-20 04:18:11 --> Helper loaded: text_helper
INFO - 2018-06-20 04:18:11 --> Helper loaded: string_helper
INFO - 2018-06-20 04:18:11 --> Database Driver Class Initialized
DEBUG - 2018-06-20 04:18:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 04:18:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 04:18:11 --> Email Class Initialized
INFO - 2018-06-20 04:18:11 --> Controller Class Initialized
DEBUG - 2018-06-20 04:18:11 --> Home MX_Controller Initialized
DEBUG - 2018-06-20 04:18:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-20 04:18:11 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-20 04:18:11 --> Login MX_Controller Initialized
INFO - 2018-06-20 04:18:11 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-20 04:18:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-20 04:18:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-20 04:18:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-20 04:18:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-20 04:18:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-20 04:18:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-20 04:18:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-20 04:18:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-06-20 04:18:11 --> Final output sent to browser
DEBUG - 2018-06-20 04:18:11 --> Total execution time: 0.6415
INFO - 2018-06-20 04:18:11 --> Config Class Initialized
INFO - 2018-06-20 04:18:11 --> Config Class Initialized
INFO - 2018-06-20 04:18:11 --> Hooks Class Initialized
INFO - 2018-06-20 04:18:11 --> Hooks Class Initialized
DEBUG - 2018-06-20 04:18:11 --> UTF-8 Support Enabled
INFO - 2018-06-20 04:18:12 --> Utf8 Class Initialized
INFO - 2018-06-20 04:18:12 --> URI Class Initialized
INFO - 2018-06-20 04:18:12 --> Router Class Initialized
DEBUG - 2018-06-20 04:18:12 --> UTF-8 Support Enabled
INFO - 2018-06-20 04:18:12 --> Output Class Initialized
INFO - 2018-06-20 04:18:12 --> Security Class Initialized
DEBUG - 2018-06-20 04:18:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 04:18:12 --> Input Class Initialized
INFO - 2018-06-20 04:18:12 --> Language Class Initialized
ERROR - 2018-06-20 04:18:12 --> 404 Page Not Found: /index
INFO - 2018-06-20 04:18:12 --> Utf8 Class Initialized
INFO - 2018-06-20 04:18:12 --> URI Class Initialized
INFO - 2018-06-20 04:18:12 --> Router Class Initialized
INFO - 2018-06-20 04:18:12 --> Output Class Initialized
INFO - 2018-06-20 04:18:12 --> Security Class Initialized
DEBUG - 2018-06-20 04:18:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 04:18:12 --> Input Class Initialized
INFO - 2018-06-20 04:18:12 --> Language Class Initialized
ERROR - 2018-06-20 04:18:12 --> 404 Page Not Found: /index
INFO - 2018-06-20 04:18:12 --> Config Class Initialized
INFO - 2018-06-20 04:18:12 --> Hooks Class Initialized
DEBUG - 2018-06-20 04:18:12 --> UTF-8 Support Enabled
INFO - 2018-06-20 04:18:12 --> Utf8 Class Initialized
INFO - 2018-06-20 04:18:12 --> URI Class Initialized
INFO - 2018-06-20 04:18:12 --> Router Class Initialized
INFO - 2018-06-20 04:18:12 --> Output Class Initialized
INFO - 2018-06-20 04:18:12 --> Security Class Initialized
DEBUG - 2018-06-20 04:18:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 04:18:12 --> Input Class Initialized
INFO - 2018-06-20 04:18:12 --> Language Class Initialized
ERROR - 2018-06-20 04:18:12 --> 404 Page Not Found: /index
INFO - 2018-06-20 04:18:12 --> Config Class Initialized
INFO - 2018-06-20 04:18:12 --> Hooks Class Initialized
DEBUG - 2018-06-20 04:18:12 --> UTF-8 Support Enabled
INFO - 2018-06-20 04:18:12 --> Utf8 Class Initialized
INFO - 2018-06-20 04:18:12 --> URI Class Initialized
INFO - 2018-06-20 04:18:12 --> Router Class Initialized
INFO - 2018-06-20 04:18:12 --> Output Class Initialized
INFO - 2018-06-20 04:18:12 --> Security Class Initialized
DEBUG - 2018-06-20 04:18:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 04:18:12 --> Input Class Initialized
INFO - 2018-06-20 04:18:13 --> Language Class Initialized
ERROR - 2018-06-20 04:18:13 --> 404 Page Not Found: /index
INFO - 2018-06-20 04:18:16 --> Config Class Initialized
INFO - 2018-06-20 04:18:16 --> Hooks Class Initialized
DEBUG - 2018-06-20 04:18:16 --> UTF-8 Support Enabled
INFO - 2018-06-20 04:18:16 --> Utf8 Class Initialized
INFO - 2018-06-20 04:18:16 --> URI Class Initialized
INFO - 2018-06-20 04:18:16 --> Router Class Initialized
INFO - 2018-06-20 04:18:16 --> Output Class Initialized
INFO - 2018-06-20 04:18:16 --> Security Class Initialized
DEBUG - 2018-06-20 04:18:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 04:18:16 --> Input Class Initialized
INFO - 2018-06-20 04:18:16 --> Language Class Initialized
INFO - 2018-06-20 04:18:16 --> Language Class Initialized
INFO - 2018-06-20 04:18:16 --> Config Class Initialized
INFO - 2018-06-20 04:18:16 --> Loader Class Initialized
DEBUG - 2018-06-20 04:18:16 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-20 04:18:16 --> Helper loaded: url_helper
INFO - 2018-06-20 04:18:16 --> Helper loaded: form_helper
INFO - 2018-06-20 04:18:16 --> Helper loaded: date_helper
INFO - 2018-06-20 04:18:16 --> Helper loaded: util_helper
INFO - 2018-06-20 04:18:16 --> Helper loaded: text_helper
INFO - 2018-06-20 04:18:16 --> Helper loaded: string_helper
INFO - 2018-06-20 04:18:16 --> Database Driver Class Initialized
DEBUG - 2018-06-20 04:18:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 04:18:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 04:18:16 --> Email Class Initialized
INFO - 2018-06-20 04:18:16 --> Controller Class Initialized
DEBUG - 2018-06-20 04:18:16 --> Home MX_Controller Initialized
DEBUG - 2018-06-20 04:18:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-20 04:18:16 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-20 04:18:16 --> Login MX_Controller Initialized
INFO - 2018-06-20 04:18:16 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-20 04:18:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-20 04:18:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-20 04:18:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-20 04:18:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-20 04:18:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-20 04:18:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-20 04:18:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-20 04:18:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-06-20 04:18:17 --> Final output sent to browser
DEBUG - 2018-06-20 04:18:17 --> Total execution time: 0.6165
INFO - 2018-06-20 04:18:17 --> Config Class Initialized
INFO - 2018-06-20 04:18:17 --> Config Class Initialized
INFO - 2018-06-20 04:18:17 --> Hooks Class Initialized
DEBUG - 2018-06-20 04:18:17 --> UTF-8 Support Enabled
INFO - 2018-06-20 04:18:17 --> Hooks Class Initialized
INFO - 2018-06-20 04:18:17 --> Utf8 Class Initialized
INFO - 2018-06-20 04:18:17 --> URI Class Initialized
DEBUG - 2018-06-20 04:18:17 --> UTF-8 Support Enabled
INFO - 2018-06-20 04:18:17 --> Utf8 Class Initialized
INFO - 2018-06-20 04:18:17 --> Router Class Initialized
INFO - 2018-06-20 04:18:17 --> URI Class Initialized
INFO - 2018-06-20 04:18:17 --> Output Class Initialized
INFO - 2018-06-20 04:18:17 --> Router Class Initialized
INFO - 2018-06-20 04:18:17 --> Security Class Initialized
DEBUG - 2018-06-20 04:18:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 04:18:17 --> Output Class Initialized
INFO - 2018-06-20 04:18:17 --> Input Class Initialized
INFO - 2018-06-20 04:18:17 --> Security Class Initialized
INFO - 2018-06-20 04:18:17 --> Language Class Initialized
DEBUG - 2018-06-20 04:18:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-06-20 04:18:17 --> 404 Page Not Found: /index
INFO - 2018-06-20 04:18:17 --> Input Class Initialized
INFO - 2018-06-20 04:18:17 --> Language Class Initialized
ERROR - 2018-06-20 04:18:17 --> 404 Page Not Found: /index
INFO - 2018-06-20 04:18:17 --> Config Class Initialized
INFO - 2018-06-20 04:18:17 --> Hooks Class Initialized
DEBUG - 2018-06-20 04:18:17 --> UTF-8 Support Enabled
INFO - 2018-06-20 04:18:17 --> Utf8 Class Initialized
INFO - 2018-06-20 04:18:17 --> URI Class Initialized
INFO - 2018-06-20 04:18:17 --> Router Class Initialized
INFO - 2018-06-20 04:18:18 --> Output Class Initialized
INFO - 2018-06-20 04:18:18 --> Security Class Initialized
DEBUG - 2018-06-20 04:18:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 04:18:18 --> Input Class Initialized
INFO - 2018-06-20 04:18:18 --> Language Class Initialized
ERROR - 2018-06-20 04:18:18 --> 404 Page Not Found: /index
INFO - 2018-06-20 04:18:18 --> Config Class Initialized
INFO - 2018-06-20 04:18:18 --> Hooks Class Initialized
DEBUG - 2018-06-20 04:18:18 --> UTF-8 Support Enabled
INFO - 2018-06-20 04:18:18 --> Utf8 Class Initialized
INFO - 2018-06-20 04:18:18 --> URI Class Initialized
INFO - 2018-06-20 04:18:18 --> Router Class Initialized
INFO - 2018-06-20 04:18:18 --> Output Class Initialized
INFO - 2018-06-20 04:18:18 --> Security Class Initialized
DEBUG - 2018-06-20 04:18:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 04:18:18 --> Input Class Initialized
INFO - 2018-06-20 04:18:18 --> Language Class Initialized
ERROR - 2018-06-20 04:18:18 --> 404 Page Not Found: /index
INFO - 2018-06-20 04:18:19 --> Config Class Initialized
INFO - 2018-06-20 04:18:19 --> Hooks Class Initialized
DEBUG - 2018-06-20 04:18:19 --> UTF-8 Support Enabled
INFO - 2018-06-20 04:18:19 --> Utf8 Class Initialized
INFO - 2018-06-20 04:18:19 --> URI Class Initialized
INFO - 2018-06-20 04:18:19 --> Router Class Initialized
INFO - 2018-06-20 04:18:19 --> Output Class Initialized
INFO - 2018-06-20 04:18:19 --> Security Class Initialized
DEBUG - 2018-06-20 04:18:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 04:18:19 --> Input Class Initialized
INFO - 2018-06-20 04:18:19 --> Language Class Initialized
INFO - 2018-06-20 04:18:19 --> Language Class Initialized
INFO - 2018-06-20 04:18:19 --> Config Class Initialized
INFO - 2018-06-20 04:18:19 --> Loader Class Initialized
DEBUG - 2018-06-20 04:18:19 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-20 04:18:19 --> Helper loaded: url_helper
INFO - 2018-06-20 04:18:19 --> Helper loaded: form_helper
INFO - 2018-06-20 04:18:19 --> Helper loaded: date_helper
INFO - 2018-06-20 04:18:19 --> Helper loaded: util_helper
INFO - 2018-06-20 04:18:19 --> Helper loaded: text_helper
INFO - 2018-06-20 04:18:19 --> Helper loaded: string_helper
INFO - 2018-06-20 04:18:19 --> Database Driver Class Initialized
DEBUG - 2018-06-20 04:18:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 04:18:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 04:18:19 --> Email Class Initialized
INFO - 2018-06-20 04:18:20 --> Controller Class Initialized
DEBUG - 2018-06-20 04:18:20 --> Home MX_Controller Initialized
DEBUG - 2018-06-20 04:18:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-20 04:18:20 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-20 04:18:20 --> Login MX_Controller Initialized
INFO - 2018-06-20 04:18:20 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-20 04:18:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-20 04:18:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-20 04:18:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-20 04:18:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-20 04:18:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-20 04:18:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-20 04:18:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-20 04:18:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-06-20 04:18:20 --> Final output sent to browser
DEBUG - 2018-06-20 04:18:20 --> Total execution time: 0.6424
INFO - 2018-06-20 04:18:20 --> Config Class Initialized
INFO - 2018-06-20 04:18:20 --> Config Class Initialized
INFO - 2018-06-20 04:18:20 --> Hooks Class Initialized
INFO - 2018-06-20 04:18:20 --> Hooks Class Initialized
DEBUG - 2018-06-20 04:18:20 --> UTF-8 Support Enabled
DEBUG - 2018-06-20 04:18:20 --> UTF-8 Support Enabled
INFO - 2018-06-20 04:18:20 --> Utf8 Class Initialized
INFO - 2018-06-20 04:18:20 --> Utf8 Class Initialized
INFO - 2018-06-20 04:18:20 --> URI Class Initialized
INFO - 2018-06-20 04:18:20 --> Router Class Initialized
INFO - 2018-06-20 04:18:20 --> URI Class Initialized
INFO - 2018-06-20 04:18:20 --> Output Class Initialized
INFO - 2018-06-20 04:18:20 --> Security Class Initialized
DEBUG - 2018-06-20 04:18:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 04:18:20 --> Input Class Initialized
INFO - 2018-06-20 04:18:20 --> Language Class Initialized
ERROR - 2018-06-20 04:18:20 --> 404 Page Not Found: /index
INFO - 2018-06-20 04:18:20 --> Router Class Initialized
INFO - 2018-06-20 04:18:20 --> Config Class Initialized
INFO - 2018-06-20 04:18:20 --> Hooks Class Initialized
INFO - 2018-06-20 04:18:20 --> Output Class Initialized
DEBUG - 2018-06-20 04:18:21 --> UTF-8 Support Enabled
INFO - 2018-06-20 04:18:21 --> Utf8 Class Initialized
INFO - 2018-06-20 04:18:21 --> URI Class Initialized
INFO - 2018-06-20 04:18:21 --> Router Class Initialized
INFO - 2018-06-20 04:18:21 --> Security Class Initialized
INFO - 2018-06-20 04:18:21 --> Output Class Initialized
DEBUG - 2018-06-20 04:18:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 04:18:21 --> Security Class Initialized
DEBUG - 2018-06-20 04:18:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 04:18:21 --> Input Class Initialized
INFO - 2018-06-20 04:18:21 --> Language Class Initialized
ERROR - 2018-06-20 04:18:21 --> 404 Page Not Found: /index
INFO - 2018-06-20 04:18:21 --> Input Class Initialized
INFO - 2018-06-20 04:18:21 --> Config Class Initialized
INFO - 2018-06-20 04:18:21 --> Hooks Class Initialized
INFO - 2018-06-20 04:18:21 --> Language Class Initialized
DEBUG - 2018-06-20 04:18:21 --> UTF-8 Support Enabled
ERROR - 2018-06-20 04:18:21 --> 404 Page Not Found: /index
INFO - 2018-06-20 04:18:21 --> Utf8 Class Initialized
INFO - 2018-06-20 04:18:21 --> URI Class Initialized
INFO - 2018-06-20 04:18:21 --> Router Class Initialized
INFO - 2018-06-20 04:18:21 --> Output Class Initialized
INFO - 2018-06-20 04:18:21 --> Security Class Initialized
DEBUG - 2018-06-20 04:18:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 04:18:21 --> Input Class Initialized
INFO - 2018-06-20 04:18:21 --> Language Class Initialized
ERROR - 2018-06-20 04:18:21 --> 404 Page Not Found: /index
INFO - 2018-06-20 21:00:28 --> Config Class Initialized
INFO - 2018-06-20 21:00:28 --> Hooks Class Initialized
DEBUG - 2018-06-20 21:00:28 --> UTF-8 Support Enabled
INFO - 2018-06-20 21:00:29 --> Utf8 Class Initialized
INFO - 2018-06-20 21:00:29 --> URI Class Initialized
INFO - 2018-06-20 21:00:29 --> Router Class Initialized
INFO - 2018-06-20 21:00:29 --> Config Class Initialized
INFO - 2018-06-20 21:00:29 --> Hooks Class Initialized
INFO - 2018-06-20 21:00:29 --> Output Class Initialized
DEBUG - 2018-06-20 21:00:29 --> UTF-8 Support Enabled
INFO - 2018-06-20 21:00:29 --> Utf8 Class Initialized
INFO - 2018-06-20 21:00:29 --> Security Class Initialized
INFO - 2018-06-20 21:00:29 --> URI Class Initialized
DEBUG - 2018-06-20 21:00:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 21:00:29 --> Input Class Initialized
INFO - 2018-06-20 21:00:29 --> Router Class Initialized
INFO - 2018-06-20 21:00:29 --> Output Class Initialized
INFO - 2018-06-20 21:00:29 --> Language Class Initialized
INFO - 2018-06-20 21:00:29 --> Security Class Initialized
DEBUG - 2018-06-20 21:00:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 21:00:29 --> Input Class Initialized
INFO - 2018-06-20 21:00:29 --> Language Class Initialized
INFO - 2018-06-20 21:00:29 --> Language Class Initialized
INFO - 2018-06-20 21:00:29 --> Language Class Initialized
INFO - 2018-06-20 21:00:29 --> Config Class Initialized
INFO - 2018-06-20 21:00:29 --> Config Class Initialized
INFO - 2018-06-20 21:00:29 --> Loader Class Initialized
INFO - 2018-06-20 21:00:29 --> Loader Class Initialized
DEBUG - 2018-06-20 21:00:29 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
DEBUG - 2018-06-20 21:00:29 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-20 21:00:29 --> Helper loaded: url_helper
INFO - 2018-06-20 21:00:29 --> Helper loaded: url_helper
INFO - 2018-06-20 21:00:29 --> Helper loaded: form_helper
INFO - 2018-06-20 21:00:29 --> Helper loaded: form_helper
INFO - 2018-06-20 21:00:29 --> Helper loaded: date_helper
INFO - 2018-06-20 21:00:29 --> Helper loaded: date_helper
INFO - 2018-06-20 21:00:29 --> Helper loaded: util_helper
INFO - 2018-06-20 21:00:29 --> Helper loaded: util_helper
INFO - 2018-06-20 21:00:29 --> Helper loaded: text_helper
INFO - 2018-06-20 21:00:29 --> Helper loaded: text_helper
INFO - 2018-06-20 21:00:29 --> Helper loaded: string_helper
INFO - 2018-06-20 21:00:29 --> Helper loaded: string_helper
INFO - 2018-06-20 21:00:29 --> Config Class Initialized
INFO - 2018-06-20 21:00:29 --> Hooks Class Initialized
DEBUG - 2018-06-20 21:00:29 --> UTF-8 Support Enabled
INFO - 2018-06-20 21:00:29 --> Utf8 Class Initialized
INFO - 2018-06-20 21:00:29 --> Database Driver Class Initialized
INFO - 2018-06-20 21:00:29 --> Database Driver Class Initialized
INFO - 2018-06-20 21:00:29 --> URI Class Initialized
INFO - 2018-06-20 21:00:29 --> Router Class Initialized
INFO - 2018-06-20 21:00:29 --> Output Class Initialized
DEBUG - 2018-06-20 21:00:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-06-20 21:00:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 21:00:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 21:00:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 21:00:29 --> Security Class Initialized
DEBUG - 2018-06-20 21:00:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 21:00:29 --> Email Class Initialized
INFO - 2018-06-20 21:00:29 --> Email Class Initialized
INFO - 2018-06-20 21:00:29 --> Controller Class Initialized
INFO - 2018-06-20 21:00:29 --> Controller Class Initialized
INFO - 2018-06-20 21:00:29 --> Input Class Initialized
DEBUG - 2018-06-20 21:00:29 --> videos MX_Controller Initialized
DEBUG - 2018-06-20 21:00:29 --> Home MX_Controller Initialized
INFO - 2018-06-20 21:00:29 --> Language Class Initialized
INFO - 2018-06-20 21:00:29 --> Language Class Initialized
INFO - 2018-06-20 21:00:29 --> Language file loaded: language/english/data_lang.php
INFO - 2018-06-20 21:00:29 --> Config Class Initialized
DEBUG - 2018-06-20 21:00:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
INFO - 2018-06-20 21:00:30 --> Loader Class Initialized
DEBUG - 2018-06-20 21:00:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-20 21:00:30 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
DEBUG - 2018-06-20 21:00:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-06-20 21:00:30 --> Helper loaded: url_helper
DEBUG - 2018-06-20 21:00:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
INFO - 2018-06-20 21:00:30 --> Helper loaded: form_helper
INFO - 2018-06-20 21:00:30 --> Helper loaded: date_helper
INFO - 2018-06-20 21:00:30 --> Helper loaded: util_helper
INFO - 2018-06-20 21:00:30 --> Helper loaded: text_helper
DEBUG - 2018-06-20 21:00:30 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-20 21:00:30 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-20 21:00:30 --> Login MX_Controller Initialized
INFO - 2018-06-20 21:00:30 --> Helper loaded: string_helper
DEBUG - 2018-06-20 21:00:30 --> Login MX_Controller Initialized
INFO - 2018-06-20 21:00:30 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-20 21:00:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-06-20 21:00:30 --> Database Driver Class Initialized
DEBUG - 2018-06-20 21:00:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-20 21:00:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-20 21:00:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-06-20 21:00:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-06-20 21:00:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 21:00:30 --> Email Class Initialized
INFO - 2018-06-20 21:00:30 --> Controller Class Initialized
DEBUG - 2018-06-20 21:00:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
DEBUG - 2018-06-20 21:00:30 --> Home MX_Controller Initialized
DEBUG - 2018-06-20 21:00:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-20 21:00:30 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-20 21:00:30 --> Login MX_Controller Initialized
INFO - 2018-06-20 21:00:30 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-20 21:00:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-20 21:00:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-20 21:00:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-06-20 21:00:30 --> Config Class Initialized
INFO - 2018-06-20 21:00:30 --> Hooks Class Initialized
DEBUG - 2018-06-20 21:00:30 --> UTF-8 Support Enabled
INFO - 2018-06-20 21:00:30 --> Utf8 Class Initialized
INFO - 2018-06-20 21:00:30 --> URI Class Initialized
INFO - 2018-06-20 21:00:30 --> Router Class Initialized
INFO - 2018-06-20 21:00:30 --> Output Class Initialized
INFO - 2018-06-20 21:00:30 --> Security Class Initialized
DEBUG - 2018-06-20 21:00:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 21:00:30 --> Input Class Initialized
INFO - 2018-06-20 21:00:31 --> Language Class Initialized
ERROR - 2018-06-20 21:00:31 --> 404 Page Not Found: /index
INFO - 2018-06-20 21:00:31 --> Config Class Initialized
INFO - 2018-06-20 21:00:31 --> Hooks Class Initialized
DEBUG - 2018-06-20 21:00:31 --> UTF-8 Support Enabled
INFO - 2018-06-20 21:00:31 --> Utf8 Class Initialized
INFO - 2018-06-20 21:00:31 --> URI Class Initialized
INFO - 2018-06-20 21:00:31 --> Router Class Initialized
INFO - 2018-06-20 21:00:31 --> Output Class Initialized
INFO - 2018-06-20 21:00:31 --> Security Class Initialized
DEBUG - 2018-06-20 21:00:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 21:00:31 --> Input Class Initialized
INFO - 2018-06-20 21:00:31 --> Language Class Initialized
ERROR - 2018-06-20 21:00:31 --> 404 Page Not Found: /index
INFO - 2018-06-20 21:01:00 --> Config Class Initialized
INFO - 2018-06-20 21:01:00 --> Hooks Class Initialized
DEBUG - 2018-06-20 21:01:00 --> UTF-8 Support Enabled
INFO - 2018-06-20 21:01:00 --> Utf8 Class Initialized
INFO - 2018-06-20 21:01:00 --> URI Class Initialized
INFO - 2018-06-20 21:01:00 --> Router Class Initialized
INFO - 2018-06-20 21:01:00 --> Output Class Initialized
INFO - 2018-06-20 21:01:00 --> Security Class Initialized
DEBUG - 2018-06-20 21:01:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 21:01:00 --> Input Class Initialized
INFO - 2018-06-20 21:01:00 --> Language Class Initialized
INFO - 2018-06-20 21:01:00 --> Language Class Initialized
INFO - 2018-06-20 21:01:00 --> Config Class Initialized
INFO - 2018-06-20 21:01:00 --> Loader Class Initialized
DEBUG - 2018-06-20 21:01:00 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-20 21:01:00 --> Helper loaded: url_helper
INFO - 2018-06-20 21:01:00 --> Helper loaded: form_helper
INFO - 2018-06-20 21:01:00 --> Helper loaded: date_helper
INFO - 2018-06-20 21:01:00 --> Helper loaded: util_helper
INFO - 2018-06-20 21:01:00 --> Helper loaded: text_helper
INFO - 2018-06-20 21:01:00 --> Helper loaded: string_helper
INFO - 2018-06-20 21:01:00 --> Database Driver Class Initialized
DEBUG - 2018-06-20 21:01:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 21:01:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 21:01:00 --> Email Class Initialized
INFO - 2018-06-20 21:01:00 --> Controller Class Initialized
DEBUG - 2018-06-20 21:01:00 --> Home MX_Controller Initialized
DEBUG - 2018-06-20 21:01:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-20 21:01:00 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-20 21:01:00 --> Login MX_Controller Initialized
INFO - 2018-06-20 21:01:00 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-20 21:01:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-20 21:01:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-20 21:01:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-06-20 21:01:19 --> Config Class Initialized
INFO - 2018-06-20 21:01:19 --> Hooks Class Initialized
DEBUG - 2018-06-20 21:01:19 --> UTF-8 Support Enabled
INFO - 2018-06-20 21:01:19 --> Utf8 Class Initialized
INFO - 2018-06-20 21:01:19 --> URI Class Initialized
INFO - 2018-06-20 21:01:19 --> Router Class Initialized
INFO - 2018-06-20 21:01:19 --> Output Class Initialized
INFO - 2018-06-20 21:01:19 --> Security Class Initialized
DEBUG - 2018-06-20 21:01:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 21:01:19 --> Input Class Initialized
INFO - 2018-06-20 21:01:19 --> Language Class Initialized
INFO - 2018-06-20 21:01:19 --> Language Class Initialized
INFO - 2018-06-20 21:01:19 --> Config Class Initialized
INFO - 2018-06-20 21:01:19 --> Loader Class Initialized
DEBUG - 2018-06-20 21:01:20 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-20 21:01:20 --> Helper loaded: url_helper
INFO - 2018-06-20 21:01:20 --> Helper loaded: form_helper
INFO - 2018-06-20 21:01:20 --> Helper loaded: date_helper
INFO - 2018-06-20 21:01:20 --> Helper loaded: util_helper
INFO - 2018-06-20 21:01:20 --> Helper loaded: text_helper
INFO - 2018-06-20 21:01:20 --> Helper loaded: string_helper
INFO - 2018-06-20 21:01:20 --> Database Driver Class Initialized
DEBUG - 2018-06-20 21:01:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 21:01:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 21:01:20 --> Email Class Initialized
INFO - 2018-06-20 21:01:20 --> Controller Class Initialized
DEBUG - 2018-06-20 21:01:20 --> Login MX_Controller Initialized
INFO - 2018-06-20 21:01:20 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-20 21:01:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-20 21:01:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-20 21:01:20 --> Email starts for user@colin.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-06-20 21:01:20 --> User session created for 4
INFO - 2018-06-20 21:01:20 --> Login status user@colin.com - success
INFO - 2018-06-20 21:01:20 --> Final output sent to browser
DEBUG - 2018-06-20 21:01:20 --> Total execution time: 0.5757
INFO - 2018-06-20 21:01:20 --> Config Class Initialized
INFO - 2018-06-20 21:01:20 --> Hooks Class Initialized
DEBUG - 2018-06-20 21:01:20 --> UTF-8 Support Enabled
INFO - 2018-06-20 21:01:20 --> Utf8 Class Initialized
INFO - 2018-06-20 21:01:20 --> URI Class Initialized
INFO - 2018-06-20 21:01:20 --> Router Class Initialized
INFO - 2018-06-20 21:01:20 --> Output Class Initialized
INFO - 2018-06-20 21:01:20 --> Security Class Initialized
DEBUG - 2018-06-20 21:01:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 21:01:20 --> Input Class Initialized
INFO - 2018-06-20 21:01:20 --> Language Class Initialized
INFO - 2018-06-20 21:01:20 --> Language Class Initialized
INFO - 2018-06-20 21:01:20 --> Config Class Initialized
INFO - 2018-06-20 21:01:20 --> Loader Class Initialized
DEBUG - 2018-06-20 21:01:20 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-20 21:01:20 --> Helper loaded: url_helper
INFO - 2018-06-20 21:01:20 --> Helper loaded: form_helper
INFO - 2018-06-20 21:01:20 --> Helper loaded: date_helper
INFO - 2018-06-20 21:01:20 --> Helper loaded: util_helper
INFO - 2018-06-20 21:01:20 --> Helper loaded: text_helper
INFO - 2018-06-20 21:01:20 --> Helper loaded: string_helper
INFO - 2018-06-20 21:01:20 --> Database Driver Class Initialized
DEBUG - 2018-06-20 21:01:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 21:01:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 21:01:20 --> Email Class Initialized
INFO - 2018-06-20 21:01:20 --> Controller Class Initialized
DEBUG - 2018-06-20 21:01:20 --> Home MX_Controller Initialized
DEBUG - 2018-06-20 21:01:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-20 21:01:20 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-20 21:01:20 --> Login MX_Controller Initialized
INFO - 2018-06-20 21:01:20 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-20 21:01:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-20 21:01:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-20 21:01:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-20 21:01:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-20 21:01:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-20 21:01:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-20 21:01:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-20 21:01:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-06-20 21:01:21 --> Final output sent to browser
DEBUG - 2018-06-20 21:01:21 --> Total execution time: 0.7564
INFO - 2018-06-20 21:01:21 --> Config Class Initialized
INFO - 2018-06-20 21:01:21 --> Hooks Class Initialized
INFO - 2018-06-20 21:01:21 --> Config Class Initialized
INFO - 2018-06-20 21:01:21 --> Hooks Class Initialized
DEBUG - 2018-06-20 21:01:21 --> UTF-8 Support Enabled
INFO - 2018-06-20 21:01:21 --> Utf8 Class Initialized
DEBUG - 2018-06-20 21:01:21 --> UTF-8 Support Enabled
INFO - 2018-06-20 21:01:21 --> Utf8 Class Initialized
INFO - 2018-06-20 21:01:21 --> URI Class Initialized
INFO - 2018-06-20 21:01:22 --> URI Class Initialized
INFO - 2018-06-20 21:01:22 --> Router Class Initialized
INFO - 2018-06-20 21:01:22 --> Output Class Initialized
INFO - 2018-06-20 21:01:22 --> Security Class Initialized
DEBUG - 2018-06-20 21:01:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 21:01:22 --> Input Class Initialized
INFO - 2018-06-20 21:01:22 --> Language Class Initialized
ERROR - 2018-06-20 21:01:22 --> 404 Page Not Found: /index
INFO - 2018-06-20 21:01:22 --> Router Class Initialized
INFO - 2018-06-20 21:01:22 --> Output Class Initialized
INFO - 2018-06-20 21:01:22 --> Config Class Initialized
INFO - 2018-06-20 21:01:22 --> Security Class Initialized
INFO - 2018-06-20 21:01:22 --> Hooks Class Initialized
DEBUG - 2018-06-20 21:01:22 --> UTF-8 Support Enabled
INFO - 2018-06-20 21:01:22 --> Utf8 Class Initialized
INFO - 2018-06-20 21:01:22 --> URI Class Initialized
INFO - 2018-06-20 21:01:22 --> Router Class Initialized
INFO - 2018-06-20 21:01:22 --> Output Class Initialized
DEBUG - 2018-06-20 21:01:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 21:01:22 --> Security Class Initialized
DEBUG - 2018-06-20 21:01:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 21:01:22 --> Input Class Initialized
INFO - 2018-06-20 21:01:22 --> Language Class Initialized
ERROR - 2018-06-20 21:01:22 --> 404 Page Not Found: /index
INFO - 2018-06-20 21:01:22 --> Input Class Initialized
INFO - 2018-06-20 21:01:22 --> Language Class Initialized
ERROR - 2018-06-20 21:01:22 --> 404 Page Not Found: /index
INFO - 2018-06-20 21:01:22 --> Config Class Initialized
INFO - 2018-06-20 21:01:22 --> Hooks Class Initialized
DEBUG - 2018-06-20 21:01:22 --> UTF-8 Support Enabled
INFO - 2018-06-20 21:01:22 --> Utf8 Class Initialized
INFO - 2018-06-20 21:01:22 --> URI Class Initialized
INFO - 2018-06-20 21:01:22 --> Router Class Initialized
INFO - 2018-06-20 21:01:22 --> Output Class Initialized
INFO - 2018-06-20 21:01:22 --> Security Class Initialized
DEBUG - 2018-06-20 21:01:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 21:01:22 --> Input Class Initialized
INFO - 2018-06-20 21:01:22 --> Language Class Initialized
ERROR - 2018-06-20 21:01:22 --> 404 Page Not Found: /index
INFO - 2018-06-20 21:01:23 --> Config Class Initialized
INFO - 2018-06-20 21:01:23 --> Hooks Class Initialized
DEBUG - 2018-06-20 21:01:23 --> UTF-8 Support Enabled
INFO - 2018-06-20 21:01:23 --> Utf8 Class Initialized
INFO - 2018-06-20 21:01:23 --> URI Class Initialized
INFO - 2018-06-20 21:01:23 --> Router Class Initialized
INFO - 2018-06-20 21:01:23 --> Output Class Initialized
INFO - 2018-06-20 21:01:23 --> Security Class Initialized
DEBUG - 2018-06-20 21:01:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 21:01:23 --> Input Class Initialized
INFO - 2018-06-20 21:01:23 --> Language Class Initialized
ERROR - 2018-06-20 21:01:23 --> 404 Page Not Found: /index
INFO - 2018-06-20 21:01:23 --> Config Class Initialized
INFO - 2018-06-20 21:01:23 --> Hooks Class Initialized
DEBUG - 2018-06-20 21:01:23 --> UTF-8 Support Enabled
INFO - 2018-06-20 21:01:23 --> Utf8 Class Initialized
INFO - 2018-06-20 21:01:23 --> URI Class Initialized
INFO - 2018-06-20 21:01:23 --> Router Class Initialized
INFO - 2018-06-20 21:01:23 --> Output Class Initialized
INFO - 2018-06-20 21:01:23 --> Security Class Initialized
DEBUG - 2018-06-20 21:01:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 21:01:23 --> Input Class Initialized
INFO - 2018-06-20 21:01:23 --> Language Class Initialized
ERROR - 2018-06-20 21:01:23 --> 404 Page Not Found: /index
INFO - 2018-06-20 21:01:23 --> Config Class Initialized
INFO - 2018-06-20 21:01:23 --> Hooks Class Initialized
DEBUG - 2018-06-20 21:01:23 --> UTF-8 Support Enabled
INFO - 2018-06-20 21:01:23 --> Utf8 Class Initialized
INFO - 2018-06-20 21:01:23 --> URI Class Initialized
INFO - 2018-06-20 21:01:23 --> Router Class Initialized
INFO - 2018-06-20 21:01:23 --> Output Class Initialized
INFO - 2018-06-20 21:01:23 --> Security Class Initialized
DEBUG - 2018-06-20 21:01:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 21:01:23 --> Input Class Initialized
INFO - 2018-06-20 21:01:23 --> Language Class Initialized
ERROR - 2018-06-20 21:01:23 --> 404 Page Not Found: /index
INFO - 2018-06-20 21:01:26 --> Config Class Initialized
INFO - 2018-06-20 21:01:26 --> Hooks Class Initialized
DEBUG - 2018-06-20 21:01:26 --> UTF-8 Support Enabled
INFO - 2018-06-20 21:01:26 --> Utf8 Class Initialized
INFO - 2018-06-20 21:01:26 --> URI Class Initialized
INFO - 2018-06-20 21:01:26 --> Router Class Initialized
INFO - 2018-06-20 21:01:26 --> Output Class Initialized
INFO - 2018-06-20 21:01:26 --> Security Class Initialized
DEBUG - 2018-06-20 21:01:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 21:01:26 --> Input Class Initialized
INFO - 2018-06-20 21:01:26 --> Language Class Initialized
INFO - 2018-06-20 21:01:26 --> Language Class Initialized
INFO - 2018-06-20 21:01:26 --> Config Class Initialized
INFO - 2018-06-20 21:01:26 --> Loader Class Initialized
DEBUG - 2018-06-20 21:01:26 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-20 21:01:26 --> Helper loaded: url_helper
INFO - 2018-06-20 21:01:26 --> Helper loaded: form_helper
INFO - 2018-06-20 21:01:26 --> Helper loaded: date_helper
INFO - 2018-06-20 21:01:26 --> Helper loaded: util_helper
INFO - 2018-06-20 21:01:26 --> Helper loaded: text_helper
INFO - 2018-06-20 21:01:26 --> Helper loaded: string_helper
INFO - 2018-06-20 21:01:26 --> Database Driver Class Initialized
DEBUG - 2018-06-20 21:01:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 21:01:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 21:01:26 --> Email Class Initialized
INFO - 2018-06-20 21:01:26 --> Controller Class Initialized
DEBUG - 2018-06-20 21:01:26 --> Login MX_Controller Initialized
INFO - 2018-06-20 21:01:26 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-20 21:01:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-20 21:01:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-20 21:01:26 --> Email starts for admin@colin.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-06-20 21:01:26 --> User session created for 1
INFO - 2018-06-20 21:01:26 --> Login status admin@colin.com - success
INFO - 2018-06-20 21:01:26 --> Final output sent to browser
DEBUG - 2018-06-20 21:01:26 --> Total execution time: 0.5824
INFO - 2018-06-20 21:01:26 --> Config Class Initialized
INFO - 2018-06-20 21:01:26 --> Hooks Class Initialized
DEBUG - 2018-06-20 21:01:26 --> UTF-8 Support Enabled
INFO - 2018-06-20 21:01:26 --> Utf8 Class Initialized
INFO - 2018-06-20 21:01:26 --> URI Class Initialized
INFO - 2018-06-20 21:01:26 --> Router Class Initialized
INFO - 2018-06-20 21:01:26 --> Output Class Initialized
INFO - 2018-06-20 21:01:26 --> Security Class Initialized
DEBUG - 2018-06-20 21:01:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 21:01:26 --> Input Class Initialized
INFO - 2018-06-20 21:01:26 --> Language Class Initialized
INFO - 2018-06-20 21:01:26 --> Language Class Initialized
INFO - 2018-06-20 21:01:26 --> Config Class Initialized
INFO - 2018-06-20 21:01:26 --> Loader Class Initialized
DEBUG - 2018-06-20 21:01:26 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-20 21:01:27 --> Helper loaded: url_helper
INFO - 2018-06-20 21:01:27 --> Helper loaded: form_helper
INFO - 2018-06-20 21:01:27 --> Helper loaded: date_helper
INFO - 2018-06-20 21:01:27 --> Helper loaded: util_helper
INFO - 2018-06-20 21:01:27 --> Helper loaded: text_helper
INFO - 2018-06-20 21:01:27 --> Helper loaded: string_helper
INFO - 2018-06-20 21:01:27 --> Database Driver Class Initialized
DEBUG - 2018-06-20 21:01:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 21:01:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 21:01:27 --> Email Class Initialized
INFO - 2018-06-20 21:01:27 --> Controller Class Initialized
DEBUG - 2018-06-20 21:01:27 --> videos MX_Controller Initialized
INFO - 2018-06-20 21:01:27 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-20 21:01:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-06-20 21:01:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-20 21:01:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-20 21:01:27 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-20 21:01:27 --> Login MX_Controller Initialized
DEBUG - 2018-06-20 21:01:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-20 21:01:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-20 21:01:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-20 21:01:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-20 21:01:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-20 21:01:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-20 21:01:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/videos/videos.php
INFO - 2018-06-20 21:01:27 --> Final output sent to browser
DEBUG - 2018-06-20 21:01:27 --> Total execution time: 0.8559
INFO - 2018-06-20 21:01:28 --> Config Class Initialized
INFO - 2018-06-20 21:01:28 --> Hooks Class Initialized
DEBUG - 2018-06-20 21:01:28 --> UTF-8 Support Enabled
INFO - 2018-06-20 21:01:28 --> Utf8 Class Initialized
INFO - 2018-06-20 21:01:28 --> URI Class Initialized
INFO - 2018-06-20 21:01:28 --> Router Class Initialized
INFO - 2018-06-20 21:01:28 --> Output Class Initialized
INFO - 2018-06-20 21:01:28 --> Security Class Initialized
DEBUG - 2018-06-20 21:01:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 21:01:28 --> Input Class Initialized
INFO - 2018-06-20 21:01:29 --> Language Class Initialized
INFO - 2018-06-20 21:01:29 --> Language Class Initialized
INFO - 2018-06-20 21:01:29 --> Config Class Initialized
INFO - 2018-06-20 21:01:29 --> Loader Class Initialized
DEBUG - 2018-06-20 21:01:29 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-20 21:01:29 --> Helper loaded: url_helper
INFO - 2018-06-20 21:01:29 --> Helper loaded: form_helper
INFO - 2018-06-20 21:01:29 --> Helper loaded: date_helper
INFO - 2018-06-20 21:01:29 --> Helper loaded: util_helper
INFO - 2018-06-20 21:01:29 --> Helper loaded: text_helper
INFO - 2018-06-20 21:01:29 --> Helper loaded: string_helper
INFO - 2018-06-20 21:01:29 --> Database Driver Class Initialized
DEBUG - 2018-06-20 21:01:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 21:01:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 21:01:29 --> Email Class Initialized
INFO - 2018-06-20 21:01:29 --> Controller Class Initialized
DEBUG - 2018-06-20 21:01:29 --> videos MX_Controller Initialized
INFO - 2018-06-20 21:01:29 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-20 21:01:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-06-20 21:01:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-20 21:01:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-20 21:01:29 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-20 21:01:29 --> Login MX_Controller Initialized
DEBUG - 2018-06-20 21:01:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-20 21:01:29 --> Final output sent to browser
DEBUG - 2018-06-20 21:01:29 --> Total execution time: 0.8614
INFO - 2018-06-20 21:01:47 --> Config Class Initialized
INFO - 2018-06-20 21:01:47 --> Hooks Class Initialized
DEBUG - 2018-06-20 21:01:47 --> UTF-8 Support Enabled
INFO - 2018-06-20 21:01:47 --> Utf8 Class Initialized
INFO - 2018-06-20 21:01:47 --> URI Class Initialized
INFO - 2018-06-20 21:01:47 --> Router Class Initialized
INFO - 2018-06-20 21:01:47 --> Output Class Initialized
INFO - 2018-06-20 21:01:47 --> Security Class Initialized
DEBUG - 2018-06-20 21:01:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 21:01:47 --> Input Class Initialized
INFO - 2018-06-20 21:01:47 --> Language Class Initialized
INFO - 2018-06-20 21:01:47 --> Language Class Initialized
INFO - 2018-06-20 21:01:47 --> Config Class Initialized
INFO - 2018-06-20 21:01:47 --> Loader Class Initialized
DEBUG - 2018-06-20 21:01:47 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-20 21:01:47 --> Helper loaded: url_helper
INFO - 2018-06-20 21:01:47 --> Helper loaded: form_helper
INFO - 2018-06-20 21:01:47 --> Helper loaded: date_helper
INFO - 2018-06-20 21:01:47 --> Helper loaded: util_helper
INFO - 2018-06-20 21:01:47 --> Helper loaded: text_helper
INFO - 2018-06-20 21:01:47 --> Helper loaded: string_helper
INFO - 2018-06-20 21:01:47 --> Database Driver Class Initialized
DEBUG - 2018-06-20 21:01:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 21:01:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 21:01:47 --> Email Class Initialized
INFO - 2018-06-20 21:01:47 --> Controller Class Initialized
DEBUG - 2018-06-20 21:01:47 --> Home MX_Controller Initialized
DEBUG - 2018-06-20 21:01:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-20 21:01:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-06-20 21:01:47 --> Final output sent to browser
DEBUG - 2018-06-20 21:01:47 --> Total execution time: 0.4720
INFO - 2018-06-20 21:01:47 --> Config Class Initialized
INFO - 2018-06-20 21:01:47 --> Hooks Class Initialized
DEBUG - 2018-06-20 21:01:47 --> UTF-8 Support Enabled
INFO - 2018-06-20 21:01:47 --> Utf8 Class Initialized
INFO - 2018-06-20 21:01:47 --> URI Class Initialized
INFO - 2018-06-20 21:01:47 --> Router Class Initialized
INFO - 2018-06-20 21:01:47 --> Output Class Initialized
INFO - 2018-06-20 21:01:47 --> Security Class Initialized
DEBUG - 2018-06-20 21:01:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 21:01:47 --> Input Class Initialized
INFO - 2018-06-20 21:01:47 --> Language Class Initialized
INFO - 2018-06-20 21:01:47 --> Language Class Initialized
INFO - 2018-06-20 21:01:47 --> Config Class Initialized
INFO - 2018-06-20 21:01:47 --> Loader Class Initialized
DEBUG - 2018-06-20 21:01:47 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-20 21:01:47 --> Helper loaded: url_helper
INFO - 2018-06-20 21:01:47 --> Helper loaded: form_helper
INFO - 2018-06-20 21:01:47 --> Helper loaded: date_helper
INFO - 2018-06-20 21:01:47 --> Helper loaded: util_helper
INFO - 2018-06-20 21:01:47 --> Helper loaded: text_helper
INFO - 2018-06-20 21:01:47 --> Helper loaded: string_helper
INFO - 2018-06-20 21:01:47 --> Database Driver Class Initialized
DEBUG - 2018-06-20 21:01:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 21:01:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 21:01:47 --> Email Class Initialized
INFO - 2018-06-20 21:01:47 --> Controller Class Initialized
DEBUG - 2018-06-20 21:01:47 --> Home MX_Controller Initialized
DEBUG - 2018-06-20 21:01:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-06-20 21:07:36 --> Config Class Initialized
INFO - 2018-06-20 21:07:36 --> Hooks Class Initialized
DEBUG - 2018-06-20 21:07:36 --> UTF-8 Support Enabled
INFO - 2018-06-20 21:07:36 --> Utf8 Class Initialized
INFO - 2018-06-20 21:07:36 --> URI Class Initialized
INFO - 2018-06-20 21:07:37 --> Router Class Initialized
INFO - 2018-06-20 21:07:37 --> Output Class Initialized
INFO - 2018-06-20 21:07:37 --> Security Class Initialized
DEBUG - 2018-06-20 21:07:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 21:07:37 --> Input Class Initialized
INFO - 2018-06-20 21:07:37 --> Language Class Initialized
INFO - 2018-06-20 21:07:37 --> Language Class Initialized
INFO - 2018-06-20 21:07:37 --> Config Class Initialized
INFO - 2018-06-20 21:07:37 --> Loader Class Initialized
DEBUG - 2018-06-20 21:07:37 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-20 21:07:37 --> Helper loaded: url_helper
INFO - 2018-06-20 21:07:37 --> Helper loaded: form_helper
INFO - 2018-06-20 21:07:37 --> Helper loaded: date_helper
INFO - 2018-06-20 21:07:37 --> Helper loaded: util_helper
INFO - 2018-06-20 21:07:37 --> Helper loaded: text_helper
INFO - 2018-06-20 21:07:37 --> Helper loaded: string_helper
INFO - 2018-06-20 21:07:37 --> Database Driver Class Initialized
DEBUG - 2018-06-20 21:07:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 21:07:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 21:07:37 --> Email Class Initialized
INFO - 2018-06-20 21:07:37 --> Controller Class Initialized
DEBUG - 2018-06-20 21:07:37 --> videos MX_Controller Initialized
INFO - 2018-06-20 21:07:37 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-20 21:07:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-06-20 21:07:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-20 21:07:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-20 21:07:37 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-20 21:07:37 --> Login MX_Controller Initialized
DEBUG - 2018-06-20 21:07:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-20 21:07:37 --> Final output sent to browser
DEBUG - 2018-06-20 21:07:37 --> Total execution time: 0.5796
INFO - 2018-06-20 21:07:40 --> Config Class Initialized
INFO - 2018-06-20 21:07:40 --> Hooks Class Initialized
DEBUG - 2018-06-20 21:07:40 --> UTF-8 Support Enabled
INFO - 2018-06-20 21:07:40 --> Utf8 Class Initialized
INFO - 2018-06-20 21:07:40 --> URI Class Initialized
INFO - 2018-06-20 21:07:40 --> Router Class Initialized
INFO - 2018-06-20 21:07:40 --> Output Class Initialized
INFO - 2018-06-20 21:07:40 --> Security Class Initialized
DEBUG - 2018-06-20 21:07:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 21:07:40 --> Input Class Initialized
INFO - 2018-06-20 21:07:40 --> Language Class Initialized
INFO - 2018-06-20 21:07:40 --> Language Class Initialized
INFO - 2018-06-20 21:07:40 --> Config Class Initialized
INFO - 2018-06-20 21:07:40 --> Loader Class Initialized
DEBUG - 2018-06-20 21:07:40 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-20 21:07:40 --> Helper loaded: url_helper
INFO - 2018-06-20 21:07:40 --> Helper loaded: form_helper
INFO - 2018-06-20 21:07:40 --> Helper loaded: date_helper
INFO - 2018-06-20 21:07:40 --> Helper loaded: util_helper
INFO - 2018-06-20 21:07:40 --> Helper loaded: text_helper
INFO - 2018-06-20 21:07:40 --> Helper loaded: string_helper
INFO - 2018-06-20 21:07:40 --> Database Driver Class Initialized
DEBUG - 2018-06-20 21:07:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 21:07:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 21:07:40 --> Email Class Initialized
INFO - 2018-06-20 21:07:41 --> Controller Class Initialized
DEBUG - 2018-06-20 21:07:41 --> videos MX_Controller Initialized
INFO - 2018-06-20 21:07:41 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-20 21:07:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-06-20 21:07:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-20 21:07:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-20 21:07:41 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-20 21:07:41 --> Login MX_Controller Initialized
DEBUG - 2018-06-20 21:07:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-20 21:07:41 --> Final output sent to browser
DEBUG - 2018-06-20 21:07:41 --> Total execution time: 0.5659
INFO - 2018-06-20 21:46:08 --> Config Class Initialized
INFO - 2018-06-20 21:46:08 --> Hooks Class Initialized
DEBUG - 2018-06-20 21:46:08 --> UTF-8 Support Enabled
INFO - 2018-06-20 21:46:08 --> Utf8 Class Initialized
INFO - 2018-06-20 21:46:08 --> URI Class Initialized
INFO - 2018-06-20 21:46:08 --> Router Class Initialized
INFO - 2018-06-20 21:46:08 --> Output Class Initialized
INFO - 2018-06-20 21:46:08 --> Security Class Initialized
DEBUG - 2018-06-20 21:46:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 21:46:08 --> Input Class Initialized
INFO - 2018-06-20 21:46:08 --> Language Class Initialized
INFO - 2018-06-20 21:46:08 --> Language Class Initialized
INFO - 2018-06-20 21:46:08 --> Config Class Initialized
INFO - 2018-06-20 21:46:08 --> Loader Class Initialized
DEBUG - 2018-06-20 21:46:08 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-20 21:46:08 --> Helper loaded: url_helper
INFO - 2018-06-20 21:46:08 --> Helper loaded: form_helper
INFO - 2018-06-20 21:46:08 --> Helper loaded: date_helper
INFO - 2018-06-20 21:46:08 --> Helper loaded: util_helper
INFO - 2018-06-20 21:46:08 --> Helper loaded: text_helper
INFO - 2018-06-20 21:46:09 --> Helper loaded: string_helper
INFO - 2018-06-20 21:46:09 --> Database Driver Class Initialized
DEBUG - 2018-06-20 21:46:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 21:46:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 21:46:09 --> Email Class Initialized
INFO - 2018-06-20 21:46:09 --> Controller Class Initialized
DEBUG - 2018-06-20 21:46:09 --> videos MX_Controller Initialized
INFO - 2018-06-20 21:46:09 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-20 21:46:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-06-20 21:46:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-20 21:46:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-20 21:46:09 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-20 21:46:09 --> Login MX_Controller Initialized
DEBUG - 2018-06-20 21:46:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-20 21:46:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-20 21:46:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-20 21:46:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-20 21:46:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-20 21:46:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-20 21:46:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/videos/videos.php
INFO - 2018-06-20 21:46:09 --> Final output sent to browser
DEBUG - 2018-06-20 21:46:09 --> Total execution time: 0.6463
INFO - 2018-06-20 21:46:09 --> Config Class Initialized
INFO - 2018-06-20 21:46:09 --> Hooks Class Initialized
DEBUG - 2018-06-20 21:46:09 --> UTF-8 Support Enabled
INFO - 2018-06-20 21:46:09 --> Utf8 Class Initialized
INFO - 2018-06-20 21:46:09 --> URI Class Initialized
INFO - 2018-06-20 21:46:10 --> Router Class Initialized
INFO - 2018-06-20 21:46:10 --> Output Class Initialized
INFO - 2018-06-20 21:46:10 --> Security Class Initialized
DEBUG - 2018-06-20 21:46:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 21:46:10 --> Input Class Initialized
INFO - 2018-06-20 21:46:10 --> Language Class Initialized
INFO - 2018-06-20 21:46:10 --> Language Class Initialized
INFO - 2018-06-20 21:46:10 --> Config Class Initialized
INFO - 2018-06-20 21:46:10 --> Loader Class Initialized
DEBUG - 2018-06-20 21:46:10 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-20 21:46:10 --> Helper loaded: url_helper
INFO - 2018-06-20 21:46:10 --> Helper loaded: form_helper
INFO - 2018-06-20 21:46:10 --> Helper loaded: date_helper
INFO - 2018-06-20 21:46:10 --> Helper loaded: util_helper
INFO - 2018-06-20 21:46:10 --> Helper loaded: text_helper
INFO - 2018-06-20 21:46:10 --> Helper loaded: string_helper
INFO - 2018-06-20 21:46:10 --> Database Driver Class Initialized
DEBUG - 2018-06-20 21:46:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 21:46:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 21:46:10 --> Email Class Initialized
INFO - 2018-06-20 21:46:10 --> Controller Class Initialized
DEBUG - 2018-06-20 21:46:10 --> videos MX_Controller Initialized
INFO - 2018-06-20 21:46:10 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-20 21:46:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-06-20 21:46:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-20 21:46:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-20 21:46:10 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-20 21:46:10 --> Login MX_Controller Initialized
DEBUG - 2018-06-20 21:46:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-20 21:46:10 --> Final output sent to browser
DEBUG - 2018-06-20 21:46:10 --> Total execution time: 0.6549
INFO - 2018-06-20 22:08:55 --> Config Class Initialized
INFO - 2018-06-20 22:08:55 --> Hooks Class Initialized
DEBUG - 2018-06-20 22:08:55 --> UTF-8 Support Enabled
INFO - 2018-06-20 22:08:55 --> Utf8 Class Initialized
INFO - 2018-06-20 22:08:55 --> URI Class Initialized
INFO - 2018-06-20 22:08:55 --> Router Class Initialized
INFO - 2018-06-20 22:08:55 --> Output Class Initialized
INFO - 2018-06-20 22:08:55 --> Security Class Initialized
DEBUG - 2018-06-20 22:08:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 22:08:55 --> Input Class Initialized
INFO - 2018-06-20 22:08:55 --> Language Class Initialized
INFO - 2018-06-20 22:08:55 --> Language Class Initialized
INFO - 2018-06-20 22:08:55 --> Config Class Initialized
INFO - 2018-06-20 22:08:55 --> Loader Class Initialized
DEBUG - 2018-06-20 22:08:55 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-20 22:08:55 --> Helper loaded: url_helper
INFO - 2018-06-20 22:08:55 --> Helper loaded: form_helper
INFO - 2018-06-20 22:08:55 --> Helper loaded: date_helper
INFO - 2018-06-20 22:08:55 --> Helper loaded: util_helper
INFO - 2018-06-20 22:08:55 --> Helper loaded: text_helper
INFO - 2018-06-20 22:08:55 --> Helper loaded: string_helper
INFO - 2018-06-20 22:08:55 --> Database Driver Class Initialized
DEBUG - 2018-06-20 22:08:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-20 22:08:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-20 22:08:55 --> Email Class Initialized
INFO - 2018-06-20 22:08:55 --> Controller Class Initialized
DEBUG - 2018-06-20 22:08:55 --> Admin MX_Controller Initialized
INFO - 2018-06-20 22:08:55 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-20 22:08:55 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-20 22:08:55 --> Login MX_Controller Initialized
DEBUG - 2018-06-20 22:08:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-20 22:08:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-20 22:08:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-20 22:08:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-20 22:08:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-20 22:08:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-20 22:08:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-20 22:08:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/dashboard.php
INFO - 2018-06-20 22:08:55 --> Final output sent to browser
DEBUG - 2018-06-20 22:08:55 --> Total execution time: 0.6430
INFO - 2018-06-20 22:08:55 --> Config Class Initialized
INFO - 2018-06-20 22:08:55 --> Hooks Class Initialized
DEBUG - 2018-06-20 22:08:56 --> UTF-8 Support Enabled
INFO - 2018-06-20 22:08:56 --> Utf8 Class Initialized
INFO - 2018-06-20 22:08:56 --> Config Class Initialized
INFO - 2018-06-20 22:08:56 --> Hooks Class Initialized
INFO - 2018-06-20 22:08:56 --> URI Class Initialized
DEBUG - 2018-06-20 22:08:56 --> UTF-8 Support Enabled
INFO - 2018-06-20 22:08:56 --> Utf8 Class Initialized
INFO - 2018-06-20 22:08:56 --> URI Class Initialized
INFO - 2018-06-20 22:08:56 --> Router Class Initialized
INFO - 2018-06-20 22:08:56 --> Router Class Initialized
INFO - 2018-06-20 22:08:56 --> Output Class Initialized
INFO - 2018-06-20 22:08:56 --> Security Class Initialized
DEBUG - 2018-06-20 22:08:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 22:08:56 --> Input Class Initialized
INFO - 2018-06-20 22:08:56 --> Language Class Initialized
ERROR - 2018-06-20 22:08:56 --> 404 Page Not Found: /index
INFO - 2018-06-20 22:08:56 --> Output Class Initialized
INFO - 2018-06-20 22:08:56 --> Security Class Initialized
DEBUG - 2018-06-20 22:08:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 22:08:56 --> Input Class Initialized
INFO - 2018-06-20 22:08:56 --> Language Class Initialized
ERROR - 2018-06-20 22:08:56 --> 404 Page Not Found: /index
INFO - 2018-06-20 22:08:56 --> Config Class Initialized
INFO - 2018-06-20 22:08:56 --> Hooks Class Initialized
DEBUG - 2018-06-20 22:08:56 --> UTF-8 Support Enabled
INFO - 2018-06-20 22:08:56 --> Utf8 Class Initialized
INFO - 2018-06-20 22:08:56 --> URI Class Initialized
INFO - 2018-06-20 22:08:56 --> Router Class Initialized
INFO - 2018-06-20 22:08:56 --> Output Class Initialized
INFO - 2018-06-20 22:08:56 --> Security Class Initialized
DEBUG - 2018-06-20 22:08:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-20 22:08:56 --> Input Class Initialized
INFO - 2018-06-20 22:08:56 --> Language Class Initialized
ERROR - 2018-06-20 22:08:56 --> 404 Page Not Found: /index
