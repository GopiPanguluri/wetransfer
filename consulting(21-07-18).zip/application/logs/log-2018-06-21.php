<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-06-21 02:41:31 --> Config Class Initialized
INFO - 2018-06-21 02:41:31 --> Hooks Class Initialized
DEBUG - 2018-06-21 02:41:31 --> UTF-8 Support Enabled
INFO - 2018-06-21 02:41:31 --> Utf8 Class Initialized
INFO - 2018-06-21 02:41:31 --> URI Class Initialized
INFO - 2018-06-21 02:41:31 --> Router Class Initialized
INFO - 2018-06-21 02:41:31 --> Output Class Initialized
INFO - 2018-06-21 02:41:31 --> Security Class Initialized
DEBUG - 2018-06-21 02:41:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 02:41:31 --> Input Class Initialized
INFO - 2018-06-21 02:41:31 --> Language Class Initialized
INFO - 2018-06-21 02:41:31 --> Language Class Initialized
INFO - 2018-06-21 02:41:31 --> Config Class Initialized
INFO - 2018-06-21 02:41:31 --> Loader Class Initialized
DEBUG - 2018-06-21 02:41:31 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 02:41:31 --> Helper loaded: url_helper
INFO - 2018-06-21 02:41:31 --> Helper loaded: form_helper
INFO - 2018-06-21 02:41:31 --> Helper loaded: date_helper
INFO - 2018-06-21 02:41:31 --> Helper loaded: util_helper
INFO - 2018-06-21 02:41:31 --> Helper loaded: text_helper
INFO - 2018-06-21 02:41:31 --> Helper loaded: string_helper
INFO - 2018-06-21 02:41:31 --> Database Driver Class Initialized
DEBUG - 2018-06-21 02:41:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 02:41:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 02:41:31 --> Email Class Initialized
INFO - 2018-06-21 02:41:31 --> Controller Class Initialized
DEBUG - 2018-06-21 02:41:31 --> Users MX_Controller Initialized
INFO - 2018-06-21 02:42:21 --> Config Class Initialized
INFO - 2018-06-21 02:42:21 --> Hooks Class Initialized
DEBUG - 2018-06-21 02:42:21 --> UTF-8 Support Enabled
INFO - 2018-06-21 02:42:21 --> Utf8 Class Initialized
INFO - 2018-06-21 02:42:21 --> URI Class Initialized
INFO - 2018-06-21 02:42:21 --> Router Class Initialized
INFO - 2018-06-21 02:42:21 --> Output Class Initialized
INFO - 2018-06-21 02:42:21 --> Security Class Initialized
DEBUG - 2018-06-21 02:42:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 02:42:21 --> Input Class Initialized
INFO - 2018-06-21 02:42:21 --> Language Class Initialized
INFO - 2018-06-21 02:42:21 --> Language Class Initialized
INFO - 2018-06-21 02:42:21 --> Config Class Initialized
INFO - 2018-06-21 02:42:21 --> Loader Class Initialized
DEBUG - 2018-06-21 02:42:21 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 02:42:21 --> Helper loaded: url_helper
INFO - 2018-06-21 02:42:21 --> Helper loaded: form_helper
INFO - 2018-06-21 02:42:21 --> Helper loaded: date_helper
INFO - 2018-06-21 02:42:21 --> Helper loaded: util_helper
INFO - 2018-06-21 02:42:21 --> Helper loaded: text_helper
INFO - 2018-06-21 02:42:21 --> Helper loaded: string_helper
INFO - 2018-06-21 02:42:21 --> Database Driver Class Initialized
DEBUG - 2018-06-21 02:42:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 02:42:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 02:42:21 --> Email Class Initialized
INFO - 2018-06-21 02:42:21 --> Controller Class Initialized
DEBUG - 2018-06-21 02:42:21 --> Users MX_Controller Initialized
ERROR - 2018-06-21 02:42:21 --> Severity: error --> Exception: Unable to locate the model you have specified: Common_model E:\xampp\htdocs\consulting\system\core\Loader.php 348
INFO - 2018-06-21 02:43:35 --> Config Class Initialized
INFO - 2018-06-21 02:43:35 --> Hooks Class Initialized
DEBUG - 2018-06-21 02:43:35 --> UTF-8 Support Enabled
INFO - 2018-06-21 02:43:35 --> Utf8 Class Initialized
INFO - 2018-06-21 02:43:35 --> URI Class Initialized
INFO - 2018-06-21 02:43:35 --> Router Class Initialized
INFO - 2018-06-21 02:43:35 --> Output Class Initialized
INFO - 2018-06-21 02:43:35 --> Security Class Initialized
DEBUG - 2018-06-21 02:43:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 02:43:35 --> Input Class Initialized
INFO - 2018-06-21 02:43:35 --> Language Class Initialized
INFO - 2018-06-21 02:43:35 --> Language Class Initialized
INFO - 2018-06-21 02:43:35 --> Config Class Initialized
INFO - 2018-06-21 02:43:35 --> Loader Class Initialized
DEBUG - 2018-06-21 02:43:35 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 02:43:35 --> Helper loaded: url_helper
INFO - 2018-06-21 02:43:35 --> Helper loaded: form_helper
INFO - 2018-06-21 02:43:35 --> Helper loaded: date_helper
INFO - 2018-06-21 02:43:35 --> Helper loaded: util_helper
INFO - 2018-06-21 02:43:35 --> Helper loaded: text_helper
INFO - 2018-06-21 02:43:35 --> Helper loaded: string_helper
INFO - 2018-06-21 02:43:35 --> Database Driver Class Initialized
DEBUG - 2018-06-21 02:43:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 02:43:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 02:43:35 --> Email Class Initialized
INFO - 2018-06-21 02:43:35 --> Controller Class Initialized
DEBUG - 2018-06-21 02:43:35 --> Users MX_Controller Initialized
DEBUG - 2018-06-21 02:43:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 02:43:35 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 02:43:35 --> Login MX_Controller Initialized
INFO - 2018-06-21 02:43:35 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 02:43:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-21 02:43:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
INFO - 2018-06-21 02:43:35 --> Config Class Initialized
INFO - 2018-06-21 02:43:35 --> Hooks Class Initialized
DEBUG - 2018-06-21 02:43:35 --> UTF-8 Support Enabled
INFO - 2018-06-21 02:43:35 --> Utf8 Class Initialized
INFO - 2018-06-21 02:43:35 --> URI Class Initialized
INFO - 2018-06-21 02:43:35 --> Router Class Initialized
INFO - 2018-06-21 02:43:35 --> Output Class Initialized
INFO - 2018-06-21 02:43:35 --> Security Class Initialized
DEBUG - 2018-06-21 02:43:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 02:43:35 --> Input Class Initialized
INFO - 2018-06-21 02:43:35 --> Language Class Initialized
ERROR - 2018-06-21 02:43:35 --> 404 Page Not Found: /index
INFO - 2018-06-21 02:43:36 --> Config Class Initialized
INFO - 2018-06-21 02:43:36 --> Hooks Class Initialized
DEBUG - 2018-06-21 02:43:36 --> UTF-8 Support Enabled
INFO - 2018-06-21 02:43:36 --> Utf8 Class Initialized
INFO - 2018-06-21 02:43:36 --> URI Class Initialized
INFO - 2018-06-21 02:43:36 --> Router Class Initialized
INFO - 2018-06-21 02:43:36 --> Output Class Initialized
INFO - 2018-06-21 02:43:36 --> Security Class Initialized
DEBUG - 2018-06-21 02:43:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 02:43:36 --> Input Class Initialized
INFO - 2018-06-21 02:43:36 --> Language Class Initialized
ERROR - 2018-06-21 02:43:36 --> 404 Page Not Found: /index
INFO - 2018-06-21 02:44:26 --> Config Class Initialized
INFO - 2018-06-21 02:44:26 --> Hooks Class Initialized
DEBUG - 2018-06-21 02:44:26 --> UTF-8 Support Enabled
INFO - 2018-06-21 02:44:26 --> Utf8 Class Initialized
INFO - 2018-06-21 02:44:26 --> URI Class Initialized
INFO - 2018-06-21 02:44:26 --> Router Class Initialized
INFO - 2018-06-21 02:44:26 --> Output Class Initialized
INFO - 2018-06-21 02:44:26 --> Security Class Initialized
DEBUG - 2018-06-21 02:44:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 02:44:26 --> Input Class Initialized
INFO - 2018-06-21 02:44:26 --> Language Class Initialized
INFO - 2018-06-21 02:44:27 --> Language Class Initialized
INFO - 2018-06-21 02:44:27 --> Config Class Initialized
INFO - 2018-06-21 02:44:27 --> Loader Class Initialized
DEBUG - 2018-06-21 02:44:27 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 02:44:27 --> Helper loaded: url_helper
INFO - 2018-06-21 02:44:27 --> Helper loaded: form_helper
INFO - 2018-06-21 02:44:27 --> Helper loaded: date_helper
INFO - 2018-06-21 02:44:27 --> Helper loaded: util_helper
INFO - 2018-06-21 02:44:27 --> Helper loaded: text_helper
INFO - 2018-06-21 02:44:27 --> Helper loaded: string_helper
INFO - 2018-06-21 02:44:27 --> Database Driver Class Initialized
DEBUG - 2018-06-21 02:44:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 02:44:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 02:44:27 --> Email Class Initialized
INFO - 2018-06-21 02:44:27 --> Controller Class Initialized
DEBUG - 2018-06-21 02:44:27 --> Admin MX_Controller Initialized
INFO - 2018-06-21 02:44:27 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 02:44:27 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 02:44:27 --> Login MX_Controller Initialized
DEBUG - 2018-06-21 02:44:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 02:44:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-21 02:44:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
INFO - 2018-06-21 02:44:29 --> Config Class Initialized
INFO - 2018-06-21 02:44:29 --> Hooks Class Initialized
DEBUG - 2018-06-21 02:44:29 --> UTF-8 Support Enabled
INFO - 2018-06-21 02:44:29 --> Utf8 Class Initialized
INFO - 2018-06-21 02:44:29 --> URI Class Initialized
INFO - 2018-06-21 02:44:29 --> Router Class Initialized
INFO - 2018-06-21 02:44:29 --> Output Class Initialized
INFO - 2018-06-21 02:44:29 --> Security Class Initialized
DEBUG - 2018-06-21 02:44:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 02:44:29 --> Input Class Initialized
INFO - 2018-06-21 02:44:29 --> Language Class Initialized
INFO - 2018-06-21 02:44:29 --> Language Class Initialized
INFO - 2018-06-21 02:44:29 --> Config Class Initialized
INFO - 2018-06-21 02:44:29 --> Loader Class Initialized
DEBUG - 2018-06-21 02:44:29 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 02:44:29 --> Helper loaded: url_helper
INFO - 2018-06-21 02:44:29 --> Helper loaded: form_helper
INFO - 2018-06-21 02:44:29 --> Helper loaded: date_helper
INFO - 2018-06-21 02:44:29 --> Helper loaded: util_helper
INFO - 2018-06-21 02:44:29 --> Helper loaded: text_helper
INFO - 2018-06-21 02:44:29 --> Helper loaded: string_helper
INFO - 2018-06-21 02:44:29 --> Database Driver Class Initialized
DEBUG - 2018-06-21 02:44:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 02:44:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 02:44:29 --> Email Class Initialized
INFO - 2018-06-21 02:44:29 --> Controller Class Initialized
DEBUG - 2018-06-21 02:44:29 --> Users MX_Controller Initialized
DEBUG - 2018-06-21 02:44:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 02:44:29 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 02:44:29 --> Login MX_Controller Initialized
INFO - 2018-06-21 02:44:29 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 02:44:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-21 02:44:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
INFO - 2018-06-21 02:44:33 --> Config Class Initialized
INFO - 2018-06-21 02:44:33 --> Hooks Class Initialized
DEBUG - 2018-06-21 02:44:33 --> UTF-8 Support Enabled
INFO - 2018-06-21 02:44:33 --> Utf8 Class Initialized
INFO - 2018-06-21 02:44:33 --> URI Class Initialized
INFO - 2018-06-21 02:44:33 --> Router Class Initialized
INFO - 2018-06-21 02:44:33 --> Output Class Initialized
INFO - 2018-06-21 02:44:33 --> Security Class Initialized
DEBUG - 2018-06-21 02:44:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 02:44:33 --> Input Class Initialized
INFO - 2018-06-21 02:44:33 --> Language Class Initialized
INFO - 2018-06-21 02:44:33 --> Language Class Initialized
INFO - 2018-06-21 02:44:33 --> Config Class Initialized
INFO - 2018-06-21 02:44:33 --> Loader Class Initialized
DEBUG - 2018-06-21 02:44:33 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 02:44:33 --> Helper loaded: url_helper
INFO - 2018-06-21 02:44:33 --> Helper loaded: form_helper
INFO - 2018-06-21 02:44:33 --> Helper loaded: date_helper
INFO - 2018-06-21 02:44:33 --> Helper loaded: util_helper
INFO - 2018-06-21 02:44:33 --> Helper loaded: text_helper
INFO - 2018-06-21 02:44:33 --> Helper loaded: string_helper
INFO - 2018-06-21 02:44:33 --> Database Driver Class Initialized
DEBUG - 2018-06-21 02:44:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 02:44:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 02:44:33 --> Email Class Initialized
INFO - 2018-06-21 02:44:33 --> Controller Class Initialized
DEBUG - 2018-06-21 02:44:33 --> Login MX_Controller Initialized
INFO - 2018-06-21 02:44:33 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 02:44:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 02:44:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-21 02:44:33 --> Email starts for admin@colin.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-06-21 02:44:33 --> User session created for 1
INFO - 2018-06-21 02:44:33 --> Login status admin@colin.com - success
INFO - 2018-06-21 02:44:33 --> Final output sent to browser
DEBUG - 2018-06-21 02:44:33 --> Total execution time: 0.3255
INFO - 2018-06-21 02:44:33 --> Config Class Initialized
INFO - 2018-06-21 02:44:33 --> Hooks Class Initialized
DEBUG - 2018-06-21 02:44:33 --> UTF-8 Support Enabled
INFO - 2018-06-21 02:44:33 --> Utf8 Class Initialized
INFO - 2018-06-21 02:44:33 --> URI Class Initialized
INFO - 2018-06-21 02:44:33 --> Router Class Initialized
INFO - 2018-06-21 02:44:33 --> Output Class Initialized
INFO - 2018-06-21 02:44:33 --> Security Class Initialized
DEBUG - 2018-06-21 02:44:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 02:44:33 --> Input Class Initialized
INFO - 2018-06-21 02:44:33 --> Language Class Initialized
INFO - 2018-06-21 02:44:33 --> Language Class Initialized
INFO - 2018-06-21 02:44:33 --> Config Class Initialized
INFO - 2018-06-21 02:44:33 --> Loader Class Initialized
DEBUG - 2018-06-21 02:44:33 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 02:44:33 --> Helper loaded: url_helper
INFO - 2018-06-21 02:44:33 --> Helper loaded: form_helper
INFO - 2018-06-21 02:44:33 --> Helper loaded: date_helper
INFO - 2018-06-21 02:44:33 --> Helper loaded: util_helper
INFO - 2018-06-21 02:44:33 --> Helper loaded: text_helper
INFO - 2018-06-21 02:44:33 --> Helper loaded: string_helper
INFO - 2018-06-21 02:44:33 --> Database Driver Class Initialized
DEBUG - 2018-06-21 02:44:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 02:44:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 02:44:33 --> Email Class Initialized
INFO - 2018-06-21 02:44:33 --> Controller Class Initialized
DEBUG - 2018-06-21 02:44:33 --> Users MX_Controller Initialized
DEBUG - 2018-06-21 02:44:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 02:44:33 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 02:44:33 --> Login MX_Controller Initialized
INFO - 2018-06-21 02:44:33 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 02:44:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-21 02:45:48 --> Config Class Initialized
INFO - 2018-06-21 02:45:48 --> Hooks Class Initialized
DEBUG - 2018-06-21 02:45:48 --> UTF-8 Support Enabled
INFO - 2018-06-21 02:45:48 --> Utf8 Class Initialized
INFO - 2018-06-21 02:45:48 --> URI Class Initialized
INFO - 2018-06-21 02:45:48 --> Router Class Initialized
INFO - 2018-06-21 02:45:48 --> Output Class Initialized
INFO - 2018-06-21 02:45:48 --> Security Class Initialized
DEBUG - 2018-06-21 02:45:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 02:45:48 --> Input Class Initialized
INFO - 2018-06-21 02:45:48 --> Language Class Initialized
INFO - 2018-06-21 02:45:48 --> Language Class Initialized
INFO - 2018-06-21 02:45:48 --> Config Class Initialized
INFO - 2018-06-21 02:45:48 --> Loader Class Initialized
DEBUG - 2018-06-21 02:45:48 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 02:45:48 --> Helper loaded: url_helper
INFO - 2018-06-21 02:45:48 --> Helper loaded: form_helper
INFO - 2018-06-21 02:45:48 --> Helper loaded: date_helper
INFO - 2018-06-21 02:45:48 --> Helper loaded: util_helper
INFO - 2018-06-21 02:45:48 --> Helper loaded: text_helper
INFO - 2018-06-21 02:45:48 --> Helper loaded: string_helper
INFO - 2018-06-21 02:45:48 --> Database Driver Class Initialized
DEBUG - 2018-06-21 02:45:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 02:45:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 02:45:48 --> Email Class Initialized
INFO - 2018-06-21 02:45:48 --> Controller Class Initialized
DEBUG - 2018-06-21 02:45:48 --> Users MX_Controller Initialized
DEBUG - 2018-06-21 02:45:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 02:45:48 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 02:45:48 --> Login MX_Controller Initialized
INFO - 2018-06-21 02:45:48 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 02:45:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-21 02:45:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-21 02:45:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-21 02:45:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
INFO - 2018-06-21 02:46:26 --> Config Class Initialized
INFO - 2018-06-21 02:46:26 --> Hooks Class Initialized
DEBUG - 2018-06-21 02:46:26 --> UTF-8 Support Enabled
INFO - 2018-06-21 02:46:26 --> Utf8 Class Initialized
INFO - 2018-06-21 02:46:26 --> URI Class Initialized
INFO - 2018-06-21 02:46:26 --> Router Class Initialized
INFO - 2018-06-21 02:46:26 --> Output Class Initialized
INFO - 2018-06-21 02:46:26 --> Security Class Initialized
DEBUG - 2018-06-21 02:46:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 02:46:26 --> Input Class Initialized
INFO - 2018-06-21 02:46:26 --> Language Class Initialized
INFO - 2018-06-21 02:46:26 --> Language Class Initialized
INFO - 2018-06-21 02:46:26 --> Config Class Initialized
INFO - 2018-06-21 02:46:26 --> Loader Class Initialized
DEBUG - 2018-06-21 02:46:26 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 02:46:26 --> Helper loaded: url_helper
INFO - 2018-06-21 02:46:26 --> Helper loaded: form_helper
INFO - 2018-06-21 02:46:26 --> Helper loaded: date_helper
INFO - 2018-06-21 02:46:26 --> Helper loaded: util_helper
INFO - 2018-06-21 02:46:26 --> Helper loaded: text_helper
INFO - 2018-06-21 02:46:26 --> Helper loaded: string_helper
INFO - 2018-06-21 02:46:26 --> Database Driver Class Initialized
DEBUG - 2018-06-21 02:46:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 02:46:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 02:46:26 --> Email Class Initialized
INFO - 2018-06-21 02:46:26 --> Controller Class Initialized
DEBUG - 2018-06-21 02:46:26 --> Users MX_Controller Initialized
DEBUG - 2018-06-21 02:46:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 02:46:26 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 02:46:26 --> Login MX_Controller Initialized
INFO - 2018-06-21 02:46:26 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 02:46:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-21 02:46:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-21 02:46:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-21 02:46:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-21 02:46:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-21 02:46:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-21 02:46:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-06-21 02:46:26 --> Final output sent to browser
DEBUG - 2018-06-21 02:46:26 --> Total execution time: 0.3649
INFO - 2018-06-21 02:46:27 --> Config Class Initialized
INFO - 2018-06-21 02:46:27 --> Hooks Class Initialized
DEBUG - 2018-06-21 02:46:27 --> UTF-8 Support Enabled
INFO - 2018-06-21 02:46:27 --> Utf8 Class Initialized
INFO - 2018-06-21 02:46:27 --> URI Class Initialized
INFO - 2018-06-21 02:46:27 --> Router Class Initialized
INFO - 2018-06-21 02:46:27 --> Output Class Initialized
INFO - 2018-06-21 02:46:27 --> Security Class Initialized
DEBUG - 2018-06-21 02:46:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 02:46:27 --> Input Class Initialized
INFO - 2018-06-21 02:46:27 --> Language Class Initialized
INFO - 2018-06-21 02:46:27 --> Language Class Initialized
INFO - 2018-06-21 02:46:27 --> Config Class Initialized
INFO - 2018-06-21 02:46:27 --> Loader Class Initialized
DEBUG - 2018-06-21 02:46:27 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 02:46:27 --> Helper loaded: url_helper
INFO - 2018-06-21 02:46:27 --> Helper loaded: form_helper
INFO - 2018-06-21 02:46:27 --> Helper loaded: date_helper
INFO - 2018-06-21 02:46:27 --> Helper loaded: util_helper
INFO - 2018-06-21 02:46:27 --> Helper loaded: text_helper
INFO - 2018-06-21 02:46:27 --> Helper loaded: string_helper
INFO - 2018-06-21 02:46:27 --> Database Driver Class Initialized
DEBUG - 2018-06-21 02:46:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 02:46:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 02:46:27 --> Email Class Initialized
INFO - 2018-06-21 02:46:27 --> Controller Class Initialized
DEBUG - 2018-06-21 02:46:27 --> Users MX_Controller Initialized
DEBUG - 2018-06-21 02:46:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 02:46:27 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 02:46:27 --> Login MX_Controller Initialized
INFO - 2018-06-21 02:46:27 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 02:46:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-21 02:46:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
ERROR - 2018-06-21 02:46:27 --> Query error: Table 'consulting.user_roles' doesn't exist - Invalid query: SELECT  users.user_id,users.name,users.image,user_roles.ur_name,users.created_on,users.status,users.user_id FROM   users join user_roles on users.role_id=user_roles.ur_id  WHERE users.user_id  != ''     LIMIT 0, 10
INFO - 2018-06-21 02:46:27 --> Language file loaded: language/english/db_lang.php
INFO - 2018-06-21 02:46:36 --> Config Class Initialized
INFO - 2018-06-21 02:46:36 --> Hooks Class Initialized
DEBUG - 2018-06-21 02:46:36 --> UTF-8 Support Enabled
INFO - 2018-06-21 02:46:36 --> Utf8 Class Initialized
INFO - 2018-06-21 02:46:36 --> URI Class Initialized
INFO - 2018-06-21 02:46:36 --> Router Class Initialized
INFO - 2018-06-21 02:46:36 --> Output Class Initialized
INFO - 2018-06-21 02:46:36 --> Security Class Initialized
DEBUG - 2018-06-21 02:46:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 02:46:36 --> Input Class Initialized
INFO - 2018-06-21 02:46:36 --> Language Class Initialized
INFO - 2018-06-21 02:46:36 --> Language Class Initialized
INFO - 2018-06-21 02:46:36 --> Config Class Initialized
INFO - 2018-06-21 02:46:36 --> Loader Class Initialized
DEBUG - 2018-06-21 02:46:36 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 02:46:36 --> Helper loaded: url_helper
INFO - 2018-06-21 02:46:36 --> Helper loaded: form_helper
INFO - 2018-06-21 02:46:36 --> Helper loaded: date_helper
INFO - 2018-06-21 02:46:36 --> Helper loaded: util_helper
INFO - 2018-06-21 02:46:36 --> Helper loaded: text_helper
INFO - 2018-06-21 02:46:36 --> Helper loaded: string_helper
INFO - 2018-06-21 02:46:36 --> Database Driver Class Initialized
DEBUG - 2018-06-21 02:46:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 02:46:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 02:46:36 --> Email Class Initialized
INFO - 2018-06-21 02:46:36 --> Controller Class Initialized
DEBUG - 2018-06-21 02:46:36 --> Users MX_Controller Initialized
DEBUG - 2018-06-21 02:46:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 02:46:36 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 02:46:36 --> Login MX_Controller Initialized
INFO - 2018-06-21 02:46:36 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 02:46:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-21 02:46:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
ERROR - 2018-06-21 02:46:36 --> Query error: Table 'consulting.user_roles' doesn't exist - Invalid query: SELECT  users.user_id,users.name,users.image,user_roles.ur_name,users.created_on,users.status,users.user_id FROM   users join user_roles on users.role_id=user_roles.ur_id  WHERE users.user_id  != ''     
INFO - 2018-06-21 02:46:36 --> Language file loaded: language/english/db_lang.php
INFO - 2018-06-21 02:48:04 --> Config Class Initialized
INFO - 2018-06-21 02:48:04 --> Hooks Class Initialized
DEBUG - 2018-06-21 02:48:04 --> UTF-8 Support Enabled
INFO - 2018-06-21 02:48:04 --> Utf8 Class Initialized
INFO - 2018-06-21 02:48:04 --> URI Class Initialized
INFO - 2018-06-21 02:48:04 --> Router Class Initialized
INFO - 2018-06-21 02:48:04 --> Output Class Initialized
INFO - 2018-06-21 02:48:04 --> Security Class Initialized
DEBUG - 2018-06-21 02:48:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 02:48:04 --> Input Class Initialized
INFO - 2018-06-21 02:48:04 --> Language Class Initialized
INFO - 2018-06-21 02:48:04 --> Language Class Initialized
INFO - 2018-06-21 02:48:04 --> Config Class Initialized
INFO - 2018-06-21 02:48:04 --> Loader Class Initialized
DEBUG - 2018-06-21 02:48:04 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 02:48:04 --> Helper loaded: url_helper
INFO - 2018-06-21 02:48:04 --> Helper loaded: form_helper
INFO - 2018-06-21 02:48:04 --> Helper loaded: date_helper
INFO - 2018-06-21 02:48:04 --> Helper loaded: util_helper
INFO - 2018-06-21 02:48:04 --> Helper loaded: text_helper
INFO - 2018-06-21 02:48:04 --> Helper loaded: string_helper
INFO - 2018-06-21 02:48:04 --> Database Driver Class Initialized
DEBUG - 2018-06-21 02:48:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 02:48:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 02:48:04 --> Email Class Initialized
INFO - 2018-06-21 02:48:04 --> Controller Class Initialized
DEBUG - 2018-06-21 02:48:04 --> Users MX_Controller Initialized
DEBUG - 2018-06-21 02:48:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 02:48:04 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 02:48:04 --> Login MX_Controller Initialized
INFO - 2018-06-21 02:48:04 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 02:48:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-21 02:48:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
ERROR - 2018-06-21 02:48:04 --> Query error: Unknown column 'users.name' in 'field list' - Invalid query: SELECT  users.user_id,users.name,users.image,user_roles.ur_name,users.created_on,users.status,users.user_id FROM   users join user_roles on users.role_id=user_roles.ur_id  WHERE users.user_id  != ''     
INFO - 2018-06-21 02:48:04 --> Language file loaded: language/english/db_lang.php
INFO - 2018-06-21 02:48:41 --> Config Class Initialized
INFO - 2018-06-21 02:48:41 --> Hooks Class Initialized
DEBUG - 2018-06-21 02:48:41 --> UTF-8 Support Enabled
INFO - 2018-06-21 02:48:41 --> Utf8 Class Initialized
INFO - 2018-06-21 02:48:41 --> URI Class Initialized
INFO - 2018-06-21 02:48:41 --> Router Class Initialized
INFO - 2018-06-21 02:48:41 --> Output Class Initialized
INFO - 2018-06-21 02:48:41 --> Security Class Initialized
DEBUG - 2018-06-21 02:48:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 02:48:42 --> Input Class Initialized
INFO - 2018-06-21 02:48:42 --> Language Class Initialized
INFO - 2018-06-21 02:48:42 --> Language Class Initialized
INFO - 2018-06-21 02:48:42 --> Config Class Initialized
INFO - 2018-06-21 02:48:42 --> Loader Class Initialized
DEBUG - 2018-06-21 02:48:42 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 02:48:42 --> Helper loaded: url_helper
INFO - 2018-06-21 02:48:42 --> Helper loaded: form_helper
INFO - 2018-06-21 02:48:42 --> Helper loaded: date_helper
INFO - 2018-06-21 02:48:42 --> Helper loaded: util_helper
INFO - 2018-06-21 02:48:42 --> Helper loaded: text_helper
INFO - 2018-06-21 02:48:42 --> Helper loaded: string_helper
INFO - 2018-06-21 02:48:42 --> Database Driver Class Initialized
DEBUG - 2018-06-21 02:48:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 02:48:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 02:48:42 --> Email Class Initialized
INFO - 2018-06-21 02:48:42 --> Controller Class Initialized
DEBUG - 2018-06-21 02:48:42 --> Users MX_Controller Initialized
DEBUG - 2018-06-21 02:48:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 02:48:42 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 02:48:42 --> Login MX_Controller Initialized
INFO - 2018-06-21 02:48:42 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 02:48:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-21 02:48:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
ERROR - 2018-06-21 02:48:42 --> Severity: Notice --> Undefined index: sEcho E:\xampp\htdocs\consulting\system\database\DB_query_builder.php 2920
INFO - 2018-06-21 02:48:42 --> Final output sent to browser
DEBUG - 2018-06-21 02:48:42 --> Total execution time: 0.3571
INFO - 2018-06-21 02:48:45 --> Config Class Initialized
INFO - 2018-06-21 02:48:45 --> Hooks Class Initialized
DEBUG - 2018-06-21 02:48:45 --> UTF-8 Support Enabled
INFO - 2018-06-21 02:48:45 --> Utf8 Class Initialized
INFO - 2018-06-21 02:48:45 --> URI Class Initialized
INFO - 2018-06-21 02:48:45 --> Router Class Initialized
INFO - 2018-06-21 02:48:45 --> Output Class Initialized
INFO - 2018-06-21 02:48:45 --> Security Class Initialized
DEBUG - 2018-06-21 02:48:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 02:48:45 --> Input Class Initialized
INFO - 2018-06-21 02:48:45 --> Language Class Initialized
INFO - 2018-06-21 02:48:45 --> Language Class Initialized
INFO - 2018-06-21 02:48:45 --> Config Class Initialized
INFO - 2018-06-21 02:48:45 --> Loader Class Initialized
DEBUG - 2018-06-21 02:48:45 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 02:48:45 --> Helper loaded: url_helper
INFO - 2018-06-21 02:48:45 --> Helper loaded: form_helper
INFO - 2018-06-21 02:48:45 --> Helper loaded: date_helper
INFO - 2018-06-21 02:48:45 --> Helper loaded: util_helper
INFO - 2018-06-21 02:48:45 --> Helper loaded: text_helper
INFO - 2018-06-21 02:48:45 --> Helper loaded: string_helper
INFO - 2018-06-21 02:48:46 --> Database Driver Class Initialized
DEBUG - 2018-06-21 02:48:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 02:48:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 02:48:46 --> Email Class Initialized
INFO - 2018-06-21 02:48:46 --> Controller Class Initialized
DEBUG - 2018-06-21 02:48:46 --> Users MX_Controller Initialized
DEBUG - 2018-06-21 02:48:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 02:48:46 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 02:48:46 --> Login MX_Controller Initialized
INFO - 2018-06-21 02:48:46 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 02:48:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-21 02:48:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-21 02:48:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-21 02:48:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-21 02:48:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-21 02:48:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-21 02:48:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-06-21 02:48:46 --> Final output sent to browser
DEBUG - 2018-06-21 02:48:46 --> Total execution time: 0.4485
INFO - 2018-06-21 02:48:47 --> Config Class Initialized
INFO - 2018-06-21 02:48:47 --> Hooks Class Initialized
DEBUG - 2018-06-21 02:48:47 --> UTF-8 Support Enabled
INFO - 2018-06-21 02:48:47 --> Utf8 Class Initialized
INFO - 2018-06-21 02:48:47 --> URI Class Initialized
INFO - 2018-06-21 02:48:47 --> Router Class Initialized
INFO - 2018-06-21 02:48:47 --> Output Class Initialized
INFO - 2018-06-21 02:48:47 --> Security Class Initialized
DEBUG - 2018-06-21 02:48:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 02:48:47 --> Input Class Initialized
INFO - 2018-06-21 02:48:47 --> Language Class Initialized
INFO - 2018-06-21 02:48:47 --> Language Class Initialized
INFO - 2018-06-21 02:48:47 --> Config Class Initialized
INFO - 2018-06-21 02:48:47 --> Loader Class Initialized
DEBUG - 2018-06-21 02:48:47 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 02:48:47 --> Helper loaded: url_helper
INFO - 2018-06-21 02:48:47 --> Helper loaded: form_helper
INFO - 2018-06-21 02:48:47 --> Helper loaded: date_helper
INFO - 2018-06-21 02:48:47 --> Helper loaded: util_helper
INFO - 2018-06-21 02:48:47 --> Helper loaded: text_helper
INFO - 2018-06-21 02:48:47 --> Helper loaded: string_helper
INFO - 2018-06-21 02:48:47 --> Database Driver Class Initialized
DEBUG - 2018-06-21 02:48:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 02:48:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 02:48:47 --> Email Class Initialized
INFO - 2018-06-21 02:48:47 --> Controller Class Initialized
DEBUG - 2018-06-21 02:48:47 --> Users MX_Controller Initialized
DEBUG - 2018-06-21 02:48:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 02:48:47 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 02:48:47 --> Login MX_Controller Initialized
INFO - 2018-06-21 02:48:47 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 02:48:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-21 02:48:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-06-21 02:48:48 --> Final output sent to browser
DEBUG - 2018-06-21 02:48:48 --> Total execution time: 0.6435
INFO - 2018-06-21 02:52:50 --> Config Class Initialized
INFO - 2018-06-21 02:52:50 --> Hooks Class Initialized
DEBUG - 2018-06-21 02:52:50 --> UTF-8 Support Enabled
INFO - 2018-06-21 02:52:50 --> Utf8 Class Initialized
INFO - 2018-06-21 02:52:50 --> URI Class Initialized
INFO - 2018-06-21 02:52:50 --> Router Class Initialized
INFO - 2018-06-21 02:52:50 --> Output Class Initialized
INFO - 2018-06-21 02:52:50 --> Security Class Initialized
DEBUG - 2018-06-21 02:52:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 02:52:50 --> Input Class Initialized
INFO - 2018-06-21 02:52:50 --> Language Class Initialized
INFO - 2018-06-21 02:52:50 --> Language Class Initialized
INFO - 2018-06-21 02:52:50 --> Config Class Initialized
INFO - 2018-06-21 02:52:50 --> Loader Class Initialized
DEBUG - 2018-06-21 02:52:50 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 02:52:50 --> Helper loaded: url_helper
INFO - 2018-06-21 02:52:50 --> Helper loaded: form_helper
INFO - 2018-06-21 02:52:50 --> Helper loaded: date_helper
INFO - 2018-06-21 02:52:50 --> Helper loaded: util_helper
INFO - 2018-06-21 02:52:50 --> Helper loaded: text_helper
INFO - 2018-06-21 02:52:50 --> Helper loaded: string_helper
INFO - 2018-06-21 02:52:50 --> Database Driver Class Initialized
DEBUG - 2018-06-21 02:52:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 02:52:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 02:52:50 --> Email Class Initialized
INFO - 2018-06-21 02:52:50 --> Controller Class Initialized
DEBUG - 2018-06-21 02:52:50 --> Login MX_Controller Initialized
INFO - 2018-06-21 02:52:50 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 02:52:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 02:52:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
ERROR - 2018-06-21 02:52:51 --> Severity: Notice --> Undefined index: home_user_id E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php 517
INFO - 2018-06-21 02:52:51 --> Config Class Initialized
INFO - 2018-06-21 02:52:51 --> Hooks Class Initialized
DEBUG - 2018-06-21 02:52:51 --> UTF-8 Support Enabled
INFO - 2018-06-21 02:52:51 --> Utf8 Class Initialized
INFO - 2018-06-21 02:52:51 --> URI Class Initialized
INFO - 2018-06-21 02:52:51 --> Router Class Initialized
INFO - 2018-06-21 02:52:51 --> Output Class Initialized
INFO - 2018-06-21 02:52:51 --> Security Class Initialized
DEBUG - 2018-06-21 02:52:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 02:52:51 --> Input Class Initialized
INFO - 2018-06-21 02:52:51 --> Language Class Initialized
INFO - 2018-06-21 02:52:51 --> Language Class Initialized
INFO - 2018-06-21 02:52:51 --> Config Class Initialized
INFO - 2018-06-21 02:52:51 --> Loader Class Initialized
DEBUG - 2018-06-21 02:52:51 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 02:52:51 --> Helper loaded: url_helper
INFO - 2018-06-21 02:52:51 --> Helper loaded: form_helper
INFO - 2018-06-21 02:52:51 --> Helper loaded: date_helper
INFO - 2018-06-21 02:52:51 --> Helper loaded: util_helper
INFO - 2018-06-21 02:52:51 --> Helper loaded: text_helper
INFO - 2018-06-21 02:52:51 --> Helper loaded: string_helper
INFO - 2018-06-21 02:52:51 --> Database Driver Class Initialized
DEBUG - 2018-06-21 02:52:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 02:52:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 02:52:51 --> Email Class Initialized
INFO - 2018-06-21 02:52:51 --> Controller Class Initialized
DEBUG - 2018-06-21 02:52:51 --> Home MX_Controller Initialized
DEBUG - 2018-06-21 02:52:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-21 02:52:51 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 02:52:51 --> Login MX_Controller Initialized
INFO - 2018-06-21 02:52:51 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 02:52:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 02:52:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-21 02:52:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-06-21 02:53:01 --> Config Class Initialized
INFO - 2018-06-21 02:53:01 --> Hooks Class Initialized
DEBUG - 2018-06-21 02:53:01 --> UTF-8 Support Enabled
INFO - 2018-06-21 02:53:01 --> Utf8 Class Initialized
INFO - 2018-06-21 02:53:01 --> URI Class Initialized
INFO - 2018-06-21 02:53:01 --> Router Class Initialized
INFO - 2018-06-21 02:53:01 --> Output Class Initialized
INFO - 2018-06-21 02:53:01 --> Security Class Initialized
DEBUG - 2018-06-21 02:53:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 02:53:01 --> Input Class Initialized
INFO - 2018-06-21 02:53:01 --> Language Class Initialized
INFO - 2018-06-21 02:53:01 --> Language Class Initialized
INFO - 2018-06-21 02:53:01 --> Config Class Initialized
INFO - 2018-06-21 02:53:01 --> Loader Class Initialized
DEBUG - 2018-06-21 02:53:01 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 02:53:01 --> Helper loaded: url_helper
INFO - 2018-06-21 02:53:01 --> Helper loaded: form_helper
INFO - 2018-06-21 02:53:01 --> Helper loaded: date_helper
INFO - 2018-06-21 02:53:01 --> Helper loaded: util_helper
INFO - 2018-06-21 02:53:01 --> Helper loaded: text_helper
INFO - 2018-06-21 02:53:01 --> Helper loaded: string_helper
INFO - 2018-06-21 02:53:01 --> Database Driver Class Initialized
DEBUG - 2018-06-21 02:53:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 02:53:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 02:53:01 --> Email Class Initialized
INFO - 2018-06-21 02:53:01 --> Controller Class Initialized
DEBUG - 2018-06-21 02:53:01 --> Home MX_Controller Initialized
DEBUG - 2018-06-21 02:53:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-21 02:53:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/register.php
INFO - 2018-06-21 02:53:01 --> Final output sent to browser
DEBUG - 2018-06-21 02:53:02 --> Total execution time: 0.2930
INFO - 2018-06-21 02:59:52 --> Config Class Initialized
INFO - 2018-06-21 02:59:52 --> Hooks Class Initialized
DEBUG - 2018-06-21 02:59:52 --> UTF-8 Support Enabled
INFO - 2018-06-21 02:59:52 --> Utf8 Class Initialized
INFO - 2018-06-21 02:59:52 --> URI Class Initialized
INFO - 2018-06-21 02:59:52 --> Router Class Initialized
INFO - 2018-06-21 02:59:52 --> Output Class Initialized
INFO - 2018-06-21 02:59:52 --> Security Class Initialized
DEBUG - 2018-06-21 02:59:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 02:59:52 --> Input Class Initialized
INFO - 2018-06-21 02:59:52 --> Language Class Initialized
INFO - 2018-06-21 02:59:52 --> Language Class Initialized
INFO - 2018-06-21 02:59:52 --> Config Class Initialized
INFO - 2018-06-21 02:59:52 --> Loader Class Initialized
DEBUG - 2018-06-21 02:59:52 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 02:59:52 --> Helper loaded: url_helper
INFO - 2018-06-21 02:59:52 --> Helper loaded: form_helper
INFO - 2018-06-21 02:59:52 --> Helper loaded: date_helper
INFO - 2018-06-21 02:59:52 --> Helper loaded: util_helper
INFO - 2018-06-21 02:59:52 --> Helper loaded: text_helper
INFO - 2018-06-21 02:59:52 --> Helper loaded: string_helper
INFO - 2018-06-21 02:59:52 --> Database Driver Class Initialized
DEBUG - 2018-06-21 02:59:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 02:59:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 02:59:53 --> Email Class Initialized
INFO - 2018-06-21 02:59:53 --> Controller Class Initialized
DEBUG - 2018-06-21 02:59:53 --> Home MX_Controller Initialized
DEBUG - 2018-06-21 02:59:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-21 02:59:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/register.php
INFO - 2018-06-21 02:59:53 --> Final output sent to browser
DEBUG - 2018-06-21 02:59:53 --> Total execution time: 0.2966
INFO - 2018-06-21 03:00:03 --> Config Class Initialized
INFO - 2018-06-21 03:00:03 --> Hooks Class Initialized
DEBUG - 2018-06-21 03:00:04 --> UTF-8 Support Enabled
INFO - 2018-06-21 03:00:04 --> Utf8 Class Initialized
INFO - 2018-06-21 03:00:04 --> URI Class Initialized
INFO - 2018-06-21 03:00:04 --> Router Class Initialized
INFO - 2018-06-21 03:00:04 --> Output Class Initialized
INFO - 2018-06-21 03:00:04 --> Security Class Initialized
DEBUG - 2018-06-21 03:00:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 03:00:04 --> Input Class Initialized
INFO - 2018-06-21 03:00:04 --> Language Class Initialized
INFO - 2018-06-21 03:00:04 --> Language Class Initialized
INFO - 2018-06-21 03:00:04 --> Config Class Initialized
INFO - 2018-06-21 03:00:04 --> Loader Class Initialized
DEBUG - 2018-06-21 03:00:04 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 03:00:04 --> Helper loaded: url_helper
INFO - 2018-06-21 03:00:04 --> Helper loaded: form_helper
INFO - 2018-06-21 03:00:04 --> Helper loaded: date_helper
INFO - 2018-06-21 03:00:04 --> Helper loaded: util_helper
INFO - 2018-06-21 03:00:04 --> Helper loaded: text_helper
INFO - 2018-06-21 03:00:04 --> Helper loaded: string_helper
INFO - 2018-06-21 03:00:04 --> Database Driver Class Initialized
DEBUG - 2018-06-21 03:00:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 03:00:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 03:00:04 --> Email Class Initialized
INFO - 2018-06-21 03:00:04 --> Controller Class Initialized
DEBUG - 2018-06-21 03:00:04 --> Home MX_Controller Initialized
DEBUG - 2018-06-21 03:00:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-21 03:00:04 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 03:00:04 --> Login MX_Controller Initialized
INFO - 2018-06-21 03:00:04 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 03:00:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 03:00:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-21 03:00:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-06-21 03:00:07 --> Config Class Initialized
INFO - 2018-06-21 03:00:07 --> Hooks Class Initialized
DEBUG - 2018-06-21 03:00:07 --> UTF-8 Support Enabled
INFO - 2018-06-21 03:00:07 --> Utf8 Class Initialized
INFO - 2018-06-21 03:00:07 --> URI Class Initialized
INFO - 2018-06-21 03:00:07 --> Router Class Initialized
INFO - 2018-06-21 03:00:07 --> Output Class Initialized
INFO - 2018-06-21 03:00:07 --> Security Class Initialized
DEBUG - 2018-06-21 03:00:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 03:00:07 --> Input Class Initialized
INFO - 2018-06-21 03:00:07 --> Language Class Initialized
INFO - 2018-06-21 03:00:07 --> Language Class Initialized
INFO - 2018-06-21 03:00:07 --> Config Class Initialized
INFO - 2018-06-21 03:00:07 --> Loader Class Initialized
DEBUG - 2018-06-21 03:00:07 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 03:00:07 --> Helper loaded: url_helper
INFO - 2018-06-21 03:00:07 --> Helper loaded: form_helper
INFO - 2018-06-21 03:00:07 --> Helper loaded: date_helper
INFO - 2018-06-21 03:00:07 --> Helper loaded: util_helper
INFO - 2018-06-21 03:00:07 --> Helper loaded: text_helper
INFO - 2018-06-21 03:00:07 --> Helper loaded: string_helper
INFO - 2018-06-21 03:00:07 --> Database Driver Class Initialized
DEBUG - 2018-06-21 03:00:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 03:00:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 03:00:07 --> Email Class Initialized
INFO - 2018-06-21 03:00:07 --> Controller Class Initialized
DEBUG - 2018-06-21 03:00:07 --> Login MX_Controller Initialized
INFO - 2018-06-21 03:00:07 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 03:00:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 03:00:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-21 03:00:07 --> Email starts for gopipanguluri123@gmail.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-06-21 03:00:07 --> Login status gopipanguluri123@gmail.com - failure
INFO - 2018-06-21 03:00:07 --> Final output sent to browser
DEBUG - 2018-06-21 03:00:07 --> Total execution time: 0.3014
INFO - 2018-06-21 03:00:36 --> Config Class Initialized
INFO - 2018-06-21 03:00:36 --> Hooks Class Initialized
DEBUG - 2018-06-21 03:00:36 --> UTF-8 Support Enabled
INFO - 2018-06-21 03:00:36 --> Utf8 Class Initialized
INFO - 2018-06-21 03:00:36 --> URI Class Initialized
INFO - 2018-06-21 03:00:36 --> Router Class Initialized
INFO - 2018-06-21 03:00:36 --> Output Class Initialized
INFO - 2018-06-21 03:00:36 --> Security Class Initialized
DEBUG - 2018-06-21 03:00:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 03:00:36 --> Input Class Initialized
INFO - 2018-06-21 03:00:36 --> Language Class Initialized
INFO - 2018-06-21 03:00:36 --> Language Class Initialized
INFO - 2018-06-21 03:00:36 --> Config Class Initialized
INFO - 2018-06-21 03:00:36 --> Loader Class Initialized
DEBUG - 2018-06-21 03:00:36 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 03:00:36 --> Helper loaded: url_helper
INFO - 2018-06-21 03:00:36 --> Helper loaded: form_helper
INFO - 2018-06-21 03:00:36 --> Helper loaded: date_helper
INFO - 2018-06-21 03:00:36 --> Helper loaded: util_helper
INFO - 2018-06-21 03:00:36 --> Helper loaded: text_helper
INFO - 2018-06-21 03:00:36 --> Helper loaded: string_helper
INFO - 2018-06-21 03:00:36 --> Database Driver Class Initialized
DEBUG - 2018-06-21 03:00:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 03:00:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 03:00:36 --> Email Class Initialized
INFO - 2018-06-21 03:00:36 --> Controller Class Initialized
DEBUG - 2018-06-21 03:00:36 --> Users MX_Controller Initialized
DEBUG - 2018-06-21 03:00:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 03:00:36 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 03:00:36 --> Login MX_Controller Initialized
INFO - 2018-06-21 03:00:36 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 03:00:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-21 03:00:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-06-21 03:00:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-21 03:00:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-21 03:00:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
INFO - 2018-06-21 03:01:06 --> Config Class Initialized
INFO - 2018-06-21 03:01:06 --> Hooks Class Initialized
DEBUG - 2018-06-21 03:01:06 --> UTF-8 Support Enabled
INFO - 2018-06-21 03:01:06 --> Utf8 Class Initialized
INFO - 2018-06-21 03:01:06 --> URI Class Initialized
INFO - 2018-06-21 03:01:06 --> Router Class Initialized
INFO - 2018-06-21 03:01:06 --> Output Class Initialized
INFO - 2018-06-21 03:01:06 --> Security Class Initialized
DEBUG - 2018-06-21 03:01:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 03:01:06 --> Input Class Initialized
INFO - 2018-06-21 03:01:06 --> Language Class Initialized
INFO - 2018-06-21 03:01:06 --> Language Class Initialized
INFO - 2018-06-21 03:01:06 --> Config Class Initialized
INFO - 2018-06-21 03:01:06 --> Loader Class Initialized
DEBUG - 2018-06-21 03:01:06 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 03:01:06 --> Helper loaded: url_helper
INFO - 2018-06-21 03:01:06 --> Helper loaded: form_helper
INFO - 2018-06-21 03:01:06 --> Helper loaded: date_helper
INFO - 2018-06-21 03:01:06 --> Helper loaded: util_helper
INFO - 2018-06-21 03:01:06 --> Helper loaded: text_helper
INFO - 2018-06-21 03:01:06 --> Helper loaded: string_helper
INFO - 2018-06-21 03:01:06 --> Database Driver Class Initialized
DEBUG - 2018-06-21 03:01:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 03:01:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 03:01:06 --> Email Class Initialized
INFO - 2018-06-21 03:01:06 --> Controller Class Initialized
DEBUG - 2018-06-21 03:01:06 --> Users MX_Controller Initialized
DEBUG - 2018-06-21 03:01:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 03:01:06 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 03:01:06 --> Login MX_Controller Initialized
INFO - 2018-06-21 03:01:06 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 03:01:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-21 03:01:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-06-21 03:01:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-21 03:01:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-21 03:01:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-21 03:01:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-21 03:01:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-21 03:01:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-06-21 03:01:06 --> Final output sent to browser
DEBUG - 2018-06-21 03:01:06 --> Total execution time: 0.4190
INFO - 2018-06-21 03:01:22 --> Config Class Initialized
INFO - 2018-06-21 03:01:22 --> Hooks Class Initialized
DEBUG - 2018-06-21 03:01:22 --> UTF-8 Support Enabled
INFO - 2018-06-21 03:01:22 --> Utf8 Class Initialized
INFO - 2018-06-21 03:01:22 --> URI Class Initialized
INFO - 2018-06-21 03:01:22 --> Router Class Initialized
INFO - 2018-06-21 03:01:22 --> Output Class Initialized
INFO - 2018-06-21 03:01:22 --> Security Class Initialized
DEBUG - 2018-06-21 03:01:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 03:01:22 --> Input Class Initialized
INFO - 2018-06-21 03:01:22 --> Language Class Initialized
INFO - 2018-06-21 03:01:22 --> Language Class Initialized
INFO - 2018-06-21 03:01:22 --> Config Class Initialized
INFO - 2018-06-21 03:01:22 --> Loader Class Initialized
DEBUG - 2018-06-21 03:01:22 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 03:01:22 --> Helper loaded: url_helper
INFO - 2018-06-21 03:01:22 --> Helper loaded: form_helper
INFO - 2018-06-21 03:01:22 --> Helper loaded: date_helper
INFO - 2018-06-21 03:01:22 --> Helper loaded: util_helper
INFO - 2018-06-21 03:01:22 --> Helper loaded: text_helper
INFO - 2018-06-21 03:01:23 --> Helper loaded: string_helper
INFO - 2018-06-21 03:01:23 --> Database Driver Class Initialized
DEBUG - 2018-06-21 03:01:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 03:01:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 03:01:23 --> Email Class Initialized
INFO - 2018-06-21 03:01:23 --> Controller Class Initialized
DEBUG - 2018-06-21 03:01:23 --> Users MX_Controller Initialized
DEBUG - 2018-06-21 03:01:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 03:01:23 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 03:01:23 --> Login MX_Controller Initialized
INFO - 2018-06-21 03:01:23 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 03:01:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-21 03:01:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-21 03:01:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-21 03:01:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-21 03:01:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-21 03:01:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-21 03:01:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-06-21 03:01:23 --> Final output sent to browser
DEBUG - 2018-06-21 03:01:23 --> Total execution time: 0.4079
INFO - 2018-06-21 03:01:23 --> Config Class Initialized
INFO - 2018-06-21 03:01:23 --> Hooks Class Initialized
DEBUG - 2018-06-21 03:01:23 --> UTF-8 Support Enabled
INFO - 2018-06-21 03:01:23 --> Utf8 Class Initialized
INFO - 2018-06-21 03:01:23 --> URI Class Initialized
INFO - 2018-06-21 03:01:23 --> Router Class Initialized
INFO - 2018-06-21 03:01:23 --> Output Class Initialized
INFO - 2018-06-21 03:01:23 --> Security Class Initialized
DEBUG - 2018-06-21 03:01:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 03:01:23 --> Input Class Initialized
INFO - 2018-06-21 03:01:23 --> Language Class Initialized
INFO - 2018-06-21 03:01:23 --> Language Class Initialized
INFO - 2018-06-21 03:01:23 --> Config Class Initialized
INFO - 2018-06-21 03:01:23 --> Loader Class Initialized
DEBUG - 2018-06-21 03:01:23 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 03:01:23 --> Helper loaded: url_helper
INFO - 2018-06-21 03:01:23 --> Helper loaded: form_helper
INFO - 2018-06-21 03:01:23 --> Helper loaded: date_helper
INFO - 2018-06-21 03:01:23 --> Helper loaded: util_helper
INFO - 2018-06-21 03:01:23 --> Helper loaded: text_helper
INFO - 2018-06-21 03:01:23 --> Helper loaded: string_helper
INFO - 2018-06-21 03:01:23 --> Database Driver Class Initialized
DEBUG - 2018-06-21 03:01:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 03:01:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 03:01:23 --> Email Class Initialized
INFO - 2018-06-21 03:01:23 --> Controller Class Initialized
DEBUG - 2018-06-21 03:01:23 --> Users MX_Controller Initialized
DEBUG - 2018-06-21 03:01:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 03:01:23 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 03:01:23 --> Login MX_Controller Initialized
INFO - 2018-06-21 03:01:24 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 03:01:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-21 03:01:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-06-21 03:01:24 --> Final output sent to browser
DEBUG - 2018-06-21 03:01:24 --> Total execution time: 0.4583
INFO - 2018-06-21 03:01:55 --> Config Class Initialized
INFO - 2018-06-21 03:01:55 --> Hooks Class Initialized
DEBUG - 2018-06-21 03:01:55 --> UTF-8 Support Enabled
INFO - 2018-06-21 03:01:55 --> Utf8 Class Initialized
INFO - 2018-06-21 03:01:55 --> URI Class Initialized
INFO - 2018-06-21 03:01:55 --> Router Class Initialized
INFO - 2018-06-21 03:01:55 --> Output Class Initialized
INFO - 2018-06-21 03:01:55 --> Security Class Initialized
DEBUG - 2018-06-21 03:01:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 03:01:55 --> Input Class Initialized
INFO - 2018-06-21 03:01:55 --> Language Class Initialized
INFO - 2018-06-21 03:01:55 --> Language Class Initialized
INFO - 2018-06-21 03:01:55 --> Config Class Initialized
INFO - 2018-06-21 03:01:55 --> Loader Class Initialized
DEBUG - 2018-06-21 03:01:55 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 03:01:55 --> Helper loaded: url_helper
INFO - 2018-06-21 03:01:55 --> Helper loaded: form_helper
INFO - 2018-06-21 03:01:55 --> Helper loaded: date_helper
INFO - 2018-06-21 03:01:55 --> Helper loaded: util_helper
INFO - 2018-06-21 03:01:55 --> Helper loaded: text_helper
INFO - 2018-06-21 03:01:55 --> Helper loaded: string_helper
INFO - 2018-06-21 03:01:55 --> Database Driver Class Initialized
DEBUG - 2018-06-21 03:01:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 03:01:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 03:01:55 --> Email Class Initialized
INFO - 2018-06-21 03:01:55 --> Controller Class Initialized
DEBUG - 2018-06-21 03:01:55 --> Users MX_Controller Initialized
DEBUG - 2018-06-21 03:01:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 03:01:55 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 03:01:55 --> Login MX_Controller Initialized
INFO - 2018-06-21 03:01:55 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 03:01:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-21 03:01:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-06-21 03:01:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-21 03:01:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-21 03:01:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-21 03:01:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-21 03:01:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-21 03:01:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-06-21 03:01:55 --> Final output sent to browser
DEBUG - 2018-06-21 03:01:55 --> Total execution time: 0.4119
INFO - 2018-06-21 03:02:13 --> Config Class Initialized
INFO - 2018-06-21 03:02:13 --> Hooks Class Initialized
DEBUG - 2018-06-21 03:02:13 --> UTF-8 Support Enabled
INFO - 2018-06-21 03:02:13 --> Utf8 Class Initialized
INFO - 2018-06-21 03:02:13 --> URI Class Initialized
INFO - 2018-06-21 03:02:13 --> Router Class Initialized
INFO - 2018-06-21 03:02:13 --> Output Class Initialized
INFO - 2018-06-21 03:02:13 --> Security Class Initialized
DEBUG - 2018-06-21 03:02:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 03:02:13 --> Input Class Initialized
INFO - 2018-06-21 03:02:13 --> Language Class Initialized
INFO - 2018-06-21 03:02:13 --> Language Class Initialized
INFO - 2018-06-21 03:02:13 --> Config Class Initialized
INFO - 2018-06-21 03:02:13 --> Loader Class Initialized
DEBUG - 2018-06-21 03:02:13 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 03:02:13 --> Helper loaded: url_helper
INFO - 2018-06-21 03:02:13 --> Helper loaded: form_helper
INFO - 2018-06-21 03:02:13 --> Helper loaded: date_helper
INFO - 2018-06-21 03:02:13 --> Helper loaded: util_helper
INFO - 2018-06-21 03:02:13 --> Helper loaded: text_helper
INFO - 2018-06-21 03:02:13 --> Helper loaded: string_helper
INFO - 2018-06-21 03:02:13 --> Database Driver Class Initialized
DEBUG - 2018-06-21 03:02:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 03:02:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 03:02:13 --> Email Class Initialized
INFO - 2018-06-21 03:02:13 --> Controller Class Initialized
DEBUG - 2018-06-21 03:02:13 --> Users MX_Controller Initialized
DEBUG - 2018-06-21 03:02:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 03:02:13 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 03:02:13 --> Login MX_Controller Initialized
INFO - 2018-06-21 03:02:13 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 03:02:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-21 03:02:13 --> Final output sent to browser
DEBUG - 2018-06-21 03:02:13 --> Total execution time: 0.3905
INFO - 2018-06-21 03:02:24 --> Config Class Initialized
INFO - 2018-06-21 03:02:24 --> Hooks Class Initialized
DEBUG - 2018-06-21 03:02:24 --> UTF-8 Support Enabled
INFO - 2018-06-21 03:02:24 --> Utf8 Class Initialized
INFO - 2018-06-21 03:02:24 --> URI Class Initialized
INFO - 2018-06-21 03:02:24 --> Router Class Initialized
INFO - 2018-06-21 03:02:24 --> Output Class Initialized
INFO - 2018-06-21 03:02:24 --> Security Class Initialized
DEBUG - 2018-06-21 03:02:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 03:02:24 --> Input Class Initialized
INFO - 2018-06-21 03:02:24 --> Language Class Initialized
INFO - 2018-06-21 03:02:24 --> Language Class Initialized
INFO - 2018-06-21 03:02:24 --> Config Class Initialized
INFO - 2018-06-21 03:02:25 --> Loader Class Initialized
DEBUG - 2018-06-21 03:02:25 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 03:02:25 --> Helper loaded: url_helper
INFO - 2018-06-21 03:02:25 --> Helper loaded: form_helper
INFO - 2018-06-21 03:02:25 --> Helper loaded: date_helper
INFO - 2018-06-21 03:02:25 --> Helper loaded: util_helper
INFO - 2018-06-21 03:02:25 --> Helper loaded: text_helper
INFO - 2018-06-21 03:02:25 --> Helper loaded: string_helper
INFO - 2018-06-21 03:02:25 --> Database Driver Class Initialized
DEBUG - 2018-06-21 03:02:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 03:02:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 03:02:25 --> Email Class Initialized
INFO - 2018-06-21 03:02:25 --> Controller Class Initialized
DEBUG - 2018-06-21 03:02:25 --> Users MX_Controller Initialized
DEBUG - 2018-06-21 03:02:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 03:02:25 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 03:02:25 --> Login MX_Controller Initialized
INFO - 2018-06-21 03:02:25 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 03:02:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-21 03:02:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
ERROR - 2018-06-21 03:02:25 --> Severity: error --> Exception: Unable to locate the model you have specified: Upload_model E:\xampp\htdocs\consulting\system\core\Loader.php 348
INFO - 2018-06-21 03:03:14 --> Config Class Initialized
INFO - 2018-06-21 03:03:14 --> Hooks Class Initialized
DEBUG - 2018-06-21 03:03:14 --> UTF-8 Support Enabled
INFO - 2018-06-21 03:03:14 --> Utf8 Class Initialized
INFO - 2018-06-21 03:03:14 --> URI Class Initialized
INFO - 2018-06-21 03:03:14 --> Router Class Initialized
INFO - 2018-06-21 03:03:14 --> Output Class Initialized
INFO - 2018-06-21 03:03:14 --> Security Class Initialized
DEBUG - 2018-06-21 03:03:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 03:03:14 --> Input Class Initialized
INFO - 2018-06-21 03:03:14 --> Language Class Initialized
INFO - 2018-06-21 03:03:14 --> Language Class Initialized
INFO - 2018-06-21 03:03:14 --> Config Class Initialized
INFO - 2018-06-21 03:03:14 --> Loader Class Initialized
DEBUG - 2018-06-21 03:03:14 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 03:03:14 --> Helper loaded: url_helper
INFO - 2018-06-21 03:03:14 --> Helper loaded: form_helper
INFO - 2018-06-21 03:03:14 --> Helper loaded: date_helper
INFO - 2018-06-21 03:03:14 --> Helper loaded: util_helper
INFO - 2018-06-21 03:03:14 --> Helper loaded: text_helper
INFO - 2018-06-21 03:03:14 --> Helper loaded: string_helper
INFO - 2018-06-21 03:03:14 --> Database Driver Class Initialized
DEBUG - 2018-06-21 03:03:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 03:03:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 03:03:14 --> Email Class Initialized
INFO - 2018-06-21 03:03:14 --> Controller Class Initialized
DEBUG - 2018-06-21 03:03:14 --> Users MX_Controller Initialized
DEBUG - 2018-06-21 03:03:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 03:03:14 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 03:03:14 --> Login MX_Controller Initialized
INFO - 2018-06-21 03:03:14 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 03:03:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-21 03:03:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-06-21 03:03:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
ERROR - 2018-06-21 03:03:14 --> Severity: Notice --> Undefined index: fname E:\xampp\htdocs\consulting\application\modules\admin\controllers\users.php 105
INFO - 2018-06-21 03:03:14 --> Upload Class Initialized
ERROR - 2018-06-21 03:03:14 --> Query error: Unknown column 'name' in 'field list' - Invalid query: INSERT INTO `users` (`name`, `email`, `role_id`, `password`, `image`) VALUES ('Gopi Testing', 'gopipanguluri@gmail.com', '3', 'e10adc3949ba59abbe56e057f20f883e', '-hWZUGLNayESXoI4A.jpg')
INFO - 2018-06-21 03:03:14 --> Language file loaded: language/english/db_lang.php
INFO - 2018-06-21 03:05:00 --> Config Class Initialized
INFO - 2018-06-21 03:05:00 --> Hooks Class Initialized
DEBUG - 2018-06-21 03:05:00 --> UTF-8 Support Enabled
INFO - 2018-06-21 03:05:00 --> Utf8 Class Initialized
INFO - 2018-06-21 03:05:00 --> URI Class Initialized
INFO - 2018-06-21 03:05:00 --> Router Class Initialized
INFO - 2018-06-21 03:05:00 --> Output Class Initialized
INFO - 2018-06-21 03:05:00 --> Security Class Initialized
DEBUG - 2018-06-21 03:05:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 03:05:00 --> Input Class Initialized
INFO - 2018-06-21 03:05:00 --> Language Class Initialized
INFO - 2018-06-21 03:05:00 --> Language Class Initialized
INFO - 2018-06-21 03:05:00 --> Config Class Initialized
INFO - 2018-06-21 03:05:00 --> Loader Class Initialized
DEBUG - 2018-06-21 03:05:00 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 03:05:00 --> Helper loaded: url_helper
INFO - 2018-06-21 03:05:00 --> Helper loaded: form_helper
INFO - 2018-06-21 03:05:00 --> Helper loaded: date_helper
INFO - 2018-06-21 03:05:00 --> Helper loaded: util_helper
INFO - 2018-06-21 03:05:00 --> Helper loaded: text_helper
INFO - 2018-06-21 03:05:00 --> Helper loaded: string_helper
INFO - 2018-06-21 03:05:00 --> Database Driver Class Initialized
DEBUG - 2018-06-21 03:05:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 03:05:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 03:05:00 --> Email Class Initialized
INFO - 2018-06-21 03:05:00 --> Controller Class Initialized
DEBUG - 2018-06-21 03:05:00 --> Users MX_Controller Initialized
DEBUG - 2018-06-21 03:05:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 03:05:00 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 03:05:00 --> Login MX_Controller Initialized
INFO - 2018-06-21 03:05:00 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 03:05:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-21 03:05:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-06-21 03:05:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
ERROR - 2018-06-21 03:05:00 --> Severity: Notice --> Undefined index: fname E:\xampp\htdocs\consulting\application\modules\admin\controllers\users.php 105
INFO - 2018-06-21 03:05:00 --> Upload Class Initialized
INFO - 2018-06-21 03:05:20 --> Config Class Initialized
INFO - 2018-06-21 03:05:20 --> Hooks Class Initialized
DEBUG - 2018-06-21 03:05:20 --> UTF-8 Support Enabled
INFO - 2018-06-21 03:05:20 --> Utf8 Class Initialized
INFO - 2018-06-21 03:05:20 --> URI Class Initialized
INFO - 2018-06-21 03:05:20 --> Router Class Initialized
INFO - 2018-06-21 03:05:20 --> Output Class Initialized
INFO - 2018-06-21 03:05:20 --> Security Class Initialized
DEBUG - 2018-06-21 03:05:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 03:05:20 --> Input Class Initialized
INFO - 2018-06-21 03:05:20 --> Language Class Initialized
INFO - 2018-06-21 03:05:20 --> Language Class Initialized
INFO - 2018-06-21 03:05:20 --> Config Class Initialized
INFO - 2018-06-21 03:05:20 --> Loader Class Initialized
DEBUG - 2018-06-21 03:05:20 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 03:05:20 --> Helper loaded: url_helper
INFO - 2018-06-21 03:05:20 --> Helper loaded: form_helper
INFO - 2018-06-21 03:05:20 --> Helper loaded: date_helper
INFO - 2018-06-21 03:05:20 --> Helper loaded: util_helper
INFO - 2018-06-21 03:05:20 --> Helper loaded: text_helper
INFO - 2018-06-21 03:05:20 --> Helper loaded: string_helper
INFO - 2018-06-21 03:05:20 --> Database Driver Class Initialized
DEBUG - 2018-06-21 03:05:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 03:05:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 03:05:20 --> Email Class Initialized
INFO - 2018-06-21 03:05:20 --> Controller Class Initialized
DEBUG - 2018-06-21 03:05:21 --> Users MX_Controller Initialized
DEBUG - 2018-06-21 03:05:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 03:05:21 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 03:05:21 --> Login MX_Controller Initialized
INFO - 2018-06-21 03:05:21 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 03:05:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-21 03:05:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-06-21 03:05:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
INFO - 2018-06-21 03:05:21 --> Upload Class Initialized
INFO - 2018-06-21 03:08:11 --> Config Class Initialized
INFO - 2018-06-21 03:08:11 --> Hooks Class Initialized
DEBUG - 2018-06-21 03:08:11 --> UTF-8 Support Enabled
INFO - 2018-06-21 03:08:11 --> Utf8 Class Initialized
INFO - 2018-06-21 03:08:11 --> URI Class Initialized
INFO - 2018-06-21 03:08:11 --> Router Class Initialized
INFO - 2018-06-21 03:08:11 --> Output Class Initialized
INFO - 2018-06-21 03:08:11 --> Security Class Initialized
DEBUG - 2018-06-21 03:08:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 03:08:11 --> Input Class Initialized
INFO - 2018-06-21 03:08:11 --> Language Class Initialized
INFO - 2018-06-21 03:08:11 --> Language Class Initialized
INFO - 2018-06-21 03:08:11 --> Config Class Initialized
INFO - 2018-06-21 03:08:11 --> Loader Class Initialized
DEBUG - 2018-06-21 03:08:11 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 03:08:11 --> Helper loaded: url_helper
INFO - 2018-06-21 03:08:11 --> Helper loaded: form_helper
INFO - 2018-06-21 03:08:11 --> Helper loaded: date_helper
INFO - 2018-06-21 03:08:11 --> Helper loaded: util_helper
INFO - 2018-06-21 03:08:11 --> Helper loaded: text_helper
INFO - 2018-06-21 03:08:11 --> Helper loaded: string_helper
INFO - 2018-06-21 03:08:11 --> Database Driver Class Initialized
DEBUG - 2018-06-21 03:08:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 03:08:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 03:08:11 --> Email Class Initialized
INFO - 2018-06-21 03:08:11 --> Controller Class Initialized
DEBUG - 2018-06-21 03:08:11 --> Users MX_Controller Initialized
DEBUG - 2018-06-21 03:08:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 03:08:11 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 03:08:11 --> Login MX_Controller Initialized
INFO - 2018-06-21 03:08:11 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 03:08:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-21 03:08:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-06-21 03:08:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
INFO - 2018-06-21 03:08:11 --> Upload Class Initialized
INFO - 2018-06-21 03:08:11 --> Config Class Initialized
INFO - 2018-06-21 03:08:12 --> Hooks Class Initialized
DEBUG - 2018-06-21 03:08:12 --> UTF-8 Support Enabled
INFO - 2018-06-21 03:08:12 --> Utf8 Class Initialized
INFO - 2018-06-21 03:08:12 --> URI Class Initialized
INFO - 2018-06-21 03:08:12 --> Router Class Initialized
INFO - 2018-06-21 03:08:12 --> Output Class Initialized
INFO - 2018-06-21 03:08:12 --> Security Class Initialized
DEBUG - 2018-06-21 03:08:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 03:08:12 --> Input Class Initialized
INFO - 2018-06-21 03:08:12 --> Language Class Initialized
INFO - 2018-06-21 03:08:12 --> Language Class Initialized
INFO - 2018-06-21 03:08:12 --> Config Class Initialized
INFO - 2018-06-21 03:08:12 --> Loader Class Initialized
DEBUG - 2018-06-21 03:08:12 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 03:08:12 --> Helper loaded: url_helper
INFO - 2018-06-21 03:08:12 --> Helper loaded: form_helper
INFO - 2018-06-21 03:08:12 --> Helper loaded: date_helper
INFO - 2018-06-21 03:08:12 --> Helper loaded: util_helper
INFO - 2018-06-21 03:08:12 --> Helper loaded: text_helper
INFO - 2018-06-21 03:08:12 --> Helper loaded: string_helper
INFO - 2018-06-21 03:08:12 --> Database Driver Class Initialized
DEBUG - 2018-06-21 03:08:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 03:08:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 03:08:12 --> Email Class Initialized
INFO - 2018-06-21 03:08:12 --> Controller Class Initialized
DEBUG - 2018-06-21 03:08:12 --> Users MX_Controller Initialized
DEBUG - 2018-06-21 03:08:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 03:08:12 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 03:08:12 --> Login MX_Controller Initialized
INFO - 2018-06-21 03:08:12 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 03:08:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-21 03:08:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-21 03:08:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-21 03:08:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-21 03:08:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-21 03:08:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-21 03:08:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-06-21 03:08:12 --> Final output sent to browser
DEBUG - 2018-06-21 03:08:12 --> Total execution time: 0.3883
INFO - 2018-06-21 03:08:13 --> Config Class Initialized
INFO - 2018-06-21 03:08:13 --> Hooks Class Initialized
DEBUG - 2018-06-21 03:08:13 --> UTF-8 Support Enabled
INFO - 2018-06-21 03:08:13 --> Utf8 Class Initialized
INFO - 2018-06-21 03:08:13 --> URI Class Initialized
INFO - 2018-06-21 03:08:13 --> Router Class Initialized
INFO - 2018-06-21 03:08:13 --> Output Class Initialized
INFO - 2018-06-21 03:08:13 --> Security Class Initialized
DEBUG - 2018-06-21 03:08:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 03:08:13 --> Input Class Initialized
INFO - 2018-06-21 03:08:13 --> Language Class Initialized
INFO - 2018-06-21 03:08:13 --> Language Class Initialized
INFO - 2018-06-21 03:08:13 --> Config Class Initialized
INFO - 2018-06-21 03:08:13 --> Loader Class Initialized
DEBUG - 2018-06-21 03:08:13 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 03:08:13 --> Helper loaded: url_helper
INFO - 2018-06-21 03:08:13 --> Helper loaded: form_helper
INFO - 2018-06-21 03:08:13 --> Helper loaded: date_helper
INFO - 2018-06-21 03:08:13 --> Helper loaded: util_helper
INFO - 2018-06-21 03:08:13 --> Helper loaded: text_helper
INFO - 2018-06-21 03:08:13 --> Helper loaded: string_helper
INFO - 2018-06-21 03:08:13 --> Database Driver Class Initialized
DEBUG - 2018-06-21 03:08:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 03:08:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 03:08:13 --> Email Class Initialized
INFO - 2018-06-21 03:08:13 --> Controller Class Initialized
DEBUG - 2018-06-21 03:08:13 --> Users MX_Controller Initialized
DEBUG - 2018-06-21 03:08:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 03:08:13 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 03:08:13 --> Login MX_Controller Initialized
INFO - 2018-06-21 03:08:13 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 03:08:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-21 03:08:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-06-21 03:08:13 --> Final output sent to browser
DEBUG - 2018-06-21 03:08:13 --> Total execution time: 0.4612
INFO - 2018-06-21 03:09:15 --> Config Class Initialized
INFO - 2018-06-21 03:09:15 --> Hooks Class Initialized
DEBUG - 2018-06-21 03:09:15 --> UTF-8 Support Enabled
INFO - 2018-06-21 03:09:15 --> Utf8 Class Initialized
INFO - 2018-06-21 03:09:15 --> URI Class Initialized
INFO - 2018-06-21 03:09:15 --> Router Class Initialized
INFO - 2018-06-21 03:09:15 --> Output Class Initialized
INFO - 2018-06-21 03:09:15 --> Security Class Initialized
DEBUG - 2018-06-21 03:09:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 03:09:15 --> Input Class Initialized
INFO - 2018-06-21 03:09:15 --> Language Class Initialized
INFO - 2018-06-21 03:09:15 --> Language Class Initialized
INFO - 2018-06-21 03:09:15 --> Config Class Initialized
INFO - 2018-06-21 03:09:15 --> Loader Class Initialized
DEBUG - 2018-06-21 03:09:15 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 03:09:15 --> Helper loaded: url_helper
INFO - 2018-06-21 03:09:15 --> Helper loaded: form_helper
INFO - 2018-06-21 03:09:15 --> Helper loaded: date_helper
INFO - 2018-06-21 03:09:15 --> Helper loaded: util_helper
INFO - 2018-06-21 03:09:15 --> Helper loaded: text_helper
INFO - 2018-06-21 03:09:15 --> Helper loaded: string_helper
INFO - 2018-06-21 03:09:15 --> Database Driver Class Initialized
DEBUG - 2018-06-21 03:09:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 03:09:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 03:09:15 --> Email Class Initialized
INFO - 2018-06-21 03:09:15 --> Controller Class Initialized
DEBUG - 2018-06-21 03:09:15 --> Users MX_Controller Initialized
DEBUG - 2018-06-21 03:09:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 03:09:15 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 03:09:15 --> Login MX_Controller Initialized
INFO - 2018-06-21 03:09:15 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 03:09:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-21 03:09:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-21 03:09:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-21 03:09:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-21 03:09:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-21 03:09:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-21 03:09:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-06-21 03:09:16 --> Final output sent to browser
DEBUG - 2018-06-21 03:09:16 --> Total execution time: 0.4005
INFO - 2018-06-21 03:09:17 --> Config Class Initialized
INFO - 2018-06-21 03:09:17 --> Hooks Class Initialized
DEBUG - 2018-06-21 03:09:17 --> UTF-8 Support Enabled
INFO - 2018-06-21 03:09:17 --> Utf8 Class Initialized
INFO - 2018-06-21 03:09:17 --> URI Class Initialized
INFO - 2018-06-21 03:09:17 --> Router Class Initialized
INFO - 2018-06-21 03:09:17 --> Output Class Initialized
INFO - 2018-06-21 03:09:17 --> Security Class Initialized
DEBUG - 2018-06-21 03:09:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 03:09:17 --> Input Class Initialized
INFO - 2018-06-21 03:09:17 --> Language Class Initialized
INFO - 2018-06-21 03:09:17 --> Language Class Initialized
INFO - 2018-06-21 03:09:17 --> Config Class Initialized
INFO - 2018-06-21 03:09:17 --> Loader Class Initialized
DEBUG - 2018-06-21 03:09:17 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 03:09:17 --> Helper loaded: url_helper
INFO - 2018-06-21 03:09:17 --> Helper loaded: form_helper
INFO - 2018-06-21 03:09:17 --> Helper loaded: date_helper
INFO - 2018-06-21 03:09:17 --> Helper loaded: util_helper
INFO - 2018-06-21 03:09:17 --> Helper loaded: text_helper
INFO - 2018-06-21 03:09:17 --> Helper loaded: string_helper
INFO - 2018-06-21 03:09:17 --> Database Driver Class Initialized
DEBUG - 2018-06-21 03:09:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 03:09:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 03:09:17 --> Email Class Initialized
INFO - 2018-06-21 03:09:17 --> Controller Class Initialized
DEBUG - 2018-06-21 03:09:17 --> Users MX_Controller Initialized
DEBUG - 2018-06-21 03:09:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 03:09:17 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 03:09:17 --> Login MX_Controller Initialized
INFO - 2018-06-21 03:09:17 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 03:09:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-21 03:09:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-06-21 03:09:17 --> Final output sent to browser
DEBUG - 2018-06-21 03:09:17 --> Total execution time: 0.5865
INFO - 2018-06-21 03:09:31 --> Config Class Initialized
INFO - 2018-06-21 03:09:31 --> Hooks Class Initialized
DEBUG - 2018-06-21 03:09:31 --> UTF-8 Support Enabled
INFO - 2018-06-21 03:09:31 --> Utf8 Class Initialized
INFO - 2018-06-21 03:09:31 --> URI Class Initialized
INFO - 2018-06-21 03:09:31 --> Router Class Initialized
INFO - 2018-06-21 03:09:31 --> Output Class Initialized
INFO - 2018-06-21 03:09:31 --> Security Class Initialized
DEBUG - 2018-06-21 03:09:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 03:09:31 --> Input Class Initialized
INFO - 2018-06-21 03:09:31 --> Language Class Initialized
INFO - 2018-06-21 03:09:31 --> Language Class Initialized
INFO - 2018-06-21 03:09:31 --> Config Class Initialized
INFO - 2018-06-21 03:09:31 --> Loader Class Initialized
DEBUG - 2018-06-21 03:09:31 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 03:09:31 --> Helper loaded: url_helper
INFO - 2018-06-21 03:09:31 --> Helper loaded: form_helper
INFO - 2018-06-21 03:09:31 --> Helper loaded: date_helper
INFO - 2018-06-21 03:09:31 --> Helper loaded: util_helper
INFO - 2018-06-21 03:09:31 --> Helper loaded: text_helper
INFO - 2018-06-21 03:09:31 --> Helper loaded: string_helper
INFO - 2018-06-21 03:09:31 --> Database Driver Class Initialized
DEBUG - 2018-06-21 03:09:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 03:09:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 03:09:31 --> Email Class Initialized
INFO - 2018-06-21 03:09:31 --> Controller Class Initialized
DEBUG - 2018-06-21 03:09:31 --> Users MX_Controller Initialized
DEBUG - 2018-06-21 03:09:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 03:09:31 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 03:09:31 --> Login MX_Controller Initialized
INFO - 2018-06-21 03:09:31 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 03:09:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-21 03:09:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-21 03:09:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-21 03:09:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-21 03:09:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-21 03:09:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-21 03:09:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-06-21 03:09:31 --> Final output sent to browser
DEBUG - 2018-06-21 03:09:31 --> Total execution time: 0.4208
INFO - 2018-06-21 03:09:31 --> Config Class Initialized
INFO - 2018-06-21 03:09:31 --> Hooks Class Initialized
DEBUG - 2018-06-21 03:09:31 --> UTF-8 Support Enabled
INFO - 2018-06-21 03:09:31 --> Utf8 Class Initialized
INFO - 2018-06-21 03:09:31 --> URI Class Initialized
INFO - 2018-06-21 03:09:31 --> Router Class Initialized
INFO - 2018-06-21 03:09:31 --> Output Class Initialized
INFO - 2018-06-21 03:09:31 --> Security Class Initialized
DEBUG - 2018-06-21 03:09:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 03:09:31 --> Input Class Initialized
INFO - 2018-06-21 03:09:31 --> Language Class Initialized
INFO - 2018-06-21 03:09:31 --> Language Class Initialized
INFO - 2018-06-21 03:09:31 --> Config Class Initialized
INFO - 2018-06-21 03:09:31 --> Loader Class Initialized
DEBUG - 2018-06-21 03:09:31 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 03:09:31 --> Helper loaded: url_helper
INFO - 2018-06-21 03:09:31 --> Helper loaded: form_helper
INFO - 2018-06-21 03:09:31 --> Helper loaded: date_helper
INFO - 2018-06-21 03:09:31 --> Helper loaded: util_helper
INFO - 2018-06-21 03:09:31 --> Helper loaded: text_helper
INFO - 2018-06-21 03:09:31 --> Helper loaded: string_helper
INFO - 2018-06-21 03:09:31 --> Database Driver Class Initialized
DEBUG - 2018-06-21 03:09:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 03:09:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 03:09:31 --> Email Class Initialized
INFO - 2018-06-21 03:09:31 --> Controller Class Initialized
DEBUG - 2018-06-21 03:09:31 --> Users MX_Controller Initialized
DEBUG - 2018-06-21 03:09:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 03:09:31 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 03:09:31 --> Login MX_Controller Initialized
INFO - 2018-06-21 03:09:31 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 03:09:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-21 03:09:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-21 03:09:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-21 03:09:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-21 03:09:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-21 03:09:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-21 03:09:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-06-21 03:09:31 --> Final output sent to browser
DEBUG - 2018-06-21 03:09:32 --> Total execution time: 0.4437
INFO - 2018-06-21 03:09:33 --> Config Class Initialized
INFO - 2018-06-21 03:09:33 --> Hooks Class Initialized
DEBUG - 2018-06-21 03:09:33 --> UTF-8 Support Enabled
INFO - 2018-06-21 03:09:33 --> Utf8 Class Initialized
INFO - 2018-06-21 03:09:33 --> URI Class Initialized
INFO - 2018-06-21 03:09:33 --> Router Class Initialized
INFO - 2018-06-21 03:09:33 --> Output Class Initialized
INFO - 2018-06-21 03:09:33 --> Security Class Initialized
DEBUG - 2018-06-21 03:09:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 03:09:33 --> Input Class Initialized
INFO - 2018-06-21 03:09:33 --> Language Class Initialized
INFO - 2018-06-21 03:09:33 --> Language Class Initialized
INFO - 2018-06-21 03:09:33 --> Config Class Initialized
INFO - 2018-06-21 03:09:33 --> Loader Class Initialized
DEBUG - 2018-06-21 03:09:33 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 03:09:33 --> Helper loaded: url_helper
INFO - 2018-06-21 03:09:33 --> Helper loaded: form_helper
INFO - 2018-06-21 03:09:33 --> Helper loaded: date_helper
INFO - 2018-06-21 03:09:33 --> Helper loaded: util_helper
INFO - 2018-06-21 03:09:33 --> Helper loaded: text_helper
INFO - 2018-06-21 03:09:33 --> Helper loaded: string_helper
INFO - 2018-06-21 03:09:33 --> Database Driver Class Initialized
DEBUG - 2018-06-21 03:09:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 03:09:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 03:09:33 --> Email Class Initialized
INFO - 2018-06-21 03:09:33 --> Controller Class Initialized
DEBUG - 2018-06-21 03:09:33 --> Users MX_Controller Initialized
DEBUG - 2018-06-21 03:09:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 03:09:33 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 03:09:33 --> Login MX_Controller Initialized
INFO - 2018-06-21 03:09:33 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 03:09:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-21 03:09:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-06-21 03:09:33 --> Final output sent to browser
DEBUG - 2018-06-21 03:09:33 --> Total execution time: 0.6897
INFO - 2018-06-21 03:09:45 --> Config Class Initialized
INFO - 2018-06-21 03:09:45 --> Hooks Class Initialized
DEBUG - 2018-06-21 03:09:45 --> UTF-8 Support Enabled
INFO - 2018-06-21 03:09:45 --> Utf8 Class Initialized
INFO - 2018-06-21 03:09:45 --> URI Class Initialized
INFO - 2018-06-21 03:09:45 --> Router Class Initialized
INFO - 2018-06-21 03:09:45 --> Output Class Initialized
INFO - 2018-06-21 03:09:45 --> Security Class Initialized
DEBUG - 2018-06-21 03:09:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 03:09:45 --> Input Class Initialized
INFO - 2018-06-21 03:09:45 --> Language Class Initialized
INFO - 2018-06-21 03:09:45 --> Language Class Initialized
INFO - 2018-06-21 03:09:45 --> Config Class Initialized
INFO - 2018-06-21 03:09:45 --> Loader Class Initialized
DEBUG - 2018-06-21 03:09:45 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 03:09:45 --> Helper loaded: url_helper
INFO - 2018-06-21 03:09:45 --> Helper loaded: form_helper
INFO - 2018-06-21 03:09:45 --> Helper loaded: date_helper
INFO - 2018-06-21 03:09:45 --> Helper loaded: util_helper
INFO - 2018-06-21 03:09:45 --> Helper loaded: text_helper
INFO - 2018-06-21 03:09:45 --> Helper loaded: string_helper
INFO - 2018-06-21 03:09:45 --> Database Driver Class Initialized
DEBUG - 2018-06-21 03:09:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 03:09:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 03:09:46 --> Email Class Initialized
INFO - 2018-06-21 03:09:46 --> Controller Class Initialized
DEBUG - 2018-06-21 03:09:46 --> Admin MX_Controller Initialized
INFO - 2018-06-21 03:09:46 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 03:09:46 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 03:09:46 --> Login MX_Controller Initialized
DEBUG - 2018-06-21 03:09:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 03:09:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-21 03:09:46 --> Final output sent to browser
DEBUG - 2018-06-21 03:09:46 --> Total execution time: 0.5203
INFO - 2018-06-21 03:09:47 --> Config Class Initialized
INFO - 2018-06-21 03:09:47 --> Hooks Class Initialized
DEBUG - 2018-06-21 03:09:47 --> UTF-8 Support Enabled
INFO - 2018-06-21 03:09:47 --> Utf8 Class Initialized
INFO - 2018-06-21 03:09:47 --> URI Class Initialized
INFO - 2018-06-21 03:09:47 --> Router Class Initialized
INFO - 2018-06-21 03:09:47 --> Output Class Initialized
INFO - 2018-06-21 03:09:47 --> Security Class Initialized
DEBUG - 2018-06-21 03:09:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 03:09:47 --> Input Class Initialized
INFO - 2018-06-21 03:09:47 --> Language Class Initialized
INFO - 2018-06-21 03:09:47 --> Language Class Initialized
INFO - 2018-06-21 03:09:47 --> Config Class Initialized
INFO - 2018-06-21 03:09:47 --> Loader Class Initialized
DEBUG - 2018-06-21 03:09:47 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 03:09:47 --> Helper loaded: url_helper
INFO - 2018-06-21 03:09:47 --> Helper loaded: form_helper
INFO - 2018-06-21 03:09:47 --> Helper loaded: date_helper
INFO - 2018-06-21 03:09:47 --> Helper loaded: util_helper
INFO - 2018-06-21 03:09:47 --> Helper loaded: text_helper
INFO - 2018-06-21 03:09:47 --> Helper loaded: string_helper
INFO - 2018-06-21 03:09:47 --> Database Driver Class Initialized
DEBUG - 2018-06-21 03:09:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 03:09:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 03:09:47 --> Email Class Initialized
INFO - 2018-06-21 03:09:47 --> Controller Class Initialized
DEBUG - 2018-06-21 03:09:47 --> Admin MX_Controller Initialized
INFO - 2018-06-21 03:09:47 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 03:09:47 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 03:09:47 --> Login MX_Controller Initialized
DEBUG - 2018-06-21 03:09:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 03:09:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-21 03:09:47 --> Final output sent to browser
DEBUG - 2018-06-21 03:09:47 --> Total execution time: 0.4996
INFO - 2018-06-21 03:09:48 --> Config Class Initialized
INFO - 2018-06-21 03:09:48 --> Hooks Class Initialized
DEBUG - 2018-06-21 03:09:48 --> UTF-8 Support Enabled
INFO - 2018-06-21 03:09:48 --> Utf8 Class Initialized
INFO - 2018-06-21 03:09:48 --> URI Class Initialized
INFO - 2018-06-21 03:09:48 --> Router Class Initialized
INFO - 2018-06-21 03:09:48 --> Output Class Initialized
INFO - 2018-06-21 03:09:48 --> Security Class Initialized
DEBUG - 2018-06-21 03:09:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 03:09:48 --> Input Class Initialized
INFO - 2018-06-21 03:09:48 --> Language Class Initialized
INFO - 2018-06-21 03:09:48 --> Language Class Initialized
INFO - 2018-06-21 03:09:48 --> Config Class Initialized
INFO - 2018-06-21 03:09:48 --> Loader Class Initialized
DEBUG - 2018-06-21 03:09:48 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 03:09:48 --> Helper loaded: url_helper
INFO - 2018-06-21 03:09:48 --> Helper loaded: form_helper
INFO - 2018-06-21 03:09:48 --> Helper loaded: date_helper
INFO - 2018-06-21 03:09:48 --> Helper loaded: util_helper
INFO - 2018-06-21 03:09:48 --> Helper loaded: text_helper
INFO - 2018-06-21 03:09:48 --> Helper loaded: string_helper
INFO - 2018-06-21 03:09:48 --> Database Driver Class Initialized
DEBUG - 2018-06-21 03:09:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 03:09:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 03:09:48 --> Email Class Initialized
INFO - 2018-06-21 03:09:48 --> Controller Class Initialized
DEBUG - 2018-06-21 03:09:48 --> Admin MX_Controller Initialized
INFO - 2018-06-21 03:09:48 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 03:09:48 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 03:09:48 --> Login MX_Controller Initialized
DEBUG - 2018-06-21 03:09:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 03:09:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-21 03:09:48 --> Final output sent to browser
DEBUG - 2018-06-21 03:09:48 --> Total execution time: 0.5229
INFO - 2018-06-21 03:09:49 --> Config Class Initialized
INFO - 2018-06-21 03:09:49 --> Hooks Class Initialized
DEBUG - 2018-06-21 03:09:49 --> UTF-8 Support Enabled
INFO - 2018-06-21 03:09:49 --> Utf8 Class Initialized
INFO - 2018-06-21 03:09:49 --> URI Class Initialized
INFO - 2018-06-21 03:09:49 --> Router Class Initialized
INFO - 2018-06-21 03:09:49 --> Output Class Initialized
INFO - 2018-06-21 03:09:49 --> Security Class Initialized
DEBUG - 2018-06-21 03:09:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 03:09:49 --> Input Class Initialized
INFO - 2018-06-21 03:09:49 --> Language Class Initialized
INFO - 2018-06-21 03:09:49 --> Language Class Initialized
INFO - 2018-06-21 03:09:49 --> Config Class Initialized
INFO - 2018-06-21 03:09:49 --> Loader Class Initialized
DEBUG - 2018-06-21 03:09:49 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 03:09:49 --> Helper loaded: url_helper
INFO - 2018-06-21 03:09:49 --> Helper loaded: form_helper
INFO - 2018-06-21 03:09:49 --> Helper loaded: date_helper
INFO - 2018-06-21 03:09:49 --> Helper loaded: util_helper
INFO - 2018-06-21 03:09:49 --> Helper loaded: text_helper
INFO - 2018-06-21 03:09:49 --> Helper loaded: string_helper
INFO - 2018-06-21 03:09:49 --> Database Driver Class Initialized
DEBUG - 2018-06-21 03:09:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 03:09:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 03:09:49 --> Email Class Initialized
INFO - 2018-06-21 03:09:49 --> Controller Class Initialized
DEBUG - 2018-06-21 03:09:49 --> Admin MX_Controller Initialized
INFO - 2018-06-21 03:09:49 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 03:09:49 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 03:09:49 --> Login MX_Controller Initialized
DEBUG - 2018-06-21 03:09:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 03:09:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-21 03:09:49 --> Final output sent to browser
DEBUG - 2018-06-21 03:09:49 --> Total execution time: 0.4903
INFO - 2018-06-21 03:09:50 --> Config Class Initialized
INFO - 2018-06-21 03:09:50 --> Hooks Class Initialized
DEBUG - 2018-06-21 03:09:50 --> UTF-8 Support Enabled
INFO - 2018-06-21 03:09:50 --> Utf8 Class Initialized
INFO - 2018-06-21 03:09:50 --> URI Class Initialized
INFO - 2018-06-21 03:09:50 --> Router Class Initialized
INFO - 2018-06-21 03:09:50 --> Output Class Initialized
INFO - 2018-06-21 03:09:50 --> Security Class Initialized
DEBUG - 2018-06-21 03:09:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 03:09:50 --> Input Class Initialized
INFO - 2018-06-21 03:09:50 --> Language Class Initialized
INFO - 2018-06-21 03:09:50 --> Language Class Initialized
INFO - 2018-06-21 03:09:50 --> Config Class Initialized
INFO - 2018-06-21 03:09:50 --> Loader Class Initialized
DEBUG - 2018-06-21 03:09:50 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 03:09:50 --> Helper loaded: url_helper
INFO - 2018-06-21 03:09:50 --> Helper loaded: form_helper
INFO - 2018-06-21 03:09:50 --> Helper loaded: date_helper
INFO - 2018-06-21 03:09:50 --> Helper loaded: util_helper
INFO - 2018-06-21 03:09:50 --> Helper loaded: text_helper
INFO - 2018-06-21 03:09:51 --> Helper loaded: string_helper
INFO - 2018-06-21 03:09:51 --> Database Driver Class Initialized
DEBUG - 2018-06-21 03:09:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 03:09:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 03:09:51 --> Email Class Initialized
INFO - 2018-06-21 03:09:51 --> Controller Class Initialized
DEBUG - 2018-06-21 03:09:51 --> Admin MX_Controller Initialized
INFO - 2018-06-21 03:09:51 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 03:09:51 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 03:09:51 --> Login MX_Controller Initialized
DEBUG - 2018-06-21 03:09:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 03:09:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-21 03:09:51 --> Final output sent to browser
DEBUG - 2018-06-21 03:09:51 --> Total execution time: 0.6966
INFO - 2018-06-21 03:10:25 --> Config Class Initialized
INFO - 2018-06-21 03:10:25 --> Hooks Class Initialized
DEBUG - 2018-06-21 03:10:25 --> UTF-8 Support Enabled
INFO - 2018-06-21 03:10:25 --> Utf8 Class Initialized
INFO - 2018-06-21 03:10:25 --> URI Class Initialized
INFO - 2018-06-21 03:10:25 --> Router Class Initialized
INFO - 2018-06-21 03:10:25 --> Output Class Initialized
INFO - 2018-06-21 03:10:25 --> Security Class Initialized
DEBUG - 2018-06-21 03:10:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 03:10:25 --> Input Class Initialized
INFO - 2018-06-21 03:10:25 --> Language Class Initialized
INFO - 2018-06-21 03:10:25 --> Language Class Initialized
INFO - 2018-06-21 03:10:25 --> Config Class Initialized
INFO - 2018-06-21 03:10:25 --> Loader Class Initialized
DEBUG - 2018-06-21 03:10:25 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 03:10:25 --> Helper loaded: url_helper
INFO - 2018-06-21 03:10:25 --> Helper loaded: form_helper
INFO - 2018-06-21 03:10:26 --> Helper loaded: date_helper
INFO - 2018-06-21 03:10:26 --> Helper loaded: util_helper
INFO - 2018-06-21 03:10:26 --> Helper loaded: text_helper
INFO - 2018-06-21 03:10:26 --> Helper loaded: string_helper
INFO - 2018-06-21 03:10:26 --> Database Driver Class Initialized
DEBUG - 2018-06-21 03:10:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 03:10:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 03:10:26 --> Email Class Initialized
INFO - 2018-06-21 03:10:26 --> Controller Class Initialized
DEBUG - 2018-06-21 03:10:26 --> Users MX_Controller Initialized
DEBUG - 2018-06-21 03:10:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 03:10:26 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 03:10:26 --> Login MX_Controller Initialized
INFO - 2018-06-21 03:10:26 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 03:10:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-21 03:10:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-21 03:10:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-21 03:10:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-21 03:10:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-21 03:10:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-21 03:10:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-06-21 03:10:26 --> Final output sent to browser
DEBUG - 2018-06-21 03:10:26 --> Total execution time: 0.5497
INFO - 2018-06-21 03:10:27 --> Config Class Initialized
INFO - 2018-06-21 03:10:27 --> Hooks Class Initialized
DEBUG - 2018-06-21 03:10:27 --> UTF-8 Support Enabled
INFO - 2018-06-21 03:10:27 --> Utf8 Class Initialized
INFO - 2018-06-21 03:10:27 --> URI Class Initialized
INFO - 2018-06-21 03:10:27 --> Router Class Initialized
INFO - 2018-06-21 03:10:27 --> Output Class Initialized
INFO - 2018-06-21 03:10:27 --> Security Class Initialized
DEBUG - 2018-06-21 03:10:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 03:10:27 --> Input Class Initialized
INFO - 2018-06-21 03:10:27 --> Language Class Initialized
INFO - 2018-06-21 03:10:27 --> Language Class Initialized
INFO - 2018-06-21 03:10:27 --> Config Class Initialized
INFO - 2018-06-21 03:10:27 --> Loader Class Initialized
DEBUG - 2018-06-21 03:10:27 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 03:10:27 --> Helper loaded: url_helper
INFO - 2018-06-21 03:10:27 --> Helper loaded: form_helper
INFO - 2018-06-21 03:10:27 --> Helper loaded: date_helper
INFO - 2018-06-21 03:10:27 --> Helper loaded: util_helper
INFO - 2018-06-21 03:10:27 --> Helper loaded: text_helper
INFO - 2018-06-21 03:10:27 --> Helper loaded: string_helper
INFO - 2018-06-21 03:10:27 --> Database Driver Class Initialized
DEBUG - 2018-06-21 03:10:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 03:10:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 03:10:27 --> Email Class Initialized
INFO - 2018-06-21 03:10:27 --> Controller Class Initialized
DEBUG - 2018-06-21 03:10:27 --> Users MX_Controller Initialized
DEBUG - 2018-06-21 03:10:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 03:10:27 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 03:10:27 --> Login MX_Controller Initialized
INFO - 2018-06-21 03:10:28 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 03:10:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-21 03:10:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-06-21 03:10:28 --> Final output sent to browser
DEBUG - 2018-06-21 03:10:28 --> Total execution time: 0.6009
INFO - 2018-06-21 03:10:34 --> Config Class Initialized
INFO - 2018-06-21 03:10:34 --> Hooks Class Initialized
DEBUG - 2018-06-21 03:10:34 --> UTF-8 Support Enabled
INFO - 2018-06-21 03:10:34 --> Utf8 Class Initialized
INFO - 2018-06-21 03:10:34 --> URI Class Initialized
INFO - 2018-06-21 03:10:34 --> Router Class Initialized
INFO - 2018-06-21 03:10:34 --> Output Class Initialized
INFO - 2018-06-21 03:10:34 --> Security Class Initialized
DEBUG - 2018-06-21 03:10:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 03:10:34 --> Input Class Initialized
INFO - 2018-06-21 03:10:34 --> Language Class Initialized
INFO - 2018-06-21 03:10:34 --> Language Class Initialized
INFO - 2018-06-21 03:10:34 --> Config Class Initialized
INFO - 2018-06-21 03:10:34 --> Loader Class Initialized
DEBUG - 2018-06-21 03:10:35 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 03:10:35 --> Helper loaded: url_helper
INFO - 2018-06-21 03:10:35 --> Helper loaded: form_helper
INFO - 2018-06-21 03:10:35 --> Helper loaded: date_helper
INFO - 2018-06-21 03:10:35 --> Helper loaded: util_helper
INFO - 2018-06-21 03:10:35 --> Helper loaded: text_helper
INFO - 2018-06-21 03:10:35 --> Helper loaded: string_helper
INFO - 2018-06-21 03:10:35 --> Database Driver Class Initialized
DEBUG - 2018-06-21 03:10:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 03:10:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 03:10:35 --> Email Class Initialized
INFO - 2018-06-21 03:10:35 --> Controller Class Initialized
DEBUG - 2018-06-21 03:10:35 --> Users MX_Controller Initialized
DEBUG - 2018-06-21 03:10:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 03:10:35 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 03:10:35 --> Login MX_Controller Initialized
INFO - 2018-06-21 03:10:35 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 03:10:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-21 03:10:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-06-21 03:10:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-21 03:10:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-21 03:10:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
ERROR - 2018-06-21 03:10:35 --> Severity: Notice --> Undefined index: name E:\xampp\htdocs\consulting\application\modules\admin\views\users\create_user.php 51
DEBUG - 2018-06-21 03:10:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-21 03:10:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-21 03:10:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-06-21 03:10:35 --> Final output sent to browser
DEBUG - 2018-06-21 03:10:35 --> Total execution time: 0.4646
INFO - 2018-06-21 03:11:06 --> Config Class Initialized
INFO - 2018-06-21 03:11:06 --> Hooks Class Initialized
DEBUG - 2018-06-21 03:11:06 --> UTF-8 Support Enabled
INFO - 2018-06-21 03:11:06 --> Utf8 Class Initialized
INFO - 2018-06-21 03:11:06 --> URI Class Initialized
INFO - 2018-06-21 03:11:06 --> Router Class Initialized
INFO - 2018-06-21 03:11:06 --> Output Class Initialized
INFO - 2018-06-21 03:11:06 --> Security Class Initialized
DEBUG - 2018-06-21 03:11:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 03:11:06 --> Input Class Initialized
INFO - 2018-06-21 03:11:06 --> Language Class Initialized
INFO - 2018-06-21 03:11:06 --> Language Class Initialized
INFO - 2018-06-21 03:11:06 --> Config Class Initialized
INFO - 2018-06-21 03:11:06 --> Loader Class Initialized
DEBUG - 2018-06-21 03:11:06 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 03:11:06 --> Helper loaded: url_helper
INFO - 2018-06-21 03:11:06 --> Helper loaded: form_helper
INFO - 2018-06-21 03:11:07 --> Helper loaded: date_helper
INFO - 2018-06-21 03:11:07 --> Helper loaded: util_helper
INFO - 2018-06-21 03:11:07 --> Helper loaded: text_helper
INFO - 2018-06-21 03:11:07 --> Helper loaded: string_helper
INFO - 2018-06-21 03:11:07 --> Database Driver Class Initialized
DEBUG - 2018-06-21 03:11:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 03:11:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 03:11:07 --> Email Class Initialized
INFO - 2018-06-21 03:11:07 --> Controller Class Initialized
DEBUG - 2018-06-21 03:11:07 --> Users MX_Controller Initialized
DEBUG - 2018-06-21 03:11:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 03:11:07 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 03:11:07 --> Login MX_Controller Initialized
INFO - 2018-06-21 03:11:07 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 03:11:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-21 03:11:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-06-21 03:11:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-21 03:11:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-21 03:11:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-21 03:11:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-21 03:11:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-21 03:11:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-06-21 03:11:07 --> Final output sent to browser
DEBUG - 2018-06-21 03:11:07 --> Total execution time: 0.4555
INFO - 2018-06-21 03:11:13 --> Config Class Initialized
INFO - 2018-06-21 03:11:13 --> Hooks Class Initialized
DEBUG - 2018-06-21 03:11:13 --> UTF-8 Support Enabled
INFO - 2018-06-21 03:11:13 --> Utf8 Class Initialized
INFO - 2018-06-21 03:11:13 --> URI Class Initialized
INFO - 2018-06-21 03:11:13 --> Router Class Initialized
INFO - 2018-06-21 03:11:13 --> Output Class Initialized
INFO - 2018-06-21 03:11:13 --> Security Class Initialized
DEBUG - 2018-06-21 03:11:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 03:11:13 --> Input Class Initialized
INFO - 2018-06-21 03:11:13 --> Language Class Initialized
INFO - 2018-06-21 03:11:13 --> Language Class Initialized
INFO - 2018-06-21 03:11:13 --> Config Class Initialized
INFO - 2018-06-21 03:11:13 --> Loader Class Initialized
DEBUG - 2018-06-21 03:11:13 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 03:11:13 --> Helper loaded: url_helper
INFO - 2018-06-21 03:11:13 --> Helper loaded: form_helper
INFO - 2018-06-21 03:11:13 --> Helper loaded: date_helper
INFO - 2018-06-21 03:11:13 --> Helper loaded: util_helper
INFO - 2018-06-21 03:11:13 --> Helper loaded: text_helper
INFO - 2018-06-21 03:11:13 --> Helper loaded: string_helper
INFO - 2018-06-21 03:11:13 --> Database Driver Class Initialized
DEBUG - 2018-06-21 03:11:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 03:11:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 03:11:13 --> Email Class Initialized
INFO - 2018-06-21 03:11:13 --> Controller Class Initialized
DEBUG - 2018-06-21 03:11:13 --> Users MX_Controller Initialized
DEBUG - 2018-06-21 03:11:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 03:11:13 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 03:11:13 --> Login MX_Controller Initialized
INFO - 2018-06-21 03:11:13 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 03:11:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-21 03:11:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-21 03:11:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-21 03:11:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-21 03:11:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-21 03:11:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-21 03:11:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-06-21 03:11:13 --> Final output sent to browser
DEBUG - 2018-06-21 03:11:13 --> Total execution time: 0.4335
INFO - 2018-06-21 03:11:13 --> Config Class Initialized
INFO - 2018-06-21 03:11:13 --> Hooks Class Initialized
DEBUG - 2018-06-21 03:11:13 --> UTF-8 Support Enabled
INFO - 2018-06-21 03:11:13 --> Utf8 Class Initialized
INFO - 2018-06-21 03:11:13 --> URI Class Initialized
INFO - 2018-06-21 03:11:13 --> Router Class Initialized
INFO - 2018-06-21 03:11:14 --> Output Class Initialized
INFO - 2018-06-21 03:11:14 --> Security Class Initialized
DEBUG - 2018-06-21 03:11:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 03:11:14 --> Input Class Initialized
INFO - 2018-06-21 03:11:14 --> Language Class Initialized
INFO - 2018-06-21 03:11:14 --> Language Class Initialized
INFO - 2018-06-21 03:11:14 --> Config Class Initialized
INFO - 2018-06-21 03:11:14 --> Loader Class Initialized
DEBUG - 2018-06-21 03:11:14 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 03:11:14 --> Helper loaded: url_helper
INFO - 2018-06-21 03:11:14 --> Helper loaded: form_helper
INFO - 2018-06-21 03:11:14 --> Helper loaded: date_helper
INFO - 2018-06-21 03:11:14 --> Helper loaded: util_helper
INFO - 2018-06-21 03:11:14 --> Helper loaded: text_helper
INFO - 2018-06-21 03:11:14 --> Helper loaded: string_helper
INFO - 2018-06-21 03:11:14 --> Database Driver Class Initialized
DEBUG - 2018-06-21 03:11:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 03:11:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 03:11:14 --> Email Class Initialized
INFO - 2018-06-21 03:11:14 --> Controller Class Initialized
DEBUG - 2018-06-21 03:11:14 --> Users MX_Controller Initialized
DEBUG - 2018-06-21 03:11:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 03:11:14 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 03:11:14 --> Login MX_Controller Initialized
INFO - 2018-06-21 03:11:14 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 03:11:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-21 03:11:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-06-21 03:11:14 --> Final output sent to browser
DEBUG - 2018-06-21 03:11:14 --> Total execution time: 0.5017
INFO - 2018-06-21 03:11:17 --> Config Class Initialized
INFO - 2018-06-21 03:11:17 --> Hooks Class Initialized
DEBUG - 2018-06-21 03:11:17 --> UTF-8 Support Enabled
INFO - 2018-06-21 03:11:17 --> Utf8 Class Initialized
INFO - 2018-06-21 03:11:17 --> URI Class Initialized
INFO - 2018-06-21 03:11:17 --> Router Class Initialized
INFO - 2018-06-21 03:11:17 --> Output Class Initialized
INFO - 2018-06-21 03:11:17 --> Security Class Initialized
DEBUG - 2018-06-21 03:11:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 03:11:17 --> Input Class Initialized
INFO - 2018-06-21 03:11:17 --> Language Class Initialized
INFO - 2018-06-21 03:11:17 --> Language Class Initialized
INFO - 2018-06-21 03:11:17 --> Config Class Initialized
INFO - 2018-06-21 03:11:17 --> Loader Class Initialized
DEBUG - 2018-06-21 03:11:17 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 03:11:17 --> Helper loaded: url_helper
INFO - 2018-06-21 03:11:17 --> Helper loaded: form_helper
INFO - 2018-06-21 03:11:17 --> Helper loaded: date_helper
INFO - 2018-06-21 03:11:17 --> Helper loaded: util_helper
INFO - 2018-06-21 03:11:17 --> Helper loaded: text_helper
INFO - 2018-06-21 03:11:17 --> Helper loaded: string_helper
INFO - 2018-06-21 03:11:17 --> Database Driver Class Initialized
DEBUG - 2018-06-21 03:11:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 03:11:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 03:11:17 --> Email Class Initialized
INFO - 2018-06-21 03:11:17 --> Controller Class Initialized
DEBUG - 2018-06-21 03:11:17 --> Users MX_Controller Initialized
DEBUG - 2018-06-21 03:11:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 03:11:17 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 03:11:17 --> Login MX_Controller Initialized
INFO - 2018-06-21 03:11:17 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 03:11:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-21 03:11:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-06-21 03:11:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-21 03:11:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-21 03:11:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-21 03:11:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-21 03:11:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-21 03:11:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-06-21 03:11:17 --> Final output sent to browser
DEBUG - 2018-06-21 03:11:17 --> Total execution time: 0.4350
INFO - 2018-06-21 03:11:20 --> Config Class Initialized
INFO - 2018-06-21 03:11:20 --> Hooks Class Initialized
DEBUG - 2018-06-21 03:11:20 --> UTF-8 Support Enabled
INFO - 2018-06-21 03:11:21 --> Utf8 Class Initialized
INFO - 2018-06-21 03:11:21 --> URI Class Initialized
INFO - 2018-06-21 03:11:21 --> Router Class Initialized
INFO - 2018-06-21 03:11:21 --> Output Class Initialized
INFO - 2018-06-21 03:11:21 --> Security Class Initialized
DEBUG - 2018-06-21 03:11:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 03:11:21 --> Input Class Initialized
INFO - 2018-06-21 03:11:21 --> Language Class Initialized
INFO - 2018-06-21 03:11:21 --> Language Class Initialized
INFO - 2018-06-21 03:11:21 --> Config Class Initialized
INFO - 2018-06-21 03:11:21 --> Loader Class Initialized
DEBUG - 2018-06-21 03:11:21 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 03:11:21 --> Helper loaded: url_helper
INFO - 2018-06-21 03:11:21 --> Helper loaded: form_helper
INFO - 2018-06-21 03:11:21 --> Helper loaded: date_helper
INFO - 2018-06-21 03:11:21 --> Helper loaded: util_helper
INFO - 2018-06-21 03:11:21 --> Helper loaded: text_helper
INFO - 2018-06-21 03:11:21 --> Helper loaded: string_helper
INFO - 2018-06-21 03:11:21 --> Database Driver Class Initialized
DEBUG - 2018-06-21 03:11:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 03:11:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 03:11:21 --> Email Class Initialized
INFO - 2018-06-21 03:11:21 --> Controller Class Initialized
DEBUG - 2018-06-21 03:11:21 --> Users MX_Controller Initialized
DEBUG - 2018-06-21 03:11:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 03:11:21 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 03:11:21 --> Login MX_Controller Initialized
INFO - 2018-06-21 03:11:21 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 03:11:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-21 03:11:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-21 03:11:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-21 03:11:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-21 03:11:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-21 03:11:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-21 03:11:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-06-21 03:11:21 --> Final output sent to browser
DEBUG - 2018-06-21 03:11:21 --> Total execution time: 0.4581
INFO - 2018-06-21 03:11:21 --> Config Class Initialized
INFO - 2018-06-21 03:11:21 --> Hooks Class Initialized
DEBUG - 2018-06-21 03:11:21 --> UTF-8 Support Enabled
INFO - 2018-06-21 03:11:21 --> Utf8 Class Initialized
INFO - 2018-06-21 03:11:21 --> URI Class Initialized
INFO - 2018-06-21 03:11:21 --> Router Class Initialized
INFO - 2018-06-21 03:11:21 --> Output Class Initialized
INFO - 2018-06-21 03:11:21 --> Security Class Initialized
DEBUG - 2018-06-21 03:11:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 03:11:21 --> Input Class Initialized
INFO - 2018-06-21 03:11:21 --> Language Class Initialized
INFO - 2018-06-21 03:11:21 --> Language Class Initialized
INFO - 2018-06-21 03:11:21 --> Config Class Initialized
INFO - 2018-06-21 03:11:21 --> Loader Class Initialized
DEBUG - 2018-06-21 03:11:21 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 03:11:21 --> Helper loaded: url_helper
INFO - 2018-06-21 03:11:22 --> Helper loaded: form_helper
INFO - 2018-06-21 03:11:22 --> Helper loaded: date_helper
INFO - 2018-06-21 03:11:22 --> Helper loaded: util_helper
INFO - 2018-06-21 03:11:22 --> Helper loaded: text_helper
INFO - 2018-06-21 03:11:22 --> Helper loaded: string_helper
INFO - 2018-06-21 03:11:22 --> Database Driver Class Initialized
DEBUG - 2018-06-21 03:11:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 03:11:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 03:11:22 --> Email Class Initialized
INFO - 2018-06-21 03:11:22 --> Controller Class Initialized
DEBUG - 2018-06-21 03:11:22 --> Users MX_Controller Initialized
DEBUG - 2018-06-21 03:11:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 03:11:22 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 03:11:22 --> Login MX_Controller Initialized
INFO - 2018-06-21 03:11:22 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 03:11:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-21 03:11:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-06-21 03:11:22 --> Final output sent to browser
DEBUG - 2018-06-21 03:11:22 --> Total execution time: 0.5280
INFO - 2018-06-21 03:11:33 --> Config Class Initialized
INFO - 2018-06-21 03:11:33 --> Hooks Class Initialized
DEBUG - 2018-06-21 03:11:33 --> UTF-8 Support Enabled
INFO - 2018-06-21 03:11:33 --> Utf8 Class Initialized
INFO - 2018-06-21 03:11:33 --> URI Class Initialized
INFO - 2018-06-21 03:11:33 --> Router Class Initialized
INFO - 2018-06-21 03:11:33 --> Output Class Initialized
INFO - 2018-06-21 03:11:33 --> Security Class Initialized
DEBUG - 2018-06-21 03:11:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 03:11:33 --> Input Class Initialized
INFO - 2018-06-21 03:11:33 --> Language Class Initialized
INFO - 2018-06-21 03:11:33 --> Language Class Initialized
INFO - 2018-06-21 03:11:33 --> Config Class Initialized
INFO - 2018-06-21 03:11:33 --> Loader Class Initialized
DEBUG - 2018-06-21 03:11:33 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 03:11:33 --> Helper loaded: url_helper
INFO - 2018-06-21 03:11:33 --> Helper loaded: form_helper
INFO - 2018-06-21 03:11:33 --> Helper loaded: date_helper
INFO - 2018-06-21 03:11:33 --> Helper loaded: util_helper
INFO - 2018-06-21 03:11:33 --> Helper loaded: text_helper
INFO - 2018-06-21 03:11:33 --> Helper loaded: string_helper
INFO - 2018-06-21 03:11:33 --> Database Driver Class Initialized
DEBUG - 2018-06-21 03:11:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 03:11:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 03:11:33 --> Email Class Initialized
INFO - 2018-06-21 03:11:33 --> Controller Class Initialized
DEBUG - 2018-06-21 03:11:33 --> Users MX_Controller Initialized
DEBUG - 2018-06-21 03:11:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 03:11:33 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 03:11:33 --> Login MX_Controller Initialized
INFO - 2018-06-21 03:11:33 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 03:11:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-21 03:11:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-06-21 03:11:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-21 03:11:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-21 03:11:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-21 03:11:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-21 03:11:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-21 03:11:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-06-21 03:11:33 --> Final output sent to browser
DEBUG - 2018-06-21 03:11:33 --> Total execution time: 0.4460
INFO - 2018-06-21 03:11:54 --> Config Class Initialized
INFO - 2018-06-21 03:11:54 --> Hooks Class Initialized
DEBUG - 2018-06-21 03:11:54 --> UTF-8 Support Enabled
INFO - 2018-06-21 03:11:54 --> Utf8 Class Initialized
INFO - 2018-06-21 03:11:54 --> URI Class Initialized
INFO - 2018-06-21 03:11:54 --> Router Class Initialized
INFO - 2018-06-21 03:11:54 --> Output Class Initialized
INFO - 2018-06-21 03:11:54 --> Security Class Initialized
DEBUG - 2018-06-21 03:11:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 03:11:54 --> Input Class Initialized
INFO - 2018-06-21 03:11:54 --> Language Class Initialized
INFO - 2018-06-21 03:11:54 --> Language Class Initialized
INFO - 2018-06-21 03:11:54 --> Config Class Initialized
INFO - 2018-06-21 03:11:54 --> Loader Class Initialized
DEBUG - 2018-06-21 03:11:54 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 03:11:54 --> Helper loaded: url_helper
INFO - 2018-06-21 03:11:54 --> Helper loaded: form_helper
INFO - 2018-06-21 03:11:54 --> Helper loaded: date_helper
INFO - 2018-06-21 03:11:54 --> Helper loaded: util_helper
INFO - 2018-06-21 03:11:54 --> Helper loaded: text_helper
INFO - 2018-06-21 03:11:54 --> Helper loaded: string_helper
INFO - 2018-06-21 03:11:54 --> Database Driver Class Initialized
DEBUG - 2018-06-21 03:11:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 03:11:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 03:11:54 --> Email Class Initialized
INFO - 2018-06-21 03:11:54 --> Controller Class Initialized
DEBUG - 2018-06-21 03:11:54 --> Users MX_Controller Initialized
DEBUG - 2018-06-21 03:11:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 03:11:54 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 03:11:54 --> Login MX_Controller Initialized
INFO - 2018-06-21 03:11:54 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 03:11:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-21 03:11:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-06-21 03:11:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-21 03:11:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-21 03:11:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-21 03:11:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-21 03:11:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-21 03:11:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-06-21 03:11:54 --> Final output sent to browser
DEBUG - 2018-06-21 03:11:55 --> Total execution time: 0.4345
INFO - 2018-06-21 03:11:58 --> Config Class Initialized
INFO - 2018-06-21 03:11:58 --> Hooks Class Initialized
DEBUG - 2018-06-21 03:11:58 --> UTF-8 Support Enabled
INFO - 2018-06-21 03:11:58 --> Utf8 Class Initialized
INFO - 2018-06-21 03:11:58 --> URI Class Initialized
INFO - 2018-06-21 03:11:58 --> Router Class Initialized
INFO - 2018-06-21 03:11:58 --> Output Class Initialized
INFO - 2018-06-21 03:11:58 --> Security Class Initialized
DEBUG - 2018-06-21 03:11:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 03:11:58 --> Input Class Initialized
INFO - 2018-06-21 03:11:58 --> Language Class Initialized
INFO - 2018-06-21 03:11:58 --> Language Class Initialized
INFO - 2018-06-21 03:11:58 --> Config Class Initialized
INFO - 2018-06-21 03:11:58 --> Loader Class Initialized
DEBUG - 2018-06-21 03:11:58 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 03:11:58 --> Helper loaded: url_helper
INFO - 2018-06-21 03:11:58 --> Helper loaded: form_helper
INFO - 2018-06-21 03:11:58 --> Helper loaded: date_helper
INFO - 2018-06-21 03:11:58 --> Helper loaded: util_helper
INFO - 2018-06-21 03:11:58 --> Helper loaded: text_helper
INFO - 2018-06-21 03:11:58 --> Helper loaded: string_helper
INFO - 2018-06-21 03:11:58 --> Database Driver Class Initialized
DEBUG - 2018-06-21 03:11:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 03:11:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 03:11:58 --> Email Class Initialized
INFO - 2018-06-21 03:11:58 --> Controller Class Initialized
DEBUG - 2018-06-21 03:11:58 --> Users MX_Controller Initialized
DEBUG - 2018-06-21 03:11:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 03:11:58 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 03:11:58 --> Login MX_Controller Initialized
INFO - 2018-06-21 03:11:58 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 03:11:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-21 03:11:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-06-21 03:11:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-21 03:11:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-21 03:11:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-21 03:11:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-21 03:11:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-21 03:11:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-06-21 03:11:58 --> Final output sent to browser
DEBUG - 2018-06-21 03:11:58 --> Total execution time: 0.4472
INFO - 2018-06-21 03:12:19 --> Config Class Initialized
INFO - 2018-06-21 03:12:19 --> Hooks Class Initialized
DEBUG - 2018-06-21 03:12:19 --> UTF-8 Support Enabled
INFO - 2018-06-21 03:12:19 --> Utf8 Class Initialized
INFO - 2018-06-21 03:12:19 --> URI Class Initialized
INFO - 2018-06-21 03:12:19 --> Router Class Initialized
INFO - 2018-06-21 03:12:19 --> Output Class Initialized
INFO - 2018-06-21 03:12:19 --> Security Class Initialized
DEBUG - 2018-06-21 03:12:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 03:12:19 --> Input Class Initialized
INFO - 2018-06-21 03:12:19 --> Language Class Initialized
INFO - 2018-06-21 03:12:19 --> Language Class Initialized
INFO - 2018-06-21 03:12:19 --> Config Class Initialized
INFO - 2018-06-21 03:12:19 --> Loader Class Initialized
DEBUG - 2018-06-21 03:12:19 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 03:12:19 --> Helper loaded: url_helper
INFO - 2018-06-21 03:12:19 --> Helper loaded: form_helper
INFO - 2018-06-21 03:12:19 --> Helper loaded: date_helper
INFO - 2018-06-21 03:12:19 --> Helper loaded: util_helper
INFO - 2018-06-21 03:12:19 --> Helper loaded: text_helper
INFO - 2018-06-21 03:12:19 --> Helper loaded: string_helper
INFO - 2018-06-21 03:12:19 --> Database Driver Class Initialized
DEBUG - 2018-06-21 03:12:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 03:12:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 03:12:19 --> Email Class Initialized
INFO - 2018-06-21 03:12:19 --> Controller Class Initialized
DEBUG - 2018-06-21 03:12:19 --> Users MX_Controller Initialized
DEBUG - 2018-06-21 03:12:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 03:12:19 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 03:12:19 --> Login MX_Controller Initialized
INFO - 2018-06-21 03:12:19 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 03:12:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-21 03:12:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-06-21 03:12:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-21 03:12:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-21 03:12:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
INFO - 2018-06-21 03:12:22 --> Config Class Initialized
INFO - 2018-06-21 03:12:22 --> Hooks Class Initialized
DEBUG - 2018-06-21 03:12:22 --> UTF-8 Support Enabled
INFO - 2018-06-21 03:12:22 --> Utf8 Class Initialized
INFO - 2018-06-21 03:12:22 --> URI Class Initialized
INFO - 2018-06-21 03:12:22 --> Router Class Initialized
INFO - 2018-06-21 03:12:22 --> Output Class Initialized
INFO - 2018-06-21 03:12:22 --> Security Class Initialized
DEBUG - 2018-06-21 03:12:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 03:12:22 --> Input Class Initialized
INFO - 2018-06-21 03:12:22 --> Language Class Initialized
INFO - 2018-06-21 03:12:22 --> Language Class Initialized
INFO - 2018-06-21 03:12:22 --> Config Class Initialized
INFO - 2018-06-21 03:12:22 --> Loader Class Initialized
DEBUG - 2018-06-21 03:12:22 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 03:12:22 --> Helper loaded: url_helper
INFO - 2018-06-21 03:12:22 --> Helper loaded: form_helper
INFO - 2018-06-21 03:12:22 --> Helper loaded: date_helper
INFO - 2018-06-21 03:12:22 --> Helper loaded: util_helper
INFO - 2018-06-21 03:12:22 --> Helper loaded: text_helper
INFO - 2018-06-21 03:12:22 --> Helper loaded: string_helper
INFO - 2018-06-21 03:12:23 --> Database Driver Class Initialized
DEBUG - 2018-06-21 03:12:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 03:12:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 03:12:23 --> Email Class Initialized
INFO - 2018-06-21 03:12:23 --> Controller Class Initialized
DEBUG - 2018-06-21 03:12:23 --> Users MX_Controller Initialized
DEBUG - 2018-06-21 03:12:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 03:12:23 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 03:12:23 --> Login MX_Controller Initialized
INFO - 2018-06-21 03:12:23 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 03:12:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-21 03:12:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-06-21 03:12:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-21 03:12:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-21 03:12:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
INFO - 2018-06-21 03:13:09 --> Config Class Initialized
INFO - 2018-06-21 03:13:09 --> Hooks Class Initialized
DEBUG - 2018-06-21 03:13:09 --> UTF-8 Support Enabled
INFO - 2018-06-21 03:13:09 --> Utf8 Class Initialized
INFO - 2018-06-21 03:13:09 --> URI Class Initialized
INFO - 2018-06-21 03:13:09 --> Router Class Initialized
INFO - 2018-06-21 03:13:09 --> Output Class Initialized
INFO - 2018-06-21 03:13:09 --> Security Class Initialized
DEBUG - 2018-06-21 03:13:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 03:13:09 --> Input Class Initialized
INFO - 2018-06-21 03:13:09 --> Language Class Initialized
INFO - 2018-06-21 03:13:09 --> Language Class Initialized
INFO - 2018-06-21 03:13:09 --> Config Class Initialized
INFO - 2018-06-21 03:13:09 --> Loader Class Initialized
DEBUG - 2018-06-21 03:13:09 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 03:13:09 --> Helper loaded: url_helper
INFO - 2018-06-21 03:13:09 --> Helper loaded: form_helper
INFO - 2018-06-21 03:13:09 --> Helper loaded: date_helper
INFO - 2018-06-21 03:13:09 --> Helper loaded: util_helper
INFO - 2018-06-21 03:13:09 --> Helper loaded: text_helper
INFO - 2018-06-21 03:13:09 --> Helper loaded: string_helper
INFO - 2018-06-21 03:13:09 --> Database Driver Class Initialized
DEBUG - 2018-06-21 03:13:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 03:13:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 03:13:09 --> Email Class Initialized
INFO - 2018-06-21 03:13:09 --> Controller Class Initialized
DEBUG - 2018-06-21 03:13:09 --> Users MX_Controller Initialized
DEBUG - 2018-06-21 03:13:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 03:13:09 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 03:13:09 --> Login MX_Controller Initialized
INFO - 2018-06-21 03:13:09 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 03:13:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-21 03:13:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-06-21 03:13:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-21 03:13:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-21 03:13:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-21 03:13:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-21 03:13:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-21 03:13:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-06-21 03:13:09 --> Final output sent to browser
DEBUG - 2018-06-21 03:13:09 --> Total execution time: 0.4703
INFO - 2018-06-21 03:13:15 --> Config Class Initialized
INFO - 2018-06-21 03:13:15 --> Hooks Class Initialized
DEBUG - 2018-06-21 03:13:15 --> UTF-8 Support Enabled
INFO - 2018-06-21 03:13:15 --> Utf8 Class Initialized
INFO - 2018-06-21 03:13:15 --> URI Class Initialized
INFO - 2018-06-21 03:13:15 --> Router Class Initialized
INFO - 2018-06-21 03:13:15 --> Output Class Initialized
INFO - 2018-06-21 03:13:15 --> Security Class Initialized
DEBUG - 2018-06-21 03:13:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 03:13:15 --> Input Class Initialized
INFO - 2018-06-21 03:13:15 --> Language Class Initialized
INFO - 2018-06-21 03:13:15 --> Language Class Initialized
INFO - 2018-06-21 03:13:15 --> Config Class Initialized
INFO - 2018-06-21 03:13:15 --> Loader Class Initialized
DEBUG - 2018-06-21 03:13:15 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 03:13:15 --> Helper loaded: url_helper
INFO - 2018-06-21 03:13:15 --> Helper loaded: form_helper
INFO - 2018-06-21 03:13:15 --> Helper loaded: date_helper
INFO - 2018-06-21 03:13:15 --> Helper loaded: util_helper
INFO - 2018-06-21 03:13:15 --> Helper loaded: text_helper
INFO - 2018-06-21 03:13:15 --> Helper loaded: string_helper
INFO - 2018-06-21 03:13:15 --> Database Driver Class Initialized
DEBUG - 2018-06-21 03:13:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 03:13:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 03:13:15 --> Email Class Initialized
INFO - 2018-06-21 03:13:15 --> Controller Class Initialized
DEBUG - 2018-06-21 03:13:15 --> Users MX_Controller Initialized
DEBUG - 2018-06-21 03:13:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 03:13:15 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 03:13:15 --> Login MX_Controller Initialized
INFO - 2018-06-21 03:13:15 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 03:13:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-21 03:13:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-06-21 03:13:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-21 03:13:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-21 03:13:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-21 03:13:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-21 03:13:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-21 03:13:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-06-21 03:13:15 --> Final output sent to browser
DEBUG - 2018-06-21 03:13:15 --> Total execution time: 0.4740
INFO - 2018-06-21 03:13:55 --> Config Class Initialized
INFO - 2018-06-21 03:13:55 --> Hooks Class Initialized
DEBUG - 2018-06-21 03:13:55 --> UTF-8 Support Enabled
INFO - 2018-06-21 03:13:55 --> Utf8 Class Initialized
INFO - 2018-06-21 03:13:55 --> URI Class Initialized
INFO - 2018-06-21 03:13:55 --> Router Class Initialized
INFO - 2018-06-21 03:13:55 --> Output Class Initialized
INFO - 2018-06-21 03:13:55 --> Security Class Initialized
DEBUG - 2018-06-21 03:13:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 03:13:55 --> Input Class Initialized
INFO - 2018-06-21 03:13:55 --> Language Class Initialized
INFO - 2018-06-21 03:13:55 --> Language Class Initialized
INFO - 2018-06-21 03:13:55 --> Config Class Initialized
INFO - 2018-06-21 03:13:55 --> Loader Class Initialized
DEBUG - 2018-06-21 03:13:55 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 03:13:55 --> Helper loaded: url_helper
INFO - 2018-06-21 03:13:55 --> Helper loaded: form_helper
INFO - 2018-06-21 03:13:55 --> Helper loaded: date_helper
INFO - 2018-06-21 03:13:55 --> Helper loaded: util_helper
INFO - 2018-06-21 03:13:55 --> Helper loaded: text_helper
INFO - 2018-06-21 03:13:55 --> Helper loaded: string_helper
INFO - 2018-06-21 03:13:55 --> Database Driver Class Initialized
DEBUG - 2018-06-21 03:13:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 03:13:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 03:13:55 --> Email Class Initialized
INFO - 2018-06-21 03:13:55 --> Controller Class Initialized
DEBUG - 2018-06-21 03:13:55 --> Users MX_Controller Initialized
DEBUG - 2018-06-21 03:13:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 03:13:55 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 03:13:55 --> Login MX_Controller Initialized
INFO - 2018-06-21 03:13:55 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 03:13:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-21 03:13:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-06-21 03:13:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-21 03:13:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-21 03:13:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-21 03:13:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-21 03:13:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-21 03:13:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-06-21 03:13:56 --> Final output sent to browser
DEBUG - 2018-06-21 03:13:56 --> Total execution time: 0.4975
INFO - 2018-06-21 03:13:59 --> Config Class Initialized
INFO - 2018-06-21 03:13:59 --> Hooks Class Initialized
DEBUG - 2018-06-21 03:13:59 --> UTF-8 Support Enabled
INFO - 2018-06-21 03:13:59 --> Utf8 Class Initialized
INFO - 2018-06-21 03:13:59 --> URI Class Initialized
INFO - 2018-06-21 03:13:59 --> Router Class Initialized
INFO - 2018-06-21 03:13:59 --> Output Class Initialized
INFO - 2018-06-21 03:13:59 --> Security Class Initialized
DEBUG - 2018-06-21 03:13:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 03:13:59 --> Input Class Initialized
INFO - 2018-06-21 03:13:59 --> Language Class Initialized
INFO - 2018-06-21 03:13:59 --> Language Class Initialized
INFO - 2018-06-21 03:13:59 --> Config Class Initialized
INFO - 2018-06-21 03:13:59 --> Loader Class Initialized
DEBUG - 2018-06-21 03:13:59 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 03:13:59 --> Helper loaded: url_helper
INFO - 2018-06-21 03:13:59 --> Helper loaded: form_helper
INFO - 2018-06-21 03:13:59 --> Helper loaded: date_helper
INFO - 2018-06-21 03:13:59 --> Helper loaded: util_helper
INFO - 2018-06-21 03:13:59 --> Helper loaded: text_helper
INFO - 2018-06-21 03:13:59 --> Helper loaded: string_helper
INFO - 2018-06-21 03:13:59 --> Database Driver Class Initialized
DEBUG - 2018-06-21 03:13:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 03:13:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 03:13:59 --> Email Class Initialized
INFO - 2018-06-21 03:13:59 --> Controller Class Initialized
DEBUG - 2018-06-21 03:13:59 --> Users MX_Controller Initialized
DEBUG - 2018-06-21 03:13:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 03:13:59 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 03:13:59 --> Login MX_Controller Initialized
INFO - 2018-06-21 03:13:59 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 03:13:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-21 03:13:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-06-21 03:13:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-21 03:13:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-21 03:13:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-21 03:13:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-21 03:13:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-21 03:13:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-06-21 03:13:59 --> Final output sent to browser
DEBUG - 2018-06-21 03:13:59 --> Total execution time: 0.4672
INFO - 2018-06-21 03:14:11 --> Config Class Initialized
INFO - 2018-06-21 03:14:11 --> Hooks Class Initialized
DEBUG - 2018-06-21 03:14:11 --> UTF-8 Support Enabled
INFO - 2018-06-21 03:14:11 --> Utf8 Class Initialized
INFO - 2018-06-21 03:14:11 --> URI Class Initialized
INFO - 2018-06-21 03:14:11 --> Router Class Initialized
INFO - 2018-06-21 03:14:11 --> Output Class Initialized
INFO - 2018-06-21 03:14:11 --> Security Class Initialized
DEBUG - 2018-06-21 03:14:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 03:14:11 --> Input Class Initialized
INFO - 2018-06-21 03:14:11 --> Language Class Initialized
INFO - 2018-06-21 03:14:11 --> Language Class Initialized
INFO - 2018-06-21 03:14:11 --> Config Class Initialized
INFO - 2018-06-21 03:14:11 --> Loader Class Initialized
DEBUG - 2018-06-21 03:14:11 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 03:14:11 --> Helper loaded: url_helper
INFO - 2018-06-21 03:14:11 --> Helper loaded: form_helper
INFO - 2018-06-21 03:14:11 --> Helper loaded: date_helper
INFO - 2018-06-21 03:14:12 --> Helper loaded: util_helper
INFO - 2018-06-21 03:14:12 --> Helper loaded: text_helper
INFO - 2018-06-21 03:14:12 --> Helper loaded: string_helper
INFO - 2018-06-21 03:14:12 --> Database Driver Class Initialized
DEBUG - 2018-06-21 03:14:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 03:14:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 03:14:12 --> Email Class Initialized
INFO - 2018-06-21 03:14:12 --> Controller Class Initialized
DEBUG - 2018-06-21 03:14:12 --> Users MX_Controller Initialized
DEBUG - 2018-06-21 03:14:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 03:14:12 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 03:14:12 --> Login MX_Controller Initialized
INFO - 2018-06-21 03:14:12 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 03:14:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-21 03:14:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-06-21 03:14:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-21 03:14:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-21 03:14:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-21 03:14:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-21 03:14:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-21 03:14:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-06-21 03:14:12 --> Final output sent to browser
DEBUG - 2018-06-21 03:14:12 --> Total execution time: 0.4805
INFO - 2018-06-21 03:14:19 --> Config Class Initialized
INFO - 2018-06-21 03:14:19 --> Hooks Class Initialized
DEBUG - 2018-06-21 03:14:19 --> UTF-8 Support Enabled
INFO - 2018-06-21 03:14:19 --> Utf8 Class Initialized
INFO - 2018-06-21 03:14:19 --> URI Class Initialized
INFO - 2018-06-21 03:14:19 --> Router Class Initialized
INFO - 2018-06-21 03:14:19 --> Output Class Initialized
INFO - 2018-06-21 03:14:19 --> Security Class Initialized
DEBUG - 2018-06-21 03:14:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 03:14:19 --> Input Class Initialized
INFO - 2018-06-21 03:14:19 --> Language Class Initialized
INFO - 2018-06-21 03:14:19 --> Language Class Initialized
INFO - 2018-06-21 03:14:19 --> Config Class Initialized
INFO - 2018-06-21 03:14:19 --> Loader Class Initialized
DEBUG - 2018-06-21 03:14:19 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 03:14:19 --> Helper loaded: url_helper
INFO - 2018-06-21 03:14:19 --> Helper loaded: form_helper
INFO - 2018-06-21 03:14:19 --> Helper loaded: date_helper
INFO - 2018-06-21 03:14:19 --> Helper loaded: util_helper
INFO - 2018-06-21 03:14:19 --> Helper loaded: text_helper
INFO - 2018-06-21 03:14:19 --> Helper loaded: string_helper
INFO - 2018-06-21 03:14:19 --> Database Driver Class Initialized
DEBUG - 2018-06-21 03:14:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 03:14:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 03:14:19 --> Email Class Initialized
INFO - 2018-06-21 03:14:19 --> Controller Class Initialized
DEBUG - 2018-06-21 03:14:19 --> Users MX_Controller Initialized
DEBUG - 2018-06-21 03:14:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 03:14:19 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 03:14:19 --> Login MX_Controller Initialized
INFO - 2018-06-21 03:14:19 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 03:14:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-21 03:14:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-06-21 03:14:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-21 03:14:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-21 03:14:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-21 03:14:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-21 03:14:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-21 03:14:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-06-21 03:14:19 --> Final output sent to browser
DEBUG - 2018-06-21 03:14:19 --> Total execution time: 0.4655
INFO - 2018-06-21 03:14:28 --> Config Class Initialized
INFO - 2018-06-21 03:14:28 --> Hooks Class Initialized
DEBUG - 2018-06-21 03:14:28 --> UTF-8 Support Enabled
INFO - 2018-06-21 03:14:28 --> Utf8 Class Initialized
INFO - 2018-06-21 03:14:28 --> URI Class Initialized
INFO - 2018-06-21 03:14:28 --> Router Class Initialized
INFO - 2018-06-21 03:14:28 --> Output Class Initialized
INFO - 2018-06-21 03:14:28 --> Security Class Initialized
DEBUG - 2018-06-21 03:14:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 03:14:28 --> Input Class Initialized
INFO - 2018-06-21 03:14:28 --> Language Class Initialized
INFO - 2018-06-21 03:14:28 --> Language Class Initialized
INFO - 2018-06-21 03:14:28 --> Config Class Initialized
INFO - 2018-06-21 03:14:28 --> Loader Class Initialized
DEBUG - 2018-06-21 03:14:28 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 03:14:28 --> Helper loaded: url_helper
INFO - 2018-06-21 03:14:28 --> Helper loaded: form_helper
INFO - 2018-06-21 03:14:28 --> Helper loaded: date_helper
INFO - 2018-06-21 03:14:28 --> Helper loaded: util_helper
INFO - 2018-06-21 03:14:28 --> Helper loaded: text_helper
INFO - 2018-06-21 03:14:28 --> Helper loaded: string_helper
INFO - 2018-06-21 03:14:28 --> Database Driver Class Initialized
DEBUG - 2018-06-21 03:14:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 03:14:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 03:14:28 --> Email Class Initialized
INFO - 2018-06-21 03:14:28 --> Controller Class Initialized
DEBUG - 2018-06-21 03:14:28 --> Users MX_Controller Initialized
DEBUG - 2018-06-21 03:14:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 03:14:28 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 03:14:28 --> Login MX_Controller Initialized
INFO - 2018-06-21 03:14:28 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 03:14:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-21 03:14:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-06-21 03:14:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-21 03:14:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-21 03:14:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-21 03:14:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-21 03:14:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-21 03:14:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-06-21 03:14:28 --> Final output sent to browser
DEBUG - 2018-06-21 03:14:28 --> Total execution time: 0.4691
INFO - 2018-06-21 03:14:51 --> Config Class Initialized
INFO - 2018-06-21 03:14:51 --> Hooks Class Initialized
DEBUG - 2018-06-21 03:14:51 --> UTF-8 Support Enabled
INFO - 2018-06-21 03:14:51 --> Utf8 Class Initialized
INFO - 2018-06-21 03:14:51 --> URI Class Initialized
INFO - 2018-06-21 03:14:51 --> Router Class Initialized
INFO - 2018-06-21 03:14:51 --> Output Class Initialized
INFO - 2018-06-21 03:14:51 --> Security Class Initialized
DEBUG - 2018-06-21 03:14:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 03:14:51 --> Input Class Initialized
INFO - 2018-06-21 03:14:51 --> Language Class Initialized
INFO - 2018-06-21 03:14:51 --> Language Class Initialized
INFO - 2018-06-21 03:14:51 --> Config Class Initialized
INFO - 2018-06-21 03:14:51 --> Loader Class Initialized
DEBUG - 2018-06-21 03:14:51 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 03:14:51 --> Helper loaded: url_helper
INFO - 2018-06-21 03:14:51 --> Helper loaded: form_helper
INFO - 2018-06-21 03:14:51 --> Helper loaded: date_helper
INFO - 2018-06-21 03:14:51 --> Helper loaded: util_helper
INFO - 2018-06-21 03:14:51 --> Helper loaded: text_helper
INFO - 2018-06-21 03:14:51 --> Helper loaded: string_helper
INFO - 2018-06-21 03:14:51 --> Database Driver Class Initialized
DEBUG - 2018-06-21 03:14:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 03:14:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 03:14:51 --> Email Class Initialized
INFO - 2018-06-21 03:14:51 --> Controller Class Initialized
DEBUG - 2018-06-21 03:14:51 --> Users MX_Controller Initialized
DEBUG - 2018-06-21 03:14:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 03:14:51 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 03:14:51 --> Login MX_Controller Initialized
INFO - 2018-06-21 03:14:51 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 03:14:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-21 03:14:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-06-21 03:14:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-21 03:14:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-21 03:14:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-21 03:14:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-21 03:14:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-21 03:14:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-06-21 03:14:51 --> Final output sent to browser
DEBUG - 2018-06-21 03:14:51 --> Total execution time: 0.4814
INFO - 2018-06-21 03:15:05 --> Config Class Initialized
INFO - 2018-06-21 03:15:05 --> Hooks Class Initialized
DEBUG - 2018-06-21 03:15:05 --> UTF-8 Support Enabled
INFO - 2018-06-21 03:15:05 --> Utf8 Class Initialized
INFO - 2018-06-21 03:15:05 --> URI Class Initialized
INFO - 2018-06-21 03:15:05 --> Router Class Initialized
INFO - 2018-06-21 03:15:05 --> Output Class Initialized
INFO - 2018-06-21 03:15:05 --> Security Class Initialized
DEBUG - 2018-06-21 03:15:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 03:15:05 --> Input Class Initialized
INFO - 2018-06-21 03:15:05 --> Language Class Initialized
INFO - 2018-06-21 03:15:05 --> Language Class Initialized
INFO - 2018-06-21 03:15:05 --> Config Class Initialized
INFO - 2018-06-21 03:15:05 --> Loader Class Initialized
DEBUG - 2018-06-21 03:15:05 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 03:15:05 --> Helper loaded: url_helper
INFO - 2018-06-21 03:15:05 --> Helper loaded: form_helper
INFO - 2018-06-21 03:15:05 --> Helper loaded: date_helper
INFO - 2018-06-21 03:15:05 --> Helper loaded: util_helper
INFO - 2018-06-21 03:15:05 --> Helper loaded: text_helper
INFO - 2018-06-21 03:15:05 --> Helper loaded: string_helper
INFO - 2018-06-21 03:15:05 --> Database Driver Class Initialized
DEBUG - 2018-06-21 03:15:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 03:15:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 03:15:05 --> Email Class Initialized
INFO - 2018-06-21 03:15:05 --> Controller Class Initialized
DEBUG - 2018-06-21 03:15:05 --> Users MX_Controller Initialized
DEBUG - 2018-06-21 03:15:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 03:15:05 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 03:15:05 --> Login MX_Controller Initialized
INFO - 2018-06-21 03:15:05 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 03:15:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-21 03:15:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-06-21 03:15:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-21 03:15:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-21 03:15:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-21 03:15:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-21 03:15:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-21 03:15:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-06-21 03:15:05 --> Final output sent to browser
DEBUG - 2018-06-21 03:15:05 --> Total execution time: 0.4803
INFO - 2018-06-21 03:15:59 --> Config Class Initialized
INFO - 2018-06-21 03:15:59 --> Hooks Class Initialized
DEBUG - 2018-06-21 03:15:59 --> UTF-8 Support Enabled
INFO - 2018-06-21 03:15:59 --> Utf8 Class Initialized
INFO - 2018-06-21 03:15:59 --> URI Class Initialized
INFO - 2018-06-21 03:15:59 --> Router Class Initialized
INFO - 2018-06-21 03:15:59 --> Output Class Initialized
INFO - 2018-06-21 03:15:59 --> Security Class Initialized
DEBUG - 2018-06-21 03:15:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 03:15:59 --> Input Class Initialized
INFO - 2018-06-21 03:15:59 --> Language Class Initialized
INFO - 2018-06-21 03:15:59 --> Language Class Initialized
INFO - 2018-06-21 03:15:59 --> Config Class Initialized
INFO - 2018-06-21 03:15:59 --> Loader Class Initialized
DEBUG - 2018-06-21 03:15:59 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 03:15:59 --> Helper loaded: url_helper
INFO - 2018-06-21 03:15:59 --> Helper loaded: form_helper
INFO - 2018-06-21 03:15:59 --> Helper loaded: date_helper
INFO - 2018-06-21 03:15:59 --> Helper loaded: util_helper
INFO - 2018-06-21 03:15:59 --> Helper loaded: text_helper
INFO - 2018-06-21 03:15:59 --> Helper loaded: string_helper
INFO - 2018-06-21 03:15:59 --> Database Driver Class Initialized
DEBUG - 2018-06-21 03:15:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 03:15:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 03:15:59 --> Email Class Initialized
INFO - 2018-06-21 03:15:59 --> Controller Class Initialized
DEBUG - 2018-06-21 03:15:59 --> Users MX_Controller Initialized
DEBUG - 2018-06-21 03:15:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 03:15:59 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 03:15:59 --> Login MX_Controller Initialized
INFO - 2018-06-21 03:15:59 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 03:15:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-21 03:15:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-06-21 03:15:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-21 03:15:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-21 03:15:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-21 03:15:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-21 03:15:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-21 03:15:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-06-21 03:15:59 --> Final output sent to browser
DEBUG - 2018-06-21 03:15:59 --> Total execution time: 0.4808
INFO - 2018-06-21 03:16:06 --> Config Class Initialized
INFO - 2018-06-21 03:16:06 --> Hooks Class Initialized
DEBUG - 2018-06-21 03:16:06 --> UTF-8 Support Enabled
INFO - 2018-06-21 03:16:06 --> Utf8 Class Initialized
INFO - 2018-06-21 03:16:06 --> URI Class Initialized
INFO - 2018-06-21 03:16:06 --> Router Class Initialized
INFO - 2018-06-21 03:16:06 --> Output Class Initialized
INFO - 2018-06-21 03:16:06 --> Security Class Initialized
DEBUG - 2018-06-21 03:16:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 03:16:06 --> Input Class Initialized
INFO - 2018-06-21 03:16:06 --> Language Class Initialized
INFO - 2018-06-21 03:16:06 --> Language Class Initialized
INFO - 2018-06-21 03:16:06 --> Config Class Initialized
INFO - 2018-06-21 03:16:06 --> Loader Class Initialized
DEBUG - 2018-06-21 03:16:06 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 03:16:06 --> Helper loaded: url_helper
INFO - 2018-06-21 03:16:06 --> Helper loaded: form_helper
INFO - 2018-06-21 03:16:06 --> Helper loaded: date_helper
INFO - 2018-06-21 03:16:06 --> Helper loaded: util_helper
INFO - 2018-06-21 03:16:06 --> Helper loaded: text_helper
INFO - 2018-06-21 03:16:06 --> Helper loaded: string_helper
INFO - 2018-06-21 03:16:06 --> Database Driver Class Initialized
DEBUG - 2018-06-21 03:16:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 03:16:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 03:16:06 --> Email Class Initialized
INFO - 2018-06-21 03:16:06 --> Controller Class Initialized
DEBUG - 2018-06-21 03:16:06 --> Users MX_Controller Initialized
DEBUG - 2018-06-21 03:16:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 03:16:06 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 03:16:06 --> Login MX_Controller Initialized
INFO - 2018-06-21 03:16:06 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 03:16:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-21 03:16:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-06-21 03:16:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-21 03:16:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-21 03:16:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-21 03:16:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-21 03:16:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-21 03:16:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-06-21 03:16:06 --> Final output sent to browser
DEBUG - 2018-06-21 03:16:07 --> Total execution time: 0.4917
INFO - 2018-06-21 03:16:37 --> Config Class Initialized
INFO - 2018-06-21 03:16:37 --> Hooks Class Initialized
DEBUG - 2018-06-21 03:16:37 --> UTF-8 Support Enabled
INFO - 2018-06-21 03:16:37 --> Utf8 Class Initialized
INFO - 2018-06-21 03:16:37 --> URI Class Initialized
INFO - 2018-06-21 03:16:38 --> Router Class Initialized
INFO - 2018-06-21 03:16:38 --> Output Class Initialized
INFO - 2018-06-21 03:16:38 --> Security Class Initialized
DEBUG - 2018-06-21 03:16:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 03:16:38 --> Input Class Initialized
INFO - 2018-06-21 03:16:38 --> Language Class Initialized
INFO - 2018-06-21 03:16:38 --> Language Class Initialized
INFO - 2018-06-21 03:16:38 --> Config Class Initialized
INFO - 2018-06-21 03:16:38 --> Loader Class Initialized
DEBUG - 2018-06-21 03:16:38 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 03:16:38 --> Helper loaded: url_helper
INFO - 2018-06-21 03:16:38 --> Helper loaded: form_helper
INFO - 2018-06-21 03:16:38 --> Helper loaded: date_helper
INFO - 2018-06-21 03:16:38 --> Helper loaded: util_helper
INFO - 2018-06-21 03:16:38 --> Helper loaded: text_helper
INFO - 2018-06-21 03:16:38 --> Helper loaded: string_helper
INFO - 2018-06-21 03:16:38 --> Database Driver Class Initialized
DEBUG - 2018-06-21 03:16:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 03:16:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 03:16:38 --> Email Class Initialized
INFO - 2018-06-21 03:16:38 --> Controller Class Initialized
DEBUG - 2018-06-21 03:16:38 --> Users MX_Controller Initialized
DEBUG - 2018-06-21 03:16:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 03:16:38 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 03:16:38 --> Login MX_Controller Initialized
INFO - 2018-06-21 03:16:38 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 03:16:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-21 03:16:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-06-21 03:16:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-21 03:16:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-21 03:16:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-21 03:16:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-21 03:16:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-21 03:16:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-06-21 03:16:38 --> Final output sent to browser
DEBUG - 2018-06-21 03:16:38 --> Total execution time: 0.4844
INFO - 2018-06-21 03:17:20 --> Config Class Initialized
INFO - 2018-06-21 03:17:20 --> Hooks Class Initialized
DEBUG - 2018-06-21 03:17:20 --> UTF-8 Support Enabled
INFO - 2018-06-21 03:17:20 --> Utf8 Class Initialized
INFO - 2018-06-21 03:17:20 --> URI Class Initialized
INFO - 2018-06-21 03:17:20 --> Router Class Initialized
INFO - 2018-06-21 03:17:20 --> Output Class Initialized
INFO - 2018-06-21 03:17:20 --> Security Class Initialized
DEBUG - 2018-06-21 03:17:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 03:17:20 --> Input Class Initialized
INFO - 2018-06-21 03:17:20 --> Language Class Initialized
INFO - 2018-06-21 03:17:20 --> Language Class Initialized
INFO - 2018-06-21 03:17:20 --> Config Class Initialized
INFO - 2018-06-21 03:17:20 --> Loader Class Initialized
DEBUG - 2018-06-21 03:17:20 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 03:17:20 --> Helper loaded: url_helper
INFO - 2018-06-21 03:17:20 --> Helper loaded: form_helper
INFO - 2018-06-21 03:17:20 --> Helper loaded: date_helper
INFO - 2018-06-21 03:17:20 --> Helper loaded: util_helper
INFO - 2018-06-21 03:17:20 --> Helper loaded: text_helper
INFO - 2018-06-21 03:17:20 --> Helper loaded: string_helper
INFO - 2018-06-21 03:17:20 --> Database Driver Class Initialized
DEBUG - 2018-06-21 03:17:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 03:17:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 03:17:20 --> Email Class Initialized
INFO - 2018-06-21 03:17:20 --> Controller Class Initialized
DEBUG - 2018-06-21 03:17:20 --> Users MX_Controller Initialized
DEBUG - 2018-06-21 03:17:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 03:17:20 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 03:17:20 --> Login MX_Controller Initialized
INFO - 2018-06-21 03:17:20 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 03:17:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-21 03:17:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-06-21 03:17:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-21 03:17:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-21 03:17:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-21 03:17:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-21 03:17:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-21 03:17:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-06-21 03:17:20 --> Final output sent to browser
DEBUG - 2018-06-21 03:17:20 --> Total execution time: 0.4861
INFO - 2018-06-21 03:36:04 --> Config Class Initialized
INFO - 2018-06-21 03:36:04 --> Hooks Class Initialized
DEBUG - 2018-06-21 03:36:04 --> UTF-8 Support Enabled
INFO - 2018-06-21 03:36:04 --> Utf8 Class Initialized
INFO - 2018-06-21 03:36:04 --> URI Class Initialized
INFO - 2018-06-21 03:36:05 --> Router Class Initialized
INFO - 2018-06-21 03:36:05 --> Output Class Initialized
INFO - 2018-06-21 03:36:05 --> Security Class Initialized
DEBUG - 2018-06-21 03:36:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 03:36:05 --> Input Class Initialized
INFO - 2018-06-21 03:36:05 --> Language Class Initialized
INFO - 2018-06-21 03:36:05 --> Language Class Initialized
INFO - 2018-06-21 03:36:05 --> Config Class Initialized
INFO - 2018-06-21 03:36:05 --> Loader Class Initialized
DEBUG - 2018-06-21 03:36:05 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 03:36:05 --> Helper loaded: url_helper
INFO - 2018-06-21 03:36:05 --> Helper loaded: form_helper
INFO - 2018-06-21 03:36:05 --> Helper loaded: date_helper
INFO - 2018-06-21 03:36:05 --> Helper loaded: util_helper
INFO - 2018-06-21 03:36:05 --> Helper loaded: text_helper
INFO - 2018-06-21 03:36:05 --> Helper loaded: string_helper
INFO - 2018-06-21 03:36:05 --> Database Driver Class Initialized
DEBUG - 2018-06-21 03:36:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 03:36:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 03:36:05 --> Email Class Initialized
INFO - 2018-06-21 03:36:05 --> Controller Class Initialized
DEBUG - 2018-06-21 03:36:05 --> Users MX_Controller Initialized
DEBUG - 2018-06-21 03:36:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 03:36:05 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 03:36:05 --> Login MX_Controller Initialized
INFO - 2018-06-21 03:36:05 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 03:36:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-21 03:36:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
INFO - 2018-06-21 03:36:05 --> Config Class Initialized
INFO - 2018-06-21 03:36:05 --> Hooks Class Initialized
DEBUG - 2018-06-21 03:36:05 --> UTF-8 Support Enabled
INFO - 2018-06-21 03:36:05 --> Utf8 Class Initialized
INFO - 2018-06-21 03:36:05 --> URI Class Initialized
INFO - 2018-06-21 03:36:05 --> Router Class Initialized
INFO - 2018-06-21 03:36:05 --> Output Class Initialized
INFO - 2018-06-21 03:36:05 --> Security Class Initialized
DEBUG - 2018-06-21 03:36:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 03:36:05 --> Input Class Initialized
INFO - 2018-06-21 03:36:05 --> Language Class Initialized
ERROR - 2018-06-21 03:36:05 --> 404 Page Not Found: /index
INFO - 2018-06-21 03:36:06 --> Config Class Initialized
INFO - 2018-06-21 03:36:06 --> Hooks Class Initialized
DEBUG - 2018-06-21 03:36:06 --> UTF-8 Support Enabled
INFO - 2018-06-21 03:36:06 --> Utf8 Class Initialized
INFO - 2018-06-21 03:36:06 --> URI Class Initialized
INFO - 2018-06-21 03:36:06 --> Router Class Initialized
INFO - 2018-06-21 03:36:06 --> Output Class Initialized
INFO - 2018-06-21 03:36:06 --> Security Class Initialized
DEBUG - 2018-06-21 03:36:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 03:36:06 --> Input Class Initialized
INFO - 2018-06-21 03:36:06 --> Language Class Initialized
ERROR - 2018-06-21 03:36:06 --> 404 Page Not Found: /index
INFO - 2018-06-21 03:36:15 --> Config Class Initialized
INFO - 2018-06-21 03:36:15 --> Hooks Class Initialized
DEBUG - 2018-06-21 03:36:15 --> UTF-8 Support Enabled
INFO - 2018-06-21 03:36:15 --> Utf8 Class Initialized
INFO - 2018-06-21 03:36:15 --> URI Class Initialized
INFO - 2018-06-21 03:36:15 --> Router Class Initialized
INFO - 2018-06-21 03:36:15 --> Output Class Initialized
INFO - 2018-06-21 03:36:16 --> Security Class Initialized
DEBUG - 2018-06-21 03:36:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 03:36:16 --> Input Class Initialized
INFO - 2018-06-21 03:36:16 --> Language Class Initialized
INFO - 2018-06-21 03:36:16 --> Language Class Initialized
INFO - 2018-06-21 03:36:16 --> Config Class Initialized
INFO - 2018-06-21 03:36:16 --> Loader Class Initialized
DEBUG - 2018-06-21 03:36:16 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 03:36:16 --> Helper loaded: url_helper
INFO - 2018-06-21 03:36:16 --> Helper loaded: form_helper
INFO - 2018-06-21 03:36:16 --> Helper loaded: date_helper
INFO - 2018-06-21 03:36:16 --> Helper loaded: util_helper
INFO - 2018-06-21 03:36:16 --> Helper loaded: text_helper
INFO - 2018-06-21 03:36:16 --> Helper loaded: string_helper
INFO - 2018-06-21 03:36:16 --> Database Driver Class Initialized
DEBUG - 2018-06-21 03:36:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 03:36:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 03:36:16 --> Email Class Initialized
INFO - 2018-06-21 03:36:16 --> Controller Class Initialized
DEBUG - 2018-06-21 03:36:16 --> Login MX_Controller Initialized
INFO - 2018-06-21 03:36:16 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 03:36:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 03:36:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-21 03:36:16 --> Email starts for admin@colin.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-06-21 03:36:16 --> User session created for 1
INFO - 2018-06-21 03:36:16 --> Login status admin@colin.com - success
INFO - 2018-06-21 03:36:16 --> Final output sent to browser
DEBUG - 2018-06-21 03:36:16 --> Total execution time: 0.5137
INFO - 2018-06-21 03:36:16 --> Config Class Initialized
INFO - 2018-06-21 03:36:16 --> Hooks Class Initialized
DEBUG - 2018-06-21 03:36:16 --> UTF-8 Support Enabled
INFO - 2018-06-21 03:36:16 --> Utf8 Class Initialized
INFO - 2018-06-21 03:36:16 --> URI Class Initialized
INFO - 2018-06-21 03:36:16 --> Router Class Initialized
INFO - 2018-06-21 03:36:16 --> Output Class Initialized
INFO - 2018-06-21 03:36:16 --> Security Class Initialized
DEBUG - 2018-06-21 03:36:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 03:36:16 --> Input Class Initialized
INFO - 2018-06-21 03:36:16 --> Language Class Initialized
INFO - 2018-06-21 03:36:16 --> Language Class Initialized
INFO - 2018-06-21 03:36:16 --> Config Class Initialized
INFO - 2018-06-21 03:36:16 --> Loader Class Initialized
DEBUG - 2018-06-21 03:36:16 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 03:36:16 --> Helper loaded: url_helper
INFO - 2018-06-21 03:36:16 --> Helper loaded: form_helper
INFO - 2018-06-21 03:36:16 --> Helper loaded: date_helper
INFO - 2018-06-21 03:36:16 --> Helper loaded: util_helper
INFO - 2018-06-21 03:36:16 --> Helper loaded: text_helper
INFO - 2018-06-21 03:36:16 --> Helper loaded: string_helper
INFO - 2018-06-21 03:36:16 --> Database Driver Class Initialized
DEBUG - 2018-06-21 03:36:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 03:36:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 03:36:16 --> Email Class Initialized
INFO - 2018-06-21 03:36:16 --> Controller Class Initialized
DEBUG - 2018-06-21 03:36:16 --> Users MX_Controller Initialized
DEBUG - 2018-06-21 03:36:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 03:36:16 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 03:36:16 --> Login MX_Controller Initialized
INFO - 2018-06-21 03:36:16 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 03:36:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-21 03:36:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-06-21 03:36:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-21 03:36:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-21 03:36:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-21 03:36:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-21 03:36:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-21 03:36:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-06-21 03:36:17 --> Final output sent to browser
DEBUG - 2018-06-21 03:36:17 --> Total execution time: 0.4832
INFO - 2018-06-21 03:36:20 --> Config Class Initialized
INFO - 2018-06-21 03:36:20 --> Hooks Class Initialized
DEBUG - 2018-06-21 03:36:20 --> UTF-8 Support Enabled
INFO - 2018-06-21 03:36:20 --> Utf8 Class Initialized
INFO - 2018-06-21 03:36:20 --> URI Class Initialized
INFO - 2018-06-21 03:36:20 --> Router Class Initialized
INFO - 2018-06-21 03:36:20 --> Output Class Initialized
INFO - 2018-06-21 03:36:20 --> Security Class Initialized
DEBUG - 2018-06-21 03:36:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 03:36:20 --> Input Class Initialized
INFO - 2018-06-21 03:36:20 --> Language Class Initialized
INFO - 2018-06-21 03:36:20 --> Language Class Initialized
INFO - 2018-06-21 03:36:20 --> Config Class Initialized
INFO - 2018-06-21 03:36:20 --> Loader Class Initialized
DEBUG - 2018-06-21 03:36:20 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 03:36:20 --> Helper loaded: url_helper
INFO - 2018-06-21 03:36:20 --> Helper loaded: form_helper
INFO - 2018-06-21 03:36:20 --> Helper loaded: date_helper
INFO - 2018-06-21 03:36:20 --> Helper loaded: util_helper
INFO - 2018-06-21 03:36:20 --> Helper loaded: text_helper
INFO - 2018-06-21 03:36:20 --> Helper loaded: string_helper
INFO - 2018-06-21 03:36:20 --> Database Driver Class Initialized
DEBUG - 2018-06-21 03:36:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 03:36:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 03:36:21 --> Email Class Initialized
INFO - 2018-06-21 03:36:21 --> Controller Class Initialized
DEBUG - 2018-06-21 03:36:21 --> Users MX_Controller Initialized
DEBUG - 2018-06-21 03:36:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 03:36:21 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 03:36:21 --> Login MX_Controller Initialized
INFO - 2018-06-21 03:36:21 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 03:36:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-21 03:36:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-06-21 03:36:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-21 03:36:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-21 03:36:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-21 03:36:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-21 03:36:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-21 03:36:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-06-21 03:36:21 --> Final output sent to browser
DEBUG - 2018-06-21 03:36:21 --> Total execution time: 0.5668
INFO - 2018-06-21 03:37:37 --> Config Class Initialized
INFO - 2018-06-21 03:37:37 --> Hooks Class Initialized
DEBUG - 2018-06-21 03:37:37 --> UTF-8 Support Enabled
INFO - 2018-06-21 03:37:37 --> Utf8 Class Initialized
INFO - 2018-06-21 03:37:37 --> URI Class Initialized
INFO - 2018-06-21 03:37:38 --> Router Class Initialized
INFO - 2018-06-21 03:37:38 --> Output Class Initialized
INFO - 2018-06-21 03:37:38 --> Security Class Initialized
DEBUG - 2018-06-21 03:37:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 03:37:38 --> Input Class Initialized
INFO - 2018-06-21 03:37:38 --> Language Class Initialized
INFO - 2018-06-21 03:37:38 --> Language Class Initialized
INFO - 2018-06-21 03:37:38 --> Config Class Initialized
INFO - 2018-06-21 03:37:38 --> Loader Class Initialized
DEBUG - 2018-06-21 03:37:38 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 03:37:38 --> Helper loaded: url_helper
INFO - 2018-06-21 03:37:38 --> Helper loaded: form_helper
INFO - 2018-06-21 03:37:38 --> Helper loaded: date_helper
INFO - 2018-06-21 03:37:38 --> Helper loaded: util_helper
INFO - 2018-06-21 03:37:38 --> Helper loaded: text_helper
INFO - 2018-06-21 03:37:38 --> Helper loaded: string_helper
INFO - 2018-06-21 03:37:38 --> Database Driver Class Initialized
DEBUG - 2018-06-21 03:37:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 03:37:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 03:37:38 --> Email Class Initialized
INFO - 2018-06-21 03:37:38 --> Controller Class Initialized
DEBUG - 2018-06-21 03:37:38 --> Users MX_Controller Initialized
DEBUG - 2018-06-21 03:37:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 03:37:38 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 03:37:38 --> Login MX_Controller Initialized
INFO - 2018-06-21 03:37:38 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 03:37:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-21 03:37:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-06-21 03:37:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-21 03:37:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-21 03:37:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-21 03:37:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-21 03:37:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-21 03:37:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-06-21 03:37:38 --> Final output sent to browser
DEBUG - 2018-06-21 03:37:38 --> Total execution time: 0.4962
INFO - 2018-06-21 03:43:41 --> Config Class Initialized
INFO - 2018-06-21 03:43:41 --> Hooks Class Initialized
DEBUG - 2018-06-21 03:43:41 --> UTF-8 Support Enabled
INFO - 2018-06-21 03:43:41 --> Utf8 Class Initialized
INFO - 2018-06-21 03:43:41 --> URI Class Initialized
INFO - 2018-06-21 03:43:41 --> Router Class Initialized
INFO - 2018-06-21 03:43:41 --> Output Class Initialized
INFO - 2018-06-21 03:43:41 --> Security Class Initialized
DEBUG - 2018-06-21 03:43:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 03:43:41 --> Input Class Initialized
INFO - 2018-06-21 03:43:41 --> Language Class Initialized
INFO - 2018-06-21 03:43:41 --> Language Class Initialized
INFO - 2018-06-21 03:43:41 --> Config Class Initialized
INFO - 2018-06-21 03:43:41 --> Loader Class Initialized
DEBUG - 2018-06-21 03:43:41 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 03:43:41 --> Helper loaded: url_helper
INFO - 2018-06-21 03:43:41 --> Helper loaded: form_helper
INFO - 2018-06-21 03:43:41 --> Helper loaded: date_helper
INFO - 2018-06-21 03:43:41 --> Helper loaded: util_helper
INFO - 2018-06-21 03:43:41 --> Helper loaded: text_helper
INFO - 2018-06-21 03:43:41 --> Helper loaded: string_helper
INFO - 2018-06-21 03:43:41 --> Database Driver Class Initialized
DEBUG - 2018-06-21 03:43:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 03:43:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 03:43:41 --> Email Class Initialized
INFO - 2018-06-21 03:43:41 --> Controller Class Initialized
DEBUG - 2018-06-21 03:43:41 --> Users MX_Controller Initialized
DEBUG - 2018-06-21 03:43:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 03:43:41 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 03:43:41 --> Login MX_Controller Initialized
INFO - 2018-06-21 03:43:41 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 03:43:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-21 03:43:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-06-21 03:43:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
INFO - 2018-06-21 03:43:41 --> Upload Class Initialized
INFO - 2018-06-21 03:43:41 --> Config Class Initialized
INFO - 2018-06-21 03:43:41 --> Hooks Class Initialized
DEBUG - 2018-06-21 03:43:41 --> UTF-8 Support Enabled
INFO - 2018-06-21 03:43:41 --> Utf8 Class Initialized
INFO - 2018-06-21 03:43:41 --> URI Class Initialized
INFO - 2018-06-21 03:43:41 --> Router Class Initialized
INFO - 2018-06-21 03:43:41 --> Output Class Initialized
INFO - 2018-06-21 03:43:41 --> Security Class Initialized
DEBUG - 2018-06-21 03:43:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 03:43:41 --> Input Class Initialized
INFO - 2018-06-21 03:43:41 --> Language Class Initialized
INFO - 2018-06-21 03:43:41 --> Language Class Initialized
INFO - 2018-06-21 03:43:41 --> Config Class Initialized
INFO - 2018-06-21 03:43:41 --> Loader Class Initialized
DEBUG - 2018-06-21 03:43:41 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 03:43:41 --> Helper loaded: url_helper
INFO - 2018-06-21 03:43:41 --> Helper loaded: form_helper
INFO - 2018-06-21 03:43:41 --> Helper loaded: date_helper
INFO - 2018-06-21 03:43:41 --> Helper loaded: util_helper
INFO - 2018-06-21 03:43:41 --> Helper loaded: text_helper
INFO - 2018-06-21 03:43:41 --> Helper loaded: string_helper
INFO - 2018-06-21 03:43:41 --> Database Driver Class Initialized
DEBUG - 2018-06-21 03:43:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 03:43:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 03:43:41 --> Email Class Initialized
INFO - 2018-06-21 03:43:41 --> Controller Class Initialized
DEBUG - 2018-06-21 03:43:41 --> Users MX_Controller Initialized
DEBUG - 2018-06-21 03:43:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 03:43:41 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 03:43:41 --> Login MX_Controller Initialized
INFO - 2018-06-21 03:43:41 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 03:43:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-21 03:43:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-21 03:43:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-21 03:43:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-21 03:43:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-21 03:43:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-21 03:43:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-06-21 03:43:42 --> Final output sent to browser
DEBUG - 2018-06-21 03:43:42 --> Total execution time: 0.4788
INFO - 2018-06-21 03:43:42 --> Config Class Initialized
INFO - 2018-06-21 03:43:42 --> Hooks Class Initialized
DEBUG - 2018-06-21 03:43:42 --> UTF-8 Support Enabled
INFO - 2018-06-21 03:43:42 --> Utf8 Class Initialized
INFO - 2018-06-21 03:43:42 --> URI Class Initialized
INFO - 2018-06-21 03:43:42 --> Router Class Initialized
INFO - 2018-06-21 03:43:42 --> Output Class Initialized
INFO - 2018-06-21 03:43:42 --> Security Class Initialized
DEBUG - 2018-06-21 03:43:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 03:43:42 --> Input Class Initialized
INFO - 2018-06-21 03:43:42 --> Language Class Initialized
INFO - 2018-06-21 03:43:42 --> Language Class Initialized
INFO - 2018-06-21 03:43:42 --> Config Class Initialized
INFO - 2018-06-21 03:43:42 --> Loader Class Initialized
DEBUG - 2018-06-21 03:43:42 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 03:43:42 --> Helper loaded: url_helper
INFO - 2018-06-21 03:43:42 --> Helper loaded: form_helper
INFO - 2018-06-21 03:43:42 --> Helper loaded: date_helper
INFO - 2018-06-21 03:43:42 --> Helper loaded: util_helper
INFO - 2018-06-21 03:43:42 --> Helper loaded: text_helper
INFO - 2018-06-21 03:43:42 --> Helper loaded: string_helper
INFO - 2018-06-21 03:43:42 --> Database Driver Class Initialized
DEBUG - 2018-06-21 03:43:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 03:43:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 03:43:42 --> Email Class Initialized
INFO - 2018-06-21 03:43:42 --> Controller Class Initialized
DEBUG - 2018-06-21 03:43:42 --> Users MX_Controller Initialized
DEBUG - 2018-06-21 03:43:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 03:43:42 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 03:43:43 --> Login MX_Controller Initialized
INFO - 2018-06-21 03:43:43 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 03:43:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-21 03:43:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-06-21 03:43:43 --> Final output sent to browser
DEBUG - 2018-06-21 03:43:43 --> Total execution time: 0.5775
INFO - 2018-06-21 03:43:47 --> Config Class Initialized
INFO - 2018-06-21 03:43:47 --> Hooks Class Initialized
DEBUG - 2018-06-21 03:43:47 --> UTF-8 Support Enabled
INFO - 2018-06-21 03:43:47 --> Utf8 Class Initialized
INFO - 2018-06-21 03:43:47 --> URI Class Initialized
INFO - 2018-06-21 03:43:47 --> Router Class Initialized
INFO - 2018-06-21 03:43:47 --> Output Class Initialized
INFO - 2018-06-21 03:43:47 --> Security Class Initialized
DEBUG - 2018-06-21 03:43:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 03:43:48 --> Input Class Initialized
INFO - 2018-06-21 03:43:48 --> Language Class Initialized
INFO - 2018-06-21 03:43:48 --> Language Class Initialized
INFO - 2018-06-21 03:43:48 --> Config Class Initialized
INFO - 2018-06-21 03:43:48 --> Loader Class Initialized
DEBUG - 2018-06-21 03:43:48 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 03:43:48 --> Helper loaded: url_helper
INFO - 2018-06-21 03:43:48 --> Helper loaded: form_helper
INFO - 2018-06-21 03:43:48 --> Helper loaded: date_helper
INFO - 2018-06-21 03:43:48 --> Helper loaded: util_helper
INFO - 2018-06-21 03:43:48 --> Helper loaded: text_helper
INFO - 2018-06-21 03:43:48 --> Helper loaded: string_helper
INFO - 2018-06-21 03:43:48 --> Database Driver Class Initialized
DEBUG - 2018-06-21 03:43:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 03:43:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 03:43:48 --> Email Class Initialized
INFO - 2018-06-21 03:43:48 --> Controller Class Initialized
DEBUG - 2018-06-21 03:43:48 --> Users MX_Controller Initialized
DEBUG - 2018-06-21 03:43:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 03:43:48 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 03:43:48 --> Login MX_Controller Initialized
INFO - 2018-06-21 03:43:48 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 03:43:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-21 03:43:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-06-21 03:43:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-21 03:43:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-21 03:43:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-21 03:43:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-21 03:43:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-21 03:43:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-06-21 03:43:48 --> Final output sent to browser
DEBUG - 2018-06-21 03:43:48 --> Total execution time: 0.4912
INFO - 2018-06-21 03:43:52 --> Config Class Initialized
INFO - 2018-06-21 03:43:52 --> Hooks Class Initialized
DEBUG - 2018-06-21 03:43:52 --> UTF-8 Support Enabled
INFO - 2018-06-21 03:43:52 --> Utf8 Class Initialized
INFO - 2018-06-21 03:43:52 --> URI Class Initialized
INFO - 2018-06-21 03:43:52 --> Router Class Initialized
INFO - 2018-06-21 03:43:52 --> Output Class Initialized
INFO - 2018-06-21 03:43:52 --> Security Class Initialized
DEBUG - 2018-06-21 03:43:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 03:43:52 --> Input Class Initialized
INFO - 2018-06-21 03:43:52 --> Language Class Initialized
INFO - 2018-06-21 03:43:52 --> Language Class Initialized
INFO - 2018-06-21 03:43:52 --> Config Class Initialized
INFO - 2018-06-21 03:43:52 --> Loader Class Initialized
DEBUG - 2018-06-21 03:43:52 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 03:43:52 --> Helper loaded: url_helper
INFO - 2018-06-21 03:43:52 --> Helper loaded: form_helper
INFO - 2018-06-21 03:43:52 --> Helper loaded: date_helper
INFO - 2018-06-21 03:43:52 --> Helper loaded: util_helper
INFO - 2018-06-21 03:43:52 --> Helper loaded: text_helper
INFO - 2018-06-21 03:43:52 --> Helper loaded: string_helper
INFO - 2018-06-21 03:43:53 --> Database Driver Class Initialized
DEBUG - 2018-06-21 03:43:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 03:43:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 03:43:53 --> Email Class Initialized
INFO - 2018-06-21 03:43:53 --> Controller Class Initialized
DEBUG - 2018-06-21 03:43:53 --> Users MX_Controller Initialized
DEBUG - 2018-06-21 03:43:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 03:43:53 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 03:43:53 --> Login MX_Controller Initialized
INFO - 2018-06-21 03:43:53 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 03:43:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-21 03:43:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-21 03:43:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-21 03:43:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-21 03:43:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-21 03:43:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-21 03:43:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-06-21 03:43:53 --> Final output sent to browser
DEBUG - 2018-06-21 03:43:53 --> Total execution time: 0.6042
INFO - 2018-06-21 03:43:53 --> Config Class Initialized
INFO - 2018-06-21 03:43:53 --> Hooks Class Initialized
DEBUG - 2018-06-21 03:43:53 --> UTF-8 Support Enabled
INFO - 2018-06-21 03:43:53 --> Utf8 Class Initialized
INFO - 2018-06-21 03:43:53 --> URI Class Initialized
INFO - 2018-06-21 03:43:53 --> Router Class Initialized
INFO - 2018-06-21 03:43:53 --> Output Class Initialized
INFO - 2018-06-21 03:43:53 --> Security Class Initialized
DEBUG - 2018-06-21 03:43:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 03:43:53 --> Input Class Initialized
INFO - 2018-06-21 03:43:53 --> Language Class Initialized
INFO - 2018-06-21 03:43:53 --> Language Class Initialized
INFO - 2018-06-21 03:43:53 --> Config Class Initialized
INFO - 2018-06-21 03:43:53 --> Loader Class Initialized
DEBUG - 2018-06-21 03:43:53 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 03:43:53 --> Helper loaded: url_helper
INFO - 2018-06-21 03:43:53 --> Helper loaded: form_helper
INFO - 2018-06-21 03:43:53 --> Helper loaded: date_helper
INFO - 2018-06-21 03:43:53 --> Helper loaded: util_helper
INFO - 2018-06-21 03:43:53 --> Helper loaded: text_helper
INFO - 2018-06-21 03:43:53 --> Helper loaded: string_helper
INFO - 2018-06-21 03:43:53 --> Database Driver Class Initialized
DEBUG - 2018-06-21 03:43:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 03:43:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 03:43:53 --> Email Class Initialized
INFO - 2018-06-21 03:43:53 --> Controller Class Initialized
DEBUG - 2018-06-21 03:43:53 --> Users MX_Controller Initialized
DEBUG - 2018-06-21 03:43:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 03:43:53 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 03:43:53 --> Login MX_Controller Initialized
INFO - 2018-06-21 03:43:53 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 03:43:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-21 03:43:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-06-21 03:43:54 --> Final output sent to browser
DEBUG - 2018-06-21 03:43:54 --> Total execution time: 0.5150
INFO - 2018-06-21 03:44:23 --> Config Class Initialized
INFO - 2018-06-21 03:44:23 --> Hooks Class Initialized
DEBUG - 2018-06-21 03:44:23 --> UTF-8 Support Enabled
INFO - 2018-06-21 03:44:23 --> Utf8 Class Initialized
INFO - 2018-06-21 03:44:23 --> URI Class Initialized
INFO - 2018-06-21 03:44:24 --> Router Class Initialized
INFO - 2018-06-21 03:44:24 --> Output Class Initialized
INFO - 2018-06-21 03:44:24 --> Security Class Initialized
DEBUG - 2018-06-21 03:44:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 03:44:24 --> Input Class Initialized
INFO - 2018-06-21 03:44:24 --> Language Class Initialized
INFO - 2018-06-21 03:44:24 --> Language Class Initialized
INFO - 2018-06-21 03:44:24 --> Config Class Initialized
INFO - 2018-06-21 03:44:24 --> Loader Class Initialized
DEBUG - 2018-06-21 03:44:24 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 03:44:24 --> Helper loaded: url_helper
INFO - 2018-06-21 03:44:24 --> Helper loaded: form_helper
INFO - 2018-06-21 03:44:24 --> Helper loaded: date_helper
INFO - 2018-06-21 03:44:24 --> Helper loaded: util_helper
INFO - 2018-06-21 03:44:24 --> Helper loaded: text_helper
INFO - 2018-06-21 03:44:24 --> Helper loaded: string_helper
INFO - 2018-06-21 03:44:24 --> Database Driver Class Initialized
DEBUG - 2018-06-21 03:44:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 03:44:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 03:44:24 --> Email Class Initialized
INFO - 2018-06-21 03:44:24 --> Controller Class Initialized
DEBUG - 2018-06-21 03:44:24 --> Admin MX_Controller Initialized
INFO - 2018-06-21 03:44:24 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 03:44:24 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 03:44:24 --> Login MX_Controller Initialized
DEBUG - 2018-06-21 03:44:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 03:44:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
ERROR - 2018-06-21 03:44:24 --> Query error: Unknown column 'users_id' in 'where clause' - Invalid query: SELECT * FROM users WHERE users_id IN(6)
INFO - 2018-06-21 03:44:24 --> Language file loaded: language/english/db_lang.php
INFO - 2018-06-21 03:44:31 --> Config Class Initialized
INFO - 2018-06-21 03:44:31 --> Hooks Class Initialized
DEBUG - 2018-06-21 03:44:31 --> UTF-8 Support Enabled
INFO - 2018-06-21 03:44:31 --> Utf8 Class Initialized
INFO - 2018-06-21 03:44:31 --> URI Class Initialized
INFO - 2018-06-21 03:44:31 --> Router Class Initialized
INFO - 2018-06-21 03:44:31 --> Output Class Initialized
INFO - 2018-06-21 03:44:31 --> Security Class Initialized
DEBUG - 2018-06-21 03:44:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 03:44:31 --> Input Class Initialized
INFO - 2018-06-21 03:44:31 --> Language Class Initialized
INFO - 2018-06-21 03:44:31 --> Language Class Initialized
INFO - 2018-06-21 03:44:31 --> Config Class Initialized
INFO - 2018-06-21 03:44:31 --> Loader Class Initialized
DEBUG - 2018-06-21 03:44:31 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 03:44:31 --> Helper loaded: url_helper
INFO - 2018-06-21 03:44:31 --> Helper loaded: form_helper
INFO - 2018-06-21 03:44:31 --> Helper loaded: date_helper
INFO - 2018-06-21 03:44:31 --> Helper loaded: util_helper
INFO - 2018-06-21 03:44:31 --> Helper loaded: text_helper
INFO - 2018-06-21 03:44:31 --> Helper loaded: string_helper
INFO - 2018-06-21 03:44:31 --> Database Driver Class Initialized
DEBUG - 2018-06-21 03:44:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 03:44:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 03:44:31 --> Email Class Initialized
INFO - 2018-06-21 03:44:31 --> Controller Class Initialized
DEBUG - 2018-06-21 03:44:31 --> Users MX_Controller Initialized
DEBUG - 2018-06-21 03:44:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 03:44:31 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 03:44:31 --> Login MX_Controller Initialized
INFO - 2018-06-21 03:44:31 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 03:44:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-21 03:44:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-06-21 03:44:32 --> Final output sent to browser
DEBUG - 2018-06-21 03:44:32 --> Total execution time: 0.4464
INFO - 2018-06-21 03:44:32 --> Config Class Initialized
INFO - 2018-06-21 03:44:32 --> Hooks Class Initialized
DEBUG - 2018-06-21 03:44:32 --> UTF-8 Support Enabled
INFO - 2018-06-21 03:44:32 --> Utf8 Class Initialized
INFO - 2018-06-21 03:44:32 --> URI Class Initialized
INFO - 2018-06-21 03:44:32 --> Router Class Initialized
INFO - 2018-06-21 03:44:32 --> Output Class Initialized
INFO - 2018-06-21 03:44:32 --> Security Class Initialized
DEBUG - 2018-06-21 03:44:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 03:44:32 --> Input Class Initialized
INFO - 2018-06-21 03:44:32 --> Language Class Initialized
INFO - 2018-06-21 03:44:32 --> Language Class Initialized
INFO - 2018-06-21 03:44:32 --> Config Class Initialized
INFO - 2018-06-21 03:44:32 --> Loader Class Initialized
DEBUG - 2018-06-21 03:44:32 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 03:44:32 --> Helper loaded: url_helper
INFO - 2018-06-21 03:44:32 --> Helper loaded: form_helper
INFO - 2018-06-21 03:44:32 --> Helper loaded: date_helper
INFO - 2018-06-21 03:44:32 --> Helper loaded: util_helper
INFO - 2018-06-21 03:44:32 --> Helper loaded: text_helper
INFO - 2018-06-21 03:44:32 --> Helper loaded: string_helper
INFO - 2018-06-21 03:44:32 --> Database Driver Class Initialized
DEBUG - 2018-06-21 03:44:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 03:44:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 03:44:33 --> Email Class Initialized
INFO - 2018-06-21 03:44:33 --> Controller Class Initialized
DEBUG - 2018-06-21 03:44:33 --> Users MX_Controller Initialized
DEBUG - 2018-06-21 03:44:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 03:44:33 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 03:44:33 --> Login MX_Controller Initialized
INFO - 2018-06-21 03:44:33 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 03:44:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-21 03:44:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-06-21 03:44:33 --> Final output sent to browser
DEBUG - 2018-06-21 03:44:33 --> Total execution time: 0.4368
INFO - 2018-06-21 03:45:31 --> Config Class Initialized
INFO - 2018-06-21 03:45:31 --> Hooks Class Initialized
DEBUG - 2018-06-21 03:45:31 --> UTF-8 Support Enabled
INFO - 2018-06-21 03:45:31 --> Utf8 Class Initialized
INFO - 2018-06-21 03:45:31 --> URI Class Initialized
INFO - 2018-06-21 03:45:31 --> Router Class Initialized
INFO - 2018-06-21 03:45:31 --> Output Class Initialized
INFO - 2018-06-21 03:45:31 --> Security Class Initialized
DEBUG - 2018-06-21 03:45:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 03:45:31 --> Input Class Initialized
INFO - 2018-06-21 03:45:31 --> Language Class Initialized
INFO - 2018-06-21 03:45:31 --> Language Class Initialized
INFO - 2018-06-21 03:45:31 --> Config Class Initialized
INFO - 2018-06-21 03:45:31 --> Loader Class Initialized
DEBUG - 2018-06-21 03:45:31 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 03:45:31 --> Helper loaded: url_helper
INFO - 2018-06-21 03:45:31 --> Helper loaded: form_helper
INFO - 2018-06-21 03:45:31 --> Helper loaded: date_helper
INFO - 2018-06-21 03:45:31 --> Helper loaded: util_helper
INFO - 2018-06-21 03:45:31 --> Helper loaded: text_helper
INFO - 2018-06-21 03:45:31 --> Helper loaded: string_helper
INFO - 2018-06-21 03:45:31 --> Database Driver Class Initialized
DEBUG - 2018-06-21 03:45:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 03:45:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 03:45:31 --> Email Class Initialized
INFO - 2018-06-21 03:45:31 --> Controller Class Initialized
DEBUG - 2018-06-21 03:45:31 --> Users MX_Controller Initialized
DEBUG - 2018-06-21 03:45:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 03:45:31 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 03:45:31 --> Login MX_Controller Initialized
INFO - 2018-06-21 03:45:31 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 03:45:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-21 03:45:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-21 03:45:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-21 03:45:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-21 03:45:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-21 03:45:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-21 03:45:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-06-21 03:45:31 --> Final output sent to browser
DEBUG - 2018-06-21 03:45:31 --> Total execution time: 0.4993
INFO - 2018-06-21 03:45:31 --> Config Class Initialized
INFO - 2018-06-21 03:45:31 --> Hooks Class Initialized
DEBUG - 2018-06-21 03:45:31 --> UTF-8 Support Enabled
INFO - 2018-06-21 03:45:32 --> Utf8 Class Initialized
INFO - 2018-06-21 03:45:32 --> URI Class Initialized
INFO - 2018-06-21 03:45:32 --> Router Class Initialized
INFO - 2018-06-21 03:45:32 --> Output Class Initialized
INFO - 2018-06-21 03:45:32 --> Security Class Initialized
DEBUG - 2018-06-21 03:45:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 03:45:32 --> Input Class Initialized
INFO - 2018-06-21 03:45:32 --> Language Class Initialized
INFO - 2018-06-21 03:45:32 --> Language Class Initialized
INFO - 2018-06-21 03:45:32 --> Config Class Initialized
INFO - 2018-06-21 03:45:32 --> Loader Class Initialized
DEBUG - 2018-06-21 03:45:32 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 03:45:32 --> Helper loaded: url_helper
INFO - 2018-06-21 03:45:32 --> Helper loaded: form_helper
INFO - 2018-06-21 03:45:32 --> Helper loaded: date_helper
INFO - 2018-06-21 03:45:32 --> Helper loaded: util_helper
INFO - 2018-06-21 03:45:32 --> Helper loaded: text_helper
INFO - 2018-06-21 03:45:32 --> Helper loaded: string_helper
INFO - 2018-06-21 03:45:32 --> Database Driver Class Initialized
DEBUG - 2018-06-21 03:45:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 03:45:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 03:45:32 --> Email Class Initialized
INFO - 2018-06-21 03:45:32 --> Controller Class Initialized
DEBUG - 2018-06-21 03:45:32 --> Users MX_Controller Initialized
DEBUG - 2018-06-21 03:45:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 03:45:32 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 03:45:32 --> Login MX_Controller Initialized
INFO - 2018-06-21 03:45:32 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 03:45:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-21 03:45:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-06-21 03:45:32 --> Final output sent to browser
DEBUG - 2018-06-21 03:45:32 --> Total execution time: 0.5139
INFO - 2018-06-21 03:47:43 --> Config Class Initialized
INFO - 2018-06-21 03:47:43 --> Hooks Class Initialized
DEBUG - 2018-06-21 03:47:43 --> UTF-8 Support Enabled
INFO - 2018-06-21 03:47:43 --> Utf8 Class Initialized
INFO - 2018-06-21 03:47:43 --> URI Class Initialized
INFO - 2018-06-21 03:47:43 --> Router Class Initialized
INFO - 2018-06-21 03:47:43 --> Output Class Initialized
INFO - 2018-06-21 03:47:43 --> Security Class Initialized
DEBUG - 2018-06-21 03:47:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 03:47:43 --> Input Class Initialized
INFO - 2018-06-21 03:47:43 --> Language Class Initialized
INFO - 2018-06-21 03:47:43 --> Language Class Initialized
INFO - 2018-06-21 03:47:43 --> Config Class Initialized
INFO - 2018-06-21 03:47:43 --> Loader Class Initialized
DEBUG - 2018-06-21 03:47:43 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 03:47:43 --> Helper loaded: url_helper
INFO - 2018-06-21 03:47:43 --> Helper loaded: form_helper
INFO - 2018-06-21 03:47:43 --> Helper loaded: date_helper
INFO - 2018-06-21 03:47:43 --> Helper loaded: util_helper
INFO - 2018-06-21 03:47:43 --> Helper loaded: text_helper
INFO - 2018-06-21 03:47:43 --> Helper loaded: string_helper
INFO - 2018-06-21 03:47:43 --> Database Driver Class Initialized
DEBUG - 2018-06-21 03:47:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 03:47:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 03:47:43 --> Email Class Initialized
INFO - 2018-06-21 03:47:43 --> Controller Class Initialized
DEBUG - 2018-06-21 03:47:43 --> Users MX_Controller Initialized
DEBUG - 2018-06-21 03:47:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 03:47:43 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 03:47:43 --> Login MX_Controller Initialized
INFO - 2018-06-21 03:47:43 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 03:47:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-21 03:47:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-06-21 03:47:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-21 03:47:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-21 03:47:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-21 03:47:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-21 03:47:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-21 03:47:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-06-21 03:47:43 --> Final output sent to browser
DEBUG - 2018-06-21 03:47:43 --> Total execution time: 0.5067
INFO - 2018-06-21 03:48:28 --> Config Class Initialized
INFO - 2018-06-21 03:48:28 --> Hooks Class Initialized
DEBUG - 2018-06-21 03:48:28 --> UTF-8 Support Enabled
INFO - 2018-06-21 03:48:29 --> Utf8 Class Initialized
INFO - 2018-06-21 03:48:29 --> URI Class Initialized
INFO - 2018-06-21 03:48:29 --> Router Class Initialized
INFO - 2018-06-21 03:48:29 --> Output Class Initialized
INFO - 2018-06-21 03:48:29 --> Security Class Initialized
DEBUG - 2018-06-21 03:48:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 03:48:29 --> Input Class Initialized
INFO - 2018-06-21 03:48:29 --> Language Class Initialized
INFO - 2018-06-21 03:48:29 --> Language Class Initialized
INFO - 2018-06-21 03:48:29 --> Config Class Initialized
INFO - 2018-06-21 03:48:29 --> Loader Class Initialized
DEBUG - 2018-06-21 03:48:29 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 03:48:29 --> Helper loaded: url_helper
INFO - 2018-06-21 03:48:29 --> Helper loaded: form_helper
INFO - 2018-06-21 03:48:29 --> Helper loaded: date_helper
INFO - 2018-06-21 03:48:29 --> Helper loaded: util_helper
INFO - 2018-06-21 03:48:29 --> Helper loaded: text_helper
INFO - 2018-06-21 03:48:29 --> Helper loaded: string_helper
INFO - 2018-06-21 03:48:29 --> Database Driver Class Initialized
DEBUG - 2018-06-21 03:48:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 03:48:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 03:48:29 --> Email Class Initialized
INFO - 2018-06-21 03:48:29 --> Controller Class Initialized
DEBUG - 2018-06-21 03:48:29 --> Users MX_Controller Initialized
DEBUG - 2018-06-21 03:48:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 03:48:29 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 03:48:29 --> Login MX_Controller Initialized
INFO - 2018-06-21 03:48:29 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 03:48:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-21 03:48:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-21 03:48:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-21 03:48:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-21 03:48:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-21 03:48:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-21 03:48:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-06-21 03:48:29 --> Final output sent to browser
DEBUG - 2018-06-21 03:48:29 --> Total execution time: 0.5042
INFO - 2018-06-21 03:48:29 --> Config Class Initialized
INFO - 2018-06-21 03:48:29 --> Hooks Class Initialized
DEBUG - 2018-06-21 03:48:29 --> UTF-8 Support Enabled
INFO - 2018-06-21 03:48:29 --> Utf8 Class Initialized
INFO - 2018-06-21 03:48:29 --> URI Class Initialized
INFO - 2018-06-21 03:48:29 --> Router Class Initialized
INFO - 2018-06-21 03:48:29 --> Output Class Initialized
INFO - 2018-06-21 03:48:29 --> Security Class Initialized
DEBUG - 2018-06-21 03:48:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 03:48:29 --> Input Class Initialized
INFO - 2018-06-21 03:48:29 --> Language Class Initialized
INFO - 2018-06-21 03:48:29 --> Language Class Initialized
INFO - 2018-06-21 03:48:30 --> Config Class Initialized
INFO - 2018-06-21 03:48:30 --> Loader Class Initialized
DEBUG - 2018-06-21 03:48:30 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 03:48:30 --> Helper loaded: url_helper
INFO - 2018-06-21 03:48:30 --> Helper loaded: form_helper
INFO - 2018-06-21 03:48:30 --> Helper loaded: date_helper
INFO - 2018-06-21 03:48:30 --> Helper loaded: util_helper
INFO - 2018-06-21 03:48:30 --> Helper loaded: text_helper
INFO - 2018-06-21 03:48:30 --> Helper loaded: string_helper
INFO - 2018-06-21 03:48:30 --> Database Driver Class Initialized
DEBUG - 2018-06-21 03:48:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 03:48:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 03:48:30 --> Email Class Initialized
INFO - 2018-06-21 03:48:30 --> Controller Class Initialized
DEBUG - 2018-06-21 03:48:30 --> Users MX_Controller Initialized
DEBUG - 2018-06-21 03:48:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 03:48:30 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 03:48:30 --> Login MX_Controller Initialized
INFO - 2018-06-21 03:48:30 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 03:48:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-21 03:48:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-06-21 03:48:30 --> Final output sent to browser
DEBUG - 2018-06-21 03:48:30 --> Total execution time: 0.5611
INFO - 2018-06-21 03:48:58 --> Config Class Initialized
INFO - 2018-06-21 03:48:58 --> Hooks Class Initialized
DEBUG - 2018-06-21 03:48:58 --> UTF-8 Support Enabled
INFO - 2018-06-21 03:48:58 --> Utf8 Class Initialized
INFO - 2018-06-21 03:48:58 --> URI Class Initialized
INFO - 2018-06-21 03:48:59 --> Router Class Initialized
INFO - 2018-06-21 03:48:59 --> Output Class Initialized
INFO - 2018-06-21 03:48:59 --> Security Class Initialized
DEBUG - 2018-06-21 03:48:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 03:48:59 --> Input Class Initialized
INFO - 2018-06-21 03:48:59 --> Language Class Initialized
INFO - 2018-06-21 03:48:59 --> Language Class Initialized
INFO - 2018-06-21 03:48:59 --> Config Class Initialized
INFO - 2018-06-21 03:48:59 --> Loader Class Initialized
DEBUG - 2018-06-21 03:48:59 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 03:48:59 --> Helper loaded: url_helper
INFO - 2018-06-21 03:48:59 --> Helper loaded: form_helper
INFO - 2018-06-21 03:48:59 --> Helper loaded: date_helper
INFO - 2018-06-21 03:48:59 --> Helper loaded: util_helper
INFO - 2018-06-21 03:48:59 --> Helper loaded: text_helper
INFO - 2018-06-21 03:48:59 --> Helper loaded: string_helper
INFO - 2018-06-21 03:48:59 --> Database Driver Class Initialized
DEBUG - 2018-06-21 03:48:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 03:48:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 03:48:59 --> Email Class Initialized
INFO - 2018-06-21 03:48:59 --> Controller Class Initialized
DEBUG - 2018-06-21 03:48:59 --> Admin MX_Controller Initialized
INFO - 2018-06-21 03:48:59 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 03:48:59 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 03:48:59 --> Login MX_Controller Initialized
DEBUG - 2018-06-21 03:48:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 03:48:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
ERROR - 2018-06-21 03:48:59 --> Query error: Unknown column 'users_id' in 'where clause' - Invalid query: SELECT * FROM users WHERE users_id IN(33)
INFO - 2018-06-21 03:48:59 --> Language file loaded: language/english/db_lang.php
INFO - 2018-06-21 03:50:12 --> Config Class Initialized
INFO - 2018-06-21 03:50:13 --> Hooks Class Initialized
DEBUG - 2018-06-21 03:50:13 --> UTF-8 Support Enabled
INFO - 2018-06-21 03:50:13 --> Utf8 Class Initialized
INFO - 2018-06-21 03:50:13 --> URI Class Initialized
INFO - 2018-06-21 03:50:13 --> Router Class Initialized
INFO - 2018-06-21 03:50:13 --> Output Class Initialized
INFO - 2018-06-21 03:50:13 --> Security Class Initialized
DEBUG - 2018-06-21 03:50:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 03:50:13 --> Input Class Initialized
INFO - 2018-06-21 03:50:13 --> Language Class Initialized
INFO - 2018-06-21 03:50:13 --> Language Class Initialized
INFO - 2018-06-21 03:50:13 --> Config Class Initialized
INFO - 2018-06-21 03:50:13 --> Loader Class Initialized
DEBUG - 2018-06-21 03:50:13 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 03:50:13 --> Helper loaded: url_helper
INFO - 2018-06-21 03:50:13 --> Helper loaded: form_helper
INFO - 2018-06-21 03:50:13 --> Helper loaded: date_helper
INFO - 2018-06-21 03:50:13 --> Helper loaded: util_helper
INFO - 2018-06-21 03:50:13 --> Helper loaded: text_helper
INFO - 2018-06-21 03:50:13 --> Helper loaded: string_helper
INFO - 2018-06-21 03:50:13 --> Database Driver Class Initialized
DEBUG - 2018-06-21 03:50:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 03:50:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 03:50:13 --> Email Class Initialized
INFO - 2018-06-21 03:50:13 --> Controller Class Initialized
DEBUG - 2018-06-21 03:50:13 --> Admin MX_Controller Initialized
INFO - 2018-06-21 03:50:13 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 03:50:13 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 03:50:13 --> Login MX_Controller Initialized
DEBUG - 2018-06-21 03:50:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 03:50:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
ERROR - 2018-06-21 03:50:13 --> Query error: Unknown column 'users_id' in 'where clause' - Invalid query: SELECT * FROM users WHERE users_id IN(33)
INFO - 2018-06-21 03:50:13 --> Language file loaded: language/english/db_lang.php
INFO - 2018-06-21 04:06:28 --> Config Class Initialized
INFO - 2018-06-21 04:06:28 --> Hooks Class Initialized
DEBUG - 2018-06-21 04:06:28 --> UTF-8 Support Enabled
INFO - 2018-06-21 04:06:28 --> Utf8 Class Initialized
INFO - 2018-06-21 04:06:28 --> URI Class Initialized
INFO - 2018-06-21 04:06:28 --> Router Class Initialized
INFO - 2018-06-21 04:06:28 --> Output Class Initialized
INFO - 2018-06-21 04:06:28 --> Security Class Initialized
DEBUG - 2018-06-21 04:06:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 04:06:28 --> Input Class Initialized
INFO - 2018-06-21 04:06:28 --> Language Class Initialized
INFO - 2018-06-21 04:06:28 --> Language Class Initialized
INFO - 2018-06-21 04:06:28 --> Config Class Initialized
INFO - 2018-06-21 04:06:28 --> Loader Class Initialized
DEBUG - 2018-06-21 04:06:28 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 04:06:28 --> Helper loaded: url_helper
INFO - 2018-06-21 04:06:28 --> Helper loaded: form_helper
INFO - 2018-06-21 04:06:28 --> Helper loaded: date_helper
INFO - 2018-06-21 04:06:28 --> Helper loaded: util_helper
INFO - 2018-06-21 04:06:28 --> Helper loaded: text_helper
INFO - 2018-06-21 04:06:28 --> Helper loaded: string_helper
INFO - 2018-06-21 04:06:28 --> Database Driver Class Initialized
DEBUG - 2018-06-21 04:06:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 04:06:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 04:06:28 --> Email Class Initialized
INFO - 2018-06-21 04:06:29 --> Controller Class Initialized
DEBUG - 2018-06-21 04:06:29 --> Users MX_Controller Initialized
DEBUG - 2018-06-21 04:06:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 04:06:29 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 04:06:29 --> Login MX_Controller Initialized
INFO - 2018-06-21 04:06:29 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 04:06:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-21 04:06:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-21 04:06:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-21 04:06:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-21 04:06:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-21 04:06:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-21 04:06:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-06-21 04:06:29 --> Final output sent to browser
DEBUG - 2018-06-21 04:06:29 --> Total execution time: 0.5425
INFO - 2018-06-21 04:06:30 --> Config Class Initialized
INFO - 2018-06-21 04:06:30 --> Hooks Class Initialized
DEBUG - 2018-06-21 04:06:30 --> UTF-8 Support Enabled
INFO - 2018-06-21 04:06:30 --> Utf8 Class Initialized
INFO - 2018-06-21 04:06:30 --> URI Class Initialized
INFO - 2018-06-21 04:06:30 --> Router Class Initialized
INFO - 2018-06-21 04:06:30 --> Output Class Initialized
INFO - 2018-06-21 04:06:30 --> Security Class Initialized
DEBUG - 2018-06-21 04:06:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 04:06:30 --> Input Class Initialized
INFO - 2018-06-21 04:06:30 --> Language Class Initialized
INFO - 2018-06-21 04:06:30 --> Language Class Initialized
INFO - 2018-06-21 04:06:30 --> Config Class Initialized
INFO - 2018-06-21 04:06:30 --> Loader Class Initialized
DEBUG - 2018-06-21 04:06:30 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 04:06:30 --> Helper loaded: url_helper
INFO - 2018-06-21 04:06:30 --> Helper loaded: form_helper
INFO - 2018-06-21 04:06:30 --> Helper loaded: date_helper
INFO - 2018-06-21 04:06:30 --> Helper loaded: util_helper
INFO - 2018-06-21 04:06:30 --> Helper loaded: text_helper
INFO - 2018-06-21 04:06:30 --> Helper loaded: string_helper
INFO - 2018-06-21 04:06:30 --> Database Driver Class Initialized
DEBUG - 2018-06-21 04:06:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 04:06:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 04:06:30 --> Email Class Initialized
INFO - 2018-06-21 04:06:30 --> Controller Class Initialized
DEBUG - 2018-06-21 04:06:30 --> Users MX_Controller Initialized
DEBUG - 2018-06-21 04:06:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 04:06:30 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 04:06:30 --> Login MX_Controller Initialized
INFO - 2018-06-21 04:06:30 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 04:06:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-21 04:06:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-06-21 04:06:30 --> Final output sent to browser
DEBUG - 2018-06-21 04:06:30 --> Total execution time: 0.5633
INFO - 2018-06-21 04:06:37 --> Config Class Initialized
INFO - 2018-06-21 04:06:37 --> Hooks Class Initialized
DEBUG - 2018-06-21 04:06:37 --> UTF-8 Support Enabled
INFO - 2018-06-21 04:06:37 --> Utf8 Class Initialized
INFO - 2018-06-21 04:06:37 --> URI Class Initialized
INFO - 2018-06-21 04:06:37 --> Router Class Initialized
INFO - 2018-06-21 04:06:37 --> Output Class Initialized
INFO - 2018-06-21 04:06:37 --> Security Class Initialized
DEBUG - 2018-06-21 04:06:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 04:06:37 --> Input Class Initialized
INFO - 2018-06-21 04:06:37 --> Language Class Initialized
INFO - 2018-06-21 04:06:37 --> Language Class Initialized
INFO - 2018-06-21 04:06:37 --> Config Class Initialized
INFO - 2018-06-21 04:06:37 --> Loader Class Initialized
DEBUG - 2018-06-21 04:06:37 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 04:06:37 --> Helper loaded: url_helper
INFO - 2018-06-21 04:06:37 --> Helper loaded: form_helper
INFO - 2018-06-21 04:06:37 --> Helper loaded: date_helper
INFO - 2018-06-21 04:06:37 --> Helper loaded: util_helper
INFO - 2018-06-21 04:06:37 --> Helper loaded: text_helper
INFO - 2018-06-21 04:06:37 --> Helper loaded: string_helper
INFO - 2018-06-21 04:06:37 --> Database Driver Class Initialized
DEBUG - 2018-06-21 04:06:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 04:06:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 04:06:37 --> Email Class Initialized
INFO - 2018-06-21 04:06:37 --> Controller Class Initialized
DEBUG - 2018-06-21 04:06:37 --> Admin MX_Controller Initialized
INFO - 2018-06-21 04:06:38 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 04:06:38 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 04:06:38 --> Login MX_Controller Initialized
DEBUG - 2018-06-21 04:06:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 04:06:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
ERROR - 2018-06-21 04:06:38 --> Severity: Warning --> unlink(E:\xampp\htdocs\consulting\assets/images/users/): Permission denied E:\xampp\htdocs\consulting\application\modules\common\models\Common_model.php 94
INFO - 2018-06-21 04:06:38 --> Final output sent to browser
DEBUG - 2018-06-21 04:06:38 --> Total execution time: 0.5674
INFO - 2018-06-21 04:06:41 --> Config Class Initialized
INFO - 2018-06-21 04:06:41 --> Hooks Class Initialized
DEBUG - 2018-06-21 04:06:41 --> UTF-8 Support Enabled
INFO - 2018-06-21 04:06:41 --> Utf8 Class Initialized
INFO - 2018-06-21 04:06:41 --> URI Class Initialized
INFO - 2018-06-21 04:06:41 --> Router Class Initialized
INFO - 2018-06-21 04:06:41 --> Output Class Initialized
INFO - 2018-06-21 04:06:41 --> Security Class Initialized
DEBUG - 2018-06-21 04:06:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 04:06:41 --> Input Class Initialized
INFO - 2018-06-21 04:06:42 --> Language Class Initialized
INFO - 2018-06-21 04:06:42 --> Language Class Initialized
INFO - 2018-06-21 04:06:42 --> Config Class Initialized
INFO - 2018-06-21 04:06:42 --> Loader Class Initialized
DEBUG - 2018-06-21 04:06:42 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 04:06:42 --> Helper loaded: url_helper
INFO - 2018-06-21 04:06:42 --> Helper loaded: form_helper
INFO - 2018-06-21 04:06:42 --> Helper loaded: date_helper
INFO - 2018-06-21 04:06:42 --> Helper loaded: util_helper
INFO - 2018-06-21 04:06:42 --> Helper loaded: text_helper
INFO - 2018-06-21 04:06:42 --> Helper loaded: string_helper
INFO - 2018-06-21 04:06:42 --> Database Driver Class Initialized
DEBUG - 2018-06-21 04:06:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 04:06:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 04:06:42 --> Email Class Initialized
INFO - 2018-06-21 04:06:42 --> Controller Class Initialized
DEBUG - 2018-06-21 04:06:42 --> Admin MX_Controller Initialized
INFO - 2018-06-21 04:06:42 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 04:06:42 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 04:06:42 --> Login MX_Controller Initialized
DEBUG - 2018-06-21 04:06:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 04:06:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
ERROR - 2018-06-21 04:06:42 --> Severity: Warning --> unlink(E:\xampp\htdocs\consulting\assets/images/users/): Permission denied E:\xampp\htdocs\consulting\application\modules\common\models\Common_model.php 94
INFO - 2018-06-21 04:06:42 --> Final output sent to browser
DEBUG - 2018-06-21 04:06:42 --> Total execution time: 0.5582
INFO - 2018-06-21 04:06:47 --> Config Class Initialized
INFO - 2018-06-21 04:06:47 --> Hooks Class Initialized
DEBUG - 2018-06-21 04:06:47 --> UTF-8 Support Enabled
INFO - 2018-06-21 04:06:47 --> Utf8 Class Initialized
INFO - 2018-06-21 04:06:47 --> URI Class Initialized
INFO - 2018-06-21 04:06:47 --> Router Class Initialized
INFO - 2018-06-21 04:06:47 --> Output Class Initialized
INFO - 2018-06-21 04:06:47 --> Security Class Initialized
DEBUG - 2018-06-21 04:06:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 04:06:47 --> Input Class Initialized
INFO - 2018-06-21 04:06:47 --> Language Class Initialized
INFO - 2018-06-21 04:06:47 --> Language Class Initialized
INFO - 2018-06-21 04:06:47 --> Config Class Initialized
INFO - 2018-06-21 04:06:47 --> Loader Class Initialized
DEBUG - 2018-06-21 04:06:47 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 04:06:47 --> Helper loaded: url_helper
INFO - 2018-06-21 04:06:47 --> Helper loaded: form_helper
INFO - 2018-06-21 04:06:47 --> Helper loaded: date_helper
INFO - 2018-06-21 04:06:47 --> Helper loaded: util_helper
INFO - 2018-06-21 04:06:47 --> Helper loaded: text_helper
INFO - 2018-06-21 04:06:47 --> Helper loaded: string_helper
INFO - 2018-06-21 04:06:47 --> Database Driver Class Initialized
DEBUG - 2018-06-21 04:06:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 04:06:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 04:06:47 --> Email Class Initialized
INFO - 2018-06-21 04:06:47 --> Controller Class Initialized
DEBUG - 2018-06-21 04:06:47 --> Admin MX_Controller Initialized
INFO - 2018-06-21 04:06:47 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 04:06:47 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 04:06:47 --> Login MX_Controller Initialized
DEBUG - 2018-06-21 04:06:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 04:06:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
ERROR - 2018-06-21 04:06:47 --> Severity: Warning --> unlink(E:\xampp\htdocs\consulting\assets/images/users/): Permission denied E:\xampp\htdocs\consulting\application\modules\common\models\Common_model.php 94
INFO - 2018-06-21 04:06:47 --> Final output sent to browser
DEBUG - 2018-06-21 04:06:47 --> Total execution time: 0.5863
INFO - 2018-06-21 04:06:52 --> Config Class Initialized
INFO - 2018-06-21 04:06:52 --> Hooks Class Initialized
DEBUG - 2018-06-21 04:06:52 --> UTF-8 Support Enabled
INFO - 2018-06-21 04:06:52 --> Utf8 Class Initialized
INFO - 2018-06-21 04:06:52 --> URI Class Initialized
INFO - 2018-06-21 04:06:52 --> Router Class Initialized
INFO - 2018-06-21 04:06:52 --> Output Class Initialized
INFO - 2018-06-21 04:06:52 --> Security Class Initialized
DEBUG - 2018-06-21 04:06:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 04:06:52 --> Input Class Initialized
INFO - 2018-06-21 04:06:52 --> Language Class Initialized
INFO - 2018-06-21 04:06:52 --> Language Class Initialized
INFO - 2018-06-21 04:06:52 --> Config Class Initialized
INFO - 2018-06-21 04:06:52 --> Loader Class Initialized
DEBUG - 2018-06-21 04:06:52 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 04:06:52 --> Helper loaded: url_helper
INFO - 2018-06-21 04:06:52 --> Helper loaded: form_helper
INFO - 2018-06-21 04:06:52 --> Helper loaded: date_helper
INFO - 2018-06-21 04:06:52 --> Helper loaded: util_helper
INFO - 2018-06-21 04:06:52 --> Helper loaded: text_helper
INFO - 2018-06-21 04:06:52 --> Helper loaded: string_helper
INFO - 2018-06-21 04:06:52 --> Database Driver Class Initialized
DEBUG - 2018-06-21 04:06:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 04:06:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 04:06:52 --> Email Class Initialized
INFO - 2018-06-21 04:06:52 --> Controller Class Initialized
DEBUG - 2018-06-21 04:06:52 --> Admin MX_Controller Initialized
INFO - 2018-06-21 04:06:52 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 04:06:52 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 04:06:52 --> Login MX_Controller Initialized
DEBUG - 2018-06-21 04:06:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 04:06:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
ERROR - 2018-06-21 04:06:52 --> Severity: Warning --> unlink(E:\xampp\htdocs\consulting\assets/images/users/): Permission denied E:\xampp\htdocs\consulting\application\modules\common\models\Common_model.php 94
INFO - 2018-06-21 04:06:52 --> Final output sent to browser
DEBUG - 2018-06-21 04:06:52 --> Total execution time: 0.6598
INFO - 2018-06-21 04:07:01 --> Config Class Initialized
INFO - 2018-06-21 04:07:01 --> Hooks Class Initialized
DEBUG - 2018-06-21 04:07:01 --> UTF-8 Support Enabled
INFO - 2018-06-21 04:07:01 --> Utf8 Class Initialized
INFO - 2018-06-21 04:07:01 --> URI Class Initialized
INFO - 2018-06-21 04:07:01 --> Router Class Initialized
INFO - 2018-06-21 04:07:01 --> Output Class Initialized
INFO - 2018-06-21 04:07:01 --> Security Class Initialized
DEBUG - 2018-06-21 04:07:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 04:07:01 --> Input Class Initialized
INFO - 2018-06-21 04:07:01 --> Language Class Initialized
INFO - 2018-06-21 04:07:02 --> Language Class Initialized
INFO - 2018-06-21 04:07:02 --> Config Class Initialized
INFO - 2018-06-21 04:07:02 --> Loader Class Initialized
DEBUG - 2018-06-21 04:07:02 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 04:07:02 --> Helper loaded: url_helper
INFO - 2018-06-21 04:07:02 --> Helper loaded: form_helper
INFO - 2018-06-21 04:07:02 --> Helper loaded: date_helper
INFO - 2018-06-21 04:07:02 --> Helper loaded: util_helper
INFO - 2018-06-21 04:07:02 --> Helper loaded: text_helper
INFO - 2018-06-21 04:07:02 --> Helper loaded: string_helper
INFO - 2018-06-21 04:07:02 --> Database Driver Class Initialized
DEBUG - 2018-06-21 04:07:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 04:07:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 04:07:02 --> Email Class Initialized
INFO - 2018-06-21 04:07:02 --> Controller Class Initialized
DEBUG - 2018-06-21 04:07:02 --> Admin MX_Controller Initialized
INFO - 2018-06-21 04:07:02 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 04:07:02 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 04:07:02 --> Login MX_Controller Initialized
DEBUG - 2018-06-21 04:07:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 04:07:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-21 04:07:02 --> Final output sent to browser
DEBUG - 2018-06-21 04:07:02 --> Total execution time: 0.5271
INFO - 2018-06-21 04:07:04 --> Config Class Initialized
INFO - 2018-06-21 04:07:04 --> Hooks Class Initialized
DEBUG - 2018-06-21 04:07:04 --> UTF-8 Support Enabled
INFO - 2018-06-21 04:07:04 --> Utf8 Class Initialized
INFO - 2018-06-21 04:07:04 --> URI Class Initialized
INFO - 2018-06-21 04:07:04 --> Router Class Initialized
INFO - 2018-06-21 04:07:04 --> Output Class Initialized
INFO - 2018-06-21 04:07:04 --> Security Class Initialized
DEBUG - 2018-06-21 04:07:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 04:07:04 --> Input Class Initialized
INFO - 2018-06-21 04:07:04 --> Language Class Initialized
INFO - 2018-06-21 04:07:04 --> Language Class Initialized
INFO - 2018-06-21 04:07:04 --> Config Class Initialized
INFO - 2018-06-21 04:07:04 --> Loader Class Initialized
DEBUG - 2018-06-21 04:07:04 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 04:07:04 --> Helper loaded: url_helper
INFO - 2018-06-21 04:07:04 --> Helper loaded: form_helper
INFO - 2018-06-21 04:07:04 --> Helper loaded: date_helper
INFO - 2018-06-21 04:07:04 --> Helper loaded: util_helper
INFO - 2018-06-21 04:07:04 --> Helper loaded: text_helper
INFO - 2018-06-21 04:07:04 --> Helper loaded: string_helper
INFO - 2018-06-21 04:07:04 --> Database Driver Class Initialized
DEBUG - 2018-06-21 04:07:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 04:07:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 04:07:04 --> Email Class Initialized
INFO - 2018-06-21 04:07:04 --> Controller Class Initialized
DEBUG - 2018-06-21 04:07:04 --> Users MX_Controller Initialized
DEBUG - 2018-06-21 04:07:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 04:07:04 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 04:07:04 --> Login MX_Controller Initialized
INFO - 2018-06-21 04:07:04 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 04:07:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-21 04:07:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-06-21 04:07:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-21 04:07:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-21 04:07:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-21 04:07:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-21 04:07:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-21 04:07:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-06-21 04:07:04 --> Final output sent to browser
DEBUG - 2018-06-21 04:07:04 --> Total execution time: 0.5388
INFO - 2018-06-21 04:07:17 --> Config Class Initialized
INFO - 2018-06-21 04:07:17 --> Hooks Class Initialized
DEBUG - 2018-06-21 04:07:17 --> UTF-8 Support Enabled
INFO - 2018-06-21 04:07:17 --> Utf8 Class Initialized
INFO - 2018-06-21 04:07:17 --> URI Class Initialized
INFO - 2018-06-21 04:07:17 --> Router Class Initialized
INFO - 2018-06-21 04:07:17 --> Output Class Initialized
INFO - 2018-06-21 04:07:17 --> Security Class Initialized
DEBUG - 2018-06-21 04:07:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 04:07:17 --> Input Class Initialized
INFO - 2018-06-21 04:07:17 --> Language Class Initialized
INFO - 2018-06-21 04:07:17 --> Language Class Initialized
INFO - 2018-06-21 04:07:17 --> Config Class Initialized
INFO - 2018-06-21 04:07:17 --> Loader Class Initialized
DEBUG - 2018-06-21 04:07:17 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 04:07:17 --> Helper loaded: url_helper
INFO - 2018-06-21 04:07:17 --> Helper loaded: form_helper
INFO - 2018-06-21 04:07:17 --> Helper loaded: date_helper
INFO - 2018-06-21 04:07:17 --> Helper loaded: util_helper
INFO - 2018-06-21 04:07:17 --> Helper loaded: text_helper
INFO - 2018-06-21 04:07:17 --> Helper loaded: string_helper
INFO - 2018-06-21 04:07:17 --> Database Driver Class Initialized
DEBUG - 2018-06-21 04:07:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 04:07:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 04:07:17 --> Email Class Initialized
INFO - 2018-06-21 04:07:17 --> Controller Class Initialized
DEBUG - 2018-06-21 04:07:17 --> Users MX_Controller Initialized
DEBUG - 2018-06-21 04:07:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 04:07:17 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 04:07:17 --> Login MX_Controller Initialized
INFO - 2018-06-21 04:07:17 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 04:07:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-21 04:07:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-06-21 04:07:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
INFO - 2018-06-21 04:07:17 --> Upload Class Initialized
ERROR - 2018-06-21 04:07:17 --> Severity: Warning --> unlink(E:\xampp\htdocs\consulting\assets/images/users/): Permission denied E:\xampp\htdocs\consulting\application\modules\admin\controllers\users.php 168
INFO - 2018-06-21 04:07:17 --> Config Class Initialized
INFO - 2018-06-21 04:07:17 --> Hooks Class Initialized
DEBUG - 2018-06-21 04:07:17 --> UTF-8 Support Enabled
INFO - 2018-06-21 04:07:17 --> Utf8 Class Initialized
INFO - 2018-06-21 04:07:17 --> URI Class Initialized
INFO - 2018-06-21 04:07:17 --> Router Class Initialized
INFO - 2018-06-21 04:07:18 --> Output Class Initialized
INFO - 2018-06-21 04:07:18 --> Security Class Initialized
DEBUG - 2018-06-21 04:07:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 04:07:18 --> Input Class Initialized
INFO - 2018-06-21 04:07:18 --> Language Class Initialized
INFO - 2018-06-21 04:07:18 --> Language Class Initialized
INFO - 2018-06-21 04:07:18 --> Config Class Initialized
INFO - 2018-06-21 04:07:18 --> Loader Class Initialized
DEBUG - 2018-06-21 04:07:18 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 04:07:18 --> Helper loaded: url_helper
INFO - 2018-06-21 04:07:18 --> Helper loaded: form_helper
INFO - 2018-06-21 04:07:18 --> Helper loaded: date_helper
INFO - 2018-06-21 04:07:18 --> Helper loaded: util_helper
INFO - 2018-06-21 04:07:18 --> Helper loaded: text_helper
INFO - 2018-06-21 04:07:18 --> Helper loaded: string_helper
INFO - 2018-06-21 04:07:18 --> Database Driver Class Initialized
DEBUG - 2018-06-21 04:07:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 04:07:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 04:07:18 --> Email Class Initialized
INFO - 2018-06-21 04:07:18 --> Controller Class Initialized
DEBUG - 2018-06-21 04:07:18 --> Users MX_Controller Initialized
DEBUG - 2018-06-21 04:07:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 04:07:18 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 04:07:18 --> Login MX_Controller Initialized
INFO - 2018-06-21 04:07:18 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 04:07:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-21 04:07:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-21 04:07:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-21 04:07:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-21 04:07:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-21 04:07:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-21 04:07:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-06-21 04:07:18 --> Final output sent to browser
DEBUG - 2018-06-21 04:07:18 --> Total execution time: 0.5427
INFO - 2018-06-21 04:07:18 --> Config Class Initialized
INFO - 2018-06-21 04:07:18 --> Hooks Class Initialized
DEBUG - 2018-06-21 04:07:18 --> UTF-8 Support Enabled
INFO - 2018-06-21 04:07:18 --> Utf8 Class Initialized
INFO - 2018-06-21 04:07:18 --> URI Class Initialized
INFO - 2018-06-21 04:07:18 --> Router Class Initialized
INFO - 2018-06-21 04:07:18 --> Output Class Initialized
INFO - 2018-06-21 04:07:18 --> Security Class Initialized
DEBUG - 2018-06-21 04:07:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 04:07:18 --> Input Class Initialized
INFO - 2018-06-21 04:07:18 --> Language Class Initialized
INFO - 2018-06-21 04:07:18 --> Language Class Initialized
INFO - 2018-06-21 04:07:19 --> Config Class Initialized
INFO - 2018-06-21 04:07:19 --> Loader Class Initialized
DEBUG - 2018-06-21 04:07:19 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 04:07:19 --> Helper loaded: url_helper
INFO - 2018-06-21 04:07:19 --> Helper loaded: form_helper
INFO - 2018-06-21 04:07:19 --> Helper loaded: date_helper
INFO - 2018-06-21 04:07:19 --> Helper loaded: util_helper
INFO - 2018-06-21 04:07:19 --> Helper loaded: text_helper
INFO - 2018-06-21 04:07:19 --> Helper loaded: string_helper
INFO - 2018-06-21 04:07:19 --> Database Driver Class Initialized
DEBUG - 2018-06-21 04:07:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 04:07:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 04:07:19 --> Email Class Initialized
INFO - 2018-06-21 04:07:19 --> Controller Class Initialized
DEBUG - 2018-06-21 04:07:19 --> Users MX_Controller Initialized
DEBUG - 2018-06-21 04:07:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 04:07:19 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 04:07:19 --> Login MX_Controller Initialized
INFO - 2018-06-21 04:07:19 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 04:07:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-21 04:07:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-06-21 04:07:19 --> Final output sent to browser
DEBUG - 2018-06-21 04:07:19 --> Total execution time: 0.5693
INFO - 2018-06-21 04:07:23 --> Config Class Initialized
INFO - 2018-06-21 04:07:23 --> Hooks Class Initialized
DEBUG - 2018-06-21 04:07:23 --> UTF-8 Support Enabled
INFO - 2018-06-21 04:07:23 --> Utf8 Class Initialized
INFO - 2018-06-21 04:07:23 --> URI Class Initialized
INFO - 2018-06-21 04:07:23 --> Router Class Initialized
INFO - 2018-06-21 04:07:23 --> Output Class Initialized
INFO - 2018-06-21 04:07:23 --> Security Class Initialized
DEBUG - 2018-06-21 04:07:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 04:07:23 --> Input Class Initialized
INFO - 2018-06-21 04:07:23 --> Language Class Initialized
INFO - 2018-06-21 04:07:23 --> Language Class Initialized
INFO - 2018-06-21 04:07:23 --> Config Class Initialized
INFO - 2018-06-21 04:07:23 --> Loader Class Initialized
DEBUG - 2018-06-21 04:07:23 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 04:07:23 --> Helper loaded: url_helper
INFO - 2018-06-21 04:07:23 --> Helper loaded: form_helper
INFO - 2018-06-21 04:07:23 --> Helper loaded: date_helper
INFO - 2018-06-21 04:07:23 --> Helper loaded: util_helper
INFO - 2018-06-21 04:07:23 --> Helper loaded: text_helper
INFO - 2018-06-21 04:07:23 --> Helper loaded: string_helper
INFO - 2018-06-21 04:07:23 --> Database Driver Class Initialized
DEBUG - 2018-06-21 04:07:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 04:07:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 04:07:23 --> Email Class Initialized
INFO - 2018-06-21 04:07:23 --> Controller Class Initialized
DEBUG - 2018-06-21 04:07:23 --> Users MX_Controller Initialized
DEBUG - 2018-06-21 04:07:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 04:07:23 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 04:07:23 --> Login MX_Controller Initialized
INFO - 2018-06-21 04:07:23 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 04:07:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-21 04:07:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-06-21 04:07:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-21 04:07:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-21 04:07:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-21 04:07:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-21 04:07:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-21 04:07:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-06-21 04:07:23 --> Final output sent to browser
DEBUG - 2018-06-21 04:07:23 --> Total execution time: 0.5633
INFO - 2018-06-21 04:07:28 --> Config Class Initialized
INFO - 2018-06-21 04:07:28 --> Hooks Class Initialized
DEBUG - 2018-06-21 04:07:28 --> UTF-8 Support Enabled
INFO - 2018-06-21 04:07:28 --> Utf8 Class Initialized
INFO - 2018-06-21 04:07:28 --> URI Class Initialized
INFO - 2018-06-21 04:07:28 --> Router Class Initialized
INFO - 2018-06-21 04:07:28 --> Output Class Initialized
INFO - 2018-06-21 04:07:28 --> Security Class Initialized
DEBUG - 2018-06-21 04:07:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 04:07:28 --> Input Class Initialized
INFO - 2018-06-21 04:07:28 --> Language Class Initialized
INFO - 2018-06-21 04:07:28 --> Language Class Initialized
INFO - 2018-06-21 04:07:28 --> Config Class Initialized
INFO - 2018-06-21 04:07:28 --> Loader Class Initialized
DEBUG - 2018-06-21 04:07:28 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 04:07:28 --> Helper loaded: url_helper
INFO - 2018-06-21 04:07:28 --> Helper loaded: form_helper
INFO - 2018-06-21 04:07:28 --> Helper loaded: date_helper
INFO - 2018-06-21 04:07:28 --> Helper loaded: util_helper
INFO - 2018-06-21 04:07:28 --> Helper loaded: text_helper
INFO - 2018-06-21 04:07:28 --> Helper loaded: string_helper
INFO - 2018-06-21 04:07:28 --> Database Driver Class Initialized
DEBUG - 2018-06-21 04:07:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 04:07:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 04:07:29 --> Email Class Initialized
INFO - 2018-06-21 04:07:29 --> Controller Class Initialized
DEBUG - 2018-06-21 04:07:29 --> Users MX_Controller Initialized
DEBUG - 2018-06-21 04:07:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 04:07:29 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 04:07:29 --> Login MX_Controller Initialized
INFO - 2018-06-21 04:07:29 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 04:07:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-21 04:07:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-06-21 04:07:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
INFO - 2018-06-21 04:07:29 --> Upload Class Initialized
INFO - 2018-06-21 04:07:29 --> Config Class Initialized
INFO - 2018-06-21 04:07:29 --> Hooks Class Initialized
DEBUG - 2018-06-21 04:07:29 --> UTF-8 Support Enabled
INFO - 2018-06-21 04:07:29 --> Utf8 Class Initialized
INFO - 2018-06-21 04:07:29 --> URI Class Initialized
INFO - 2018-06-21 04:07:29 --> Router Class Initialized
INFO - 2018-06-21 04:07:29 --> Output Class Initialized
INFO - 2018-06-21 04:07:29 --> Security Class Initialized
DEBUG - 2018-06-21 04:07:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 04:07:29 --> Input Class Initialized
INFO - 2018-06-21 04:07:29 --> Language Class Initialized
INFO - 2018-06-21 04:07:29 --> Language Class Initialized
INFO - 2018-06-21 04:07:29 --> Config Class Initialized
INFO - 2018-06-21 04:07:29 --> Loader Class Initialized
DEBUG - 2018-06-21 04:07:29 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 04:07:29 --> Helper loaded: url_helper
INFO - 2018-06-21 04:07:29 --> Helper loaded: form_helper
INFO - 2018-06-21 04:07:29 --> Helper loaded: date_helper
INFO - 2018-06-21 04:07:29 --> Helper loaded: util_helper
INFO - 2018-06-21 04:07:29 --> Helper loaded: text_helper
INFO - 2018-06-21 04:07:29 --> Helper loaded: string_helper
INFO - 2018-06-21 04:07:29 --> Database Driver Class Initialized
DEBUG - 2018-06-21 04:07:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 04:07:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 04:07:29 --> Email Class Initialized
INFO - 2018-06-21 04:07:29 --> Controller Class Initialized
DEBUG - 2018-06-21 04:07:29 --> Users MX_Controller Initialized
DEBUG - 2018-06-21 04:07:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 04:07:29 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 04:07:29 --> Login MX_Controller Initialized
INFO - 2018-06-21 04:07:29 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 04:07:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-21 04:07:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-21 04:07:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-21 04:07:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-21 04:07:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-21 04:07:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-21 04:07:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-06-21 04:07:29 --> Final output sent to browser
DEBUG - 2018-06-21 04:07:29 --> Total execution time: 0.5972
INFO - 2018-06-21 04:07:30 --> Config Class Initialized
INFO - 2018-06-21 04:07:30 --> Hooks Class Initialized
DEBUG - 2018-06-21 04:07:30 --> UTF-8 Support Enabled
INFO - 2018-06-21 04:07:30 --> Utf8 Class Initialized
INFO - 2018-06-21 04:07:30 --> URI Class Initialized
INFO - 2018-06-21 04:07:30 --> Router Class Initialized
INFO - 2018-06-21 04:07:30 --> Output Class Initialized
INFO - 2018-06-21 04:07:30 --> Security Class Initialized
DEBUG - 2018-06-21 04:07:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 04:07:30 --> Input Class Initialized
INFO - 2018-06-21 04:07:30 --> Language Class Initialized
INFO - 2018-06-21 04:07:30 --> Language Class Initialized
INFO - 2018-06-21 04:07:30 --> Config Class Initialized
INFO - 2018-06-21 04:07:30 --> Loader Class Initialized
DEBUG - 2018-06-21 04:07:30 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 04:07:30 --> Helper loaded: url_helper
INFO - 2018-06-21 04:07:30 --> Helper loaded: form_helper
INFO - 2018-06-21 04:07:30 --> Helper loaded: date_helper
INFO - 2018-06-21 04:07:30 --> Helper loaded: util_helper
INFO - 2018-06-21 04:07:30 --> Helper loaded: text_helper
INFO - 2018-06-21 04:07:30 --> Helper loaded: string_helper
INFO - 2018-06-21 04:07:30 --> Database Driver Class Initialized
DEBUG - 2018-06-21 04:07:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 04:07:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 04:07:30 --> Email Class Initialized
INFO - 2018-06-21 04:07:30 --> Controller Class Initialized
DEBUG - 2018-06-21 04:07:30 --> Users MX_Controller Initialized
DEBUG - 2018-06-21 04:07:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 04:07:30 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 04:07:30 --> Login MX_Controller Initialized
INFO - 2018-06-21 04:07:30 --> Config Class Initialized
INFO - 2018-06-21 04:07:30 --> Hooks Class Initialized
INFO - 2018-06-21 04:07:30 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 04:07:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-21 04:07:30 --> UTF-8 Support Enabled
INFO - 2018-06-21 04:07:30 --> Utf8 Class Initialized
DEBUG - 2018-06-21 04:07:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-06-21 04:07:30 --> URI Class Initialized
INFO - 2018-06-21 04:07:30 --> Final output sent to browser
DEBUG - 2018-06-21 04:07:30 --> Total execution time: 0.5409
INFO - 2018-06-21 04:07:30 --> Router Class Initialized
INFO - 2018-06-21 04:07:30 --> Output Class Initialized
INFO - 2018-06-21 04:07:30 --> Security Class Initialized
DEBUG - 2018-06-21 04:07:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 04:07:30 --> Input Class Initialized
INFO - 2018-06-21 04:07:30 --> Language Class Initialized
ERROR - 2018-06-21 04:07:30 --> 404 Page Not Found: /index
INFO - 2018-06-21 04:07:34 --> Config Class Initialized
INFO - 2018-06-21 04:07:34 --> Hooks Class Initialized
DEBUG - 2018-06-21 04:07:34 --> UTF-8 Support Enabled
INFO - 2018-06-21 04:07:34 --> Utf8 Class Initialized
INFO - 2018-06-21 04:07:34 --> URI Class Initialized
INFO - 2018-06-21 04:07:34 --> Router Class Initialized
INFO - 2018-06-21 04:07:34 --> Output Class Initialized
INFO - 2018-06-21 04:07:34 --> Security Class Initialized
DEBUG - 2018-06-21 04:07:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 04:07:34 --> Input Class Initialized
INFO - 2018-06-21 04:07:34 --> Language Class Initialized
INFO - 2018-06-21 04:07:34 --> Language Class Initialized
INFO - 2018-06-21 04:07:34 --> Config Class Initialized
INFO - 2018-06-21 04:07:34 --> Loader Class Initialized
DEBUG - 2018-06-21 04:07:34 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 04:07:34 --> Helper loaded: url_helper
INFO - 2018-06-21 04:07:34 --> Helper loaded: form_helper
INFO - 2018-06-21 04:07:34 --> Helper loaded: date_helper
INFO - 2018-06-21 04:07:34 --> Helper loaded: util_helper
INFO - 2018-06-21 04:07:35 --> Helper loaded: text_helper
INFO - 2018-06-21 04:07:35 --> Helper loaded: string_helper
INFO - 2018-06-21 04:07:35 --> Database Driver Class Initialized
DEBUG - 2018-06-21 04:07:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 04:07:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 04:07:35 --> Email Class Initialized
INFO - 2018-06-21 04:07:35 --> Controller Class Initialized
DEBUG - 2018-06-21 04:07:35 --> Users MX_Controller Initialized
DEBUG - 2018-06-21 04:07:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 04:07:35 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 04:07:35 --> Login MX_Controller Initialized
INFO - 2018-06-21 04:07:35 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 04:07:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-21 04:07:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-21 04:07:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-21 04:07:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-21 04:07:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-21 04:07:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-21 04:07:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-06-21 04:07:35 --> Final output sent to browser
DEBUG - 2018-06-21 04:07:35 --> Total execution time: 0.5250
INFO - 2018-06-21 04:07:35 --> Config Class Initialized
INFO - 2018-06-21 04:07:35 --> Hooks Class Initialized
DEBUG - 2018-06-21 04:07:35 --> UTF-8 Support Enabled
INFO - 2018-06-21 04:07:35 --> Utf8 Class Initialized
INFO - 2018-06-21 04:07:35 --> URI Class Initialized
INFO - 2018-06-21 04:07:35 --> Router Class Initialized
INFO - 2018-06-21 04:07:35 --> Output Class Initialized
INFO - 2018-06-21 04:07:35 --> Security Class Initialized
DEBUG - 2018-06-21 04:07:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 04:07:35 --> Input Class Initialized
INFO - 2018-06-21 04:07:35 --> Language Class Initialized
INFO - 2018-06-21 04:07:35 --> Language Class Initialized
INFO - 2018-06-21 04:07:35 --> Config Class Initialized
INFO - 2018-06-21 04:07:35 --> Loader Class Initialized
DEBUG - 2018-06-21 04:07:35 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 04:07:35 --> Helper loaded: url_helper
INFO - 2018-06-21 04:07:35 --> Helper loaded: form_helper
INFO - 2018-06-21 04:07:35 --> Helper loaded: date_helper
INFO - 2018-06-21 04:07:35 --> Helper loaded: util_helper
INFO - 2018-06-21 04:07:35 --> Helper loaded: text_helper
INFO - 2018-06-21 04:07:35 --> Helper loaded: string_helper
INFO - 2018-06-21 04:07:35 --> Database Driver Class Initialized
DEBUG - 2018-06-21 04:07:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 04:07:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 04:07:35 --> Email Class Initialized
INFO - 2018-06-21 04:07:35 --> Controller Class Initialized
DEBUG - 2018-06-21 04:07:35 --> Users MX_Controller Initialized
DEBUG - 2018-06-21 04:07:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 04:07:35 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 04:07:35 --> Login MX_Controller Initialized
INFO - 2018-06-21 04:07:35 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 04:07:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-21 04:07:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-06-21 04:07:36 --> Final output sent to browser
DEBUG - 2018-06-21 04:07:36 --> Total execution time: 0.5808
INFO - 2018-06-21 04:09:09 --> Config Class Initialized
INFO - 2018-06-21 04:09:09 --> Hooks Class Initialized
DEBUG - 2018-06-21 04:09:09 --> UTF-8 Support Enabled
INFO - 2018-06-21 04:09:09 --> Utf8 Class Initialized
INFO - 2018-06-21 04:09:09 --> URI Class Initialized
INFO - 2018-06-21 04:09:09 --> Router Class Initialized
INFO - 2018-06-21 04:09:09 --> Output Class Initialized
INFO - 2018-06-21 04:09:09 --> Security Class Initialized
DEBUG - 2018-06-21 04:09:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 04:09:09 --> Input Class Initialized
INFO - 2018-06-21 04:09:09 --> Language Class Initialized
INFO - 2018-06-21 04:09:09 --> Language Class Initialized
INFO - 2018-06-21 04:09:09 --> Config Class Initialized
INFO - 2018-06-21 04:09:09 --> Loader Class Initialized
DEBUG - 2018-06-21 04:09:09 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 04:09:09 --> Helper loaded: url_helper
INFO - 2018-06-21 04:09:09 --> Helper loaded: form_helper
INFO - 2018-06-21 04:09:09 --> Helper loaded: date_helper
INFO - 2018-06-21 04:09:09 --> Helper loaded: util_helper
INFO - 2018-06-21 04:09:09 --> Helper loaded: text_helper
INFO - 2018-06-21 04:09:09 --> Helper loaded: string_helper
INFO - 2018-06-21 04:09:09 --> Database Driver Class Initialized
DEBUG - 2018-06-21 04:09:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 04:09:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 04:09:09 --> Email Class Initialized
INFO - 2018-06-21 04:09:09 --> Controller Class Initialized
DEBUG - 2018-06-21 04:09:09 --> Users MX_Controller Initialized
DEBUG - 2018-06-21 04:09:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 04:09:09 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 04:09:09 --> Login MX_Controller Initialized
INFO - 2018-06-21 04:09:09 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 04:09:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-21 04:09:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-06-21 04:09:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-21 04:09:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-21 04:09:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-21 04:09:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-21 04:09:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-21 04:09:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-06-21 04:09:10 --> Final output sent to browser
DEBUG - 2018-06-21 04:09:10 --> Total execution time: 0.5528
INFO - 2018-06-21 04:09:12 --> Config Class Initialized
INFO - 2018-06-21 04:09:12 --> Hooks Class Initialized
DEBUG - 2018-06-21 04:09:12 --> UTF-8 Support Enabled
INFO - 2018-06-21 04:09:12 --> Utf8 Class Initialized
INFO - 2018-06-21 04:09:12 --> URI Class Initialized
INFO - 2018-06-21 04:09:12 --> Router Class Initialized
INFO - 2018-06-21 04:09:12 --> Output Class Initialized
INFO - 2018-06-21 04:09:12 --> Security Class Initialized
DEBUG - 2018-06-21 04:09:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 04:09:12 --> Input Class Initialized
INFO - 2018-06-21 04:09:12 --> Language Class Initialized
INFO - 2018-06-21 04:09:12 --> Language Class Initialized
INFO - 2018-06-21 04:09:12 --> Config Class Initialized
INFO - 2018-06-21 04:09:12 --> Loader Class Initialized
DEBUG - 2018-06-21 04:09:12 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 04:09:12 --> Helper loaded: url_helper
INFO - 2018-06-21 04:09:12 --> Helper loaded: form_helper
INFO - 2018-06-21 04:09:12 --> Helper loaded: date_helper
INFO - 2018-06-21 04:09:12 --> Helper loaded: util_helper
INFO - 2018-06-21 04:09:12 --> Helper loaded: text_helper
INFO - 2018-06-21 04:09:12 --> Helper loaded: string_helper
INFO - 2018-06-21 04:09:12 --> Database Driver Class Initialized
DEBUG - 2018-06-21 04:09:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 04:09:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 04:09:12 --> Email Class Initialized
INFO - 2018-06-21 04:09:12 --> Controller Class Initialized
DEBUG - 2018-06-21 04:09:12 --> Users MX_Controller Initialized
DEBUG - 2018-06-21 04:09:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 04:09:12 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 04:09:12 --> Login MX_Controller Initialized
INFO - 2018-06-21 04:09:12 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 04:09:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-21 04:09:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-21 04:09:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-21 04:09:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-21 04:09:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-21 04:09:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-21 04:09:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-06-21 04:09:12 --> Final output sent to browser
DEBUG - 2018-06-21 04:09:12 --> Total execution time: 0.5282
INFO - 2018-06-21 04:09:13 --> Config Class Initialized
INFO - 2018-06-21 04:09:13 --> Hooks Class Initialized
DEBUG - 2018-06-21 04:09:13 --> UTF-8 Support Enabled
INFO - 2018-06-21 04:09:13 --> Utf8 Class Initialized
INFO - 2018-06-21 04:09:13 --> URI Class Initialized
INFO - 2018-06-21 04:09:13 --> Router Class Initialized
INFO - 2018-06-21 04:09:13 --> Output Class Initialized
INFO - 2018-06-21 04:09:13 --> Security Class Initialized
DEBUG - 2018-06-21 04:09:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 04:09:13 --> Input Class Initialized
INFO - 2018-06-21 04:09:13 --> Language Class Initialized
INFO - 2018-06-21 04:09:13 --> Language Class Initialized
INFO - 2018-06-21 04:09:13 --> Config Class Initialized
INFO - 2018-06-21 04:09:13 --> Loader Class Initialized
DEBUG - 2018-06-21 04:09:13 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 04:09:13 --> Helper loaded: url_helper
INFO - 2018-06-21 04:09:13 --> Helper loaded: form_helper
INFO - 2018-06-21 04:09:13 --> Helper loaded: date_helper
INFO - 2018-06-21 04:09:13 --> Helper loaded: util_helper
INFO - 2018-06-21 04:09:13 --> Helper loaded: text_helper
INFO - 2018-06-21 04:09:13 --> Helper loaded: string_helper
INFO - 2018-06-21 04:09:13 --> Database Driver Class Initialized
DEBUG - 2018-06-21 04:09:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 04:09:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 04:09:13 --> Email Class Initialized
INFO - 2018-06-21 04:09:13 --> Controller Class Initialized
DEBUG - 2018-06-21 04:09:13 --> Users MX_Controller Initialized
DEBUG - 2018-06-21 04:09:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 04:09:13 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 04:09:13 --> Login MX_Controller Initialized
INFO - 2018-06-21 04:09:13 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 04:09:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-21 04:09:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-06-21 04:09:13 --> Final output sent to browser
DEBUG - 2018-06-21 04:09:13 --> Total execution time: 0.5900
INFO - 2018-06-21 04:09:50 --> Config Class Initialized
INFO - 2018-06-21 04:09:50 --> Hooks Class Initialized
DEBUG - 2018-06-21 04:09:50 --> UTF-8 Support Enabled
INFO - 2018-06-21 04:09:50 --> Utf8 Class Initialized
INFO - 2018-06-21 04:09:50 --> URI Class Initialized
INFO - 2018-06-21 04:09:50 --> Router Class Initialized
INFO - 2018-06-21 04:09:50 --> Output Class Initialized
INFO - 2018-06-21 04:09:50 --> Security Class Initialized
DEBUG - 2018-06-21 04:09:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 04:09:50 --> Input Class Initialized
INFO - 2018-06-21 04:09:50 --> Language Class Initialized
INFO - 2018-06-21 04:09:50 --> Language Class Initialized
INFO - 2018-06-21 04:09:51 --> Config Class Initialized
INFO - 2018-06-21 04:09:51 --> Loader Class Initialized
DEBUG - 2018-06-21 04:09:51 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 04:09:51 --> Helper loaded: url_helper
INFO - 2018-06-21 04:09:51 --> Helper loaded: form_helper
INFO - 2018-06-21 04:09:51 --> Helper loaded: date_helper
INFO - 2018-06-21 04:09:51 --> Helper loaded: util_helper
INFO - 2018-06-21 04:09:51 --> Helper loaded: text_helper
INFO - 2018-06-21 04:09:51 --> Helper loaded: string_helper
INFO - 2018-06-21 04:09:51 --> Database Driver Class Initialized
DEBUG - 2018-06-21 04:09:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 04:09:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 04:09:51 --> Email Class Initialized
INFO - 2018-06-21 04:09:51 --> Controller Class Initialized
DEBUG - 2018-06-21 04:09:51 --> Users MX_Controller Initialized
DEBUG - 2018-06-21 04:09:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 04:09:51 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 04:09:51 --> Login MX_Controller Initialized
INFO - 2018-06-21 04:09:51 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 04:09:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-21 04:09:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-06-21 04:09:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-21 04:09:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-21 04:09:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-21 04:09:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-21 04:09:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-21 04:09:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-06-21 04:09:51 --> Final output sent to browser
DEBUG - 2018-06-21 04:09:51 --> Total execution time: 0.5777
INFO - 2018-06-21 04:09:55 --> Config Class Initialized
INFO - 2018-06-21 04:09:55 --> Hooks Class Initialized
DEBUG - 2018-06-21 04:09:55 --> UTF-8 Support Enabled
INFO - 2018-06-21 04:09:55 --> Utf8 Class Initialized
INFO - 2018-06-21 04:09:55 --> URI Class Initialized
INFO - 2018-06-21 04:09:55 --> Router Class Initialized
INFO - 2018-06-21 04:09:55 --> Output Class Initialized
INFO - 2018-06-21 04:09:55 --> Security Class Initialized
DEBUG - 2018-06-21 04:09:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 04:09:55 --> Input Class Initialized
INFO - 2018-06-21 04:09:55 --> Language Class Initialized
INFO - 2018-06-21 04:09:55 --> Language Class Initialized
INFO - 2018-06-21 04:09:55 --> Config Class Initialized
INFO - 2018-06-21 04:09:56 --> Loader Class Initialized
DEBUG - 2018-06-21 04:09:56 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 04:09:56 --> Helper loaded: url_helper
INFO - 2018-06-21 04:09:56 --> Helper loaded: form_helper
INFO - 2018-06-21 04:09:56 --> Helper loaded: date_helper
INFO - 2018-06-21 04:09:56 --> Helper loaded: util_helper
INFO - 2018-06-21 04:09:56 --> Helper loaded: text_helper
INFO - 2018-06-21 04:09:56 --> Helper loaded: string_helper
INFO - 2018-06-21 04:09:56 --> Database Driver Class Initialized
DEBUG - 2018-06-21 04:09:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 04:09:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 04:09:56 --> Email Class Initialized
INFO - 2018-06-21 04:09:56 --> Controller Class Initialized
DEBUG - 2018-06-21 04:09:56 --> Users MX_Controller Initialized
DEBUG - 2018-06-21 04:09:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 04:09:56 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 04:09:56 --> Login MX_Controller Initialized
INFO - 2018-06-21 04:09:56 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 04:09:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-21 04:09:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-06-21 04:09:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
INFO - 2018-06-21 04:09:56 --> Config Class Initialized
INFO - 2018-06-21 04:09:56 --> Hooks Class Initialized
DEBUG - 2018-06-21 04:09:56 --> UTF-8 Support Enabled
INFO - 2018-06-21 04:09:56 --> Utf8 Class Initialized
INFO - 2018-06-21 04:09:56 --> URI Class Initialized
INFO - 2018-06-21 04:09:56 --> Router Class Initialized
INFO - 2018-06-21 04:09:56 --> Output Class Initialized
INFO - 2018-06-21 04:09:56 --> Security Class Initialized
DEBUG - 2018-06-21 04:09:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 04:09:56 --> Input Class Initialized
INFO - 2018-06-21 04:09:56 --> Language Class Initialized
INFO - 2018-06-21 04:09:56 --> Language Class Initialized
INFO - 2018-06-21 04:09:56 --> Config Class Initialized
INFO - 2018-06-21 04:09:56 --> Loader Class Initialized
DEBUG - 2018-06-21 04:09:56 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 04:09:56 --> Helper loaded: url_helper
INFO - 2018-06-21 04:09:56 --> Helper loaded: form_helper
INFO - 2018-06-21 04:09:56 --> Helper loaded: date_helper
INFO - 2018-06-21 04:09:56 --> Helper loaded: util_helper
INFO - 2018-06-21 04:09:56 --> Helper loaded: text_helper
INFO - 2018-06-21 04:09:56 --> Helper loaded: string_helper
INFO - 2018-06-21 04:09:56 --> Database Driver Class Initialized
DEBUG - 2018-06-21 04:09:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 04:09:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 04:09:56 --> Email Class Initialized
INFO - 2018-06-21 04:09:56 --> Controller Class Initialized
DEBUG - 2018-06-21 04:09:56 --> Users MX_Controller Initialized
DEBUG - 2018-06-21 04:09:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 04:09:56 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 04:09:56 --> Login MX_Controller Initialized
INFO - 2018-06-21 04:09:56 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 04:09:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-21 04:09:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-21 04:09:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-21 04:09:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-21 04:09:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-21 04:09:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-21 04:09:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-06-21 04:09:56 --> Final output sent to browser
DEBUG - 2018-06-21 04:09:56 --> Total execution time: 0.5542
INFO - 2018-06-21 04:09:57 --> Config Class Initialized
INFO - 2018-06-21 04:09:57 --> Hooks Class Initialized
DEBUG - 2018-06-21 04:09:57 --> UTF-8 Support Enabled
INFO - 2018-06-21 04:09:57 --> Utf8 Class Initialized
INFO - 2018-06-21 04:09:57 --> URI Class Initialized
INFO - 2018-06-21 04:09:57 --> Router Class Initialized
INFO - 2018-06-21 04:09:57 --> Output Class Initialized
INFO - 2018-06-21 04:09:57 --> Security Class Initialized
DEBUG - 2018-06-21 04:09:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 04:09:57 --> Input Class Initialized
INFO - 2018-06-21 04:09:57 --> Language Class Initialized
INFO - 2018-06-21 04:09:57 --> Language Class Initialized
INFO - 2018-06-21 04:09:57 --> Config Class Initialized
INFO - 2018-06-21 04:09:57 --> Loader Class Initialized
DEBUG - 2018-06-21 04:09:57 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 04:09:57 --> Helper loaded: url_helper
INFO - 2018-06-21 04:09:57 --> Helper loaded: form_helper
INFO - 2018-06-21 04:09:57 --> Helper loaded: date_helper
INFO - 2018-06-21 04:09:57 --> Helper loaded: util_helper
INFO - 2018-06-21 04:09:57 --> Helper loaded: text_helper
INFO - 2018-06-21 04:09:57 --> Helper loaded: string_helper
INFO - 2018-06-21 04:09:57 --> Database Driver Class Initialized
DEBUG - 2018-06-21 04:09:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 04:09:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 04:09:57 --> Email Class Initialized
INFO - 2018-06-21 04:09:57 --> Controller Class Initialized
DEBUG - 2018-06-21 04:09:57 --> Users MX_Controller Initialized
DEBUG - 2018-06-21 04:09:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 04:09:57 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 04:09:57 --> Login MX_Controller Initialized
INFO - 2018-06-21 04:09:57 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 04:09:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-21 04:09:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-06-21 04:09:57 --> Final output sent to browser
DEBUG - 2018-06-21 04:09:57 --> Total execution time: 0.5505
INFO - 2018-06-21 04:10:01 --> Config Class Initialized
INFO - 2018-06-21 04:10:01 --> Hooks Class Initialized
DEBUG - 2018-06-21 04:10:01 --> UTF-8 Support Enabled
INFO - 2018-06-21 04:10:01 --> Utf8 Class Initialized
INFO - 2018-06-21 04:10:01 --> URI Class Initialized
INFO - 2018-06-21 04:10:01 --> Router Class Initialized
INFO - 2018-06-21 04:10:01 --> Output Class Initialized
INFO - 2018-06-21 04:10:01 --> Security Class Initialized
DEBUG - 2018-06-21 04:10:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 04:10:01 --> Input Class Initialized
INFO - 2018-06-21 04:10:01 --> Language Class Initialized
INFO - 2018-06-21 04:10:01 --> Language Class Initialized
INFO - 2018-06-21 04:10:01 --> Config Class Initialized
INFO - 2018-06-21 04:10:01 --> Loader Class Initialized
DEBUG - 2018-06-21 04:10:01 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 04:10:01 --> Helper loaded: url_helper
INFO - 2018-06-21 04:10:02 --> Helper loaded: form_helper
INFO - 2018-06-21 04:10:02 --> Helper loaded: date_helper
INFO - 2018-06-21 04:10:02 --> Helper loaded: util_helper
INFO - 2018-06-21 04:10:02 --> Helper loaded: text_helper
INFO - 2018-06-21 04:10:02 --> Helper loaded: string_helper
INFO - 2018-06-21 04:10:02 --> Database Driver Class Initialized
DEBUG - 2018-06-21 04:10:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 04:10:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 04:10:02 --> Email Class Initialized
INFO - 2018-06-21 04:10:02 --> Controller Class Initialized
DEBUG - 2018-06-21 04:10:02 --> Users MX_Controller Initialized
DEBUG - 2018-06-21 04:10:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 04:10:02 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 04:10:02 --> Login MX_Controller Initialized
INFO - 2018-06-21 04:10:02 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 04:10:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-21 04:10:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-06-21 04:10:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-21 04:10:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-21 04:10:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-21 04:10:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-21 04:10:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-21 04:10:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-06-21 04:10:02 --> Final output sent to browser
DEBUG - 2018-06-21 04:10:02 --> Total execution time: 0.5736
INFO - 2018-06-21 04:10:07 --> Config Class Initialized
INFO - 2018-06-21 04:10:07 --> Hooks Class Initialized
DEBUG - 2018-06-21 04:10:07 --> UTF-8 Support Enabled
INFO - 2018-06-21 04:10:07 --> Utf8 Class Initialized
INFO - 2018-06-21 04:10:07 --> URI Class Initialized
INFO - 2018-06-21 04:10:07 --> Router Class Initialized
INFO - 2018-06-21 04:10:07 --> Output Class Initialized
INFO - 2018-06-21 04:10:07 --> Security Class Initialized
DEBUG - 2018-06-21 04:10:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 04:10:07 --> Input Class Initialized
INFO - 2018-06-21 04:10:07 --> Language Class Initialized
INFO - 2018-06-21 04:10:07 --> Language Class Initialized
INFO - 2018-06-21 04:10:07 --> Config Class Initialized
INFO - 2018-06-21 04:10:07 --> Loader Class Initialized
DEBUG - 2018-06-21 04:10:07 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 04:10:07 --> Helper loaded: url_helper
INFO - 2018-06-21 04:10:07 --> Helper loaded: form_helper
INFO - 2018-06-21 04:10:07 --> Helper loaded: date_helper
INFO - 2018-06-21 04:10:07 --> Helper loaded: util_helper
INFO - 2018-06-21 04:10:07 --> Helper loaded: text_helper
INFO - 2018-06-21 04:10:07 --> Helper loaded: string_helper
INFO - 2018-06-21 04:10:07 --> Database Driver Class Initialized
DEBUG - 2018-06-21 04:10:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 04:10:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 04:10:07 --> Email Class Initialized
INFO - 2018-06-21 04:10:07 --> Controller Class Initialized
DEBUG - 2018-06-21 04:10:07 --> Users MX_Controller Initialized
DEBUG - 2018-06-21 04:10:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 04:10:07 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 04:10:07 --> Login MX_Controller Initialized
INFO - 2018-06-21 04:10:07 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 04:10:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-21 04:10:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-21 04:10:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-21 04:10:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-21 04:10:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-21 04:10:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-21 04:10:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-06-21 04:10:07 --> Final output sent to browser
DEBUG - 2018-06-21 04:10:07 --> Total execution time: 0.5586
INFO - 2018-06-21 04:10:08 --> Config Class Initialized
INFO - 2018-06-21 04:10:08 --> Hooks Class Initialized
DEBUG - 2018-06-21 04:10:08 --> UTF-8 Support Enabled
INFO - 2018-06-21 04:10:08 --> Utf8 Class Initialized
INFO - 2018-06-21 04:10:08 --> URI Class Initialized
INFO - 2018-06-21 04:10:08 --> Router Class Initialized
INFO - 2018-06-21 04:10:08 --> Output Class Initialized
INFO - 2018-06-21 04:10:08 --> Security Class Initialized
DEBUG - 2018-06-21 04:10:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 04:10:08 --> Input Class Initialized
INFO - 2018-06-21 04:10:08 --> Language Class Initialized
INFO - 2018-06-21 04:10:08 --> Language Class Initialized
INFO - 2018-06-21 04:10:08 --> Config Class Initialized
INFO - 2018-06-21 04:10:08 --> Loader Class Initialized
DEBUG - 2018-06-21 04:10:08 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 04:10:08 --> Helper loaded: url_helper
INFO - 2018-06-21 04:10:08 --> Helper loaded: form_helper
INFO - 2018-06-21 04:10:08 --> Helper loaded: date_helper
INFO - 2018-06-21 04:10:08 --> Helper loaded: util_helper
INFO - 2018-06-21 04:10:08 --> Helper loaded: text_helper
INFO - 2018-06-21 04:10:08 --> Helper loaded: string_helper
INFO - 2018-06-21 04:10:08 --> Database Driver Class Initialized
DEBUG - 2018-06-21 04:10:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 04:10:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 04:10:08 --> Email Class Initialized
INFO - 2018-06-21 04:10:08 --> Controller Class Initialized
DEBUG - 2018-06-21 04:10:08 --> Users MX_Controller Initialized
DEBUG - 2018-06-21 04:10:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 04:10:08 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 04:10:08 --> Login MX_Controller Initialized
INFO - 2018-06-21 04:10:08 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 04:10:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-21 04:10:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-06-21 04:10:08 --> Final output sent to browser
DEBUG - 2018-06-21 04:10:08 --> Total execution time: 0.6090
INFO - 2018-06-21 04:10:10 --> Config Class Initialized
INFO - 2018-06-21 04:10:10 --> Hooks Class Initialized
DEBUG - 2018-06-21 04:10:10 --> UTF-8 Support Enabled
INFO - 2018-06-21 04:10:10 --> Utf8 Class Initialized
INFO - 2018-06-21 04:10:10 --> URI Class Initialized
INFO - 2018-06-21 04:10:10 --> Router Class Initialized
INFO - 2018-06-21 04:10:10 --> Output Class Initialized
INFO - 2018-06-21 04:10:10 --> Security Class Initialized
DEBUG - 2018-06-21 04:10:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 04:10:10 --> Input Class Initialized
INFO - 2018-06-21 04:10:10 --> Language Class Initialized
INFO - 2018-06-21 04:10:10 --> Language Class Initialized
INFO - 2018-06-21 04:10:10 --> Config Class Initialized
INFO - 2018-06-21 04:10:10 --> Loader Class Initialized
DEBUG - 2018-06-21 04:10:10 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 04:10:10 --> Helper loaded: url_helper
INFO - 2018-06-21 04:10:10 --> Helper loaded: form_helper
INFO - 2018-06-21 04:10:10 --> Helper loaded: date_helper
INFO - 2018-06-21 04:10:10 --> Helper loaded: util_helper
INFO - 2018-06-21 04:10:10 --> Helper loaded: text_helper
INFO - 2018-06-21 04:10:10 --> Helper loaded: string_helper
INFO - 2018-06-21 04:10:10 --> Database Driver Class Initialized
DEBUG - 2018-06-21 04:10:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 04:10:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 04:10:10 --> Email Class Initialized
INFO - 2018-06-21 04:10:10 --> Controller Class Initialized
DEBUG - 2018-06-21 04:10:10 --> Login MX_Controller Initialized
INFO - 2018-06-21 04:10:10 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 04:10:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 04:10:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-21 04:10:10 --> 1 Loggedout
INFO - 2018-06-21 04:10:10 --> Config Class Initialized
INFO - 2018-06-21 04:10:10 --> Hooks Class Initialized
DEBUG - 2018-06-21 04:10:10 --> UTF-8 Support Enabled
INFO - 2018-06-21 04:10:10 --> Utf8 Class Initialized
INFO - 2018-06-21 04:10:10 --> URI Class Initialized
INFO - 2018-06-21 04:10:10 --> Router Class Initialized
INFO - 2018-06-21 04:10:10 --> Output Class Initialized
INFO - 2018-06-21 04:10:10 --> Security Class Initialized
DEBUG - 2018-06-21 04:10:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 04:10:10 --> Input Class Initialized
INFO - 2018-06-21 04:10:10 --> Language Class Initialized
INFO - 2018-06-21 04:10:10 --> Language Class Initialized
INFO - 2018-06-21 04:10:10 --> Config Class Initialized
INFO - 2018-06-21 04:10:10 --> Loader Class Initialized
DEBUG - 2018-06-21 04:10:10 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 04:10:10 --> Helper loaded: url_helper
INFO - 2018-06-21 04:10:10 --> Helper loaded: form_helper
INFO - 2018-06-21 04:10:10 --> Helper loaded: date_helper
INFO - 2018-06-21 04:10:10 --> Helper loaded: util_helper
INFO - 2018-06-21 04:10:10 --> Helper loaded: text_helper
INFO - 2018-06-21 04:10:10 --> Helper loaded: string_helper
INFO - 2018-06-21 04:10:10 --> Database Driver Class Initialized
DEBUG - 2018-06-21 04:10:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 04:10:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 04:10:10 --> Email Class Initialized
INFO - 2018-06-21 04:10:10 --> Controller Class Initialized
DEBUG - 2018-06-21 04:10:10 --> Admin MX_Controller Initialized
INFO - 2018-06-21 04:10:10 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 04:10:10 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 04:10:11 --> Login MX_Controller Initialized
DEBUG - 2018-06-21 04:10:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 04:10:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-21 04:10:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
INFO - 2018-06-21 04:10:11 --> Config Class Initialized
INFO - 2018-06-21 04:10:11 --> Hooks Class Initialized
DEBUG - 2018-06-21 04:10:11 --> UTF-8 Support Enabled
INFO - 2018-06-21 04:10:11 --> Utf8 Class Initialized
INFO - 2018-06-21 04:10:11 --> URI Class Initialized
INFO - 2018-06-21 04:10:11 --> Router Class Initialized
INFO - 2018-06-21 04:10:11 --> Output Class Initialized
INFO - 2018-06-21 04:10:11 --> Security Class Initialized
DEBUG - 2018-06-21 04:10:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 04:10:11 --> Input Class Initialized
INFO - 2018-06-21 04:10:11 --> Language Class Initialized
ERROR - 2018-06-21 04:10:11 --> 404 Page Not Found: /index
INFO - 2018-06-21 04:10:14 --> Config Class Initialized
INFO - 2018-06-21 04:10:14 --> Hooks Class Initialized
DEBUG - 2018-06-21 04:10:14 --> UTF-8 Support Enabled
INFO - 2018-06-21 04:10:14 --> Utf8 Class Initialized
INFO - 2018-06-21 04:10:14 --> URI Class Initialized
INFO - 2018-06-21 04:10:14 --> Router Class Initialized
INFO - 2018-06-21 04:10:14 --> Output Class Initialized
INFO - 2018-06-21 04:10:14 --> Security Class Initialized
DEBUG - 2018-06-21 04:10:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 04:10:14 --> Input Class Initialized
INFO - 2018-06-21 04:10:14 --> Language Class Initialized
INFO - 2018-06-21 04:10:14 --> Language Class Initialized
INFO - 2018-06-21 04:10:14 --> Config Class Initialized
INFO - 2018-06-21 04:10:14 --> Loader Class Initialized
DEBUG - 2018-06-21 04:10:14 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 04:10:14 --> Helper loaded: url_helper
INFO - 2018-06-21 04:10:14 --> Helper loaded: form_helper
INFO - 2018-06-21 04:10:14 --> Helper loaded: date_helper
INFO - 2018-06-21 04:10:14 --> Helper loaded: util_helper
INFO - 2018-06-21 04:10:14 --> Helper loaded: text_helper
INFO - 2018-06-21 04:10:14 --> Helper loaded: string_helper
INFO - 2018-06-21 04:10:14 --> Database Driver Class Initialized
DEBUG - 2018-06-21 04:10:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 04:10:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 04:10:14 --> Email Class Initialized
INFO - 2018-06-21 04:10:14 --> Controller Class Initialized
DEBUG - 2018-06-21 04:10:14 --> Login MX_Controller Initialized
INFO - 2018-06-21 04:10:14 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 04:10:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 04:10:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-21 04:10:14 --> Email starts for gopi.lion123@gmail.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-06-21 04:10:14 --> Login status gopi.lion123@gmail.com - failure
INFO - 2018-06-21 04:10:14 --> Final output sent to browser
DEBUG - 2018-06-21 04:10:14 --> Total execution time: 0.4390
INFO - 2018-06-21 04:10:25 --> Config Class Initialized
INFO - 2018-06-21 04:10:25 --> Hooks Class Initialized
DEBUG - 2018-06-21 04:10:25 --> UTF-8 Support Enabled
INFO - 2018-06-21 04:10:25 --> Utf8 Class Initialized
INFO - 2018-06-21 04:10:25 --> URI Class Initialized
INFO - 2018-06-21 04:10:25 --> Router Class Initialized
INFO - 2018-06-21 04:10:25 --> Output Class Initialized
INFO - 2018-06-21 04:10:25 --> Security Class Initialized
DEBUG - 2018-06-21 04:10:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 04:10:25 --> Input Class Initialized
INFO - 2018-06-21 04:10:25 --> Language Class Initialized
INFO - 2018-06-21 04:10:25 --> Language Class Initialized
INFO - 2018-06-21 04:10:25 --> Config Class Initialized
INFO - 2018-06-21 04:10:25 --> Loader Class Initialized
DEBUG - 2018-06-21 04:10:25 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 04:10:25 --> Helper loaded: url_helper
INFO - 2018-06-21 04:10:25 --> Helper loaded: form_helper
INFO - 2018-06-21 04:10:25 --> Helper loaded: date_helper
INFO - 2018-06-21 04:10:25 --> Helper loaded: util_helper
INFO - 2018-06-21 04:10:25 --> Helper loaded: text_helper
INFO - 2018-06-21 04:10:25 --> Helper loaded: string_helper
INFO - 2018-06-21 04:10:25 --> Database Driver Class Initialized
DEBUG - 2018-06-21 04:10:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 04:10:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 04:10:25 --> Email Class Initialized
INFO - 2018-06-21 04:10:25 --> Controller Class Initialized
DEBUG - 2018-06-21 04:10:25 --> Login MX_Controller Initialized
INFO - 2018-06-21 04:10:25 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 04:10:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 04:10:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-21 04:10:25 --> Email starts for gopi.lion123@gmail.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-06-21 04:10:25 --> Login status gopi.lion123@gmail.com - failure
INFO - 2018-06-21 04:10:25 --> Final output sent to browser
DEBUG - 2018-06-21 04:10:25 --> Total execution time: 0.4820
INFO - 2018-06-21 04:11:41 --> Config Class Initialized
INFO - 2018-06-21 04:11:41 --> Hooks Class Initialized
DEBUG - 2018-06-21 04:11:41 --> UTF-8 Support Enabled
INFO - 2018-06-21 04:11:41 --> Utf8 Class Initialized
INFO - 2018-06-21 04:11:41 --> URI Class Initialized
INFO - 2018-06-21 04:11:41 --> Router Class Initialized
INFO - 2018-06-21 04:11:41 --> Output Class Initialized
INFO - 2018-06-21 04:11:41 --> Security Class Initialized
DEBUG - 2018-06-21 04:11:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 04:11:41 --> Input Class Initialized
INFO - 2018-06-21 04:11:41 --> Language Class Initialized
INFO - 2018-06-21 04:11:41 --> Language Class Initialized
INFO - 2018-06-21 04:11:41 --> Config Class Initialized
INFO - 2018-06-21 04:11:41 --> Loader Class Initialized
DEBUG - 2018-06-21 04:11:41 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 04:11:41 --> Helper loaded: url_helper
INFO - 2018-06-21 04:11:41 --> Helper loaded: form_helper
INFO - 2018-06-21 04:11:41 --> Helper loaded: date_helper
INFO - 2018-06-21 04:11:41 --> Helper loaded: util_helper
INFO - 2018-06-21 04:11:41 --> Helper loaded: text_helper
INFO - 2018-06-21 04:11:41 --> Helper loaded: string_helper
INFO - 2018-06-21 04:11:41 --> Database Driver Class Initialized
DEBUG - 2018-06-21 04:11:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 04:11:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 04:11:41 --> Email Class Initialized
INFO - 2018-06-21 04:11:41 --> Controller Class Initialized
DEBUG - 2018-06-21 04:11:41 --> Login MX_Controller Initialized
INFO - 2018-06-21 04:11:41 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 04:11:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 04:11:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-21 04:11:51 --> Config Class Initialized
INFO - 2018-06-21 04:11:51 --> Hooks Class Initialized
DEBUG - 2018-06-21 04:11:51 --> UTF-8 Support Enabled
INFO - 2018-06-21 04:11:51 --> Utf8 Class Initialized
INFO - 2018-06-21 04:11:51 --> URI Class Initialized
INFO - 2018-06-21 04:11:51 --> Router Class Initialized
INFO - 2018-06-21 04:11:51 --> Output Class Initialized
INFO - 2018-06-21 04:11:51 --> Security Class Initialized
DEBUG - 2018-06-21 04:11:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 04:11:51 --> Input Class Initialized
INFO - 2018-06-21 04:11:51 --> Language Class Initialized
INFO - 2018-06-21 04:11:51 --> Language Class Initialized
INFO - 2018-06-21 04:11:51 --> Config Class Initialized
INFO - 2018-06-21 04:11:51 --> Loader Class Initialized
DEBUG - 2018-06-21 04:11:51 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 04:11:51 --> Helper loaded: url_helper
INFO - 2018-06-21 04:11:51 --> Helper loaded: form_helper
INFO - 2018-06-21 04:11:51 --> Helper loaded: date_helper
INFO - 2018-06-21 04:11:52 --> Helper loaded: util_helper
INFO - 2018-06-21 04:11:52 --> Helper loaded: text_helper
INFO - 2018-06-21 04:11:52 --> Helper loaded: string_helper
INFO - 2018-06-21 04:11:52 --> Database Driver Class Initialized
DEBUG - 2018-06-21 04:11:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 04:11:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 04:11:52 --> Email Class Initialized
INFO - 2018-06-21 04:11:52 --> Controller Class Initialized
DEBUG - 2018-06-21 04:11:52 --> Admin MX_Controller Initialized
INFO - 2018-06-21 04:11:52 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 04:11:52 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 04:11:52 --> Login MX_Controller Initialized
DEBUG - 2018-06-21 04:11:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 04:11:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-21 04:11:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
INFO - 2018-06-21 04:11:52 --> Config Class Initialized
INFO - 2018-06-21 04:11:52 --> Hooks Class Initialized
DEBUG - 2018-06-21 04:11:52 --> UTF-8 Support Enabled
INFO - 2018-06-21 04:11:52 --> Utf8 Class Initialized
INFO - 2018-06-21 04:11:52 --> URI Class Initialized
INFO - 2018-06-21 04:11:52 --> Router Class Initialized
INFO - 2018-06-21 04:11:52 --> Output Class Initialized
INFO - 2018-06-21 04:11:52 --> Security Class Initialized
DEBUG - 2018-06-21 04:11:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 04:11:52 --> Input Class Initialized
INFO - 2018-06-21 04:11:52 --> Language Class Initialized
ERROR - 2018-06-21 04:11:52 --> 404 Page Not Found: /index
INFO - 2018-06-21 04:11:53 --> Config Class Initialized
INFO - 2018-06-21 04:11:53 --> Hooks Class Initialized
DEBUG - 2018-06-21 04:11:53 --> UTF-8 Support Enabled
INFO - 2018-06-21 04:11:53 --> Utf8 Class Initialized
INFO - 2018-06-21 04:11:53 --> URI Class Initialized
DEBUG - 2018-06-21 04:11:53 --> No URI present. Default controller set.
INFO - 2018-06-21 04:11:53 --> Router Class Initialized
INFO - 2018-06-21 04:11:53 --> Output Class Initialized
INFO - 2018-06-21 04:11:53 --> Security Class Initialized
DEBUG - 2018-06-21 04:11:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 04:11:53 --> Input Class Initialized
INFO - 2018-06-21 04:11:53 --> Language Class Initialized
INFO - 2018-06-21 04:11:53 --> Language Class Initialized
INFO - 2018-06-21 04:11:53 --> Config Class Initialized
INFO - 2018-06-21 04:11:53 --> Loader Class Initialized
DEBUG - 2018-06-21 04:11:53 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 04:11:53 --> Helper loaded: url_helper
INFO - 2018-06-21 04:11:53 --> Helper loaded: form_helper
INFO - 2018-06-21 04:11:53 --> Helper loaded: date_helper
INFO - 2018-06-21 04:11:53 --> Helper loaded: util_helper
INFO - 2018-06-21 04:11:54 --> Helper loaded: text_helper
INFO - 2018-06-21 04:11:54 --> Helper loaded: string_helper
INFO - 2018-06-21 04:11:54 --> Database Driver Class Initialized
DEBUG - 2018-06-21 04:11:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 04:11:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 04:11:54 --> Email Class Initialized
INFO - 2018-06-21 04:11:54 --> Controller Class Initialized
DEBUG - 2018-06-21 04:11:54 --> Home MX_Controller Initialized
DEBUG - 2018-06-21 04:11:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-21 04:11:54 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 04:11:54 --> Login MX_Controller Initialized
INFO - 2018-06-21 04:11:54 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 04:11:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 04:11:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-21 04:11:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-06-21 04:11:54 --> Config Class Initialized
INFO - 2018-06-21 04:11:54 --> Hooks Class Initialized
DEBUG - 2018-06-21 04:11:54 --> UTF-8 Support Enabled
INFO - 2018-06-21 04:11:54 --> Utf8 Class Initialized
INFO - 2018-06-21 04:11:54 --> URI Class Initialized
DEBUG - 2018-06-21 04:11:54 --> No URI present. Default controller set.
INFO - 2018-06-21 04:11:54 --> Router Class Initialized
INFO - 2018-06-21 04:11:54 --> Output Class Initialized
INFO - 2018-06-21 04:11:54 --> Security Class Initialized
DEBUG - 2018-06-21 04:11:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 04:11:54 --> Input Class Initialized
INFO - 2018-06-21 04:11:54 --> Language Class Initialized
INFO - 2018-06-21 04:11:54 --> Language Class Initialized
INFO - 2018-06-21 04:11:54 --> Config Class Initialized
INFO - 2018-06-21 04:11:54 --> Loader Class Initialized
DEBUG - 2018-06-21 04:11:54 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 04:11:54 --> Helper loaded: url_helper
INFO - 2018-06-21 04:11:54 --> Helper loaded: form_helper
INFO - 2018-06-21 04:11:54 --> Helper loaded: date_helper
INFO - 2018-06-21 04:11:54 --> Helper loaded: util_helper
INFO - 2018-06-21 04:11:54 --> Helper loaded: text_helper
INFO - 2018-06-21 04:11:54 --> Helper loaded: string_helper
INFO - 2018-06-21 04:11:54 --> Database Driver Class Initialized
DEBUG - 2018-06-21 04:11:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 04:11:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 04:11:54 --> Email Class Initialized
INFO - 2018-06-21 04:11:54 --> Controller Class Initialized
DEBUG - 2018-06-21 04:11:54 --> Home MX_Controller Initialized
DEBUG - 2018-06-21 04:11:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-21 04:11:54 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 04:11:55 --> Login MX_Controller Initialized
INFO - 2018-06-21 04:11:55 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 04:11:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 04:11:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-21 04:11:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-06-21 04:11:57 --> Config Class Initialized
INFO - 2018-06-21 04:11:57 --> Hooks Class Initialized
DEBUG - 2018-06-21 04:11:57 --> UTF-8 Support Enabled
INFO - 2018-06-21 04:11:57 --> Utf8 Class Initialized
INFO - 2018-06-21 04:11:57 --> URI Class Initialized
INFO - 2018-06-21 04:11:57 --> Router Class Initialized
INFO - 2018-06-21 04:11:57 --> Output Class Initialized
INFO - 2018-06-21 04:11:57 --> Security Class Initialized
DEBUG - 2018-06-21 04:11:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 04:11:57 --> Input Class Initialized
INFO - 2018-06-21 04:11:57 --> Language Class Initialized
INFO - 2018-06-21 04:11:57 --> Language Class Initialized
INFO - 2018-06-21 04:11:57 --> Config Class Initialized
INFO - 2018-06-21 04:11:57 --> Loader Class Initialized
DEBUG - 2018-06-21 04:11:57 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 04:11:57 --> Helper loaded: url_helper
INFO - 2018-06-21 04:11:57 --> Helper loaded: form_helper
INFO - 2018-06-21 04:11:57 --> Helper loaded: date_helper
INFO - 2018-06-21 04:11:57 --> Helper loaded: util_helper
INFO - 2018-06-21 04:11:57 --> Helper loaded: text_helper
INFO - 2018-06-21 04:11:57 --> Helper loaded: string_helper
INFO - 2018-06-21 04:11:57 --> Database Driver Class Initialized
DEBUG - 2018-06-21 04:11:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 04:11:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 04:11:57 --> Email Class Initialized
INFO - 2018-06-21 04:11:57 --> Controller Class Initialized
DEBUG - 2018-06-21 04:11:57 --> Login MX_Controller Initialized
INFO - 2018-06-21 04:11:57 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 04:11:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 04:11:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-21 04:12:00 --> Config Class Initialized
INFO - 2018-06-21 04:12:00 --> Hooks Class Initialized
DEBUG - 2018-06-21 04:12:00 --> UTF-8 Support Enabled
INFO - 2018-06-21 04:12:00 --> Utf8 Class Initialized
INFO - 2018-06-21 04:12:00 --> URI Class Initialized
INFO - 2018-06-21 04:12:00 --> Router Class Initialized
INFO - 2018-06-21 04:12:00 --> Output Class Initialized
INFO - 2018-06-21 04:12:00 --> Security Class Initialized
DEBUG - 2018-06-21 04:12:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 04:12:00 --> Input Class Initialized
INFO - 2018-06-21 04:12:00 --> Language Class Initialized
INFO - 2018-06-21 04:12:00 --> Language Class Initialized
INFO - 2018-06-21 04:12:00 --> Config Class Initialized
INFO - 2018-06-21 04:12:00 --> Loader Class Initialized
DEBUG - 2018-06-21 04:12:00 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 04:12:00 --> Helper loaded: url_helper
INFO - 2018-06-21 04:12:00 --> Helper loaded: form_helper
INFO - 2018-06-21 04:12:00 --> Helper loaded: date_helper
INFO - 2018-06-21 04:12:00 --> Helper loaded: util_helper
INFO - 2018-06-21 04:12:00 --> Helper loaded: text_helper
INFO - 2018-06-21 04:12:00 --> Helper loaded: string_helper
INFO - 2018-06-21 04:12:00 --> Database Driver Class Initialized
DEBUG - 2018-06-21 04:12:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 04:12:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 04:12:00 --> Email Class Initialized
INFO - 2018-06-21 04:12:00 --> Controller Class Initialized
DEBUG - 2018-06-21 04:12:00 --> Login MX_Controller Initialized
INFO - 2018-06-21 04:12:00 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 04:12:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 04:12:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-21 04:12:35 --> Config Class Initialized
INFO - 2018-06-21 04:12:35 --> Hooks Class Initialized
DEBUG - 2018-06-21 04:12:35 --> UTF-8 Support Enabled
INFO - 2018-06-21 04:12:35 --> Utf8 Class Initialized
INFO - 2018-06-21 04:12:35 --> URI Class Initialized
DEBUG - 2018-06-21 04:12:35 --> No URI present. Default controller set.
INFO - 2018-06-21 04:12:35 --> Router Class Initialized
INFO - 2018-06-21 04:12:35 --> Output Class Initialized
INFO - 2018-06-21 04:12:35 --> Security Class Initialized
DEBUG - 2018-06-21 04:12:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 04:12:35 --> Input Class Initialized
INFO - 2018-06-21 04:12:35 --> Language Class Initialized
INFO - 2018-06-21 04:12:35 --> Language Class Initialized
INFO - 2018-06-21 04:12:35 --> Config Class Initialized
INFO - 2018-06-21 04:12:35 --> Loader Class Initialized
DEBUG - 2018-06-21 04:12:35 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 04:12:35 --> Helper loaded: url_helper
INFO - 2018-06-21 04:12:35 --> Helper loaded: form_helper
INFO - 2018-06-21 04:12:35 --> Helper loaded: date_helper
INFO - 2018-06-21 04:12:35 --> Helper loaded: util_helper
INFO - 2018-06-21 04:12:35 --> Helper loaded: text_helper
INFO - 2018-06-21 04:12:35 --> Helper loaded: string_helper
INFO - 2018-06-21 04:12:35 --> Database Driver Class Initialized
DEBUG - 2018-06-21 04:12:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 04:12:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 04:12:35 --> Email Class Initialized
INFO - 2018-06-21 04:12:35 --> Controller Class Initialized
DEBUG - 2018-06-21 04:12:35 --> Home MX_Controller Initialized
DEBUG - 2018-06-21 04:12:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-21 04:12:35 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 04:12:35 --> Login MX_Controller Initialized
INFO - 2018-06-21 04:12:35 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 04:12:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 04:12:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-21 04:12:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-06-21 04:12:44 --> Config Class Initialized
INFO - 2018-06-21 04:12:44 --> Hooks Class Initialized
DEBUG - 2018-06-21 04:12:44 --> UTF-8 Support Enabled
INFO - 2018-06-21 04:12:44 --> Utf8 Class Initialized
INFO - 2018-06-21 04:12:44 --> URI Class Initialized
INFO - 2018-06-21 04:12:44 --> Router Class Initialized
INFO - 2018-06-21 04:12:44 --> Output Class Initialized
INFO - 2018-06-21 04:12:44 --> Security Class Initialized
DEBUG - 2018-06-21 04:12:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 04:12:44 --> Input Class Initialized
INFO - 2018-06-21 04:12:44 --> Language Class Initialized
INFO - 2018-06-21 04:12:44 --> Language Class Initialized
INFO - 2018-06-21 04:12:44 --> Config Class Initialized
INFO - 2018-06-21 04:12:44 --> Loader Class Initialized
DEBUG - 2018-06-21 04:12:44 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 04:12:44 --> Helper loaded: url_helper
INFO - 2018-06-21 04:12:44 --> Helper loaded: form_helper
INFO - 2018-06-21 04:12:44 --> Helper loaded: date_helper
INFO - 2018-06-21 04:12:44 --> Helper loaded: util_helper
INFO - 2018-06-21 04:12:44 --> Helper loaded: text_helper
INFO - 2018-06-21 04:12:44 --> Helper loaded: string_helper
INFO - 2018-06-21 04:12:44 --> Database Driver Class Initialized
DEBUG - 2018-06-21 04:12:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 04:12:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 04:12:44 --> Email Class Initialized
INFO - 2018-06-21 04:12:44 --> Controller Class Initialized
DEBUG - 2018-06-21 04:12:44 --> Login MX_Controller Initialized
INFO - 2018-06-21 04:12:44 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 04:12:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 04:12:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-21 04:16:53 --> Config Class Initialized
INFO - 2018-06-21 04:16:53 --> Hooks Class Initialized
DEBUG - 2018-06-21 04:16:53 --> UTF-8 Support Enabled
INFO - 2018-06-21 04:16:53 --> Utf8 Class Initialized
INFO - 2018-06-21 04:16:53 --> URI Class Initialized
INFO - 2018-06-21 04:16:53 --> Router Class Initialized
INFO - 2018-06-21 04:16:53 --> Output Class Initialized
INFO - 2018-06-21 04:16:53 --> Security Class Initialized
DEBUG - 2018-06-21 04:16:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 04:16:53 --> Input Class Initialized
INFO - 2018-06-21 04:16:53 --> Language Class Initialized
INFO - 2018-06-21 04:16:53 --> Language Class Initialized
INFO - 2018-06-21 04:16:53 --> Config Class Initialized
INFO - 2018-06-21 04:16:53 --> Loader Class Initialized
DEBUG - 2018-06-21 04:16:53 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 04:16:53 --> Helper loaded: url_helper
INFO - 2018-06-21 04:16:53 --> Helper loaded: form_helper
INFO - 2018-06-21 04:16:53 --> Helper loaded: date_helper
INFO - 2018-06-21 04:16:53 --> Helper loaded: util_helper
INFO - 2018-06-21 04:16:53 --> Helper loaded: text_helper
INFO - 2018-06-21 04:16:53 --> Helper loaded: string_helper
INFO - 2018-06-21 04:16:53 --> Database Driver Class Initialized
DEBUG - 2018-06-21 04:16:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 04:16:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 04:16:53 --> Email Class Initialized
INFO - 2018-06-21 04:16:53 --> Controller Class Initialized
DEBUG - 2018-06-21 04:16:53 --> Admin MX_Controller Initialized
INFO - 2018-06-21 04:16:53 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 04:16:53 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 04:16:53 --> Login MX_Controller Initialized
DEBUG - 2018-06-21 04:16:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 04:16:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-21 04:16:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
INFO - 2018-06-21 04:16:54 --> Config Class Initialized
INFO - 2018-06-21 04:16:54 --> Hooks Class Initialized
DEBUG - 2018-06-21 04:16:54 --> UTF-8 Support Enabled
INFO - 2018-06-21 04:16:54 --> Utf8 Class Initialized
INFO - 2018-06-21 04:16:54 --> URI Class Initialized
INFO - 2018-06-21 04:16:54 --> Router Class Initialized
INFO - 2018-06-21 04:16:54 --> Output Class Initialized
INFO - 2018-06-21 04:16:54 --> Security Class Initialized
DEBUG - 2018-06-21 04:16:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 04:16:54 --> Input Class Initialized
INFO - 2018-06-21 04:16:54 --> Language Class Initialized
ERROR - 2018-06-21 04:16:54 --> 404 Page Not Found: /index
INFO - 2018-06-21 04:16:59 --> Config Class Initialized
INFO - 2018-06-21 04:16:59 --> Hooks Class Initialized
DEBUG - 2018-06-21 04:16:59 --> UTF-8 Support Enabled
INFO - 2018-06-21 04:16:59 --> Utf8 Class Initialized
INFO - 2018-06-21 04:16:59 --> URI Class Initialized
INFO - 2018-06-21 04:16:59 --> Router Class Initialized
INFO - 2018-06-21 04:16:59 --> Output Class Initialized
INFO - 2018-06-21 04:16:59 --> Security Class Initialized
DEBUG - 2018-06-21 04:16:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 04:16:59 --> Input Class Initialized
INFO - 2018-06-21 04:16:59 --> Language Class Initialized
INFO - 2018-06-21 04:16:59 --> Language Class Initialized
INFO - 2018-06-21 04:16:59 --> Config Class Initialized
INFO - 2018-06-21 04:16:59 --> Loader Class Initialized
DEBUG - 2018-06-21 04:16:59 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 04:16:59 --> Helper loaded: url_helper
INFO - 2018-06-21 04:16:59 --> Helper loaded: form_helper
INFO - 2018-06-21 04:16:59 --> Helper loaded: date_helper
INFO - 2018-06-21 04:16:59 --> Helper loaded: util_helper
INFO - 2018-06-21 04:16:59 --> Helper loaded: text_helper
INFO - 2018-06-21 04:16:59 --> Helper loaded: string_helper
INFO - 2018-06-21 04:17:00 --> Database Driver Class Initialized
DEBUG - 2018-06-21 04:17:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 04:17:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 04:17:00 --> Email Class Initialized
INFO - 2018-06-21 04:17:00 --> Controller Class Initialized
DEBUG - 2018-06-21 04:17:00 --> Login MX_Controller Initialized
INFO - 2018-06-21 04:17:00 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 04:17:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 04:17:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-21 04:17:00 --> Email starts for gopipanguluri123@gmail.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-06-21 04:17:32 --> Config Class Initialized
INFO - 2018-06-21 04:17:32 --> Hooks Class Initialized
DEBUG - 2018-06-21 04:17:32 --> UTF-8 Support Enabled
INFO - 2018-06-21 04:17:32 --> Utf8 Class Initialized
INFO - 2018-06-21 04:17:32 --> URI Class Initialized
INFO - 2018-06-21 04:17:32 --> Router Class Initialized
INFO - 2018-06-21 04:17:32 --> Output Class Initialized
INFO - 2018-06-21 04:17:32 --> Security Class Initialized
DEBUG - 2018-06-21 04:17:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 04:17:32 --> Input Class Initialized
INFO - 2018-06-21 04:17:32 --> Language Class Initialized
INFO - 2018-06-21 04:17:32 --> Language Class Initialized
INFO - 2018-06-21 04:17:32 --> Config Class Initialized
INFO - 2018-06-21 04:17:32 --> Loader Class Initialized
DEBUG - 2018-06-21 04:17:32 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 04:17:32 --> Helper loaded: url_helper
INFO - 2018-06-21 04:17:32 --> Helper loaded: form_helper
INFO - 2018-06-21 04:17:32 --> Helper loaded: date_helper
INFO - 2018-06-21 04:17:32 --> Helper loaded: util_helper
INFO - 2018-06-21 04:17:32 --> Helper loaded: text_helper
INFO - 2018-06-21 04:17:32 --> Helper loaded: string_helper
INFO - 2018-06-21 04:17:32 --> Database Driver Class Initialized
DEBUG - 2018-06-21 04:17:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 04:17:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 04:17:32 --> Email Class Initialized
INFO - 2018-06-21 04:17:32 --> Controller Class Initialized
DEBUG - 2018-06-21 04:17:32 --> Users MX_Controller Initialized
DEBUG - 2018-06-21 04:17:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 04:17:32 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 04:17:33 --> Login MX_Controller Initialized
INFO - 2018-06-21 04:17:33 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 04:17:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-21 04:17:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-06-21 04:17:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-21 04:17:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-21 04:17:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-21 04:17:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-21 04:17:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-21 04:17:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-06-21 04:17:33 --> Final output sent to browser
DEBUG - 2018-06-21 04:17:33 --> Total execution time: 0.6231
INFO - 2018-06-21 04:17:34 --> Config Class Initialized
INFO - 2018-06-21 04:17:34 --> Hooks Class Initialized
DEBUG - 2018-06-21 04:17:34 --> UTF-8 Support Enabled
INFO - 2018-06-21 04:17:34 --> Utf8 Class Initialized
INFO - 2018-06-21 04:17:34 --> URI Class Initialized
INFO - 2018-06-21 04:17:34 --> Router Class Initialized
INFO - 2018-06-21 04:17:34 --> Output Class Initialized
INFO - 2018-06-21 04:17:34 --> Security Class Initialized
DEBUG - 2018-06-21 04:17:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 04:17:35 --> Input Class Initialized
INFO - 2018-06-21 04:17:35 --> Language Class Initialized
INFO - 2018-06-21 04:17:35 --> Language Class Initialized
INFO - 2018-06-21 04:17:35 --> Config Class Initialized
INFO - 2018-06-21 04:17:35 --> Loader Class Initialized
DEBUG - 2018-06-21 04:17:35 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 04:17:35 --> Helper loaded: url_helper
INFO - 2018-06-21 04:17:35 --> Helper loaded: form_helper
INFO - 2018-06-21 04:17:35 --> Helper loaded: date_helper
INFO - 2018-06-21 04:17:35 --> Helper loaded: util_helper
INFO - 2018-06-21 04:17:35 --> Helper loaded: text_helper
INFO - 2018-06-21 04:17:35 --> Helper loaded: string_helper
INFO - 2018-06-21 04:17:35 --> Database Driver Class Initialized
DEBUG - 2018-06-21 04:17:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 04:17:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 04:17:35 --> Email Class Initialized
INFO - 2018-06-21 04:17:35 --> Controller Class Initialized
DEBUG - 2018-06-21 04:17:35 --> Users MX_Controller Initialized
DEBUG - 2018-06-21 04:17:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 04:17:35 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 04:17:35 --> Login MX_Controller Initialized
INFO - 2018-06-21 04:17:35 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 04:17:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-21 04:17:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-21 04:17:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-21 04:17:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-21 04:17:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-21 04:17:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-21 04:17:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-06-21 04:17:35 --> Final output sent to browser
DEBUG - 2018-06-21 04:17:35 --> Total execution time: 0.6035
INFO - 2018-06-21 04:17:36 --> Config Class Initialized
INFO - 2018-06-21 04:17:36 --> Hooks Class Initialized
DEBUG - 2018-06-21 04:17:36 --> UTF-8 Support Enabled
INFO - 2018-06-21 04:17:36 --> Utf8 Class Initialized
INFO - 2018-06-21 04:17:36 --> URI Class Initialized
INFO - 2018-06-21 04:17:36 --> Router Class Initialized
INFO - 2018-06-21 04:17:36 --> Output Class Initialized
INFO - 2018-06-21 04:17:36 --> Security Class Initialized
DEBUG - 2018-06-21 04:17:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 04:17:36 --> Input Class Initialized
INFO - 2018-06-21 04:17:36 --> Language Class Initialized
INFO - 2018-06-21 04:17:36 --> Language Class Initialized
INFO - 2018-06-21 04:17:36 --> Config Class Initialized
INFO - 2018-06-21 04:17:36 --> Loader Class Initialized
DEBUG - 2018-06-21 04:17:36 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 04:17:36 --> Helper loaded: url_helper
INFO - 2018-06-21 04:17:36 --> Helper loaded: form_helper
INFO - 2018-06-21 04:17:36 --> Helper loaded: date_helper
INFO - 2018-06-21 04:17:36 --> Helper loaded: util_helper
INFO - 2018-06-21 04:17:36 --> Helper loaded: text_helper
INFO - 2018-06-21 04:17:36 --> Helper loaded: string_helper
INFO - 2018-06-21 04:17:36 --> Database Driver Class Initialized
DEBUG - 2018-06-21 04:17:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 04:17:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 04:17:36 --> Email Class Initialized
INFO - 2018-06-21 04:17:36 --> Controller Class Initialized
DEBUG - 2018-06-21 04:17:36 --> Users MX_Controller Initialized
DEBUG - 2018-06-21 04:17:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 04:17:36 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 04:17:36 --> Login MX_Controller Initialized
INFO - 2018-06-21 04:17:36 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 04:17:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-21 04:17:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-06-21 04:17:36 --> Final output sent to browser
DEBUG - 2018-06-21 04:17:36 --> Total execution time: 0.7590
INFO - 2018-06-21 04:18:08 --> Config Class Initialized
INFO - 2018-06-21 04:18:08 --> Hooks Class Initialized
DEBUG - 2018-06-21 04:18:08 --> UTF-8 Support Enabled
INFO - 2018-06-21 04:18:08 --> Utf8 Class Initialized
INFO - 2018-06-21 04:18:08 --> URI Class Initialized
INFO - 2018-06-21 04:18:08 --> Router Class Initialized
INFO - 2018-06-21 04:18:08 --> Output Class Initialized
INFO - 2018-06-21 04:18:08 --> Security Class Initialized
DEBUG - 2018-06-21 04:18:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 04:18:08 --> Input Class Initialized
INFO - 2018-06-21 04:18:08 --> Language Class Initialized
INFO - 2018-06-21 04:18:08 --> Language Class Initialized
INFO - 2018-06-21 04:18:08 --> Config Class Initialized
INFO - 2018-06-21 04:18:09 --> Loader Class Initialized
DEBUG - 2018-06-21 04:18:09 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 04:18:09 --> Helper loaded: url_helper
INFO - 2018-06-21 04:18:09 --> Helper loaded: form_helper
INFO - 2018-06-21 04:18:09 --> Helper loaded: date_helper
INFO - 2018-06-21 04:18:09 --> Helper loaded: util_helper
INFO - 2018-06-21 04:18:09 --> Helper loaded: text_helper
INFO - 2018-06-21 04:18:09 --> Helper loaded: string_helper
INFO - 2018-06-21 04:18:09 --> Database Driver Class Initialized
DEBUG - 2018-06-21 04:18:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 04:18:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 04:18:09 --> Email Class Initialized
INFO - 2018-06-21 04:18:09 --> Controller Class Initialized
DEBUG - 2018-06-21 04:18:09 --> Login MX_Controller Initialized
INFO - 2018-06-21 04:18:09 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 04:18:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 04:18:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-21 04:18:09 --> Email starts for gopipanguluri123@gmail.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-06-21 04:18:09 --> Login status gopipanguluri123@gmail.com - failure
INFO - 2018-06-21 04:18:09 --> Final output sent to browser
DEBUG - 2018-06-21 04:18:09 --> Total execution time: 0.7855
INFO - 2018-06-21 05:49:06 --> Config Class Initialized
INFO - 2018-06-21 05:49:06 --> Hooks Class Initialized
DEBUG - 2018-06-21 05:49:06 --> UTF-8 Support Enabled
INFO - 2018-06-21 05:49:06 --> Utf8 Class Initialized
INFO - 2018-06-21 05:49:06 --> URI Class Initialized
DEBUG - 2018-06-21 05:49:06 --> No URI present. Default controller set.
INFO - 2018-06-21 05:49:06 --> Router Class Initialized
INFO - 2018-06-21 05:49:06 --> Output Class Initialized
INFO - 2018-06-21 05:49:06 --> Security Class Initialized
DEBUG - 2018-06-21 05:49:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 05:49:06 --> Input Class Initialized
INFO - 2018-06-21 05:49:06 --> Language Class Initialized
INFO - 2018-06-21 05:49:06 --> Language Class Initialized
INFO - 2018-06-21 05:49:06 --> Config Class Initialized
INFO - 2018-06-21 05:49:06 --> Loader Class Initialized
DEBUG - 2018-06-21 05:49:06 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 05:49:07 --> Helper loaded: url_helper
INFO - 2018-06-21 05:49:07 --> Helper loaded: form_helper
INFO - 2018-06-21 05:49:07 --> Helper loaded: date_helper
INFO - 2018-06-21 05:49:07 --> Helper loaded: util_helper
INFO - 2018-06-21 05:49:07 --> Helper loaded: text_helper
INFO - 2018-06-21 05:49:07 --> Helper loaded: string_helper
INFO - 2018-06-21 05:49:07 --> Database Driver Class Initialized
DEBUG - 2018-06-21 05:49:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 05:49:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 05:49:07 --> Email Class Initialized
INFO - 2018-06-21 05:49:07 --> Controller Class Initialized
DEBUG - 2018-06-21 05:49:07 --> Home MX_Controller Initialized
DEBUG - 2018-06-21 05:49:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-21 05:49:07 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 05:49:07 --> Login MX_Controller Initialized
INFO - 2018-06-21 05:49:07 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 05:49:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 05:49:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-21 05:49:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-06-21 21:06:20 --> Config Class Initialized
INFO - 2018-06-21 21:06:20 --> Hooks Class Initialized
DEBUG - 2018-06-21 21:06:20 --> UTF-8 Support Enabled
INFO - 2018-06-21 21:06:20 --> Utf8 Class Initialized
INFO - 2018-06-21 21:06:20 --> URI Class Initialized
INFO - 2018-06-21 21:06:21 --> Router Class Initialized
INFO - 2018-06-21 21:06:21 --> Output Class Initialized
INFO - 2018-06-21 21:06:21 --> Security Class Initialized
DEBUG - 2018-06-21 21:06:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 21:06:21 --> Input Class Initialized
INFO - 2018-06-21 21:06:21 --> Language Class Initialized
INFO - 2018-06-21 21:06:21 --> Language Class Initialized
INFO - 2018-06-21 21:06:21 --> Config Class Initialized
INFO - 2018-06-21 21:06:23 --> Loader Class Initialized
DEBUG - 2018-06-21 21:06:23 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 21:06:24 --> Helper loaded: url_helper
INFO - 2018-06-21 21:06:25 --> Helper loaded: form_helper
INFO - 2018-06-21 21:06:25 --> Helper loaded: date_helper
INFO - 2018-06-21 21:06:25 --> Helper loaded: util_helper
INFO - 2018-06-21 21:06:25 --> Helper loaded: text_helper
INFO - 2018-06-21 21:06:25 --> Helper loaded: string_helper
INFO - 2018-06-21 21:06:25 --> Database Driver Class Initialized
DEBUG - 2018-06-21 21:06:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 21:06:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 21:06:27 --> Email Class Initialized
INFO - 2018-06-21 21:06:27 --> Controller Class Initialized
DEBUG - 2018-06-21 21:06:27 --> Users MX_Controller Initialized
DEBUG - 2018-06-21 21:06:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 21:06:27 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 21:06:27 --> Login MX_Controller Initialized
INFO - 2018-06-21 21:06:27 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 21:06:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-21 21:06:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
INFO - 2018-06-21 21:06:28 --> Config Class Initialized
INFO - 2018-06-21 21:06:28 --> Hooks Class Initialized
DEBUG - 2018-06-21 21:06:28 --> UTF-8 Support Enabled
INFO - 2018-06-21 21:06:28 --> Utf8 Class Initialized
INFO - 2018-06-21 21:06:28 --> URI Class Initialized
INFO - 2018-06-21 21:06:28 --> Router Class Initialized
INFO - 2018-06-21 21:06:28 --> Output Class Initialized
INFO - 2018-06-21 21:06:28 --> Security Class Initialized
DEBUG - 2018-06-21 21:06:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 21:06:28 --> Input Class Initialized
INFO - 2018-06-21 21:06:28 --> Language Class Initialized
ERROR - 2018-06-21 21:06:28 --> 404 Page Not Found: /index
INFO - 2018-06-21 21:06:29 --> Config Class Initialized
INFO - 2018-06-21 21:06:29 --> Hooks Class Initialized
DEBUG - 2018-06-21 21:06:29 --> UTF-8 Support Enabled
INFO - 2018-06-21 21:06:29 --> Utf8 Class Initialized
INFO - 2018-06-21 21:06:29 --> URI Class Initialized
INFO - 2018-06-21 21:06:29 --> Router Class Initialized
INFO - 2018-06-21 21:06:29 --> Output Class Initialized
INFO - 2018-06-21 21:06:29 --> Security Class Initialized
DEBUG - 2018-06-21 21:06:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 21:06:29 --> Input Class Initialized
INFO - 2018-06-21 21:06:29 --> Language Class Initialized
ERROR - 2018-06-21 21:06:29 --> 404 Page Not Found: /index
INFO - 2018-06-21 21:07:55 --> Config Class Initialized
INFO - 2018-06-21 21:07:55 --> Hooks Class Initialized
DEBUG - 2018-06-21 21:07:55 --> UTF-8 Support Enabled
INFO - 2018-06-21 21:07:55 --> Utf8 Class Initialized
INFO - 2018-06-21 21:07:55 --> URI Class Initialized
INFO - 2018-06-21 21:07:56 --> Router Class Initialized
INFO - 2018-06-21 21:07:56 --> Output Class Initialized
INFO - 2018-06-21 21:07:56 --> Security Class Initialized
DEBUG - 2018-06-21 21:07:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 21:07:56 --> Input Class Initialized
INFO - 2018-06-21 21:07:56 --> Language Class Initialized
INFO - 2018-06-21 21:07:56 --> Language Class Initialized
INFO - 2018-06-21 21:07:56 --> Config Class Initialized
INFO - 2018-06-21 21:07:56 --> Loader Class Initialized
DEBUG - 2018-06-21 21:07:56 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 21:07:56 --> Helper loaded: url_helper
INFO - 2018-06-21 21:07:56 --> Helper loaded: form_helper
INFO - 2018-06-21 21:07:56 --> Helper loaded: date_helper
INFO - 2018-06-21 21:07:56 --> Helper loaded: util_helper
INFO - 2018-06-21 21:07:56 --> Helper loaded: text_helper
INFO - 2018-06-21 21:07:56 --> Helper loaded: string_helper
INFO - 2018-06-21 21:07:56 --> Database Driver Class Initialized
DEBUG - 2018-06-21 21:07:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 21:07:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 21:07:56 --> Email Class Initialized
INFO - 2018-06-21 21:07:56 --> Controller Class Initialized
DEBUG - 2018-06-21 21:07:56 --> Home MX_Controller Initialized
DEBUG - 2018-06-21 21:07:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-21 21:07:57 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 21:07:57 --> Login MX_Controller Initialized
INFO - 2018-06-21 21:07:57 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 21:07:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 21:07:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-21 21:07:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-06-21 21:08:09 --> Config Class Initialized
INFO - 2018-06-21 21:08:09 --> Hooks Class Initialized
DEBUG - 2018-06-21 21:08:09 --> UTF-8 Support Enabled
INFO - 2018-06-21 21:08:09 --> Utf8 Class Initialized
INFO - 2018-06-21 21:08:09 --> URI Class Initialized
INFO - 2018-06-21 21:08:09 --> Router Class Initialized
INFO - 2018-06-21 21:08:09 --> Output Class Initialized
INFO - 2018-06-21 21:08:09 --> Security Class Initialized
DEBUG - 2018-06-21 21:08:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 21:08:09 --> Input Class Initialized
INFO - 2018-06-21 21:08:09 --> Language Class Initialized
INFO - 2018-06-21 21:08:09 --> Language Class Initialized
INFO - 2018-06-21 21:08:09 --> Config Class Initialized
INFO - 2018-06-21 21:08:09 --> Loader Class Initialized
DEBUG - 2018-06-21 21:08:09 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 21:08:09 --> Helper loaded: url_helper
INFO - 2018-06-21 21:08:09 --> Helper loaded: form_helper
INFO - 2018-06-21 21:08:09 --> Helper loaded: date_helper
INFO - 2018-06-21 21:08:09 --> Helper loaded: util_helper
INFO - 2018-06-21 21:08:09 --> Helper loaded: text_helper
INFO - 2018-06-21 21:08:09 --> Helper loaded: string_helper
INFO - 2018-06-21 21:08:09 --> Database Driver Class Initialized
DEBUG - 2018-06-21 21:08:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 21:08:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 21:08:09 --> Email Class Initialized
INFO - 2018-06-21 21:08:09 --> Controller Class Initialized
DEBUG - 2018-06-21 21:08:09 --> Login MX_Controller Initialized
INFO - 2018-06-21 21:08:09 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 21:08:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 21:08:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-21 21:08:09 --> Email starts for user@colin.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-06-21 21:08:09 --> Login status user@colin.com - failure
INFO - 2018-06-21 21:08:09 --> Final output sent to browser
DEBUG - 2018-06-21 21:08:09 --> Total execution time: 0.5307
INFO - 2018-06-21 21:08:13 --> Config Class Initialized
INFO - 2018-06-21 21:08:13 --> Hooks Class Initialized
DEBUG - 2018-06-21 21:08:13 --> UTF-8 Support Enabled
INFO - 2018-06-21 21:08:13 --> Utf8 Class Initialized
INFO - 2018-06-21 21:08:13 --> URI Class Initialized
INFO - 2018-06-21 21:08:13 --> Router Class Initialized
INFO - 2018-06-21 21:08:13 --> Output Class Initialized
INFO - 2018-06-21 21:08:13 --> Security Class Initialized
DEBUG - 2018-06-21 21:08:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 21:08:13 --> Input Class Initialized
INFO - 2018-06-21 21:08:13 --> Language Class Initialized
INFO - 2018-06-21 21:08:13 --> Language Class Initialized
INFO - 2018-06-21 21:08:13 --> Config Class Initialized
INFO - 2018-06-21 21:08:13 --> Loader Class Initialized
DEBUG - 2018-06-21 21:08:13 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 21:08:13 --> Helper loaded: url_helper
INFO - 2018-06-21 21:08:13 --> Helper loaded: form_helper
INFO - 2018-06-21 21:08:13 --> Helper loaded: date_helper
INFO - 2018-06-21 21:08:13 --> Helper loaded: util_helper
INFO - 2018-06-21 21:08:13 --> Helper loaded: text_helper
INFO - 2018-06-21 21:08:13 --> Helper loaded: string_helper
INFO - 2018-06-21 21:08:13 --> Database Driver Class Initialized
DEBUG - 2018-06-21 21:08:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 21:08:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 21:08:13 --> Email Class Initialized
INFO - 2018-06-21 21:08:13 --> Controller Class Initialized
DEBUG - 2018-06-21 21:08:13 --> Login MX_Controller Initialized
INFO - 2018-06-21 21:08:13 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 21:08:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 21:08:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-21 21:08:13 --> Email starts for user@colin.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-06-21 21:08:13 --> Login status user@colin.com - failure
INFO - 2018-06-21 21:08:13 --> Final output sent to browser
DEBUG - 2018-06-21 21:08:13 --> Total execution time: 0.4553
INFO - 2018-06-21 21:08:24 --> Config Class Initialized
INFO - 2018-06-21 21:08:24 --> Hooks Class Initialized
DEBUG - 2018-06-21 21:08:24 --> UTF-8 Support Enabled
INFO - 2018-06-21 21:08:24 --> Utf8 Class Initialized
INFO - 2018-06-21 21:08:24 --> URI Class Initialized
INFO - 2018-06-21 21:08:24 --> Router Class Initialized
INFO - 2018-06-21 21:08:24 --> Output Class Initialized
INFO - 2018-06-21 21:08:24 --> Security Class Initialized
DEBUG - 2018-06-21 21:08:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 21:08:24 --> Input Class Initialized
INFO - 2018-06-21 21:08:24 --> Language Class Initialized
INFO - 2018-06-21 21:08:24 --> Language Class Initialized
INFO - 2018-06-21 21:08:24 --> Config Class Initialized
INFO - 2018-06-21 21:08:24 --> Loader Class Initialized
DEBUG - 2018-06-21 21:08:24 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 21:08:24 --> Helper loaded: url_helper
INFO - 2018-06-21 21:08:24 --> Helper loaded: form_helper
INFO - 2018-06-21 21:08:24 --> Helper loaded: date_helper
INFO - 2018-06-21 21:08:24 --> Helper loaded: util_helper
INFO - 2018-06-21 21:08:24 --> Helper loaded: text_helper
INFO - 2018-06-21 21:08:24 --> Helper loaded: string_helper
INFO - 2018-06-21 21:08:24 --> Database Driver Class Initialized
DEBUG - 2018-06-21 21:08:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 21:08:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 21:08:25 --> Email Class Initialized
INFO - 2018-06-21 21:08:25 --> Controller Class Initialized
DEBUG - 2018-06-21 21:08:25 --> Login MX_Controller Initialized
INFO - 2018-06-21 21:08:25 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 21:08:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 21:08:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-21 21:08:25 --> Email starts for user@colin.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-06-21 21:08:25 --> Login status user@colin.com - failure
INFO - 2018-06-21 21:08:25 --> Final output sent to browser
DEBUG - 2018-06-21 21:08:25 --> Total execution time: 1.2217
INFO - 2018-06-21 21:11:00 --> Config Class Initialized
INFO - 2018-06-21 21:11:00 --> Hooks Class Initialized
DEBUG - 2018-06-21 21:11:00 --> UTF-8 Support Enabled
INFO - 2018-06-21 21:11:00 --> Utf8 Class Initialized
INFO - 2018-06-21 21:11:00 --> URI Class Initialized
INFO - 2018-06-21 21:11:00 --> Router Class Initialized
INFO - 2018-06-21 21:11:00 --> Output Class Initialized
INFO - 2018-06-21 21:11:00 --> Security Class Initialized
DEBUG - 2018-06-21 21:11:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 21:11:00 --> Input Class Initialized
INFO - 2018-06-21 21:11:00 --> Language Class Initialized
INFO - 2018-06-21 21:11:00 --> Language Class Initialized
INFO - 2018-06-21 21:11:00 --> Config Class Initialized
INFO - 2018-06-21 21:11:00 --> Loader Class Initialized
DEBUG - 2018-06-21 21:11:00 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 21:11:00 --> Helper loaded: url_helper
INFO - 2018-06-21 21:11:01 --> Helper loaded: form_helper
INFO - 2018-06-21 21:11:01 --> Helper loaded: date_helper
INFO - 2018-06-21 21:11:01 --> Helper loaded: util_helper
INFO - 2018-06-21 21:11:01 --> Helper loaded: text_helper
INFO - 2018-06-21 21:11:01 --> Helper loaded: string_helper
INFO - 2018-06-21 21:11:01 --> Database Driver Class Initialized
DEBUG - 2018-06-21 21:11:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 21:11:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 21:11:01 --> Email Class Initialized
INFO - 2018-06-21 21:11:01 --> Controller Class Initialized
DEBUG - 2018-06-21 21:11:01 --> Login MX_Controller Initialized
INFO - 2018-06-21 21:11:01 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 21:11:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 21:11:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-21 21:11:01 --> Email starts for user@colin.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-06-21 21:11:01 --> Login status user@colin.com - failure
INFO - 2018-06-21 21:11:01 --> Final output sent to browser
DEBUG - 2018-06-21 21:11:01 --> Total execution time: 0.4934
INFO - 2018-06-21 21:11:06 --> Config Class Initialized
INFO - 2018-06-21 21:11:06 --> Hooks Class Initialized
DEBUG - 2018-06-21 21:11:06 --> UTF-8 Support Enabled
INFO - 2018-06-21 21:11:06 --> Utf8 Class Initialized
INFO - 2018-06-21 21:11:06 --> URI Class Initialized
INFO - 2018-06-21 21:11:06 --> Router Class Initialized
INFO - 2018-06-21 21:11:06 --> Output Class Initialized
INFO - 2018-06-21 21:11:06 --> Security Class Initialized
DEBUG - 2018-06-21 21:11:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 21:11:06 --> Input Class Initialized
INFO - 2018-06-21 21:11:06 --> Language Class Initialized
INFO - 2018-06-21 21:11:06 --> Language Class Initialized
INFO - 2018-06-21 21:11:06 --> Config Class Initialized
INFO - 2018-06-21 21:11:06 --> Loader Class Initialized
DEBUG - 2018-06-21 21:11:06 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 21:11:06 --> Helper loaded: url_helper
INFO - 2018-06-21 21:11:06 --> Helper loaded: form_helper
INFO - 2018-06-21 21:11:06 --> Helper loaded: date_helper
INFO - 2018-06-21 21:11:06 --> Helper loaded: util_helper
INFO - 2018-06-21 21:11:06 --> Helper loaded: text_helper
INFO - 2018-06-21 21:11:06 --> Helper loaded: string_helper
INFO - 2018-06-21 21:11:06 --> Database Driver Class Initialized
DEBUG - 2018-06-21 21:11:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 21:11:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 21:11:06 --> Email Class Initialized
INFO - 2018-06-21 21:11:06 --> Controller Class Initialized
DEBUG - 2018-06-21 21:11:06 --> Login MX_Controller Initialized
INFO - 2018-06-21 21:11:06 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 21:11:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 21:11:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-21 21:11:06 --> Email starts for user@colin.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-06-21 21:11:06 --> Login status user@colin.com - failure
INFO - 2018-06-21 21:11:06 --> Final output sent to browser
DEBUG - 2018-06-21 21:11:06 --> Total execution time: 0.4737
INFO - 2018-06-21 21:13:28 --> Config Class Initialized
INFO - 2018-06-21 21:13:28 --> Hooks Class Initialized
DEBUG - 2018-06-21 21:13:28 --> UTF-8 Support Enabled
INFO - 2018-06-21 21:13:28 --> Utf8 Class Initialized
INFO - 2018-06-21 21:13:28 --> URI Class Initialized
INFO - 2018-06-21 21:13:28 --> Router Class Initialized
INFO - 2018-06-21 21:13:28 --> Output Class Initialized
INFO - 2018-06-21 21:13:28 --> Security Class Initialized
DEBUG - 2018-06-21 21:13:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 21:13:28 --> Input Class Initialized
INFO - 2018-06-21 21:13:28 --> Language Class Initialized
INFO - 2018-06-21 21:13:28 --> Language Class Initialized
INFO - 2018-06-21 21:13:28 --> Config Class Initialized
INFO - 2018-06-21 21:13:28 --> Loader Class Initialized
DEBUG - 2018-06-21 21:13:28 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 21:13:28 --> Helper loaded: url_helper
INFO - 2018-06-21 21:13:28 --> Helper loaded: form_helper
INFO - 2018-06-21 21:13:28 --> Helper loaded: date_helper
INFO - 2018-06-21 21:13:28 --> Helper loaded: util_helper
INFO - 2018-06-21 21:13:28 --> Helper loaded: text_helper
INFO - 2018-06-21 21:13:28 --> Helper loaded: string_helper
INFO - 2018-06-21 21:13:28 --> Database Driver Class Initialized
DEBUG - 2018-06-21 21:13:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 21:13:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 21:13:28 --> Email Class Initialized
INFO - 2018-06-21 21:13:28 --> Controller Class Initialized
DEBUG - 2018-06-21 21:13:28 --> Login MX_Controller Initialized
INFO - 2018-06-21 21:13:28 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 21:13:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 21:13:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-21 21:13:28 --> Email starts for user@colin.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-06-21 21:13:28 --> Login status user@colin.com - failure
INFO - 2018-06-21 21:13:28 --> Final output sent to browser
DEBUG - 2018-06-21 21:13:28 --> Total execution time: 0.4977
INFO - 2018-06-21 21:13:33 --> Config Class Initialized
INFO - 2018-06-21 21:13:33 --> Hooks Class Initialized
DEBUG - 2018-06-21 21:13:33 --> UTF-8 Support Enabled
INFO - 2018-06-21 21:13:33 --> Utf8 Class Initialized
INFO - 2018-06-21 21:13:33 --> URI Class Initialized
INFO - 2018-06-21 21:13:33 --> Router Class Initialized
INFO - 2018-06-21 21:13:33 --> Output Class Initialized
INFO - 2018-06-21 21:13:33 --> Security Class Initialized
DEBUG - 2018-06-21 21:13:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 21:13:33 --> Input Class Initialized
INFO - 2018-06-21 21:13:33 --> Language Class Initialized
INFO - 2018-06-21 21:13:33 --> Language Class Initialized
INFO - 2018-06-21 21:13:33 --> Config Class Initialized
INFO - 2018-06-21 21:13:33 --> Loader Class Initialized
DEBUG - 2018-06-21 21:13:33 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 21:13:34 --> Helper loaded: url_helper
INFO - 2018-06-21 21:13:34 --> Helper loaded: form_helper
INFO - 2018-06-21 21:13:34 --> Helper loaded: date_helper
INFO - 2018-06-21 21:13:34 --> Helper loaded: util_helper
INFO - 2018-06-21 21:13:34 --> Helper loaded: text_helper
INFO - 2018-06-21 21:13:34 --> Helper loaded: string_helper
INFO - 2018-06-21 21:13:34 --> Database Driver Class Initialized
DEBUG - 2018-06-21 21:13:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 21:13:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 21:13:34 --> Email Class Initialized
INFO - 2018-06-21 21:13:34 --> Controller Class Initialized
DEBUG - 2018-06-21 21:13:34 --> Login MX_Controller Initialized
INFO - 2018-06-21 21:13:34 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 21:13:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 21:13:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-21 21:13:34 --> Email starts for user@colin.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-06-21 21:13:34 --> Login status user@colin.com - failure
INFO - 2018-06-21 21:13:34 --> Final output sent to browser
DEBUG - 2018-06-21 21:13:34 --> Total execution time: 0.5364
INFO - 2018-06-21 21:14:24 --> Config Class Initialized
INFO - 2018-06-21 21:14:24 --> Hooks Class Initialized
DEBUG - 2018-06-21 21:14:24 --> UTF-8 Support Enabled
INFO - 2018-06-21 21:14:24 --> Utf8 Class Initialized
INFO - 2018-06-21 21:14:24 --> URI Class Initialized
INFO - 2018-06-21 21:14:24 --> Router Class Initialized
INFO - 2018-06-21 21:14:24 --> Output Class Initialized
INFO - 2018-06-21 21:14:24 --> Security Class Initialized
DEBUG - 2018-06-21 21:14:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 21:14:24 --> Input Class Initialized
INFO - 2018-06-21 21:14:24 --> Language Class Initialized
INFO - 2018-06-21 21:14:24 --> Language Class Initialized
INFO - 2018-06-21 21:14:24 --> Config Class Initialized
INFO - 2018-06-21 21:14:24 --> Loader Class Initialized
DEBUG - 2018-06-21 21:14:24 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 21:14:24 --> Helper loaded: url_helper
INFO - 2018-06-21 21:14:24 --> Helper loaded: form_helper
INFO - 2018-06-21 21:14:24 --> Helper loaded: date_helper
INFO - 2018-06-21 21:14:24 --> Helper loaded: util_helper
INFO - 2018-06-21 21:14:24 --> Helper loaded: text_helper
INFO - 2018-06-21 21:14:24 --> Helper loaded: string_helper
INFO - 2018-06-21 21:14:24 --> Database Driver Class Initialized
DEBUG - 2018-06-21 21:14:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 21:14:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 21:14:24 --> Email Class Initialized
INFO - 2018-06-21 21:14:24 --> Controller Class Initialized
DEBUG - 2018-06-21 21:14:24 --> Login MX_Controller Initialized
INFO - 2018-06-21 21:14:24 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 21:14:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 21:14:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-21 21:14:24 --> Email starts for user@colin.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-06-21 21:14:24 --> User session created for 4
INFO - 2018-06-21 21:14:24 --> Login status user@colin.com - success
INFO - 2018-06-21 21:14:24 --> Final output sent to browser
DEBUG - 2018-06-21 21:14:24 --> Total execution time: 0.5746
INFO - 2018-06-21 21:14:24 --> Config Class Initialized
INFO - 2018-06-21 21:14:24 --> Hooks Class Initialized
DEBUG - 2018-06-21 21:14:24 --> UTF-8 Support Enabled
INFO - 2018-06-21 21:14:24 --> Utf8 Class Initialized
INFO - 2018-06-21 21:14:24 --> URI Class Initialized
INFO - 2018-06-21 21:14:24 --> Router Class Initialized
INFO - 2018-06-21 21:14:24 --> Output Class Initialized
INFO - 2018-06-21 21:14:24 --> Security Class Initialized
DEBUG - 2018-06-21 21:14:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 21:14:25 --> Input Class Initialized
INFO - 2018-06-21 21:14:25 --> Language Class Initialized
INFO - 2018-06-21 21:14:25 --> Language Class Initialized
INFO - 2018-06-21 21:14:25 --> Config Class Initialized
INFO - 2018-06-21 21:14:25 --> Loader Class Initialized
DEBUG - 2018-06-21 21:14:25 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 21:14:25 --> Helper loaded: url_helper
INFO - 2018-06-21 21:14:25 --> Helper loaded: form_helper
INFO - 2018-06-21 21:14:25 --> Helper loaded: date_helper
INFO - 2018-06-21 21:14:25 --> Helper loaded: util_helper
INFO - 2018-06-21 21:14:25 --> Helper loaded: text_helper
INFO - 2018-06-21 21:14:25 --> Helper loaded: string_helper
INFO - 2018-06-21 21:14:25 --> Database Driver Class Initialized
DEBUG - 2018-06-21 21:14:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 21:14:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 21:14:25 --> Email Class Initialized
INFO - 2018-06-21 21:14:25 --> Controller Class Initialized
DEBUG - 2018-06-21 21:14:25 --> Home MX_Controller Initialized
DEBUG - 2018-06-21 21:14:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-21 21:14:25 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 21:14:25 --> Login MX_Controller Initialized
INFO - 2018-06-21 21:14:25 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 21:14:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 21:14:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-21 21:14:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-21 21:14:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-21 21:14:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-21 21:14:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-21 21:14:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-21 21:14:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-06-21 21:14:25 --> Final output sent to browser
DEBUG - 2018-06-21 21:14:25 --> Total execution time: 0.6718
INFO - 2018-06-21 21:14:26 --> Config Class Initialized
INFO - 2018-06-21 21:14:26 --> Config Class Initialized
INFO - 2018-06-21 21:14:26 --> Hooks Class Initialized
INFO - 2018-06-21 21:14:26 --> Hooks Class Initialized
DEBUG - 2018-06-21 21:14:26 --> UTF-8 Support Enabled
DEBUG - 2018-06-21 21:14:26 --> UTF-8 Support Enabled
INFO - 2018-06-21 21:14:26 --> Utf8 Class Initialized
INFO - 2018-06-21 21:14:26 --> Utf8 Class Initialized
INFO - 2018-06-21 21:14:26 --> URI Class Initialized
INFO - 2018-06-21 21:14:26 --> URI Class Initialized
INFO - 2018-06-21 21:14:26 --> Router Class Initialized
INFO - 2018-06-21 21:14:26 --> Output Class Initialized
INFO - 2018-06-21 21:14:26 --> Security Class Initialized
DEBUG - 2018-06-21 21:14:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 21:14:26 --> Input Class Initialized
INFO - 2018-06-21 21:14:26 --> Router Class Initialized
INFO - 2018-06-21 21:14:26 --> Output Class Initialized
INFO - 2018-06-21 21:14:26 --> Language Class Initialized
ERROR - 2018-06-21 21:14:26 --> 404 Page Not Found: /index
INFO - 2018-06-21 21:14:26 --> Security Class Initialized
DEBUG - 2018-06-21 21:14:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 21:14:26 --> Input Class Initialized
INFO - 2018-06-21 21:14:26 --> Language Class Initialized
ERROR - 2018-06-21 21:14:26 --> 404 Page Not Found: /index
INFO - 2018-06-21 21:14:26 --> Config Class Initialized
INFO - 2018-06-21 21:14:26 --> Hooks Class Initialized
DEBUG - 2018-06-21 21:14:27 --> UTF-8 Support Enabled
INFO - 2018-06-21 21:14:27 --> Utf8 Class Initialized
INFO - 2018-06-21 21:14:27 --> URI Class Initialized
INFO - 2018-06-21 21:14:27 --> Router Class Initialized
INFO - 2018-06-21 21:14:27 --> Output Class Initialized
INFO - 2018-06-21 21:14:27 --> Security Class Initialized
DEBUG - 2018-06-21 21:14:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 21:14:27 --> Input Class Initialized
INFO - 2018-06-21 21:14:27 --> Language Class Initialized
ERROR - 2018-06-21 21:14:27 --> 404 Page Not Found: /index
INFO - 2018-06-21 21:14:27 --> Config Class Initialized
INFO - 2018-06-21 21:14:27 --> Hooks Class Initialized
DEBUG - 2018-06-21 21:14:27 --> UTF-8 Support Enabled
INFO - 2018-06-21 21:14:27 --> Utf8 Class Initialized
INFO - 2018-06-21 21:14:27 --> URI Class Initialized
INFO - 2018-06-21 21:14:27 --> Router Class Initialized
INFO - 2018-06-21 21:14:27 --> Output Class Initialized
INFO - 2018-06-21 21:14:27 --> Security Class Initialized
DEBUG - 2018-06-21 21:14:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 21:14:27 --> Input Class Initialized
INFO - 2018-06-21 21:14:27 --> Language Class Initialized
ERROR - 2018-06-21 21:14:27 --> 404 Page Not Found: /index
INFO - 2018-06-21 21:14:28 --> Config Class Initialized
INFO - 2018-06-21 21:14:28 --> Hooks Class Initialized
DEBUG - 2018-06-21 21:14:28 --> UTF-8 Support Enabled
INFO - 2018-06-21 21:14:28 --> Utf8 Class Initialized
INFO - 2018-06-21 21:14:28 --> URI Class Initialized
INFO - 2018-06-21 21:14:28 --> Router Class Initialized
INFO - 2018-06-21 21:14:28 --> Output Class Initialized
INFO - 2018-06-21 21:14:28 --> Security Class Initialized
DEBUG - 2018-06-21 21:14:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 21:14:28 --> Input Class Initialized
INFO - 2018-06-21 21:14:28 --> Language Class Initialized
ERROR - 2018-06-21 21:14:28 --> 404 Page Not Found: /index
INFO - 2018-06-21 21:14:28 --> Config Class Initialized
INFO - 2018-06-21 21:14:28 --> Hooks Class Initialized
DEBUG - 2018-06-21 21:14:28 --> UTF-8 Support Enabled
INFO - 2018-06-21 21:14:28 --> Utf8 Class Initialized
INFO - 2018-06-21 21:14:28 --> URI Class Initialized
INFO - 2018-06-21 21:14:28 --> Router Class Initialized
INFO - 2018-06-21 21:14:28 --> Output Class Initialized
INFO - 2018-06-21 21:14:28 --> Security Class Initialized
DEBUG - 2018-06-21 21:14:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 21:14:28 --> Input Class Initialized
INFO - 2018-06-21 21:14:28 --> Language Class Initialized
ERROR - 2018-06-21 21:14:28 --> 404 Page Not Found: /index
INFO - 2018-06-21 21:14:28 --> Config Class Initialized
INFO - 2018-06-21 21:14:28 --> Hooks Class Initialized
DEBUG - 2018-06-21 21:14:28 --> UTF-8 Support Enabled
INFO - 2018-06-21 21:14:28 --> Utf8 Class Initialized
INFO - 2018-06-21 21:14:28 --> URI Class Initialized
INFO - 2018-06-21 21:14:28 --> Router Class Initialized
INFO - 2018-06-21 21:14:28 --> Output Class Initialized
INFO - 2018-06-21 21:14:28 --> Security Class Initialized
DEBUG - 2018-06-21 21:14:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 21:14:28 --> Input Class Initialized
INFO - 2018-06-21 21:14:28 --> Language Class Initialized
ERROR - 2018-06-21 21:14:28 --> 404 Page Not Found: /index
INFO - 2018-06-21 21:31:31 --> Config Class Initialized
INFO - 2018-06-21 21:31:31 --> Hooks Class Initialized
DEBUG - 2018-06-21 21:31:31 --> UTF-8 Support Enabled
INFO - 2018-06-21 21:31:31 --> Utf8 Class Initialized
INFO - 2018-06-21 21:31:31 --> URI Class Initialized
INFO - 2018-06-21 21:31:31 --> Router Class Initialized
INFO - 2018-06-21 21:31:31 --> Output Class Initialized
INFO - 2018-06-21 21:31:31 --> Security Class Initialized
DEBUG - 2018-06-21 21:31:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 21:31:31 --> Input Class Initialized
INFO - 2018-06-21 21:31:31 --> Language Class Initialized
INFO - 2018-06-21 21:31:31 --> Language Class Initialized
INFO - 2018-06-21 21:31:31 --> Config Class Initialized
INFO - 2018-06-21 21:31:31 --> Loader Class Initialized
DEBUG - 2018-06-21 21:31:31 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 21:31:31 --> Helper loaded: url_helper
INFO - 2018-06-21 21:31:31 --> Helper loaded: form_helper
INFO - 2018-06-21 21:31:31 --> Helper loaded: date_helper
INFO - 2018-06-21 21:31:31 --> Helper loaded: util_helper
INFO - 2018-06-21 21:31:31 --> Helper loaded: text_helper
INFO - 2018-06-21 21:31:31 --> Helper loaded: string_helper
INFO - 2018-06-21 21:31:31 --> Database Driver Class Initialized
DEBUG - 2018-06-21 21:31:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 21:31:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 21:31:31 --> Email Class Initialized
INFO - 2018-06-21 21:31:31 --> Controller Class Initialized
DEBUG - 2018-06-21 21:31:31 --> Login MX_Controller Initialized
INFO - 2018-06-21 21:31:31 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 21:31:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 21:31:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-21 21:31:31 --> Email starts for gopipanguluri123@gmail.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-06-21 21:31:31 --> Login status gopipanguluri123@gmail.com - failure
INFO - 2018-06-21 21:31:31 --> Final output sent to browser
DEBUG - 2018-06-21 21:31:31 --> Total execution time: 0.4785
INFO - 2018-06-21 21:31:46 --> Config Class Initialized
INFO - 2018-06-21 21:31:46 --> Hooks Class Initialized
DEBUG - 2018-06-21 21:31:47 --> UTF-8 Support Enabled
INFO - 2018-06-21 21:31:47 --> Utf8 Class Initialized
INFO - 2018-06-21 21:31:47 --> URI Class Initialized
INFO - 2018-06-21 21:31:47 --> Router Class Initialized
INFO - 2018-06-21 21:31:47 --> Output Class Initialized
INFO - 2018-06-21 21:31:47 --> Security Class Initialized
DEBUG - 2018-06-21 21:31:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 21:31:47 --> Input Class Initialized
INFO - 2018-06-21 21:31:47 --> Language Class Initialized
INFO - 2018-06-21 21:31:47 --> Language Class Initialized
INFO - 2018-06-21 21:31:47 --> Config Class Initialized
INFO - 2018-06-21 21:31:47 --> Loader Class Initialized
DEBUG - 2018-06-21 21:31:47 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 21:31:47 --> Helper loaded: url_helper
INFO - 2018-06-21 21:31:47 --> Helper loaded: form_helper
INFO - 2018-06-21 21:31:47 --> Helper loaded: date_helper
INFO - 2018-06-21 21:31:47 --> Helper loaded: util_helper
INFO - 2018-06-21 21:31:47 --> Helper loaded: text_helper
INFO - 2018-06-21 21:31:47 --> Helper loaded: string_helper
INFO - 2018-06-21 21:31:47 --> Database Driver Class Initialized
DEBUG - 2018-06-21 21:31:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 21:31:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 21:31:47 --> Email Class Initialized
INFO - 2018-06-21 21:31:47 --> Controller Class Initialized
DEBUG - 2018-06-21 21:31:47 --> Login MX_Controller Initialized
INFO - 2018-06-21 21:31:47 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 21:31:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 21:31:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-21 21:31:47 --> Email starts for gopi.lion123@gmail.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-06-21 21:31:47 --> User session created for 6
INFO - 2018-06-21 21:31:47 --> Login status gopi.lion123@gmail.com - success
INFO - 2018-06-21 21:31:47 --> Final output sent to browser
DEBUG - 2018-06-21 21:31:47 --> Total execution time: 0.5975
INFO - 2018-06-21 21:31:47 --> Config Class Initialized
INFO - 2018-06-21 21:31:47 --> Hooks Class Initialized
DEBUG - 2018-06-21 21:31:47 --> UTF-8 Support Enabled
INFO - 2018-06-21 21:31:47 --> Utf8 Class Initialized
INFO - 2018-06-21 21:31:47 --> URI Class Initialized
INFO - 2018-06-21 21:31:47 --> Router Class Initialized
INFO - 2018-06-21 21:31:47 --> Output Class Initialized
INFO - 2018-06-21 21:31:47 --> Security Class Initialized
DEBUG - 2018-06-21 21:31:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 21:31:47 --> Input Class Initialized
INFO - 2018-06-21 21:31:47 --> Language Class Initialized
INFO - 2018-06-21 21:31:47 --> Language Class Initialized
INFO - 2018-06-21 21:31:47 --> Config Class Initialized
INFO - 2018-06-21 21:31:47 --> Loader Class Initialized
DEBUG - 2018-06-21 21:31:47 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 21:31:47 --> Helper loaded: url_helper
INFO - 2018-06-21 21:31:47 --> Helper loaded: form_helper
INFO - 2018-06-21 21:31:47 --> Helper loaded: date_helper
INFO - 2018-06-21 21:31:47 --> Helper loaded: util_helper
INFO - 2018-06-21 21:31:47 --> Helper loaded: text_helper
INFO - 2018-06-21 21:31:47 --> Helper loaded: string_helper
INFO - 2018-06-21 21:31:47 --> Database Driver Class Initialized
DEBUG - 2018-06-21 21:31:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 21:31:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 21:31:48 --> Email Class Initialized
INFO - 2018-06-21 21:31:48 --> Controller Class Initialized
DEBUG - 2018-06-21 21:31:48 --> Users MX_Controller Initialized
DEBUG - 2018-06-21 21:31:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 21:31:48 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 21:31:48 --> Login MX_Controller Initialized
INFO - 2018-06-21 21:31:48 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 21:31:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-21 21:31:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
INFO - 2018-06-21 21:31:48 --> Config Class Initialized
INFO - 2018-06-21 21:31:48 --> Hooks Class Initialized
DEBUG - 2018-06-21 21:31:48 --> UTF-8 Support Enabled
INFO - 2018-06-21 21:31:48 --> Utf8 Class Initialized
INFO - 2018-06-21 21:31:48 --> URI Class Initialized
INFO - 2018-06-21 21:31:48 --> Router Class Initialized
INFO - 2018-06-21 21:31:48 --> Output Class Initialized
INFO - 2018-06-21 21:31:48 --> Security Class Initialized
DEBUG - 2018-06-21 21:31:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 21:31:48 --> Input Class Initialized
INFO - 2018-06-21 21:31:48 --> Language Class Initialized
ERROR - 2018-06-21 21:31:48 --> 404 Page Not Found: /index
INFO - 2018-06-21 21:31:51 --> Config Class Initialized
INFO - 2018-06-21 21:31:51 --> Hooks Class Initialized
DEBUG - 2018-06-21 21:31:51 --> UTF-8 Support Enabled
INFO - 2018-06-21 21:31:51 --> Utf8 Class Initialized
INFO - 2018-06-21 21:31:51 --> URI Class Initialized
INFO - 2018-06-21 21:31:51 --> Router Class Initialized
INFO - 2018-06-21 21:31:51 --> Output Class Initialized
INFO - 2018-06-21 21:31:51 --> Security Class Initialized
DEBUG - 2018-06-21 21:31:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 21:31:51 --> Input Class Initialized
INFO - 2018-06-21 21:31:51 --> Language Class Initialized
INFO - 2018-06-21 21:31:51 --> Language Class Initialized
INFO - 2018-06-21 21:31:52 --> Config Class Initialized
INFO - 2018-06-21 21:31:52 --> Loader Class Initialized
DEBUG - 2018-06-21 21:31:52 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 21:31:52 --> Helper loaded: url_helper
INFO - 2018-06-21 21:31:52 --> Helper loaded: form_helper
INFO - 2018-06-21 21:31:52 --> Helper loaded: date_helper
INFO - 2018-06-21 21:31:52 --> Helper loaded: util_helper
INFO - 2018-06-21 21:31:52 --> Helper loaded: text_helper
INFO - 2018-06-21 21:31:52 --> Helper loaded: string_helper
INFO - 2018-06-21 21:31:52 --> Database Driver Class Initialized
DEBUG - 2018-06-21 21:31:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 21:31:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 21:31:52 --> Email Class Initialized
INFO - 2018-06-21 21:31:52 --> Controller Class Initialized
DEBUG - 2018-06-21 21:31:52 --> Users MX_Controller Initialized
DEBUG - 2018-06-21 21:31:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 21:31:52 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 21:31:52 --> Login MX_Controller Initialized
INFO - 2018-06-21 21:31:52 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 21:31:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-21 21:31:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
INFO - 2018-06-21 21:31:52 --> Config Class Initialized
INFO - 2018-06-21 21:31:52 --> Hooks Class Initialized
DEBUG - 2018-06-21 21:31:52 --> UTF-8 Support Enabled
INFO - 2018-06-21 21:31:52 --> Utf8 Class Initialized
INFO - 2018-06-21 21:31:52 --> URI Class Initialized
INFO - 2018-06-21 21:31:52 --> Router Class Initialized
INFO - 2018-06-21 21:31:52 --> Output Class Initialized
INFO - 2018-06-21 21:31:52 --> Security Class Initialized
DEBUG - 2018-06-21 21:31:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 21:31:52 --> Input Class Initialized
INFO - 2018-06-21 21:31:52 --> Language Class Initialized
ERROR - 2018-06-21 21:31:52 --> 404 Page Not Found: /index
INFO - 2018-06-21 21:31:54 --> Config Class Initialized
INFO - 2018-06-21 21:31:54 --> Hooks Class Initialized
DEBUG - 2018-06-21 21:31:54 --> UTF-8 Support Enabled
INFO - 2018-06-21 21:31:54 --> Utf8 Class Initialized
INFO - 2018-06-21 21:31:54 --> URI Class Initialized
INFO - 2018-06-21 21:31:54 --> Router Class Initialized
INFO - 2018-06-21 21:31:54 --> Output Class Initialized
INFO - 2018-06-21 21:31:54 --> Security Class Initialized
DEBUG - 2018-06-21 21:31:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 21:31:54 --> Input Class Initialized
INFO - 2018-06-21 21:31:54 --> Language Class Initialized
INFO - 2018-06-21 21:31:54 --> Language Class Initialized
INFO - 2018-06-21 21:31:54 --> Config Class Initialized
INFO - 2018-06-21 21:31:54 --> Loader Class Initialized
DEBUG - 2018-06-21 21:31:54 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 21:31:55 --> Helper loaded: url_helper
INFO - 2018-06-21 21:31:55 --> Helper loaded: form_helper
INFO - 2018-06-21 21:31:55 --> Helper loaded: date_helper
INFO - 2018-06-21 21:31:55 --> Helper loaded: util_helper
INFO - 2018-06-21 21:31:55 --> Helper loaded: text_helper
INFO - 2018-06-21 21:31:55 --> Helper loaded: string_helper
INFO - 2018-06-21 21:31:55 --> Database Driver Class Initialized
DEBUG - 2018-06-21 21:31:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 21:31:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 21:31:55 --> Email Class Initialized
INFO - 2018-06-21 21:31:55 --> Controller Class Initialized
DEBUG - 2018-06-21 21:31:55 --> Admin MX_Controller Initialized
INFO - 2018-06-21 21:31:55 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 21:31:55 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 21:31:55 --> Login MX_Controller Initialized
DEBUG - 2018-06-21 21:31:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 21:31:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-21 21:31:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
INFO - 2018-06-21 21:31:55 --> Config Class Initialized
INFO - 2018-06-21 21:31:55 --> Hooks Class Initialized
DEBUG - 2018-06-21 21:31:55 --> UTF-8 Support Enabled
INFO - 2018-06-21 21:31:55 --> Utf8 Class Initialized
INFO - 2018-06-21 21:31:55 --> URI Class Initialized
INFO - 2018-06-21 21:31:55 --> Router Class Initialized
INFO - 2018-06-21 21:31:55 --> Output Class Initialized
INFO - 2018-06-21 21:31:55 --> Security Class Initialized
DEBUG - 2018-06-21 21:31:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 21:31:55 --> Input Class Initialized
INFO - 2018-06-21 21:31:55 --> Language Class Initialized
ERROR - 2018-06-21 21:31:55 --> 404 Page Not Found: /index
INFO - 2018-06-21 21:31:57 --> Config Class Initialized
INFO - 2018-06-21 21:31:57 --> Hooks Class Initialized
DEBUG - 2018-06-21 21:31:57 --> UTF-8 Support Enabled
INFO - 2018-06-21 21:31:57 --> Utf8 Class Initialized
INFO - 2018-06-21 21:31:57 --> URI Class Initialized
INFO - 2018-06-21 21:31:57 --> Router Class Initialized
INFO - 2018-06-21 21:31:57 --> Output Class Initialized
INFO - 2018-06-21 21:31:57 --> Security Class Initialized
DEBUG - 2018-06-21 21:31:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 21:31:57 --> Input Class Initialized
INFO - 2018-06-21 21:31:57 --> Language Class Initialized
INFO - 2018-06-21 21:31:57 --> Language Class Initialized
INFO - 2018-06-21 21:31:57 --> Config Class Initialized
INFO - 2018-06-21 21:31:57 --> Loader Class Initialized
DEBUG - 2018-06-21 21:31:57 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 21:31:57 --> Helper loaded: url_helper
INFO - 2018-06-21 21:31:57 --> Helper loaded: form_helper
INFO - 2018-06-21 21:31:57 --> Helper loaded: date_helper
INFO - 2018-06-21 21:31:57 --> Helper loaded: util_helper
INFO - 2018-06-21 21:31:57 --> Helper loaded: text_helper
INFO - 2018-06-21 21:31:57 --> Helper loaded: string_helper
INFO - 2018-06-21 21:31:57 --> Database Driver Class Initialized
DEBUG - 2018-06-21 21:31:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 21:31:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 21:31:57 --> Email Class Initialized
INFO - 2018-06-21 21:31:57 --> Controller Class Initialized
DEBUG - 2018-06-21 21:31:57 --> Login MX_Controller Initialized
INFO - 2018-06-21 21:31:58 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 21:31:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 21:31:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-21 21:31:58 --> Email starts for gopipanguluri123@gmail.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-06-21 21:31:58 --> Login status gopipanguluri123@gmail.com - failure
INFO - 2018-06-21 21:31:58 --> Final output sent to browser
DEBUG - 2018-06-21 21:31:58 --> Total execution time: 0.4698
INFO - 2018-06-21 21:32:00 --> Config Class Initialized
INFO - 2018-06-21 21:32:00 --> Hooks Class Initialized
DEBUG - 2018-06-21 21:32:00 --> UTF-8 Support Enabled
INFO - 2018-06-21 21:32:00 --> Utf8 Class Initialized
INFO - 2018-06-21 21:32:00 --> URI Class Initialized
INFO - 2018-06-21 21:32:00 --> Router Class Initialized
INFO - 2018-06-21 21:32:00 --> Output Class Initialized
INFO - 2018-06-21 21:32:00 --> Security Class Initialized
DEBUG - 2018-06-21 21:32:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 21:32:00 --> Input Class Initialized
INFO - 2018-06-21 21:32:00 --> Language Class Initialized
INFO - 2018-06-21 21:32:00 --> Language Class Initialized
INFO - 2018-06-21 21:32:00 --> Config Class Initialized
INFO - 2018-06-21 21:32:00 --> Loader Class Initialized
DEBUG - 2018-06-21 21:32:00 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 21:32:00 --> Helper loaded: url_helper
INFO - 2018-06-21 21:32:00 --> Helper loaded: form_helper
INFO - 2018-06-21 21:32:00 --> Helper loaded: date_helper
INFO - 2018-06-21 21:32:00 --> Helper loaded: util_helper
INFO - 2018-06-21 21:32:00 --> Helper loaded: text_helper
INFO - 2018-06-21 21:32:00 --> Helper loaded: string_helper
INFO - 2018-06-21 21:32:00 --> Database Driver Class Initialized
DEBUG - 2018-06-21 21:32:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 21:32:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 21:32:00 --> Email Class Initialized
INFO - 2018-06-21 21:32:00 --> Controller Class Initialized
DEBUG - 2018-06-21 21:32:00 --> Login MX_Controller Initialized
INFO - 2018-06-21 21:32:00 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 21:32:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 21:32:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-21 21:32:00 --> Email starts for gopi.lion123@gmail.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-06-21 21:32:00 --> User session created for 6
INFO - 2018-06-21 21:32:00 --> Login status gopi.lion123@gmail.com - success
INFO - 2018-06-21 21:32:00 --> Final output sent to browser
DEBUG - 2018-06-21 21:32:00 --> Total execution time: 0.5687
INFO - 2018-06-21 21:32:00 --> Config Class Initialized
INFO - 2018-06-21 21:32:00 --> Hooks Class Initialized
DEBUG - 2018-06-21 21:32:00 --> UTF-8 Support Enabled
INFO - 2018-06-21 21:32:00 --> Utf8 Class Initialized
INFO - 2018-06-21 21:32:00 --> URI Class Initialized
INFO - 2018-06-21 21:32:00 --> Router Class Initialized
INFO - 2018-06-21 21:32:00 --> Output Class Initialized
INFO - 2018-06-21 21:32:00 --> Security Class Initialized
DEBUG - 2018-06-21 21:32:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 21:32:00 --> Input Class Initialized
INFO - 2018-06-21 21:32:00 --> Language Class Initialized
INFO - 2018-06-21 21:32:00 --> Language Class Initialized
INFO - 2018-06-21 21:32:00 --> Config Class Initialized
INFO - 2018-06-21 21:32:00 --> Loader Class Initialized
DEBUG - 2018-06-21 21:32:00 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 21:32:00 --> Helper loaded: url_helper
INFO - 2018-06-21 21:32:00 --> Helper loaded: form_helper
INFO - 2018-06-21 21:32:00 --> Helper loaded: date_helper
INFO - 2018-06-21 21:32:01 --> Helper loaded: util_helper
INFO - 2018-06-21 21:32:01 --> Helper loaded: text_helper
INFO - 2018-06-21 21:32:01 --> Helper loaded: string_helper
INFO - 2018-06-21 21:32:01 --> Database Driver Class Initialized
DEBUG - 2018-06-21 21:32:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 21:32:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 21:32:01 --> Email Class Initialized
INFO - 2018-06-21 21:32:01 --> Controller Class Initialized
DEBUG - 2018-06-21 21:32:01 --> Admin MX_Controller Initialized
INFO - 2018-06-21 21:32:01 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 21:32:01 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 21:32:01 --> Login MX_Controller Initialized
DEBUG - 2018-06-21 21:32:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 21:32:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-21 21:32:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
INFO - 2018-06-21 21:32:01 --> Config Class Initialized
INFO - 2018-06-21 21:32:01 --> Hooks Class Initialized
DEBUG - 2018-06-21 21:32:01 --> UTF-8 Support Enabled
INFO - 2018-06-21 21:32:01 --> Utf8 Class Initialized
INFO - 2018-06-21 21:32:01 --> URI Class Initialized
INFO - 2018-06-21 21:32:01 --> Router Class Initialized
INFO - 2018-06-21 21:32:01 --> Output Class Initialized
INFO - 2018-06-21 21:32:01 --> Security Class Initialized
DEBUG - 2018-06-21 21:32:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 21:32:01 --> Input Class Initialized
INFO - 2018-06-21 21:32:01 --> Language Class Initialized
ERROR - 2018-06-21 21:32:01 --> 404 Page Not Found: /index
INFO - 2018-06-21 21:37:03 --> Config Class Initialized
INFO - 2018-06-21 21:37:03 --> Hooks Class Initialized
DEBUG - 2018-06-21 21:37:03 --> UTF-8 Support Enabled
INFO - 2018-06-21 21:37:03 --> Utf8 Class Initialized
INFO - 2018-06-21 21:37:03 --> URI Class Initialized
INFO - 2018-06-21 21:37:03 --> Router Class Initialized
INFO - 2018-06-21 21:37:03 --> Output Class Initialized
INFO - 2018-06-21 21:37:03 --> Security Class Initialized
DEBUG - 2018-06-21 21:37:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 21:37:03 --> Input Class Initialized
INFO - 2018-06-21 21:37:03 --> Language Class Initialized
INFO - 2018-06-21 21:37:03 --> Language Class Initialized
INFO - 2018-06-21 21:37:03 --> Config Class Initialized
INFO - 2018-06-21 21:37:03 --> Loader Class Initialized
DEBUG - 2018-06-21 21:37:03 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 21:37:03 --> Helper loaded: url_helper
INFO - 2018-06-21 21:37:03 --> Helper loaded: form_helper
INFO - 2018-06-21 21:37:03 --> Helper loaded: date_helper
INFO - 2018-06-21 21:37:03 --> Helper loaded: util_helper
INFO - 2018-06-21 21:37:03 --> Helper loaded: text_helper
INFO - 2018-06-21 21:37:03 --> Helper loaded: string_helper
INFO - 2018-06-21 21:37:03 --> Database Driver Class Initialized
DEBUG - 2018-06-21 21:37:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 21:37:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 21:37:03 --> Email Class Initialized
INFO - 2018-06-21 21:37:03 --> Controller Class Initialized
DEBUG - 2018-06-21 21:37:03 --> Login MX_Controller Initialized
INFO - 2018-06-21 21:37:03 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 21:37:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 21:37:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-21 21:37:03 --> Email starts for gopi.lion123@gmail.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-06-21 21:37:39 --> Config Class Initialized
INFO - 2018-06-21 21:37:40 --> Hooks Class Initialized
DEBUG - 2018-06-21 21:37:40 --> UTF-8 Support Enabled
INFO - 2018-06-21 21:37:40 --> Utf8 Class Initialized
INFO - 2018-06-21 21:37:40 --> URI Class Initialized
INFO - 2018-06-21 21:37:40 --> Router Class Initialized
INFO - 2018-06-21 21:37:40 --> Output Class Initialized
INFO - 2018-06-21 21:37:40 --> Security Class Initialized
DEBUG - 2018-06-21 21:37:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 21:37:40 --> Input Class Initialized
INFO - 2018-06-21 21:37:40 --> Language Class Initialized
INFO - 2018-06-21 21:37:40 --> Language Class Initialized
INFO - 2018-06-21 21:37:40 --> Config Class Initialized
INFO - 2018-06-21 21:37:40 --> Loader Class Initialized
DEBUG - 2018-06-21 21:37:40 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 21:37:40 --> Helper loaded: url_helper
INFO - 2018-06-21 21:37:40 --> Helper loaded: form_helper
INFO - 2018-06-21 21:37:40 --> Helper loaded: date_helper
INFO - 2018-06-21 21:37:40 --> Helper loaded: util_helper
INFO - 2018-06-21 21:37:40 --> Helper loaded: text_helper
INFO - 2018-06-21 21:37:40 --> Helper loaded: string_helper
INFO - 2018-06-21 21:37:40 --> Database Driver Class Initialized
DEBUG - 2018-06-21 21:37:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 21:37:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 21:37:40 --> Email Class Initialized
INFO - 2018-06-21 21:37:40 --> Controller Class Initialized
DEBUG - 2018-06-21 21:37:40 --> Login MX_Controller Initialized
INFO - 2018-06-21 21:37:40 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 21:37:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 21:37:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-21 21:37:40 --> Email starts for gopi.lion123@gmail.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-06-21 21:38:16 --> Config Class Initialized
INFO - 2018-06-21 21:38:16 --> Hooks Class Initialized
DEBUG - 2018-06-21 21:38:16 --> UTF-8 Support Enabled
INFO - 2018-06-21 21:38:16 --> Utf8 Class Initialized
INFO - 2018-06-21 21:38:16 --> URI Class Initialized
INFO - 2018-06-21 21:38:16 --> Router Class Initialized
INFO - 2018-06-21 21:38:16 --> Output Class Initialized
INFO - 2018-06-21 21:38:16 --> Security Class Initialized
DEBUG - 2018-06-21 21:38:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 21:38:17 --> Input Class Initialized
INFO - 2018-06-21 21:38:17 --> Language Class Initialized
INFO - 2018-06-21 21:38:17 --> Language Class Initialized
INFO - 2018-06-21 21:38:17 --> Config Class Initialized
INFO - 2018-06-21 21:38:17 --> Loader Class Initialized
DEBUG - 2018-06-21 21:38:17 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 21:38:17 --> Helper loaded: url_helper
INFO - 2018-06-21 21:38:17 --> Helper loaded: form_helper
INFO - 2018-06-21 21:38:17 --> Helper loaded: date_helper
INFO - 2018-06-21 21:38:17 --> Helper loaded: util_helper
INFO - 2018-06-21 21:38:17 --> Helper loaded: text_helper
INFO - 2018-06-21 21:38:17 --> Helper loaded: string_helper
INFO - 2018-06-21 21:38:17 --> Database Driver Class Initialized
DEBUG - 2018-06-21 21:38:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 21:38:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 21:38:17 --> Email Class Initialized
INFO - 2018-06-21 21:38:17 --> Controller Class Initialized
DEBUG - 2018-06-21 21:38:17 --> Login MX_Controller Initialized
INFO - 2018-06-21 21:38:17 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 21:38:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 21:38:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-21 21:38:17 --> Email starts for gopi.lion123@gmail.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
ERROR - 2018-06-21 21:38:17 --> Severity: Notice --> Undefined variable: loggedin_user E:\xampp\htdocs\consulting\application\modules\admin\models\Loginmdl.php 65
INFO - 2018-06-21 21:38:31 --> Config Class Initialized
INFO - 2018-06-21 21:38:31 --> Hooks Class Initialized
DEBUG - 2018-06-21 21:38:31 --> UTF-8 Support Enabled
INFO - 2018-06-21 21:38:31 --> Utf8 Class Initialized
INFO - 2018-06-21 21:38:31 --> URI Class Initialized
INFO - 2018-06-21 21:38:31 --> Router Class Initialized
INFO - 2018-06-21 21:38:31 --> Output Class Initialized
INFO - 2018-06-21 21:38:31 --> Security Class Initialized
DEBUG - 2018-06-21 21:38:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 21:38:31 --> Input Class Initialized
INFO - 2018-06-21 21:38:31 --> Language Class Initialized
INFO - 2018-06-21 21:38:31 --> Language Class Initialized
INFO - 2018-06-21 21:38:31 --> Config Class Initialized
INFO - 2018-06-21 21:38:31 --> Loader Class Initialized
DEBUG - 2018-06-21 21:38:31 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 21:38:31 --> Helper loaded: url_helper
INFO - 2018-06-21 21:38:31 --> Helper loaded: form_helper
INFO - 2018-06-21 21:38:31 --> Helper loaded: date_helper
INFO - 2018-06-21 21:38:31 --> Helper loaded: util_helper
INFO - 2018-06-21 21:38:31 --> Helper loaded: text_helper
INFO - 2018-06-21 21:38:31 --> Helper loaded: string_helper
INFO - 2018-06-21 21:38:31 --> Database Driver Class Initialized
DEBUG - 2018-06-21 21:38:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 21:38:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 21:38:31 --> Email Class Initialized
INFO - 2018-06-21 21:38:31 --> Controller Class Initialized
DEBUG - 2018-06-21 21:38:31 --> Login MX_Controller Initialized
INFO - 2018-06-21 21:38:31 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 21:38:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 21:38:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-21 21:38:31 --> Email starts for gopi.lion123@gmail.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-06-21 21:41:52 --> Config Class Initialized
INFO - 2018-06-21 21:41:52 --> Hooks Class Initialized
DEBUG - 2018-06-21 21:41:52 --> UTF-8 Support Enabled
INFO - 2018-06-21 21:41:52 --> Utf8 Class Initialized
INFO - 2018-06-21 21:41:52 --> URI Class Initialized
INFO - 2018-06-21 21:41:52 --> Router Class Initialized
INFO - 2018-06-21 21:41:52 --> Output Class Initialized
INFO - 2018-06-21 21:41:52 --> Security Class Initialized
DEBUG - 2018-06-21 21:41:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 21:41:52 --> Input Class Initialized
INFO - 2018-06-21 21:41:52 --> Language Class Initialized
INFO - 2018-06-21 21:41:52 --> Language Class Initialized
INFO - 2018-06-21 21:41:52 --> Config Class Initialized
INFO - 2018-06-21 21:41:52 --> Loader Class Initialized
DEBUG - 2018-06-21 21:41:52 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 21:41:52 --> Helper loaded: url_helper
INFO - 2018-06-21 21:41:52 --> Helper loaded: form_helper
INFO - 2018-06-21 21:41:52 --> Helper loaded: date_helper
INFO - 2018-06-21 21:41:52 --> Helper loaded: util_helper
INFO - 2018-06-21 21:41:52 --> Helper loaded: text_helper
INFO - 2018-06-21 21:41:52 --> Helper loaded: string_helper
INFO - 2018-06-21 21:41:52 --> Database Driver Class Initialized
DEBUG - 2018-06-21 21:41:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 21:41:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 21:41:52 --> Email Class Initialized
INFO - 2018-06-21 21:41:52 --> Controller Class Initialized
DEBUG - 2018-06-21 21:41:52 --> Login MX_Controller Initialized
INFO - 2018-06-21 21:41:52 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 21:41:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 21:41:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-21 21:41:52 --> Email starts for gopi.lion123@gmail.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-06-21 21:41:52 --> User session created for 6
INFO - 2018-06-21 21:41:52 --> Login status gopi.lion123@gmail.com - success
INFO - 2018-06-21 21:41:52 --> Final output sent to browser
DEBUG - 2018-06-21 21:41:52 --> Total execution time: 0.6174
INFO - 2018-06-21 21:41:52 --> Config Class Initialized
INFO - 2018-06-21 21:41:52 --> Hooks Class Initialized
DEBUG - 2018-06-21 21:41:52 --> UTF-8 Support Enabled
INFO - 2018-06-21 21:41:52 --> Utf8 Class Initialized
INFO - 2018-06-21 21:41:52 --> URI Class Initialized
INFO - 2018-06-21 21:41:52 --> Router Class Initialized
INFO - 2018-06-21 21:41:52 --> Output Class Initialized
INFO - 2018-06-21 21:41:52 --> Security Class Initialized
DEBUG - 2018-06-21 21:41:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 21:41:52 --> Input Class Initialized
INFO - 2018-06-21 21:41:52 --> Language Class Initialized
INFO - 2018-06-21 21:41:52 --> Language Class Initialized
INFO - 2018-06-21 21:41:52 --> Config Class Initialized
INFO - 2018-06-21 21:41:52 --> Loader Class Initialized
DEBUG - 2018-06-21 21:41:52 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 21:41:52 --> Helper loaded: url_helper
INFO - 2018-06-21 21:41:53 --> Helper loaded: form_helper
INFO - 2018-06-21 21:41:53 --> Helper loaded: date_helper
INFO - 2018-06-21 21:41:53 --> Helper loaded: util_helper
INFO - 2018-06-21 21:41:53 --> Helper loaded: text_helper
INFO - 2018-06-21 21:41:53 --> Helper loaded: string_helper
INFO - 2018-06-21 21:41:53 --> Database Driver Class Initialized
DEBUG - 2018-06-21 21:41:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 21:41:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 21:41:53 --> Email Class Initialized
INFO - 2018-06-21 21:41:53 --> Controller Class Initialized
DEBUG - 2018-06-21 21:41:53 --> Admin MX_Controller Initialized
INFO - 2018-06-21 21:41:53 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 21:41:53 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 21:41:53 --> Login MX_Controller Initialized
DEBUG - 2018-06-21 21:41:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 21:41:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-21 21:41:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-21 21:41:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-21 21:41:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-21 21:41:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-21 21:41:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-21 21:41:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/dashboard.php
INFO - 2018-06-21 21:41:53 --> Final output sent to browser
DEBUG - 2018-06-21 21:41:53 --> Total execution time: 0.6353
INFO - 2018-06-21 21:41:53 --> Config Class Initialized
INFO - 2018-06-21 21:41:53 --> Hooks Class Initialized
DEBUG - 2018-06-21 21:41:53 --> UTF-8 Support Enabled
INFO - 2018-06-21 21:41:53 --> Utf8 Class Initialized
INFO - 2018-06-21 21:41:53 --> URI Class Initialized
INFO - 2018-06-21 21:41:53 --> Router Class Initialized
INFO - 2018-06-21 21:41:53 --> Output Class Initialized
INFO - 2018-06-21 21:41:53 --> Security Class Initialized
DEBUG - 2018-06-21 21:41:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 21:41:53 --> Input Class Initialized
INFO - 2018-06-21 21:41:53 --> Language Class Initialized
ERROR - 2018-06-21 21:41:53 --> 404 Page Not Found: /index
INFO - 2018-06-21 21:41:54 --> Config Class Initialized
INFO - 2018-06-21 21:41:54 --> Hooks Class Initialized
DEBUG - 2018-06-21 21:41:54 --> UTF-8 Support Enabled
INFO - 2018-06-21 21:41:54 --> Utf8 Class Initialized
INFO - 2018-06-21 21:41:54 --> URI Class Initialized
INFO - 2018-06-21 21:41:54 --> Router Class Initialized
INFO - 2018-06-21 21:41:54 --> Output Class Initialized
INFO - 2018-06-21 21:41:54 --> Security Class Initialized
DEBUG - 2018-06-21 21:41:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 21:41:54 --> Input Class Initialized
INFO - 2018-06-21 21:41:54 --> Language Class Initialized
ERROR - 2018-06-21 21:41:54 --> 404 Page Not Found: /index
INFO - 2018-06-21 21:42:17 --> Config Class Initialized
INFO - 2018-06-21 21:42:18 --> Hooks Class Initialized
DEBUG - 2018-06-21 21:42:18 --> UTF-8 Support Enabled
INFO - 2018-06-21 21:42:18 --> Utf8 Class Initialized
INFO - 2018-06-21 21:42:18 --> URI Class Initialized
INFO - 2018-06-21 21:42:18 --> Router Class Initialized
INFO - 2018-06-21 21:42:18 --> Output Class Initialized
INFO - 2018-06-21 21:42:18 --> Security Class Initialized
DEBUG - 2018-06-21 21:42:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 21:42:18 --> Input Class Initialized
INFO - 2018-06-21 21:42:18 --> Language Class Initialized
INFO - 2018-06-21 21:42:18 --> Language Class Initialized
INFO - 2018-06-21 21:42:18 --> Config Class Initialized
INFO - 2018-06-21 21:42:18 --> Loader Class Initialized
DEBUG - 2018-06-21 21:42:18 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 21:42:18 --> Helper loaded: url_helper
INFO - 2018-06-21 21:42:18 --> Helper loaded: form_helper
INFO - 2018-06-21 21:42:18 --> Helper loaded: date_helper
INFO - 2018-06-21 21:42:18 --> Helper loaded: util_helper
INFO - 2018-06-21 21:42:18 --> Helper loaded: text_helper
INFO - 2018-06-21 21:42:18 --> Helper loaded: string_helper
INFO - 2018-06-21 21:42:18 --> Database Driver Class Initialized
DEBUG - 2018-06-21 21:42:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 21:42:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 21:42:18 --> Email Class Initialized
INFO - 2018-06-21 21:42:18 --> Controller Class Initialized
DEBUG - 2018-06-21 21:42:18 --> Users MX_Controller Initialized
DEBUG - 2018-06-21 21:42:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 21:42:18 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 21:42:18 --> Login MX_Controller Initialized
INFO - 2018-06-21 21:42:18 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 21:42:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-21 21:42:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-21 21:42:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-21 21:42:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-21 21:42:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-21 21:42:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-21 21:42:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-06-21 21:42:18 --> Final output sent to browser
DEBUG - 2018-06-21 21:42:18 --> Total execution time: 0.6075
INFO - 2018-06-21 21:42:19 --> Config Class Initialized
INFO - 2018-06-21 21:42:19 --> Hooks Class Initialized
DEBUG - 2018-06-21 21:42:19 --> UTF-8 Support Enabled
INFO - 2018-06-21 21:42:19 --> Utf8 Class Initialized
INFO - 2018-06-21 21:42:19 --> URI Class Initialized
INFO - 2018-06-21 21:42:19 --> Router Class Initialized
INFO - 2018-06-21 21:42:19 --> Output Class Initialized
INFO - 2018-06-21 21:42:19 --> Security Class Initialized
DEBUG - 2018-06-21 21:42:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 21:42:19 --> Input Class Initialized
INFO - 2018-06-21 21:42:19 --> Language Class Initialized
INFO - 2018-06-21 21:42:19 --> Language Class Initialized
INFO - 2018-06-21 21:42:19 --> Config Class Initialized
INFO - 2018-06-21 21:42:19 --> Loader Class Initialized
DEBUG - 2018-06-21 21:42:19 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 21:42:19 --> Helper loaded: url_helper
INFO - 2018-06-21 21:42:19 --> Helper loaded: form_helper
INFO - 2018-06-21 21:42:19 --> Helper loaded: date_helper
INFO - 2018-06-21 21:42:19 --> Helper loaded: util_helper
INFO - 2018-06-21 21:42:19 --> Helper loaded: text_helper
INFO - 2018-06-21 21:42:19 --> Helper loaded: string_helper
INFO - 2018-06-21 21:42:19 --> Database Driver Class Initialized
DEBUG - 2018-06-21 21:42:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 21:42:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 21:42:19 --> Email Class Initialized
INFO - 2018-06-21 21:42:19 --> Controller Class Initialized
DEBUG - 2018-06-21 21:42:19 --> Users MX_Controller Initialized
DEBUG - 2018-06-21 21:42:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 21:42:19 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 21:42:19 --> Login MX_Controller Initialized
INFO - 2018-06-21 21:42:19 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 21:42:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-21 21:42:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-06-21 21:42:19 --> Final output sent to browser
DEBUG - 2018-06-21 21:42:19 --> Total execution time: 0.7608
INFO - 2018-06-21 22:18:30 --> Config Class Initialized
INFO - 2018-06-21 22:18:30 --> Hooks Class Initialized
DEBUG - 2018-06-21 22:18:30 --> UTF-8 Support Enabled
INFO - 2018-06-21 22:18:30 --> Utf8 Class Initialized
INFO - 2018-06-21 22:18:30 --> URI Class Initialized
INFO - 2018-06-21 22:18:30 --> Router Class Initialized
INFO - 2018-06-21 22:18:30 --> Output Class Initialized
INFO - 2018-06-21 22:18:30 --> Security Class Initialized
DEBUG - 2018-06-21 22:18:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 22:18:30 --> Input Class Initialized
INFO - 2018-06-21 22:18:30 --> Language Class Initialized
INFO - 2018-06-21 22:18:30 --> Language Class Initialized
INFO - 2018-06-21 22:18:30 --> Config Class Initialized
INFO - 2018-06-21 22:18:30 --> Loader Class Initialized
DEBUG - 2018-06-21 22:18:30 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 22:18:30 --> Helper loaded: url_helper
INFO - 2018-06-21 22:18:30 --> Helper loaded: form_helper
INFO - 2018-06-21 22:18:30 --> Helper loaded: date_helper
INFO - 2018-06-21 22:18:30 --> Helper loaded: util_helper
INFO - 2018-06-21 22:18:30 --> Helper loaded: text_helper
INFO - 2018-06-21 22:18:30 --> Helper loaded: string_helper
INFO - 2018-06-21 22:18:30 --> Database Driver Class Initialized
DEBUG - 2018-06-21 22:18:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 22:18:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 22:18:30 --> Email Class Initialized
INFO - 2018-06-21 22:18:30 --> Controller Class Initialized
DEBUG - 2018-06-21 22:18:30 --> Users MX_Controller Initialized
DEBUG - 2018-06-21 22:18:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 22:18:30 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 22:18:30 --> Login MX_Controller Initialized
INFO - 2018-06-21 22:18:30 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 22:18:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-21 22:18:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-06-21 22:18:30 --> Final output sent to browser
DEBUG - 2018-06-21 22:18:30 --> Total execution time: 0.5655
INFO - 2018-06-21 22:18:33 --> Config Class Initialized
INFO - 2018-06-21 22:18:33 --> Hooks Class Initialized
DEBUG - 2018-06-21 22:18:33 --> UTF-8 Support Enabled
INFO - 2018-06-21 22:18:33 --> Utf8 Class Initialized
INFO - 2018-06-21 22:18:33 --> URI Class Initialized
INFO - 2018-06-21 22:18:33 --> Router Class Initialized
INFO - 2018-06-21 22:18:33 --> Output Class Initialized
INFO - 2018-06-21 22:18:33 --> Security Class Initialized
DEBUG - 2018-06-21 22:18:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 22:18:33 --> Input Class Initialized
INFO - 2018-06-21 22:18:33 --> Language Class Initialized
INFO - 2018-06-21 22:18:33 --> Language Class Initialized
INFO - 2018-06-21 22:18:33 --> Config Class Initialized
INFO - 2018-06-21 22:18:33 --> Loader Class Initialized
DEBUG - 2018-06-21 22:18:33 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 22:18:33 --> Helper loaded: url_helper
INFO - 2018-06-21 22:18:33 --> Helper loaded: form_helper
INFO - 2018-06-21 22:18:33 --> Helper loaded: date_helper
INFO - 2018-06-21 22:18:33 --> Helper loaded: util_helper
INFO - 2018-06-21 22:18:33 --> Helper loaded: text_helper
INFO - 2018-06-21 22:18:33 --> Helper loaded: string_helper
INFO - 2018-06-21 22:18:33 --> Database Driver Class Initialized
DEBUG - 2018-06-21 22:18:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 22:18:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 22:18:33 --> Email Class Initialized
INFO - 2018-06-21 22:18:33 --> Controller Class Initialized
DEBUG - 2018-06-21 22:18:33 --> Users MX_Controller Initialized
DEBUG - 2018-06-21 22:18:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 22:18:33 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 22:18:33 --> Login MX_Controller Initialized
INFO - 2018-06-21 22:18:33 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 22:18:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-21 22:18:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-06-21 22:18:33 --> Final output sent to browser
DEBUG - 2018-06-21 22:18:33 --> Total execution time: 0.5614
INFO - 2018-06-21 22:18:34 --> Config Class Initialized
INFO - 2018-06-21 22:18:34 --> Hooks Class Initialized
DEBUG - 2018-06-21 22:18:34 --> UTF-8 Support Enabled
INFO - 2018-06-21 22:18:34 --> Utf8 Class Initialized
INFO - 2018-06-21 22:18:34 --> URI Class Initialized
INFO - 2018-06-21 22:18:34 --> Router Class Initialized
INFO - 2018-06-21 22:18:34 --> Output Class Initialized
INFO - 2018-06-21 22:18:34 --> Security Class Initialized
DEBUG - 2018-06-21 22:18:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 22:18:34 --> Input Class Initialized
INFO - 2018-06-21 22:18:34 --> Language Class Initialized
INFO - 2018-06-21 22:18:34 --> Language Class Initialized
INFO - 2018-06-21 22:18:34 --> Config Class Initialized
INFO - 2018-06-21 22:18:34 --> Loader Class Initialized
DEBUG - 2018-06-21 22:18:34 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 22:18:34 --> Helper loaded: url_helper
INFO - 2018-06-21 22:18:34 --> Helper loaded: form_helper
INFO - 2018-06-21 22:18:34 --> Helper loaded: date_helper
INFO - 2018-06-21 22:18:34 --> Helper loaded: util_helper
INFO - 2018-06-21 22:18:34 --> Helper loaded: text_helper
INFO - 2018-06-21 22:18:34 --> Helper loaded: string_helper
INFO - 2018-06-21 22:18:34 --> Database Driver Class Initialized
DEBUG - 2018-06-21 22:18:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 22:18:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 22:18:34 --> Email Class Initialized
INFO - 2018-06-21 22:18:34 --> Controller Class Initialized
DEBUG - 2018-06-21 22:18:34 --> Users MX_Controller Initialized
DEBUG - 2018-06-21 22:18:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 22:18:34 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 22:18:34 --> Login MX_Controller Initialized
INFO - 2018-06-21 22:18:34 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 22:18:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-21 22:18:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-06-21 22:18:34 --> Final output sent to browser
DEBUG - 2018-06-21 22:18:34 --> Total execution time: 0.5622
INFO - 2018-06-21 22:18:41 --> Config Class Initialized
INFO - 2018-06-21 22:18:41 --> Hooks Class Initialized
DEBUG - 2018-06-21 22:18:41 --> UTF-8 Support Enabled
INFO - 2018-06-21 22:18:41 --> Utf8 Class Initialized
INFO - 2018-06-21 22:18:41 --> URI Class Initialized
INFO - 2018-06-21 22:18:41 --> Router Class Initialized
INFO - 2018-06-21 22:18:41 --> Output Class Initialized
INFO - 2018-06-21 22:18:41 --> Security Class Initialized
DEBUG - 2018-06-21 22:18:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 22:18:41 --> Input Class Initialized
INFO - 2018-06-21 22:18:41 --> Language Class Initialized
INFO - 2018-06-21 22:18:41 --> Language Class Initialized
INFO - 2018-06-21 22:18:41 --> Config Class Initialized
INFO - 2018-06-21 22:18:41 --> Loader Class Initialized
DEBUG - 2018-06-21 22:18:41 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 22:18:42 --> Helper loaded: url_helper
INFO - 2018-06-21 22:18:42 --> Helper loaded: form_helper
INFO - 2018-06-21 22:18:42 --> Helper loaded: date_helper
INFO - 2018-06-21 22:18:42 --> Helper loaded: util_helper
INFO - 2018-06-21 22:18:42 --> Helper loaded: text_helper
INFO - 2018-06-21 22:18:42 --> Helper loaded: string_helper
INFO - 2018-06-21 22:18:42 --> Database Driver Class Initialized
DEBUG - 2018-06-21 22:18:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 22:18:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 22:18:42 --> Email Class Initialized
INFO - 2018-06-21 22:18:42 --> Controller Class Initialized
DEBUG - 2018-06-21 22:18:42 --> Users MX_Controller Initialized
DEBUG - 2018-06-21 22:18:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 22:18:42 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 22:18:42 --> Login MX_Controller Initialized
INFO - 2018-06-21 22:18:42 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 22:18:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-21 22:18:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-06-21 22:18:42 --> Final output sent to browser
DEBUG - 2018-06-21 22:18:42 --> Total execution time: 0.5684
INFO - 2018-06-21 22:22:02 --> Config Class Initialized
INFO - 2018-06-21 22:22:02 --> Hooks Class Initialized
DEBUG - 2018-06-21 22:22:03 --> UTF-8 Support Enabled
INFO - 2018-06-21 22:22:03 --> Utf8 Class Initialized
INFO - 2018-06-21 22:22:03 --> URI Class Initialized
INFO - 2018-06-21 22:22:03 --> Router Class Initialized
INFO - 2018-06-21 22:22:03 --> Output Class Initialized
INFO - 2018-06-21 22:22:03 --> Security Class Initialized
DEBUG - 2018-06-21 22:22:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 22:22:03 --> Input Class Initialized
INFO - 2018-06-21 22:22:03 --> Language Class Initialized
INFO - 2018-06-21 22:22:03 --> Language Class Initialized
INFO - 2018-06-21 22:22:03 --> Config Class Initialized
INFO - 2018-06-21 22:22:03 --> Loader Class Initialized
DEBUG - 2018-06-21 22:22:03 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 22:22:03 --> Helper loaded: url_helper
INFO - 2018-06-21 22:22:03 --> Helper loaded: form_helper
INFO - 2018-06-21 22:22:03 --> Helper loaded: date_helper
INFO - 2018-06-21 22:22:03 --> Helper loaded: util_helper
INFO - 2018-06-21 22:22:03 --> Helper loaded: text_helper
INFO - 2018-06-21 22:22:03 --> Helper loaded: string_helper
INFO - 2018-06-21 22:22:03 --> Database Driver Class Initialized
DEBUG - 2018-06-21 22:22:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 22:22:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 22:22:03 --> Email Class Initialized
INFO - 2018-06-21 22:22:03 --> Controller Class Initialized
DEBUG - 2018-06-21 22:22:03 --> Users MX_Controller Initialized
DEBUG - 2018-06-21 22:22:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 22:22:03 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 22:22:03 --> Login MX_Controller Initialized
INFO - 2018-06-21 22:22:03 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 22:22:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-21 22:22:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-06-21 22:22:03 --> Final output sent to browser
DEBUG - 2018-06-21 22:22:03 --> Total execution time: 0.5711
INFO - 2018-06-21 22:22:05 --> Config Class Initialized
INFO - 2018-06-21 22:22:05 --> Hooks Class Initialized
DEBUG - 2018-06-21 22:22:05 --> UTF-8 Support Enabled
INFO - 2018-06-21 22:22:05 --> Utf8 Class Initialized
INFO - 2018-06-21 22:22:05 --> URI Class Initialized
INFO - 2018-06-21 22:22:05 --> Router Class Initialized
INFO - 2018-06-21 22:22:05 --> Output Class Initialized
INFO - 2018-06-21 22:22:05 --> Security Class Initialized
DEBUG - 2018-06-21 22:22:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 22:22:05 --> Input Class Initialized
INFO - 2018-06-21 22:22:05 --> Language Class Initialized
INFO - 2018-06-21 22:22:05 --> Language Class Initialized
INFO - 2018-06-21 22:22:05 --> Config Class Initialized
INFO - 2018-06-21 22:22:05 --> Loader Class Initialized
DEBUG - 2018-06-21 22:22:05 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 22:22:05 --> Helper loaded: url_helper
INFO - 2018-06-21 22:22:05 --> Helper loaded: form_helper
INFO - 2018-06-21 22:22:05 --> Helper loaded: date_helper
INFO - 2018-06-21 22:22:05 --> Helper loaded: util_helper
INFO - 2018-06-21 22:22:05 --> Helper loaded: text_helper
INFO - 2018-06-21 22:22:05 --> Helper loaded: string_helper
INFO - 2018-06-21 22:22:05 --> Database Driver Class Initialized
DEBUG - 2018-06-21 22:22:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 22:22:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 22:22:05 --> Email Class Initialized
INFO - 2018-06-21 22:22:05 --> Controller Class Initialized
DEBUG - 2018-06-21 22:22:05 --> Users MX_Controller Initialized
DEBUG - 2018-06-21 22:22:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 22:22:05 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 22:22:05 --> Login MX_Controller Initialized
INFO - 2018-06-21 22:22:05 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 22:22:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-21 22:22:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-06-21 22:22:05 --> Final output sent to browser
DEBUG - 2018-06-21 22:22:05 --> Total execution time: 0.5779
INFO - 2018-06-21 22:23:45 --> Config Class Initialized
INFO - 2018-06-21 22:23:45 --> Hooks Class Initialized
DEBUG - 2018-06-21 22:23:45 --> UTF-8 Support Enabled
INFO - 2018-06-21 22:23:45 --> Utf8 Class Initialized
INFO - 2018-06-21 22:23:45 --> URI Class Initialized
INFO - 2018-06-21 22:23:45 --> Router Class Initialized
INFO - 2018-06-21 22:23:45 --> Output Class Initialized
INFO - 2018-06-21 22:23:45 --> Security Class Initialized
DEBUG - 2018-06-21 22:23:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 22:23:45 --> Input Class Initialized
INFO - 2018-06-21 22:23:45 --> Language Class Initialized
INFO - 2018-06-21 22:23:45 --> Language Class Initialized
INFO - 2018-06-21 22:23:45 --> Config Class Initialized
INFO - 2018-06-21 22:23:45 --> Loader Class Initialized
DEBUG - 2018-06-21 22:23:45 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 22:23:45 --> Helper loaded: url_helper
INFO - 2018-06-21 22:23:45 --> Helper loaded: form_helper
INFO - 2018-06-21 22:23:45 --> Helper loaded: date_helper
INFO - 2018-06-21 22:23:45 --> Helper loaded: util_helper
INFO - 2018-06-21 22:23:45 --> Helper loaded: text_helper
INFO - 2018-06-21 22:23:45 --> Helper loaded: string_helper
INFO - 2018-06-21 22:23:45 --> Database Driver Class Initialized
DEBUG - 2018-06-21 22:23:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 22:23:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 22:23:45 --> Email Class Initialized
INFO - 2018-06-21 22:23:45 --> Controller Class Initialized
DEBUG - 2018-06-21 22:23:45 --> Admin MX_Controller Initialized
INFO - 2018-06-21 22:23:45 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 22:23:45 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 22:23:45 --> Login MX_Controller Initialized
DEBUG - 2018-06-21 22:23:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 22:23:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-21 22:23:46 --> Final output sent to browser
DEBUG - 2018-06-21 22:23:46 --> Total execution time: 0.6356
INFO - 2018-06-21 22:23:51 --> Config Class Initialized
INFO - 2018-06-21 22:23:51 --> Hooks Class Initialized
DEBUG - 2018-06-21 22:23:51 --> UTF-8 Support Enabled
INFO - 2018-06-21 22:23:51 --> Utf8 Class Initialized
INFO - 2018-06-21 22:23:51 --> URI Class Initialized
INFO - 2018-06-21 22:23:51 --> Router Class Initialized
INFO - 2018-06-21 22:23:51 --> Output Class Initialized
INFO - 2018-06-21 22:23:51 --> Security Class Initialized
DEBUG - 2018-06-21 22:23:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 22:23:51 --> Input Class Initialized
INFO - 2018-06-21 22:23:51 --> Language Class Initialized
INFO - 2018-06-21 22:23:51 --> Language Class Initialized
INFO - 2018-06-21 22:23:51 --> Config Class Initialized
INFO - 2018-06-21 22:23:51 --> Loader Class Initialized
DEBUG - 2018-06-21 22:23:51 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 22:23:51 --> Helper loaded: url_helper
INFO - 2018-06-21 22:23:51 --> Helper loaded: form_helper
INFO - 2018-06-21 22:23:51 --> Helper loaded: date_helper
INFO - 2018-06-21 22:23:51 --> Helper loaded: util_helper
INFO - 2018-06-21 22:23:51 --> Helper loaded: text_helper
INFO - 2018-06-21 22:23:52 --> Helper loaded: string_helper
INFO - 2018-06-21 22:23:52 --> Database Driver Class Initialized
DEBUG - 2018-06-21 22:23:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 22:23:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 22:23:52 --> Email Class Initialized
INFO - 2018-06-21 22:23:52 --> Controller Class Initialized
DEBUG - 2018-06-21 22:23:52 --> Home MX_Controller Initialized
DEBUG - 2018-06-21 22:23:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-21 22:23:52 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 22:23:52 --> Login MX_Controller Initialized
INFO - 2018-06-21 22:23:52 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 22:23:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 22:23:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-21 22:23:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-21 22:23:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-21 22:23:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-21 22:23:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-21 22:23:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-21 22:23:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-06-21 22:23:52 --> Final output sent to browser
DEBUG - 2018-06-21 22:23:52 --> Total execution time: 0.6714
INFO - 2018-06-21 22:23:52 --> Config Class Initialized
INFO - 2018-06-21 22:23:52 --> Config Class Initialized
INFO - 2018-06-21 22:23:52 --> Hooks Class Initialized
INFO - 2018-06-21 22:23:52 --> Hooks Class Initialized
DEBUG - 2018-06-21 22:23:52 --> UTF-8 Support Enabled
DEBUG - 2018-06-21 22:23:52 --> UTF-8 Support Enabled
INFO - 2018-06-21 22:23:52 --> Utf8 Class Initialized
INFO - 2018-06-21 22:23:52 --> Utf8 Class Initialized
INFO - 2018-06-21 22:23:52 --> URI Class Initialized
INFO - 2018-06-21 22:23:52 --> Router Class Initialized
INFO - 2018-06-21 22:23:53 --> Output Class Initialized
INFO - 2018-06-21 22:23:53 --> Security Class Initialized
DEBUG - 2018-06-21 22:23:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 22:23:53 --> URI Class Initialized
INFO - 2018-06-21 22:23:53 --> Input Class Initialized
INFO - 2018-06-21 22:23:53 --> Language Class Initialized
ERROR - 2018-06-21 22:23:53 --> 404 Page Not Found: /index
INFO - 2018-06-21 22:23:53 --> Router Class Initialized
INFO - 2018-06-21 22:23:53 --> Config Class Initialized
INFO - 2018-06-21 22:23:53 --> Hooks Class Initialized
INFO - 2018-06-21 22:23:53 --> Output Class Initialized
DEBUG - 2018-06-21 22:23:53 --> UTF-8 Support Enabled
INFO - 2018-06-21 22:23:53 --> Security Class Initialized
INFO - 2018-06-21 22:23:53 --> Utf8 Class Initialized
DEBUG - 2018-06-21 22:23:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 22:23:53 --> URI Class Initialized
INFO - 2018-06-21 22:23:53 --> Input Class Initialized
INFO - 2018-06-21 22:23:53 --> Router Class Initialized
INFO - 2018-06-21 22:23:53 --> Language Class Initialized
ERROR - 2018-06-21 22:23:53 --> 404 Page Not Found: /index
INFO - 2018-06-21 22:23:53 --> Output Class Initialized
INFO - 2018-06-21 22:23:53 --> Security Class Initialized
DEBUG - 2018-06-21 22:23:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 22:23:53 --> Input Class Initialized
INFO - 2018-06-21 22:23:53 --> Language Class Initialized
ERROR - 2018-06-21 22:23:53 --> 404 Page Not Found: /index
INFO - 2018-06-21 22:23:53 --> Config Class Initialized
INFO - 2018-06-21 22:23:53 --> Hooks Class Initialized
DEBUG - 2018-06-21 22:23:53 --> UTF-8 Support Enabled
INFO - 2018-06-21 22:23:53 --> Utf8 Class Initialized
INFO - 2018-06-21 22:23:53 --> URI Class Initialized
INFO - 2018-06-21 22:23:53 --> Router Class Initialized
INFO - 2018-06-21 22:23:53 --> Output Class Initialized
INFO - 2018-06-21 22:23:53 --> Security Class Initialized
DEBUG - 2018-06-21 22:23:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 22:23:53 --> Input Class Initialized
INFO - 2018-06-21 22:23:53 --> Language Class Initialized
ERROR - 2018-06-21 22:23:53 --> 404 Page Not Found: /index
INFO - 2018-06-21 22:23:56 --> Config Class Initialized
INFO - 2018-06-21 22:23:56 --> Hooks Class Initialized
DEBUG - 2018-06-21 22:23:56 --> UTF-8 Support Enabled
INFO - 2018-06-21 22:23:56 --> Utf8 Class Initialized
INFO - 2018-06-21 22:23:56 --> URI Class Initialized
INFO - 2018-06-21 22:23:56 --> Router Class Initialized
INFO - 2018-06-21 22:23:56 --> Output Class Initialized
INFO - 2018-06-21 22:23:56 --> Security Class Initialized
DEBUG - 2018-06-21 22:23:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 22:23:56 --> Input Class Initialized
INFO - 2018-06-21 22:23:56 --> Language Class Initialized
INFO - 2018-06-21 22:23:57 --> Language Class Initialized
INFO - 2018-06-21 22:23:57 --> Config Class Initialized
INFO - 2018-06-21 22:23:57 --> Loader Class Initialized
DEBUG - 2018-06-21 22:23:57 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 22:23:57 --> Helper loaded: url_helper
INFO - 2018-06-21 22:23:57 --> Helper loaded: form_helper
INFO - 2018-06-21 22:23:57 --> Helper loaded: date_helper
INFO - 2018-06-21 22:23:57 --> Helper loaded: util_helper
INFO - 2018-06-21 22:23:57 --> Helper loaded: text_helper
INFO - 2018-06-21 22:23:57 --> Helper loaded: string_helper
INFO - 2018-06-21 22:23:57 --> Database Driver Class Initialized
DEBUG - 2018-06-21 22:23:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 22:23:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 22:23:57 --> Email Class Initialized
INFO - 2018-06-21 22:23:57 --> Controller Class Initialized
DEBUG - 2018-06-21 22:23:57 --> Login MX_Controller Initialized
INFO - 2018-06-21 22:23:57 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 22:23:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 22:23:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-21 22:23:57 --> 6 Loggedout
INFO - 2018-06-21 22:23:57 --> Config Class Initialized
INFO - 2018-06-21 22:23:57 --> Hooks Class Initialized
DEBUG - 2018-06-21 22:23:57 --> UTF-8 Support Enabled
INFO - 2018-06-21 22:23:57 --> Utf8 Class Initialized
INFO - 2018-06-21 22:23:57 --> URI Class Initialized
INFO - 2018-06-21 22:23:57 --> Router Class Initialized
INFO - 2018-06-21 22:23:57 --> Output Class Initialized
INFO - 2018-06-21 22:23:57 --> Security Class Initialized
DEBUG - 2018-06-21 22:23:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 22:23:57 --> Input Class Initialized
INFO - 2018-06-21 22:23:57 --> Language Class Initialized
INFO - 2018-06-21 22:23:57 --> Language Class Initialized
INFO - 2018-06-21 22:23:57 --> Config Class Initialized
INFO - 2018-06-21 22:23:57 --> Loader Class Initialized
DEBUG - 2018-06-21 22:23:57 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 22:23:57 --> Helper loaded: url_helper
INFO - 2018-06-21 22:23:57 --> Helper loaded: form_helper
INFO - 2018-06-21 22:23:57 --> Helper loaded: date_helper
INFO - 2018-06-21 22:23:57 --> Helper loaded: util_helper
INFO - 2018-06-21 22:23:57 --> Helper loaded: text_helper
INFO - 2018-06-21 22:23:57 --> Helper loaded: string_helper
INFO - 2018-06-21 22:23:57 --> Database Driver Class Initialized
DEBUG - 2018-06-21 22:23:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 22:23:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 22:23:57 --> Email Class Initialized
INFO - 2018-06-21 22:23:57 --> Controller Class Initialized
DEBUG - 2018-06-21 22:23:57 --> Home MX_Controller Initialized
DEBUG - 2018-06-21 22:23:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-21 22:23:57 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 22:23:57 --> Login MX_Controller Initialized
INFO - 2018-06-21 22:23:57 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 22:23:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 22:23:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-21 22:23:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-06-21 22:24:11 --> Config Class Initialized
INFO - 2018-06-21 22:24:11 --> Hooks Class Initialized
DEBUG - 2018-06-21 22:24:11 --> UTF-8 Support Enabled
INFO - 2018-06-21 22:24:11 --> Utf8 Class Initialized
INFO - 2018-06-21 22:24:11 --> URI Class Initialized
INFO - 2018-06-21 22:24:11 --> Router Class Initialized
INFO - 2018-06-21 22:24:11 --> Output Class Initialized
INFO - 2018-06-21 22:24:11 --> Security Class Initialized
DEBUG - 2018-06-21 22:24:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 22:24:11 --> Input Class Initialized
INFO - 2018-06-21 22:24:11 --> Language Class Initialized
INFO - 2018-06-21 22:24:11 --> Language Class Initialized
INFO - 2018-06-21 22:24:11 --> Config Class Initialized
INFO - 2018-06-21 22:24:11 --> Loader Class Initialized
DEBUG - 2018-06-21 22:24:11 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 22:24:11 --> Helper loaded: url_helper
INFO - 2018-06-21 22:24:11 --> Helper loaded: form_helper
INFO - 2018-06-21 22:24:11 --> Helper loaded: date_helper
INFO - 2018-06-21 22:24:11 --> Helper loaded: util_helper
INFO - 2018-06-21 22:24:11 --> Helper loaded: text_helper
INFO - 2018-06-21 22:24:11 --> Helper loaded: string_helper
INFO - 2018-06-21 22:24:11 --> Database Driver Class Initialized
DEBUG - 2018-06-21 22:24:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 22:24:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 22:24:11 --> Email Class Initialized
INFO - 2018-06-21 22:24:11 --> Controller Class Initialized
DEBUG - 2018-06-21 22:24:11 --> Login MX_Controller Initialized
INFO - 2018-06-21 22:24:11 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 22:24:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 22:24:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-21 22:24:11 --> Email starts for user@colin.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-06-21 22:24:11 --> Login status user@colin.com - blocked
INFO - 2018-06-21 22:24:11 --> Final output sent to browser
DEBUG - 2018-06-21 22:24:11 --> Total execution time: 0.5002
INFO - 2018-06-21 22:24:16 --> Config Class Initialized
INFO - 2018-06-21 22:24:16 --> Hooks Class Initialized
DEBUG - 2018-06-21 22:24:16 --> UTF-8 Support Enabled
INFO - 2018-06-21 22:24:16 --> Utf8 Class Initialized
INFO - 2018-06-21 22:24:16 --> URI Class Initialized
INFO - 2018-06-21 22:24:16 --> Router Class Initialized
INFO - 2018-06-21 22:24:16 --> Output Class Initialized
INFO - 2018-06-21 22:24:16 --> Security Class Initialized
DEBUG - 2018-06-21 22:24:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 22:24:16 --> Input Class Initialized
INFO - 2018-06-21 22:24:16 --> Language Class Initialized
INFO - 2018-06-21 22:24:16 --> Language Class Initialized
INFO - 2018-06-21 22:24:16 --> Config Class Initialized
INFO - 2018-06-21 22:24:16 --> Loader Class Initialized
DEBUG - 2018-06-21 22:24:16 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 22:24:16 --> Helper loaded: url_helper
INFO - 2018-06-21 22:24:16 --> Helper loaded: form_helper
INFO - 2018-06-21 22:24:16 --> Helper loaded: date_helper
INFO - 2018-06-21 22:24:16 --> Helper loaded: util_helper
INFO - 2018-06-21 22:24:16 --> Helper loaded: text_helper
INFO - 2018-06-21 22:24:16 --> Helper loaded: string_helper
INFO - 2018-06-21 22:24:16 --> Database Driver Class Initialized
DEBUG - 2018-06-21 22:24:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 22:24:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 22:24:16 --> Email Class Initialized
INFO - 2018-06-21 22:24:16 --> Controller Class Initialized
DEBUG - 2018-06-21 22:24:16 --> Admin MX_Controller Initialized
INFO - 2018-06-21 22:24:16 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 22:24:16 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 22:24:16 --> Login MX_Controller Initialized
DEBUG - 2018-06-21 22:24:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 22:24:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-21 22:24:16 --> Final output sent to browser
DEBUG - 2018-06-21 22:24:16 --> Total execution time: 0.7023
INFO - 2018-06-21 22:24:19 --> Config Class Initialized
INFO - 2018-06-21 22:24:19 --> Hooks Class Initialized
DEBUG - 2018-06-21 22:24:19 --> UTF-8 Support Enabled
INFO - 2018-06-21 22:24:20 --> Utf8 Class Initialized
INFO - 2018-06-21 22:24:20 --> URI Class Initialized
INFO - 2018-06-21 22:24:20 --> Router Class Initialized
INFO - 2018-06-21 22:24:20 --> Output Class Initialized
INFO - 2018-06-21 22:24:20 --> Security Class Initialized
DEBUG - 2018-06-21 22:24:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 22:24:20 --> Input Class Initialized
INFO - 2018-06-21 22:24:20 --> Language Class Initialized
INFO - 2018-06-21 22:24:20 --> Language Class Initialized
INFO - 2018-06-21 22:24:20 --> Config Class Initialized
INFO - 2018-06-21 22:24:20 --> Loader Class Initialized
DEBUG - 2018-06-21 22:24:20 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 22:24:20 --> Helper loaded: url_helper
INFO - 2018-06-21 22:24:20 --> Helper loaded: form_helper
INFO - 2018-06-21 22:24:20 --> Helper loaded: date_helper
INFO - 2018-06-21 22:24:20 --> Helper loaded: util_helper
INFO - 2018-06-21 22:24:20 --> Helper loaded: text_helper
INFO - 2018-06-21 22:24:20 --> Helper loaded: string_helper
INFO - 2018-06-21 22:24:20 --> Database Driver Class Initialized
DEBUG - 2018-06-21 22:24:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 22:24:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 22:24:20 --> Email Class Initialized
INFO - 2018-06-21 22:24:20 --> Controller Class Initialized
DEBUG - 2018-06-21 22:24:20 --> Login MX_Controller Initialized
INFO - 2018-06-21 22:24:20 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 22:24:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 22:24:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-21 22:24:20 --> Email starts for user@colin.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-06-21 22:24:20 --> User session created for 4
INFO - 2018-06-21 22:24:20 --> Login status user@colin.com - success
INFO - 2018-06-21 22:24:20 --> Final output sent to browser
DEBUG - 2018-06-21 22:24:20 --> Total execution time: 0.6321
INFO - 2018-06-21 22:24:20 --> Config Class Initialized
INFO - 2018-06-21 22:24:20 --> Hooks Class Initialized
DEBUG - 2018-06-21 22:24:20 --> UTF-8 Support Enabled
INFO - 2018-06-21 22:24:20 --> Utf8 Class Initialized
INFO - 2018-06-21 22:24:20 --> URI Class Initialized
INFO - 2018-06-21 22:24:20 --> Router Class Initialized
INFO - 2018-06-21 22:24:20 --> Output Class Initialized
INFO - 2018-06-21 22:24:20 --> Security Class Initialized
DEBUG - 2018-06-21 22:24:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 22:24:20 --> Input Class Initialized
INFO - 2018-06-21 22:24:20 --> Language Class Initialized
INFO - 2018-06-21 22:24:20 --> Language Class Initialized
INFO - 2018-06-21 22:24:20 --> Config Class Initialized
INFO - 2018-06-21 22:24:20 --> Loader Class Initialized
DEBUG - 2018-06-21 22:24:20 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 22:24:20 --> Helper loaded: url_helper
INFO - 2018-06-21 22:24:20 --> Helper loaded: form_helper
INFO - 2018-06-21 22:24:20 --> Helper loaded: date_helper
INFO - 2018-06-21 22:24:20 --> Helper loaded: util_helper
INFO - 2018-06-21 22:24:20 --> Helper loaded: text_helper
INFO - 2018-06-21 22:24:20 --> Helper loaded: string_helper
INFO - 2018-06-21 22:24:21 --> Database Driver Class Initialized
DEBUG - 2018-06-21 22:24:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 22:24:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 22:24:21 --> Email Class Initialized
INFO - 2018-06-21 22:24:21 --> Controller Class Initialized
DEBUG - 2018-06-21 22:24:21 --> Home MX_Controller Initialized
DEBUG - 2018-06-21 22:24:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-21 22:24:21 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 22:24:21 --> Login MX_Controller Initialized
INFO - 2018-06-21 22:24:21 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 22:24:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 22:24:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-21 22:24:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-21 22:24:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-21 22:24:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-21 22:24:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-21 22:24:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-21 22:24:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-06-21 22:24:21 --> Final output sent to browser
DEBUG - 2018-06-21 22:24:21 --> Total execution time: 0.7027
INFO - 2018-06-21 22:24:21 --> Config Class Initialized
INFO - 2018-06-21 22:24:21 --> Hooks Class Initialized
DEBUG - 2018-06-21 22:24:21 --> UTF-8 Support Enabled
INFO - 2018-06-21 22:24:21 --> Utf8 Class Initialized
INFO - 2018-06-21 22:24:21 --> URI Class Initialized
INFO - 2018-06-21 22:24:21 --> Router Class Initialized
INFO - 2018-06-21 22:24:21 --> Output Class Initialized
INFO - 2018-06-21 22:24:21 --> Security Class Initialized
DEBUG - 2018-06-21 22:24:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 22:24:21 --> Input Class Initialized
INFO - 2018-06-21 22:24:21 --> Language Class Initialized
ERROR - 2018-06-21 22:24:21 --> 404 Page Not Found: /index
INFO - 2018-06-21 22:24:21 --> Config Class Initialized
INFO - 2018-06-21 22:24:22 --> Hooks Class Initialized
DEBUG - 2018-06-21 22:24:22 --> UTF-8 Support Enabled
INFO - 2018-06-21 22:24:22 --> Utf8 Class Initialized
INFO - 2018-06-21 22:24:22 --> URI Class Initialized
INFO - 2018-06-21 22:24:22 --> Router Class Initialized
INFO - 2018-06-21 22:24:22 --> Output Class Initialized
INFO - 2018-06-21 22:24:22 --> Security Class Initialized
DEBUG - 2018-06-21 22:24:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 22:24:22 --> Input Class Initialized
INFO - 2018-06-21 22:24:22 --> Language Class Initialized
ERROR - 2018-06-21 22:24:22 --> 404 Page Not Found: /index
INFO - 2018-06-21 22:24:22 --> Config Class Initialized
INFO - 2018-06-21 22:24:22 --> Hooks Class Initialized
DEBUG - 2018-06-21 22:24:22 --> UTF-8 Support Enabled
INFO - 2018-06-21 22:24:22 --> Utf8 Class Initialized
INFO - 2018-06-21 22:24:22 --> URI Class Initialized
INFO - 2018-06-21 22:24:22 --> Router Class Initialized
INFO - 2018-06-21 22:24:22 --> Output Class Initialized
INFO - 2018-06-21 22:24:22 --> Security Class Initialized
DEBUG - 2018-06-21 22:24:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 22:24:22 --> Input Class Initialized
INFO - 2018-06-21 22:24:22 --> Language Class Initialized
ERROR - 2018-06-21 22:24:22 --> 404 Page Not Found: /index
INFO - 2018-06-21 22:58:24 --> Config Class Initialized
INFO - 2018-06-21 22:58:24 --> Hooks Class Initialized
DEBUG - 2018-06-21 22:58:24 --> UTF-8 Support Enabled
INFO - 2018-06-21 22:58:24 --> Utf8 Class Initialized
INFO - 2018-06-21 22:58:24 --> URI Class Initialized
INFO - 2018-06-21 22:58:24 --> Router Class Initialized
INFO - 2018-06-21 22:58:24 --> Output Class Initialized
INFO - 2018-06-21 22:58:24 --> Security Class Initialized
DEBUG - 2018-06-21 22:58:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 22:58:24 --> Input Class Initialized
INFO - 2018-06-21 22:58:24 --> Language Class Initialized
INFO - 2018-06-21 22:58:24 --> Language Class Initialized
INFO - 2018-06-21 22:58:24 --> Config Class Initialized
INFO - 2018-06-21 22:58:24 --> Loader Class Initialized
DEBUG - 2018-06-21 22:58:24 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 22:58:24 --> Helper loaded: url_helper
INFO - 2018-06-21 22:58:24 --> Helper loaded: form_helper
INFO - 2018-06-21 22:58:24 --> Helper loaded: date_helper
INFO - 2018-06-21 22:58:24 --> Helper loaded: util_helper
INFO - 2018-06-21 22:58:24 --> Helper loaded: text_helper
INFO - 2018-06-21 22:58:24 --> Helper loaded: string_helper
INFO - 2018-06-21 22:58:24 --> Database Driver Class Initialized
DEBUG - 2018-06-21 22:58:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 22:58:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 22:58:24 --> Email Class Initialized
INFO - 2018-06-21 22:58:24 --> Controller Class Initialized
DEBUG - 2018-06-21 22:58:24 --> Home MX_Controller Initialized
DEBUG - 2018-06-21 22:58:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-21 22:58:24 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-21 22:58:24 --> Login MX_Controller Initialized
INFO - 2018-06-21 22:58:24 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-21 22:58:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-21 22:58:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-21 22:58:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-21 22:58:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-21 22:58:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-21 22:58:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-21 22:58:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-21 22:58:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-06-21 22:58:24 --> Final output sent to browser
DEBUG - 2018-06-21 22:58:24 --> Total execution time: 0.6725
INFO - 2018-06-21 22:58:25 --> Config Class Initialized
INFO - 2018-06-21 22:58:25 --> Config Class Initialized
INFO - 2018-06-21 22:58:25 --> Hooks Class Initialized
INFO - 2018-06-21 22:58:25 --> Hooks Class Initialized
DEBUG - 2018-06-21 22:58:25 --> UTF-8 Support Enabled
DEBUG - 2018-06-21 22:58:25 --> UTF-8 Support Enabled
INFO - 2018-06-21 22:58:25 --> Utf8 Class Initialized
INFO - 2018-06-21 22:58:25 --> Utf8 Class Initialized
INFO - 2018-06-21 22:58:25 --> URI Class Initialized
INFO - 2018-06-21 22:58:25 --> URI Class Initialized
INFO - 2018-06-21 22:58:25 --> Router Class Initialized
INFO - 2018-06-21 22:58:25 --> Router Class Initialized
INFO - 2018-06-21 22:58:25 --> Output Class Initialized
INFO - 2018-06-21 22:58:25 --> Output Class Initialized
INFO - 2018-06-21 22:58:25 --> Security Class Initialized
DEBUG - 2018-06-21 22:58:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 22:58:25 --> Input Class Initialized
INFO - 2018-06-21 22:58:25 --> Language Class Initialized
ERROR - 2018-06-21 22:58:25 --> 404 Page Not Found: /index
INFO - 2018-06-21 22:58:25 --> Config Class Initialized
INFO - 2018-06-21 22:58:25 --> Hooks Class Initialized
DEBUG - 2018-06-21 22:58:25 --> UTF-8 Support Enabled
INFO - 2018-06-21 22:58:25 --> Utf8 Class Initialized
INFO - 2018-06-21 22:58:25 --> URI Class Initialized
INFO - 2018-06-21 22:58:25 --> Security Class Initialized
DEBUG - 2018-06-21 22:58:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 22:58:25 --> Router Class Initialized
INFO - 2018-06-21 22:58:25 --> Output Class Initialized
INFO - 2018-06-21 22:58:25 --> Input Class Initialized
INFO - 2018-06-21 22:58:25 --> Security Class Initialized
DEBUG - 2018-06-21 22:58:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 22:58:25 --> Input Class Initialized
INFO - 2018-06-21 22:58:26 --> Language Class Initialized
INFO - 2018-06-21 22:58:26 --> Language Class Initialized
ERROR - 2018-06-21 22:58:26 --> 404 Page Not Found: /index
ERROR - 2018-06-21 22:58:26 --> 404 Page Not Found: /index
INFO - 2018-06-21 22:58:26 --> Config Class Initialized
INFO - 2018-06-21 22:58:26 --> Hooks Class Initialized
DEBUG - 2018-06-21 22:58:26 --> UTF-8 Support Enabled
INFO - 2018-06-21 22:58:26 --> Utf8 Class Initialized
INFO - 2018-06-21 22:58:26 --> URI Class Initialized
INFO - 2018-06-21 22:58:26 --> Router Class Initialized
INFO - 2018-06-21 22:58:26 --> Output Class Initialized
INFO - 2018-06-21 22:58:26 --> Security Class Initialized
DEBUG - 2018-06-21 22:58:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 22:58:26 --> Input Class Initialized
INFO - 2018-06-21 22:58:26 --> Language Class Initialized
ERROR - 2018-06-21 22:58:26 --> 404 Page Not Found: /index
INFO - 2018-06-21 23:01:11 --> Config Class Initialized
INFO - 2018-06-21 23:01:11 --> Hooks Class Initialized
DEBUG - 2018-06-21 23:01:11 --> UTF-8 Support Enabled
INFO - 2018-06-21 23:01:12 --> Utf8 Class Initialized
INFO - 2018-06-21 23:01:12 --> URI Class Initialized
INFO - 2018-06-21 23:01:12 --> Router Class Initialized
INFO - 2018-06-21 23:01:12 --> Output Class Initialized
INFO - 2018-06-21 23:01:12 --> Security Class Initialized
DEBUG - 2018-06-21 23:01:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 23:01:12 --> Input Class Initialized
INFO - 2018-06-21 23:01:12 --> Language Class Initialized
INFO - 2018-06-21 23:01:12 --> Language Class Initialized
INFO - 2018-06-21 23:01:12 --> Config Class Initialized
INFO - 2018-06-21 23:01:12 --> Loader Class Initialized
DEBUG - 2018-06-21 23:01:12 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 23:01:12 --> Helper loaded: url_helper
INFO - 2018-06-21 23:01:12 --> Helper loaded: form_helper
INFO - 2018-06-21 23:01:12 --> Helper loaded: date_helper
INFO - 2018-06-21 23:01:12 --> Helper loaded: util_helper
INFO - 2018-06-21 23:01:12 --> Helper loaded: text_helper
INFO - 2018-06-21 23:01:12 --> Helper loaded: string_helper
INFO - 2018-06-21 23:01:12 --> Database Driver Class Initialized
DEBUG - 2018-06-21 23:01:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 23:01:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 23:01:12 --> Email Class Initialized
INFO - 2018-06-21 23:01:12 --> Controller Class Initialized
DEBUG - 2018-06-21 23:01:12 --> Home MX_Controller Initialized
DEBUG - 2018-06-21 23:01:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-21 23:01:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-06-21 23:01:12 --> Final output sent to browser
DEBUG - 2018-06-21 23:01:12 --> Total execution time: 0.5216
INFO - 2018-06-21 23:01:12 --> Config Class Initialized
INFO - 2018-06-21 23:01:12 --> Hooks Class Initialized
DEBUG - 2018-06-21 23:01:12 --> UTF-8 Support Enabled
INFO - 2018-06-21 23:01:12 --> Utf8 Class Initialized
INFO - 2018-06-21 23:01:12 --> URI Class Initialized
INFO - 2018-06-21 23:01:12 --> Router Class Initialized
INFO - 2018-06-21 23:01:12 --> Output Class Initialized
INFO - 2018-06-21 23:01:12 --> Security Class Initialized
DEBUG - 2018-06-21 23:01:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 23:01:12 --> Input Class Initialized
INFO - 2018-06-21 23:01:12 --> Language Class Initialized
INFO - 2018-06-21 23:01:12 --> Language Class Initialized
INFO - 2018-06-21 23:01:12 --> Config Class Initialized
INFO - 2018-06-21 23:01:12 --> Loader Class Initialized
DEBUG - 2018-06-21 23:01:12 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 23:01:12 --> Helper loaded: url_helper
INFO - 2018-06-21 23:01:12 --> Helper loaded: form_helper
INFO - 2018-06-21 23:01:12 --> Helper loaded: date_helper
INFO - 2018-06-21 23:01:12 --> Helper loaded: util_helper
INFO - 2018-06-21 23:01:12 --> Helper loaded: text_helper
INFO - 2018-06-21 23:01:12 --> Helper loaded: string_helper
INFO - 2018-06-21 23:01:12 --> Database Driver Class Initialized
DEBUG - 2018-06-21 23:01:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 23:01:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 23:01:12 --> Email Class Initialized
INFO - 2018-06-21 23:01:12 --> Controller Class Initialized
DEBUG - 2018-06-21 23:01:12 --> Home MX_Controller Initialized
DEBUG - 2018-06-21 23:01:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-06-21 23:03:08 --> Config Class Initialized
INFO - 2018-06-21 23:03:08 --> Hooks Class Initialized
DEBUG - 2018-06-21 23:03:08 --> UTF-8 Support Enabled
INFO - 2018-06-21 23:03:08 --> Utf8 Class Initialized
INFO - 2018-06-21 23:03:08 --> URI Class Initialized
INFO - 2018-06-21 23:03:08 --> Router Class Initialized
INFO - 2018-06-21 23:03:08 --> Output Class Initialized
INFO - 2018-06-21 23:03:08 --> Security Class Initialized
DEBUG - 2018-06-21 23:03:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 23:03:08 --> Input Class Initialized
INFO - 2018-06-21 23:03:08 --> Language Class Initialized
INFO - 2018-06-21 23:03:08 --> Language Class Initialized
INFO - 2018-06-21 23:03:08 --> Config Class Initialized
INFO - 2018-06-21 23:03:08 --> Loader Class Initialized
DEBUG - 2018-06-21 23:03:08 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 23:03:08 --> Helper loaded: url_helper
INFO - 2018-06-21 23:03:08 --> Helper loaded: form_helper
INFO - 2018-06-21 23:03:08 --> Helper loaded: date_helper
INFO - 2018-06-21 23:03:08 --> Helper loaded: util_helper
INFO - 2018-06-21 23:03:08 --> Helper loaded: text_helper
INFO - 2018-06-21 23:03:08 --> Helper loaded: string_helper
INFO - 2018-06-21 23:03:08 --> Database Driver Class Initialized
DEBUG - 2018-06-21 23:03:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 23:03:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 23:03:08 --> Email Class Initialized
INFO - 2018-06-21 23:03:08 --> Controller Class Initialized
DEBUG - 2018-06-21 23:03:08 --> Home MX_Controller Initialized
DEBUG - 2018-06-21 23:03:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-21 23:03:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-06-21 23:03:08 --> Final output sent to browser
DEBUG - 2018-06-21 23:03:08 --> Total execution time: 0.5342
INFO - 2018-06-21 23:03:08 --> Config Class Initialized
INFO - 2018-06-21 23:03:08 --> Hooks Class Initialized
DEBUG - 2018-06-21 23:03:08 --> UTF-8 Support Enabled
INFO - 2018-06-21 23:03:08 --> Utf8 Class Initialized
INFO - 2018-06-21 23:03:08 --> URI Class Initialized
INFO - 2018-06-21 23:03:08 --> Router Class Initialized
INFO - 2018-06-21 23:03:08 --> Output Class Initialized
INFO - 2018-06-21 23:03:08 --> Security Class Initialized
DEBUG - 2018-06-21 23:03:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 23:03:08 --> Input Class Initialized
INFO - 2018-06-21 23:03:08 --> Language Class Initialized
INFO - 2018-06-21 23:03:08 --> Language Class Initialized
INFO - 2018-06-21 23:03:08 --> Config Class Initialized
INFO - 2018-06-21 23:03:08 --> Loader Class Initialized
DEBUG - 2018-06-21 23:03:08 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 23:03:09 --> Helper loaded: url_helper
INFO - 2018-06-21 23:03:09 --> Helper loaded: form_helper
INFO - 2018-06-21 23:03:09 --> Helper loaded: date_helper
INFO - 2018-06-21 23:03:09 --> Helper loaded: util_helper
INFO - 2018-06-21 23:03:09 --> Helper loaded: text_helper
INFO - 2018-06-21 23:03:09 --> Helper loaded: string_helper
INFO - 2018-06-21 23:03:09 --> Database Driver Class Initialized
DEBUG - 2018-06-21 23:03:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 23:03:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 23:03:09 --> Email Class Initialized
INFO - 2018-06-21 23:03:09 --> Controller Class Initialized
DEBUG - 2018-06-21 23:03:09 --> Home MX_Controller Initialized
DEBUG - 2018-06-21 23:03:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-06-21 23:03:10 --> Config Class Initialized
INFO - 2018-06-21 23:03:10 --> Hooks Class Initialized
DEBUG - 2018-06-21 23:03:10 --> UTF-8 Support Enabled
INFO - 2018-06-21 23:03:10 --> Utf8 Class Initialized
INFO - 2018-06-21 23:03:10 --> URI Class Initialized
INFO - 2018-06-21 23:03:10 --> Router Class Initialized
INFO - 2018-06-21 23:03:10 --> Output Class Initialized
INFO - 2018-06-21 23:03:10 --> Security Class Initialized
DEBUG - 2018-06-21 23:03:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 23:03:10 --> Input Class Initialized
INFO - 2018-06-21 23:03:10 --> Language Class Initialized
INFO - 2018-06-21 23:03:10 --> Language Class Initialized
INFO - 2018-06-21 23:03:10 --> Config Class Initialized
INFO - 2018-06-21 23:03:10 --> Loader Class Initialized
DEBUG - 2018-06-21 23:03:10 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 23:03:10 --> Helper loaded: url_helper
INFO - 2018-06-21 23:03:10 --> Helper loaded: form_helper
INFO - 2018-06-21 23:03:10 --> Helper loaded: date_helper
INFO - 2018-06-21 23:03:10 --> Helper loaded: util_helper
INFO - 2018-06-21 23:03:10 --> Helper loaded: text_helper
INFO - 2018-06-21 23:03:10 --> Helper loaded: string_helper
INFO - 2018-06-21 23:03:10 --> Database Driver Class Initialized
DEBUG - 2018-06-21 23:03:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 23:03:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 23:03:10 --> Email Class Initialized
INFO - 2018-06-21 23:03:10 --> Controller Class Initialized
DEBUG - 2018-06-21 23:03:10 --> Home MX_Controller Initialized
DEBUG - 2018-06-21 23:03:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-21 23:03:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-06-21 23:03:10 --> Final output sent to browser
DEBUG - 2018-06-21 23:03:10 --> Total execution time: 0.5390
INFO - 2018-06-21 23:03:10 --> Config Class Initialized
INFO - 2018-06-21 23:03:10 --> Hooks Class Initialized
DEBUG - 2018-06-21 23:03:10 --> UTF-8 Support Enabled
INFO - 2018-06-21 23:03:10 --> Utf8 Class Initialized
INFO - 2018-06-21 23:03:10 --> URI Class Initialized
INFO - 2018-06-21 23:03:10 --> Router Class Initialized
INFO - 2018-06-21 23:03:10 --> Output Class Initialized
INFO - 2018-06-21 23:03:10 --> Security Class Initialized
DEBUG - 2018-06-21 23:03:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 23:03:10 --> Input Class Initialized
INFO - 2018-06-21 23:03:10 --> Language Class Initialized
INFO - 2018-06-21 23:03:10 --> Language Class Initialized
INFO - 2018-06-21 23:03:10 --> Config Class Initialized
INFO - 2018-06-21 23:03:10 --> Loader Class Initialized
DEBUG - 2018-06-21 23:03:11 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 23:03:11 --> Helper loaded: url_helper
INFO - 2018-06-21 23:03:11 --> Helper loaded: form_helper
INFO - 2018-06-21 23:03:11 --> Helper loaded: date_helper
INFO - 2018-06-21 23:03:11 --> Helper loaded: util_helper
INFO - 2018-06-21 23:03:11 --> Helper loaded: text_helper
INFO - 2018-06-21 23:03:11 --> Helper loaded: string_helper
INFO - 2018-06-21 23:03:11 --> Database Driver Class Initialized
DEBUG - 2018-06-21 23:03:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 23:03:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 23:03:11 --> Email Class Initialized
INFO - 2018-06-21 23:03:11 --> Controller Class Initialized
DEBUG - 2018-06-21 23:03:11 --> Home MX_Controller Initialized
DEBUG - 2018-06-21 23:03:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-06-21 23:06:45 --> Config Class Initialized
INFO - 2018-06-21 23:06:45 --> Hooks Class Initialized
DEBUG - 2018-06-21 23:06:45 --> UTF-8 Support Enabled
INFO - 2018-06-21 23:06:45 --> Utf8 Class Initialized
INFO - 2018-06-21 23:06:45 --> URI Class Initialized
INFO - 2018-06-21 23:06:45 --> Router Class Initialized
INFO - 2018-06-21 23:06:45 --> Output Class Initialized
INFO - 2018-06-21 23:06:45 --> Security Class Initialized
DEBUG - 2018-06-21 23:06:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 23:06:46 --> Input Class Initialized
INFO - 2018-06-21 23:06:46 --> Language Class Initialized
INFO - 2018-06-21 23:06:46 --> Language Class Initialized
INFO - 2018-06-21 23:06:46 --> Config Class Initialized
INFO - 2018-06-21 23:06:46 --> Loader Class Initialized
DEBUG - 2018-06-21 23:06:46 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 23:06:46 --> Helper loaded: url_helper
INFO - 2018-06-21 23:06:46 --> Helper loaded: form_helper
INFO - 2018-06-21 23:06:46 --> Helper loaded: date_helper
INFO - 2018-06-21 23:06:46 --> Helper loaded: util_helper
INFO - 2018-06-21 23:06:46 --> Helper loaded: text_helper
INFO - 2018-06-21 23:06:46 --> Helper loaded: string_helper
INFO - 2018-06-21 23:06:46 --> Database Driver Class Initialized
DEBUG - 2018-06-21 23:06:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 23:06:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 23:06:46 --> Email Class Initialized
INFO - 2018-06-21 23:06:46 --> Controller Class Initialized
DEBUG - 2018-06-21 23:06:46 --> Home MX_Controller Initialized
DEBUG - 2018-06-21 23:06:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-21 23:06:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-06-21 23:06:46 --> Final output sent to browser
DEBUG - 2018-06-21 23:06:46 --> Total execution time: 0.5164
INFO - 2018-06-21 23:06:46 --> Config Class Initialized
INFO - 2018-06-21 23:06:46 --> Hooks Class Initialized
DEBUG - 2018-06-21 23:06:46 --> UTF-8 Support Enabled
INFO - 2018-06-21 23:06:46 --> Utf8 Class Initialized
INFO - 2018-06-21 23:06:46 --> URI Class Initialized
INFO - 2018-06-21 23:06:46 --> Router Class Initialized
INFO - 2018-06-21 23:06:46 --> Output Class Initialized
INFO - 2018-06-21 23:06:46 --> Security Class Initialized
DEBUG - 2018-06-21 23:06:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-21 23:06:46 --> Input Class Initialized
INFO - 2018-06-21 23:06:46 --> Language Class Initialized
INFO - 2018-06-21 23:06:46 --> Language Class Initialized
INFO - 2018-06-21 23:06:46 --> Config Class Initialized
INFO - 2018-06-21 23:06:46 --> Loader Class Initialized
DEBUG - 2018-06-21 23:06:46 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-21 23:06:46 --> Helper loaded: url_helper
INFO - 2018-06-21 23:06:46 --> Helper loaded: form_helper
INFO - 2018-06-21 23:06:46 --> Helper loaded: date_helper
INFO - 2018-06-21 23:06:46 --> Helper loaded: util_helper
INFO - 2018-06-21 23:06:46 --> Helper loaded: text_helper
INFO - 2018-06-21 23:06:46 --> Helper loaded: string_helper
INFO - 2018-06-21 23:06:46 --> Database Driver Class Initialized
DEBUG - 2018-06-21 23:06:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-21 23:06:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-21 23:06:46 --> Email Class Initialized
INFO - 2018-06-21 23:06:46 --> Controller Class Initialized
DEBUG - 2018-06-21 23:06:46 --> Home MX_Controller Initialized
DEBUG - 2018-06-21 23:06:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
