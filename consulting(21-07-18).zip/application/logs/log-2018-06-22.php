<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-06-22 00:48:40 --> Config Class Initialized
INFO - 2018-06-22 00:48:40 --> Hooks Class Initialized
DEBUG - 2018-06-22 00:48:41 --> UTF-8 Support Enabled
INFO - 2018-06-22 00:48:41 --> Utf8 Class Initialized
INFO - 2018-06-22 00:48:41 --> URI Class Initialized
INFO - 2018-06-22 00:48:41 --> Router Class Initialized
INFO - 2018-06-22 00:48:41 --> Output Class Initialized
INFO - 2018-06-22 00:48:41 --> Security Class Initialized
DEBUG - 2018-06-22 00:48:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 00:48:41 --> Input Class Initialized
INFO - 2018-06-22 00:48:41 --> Language Class Initialized
INFO - 2018-06-22 00:48:41 --> Language Class Initialized
INFO - 2018-06-22 00:48:41 --> Config Class Initialized
INFO - 2018-06-22 00:48:41 --> Loader Class Initialized
DEBUG - 2018-06-22 00:48:41 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-22 00:48:41 --> Helper loaded: url_helper
INFO - 2018-06-22 00:48:41 --> Helper loaded: form_helper
INFO - 2018-06-22 00:48:41 --> Helper loaded: date_helper
INFO - 2018-06-22 00:48:41 --> Helper loaded: util_helper
INFO - 2018-06-22 00:48:41 --> Helper loaded: text_helper
INFO - 2018-06-22 00:48:41 --> Helper loaded: string_helper
INFO - 2018-06-22 00:48:41 --> Database Driver Class Initialized
DEBUG - 2018-06-22 00:48:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 00:48:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 00:48:41 --> Email Class Initialized
INFO - 2018-06-22 00:48:41 --> Controller Class Initialized
DEBUG - 2018-06-22 00:48:41 --> Users MX_Controller Initialized
DEBUG - 2018-06-22 00:48:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-22 00:48:41 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-22 00:48:41 --> Login MX_Controller Initialized
INFO - 2018-06-22 00:48:41 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-22 00:48:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-22 00:48:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-22 00:48:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-22 00:48:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-22 00:48:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-22 00:48:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-22 00:48:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-06-22 00:48:41 --> Final output sent to browser
DEBUG - 2018-06-22 00:48:41 --> Total execution time: 0.3580
INFO - 2018-06-22 00:48:41 --> Config Class Initialized
INFO - 2018-06-22 00:48:41 --> Hooks Class Initialized
DEBUG - 2018-06-22 00:48:41 --> UTF-8 Support Enabled
INFO - 2018-06-22 00:48:42 --> Utf8 Class Initialized
INFO - 2018-06-22 00:48:42 --> URI Class Initialized
INFO - 2018-06-22 00:48:42 --> Router Class Initialized
INFO - 2018-06-22 00:48:42 --> Output Class Initialized
INFO - 2018-06-22 00:48:42 --> Security Class Initialized
DEBUG - 2018-06-22 00:48:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 00:48:42 --> Input Class Initialized
INFO - 2018-06-22 00:48:42 --> Language Class Initialized
INFO - 2018-06-22 00:48:42 --> Language Class Initialized
INFO - 2018-06-22 00:48:42 --> Config Class Initialized
INFO - 2018-06-22 00:48:42 --> Loader Class Initialized
DEBUG - 2018-06-22 00:48:42 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-22 00:48:42 --> Helper loaded: url_helper
INFO - 2018-06-22 00:48:42 --> Helper loaded: form_helper
INFO - 2018-06-22 00:48:42 --> Helper loaded: date_helper
INFO - 2018-06-22 00:48:42 --> Helper loaded: util_helper
INFO - 2018-06-22 00:48:42 --> Helper loaded: text_helper
INFO - 2018-06-22 00:48:42 --> Helper loaded: string_helper
INFO - 2018-06-22 00:48:42 --> Database Driver Class Initialized
DEBUG - 2018-06-22 00:48:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 00:48:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 00:48:42 --> Email Class Initialized
INFO - 2018-06-22 00:48:42 --> Controller Class Initialized
DEBUG - 2018-06-22 00:48:42 --> Users MX_Controller Initialized
DEBUG - 2018-06-22 00:48:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-22 00:48:42 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-22 00:48:42 --> Login MX_Controller Initialized
INFO - 2018-06-22 00:48:42 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-22 00:48:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-22 00:48:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-06-22 00:48:42 --> Final output sent to browser
DEBUG - 2018-06-22 00:48:42 --> Total execution time: 0.4237
INFO - 2018-06-22 00:48:45 --> Config Class Initialized
INFO - 2018-06-22 00:48:45 --> Hooks Class Initialized
DEBUG - 2018-06-22 00:48:45 --> UTF-8 Support Enabled
INFO - 2018-06-22 00:48:45 --> Utf8 Class Initialized
INFO - 2018-06-22 00:48:45 --> URI Class Initialized
INFO - 2018-06-22 00:48:45 --> Router Class Initialized
INFO - 2018-06-22 00:48:45 --> Output Class Initialized
INFO - 2018-06-22 00:48:45 --> Security Class Initialized
DEBUG - 2018-06-22 00:48:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 00:48:45 --> Input Class Initialized
INFO - 2018-06-22 00:48:45 --> Language Class Initialized
INFO - 2018-06-22 00:48:45 --> Language Class Initialized
INFO - 2018-06-22 00:48:45 --> Config Class Initialized
INFO - 2018-06-22 00:48:45 --> Loader Class Initialized
DEBUG - 2018-06-22 00:48:45 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-22 00:48:45 --> Helper loaded: url_helper
INFO - 2018-06-22 00:48:45 --> Helper loaded: form_helper
INFO - 2018-06-22 00:48:45 --> Helper loaded: date_helper
INFO - 2018-06-22 00:48:45 --> Helper loaded: util_helper
INFO - 2018-06-22 00:48:45 --> Helper loaded: text_helper
INFO - 2018-06-22 00:48:45 --> Helper loaded: string_helper
INFO - 2018-06-22 00:48:45 --> Database Driver Class Initialized
DEBUG - 2018-06-22 00:48:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 00:48:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 00:48:45 --> Email Class Initialized
INFO - 2018-06-22 00:48:45 --> Controller Class Initialized
DEBUG - 2018-06-22 00:48:45 --> Profile MX_Controller Initialized
INFO - 2018-06-22 00:48:45 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-22 00:48:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-22 00:48:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Profile_model.php
DEBUG - 2018-06-22 00:48:45 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-22 00:48:45 --> Login MX_Controller Initialized
DEBUG - 2018-06-22 00:48:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-22 00:48:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-22 00:48:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-22 00:48:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-22 00:48:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-22 00:48:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-22 00:48:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/admin_password.php
INFO - 2018-06-22 00:48:45 --> Final output sent to browser
DEBUG - 2018-06-22 00:48:45 --> Total execution time: 0.3390
INFO - 2018-06-22 00:48:47 --> Config Class Initialized
INFO - 2018-06-22 00:48:47 --> Hooks Class Initialized
DEBUG - 2018-06-22 00:48:47 --> UTF-8 Support Enabled
INFO - 2018-06-22 00:48:47 --> Utf8 Class Initialized
INFO - 2018-06-22 00:48:47 --> URI Class Initialized
INFO - 2018-06-22 00:48:47 --> Router Class Initialized
INFO - 2018-06-22 00:48:47 --> Output Class Initialized
INFO - 2018-06-22 00:48:47 --> Security Class Initialized
DEBUG - 2018-06-22 00:48:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 00:48:47 --> Input Class Initialized
INFO - 2018-06-22 00:48:47 --> Language Class Initialized
INFO - 2018-06-22 00:48:47 --> Language Class Initialized
INFO - 2018-06-22 00:48:47 --> Config Class Initialized
INFO - 2018-06-22 00:48:47 --> Loader Class Initialized
DEBUG - 2018-06-22 00:48:47 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-22 00:48:47 --> Helper loaded: url_helper
INFO - 2018-06-22 00:48:47 --> Helper loaded: form_helper
INFO - 2018-06-22 00:48:47 --> Helper loaded: date_helper
INFO - 2018-06-22 00:48:47 --> Helper loaded: util_helper
INFO - 2018-06-22 00:48:47 --> Helper loaded: text_helper
INFO - 2018-06-22 00:48:47 --> Helper loaded: string_helper
INFO - 2018-06-22 00:48:47 --> Database Driver Class Initialized
DEBUG - 2018-06-22 00:48:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 00:48:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 00:48:47 --> Email Class Initialized
INFO - 2018-06-22 00:48:47 --> Controller Class Initialized
DEBUG - 2018-06-22 00:48:47 --> Profile MX_Controller Initialized
INFO - 2018-06-22 00:48:47 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-22 00:48:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-22 00:48:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Profile_model.php
DEBUG - 2018-06-22 00:48:47 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-22 00:48:47 --> Login MX_Controller Initialized
DEBUG - 2018-06-22 00:48:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-22 00:48:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-22 00:48:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-22 00:48:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-22 00:48:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-22 00:48:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-22 00:48:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/profile.php
INFO - 2018-06-22 00:48:47 --> Final output sent to browser
DEBUG - 2018-06-22 00:48:47 --> Total execution time: 0.3422
INFO - 2018-06-22 02:17:06 --> Config Class Initialized
INFO - 2018-06-22 02:17:06 --> Hooks Class Initialized
DEBUG - 2018-06-22 02:17:06 --> UTF-8 Support Enabled
INFO - 2018-06-22 02:17:06 --> Utf8 Class Initialized
INFO - 2018-06-22 02:17:06 --> URI Class Initialized
INFO - 2018-06-22 02:17:06 --> Router Class Initialized
INFO - 2018-06-22 02:17:06 --> Output Class Initialized
INFO - 2018-06-22 02:17:06 --> Security Class Initialized
DEBUG - 2018-06-22 02:17:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 02:17:06 --> Input Class Initialized
INFO - 2018-06-22 02:17:06 --> Language Class Initialized
INFO - 2018-06-22 02:17:06 --> Language Class Initialized
INFO - 2018-06-22 02:17:06 --> Config Class Initialized
INFO - 2018-06-22 02:17:06 --> Loader Class Initialized
DEBUG - 2018-06-22 02:17:06 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-22 02:17:06 --> Helper loaded: url_helper
INFO - 2018-06-22 02:17:06 --> Helper loaded: form_helper
INFO - 2018-06-22 02:17:06 --> Helper loaded: date_helper
INFO - 2018-06-22 02:17:06 --> Helper loaded: util_helper
INFO - 2018-06-22 02:17:06 --> Helper loaded: text_helper
INFO - 2018-06-22 02:17:06 --> Helper loaded: string_helper
INFO - 2018-06-22 02:17:06 --> Database Driver Class Initialized
DEBUG - 2018-06-22 02:17:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 02:17:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 02:17:06 --> Email Class Initialized
INFO - 2018-06-22 02:17:06 --> Controller Class Initialized
DEBUG - 2018-06-22 02:17:06 --> Profile MX_Controller Initialized
INFO - 2018-06-22 02:17:06 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-22 02:17:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-22 02:17:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Profile_model.php
DEBUG - 2018-06-22 02:17:06 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-22 02:17:06 --> Login MX_Controller Initialized
DEBUG - 2018-06-22 02:17:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-22 02:17:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-22 02:17:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-22 02:17:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-22 02:17:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-22 02:17:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-22 02:17:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/profile.php
INFO - 2018-06-22 02:17:06 --> Final output sent to browser
DEBUG - 2018-06-22 02:17:06 --> Total execution time: 0.3768
INFO - 2018-06-22 02:17:40 --> Config Class Initialized
INFO - 2018-06-22 02:17:40 --> Hooks Class Initialized
DEBUG - 2018-06-22 02:17:40 --> UTF-8 Support Enabled
INFO - 2018-06-22 02:17:40 --> Utf8 Class Initialized
INFO - 2018-06-22 02:17:40 --> URI Class Initialized
INFO - 2018-06-22 02:17:40 --> Router Class Initialized
INFO - 2018-06-22 02:17:40 --> Output Class Initialized
INFO - 2018-06-22 02:17:40 --> Security Class Initialized
DEBUG - 2018-06-22 02:17:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 02:17:40 --> Input Class Initialized
INFO - 2018-06-22 02:17:40 --> Language Class Initialized
INFO - 2018-06-22 02:17:40 --> Language Class Initialized
INFO - 2018-06-22 02:17:40 --> Config Class Initialized
INFO - 2018-06-22 02:17:40 --> Loader Class Initialized
DEBUG - 2018-06-22 02:17:40 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-22 02:17:40 --> Helper loaded: url_helper
INFO - 2018-06-22 02:17:40 --> Helper loaded: form_helper
INFO - 2018-06-22 02:17:40 --> Helper loaded: date_helper
INFO - 2018-06-22 02:17:40 --> Helper loaded: util_helper
INFO - 2018-06-22 02:17:40 --> Helper loaded: text_helper
INFO - 2018-06-22 02:17:40 --> Helper loaded: string_helper
INFO - 2018-06-22 02:17:40 --> Database Driver Class Initialized
DEBUG - 2018-06-22 02:17:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 02:17:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 02:17:40 --> Email Class Initialized
INFO - 2018-06-22 02:17:40 --> Controller Class Initialized
DEBUG - 2018-06-22 02:17:40 --> Profile MX_Controller Initialized
INFO - 2018-06-22 02:17:40 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-22 02:17:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-22 02:17:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Profile_model.php
DEBUG - 2018-06-22 02:17:40 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-22 02:17:40 --> Login MX_Controller Initialized
DEBUG - 2018-06-22 02:17:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-22 02:17:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-22 02:17:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-22 02:17:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-22 02:17:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-22 02:17:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-22 02:17:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/profile.php
INFO - 2018-06-22 02:17:40 --> Final output sent to browser
DEBUG - 2018-06-22 02:17:40 --> Total execution time: 0.3754
INFO - 2018-06-22 02:17:44 --> Config Class Initialized
INFO - 2018-06-22 02:17:44 --> Hooks Class Initialized
DEBUG - 2018-06-22 02:17:44 --> UTF-8 Support Enabled
INFO - 2018-06-22 02:17:44 --> Utf8 Class Initialized
INFO - 2018-06-22 02:17:44 --> URI Class Initialized
INFO - 2018-06-22 02:17:44 --> Router Class Initialized
INFO - 2018-06-22 02:17:44 --> Output Class Initialized
INFO - 2018-06-22 02:17:44 --> Security Class Initialized
DEBUG - 2018-06-22 02:17:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 02:17:44 --> Input Class Initialized
INFO - 2018-06-22 02:17:44 --> Language Class Initialized
INFO - 2018-06-22 02:17:44 --> Language Class Initialized
INFO - 2018-06-22 02:17:44 --> Config Class Initialized
INFO - 2018-06-22 02:17:44 --> Loader Class Initialized
DEBUG - 2018-06-22 02:17:44 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-22 02:17:44 --> Helper loaded: url_helper
INFO - 2018-06-22 02:17:44 --> Helper loaded: form_helper
INFO - 2018-06-22 02:17:44 --> Helper loaded: date_helper
INFO - 2018-06-22 02:17:44 --> Helper loaded: util_helper
INFO - 2018-06-22 02:17:44 --> Helper loaded: text_helper
INFO - 2018-06-22 02:17:44 --> Helper loaded: string_helper
INFO - 2018-06-22 02:17:44 --> Database Driver Class Initialized
DEBUG - 2018-06-22 02:17:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 02:17:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 02:17:44 --> Email Class Initialized
INFO - 2018-06-22 02:17:44 --> Controller Class Initialized
DEBUG - 2018-06-22 02:17:44 --> Profile MX_Controller Initialized
INFO - 2018-06-22 02:17:44 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-22 02:17:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-22 02:17:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Profile_model.php
DEBUG - 2018-06-22 02:17:44 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-22 02:17:44 --> Login MX_Controller Initialized
DEBUG - 2018-06-22 02:17:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-22 02:17:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-22 02:17:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-22 02:17:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-22 02:17:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-22 02:17:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-22 02:17:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/admin_password.php
INFO - 2018-06-22 02:17:44 --> Final output sent to browser
DEBUG - 2018-06-22 02:17:44 --> Total execution time: 0.3572
INFO - 2018-06-22 02:17:46 --> Config Class Initialized
INFO - 2018-06-22 02:17:46 --> Hooks Class Initialized
DEBUG - 2018-06-22 02:17:46 --> UTF-8 Support Enabled
INFO - 2018-06-22 02:17:46 --> Utf8 Class Initialized
INFO - 2018-06-22 02:17:46 --> URI Class Initialized
INFO - 2018-06-22 02:17:46 --> Router Class Initialized
INFO - 2018-06-22 02:17:46 --> Output Class Initialized
INFO - 2018-06-22 02:17:46 --> Security Class Initialized
DEBUG - 2018-06-22 02:17:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 02:17:46 --> Input Class Initialized
INFO - 2018-06-22 02:17:46 --> Language Class Initialized
INFO - 2018-06-22 02:17:46 --> Language Class Initialized
INFO - 2018-06-22 02:17:46 --> Config Class Initialized
INFO - 2018-06-22 02:17:46 --> Loader Class Initialized
DEBUG - 2018-06-22 02:17:46 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-22 02:17:46 --> Helper loaded: url_helper
INFO - 2018-06-22 02:17:46 --> Helper loaded: form_helper
INFO - 2018-06-22 02:17:46 --> Helper loaded: date_helper
INFO - 2018-06-22 02:17:46 --> Helper loaded: util_helper
INFO - 2018-06-22 02:17:46 --> Helper loaded: text_helper
INFO - 2018-06-22 02:17:46 --> Helper loaded: string_helper
INFO - 2018-06-22 02:17:46 --> Database Driver Class Initialized
DEBUG - 2018-06-22 02:17:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 02:17:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 02:17:46 --> Email Class Initialized
INFO - 2018-06-22 02:17:46 --> Controller Class Initialized
DEBUG - 2018-06-22 02:17:46 --> Admin MX_Controller Initialized
INFO - 2018-06-22 02:17:46 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-22 02:17:46 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-22 02:17:46 --> Login MX_Controller Initialized
DEBUG - 2018-06-22 02:17:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-22 02:17:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-22 02:17:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-22 02:17:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-22 02:17:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-22 02:17:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-22 02:17:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-22 02:17:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/dashboard.php
INFO - 2018-06-22 02:17:46 --> Final output sent to browser
DEBUG - 2018-06-22 02:17:46 --> Total execution time: 0.3701
INFO - 2018-06-22 02:17:47 --> Config Class Initialized
INFO - 2018-06-22 02:17:47 --> Hooks Class Initialized
DEBUG - 2018-06-22 02:17:47 --> UTF-8 Support Enabled
INFO - 2018-06-22 02:17:47 --> Utf8 Class Initialized
INFO - 2018-06-22 02:17:47 --> Config Class Initialized
INFO - 2018-06-22 02:17:47 --> Hooks Class Initialized
INFO - 2018-06-22 02:17:47 --> URI Class Initialized
DEBUG - 2018-06-22 02:17:47 --> UTF-8 Support Enabled
INFO - 2018-06-22 02:17:47 --> Router Class Initialized
INFO - 2018-06-22 02:17:47 --> Utf8 Class Initialized
INFO - 2018-06-22 02:17:47 --> URI Class Initialized
INFO - 2018-06-22 02:17:47 --> Output Class Initialized
INFO - 2018-06-22 02:17:47 --> Security Class Initialized
INFO - 2018-06-22 02:17:47 --> Router Class Initialized
DEBUG - 2018-06-22 02:17:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 02:17:47 --> Output Class Initialized
INFO - 2018-06-22 02:17:47 --> Input Class Initialized
INFO - 2018-06-22 02:17:47 --> Security Class Initialized
INFO - 2018-06-22 02:17:47 --> Language Class Initialized
DEBUG - 2018-06-22 02:17:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 02:17:47 --> Input Class Initialized
ERROR - 2018-06-22 02:17:47 --> 404 Page Not Found: /index
INFO - 2018-06-22 02:17:47 --> Language Class Initialized
ERROR - 2018-06-22 02:17:47 --> 404 Page Not Found: /index
INFO - 2018-06-22 02:17:47 --> Config Class Initialized
INFO - 2018-06-22 02:17:47 --> Hooks Class Initialized
DEBUG - 2018-06-22 02:17:47 --> UTF-8 Support Enabled
INFO - 2018-06-22 02:17:47 --> Utf8 Class Initialized
INFO - 2018-06-22 02:17:47 --> URI Class Initialized
INFO - 2018-06-22 02:17:47 --> Router Class Initialized
INFO - 2018-06-22 02:17:47 --> Output Class Initialized
INFO - 2018-06-22 02:17:47 --> Security Class Initialized
DEBUG - 2018-06-22 02:17:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 02:17:47 --> Input Class Initialized
INFO - 2018-06-22 02:17:47 --> Language Class Initialized
ERROR - 2018-06-22 02:17:47 --> 404 Page Not Found: /index
INFO - 2018-06-22 02:17:48 --> Config Class Initialized
INFO - 2018-06-22 02:17:48 --> Hooks Class Initialized
DEBUG - 2018-06-22 02:17:48 --> UTF-8 Support Enabled
INFO - 2018-06-22 02:17:49 --> Utf8 Class Initialized
INFO - 2018-06-22 02:17:49 --> URI Class Initialized
INFO - 2018-06-22 02:17:49 --> Router Class Initialized
INFO - 2018-06-22 02:17:49 --> Output Class Initialized
INFO - 2018-06-22 02:17:49 --> Security Class Initialized
DEBUG - 2018-06-22 02:17:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 02:17:49 --> Input Class Initialized
INFO - 2018-06-22 02:17:49 --> Language Class Initialized
INFO - 2018-06-22 02:17:49 --> Language Class Initialized
INFO - 2018-06-22 02:17:49 --> Config Class Initialized
INFO - 2018-06-22 02:17:49 --> Loader Class Initialized
DEBUG - 2018-06-22 02:17:49 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-22 02:17:49 --> Helper loaded: url_helper
INFO - 2018-06-22 02:17:49 --> Helper loaded: form_helper
INFO - 2018-06-22 02:17:49 --> Helper loaded: date_helper
INFO - 2018-06-22 02:17:49 --> Helper loaded: util_helper
INFO - 2018-06-22 02:17:49 --> Helper loaded: text_helper
INFO - 2018-06-22 02:17:49 --> Helper loaded: string_helper
INFO - 2018-06-22 02:17:49 --> Database Driver Class Initialized
DEBUG - 2018-06-22 02:17:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 02:17:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 02:17:49 --> Email Class Initialized
INFO - 2018-06-22 02:17:49 --> Controller Class Initialized
DEBUG - 2018-06-22 02:17:49 --> Profile MX_Controller Initialized
INFO - 2018-06-22 02:17:49 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-22 02:17:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-22 02:17:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Profile_model.php
DEBUG - 2018-06-22 02:17:49 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-22 02:17:49 --> Login MX_Controller Initialized
DEBUG - 2018-06-22 02:17:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-22 02:17:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-22 02:17:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-22 02:17:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-22 02:17:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-22 02:17:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-22 02:17:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/profile.php
INFO - 2018-06-22 02:17:49 --> Final output sent to browser
DEBUG - 2018-06-22 02:17:49 --> Total execution time: 0.3917
INFO - 2018-06-22 02:18:10 --> Config Class Initialized
INFO - 2018-06-22 02:18:10 --> Hooks Class Initialized
DEBUG - 2018-06-22 02:18:10 --> UTF-8 Support Enabled
INFO - 2018-06-22 02:18:10 --> Utf8 Class Initialized
INFO - 2018-06-22 02:18:10 --> URI Class Initialized
INFO - 2018-06-22 02:18:10 --> Router Class Initialized
INFO - 2018-06-22 02:18:10 --> Output Class Initialized
INFO - 2018-06-22 02:18:10 --> Security Class Initialized
DEBUG - 2018-06-22 02:18:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 02:18:10 --> Input Class Initialized
INFO - 2018-06-22 02:18:10 --> Language Class Initialized
INFO - 2018-06-22 02:18:10 --> Language Class Initialized
INFO - 2018-06-22 02:18:10 --> Config Class Initialized
INFO - 2018-06-22 02:18:10 --> Loader Class Initialized
DEBUG - 2018-06-22 02:18:10 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-22 02:18:10 --> Helper loaded: url_helper
INFO - 2018-06-22 02:18:10 --> Helper loaded: form_helper
INFO - 2018-06-22 02:18:10 --> Helper loaded: date_helper
INFO - 2018-06-22 02:18:10 --> Helper loaded: util_helper
INFO - 2018-06-22 02:18:10 --> Helper loaded: text_helper
INFO - 2018-06-22 02:18:10 --> Helper loaded: string_helper
INFO - 2018-06-22 02:18:10 --> Database Driver Class Initialized
DEBUG - 2018-06-22 02:18:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 02:18:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 02:18:10 --> Email Class Initialized
INFO - 2018-06-22 02:18:10 --> Controller Class Initialized
DEBUG - 2018-06-22 02:18:10 --> Profile MX_Controller Initialized
INFO - 2018-06-22 02:18:10 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-22 02:18:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-22 02:18:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Profile_model.php
DEBUG - 2018-06-22 02:18:10 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-22 02:18:10 --> Login MX_Controller Initialized
DEBUG - 2018-06-22 02:18:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-22 02:18:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-22 02:18:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-22 02:18:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-22 02:18:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-22 02:18:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-22 02:18:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/profile.php
INFO - 2018-06-22 02:18:11 --> Final output sent to browser
DEBUG - 2018-06-22 02:18:11 --> Total execution time: 0.3724
INFO - 2018-06-22 02:32:58 --> Config Class Initialized
INFO - 2018-06-22 02:32:58 --> Hooks Class Initialized
DEBUG - 2018-06-22 02:32:58 --> UTF-8 Support Enabled
INFO - 2018-06-22 02:32:58 --> Utf8 Class Initialized
INFO - 2018-06-22 02:32:58 --> URI Class Initialized
INFO - 2018-06-22 02:32:58 --> Router Class Initialized
INFO - 2018-06-22 02:32:58 --> Output Class Initialized
INFO - 2018-06-22 02:32:58 --> Security Class Initialized
DEBUG - 2018-06-22 02:32:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 02:32:58 --> Input Class Initialized
INFO - 2018-06-22 02:32:58 --> Language Class Initialized
INFO - 2018-06-22 02:32:58 --> Language Class Initialized
INFO - 2018-06-22 02:32:58 --> Config Class Initialized
INFO - 2018-06-22 02:32:58 --> Loader Class Initialized
DEBUG - 2018-06-22 02:32:58 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-22 02:32:58 --> Helper loaded: url_helper
INFO - 2018-06-22 02:32:58 --> Helper loaded: form_helper
INFO - 2018-06-22 02:32:58 --> Helper loaded: date_helper
INFO - 2018-06-22 02:32:58 --> Helper loaded: util_helper
INFO - 2018-06-22 02:32:58 --> Helper loaded: text_helper
INFO - 2018-06-22 02:32:58 --> Helper loaded: string_helper
INFO - 2018-06-22 02:32:58 --> Database Driver Class Initialized
DEBUG - 2018-06-22 02:32:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 02:32:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 02:32:58 --> Email Class Initialized
INFO - 2018-06-22 02:32:58 --> Controller Class Initialized
DEBUG - 2018-06-22 02:32:58 --> Profile MX_Controller Initialized
INFO - 2018-06-22 02:32:58 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-22 02:32:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-22 02:32:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Profile_model.php
DEBUG - 2018-06-22 02:32:58 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-22 02:32:58 --> Login MX_Controller Initialized
DEBUG - 2018-06-22 02:32:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-22 02:32:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-22 02:32:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-22 02:32:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-22 02:32:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-22 02:32:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-22 02:32:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/profile.php
INFO - 2018-06-22 02:32:58 --> Final output sent to browser
DEBUG - 2018-06-22 02:32:58 --> Total execution time: 0.4669
INFO - 2018-06-22 02:33:20 --> Config Class Initialized
INFO - 2018-06-22 02:33:20 --> Hooks Class Initialized
DEBUG - 2018-06-22 02:33:20 --> UTF-8 Support Enabled
INFO - 2018-06-22 02:33:20 --> Utf8 Class Initialized
INFO - 2018-06-22 02:33:20 --> URI Class Initialized
INFO - 2018-06-22 02:33:20 --> Router Class Initialized
INFO - 2018-06-22 02:33:20 --> Output Class Initialized
INFO - 2018-06-22 02:33:20 --> Security Class Initialized
DEBUG - 2018-06-22 02:33:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 02:33:20 --> Input Class Initialized
INFO - 2018-06-22 02:33:20 --> Language Class Initialized
INFO - 2018-06-22 02:33:20 --> Language Class Initialized
INFO - 2018-06-22 02:33:20 --> Config Class Initialized
INFO - 2018-06-22 02:33:21 --> Loader Class Initialized
DEBUG - 2018-06-22 02:33:21 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-22 02:33:21 --> Helper loaded: url_helper
INFO - 2018-06-22 02:33:21 --> Helper loaded: form_helper
INFO - 2018-06-22 02:33:21 --> Helper loaded: date_helper
INFO - 2018-06-22 02:33:21 --> Helper loaded: util_helper
INFO - 2018-06-22 02:33:21 --> Helper loaded: text_helper
INFO - 2018-06-22 02:33:21 --> Helper loaded: string_helper
INFO - 2018-06-22 02:33:21 --> Database Driver Class Initialized
DEBUG - 2018-06-22 02:33:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 02:33:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 02:33:21 --> Email Class Initialized
INFO - 2018-06-22 02:33:21 --> Controller Class Initialized
DEBUG - 2018-06-22 02:33:21 --> Home MX_Controller Initialized
DEBUG - 2018-06-22 02:33:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-22 02:33:21 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-22 02:33:21 --> Login MX_Controller Initialized
INFO - 2018-06-22 02:33:21 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-22 02:33:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-22 02:33:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-22 02:33:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-22 02:33:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-22 02:33:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-22 02:33:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-22 02:33:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-22 02:33:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-06-22 02:33:21 --> Final output sent to browser
DEBUG - 2018-06-22 02:33:21 --> Total execution time: 0.3819
INFO - 2018-06-22 02:33:22 --> Config Class Initialized
INFO - 2018-06-22 02:33:22 --> Config Class Initialized
INFO - 2018-06-22 02:33:22 --> Hooks Class Initialized
INFO - 2018-06-22 02:33:22 --> Hooks Class Initialized
DEBUG - 2018-06-22 02:33:22 --> UTF-8 Support Enabled
INFO - 2018-06-22 02:33:22 --> Utf8 Class Initialized
DEBUG - 2018-06-22 02:33:22 --> UTF-8 Support Enabled
INFO - 2018-06-22 02:33:22 --> Utf8 Class Initialized
INFO - 2018-06-22 02:33:22 --> URI Class Initialized
INFO - 2018-06-22 02:33:22 --> URI Class Initialized
INFO - 2018-06-22 02:33:22 --> Router Class Initialized
INFO - 2018-06-22 02:33:22 --> Output Class Initialized
INFO - 2018-06-22 02:33:22 --> Router Class Initialized
INFO - 2018-06-22 02:33:22 --> Security Class Initialized
DEBUG - 2018-06-22 02:33:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 02:33:22 --> Input Class Initialized
INFO - 2018-06-22 02:33:22 --> Language Class Initialized
ERROR - 2018-06-22 02:33:22 --> 404 Page Not Found: /index
INFO - 2018-06-22 02:33:22 --> Output Class Initialized
INFO - 2018-06-22 02:33:22 --> Security Class Initialized
DEBUG - 2018-06-22 02:33:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 02:33:22 --> Input Class Initialized
INFO - 2018-06-22 02:33:22 --> Language Class Initialized
ERROR - 2018-06-22 02:33:22 --> 404 Page Not Found: /index
INFO - 2018-06-22 02:33:23 --> Config Class Initialized
INFO - 2018-06-22 02:33:23 --> Hooks Class Initialized
DEBUG - 2018-06-22 02:33:23 --> UTF-8 Support Enabled
INFO - 2018-06-22 02:33:23 --> Utf8 Class Initialized
INFO - 2018-06-22 02:33:23 --> URI Class Initialized
INFO - 2018-06-22 02:33:23 --> Router Class Initialized
INFO - 2018-06-22 02:33:23 --> Output Class Initialized
INFO - 2018-06-22 02:33:23 --> Security Class Initialized
DEBUG - 2018-06-22 02:33:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 02:33:23 --> Input Class Initialized
INFO - 2018-06-22 02:33:23 --> Language Class Initialized
ERROR - 2018-06-22 02:33:23 --> 404 Page Not Found: /index
INFO - 2018-06-22 02:33:23 --> Config Class Initialized
INFO - 2018-06-22 02:33:23 --> Hooks Class Initialized
DEBUG - 2018-06-22 02:33:23 --> UTF-8 Support Enabled
INFO - 2018-06-22 02:33:23 --> Utf8 Class Initialized
INFO - 2018-06-22 02:33:23 --> URI Class Initialized
INFO - 2018-06-22 02:33:23 --> Router Class Initialized
INFO - 2018-06-22 02:33:23 --> Output Class Initialized
INFO - 2018-06-22 02:33:23 --> Security Class Initialized
DEBUG - 2018-06-22 02:33:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 02:33:23 --> Input Class Initialized
INFO - 2018-06-22 02:33:23 --> Language Class Initialized
ERROR - 2018-06-22 02:33:23 --> 404 Page Not Found: /index
INFO - 2018-06-22 02:33:23 --> Config Class Initialized
INFO - 2018-06-22 02:33:23 --> Hooks Class Initialized
DEBUG - 2018-06-22 02:33:23 --> UTF-8 Support Enabled
INFO - 2018-06-22 02:33:23 --> Utf8 Class Initialized
INFO - 2018-06-22 02:33:23 --> URI Class Initialized
INFO - 2018-06-22 02:33:23 --> Router Class Initialized
INFO - 2018-06-22 02:33:23 --> Output Class Initialized
INFO - 2018-06-22 02:33:23 --> Security Class Initialized
DEBUG - 2018-06-22 02:33:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 02:33:23 --> Input Class Initialized
INFO - 2018-06-22 02:33:23 --> Language Class Initialized
ERROR - 2018-06-22 02:33:23 --> 404 Page Not Found: /index
INFO - 2018-06-22 02:33:23 --> Config Class Initialized
INFO - 2018-06-22 02:33:23 --> Hooks Class Initialized
DEBUG - 2018-06-22 02:33:23 --> UTF-8 Support Enabled
INFO - 2018-06-22 02:33:23 --> Utf8 Class Initialized
INFO - 2018-06-22 02:33:23 --> URI Class Initialized
INFO - 2018-06-22 02:33:23 --> Router Class Initialized
INFO - 2018-06-22 02:33:23 --> Output Class Initialized
INFO - 2018-06-22 02:33:23 --> Security Class Initialized
DEBUG - 2018-06-22 02:33:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 02:33:23 --> Input Class Initialized
INFO - 2018-06-22 02:33:23 --> Language Class Initialized
ERROR - 2018-06-22 02:33:23 --> 404 Page Not Found: /index
INFO - 2018-06-22 02:33:23 --> Config Class Initialized
INFO - 2018-06-22 02:33:23 --> Hooks Class Initialized
DEBUG - 2018-06-22 02:33:23 --> UTF-8 Support Enabled
INFO - 2018-06-22 02:33:23 --> Utf8 Class Initialized
INFO - 2018-06-22 02:33:23 --> URI Class Initialized
INFO - 2018-06-22 02:33:23 --> Router Class Initialized
INFO - 2018-06-22 02:33:23 --> Output Class Initialized
INFO - 2018-06-22 02:33:23 --> Security Class Initialized
DEBUG - 2018-06-22 02:33:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 02:33:23 --> Input Class Initialized
INFO - 2018-06-22 02:33:23 --> Language Class Initialized
ERROR - 2018-06-22 02:33:23 --> 404 Page Not Found: /index
INFO - 2018-06-22 04:16:43 --> Config Class Initialized
INFO - 2018-06-22 04:16:43 --> Hooks Class Initialized
DEBUG - 2018-06-22 04:16:43 --> UTF-8 Support Enabled
INFO - 2018-06-22 04:16:43 --> Utf8 Class Initialized
INFO - 2018-06-22 04:16:43 --> URI Class Initialized
INFO - 2018-06-22 04:16:43 --> Router Class Initialized
INFO - 2018-06-22 04:16:43 --> Output Class Initialized
INFO - 2018-06-22 04:16:43 --> Security Class Initialized
DEBUG - 2018-06-22 04:16:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 04:16:43 --> Input Class Initialized
INFO - 2018-06-22 04:16:43 --> Language Class Initialized
INFO - 2018-06-22 04:16:43 --> Language Class Initialized
INFO - 2018-06-22 04:16:43 --> Config Class Initialized
INFO - 2018-06-22 04:16:43 --> Loader Class Initialized
DEBUG - 2018-06-22 04:16:43 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-22 04:16:43 --> Helper loaded: url_helper
INFO - 2018-06-22 04:16:43 --> Helper loaded: form_helper
INFO - 2018-06-22 04:16:43 --> Helper loaded: date_helper
INFO - 2018-06-22 04:16:43 --> Helper loaded: util_helper
INFO - 2018-06-22 04:16:43 --> Helper loaded: text_helper
INFO - 2018-06-22 04:16:43 --> Helper loaded: string_helper
INFO - 2018-06-22 04:16:43 --> Database Driver Class Initialized
DEBUG - 2018-06-22 04:16:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 04:16:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 04:16:43 --> Email Class Initialized
INFO - 2018-06-22 04:16:43 --> Controller Class Initialized
DEBUG - 2018-06-22 04:16:43 --> Profile MX_Controller Initialized
INFO - 2018-06-22 04:16:43 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-22 04:16:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-22 04:16:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Profile_model.php
DEBUG - 2018-06-22 04:16:43 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-22 04:16:43 --> Login MX_Controller Initialized
DEBUG - 2018-06-22 04:16:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-22 04:16:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-22 04:16:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-22 04:16:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-22 04:16:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-22 04:16:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-22 04:16:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/profile.php
INFO - 2018-06-22 04:16:43 --> Final output sent to browser
DEBUG - 2018-06-22 04:16:44 --> Total execution time: 0.4435
INFO - 2018-06-22 04:16:46 --> Config Class Initialized
INFO - 2018-06-22 04:16:46 --> Hooks Class Initialized
DEBUG - 2018-06-22 04:16:46 --> UTF-8 Support Enabled
INFO - 2018-06-22 04:16:46 --> Utf8 Class Initialized
INFO - 2018-06-22 04:16:46 --> URI Class Initialized
INFO - 2018-06-22 04:16:46 --> Router Class Initialized
INFO - 2018-06-22 04:16:46 --> Output Class Initialized
INFO - 2018-06-22 04:16:46 --> Security Class Initialized
DEBUG - 2018-06-22 04:16:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 04:16:46 --> Input Class Initialized
INFO - 2018-06-22 04:16:46 --> Language Class Initialized
INFO - 2018-06-22 04:16:46 --> Language Class Initialized
INFO - 2018-06-22 04:16:46 --> Config Class Initialized
INFO - 2018-06-22 04:16:46 --> Loader Class Initialized
DEBUG - 2018-06-22 04:16:46 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-22 04:16:46 --> Helper loaded: url_helper
INFO - 2018-06-22 04:16:46 --> Helper loaded: form_helper
INFO - 2018-06-22 04:16:46 --> Helper loaded: date_helper
INFO - 2018-06-22 04:16:46 --> Helper loaded: util_helper
INFO - 2018-06-22 04:16:46 --> Helper loaded: text_helper
INFO - 2018-06-22 04:16:46 --> Helper loaded: string_helper
INFO - 2018-06-22 04:16:46 --> Database Driver Class Initialized
DEBUG - 2018-06-22 04:16:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 04:16:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 04:16:46 --> Email Class Initialized
INFO - 2018-06-22 04:16:46 --> Controller Class Initialized
DEBUG - 2018-06-22 04:16:46 --> Users MX_Controller Initialized
DEBUG - 2018-06-22 04:16:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-22 04:16:46 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-22 04:16:46 --> Login MX_Controller Initialized
INFO - 2018-06-22 04:16:46 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-22 04:16:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-22 04:16:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-22 04:16:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-22 04:16:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-22 04:16:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-22 04:16:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-22 04:16:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-06-22 04:16:46 --> Final output sent to browser
DEBUG - 2018-06-22 04:16:46 --> Total execution time: 0.4014
INFO - 2018-06-22 04:16:46 --> Config Class Initialized
INFO - 2018-06-22 04:16:46 --> Hooks Class Initialized
DEBUG - 2018-06-22 04:16:47 --> UTF-8 Support Enabled
INFO - 2018-06-22 04:16:47 --> Utf8 Class Initialized
INFO - 2018-06-22 04:16:47 --> URI Class Initialized
INFO - 2018-06-22 04:16:47 --> Router Class Initialized
INFO - 2018-06-22 04:16:47 --> Output Class Initialized
INFO - 2018-06-22 04:16:47 --> Security Class Initialized
DEBUG - 2018-06-22 04:16:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 04:16:47 --> Input Class Initialized
INFO - 2018-06-22 04:16:47 --> Language Class Initialized
INFO - 2018-06-22 04:16:47 --> Language Class Initialized
INFO - 2018-06-22 04:16:47 --> Config Class Initialized
INFO - 2018-06-22 04:16:47 --> Loader Class Initialized
DEBUG - 2018-06-22 04:16:47 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-22 04:16:47 --> Helper loaded: url_helper
INFO - 2018-06-22 04:16:47 --> Helper loaded: form_helper
INFO - 2018-06-22 04:16:47 --> Helper loaded: date_helper
INFO - 2018-06-22 04:16:47 --> Helper loaded: util_helper
INFO - 2018-06-22 04:16:47 --> Helper loaded: text_helper
INFO - 2018-06-22 04:16:47 --> Helper loaded: string_helper
INFO - 2018-06-22 04:16:47 --> Database Driver Class Initialized
DEBUG - 2018-06-22 04:16:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 04:16:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 04:16:47 --> Email Class Initialized
INFO - 2018-06-22 04:16:47 --> Controller Class Initialized
DEBUG - 2018-06-22 04:16:47 --> Users MX_Controller Initialized
DEBUG - 2018-06-22 04:16:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-22 04:16:47 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-22 04:16:47 --> Login MX_Controller Initialized
INFO - 2018-06-22 04:16:47 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-22 04:16:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-22 04:16:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-06-22 04:16:47 --> Final output sent to browser
DEBUG - 2018-06-22 04:16:47 --> Total execution time: 0.5821
INFO - 2018-06-22 04:24:05 --> Config Class Initialized
INFO - 2018-06-22 04:24:05 --> Hooks Class Initialized
DEBUG - 2018-06-22 04:24:05 --> UTF-8 Support Enabled
INFO - 2018-06-22 04:24:05 --> Utf8 Class Initialized
INFO - 2018-06-22 04:24:05 --> URI Class Initialized
INFO - 2018-06-22 04:24:05 --> Router Class Initialized
INFO - 2018-06-22 04:24:05 --> Output Class Initialized
INFO - 2018-06-22 04:24:05 --> Security Class Initialized
DEBUG - 2018-06-22 04:24:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 04:24:05 --> Input Class Initialized
INFO - 2018-06-22 04:24:05 --> Language Class Initialized
INFO - 2018-06-22 04:24:05 --> Language Class Initialized
INFO - 2018-06-22 04:24:06 --> Config Class Initialized
INFO - 2018-06-22 04:24:06 --> Loader Class Initialized
DEBUG - 2018-06-22 04:24:06 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-22 04:24:06 --> Helper loaded: url_helper
INFO - 2018-06-22 04:24:06 --> Helper loaded: form_helper
INFO - 2018-06-22 04:24:06 --> Helper loaded: date_helper
INFO - 2018-06-22 04:24:06 --> Helper loaded: util_helper
INFO - 2018-06-22 04:24:06 --> Helper loaded: text_helper
INFO - 2018-06-22 04:24:06 --> Helper loaded: string_helper
INFO - 2018-06-22 04:24:06 --> Database Driver Class Initialized
DEBUG - 2018-06-22 04:24:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 04:24:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 04:24:06 --> Email Class Initialized
INFO - 2018-06-22 04:24:06 --> Controller Class Initialized
DEBUG - 2018-06-22 04:24:06 --> Users MX_Controller Initialized
DEBUG - 2018-06-22 04:24:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-22 04:24:06 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-22 04:24:06 --> Login MX_Controller Initialized
INFO - 2018-06-22 04:24:06 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-22 04:24:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-22 04:24:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-06-22 04:24:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-22 04:24:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-22 04:24:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-22 04:24:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-22 04:24:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-22 04:24:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-06-22 04:24:06 --> Final output sent to browser
DEBUG - 2018-06-22 04:24:06 --> Total execution time: 0.4735
INFO - 2018-06-22 04:27:50 --> Config Class Initialized
INFO - 2018-06-22 04:27:50 --> Hooks Class Initialized
DEBUG - 2018-06-22 04:27:50 --> UTF-8 Support Enabled
INFO - 2018-06-22 04:27:50 --> Utf8 Class Initialized
INFO - 2018-06-22 04:27:50 --> URI Class Initialized
INFO - 2018-06-22 04:27:50 --> Router Class Initialized
INFO - 2018-06-22 04:27:50 --> Output Class Initialized
INFO - 2018-06-22 04:27:50 --> Security Class Initialized
DEBUG - 2018-06-22 04:27:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 04:27:50 --> Input Class Initialized
INFO - 2018-06-22 04:27:50 --> Language Class Initialized
INFO - 2018-06-22 04:27:50 --> Language Class Initialized
INFO - 2018-06-22 04:27:50 --> Config Class Initialized
INFO - 2018-06-22 04:27:50 --> Loader Class Initialized
DEBUG - 2018-06-22 04:27:50 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-22 04:27:50 --> Helper loaded: url_helper
INFO - 2018-06-22 04:27:50 --> Helper loaded: form_helper
INFO - 2018-06-22 04:27:50 --> Helper loaded: date_helper
INFO - 2018-06-22 04:27:50 --> Helper loaded: util_helper
INFO - 2018-06-22 04:27:50 --> Helper loaded: text_helper
INFO - 2018-06-22 04:27:50 --> Helper loaded: string_helper
INFO - 2018-06-22 04:27:50 --> Database Driver Class Initialized
DEBUG - 2018-06-22 04:27:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 04:27:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 04:27:50 --> Email Class Initialized
INFO - 2018-06-22 04:27:50 --> Controller Class Initialized
DEBUG - 2018-06-22 04:27:50 --> Users MX_Controller Initialized
DEBUG - 2018-06-22 04:27:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-22 04:27:50 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-22 04:27:50 --> Login MX_Controller Initialized
INFO - 2018-06-22 04:27:50 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-22 04:27:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-22 04:29:13 --> Config Class Initialized
INFO - 2018-06-22 04:29:13 --> Hooks Class Initialized
DEBUG - 2018-06-22 04:29:13 --> UTF-8 Support Enabled
INFO - 2018-06-22 04:29:13 --> Utf8 Class Initialized
INFO - 2018-06-22 04:29:13 --> URI Class Initialized
INFO - 2018-06-22 04:29:13 --> Router Class Initialized
INFO - 2018-06-22 04:29:13 --> Output Class Initialized
INFO - 2018-06-22 04:29:13 --> Security Class Initialized
DEBUG - 2018-06-22 04:29:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 04:29:13 --> Input Class Initialized
INFO - 2018-06-22 04:29:13 --> Language Class Initialized
INFO - 2018-06-22 04:29:13 --> Language Class Initialized
INFO - 2018-06-22 04:29:13 --> Config Class Initialized
INFO - 2018-06-22 04:29:13 --> Loader Class Initialized
DEBUG - 2018-06-22 04:29:13 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-22 04:29:13 --> Helper loaded: url_helper
INFO - 2018-06-22 04:29:13 --> Helper loaded: form_helper
INFO - 2018-06-22 04:29:13 --> Helper loaded: date_helper
INFO - 2018-06-22 04:29:13 --> Helper loaded: util_helper
INFO - 2018-06-22 04:29:13 --> Helper loaded: text_helper
INFO - 2018-06-22 04:29:13 --> Helper loaded: string_helper
INFO - 2018-06-22 04:29:13 --> Database Driver Class Initialized
DEBUG - 2018-06-22 04:29:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 04:29:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 04:29:13 --> Email Class Initialized
INFO - 2018-06-22 04:29:13 --> Controller Class Initialized
DEBUG - 2018-06-22 04:29:13 --> Users MX_Controller Initialized
DEBUG - 2018-06-22 04:29:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-22 04:29:13 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-22 04:29:13 --> Login MX_Controller Initialized
INFO - 2018-06-22 04:29:13 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-22 04:29:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-22 04:29:22 --> Config Class Initialized
INFO - 2018-06-22 04:29:22 --> Hooks Class Initialized
DEBUG - 2018-06-22 04:29:22 --> UTF-8 Support Enabled
INFO - 2018-06-22 04:29:22 --> Utf8 Class Initialized
INFO - 2018-06-22 04:29:22 --> URI Class Initialized
INFO - 2018-06-22 04:29:22 --> Router Class Initialized
INFO - 2018-06-22 04:29:22 --> Output Class Initialized
INFO - 2018-06-22 04:29:22 --> Security Class Initialized
DEBUG - 2018-06-22 04:29:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 04:29:22 --> Input Class Initialized
INFO - 2018-06-22 04:29:22 --> Language Class Initialized
INFO - 2018-06-22 04:29:22 --> Language Class Initialized
INFO - 2018-06-22 04:29:22 --> Config Class Initialized
INFO - 2018-06-22 04:29:22 --> Loader Class Initialized
DEBUG - 2018-06-22 04:29:22 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-22 04:29:22 --> Helper loaded: url_helper
INFO - 2018-06-22 04:29:22 --> Helper loaded: form_helper
INFO - 2018-06-22 04:29:22 --> Helper loaded: date_helper
INFO - 2018-06-22 04:29:22 --> Helper loaded: util_helper
INFO - 2018-06-22 04:29:22 --> Helper loaded: text_helper
INFO - 2018-06-22 04:29:22 --> Helper loaded: string_helper
INFO - 2018-06-22 04:29:22 --> Database Driver Class Initialized
DEBUG - 2018-06-22 04:29:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 04:29:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 04:29:22 --> Email Class Initialized
INFO - 2018-06-22 04:29:22 --> Controller Class Initialized
DEBUG - 2018-06-22 04:29:22 --> Users MX_Controller Initialized
DEBUG - 2018-06-22 04:29:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-22 04:29:22 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-22 04:29:22 --> Login MX_Controller Initialized
INFO - 2018-06-22 04:29:22 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-22 04:29:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-22 04:29:29 --> Config Class Initialized
INFO - 2018-06-22 04:29:29 --> Hooks Class Initialized
DEBUG - 2018-06-22 04:29:29 --> UTF-8 Support Enabled
INFO - 2018-06-22 04:29:29 --> Utf8 Class Initialized
INFO - 2018-06-22 04:29:29 --> URI Class Initialized
INFO - 2018-06-22 04:29:29 --> Router Class Initialized
INFO - 2018-06-22 04:29:29 --> Output Class Initialized
INFO - 2018-06-22 04:29:29 --> Security Class Initialized
DEBUG - 2018-06-22 04:29:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 04:29:29 --> Input Class Initialized
INFO - 2018-06-22 04:29:30 --> Language Class Initialized
INFO - 2018-06-22 04:29:30 --> Language Class Initialized
INFO - 2018-06-22 04:29:30 --> Config Class Initialized
INFO - 2018-06-22 04:29:30 --> Loader Class Initialized
DEBUG - 2018-06-22 04:29:30 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-22 04:29:30 --> Helper loaded: url_helper
INFO - 2018-06-22 04:29:30 --> Helper loaded: form_helper
INFO - 2018-06-22 04:29:30 --> Helper loaded: date_helper
INFO - 2018-06-22 04:29:30 --> Helper loaded: util_helper
INFO - 2018-06-22 04:29:30 --> Helper loaded: text_helper
INFO - 2018-06-22 04:29:30 --> Helper loaded: string_helper
INFO - 2018-06-22 04:29:30 --> Database Driver Class Initialized
DEBUG - 2018-06-22 04:29:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 04:29:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 04:29:30 --> Email Class Initialized
INFO - 2018-06-22 04:29:30 --> Controller Class Initialized
DEBUG - 2018-06-22 04:29:30 --> Users MX_Controller Initialized
DEBUG - 2018-06-22 04:29:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-22 04:29:30 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-22 04:29:30 --> Login MX_Controller Initialized
INFO - 2018-06-22 04:29:30 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-22 04:29:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-22 04:35:12 --> Config Class Initialized
INFO - 2018-06-22 04:35:12 --> Hooks Class Initialized
DEBUG - 2018-06-22 04:35:12 --> UTF-8 Support Enabled
INFO - 2018-06-22 04:35:13 --> Utf8 Class Initialized
INFO - 2018-06-22 04:35:13 --> URI Class Initialized
INFO - 2018-06-22 04:35:13 --> Router Class Initialized
INFO - 2018-06-22 04:35:13 --> Output Class Initialized
INFO - 2018-06-22 04:35:13 --> Security Class Initialized
DEBUG - 2018-06-22 04:35:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 04:35:13 --> Input Class Initialized
INFO - 2018-06-22 04:35:13 --> Language Class Initialized
INFO - 2018-06-22 04:35:13 --> Language Class Initialized
INFO - 2018-06-22 04:35:13 --> Config Class Initialized
INFO - 2018-06-22 04:35:13 --> Loader Class Initialized
DEBUG - 2018-06-22 04:35:13 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-22 04:35:13 --> Helper loaded: url_helper
INFO - 2018-06-22 04:35:13 --> Helper loaded: form_helper
INFO - 2018-06-22 04:35:13 --> Helper loaded: date_helper
INFO - 2018-06-22 04:35:13 --> Helper loaded: util_helper
INFO - 2018-06-22 04:35:13 --> Helper loaded: text_helper
INFO - 2018-06-22 04:35:13 --> Helper loaded: string_helper
INFO - 2018-06-22 04:35:13 --> Database Driver Class Initialized
DEBUG - 2018-06-22 04:35:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 04:35:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 04:35:13 --> Email Class Initialized
INFO - 2018-06-22 04:35:13 --> Controller Class Initialized
DEBUG - 2018-06-22 04:35:13 --> Users MX_Controller Initialized
DEBUG - 2018-06-22 04:35:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-22 04:35:13 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-22 04:35:13 --> Login MX_Controller Initialized
INFO - 2018-06-22 04:35:13 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-22 04:35:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-22 04:35:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-06-22 04:36:15 --> Config Class Initialized
INFO - 2018-06-22 04:36:15 --> Hooks Class Initialized
DEBUG - 2018-06-22 04:36:15 --> UTF-8 Support Enabled
INFO - 2018-06-22 04:36:15 --> Utf8 Class Initialized
INFO - 2018-06-22 04:36:15 --> URI Class Initialized
INFO - 2018-06-22 04:36:15 --> Router Class Initialized
INFO - 2018-06-22 04:36:15 --> Output Class Initialized
INFO - 2018-06-22 04:36:15 --> Security Class Initialized
DEBUG - 2018-06-22 04:36:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 04:36:15 --> Input Class Initialized
INFO - 2018-06-22 04:36:15 --> Language Class Initialized
INFO - 2018-06-22 04:36:15 --> Language Class Initialized
INFO - 2018-06-22 04:36:15 --> Config Class Initialized
INFO - 2018-06-22 04:36:15 --> Loader Class Initialized
DEBUG - 2018-06-22 04:36:15 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-22 04:36:15 --> Helper loaded: url_helper
INFO - 2018-06-22 04:36:15 --> Helper loaded: form_helper
INFO - 2018-06-22 04:36:15 --> Helper loaded: date_helper
INFO - 2018-06-22 04:36:15 --> Helper loaded: util_helper
INFO - 2018-06-22 04:36:15 --> Helper loaded: text_helper
INFO - 2018-06-22 04:36:15 --> Helper loaded: string_helper
INFO - 2018-06-22 04:36:15 --> Database Driver Class Initialized
DEBUG - 2018-06-22 04:36:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 04:36:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 04:36:15 --> Email Class Initialized
INFO - 2018-06-22 04:36:15 --> Controller Class Initialized
DEBUG - 2018-06-22 04:36:15 --> Users MX_Controller Initialized
DEBUG - 2018-06-22 04:36:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-22 04:36:15 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-22 04:36:15 --> Login MX_Controller Initialized
INFO - 2018-06-22 04:36:15 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-22 04:36:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-22 04:36:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-06-22 04:36:25 --> Config Class Initialized
INFO - 2018-06-22 04:36:25 --> Hooks Class Initialized
DEBUG - 2018-06-22 04:36:25 --> UTF-8 Support Enabled
INFO - 2018-06-22 04:36:25 --> Utf8 Class Initialized
INFO - 2018-06-22 04:36:25 --> URI Class Initialized
INFO - 2018-06-22 04:36:25 --> Router Class Initialized
INFO - 2018-06-22 04:36:25 --> Output Class Initialized
INFO - 2018-06-22 04:36:25 --> Security Class Initialized
DEBUG - 2018-06-22 04:36:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 04:36:25 --> Input Class Initialized
INFO - 2018-06-22 04:36:25 --> Language Class Initialized
INFO - 2018-06-22 04:36:25 --> Language Class Initialized
INFO - 2018-06-22 04:36:25 --> Config Class Initialized
INFO - 2018-06-22 04:36:25 --> Loader Class Initialized
DEBUG - 2018-06-22 04:36:25 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-22 04:36:25 --> Helper loaded: url_helper
INFO - 2018-06-22 04:36:25 --> Helper loaded: form_helper
INFO - 2018-06-22 04:36:25 --> Helper loaded: date_helper
INFO - 2018-06-22 04:36:25 --> Helper loaded: util_helper
INFO - 2018-06-22 04:36:25 --> Helper loaded: text_helper
INFO - 2018-06-22 04:36:25 --> Helper loaded: string_helper
INFO - 2018-06-22 04:36:25 --> Database Driver Class Initialized
DEBUG - 2018-06-22 04:36:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 04:36:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 04:36:25 --> Email Class Initialized
INFO - 2018-06-22 04:36:25 --> Controller Class Initialized
DEBUG - 2018-06-22 04:36:25 --> Users MX_Controller Initialized
DEBUG - 2018-06-22 04:36:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-22 04:36:25 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-22 04:36:25 --> Login MX_Controller Initialized
INFO - 2018-06-22 04:36:25 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-22 04:36:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-22 04:36:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-06-22 04:36:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-22 04:36:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-22 04:36:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-22 04:36:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-22 04:36:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-22 04:36:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-06-22 04:36:25 --> Final output sent to browser
DEBUG - 2018-06-22 04:36:25 --> Total execution time: 0.4509
INFO - 2018-06-22 04:41:25 --> Config Class Initialized
INFO - 2018-06-22 04:41:25 --> Hooks Class Initialized
DEBUG - 2018-06-22 04:41:25 --> UTF-8 Support Enabled
INFO - 2018-06-22 04:41:25 --> Utf8 Class Initialized
INFO - 2018-06-22 04:41:25 --> URI Class Initialized
INFO - 2018-06-22 04:41:25 --> Router Class Initialized
INFO - 2018-06-22 04:41:25 --> Output Class Initialized
INFO - 2018-06-22 04:41:25 --> Security Class Initialized
DEBUG - 2018-06-22 04:41:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 04:41:25 --> Input Class Initialized
INFO - 2018-06-22 04:41:25 --> Language Class Initialized
INFO - 2018-06-22 04:41:25 --> Language Class Initialized
INFO - 2018-06-22 04:41:25 --> Config Class Initialized
INFO - 2018-06-22 04:41:25 --> Loader Class Initialized
DEBUG - 2018-06-22 04:41:25 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-22 04:41:25 --> Helper loaded: url_helper
INFO - 2018-06-22 04:41:25 --> Helper loaded: form_helper
INFO - 2018-06-22 04:41:25 --> Helper loaded: date_helper
INFO - 2018-06-22 04:41:25 --> Helper loaded: util_helper
INFO - 2018-06-22 04:41:25 --> Helper loaded: text_helper
INFO - 2018-06-22 04:41:25 --> Helper loaded: string_helper
INFO - 2018-06-22 04:41:25 --> Database Driver Class Initialized
DEBUG - 2018-06-22 04:41:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 04:41:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 04:41:25 --> Email Class Initialized
INFO - 2018-06-22 04:41:25 --> Controller Class Initialized
DEBUG - 2018-06-22 04:41:25 --> Users MX_Controller Initialized
DEBUG - 2018-06-22 04:41:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-22 04:41:25 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-22 04:41:25 --> Login MX_Controller Initialized
INFO - 2018-06-22 04:41:25 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-22 04:41:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-22 04:41:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-06-22 04:41:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-22 04:41:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-22 04:41:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-22 04:41:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-22 04:41:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-22 04:41:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-06-22 04:41:25 --> Final output sent to browser
DEBUG - 2018-06-22 04:41:25 --> Total execution time: 0.5846
INFO - 2018-06-22 04:53:03 --> Config Class Initialized
INFO - 2018-06-22 04:53:03 --> Hooks Class Initialized
DEBUG - 2018-06-22 04:53:03 --> UTF-8 Support Enabled
INFO - 2018-06-22 04:53:03 --> Utf8 Class Initialized
INFO - 2018-06-22 04:53:03 --> URI Class Initialized
INFO - 2018-06-22 04:53:03 --> Router Class Initialized
INFO - 2018-06-22 04:53:03 --> Output Class Initialized
INFO - 2018-06-22 04:53:03 --> Security Class Initialized
DEBUG - 2018-06-22 04:53:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 04:53:03 --> Input Class Initialized
INFO - 2018-06-22 04:53:03 --> Language Class Initialized
INFO - 2018-06-22 04:53:03 --> Language Class Initialized
INFO - 2018-06-22 04:53:03 --> Config Class Initialized
INFO - 2018-06-22 04:53:03 --> Loader Class Initialized
DEBUG - 2018-06-22 04:53:03 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-22 04:53:03 --> Helper loaded: url_helper
INFO - 2018-06-22 04:53:03 --> Helper loaded: form_helper
INFO - 2018-06-22 04:53:03 --> Helper loaded: date_helper
INFO - 2018-06-22 04:53:03 --> Helper loaded: util_helper
INFO - 2018-06-22 04:53:03 --> Helper loaded: text_helper
INFO - 2018-06-22 04:53:03 --> Helper loaded: string_helper
INFO - 2018-06-22 04:53:03 --> Database Driver Class Initialized
DEBUG - 2018-06-22 04:53:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 04:53:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 04:53:03 --> Email Class Initialized
INFO - 2018-06-22 04:53:03 --> Controller Class Initialized
DEBUG - 2018-06-22 04:53:03 --> Users MX_Controller Initialized
DEBUG - 2018-06-22 04:53:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-22 04:53:03 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-22 04:53:03 --> Login MX_Controller Initialized
INFO - 2018-06-22 04:53:03 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-22 04:53:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-22 04:53:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-06-22 04:53:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-22 04:53:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-22 04:53:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-22 04:53:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-22 04:53:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-22 04:53:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-06-22 04:53:03 --> Final output sent to browser
DEBUG - 2018-06-22 04:53:03 --> Total execution time: 0.4485
INFO - 2018-06-22 05:01:01 --> Config Class Initialized
INFO - 2018-06-22 05:01:01 --> Hooks Class Initialized
DEBUG - 2018-06-22 05:01:01 --> UTF-8 Support Enabled
INFO - 2018-06-22 05:01:01 --> Utf8 Class Initialized
INFO - 2018-06-22 05:01:01 --> URI Class Initialized
INFO - 2018-06-22 05:01:01 --> Router Class Initialized
INFO - 2018-06-22 05:01:01 --> Output Class Initialized
INFO - 2018-06-22 05:01:01 --> Security Class Initialized
DEBUG - 2018-06-22 05:01:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 05:01:01 --> Input Class Initialized
INFO - 2018-06-22 05:01:01 --> Language Class Initialized
INFO - 2018-06-22 05:01:01 --> Language Class Initialized
INFO - 2018-06-22 05:01:01 --> Config Class Initialized
INFO - 2018-06-22 05:01:01 --> Loader Class Initialized
DEBUG - 2018-06-22 05:01:01 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-22 05:01:01 --> Helper loaded: url_helper
INFO - 2018-06-22 05:01:01 --> Helper loaded: form_helper
INFO - 2018-06-22 05:01:01 --> Helper loaded: date_helper
INFO - 2018-06-22 05:01:01 --> Helper loaded: util_helper
INFO - 2018-06-22 05:01:01 --> Helper loaded: text_helper
INFO - 2018-06-22 05:01:01 --> Helper loaded: string_helper
INFO - 2018-06-22 05:01:01 --> Database Driver Class Initialized
DEBUG - 2018-06-22 05:01:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 05:01:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 05:01:01 --> Email Class Initialized
INFO - 2018-06-22 05:01:01 --> Controller Class Initialized
DEBUG - 2018-06-22 05:01:01 --> Users MX_Controller Initialized
DEBUG - 2018-06-22 05:01:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-22 05:01:01 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-22 05:01:01 --> Login MX_Controller Initialized
INFO - 2018-06-22 05:01:01 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-22 05:01:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-22 05:01:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-06-22 05:01:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-22 05:01:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-22 05:01:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-22 05:01:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-22 05:01:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-22 05:01:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-06-22 05:01:01 --> Final output sent to browser
DEBUG - 2018-06-22 05:01:02 --> Total execution time: 0.5295
INFO - 2018-06-22 05:01:40 --> Config Class Initialized
INFO - 2018-06-22 05:01:40 --> Hooks Class Initialized
DEBUG - 2018-06-22 05:01:40 --> UTF-8 Support Enabled
INFO - 2018-06-22 05:01:40 --> Utf8 Class Initialized
INFO - 2018-06-22 05:01:40 --> URI Class Initialized
INFO - 2018-06-22 05:01:40 --> Router Class Initialized
INFO - 2018-06-22 05:01:40 --> Output Class Initialized
INFO - 2018-06-22 05:01:40 --> Security Class Initialized
DEBUG - 2018-06-22 05:01:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 05:01:40 --> Input Class Initialized
INFO - 2018-06-22 05:01:40 --> Language Class Initialized
INFO - 2018-06-22 05:01:40 --> Language Class Initialized
INFO - 2018-06-22 05:01:40 --> Config Class Initialized
INFO - 2018-06-22 05:01:40 --> Loader Class Initialized
INFO - 2018-06-22 05:01:40 --> Config Class Initialized
INFO - 2018-06-22 05:01:40 --> Hooks Class Initialized
DEBUG - 2018-06-22 05:01:40 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
DEBUG - 2018-06-22 05:01:40 --> UTF-8 Support Enabled
INFO - 2018-06-22 05:01:40 --> Helper loaded: url_helper
INFO - 2018-06-22 05:01:40 --> Utf8 Class Initialized
INFO - 2018-06-22 05:01:40 --> URI Class Initialized
INFO - 2018-06-22 05:01:40 --> Router Class Initialized
INFO - 2018-06-22 05:01:40 --> Helper loaded: form_helper
INFO - 2018-06-22 05:01:40 --> Output Class Initialized
INFO - 2018-06-22 05:01:40 --> Security Class Initialized
DEBUG - 2018-06-22 05:01:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 05:01:40 --> Input Class Initialized
INFO - 2018-06-22 05:01:40 --> Language Class Initialized
INFO - 2018-06-22 05:01:40 --> Language Class Initialized
INFO - 2018-06-22 05:01:40 --> Helper loaded: date_helper
INFO - 2018-06-22 05:01:40 --> Config Class Initialized
INFO - 2018-06-22 05:01:40 --> Loader Class Initialized
INFO - 2018-06-22 05:01:40 --> Helper loaded: util_helper
DEBUG - 2018-06-22 05:01:40 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-22 05:01:40 --> Helper loaded: url_helper
INFO - 2018-06-22 05:01:40 --> Helper loaded: form_helper
INFO - 2018-06-22 05:01:40 --> Helper loaded: date_helper
INFO - 2018-06-22 05:01:40 --> Helper loaded: text_helper
INFO - 2018-06-22 05:01:40 --> Helper loaded: util_helper
INFO - 2018-06-22 05:01:40 --> Helper loaded: string_helper
INFO - 2018-06-22 05:01:40 --> Helper loaded: text_helper
INFO - 2018-06-22 05:01:40 --> Database Driver Class Initialized
INFO - 2018-06-22 05:01:40 --> Helper loaded: string_helper
DEBUG - 2018-06-22 05:01:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 05:01:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 05:01:40 --> Database Driver Class Initialized
INFO - 2018-06-22 05:01:40 --> Email Class Initialized
DEBUG - 2018-06-22 05:01:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 05:01:40 --> Controller Class Initialized
DEBUG - 2018-06-22 05:01:40 --> Users MX_Controller Initialized
DEBUG - 2018-06-22 05:01:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-22 05:01:40 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-22 05:01:40 --> Login MX_Controller Initialized
INFO - 2018-06-22 05:01:40 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-22 05:01:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-22 05:01:40 --> Final output sent to browser
DEBUG - 2018-06-22 05:01:40 --> Total execution time: 0.5364
INFO - 2018-06-22 05:01:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 05:01:40 --> Email Class Initialized
INFO - 2018-06-22 05:01:40 --> Controller Class Initialized
DEBUG - 2018-06-22 05:01:40 --> Users MX_Controller Initialized
DEBUG - 2018-06-22 05:01:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-22 05:01:40 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-22 05:01:40 --> Login MX_Controller Initialized
INFO - 2018-06-22 05:01:40 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-22 05:01:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-22 05:01:40 --> Final output sent to browser
DEBUG - 2018-06-22 05:01:40 --> Total execution time: 0.4562
INFO - 2018-06-22 05:01:51 --> Config Class Initialized
INFO - 2018-06-22 05:01:51 --> Hooks Class Initialized
DEBUG - 2018-06-22 05:01:51 --> UTF-8 Support Enabled
INFO - 2018-06-22 05:01:51 --> Utf8 Class Initialized
INFO - 2018-06-22 05:01:51 --> URI Class Initialized
INFO - 2018-06-22 05:01:51 --> Router Class Initialized
INFO - 2018-06-22 05:01:51 --> Output Class Initialized
INFO - 2018-06-22 05:01:51 --> Security Class Initialized
DEBUG - 2018-06-22 05:01:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 05:01:51 --> Input Class Initialized
INFO - 2018-06-22 05:01:51 --> Language Class Initialized
INFO - 2018-06-22 05:01:51 --> Language Class Initialized
INFO - 2018-06-22 05:01:51 --> Config Class Initialized
INFO - 2018-06-22 05:01:51 --> Loader Class Initialized
DEBUG - 2018-06-22 05:01:51 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-22 05:01:51 --> Helper loaded: url_helper
INFO - 2018-06-22 05:01:51 --> Helper loaded: form_helper
INFO - 2018-06-22 05:01:51 --> Helper loaded: date_helper
INFO - 2018-06-22 05:01:51 --> Helper loaded: util_helper
INFO - 2018-06-22 05:01:51 --> Helper loaded: text_helper
INFO - 2018-06-22 05:01:51 --> Helper loaded: string_helper
INFO - 2018-06-22 05:01:51 --> Database Driver Class Initialized
DEBUG - 2018-06-22 05:01:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 05:01:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 05:01:51 --> Email Class Initialized
INFO - 2018-06-22 05:01:51 --> Controller Class Initialized
DEBUG - 2018-06-22 05:01:51 --> Users MX_Controller Initialized
DEBUG - 2018-06-22 05:01:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-22 05:01:51 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-22 05:01:51 --> Login MX_Controller Initialized
INFO - 2018-06-22 05:01:51 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-22 05:01:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-22 05:01:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-06-22 05:01:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
INFO - 2018-06-22 05:01:51 --> Upload Class Initialized
INFO - 2018-06-22 05:01:51 --> Config Class Initialized
INFO - 2018-06-22 05:01:51 --> Hooks Class Initialized
DEBUG - 2018-06-22 05:01:51 --> UTF-8 Support Enabled
INFO - 2018-06-22 05:01:51 --> Utf8 Class Initialized
INFO - 2018-06-22 05:01:51 --> URI Class Initialized
INFO - 2018-06-22 05:01:51 --> Router Class Initialized
INFO - 2018-06-22 05:01:51 --> Output Class Initialized
INFO - 2018-06-22 05:01:51 --> Security Class Initialized
DEBUG - 2018-06-22 05:01:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 05:01:51 --> Input Class Initialized
INFO - 2018-06-22 05:01:51 --> Language Class Initialized
INFO - 2018-06-22 05:01:51 --> Language Class Initialized
INFO - 2018-06-22 05:01:51 --> Config Class Initialized
INFO - 2018-06-22 05:01:51 --> Loader Class Initialized
DEBUG - 2018-06-22 05:01:51 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-22 05:01:51 --> Helper loaded: url_helper
INFO - 2018-06-22 05:01:51 --> Helper loaded: form_helper
INFO - 2018-06-22 05:01:51 --> Helper loaded: date_helper
INFO - 2018-06-22 05:01:51 --> Helper loaded: util_helper
INFO - 2018-06-22 05:01:51 --> Helper loaded: text_helper
INFO - 2018-06-22 05:01:52 --> Helper loaded: string_helper
INFO - 2018-06-22 05:01:52 --> Database Driver Class Initialized
DEBUG - 2018-06-22 05:01:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 05:01:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 05:01:52 --> Email Class Initialized
INFO - 2018-06-22 05:01:52 --> Controller Class Initialized
DEBUG - 2018-06-22 05:01:52 --> Users MX_Controller Initialized
DEBUG - 2018-06-22 05:01:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-22 05:01:52 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-22 05:01:52 --> Login MX_Controller Initialized
INFO - 2018-06-22 05:01:52 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-22 05:01:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-22 05:01:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-22 05:01:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-22 05:01:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-22 05:01:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-22 05:01:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-22 05:01:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-06-22 05:01:52 --> Final output sent to browser
DEBUG - 2018-06-22 05:01:52 --> Total execution time: 0.3980
INFO - 2018-06-22 05:01:52 --> Config Class Initialized
INFO - 2018-06-22 05:01:52 --> Hooks Class Initialized
DEBUG - 2018-06-22 05:01:52 --> UTF-8 Support Enabled
INFO - 2018-06-22 05:01:52 --> Utf8 Class Initialized
INFO - 2018-06-22 05:01:52 --> URI Class Initialized
INFO - 2018-06-22 05:01:52 --> Router Class Initialized
INFO - 2018-06-22 05:01:52 --> Output Class Initialized
INFO - 2018-06-22 05:01:52 --> Security Class Initialized
DEBUG - 2018-06-22 05:01:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 05:01:52 --> Input Class Initialized
INFO - 2018-06-22 05:01:52 --> Language Class Initialized
INFO - 2018-06-22 05:01:52 --> Language Class Initialized
INFO - 2018-06-22 05:01:52 --> Config Class Initialized
INFO - 2018-06-22 05:01:52 --> Loader Class Initialized
DEBUG - 2018-06-22 05:01:52 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-22 05:01:52 --> Helper loaded: url_helper
INFO - 2018-06-22 05:01:52 --> Helper loaded: form_helper
INFO - 2018-06-22 05:01:52 --> Helper loaded: date_helper
INFO - 2018-06-22 05:01:52 --> Helper loaded: util_helper
INFO - 2018-06-22 05:01:52 --> Helper loaded: text_helper
INFO - 2018-06-22 05:01:52 --> Helper loaded: string_helper
INFO - 2018-06-22 05:01:53 --> Database Driver Class Initialized
DEBUG - 2018-06-22 05:01:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 05:01:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 05:01:53 --> Email Class Initialized
INFO - 2018-06-22 05:01:53 --> Controller Class Initialized
DEBUG - 2018-06-22 05:01:53 --> Users MX_Controller Initialized
DEBUG - 2018-06-22 05:01:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-22 05:01:53 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-22 05:01:53 --> Login MX_Controller Initialized
INFO - 2018-06-22 05:01:53 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-22 05:01:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-22 05:01:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
ERROR - 2018-06-22 05:01:53 --> Severity: Notice --> Undefined variable: roles E:\xampp\htdocs\consulting\application\modules\admin\models\users_model.php 68
ERROR - 2018-06-22 05:01:53 --> Severity: error --> Exception: Unsupported operand types E:\xampp\htdocs\consulting\application\modules\admin\controllers\users.php 33
INFO - 2018-06-22 05:01:56 --> Config Class Initialized
INFO - 2018-06-22 05:01:56 --> Hooks Class Initialized
DEBUG - 2018-06-22 05:01:56 --> UTF-8 Support Enabled
INFO - 2018-06-22 05:01:56 --> Utf8 Class Initialized
INFO - 2018-06-22 05:01:56 --> URI Class Initialized
INFO - 2018-06-22 05:01:56 --> Router Class Initialized
INFO - 2018-06-22 05:01:56 --> Output Class Initialized
INFO - 2018-06-22 05:01:56 --> Security Class Initialized
DEBUG - 2018-06-22 05:01:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 05:01:56 --> Input Class Initialized
INFO - 2018-06-22 05:01:56 --> Language Class Initialized
INFO - 2018-06-22 05:01:56 --> Language Class Initialized
INFO - 2018-06-22 05:01:56 --> Config Class Initialized
INFO - 2018-06-22 05:01:56 --> Loader Class Initialized
DEBUG - 2018-06-22 05:01:56 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-22 05:01:56 --> Helper loaded: url_helper
INFO - 2018-06-22 05:01:56 --> Helper loaded: form_helper
INFO - 2018-06-22 05:01:56 --> Helper loaded: date_helper
INFO - 2018-06-22 05:01:56 --> Helper loaded: util_helper
INFO - 2018-06-22 05:01:56 --> Helper loaded: text_helper
INFO - 2018-06-22 05:01:56 --> Helper loaded: string_helper
INFO - 2018-06-22 05:01:56 --> Database Driver Class Initialized
DEBUG - 2018-06-22 05:01:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 05:01:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 05:01:56 --> Email Class Initialized
INFO - 2018-06-22 05:01:56 --> Controller Class Initialized
DEBUG - 2018-06-22 05:01:56 --> Users MX_Controller Initialized
DEBUG - 2018-06-22 05:01:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-22 05:01:56 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-22 05:01:56 --> Login MX_Controller Initialized
INFO - 2018-06-22 05:01:56 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-22 05:01:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-22 05:01:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-22 05:01:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-22 05:01:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-22 05:01:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-22 05:01:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-22 05:01:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-06-22 05:01:57 --> Final output sent to browser
DEBUG - 2018-06-22 05:01:57 --> Total execution time: 0.4547
INFO - 2018-06-22 05:01:57 --> Config Class Initialized
INFO - 2018-06-22 05:01:57 --> Hooks Class Initialized
DEBUG - 2018-06-22 05:01:57 --> UTF-8 Support Enabled
INFO - 2018-06-22 05:01:57 --> Utf8 Class Initialized
INFO - 2018-06-22 05:01:57 --> URI Class Initialized
INFO - 2018-06-22 05:01:57 --> Router Class Initialized
INFO - 2018-06-22 05:01:57 --> Output Class Initialized
INFO - 2018-06-22 05:01:57 --> Security Class Initialized
DEBUG - 2018-06-22 05:01:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 05:01:57 --> Input Class Initialized
INFO - 2018-06-22 05:01:57 --> Language Class Initialized
INFO - 2018-06-22 05:01:57 --> Language Class Initialized
INFO - 2018-06-22 05:01:57 --> Config Class Initialized
INFO - 2018-06-22 05:01:57 --> Loader Class Initialized
DEBUG - 2018-06-22 05:01:57 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-22 05:01:57 --> Helper loaded: url_helper
INFO - 2018-06-22 05:01:57 --> Helper loaded: form_helper
INFO - 2018-06-22 05:01:57 --> Helper loaded: date_helper
INFO - 2018-06-22 05:01:57 --> Helper loaded: util_helper
INFO - 2018-06-22 05:01:57 --> Helper loaded: text_helper
INFO - 2018-06-22 05:01:57 --> Helper loaded: string_helper
INFO - 2018-06-22 05:01:57 --> Database Driver Class Initialized
DEBUG - 2018-06-22 05:01:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 05:01:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 05:01:57 --> Email Class Initialized
INFO - 2018-06-22 05:01:57 --> Controller Class Initialized
DEBUG - 2018-06-22 05:01:57 --> Users MX_Controller Initialized
DEBUG - 2018-06-22 05:01:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-22 05:01:57 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-22 05:01:57 --> Login MX_Controller Initialized
INFO - 2018-06-22 05:01:57 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-22 05:01:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-22 05:01:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
ERROR - 2018-06-22 05:01:57 --> Severity: Notice --> Undefined variable: roles E:\xampp\htdocs\consulting\application\modules\admin\models\users_model.php 68
ERROR - 2018-06-22 05:01:57 --> Severity: error --> Exception: Unsupported operand types E:\xampp\htdocs\consulting\application\modules\admin\controllers\users.php 33
INFO - 2018-06-22 05:02:23 --> Config Class Initialized
INFO - 2018-06-22 05:02:23 --> Hooks Class Initialized
DEBUG - 2018-06-22 05:02:23 --> UTF-8 Support Enabled
INFO - 2018-06-22 05:02:23 --> Utf8 Class Initialized
INFO - 2018-06-22 05:02:23 --> URI Class Initialized
INFO - 2018-06-22 05:02:23 --> Router Class Initialized
INFO - 2018-06-22 05:02:23 --> Output Class Initialized
INFO - 2018-06-22 05:02:23 --> Security Class Initialized
DEBUG - 2018-06-22 05:02:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 05:02:23 --> Input Class Initialized
INFO - 2018-06-22 05:02:23 --> Language Class Initialized
INFO - 2018-06-22 05:02:24 --> Language Class Initialized
INFO - 2018-06-22 05:02:24 --> Config Class Initialized
INFO - 2018-06-22 05:02:24 --> Loader Class Initialized
DEBUG - 2018-06-22 05:02:24 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-22 05:02:24 --> Helper loaded: url_helper
INFO - 2018-06-22 05:02:24 --> Helper loaded: form_helper
INFO - 2018-06-22 05:02:24 --> Helper loaded: date_helper
INFO - 2018-06-22 05:02:24 --> Helper loaded: util_helper
INFO - 2018-06-22 05:02:24 --> Helper loaded: text_helper
INFO - 2018-06-22 05:02:24 --> Helper loaded: string_helper
INFO - 2018-06-22 05:02:24 --> Database Driver Class Initialized
DEBUG - 2018-06-22 05:02:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 05:02:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 05:02:24 --> Email Class Initialized
INFO - 2018-06-22 05:02:24 --> Controller Class Initialized
DEBUG - 2018-06-22 05:02:24 --> Users MX_Controller Initialized
DEBUG - 2018-06-22 05:02:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-22 05:02:24 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-22 05:02:24 --> Login MX_Controller Initialized
INFO - 2018-06-22 05:02:24 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-22 05:02:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-22 05:02:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
ERROR - 2018-06-22 05:02:24 --> Severity: Notice --> Undefined variable: roles E:\xampp\htdocs\consulting\application\modules\admin\models\users_model.php 68
ERROR - 2018-06-22 05:02:24 --> Severity: error --> Exception: Unsupported operand types E:\xampp\htdocs\consulting\application\modules\admin\controllers\users.php 33
INFO - 2018-06-22 05:04:25 --> Config Class Initialized
INFO - 2018-06-22 05:04:25 --> Hooks Class Initialized
DEBUG - 2018-06-22 05:04:25 --> UTF-8 Support Enabled
INFO - 2018-06-22 05:04:25 --> Utf8 Class Initialized
INFO - 2018-06-22 05:04:25 --> URI Class Initialized
INFO - 2018-06-22 05:04:25 --> Router Class Initialized
INFO - 2018-06-22 05:04:26 --> Output Class Initialized
INFO - 2018-06-22 05:04:26 --> Security Class Initialized
DEBUG - 2018-06-22 05:04:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 05:04:26 --> Input Class Initialized
INFO - 2018-06-22 05:04:26 --> Language Class Initialized
INFO - 2018-06-22 05:04:26 --> Language Class Initialized
INFO - 2018-06-22 05:04:26 --> Config Class Initialized
INFO - 2018-06-22 05:04:26 --> Loader Class Initialized
DEBUG - 2018-06-22 05:04:26 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-22 05:04:26 --> Helper loaded: url_helper
INFO - 2018-06-22 05:04:26 --> Helper loaded: form_helper
INFO - 2018-06-22 05:04:26 --> Helper loaded: date_helper
INFO - 2018-06-22 05:04:26 --> Helper loaded: util_helper
INFO - 2018-06-22 05:04:26 --> Helper loaded: text_helper
INFO - 2018-06-22 05:04:26 --> Helper loaded: string_helper
INFO - 2018-06-22 05:04:26 --> Database Driver Class Initialized
DEBUG - 2018-06-22 05:04:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 05:04:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 05:04:26 --> Email Class Initialized
INFO - 2018-06-22 05:04:26 --> Controller Class Initialized
DEBUG - 2018-06-22 05:04:26 --> Users MX_Controller Initialized
DEBUG - 2018-06-22 05:04:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-22 05:04:26 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-22 05:04:26 --> Login MX_Controller Initialized
INFO - 2018-06-22 05:04:26 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-22 05:04:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-22 05:04:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-06-22 05:04:26 --> Final output sent to browser
DEBUG - 2018-06-22 05:04:26 --> Total execution time: 0.4139
INFO - 2018-06-22 05:04:29 --> Config Class Initialized
INFO - 2018-06-22 05:04:29 --> Hooks Class Initialized
DEBUG - 2018-06-22 05:04:29 --> UTF-8 Support Enabled
INFO - 2018-06-22 05:04:29 --> Utf8 Class Initialized
INFO - 2018-06-22 05:04:29 --> URI Class Initialized
INFO - 2018-06-22 05:04:29 --> Router Class Initialized
INFO - 2018-06-22 05:04:29 --> Output Class Initialized
INFO - 2018-06-22 05:04:29 --> Security Class Initialized
DEBUG - 2018-06-22 05:04:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 05:04:29 --> Input Class Initialized
INFO - 2018-06-22 05:04:29 --> Language Class Initialized
INFO - 2018-06-22 05:04:29 --> Language Class Initialized
INFO - 2018-06-22 05:04:29 --> Config Class Initialized
INFO - 2018-06-22 05:04:29 --> Loader Class Initialized
DEBUG - 2018-06-22 05:04:29 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-22 05:04:29 --> Helper loaded: url_helper
INFO - 2018-06-22 05:04:30 --> Helper loaded: form_helper
INFO - 2018-06-22 05:04:30 --> Helper loaded: date_helper
INFO - 2018-06-22 05:04:30 --> Helper loaded: util_helper
INFO - 2018-06-22 05:04:30 --> Helper loaded: text_helper
INFO - 2018-06-22 05:04:30 --> Helper loaded: string_helper
INFO - 2018-06-22 05:04:30 --> Database Driver Class Initialized
DEBUG - 2018-06-22 05:04:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 05:04:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 05:04:30 --> Email Class Initialized
INFO - 2018-06-22 05:04:30 --> Controller Class Initialized
DEBUG - 2018-06-22 05:04:30 --> Users MX_Controller Initialized
DEBUG - 2018-06-22 05:04:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-22 05:04:30 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-22 05:04:30 --> Login MX_Controller Initialized
INFO - 2018-06-22 05:04:30 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-22 05:04:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-22 05:04:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-06-22 05:04:30 --> Final output sent to browser
DEBUG - 2018-06-22 05:04:30 --> Total execution time: 0.4176
INFO - 2018-06-22 05:04:35 --> Config Class Initialized
INFO - 2018-06-22 05:04:35 --> Hooks Class Initialized
DEBUG - 2018-06-22 05:04:35 --> UTF-8 Support Enabled
INFO - 2018-06-22 05:04:35 --> Utf8 Class Initialized
INFO - 2018-06-22 05:04:35 --> URI Class Initialized
INFO - 2018-06-22 05:04:35 --> Router Class Initialized
INFO - 2018-06-22 05:04:35 --> Output Class Initialized
INFO - 2018-06-22 05:04:35 --> Security Class Initialized
DEBUG - 2018-06-22 05:04:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 05:04:35 --> Input Class Initialized
INFO - 2018-06-22 05:04:35 --> Language Class Initialized
INFO - 2018-06-22 05:04:35 --> Language Class Initialized
INFO - 2018-06-22 05:04:35 --> Config Class Initialized
INFO - 2018-06-22 05:04:35 --> Loader Class Initialized
DEBUG - 2018-06-22 05:04:35 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-22 05:04:35 --> Helper loaded: url_helper
INFO - 2018-06-22 05:04:35 --> Helper loaded: form_helper
INFO - 2018-06-22 05:04:35 --> Helper loaded: date_helper
INFO - 2018-06-22 05:04:35 --> Helper loaded: util_helper
INFO - 2018-06-22 05:04:35 --> Helper loaded: text_helper
INFO - 2018-06-22 05:04:35 --> Helper loaded: string_helper
INFO - 2018-06-22 05:04:35 --> Database Driver Class Initialized
DEBUG - 2018-06-22 05:04:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 05:04:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 05:04:35 --> Email Class Initialized
INFO - 2018-06-22 05:04:35 --> Controller Class Initialized
DEBUG - 2018-06-22 05:04:35 --> Users MX_Controller Initialized
DEBUG - 2018-06-22 05:04:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-22 05:04:35 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-22 05:04:35 --> Login MX_Controller Initialized
INFO - 2018-06-22 05:04:35 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-22 05:04:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-22 05:04:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-22 05:04:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-22 05:04:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-22 05:04:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-22 05:04:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-22 05:04:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-06-22 05:04:35 --> Final output sent to browser
DEBUG - 2018-06-22 05:04:35 --> Total execution time: 0.4908
INFO - 2018-06-22 05:04:36 --> Config Class Initialized
INFO - 2018-06-22 05:04:36 --> Hooks Class Initialized
DEBUG - 2018-06-22 05:04:36 --> UTF-8 Support Enabled
INFO - 2018-06-22 05:04:36 --> Utf8 Class Initialized
INFO - 2018-06-22 05:04:36 --> URI Class Initialized
INFO - 2018-06-22 05:04:36 --> Router Class Initialized
INFO - 2018-06-22 05:04:36 --> Output Class Initialized
INFO - 2018-06-22 05:04:36 --> Security Class Initialized
DEBUG - 2018-06-22 05:04:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 05:04:36 --> Input Class Initialized
INFO - 2018-06-22 05:04:36 --> Language Class Initialized
INFO - 2018-06-22 05:04:36 --> Language Class Initialized
INFO - 2018-06-22 05:04:36 --> Config Class Initialized
INFO - 2018-06-22 05:04:36 --> Loader Class Initialized
DEBUG - 2018-06-22 05:04:36 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-22 05:04:36 --> Helper loaded: url_helper
INFO - 2018-06-22 05:04:36 --> Helper loaded: form_helper
INFO - 2018-06-22 05:04:36 --> Helper loaded: date_helper
INFO - 2018-06-22 05:04:36 --> Helper loaded: util_helper
INFO - 2018-06-22 05:04:36 --> Helper loaded: text_helper
INFO - 2018-06-22 05:04:36 --> Helper loaded: string_helper
INFO - 2018-06-22 05:04:36 --> Database Driver Class Initialized
DEBUG - 2018-06-22 05:04:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 05:04:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 05:04:36 --> Email Class Initialized
INFO - 2018-06-22 05:04:36 --> Controller Class Initialized
DEBUG - 2018-06-22 05:04:36 --> Users MX_Controller Initialized
DEBUG - 2018-06-22 05:04:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-22 05:04:36 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-22 05:04:36 --> Login MX_Controller Initialized
INFO - 2018-06-22 05:04:36 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-22 05:04:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-22 05:04:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-06-22 05:04:36 --> Final output sent to browser
DEBUG - 2018-06-22 05:04:36 --> Total execution time: 0.7803
INFO - 2018-06-22 05:04:41 --> Config Class Initialized
INFO - 2018-06-22 05:04:41 --> Hooks Class Initialized
DEBUG - 2018-06-22 05:04:41 --> UTF-8 Support Enabled
INFO - 2018-06-22 05:04:41 --> Utf8 Class Initialized
INFO - 2018-06-22 05:04:41 --> URI Class Initialized
INFO - 2018-06-22 05:04:41 --> Router Class Initialized
INFO - 2018-06-22 05:04:41 --> Output Class Initialized
INFO - 2018-06-22 05:04:41 --> Security Class Initialized
DEBUG - 2018-06-22 05:04:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 05:04:41 --> Input Class Initialized
INFO - 2018-06-22 05:04:41 --> Language Class Initialized
INFO - 2018-06-22 05:04:41 --> Language Class Initialized
INFO - 2018-06-22 05:04:41 --> Config Class Initialized
INFO - 2018-06-22 05:04:41 --> Loader Class Initialized
DEBUG - 2018-06-22 05:04:41 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-22 05:04:41 --> Helper loaded: url_helper
INFO - 2018-06-22 05:04:41 --> Helper loaded: form_helper
INFO - 2018-06-22 05:04:41 --> Helper loaded: date_helper
INFO - 2018-06-22 05:04:41 --> Helper loaded: util_helper
INFO - 2018-06-22 05:04:42 --> Helper loaded: text_helper
INFO - 2018-06-22 05:04:42 --> Helper loaded: string_helper
INFO - 2018-06-22 05:04:42 --> Database Driver Class Initialized
DEBUG - 2018-06-22 05:04:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 05:04:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 05:04:42 --> Email Class Initialized
INFO - 2018-06-22 05:04:42 --> Controller Class Initialized
DEBUG - 2018-06-22 05:04:42 --> Users MX_Controller Initialized
DEBUG - 2018-06-22 05:04:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-22 05:04:42 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-22 05:04:42 --> Login MX_Controller Initialized
INFO - 2018-06-22 05:04:42 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-22 05:04:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-22 05:04:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-06-22 05:04:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-22 05:04:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-22 05:04:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-22 05:04:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-22 05:04:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-22 05:04:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-06-22 05:04:42 --> Final output sent to browser
DEBUG - 2018-06-22 05:04:42 --> Total execution time: 0.4493
INFO - 2018-06-22 05:04:52 --> Config Class Initialized
INFO - 2018-06-22 05:04:52 --> Hooks Class Initialized
DEBUG - 2018-06-22 05:04:52 --> UTF-8 Support Enabled
INFO - 2018-06-22 05:04:52 --> Utf8 Class Initialized
INFO - 2018-06-22 05:04:52 --> URI Class Initialized
INFO - 2018-06-22 05:04:52 --> Router Class Initialized
INFO - 2018-06-22 05:04:52 --> Output Class Initialized
INFO - 2018-06-22 05:04:52 --> Security Class Initialized
DEBUG - 2018-06-22 05:04:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 05:04:52 --> Input Class Initialized
INFO - 2018-06-22 05:04:52 --> Language Class Initialized
INFO - 2018-06-22 05:04:52 --> Language Class Initialized
INFO - 2018-06-22 05:04:52 --> Config Class Initialized
INFO - 2018-06-22 05:04:52 --> Loader Class Initialized
DEBUG - 2018-06-22 05:04:52 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-22 05:04:52 --> Helper loaded: url_helper
INFO - 2018-06-22 05:04:52 --> Helper loaded: form_helper
INFO - 2018-06-22 05:04:52 --> Helper loaded: date_helper
INFO - 2018-06-22 05:04:52 --> Helper loaded: util_helper
INFO - 2018-06-22 05:04:52 --> Helper loaded: text_helper
INFO - 2018-06-22 05:04:52 --> Helper loaded: string_helper
INFO - 2018-06-22 05:04:52 --> Database Driver Class Initialized
DEBUG - 2018-06-22 05:04:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 05:04:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 05:04:52 --> Email Class Initialized
INFO - 2018-06-22 05:04:52 --> Controller Class Initialized
DEBUG - 2018-06-22 05:04:52 --> Users MX_Controller Initialized
DEBUG - 2018-06-22 05:04:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-22 05:04:52 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-22 05:04:52 --> Login MX_Controller Initialized
INFO - 2018-06-22 05:04:52 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-22 05:04:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-22 05:04:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-06-22 05:04:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
INFO - 2018-06-22 05:04:52 --> Config Class Initialized
INFO - 2018-06-22 05:04:53 --> Hooks Class Initialized
DEBUG - 2018-06-22 05:04:53 --> UTF-8 Support Enabled
INFO - 2018-06-22 05:04:53 --> Utf8 Class Initialized
INFO - 2018-06-22 05:04:53 --> URI Class Initialized
INFO - 2018-06-22 05:04:53 --> Router Class Initialized
INFO - 2018-06-22 05:04:53 --> Output Class Initialized
INFO - 2018-06-22 05:04:53 --> Security Class Initialized
DEBUG - 2018-06-22 05:04:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 05:04:53 --> Input Class Initialized
INFO - 2018-06-22 05:04:53 --> Language Class Initialized
INFO - 2018-06-22 05:04:53 --> Language Class Initialized
INFO - 2018-06-22 05:04:53 --> Config Class Initialized
INFO - 2018-06-22 05:04:53 --> Loader Class Initialized
DEBUG - 2018-06-22 05:04:53 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-22 05:04:53 --> Helper loaded: url_helper
INFO - 2018-06-22 05:04:53 --> Helper loaded: form_helper
INFO - 2018-06-22 05:04:53 --> Helper loaded: date_helper
INFO - 2018-06-22 05:04:53 --> Helper loaded: util_helper
INFO - 2018-06-22 05:04:53 --> Helper loaded: text_helper
INFO - 2018-06-22 05:04:53 --> Helper loaded: string_helper
INFO - 2018-06-22 05:04:53 --> Database Driver Class Initialized
DEBUG - 2018-06-22 05:04:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 05:04:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 05:04:53 --> Email Class Initialized
INFO - 2018-06-22 05:04:53 --> Controller Class Initialized
DEBUG - 2018-06-22 05:04:53 --> Users MX_Controller Initialized
DEBUG - 2018-06-22 05:04:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-22 05:04:53 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-22 05:04:53 --> Login MX_Controller Initialized
INFO - 2018-06-22 05:04:53 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-22 05:04:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-22 05:04:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-22 05:04:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-22 05:04:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-22 05:04:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-22 05:04:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-22 05:04:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-06-22 05:04:53 --> Final output sent to browser
DEBUG - 2018-06-22 05:04:53 --> Total execution time: 0.4590
INFO - 2018-06-22 05:04:53 --> Config Class Initialized
INFO - 2018-06-22 05:04:53 --> Hooks Class Initialized
DEBUG - 2018-06-22 05:04:53 --> UTF-8 Support Enabled
INFO - 2018-06-22 05:04:53 --> Utf8 Class Initialized
INFO - 2018-06-22 05:04:53 --> URI Class Initialized
INFO - 2018-06-22 05:04:54 --> Router Class Initialized
INFO - 2018-06-22 05:04:54 --> Output Class Initialized
INFO - 2018-06-22 05:04:54 --> Security Class Initialized
DEBUG - 2018-06-22 05:04:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 05:04:54 --> Input Class Initialized
INFO - 2018-06-22 05:04:54 --> Language Class Initialized
INFO - 2018-06-22 05:04:54 --> Language Class Initialized
INFO - 2018-06-22 05:04:54 --> Config Class Initialized
INFO - 2018-06-22 05:04:54 --> Loader Class Initialized
DEBUG - 2018-06-22 05:04:54 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-22 05:04:54 --> Helper loaded: url_helper
INFO - 2018-06-22 05:04:54 --> Helper loaded: form_helper
INFO - 2018-06-22 05:04:54 --> Helper loaded: date_helper
INFO - 2018-06-22 05:04:54 --> Helper loaded: util_helper
INFO - 2018-06-22 05:04:54 --> Helper loaded: text_helper
INFO - 2018-06-22 05:04:54 --> Helper loaded: string_helper
INFO - 2018-06-22 05:04:54 --> Database Driver Class Initialized
DEBUG - 2018-06-22 05:04:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 05:04:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 05:04:54 --> Email Class Initialized
INFO - 2018-06-22 05:04:54 --> Controller Class Initialized
DEBUG - 2018-06-22 05:04:54 --> Users MX_Controller Initialized
DEBUG - 2018-06-22 05:04:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-22 05:04:54 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-22 05:04:54 --> Login MX_Controller Initialized
INFO - 2018-06-22 05:04:54 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-22 05:04:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-22 05:04:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-06-22 05:04:54 --> Final output sent to browser
DEBUG - 2018-06-22 05:04:54 --> Total execution time: 0.6107
INFO - 2018-06-22 05:04:58 --> Config Class Initialized
INFO - 2018-06-22 05:04:58 --> Hooks Class Initialized
DEBUG - 2018-06-22 05:04:58 --> UTF-8 Support Enabled
INFO - 2018-06-22 05:04:58 --> Utf8 Class Initialized
INFO - 2018-06-22 05:04:58 --> URI Class Initialized
INFO - 2018-06-22 05:04:58 --> Router Class Initialized
INFO - 2018-06-22 05:04:58 --> Output Class Initialized
INFO - 2018-06-22 05:04:58 --> Security Class Initialized
DEBUG - 2018-06-22 05:04:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 05:04:58 --> Input Class Initialized
INFO - 2018-06-22 05:04:58 --> Language Class Initialized
INFO - 2018-06-22 05:04:58 --> Language Class Initialized
INFO - 2018-06-22 05:04:58 --> Config Class Initialized
INFO - 2018-06-22 05:04:58 --> Loader Class Initialized
DEBUG - 2018-06-22 05:04:58 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-22 05:04:58 --> Helper loaded: url_helper
INFO - 2018-06-22 05:04:58 --> Helper loaded: form_helper
INFO - 2018-06-22 05:04:58 --> Helper loaded: date_helper
INFO - 2018-06-22 05:04:58 --> Helper loaded: util_helper
INFO - 2018-06-22 05:04:58 --> Helper loaded: text_helper
INFO - 2018-06-22 05:04:58 --> Helper loaded: string_helper
INFO - 2018-06-22 05:04:58 --> Database Driver Class Initialized
DEBUG - 2018-06-22 05:04:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 05:04:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 05:04:58 --> Email Class Initialized
INFO - 2018-06-22 05:04:58 --> Controller Class Initialized
DEBUG - 2018-06-22 05:04:58 --> Admin MX_Controller Initialized
INFO - 2018-06-22 05:04:58 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-22 05:04:58 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-22 05:04:58 --> Login MX_Controller Initialized
DEBUG - 2018-06-22 05:04:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-22 05:04:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-22 05:04:58 --> Final output sent to browser
DEBUG - 2018-06-22 05:04:58 --> Total execution time: 0.4852
INFO - 2018-06-22 05:05:00 --> Config Class Initialized
INFO - 2018-06-22 05:05:00 --> Hooks Class Initialized
DEBUG - 2018-06-22 05:05:00 --> UTF-8 Support Enabled
INFO - 2018-06-22 05:05:00 --> Utf8 Class Initialized
INFO - 2018-06-22 05:05:00 --> URI Class Initialized
INFO - 2018-06-22 05:05:00 --> Router Class Initialized
INFO - 2018-06-22 05:05:00 --> Output Class Initialized
INFO - 2018-06-22 05:05:00 --> Security Class Initialized
DEBUG - 2018-06-22 05:05:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 05:05:01 --> Input Class Initialized
INFO - 2018-06-22 05:05:01 --> Language Class Initialized
INFO - 2018-06-22 05:05:01 --> Language Class Initialized
INFO - 2018-06-22 05:05:01 --> Config Class Initialized
INFO - 2018-06-22 05:05:01 --> Loader Class Initialized
DEBUG - 2018-06-22 05:05:01 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-22 05:05:01 --> Helper loaded: url_helper
INFO - 2018-06-22 05:05:01 --> Helper loaded: form_helper
INFO - 2018-06-22 05:05:01 --> Helper loaded: date_helper
INFO - 2018-06-22 05:05:01 --> Helper loaded: util_helper
INFO - 2018-06-22 05:05:01 --> Helper loaded: text_helper
INFO - 2018-06-22 05:05:01 --> Helper loaded: string_helper
INFO - 2018-06-22 05:05:01 --> Database Driver Class Initialized
DEBUG - 2018-06-22 05:05:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 05:05:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 05:05:01 --> Email Class Initialized
INFO - 2018-06-22 05:05:01 --> Controller Class Initialized
DEBUG - 2018-06-22 05:05:01 --> Users MX_Controller Initialized
DEBUG - 2018-06-22 05:05:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-22 05:05:01 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-22 05:05:01 --> Login MX_Controller Initialized
INFO - 2018-06-22 05:05:01 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-22 05:05:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-22 05:05:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-06-22 05:05:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-22 05:05:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-22 05:05:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-22 05:05:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-22 05:05:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-22 05:05:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-06-22 05:05:01 --> Final output sent to browser
DEBUG - 2018-06-22 05:05:01 --> Total execution time: 0.4520
INFO - 2018-06-22 05:05:03 --> Config Class Initialized
INFO - 2018-06-22 05:05:03 --> Hooks Class Initialized
DEBUG - 2018-06-22 05:05:03 --> UTF-8 Support Enabled
INFO - 2018-06-22 05:05:03 --> Utf8 Class Initialized
INFO - 2018-06-22 05:05:03 --> URI Class Initialized
INFO - 2018-06-22 05:05:03 --> Router Class Initialized
INFO - 2018-06-22 05:05:03 --> Output Class Initialized
INFO - 2018-06-22 05:05:03 --> Security Class Initialized
DEBUG - 2018-06-22 05:05:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 05:05:03 --> Input Class Initialized
INFO - 2018-06-22 05:05:03 --> Language Class Initialized
INFO - 2018-06-22 05:05:03 --> Language Class Initialized
INFO - 2018-06-22 05:05:03 --> Config Class Initialized
INFO - 2018-06-22 05:05:03 --> Loader Class Initialized
DEBUG - 2018-06-22 05:05:03 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-22 05:05:03 --> Helper loaded: url_helper
INFO - 2018-06-22 05:05:03 --> Helper loaded: form_helper
INFO - 2018-06-22 05:05:03 --> Helper loaded: date_helper
INFO - 2018-06-22 05:05:03 --> Helper loaded: util_helper
INFO - 2018-06-22 05:05:03 --> Helper loaded: text_helper
INFO - 2018-06-22 05:05:03 --> Helper loaded: string_helper
INFO - 2018-06-22 05:05:03 --> Database Driver Class Initialized
DEBUG - 2018-06-22 05:05:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 05:05:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 05:05:03 --> Email Class Initialized
INFO - 2018-06-22 05:05:03 --> Controller Class Initialized
DEBUG - 2018-06-22 05:05:03 --> Users MX_Controller Initialized
DEBUG - 2018-06-22 05:05:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-22 05:05:03 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-22 05:05:04 --> Login MX_Controller Initialized
INFO - 2018-06-22 05:05:04 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-22 05:05:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-22 05:05:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-22 05:05:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-22 05:05:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-22 05:05:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-22 05:05:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-22 05:05:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-06-22 05:05:04 --> Final output sent to browser
DEBUG - 2018-06-22 05:05:04 --> Total execution time: 0.4249
INFO - 2018-06-22 05:05:04 --> Config Class Initialized
INFO - 2018-06-22 05:05:04 --> Hooks Class Initialized
DEBUG - 2018-06-22 05:05:04 --> UTF-8 Support Enabled
INFO - 2018-06-22 05:05:04 --> Utf8 Class Initialized
INFO - 2018-06-22 05:05:04 --> URI Class Initialized
INFO - 2018-06-22 05:05:04 --> Router Class Initialized
INFO - 2018-06-22 05:05:04 --> Output Class Initialized
INFO - 2018-06-22 05:05:04 --> Security Class Initialized
DEBUG - 2018-06-22 05:05:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 05:05:04 --> Input Class Initialized
INFO - 2018-06-22 05:05:04 --> Language Class Initialized
INFO - 2018-06-22 05:05:04 --> Language Class Initialized
INFO - 2018-06-22 05:05:04 --> Config Class Initialized
INFO - 2018-06-22 05:05:04 --> Loader Class Initialized
DEBUG - 2018-06-22 05:05:04 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-22 05:05:04 --> Helper loaded: url_helper
INFO - 2018-06-22 05:05:04 --> Helper loaded: form_helper
INFO - 2018-06-22 05:05:04 --> Helper loaded: date_helper
INFO - 2018-06-22 05:05:04 --> Helper loaded: util_helper
INFO - 2018-06-22 05:05:04 --> Helper loaded: text_helper
INFO - 2018-06-22 05:05:04 --> Helper loaded: string_helper
INFO - 2018-06-22 05:05:04 --> Database Driver Class Initialized
DEBUG - 2018-06-22 05:05:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 05:05:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 05:05:04 --> Email Class Initialized
INFO - 2018-06-22 05:05:04 --> Controller Class Initialized
DEBUG - 2018-06-22 05:05:04 --> Users MX_Controller Initialized
DEBUG - 2018-06-22 05:05:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-22 05:05:04 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-22 05:05:04 --> Login MX_Controller Initialized
INFO - 2018-06-22 05:05:04 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-22 05:05:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-22 05:05:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-06-22 05:05:04 --> Final output sent to browser
DEBUG - 2018-06-22 05:05:04 --> Total execution time: 0.5783
INFO - 2018-06-22 05:05:06 --> Config Class Initialized
INFO - 2018-06-22 05:05:06 --> Hooks Class Initialized
DEBUG - 2018-06-22 05:05:06 --> UTF-8 Support Enabled
INFO - 2018-06-22 05:05:06 --> Utf8 Class Initialized
INFO - 2018-06-22 05:05:06 --> URI Class Initialized
INFO - 2018-06-22 05:05:06 --> Router Class Initialized
INFO - 2018-06-22 05:05:06 --> Output Class Initialized
INFO - 2018-06-22 05:05:06 --> Security Class Initialized
DEBUG - 2018-06-22 05:05:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 05:05:06 --> Input Class Initialized
INFO - 2018-06-22 05:05:06 --> Language Class Initialized
INFO - 2018-06-22 05:05:06 --> Language Class Initialized
INFO - 2018-06-22 05:05:06 --> Config Class Initialized
INFO - 2018-06-22 05:05:06 --> Loader Class Initialized
DEBUG - 2018-06-22 05:05:06 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-22 05:05:06 --> Helper loaded: url_helper
INFO - 2018-06-22 05:05:06 --> Helper loaded: form_helper
INFO - 2018-06-22 05:05:06 --> Helper loaded: date_helper
INFO - 2018-06-22 05:05:06 --> Helper loaded: util_helper
INFO - 2018-06-22 05:05:06 --> Helper loaded: text_helper
INFO - 2018-06-22 05:05:06 --> Helper loaded: string_helper
INFO - 2018-06-22 05:05:06 --> Database Driver Class Initialized
DEBUG - 2018-06-22 05:05:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 05:05:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 05:05:06 --> Email Class Initialized
INFO - 2018-06-22 05:05:06 --> Controller Class Initialized
DEBUG - 2018-06-22 05:05:06 --> Users MX_Controller Initialized
DEBUG - 2018-06-22 05:05:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-22 05:05:06 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-22 05:05:06 --> Login MX_Controller Initialized
INFO - 2018-06-22 05:05:06 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-22 05:05:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-22 05:05:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-06-22 05:05:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-22 05:05:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-22 05:05:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-22 05:05:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-22 05:05:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-22 05:05:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-06-22 05:05:06 --> Final output sent to browser
DEBUG - 2018-06-22 05:05:06 --> Total execution time: 0.5195
INFO - 2018-06-22 05:05:09 --> Config Class Initialized
INFO - 2018-06-22 05:05:09 --> Hooks Class Initialized
DEBUG - 2018-06-22 05:05:09 --> UTF-8 Support Enabled
INFO - 2018-06-22 05:05:09 --> Utf8 Class Initialized
INFO - 2018-06-22 05:05:09 --> URI Class Initialized
INFO - 2018-06-22 05:05:09 --> Router Class Initialized
INFO - 2018-06-22 05:05:09 --> Output Class Initialized
INFO - 2018-06-22 05:05:09 --> Security Class Initialized
DEBUG - 2018-06-22 05:05:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 05:05:09 --> Input Class Initialized
INFO - 2018-06-22 05:05:09 --> Language Class Initialized
INFO - 2018-06-22 05:05:09 --> Language Class Initialized
INFO - 2018-06-22 05:05:09 --> Config Class Initialized
INFO - 2018-06-22 05:05:09 --> Loader Class Initialized
DEBUG - 2018-06-22 05:05:09 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-22 05:05:09 --> Helper loaded: url_helper
INFO - 2018-06-22 05:05:09 --> Helper loaded: form_helper
INFO - 2018-06-22 05:05:09 --> Helper loaded: date_helper
INFO - 2018-06-22 05:05:09 --> Helper loaded: util_helper
INFO - 2018-06-22 05:05:09 --> Helper loaded: text_helper
INFO - 2018-06-22 05:05:09 --> Helper loaded: string_helper
INFO - 2018-06-22 05:05:09 --> Database Driver Class Initialized
DEBUG - 2018-06-22 05:05:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 05:05:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 05:05:09 --> Email Class Initialized
INFO - 2018-06-22 05:05:09 --> Controller Class Initialized
DEBUG - 2018-06-22 05:05:09 --> Users MX_Controller Initialized
DEBUG - 2018-06-22 05:05:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-22 05:05:09 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-22 05:05:09 --> Login MX_Controller Initialized
INFO - 2018-06-22 05:05:09 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-22 05:05:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-22 05:05:09 --> Final output sent to browser
DEBUG - 2018-06-22 05:05:09 --> Total execution time: 0.3928
INFO - 2018-06-22 05:05:35 --> Config Class Initialized
INFO - 2018-06-22 05:05:35 --> Hooks Class Initialized
DEBUG - 2018-06-22 05:05:35 --> UTF-8 Support Enabled
INFO - 2018-06-22 05:05:35 --> Utf8 Class Initialized
INFO - 2018-06-22 05:05:35 --> URI Class Initialized
INFO - 2018-06-22 05:05:35 --> Router Class Initialized
INFO - 2018-06-22 05:05:35 --> Output Class Initialized
INFO - 2018-06-22 05:05:35 --> Security Class Initialized
DEBUG - 2018-06-22 05:05:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 05:05:35 --> Input Class Initialized
INFO - 2018-06-22 05:05:35 --> Language Class Initialized
INFO - 2018-06-22 05:05:35 --> Language Class Initialized
INFO - 2018-06-22 05:05:35 --> Config Class Initialized
INFO - 2018-06-22 05:05:35 --> Loader Class Initialized
DEBUG - 2018-06-22 05:05:35 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-22 05:05:35 --> Helper loaded: url_helper
INFO - 2018-06-22 05:05:35 --> Helper loaded: form_helper
INFO - 2018-06-22 05:05:35 --> Helper loaded: date_helper
INFO - 2018-06-22 05:05:35 --> Helper loaded: util_helper
INFO - 2018-06-22 05:05:35 --> Helper loaded: text_helper
INFO - 2018-06-22 05:05:35 --> Helper loaded: string_helper
INFO - 2018-06-22 05:05:35 --> Database Driver Class Initialized
DEBUG - 2018-06-22 05:05:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 05:05:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 05:05:36 --> Email Class Initialized
INFO - 2018-06-22 05:05:36 --> Controller Class Initialized
DEBUG - 2018-06-22 05:05:36 --> Users MX_Controller Initialized
DEBUG - 2018-06-22 05:05:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-22 05:05:36 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-22 05:05:36 --> Login MX_Controller Initialized
INFO - 2018-06-22 05:05:36 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-22 05:05:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-22 05:05:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-06-22 05:05:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-22 05:05:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-22 05:05:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-22 05:05:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-22 05:05:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-22 05:05:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-06-22 05:05:36 --> Final output sent to browser
DEBUG - 2018-06-22 05:05:36 --> Total execution time: 0.4563
INFO - 2018-06-22 05:10:49 --> Config Class Initialized
INFO - 2018-06-22 05:10:49 --> Hooks Class Initialized
DEBUG - 2018-06-22 05:10:49 --> UTF-8 Support Enabled
INFO - 2018-06-22 05:10:49 --> Utf8 Class Initialized
INFO - 2018-06-22 05:10:49 --> URI Class Initialized
INFO - 2018-06-22 05:10:49 --> Router Class Initialized
INFO - 2018-06-22 05:10:49 --> Output Class Initialized
INFO - 2018-06-22 05:10:49 --> Security Class Initialized
DEBUG - 2018-06-22 05:10:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 05:10:49 --> Input Class Initialized
INFO - 2018-06-22 05:10:49 --> Language Class Initialized
INFO - 2018-06-22 05:10:49 --> Language Class Initialized
INFO - 2018-06-22 05:10:49 --> Config Class Initialized
INFO - 2018-06-22 05:10:49 --> Loader Class Initialized
DEBUG - 2018-06-22 05:10:49 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-22 05:10:49 --> Helper loaded: url_helper
INFO - 2018-06-22 05:10:49 --> Helper loaded: form_helper
INFO - 2018-06-22 05:10:49 --> Helper loaded: date_helper
INFO - 2018-06-22 05:10:49 --> Helper loaded: util_helper
INFO - 2018-06-22 05:10:49 --> Helper loaded: text_helper
INFO - 2018-06-22 05:10:49 --> Helper loaded: string_helper
INFO - 2018-06-22 05:10:49 --> Database Driver Class Initialized
DEBUG - 2018-06-22 05:10:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 05:10:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 05:10:49 --> Email Class Initialized
INFO - 2018-06-22 05:10:49 --> Controller Class Initialized
DEBUG - 2018-06-22 05:10:49 --> Users MX_Controller Initialized
DEBUG - 2018-06-22 05:10:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-22 05:10:49 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-22 05:10:49 --> Login MX_Controller Initialized
INFO - 2018-06-22 05:10:49 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-22 05:10:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-22 05:10:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-22 05:10:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-22 05:10:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-22 05:10:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-22 05:10:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-22 05:10:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-06-22 05:10:49 --> Final output sent to browser
DEBUG - 2018-06-22 05:10:50 --> Total execution time: 0.4895
INFO - 2018-06-22 05:10:50 --> Config Class Initialized
INFO - 2018-06-22 05:10:50 --> Hooks Class Initialized
DEBUG - 2018-06-22 05:10:50 --> UTF-8 Support Enabled
INFO - 2018-06-22 05:10:50 --> Utf8 Class Initialized
INFO - 2018-06-22 05:10:50 --> URI Class Initialized
INFO - 2018-06-22 05:10:50 --> Router Class Initialized
INFO - 2018-06-22 05:10:51 --> Output Class Initialized
INFO - 2018-06-22 05:10:51 --> Security Class Initialized
DEBUG - 2018-06-22 05:10:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 05:10:51 --> Input Class Initialized
INFO - 2018-06-22 05:10:51 --> Language Class Initialized
INFO - 2018-06-22 05:10:51 --> Language Class Initialized
INFO - 2018-06-22 05:10:51 --> Config Class Initialized
INFO - 2018-06-22 05:10:51 --> Loader Class Initialized
DEBUG - 2018-06-22 05:10:51 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-22 05:10:51 --> Helper loaded: url_helper
INFO - 2018-06-22 05:10:51 --> Helper loaded: form_helper
INFO - 2018-06-22 05:10:51 --> Helper loaded: date_helper
INFO - 2018-06-22 05:10:51 --> Helper loaded: util_helper
INFO - 2018-06-22 05:10:51 --> Helper loaded: text_helper
INFO - 2018-06-22 05:10:51 --> Helper loaded: string_helper
INFO - 2018-06-22 05:10:51 --> Database Driver Class Initialized
DEBUG - 2018-06-22 05:10:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 05:10:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 05:10:51 --> Email Class Initialized
INFO - 2018-06-22 05:10:51 --> Controller Class Initialized
DEBUG - 2018-06-22 05:10:51 --> Users MX_Controller Initialized
DEBUG - 2018-06-22 05:10:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-22 05:10:51 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-22 05:10:51 --> Login MX_Controller Initialized
INFO - 2018-06-22 05:10:51 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-22 05:10:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-22 05:10:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-06-22 05:10:51 --> Final output sent to browser
DEBUG - 2018-06-22 05:10:51 --> Total execution time: 0.6617
INFO - 2018-06-22 05:10:54 --> Config Class Initialized
INFO - 2018-06-22 05:10:54 --> Hooks Class Initialized
DEBUG - 2018-06-22 05:10:54 --> UTF-8 Support Enabled
INFO - 2018-06-22 05:10:54 --> Utf8 Class Initialized
INFO - 2018-06-22 05:10:54 --> URI Class Initialized
INFO - 2018-06-22 05:10:54 --> Router Class Initialized
INFO - 2018-06-22 05:10:54 --> Output Class Initialized
INFO - 2018-06-22 05:10:54 --> Security Class Initialized
DEBUG - 2018-06-22 05:10:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 05:10:54 --> Input Class Initialized
INFO - 2018-06-22 05:10:54 --> Language Class Initialized
INFO - 2018-06-22 05:10:54 --> Language Class Initialized
INFO - 2018-06-22 05:10:54 --> Config Class Initialized
INFO - 2018-06-22 05:10:54 --> Loader Class Initialized
DEBUG - 2018-06-22 05:10:54 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-22 05:10:54 --> Helper loaded: url_helper
INFO - 2018-06-22 05:10:54 --> Helper loaded: form_helper
INFO - 2018-06-22 05:10:54 --> Helper loaded: date_helper
INFO - 2018-06-22 05:10:54 --> Helper loaded: util_helper
INFO - 2018-06-22 05:10:54 --> Helper loaded: text_helper
INFO - 2018-06-22 05:10:54 --> Helper loaded: string_helper
INFO - 2018-06-22 05:10:54 --> Database Driver Class Initialized
DEBUG - 2018-06-22 05:10:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 05:10:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 05:10:54 --> Email Class Initialized
INFO - 2018-06-22 05:10:54 --> Controller Class Initialized
DEBUG - 2018-06-22 05:10:54 --> Users MX_Controller Initialized
DEBUG - 2018-06-22 05:10:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-22 05:10:54 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-22 05:10:54 --> Login MX_Controller Initialized
INFO - 2018-06-22 05:10:54 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-22 05:10:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-22 05:10:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-06-22 05:10:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-22 05:10:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-22 05:10:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-22 05:10:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-22 05:10:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-22 05:10:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-06-22 05:10:54 --> Final output sent to browser
DEBUG - 2018-06-22 05:10:54 --> Total execution time: 0.7000
INFO - 2018-06-22 05:10:56 --> Config Class Initialized
INFO - 2018-06-22 05:10:56 --> Hooks Class Initialized
DEBUG - 2018-06-22 05:10:56 --> UTF-8 Support Enabled
INFO - 2018-06-22 05:10:56 --> Utf8 Class Initialized
INFO - 2018-06-22 05:10:56 --> URI Class Initialized
INFO - 2018-06-22 05:10:56 --> Router Class Initialized
INFO - 2018-06-22 05:10:56 --> Output Class Initialized
INFO - 2018-06-22 05:10:56 --> Security Class Initialized
DEBUG - 2018-06-22 05:10:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 05:10:56 --> Input Class Initialized
INFO - 2018-06-22 05:10:56 --> Language Class Initialized
INFO - 2018-06-22 05:10:56 --> Language Class Initialized
INFO - 2018-06-22 05:10:56 --> Config Class Initialized
INFO - 2018-06-22 05:10:56 --> Loader Class Initialized
DEBUG - 2018-06-22 05:10:56 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-22 05:10:56 --> Helper loaded: url_helper
INFO - 2018-06-22 05:10:56 --> Helper loaded: form_helper
INFO - 2018-06-22 05:10:56 --> Helper loaded: date_helper
INFO - 2018-06-22 05:10:56 --> Helper loaded: util_helper
INFO - 2018-06-22 05:10:56 --> Helper loaded: text_helper
INFO - 2018-06-22 05:10:56 --> Helper loaded: string_helper
INFO - 2018-06-22 05:10:56 --> Database Driver Class Initialized
DEBUG - 2018-06-22 05:10:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 05:10:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 05:10:57 --> Email Class Initialized
INFO - 2018-06-22 05:10:57 --> Controller Class Initialized
DEBUG - 2018-06-22 05:10:57 --> Users MX_Controller Initialized
DEBUG - 2018-06-22 05:10:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-22 05:10:57 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-22 05:10:57 --> Login MX_Controller Initialized
INFO - 2018-06-22 05:10:57 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-22 05:10:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-22 05:10:57 --> Final output sent to browser
DEBUG - 2018-06-22 05:10:57 --> Total execution time: 0.3915
INFO - 2018-06-22 05:11:16 --> Config Class Initialized
INFO - 2018-06-22 05:11:16 --> Hooks Class Initialized
DEBUG - 2018-06-22 05:11:16 --> UTF-8 Support Enabled
INFO - 2018-06-22 05:11:16 --> Utf8 Class Initialized
INFO - 2018-06-22 05:11:16 --> URI Class Initialized
INFO - 2018-06-22 05:11:16 --> Router Class Initialized
INFO - 2018-06-22 05:11:16 --> Output Class Initialized
INFO - 2018-06-22 05:11:16 --> Security Class Initialized
DEBUG - 2018-06-22 05:11:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 05:11:16 --> Input Class Initialized
INFO - 2018-06-22 05:11:16 --> Language Class Initialized
INFO - 2018-06-22 05:11:16 --> Language Class Initialized
INFO - 2018-06-22 05:11:16 --> Config Class Initialized
INFO - 2018-06-22 05:11:16 --> Loader Class Initialized
DEBUG - 2018-06-22 05:11:16 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-22 05:11:16 --> Helper loaded: url_helper
INFO - 2018-06-22 05:11:16 --> Helper loaded: form_helper
INFO - 2018-06-22 05:11:16 --> Helper loaded: date_helper
INFO - 2018-06-22 05:11:16 --> Helper loaded: util_helper
INFO - 2018-06-22 05:11:16 --> Helper loaded: text_helper
INFO - 2018-06-22 05:11:16 --> Helper loaded: string_helper
INFO - 2018-06-22 05:11:16 --> Database Driver Class Initialized
DEBUG - 2018-06-22 05:11:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 05:11:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 05:11:16 --> Email Class Initialized
INFO - 2018-06-22 05:11:16 --> Controller Class Initialized
DEBUG - 2018-06-22 05:11:16 --> Users MX_Controller Initialized
DEBUG - 2018-06-22 05:11:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-22 05:11:16 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-22 05:11:16 --> Login MX_Controller Initialized
INFO - 2018-06-22 05:11:16 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-22 05:11:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-22 05:11:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-06-22 05:11:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
INFO - 2018-06-22 05:11:16 --> Upload Class Initialized
INFO - 2018-06-22 05:12:46 --> Config Class Initialized
INFO - 2018-06-22 05:12:46 --> Hooks Class Initialized
DEBUG - 2018-06-22 05:12:46 --> UTF-8 Support Enabled
INFO - 2018-06-22 05:12:46 --> Utf8 Class Initialized
INFO - 2018-06-22 05:12:46 --> URI Class Initialized
INFO - 2018-06-22 05:12:46 --> Router Class Initialized
INFO - 2018-06-22 05:12:46 --> Output Class Initialized
INFO - 2018-06-22 05:12:46 --> Security Class Initialized
DEBUG - 2018-06-22 05:12:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 05:12:46 --> Input Class Initialized
INFO - 2018-06-22 05:12:46 --> Language Class Initialized
INFO - 2018-06-22 05:12:46 --> Language Class Initialized
INFO - 2018-06-22 05:12:46 --> Config Class Initialized
INFO - 2018-06-22 05:12:46 --> Loader Class Initialized
DEBUG - 2018-06-22 05:12:46 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-22 05:12:46 --> Helper loaded: url_helper
INFO - 2018-06-22 05:12:46 --> Helper loaded: form_helper
INFO - 2018-06-22 05:12:46 --> Helper loaded: date_helper
INFO - 2018-06-22 05:12:46 --> Helper loaded: util_helper
INFO - 2018-06-22 05:12:46 --> Helper loaded: text_helper
INFO - 2018-06-22 05:12:46 --> Helper loaded: string_helper
INFO - 2018-06-22 05:12:46 --> Database Driver Class Initialized
DEBUG - 2018-06-22 05:12:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 05:12:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 05:12:46 --> Email Class Initialized
INFO - 2018-06-22 05:12:46 --> Controller Class Initialized
DEBUG - 2018-06-22 05:12:46 --> Users MX_Controller Initialized
DEBUG - 2018-06-22 05:12:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-22 05:12:46 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-22 05:12:46 --> Login MX_Controller Initialized
INFO - 2018-06-22 05:12:46 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-22 05:12:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-22 05:12:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-06-22 05:12:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
INFO - 2018-06-22 05:12:46 --> Upload Class Initialized
ERROR - 2018-06-22 05:12:46 --> Query error: Unknown column 'user_password' in 'field list' - Invalid query: INSERT INTO `users` (`first_name`, `email`, `role_id`, `user_password`, `image`) VALUES ('Gopi Testing', 'gopaltesting@yopmail.com', '3', 'e10adc3949ba59abbe56e057f20f883e', 'Gopi-Testing-G0tlNd2YLOMExj9J.jpg')
INFO - 2018-06-22 05:12:46 --> Language file loaded: language/english/db_lang.php
INFO - 2018-06-22 05:13:01 --> Config Class Initialized
INFO - 2018-06-22 05:13:01 --> Hooks Class Initialized
DEBUG - 2018-06-22 05:13:01 --> UTF-8 Support Enabled
INFO - 2018-06-22 05:13:01 --> Utf8 Class Initialized
INFO - 2018-06-22 05:13:01 --> URI Class Initialized
INFO - 2018-06-22 05:13:01 --> Router Class Initialized
INFO - 2018-06-22 05:13:01 --> Output Class Initialized
INFO - 2018-06-22 05:13:01 --> Security Class Initialized
DEBUG - 2018-06-22 05:13:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 05:13:01 --> Input Class Initialized
INFO - 2018-06-22 05:13:01 --> Language Class Initialized
INFO - 2018-06-22 05:13:01 --> Language Class Initialized
INFO - 2018-06-22 05:13:01 --> Config Class Initialized
INFO - 2018-06-22 05:13:01 --> Loader Class Initialized
DEBUG - 2018-06-22 05:13:01 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-22 05:13:01 --> Helper loaded: url_helper
INFO - 2018-06-22 05:13:01 --> Helper loaded: form_helper
INFO - 2018-06-22 05:13:01 --> Helper loaded: date_helper
INFO - 2018-06-22 05:13:01 --> Helper loaded: util_helper
INFO - 2018-06-22 05:13:01 --> Helper loaded: text_helper
INFO - 2018-06-22 05:13:02 --> Helper loaded: string_helper
INFO - 2018-06-22 05:13:02 --> Database Driver Class Initialized
DEBUG - 2018-06-22 05:13:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 05:13:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 05:13:02 --> Email Class Initialized
INFO - 2018-06-22 05:13:02 --> Controller Class Initialized
DEBUG - 2018-06-22 05:13:02 --> Users MX_Controller Initialized
DEBUG - 2018-06-22 05:13:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-22 05:13:02 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-22 05:13:02 --> Login MX_Controller Initialized
INFO - 2018-06-22 05:13:02 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-22 05:13:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-22 05:13:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-06-22 05:13:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
INFO - 2018-06-22 05:13:02 --> Upload Class Initialized
INFO - 2018-06-22 05:13:02 --> Config Class Initialized
INFO - 2018-06-22 05:13:02 --> Hooks Class Initialized
DEBUG - 2018-06-22 05:13:02 --> UTF-8 Support Enabled
INFO - 2018-06-22 05:13:02 --> Utf8 Class Initialized
INFO - 2018-06-22 05:13:02 --> URI Class Initialized
INFO - 2018-06-22 05:13:02 --> Router Class Initialized
INFO - 2018-06-22 05:13:02 --> Output Class Initialized
INFO - 2018-06-22 05:13:02 --> Security Class Initialized
DEBUG - 2018-06-22 05:13:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 05:13:02 --> Input Class Initialized
INFO - 2018-06-22 05:13:02 --> Language Class Initialized
INFO - 2018-06-22 05:13:02 --> Language Class Initialized
INFO - 2018-06-22 05:13:02 --> Config Class Initialized
INFO - 2018-06-22 05:13:02 --> Loader Class Initialized
DEBUG - 2018-06-22 05:13:02 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-22 05:13:02 --> Helper loaded: url_helper
INFO - 2018-06-22 05:13:02 --> Helper loaded: form_helper
INFO - 2018-06-22 05:13:02 --> Helper loaded: date_helper
INFO - 2018-06-22 05:13:02 --> Helper loaded: util_helper
INFO - 2018-06-22 05:13:02 --> Helper loaded: text_helper
INFO - 2018-06-22 05:13:02 --> Helper loaded: string_helper
INFO - 2018-06-22 05:13:02 --> Database Driver Class Initialized
DEBUG - 2018-06-22 05:13:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 05:13:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 05:13:02 --> Email Class Initialized
INFO - 2018-06-22 05:13:02 --> Controller Class Initialized
DEBUG - 2018-06-22 05:13:02 --> Users MX_Controller Initialized
DEBUG - 2018-06-22 05:13:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-22 05:13:02 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-22 05:13:02 --> Login MX_Controller Initialized
INFO - 2018-06-22 05:13:02 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-22 05:13:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-22 05:13:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-22 05:13:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-22 05:13:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-22 05:13:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-22 05:13:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-22 05:13:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-06-22 05:13:02 --> Final output sent to browser
DEBUG - 2018-06-22 05:13:02 --> Total execution time: 0.4601
INFO - 2018-06-22 05:13:03 --> Config Class Initialized
INFO - 2018-06-22 05:13:03 --> Hooks Class Initialized
DEBUG - 2018-06-22 05:13:03 --> UTF-8 Support Enabled
INFO - 2018-06-22 05:13:03 --> Utf8 Class Initialized
INFO - 2018-06-22 05:13:03 --> URI Class Initialized
INFO - 2018-06-22 05:13:03 --> Router Class Initialized
INFO - 2018-06-22 05:13:03 --> Output Class Initialized
INFO - 2018-06-22 05:13:03 --> Security Class Initialized
DEBUG - 2018-06-22 05:13:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 05:13:03 --> Input Class Initialized
INFO - 2018-06-22 05:13:03 --> Language Class Initialized
INFO - 2018-06-22 05:13:03 --> Language Class Initialized
INFO - 2018-06-22 05:13:03 --> Config Class Initialized
INFO - 2018-06-22 05:13:03 --> Loader Class Initialized
DEBUG - 2018-06-22 05:13:03 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-22 05:13:03 --> Helper loaded: url_helper
INFO - 2018-06-22 05:13:03 --> Helper loaded: form_helper
INFO - 2018-06-22 05:13:03 --> Helper loaded: date_helper
INFO - 2018-06-22 05:13:03 --> Helper loaded: util_helper
INFO - 2018-06-22 05:13:03 --> Helper loaded: text_helper
INFO - 2018-06-22 05:13:03 --> Helper loaded: string_helper
INFO - 2018-06-22 05:13:03 --> Database Driver Class Initialized
DEBUG - 2018-06-22 05:13:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 05:13:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 05:13:03 --> Email Class Initialized
INFO - 2018-06-22 05:13:03 --> Controller Class Initialized
DEBUG - 2018-06-22 05:13:03 --> Users MX_Controller Initialized
DEBUG - 2018-06-22 05:13:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-22 05:13:03 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-22 05:13:03 --> Login MX_Controller Initialized
INFO - 2018-06-22 05:13:03 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-22 05:13:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-22 05:13:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-06-22 05:13:03 --> Final output sent to browser
DEBUG - 2018-06-22 05:13:03 --> Total execution time: 0.6283
INFO - 2018-06-22 05:13:07 --> Config Class Initialized
INFO - 2018-06-22 05:13:07 --> Hooks Class Initialized
DEBUG - 2018-06-22 05:13:07 --> UTF-8 Support Enabled
INFO - 2018-06-22 05:13:07 --> Utf8 Class Initialized
INFO - 2018-06-22 05:13:07 --> URI Class Initialized
INFO - 2018-06-22 05:13:07 --> Router Class Initialized
INFO - 2018-06-22 05:13:07 --> Output Class Initialized
INFO - 2018-06-22 05:13:07 --> Security Class Initialized
DEBUG - 2018-06-22 05:13:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 05:13:07 --> Input Class Initialized
INFO - 2018-06-22 05:13:07 --> Language Class Initialized
INFO - 2018-06-22 05:13:07 --> Language Class Initialized
INFO - 2018-06-22 05:13:07 --> Config Class Initialized
INFO - 2018-06-22 05:13:07 --> Loader Class Initialized
DEBUG - 2018-06-22 05:13:07 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-22 05:13:07 --> Helper loaded: url_helper
INFO - 2018-06-22 05:13:07 --> Helper loaded: form_helper
INFO - 2018-06-22 05:13:07 --> Helper loaded: date_helper
INFO - 2018-06-22 05:13:07 --> Helper loaded: util_helper
INFO - 2018-06-22 05:13:07 --> Helper loaded: text_helper
INFO - 2018-06-22 05:13:07 --> Helper loaded: string_helper
INFO - 2018-06-22 05:13:07 --> Database Driver Class Initialized
DEBUG - 2018-06-22 05:13:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 05:13:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 05:13:07 --> Email Class Initialized
INFO - 2018-06-22 05:13:07 --> Controller Class Initialized
DEBUG - 2018-06-22 05:13:07 --> Admin MX_Controller Initialized
INFO - 2018-06-22 05:13:07 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-22 05:13:07 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-22 05:13:07 --> Login MX_Controller Initialized
DEBUG - 2018-06-22 05:13:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-22 05:13:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-22 05:13:08 --> Final output sent to browser
DEBUG - 2018-06-22 05:13:08 --> Total execution time: 0.4750
INFO - 2018-06-22 05:13:08 --> Config Class Initialized
INFO - 2018-06-22 05:13:08 --> Hooks Class Initialized
DEBUG - 2018-06-22 05:13:08 --> UTF-8 Support Enabled
INFO - 2018-06-22 05:13:08 --> Utf8 Class Initialized
INFO - 2018-06-22 05:13:08 --> URI Class Initialized
INFO - 2018-06-22 05:13:08 --> Router Class Initialized
INFO - 2018-06-22 05:13:08 --> Output Class Initialized
INFO - 2018-06-22 05:13:08 --> Security Class Initialized
DEBUG - 2018-06-22 05:13:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 05:13:08 --> Input Class Initialized
INFO - 2018-06-22 05:13:08 --> Language Class Initialized
INFO - 2018-06-22 05:13:08 --> Language Class Initialized
INFO - 2018-06-22 05:13:08 --> Config Class Initialized
INFO - 2018-06-22 05:13:08 --> Loader Class Initialized
DEBUG - 2018-06-22 05:13:08 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-22 05:13:08 --> Helper loaded: url_helper
INFO - 2018-06-22 05:13:08 --> Helper loaded: form_helper
INFO - 2018-06-22 05:13:08 --> Helper loaded: date_helper
INFO - 2018-06-22 05:13:08 --> Helper loaded: util_helper
INFO - 2018-06-22 05:13:08 --> Helper loaded: text_helper
INFO - 2018-06-22 05:13:08 --> Helper loaded: string_helper
INFO - 2018-06-22 05:13:08 --> Database Driver Class Initialized
DEBUG - 2018-06-22 05:13:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 05:13:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 05:13:08 --> Email Class Initialized
INFO - 2018-06-22 05:13:08 --> Controller Class Initialized
DEBUG - 2018-06-22 05:13:08 --> Admin MX_Controller Initialized
INFO - 2018-06-22 05:13:08 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-22 05:13:08 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-22 05:13:08 --> Login MX_Controller Initialized
DEBUG - 2018-06-22 05:13:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-22 05:13:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-22 05:13:09 --> Final output sent to browser
DEBUG - 2018-06-22 05:13:09 --> Total execution time: 0.4725
INFO - 2018-06-22 05:13:11 --> Config Class Initialized
INFO - 2018-06-22 05:13:11 --> Hooks Class Initialized
DEBUG - 2018-06-22 05:13:11 --> UTF-8 Support Enabled
INFO - 2018-06-22 05:13:11 --> Utf8 Class Initialized
INFO - 2018-06-22 05:13:11 --> URI Class Initialized
INFO - 2018-06-22 05:13:11 --> Router Class Initialized
INFO - 2018-06-22 05:13:11 --> Output Class Initialized
INFO - 2018-06-22 05:13:11 --> Security Class Initialized
DEBUG - 2018-06-22 05:13:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 05:13:11 --> Input Class Initialized
INFO - 2018-06-22 05:13:11 --> Language Class Initialized
INFO - 2018-06-22 05:13:11 --> Language Class Initialized
INFO - 2018-06-22 05:13:11 --> Config Class Initialized
INFO - 2018-06-22 05:13:11 --> Loader Class Initialized
DEBUG - 2018-06-22 05:13:11 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-22 05:13:11 --> Helper loaded: url_helper
INFO - 2018-06-22 05:13:11 --> Helper loaded: form_helper
INFO - 2018-06-22 05:13:11 --> Helper loaded: date_helper
INFO - 2018-06-22 05:13:11 --> Helper loaded: util_helper
INFO - 2018-06-22 05:13:11 --> Helper loaded: text_helper
INFO - 2018-06-22 05:13:11 --> Helper loaded: string_helper
INFO - 2018-06-22 05:13:11 --> Database Driver Class Initialized
DEBUG - 2018-06-22 05:13:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 05:13:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 05:13:11 --> Email Class Initialized
INFO - 2018-06-22 05:13:11 --> Controller Class Initialized
DEBUG - 2018-06-22 05:13:11 --> Users MX_Controller Initialized
DEBUG - 2018-06-22 05:13:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-22 05:13:11 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-22 05:13:11 --> Login MX_Controller Initialized
INFO - 2018-06-22 05:13:11 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-22 05:13:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-22 05:13:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-06-22 05:13:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-22 05:13:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-22 05:13:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-22 05:13:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-22 05:13:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-22 05:13:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-06-22 05:13:11 --> Final output sent to browser
DEBUG - 2018-06-22 05:13:11 --> Total execution time: 0.4698
INFO - 2018-06-22 05:13:35 --> Config Class Initialized
INFO - 2018-06-22 05:13:35 --> Hooks Class Initialized
DEBUG - 2018-06-22 05:13:35 --> UTF-8 Support Enabled
INFO - 2018-06-22 05:13:35 --> Utf8 Class Initialized
INFO - 2018-06-22 05:13:35 --> URI Class Initialized
INFO - 2018-06-22 05:13:35 --> Router Class Initialized
INFO - 2018-06-22 05:13:35 --> Output Class Initialized
INFO - 2018-06-22 05:13:35 --> Security Class Initialized
DEBUG - 2018-06-22 05:13:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 05:13:35 --> Input Class Initialized
INFO - 2018-06-22 05:13:35 --> Language Class Initialized
INFO - 2018-06-22 05:13:35 --> Language Class Initialized
INFO - 2018-06-22 05:13:35 --> Config Class Initialized
INFO - 2018-06-22 05:13:35 --> Loader Class Initialized
DEBUG - 2018-06-22 05:13:35 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-22 05:13:35 --> Helper loaded: url_helper
INFO - 2018-06-22 05:13:35 --> Helper loaded: form_helper
INFO - 2018-06-22 05:13:35 --> Helper loaded: date_helper
INFO - 2018-06-22 05:13:35 --> Helper loaded: util_helper
INFO - 2018-06-22 05:13:35 --> Helper loaded: text_helper
INFO - 2018-06-22 05:13:35 --> Helper loaded: string_helper
INFO - 2018-06-22 05:13:35 --> Database Driver Class Initialized
DEBUG - 2018-06-22 05:13:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 05:13:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 05:13:35 --> Email Class Initialized
INFO - 2018-06-22 05:13:35 --> Controller Class Initialized
DEBUG - 2018-06-22 05:13:35 --> Users MX_Controller Initialized
DEBUG - 2018-06-22 05:13:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-22 05:13:35 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-22 05:13:35 --> Login MX_Controller Initialized
INFO - 2018-06-22 05:13:35 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-22 05:13:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-22 05:13:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-22 05:13:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-22 05:13:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-22 05:13:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-22 05:13:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-22 05:13:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-06-22 05:13:35 --> Final output sent to browser
DEBUG - 2018-06-22 05:13:35 --> Total execution time: 0.4931
INFO - 2018-06-22 05:13:36 --> Config Class Initialized
INFO - 2018-06-22 05:13:36 --> Hooks Class Initialized
DEBUG - 2018-06-22 05:13:36 --> UTF-8 Support Enabled
INFO - 2018-06-22 05:13:36 --> Utf8 Class Initialized
INFO - 2018-06-22 05:13:36 --> URI Class Initialized
INFO - 2018-06-22 05:13:36 --> Router Class Initialized
INFO - 2018-06-22 05:13:36 --> Output Class Initialized
INFO - 2018-06-22 05:13:36 --> Security Class Initialized
DEBUG - 2018-06-22 05:13:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 05:13:36 --> Input Class Initialized
INFO - 2018-06-22 05:13:36 --> Language Class Initialized
INFO - 2018-06-22 05:13:36 --> Language Class Initialized
INFO - 2018-06-22 05:13:36 --> Config Class Initialized
INFO - 2018-06-22 05:13:36 --> Loader Class Initialized
DEBUG - 2018-06-22 05:13:36 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-22 05:13:36 --> Helper loaded: url_helper
INFO - 2018-06-22 05:13:36 --> Helper loaded: form_helper
INFO - 2018-06-22 05:13:36 --> Helper loaded: date_helper
INFO - 2018-06-22 05:13:36 --> Helper loaded: util_helper
INFO - 2018-06-22 05:13:36 --> Helper loaded: text_helper
INFO - 2018-06-22 05:13:36 --> Helper loaded: string_helper
INFO - 2018-06-22 05:13:36 --> Database Driver Class Initialized
DEBUG - 2018-06-22 05:13:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 05:13:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 05:13:36 --> Email Class Initialized
INFO - 2018-06-22 05:13:36 --> Controller Class Initialized
DEBUG - 2018-06-22 05:13:36 --> Users MX_Controller Initialized
DEBUG - 2018-06-22 05:13:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-22 05:13:36 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-22 05:13:36 --> Login MX_Controller Initialized
INFO - 2018-06-22 05:13:36 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-22 05:13:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-22 05:13:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-06-22 05:13:36 --> Final output sent to browser
DEBUG - 2018-06-22 05:13:36 --> Total execution time: 0.5771
INFO - 2018-06-22 05:18:37 --> Config Class Initialized
INFO - 2018-06-22 05:18:37 --> Hooks Class Initialized
DEBUG - 2018-06-22 05:18:37 --> UTF-8 Support Enabled
INFO - 2018-06-22 05:18:37 --> Utf8 Class Initialized
INFO - 2018-06-22 05:18:37 --> URI Class Initialized
INFO - 2018-06-22 05:18:37 --> Router Class Initialized
INFO - 2018-06-22 05:18:37 --> Output Class Initialized
INFO - 2018-06-22 05:18:37 --> Security Class Initialized
DEBUG - 2018-06-22 05:18:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 05:18:37 --> Input Class Initialized
INFO - 2018-06-22 05:18:37 --> Language Class Initialized
INFO - 2018-06-22 05:18:38 --> Language Class Initialized
INFO - 2018-06-22 05:18:38 --> Config Class Initialized
INFO - 2018-06-22 05:18:38 --> Loader Class Initialized
DEBUG - 2018-06-22 05:18:38 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-22 05:18:38 --> Helper loaded: url_helper
INFO - 2018-06-22 05:18:38 --> Helper loaded: form_helper
INFO - 2018-06-22 05:18:38 --> Helper loaded: date_helper
INFO - 2018-06-22 05:18:38 --> Helper loaded: util_helper
INFO - 2018-06-22 05:18:38 --> Helper loaded: text_helper
INFO - 2018-06-22 05:18:38 --> Helper loaded: string_helper
INFO - 2018-06-22 05:18:38 --> Database Driver Class Initialized
DEBUG - 2018-06-22 05:18:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 05:18:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 05:18:38 --> Email Class Initialized
INFO - 2018-06-22 05:18:38 --> Controller Class Initialized
DEBUG - 2018-06-22 05:18:38 --> Users MX_Controller Initialized
DEBUG - 2018-06-22 05:18:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-22 05:18:38 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-22 05:18:38 --> Login MX_Controller Initialized
INFO - 2018-06-22 05:18:38 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-22 05:18:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-22 05:18:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-22 05:18:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-22 05:18:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-22 05:18:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-22 05:18:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-22 05:18:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-06-22 05:18:38 --> Final output sent to browser
DEBUG - 2018-06-22 05:18:38 --> Total execution time: 0.5000
INFO - 2018-06-22 05:18:39 --> Config Class Initialized
INFO - 2018-06-22 05:18:39 --> Hooks Class Initialized
DEBUG - 2018-06-22 05:18:39 --> UTF-8 Support Enabled
INFO - 2018-06-22 05:18:39 --> Utf8 Class Initialized
INFO - 2018-06-22 05:18:39 --> URI Class Initialized
INFO - 2018-06-22 05:18:39 --> Router Class Initialized
INFO - 2018-06-22 05:18:39 --> Output Class Initialized
INFO - 2018-06-22 05:18:39 --> Security Class Initialized
DEBUG - 2018-06-22 05:18:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 05:18:39 --> Input Class Initialized
INFO - 2018-06-22 05:18:39 --> Language Class Initialized
INFO - 2018-06-22 05:18:39 --> Language Class Initialized
INFO - 2018-06-22 05:18:39 --> Config Class Initialized
INFO - 2018-06-22 05:18:39 --> Loader Class Initialized
DEBUG - 2018-06-22 05:18:39 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-22 05:18:39 --> Helper loaded: url_helper
INFO - 2018-06-22 05:18:39 --> Helper loaded: form_helper
INFO - 2018-06-22 05:18:39 --> Helper loaded: date_helper
INFO - 2018-06-22 05:18:39 --> Helper loaded: util_helper
INFO - 2018-06-22 05:18:39 --> Helper loaded: text_helper
INFO - 2018-06-22 05:18:39 --> Helper loaded: string_helper
INFO - 2018-06-22 05:18:39 --> Database Driver Class Initialized
DEBUG - 2018-06-22 05:18:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 05:18:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 05:18:39 --> Email Class Initialized
INFO - 2018-06-22 05:18:39 --> Controller Class Initialized
DEBUG - 2018-06-22 05:18:39 --> Users MX_Controller Initialized
DEBUG - 2018-06-22 05:18:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-22 05:18:39 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-22 05:18:39 --> Login MX_Controller Initialized
INFO - 2018-06-22 05:18:39 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-22 05:18:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-22 05:18:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-06-22 05:18:39 --> Final output sent to browser
DEBUG - 2018-06-22 05:18:39 --> Total execution time: 0.5704
INFO - 2018-06-22 05:18:49 --> Config Class Initialized
INFO - 2018-06-22 05:18:49 --> Hooks Class Initialized
DEBUG - 2018-06-22 05:18:49 --> UTF-8 Support Enabled
INFO - 2018-06-22 05:18:49 --> Utf8 Class Initialized
INFO - 2018-06-22 05:18:49 --> URI Class Initialized
INFO - 2018-06-22 05:18:49 --> Router Class Initialized
INFO - 2018-06-22 05:18:49 --> Output Class Initialized
INFO - 2018-06-22 05:18:49 --> Security Class Initialized
DEBUG - 2018-06-22 05:18:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 05:18:49 --> Input Class Initialized
INFO - 2018-06-22 05:18:49 --> Language Class Initialized
INFO - 2018-06-22 05:18:49 --> Language Class Initialized
INFO - 2018-06-22 05:18:49 --> Config Class Initialized
INFO - 2018-06-22 05:18:49 --> Loader Class Initialized
DEBUG - 2018-06-22 05:18:49 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-22 05:18:49 --> Helper loaded: url_helper
INFO - 2018-06-22 05:18:49 --> Helper loaded: form_helper
INFO - 2018-06-22 05:18:49 --> Helper loaded: date_helper
INFO - 2018-06-22 05:18:49 --> Helper loaded: util_helper
INFO - 2018-06-22 05:18:49 --> Helper loaded: text_helper
INFO - 2018-06-22 05:18:49 --> Helper loaded: string_helper
INFO - 2018-06-22 05:18:49 --> Database Driver Class Initialized
DEBUG - 2018-06-22 05:18:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 05:18:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 05:18:49 --> Email Class Initialized
INFO - 2018-06-22 05:18:49 --> Controller Class Initialized
DEBUG - 2018-06-22 05:18:49 --> Admin MX_Controller Initialized
INFO - 2018-06-22 05:18:49 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-22 05:18:49 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-22 05:18:49 --> Login MX_Controller Initialized
DEBUG - 2018-06-22 05:18:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-22 05:18:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-22 05:18:49 --> Final output sent to browser
DEBUG - 2018-06-22 05:18:49 --> Total execution time: 0.4900
INFO - 2018-06-22 05:18:50 --> Config Class Initialized
INFO - 2018-06-22 05:18:50 --> Hooks Class Initialized
DEBUG - 2018-06-22 05:18:50 --> UTF-8 Support Enabled
INFO - 2018-06-22 05:18:50 --> Utf8 Class Initialized
INFO - 2018-06-22 05:18:50 --> URI Class Initialized
INFO - 2018-06-22 05:18:50 --> Router Class Initialized
INFO - 2018-06-22 05:18:50 --> Output Class Initialized
INFO - 2018-06-22 05:18:50 --> Security Class Initialized
DEBUG - 2018-06-22 05:18:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 05:18:50 --> Input Class Initialized
INFO - 2018-06-22 05:18:50 --> Language Class Initialized
INFO - 2018-06-22 05:18:50 --> Language Class Initialized
INFO - 2018-06-22 05:18:50 --> Config Class Initialized
INFO - 2018-06-22 05:18:50 --> Loader Class Initialized
DEBUG - 2018-06-22 05:18:50 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-22 05:18:50 --> Helper loaded: url_helper
INFO - 2018-06-22 05:18:50 --> Helper loaded: form_helper
INFO - 2018-06-22 05:18:50 --> Helper loaded: date_helper
INFO - 2018-06-22 05:18:50 --> Helper loaded: util_helper
INFO - 2018-06-22 05:18:50 --> Helper loaded: text_helper
INFO - 2018-06-22 05:18:50 --> Helper loaded: string_helper
INFO - 2018-06-22 05:18:50 --> Database Driver Class Initialized
DEBUG - 2018-06-22 05:18:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 05:18:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 05:18:50 --> Email Class Initialized
INFO - 2018-06-22 05:18:50 --> Controller Class Initialized
DEBUG - 2018-06-22 05:18:50 --> Admin MX_Controller Initialized
INFO - 2018-06-22 05:18:50 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-22 05:18:50 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-22 05:18:50 --> Login MX_Controller Initialized
DEBUG - 2018-06-22 05:18:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-22 05:18:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-22 05:18:50 --> Final output sent to browser
DEBUG - 2018-06-22 05:18:50 --> Total execution time: 0.5042
INFO - 2018-06-22 05:20:54 --> Config Class Initialized
INFO - 2018-06-22 05:20:54 --> Hooks Class Initialized
DEBUG - 2018-06-22 05:20:54 --> UTF-8 Support Enabled
INFO - 2018-06-22 05:20:54 --> Utf8 Class Initialized
INFO - 2018-06-22 05:20:55 --> URI Class Initialized
INFO - 2018-06-22 05:20:55 --> Router Class Initialized
INFO - 2018-06-22 05:20:55 --> Output Class Initialized
INFO - 2018-06-22 05:20:55 --> Security Class Initialized
DEBUG - 2018-06-22 05:20:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 05:20:55 --> Input Class Initialized
INFO - 2018-06-22 05:20:55 --> Language Class Initialized
INFO - 2018-06-22 05:20:55 --> Language Class Initialized
INFO - 2018-06-22 05:20:55 --> Config Class Initialized
INFO - 2018-06-22 05:20:55 --> Loader Class Initialized
DEBUG - 2018-06-22 05:20:55 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-22 05:20:55 --> Helper loaded: url_helper
INFO - 2018-06-22 05:20:55 --> Helper loaded: form_helper
INFO - 2018-06-22 05:20:55 --> Helper loaded: date_helper
INFO - 2018-06-22 05:20:55 --> Helper loaded: util_helper
INFO - 2018-06-22 05:20:55 --> Helper loaded: text_helper
INFO - 2018-06-22 05:20:55 --> Helper loaded: string_helper
INFO - 2018-06-22 05:20:55 --> Database Driver Class Initialized
DEBUG - 2018-06-22 05:20:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 05:20:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 05:20:55 --> Email Class Initialized
INFO - 2018-06-22 05:20:55 --> Controller Class Initialized
DEBUG - 2018-06-22 05:20:55 --> Users MX_Controller Initialized
DEBUG - 2018-06-22 05:20:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-22 05:20:55 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-22 05:20:55 --> Login MX_Controller Initialized
INFO - 2018-06-22 05:20:55 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-22 05:20:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-22 05:20:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-22 05:20:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-22 05:20:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-22 05:20:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-22 05:20:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-22 05:20:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-06-22 05:20:55 --> Final output sent to browser
DEBUG - 2018-06-22 05:20:55 --> Total execution time: 0.4951
INFO - 2018-06-22 05:20:56 --> Config Class Initialized
INFO - 2018-06-22 05:20:56 --> Hooks Class Initialized
DEBUG - 2018-06-22 05:20:56 --> UTF-8 Support Enabled
INFO - 2018-06-22 05:20:56 --> Utf8 Class Initialized
INFO - 2018-06-22 05:20:56 --> URI Class Initialized
INFO - 2018-06-22 05:20:56 --> Router Class Initialized
INFO - 2018-06-22 05:20:56 --> Output Class Initialized
INFO - 2018-06-22 05:20:56 --> Security Class Initialized
DEBUG - 2018-06-22 05:20:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 05:20:56 --> Input Class Initialized
INFO - 2018-06-22 05:20:56 --> Language Class Initialized
INFO - 2018-06-22 05:20:56 --> Language Class Initialized
INFO - 2018-06-22 05:20:56 --> Config Class Initialized
INFO - 2018-06-22 05:20:56 --> Loader Class Initialized
DEBUG - 2018-06-22 05:20:56 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-22 05:20:56 --> Helper loaded: url_helper
INFO - 2018-06-22 05:20:56 --> Helper loaded: form_helper
INFO - 2018-06-22 05:20:56 --> Helper loaded: date_helper
INFO - 2018-06-22 05:20:56 --> Helper loaded: util_helper
INFO - 2018-06-22 05:20:56 --> Helper loaded: text_helper
INFO - 2018-06-22 05:20:56 --> Helper loaded: string_helper
INFO - 2018-06-22 05:20:56 --> Database Driver Class Initialized
DEBUG - 2018-06-22 05:20:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 05:20:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 05:20:56 --> Email Class Initialized
INFO - 2018-06-22 05:20:56 --> Controller Class Initialized
DEBUG - 2018-06-22 05:20:56 --> Users MX_Controller Initialized
DEBUG - 2018-06-22 05:20:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-22 05:20:56 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-22 05:20:56 --> Login MX_Controller Initialized
INFO - 2018-06-22 05:20:56 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-22 05:20:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-22 05:20:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-06-22 05:20:56 --> Final output sent to browser
DEBUG - 2018-06-22 05:20:56 --> Total execution time: 0.5678
INFO - 2018-06-22 05:21:07 --> Config Class Initialized
INFO - 2018-06-22 05:21:07 --> Hooks Class Initialized
DEBUG - 2018-06-22 05:21:07 --> UTF-8 Support Enabled
INFO - 2018-06-22 05:21:07 --> Utf8 Class Initialized
INFO - 2018-06-22 05:21:07 --> URI Class Initialized
INFO - 2018-06-22 05:21:07 --> Router Class Initialized
INFO - 2018-06-22 05:21:07 --> Output Class Initialized
INFO - 2018-06-22 05:21:07 --> Security Class Initialized
DEBUG - 2018-06-22 05:21:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 05:21:07 --> Input Class Initialized
INFO - 2018-06-22 05:21:07 --> Language Class Initialized
INFO - 2018-06-22 05:21:07 --> Language Class Initialized
INFO - 2018-06-22 05:21:07 --> Config Class Initialized
INFO - 2018-06-22 05:21:07 --> Loader Class Initialized
DEBUG - 2018-06-22 05:21:07 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-22 05:21:07 --> Helper loaded: url_helper
INFO - 2018-06-22 05:21:07 --> Helper loaded: form_helper
INFO - 2018-06-22 05:21:07 --> Helper loaded: date_helper
INFO - 2018-06-22 05:21:07 --> Helper loaded: util_helper
INFO - 2018-06-22 05:21:07 --> Helper loaded: text_helper
INFO - 2018-06-22 05:21:07 --> Helper loaded: string_helper
INFO - 2018-06-22 05:21:07 --> Database Driver Class Initialized
DEBUG - 2018-06-22 05:21:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 05:21:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 05:21:07 --> Email Class Initialized
INFO - 2018-06-22 05:21:07 --> Controller Class Initialized
DEBUG - 2018-06-22 05:21:07 --> Users MX_Controller Initialized
DEBUG - 2018-06-22 05:21:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-22 05:21:07 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-22 05:21:07 --> Login MX_Controller Initialized
INFO - 2018-06-22 05:21:07 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-22 05:21:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-22 05:21:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-22 05:21:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-22 05:21:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-22 05:21:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-22 05:21:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-22 05:21:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-06-22 05:21:07 --> Final output sent to browser
DEBUG - 2018-06-22 05:21:08 --> Total execution time: 0.4606
INFO - 2018-06-22 05:21:08 --> Config Class Initialized
INFO - 2018-06-22 05:21:08 --> Hooks Class Initialized
DEBUG - 2018-06-22 05:21:08 --> UTF-8 Support Enabled
INFO - 2018-06-22 05:21:08 --> Utf8 Class Initialized
INFO - 2018-06-22 05:21:08 --> URI Class Initialized
INFO - 2018-06-22 05:21:08 --> Router Class Initialized
INFO - 2018-06-22 05:21:08 --> Output Class Initialized
INFO - 2018-06-22 05:21:08 --> Security Class Initialized
DEBUG - 2018-06-22 05:21:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 05:21:08 --> Input Class Initialized
INFO - 2018-06-22 05:21:08 --> Language Class Initialized
INFO - 2018-06-22 05:21:08 --> Language Class Initialized
INFO - 2018-06-22 05:21:08 --> Config Class Initialized
INFO - 2018-06-22 05:21:08 --> Loader Class Initialized
DEBUG - 2018-06-22 05:21:09 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-22 05:21:09 --> Helper loaded: url_helper
INFO - 2018-06-22 05:21:09 --> Helper loaded: form_helper
INFO - 2018-06-22 05:21:09 --> Helper loaded: date_helper
INFO - 2018-06-22 05:21:09 --> Helper loaded: util_helper
INFO - 2018-06-22 05:21:09 --> Helper loaded: text_helper
INFO - 2018-06-22 05:21:09 --> Helper loaded: string_helper
INFO - 2018-06-22 05:21:09 --> Database Driver Class Initialized
DEBUG - 2018-06-22 05:21:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 05:21:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 05:21:09 --> Email Class Initialized
INFO - 2018-06-22 05:21:09 --> Controller Class Initialized
DEBUG - 2018-06-22 05:21:09 --> Users MX_Controller Initialized
DEBUG - 2018-06-22 05:21:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-22 05:21:09 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-22 05:21:09 --> Login MX_Controller Initialized
INFO - 2018-06-22 05:21:09 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-22 05:21:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-22 05:21:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-06-22 05:21:09 --> Final output sent to browser
DEBUG - 2018-06-22 05:21:09 --> Total execution time: 0.6541
INFO - 2018-06-22 05:21:45 --> Config Class Initialized
INFO - 2018-06-22 05:21:45 --> Hooks Class Initialized
DEBUG - 2018-06-22 05:21:45 --> UTF-8 Support Enabled
INFO - 2018-06-22 05:21:45 --> Utf8 Class Initialized
INFO - 2018-06-22 05:21:45 --> URI Class Initialized
INFO - 2018-06-22 05:21:45 --> Router Class Initialized
INFO - 2018-06-22 05:21:45 --> Output Class Initialized
INFO - 2018-06-22 05:21:45 --> Security Class Initialized
DEBUG - 2018-06-22 05:21:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 05:21:45 --> Input Class Initialized
INFO - 2018-06-22 05:21:45 --> Language Class Initialized
INFO - 2018-06-22 05:21:45 --> Language Class Initialized
INFO - 2018-06-22 05:21:45 --> Config Class Initialized
INFO - 2018-06-22 05:21:45 --> Loader Class Initialized
DEBUG - 2018-06-22 05:21:45 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-22 05:21:45 --> Helper loaded: url_helper
INFO - 2018-06-22 05:21:45 --> Helper loaded: form_helper
INFO - 2018-06-22 05:21:45 --> Helper loaded: date_helper
INFO - 2018-06-22 05:21:45 --> Helper loaded: util_helper
INFO - 2018-06-22 05:21:45 --> Helper loaded: text_helper
INFO - 2018-06-22 05:21:45 --> Helper loaded: string_helper
INFO - 2018-06-22 05:21:45 --> Database Driver Class Initialized
DEBUG - 2018-06-22 05:21:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 05:21:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 05:21:45 --> Email Class Initialized
INFO - 2018-06-22 05:21:45 --> Controller Class Initialized
DEBUG - 2018-06-22 05:21:45 --> Users MX_Controller Initialized
DEBUG - 2018-06-22 05:21:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-22 05:21:45 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-22 05:21:45 --> Login MX_Controller Initialized
INFO - 2018-06-22 05:21:45 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-22 05:21:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-22 05:21:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-22 05:21:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-22 05:21:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-22 05:21:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-22 05:21:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-22 05:21:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-06-22 05:21:45 --> Final output sent to browser
DEBUG - 2018-06-22 05:21:45 --> Total execution time: 0.4746
INFO - 2018-06-22 05:21:46 --> Config Class Initialized
INFO - 2018-06-22 05:21:46 --> Hooks Class Initialized
DEBUG - 2018-06-22 05:21:46 --> UTF-8 Support Enabled
INFO - 2018-06-22 05:21:46 --> Utf8 Class Initialized
INFO - 2018-06-22 05:21:46 --> URI Class Initialized
INFO - 2018-06-22 05:21:46 --> Router Class Initialized
INFO - 2018-06-22 05:21:46 --> Output Class Initialized
INFO - 2018-06-22 05:21:46 --> Security Class Initialized
DEBUG - 2018-06-22 05:21:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 05:21:46 --> Input Class Initialized
INFO - 2018-06-22 05:21:46 --> Language Class Initialized
INFO - 2018-06-22 05:21:46 --> Language Class Initialized
INFO - 2018-06-22 05:21:46 --> Config Class Initialized
INFO - 2018-06-22 05:21:46 --> Loader Class Initialized
DEBUG - 2018-06-22 05:21:46 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-22 05:21:46 --> Helper loaded: url_helper
INFO - 2018-06-22 05:21:46 --> Helper loaded: form_helper
INFO - 2018-06-22 05:21:46 --> Helper loaded: date_helper
INFO - 2018-06-22 05:21:46 --> Helper loaded: util_helper
INFO - 2018-06-22 05:21:46 --> Helper loaded: text_helper
INFO - 2018-06-22 05:21:46 --> Helper loaded: string_helper
INFO - 2018-06-22 05:21:46 --> Database Driver Class Initialized
DEBUG - 2018-06-22 05:21:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 05:21:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 05:21:46 --> Email Class Initialized
INFO - 2018-06-22 05:21:46 --> Controller Class Initialized
DEBUG - 2018-06-22 05:21:46 --> Users MX_Controller Initialized
DEBUG - 2018-06-22 05:21:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-22 05:21:47 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-22 05:21:47 --> Login MX_Controller Initialized
INFO - 2018-06-22 05:21:47 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-22 05:21:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-22 05:21:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-06-22 05:21:47 --> Final output sent to browser
DEBUG - 2018-06-22 05:21:47 --> Total execution time: 0.5922
INFO - 2018-06-22 05:24:14 --> Config Class Initialized
INFO - 2018-06-22 05:24:14 --> Hooks Class Initialized
DEBUG - 2018-06-22 05:24:14 --> UTF-8 Support Enabled
INFO - 2018-06-22 05:24:14 --> Utf8 Class Initialized
INFO - 2018-06-22 05:24:14 --> URI Class Initialized
INFO - 2018-06-22 05:24:14 --> Router Class Initialized
INFO - 2018-06-22 05:24:14 --> Output Class Initialized
INFO - 2018-06-22 05:24:14 --> Security Class Initialized
DEBUG - 2018-06-22 05:24:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 05:24:14 --> Input Class Initialized
INFO - 2018-06-22 05:24:14 --> Language Class Initialized
INFO - 2018-06-22 05:24:14 --> Language Class Initialized
INFO - 2018-06-22 05:24:14 --> Config Class Initialized
INFO - 2018-06-22 05:24:14 --> Loader Class Initialized
DEBUG - 2018-06-22 05:24:14 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-22 05:24:14 --> Helper loaded: url_helper
INFO - 2018-06-22 05:24:14 --> Helper loaded: form_helper
INFO - 2018-06-22 05:24:14 --> Helper loaded: date_helper
INFO - 2018-06-22 05:24:14 --> Helper loaded: util_helper
INFO - 2018-06-22 05:24:14 --> Helper loaded: text_helper
INFO - 2018-06-22 05:24:14 --> Helper loaded: string_helper
INFO - 2018-06-22 05:24:14 --> Database Driver Class Initialized
DEBUG - 2018-06-22 05:24:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 05:24:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 05:24:14 --> Email Class Initialized
INFO - 2018-06-22 05:24:14 --> Controller Class Initialized
DEBUG - 2018-06-22 05:24:14 --> Users MX_Controller Initialized
DEBUG - 2018-06-22 05:24:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-22 05:24:14 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-22 05:24:14 --> Login MX_Controller Initialized
INFO - 2018-06-22 05:24:14 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-22 05:24:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-22 05:24:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-06-22 05:29:00 --> Config Class Initialized
INFO - 2018-06-22 05:29:00 --> Hooks Class Initialized
DEBUG - 2018-06-22 05:29:00 --> UTF-8 Support Enabled
INFO - 2018-06-22 05:29:00 --> Utf8 Class Initialized
INFO - 2018-06-22 05:29:01 --> URI Class Initialized
INFO - 2018-06-22 05:29:01 --> Router Class Initialized
INFO - 2018-06-22 05:29:01 --> Output Class Initialized
INFO - 2018-06-22 05:29:01 --> Security Class Initialized
DEBUG - 2018-06-22 05:29:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 05:29:01 --> Input Class Initialized
INFO - 2018-06-22 05:29:01 --> Language Class Initialized
INFO - 2018-06-22 05:29:01 --> Language Class Initialized
INFO - 2018-06-22 05:29:01 --> Config Class Initialized
INFO - 2018-06-22 05:29:01 --> Loader Class Initialized
DEBUG - 2018-06-22 05:29:01 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-22 05:29:01 --> Helper loaded: url_helper
INFO - 2018-06-22 05:29:01 --> Helper loaded: form_helper
INFO - 2018-06-22 05:29:01 --> Helper loaded: date_helper
INFO - 2018-06-22 05:29:01 --> Helper loaded: util_helper
INFO - 2018-06-22 05:29:01 --> Helper loaded: text_helper
INFO - 2018-06-22 05:29:01 --> Helper loaded: string_helper
INFO - 2018-06-22 05:29:01 --> Database Driver Class Initialized
DEBUG - 2018-06-22 05:29:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 05:29:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 05:29:01 --> Email Class Initialized
INFO - 2018-06-22 05:29:01 --> Controller Class Initialized
DEBUG - 2018-06-22 05:29:01 --> Users MX_Controller Initialized
DEBUG - 2018-06-22 05:29:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-22 05:29:01 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-22 05:29:01 --> Login MX_Controller Initialized
INFO - 2018-06-22 05:29:01 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-22 05:29:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-22 05:29:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-06-22 05:31:00 --> Config Class Initialized
INFO - 2018-06-22 05:31:00 --> Hooks Class Initialized
DEBUG - 2018-06-22 05:31:00 --> UTF-8 Support Enabled
INFO - 2018-06-22 05:31:00 --> Utf8 Class Initialized
INFO - 2018-06-22 05:31:00 --> URI Class Initialized
INFO - 2018-06-22 05:31:00 --> Router Class Initialized
INFO - 2018-06-22 05:31:00 --> Output Class Initialized
INFO - 2018-06-22 05:31:00 --> Security Class Initialized
DEBUG - 2018-06-22 05:31:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 05:31:00 --> Input Class Initialized
INFO - 2018-06-22 05:31:00 --> Language Class Initialized
INFO - 2018-06-22 05:31:00 --> Language Class Initialized
INFO - 2018-06-22 05:31:00 --> Config Class Initialized
INFO - 2018-06-22 05:31:00 --> Loader Class Initialized
DEBUG - 2018-06-22 05:31:00 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-22 05:31:00 --> Helper loaded: url_helper
INFO - 2018-06-22 05:31:00 --> Helper loaded: form_helper
INFO - 2018-06-22 05:31:00 --> Helper loaded: date_helper
INFO - 2018-06-22 05:31:00 --> Helper loaded: util_helper
INFO - 2018-06-22 05:31:00 --> Helper loaded: text_helper
INFO - 2018-06-22 05:31:00 --> Helper loaded: string_helper
INFO - 2018-06-22 05:31:00 --> Database Driver Class Initialized
DEBUG - 2018-06-22 05:31:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 05:31:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 05:31:00 --> Email Class Initialized
INFO - 2018-06-22 05:31:00 --> Controller Class Initialized
DEBUG - 2018-06-22 05:31:00 --> Users MX_Controller Initialized
DEBUG - 2018-06-22 05:31:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-22 05:31:00 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-22 05:31:01 --> Login MX_Controller Initialized
INFO - 2018-06-22 05:31:01 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-22 05:31:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-22 05:31:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-22 05:31:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-22 05:31:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-22 05:31:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-22 05:31:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-22 05:31:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-06-22 05:31:01 --> Final output sent to browser
DEBUG - 2018-06-22 05:31:01 --> Total execution time: 0.5171
INFO - 2018-06-22 05:31:02 --> Config Class Initialized
INFO - 2018-06-22 05:31:02 --> Hooks Class Initialized
DEBUG - 2018-06-22 05:31:02 --> UTF-8 Support Enabled
INFO - 2018-06-22 05:31:02 --> Utf8 Class Initialized
INFO - 2018-06-22 05:31:02 --> URI Class Initialized
INFO - 2018-06-22 05:31:02 --> Router Class Initialized
INFO - 2018-06-22 05:31:02 --> Output Class Initialized
INFO - 2018-06-22 05:31:02 --> Security Class Initialized
DEBUG - 2018-06-22 05:31:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 05:31:02 --> Input Class Initialized
INFO - 2018-06-22 05:31:02 --> Language Class Initialized
INFO - 2018-06-22 05:31:02 --> Language Class Initialized
INFO - 2018-06-22 05:31:02 --> Config Class Initialized
INFO - 2018-06-22 05:31:02 --> Loader Class Initialized
DEBUG - 2018-06-22 05:31:02 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-22 05:31:02 --> Helper loaded: url_helper
INFO - 2018-06-22 05:31:02 --> Helper loaded: form_helper
INFO - 2018-06-22 05:31:02 --> Helper loaded: date_helper
INFO - 2018-06-22 05:31:02 --> Helper loaded: util_helper
INFO - 2018-06-22 05:31:02 --> Helper loaded: text_helper
INFO - 2018-06-22 05:31:02 --> Helper loaded: string_helper
INFO - 2018-06-22 05:31:02 --> Database Driver Class Initialized
DEBUG - 2018-06-22 05:31:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 05:31:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 05:31:02 --> Email Class Initialized
INFO - 2018-06-22 05:31:02 --> Controller Class Initialized
DEBUG - 2018-06-22 05:31:02 --> Users MX_Controller Initialized
DEBUG - 2018-06-22 05:31:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-22 05:31:02 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-22 05:31:02 --> Login MX_Controller Initialized
INFO - 2018-06-22 05:31:02 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-22 05:31:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-22 05:31:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-06-22 05:42:47 --> Config Class Initialized
INFO - 2018-06-22 05:42:47 --> Hooks Class Initialized
DEBUG - 2018-06-22 05:42:47 --> UTF-8 Support Enabled
INFO - 2018-06-22 05:42:47 --> Utf8 Class Initialized
INFO - 2018-06-22 05:42:47 --> URI Class Initialized
INFO - 2018-06-22 05:42:47 --> Router Class Initialized
INFO - 2018-06-22 05:42:47 --> Output Class Initialized
INFO - 2018-06-22 05:42:47 --> Security Class Initialized
DEBUG - 2018-06-22 05:42:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 05:42:47 --> Input Class Initialized
INFO - 2018-06-22 05:42:47 --> Language Class Initialized
INFO - 2018-06-22 05:42:47 --> Language Class Initialized
INFO - 2018-06-22 05:42:47 --> Config Class Initialized
INFO - 2018-06-22 05:42:47 --> Loader Class Initialized
DEBUG - 2018-06-22 05:42:47 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-22 05:42:47 --> Helper loaded: url_helper
INFO - 2018-06-22 05:42:47 --> Helper loaded: form_helper
INFO - 2018-06-22 05:42:47 --> Helper loaded: date_helper
INFO - 2018-06-22 05:42:47 --> Helper loaded: util_helper
INFO - 2018-06-22 05:42:47 --> Helper loaded: text_helper
INFO - 2018-06-22 05:42:47 --> Helper loaded: string_helper
INFO - 2018-06-22 05:42:47 --> Database Driver Class Initialized
DEBUG - 2018-06-22 05:42:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 05:42:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 05:42:47 --> Email Class Initialized
INFO - 2018-06-22 05:42:47 --> Controller Class Initialized
DEBUG - 2018-06-22 05:42:47 --> Users MX_Controller Initialized
DEBUG - 2018-06-22 05:42:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-22 05:42:47 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-22 05:42:47 --> Login MX_Controller Initialized
INFO - 2018-06-22 05:42:48 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-22 05:42:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-22 05:42:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-22 05:42:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-22 05:42:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-22 05:42:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-22 05:42:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-22 05:42:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-06-22 05:42:48 --> Final output sent to browser
DEBUG - 2018-06-22 05:42:48 --> Total execution time: 0.5697
INFO - 2018-06-22 05:42:48 --> Config Class Initialized
INFO - 2018-06-22 05:42:48 --> Hooks Class Initialized
DEBUG - 2018-06-22 05:42:48 --> UTF-8 Support Enabled
INFO - 2018-06-22 05:42:48 --> Utf8 Class Initialized
INFO - 2018-06-22 05:42:48 --> URI Class Initialized
INFO - 2018-06-22 05:42:48 --> Router Class Initialized
INFO - 2018-06-22 05:42:48 --> Output Class Initialized
INFO - 2018-06-22 05:42:48 --> Security Class Initialized
DEBUG - 2018-06-22 05:42:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 05:42:49 --> Input Class Initialized
INFO - 2018-06-22 05:42:49 --> Language Class Initialized
INFO - 2018-06-22 05:42:49 --> Language Class Initialized
INFO - 2018-06-22 05:42:49 --> Config Class Initialized
INFO - 2018-06-22 05:42:49 --> Loader Class Initialized
DEBUG - 2018-06-22 05:42:49 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-22 05:42:49 --> Helper loaded: url_helper
INFO - 2018-06-22 05:42:49 --> Helper loaded: form_helper
INFO - 2018-06-22 05:42:49 --> Helper loaded: date_helper
INFO - 2018-06-22 05:42:49 --> Helper loaded: util_helper
INFO - 2018-06-22 05:42:49 --> Helper loaded: text_helper
INFO - 2018-06-22 05:42:49 --> Helper loaded: string_helper
INFO - 2018-06-22 05:42:49 --> Database Driver Class Initialized
DEBUG - 2018-06-22 05:42:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 05:42:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 05:42:49 --> Email Class Initialized
INFO - 2018-06-22 05:42:49 --> Controller Class Initialized
DEBUG - 2018-06-22 05:42:49 --> Users MX_Controller Initialized
DEBUG - 2018-06-22 05:42:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-22 05:42:49 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-22 05:42:49 --> Login MX_Controller Initialized
INFO - 2018-06-22 05:42:49 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-22 05:42:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-22 05:42:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-06-22 05:42:49 --> Final output sent to browser
DEBUG - 2018-06-22 05:42:49 --> Total execution time: 0.5778
INFO - 2018-06-22 06:03:02 --> Config Class Initialized
INFO - 2018-06-22 06:03:03 --> Hooks Class Initialized
DEBUG - 2018-06-22 06:03:03 --> UTF-8 Support Enabled
INFO - 2018-06-22 06:03:03 --> Utf8 Class Initialized
INFO - 2018-06-22 06:03:03 --> URI Class Initialized
INFO - 2018-06-22 06:03:03 --> Router Class Initialized
INFO - 2018-06-22 06:03:03 --> Output Class Initialized
INFO - 2018-06-22 06:03:03 --> Security Class Initialized
DEBUG - 2018-06-22 06:03:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 06:03:03 --> Input Class Initialized
INFO - 2018-06-22 06:03:03 --> Language Class Initialized
INFO - 2018-06-22 06:03:03 --> Language Class Initialized
INFO - 2018-06-22 06:03:03 --> Config Class Initialized
INFO - 2018-06-22 06:03:03 --> Loader Class Initialized
DEBUG - 2018-06-22 06:03:03 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-22 06:03:03 --> Helper loaded: url_helper
INFO - 2018-06-22 06:03:03 --> Helper loaded: form_helper
INFO - 2018-06-22 06:03:03 --> Helper loaded: date_helper
INFO - 2018-06-22 06:03:03 --> Helper loaded: util_helper
INFO - 2018-06-22 06:03:03 --> Helper loaded: text_helper
INFO - 2018-06-22 06:03:03 --> Helper loaded: string_helper
INFO - 2018-06-22 06:03:03 --> Database Driver Class Initialized
DEBUG - 2018-06-22 06:03:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 06:03:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 06:03:03 --> Email Class Initialized
INFO - 2018-06-22 06:03:03 --> Controller Class Initialized
DEBUG - 2018-06-22 06:03:03 --> Users MX_Controller Initialized
DEBUG - 2018-06-22 06:03:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-22 06:03:03 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-22 06:03:03 --> Login MX_Controller Initialized
INFO - 2018-06-22 06:03:03 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-22 06:03:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-22 06:03:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-22 06:03:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-22 06:03:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-22 06:03:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-22 06:03:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-22 06:03:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-06-22 06:03:03 --> Final output sent to browser
DEBUG - 2018-06-22 06:03:03 --> Total execution time: 0.5422
INFO - 2018-06-22 06:03:04 --> Config Class Initialized
INFO - 2018-06-22 06:03:04 --> Hooks Class Initialized
DEBUG - 2018-06-22 06:03:04 --> UTF-8 Support Enabled
INFO - 2018-06-22 06:03:04 --> Utf8 Class Initialized
INFO - 2018-06-22 06:03:04 --> URI Class Initialized
INFO - 2018-06-22 06:03:04 --> Router Class Initialized
INFO - 2018-06-22 06:03:04 --> Output Class Initialized
INFO - 2018-06-22 06:03:04 --> Security Class Initialized
DEBUG - 2018-06-22 06:03:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 06:03:04 --> Input Class Initialized
INFO - 2018-06-22 06:03:04 --> Language Class Initialized
INFO - 2018-06-22 06:03:04 --> Language Class Initialized
INFO - 2018-06-22 06:03:04 --> Config Class Initialized
INFO - 2018-06-22 06:03:04 --> Loader Class Initialized
DEBUG - 2018-06-22 06:03:04 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-22 06:03:04 --> Helper loaded: url_helper
INFO - 2018-06-22 06:03:04 --> Helper loaded: form_helper
INFO - 2018-06-22 06:03:04 --> Helper loaded: date_helper
INFO - 2018-06-22 06:03:04 --> Helper loaded: util_helper
INFO - 2018-06-22 06:03:04 --> Helper loaded: text_helper
INFO - 2018-06-22 06:03:04 --> Helper loaded: string_helper
INFO - 2018-06-22 06:03:04 --> Database Driver Class Initialized
DEBUG - 2018-06-22 06:03:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 06:03:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 06:03:04 --> Email Class Initialized
INFO - 2018-06-22 06:03:04 --> Controller Class Initialized
DEBUG - 2018-06-22 06:03:04 --> Users MX_Controller Initialized
DEBUG - 2018-06-22 06:03:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-22 06:03:04 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-22 06:03:04 --> Login MX_Controller Initialized
INFO - 2018-06-22 06:03:04 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-22 06:03:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-22 06:03:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-06-22 06:03:04 --> Final output sent to browser
DEBUG - 2018-06-22 06:03:04 --> Total execution time: 0.7467
INFO - 2018-06-22 06:03:25 --> Config Class Initialized
INFO - 2018-06-22 06:03:25 --> Hooks Class Initialized
DEBUG - 2018-06-22 06:03:25 --> UTF-8 Support Enabled
INFO - 2018-06-22 06:03:26 --> Utf8 Class Initialized
INFO - 2018-06-22 06:03:26 --> URI Class Initialized
INFO - 2018-06-22 06:03:26 --> Router Class Initialized
INFO - 2018-06-22 06:03:26 --> Output Class Initialized
INFO - 2018-06-22 06:03:26 --> Security Class Initialized
DEBUG - 2018-06-22 06:03:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 06:03:26 --> Input Class Initialized
INFO - 2018-06-22 06:03:26 --> Language Class Initialized
INFO - 2018-06-22 06:03:26 --> Language Class Initialized
INFO - 2018-06-22 06:03:26 --> Config Class Initialized
INFO - 2018-06-22 06:03:26 --> Loader Class Initialized
DEBUG - 2018-06-22 06:03:26 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-22 06:03:26 --> Helper loaded: url_helper
INFO - 2018-06-22 06:03:26 --> Helper loaded: form_helper
INFO - 2018-06-22 06:03:26 --> Helper loaded: date_helper
INFO - 2018-06-22 06:03:26 --> Helper loaded: util_helper
INFO - 2018-06-22 06:03:26 --> Helper loaded: text_helper
INFO - 2018-06-22 06:03:26 --> Helper loaded: string_helper
INFO - 2018-06-22 06:03:26 --> Database Driver Class Initialized
DEBUG - 2018-06-22 06:03:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 06:03:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 06:03:26 --> Email Class Initialized
INFO - 2018-06-22 06:03:26 --> Controller Class Initialized
DEBUG - 2018-06-22 06:03:26 --> Users MX_Controller Initialized
DEBUG - 2018-06-22 06:03:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-22 06:03:26 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-22 06:03:26 --> Login MX_Controller Initialized
INFO - 2018-06-22 06:03:26 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-22 06:03:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-22 06:03:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-06-22 06:03:32 --> Config Class Initialized
INFO - 2018-06-22 06:03:32 --> Hooks Class Initialized
DEBUG - 2018-06-22 06:03:32 --> UTF-8 Support Enabled
INFO - 2018-06-22 06:03:32 --> Utf8 Class Initialized
INFO - 2018-06-22 06:03:32 --> URI Class Initialized
INFO - 2018-06-22 06:03:32 --> Router Class Initialized
INFO - 2018-06-22 06:03:32 --> Output Class Initialized
INFO - 2018-06-22 06:03:32 --> Security Class Initialized
DEBUG - 2018-06-22 06:03:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 06:03:32 --> Input Class Initialized
INFO - 2018-06-22 06:03:32 --> Language Class Initialized
INFO - 2018-06-22 06:03:32 --> Language Class Initialized
INFO - 2018-06-22 06:03:32 --> Config Class Initialized
INFO - 2018-06-22 06:03:33 --> Loader Class Initialized
DEBUG - 2018-06-22 06:03:33 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-22 06:03:33 --> Helper loaded: url_helper
INFO - 2018-06-22 06:03:33 --> Helper loaded: form_helper
INFO - 2018-06-22 06:03:33 --> Helper loaded: date_helper
INFO - 2018-06-22 06:03:33 --> Helper loaded: util_helper
INFO - 2018-06-22 06:03:33 --> Helper loaded: text_helper
INFO - 2018-06-22 06:03:33 --> Helper loaded: string_helper
INFO - 2018-06-22 06:03:33 --> Database Driver Class Initialized
DEBUG - 2018-06-22 06:03:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 06:03:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 06:03:33 --> Email Class Initialized
INFO - 2018-06-22 06:03:33 --> Controller Class Initialized
DEBUG - 2018-06-22 06:03:33 --> Users MX_Controller Initialized
DEBUG - 2018-06-22 06:03:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-22 06:03:33 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-22 06:03:33 --> Login MX_Controller Initialized
INFO - 2018-06-22 06:03:33 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-22 06:03:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-22 06:03:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-06-22 06:04:05 --> Config Class Initialized
INFO - 2018-06-22 06:04:05 --> Hooks Class Initialized
DEBUG - 2018-06-22 06:04:05 --> UTF-8 Support Enabled
INFO - 2018-06-22 06:04:05 --> Utf8 Class Initialized
INFO - 2018-06-22 06:04:05 --> URI Class Initialized
INFO - 2018-06-22 06:04:05 --> Router Class Initialized
INFO - 2018-06-22 06:04:05 --> Output Class Initialized
INFO - 2018-06-22 06:04:05 --> Security Class Initialized
DEBUG - 2018-06-22 06:04:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 06:04:05 --> Input Class Initialized
INFO - 2018-06-22 06:04:05 --> Language Class Initialized
INFO - 2018-06-22 06:04:05 --> Language Class Initialized
INFO - 2018-06-22 06:04:05 --> Config Class Initialized
INFO - 2018-06-22 06:04:05 --> Loader Class Initialized
DEBUG - 2018-06-22 06:04:05 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-22 06:04:05 --> Helper loaded: url_helper
INFO - 2018-06-22 06:04:05 --> Helper loaded: form_helper
INFO - 2018-06-22 06:04:05 --> Helper loaded: date_helper
INFO - 2018-06-22 06:04:05 --> Helper loaded: util_helper
INFO - 2018-06-22 06:04:05 --> Helper loaded: text_helper
INFO - 2018-06-22 06:04:05 --> Helper loaded: string_helper
INFO - 2018-06-22 06:04:05 --> Database Driver Class Initialized
DEBUG - 2018-06-22 06:04:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 06:04:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 06:04:05 --> Email Class Initialized
INFO - 2018-06-22 06:04:05 --> Controller Class Initialized
DEBUG - 2018-06-22 06:04:05 --> Users MX_Controller Initialized
DEBUG - 2018-06-22 06:04:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-22 06:04:05 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-22 06:04:05 --> Login MX_Controller Initialized
INFO - 2018-06-22 06:04:05 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-22 06:04:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-22 06:04:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-06-22 06:04:35 --> Config Class Initialized
INFO - 2018-06-22 06:04:35 --> Hooks Class Initialized
DEBUG - 2018-06-22 06:04:35 --> UTF-8 Support Enabled
INFO - 2018-06-22 06:04:35 --> Utf8 Class Initialized
INFO - 2018-06-22 06:04:35 --> URI Class Initialized
INFO - 2018-06-22 06:04:35 --> Router Class Initialized
INFO - 2018-06-22 06:04:35 --> Output Class Initialized
INFO - 2018-06-22 06:04:35 --> Security Class Initialized
DEBUG - 2018-06-22 06:04:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 06:04:35 --> Input Class Initialized
INFO - 2018-06-22 06:04:35 --> Language Class Initialized
INFO - 2018-06-22 06:04:35 --> Language Class Initialized
INFO - 2018-06-22 06:04:35 --> Config Class Initialized
INFO - 2018-06-22 06:04:35 --> Loader Class Initialized
DEBUG - 2018-06-22 06:04:35 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-22 06:04:35 --> Helper loaded: url_helper
INFO - 2018-06-22 06:04:35 --> Helper loaded: form_helper
INFO - 2018-06-22 06:04:35 --> Helper loaded: date_helper
INFO - 2018-06-22 06:04:35 --> Helper loaded: util_helper
INFO - 2018-06-22 06:04:35 --> Helper loaded: text_helper
INFO - 2018-06-22 06:04:35 --> Helper loaded: string_helper
INFO - 2018-06-22 06:04:35 --> Database Driver Class Initialized
DEBUG - 2018-06-22 06:04:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 06:04:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 06:04:35 --> Email Class Initialized
INFO - 2018-06-22 06:04:35 --> Controller Class Initialized
DEBUG - 2018-06-22 06:04:35 --> Users MX_Controller Initialized
DEBUG - 2018-06-22 06:04:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-22 06:04:35 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-22 06:04:35 --> Login MX_Controller Initialized
INFO - 2018-06-22 06:04:35 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-22 06:04:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-22 06:04:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-06-22 06:04:36 --> Final output sent to browser
DEBUG - 2018-06-22 06:04:36 --> Total execution time: 0.7011
INFO - 2018-06-22 06:05:30 --> Config Class Initialized
INFO - 2018-06-22 06:05:30 --> Hooks Class Initialized
DEBUG - 2018-06-22 06:05:30 --> UTF-8 Support Enabled
INFO - 2018-06-22 06:05:30 --> Utf8 Class Initialized
INFO - 2018-06-22 06:05:30 --> URI Class Initialized
INFO - 2018-06-22 06:05:30 --> Router Class Initialized
INFO - 2018-06-22 06:05:30 --> Output Class Initialized
INFO - 2018-06-22 06:05:30 --> Security Class Initialized
DEBUG - 2018-06-22 06:05:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 06:05:30 --> Input Class Initialized
INFO - 2018-06-22 06:05:30 --> Language Class Initialized
INFO - 2018-06-22 06:05:30 --> Language Class Initialized
INFO - 2018-06-22 06:05:30 --> Config Class Initialized
INFO - 2018-06-22 06:05:30 --> Loader Class Initialized
DEBUG - 2018-06-22 06:05:30 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-22 06:05:30 --> Helper loaded: url_helper
INFO - 2018-06-22 06:05:30 --> Helper loaded: form_helper
INFO - 2018-06-22 06:05:30 --> Helper loaded: date_helper
INFO - 2018-06-22 06:05:30 --> Helper loaded: util_helper
INFO - 2018-06-22 06:05:30 --> Helper loaded: text_helper
INFO - 2018-06-22 06:05:30 --> Helper loaded: string_helper
INFO - 2018-06-22 06:05:30 --> Database Driver Class Initialized
DEBUG - 2018-06-22 06:05:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 06:05:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 06:05:30 --> Email Class Initialized
INFO - 2018-06-22 06:05:30 --> Controller Class Initialized
DEBUG - 2018-06-22 06:05:30 --> Users MX_Controller Initialized
DEBUG - 2018-06-22 06:05:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-22 06:05:31 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-22 06:05:31 --> Login MX_Controller Initialized
INFO - 2018-06-22 06:05:31 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-22 06:05:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-22 06:05:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-22 06:05:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-22 06:05:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-22 06:05:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-22 06:05:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-22 06:05:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-06-22 06:05:31 --> Final output sent to browser
DEBUG - 2018-06-22 06:05:31 --> Total execution time: 0.5637
INFO - 2018-06-22 06:05:31 --> Config Class Initialized
INFO - 2018-06-22 06:05:31 --> Hooks Class Initialized
DEBUG - 2018-06-22 06:05:31 --> UTF-8 Support Enabled
INFO - 2018-06-22 06:05:31 --> Utf8 Class Initialized
INFO - 2018-06-22 06:05:31 --> URI Class Initialized
INFO - 2018-06-22 06:05:32 --> Router Class Initialized
INFO - 2018-06-22 06:05:32 --> Output Class Initialized
INFO - 2018-06-22 06:05:32 --> Security Class Initialized
DEBUG - 2018-06-22 06:05:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 06:05:32 --> Input Class Initialized
INFO - 2018-06-22 06:05:32 --> Language Class Initialized
INFO - 2018-06-22 06:05:32 --> Language Class Initialized
INFO - 2018-06-22 06:05:32 --> Config Class Initialized
INFO - 2018-06-22 06:05:32 --> Loader Class Initialized
DEBUG - 2018-06-22 06:05:32 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-22 06:05:32 --> Helper loaded: url_helper
INFO - 2018-06-22 06:05:32 --> Helper loaded: form_helper
INFO - 2018-06-22 06:05:32 --> Helper loaded: date_helper
INFO - 2018-06-22 06:05:32 --> Helper loaded: util_helper
INFO - 2018-06-22 06:05:32 --> Helper loaded: text_helper
INFO - 2018-06-22 06:05:32 --> Helper loaded: string_helper
INFO - 2018-06-22 06:05:32 --> Database Driver Class Initialized
DEBUG - 2018-06-22 06:05:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 06:05:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 06:05:32 --> Email Class Initialized
INFO - 2018-06-22 06:05:32 --> Controller Class Initialized
DEBUG - 2018-06-22 06:05:32 --> Users MX_Controller Initialized
DEBUG - 2018-06-22 06:05:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-22 06:05:32 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-22 06:05:32 --> Login MX_Controller Initialized
INFO - 2018-06-22 06:05:32 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-22 06:05:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-22 06:05:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-06-22 06:05:32 --> Final output sent to browser
DEBUG - 2018-06-22 06:05:32 --> Total execution time: 0.6378
INFO - 2018-06-22 06:05:44 --> Config Class Initialized
INFO - 2018-06-22 06:05:44 --> Hooks Class Initialized
DEBUG - 2018-06-22 06:05:44 --> UTF-8 Support Enabled
INFO - 2018-06-22 06:05:44 --> Utf8 Class Initialized
INFO - 2018-06-22 06:05:44 --> URI Class Initialized
INFO - 2018-06-22 06:05:44 --> Router Class Initialized
INFO - 2018-06-22 06:05:44 --> Output Class Initialized
INFO - 2018-06-22 06:05:44 --> Security Class Initialized
DEBUG - 2018-06-22 06:05:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 06:05:44 --> Input Class Initialized
INFO - 2018-06-22 06:05:44 --> Language Class Initialized
INFO - 2018-06-22 06:05:44 --> Language Class Initialized
INFO - 2018-06-22 06:05:44 --> Config Class Initialized
INFO - 2018-06-22 06:05:44 --> Loader Class Initialized
DEBUG - 2018-06-22 06:05:44 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-22 06:05:44 --> Helper loaded: url_helper
INFO - 2018-06-22 06:05:44 --> Helper loaded: form_helper
INFO - 2018-06-22 06:05:44 --> Helper loaded: date_helper
INFO - 2018-06-22 06:05:44 --> Helper loaded: util_helper
INFO - 2018-06-22 06:05:44 --> Helper loaded: text_helper
INFO - 2018-06-22 06:05:44 --> Helper loaded: string_helper
INFO - 2018-06-22 06:05:44 --> Database Driver Class Initialized
DEBUG - 2018-06-22 06:05:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 06:05:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 06:05:44 --> Email Class Initialized
INFO - 2018-06-22 06:05:44 --> Controller Class Initialized
DEBUG - 2018-06-22 06:05:44 --> Users MX_Controller Initialized
DEBUG - 2018-06-22 06:05:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-22 06:05:44 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-22 06:05:44 --> Login MX_Controller Initialized
INFO - 2018-06-22 06:05:44 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-22 06:05:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-22 06:05:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-22 06:05:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-22 06:05:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-22 06:05:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-22 06:05:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-22 06:05:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-06-22 06:05:44 --> Final output sent to browser
DEBUG - 2018-06-22 06:05:44 --> Total execution time: 0.5789
INFO - 2018-06-22 06:05:45 --> Config Class Initialized
INFO - 2018-06-22 06:05:45 --> Hooks Class Initialized
DEBUG - 2018-06-22 06:05:45 --> UTF-8 Support Enabled
INFO - 2018-06-22 06:05:45 --> Utf8 Class Initialized
INFO - 2018-06-22 06:05:45 --> URI Class Initialized
INFO - 2018-06-22 06:05:45 --> Router Class Initialized
INFO - 2018-06-22 06:05:45 --> Output Class Initialized
INFO - 2018-06-22 06:05:45 --> Security Class Initialized
DEBUG - 2018-06-22 06:05:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 06:05:45 --> Input Class Initialized
INFO - 2018-06-22 06:05:45 --> Language Class Initialized
INFO - 2018-06-22 06:05:45 --> Language Class Initialized
INFO - 2018-06-22 06:05:45 --> Config Class Initialized
INFO - 2018-06-22 06:05:45 --> Loader Class Initialized
DEBUG - 2018-06-22 06:05:45 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-22 06:05:45 --> Helper loaded: url_helper
INFO - 2018-06-22 06:05:45 --> Helper loaded: form_helper
INFO - 2018-06-22 06:05:46 --> Helper loaded: date_helper
INFO - 2018-06-22 06:05:46 --> Helper loaded: util_helper
INFO - 2018-06-22 06:05:46 --> Helper loaded: text_helper
INFO - 2018-06-22 06:05:46 --> Helper loaded: string_helper
INFO - 2018-06-22 06:05:46 --> Database Driver Class Initialized
DEBUG - 2018-06-22 06:05:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 06:05:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 06:05:46 --> Email Class Initialized
INFO - 2018-06-22 06:05:46 --> Controller Class Initialized
DEBUG - 2018-06-22 06:05:46 --> Users MX_Controller Initialized
DEBUG - 2018-06-22 06:05:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-22 06:05:46 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-22 06:05:46 --> Login MX_Controller Initialized
INFO - 2018-06-22 06:05:46 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-22 06:05:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-22 06:05:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-06-22 06:05:46 --> Final output sent to browser
DEBUG - 2018-06-22 06:05:46 --> Total execution time: 0.6438
INFO - 2018-06-22 06:05:59 --> Config Class Initialized
INFO - 2018-06-22 06:05:59 --> Hooks Class Initialized
DEBUG - 2018-06-22 06:05:59 --> UTF-8 Support Enabled
INFO - 2018-06-22 06:05:59 --> Utf8 Class Initialized
INFO - 2018-06-22 06:05:59 --> URI Class Initialized
INFO - 2018-06-22 06:05:59 --> Router Class Initialized
INFO - 2018-06-22 06:05:59 --> Output Class Initialized
INFO - 2018-06-22 06:06:00 --> Security Class Initialized
DEBUG - 2018-06-22 06:06:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 06:06:00 --> Input Class Initialized
INFO - 2018-06-22 06:06:00 --> Language Class Initialized
INFO - 2018-06-22 06:06:00 --> Language Class Initialized
INFO - 2018-06-22 06:06:00 --> Config Class Initialized
INFO - 2018-06-22 06:06:00 --> Loader Class Initialized
DEBUG - 2018-06-22 06:06:00 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-22 06:06:00 --> Helper loaded: url_helper
INFO - 2018-06-22 06:06:00 --> Helper loaded: form_helper
INFO - 2018-06-22 06:06:00 --> Helper loaded: date_helper
INFO - 2018-06-22 06:06:00 --> Helper loaded: util_helper
INFO - 2018-06-22 06:06:00 --> Helper loaded: text_helper
INFO - 2018-06-22 06:06:00 --> Helper loaded: string_helper
INFO - 2018-06-22 06:06:00 --> Database Driver Class Initialized
DEBUG - 2018-06-22 06:06:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 06:06:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 06:06:00 --> Email Class Initialized
INFO - 2018-06-22 06:06:00 --> Controller Class Initialized
DEBUG - 2018-06-22 06:06:00 --> Users MX_Controller Initialized
DEBUG - 2018-06-22 06:06:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-22 06:06:00 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-22 06:06:00 --> Login MX_Controller Initialized
INFO - 2018-06-22 06:06:00 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-22 06:06:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-22 06:06:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-22 06:06:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-22 06:06:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-22 06:06:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-22 06:06:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-22 06:06:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-06-22 06:06:00 --> Final output sent to browser
DEBUG - 2018-06-22 06:06:00 --> Total execution time: 0.6020
INFO - 2018-06-22 06:06:01 --> Config Class Initialized
INFO - 2018-06-22 06:06:01 --> Hooks Class Initialized
DEBUG - 2018-06-22 06:06:01 --> UTF-8 Support Enabled
INFO - 2018-06-22 06:06:01 --> Utf8 Class Initialized
INFO - 2018-06-22 06:06:01 --> URI Class Initialized
INFO - 2018-06-22 06:06:01 --> Router Class Initialized
INFO - 2018-06-22 06:06:01 --> Output Class Initialized
INFO - 2018-06-22 06:06:01 --> Security Class Initialized
DEBUG - 2018-06-22 06:06:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 06:06:01 --> Input Class Initialized
INFO - 2018-06-22 06:06:01 --> Language Class Initialized
INFO - 2018-06-22 06:06:01 --> Language Class Initialized
INFO - 2018-06-22 06:06:01 --> Config Class Initialized
INFO - 2018-06-22 06:06:01 --> Loader Class Initialized
DEBUG - 2018-06-22 06:06:01 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-22 06:06:01 --> Helper loaded: url_helper
INFO - 2018-06-22 06:06:01 --> Helper loaded: form_helper
INFO - 2018-06-22 06:06:01 --> Helper loaded: date_helper
INFO - 2018-06-22 06:06:01 --> Helper loaded: util_helper
INFO - 2018-06-22 06:06:01 --> Helper loaded: text_helper
INFO - 2018-06-22 06:06:01 --> Helper loaded: string_helper
INFO - 2018-06-22 06:06:02 --> Database Driver Class Initialized
DEBUG - 2018-06-22 06:06:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 06:06:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 06:06:02 --> Email Class Initialized
INFO - 2018-06-22 06:06:02 --> Controller Class Initialized
DEBUG - 2018-06-22 06:06:02 --> Users MX_Controller Initialized
DEBUG - 2018-06-22 06:06:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-22 06:06:02 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-22 06:06:02 --> Login MX_Controller Initialized
INFO - 2018-06-22 06:06:02 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-22 06:06:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-22 06:06:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-06-22 06:06:02 --> Final output sent to browser
DEBUG - 2018-06-22 06:06:02 --> Total execution time: 0.7802
INFO - 2018-06-22 06:06:15 --> Config Class Initialized
INFO - 2018-06-22 06:06:15 --> Hooks Class Initialized
DEBUG - 2018-06-22 06:06:15 --> UTF-8 Support Enabled
INFO - 2018-06-22 06:06:15 --> Utf8 Class Initialized
INFO - 2018-06-22 06:06:15 --> URI Class Initialized
INFO - 2018-06-22 06:06:15 --> Router Class Initialized
INFO - 2018-06-22 06:06:15 --> Output Class Initialized
INFO - 2018-06-22 06:06:15 --> Security Class Initialized
DEBUG - 2018-06-22 06:06:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 06:06:15 --> Input Class Initialized
INFO - 2018-06-22 06:06:15 --> Language Class Initialized
INFO - 2018-06-22 06:06:15 --> Language Class Initialized
INFO - 2018-06-22 06:06:15 --> Config Class Initialized
INFO - 2018-06-22 06:06:15 --> Loader Class Initialized
DEBUG - 2018-06-22 06:06:15 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-22 06:06:15 --> Helper loaded: url_helper
INFO - 2018-06-22 06:06:15 --> Helper loaded: form_helper
INFO - 2018-06-22 06:06:15 --> Helper loaded: date_helper
INFO - 2018-06-22 06:06:15 --> Helper loaded: util_helper
INFO - 2018-06-22 06:06:15 --> Helper loaded: text_helper
INFO - 2018-06-22 06:06:15 --> Helper loaded: string_helper
INFO - 2018-06-22 06:06:15 --> Database Driver Class Initialized
DEBUG - 2018-06-22 06:06:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 06:06:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 06:06:15 --> Email Class Initialized
INFO - 2018-06-22 06:06:15 --> Controller Class Initialized
DEBUG - 2018-06-22 06:06:15 --> Users MX_Controller Initialized
DEBUG - 2018-06-22 06:06:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-22 06:06:15 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-22 06:06:15 --> Login MX_Controller Initialized
INFO - 2018-06-22 06:06:15 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-22 06:06:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-22 06:06:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
INFO - 2018-06-22 06:06:15 --> Config Class Initialized
INFO - 2018-06-22 06:06:15 --> Hooks Class Initialized
DEBUG - 2018-06-22 06:06:15 --> UTF-8 Support Enabled
INFO - 2018-06-22 06:06:15 --> Utf8 Class Initialized
INFO - 2018-06-22 06:06:15 --> URI Class Initialized
INFO - 2018-06-22 06:06:15 --> Router Class Initialized
INFO - 2018-06-22 06:06:15 --> Output Class Initialized
INFO - 2018-06-22 06:06:15 --> Security Class Initialized
DEBUG - 2018-06-22 06:06:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 06:06:15 --> Input Class Initialized
INFO - 2018-06-22 06:06:15 --> Language Class Initialized
ERROR - 2018-06-22 06:06:15 --> 404 Page Not Found: /index
INFO - 2018-06-22 06:06:17 --> Config Class Initialized
INFO - 2018-06-22 06:06:17 --> Hooks Class Initialized
DEBUG - 2018-06-22 06:06:17 --> UTF-8 Support Enabled
INFO - 2018-06-22 06:06:17 --> Utf8 Class Initialized
INFO - 2018-06-22 06:06:17 --> URI Class Initialized
INFO - 2018-06-22 06:06:17 --> Router Class Initialized
INFO - 2018-06-22 06:06:17 --> Output Class Initialized
INFO - 2018-06-22 06:06:17 --> Security Class Initialized
DEBUG - 2018-06-22 06:06:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 06:06:17 --> Input Class Initialized
INFO - 2018-06-22 06:06:17 --> Language Class Initialized
ERROR - 2018-06-22 06:06:17 --> 404 Page Not Found: /index
INFO - 2018-06-22 06:06:25 --> Config Class Initialized
INFO - 2018-06-22 06:06:25 --> Hooks Class Initialized
DEBUG - 2018-06-22 06:06:25 --> UTF-8 Support Enabled
INFO - 2018-06-22 06:06:25 --> Utf8 Class Initialized
INFO - 2018-06-22 06:06:25 --> URI Class Initialized
INFO - 2018-06-22 06:06:25 --> Router Class Initialized
INFO - 2018-06-22 06:06:25 --> Output Class Initialized
INFO - 2018-06-22 06:06:25 --> Security Class Initialized
DEBUG - 2018-06-22 06:06:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 06:06:25 --> Input Class Initialized
INFO - 2018-06-22 06:06:25 --> Language Class Initialized
INFO - 2018-06-22 06:06:25 --> Language Class Initialized
INFO - 2018-06-22 06:06:25 --> Config Class Initialized
INFO - 2018-06-22 06:06:25 --> Loader Class Initialized
DEBUG - 2018-06-22 06:06:25 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-22 06:06:25 --> Helper loaded: url_helper
INFO - 2018-06-22 06:06:25 --> Helper loaded: form_helper
INFO - 2018-06-22 06:06:25 --> Helper loaded: date_helper
INFO - 2018-06-22 06:06:25 --> Helper loaded: util_helper
INFO - 2018-06-22 06:06:25 --> Helper loaded: text_helper
INFO - 2018-06-22 06:06:25 --> Helper loaded: string_helper
INFO - 2018-06-22 06:06:25 --> Database Driver Class Initialized
DEBUG - 2018-06-22 06:06:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 06:06:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 06:06:26 --> Email Class Initialized
INFO - 2018-06-22 06:06:26 --> Controller Class Initialized
DEBUG - 2018-06-22 06:06:26 --> Login MX_Controller Initialized
INFO - 2018-06-22 06:06:26 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-22 06:06:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-22 06:06:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-22 06:06:26 --> Email starts for admin@colin.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-06-22 06:06:26 --> User session created for 1
INFO - 2018-06-22 06:06:26 --> Login status admin@colin.com - success
INFO - 2018-06-22 06:06:26 --> Final output sent to browser
DEBUG - 2018-06-22 06:06:26 --> Total execution time: 0.5522
INFO - 2018-06-22 06:06:26 --> Config Class Initialized
INFO - 2018-06-22 06:06:26 --> Hooks Class Initialized
DEBUG - 2018-06-22 06:06:26 --> UTF-8 Support Enabled
INFO - 2018-06-22 06:06:26 --> Utf8 Class Initialized
INFO - 2018-06-22 06:06:26 --> URI Class Initialized
INFO - 2018-06-22 06:06:26 --> Router Class Initialized
INFO - 2018-06-22 06:06:26 --> Output Class Initialized
INFO - 2018-06-22 06:06:26 --> Security Class Initialized
DEBUG - 2018-06-22 06:06:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 06:06:26 --> Input Class Initialized
INFO - 2018-06-22 06:06:26 --> Language Class Initialized
INFO - 2018-06-22 06:06:26 --> Language Class Initialized
INFO - 2018-06-22 06:06:26 --> Config Class Initialized
INFO - 2018-06-22 06:06:26 --> Loader Class Initialized
DEBUG - 2018-06-22 06:06:26 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-22 06:06:26 --> Helper loaded: url_helper
INFO - 2018-06-22 06:06:26 --> Helper loaded: form_helper
INFO - 2018-06-22 06:06:26 --> Helper loaded: date_helper
INFO - 2018-06-22 06:06:26 --> Helper loaded: util_helper
INFO - 2018-06-22 06:06:26 --> Helper loaded: text_helper
INFO - 2018-06-22 06:06:26 --> Helper loaded: string_helper
INFO - 2018-06-22 06:06:26 --> Database Driver Class Initialized
DEBUG - 2018-06-22 06:06:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 06:06:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 06:06:26 --> Email Class Initialized
INFO - 2018-06-22 06:06:26 --> Controller Class Initialized
DEBUG - 2018-06-22 06:06:26 --> Users MX_Controller Initialized
DEBUG - 2018-06-22 06:06:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-22 06:06:26 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-22 06:06:26 --> Login MX_Controller Initialized
INFO - 2018-06-22 06:06:26 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-22 06:06:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-22 06:06:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-22 06:06:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-22 06:06:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-22 06:06:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-22 06:06:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-22 06:06:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-06-22 06:06:26 --> Final output sent to browser
DEBUG - 2018-06-22 06:06:26 --> Total execution time: 0.5603
INFO - 2018-06-22 06:06:27 --> Config Class Initialized
INFO - 2018-06-22 06:06:27 --> Hooks Class Initialized
DEBUG - 2018-06-22 06:06:27 --> UTF-8 Support Enabled
INFO - 2018-06-22 06:06:27 --> Utf8 Class Initialized
INFO - 2018-06-22 06:06:27 --> URI Class Initialized
INFO - 2018-06-22 06:06:27 --> Router Class Initialized
INFO - 2018-06-22 06:06:27 --> Output Class Initialized
INFO - 2018-06-22 06:06:27 --> Security Class Initialized
DEBUG - 2018-06-22 06:06:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 06:06:27 --> Input Class Initialized
INFO - 2018-06-22 06:06:27 --> Language Class Initialized
INFO - 2018-06-22 06:06:27 --> Language Class Initialized
INFO - 2018-06-22 06:06:27 --> Config Class Initialized
INFO - 2018-06-22 06:06:27 --> Loader Class Initialized
DEBUG - 2018-06-22 06:06:27 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-22 06:06:27 --> Helper loaded: url_helper
INFO - 2018-06-22 06:06:27 --> Helper loaded: form_helper
INFO - 2018-06-22 06:06:27 --> Helper loaded: date_helper
INFO - 2018-06-22 06:06:27 --> Helper loaded: util_helper
INFO - 2018-06-22 06:06:27 --> Helper loaded: text_helper
INFO - 2018-06-22 06:06:27 --> Helper loaded: string_helper
INFO - 2018-06-22 06:06:28 --> Database Driver Class Initialized
DEBUG - 2018-06-22 06:06:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 06:06:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 06:06:28 --> Email Class Initialized
INFO - 2018-06-22 06:06:28 --> Controller Class Initialized
DEBUG - 2018-06-22 06:06:28 --> Users MX_Controller Initialized
DEBUG - 2018-06-22 06:06:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-22 06:06:28 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-22 06:06:28 --> Login MX_Controller Initialized
INFO - 2018-06-22 06:06:28 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-22 06:06:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-22 06:06:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-06-22 06:06:28 --> Final output sent to browser
DEBUG - 2018-06-22 06:06:28 --> Total execution time: 0.9965
INFO - 2018-06-22 21:11:09 --> Config Class Initialized
INFO - 2018-06-22 21:11:09 --> Hooks Class Initialized
DEBUG - 2018-06-22 21:11:09 --> UTF-8 Support Enabled
INFO - 2018-06-22 21:11:09 --> Utf8 Class Initialized
INFO - 2018-06-22 21:11:09 --> URI Class Initialized
INFO - 2018-06-22 21:11:09 --> Router Class Initialized
INFO - 2018-06-22 21:11:10 --> Output Class Initialized
INFO - 2018-06-22 21:11:10 --> Security Class Initialized
DEBUG - 2018-06-22 21:11:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 21:11:10 --> Input Class Initialized
INFO - 2018-06-22 21:11:10 --> Language Class Initialized
INFO - 2018-06-22 21:11:10 --> Language Class Initialized
INFO - 2018-06-22 21:11:10 --> Config Class Initialized
INFO - 2018-06-22 21:11:10 --> Loader Class Initialized
DEBUG - 2018-06-22 21:11:11 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-22 21:11:11 --> Helper loaded: url_helper
INFO - 2018-06-22 21:11:11 --> Helper loaded: form_helper
INFO - 2018-06-22 21:11:11 --> Helper loaded: date_helper
INFO - 2018-06-22 21:11:11 --> Helper loaded: util_helper
INFO - 2018-06-22 21:11:11 --> Helper loaded: text_helper
INFO - 2018-06-22 21:11:11 --> Helper loaded: string_helper
INFO - 2018-06-22 21:11:11 --> Database Driver Class Initialized
DEBUG - 2018-06-22 21:11:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 21:11:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 21:11:12 --> Email Class Initialized
INFO - 2018-06-22 21:11:12 --> Controller Class Initialized
DEBUG - 2018-06-22 21:11:12 --> Home MX_Controller Initialized
DEBUG - 2018-06-22 21:11:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-22 21:11:13 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-22 21:11:13 --> Login MX_Controller Initialized
INFO - 2018-06-22 21:11:13 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-22 21:11:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-22 21:11:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-22 21:11:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-06-22 21:11:53 --> Config Class Initialized
INFO - 2018-06-22 21:11:53 --> Hooks Class Initialized
DEBUG - 2018-06-22 21:11:53 --> UTF-8 Support Enabled
INFO - 2018-06-22 21:11:53 --> Utf8 Class Initialized
INFO - 2018-06-22 21:11:53 --> URI Class Initialized
INFO - 2018-06-22 21:11:53 --> Router Class Initialized
INFO - 2018-06-22 21:11:53 --> Output Class Initialized
INFO - 2018-06-22 21:11:53 --> Security Class Initialized
DEBUG - 2018-06-22 21:11:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 21:11:54 --> Input Class Initialized
INFO - 2018-06-22 21:11:54 --> Language Class Initialized
INFO - 2018-06-22 21:11:54 --> Language Class Initialized
INFO - 2018-06-22 21:11:54 --> Config Class Initialized
INFO - 2018-06-22 21:11:54 --> Loader Class Initialized
DEBUG - 2018-06-22 21:11:54 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-22 21:11:54 --> Helper loaded: url_helper
INFO - 2018-06-22 21:11:54 --> Helper loaded: form_helper
INFO - 2018-06-22 21:11:54 --> Helper loaded: date_helper
INFO - 2018-06-22 21:11:54 --> Helper loaded: util_helper
INFO - 2018-06-22 21:11:54 --> Helper loaded: text_helper
INFO - 2018-06-22 21:11:54 --> Helper loaded: string_helper
INFO - 2018-06-22 21:11:54 --> Database Driver Class Initialized
DEBUG - 2018-06-22 21:11:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 21:11:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 21:11:54 --> Email Class Initialized
INFO - 2018-06-22 21:11:54 --> Controller Class Initialized
DEBUG - 2018-06-22 21:11:54 --> Home MX_Controller Initialized
DEBUG - 2018-06-22 21:11:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-22 21:11:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/register.php
INFO - 2018-06-22 21:11:54 --> Final output sent to browser
DEBUG - 2018-06-22 21:11:54 --> Total execution time: 1.1115
INFO - 2018-06-22 21:11:56 --> Config Class Initialized
INFO - 2018-06-22 21:11:56 --> Hooks Class Initialized
DEBUG - 2018-06-22 21:11:56 --> UTF-8 Support Enabled
INFO - 2018-06-22 21:11:56 --> Utf8 Class Initialized
INFO - 2018-06-22 21:11:56 --> URI Class Initialized
INFO - 2018-06-22 21:11:56 --> Router Class Initialized
INFO - 2018-06-22 21:11:56 --> Output Class Initialized
INFO - 2018-06-22 21:11:56 --> Security Class Initialized
DEBUG - 2018-06-22 21:11:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 21:11:56 --> Input Class Initialized
INFO - 2018-06-22 21:11:56 --> Language Class Initialized
INFO - 2018-06-22 21:11:56 --> Language Class Initialized
INFO - 2018-06-22 21:11:56 --> Config Class Initialized
INFO - 2018-06-22 21:11:56 --> Loader Class Initialized
DEBUG - 2018-06-22 21:11:56 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-22 21:11:56 --> Helper loaded: url_helper
INFO - 2018-06-22 21:11:57 --> Helper loaded: form_helper
INFO - 2018-06-22 21:11:57 --> Helper loaded: date_helper
INFO - 2018-06-22 21:11:57 --> Helper loaded: util_helper
INFO - 2018-06-22 21:11:57 --> Helper loaded: text_helper
INFO - 2018-06-22 21:11:57 --> Helper loaded: string_helper
INFO - 2018-06-22 21:11:57 --> Database Driver Class Initialized
DEBUG - 2018-06-22 21:11:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 21:11:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 21:11:57 --> Email Class Initialized
INFO - 2018-06-22 21:11:57 --> Controller Class Initialized
DEBUG - 2018-06-22 21:11:57 --> Home MX_Controller Initialized
DEBUG - 2018-06-22 21:11:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-22 21:11:57 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-22 21:11:57 --> Login MX_Controller Initialized
INFO - 2018-06-22 21:11:57 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-22 21:11:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-22 21:11:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-22 21:11:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-06-22 21:12:00 --> Config Class Initialized
INFO - 2018-06-22 21:12:00 --> Hooks Class Initialized
DEBUG - 2018-06-22 21:12:00 --> UTF-8 Support Enabled
INFO - 2018-06-22 21:12:00 --> Utf8 Class Initialized
INFO - 2018-06-22 21:12:00 --> URI Class Initialized
INFO - 2018-06-22 21:12:00 --> Router Class Initialized
INFO - 2018-06-22 21:12:00 --> Output Class Initialized
INFO - 2018-06-22 21:12:00 --> Security Class Initialized
DEBUG - 2018-06-22 21:12:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 21:12:00 --> Input Class Initialized
INFO - 2018-06-22 21:12:00 --> Language Class Initialized
INFO - 2018-06-22 21:12:00 --> Language Class Initialized
INFO - 2018-06-22 21:12:00 --> Config Class Initialized
INFO - 2018-06-22 21:12:00 --> Loader Class Initialized
DEBUG - 2018-06-22 21:12:00 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-22 21:12:00 --> Helper loaded: url_helper
INFO - 2018-06-22 21:12:00 --> Helper loaded: form_helper
INFO - 2018-06-22 21:12:00 --> Helper loaded: date_helper
INFO - 2018-06-22 21:12:00 --> Helper loaded: util_helper
INFO - 2018-06-22 21:12:00 --> Helper loaded: text_helper
INFO - 2018-06-22 21:12:00 --> Helper loaded: string_helper
INFO - 2018-06-22 21:12:00 --> Database Driver Class Initialized
DEBUG - 2018-06-22 21:12:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 21:12:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 21:12:00 --> Email Class Initialized
INFO - 2018-06-22 21:12:00 --> Controller Class Initialized
DEBUG - 2018-06-22 21:12:00 --> Login MX_Controller Initialized
INFO - 2018-06-22 21:12:00 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-22 21:12:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-22 21:12:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-22 21:12:00 --> Email starts for user@colin.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-06-22 21:12:00 --> User session created for 4
INFO - 2018-06-22 21:12:01 --> Login status user@colin.com - success
INFO - 2018-06-22 21:12:01 --> Final output sent to browser
DEBUG - 2018-06-22 21:12:01 --> Total execution time: 0.5898
INFO - 2018-06-22 21:12:01 --> Config Class Initialized
INFO - 2018-06-22 21:12:01 --> Hooks Class Initialized
DEBUG - 2018-06-22 21:12:01 --> UTF-8 Support Enabled
INFO - 2018-06-22 21:12:01 --> Utf8 Class Initialized
INFO - 2018-06-22 21:12:01 --> URI Class Initialized
INFO - 2018-06-22 21:12:01 --> Router Class Initialized
INFO - 2018-06-22 21:12:01 --> Output Class Initialized
INFO - 2018-06-22 21:12:01 --> Security Class Initialized
DEBUG - 2018-06-22 21:12:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 21:12:01 --> Input Class Initialized
INFO - 2018-06-22 21:12:01 --> Language Class Initialized
INFO - 2018-06-22 21:12:01 --> Language Class Initialized
INFO - 2018-06-22 21:12:01 --> Config Class Initialized
INFO - 2018-06-22 21:12:01 --> Loader Class Initialized
DEBUG - 2018-06-22 21:12:01 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-22 21:12:01 --> Helper loaded: url_helper
INFO - 2018-06-22 21:12:01 --> Helper loaded: form_helper
INFO - 2018-06-22 21:12:01 --> Helper loaded: date_helper
INFO - 2018-06-22 21:12:01 --> Helper loaded: util_helper
INFO - 2018-06-22 21:12:01 --> Helper loaded: text_helper
INFO - 2018-06-22 21:12:01 --> Helper loaded: string_helper
INFO - 2018-06-22 21:12:01 --> Database Driver Class Initialized
DEBUG - 2018-06-22 21:12:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 21:12:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 21:12:01 --> Email Class Initialized
INFO - 2018-06-22 21:12:01 --> Controller Class Initialized
DEBUG - 2018-06-22 21:12:01 --> Home MX_Controller Initialized
DEBUG - 2018-06-22 21:12:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-22 21:12:01 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-22 21:12:01 --> Login MX_Controller Initialized
INFO - 2018-06-22 21:12:01 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-22 21:12:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-22 21:12:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-22 21:12:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-22 21:12:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-22 21:12:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-22 21:12:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-22 21:12:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-22 21:12:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-06-22 21:12:01 --> Final output sent to browser
DEBUG - 2018-06-22 21:12:01 --> Total execution time: 0.8036
INFO - 2018-06-22 21:12:02 --> Config Class Initialized
INFO - 2018-06-22 21:12:02 --> Hooks Class Initialized
DEBUG - 2018-06-22 21:12:02 --> UTF-8 Support Enabled
INFO - 2018-06-22 21:12:02 --> Utf8 Class Initialized
INFO - 2018-06-22 21:12:02 --> URI Class Initialized
INFO - 2018-06-22 21:12:02 --> Router Class Initialized
INFO - 2018-06-22 21:12:02 --> Output Class Initialized
INFO - 2018-06-22 21:12:02 --> Security Class Initialized
DEBUG - 2018-06-22 21:12:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 21:12:02 --> Input Class Initialized
INFO - 2018-06-22 21:12:02 --> Language Class Initialized
INFO - 2018-06-22 21:12:02 --> Language Class Initialized
INFO - 2018-06-22 21:12:02 --> Config Class Initialized
INFO - 2018-06-22 21:12:02 --> Loader Class Initialized
DEBUG - 2018-06-22 21:12:02 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-22 21:12:02 --> Helper loaded: url_helper
INFO - 2018-06-22 21:12:02 --> Helper loaded: form_helper
INFO - 2018-06-22 21:12:02 --> Helper loaded: date_helper
INFO - 2018-06-22 21:12:02 --> Helper loaded: util_helper
INFO - 2018-06-22 21:12:02 --> Helper loaded: text_helper
INFO - 2018-06-22 21:12:02 --> Helper loaded: string_helper
INFO - 2018-06-22 21:12:02 --> Database Driver Class Initialized
DEBUG - 2018-06-22 21:12:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 21:12:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 21:12:02 --> Email Class Initialized
INFO - 2018-06-22 21:12:02 --> Controller Class Initialized
DEBUG - 2018-06-22 21:12:02 --> Users MX_Controller Initialized
DEBUG - 2018-06-22 21:12:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-22 21:12:02 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-22 21:12:02 --> Login MX_Controller Initialized
INFO - 2018-06-22 21:12:02 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-22 21:12:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-22 21:12:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
INFO - 2018-06-22 21:12:03 --> Config Class Initialized
INFO - 2018-06-22 21:12:03 --> Hooks Class Initialized
DEBUG - 2018-06-22 21:12:03 --> UTF-8 Support Enabled
INFO - 2018-06-22 21:12:03 --> Utf8 Class Initialized
INFO - 2018-06-22 21:12:03 --> URI Class Initialized
INFO - 2018-06-22 21:12:03 --> Router Class Initialized
INFO - 2018-06-22 21:12:03 --> Output Class Initialized
INFO - 2018-06-22 21:12:03 --> Security Class Initialized
DEBUG - 2018-06-22 21:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 21:12:03 --> Input Class Initialized
INFO - 2018-06-22 21:12:03 --> Language Class Initialized
INFO - 2018-06-22 21:12:03 --> Config Class Initialized
INFO - 2018-06-22 21:12:03 --> Hooks Class Initialized
DEBUG - 2018-06-22 21:12:03 --> UTF-8 Support Enabled
ERROR - 2018-06-22 21:12:03 --> 404 Page Not Found: /index
INFO - 2018-06-22 21:12:03 --> Utf8 Class Initialized
INFO - 2018-06-22 21:12:03 --> URI Class Initialized
INFO - 2018-06-22 21:12:03 --> Router Class Initialized
INFO - 2018-06-22 21:12:03 --> Output Class Initialized
INFO - 2018-06-22 21:12:03 --> Security Class Initialized
DEBUG - 2018-06-22 21:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 21:12:03 --> Input Class Initialized
INFO - 2018-06-22 21:12:03 --> Language Class Initialized
ERROR - 2018-06-22 21:12:03 --> 404 Page Not Found: /index
INFO - 2018-06-22 21:12:03 --> Config Class Initialized
INFO - 2018-06-22 21:12:03 --> Hooks Class Initialized
DEBUG - 2018-06-22 21:12:03 --> UTF-8 Support Enabled
INFO - 2018-06-22 21:12:03 --> Utf8 Class Initialized
INFO - 2018-06-22 21:12:03 --> URI Class Initialized
INFO - 2018-06-22 21:12:03 --> Router Class Initialized
INFO - 2018-06-22 21:12:03 --> Output Class Initialized
INFO - 2018-06-22 21:12:03 --> Security Class Initialized
DEBUG - 2018-06-22 21:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 21:12:03 --> Input Class Initialized
INFO - 2018-06-22 21:12:03 --> Language Class Initialized
ERROR - 2018-06-22 21:12:03 --> 404 Page Not Found: /index
INFO - 2018-06-22 21:12:03 --> Config Class Initialized
INFO - 2018-06-22 21:12:03 --> Hooks Class Initialized
DEBUG - 2018-06-22 21:12:03 --> UTF-8 Support Enabled
INFO - 2018-06-22 21:12:03 --> Utf8 Class Initialized
INFO - 2018-06-22 21:12:04 --> URI Class Initialized
INFO - 2018-06-22 21:12:04 --> Router Class Initialized
INFO - 2018-06-22 21:12:04 --> Config Class Initialized
INFO - 2018-06-22 21:12:04 --> Hooks Class Initialized
INFO - 2018-06-22 21:12:04 --> Output Class Initialized
INFO - 2018-06-22 21:12:04 --> Security Class Initialized
DEBUG - 2018-06-22 21:12:04 --> UTF-8 Support Enabled
INFO - 2018-06-22 21:12:04 --> Utf8 Class Initialized
DEBUG - 2018-06-22 21:12:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 21:12:04 --> Input Class Initialized
INFO - 2018-06-22 21:12:04 --> URI Class Initialized
INFO - 2018-06-22 21:12:04 --> Language Class Initialized
INFO - 2018-06-22 21:12:04 --> Router Class Initialized
ERROR - 2018-06-22 21:12:04 --> 404 Page Not Found: /index
INFO - 2018-06-22 21:12:04 --> Output Class Initialized
INFO - 2018-06-22 21:12:04 --> Security Class Initialized
DEBUG - 2018-06-22 21:12:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 21:12:04 --> Input Class Initialized
INFO - 2018-06-22 21:12:04 --> Language Class Initialized
ERROR - 2018-06-22 21:12:04 --> 404 Page Not Found: /index
INFO - 2018-06-22 21:12:04 --> Config Class Initialized
INFO - 2018-06-22 21:12:04 --> Hooks Class Initialized
DEBUG - 2018-06-22 21:12:04 --> UTF-8 Support Enabled
INFO - 2018-06-22 21:12:04 --> Utf8 Class Initialized
INFO - 2018-06-22 21:12:04 --> URI Class Initialized
INFO - 2018-06-22 21:12:04 --> Router Class Initialized
INFO - 2018-06-22 21:12:04 --> Output Class Initialized
INFO - 2018-06-22 21:12:04 --> Security Class Initialized
DEBUG - 2018-06-22 21:12:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 21:12:04 --> Input Class Initialized
INFO - 2018-06-22 21:12:04 --> Language Class Initialized
ERROR - 2018-06-22 21:12:04 --> 404 Page Not Found: /index
INFO - 2018-06-22 21:12:04 --> Config Class Initialized
INFO - 2018-06-22 21:12:04 --> Hooks Class Initialized
DEBUG - 2018-06-22 21:12:04 --> UTF-8 Support Enabled
INFO - 2018-06-22 21:12:04 --> Utf8 Class Initialized
INFO - 2018-06-22 21:12:04 --> URI Class Initialized
INFO - 2018-06-22 21:12:04 --> Router Class Initialized
INFO - 2018-06-22 21:12:04 --> Output Class Initialized
INFO - 2018-06-22 21:12:04 --> Security Class Initialized
DEBUG - 2018-06-22 21:12:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 21:12:04 --> Input Class Initialized
INFO - 2018-06-22 21:12:04 --> Language Class Initialized
ERROR - 2018-06-22 21:12:04 --> 404 Page Not Found: /index
INFO - 2018-06-22 21:12:05 --> Config Class Initialized
INFO - 2018-06-22 21:12:05 --> Hooks Class Initialized
DEBUG - 2018-06-22 21:12:05 --> UTF-8 Support Enabled
INFO - 2018-06-22 21:12:05 --> Utf8 Class Initialized
INFO - 2018-06-22 21:12:05 --> URI Class Initialized
INFO - 2018-06-22 21:12:05 --> Router Class Initialized
INFO - 2018-06-22 21:12:05 --> Output Class Initialized
INFO - 2018-06-22 21:12:05 --> Security Class Initialized
DEBUG - 2018-06-22 21:12:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 21:12:05 --> Input Class Initialized
INFO - 2018-06-22 21:12:05 --> Language Class Initialized
ERROR - 2018-06-22 21:12:05 --> 404 Page Not Found: /index
INFO - 2018-06-22 21:12:12 --> Config Class Initialized
INFO - 2018-06-22 21:12:13 --> Hooks Class Initialized
DEBUG - 2018-06-22 21:12:13 --> UTF-8 Support Enabled
INFO - 2018-06-22 21:12:13 --> Utf8 Class Initialized
INFO - 2018-06-22 21:12:13 --> URI Class Initialized
INFO - 2018-06-22 21:12:13 --> Router Class Initialized
INFO - 2018-06-22 21:12:13 --> Output Class Initialized
INFO - 2018-06-22 21:12:13 --> Security Class Initialized
DEBUG - 2018-06-22 21:12:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 21:12:13 --> Input Class Initialized
INFO - 2018-06-22 21:12:13 --> Language Class Initialized
INFO - 2018-06-22 21:12:13 --> Language Class Initialized
INFO - 2018-06-22 21:12:13 --> Config Class Initialized
INFO - 2018-06-22 21:12:13 --> Loader Class Initialized
DEBUG - 2018-06-22 21:12:13 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-22 21:12:13 --> Helper loaded: url_helper
INFO - 2018-06-22 21:12:13 --> Helper loaded: form_helper
INFO - 2018-06-22 21:12:13 --> Helper loaded: date_helper
INFO - 2018-06-22 21:12:13 --> Helper loaded: util_helper
INFO - 2018-06-22 21:12:13 --> Helper loaded: text_helper
INFO - 2018-06-22 21:12:13 --> Helper loaded: string_helper
INFO - 2018-06-22 21:12:13 --> Database Driver Class Initialized
DEBUG - 2018-06-22 21:12:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 21:12:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 21:12:13 --> Email Class Initialized
INFO - 2018-06-22 21:12:13 --> Controller Class Initialized
DEBUG - 2018-06-22 21:12:13 --> Login MX_Controller Initialized
INFO - 2018-06-22 21:12:13 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-22 21:12:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-22 21:12:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-22 21:12:13 --> Email starts for admin@colin.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-06-22 21:12:13 --> User session created for 1
INFO - 2018-06-22 21:12:13 --> Login status admin@colin.com - success
INFO - 2018-06-22 21:12:13 --> Final output sent to browser
DEBUG - 2018-06-22 21:12:13 --> Total execution time: 0.5729
INFO - 2018-06-22 21:12:13 --> Config Class Initialized
INFO - 2018-06-22 21:12:13 --> Hooks Class Initialized
DEBUG - 2018-06-22 21:12:13 --> UTF-8 Support Enabled
INFO - 2018-06-22 21:12:13 --> Utf8 Class Initialized
INFO - 2018-06-22 21:12:13 --> URI Class Initialized
INFO - 2018-06-22 21:12:13 --> Router Class Initialized
INFO - 2018-06-22 21:12:13 --> Output Class Initialized
INFO - 2018-06-22 21:12:13 --> Security Class Initialized
DEBUG - 2018-06-22 21:12:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 21:12:13 --> Input Class Initialized
INFO - 2018-06-22 21:12:13 --> Language Class Initialized
INFO - 2018-06-22 21:12:13 --> Language Class Initialized
INFO - 2018-06-22 21:12:13 --> Config Class Initialized
INFO - 2018-06-22 21:12:13 --> Loader Class Initialized
DEBUG - 2018-06-22 21:12:13 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-22 21:12:13 --> Helper loaded: url_helper
INFO - 2018-06-22 21:12:13 --> Helper loaded: form_helper
INFO - 2018-06-22 21:12:13 --> Helper loaded: date_helper
INFO - 2018-06-22 21:12:13 --> Helper loaded: util_helper
INFO - 2018-06-22 21:12:13 --> Helper loaded: text_helper
INFO - 2018-06-22 21:12:13 --> Helper loaded: string_helper
INFO - 2018-06-22 21:12:13 --> Database Driver Class Initialized
DEBUG - 2018-06-22 21:12:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 21:12:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 21:12:13 --> Email Class Initialized
INFO - 2018-06-22 21:12:13 --> Controller Class Initialized
DEBUG - 2018-06-22 21:12:13 --> Users MX_Controller Initialized
DEBUG - 2018-06-22 21:12:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-22 21:12:14 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-22 21:12:14 --> Login MX_Controller Initialized
INFO - 2018-06-22 21:12:14 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-22 21:12:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-22 21:12:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-22 21:12:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-22 21:12:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-22 21:12:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-22 21:12:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-22 21:12:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-06-22 21:12:14 --> Final output sent to browser
DEBUG - 2018-06-22 21:12:14 --> Total execution time: 0.6706
INFO - 2018-06-22 21:12:15 --> Config Class Initialized
INFO - 2018-06-22 21:12:15 --> Hooks Class Initialized
DEBUG - 2018-06-22 21:12:15 --> UTF-8 Support Enabled
INFO - 2018-06-22 21:12:15 --> Utf8 Class Initialized
INFO - 2018-06-22 21:12:15 --> URI Class Initialized
INFO - 2018-06-22 21:12:15 --> Router Class Initialized
INFO - 2018-06-22 21:12:15 --> Output Class Initialized
INFO - 2018-06-22 21:12:15 --> Security Class Initialized
DEBUG - 2018-06-22 21:12:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 21:12:15 --> Input Class Initialized
INFO - 2018-06-22 21:12:15 --> Language Class Initialized
INFO - 2018-06-22 21:12:15 --> Language Class Initialized
INFO - 2018-06-22 21:12:15 --> Config Class Initialized
INFO - 2018-06-22 21:12:15 --> Loader Class Initialized
DEBUG - 2018-06-22 21:12:15 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-22 21:12:15 --> Helper loaded: url_helper
INFO - 2018-06-22 21:12:15 --> Helper loaded: form_helper
INFO - 2018-06-22 21:12:15 --> Helper loaded: date_helper
INFO - 2018-06-22 21:12:15 --> Helper loaded: util_helper
INFO - 2018-06-22 21:12:15 --> Helper loaded: text_helper
INFO - 2018-06-22 21:12:15 --> Helper loaded: string_helper
INFO - 2018-06-22 21:12:15 --> Database Driver Class Initialized
DEBUG - 2018-06-22 21:12:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 21:12:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 21:12:15 --> Email Class Initialized
INFO - 2018-06-22 21:12:15 --> Controller Class Initialized
DEBUG - 2018-06-22 21:12:15 --> Users MX_Controller Initialized
DEBUG - 2018-06-22 21:12:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-22 21:12:15 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-22 21:12:16 --> Login MX_Controller Initialized
INFO - 2018-06-22 21:12:16 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-22 21:12:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-22 21:12:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-06-22 21:12:16 --> Final output sent to browser
DEBUG - 2018-06-22 21:12:16 --> Total execution time: 0.9960
INFO - 2018-06-22 21:12:26 --> Config Class Initialized
INFO - 2018-06-22 21:12:26 --> Hooks Class Initialized
DEBUG - 2018-06-22 21:12:26 --> UTF-8 Support Enabled
INFO - 2018-06-22 21:12:26 --> Utf8 Class Initialized
INFO - 2018-06-22 21:12:26 --> URI Class Initialized
INFO - 2018-06-22 21:12:27 --> Router Class Initialized
INFO - 2018-06-22 21:12:27 --> Output Class Initialized
INFO - 2018-06-22 21:12:27 --> Security Class Initialized
DEBUG - 2018-06-22 21:12:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 21:12:27 --> Input Class Initialized
INFO - 2018-06-22 21:12:27 --> Language Class Initialized
INFO - 2018-06-22 21:12:27 --> Language Class Initialized
INFO - 2018-06-22 21:12:27 --> Config Class Initialized
INFO - 2018-06-22 21:12:27 --> Loader Class Initialized
DEBUG - 2018-06-22 21:12:27 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-22 21:12:27 --> Helper loaded: url_helper
INFO - 2018-06-22 21:12:27 --> Helper loaded: form_helper
INFO - 2018-06-22 21:12:27 --> Helper loaded: date_helper
INFO - 2018-06-22 21:12:27 --> Helper loaded: util_helper
INFO - 2018-06-22 21:12:27 --> Helper loaded: text_helper
INFO - 2018-06-22 21:12:27 --> Helper loaded: string_helper
INFO - 2018-06-22 21:12:27 --> Database Driver Class Initialized
DEBUG - 2018-06-22 21:12:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 21:12:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 21:12:27 --> Email Class Initialized
INFO - 2018-06-22 21:12:27 --> Controller Class Initialized
DEBUG - 2018-06-22 21:12:27 --> Users MX_Controller Initialized
DEBUG - 2018-06-22 21:12:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-22 21:12:27 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-22 21:12:27 --> Login MX_Controller Initialized
INFO - 2018-06-22 21:12:27 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-22 21:12:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-22 21:12:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-22 21:12:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-22 21:12:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-22 21:12:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-22 21:12:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-22 21:12:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-06-22 21:12:27 --> Final output sent to browser
DEBUG - 2018-06-22 21:12:27 --> Total execution time: 0.5805
INFO - 2018-06-22 21:12:27 --> Config Class Initialized
INFO - 2018-06-22 21:12:27 --> Hooks Class Initialized
DEBUG - 2018-06-22 21:12:27 --> UTF-8 Support Enabled
INFO - 2018-06-22 21:12:27 --> Utf8 Class Initialized
INFO - 2018-06-22 21:12:28 --> URI Class Initialized
INFO - 2018-06-22 21:12:28 --> Router Class Initialized
INFO - 2018-06-22 21:12:28 --> Output Class Initialized
INFO - 2018-06-22 21:12:28 --> Security Class Initialized
DEBUG - 2018-06-22 21:12:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 21:12:28 --> Input Class Initialized
INFO - 2018-06-22 21:12:28 --> Language Class Initialized
INFO - 2018-06-22 21:12:28 --> Language Class Initialized
INFO - 2018-06-22 21:12:28 --> Config Class Initialized
INFO - 2018-06-22 21:12:28 --> Loader Class Initialized
DEBUG - 2018-06-22 21:12:28 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-22 21:12:28 --> Helper loaded: url_helper
INFO - 2018-06-22 21:12:28 --> Helper loaded: form_helper
INFO - 2018-06-22 21:12:28 --> Helper loaded: date_helper
INFO - 2018-06-22 21:12:28 --> Helper loaded: util_helper
INFO - 2018-06-22 21:12:28 --> Helper loaded: text_helper
INFO - 2018-06-22 21:12:28 --> Helper loaded: string_helper
INFO - 2018-06-22 21:12:28 --> Database Driver Class Initialized
DEBUG - 2018-06-22 21:12:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 21:12:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 21:12:28 --> Email Class Initialized
INFO - 2018-06-22 21:12:28 --> Controller Class Initialized
DEBUG - 2018-06-22 21:12:28 --> Users MX_Controller Initialized
DEBUG - 2018-06-22 21:12:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-22 21:12:28 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-22 21:12:28 --> Login MX_Controller Initialized
INFO - 2018-06-22 21:12:28 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-22 21:12:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-22 21:12:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-06-22 21:12:28 --> Final output sent to browser
DEBUG - 2018-06-22 21:12:28 --> Total execution time: 0.6035
INFO - 2018-06-22 21:17:53 --> Config Class Initialized
INFO - 2018-06-22 21:17:53 --> Hooks Class Initialized
DEBUG - 2018-06-22 21:17:53 --> UTF-8 Support Enabled
INFO - 2018-06-22 21:17:53 --> Utf8 Class Initialized
INFO - 2018-06-22 21:17:53 --> URI Class Initialized
INFO - 2018-06-22 21:17:53 --> Router Class Initialized
INFO - 2018-06-22 21:17:53 --> Output Class Initialized
INFO - 2018-06-22 21:17:53 --> Security Class Initialized
DEBUG - 2018-06-22 21:17:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 21:17:53 --> Input Class Initialized
INFO - 2018-06-22 21:17:53 --> Language Class Initialized
INFO - 2018-06-22 21:17:53 --> Language Class Initialized
INFO - 2018-06-22 21:17:53 --> Config Class Initialized
INFO - 2018-06-22 21:17:53 --> Loader Class Initialized
DEBUG - 2018-06-22 21:17:53 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-22 21:17:53 --> Helper loaded: url_helper
INFO - 2018-06-22 21:17:53 --> Helper loaded: form_helper
INFO - 2018-06-22 21:17:53 --> Helper loaded: date_helper
INFO - 2018-06-22 21:17:53 --> Helper loaded: util_helper
INFO - 2018-06-22 21:17:53 --> Helper loaded: text_helper
INFO - 2018-06-22 21:17:53 --> Helper loaded: string_helper
INFO - 2018-06-22 21:17:53 --> Database Driver Class Initialized
DEBUG - 2018-06-22 21:17:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 21:17:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 21:17:53 --> Email Class Initialized
INFO - 2018-06-22 21:17:54 --> Controller Class Initialized
DEBUG - 2018-06-22 21:17:54 --> Users MX_Controller Initialized
DEBUG - 2018-06-22 21:17:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-22 21:17:54 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-22 21:17:54 --> Login MX_Controller Initialized
INFO - 2018-06-22 21:17:54 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-22 21:17:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-22 21:17:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-06-22 21:17:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-22 21:17:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-22 21:17:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-22 21:17:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-22 21:17:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-22 21:17:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-06-22 21:17:54 --> Final output sent to browser
DEBUG - 2018-06-22 21:17:54 --> Total execution time: 0.5608
INFO - 2018-06-22 21:17:59 --> Config Class Initialized
INFO - 2018-06-22 21:17:59 --> Hooks Class Initialized
DEBUG - 2018-06-22 21:17:59 --> UTF-8 Support Enabled
INFO - 2018-06-22 21:17:59 --> Utf8 Class Initialized
INFO - 2018-06-22 21:17:59 --> URI Class Initialized
INFO - 2018-06-22 21:17:59 --> Router Class Initialized
INFO - 2018-06-22 21:17:59 --> Output Class Initialized
INFO - 2018-06-22 21:17:59 --> Security Class Initialized
DEBUG - 2018-06-22 21:17:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 21:17:59 --> Input Class Initialized
INFO - 2018-06-22 21:17:59 --> Language Class Initialized
INFO - 2018-06-22 21:17:59 --> Language Class Initialized
INFO - 2018-06-22 21:17:59 --> Config Class Initialized
INFO - 2018-06-22 21:17:59 --> Loader Class Initialized
DEBUG - 2018-06-22 21:17:59 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-22 21:17:59 --> Helper loaded: url_helper
INFO - 2018-06-22 21:17:59 --> Helper loaded: form_helper
INFO - 2018-06-22 21:17:59 --> Helper loaded: date_helper
INFO - 2018-06-22 21:17:59 --> Helper loaded: util_helper
INFO - 2018-06-22 21:17:59 --> Helper loaded: text_helper
INFO - 2018-06-22 21:17:59 --> Helper loaded: string_helper
INFO - 2018-06-22 21:17:59 --> Database Driver Class Initialized
DEBUG - 2018-06-22 21:17:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 21:17:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 21:17:59 --> Email Class Initialized
INFO - 2018-06-22 21:17:59 --> Controller Class Initialized
DEBUG - 2018-06-22 21:17:59 --> Users MX_Controller Initialized
DEBUG - 2018-06-22 21:17:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-22 21:17:59 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-22 21:17:59 --> Login MX_Controller Initialized
INFO - 2018-06-22 21:17:59 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-22 21:17:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-22 21:17:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-22 21:17:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-22 21:17:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-22 21:17:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-22 21:17:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-22 21:17:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-06-22 21:17:59 --> Final output sent to browser
DEBUG - 2018-06-22 21:17:59 --> Total execution time: 0.5254
INFO - 2018-06-22 21:18:00 --> Config Class Initialized
INFO - 2018-06-22 21:18:00 --> Hooks Class Initialized
DEBUG - 2018-06-22 21:18:00 --> UTF-8 Support Enabled
INFO - 2018-06-22 21:18:00 --> Utf8 Class Initialized
INFO - 2018-06-22 21:18:00 --> URI Class Initialized
INFO - 2018-06-22 21:18:00 --> Router Class Initialized
INFO - 2018-06-22 21:18:00 --> Output Class Initialized
INFO - 2018-06-22 21:18:00 --> Security Class Initialized
DEBUG - 2018-06-22 21:18:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 21:18:00 --> Input Class Initialized
INFO - 2018-06-22 21:18:00 --> Language Class Initialized
INFO - 2018-06-22 21:18:00 --> Language Class Initialized
INFO - 2018-06-22 21:18:00 --> Config Class Initialized
INFO - 2018-06-22 21:18:00 --> Loader Class Initialized
DEBUG - 2018-06-22 21:18:00 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-22 21:18:00 --> Helper loaded: url_helper
INFO - 2018-06-22 21:18:00 --> Helper loaded: form_helper
INFO - 2018-06-22 21:18:00 --> Helper loaded: date_helper
INFO - 2018-06-22 21:18:00 --> Helper loaded: util_helper
INFO - 2018-06-22 21:18:00 --> Helper loaded: text_helper
INFO - 2018-06-22 21:18:00 --> Helper loaded: string_helper
INFO - 2018-06-22 21:18:00 --> Database Driver Class Initialized
DEBUG - 2018-06-22 21:18:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 21:18:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 21:18:00 --> Email Class Initialized
INFO - 2018-06-22 21:18:00 --> Controller Class Initialized
DEBUG - 2018-06-22 21:18:00 --> Users MX_Controller Initialized
DEBUG - 2018-06-22 21:18:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-22 21:18:00 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-22 21:18:00 --> Login MX_Controller Initialized
INFO - 2018-06-22 21:18:00 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-22 21:18:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-22 21:18:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-06-22 21:18:00 --> Final output sent to browser
DEBUG - 2018-06-22 21:18:00 --> Total execution time: 0.5387
INFO - 2018-06-22 22:35:31 --> Config Class Initialized
INFO - 2018-06-22 22:35:31 --> Hooks Class Initialized
DEBUG - 2018-06-22 22:35:31 --> UTF-8 Support Enabled
INFO - 2018-06-22 22:35:31 --> Utf8 Class Initialized
INFO - 2018-06-22 22:35:31 --> URI Class Initialized
INFO - 2018-06-22 22:35:31 --> Router Class Initialized
INFO - 2018-06-22 22:35:31 --> Output Class Initialized
INFO - 2018-06-22 22:35:31 --> Security Class Initialized
DEBUG - 2018-06-22 22:35:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 22:35:31 --> Input Class Initialized
INFO - 2018-06-22 22:35:31 --> Language Class Initialized
INFO - 2018-06-22 22:35:31 --> Language Class Initialized
INFO - 2018-06-22 22:35:31 --> Config Class Initialized
INFO - 2018-06-22 22:35:31 --> Loader Class Initialized
DEBUG - 2018-06-22 22:35:31 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-22 22:35:31 --> Helper loaded: url_helper
INFO - 2018-06-22 22:35:31 --> Helper loaded: form_helper
INFO - 2018-06-22 22:35:31 --> Helper loaded: date_helper
INFO - 2018-06-22 22:35:31 --> Helper loaded: util_helper
INFO - 2018-06-22 22:35:31 --> Helper loaded: text_helper
INFO - 2018-06-22 22:35:31 --> Helper loaded: string_helper
INFO - 2018-06-22 22:35:31 --> Database Driver Class Initialized
DEBUG - 2018-06-22 22:35:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 22:35:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 22:35:31 --> Email Class Initialized
INFO - 2018-06-22 22:35:31 --> Controller Class Initialized
DEBUG - 2018-06-22 22:35:31 --> Home MX_Controller Initialized
DEBUG - 2018-06-22 22:35:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-22 22:35:31 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-22 22:35:31 --> Login MX_Controller Initialized
INFO - 2018-06-22 22:35:31 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-22 22:35:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-22 22:35:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-22 22:35:32 --> Config Class Initialized
INFO - 2018-06-22 22:35:32 --> Hooks Class Initialized
DEBUG - 2018-06-22 22:35:32 --> UTF-8 Support Enabled
INFO - 2018-06-22 22:35:32 --> Utf8 Class Initialized
INFO - 2018-06-22 22:35:32 --> URI Class Initialized
INFO - 2018-06-22 22:35:32 --> Router Class Initialized
INFO - 2018-06-22 22:35:32 --> Output Class Initialized
INFO - 2018-06-22 22:35:32 --> Security Class Initialized
DEBUG - 2018-06-22 22:35:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 22:35:32 --> Input Class Initialized
INFO - 2018-06-22 22:35:32 --> Language Class Initialized
INFO - 2018-06-22 22:35:32 --> Language Class Initialized
INFO - 2018-06-22 22:35:32 --> Config Class Initialized
INFO - 2018-06-22 22:35:32 --> Loader Class Initialized
DEBUG - 2018-06-22 22:35:32 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-22 22:35:32 --> Helper loaded: url_helper
INFO - 2018-06-22 22:35:32 --> Helper loaded: form_helper
INFO - 2018-06-22 22:35:32 --> Helper loaded: date_helper
INFO - 2018-06-22 22:35:32 --> Helper loaded: util_helper
INFO - 2018-06-22 22:35:32 --> Helper loaded: text_helper
INFO - 2018-06-22 22:35:32 --> Helper loaded: string_helper
INFO - 2018-06-22 22:35:32 --> Database Driver Class Initialized
DEBUG - 2018-06-22 22:35:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 22:35:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 22:35:32 --> Email Class Initialized
INFO - 2018-06-22 22:35:32 --> Controller Class Initialized
DEBUG - 2018-06-22 22:35:32 --> Home MX_Controller Initialized
DEBUG - 2018-06-22 22:35:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-22 22:35:32 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-22 22:35:32 --> Login MX_Controller Initialized
INFO - 2018-06-22 22:35:32 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-22 22:35:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-22 22:35:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-22 22:35:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-22 22:35:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-22 22:35:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-22 22:35:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-22 22:35:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-22 22:35:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-06-22 22:35:32 --> Final output sent to browser
DEBUG - 2018-06-22 22:35:32 --> Total execution time: 0.5421
INFO - 2018-06-22 22:35:33 --> Config Class Initialized
INFO - 2018-06-22 22:35:33 --> Hooks Class Initialized
DEBUG - 2018-06-22 22:35:33 --> UTF-8 Support Enabled
INFO - 2018-06-22 22:35:33 --> Utf8 Class Initialized
INFO - 2018-06-22 22:35:33 --> URI Class Initialized
INFO - 2018-06-22 22:35:33 --> Router Class Initialized
INFO - 2018-06-22 22:35:33 --> Output Class Initialized
INFO - 2018-06-22 22:35:33 --> Security Class Initialized
DEBUG - 2018-06-22 22:35:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 22:35:33 --> Input Class Initialized
INFO - 2018-06-22 22:35:33 --> Language Class Initialized
ERROR - 2018-06-22 22:35:33 --> 404 Page Not Found: /index
INFO - 2018-06-22 22:35:33 --> Config Class Initialized
INFO - 2018-06-22 22:35:33 --> Hooks Class Initialized
DEBUG - 2018-06-22 22:35:33 --> UTF-8 Support Enabled
INFO - 2018-06-22 22:35:33 --> Utf8 Class Initialized
INFO - 2018-06-22 22:35:33 --> URI Class Initialized
INFO - 2018-06-22 22:35:34 --> Router Class Initialized
INFO - 2018-06-22 22:35:34 --> Output Class Initialized
INFO - 2018-06-22 22:35:34 --> Security Class Initialized
DEBUG - 2018-06-22 22:35:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 22:35:34 --> Input Class Initialized
INFO - 2018-06-22 22:35:34 --> Language Class Initialized
ERROR - 2018-06-22 22:35:34 --> 404 Page Not Found: /index
INFO - 2018-06-22 22:35:34 --> Config Class Initialized
INFO - 2018-06-22 22:35:34 --> Hooks Class Initialized
DEBUG - 2018-06-22 22:35:34 --> UTF-8 Support Enabled
INFO - 2018-06-22 22:35:34 --> Utf8 Class Initialized
INFO - 2018-06-22 22:35:34 --> URI Class Initialized
INFO - 2018-06-22 22:35:34 --> Router Class Initialized
INFO - 2018-06-22 22:35:34 --> Output Class Initialized
INFO - 2018-06-22 22:35:34 --> Security Class Initialized
DEBUG - 2018-06-22 22:35:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 22:35:34 --> Input Class Initialized
INFO - 2018-06-22 22:35:34 --> Language Class Initialized
ERROR - 2018-06-22 22:35:34 --> 404 Page Not Found: /index
INFO - 2018-06-22 22:35:39 --> Config Class Initialized
INFO - 2018-06-22 22:35:39 --> Hooks Class Initialized
DEBUG - 2018-06-22 22:35:39 --> UTF-8 Support Enabled
INFO - 2018-06-22 22:35:39 --> Utf8 Class Initialized
INFO - 2018-06-22 22:35:39 --> URI Class Initialized
INFO - 2018-06-22 22:35:39 --> Router Class Initialized
INFO - 2018-06-22 22:35:39 --> Output Class Initialized
INFO - 2018-06-22 22:35:39 --> Security Class Initialized
DEBUG - 2018-06-22 22:35:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 22:35:39 --> Input Class Initialized
INFO - 2018-06-22 22:35:39 --> Language Class Initialized
INFO - 2018-06-22 22:35:39 --> Language Class Initialized
INFO - 2018-06-22 22:35:39 --> Config Class Initialized
INFO - 2018-06-22 22:35:39 --> Loader Class Initialized
DEBUG - 2018-06-22 22:35:39 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-22 22:35:39 --> Helper loaded: url_helper
INFO - 2018-06-22 22:35:39 --> Helper loaded: form_helper
INFO - 2018-06-22 22:35:39 --> Helper loaded: date_helper
INFO - 2018-06-22 22:35:39 --> Helper loaded: util_helper
INFO - 2018-06-22 22:35:39 --> Helper loaded: text_helper
INFO - 2018-06-22 22:35:39 --> Helper loaded: string_helper
INFO - 2018-06-22 22:35:39 --> Database Driver Class Initialized
DEBUG - 2018-06-22 22:35:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 22:35:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 22:35:39 --> Email Class Initialized
INFO - 2018-06-22 22:35:39 --> Controller Class Initialized
DEBUG - 2018-06-22 22:35:39 --> Home MX_Controller Initialized
DEBUG - 2018-06-22 22:35:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-22 22:35:39 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-22 22:35:39 --> Login MX_Controller Initialized
INFO - 2018-06-22 22:35:39 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-22 22:35:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-22 22:35:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-22 22:35:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-22 22:35:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-22 22:35:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-22 22:35:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-22 22:35:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-22 22:35:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-06-22 22:35:40 --> Final output sent to browser
DEBUG - 2018-06-22 22:35:40 --> Total execution time: 0.6133
INFO - 2018-06-22 22:35:40 --> Config Class Initialized
INFO - 2018-06-22 22:35:40 --> Config Class Initialized
INFO - 2018-06-22 22:35:40 --> Hooks Class Initialized
INFO - 2018-06-22 22:35:40 --> Hooks Class Initialized
DEBUG - 2018-06-22 22:35:40 --> UTF-8 Support Enabled
DEBUG - 2018-06-22 22:35:40 --> UTF-8 Support Enabled
INFO - 2018-06-22 22:35:40 --> Utf8 Class Initialized
INFO - 2018-06-22 22:35:40 --> Utf8 Class Initialized
INFO - 2018-06-22 22:35:40 --> URI Class Initialized
INFO - 2018-06-22 22:35:40 --> URI Class Initialized
INFO - 2018-06-22 22:35:40 --> Router Class Initialized
INFO - 2018-06-22 22:35:40 --> Router Class Initialized
INFO - 2018-06-22 22:35:40 --> Output Class Initialized
INFO - 2018-06-22 22:35:40 --> Security Class Initialized
DEBUG - 2018-06-22 22:35:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 22:35:40 --> Output Class Initialized
INFO - 2018-06-22 22:35:40 --> Input Class Initialized
INFO - 2018-06-22 22:35:40 --> Security Class Initialized
INFO - 2018-06-22 22:35:40 --> Language Class Initialized
DEBUG - 2018-06-22 22:35:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-06-22 22:35:40 --> 404 Page Not Found: /index
INFO - 2018-06-22 22:35:40 --> Input Class Initialized
INFO - 2018-06-22 22:35:40 --> Language Class Initialized
INFO - 2018-06-22 22:35:40 --> Config Class Initialized
INFO - 2018-06-22 22:35:40 --> Hooks Class Initialized
ERROR - 2018-06-22 22:35:40 --> 404 Page Not Found: /index
DEBUG - 2018-06-22 22:35:40 --> UTF-8 Support Enabled
INFO - 2018-06-22 22:35:40 --> Utf8 Class Initialized
INFO - 2018-06-22 22:35:40 --> URI Class Initialized
INFO - 2018-06-22 22:35:40 --> Router Class Initialized
INFO - 2018-06-22 22:35:40 --> Output Class Initialized
INFO - 2018-06-22 22:35:40 --> Security Class Initialized
DEBUG - 2018-06-22 22:35:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 22:35:41 --> Input Class Initialized
INFO - 2018-06-22 22:35:41 --> Language Class Initialized
ERROR - 2018-06-22 22:35:41 --> 404 Page Not Found: /index
INFO - 2018-06-22 22:35:41 --> Config Class Initialized
INFO - 2018-06-22 22:35:41 --> Hooks Class Initialized
DEBUG - 2018-06-22 22:35:41 --> UTF-8 Support Enabled
INFO - 2018-06-22 22:35:41 --> Utf8 Class Initialized
INFO - 2018-06-22 22:35:41 --> URI Class Initialized
INFO - 2018-06-22 22:35:41 --> Router Class Initialized
INFO - 2018-06-22 22:35:41 --> Output Class Initialized
INFO - 2018-06-22 22:35:41 --> Security Class Initialized
DEBUG - 2018-06-22 22:35:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 22:35:41 --> Input Class Initialized
INFO - 2018-06-22 22:35:41 --> Language Class Initialized
ERROR - 2018-06-22 22:35:41 --> 404 Page Not Found: /index
INFO - 2018-06-22 22:35:43 --> Config Class Initialized
INFO - 2018-06-22 22:35:43 --> Hooks Class Initialized
DEBUG - 2018-06-22 22:35:43 --> UTF-8 Support Enabled
INFO - 2018-06-22 22:35:43 --> Utf8 Class Initialized
INFO - 2018-06-22 22:35:43 --> URI Class Initialized
INFO - 2018-06-22 22:35:43 --> Router Class Initialized
INFO - 2018-06-22 22:35:43 --> Output Class Initialized
INFO - 2018-06-22 22:35:43 --> Security Class Initialized
DEBUG - 2018-06-22 22:35:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 22:35:43 --> Input Class Initialized
INFO - 2018-06-22 22:35:43 --> Language Class Initialized
INFO - 2018-06-22 22:35:43 --> Language Class Initialized
INFO - 2018-06-22 22:35:43 --> Config Class Initialized
INFO - 2018-06-22 22:35:43 --> Loader Class Initialized
DEBUG - 2018-06-22 22:35:43 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-22 22:35:43 --> Helper loaded: url_helper
INFO - 2018-06-22 22:35:43 --> Helper loaded: form_helper
INFO - 2018-06-22 22:35:43 --> Helper loaded: date_helper
INFO - 2018-06-22 22:35:43 --> Helper loaded: util_helper
INFO - 2018-06-22 22:35:43 --> Helper loaded: text_helper
INFO - 2018-06-22 22:35:43 --> Helper loaded: string_helper
INFO - 2018-06-22 22:35:43 --> Database Driver Class Initialized
DEBUG - 2018-06-22 22:35:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 22:35:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 22:35:43 --> Email Class Initialized
INFO - 2018-06-22 22:35:43 --> Controller Class Initialized
DEBUG - 2018-06-22 22:35:43 --> Home MX_Controller Initialized
DEBUG - 2018-06-22 22:35:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-22 22:35:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-06-22 22:35:43 --> Final output sent to browser
DEBUG - 2018-06-22 22:35:43 --> Total execution time: 0.4498
INFO - 2018-06-22 22:35:43 --> Config Class Initialized
INFO - 2018-06-22 22:35:43 --> Hooks Class Initialized
DEBUG - 2018-06-22 22:35:43 --> UTF-8 Support Enabled
INFO - 2018-06-22 22:35:43 --> Utf8 Class Initialized
INFO - 2018-06-22 22:35:43 --> URI Class Initialized
INFO - 2018-06-22 22:35:43 --> Router Class Initialized
INFO - 2018-06-22 22:35:43 --> Output Class Initialized
INFO - 2018-06-22 22:35:43 --> Security Class Initialized
DEBUG - 2018-06-22 22:35:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 22:35:43 --> Input Class Initialized
INFO - 2018-06-22 22:35:43 --> Language Class Initialized
INFO - 2018-06-22 22:35:43 --> Language Class Initialized
INFO - 2018-06-22 22:35:43 --> Config Class Initialized
INFO - 2018-06-22 22:35:43 --> Loader Class Initialized
DEBUG - 2018-06-22 22:35:43 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-22 22:35:43 --> Helper loaded: url_helper
INFO - 2018-06-22 22:35:43 --> Helper loaded: form_helper
INFO - 2018-06-22 22:35:44 --> Helper loaded: date_helper
INFO - 2018-06-22 22:35:44 --> Helper loaded: util_helper
INFO - 2018-06-22 22:35:44 --> Helper loaded: text_helper
INFO - 2018-06-22 22:35:44 --> Helper loaded: string_helper
INFO - 2018-06-22 22:35:44 --> Database Driver Class Initialized
DEBUG - 2018-06-22 22:35:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 22:35:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 22:35:44 --> Email Class Initialized
INFO - 2018-06-22 22:35:44 --> Controller Class Initialized
DEBUG - 2018-06-22 22:35:44 --> Home MX_Controller Initialized
DEBUG - 2018-06-22 22:35:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-06-22 22:35:49 --> Config Class Initialized
INFO - 2018-06-22 22:35:49 --> Hooks Class Initialized
DEBUG - 2018-06-22 22:35:49 --> UTF-8 Support Enabled
INFO - 2018-06-22 22:35:49 --> Utf8 Class Initialized
INFO - 2018-06-22 22:35:49 --> URI Class Initialized
INFO - 2018-06-22 22:35:49 --> Router Class Initialized
INFO - 2018-06-22 22:35:49 --> Output Class Initialized
INFO - 2018-06-22 22:35:49 --> Security Class Initialized
DEBUG - 2018-06-22 22:35:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 22:35:49 --> Input Class Initialized
INFO - 2018-06-22 22:35:49 --> Language Class Initialized
INFO - 2018-06-22 22:35:49 --> Language Class Initialized
INFO - 2018-06-22 22:35:49 --> Config Class Initialized
INFO - 2018-06-22 22:35:49 --> Loader Class Initialized
DEBUG - 2018-06-22 22:35:49 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-22 22:35:49 --> Helper loaded: url_helper
INFO - 2018-06-22 22:35:49 --> Helper loaded: form_helper
INFO - 2018-06-22 22:35:49 --> Helper loaded: date_helper
INFO - 2018-06-22 22:35:49 --> Helper loaded: util_helper
INFO - 2018-06-22 22:35:49 --> Helper loaded: text_helper
INFO - 2018-06-22 22:35:50 --> Helper loaded: string_helper
INFO - 2018-06-22 22:35:50 --> Database Driver Class Initialized
DEBUG - 2018-06-22 22:35:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 22:35:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 22:35:50 --> Email Class Initialized
INFO - 2018-06-22 22:35:50 --> Controller Class Initialized
DEBUG - 2018-06-22 22:35:50 --> Home MX_Controller Initialized
DEBUG - 2018-06-22 22:35:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-22 22:35:50 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-22 22:35:50 --> Login MX_Controller Initialized
INFO - 2018-06-22 22:35:50 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-22 22:35:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-22 22:35:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-22 22:35:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-22 22:35:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-22 22:35:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-22 22:35:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-22 22:35:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-22 22:35:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-06-22 22:35:50 --> Final output sent to browser
DEBUG - 2018-06-22 22:35:50 --> Total execution time: 0.5785
INFO - 2018-06-22 22:35:50 --> Config Class Initialized
INFO - 2018-06-22 22:35:50 --> Config Class Initialized
INFO - 2018-06-22 22:35:50 --> Hooks Class Initialized
INFO - 2018-06-22 22:35:50 --> Hooks Class Initialized
DEBUG - 2018-06-22 22:35:50 --> UTF-8 Support Enabled
DEBUG - 2018-06-22 22:35:50 --> UTF-8 Support Enabled
INFO - 2018-06-22 22:35:50 --> Utf8 Class Initialized
INFO - 2018-06-22 22:35:50 --> Utf8 Class Initialized
INFO - 2018-06-22 22:35:50 --> URI Class Initialized
INFO - 2018-06-22 22:35:50 --> URI Class Initialized
INFO - 2018-06-22 22:35:50 --> Router Class Initialized
INFO - 2018-06-22 22:35:50 --> Router Class Initialized
INFO - 2018-06-22 22:35:50 --> Output Class Initialized
INFO - 2018-06-22 22:35:50 --> Output Class Initialized
INFO - 2018-06-22 22:35:50 --> Security Class Initialized
DEBUG - 2018-06-22 22:35:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 22:35:50 --> Security Class Initialized
INFO - 2018-06-22 22:35:50 --> Input Class Initialized
DEBUG - 2018-06-22 22:35:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 22:35:50 --> Language Class Initialized
INFO - 2018-06-22 22:35:50 --> Input Class Initialized
ERROR - 2018-06-22 22:35:51 --> 404 Page Not Found: /index
INFO - 2018-06-22 22:35:51 --> Language Class Initialized
ERROR - 2018-06-22 22:35:51 --> 404 Page Not Found: /index
INFO - 2018-06-22 22:35:51 --> Config Class Initialized
INFO - 2018-06-22 22:35:51 --> Hooks Class Initialized
DEBUG - 2018-06-22 22:35:51 --> UTF-8 Support Enabled
INFO - 2018-06-22 22:35:51 --> Utf8 Class Initialized
INFO - 2018-06-22 22:35:51 --> URI Class Initialized
INFO - 2018-06-22 22:35:51 --> Router Class Initialized
INFO - 2018-06-22 22:35:51 --> Output Class Initialized
INFO - 2018-06-22 22:35:51 --> Security Class Initialized
DEBUG - 2018-06-22 22:35:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 22:35:51 --> Input Class Initialized
INFO - 2018-06-22 22:35:51 --> Language Class Initialized
ERROR - 2018-06-22 22:35:51 --> 404 Page Not Found: /index
INFO - 2018-06-22 22:35:51 --> Config Class Initialized
INFO - 2018-06-22 22:35:51 --> Hooks Class Initialized
DEBUG - 2018-06-22 22:35:51 --> UTF-8 Support Enabled
INFO - 2018-06-22 22:35:51 --> Utf8 Class Initialized
INFO - 2018-06-22 22:35:51 --> URI Class Initialized
INFO - 2018-06-22 22:35:51 --> Router Class Initialized
INFO - 2018-06-22 22:35:51 --> Output Class Initialized
INFO - 2018-06-22 22:35:51 --> Security Class Initialized
DEBUG - 2018-06-22 22:35:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 22:35:51 --> Input Class Initialized
INFO - 2018-06-22 22:35:51 --> Language Class Initialized
ERROR - 2018-06-22 22:35:51 --> 404 Page Not Found: /index
INFO - 2018-06-22 22:36:04 --> Config Class Initialized
INFO - 2018-06-22 22:36:04 --> Hooks Class Initialized
DEBUG - 2018-06-22 22:36:04 --> UTF-8 Support Enabled
INFO - 2018-06-22 22:36:04 --> Utf8 Class Initialized
INFO - 2018-06-22 22:36:04 --> URI Class Initialized
INFO - 2018-06-22 22:36:04 --> Router Class Initialized
INFO - 2018-06-22 22:36:04 --> Output Class Initialized
INFO - 2018-06-22 22:36:04 --> Security Class Initialized
DEBUG - 2018-06-22 22:36:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 22:36:04 --> Input Class Initialized
INFO - 2018-06-22 22:36:04 --> Language Class Initialized
INFO - 2018-06-22 22:36:04 --> Language Class Initialized
INFO - 2018-06-22 22:36:04 --> Config Class Initialized
INFO - 2018-06-22 22:36:04 --> Loader Class Initialized
DEBUG - 2018-06-22 22:36:04 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-22 22:36:04 --> Helper loaded: url_helper
INFO - 2018-06-22 22:36:04 --> Helper loaded: form_helper
INFO - 2018-06-22 22:36:04 --> Helper loaded: date_helper
INFO - 2018-06-22 22:36:05 --> Helper loaded: util_helper
INFO - 2018-06-22 22:36:05 --> Helper loaded: text_helper
INFO - 2018-06-22 22:36:05 --> Helper loaded: string_helper
INFO - 2018-06-22 22:36:05 --> Database Driver Class Initialized
DEBUG - 2018-06-22 22:36:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 22:36:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 22:36:05 --> Email Class Initialized
INFO - 2018-06-22 22:36:05 --> Controller Class Initialized
DEBUG - 2018-06-22 22:36:05 --> Home MX_Controller Initialized
DEBUG - 2018-06-22 22:36:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-22 22:36:05 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-22 22:36:05 --> Login MX_Controller Initialized
INFO - 2018-06-22 22:36:05 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-22 22:36:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-22 22:36:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-22 22:36:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-22 22:36:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-22 22:36:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-22 22:36:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-22 22:36:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-22 22:36:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-06-22 22:36:05 --> Final output sent to browser
DEBUG - 2018-06-22 22:36:05 --> Total execution time: 0.5571
INFO - 2018-06-22 22:36:05 --> Config Class Initialized
INFO - 2018-06-22 22:36:05 --> Config Class Initialized
INFO - 2018-06-22 22:36:05 --> Hooks Class Initialized
INFO - 2018-06-22 22:36:05 --> Hooks Class Initialized
DEBUG - 2018-06-22 22:36:05 --> UTF-8 Support Enabled
DEBUG - 2018-06-22 22:36:05 --> UTF-8 Support Enabled
INFO - 2018-06-22 22:36:05 --> Utf8 Class Initialized
INFO - 2018-06-22 22:36:05 --> URI Class Initialized
INFO - 2018-06-22 22:36:05 --> Router Class Initialized
INFO - 2018-06-22 22:36:06 --> Utf8 Class Initialized
INFO - 2018-06-22 22:36:06 --> Output Class Initialized
INFO - 2018-06-22 22:36:06 --> URI Class Initialized
INFO - 2018-06-22 22:36:06 --> Security Class Initialized
DEBUG - 2018-06-22 22:36:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 22:36:06 --> Router Class Initialized
INFO - 2018-06-22 22:36:06 --> Input Class Initialized
INFO - 2018-06-22 22:36:06 --> Output Class Initialized
INFO - 2018-06-22 22:36:06 --> Security Class Initialized
INFO - 2018-06-22 22:36:06 --> Language Class Initialized
DEBUG - 2018-06-22 22:36:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-06-22 22:36:06 --> 404 Page Not Found: /index
INFO - 2018-06-22 22:36:06 --> Input Class Initialized
INFO - 2018-06-22 22:36:06 --> Config Class Initialized
INFO - 2018-06-22 22:36:06 --> Hooks Class Initialized
INFO - 2018-06-22 22:36:06 --> Language Class Initialized
ERROR - 2018-06-22 22:36:06 --> 404 Page Not Found: /index
DEBUG - 2018-06-22 22:36:06 --> UTF-8 Support Enabled
INFO - 2018-06-22 22:36:06 --> Utf8 Class Initialized
INFO - 2018-06-22 22:36:06 --> URI Class Initialized
INFO - 2018-06-22 22:36:06 --> Router Class Initialized
INFO - 2018-06-22 22:36:06 --> Output Class Initialized
INFO - 2018-06-22 22:36:06 --> Security Class Initialized
DEBUG - 2018-06-22 22:36:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 22:36:06 --> Input Class Initialized
INFO - 2018-06-22 22:36:06 --> Language Class Initialized
ERROR - 2018-06-22 22:36:06 --> 404 Page Not Found: /index
INFO - 2018-06-22 22:36:06 --> Config Class Initialized
INFO - 2018-06-22 22:36:06 --> Hooks Class Initialized
DEBUG - 2018-06-22 22:36:06 --> UTF-8 Support Enabled
INFO - 2018-06-22 22:36:06 --> Utf8 Class Initialized
INFO - 2018-06-22 22:36:06 --> URI Class Initialized
INFO - 2018-06-22 22:36:06 --> Router Class Initialized
INFO - 2018-06-22 22:36:06 --> Output Class Initialized
INFO - 2018-06-22 22:36:06 --> Security Class Initialized
DEBUG - 2018-06-22 22:36:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 22:36:06 --> Input Class Initialized
INFO - 2018-06-22 22:36:06 --> Language Class Initialized
ERROR - 2018-06-22 22:36:06 --> 404 Page Not Found: /index
INFO - 2018-06-22 23:16:27 --> Config Class Initialized
INFO - 2018-06-22 23:16:27 --> Hooks Class Initialized
DEBUG - 2018-06-22 23:16:27 --> UTF-8 Support Enabled
INFO - 2018-06-22 23:16:27 --> Utf8 Class Initialized
INFO - 2018-06-22 23:16:27 --> URI Class Initialized
INFO - 2018-06-22 23:16:27 --> Router Class Initialized
INFO - 2018-06-22 23:16:27 --> Output Class Initialized
INFO - 2018-06-22 23:16:27 --> Security Class Initialized
DEBUG - 2018-06-22 23:16:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 23:16:27 --> Input Class Initialized
INFO - 2018-06-22 23:16:27 --> Language Class Initialized
INFO - 2018-06-22 23:16:27 --> Language Class Initialized
INFO - 2018-06-22 23:16:27 --> Config Class Initialized
INFO - 2018-06-22 23:16:27 --> Loader Class Initialized
DEBUG - 2018-06-22 23:16:27 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-22 23:16:27 --> Helper loaded: url_helper
INFO - 2018-06-22 23:16:27 --> Helper loaded: form_helper
INFO - 2018-06-22 23:16:27 --> Helper loaded: date_helper
INFO - 2018-06-22 23:16:27 --> Helper loaded: util_helper
INFO - 2018-06-22 23:16:27 --> Helper loaded: text_helper
INFO - 2018-06-22 23:16:27 --> Helper loaded: string_helper
INFO - 2018-06-22 23:16:27 --> Database Driver Class Initialized
DEBUG - 2018-06-22 23:16:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 23:16:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 23:16:27 --> Email Class Initialized
INFO - 2018-06-22 23:16:27 --> Controller Class Initialized
DEBUG - 2018-06-22 23:16:27 --> Home MX_Controller Initialized
DEBUG - 2018-06-22 23:16:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-22 23:16:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-06-22 23:16:27 --> Final output sent to browser
DEBUG - 2018-06-22 23:16:27 --> Total execution time: 0.4478
INFO - 2018-06-22 23:16:27 --> Config Class Initialized
INFO - 2018-06-22 23:16:27 --> Hooks Class Initialized
DEBUG - 2018-06-22 23:16:27 --> UTF-8 Support Enabled
INFO - 2018-06-22 23:16:27 --> Utf8 Class Initialized
INFO - 2018-06-22 23:16:27 --> URI Class Initialized
INFO - 2018-06-22 23:16:27 --> Router Class Initialized
INFO - 2018-06-22 23:16:27 --> Output Class Initialized
INFO - 2018-06-22 23:16:27 --> Security Class Initialized
DEBUG - 2018-06-22 23:16:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 23:16:27 --> Input Class Initialized
INFO - 2018-06-22 23:16:27 --> Language Class Initialized
INFO - 2018-06-22 23:16:27 --> Language Class Initialized
INFO - 2018-06-22 23:16:27 --> Config Class Initialized
INFO - 2018-06-22 23:16:27 --> Loader Class Initialized
DEBUG - 2018-06-22 23:16:27 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-22 23:16:27 --> Helper loaded: url_helper
INFO - 2018-06-22 23:16:27 --> Helper loaded: form_helper
INFO - 2018-06-22 23:16:27 --> Helper loaded: date_helper
INFO - 2018-06-22 23:16:27 --> Helper loaded: util_helper
INFO - 2018-06-22 23:16:27 --> Helper loaded: text_helper
INFO - 2018-06-22 23:16:27 --> Helper loaded: string_helper
INFO - 2018-06-22 23:16:27 --> Database Driver Class Initialized
DEBUG - 2018-06-22 23:16:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 23:16:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 23:16:27 --> Email Class Initialized
INFO - 2018-06-22 23:16:27 --> Controller Class Initialized
DEBUG - 2018-06-22 23:16:27 --> Home MX_Controller Initialized
DEBUG - 2018-06-22 23:16:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-06-22 23:46:05 --> Config Class Initialized
INFO - 2018-06-22 23:46:05 --> Hooks Class Initialized
DEBUG - 2018-06-22 23:46:05 --> UTF-8 Support Enabled
INFO - 2018-06-22 23:46:05 --> Utf8 Class Initialized
INFO - 2018-06-22 23:46:05 --> URI Class Initialized
INFO - 2018-06-22 23:46:05 --> Router Class Initialized
INFO - 2018-06-22 23:46:05 --> Output Class Initialized
INFO - 2018-06-22 23:46:05 --> Security Class Initialized
DEBUG - 2018-06-22 23:46:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 23:46:05 --> Input Class Initialized
INFO - 2018-06-22 23:46:05 --> Language Class Initialized
INFO - 2018-06-22 23:46:05 --> Language Class Initialized
INFO - 2018-06-22 23:46:05 --> Config Class Initialized
INFO - 2018-06-22 23:46:05 --> Loader Class Initialized
DEBUG - 2018-06-22 23:46:05 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-22 23:46:05 --> Helper loaded: url_helper
INFO - 2018-06-22 23:46:05 --> Helper loaded: form_helper
INFO - 2018-06-22 23:46:05 --> Helper loaded: date_helper
INFO - 2018-06-22 23:46:05 --> Helper loaded: util_helper
INFO - 2018-06-22 23:46:05 --> Helper loaded: text_helper
INFO - 2018-06-22 23:46:05 --> Helper loaded: string_helper
INFO - 2018-06-22 23:46:05 --> Database Driver Class Initialized
DEBUG - 2018-06-22 23:46:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 23:46:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 23:46:05 --> Email Class Initialized
INFO - 2018-06-22 23:46:06 --> Controller Class Initialized
DEBUG - 2018-06-22 23:46:06 --> Home MX_Controller Initialized
DEBUG - 2018-06-22 23:46:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-22 23:46:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-06-22 23:46:06 --> Config Class Initialized
INFO - 2018-06-22 23:46:06 --> Hooks Class Initialized
INFO - 2018-06-22 23:46:06 --> Final output sent to browser
DEBUG - 2018-06-22 23:46:06 --> Total execution time: 0.4639
DEBUG - 2018-06-22 23:46:06 --> UTF-8 Support Enabled
INFO - 2018-06-22 23:46:06 --> Utf8 Class Initialized
INFO - 2018-06-22 23:46:06 --> Config Class Initialized
INFO - 2018-06-22 23:46:06 --> Hooks Class Initialized
INFO - 2018-06-22 23:46:06 --> URI Class Initialized
DEBUG - 2018-06-22 23:46:06 --> UTF-8 Support Enabled
INFO - 2018-06-22 23:46:06 --> Router Class Initialized
INFO - 2018-06-22 23:46:06 --> Utf8 Class Initialized
INFO - 2018-06-22 23:46:06 --> Output Class Initialized
INFO - 2018-06-22 23:46:06 --> URI Class Initialized
INFO - 2018-06-22 23:46:06 --> Security Class Initialized
INFO - 2018-06-22 23:46:06 --> Router Class Initialized
DEBUG - 2018-06-22 23:46:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 23:46:06 --> Input Class Initialized
INFO - 2018-06-22 23:46:06 --> Output Class Initialized
INFO - 2018-06-22 23:46:06 --> Language Class Initialized
INFO - 2018-06-22 23:46:06 --> Security Class Initialized
DEBUG - 2018-06-22 23:46:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 23:46:06 --> Language Class Initialized
INFO - 2018-06-22 23:46:06 --> Input Class Initialized
INFO - 2018-06-22 23:46:06 --> Config Class Initialized
INFO - 2018-06-22 23:46:06 --> Language Class Initialized
INFO - 2018-06-22 23:46:06 --> Loader Class Initialized
DEBUG - 2018-06-22 23:46:06 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-22 23:46:06 --> Language Class Initialized
INFO - 2018-06-22 23:46:06 --> Config Class Initialized
INFO - 2018-06-22 23:46:06 --> Helper loaded: url_helper
INFO - 2018-06-22 23:46:06 --> Helper loaded: form_helper
INFO - 2018-06-22 23:46:06 --> Loader Class Initialized
DEBUG - 2018-06-22 23:46:06 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-22 23:46:06 --> Helper loaded: date_helper
INFO - 2018-06-22 23:46:06 --> Helper loaded: util_helper
INFO - 2018-06-22 23:46:06 --> Helper loaded: url_helper
INFO - 2018-06-22 23:46:06 --> Helper loaded: form_helper
INFO - 2018-06-22 23:46:06 --> Helper loaded: text_helper
INFO - 2018-06-22 23:46:06 --> Helper loaded: date_helper
INFO - 2018-06-22 23:46:06 --> Helper loaded: string_helper
INFO - 2018-06-22 23:46:06 --> Helper loaded: util_helper
INFO - 2018-06-22 23:46:06 --> Database Driver Class Initialized
INFO - 2018-06-22 23:46:06 --> Helper loaded: text_helper
DEBUG - 2018-06-22 23:46:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 23:46:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 23:46:06 --> Helper loaded: string_helper
INFO - 2018-06-22 23:46:06 --> Email Class Initialized
INFO - 2018-06-22 23:46:06 --> Database Driver Class Initialized
INFO - 2018-06-22 23:46:06 --> Controller Class Initialized
DEBUG - 2018-06-22 23:46:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-06-22 23:46:06 --> Home MX_Controller Initialized
DEBUG - 2018-06-22 23:46:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-22 23:46:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-06-22 23:46:06 --> Final output sent to browser
DEBUG - 2018-06-22 23:46:06 --> Total execution time: 0.4598
INFO - 2018-06-22 23:46:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 23:46:06 --> Config Class Initialized
INFO - 2018-06-22 23:46:06 --> Hooks Class Initialized
INFO - 2018-06-22 23:46:06 --> Email Class Initialized
INFO - 2018-06-22 23:46:06 --> Controller Class Initialized
DEBUG - 2018-06-22 23:46:06 --> UTF-8 Support Enabled
INFO - 2018-06-22 23:46:06 --> Utf8 Class Initialized
DEBUG - 2018-06-22 23:46:06 --> Home MX_Controller Initialized
INFO - 2018-06-22 23:46:06 --> URI Class Initialized
DEBUG - 2018-06-22 23:46:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-06-22 23:46:06 --> Router Class Initialized
INFO - 2018-06-22 23:46:06 --> Output Class Initialized
INFO - 2018-06-22 23:46:06 --> Security Class Initialized
DEBUG - 2018-06-22 23:46:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 23:46:06 --> Input Class Initialized
INFO - 2018-06-22 23:46:06 --> Language Class Initialized
INFO - 2018-06-22 23:46:06 --> Language Class Initialized
INFO - 2018-06-22 23:46:06 --> Config Class Initialized
INFO - 2018-06-22 23:46:06 --> Loader Class Initialized
DEBUG - 2018-06-22 23:46:06 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-22 23:46:06 --> Helper loaded: url_helper
INFO - 2018-06-22 23:46:06 --> Helper loaded: form_helper
INFO - 2018-06-22 23:46:06 --> Helper loaded: date_helper
INFO - 2018-06-22 23:46:06 --> Helper loaded: util_helper
INFO - 2018-06-22 23:46:06 --> Helper loaded: text_helper
INFO - 2018-06-22 23:46:06 --> Helper loaded: string_helper
INFO - 2018-06-22 23:46:06 --> Database Driver Class Initialized
DEBUG - 2018-06-22 23:46:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 23:46:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 23:46:06 --> Email Class Initialized
INFO - 2018-06-22 23:46:06 --> Controller Class Initialized
DEBUG - 2018-06-22 23:46:06 --> Home MX_Controller Initialized
DEBUG - 2018-06-22 23:46:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-06-22 23:47:20 --> Config Class Initialized
INFO - 2018-06-22 23:47:20 --> Hooks Class Initialized
DEBUG - 2018-06-22 23:47:20 --> UTF-8 Support Enabled
INFO - 2018-06-22 23:47:20 --> Utf8 Class Initialized
INFO - 2018-06-22 23:47:20 --> URI Class Initialized
INFO - 2018-06-22 23:47:20 --> Router Class Initialized
INFO - 2018-06-22 23:47:20 --> Output Class Initialized
INFO - 2018-06-22 23:47:20 --> Security Class Initialized
DEBUG - 2018-06-22 23:47:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 23:47:20 --> Input Class Initialized
INFO - 2018-06-22 23:47:20 --> Language Class Initialized
INFO - 2018-06-22 23:47:20 --> Language Class Initialized
INFO - 2018-06-22 23:47:20 --> Config Class Initialized
INFO - 2018-06-22 23:47:20 --> Loader Class Initialized
DEBUG - 2018-06-22 23:47:20 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-22 23:47:20 --> Helper loaded: url_helper
INFO - 2018-06-22 23:47:20 --> Helper loaded: form_helper
INFO - 2018-06-22 23:47:20 --> Helper loaded: date_helper
INFO - 2018-06-22 23:47:20 --> Helper loaded: util_helper
INFO - 2018-06-22 23:47:20 --> Helper loaded: text_helper
INFO - 2018-06-22 23:47:20 --> Helper loaded: string_helper
INFO - 2018-06-22 23:47:20 --> Database Driver Class Initialized
DEBUG - 2018-06-22 23:47:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 23:47:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 23:47:20 --> Email Class Initialized
INFO - 2018-06-22 23:47:20 --> Controller Class Initialized
DEBUG - 2018-06-22 23:47:20 --> Home MX_Controller Initialized
DEBUG - 2018-06-22 23:47:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-22 23:47:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-06-22 23:47:20 --> Config Class Initialized
INFO - 2018-06-22 23:47:20 --> Final output sent to browser
DEBUG - 2018-06-22 23:47:20 --> Total execution time: 0.4515
INFO - 2018-06-22 23:47:20 --> Hooks Class Initialized
DEBUG - 2018-06-22 23:47:20 --> UTF-8 Support Enabled
INFO - 2018-06-22 23:47:20 --> Config Class Initialized
INFO - 2018-06-22 23:47:20 --> Hooks Class Initialized
INFO - 2018-06-22 23:47:20 --> Utf8 Class Initialized
DEBUG - 2018-06-22 23:47:20 --> UTF-8 Support Enabled
INFO - 2018-06-22 23:47:20 --> URI Class Initialized
INFO - 2018-06-22 23:47:20 --> Utf8 Class Initialized
INFO - 2018-06-22 23:47:20 --> URI Class Initialized
INFO - 2018-06-22 23:47:20 --> Router Class Initialized
INFO - 2018-06-22 23:47:20 --> Router Class Initialized
INFO - 2018-06-22 23:47:20 --> Output Class Initialized
INFO - 2018-06-22 23:47:20 --> Security Class Initialized
DEBUG - 2018-06-22 23:47:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 23:47:20 --> Input Class Initialized
INFO - 2018-06-22 23:47:20 --> Language Class Initialized
INFO - 2018-06-22 23:47:20 --> Language Class Initialized
INFO - 2018-06-22 23:47:20 --> Output Class Initialized
INFO - 2018-06-22 23:47:20 --> Config Class Initialized
INFO - 2018-06-22 23:47:20 --> Loader Class Initialized
INFO - 2018-06-22 23:47:20 --> Security Class Initialized
DEBUG - 2018-06-22 23:47:20 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-22 23:47:20 --> Helper loaded: url_helper
INFO - 2018-06-22 23:47:20 --> Helper loaded: form_helper
INFO - 2018-06-22 23:47:20 --> Helper loaded: date_helper
INFO - 2018-06-22 23:47:20 --> Helper loaded: util_helper
INFO - 2018-06-22 23:47:20 --> Helper loaded: text_helper
INFO - 2018-06-22 23:47:20 --> Helper loaded: string_helper
DEBUG - 2018-06-22 23:47:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 23:47:20 --> Database Driver Class Initialized
INFO - 2018-06-22 23:47:20 --> Input Class Initialized
DEBUG - 2018-06-22 23:47:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 23:47:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 23:47:20 --> Language Class Initialized
INFO - 2018-06-22 23:47:20 --> Email Class Initialized
INFO - 2018-06-22 23:47:20 --> Language Class Initialized
INFO - 2018-06-22 23:47:20 --> Controller Class Initialized
DEBUG - 2018-06-22 23:47:20 --> Home MX_Controller Initialized
DEBUG - 2018-06-22 23:47:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-06-22 23:47:20 --> Config Class Initialized
INFO - 2018-06-22 23:47:20 --> Loader Class Initialized
DEBUG - 2018-06-22 23:47:20 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-22 23:47:20 --> Helper loaded: url_helper
INFO - 2018-06-22 23:47:20 --> Helper loaded: form_helper
INFO - 2018-06-22 23:47:21 --> Helper loaded: date_helper
INFO - 2018-06-22 23:47:21 --> Helper loaded: util_helper
INFO - 2018-06-22 23:47:21 --> Helper loaded: text_helper
INFO - 2018-06-22 23:47:21 --> Helper loaded: string_helper
INFO - 2018-06-22 23:47:21 --> Database Driver Class Initialized
DEBUG - 2018-06-22 23:47:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 23:47:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 23:47:21 --> Email Class Initialized
INFO - 2018-06-22 23:47:21 --> Controller Class Initialized
DEBUG - 2018-06-22 23:47:21 --> Home MX_Controller Initialized
DEBUG - 2018-06-22 23:47:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-22 23:47:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-06-22 23:47:21 --> Final output sent to browser
DEBUG - 2018-06-22 23:47:21 --> Total execution time: 0.7206
INFO - 2018-06-22 23:47:21 --> Config Class Initialized
INFO - 2018-06-22 23:47:21 --> Hooks Class Initialized
DEBUG - 2018-06-22 23:47:21 --> UTF-8 Support Enabled
INFO - 2018-06-22 23:47:21 --> Utf8 Class Initialized
INFO - 2018-06-22 23:47:21 --> URI Class Initialized
INFO - 2018-06-22 23:47:21 --> Router Class Initialized
INFO - 2018-06-22 23:47:21 --> Output Class Initialized
INFO - 2018-06-22 23:47:21 --> Security Class Initialized
DEBUG - 2018-06-22 23:47:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-22 23:47:21 --> Input Class Initialized
INFO - 2018-06-22 23:47:21 --> Language Class Initialized
INFO - 2018-06-22 23:47:21 --> Language Class Initialized
INFO - 2018-06-22 23:47:21 --> Config Class Initialized
INFO - 2018-06-22 23:47:21 --> Loader Class Initialized
DEBUG - 2018-06-22 23:47:21 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-22 23:47:21 --> Helper loaded: url_helper
INFO - 2018-06-22 23:47:21 --> Helper loaded: form_helper
INFO - 2018-06-22 23:47:21 --> Helper loaded: date_helper
INFO - 2018-06-22 23:47:21 --> Helper loaded: util_helper
INFO - 2018-06-22 23:47:21 --> Helper loaded: text_helper
INFO - 2018-06-22 23:47:21 --> Helper loaded: string_helper
INFO - 2018-06-22 23:47:21 --> Database Driver Class Initialized
DEBUG - 2018-06-22 23:47:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-22 23:47:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-22 23:47:21 --> Email Class Initialized
INFO - 2018-06-22 23:47:21 --> Controller Class Initialized
DEBUG - 2018-06-22 23:47:21 --> Home MX_Controller Initialized
DEBUG - 2018-06-22 23:47:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
