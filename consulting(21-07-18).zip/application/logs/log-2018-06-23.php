<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-06-23 00:29:08 --> Config Class Initialized
INFO - 2018-06-23 00:29:08 --> Hooks Class Initialized
DEBUG - 2018-06-23 00:29:08 --> UTF-8 Support Enabled
INFO - 2018-06-23 00:29:08 --> Utf8 Class Initialized
INFO - 2018-06-23 00:29:08 --> URI Class Initialized
INFO - 2018-06-23 00:29:08 --> Router Class Initialized
INFO - 2018-06-23 00:29:08 --> Output Class Initialized
INFO - 2018-06-23 00:29:08 --> Security Class Initialized
DEBUG - 2018-06-23 00:29:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 00:29:08 --> Input Class Initialized
INFO - 2018-06-23 00:29:08 --> Language Class Initialized
INFO - 2018-06-23 00:29:08 --> Language Class Initialized
INFO - 2018-06-23 00:29:08 --> Config Class Initialized
INFO - 2018-06-23 00:29:08 --> Loader Class Initialized
DEBUG - 2018-06-23 00:29:08 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-23 00:29:08 --> Helper loaded: url_helper
INFO - 2018-06-23 00:29:08 --> Helper loaded: form_helper
INFO - 2018-06-23 00:29:08 --> Helper loaded: date_helper
INFO - 2018-06-23 00:29:08 --> Helper loaded: util_helper
INFO - 2018-06-23 00:29:08 --> Helper loaded: text_helper
INFO - 2018-06-23 00:29:08 --> Helper loaded: string_helper
INFO - 2018-06-23 00:29:08 --> Database Driver Class Initialized
DEBUG - 2018-06-23 00:29:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-23 00:29:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-23 00:29:08 --> Email Class Initialized
INFO - 2018-06-23 00:29:08 --> Controller Class Initialized
DEBUG - 2018-06-23 00:29:08 --> Profile MX_Controller Initialized
DEBUG - 2018-06-23 00:29:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-23 00:29:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-23 00:29:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-23 00:29:08 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-23 00:29:08 --> Login MX_Controller Initialized
INFO - 2018-06-23 00:29:08 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-23 00:29:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-23 00:29:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-23 00:29:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-23 00:29:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-23 00:29:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-06-23 00:29:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-23 00:29:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-23 00:29:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/profile.php
INFO - 2018-06-23 00:29:08 --> Final output sent to browser
DEBUG - 2018-06-23 00:29:08 --> Total execution time: 0.3484
INFO - 2018-06-23 00:29:09 --> Config Class Initialized
INFO - 2018-06-23 00:29:09 --> Hooks Class Initialized
DEBUG - 2018-06-23 00:29:09 --> UTF-8 Support Enabled
INFO - 2018-06-23 00:29:09 --> Utf8 Class Initialized
INFO - 2018-06-23 00:29:09 --> URI Class Initialized
INFO - 2018-06-23 00:29:09 --> Router Class Initialized
INFO - 2018-06-23 00:29:09 --> Output Class Initialized
INFO - 2018-06-23 00:29:10 --> Security Class Initialized
DEBUG - 2018-06-23 00:29:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 00:29:10 --> Input Class Initialized
INFO - 2018-06-23 00:29:10 --> Language Class Initialized
ERROR - 2018-06-23 00:29:10 --> 404 Page Not Found: /index
INFO - 2018-06-23 00:29:10 --> Config Class Initialized
INFO - 2018-06-23 00:29:10 --> Hooks Class Initialized
DEBUG - 2018-06-23 00:29:10 --> UTF-8 Support Enabled
INFO - 2018-06-23 00:29:10 --> Utf8 Class Initialized
INFO - 2018-06-23 00:29:10 --> URI Class Initialized
INFO - 2018-06-23 00:29:10 --> Router Class Initialized
INFO - 2018-06-23 00:29:10 --> Output Class Initialized
INFO - 2018-06-23 00:29:10 --> Security Class Initialized
DEBUG - 2018-06-23 00:29:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 00:29:10 --> Input Class Initialized
INFO - 2018-06-23 00:29:10 --> Language Class Initialized
ERROR - 2018-06-23 00:29:10 --> 404 Page Not Found: /index
INFO - 2018-06-23 00:29:10 --> Config Class Initialized
INFO - 2018-06-23 00:29:10 --> Hooks Class Initialized
DEBUG - 2018-06-23 00:29:10 --> UTF-8 Support Enabled
INFO - 2018-06-23 00:29:10 --> Utf8 Class Initialized
INFO - 2018-06-23 00:29:10 --> URI Class Initialized
INFO - 2018-06-23 00:29:10 --> Router Class Initialized
INFO - 2018-06-23 00:29:10 --> Output Class Initialized
INFO - 2018-06-23 00:29:10 --> Security Class Initialized
DEBUG - 2018-06-23 00:29:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 00:29:10 --> Input Class Initialized
INFO - 2018-06-23 00:29:10 --> Language Class Initialized
ERROR - 2018-06-23 00:29:10 --> 404 Page Not Found: /index
INFO - 2018-06-23 00:29:16 --> Config Class Initialized
INFO - 2018-06-23 00:29:16 --> Hooks Class Initialized
DEBUG - 2018-06-23 00:29:17 --> UTF-8 Support Enabled
INFO - 2018-06-23 00:29:17 --> Utf8 Class Initialized
INFO - 2018-06-23 00:29:17 --> URI Class Initialized
INFO - 2018-06-23 00:29:17 --> Router Class Initialized
INFO - 2018-06-23 00:29:17 --> Output Class Initialized
INFO - 2018-06-23 00:29:17 --> Security Class Initialized
DEBUG - 2018-06-23 00:29:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 00:29:17 --> Input Class Initialized
INFO - 2018-06-23 00:29:17 --> Language Class Initialized
INFO - 2018-06-23 00:29:17 --> Language Class Initialized
INFO - 2018-06-23 00:29:17 --> Config Class Initialized
INFO - 2018-06-23 00:29:17 --> Loader Class Initialized
DEBUG - 2018-06-23 00:29:17 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-23 00:29:17 --> Helper loaded: url_helper
INFO - 2018-06-23 00:29:17 --> Helper loaded: form_helper
INFO - 2018-06-23 00:29:17 --> Helper loaded: date_helper
INFO - 2018-06-23 00:29:17 --> Helper loaded: util_helper
INFO - 2018-06-23 00:29:17 --> Helper loaded: text_helper
INFO - 2018-06-23 00:29:17 --> Helper loaded: string_helper
INFO - 2018-06-23 00:29:17 --> Database Driver Class Initialized
DEBUG - 2018-06-23 00:29:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-23 00:29:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-23 00:29:17 --> Email Class Initialized
INFO - 2018-06-23 00:29:17 --> Controller Class Initialized
DEBUG - 2018-06-23 00:29:17 --> Home MX_Controller Initialized
DEBUG - 2018-06-23 00:29:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-23 00:29:17 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-23 00:29:17 --> Login MX_Controller Initialized
INFO - 2018-06-23 00:29:17 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-23 00:29:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-23 00:29:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-23 00:29:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-23 00:29:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-23 00:29:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-23 00:29:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-23 00:29:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-23 00:29:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-06-23 00:29:17 --> Final output sent to browser
DEBUG - 2018-06-23 00:29:17 --> Total execution time: 0.3435
INFO - 2018-06-23 00:29:17 --> Config Class Initialized
INFO - 2018-06-23 00:29:17 --> Hooks Class Initialized
DEBUG - 2018-06-23 00:29:17 --> UTF-8 Support Enabled
INFO - 2018-06-23 00:29:17 --> Utf8 Class Initialized
INFO - 2018-06-23 00:29:17 --> URI Class Initialized
INFO - 2018-06-23 00:29:17 --> Router Class Initialized
INFO - 2018-06-23 00:29:17 --> Output Class Initialized
INFO - 2018-06-23 00:29:17 --> Security Class Initialized
DEBUG - 2018-06-23 00:29:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 00:29:17 --> Input Class Initialized
INFO - 2018-06-23 00:29:17 --> Language Class Initialized
ERROR - 2018-06-23 00:29:17 --> 404 Page Not Found: /index
INFO - 2018-06-23 00:29:17 --> Config Class Initialized
INFO - 2018-06-23 00:29:17 --> Hooks Class Initialized
DEBUG - 2018-06-23 00:29:17 --> UTF-8 Support Enabled
INFO - 2018-06-23 00:29:17 --> Utf8 Class Initialized
INFO - 2018-06-23 00:29:17 --> URI Class Initialized
INFO - 2018-06-23 00:29:17 --> Router Class Initialized
INFO - 2018-06-23 00:29:17 --> Output Class Initialized
INFO - 2018-06-23 00:29:17 --> Security Class Initialized
DEBUG - 2018-06-23 00:29:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 00:29:17 --> Input Class Initialized
INFO - 2018-06-23 00:29:17 --> Language Class Initialized
ERROR - 2018-06-23 00:29:17 --> 404 Page Not Found: /index
INFO - 2018-06-23 00:29:18 --> Config Class Initialized
INFO - 2018-06-23 00:29:18 --> Hooks Class Initialized
DEBUG - 2018-06-23 00:29:18 --> UTF-8 Support Enabled
INFO - 2018-06-23 00:29:18 --> Utf8 Class Initialized
INFO - 2018-06-23 00:29:18 --> URI Class Initialized
INFO - 2018-06-23 00:29:18 --> Router Class Initialized
INFO - 2018-06-23 00:29:18 --> Output Class Initialized
INFO - 2018-06-23 00:29:18 --> Security Class Initialized
DEBUG - 2018-06-23 00:29:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 00:29:18 --> Input Class Initialized
INFO - 2018-06-23 00:29:18 --> Language Class Initialized
ERROR - 2018-06-23 00:29:18 --> 404 Page Not Found: /index
INFO - 2018-06-23 00:29:20 --> Config Class Initialized
INFO - 2018-06-23 00:29:20 --> Hooks Class Initialized
DEBUG - 2018-06-23 00:29:20 --> UTF-8 Support Enabled
INFO - 2018-06-23 00:29:20 --> Utf8 Class Initialized
INFO - 2018-06-23 00:29:20 --> URI Class Initialized
INFO - 2018-06-23 00:29:20 --> Router Class Initialized
INFO - 2018-06-23 00:29:20 --> Output Class Initialized
INFO - 2018-06-23 00:29:20 --> Security Class Initialized
DEBUG - 2018-06-23 00:29:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 00:29:20 --> Input Class Initialized
INFO - 2018-06-23 00:29:20 --> Language Class Initialized
INFO - 2018-06-23 00:29:20 --> Language Class Initialized
INFO - 2018-06-23 00:29:20 --> Config Class Initialized
INFO - 2018-06-23 00:29:20 --> Loader Class Initialized
DEBUG - 2018-06-23 00:29:20 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-23 00:29:20 --> Helper loaded: url_helper
INFO - 2018-06-23 00:29:20 --> Helper loaded: form_helper
INFO - 2018-06-23 00:29:20 --> Helper loaded: date_helper
INFO - 2018-06-23 00:29:20 --> Helper loaded: util_helper
INFO - 2018-06-23 00:29:20 --> Helper loaded: text_helper
INFO - 2018-06-23 00:29:20 --> Helper loaded: string_helper
INFO - 2018-06-23 00:29:20 --> Database Driver Class Initialized
DEBUG - 2018-06-23 00:29:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-23 00:29:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-23 00:29:20 --> Email Class Initialized
INFO - 2018-06-23 00:29:20 --> Controller Class Initialized
DEBUG - 2018-06-23 00:29:20 --> Home MX_Controller Initialized
DEBUG - 2018-06-23 00:29:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-23 00:29:20 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-23 00:29:20 --> Login MX_Controller Initialized
INFO - 2018-06-23 00:29:20 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-23 00:29:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-23 00:29:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-23 00:29:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-23 00:29:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-23 00:29:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-23 00:29:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-23 00:29:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-23 00:29:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-06-23 00:29:20 --> Final output sent to browser
DEBUG - 2018-06-23 00:29:20 --> Total execution time: 0.3422
INFO - 2018-06-23 00:29:20 --> Config Class Initialized
INFO - 2018-06-23 00:29:20 --> Hooks Class Initialized
DEBUG - 2018-06-23 00:29:20 --> UTF-8 Support Enabled
INFO - 2018-06-23 00:29:20 --> Utf8 Class Initialized
INFO - 2018-06-23 00:29:20 --> URI Class Initialized
INFO - 2018-06-23 00:29:20 --> Router Class Initialized
INFO - 2018-06-23 00:29:20 --> Output Class Initialized
INFO - 2018-06-23 00:29:21 --> Security Class Initialized
DEBUG - 2018-06-23 00:29:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 00:29:21 --> Input Class Initialized
INFO - 2018-06-23 00:29:21 --> Language Class Initialized
ERROR - 2018-06-23 00:29:21 --> 404 Page Not Found: /index
INFO - 2018-06-23 00:29:21 --> Config Class Initialized
INFO - 2018-06-23 00:29:21 --> Hooks Class Initialized
DEBUG - 2018-06-23 00:29:21 --> UTF-8 Support Enabled
INFO - 2018-06-23 00:29:21 --> Utf8 Class Initialized
INFO - 2018-06-23 00:29:21 --> URI Class Initialized
INFO - 2018-06-23 00:29:21 --> Router Class Initialized
INFO - 2018-06-23 00:29:21 --> Output Class Initialized
INFO - 2018-06-23 00:29:21 --> Security Class Initialized
DEBUG - 2018-06-23 00:29:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 00:29:21 --> Input Class Initialized
INFO - 2018-06-23 00:29:21 --> Language Class Initialized
ERROR - 2018-06-23 00:29:21 --> 404 Page Not Found: /index
INFO - 2018-06-23 00:29:21 --> Config Class Initialized
INFO - 2018-06-23 00:29:21 --> Hooks Class Initialized
DEBUG - 2018-06-23 00:29:21 --> UTF-8 Support Enabled
INFO - 2018-06-23 00:29:21 --> Utf8 Class Initialized
INFO - 2018-06-23 00:29:21 --> URI Class Initialized
INFO - 2018-06-23 00:29:21 --> Router Class Initialized
INFO - 2018-06-23 00:29:21 --> Output Class Initialized
INFO - 2018-06-23 00:29:21 --> Security Class Initialized
DEBUG - 2018-06-23 00:29:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 00:29:21 --> Input Class Initialized
INFO - 2018-06-23 00:29:21 --> Language Class Initialized
ERROR - 2018-06-23 00:29:21 --> 404 Page Not Found: /index
INFO - 2018-06-23 00:52:17 --> Config Class Initialized
INFO - 2018-06-23 00:52:17 --> Hooks Class Initialized
DEBUG - 2018-06-23 00:52:17 --> UTF-8 Support Enabled
INFO - 2018-06-23 00:52:17 --> Utf8 Class Initialized
INFO - 2018-06-23 00:52:17 --> URI Class Initialized
INFO - 2018-06-23 00:52:17 --> Router Class Initialized
INFO - 2018-06-23 00:52:17 --> Output Class Initialized
INFO - 2018-06-23 00:52:17 --> Security Class Initialized
DEBUG - 2018-06-23 00:52:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 00:52:17 --> Input Class Initialized
INFO - 2018-06-23 00:52:17 --> Language Class Initialized
INFO - 2018-06-23 00:52:17 --> Language Class Initialized
INFO - 2018-06-23 00:52:17 --> Config Class Initialized
INFO - 2018-06-23 00:52:17 --> Loader Class Initialized
DEBUG - 2018-06-23 00:52:17 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-23 00:52:17 --> Helper loaded: url_helper
INFO - 2018-06-23 00:52:17 --> Helper loaded: form_helper
INFO - 2018-06-23 00:52:17 --> Helper loaded: date_helper
INFO - 2018-06-23 00:52:17 --> Helper loaded: util_helper
INFO - 2018-06-23 00:52:17 --> Helper loaded: text_helper
INFO - 2018-06-23 00:52:17 --> Helper loaded: string_helper
INFO - 2018-06-23 00:52:17 --> Database Driver Class Initialized
DEBUG - 2018-06-23 00:52:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-23 00:52:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-23 00:52:17 --> Email Class Initialized
INFO - 2018-06-23 00:52:17 --> Controller Class Initialized
DEBUG - 2018-06-23 00:52:17 --> Home MX_Controller Initialized
DEBUG - 2018-06-23 00:52:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-23 00:52:17 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-23 00:52:17 --> Login MX_Controller Initialized
INFO - 2018-06-23 00:52:17 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-23 00:52:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-23 00:52:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-23 00:52:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-23 00:52:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-23 00:52:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-23 00:52:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-23 00:52:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-23 00:52:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-06-23 00:52:17 --> Final output sent to browser
DEBUG - 2018-06-23 00:52:17 --> Total execution time: 0.4437
INFO - 2018-06-23 00:52:45 --> Config Class Initialized
INFO - 2018-06-23 00:52:45 --> Hooks Class Initialized
DEBUG - 2018-06-23 00:52:45 --> UTF-8 Support Enabled
INFO - 2018-06-23 00:52:45 --> Utf8 Class Initialized
INFO - 2018-06-23 00:52:45 --> URI Class Initialized
INFO - 2018-06-23 00:52:45 --> Router Class Initialized
INFO - 2018-06-23 00:52:45 --> Output Class Initialized
INFO - 2018-06-23 00:52:45 --> Security Class Initialized
DEBUG - 2018-06-23 00:52:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 00:52:45 --> Input Class Initialized
INFO - 2018-06-23 00:52:45 --> Language Class Initialized
INFO - 2018-06-23 00:52:45 --> Language Class Initialized
INFO - 2018-06-23 00:52:45 --> Config Class Initialized
INFO - 2018-06-23 00:52:45 --> Loader Class Initialized
DEBUG - 2018-06-23 00:52:45 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-23 00:52:45 --> Helper loaded: url_helper
INFO - 2018-06-23 00:52:45 --> Helper loaded: form_helper
INFO - 2018-06-23 00:52:45 --> Helper loaded: date_helper
INFO - 2018-06-23 00:52:45 --> Helper loaded: util_helper
INFO - 2018-06-23 00:52:45 --> Helper loaded: text_helper
INFO - 2018-06-23 00:52:45 --> Helper loaded: string_helper
INFO - 2018-06-23 00:52:45 --> Database Driver Class Initialized
DEBUG - 2018-06-23 00:52:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-23 00:52:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-23 00:52:45 --> Email Class Initialized
INFO - 2018-06-23 00:52:45 --> Controller Class Initialized
DEBUG - 2018-06-23 00:52:45 --> Home MX_Controller Initialized
DEBUG - 2018-06-23 00:52:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-23 00:52:45 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-23 00:52:45 --> Login MX_Controller Initialized
INFO - 2018-06-23 00:52:45 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-23 00:52:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-23 00:52:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-23 00:52:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-23 00:52:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-23 00:52:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-23 00:52:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-23 00:52:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-23 00:52:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-06-23 00:52:45 --> Final output sent to browser
DEBUG - 2018-06-23 00:52:45 --> Total execution time: 0.5176
INFO - 2018-06-23 00:52:47 --> Config Class Initialized
INFO - 2018-06-23 00:52:48 --> Hooks Class Initialized
DEBUG - 2018-06-23 00:52:48 --> UTF-8 Support Enabled
INFO - 2018-06-23 00:52:48 --> Utf8 Class Initialized
INFO - 2018-06-23 00:52:48 --> URI Class Initialized
INFO - 2018-06-23 00:52:48 --> Router Class Initialized
INFO - 2018-06-23 00:52:48 --> Output Class Initialized
INFO - 2018-06-23 00:52:48 --> Security Class Initialized
DEBUG - 2018-06-23 00:52:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 00:52:48 --> Input Class Initialized
INFO - 2018-06-23 00:52:48 --> Language Class Initialized
INFO - 2018-06-23 00:52:48 --> Language Class Initialized
INFO - 2018-06-23 00:52:48 --> Config Class Initialized
INFO - 2018-06-23 00:52:48 --> Loader Class Initialized
DEBUG - 2018-06-23 00:52:48 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-23 00:52:48 --> Helper loaded: url_helper
INFO - 2018-06-23 00:52:48 --> Helper loaded: form_helper
INFO - 2018-06-23 00:52:48 --> Helper loaded: date_helper
INFO - 2018-06-23 00:52:48 --> Helper loaded: util_helper
INFO - 2018-06-23 00:52:48 --> Helper loaded: text_helper
INFO - 2018-06-23 00:52:48 --> Helper loaded: string_helper
INFO - 2018-06-23 00:52:48 --> Database Driver Class Initialized
DEBUG - 2018-06-23 00:52:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-23 00:52:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-23 00:52:48 --> Email Class Initialized
INFO - 2018-06-23 00:52:48 --> Controller Class Initialized
DEBUG - 2018-06-23 00:52:48 --> Profile MX_Controller Initialized
INFO - 2018-06-23 00:52:48 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-23 00:52:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-23 00:52:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Profile_model.php
DEBUG - 2018-06-23 00:52:48 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-23 00:52:48 --> Login MX_Controller Initialized
DEBUG - 2018-06-23 00:52:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-23 00:52:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-23 00:52:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-23 00:52:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-23 00:52:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-23 00:52:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-23 00:52:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/profile.php
INFO - 2018-06-23 00:52:48 --> Final output sent to browser
DEBUG - 2018-06-23 00:52:48 --> Total execution time: 0.3999
INFO - 2018-06-23 00:52:50 --> Config Class Initialized
INFO - 2018-06-23 00:52:50 --> Hooks Class Initialized
DEBUG - 2018-06-23 00:52:50 --> UTF-8 Support Enabled
INFO - 2018-06-23 00:52:50 --> Utf8 Class Initialized
INFO - 2018-06-23 00:52:50 --> URI Class Initialized
INFO - 2018-06-23 00:52:50 --> Router Class Initialized
INFO - 2018-06-23 00:52:50 --> Output Class Initialized
INFO - 2018-06-23 00:52:50 --> Security Class Initialized
DEBUG - 2018-06-23 00:52:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 00:52:50 --> Input Class Initialized
INFO - 2018-06-23 00:52:50 --> Language Class Initialized
INFO - 2018-06-23 00:52:50 --> Language Class Initialized
INFO - 2018-06-23 00:52:50 --> Config Class Initialized
INFO - 2018-06-23 00:52:50 --> Loader Class Initialized
DEBUG - 2018-06-23 00:52:50 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-23 00:52:50 --> Helper loaded: url_helper
INFO - 2018-06-23 00:52:50 --> Helper loaded: form_helper
INFO - 2018-06-23 00:52:50 --> Helper loaded: date_helper
INFO - 2018-06-23 00:52:50 --> Helper loaded: util_helper
INFO - 2018-06-23 00:52:50 --> Helper loaded: text_helper
INFO - 2018-06-23 00:52:50 --> Helper loaded: string_helper
INFO - 2018-06-23 00:52:50 --> Database Driver Class Initialized
DEBUG - 2018-06-23 00:52:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-23 00:52:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-23 00:52:50 --> Email Class Initialized
INFO - 2018-06-23 00:52:50 --> Controller Class Initialized
DEBUG - 2018-06-23 00:52:50 --> Profile MX_Controller Initialized
INFO - 2018-06-23 00:52:50 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-23 00:52:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-23 00:52:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Profile_model.php
DEBUG - 2018-06-23 00:52:50 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-23 00:52:50 --> Login MX_Controller Initialized
DEBUG - 2018-06-23 00:52:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-23 00:52:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-23 00:52:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-23 00:52:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-23 00:52:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-23 00:52:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-23 00:52:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/admin_password.php
INFO - 2018-06-23 00:52:50 --> Final output sent to browser
DEBUG - 2018-06-23 00:52:51 --> Total execution time: 0.3865
INFO - 2018-06-23 00:52:52 --> Config Class Initialized
INFO - 2018-06-23 00:52:52 --> Hooks Class Initialized
DEBUG - 2018-06-23 00:52:52 --> UTF-8 Support Enabled
INFO - 2018-06-23 00:52:52 --> Utf8 Class Initialized
INFO - 2018-06-23 00:52:52 --> URI Class Initialized
INFO - 2018-06-23 00:52:52 --> Router Class Initialized
INFO - 2018-06-23 00:52:52 --> Output Class Initialized
INFO - 2018-06-23 00:52:52 --> Security Class Initialized
DEBUG - 2018-06-23 00:52:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 00:52:52 --> Input Class Initialized
INFO - 2018-06-23 00:52:52 --> Language Class Initialized
INFO - 2018-06-23 00:52:52 --> Language Class Initialized
INFO - 2018-06-23 00:52:52 --> Config Class Initialized
INFO - 2018-06-23 00:52:52 --> Loader Class Initialized
DEBUG - 2018-06-23 00:52:52 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-23 00:52:52 --> Helper loaded: url_helper
INFO - 2018-06-23 00:52:52 --> Helper loaded: form_helper
INFO - 2018-06-23 00:52:52 --> Helper loaded: date_helper
INFO - 2018-06-23 00:52:52 --> Helper loaded: util_helper
INFO - 2018-06-23 00:52:52 --> Helper loaded: text_helper
INFO - 2018-06-23 00:52:52 --> Helper loaded: string_helper
INFO - 2018-06-23 00:52:52 --> Database Driver Class Initialized
DEBUG - 2018-06-23 00:52:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-23 00:52:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-23 00:52:52 --> Email Class Initialized
INFO - 2018-06-23 00:52:52 --> Controller Class Initialized
DEBUG - 2018-06-23 00:52:52 --> Admin MX_Controller Initialized
INFO - 2018-06-23 00:52:52 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-23 00:52:52 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-23 00:52:52 --> Login MX_Controller Initialized
DEBUG - 2018-06-23 00:52:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-23 00:52:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-23 00:52:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-23 00:52:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-23 00:52:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-23 00:52:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-23 00:52:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-23 00:52:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/dashboard.php
INFO - 2018-06-23 00:52:52 --> Final output sent to browser
DEBUG - 2018-06-23 00:52:52 --> Total execution time: 0.3968
INFO - 2018-06-23 00:52:52 --> Config Class Initialized
INFO - 2018-06-23 00:52:52 --> Hooks Class Initialized
INFO - 2018-06-23 00:52:52 --> Config Class Initialized
INFO - 2018-06-23 00:52:52 --> Hooks Class Initialized
DEBUG - 2018-06-23 00:52:52 --> UTF-8 Support Enabled
INFO - 2018-06-23 00:52:52 --> Utf8 Class Initialized
DEBUG - 2018-06-23 00:52:52 --> UTF-8 Support Enabled
INFO - 2018-06-23 00:52:52 --> Utf8 Class Initialized
INFO - 2018-06-23 00:52:52 --> URI Class Initialized
INFO - 2018-06-23 00:52:52 --> URI Class Initialized
INFO - 2018-06-23 00:52:52 --> Router Class Initialized
INFO - 2018-06-23 00:52:52 --> Output Class Initialized
INFO - 2018-06-23 00:52:52 --> Router Class Initialized
INFO - 2018-06-23 00:52:52 --> Output Class Initialized
INFO - 2018-06-23 00:52:52 --> Security Class Initialized
INFO - 2018-06-23 00:52:52 --> Security Class Initialized
DEBUG - 2018-06-23 00:52:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 00:52:52 --> Input Class Initialized
DEBUG - 2018-06-23 00:52:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 00:52:52 --> Input Class Initialized
INFO - 2018-06-23 00:52:52 --> Language Class Initialized
INFO - 2018-06-23 00:52:52 --> Language Class Initialized
ERROR - 2018-06-23 00:52:52 --> 404 Page Not Found: /index
ERROR - 2018-06-23 00:52:52 --> 404 Page Not Found: /index
INFO - 2018-06-23 00:52:53 --> Config Class Initialized
INFO - 2018-06-23 00:52:53 --> Hooks Class Initialized
DEBUG - 2018-06-23 00:52:53 --> UTF-8 Support Enabled
INFO - 2018-06-23 00:52:53 --> Utf8 Class Initialized
INFO - 2018-06-23 00:52:53 --> URI Class Initialized
INFO - 2018-06-23 00:52:53 --> Router Class Initialized
INFO - 2018-06-23 00:52:53 --> Output Class Initialized
INFO - 2018-06-23 00:52:53 --> Security Class Initialized
DEBUG - 2018-06-23 00:52:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 00:52:53 --> Input Class Initialized
INFO - 2018-06-23 00:52:53 --> Language Class Initialized
INFO - 2018-06-23 00:52:53 --> Language Class Initialized
INFO - 2018-06-23 00:52:53 --> Config Class Initialized
INFO - 2018-06-23 00:52:53 --> Loader Class Initialized
DEBUG - 2018-06-23 00:52:53 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-23 00:52:53 --> Helper loaded: url_helper
INFO - 2018-06-23 00:52:53 --> Helper loaded: form_helper
INFO - 2018-06-23 00:52:53 --> Helper loaded: date_helper
INFO - 2018-06-23 00:52:53 --> Helper loaded: util_helper
INFO - 2018-06-23 00:52:53 --> Helper loaded: text_helper
INFO - 2018-06-23 00:52:53 --> Helper loaded: string_helper
INFO - 2018-06-23 00:52:53 --> Database Driver Class Initialized
DEBUG - 2018-06-23 00:52:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-23 00:52:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-23 00:52:53 --> Email Class Initialized
INFO - 2018-06-23 00:52:53 --> Controller Class Initialized
DEBUG - 2018-06-23 00:52:53 --> Users MX_Controller Initialized
DEBUG - 2018-06-23 00:52:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-23 00:52:53 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-23 00:52:53 --> Login MX_Controller Initialized
INFO - 2018-06-23 00:52:53 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-23 00:52:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-23 00:52:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-23 00:52:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-23 00:52:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-23 00:52:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-23 00:52:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-23 00:52:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-06-23 00:52:54 --> Final output sent to browser
DEBUG - 2018-06-23 00:52:54 --> Total execution time: 0.3915
INFO - 2018-06-23 00:52:54 --> Config Class Initialized
INFO - 2018-06-23 00:52:54 --> Hooks Class Initialized
DEBUG - 2018-06-23 00:52:54 --> UTF-8 Support Enabled
INFO - 2018-06-23 00:52:54 --> Utf8 Class Initialized
INFO - 2018-06-23 00:52:54 --> URI Class Initialized
INFO - 2018-06-23 00:52:54 --> Router Class Initialized
INFO - 2018-06-23 00:52:54 --> Output Class Initialized
INFO - 2018-06-23 00:52:54 --> Security Class Initialized
DEBUG - 2018-06-23 00:52:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 00:52:54 --> Input Class Initialized
INFO - 2018-06-23 00:52:54 --> Language Class Initialized
INFO - 2018-06-23 00:52:54 --> Language Class Initialized
INFO - 2018-06-23 00:52:54 --> Config Class Initialized
INFO - 2018-06-23 00:52:54 --> Loader Class Initialized
DEBUG - 2018-06-23 00:52:54 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-23 00:52:54 --> Helper loaded: url_helper
INFO - 2018-06-23 00:52:54 --> Helper loaded: form_helper
INFO - 2018-06-23 00:52:54 --> Helper loaded: date_helper
INFO - 2018-06-23 00:52:54 --> Helper loaded: util_helper
INFO - 2018-06-23 00:52:54 --> Helper loaded: text_helper
INFO - 2018-06-23 00:52:54 --> Helper loaded: string_helper
INFO - 2018-06-23 00:52:54 --> Database Driver Class Initialized
DEBUG - 2018-06-23 00:52:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-23 00:52:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-23 00:52:54 --> Email Class Initialized
INFO - 2018-06-23 00:52:54 --> Controller Class Initialized
DEBUG - 2018-06-23 00:52:54 --> Users MX_Controller Initialized
DEBUG - 2018-06-23 00:52:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-23 00:52:54 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-23 00:52:54 --> Login MX_Controller Initialized
INFO - 2018-06-23 00:52:54 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-23 00:52:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-23 00:52:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-06-23 00:52:54 --> Final output sent to browser
DEBUG - 2018-06-23 00:52:54 --> Total execution time: 0.4502
INFO - 2018-06-23 00:55:02 --> Config Class Initialized
INFO - 2018-06-23 00:55:02 --> Hooks Class Initialized
DEBUG - 2018-06-23 00:55:02 --> UTF-8 Support Enabled
INFO - 2018-06-23 00:55:02 --> Utf8 Class Initialized
INFO - 2018-06-23 00:55:02 --> URI Class Initialized
INFO - 2018-06-23 00:55:02 --> Router Class Initialized
INFO - 2018-06-23 00:55:02 --> Output Class Initialized
INFO - 2018-06-23 00:55:02 --> Security Class Initialized
DEBUG - 2018-06-23 00:55:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 00:55:02 --> Input Class Initialized
INFO - 2018-06-23 00:55:02 --> Language Class Initialized
INFO - 2018-06-23 00:55:02 --> Language Class Initialized
INFO - 2018-06-23 00:55:02 --> Config Class Initialized
INFO - 2018-06-23 00:55:02 --> Loader Class Initialized
DEBUG - 2018-06-23 00:55:02 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-23 00:55:02 --> Helper loaded: url_helper
INFO - 2018-06-23 00:55:02 --> Helper loaded: form_helper
INFO - 2018-06-23 00:55:02 --> Helper loaded: date_helper
INFO - 2018-06-23 00:55:02 --> Helper loaded: util_helper
INFO - 2018-06-23 00:55:02 --> Helper loaded: text_helper
INFO - 2018-06-23 00:55:02 --> Helper loaded: string_helper
INFO - 2018-06-23 00:55:02 --> Database Driver Class Initialized
DEBUG - 2018-06-23 00:55:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-23 00:55:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-23 00:55:02 --> Email Class Initialized
INFO - 2018-06-23 00:55:02 --> Controller Class Initialized
DEBUG - 2018-06-23 00:55:02 --> Users MX_Controller Initialized
DEBUG - 2018-06-23 00:55:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-23 00:55:03 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-23 00:55:03 --> Login MX_Controller Initialized
INFO - 2018-06-23 00:55:03 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-23 00:55:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-23 00:55:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-23 00:55:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-23 00:55:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-23 00:55:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-23 00:55:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-23 00:55:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-06-23 00:55:03 --> Final output sent to browser
DEBUG - 2018-06-23 00:55:03 --> Total execution time: 0.3807
INFO - 2018-06-23 00:55:04 --> Config Class Initialized
INFO - 2018-06-23 00:55:04 --> Hooks Class Initialized
DEBUG - 2018-06-23 00:55:04 --> UTF-8 Support Enabled
INFO - 2018-06-23 00:55:04 --> Utf8 Class Initialized
INFO - 2018-06-23 00:55:04 --> URI Class Initialized
INFO - 2018-06-23 00:55:04 --> Router Class Initialized
INFO - 2018-06-23 00:55:04 --> Output Class Initialized
INFO - 2018-06-23 00:55:04 --> Security Class Initialized
DEBUG - 2018-06-23 00:55:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 00:55:04 --> Input Class Initialized
INFO - 2018-06-23 00:55:04 --> Language Class Initialized
INFO - 2018-06-23 00:55:04 --> Language Class Initialized
INFO - 2018-06-23 00:55:04 --> Config Class Initialized
INFO - 2018-06-23 00:55:04 --> Loader Class Initialized
DEBUG - 2018-06-23 00:55:04 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-23 00:55:04 --> Helper loaded: url_helper
INFO - 2018-06-23 00:55:04 --> Helper loaded: form_helper
INFO - 2018-06-23 00:55:04 --> Helper loaded: date_helper
INFO - 2018-06-23 00:55:04 --> Helper loaded: util_helper
INFO - 2018-06-23 00:55:04 --> Helper loaded: text_helper
INFO - 2018-06-23 00:55:04 --> Helper loaded: string_helper
INFO - 2018-06-23 00:55:04 --> Database Driver Class Initialized
DEBUG - 2018-06-23 00:55:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-23 00:55:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-23 00:55:04 --> Email Class Initialized
INFO - 2018-06-23 00:55:04 --> Controller Class Initialized
DEBUG - 2018-06-23 00:55:04 --> Users MX_Controller Initialized
DEBUG - 2018-06-23 00:55:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-23 00:55:04 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-23 00:55:04 --> Login MX_Controller Initialized
INFO - 2018-06-23 00:55:04 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-23 00:55:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-23 00:55:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-06-23 00:55:05 --> Final output sent to browser
DEBUG - 2018-06-23 00:55:05 --> Total execution time: 0.8692
INFO - 2018-06-23 00:55:22 --> Config Class Initialized
INFO - 2018-06-23 00:55:22 --> Hooks Class Initialized
DEBUG - 2018-06-23 00:55:22 --> UTF-8 Support Enabled
INFO - 2018-06-23 00:55:22 --> Utf8 Class Initialized
INFO - 2018-06-23 00:55:22 --> URI Class Initialized
INFO - 2018-06-23 00:55:22 --> Router Class Initialized
INFO - 2018-06-23 00:55:22 --> Output Class Initialized
INFO - 2018-06-23 00:55:22 --> Security Class Initialized
DEBUG - 2018-06-23 00:55:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 00:55:22 --> Input Class Initialized
INFO - 2018-06-23 00:55:22 --> Language Class Initialized
INFO - 2018-06-23 00:55:22 --> Language Class Initialized
INFO - 2018-06-23 00:55:22 --> Config Class Initialized
INFO - 2018-06-23 00:55:22 --> Loader Class Initialized
DEBUG - 2018-06-23 00:55:22 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-23 00:55:22 --> Helper loaded: url_helper
INFO - 2018-06-23 00:55:22 --> Helper loaded: form_helper
INFO - 2018-06-23 00:55:22 --> Helper loaded: date_helper
INFO - 2018-06-23 00:55:22 --> Helper loaded: util_helper
INFO - 2018-06-23 00:55:22 --> Helper loaded: text_helper
INFO - 2018-06-23 00:55:22 --> Helper loaded: string_helper
INFO - 2018-06-23 00:55:22 --> Database Driver Class Initialized
DEBUG - 2018-06-23 00:55:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-23 00:55:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-23 00:55:22 --> Email Class Initialized
INFO - 2018-06-23 00:55:22 --> Controller Class Initialized
DEBUG - 2018-06-23 00:55:22 --> Users MX_Controller Initialized
DEBUG - 2018-06-23 00:55:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-23 00:55:22 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-23 00:55:22 --> Login MX_Controller Initialized
INFO - 2018-06-23 00:55:22 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-23 00:55:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-23 00:55:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-23 00:55:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-23 00:55:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-23 00:55:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-23 00:55:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-23 00:55:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-06-23 00:55:22 --> Final output sent to browser
DEBUG - 2018-06-23 00:55:22 --> Total execution time: 0.3707
INFO - 2018-06-23 00:55:23 --> Config Class Initialized
INFO - 2018-06-23 00:55:23 --> Hooks Class Initialized
DEBUG - 2018-06-23 00:55:23 --> UTF-8 Support Enabled
INFO - 2018-06-23 00:55:23 --> Utf8 Class Initialized
INFO - 2018-06-23 00:55:23 --> URI Class Initialized
INFO - 2018-06-23 00:55:23 --> Router Class Initialized
INFO - 2018-06-23 00:55:23 --> Output Class Initialized
INFO - 2018-06-23 00:55:23 --> Security Class Initialized
DEBUG - 2018-06-23 00:55:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 00:55:23 --> Input Class Initialized
INFO - 2018-06-23 00:55:23 --> Language Class Initialized
INFO - 2018-06-23 00:55:23 --> Language Class Initialized
INFO - 2018-06-23 00:55:23 --> Config Class Initialized
INFO - 2018-06-23 00:55:23 --> Loader Class Initialized
DEBUG - 2018-06-23 00:55:23 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-23 00:55:23 --> Helper loaded: url_helper
INFO - 2018-06-23 00:55:23 --> Helper loaded: form_helper
INFO - 2018-06-23 00:55:23 --> Helper loaded: date_helper
INFO - 2018-06-23 00:55:23 --> Helper loaded: util_helper
INFO - 2018-06-23 00:55:23 --> Helper loaded: text_helper
INFO - 2018-06-23 00:55:23 --> Helper loaded: string_helper
INFO - 2018-06-23 00:55:23 --> Database Driver Class Initialized
DEBUG - 2018-06-23 00:55:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-23 00:55:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-23 00:55:23 --> Email Class Initialized
INFO - 2018-06-23 00:55:23 --> Controller Class Initialized
DEBUG - 2018-06-23 00:55:23 --> Users MX_Controller Initialized
DEBUG - 2018-06-23 00:55:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-23 00:55:23 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-23 00:55:23 --> Login MX_Controller Initialized
INFO - 2018-06-23 00:55:23 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-23 00:55:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-23 00:55:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-06-23 00:55:23 --> Final output sent to browser
DEBUG - 2018-06-23 00:55:23 --> Total execution time: 0.4019
INFO - 2018-06-23 00:55:43 --> Config Class Initialized
INFO - 2018-06-23 00:55:43 --> Hooks Class Initialized
DEBUG - 2018-06-23 00:55:43 --> UTF-8 Support Enabled
INFO - 2018-06-23 00:55:43 --> Utf8 Class Initialized
INFO - 2018-06-23 00:55:43 --> URI Class Initialized
INFO - 2018-06-23 00:55:43 --> Router Class Initialized
INFO - 2018-06-23 00:55:43 --> Output Class Initialized
INFO - 2018-06-23 00:55:43 --> Security Class Initialized
DEBUG - 2018-06-23 00:55:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 00:55:43 --> Input Class Initialized
INFO - 2018-06-23 00:55:43 --> Language Class Initialized
INFO - 2018-06-23 00:55:43 --> Language Class Initialized
INFO - 2018-06-23 00:55:43 --> Config Class Initialized
INFO - 2018-06-23 00:55:43 --> Loader Class Initialized
DEBUG - 2018-06-23 00:55:43 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-23 00:55:43 --> Helper loaded: url_helper
INFO - 2018-06-23 00:55:43 --> Helper loaded: form_helper
INFO - 2018-06-23 00:55:43 --> Helper loaded: date_helper
INFO - 2018-06-23 00:55:43 --> Helper loaded: util_helper
INFO - 2018-06-23 00:55:43 --> Helper loaded: text_helper
INFO - 2018-06-23 00:55:43 --> Helper loaded: string_helper
INFO - 2018-06-23 00:55:43 --> Database Driver Class Initialized
DEBUG - 2018-06-23 00:55:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-23 00:55:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-23 00:55:43 --> Email Class Initialized
INFO - 2018-06-23 00:55:43 --> Controller Class Initialized
DEBUG - 2018-06-23 00:55:43 --> Profile MX_Controller Initialized
INFO - 2018-06-23 00:55:43 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-23 00:55:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-23 00:55:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Profile_model.php
DEBUG - 2018-06-23 00:55:44 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-23 00:55:44 --> Login MX_Controller Initialized
DEBUG - 2018-06-23 00:55:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-23 00:55:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-23 00:55:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-23 00:55:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-23 00:55:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-23 00:55:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-23 00:55:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/profile.php
INFO - 2018-06-23 00:55:44 --> Final output sent to browser
DEBUG - 2018-06-23 00:55:44 --> Total execution time: 0.3806
INFO - 2018-06-23 00:55:47 --> Config Class Initialized
INFO - 2018-06-23 00:55:47 --> Hooks Class Initialized
DEBUG - 2018-06-23 00:55:47 --> UTF-8 Support Enabled
INFO - 2018-06-23 00:55:47 --> Utf8 Class Initialized
INFO - 2018-06-23 00:55:47 --> URI Class Initialized
INFO - 2018-06-23 00:55:47 --> Router Class Initialized
INFO - 2018-06-23 00:55:47 --> Output Class Initialized
INFO - 2018-06-23 00:55:47 --> Security Class Initialized
DEBUG - 2018-06-23 00:55:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 00:55:47 --> Input Class Initialized
INFO - 2018-06-23 00:55:47 --> Language Class Initialized
INFO - 2018-06-23 00:55:47 --> Language Class Initialized
INFO - 2018-06-23 00:55:47 --> Config Class Initialized
INFO - 2018-06-23 00:55:47 --> Loader Class Initialized
DEBUG - 2018-06-23 00:55:47 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-23 00:55:47 --> Helper loaded: url_helper
INFO - 2018-06-23 00:55:47 --> Helper loaded: form_helper
INFO - 2018-06-23 00:55:47 --> Helper loaded: date_helper
INFO - 2018-06-23 00:55:47 --> Helper loaded: util_helper
INFO - 2018-06-23 00:55:47 --> Helper loaded: text_helper
INFO - 2018-06-23 00:55:47 --> Helper loaded: string_helper
INFO - 2018-06-23 00:55:47 --> Database Driver Class Initialized
DEBUG - 2018-06-23 00:55:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-23 00:55:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-23 00:55:47 --> Email Class Initialized
INFO - 2018-06-23 00:55:47 --> Controller Class Initialized
DEBUG - 2018-06-23 00:55:47 --> Profile MX_Controller Initialized
INFO - 2018-06-23 00:55:47 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-23 00:55:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-23 00:55:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Profile_model.php
DEBUG - 2018-06-23 00:55:47 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-23 00:55:47 --> Login MX_Controller Initialized
DEBUG - 2018-06-23 00:55:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-23 00:55:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-23 00:55:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-23 00:55:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-23 00:55:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-23 00:55:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-23 00:55:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/admin_password.php
INFO - 2018-06-23 00:55:47 --> Final output sent to browser
DEBUG - 2018-06-23 00:55:47 --> Total execution time: 0.3927
INFO - 2018-06-23 00:57:16 --> Config Class Initialized
INFO - 2018-06-23 00:57:16 --> Hooks Class Initialized
DEBUG - 2018-06-23 00:57:16 --> UTF-8 Support Enabled
INFO - 2018-06-23 00:57:16 --> Utf8 Class Initialized
INFO - 2018-06-23 00:57:16 --> URI Class Initialized
INFO - 2018-06-23 00:57:16 --> Router Class Initialized
INFO - 2018-06-23 00:57:16 --> Output Class Initialized
INFO - 2018-06-23 00:57:16 --> Security Class Initialized
DEBUG - 2018-06-23 00:57:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 00:57:16 --> Input Class Initialized
INFO - 2018-06-23 00:57:16 --> Language Class Initialized
INFO - 2018-06-23 00:57:16 --> Language Class Initialized
INFO - 2018-06-23 00:57:16 --> Config Class Initialized
INFO - 2018-06-23 00:57:16 --> Loader Class Initialized
DEBUG - 2018-06-23 00:57:16 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-23 00:57:16 --> Helper loaded: url_helper
INFO - 2018-06-23 00:57:16 --> Helper loaded: form_helper
INFO - 2018-06-23 00:57:16 --> Helper loaded: date_helper
INFO - 2018-06-23 00:57:16 --> Helper loaded: util_helper
INFO - 2018-06-23 00:57:16 --> Helper loaded: text_helper
INFO - 2018-06-23 00:57:16 --> Helper loaded: string_helper
INFO - 2018-06-23 00:57:16 --> Database Driver Class Initialized
DEBUG - 2018-06-23 00:57:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-23 00:57:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-23 00:57:16 --> Email Class Initialized
INFO - 2018-06-23 00:57:16 --> Controller Class Initialized
DEBUG - 2018-06-23 00:57:16 --> Profile MX_Controller Initialized
INFO - 2018-06-23 00:57:16 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-23 00:57:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-23 00:57:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Profile_model.php
DEBUG - 2018-06-23 00:57:16 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-23 00:57:16 --> Login MX_Controller Initialized
DEBUG - 2018-06-23 00:57:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-23 00:57:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-23 00:57:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-23 00:57:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-23 00:57:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-23 00:57:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-23 00:57:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/profile.php
INFO - 2018-06-23 00:57:16 --> Final output sent to browser
DEBUG - 2018-06-23 00:57:16 --> Total execution time: 0.4191
INFO - 2018-06-23 00:58:03 --> Config Class Initialized
INFO - 2018-06-23 00:58:03 --> Hooks Class Initialized
DEBUG - 2018-06-23 00:58:03 --> UTF-8 Support Enabled
INFO - 2018-06-23 00:58:03 --> Utf8 Class Initialized
INFO - 2018-06-23 00:58:04 --> URI Class Initialized
INFO - 2018-06-23 00:58:04 --> Router Class Initialized
INFO - 2018-06-23 00:58:04 --> Output Class Initialized
INFO - 2018-06-23 00:58:04 --> Security Class Initialized
DEBUG - 2018-06-23 00:58:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 00:58:04 --> Input Class Initialized
INFO - 2018-06-23 00:58:04 --> Language Class Initialized
INFO - 2018-06-23 00:58:04 --> Language Class Initialized
INFO - 2018-06-23 00:58:04 --> Config Class Initialized
INFO - 2018-06-23 00:58:04 --> Loader Class Initialized
DEBUG - 2018-06-23 00:58:04 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-23 00:58:04 --> Helper loaded: url_helper
INFO - 2018-06-23 00:58:04 --> Helper loaded: form_helper
INFO - 2018-06-23 00:58:04 --> Helper loaded: date_helper
INFO - 2018-06-23 00:58:04 --> Helper loaded: util_helper
INFO - 2018-06-23 00:58:04 --> Helper loaded: text_helper
INFO - 2018-06-23 00:58:04 --> Helper loaded: string_helper
INFO - 2018-06-23 00:58:04 --> Database Driver Class Initialized
DEBUG - 2018-06-23 00:58:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-23 00:58:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-23 00:58:04 --> Email Class Initialized
INFO - 2018-06-23 00:58:04 --> Controller Class Initialized
DEBUG - 2018-06-23 00:58:04 --> Profile MX_Controller Initialized
INFO - 2018-06-23 00:58:04 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-23 00:58:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-23 00:58:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Profile_model.php
DEBUG - 2018-06-23 00:58:04 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-23 00:58:04 --> Login MX_Controller Initialized
DEBUG - 2018-06-23 00:58:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-23 00:58:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-23 00:58:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-23 00:58:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-23 00:58:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-23 00:58:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-23 00:58:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/profile.php
INFO - 2018-06-23 00:58:04 --> Final output sent to browser
DEBUG - 2018-06-23 00:58:04 --> Total execution time: 0.6580
INFO - 2018-06-23 00:58:09 --> Config Class Initialized
INFO - 2018-06-23 00:58:09 --> Hooks Class Initialized
DEBUG - 2018-06-23 00:58:09 --> UTF-8 Support Enabled
INFO - 2018-06-23 00:58:09 --> Utf8 Class Initialized
INFO - 2018-06-23 00:58:09 --> URI Class Initialized
INFO - 2018-06-23 00:58:09 --> Router Class Initialized
INFO - 2018-06-23 00:58:09 --> Output Class Initialized
INFO - 2018-06-23 00:58:09 --> Security Class Initialized
DEBUG - 2018-06-23 00:58:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 00:58:09 --> Input Class Initialized
INFO - 2018-06-23 00:58:09 --> Language Class Initialized
INFO - 2018-06-23 00:58:09 --> Language Class Initialized
INFO - 2018-06-23 00:58:09 --> Config Class Initialized
INFO - 2018-06-23 00:58:09 --> Loader Class Initialized
DEBUG - 2018-06-23 00:58:09 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-23 00:58:09 --> Helper loaded: url_helper
INFO - 2018-06-23 00:58:09 --> Helper loaded: form_helper
INFO - 2018-06-23 00:58:09 --> Helper loaded: date_helper
INFO - 2018-06-23 00:58:09 --> Helper loaded: util_helper
INFO - 2018-06-23 00:58:09 --> Helper loaded: text_helper
INFO - 2018-06-23 00:58:09 --> Helper loaded: string_helper
INFO - 2018-06-23 00:58:09 --> Database Driver Class Initialized
DEBUG - 2018-06-23 00:58:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-23 00:58:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-23 00:58:09 --> Email Class Initialized
INFO - 2018-06-23 00:58:09 --> Controller Class Initialized
DEBUG - 2018-06-23 00:58:09 --> Profile MX_Controller Initialized
INFO - 2018-06-23 00:58:09 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-23 00:58:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-23 00:58:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Profile_model.php
DEBUG - 2018-06-23 00:58:09 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-23 00:58:09 --> Login MX_Controller Initialized
DEBUG - 2018-06-23 00:58:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-23 00:58:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-23 00:58:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-23 00:58:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-23 00:58:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-23 00:58:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-23 00:58:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/admin_password.php
INFO - 2018-06-23 00:58:09 --> Final output sent to browser
DEBUG - 2018-06-23 00:58:09 --> Total execution time: 0.4795
INFO - 2018-06-23 00:58:12 --> Config Class Initialized
INFO - 2018-06-23 00:58:12 --> Hooks Class Initialized
DEBUG - 2018-06-23 00:58:12 --> UTF-8 Support Enabled
INFO - 2018-06-23 00:58:12 --> Utf8 Class Initialized
INFO - 2018-06-23 00:58:12 --> URI Class Initialized
INFO - 2018-06-23 00:58:12 --> Router Class Initialized
INFO - 2018-06-23 00:58:12 --> Output Class Initialized
INFO - 2018-06-23 00:58:12 --> Security Class Initialized
DEBUG - 2018-06-23 00:58:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 00:58:12 --> Input Class Initialized
INFO - 2018-06-23 00:58:12 --> Language Class Initialized
INFO - 2018-06-23 00:58:12 --> Language Class Initialized
INFO - 2018-06-23 00:58:12 --> Config Class Initialized
INFO - 2018-06-23 00:58:12 --> Loader Class Initialized
DEBUG - 2018-06-23 00:58:12 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-23 00:58:12 --> Helper loaded: url_helper
INFO - 2018-06-23 00:58:12 --> Helper loaded: form_helper
INFO - 2018-06-23 00:58:12 --> Helper loaded: date_helper
INFO - 2018-06-23 00:58:12 --> Helper loaded: util_helper
INFO - 2018-06-23 00:58:12 --> Helper loaded: text_helper
INFO - 2018-06-23 00:58:12 --> Helper loaded: string_helper
INFO - 2018-06-23 00:58:12 --> Database Driver Class Initialized
DEBUG - 2018-06-23 00:58:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-23 00:58:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-23 00:58:12 --> Email Class Initialized
INFO - 2018-06-23 00:58:12 --> Controller Class Initialized
DEBUG - 2018-06-23 00:58:12 --> Admin MX_Controller Initialized
INFO - 2018-06-23 00:58:12 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-23 00:58:12 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-23 00:58:12 --> Login MX_Controller Initialized
DEBUG - 2018-06-23 00:58:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-23 00:58:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-23 00:58:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-23 00:58:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-23 00:58:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-23 00:58:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-23 00:58:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-23 00:58:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/dashboard.php
INFO - 2018-06-23 00:58:12 --> Final output sent to browser
DEBUG - 2018-06-23 00:58:12 --> Total execution time: 0.3854
INFO - 2018-06-23 00:58:12 --> Config Class Initialized
INFO - 2018-06-23 00:58:12 --> Config Class Initialized
INFO - 2018-06-23 00:58:12 --> Hooks Class Initialized
INFO - 2018-06-23 00:58:12 --> Hooks Class Initialized
DEBUG - 2018-06-23 00:58:12 --> UTF-8 Support Enabled
DEBUG - 2018-06-23 00:58:12 --> UTF-8 Support Enabled
INFO - 2018-06-23 00:58:12 --> Utf8 Class Initialized
INFO - 2018-06-23 00:58:12 --> Utf8 Class Initialized
INFO - 2018-06-23 00:58:12 --> URI Class Initialized
INFO - 2018-06-23 00:58:12 --> Router Class Initialized
INFO - 2018-06-23 00:58:12 --> URI Class Initialized
INFO - 2018-06-23 00:58:12 --> Output Class Initialized
INFO - 2018-06-23 00:58:12 --> Router Class Initialized
INFO - 2018-06-23 00:58:12 --> Security Class Initialized
INFO - 2018-06-23 00:58:12 --> Output Class Initialized
DEBUG - 2018-06-23 00:58:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 00:58:12 --> Input Class Initialized
INFO - 2018-06-23 00:58:12 --> Language Class Initialized
ERROR - 2018-06-23 00:58:12 --> 404 Page Not Found: /index
INFO - 2018-06-23 00:58:12 --> Security Class Initialized
DEBUG - 2018-06-23 00:58:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 00:58:12 --> Input Class Initialized
INFO - 2018-06-23 00:58:12 --> Language Class Initialized
ERROR - 2018-06-23 00:58:12 --> 404 Page Not Found: /index
INFO - 2018-06-23 00:58:12 --> Config Class Initialized
INFO - 2018-06-23 00:58:12 --> Hooks Class Initialized
DEBUG - 2018-06-23 00:58:12 --> UTF-8 Support Enabled
INFO - 2018-06-23 00:58:13 --> Utf8 Class Initialized
INFO - 2018-06-23 00:58:13 --> URI Class Initialized
INFO - 2018-06-23 00:58:13 --> Router Class Initialized
INFO - 2018-06-23 00:58:13 --> Output Class Initialized
INFO - 2018-06-23 00:58:13 --> Security Class Initialized
DEBUG - 2018-06-23 00:58:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 00:58:13 --> Input Class Initialized
INFO - 2018-06-23 00:58:13 --> Language Class Initialized
ERROR - 2018-06-23 00:58:13 --> 404 Page Not Found: /index
INFO - 2018-06-23 00:58:17 --> Config Class Initialized
INFO - 2018-06-23 00:58:17 --> Hooks Class Initialized
DEBUG - 2018-06-23 00:58:17 --> UTF-8 Support Enabled
INFO - 2018-06-23 00:58:17 --> Utf8 Class Initialized
INFO - 2018-06-23 00:58:17 --> URI Class Initialized
INFO - 2018-06-23 00:58:17 --> Router Class Initialized
INFO - 2018-06-23 00:58:17 --> Output Class Initialized
INFO - 2018-06-23 00:58:17 --> Security Class Initialized
DEBUG - 2018-06-23 00:58:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 00:58:17 --> Input Class Initialized
INFO - 2018-06-23 00:58:17 --> Language Class Initialized
INFO - 2018-06-23 00:58:17 --> Language Class Initialized
INFO - 2018-06-23 00:58:17 --> Config Class Initialized
INFO - 2018-06-23 00:58:17 --> Loader Class Initialized
DEBUG - 2018-06-23 00:58:17 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-23 00:58:17 --> Helper loaded: url_helper
INFO - 2018-06-23 00:58:17 --> Helper loaded: form_helper
INFO - 2018-06-23 00:58:17 --> Helper loaded: date_helper
INFO - 2018-06-23 00:58:17 --> Helper loaded: util_helper
INFO - 2018-06-23 00:58:17 --> Helper loaded: text_helper
INFO - 2018-06-23 00:58:17 --> Helper loaded: string_helper
INFO - 2018-06-23 00:58:17 --> Database Driver Class Initialized
DEBUG - 2018-06-23 00:58:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-23 00:58:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-23 00:58:17 --> Email Class Initialized
INFO - 2018-06-23 00:58:17 --> Controller Class Initialized
DEBUG - 2018-06-23 00:58:17 --> Profile MX_Controller Initialized
INFO - 2018-06-23 00:58:17 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-23 00:58:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-23 00:58:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Profile_model.php
DEBUG - 2018-06-23 00:58:17 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-23 00:58:17 --> Login MX_Controller Initialized
DEBUG - 2018-06-23 00:58:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-23 00:58:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-23 00:58:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-23 00:58:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-23 00:58:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-23 00:58:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-23 00:58:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/profile.php
INFO - 2018-06-23 00:58:17 --> Final output sent to browser
DEBUG - 2018-06-23 00:58:17 --> Total execution time: 0.3898
INFO - 2018-06-23 00:58:18 --> Config Class Initialized
INFO - 2018-06-23 00:58:18 --> Hooks Class Initialized
DEBUG - 2018-06-23 00:58:18 --> UTF-8 Support Enabled
INFO - 2018-06-23 00:58:18 --> Utf8 Class Initialized
INFO - 2018-06-23 00:58:18 --> URI Class Initialized
INFO - 2018-06-23 00:58:18 --> Router Class Initialized
INFO - 2018-06-23 00:58:18 --> Output Class Initialized
INFO - 2018-06-23 00:58:18 --> Security Class Initialized
DEBUG - 2018-06-23 00:58:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 00:58:19 --> Input Class Initialized
INFO - 2018-06-23 00:58:19 --> Language Class Initialized
INFO - 2018-06-23 00:58:19 --> Language Class Initialized
INFO - 2018-06-23 00:58:19 --> Config Class Initialized
INFO - 2018-06-23 00:58:19 --> Loader Class Initialized
DEBUG - 2018-06-23 00:58:19 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-23 00:58:19 --> Helper loaded: url_helper
INFO - 2018-06-23 00:58:19 --> Helper loaded: form_helper
INFO - 2018-06-23 00:58:19 --> Helper loaded: date_helper
INFO - 2018-06-23 00:58:19 --> Helper loaded: util_helper
INFO - 2018-06-23 00:58:19 --> Helper loaded: text_helper
INFO - 2018-06-23 00:58:19 --> Helper loaded: string_helper
INFO - 2018-06-23 00:58:19 --> Database Driver Class Initialized
DEBUG - 2018-06-23 00:58:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-23 00:58:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-23 00:58:19 --> Email Class Initialized
INFO - 2018-06-23 00:58:19 --> Controller Class Initialized
DEBUG - 2018-06-23 00:58:19 --> Profile MX_Controller Initialized
INFO - 2018-06-23 00:58:19 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-23 00:58:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-23 00:58:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Profile_model.php
DEBUG - 2018-06-23 00:58:19 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-23 00:58:19 --> Login MX_Controller Initialized
DEBUG - 2018-06-23 00:58:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-23 00:58:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-23 00:58:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-23 00:58:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-23 00:58:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-23 00:58:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-23 00:58:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/admin_password.php
INFO - 2018-06-23 00:58:19 --> Final output sent to browser
DEBUG - 2018-06-23 00:58:19 --> Total execution time: 0.3862
INFO - 2018-06-23 00:58:19 --> Config Class Initialized
INFO - 2018-06-23 00:58:19 --> Hooks Class Initialized
DEBUG - 2018-06-23 00:58:19 --> UTF-8 Support Enabled
INFO - 2018-06-23 00:58:19 --> Utf8 Class Initialized
INFO - 2018-06-23 00:58:19 --> URI Class Initialized
INFO - 2018-06-23 00:58:19 --> Router Class Initialized
INFO - 2018-06-23 00:58:19 --> Output Class Initialized
INFO - 2018-06-23 00:58:20 --> Security Class Initialized
DEBUG - 2018-06-23 00:58:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 00:58:20 --> Input Class Initialized
INFO - 2018-06-23 00:58:20 --> Language Class Initialized
INFO - 2018-06-23 00:58:20 --> Language Class Initialized
INFO - 2018-06-23 00:58:20 --> Config Class Initialized
INFO - 2018-06-23 00:58:20 --> Loader Class Initialized
DEBUG - 2018-06-23 00:58:20 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-23 00:58:20 --> Helper loaded: url_helper
INFO - 2018-06-23 00:58:20 --> Helper loaded: form_helper
INFO - 2018-06-23 00:58:20 --> Helper loaded: date_helper
INFO - 2018-06-23 00:58:20 --> Helper loaded: util_helper
INFO - 2018-06-23 00:58:20 --> Helper loaded: text_helper
INFO - 2018-06-23 00:58:20 --> Helper loaded: string_helper
INFO - 2018-06-23 00:58:20 --> Database Driver Class Initialized
DEBUG - 2018-06-23 00:58:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-23 00:58:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-23 00:58:20 --> Email Class Initialized
INFO - 2018-06-23 00:58:20 --> Controller Class Initialized
DEBUG - 2018-06-23 00:58:20 --> Profile MX_Controller Initialized
INFO - 2018-06-23 00:58:20 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-23 00:58:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-23 00:58:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Profile_model.php
DEBUG - 2018-06-23 00:58:20 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-23 00:58:20 --> Login MX_Controller Initialized
DEBUG - 2018-06-23 00:58:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-23 00:58:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-23 00:58:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-23 00:58:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-23 00:58:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-23 00:58:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-23 00:58:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/admin_password.php
INFO - 2018-06-23 00:58:20 --> Final output sent to browser
DEBUG - 2018-06-23 00:58:20 --> Total execution time: 0.4236
INFO - 2018-06-23 00:58:20 --> Config Class Initialized
INFO - 2018-06-23 00:58:20 --> Hooks Class Initialized
DEBUG - 2018-06-23 00:58:20 --> UTF-8 Support Enabled
INFO - 2018-06-23 00:58:20 --> Utf8 Class Initialized
INFO - 2018-06-23 00:58:20 --> URI Class Initialized
INFO - 2018-06-23 00:58:20 --> Router Class Initialized
INFO - 2018-06-23 00:58:20 --> Output Class Initialized
INFO - 2018-06-23 00:58:20 --> Security Class Initialized
DEBUG - 2018-06-23 00:58:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 00:58:20 --> Input Class Initialized
INFO - 2018-06-23 00:58:20 --> Language Class Initialized
INFO - 2018-06-23 00:58:20 --> Language Class Initialized
INFO - 2018-06-23 00:58:20 --> Config Class Initialized
INFO - 2018-06-23 00:58:20 --> Loader Class Initialized
DEBUG - 2018-06-23 00:58:20 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-23 00:58:20 --> Helper loaded: url_helper
INFO - 2018-06-23 00:58:20 --> Helper loaded: form_helper
INFO - 2018-06-23 00:58:20 --> Helper loaded: date_helper
INFO - 2018-06-23 00:58:20 --> Helper loaded: util_helper
INFO - 2018-06-23 00:58:20 --> Helper loaded: text_helper
INFO - 2018-06-23 00:58:20 --> Helper loaded: string_helper
INFO - 2018-06-23 00:58:20 --> Database Driver Class Initialized
DEBUG - 2018-06-23 00:58:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-23 00:58:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-23 00:58:20 --> Email Class Initialized
INFO - 2018-06-23 00:58:21 --> Controller Class Initialized
DEBUG - 2018-06-23 00:58:21 --> Profile MX_Controller Initialized
INFO - 2018-06-23 00:58:21 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-23 00:58:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-23 00:58:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Profile_model.php
DEBUG - 2018-06-23 00:58:21 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-23 00:58:21 --> Login MX_Controller Initialized
DEBUG - 2018-06-23 00:58:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-23 00:58:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-23 00:58:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-23 00:58:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-23 00:58:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-23 00:58:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-23 00:58:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/profile.php
INFO - 2018-06-23 00:58:21 --> Final output sent to browser
DEBUG - 2018-06-23 00:58:21 --> Total execution time: 0.4317
INFO - 2018-06-23 00:58:31 --> Config Class Initialized
INFO - 2018-06-23 00:58:31 --> Hooks Class Initialized
DEBUG - 2018-06-23 00:58:31 --> UTF-8 Support Enabled
INFO - 2018-06-23 00:58:31 --> Utf8 Class Initialized
INFO - 2018-06-23 00:58:31 --> URI Class Initialized
INFO - 2018-06-23 00:58:31 --> Router Class Initialized
INFO - 2018-06-23 00:58:31 --> Output Class Initialized
INFO - 2018-06-23 00:58:31 --> Security Class Initialized
DEBUG - 2018-06-23 00:58:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 00:58:31 --> Input Class Initialized
INFO - 2018-06-23 00:58:31 --> Language Class Initialized
INFO - 2018-06-23 00:58:31 --> Language Class Initialized
INFO - 2018-06-23 00:58:31 --> Config Class Initialized
INFO - 2018-06-23 00:58:31 --> Loader Class Initialized
DEBUG - 2018-06-23 00:58:31 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-23 00:58:31 --> Helper loaded: url_helper
INFO - 2018-06-23 00:58:31 --> Helper loaded: form_helper
INFO - 2018-06-23 00:58:32 --> Helper loaded: date_helper
INFO - 2018-06-23 00:58:32 --> Helper loaded: util_helper
INFO - 2018-06-23 00:58:32 --> Helper loaded: text_helper
INFO - 2018-06-23 00:58:32 --> Helper loaded: string_helper
INFO - 2018-06-23 00:58:32 --> Database Driver Class Initialized
DEBUG - 2018-06-23 00:58:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-23 00:58:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-23 00:58:32 --> Email Class Initialized
INFO - 2018-06-23 00:58:32 --> Controller Class Initialized
DEBUG - 2018-06-23 00:58:32 --> Profile MX_Controller Initialized
DEBUG - 2018-06-23 00:58:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-23 00:58:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-23 00:58:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-23 00:58:32 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-23 00:58:32 --> Login MX_Controller Initialized
INFO - 2018-06-23 00:58:32 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-23 00:58:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-23 00:58:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-23 00:58:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-23 00:58:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-23 00:58:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-06-23 00:58:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-23 00:58:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-23 00:58:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/profile.php
INFO - 2018-06-23 00:58:32 --> Final output sent to browser
DEBUG - 2018-06-23 00:58:32 --> Total execution time: 0.4216
INFO - 2018-06-23 00:58:33 --> Config Class Initialized
INFO - 2018-06-23 00:58:33 --> Hooks Class Initialized
DEBUG - 2018-06-23 00:58:33 --> UTF-8 Support Enabled
INFO - 2018-06-23 00:58:33 --> Utf8 Class Initialized
INFO - 2018-06-23 00:58:33 --> URI Class Initialized
INFO - 2018-06-23 00:58:33 --> Router Class Initialized
INFO - 2018-06-23 00:58:33 --> Output Class Initialized
INFO - 2018-06-23 00:58:33 --> Security Class Initialized
DEBUG - 2018-06-23 00:58:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 00:58:33 --> Input Class Initialized
INFO - 2018-06-23 00:58:33 --> Language Class Initialized
ERROR - 2018-06-23 00:58:33 --> 404 Page Not Found: /index
INFO - 2018-06-23 00:58:33 --> Config Class Initialized
INFO - 2018-06-23 00:58:33 --> Hooks Class Initialized
DEBUG - 2018-06-23 00:58:33 --> UTF-8 Support Enabled
INFO - 2018-06-23 00:58:33 --> Utf8 Class Initialized
INFO - 2018-06-23 00:58:33 --> URI Class Initialized
INFO - 2018-06-23 00:58:33 --> Router Class Initialized
INFO - 2018-06-23 00:58:33 --> Output Class Initialized
INFO - 2018-06-23 00:58:33 --> Security Class Initialized
DEBUG - 2018-06-23 00:58:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 00:58:33 --> Input Class Initialized
INFO - 2018-06-23 00:58:33 --> Language Class Initialized
ERROR - 2018-06-23 00:58:33 --> 404 Page Not Found: /index
INFO - 2018-06-23 00:58:33 --> Config Class Initialized
INFO - 2018-06-23 00:58:33 --> Hooks Class Initialized
DEBUG - 2018-06-23 00:58:33 --> UTF-8 Support Enabled
INFO - 2018-06-23 00:58:33 --> Utf8 Class Initialized
INFO - 2018-06-23 00:58:33 --> URI Class Initialized
INFO - 2018-06-23 00:58:33 --> Router Class Initialized
INFO - 2018-06-23 00:58:33 --> Output Class Initialized
INFO - 2018-06-23 00:58:33 --> Security Class Initialized
DEBUG - 2018-06-23 00:58:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 00:58:33 --> Input Class Initialized
INFO - 2018-06-23 00:58:33 --> Language Class Initialized
ERROR - 2018-06-23 00:58:33 --> 404 Page Not Found: /index
INFO - 2018-06-23 00:58:34 --> Config Class Initialized
INFO - 2018-06-23 00:58:34 --> Hooks Class Initialized
DEBUG - 2018-06-23 00:58:34 --> UTF-8 Support Enabled
INFO - 2018-06-23 00:58:34 --> Utf8 Class Initialized
INFO - 2018-06-23 00:58:34 --> URI Class Initialized
DEBUG - 2018-06-23 00:58:34 --> No URI present. Default controller set.
INFO - 2018-06-23 00:58:34 --> Router Class Initialized
INFO - 2018-06-23 00:58:34 --> Output Class Initialized
INFO - 2018-06-23 00:58:34 --> Security Class Initialized
DEBUG - 2018-06-23 00:58:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 00:58:34 --> Input Class Initialized
INFO - 2018-06-23 00:58:34 --> Language Class Initialized
INFO - 2018-06-23 00:58:34 --> Language Class Initialized
INFO - 2018-06-23 00:58:34 --> Config Class Initialized
INFO - 2018-06-23 00:58:34 --> Loader Class Initialized
DEBUG - 2018-06-23 00:58:34 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-23 00:58:34 --> Helper loaded: url_helper
INFO - 2018-06-23 00:58:34 --> Helper loaded: form_helper
INFO - 2018-06-23 00:58:34 --> Helper loaded: date_helper
INFO - 2018-06-23 00:58:34 --> Helper loaded: util_helper
INFO - 2018-06-23 00:58:34 --> Helper loaded: text_helper
INFO - 2018-06-23 00:58:34 --> Helper loaded: string_helper
INFO - 2018-06-23 00:58:34 --> Database Driver Class Initialized
DEBUG - 2018-06-23 00:58:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-23 00:58:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-23 00:58:34 --> Email Class Initialized
INFO - 2018-06-23 00:58:34 --> Controller Class Initialized
DEBUG - 2018-06-23 00:58:34 --> Home MX_Controller Initialized
DEBUG - 2018-06-23 00:58:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-23 00:58:34 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-23 00:58:34 --> Login MX_Controller Initialized
INFO - 2018-06-23 00:58:34 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-23 00:58:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-23 00:58:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-23 00:58:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-23 00:58:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-23 00:58:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-23 00:58:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-23 00:58:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-23 00:58:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-06-23 00:58:34 --> Final output sent to browser
DEBUG - 2018-06-23 00:58:34 --> Total execution time: 0.4173
INFO - 2018-06-23 00:58:35 --> Config Class Initialized
INFO - 2018-06-23 00:58:35 --> Hooks Class Initialized
DEBUG - 2018-06-23 00:58:35 --> UTF-8 Support Enabled
INFO - 2018-06-23 00:58:35 --> Utf8 Class Initialized
INFO - 2018-06-23 00:58:35 --> URI Class Initialized
INFO - 2018-06-23 00:58:35 --> Router Class Initialized
INFO - 2018-06-23 00:58:35 --> Output Class Initialized
INFO - 2018-06-23 00:58:35 --> Security Class Initialized
DEBUG - 2018-06-23 00:58:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 00:58:35 --> Input Class Initialized
INFO - 2018-06-23 00:58:35 --> Language Class Initialized
ERROR - 2018-06-23 00:58:35 --> 404 Page Not Found: /index
INFO - 2018-06-23 00:58:35 --> Config Class Initialized
INFO - 2018-06-23 00:58:35 --> Hooks Class Initialized
DEBUG - 2018-06-23 00:58:35 --> UTF-8 Support Enabled
INFO - 2018-06-23 00:58:35 --> Utf8 Class Initialized
INFO - 2018-06-23 00:58:35 --> URI Class Initialized
INFO - 2018-06-23 00:58:35 --> Router Class Initialized
INFO - 2018-06-23 00:58:35 --> Output Class Initialized
INFO - 2018-06-23 00:58:35 --> Security Class Initialized
DEBUG - 2018-06-23 00:58:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 00:58:35 --> Input Class Initialized
INFO - 2018-06-23 00:58:35 --> Language Class Initialized
ERROR - 2018-06-23 00:58:35 --> 404 Page Not Found: /index
INFO - 2018-06-23 00:58:35 --> Config Class Initialized
INFO - 2018-06-23 00:58:35 --> Hooks Class Initialized
DEBUG - 2018-06-23 00:58:35 --> UTF-8 Support Enabled
INFO - 2018-06-23 00:58:35 --> Utf8 Class Initialized
INFO - 2018-06-23 00:58:35 --> URI Class Initialized
INFO - 2018-06-23 00:58:35 --> Router Class Initialized
INFO - 2018-06-23 00:58:35 --> Output Class Initialized
INFO - 2018-06-23 00:58:35 --> Security Class Initialized
DEBUG - 2018-06-23 00:58:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 00:58:35 --> Input Class Initialized
INFO - 2018-06-23 00:58:35 --> Language Class Initialized
ERROR - 2018-06-23 00:58:35 --> 404 Page Not Found: /index
INFO - 2018-06-23 00:58:35 --> Config Class Initialized
INFO - 2018-06-23 00:58:35 --> Hooks Class Initialized
DEBUG - 2018-06-23 00:58:35 --> UTF-8 Support Enabled
INFO - 2018-06-23 00:58:35 --> Utf8 Class Initialized
INFO - 2018-06-23 00:58:35 --> URI Class Initialized
INFO - 2018-06-23 00:58:35 --> Router Class Initialized
INFO - 2018-06-23 00:58:35 --> Output Class Initialized
INFO - 2018-06-23 00:58:35 --> Security Class Initialized
DEBUG - 2018-06-23 00:58:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 00:58:35 --> Input Class Initialized
INFO - 2018-06-23 00:58:35 --> Language Class Initialized
ERROR - 2018-06-23 00:58:35 --> 404 Page Not Found: /index
INFO - 2018-06-23 00:58:35 --> Config Class Initialized
INFO - 2018-06-23 00:58:35 --> Hooks Class Initialized
DEBUG - 2018-06-23 00:58:35 --> UTF-8 Support Enabled
INFO - 2018-06-23 00:58:35 --> Utf8 Class Initialized
INFO - 2018-06-23 00:58:35 --> URI Class Initialized
INFO - 2018-06-23 00:58:35 --> Router Class Initialized
INFO - 2018-06-23 00:58:35 --> Output Class Initialized
INFO - 2018-06-23 00:58:35 --> Security Class Initialized
DEBUG - 2018-06-23 00:58:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 00:58:35 --> Input Class Initialized
INFO - 2018-06-23 00:58:35 --> Language Class Initialized
ERROR - 2018-06-23 00:58:35 --> 404 Page Not Found: /index
INFO - 2018-06-23 00:58:35 --> Config Class Initialized
INFO - 2018-06-23 00:58:35 --> Hooks Class Initialized
DEBUG - 2018-06-23 00:58:35 --> UTF-8 Support Enabled
INFO - 2018-06-23 00:58:35 --> Utf8 Class Initialized
INFO - 2018-06-23 00:58:35 --> URI Class Initialized
INFO - 2018-06-23 00:58:35 --> Router Class Initialized
INFO - 2018-06-23 00:58:35 --> Output Class Initialized
INFO - 2018-06-23 00:58:35 --> Security Class Initialized
DEBUG - 2018-06-23 00:58:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 00:58:35 --> Input Class Initialized
INFO - 2018-06-23 00:58:35 --> Language Class Initialized
ERROR - 2018-06-23 00:58:35 --> 404 Page Not Found: /index
INFO - 2018-06-23 00:58:42 --> Config Class Initialized
INFO - 2018-06-23 00:58:42 --> Hooks Class Initialized
DEBUG - 2018-06-23 00:58:42 --> UTF-8 Support Enabled
INFO - 2018-06-23 00:58:42 --> Utf8 Class Initialized
INFO - 2018-06-23 00:58:42 --> URI Class Initialized
INFO - 2018-06-23 00:58:42 --> Router Class Initialized
INFO - 2018-06-23 00:58:42 --> Output Class Initialized
INFO - 2018-06-23 00:58:42 --> Security Class Initialized
DEBUG - 2018-06-23 00:58:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 00:58:42 --> Input Class Initialized
INFO - 2018-06-23 00:58:42 --> Language Class Initialized
INFO - 2018-06-23 00:58:42 --> Language Class Initialized
INFO - 2018-06-23 00:58:42 --> Config Class Initialized
INFO - 2018-06-23 00:58:42 --> Loader Class Initialized
DEBUG - 2018-06-23 00:58:42 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-23 00:58:42 --> Helper loaded: url_helper
INFO - 2018-06-23 00:58:42 --> Helper loaded: form_helper
INFO - 2018-06-23 00:58:42 --> Helper loaded: date_helper
INFO - 2018-06-23 00:58:42 --> Helper loaded: util_helper
INFO - 2018-06-23 00:58:42 --> Helper loaded: text_helper
INFO - 2018-06-23 00:58:42 --> Helper loaded: string_helper
INFO - 2018-06-23 00:58:42 --> Database Driver Class Initialized
DEBUG - 2018-06-23 00:58:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-23 00:58:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-23 00:58:42 --> Email Class Initialized
INFO - 2018-06-23 00:58:42 --> Controller Class Initialized
DEBUG - 2018-06-23 00:58:42 --> Admin MX_Controller Initialized
INFO - 2018-06-23 00:58:42 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-23 00:58:42 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-23 00:58:42 --> Login MX_Controller Initialized
DEBUG - 2018-06-23 00:58:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-23 00:58:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-23 00:58:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-23 00:58:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-23 00:58:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-23 00:58:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-23 00:58:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-23 00:58:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/dashboard.php
INFO - 2018-06-23 00:58:42 --> Final output sent to browser
DEBUG - 2018-06-23 00:58:42 --> Total execution time: 0.3893
INFO - 2018-06-23 00:58:42 --> Config Class Initialized
INFO - 2018-06-23 00:58:42 --> Hooks Class Initialized
DEBUG - 2018-06-23 00:58:42 --> UTF-8 Support Enabled
INFO - 2018-06-23 00:58:42 --> Utf8 Class Initialized
INFO - 2018-06-23 00:58:42 --> URI Class Initialized
INFO - 2018-06-23 00:58:42 --> Router Class Initialized
INFO - 2018-06-23 00:58:42 --> Config Class Initialized
INFO - 2018-06-23 00:58:42 --> Hooks Class Initialized
INFO - 2018-06-23 00:58:42 --> Output Class Initialized
DEBUG - 2018-06-23 00:58:42 --> UTF-8 Support Enabled
INFO - 2018-06-23 00:58:42 --> Utf8 Class Initialized
INFO - 2018-06-23 00:58:42 --> Security Class Initialized
INFO - 2018-06-23 00:58:42 --> URI Class Initialized
INFO - 2018-06-23 00:58:42 --> Router Class Initialized
DEBUG - 2018-06-23 00:58:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 00:58:42 --> Input Class Initialized
INFO - 2018-06-23 00:58:42 --> Output Class Initialized
INFO - 2018-06-23 00:58:42 --> Language Class Initialized
INFO - 2018-06-23 00:58:42 --> Security Class Initialized
ERROR - 2018-06-23 00:58:42 --> 404 Page Not Found: /index
DEBUG - 2018-06-23 00:58:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 00:58:42 --> Input Class Initialized
INFO - 2018-06-23 00:58:42 --> Language Class Initialized
ERROR - 2018-06-23 00:58:42 --> 404 Page Not Found: /index
INFO - 2018-06-23 01:14:54 --> Config Class Initialized
INFO - 2018-06-23 01:14:54 --> Hooks Class Initialized
DEBUG - 2018-06-23 01:14:54 --> UTF-8 Support Enabled
INFO - 2018-06-23 01:14:54 --> Utf8 Class Initialized
INFO - 2018-06-23 01:14:54 --> URI Class Initialized
INFO - 2018-06-23 01:14:54 --> Router Class Initialized
INFO - 2018-06-23 01:14:54 --> Output Class Initialized
INFO - 2018-06-23 01:14:54 --> Security Class Initialized
DEBUG - 2018-06-23 01:14:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 01:14:54 --> Input Class Initialized
INFO - 2018-06-23 01:14:54 --> Language Class Initialized
INFO - 2018-06-23 01:14:54 --> Language Class Initialized
INFO - 2018-06-23 01:14:54 --> Config Class Initialized
INFO - 2018-06-23 01:14:54 --> Loader Class Initialized
DEBUG - 2018-06-23 01:14:55 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-23 01:14:55 --> Helper loaded: url_helper
INFO - 2018-06-23 01:14:55 --> Helper loaded: form_helper
INFO - 2018-06-23 01:14:55 --> Helper loaded: date_helper
INFO - 2018-06-23 01:14:55 --> Helper loaded: util_helper
INFO - 2018-06-23 01:14:55 --> Helper loaded: text_helper
INFO - 2018-06-23 01:14:55 --> Helper loaded: string_helper
INFO - 2018-06-23 01:14:55 --> Database Driver Class Initialized
DEBUG - 2018-06-23 01:14:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-23 01:14:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-23 01:14:55 --> Email Class Initialized
INFO - 2018-06-23 01:14:55 --> Controller Class Initialized
DEBUG - 2018-06-23 01:14:55 --> Users MX_Controller Initialized
DEBUG - 2018-06-23 01:14:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-23 01:14:55 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-23 01:14:55 --> Login MX_Controller Initialized
INFO - 2018-06-23 01:14:55 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-23 01:14:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-23 01:14:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-23 01:14:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-23 01:14:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-23 01:14:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-23 01:14:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-23 01:14:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-06-23 01:14:55 --> Final output sent to browser
DEBUG - 2018-06-23 01:14:55 --> Total execution time: 0.4258
INFO - 2018-06-23 01:14:55 --> Config Class Initialized
INFO - 2018-06-23 01:14:55 --> Hooks Class Initialized
DEBUG - 2018-06-23 01:14:55 --> UTF-8 Support Enabled
INFO - 2018-06-23 01:14:55 --> Utf8 Class Initialized
INFO - 2018-06-23 01:14:55 --> URI Class Initialized
INFO - 2018-06-23 01:14:55 --> Router Class Initialized
INFO - 2018-06-23 01:14:55 --> Output Class Initialized
INFO - 2018-06-23 01:14:55 --> Security Class Initialized
DEBUG - 2018-06-23 01:14:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 01:14:55 --> Input Class Initialized
INFO - 2018-06-23 01:14:55 --> Language Class Initialized
INFO - 2018-06-23 01:14:55 --> Language Class Initialized
INFO - 2018-06-23 01:14:55 --> Config Class Initialized
INFO - 2018-06-23 01:14:55 --> Loader Class Initialized
DEBUG - 2018-06-23 01:14:55 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-23 01:14:56 --> Helper loaded: url_helper
INFO - 2018-06-23 01:14:56 --> Helper loaded: form_helper
INFO - 2018-06-23 01:14:56 --> Helper loaded: date_helper
INFO - 2018-06-23 01:14:56 --> Helper loaded: util_helper
INFO - 2018-06-23 01:14:56 --> Helper loaded: text_helper
INFO - 2018-06-23 01:14:56 --> Helper loaded: string_helper
INFO - 2018-06-23 01:14:56 --> Database Driver Class Initialized
DEBUG - 2018-06-23 01:14:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-23 01:14:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-23 01:14:56 --> Email Class Initialized
INFO - 2018-06-23 01:14:56 --> Controller Class Initialized
DEBUG - 2018-06-23 01:14:56 --> Users MX_Controller Initialized
DEBUG - 2018-06-23 01:14:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-23 01:14:56 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-23 01:14:56 --> Login MX_Controller Initialized
INFO - 2018-06-23 01:14:56 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-23 01:14:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-23 01:14:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-06-23 01:14:56 --> Final output sent to browser
DEBUG - 2018-06-23 01:14:56 --> Total execution time: 0.4614
INFO - 2018-06-23 01:14:56 --> Config Class Initialized
INFO - 2018-06-23 01:14:56 --> Hooks Class Initialized
DEBUG - 2018-06-23 01:14:56 --> UTF-8 Support Enabled
INFO - 2018-06-23 01:14:56 --> Utf8 Class Initialized
INFO - 2018-06-23 01:14:56 --> URI Class Initialized
INFO - 2018-06-23 01:14:56 --> Router Class Initialized
INFO - 2018-06-23 01:14:56 --> Output Class Initialized
INFO - 2018-06-23 01:14:56 --> Security Class Initialized
DEBUG - 2018-06-23 01:14:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 01:14:56 --> Input Class Initialized
INFO - 2018-06-23 01:14:56 --> Language Class Initialized
INFO - 2018-06-23 01:14:56 --> Language Class Initialized
INFO - 2018-06-23 01:14:56 --> Config Class Initialized
INFO - 2018-06-23 01:14:56 --> Loader Class Initialized
DEBUG - 2018-06-23 01:14:56 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-23 01:14:56 --> Helper loaded: url_helper
INFO - 2018-06-23 01:14:56 --> Helper loaded: form_helper
INFO - 2018-06-23 01:14:56 --> Helper loaded: date_helper
INFO - 2018-06-23 01:14:56 --> Helper loaded: util_helper
INFO - 2018-06-23 01:14:56 --> Helper loaded: text_helper
INFO - 2018-06-23 01:14:56 --> Helper loaded: string_helper
INFO - 2018-06-23 01:14:56 --> Database Driver Class Initialized
DEBUG - 2018-06-23 01:14:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-23 01:14:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-23 01:14:56 --> Email Class Initialized
INFO - 2018-06-23 01:14:56 --> Controller Class Initialized
DEBUG - 2018-06-23 01:14:56 --> Users MX_Controller Initialized
DEBUG - 2018-06-23 01:14:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-23 01:14:56 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-23 01:14:56 --> Login MX_Controller Initialized
INFO - 2018-06-23 01:14:56 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-23 01:14:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-23 01:14:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-06-23 01:14:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-23 01:14:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-23 01:14:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-23 01:14:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-23 01:14:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-23 01:14:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-06-23 01:14:56 --> Final output sent to browser
DEBUG - 2018-06-23 01:14:56 --> Total execution time: 0.4576
INFO - 2018-06-23 02:16:54 --> Config Class Initialized
INFO - 2018-06-23 02:16:54 --> Hooks Class Initialized
DEBUG - 2018-06-23 02:16:54 --> UTF-8 Support Enabled
INFO - 2018-06-23 02:16:54 --> Utf8 Class Initialized
INFO - 2018-06-23 02:16:54 --> URI Class Initialized
DEBUG - 2018-06-23 02:16:54 --> No URI present. Default controller set.
INFO - 2018-06-23 02:16:54 --> Router Class Initialized
INFO - 2018-06-23 02:16:54 --> Output Class Initialized
INFO - 2018-06-23 02:16:54 --> Security Class Initialized
DEBUG - 2018-06-23 02:16:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 02:16:54 --> Input Class Initialized
INFO - 2018-06-23 02:16:54 --> Language Class Initialized
INFO - 2018-06-23 02:16:54 --> Language Class Initialized
INFO - 2018-06-23 02:16:54 --> Config Class Initialized
INFO - 2018-06-23 02:16:54 --> Loader Class Initialized
DEBUG - 2018-06-23 02:16:54 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-23 02:16:54 --> Helper loaded: url_helper
INFO - 2018-06-23 02:16:54 --> Helper loaded: form_helper
INFO - 2018-06-23 02:16:54 --> Helper loaded: date_helper
INFO - 2018-06-23 02:16:54 --> Helper loaded: util_helper
INFO - 2018-06-23 02:16:54 --> Helper loaded: text_helper
INFO - 2018-06-23 02:16:54 --> Helper loaded: string_helper
INFO - 2018-06-23 02:16:54 --> Database Driver Class Initialized
DEBUG - 2018-06-23 02:16:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-23 02:16:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-23 02:16:54 --> Email Class Initialized
INFO - 2018-06-23 02:16:54 --> Controller Class Initialized
DEBUG - 2018-06-23 02:16:54 --> Home MX_Controller Initialized
DEBUG - 2018-06-23 02:16:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-23 02:16:54 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-23 02:16:54 --> Login MX_Controller Initialized
INFO - 2018-06-23 02:16:54 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-23 02:16:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-23 02:16:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-23 02:16:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-06-23 02:16:56 --> Config Class Initialized
INFO - 2018-06-23 02:16:56 --> Hooks Class Initialized
DEBUG - 2018-06-23 02:16:56 --> UTF-8 Support Enabled
INFO - 2018-06-23 02:16:56 --> Utf8 Class Initialized
INFO - 2018-06-23 02:16:56 --> URI Class Initialized
DEBUG - 2018-06-23 02:16:56 --> No URI present. Default controller set.
INFO - 2018-06-23 02:16:56 --> Router Class Initialized
INFO - 2018-06-23 02:16:56 --> Output Class Initialized
INFO - 2018-06-23 02:16:56 --> Security Class Initialized
DEBUG - 2018-06-23 02:16:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 02:16:56 --> Input Class Initialized
INFO - 2018-06-23 02:16:56 --> Language Class Initialized
INFO - 2018-06-23 02:16:56 --> Language Class Initialized
INFO - 2018-06-23 02:16:56 --> Config Class Initialized
INFO - 2018-06-23 02:16:56 --> Loader Class Initialized
DEBUG - 2018-06-23 02:16:56 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-23 02:16:56 --> Helper loaded: url_helper
INFO - 2018-06-23 02:16:56 --> Helper loaded: form_helper
INFO - 2018-06-23 02:16:56 --> Helper loaded: date_helper
INFO - 2018-06-23 02:16:56 --> Helper loaded: util_helper
INFO - 2018-06-23 02:16:56 --> Helper loaded: text_helper
INFO - 2018-06-23 02:16:56 --> Helper loaded: string_helper
INFO - 2018-06-23 02:16:56 --> Database Driver Class Initialized
DEBUG - 2018-06-23 02:16:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-23 02:16:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-23 02:16:56 --> Email Class Initialized
INFO - 2018-06-23 02:16:56 --> Controller Class Initialized
DEBUG - 2018-06-23 02:16:56 --> Home MX_Controller Initialized
DEBUG - 2018-06-23 02:16:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-23 02:16:56 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-23 02:16:56 --> Login MX_Controller Initialized
INFO - 2018-06-23 02:16:56 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-23 02:16:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-23 02:16:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-23 02:16:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-06-23 02:17:02 --> Config Class Initialized
INFO - 2018-06-23 02:17:02 --> Hooks Class Initialized
DEBUG - 2018-06-23 02:17:02 --> UTF-8 Support Enabled
INFO - 2018-06-23 02:17:02 --> Utf8 Class Initialized
INFO - 2018-06-23 02:17:02 --> URI Class Initialized
INFO - 2018-06-23 02:17:02 --> Router Class Initialized
INFO - 2018-06-23 02:17:02 --> Output Class Initialized
INFO - 2018-06-23 02:17:02 --> Security Class Initialized
DEBUG - 2018-06-23 02:17:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 02:17:02 --> Input Class Initialized
INFO - 2018-06-23 02:17:02 --> Language Class Initialized
INFO - 2018-06-23 02:17:02 --> Language Class Initialized
INFO - 2018-06-23 02:17:02 --> Config Class Initialized
INFO - 2018-06-23 02:17:02 --> Loader Class Initialized
DEBUG - 2018-06-23 02:17:02 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-23 02:17:02 --> Helper loaded: url_helper
INFO - 2018-06-23 02:17:02 --> Helper loaded: form_helper
INFO - 2018-06-23 02:17:02 --> Helper loaded: date_helper
INFO - 2018-06-23 02:17:02 --> Helper loaded: util_helper
INFO - 2018-06-23 02:17:02 --> Helper loaded: text_helper
INFO - 2018-06-23 02:17:02 --> Helper loaded: string_helper
INFO - 2018-06-23 02:17:02 --> Database Driver Class Initialized
DEBUG - 2018-06-23 02:17:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-23 02:17:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-23 02:17:02 --> Email Class Initialized
INFO - 2018-06-23 02:17:02 --> Controller Class Initialized
DEBUG - 2018-06-23 02:17:02 --> Login MX_Controller Initialized
INFO - 2018-06-23 02:17:02 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-23 02:17:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-23 02:17:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-23 02:17:02 --> Email starts for user@colin.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-06-23 02:17:02 --> User session created for 4
INFO - 2018-06-23 02:17:02 --> Login status user@colin.com - success
INFO - 2018-06-23 02:17:02 --> Final output sent to browser
DEBUG - 2018-06-23 02:17:02 --> Total execution time: 0.3999
INFO - 2018-06-23 02:17:02 --> Config Class Initialized
INFO - 2018-06-23 02:17:02 --> Hooks Class Initialized
DEBUG - 2018-06-23 02:17:02 --> UTF-8 Support Enabled
INFO - 2018-06-23 02:17:02 --> Utf8 Class Initialized
INFO - 2018-06-23 02:17:02 --> URI Class Initialized
DEBUG - 2018-06-23 02:17:02 --> No URI present. Default controller set.
INFO - 2018-06-23 02:17:02 --> Router Class Initialized
INFO - 2018-06-23 02:17:02 --> Output Class Initialized
INFO - 2018-06-23 02:17:02 --> Security Class Initialized
DEBUG - 2018-06-23 02:17:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 02:17:02 --> Input Class Initialized
INFO - 2018-06-23 02:17:02 --> Language Class Initialized
INFO - 2018-06-23 02:17:02 --> Language Class Initialized
INFO - 2018-06-23 02:17:02 --> Config Class Initialized
INFO - 2018-06-23 02:17:02 --> Loader Class Initialized
DEBUG - 2018-06-23 02:17:02 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-23 02:17:02 --> Helper loaded: url_helper
INFO - 2018-06-23 02:17:02 --> Helper loaded: form_helper
INFO - 2018-06-23 02:17:02 --> Helper loaded: date_helper
INFO - 2018-06-23 02:17:02 --> Helper loaded: util_helper
INFO - 2018-06-23 02:17:02 --> Helper loaded: text_helper
INFO - 2018-06-23 02:17:02 --> Helper loaded: string_helper
INFO - 2018-06-23 02:17:02 --> Database Driver Class Initialized
DEBUG - 2018-06-23 02:17:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-23 02:17:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-23 02:17:02 --> Email Class Initialized
INFO - 2018-06-23 02:17:02 --> Controller Class Initialized
DEBUG - 2018-06-23 02:17:02 --> Home MX_Controller Initialized
DEBUG - 2018-06-23 02:17:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-23 02:17:02 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-23 02:17:02 --> Login MX_Controller Initialized
INFO - 2018-06-23 02:17:02 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-23 02:17:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-23 02:17:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-23 02:17:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-23 02:17:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-23 02:17:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-23 02:17:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-23 02:17:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-23 02:17:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-06-23 02:17:02 --> Final output sent to browser
DEBUG - 2018-06-23 02:17:03 --> Total execution time: 0.4832
INFO - 2018-06-23 02:17:04 --> Config Class Initialized
INFO - 2018-06-23 02:17:04 --> Hooks Class Initialized
DEBUG - 2018-06-23 02:17:04 --> UTF-8 Support Enabled
INFO - 2018-06-23 02:17:04 --> Utf8 Class Initialized
INFO - 2018-06-23 02:17:04 --> URI Class Initialized
INFO - 2018-06-23 02:17:04 --> Router Class Initialized
INFO - 2018-06-23 02:17:04 --> Output Class Initialized
INFO - 2018-06-23 02:17:04 --> Security Class Initialized
DEBUG - 2018-06-23 02:17:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 02:17:04 --> Input Class Initialized
INFO - 2018-06-23 02:17:04 --> Language Class Initialized
ERROR - 2018-06-23 02:17:04 --> 404 Page Not Found: /index
INFO - 2018-06-23 02:17:04 --> Config Class Initialized
INFO - 2018-06-23 02:17:04 --> Hooks Class Initialized
DEBUG - 2018-06-23 02:17:04 --> UTF-8 Support Enabled
INFO - 2018-06-23 02:17:04 --> Utf8 Class Initialized
INFO - 2018-06-23 02:17:04 --> URI Class Initialized
INFO - 2018-06-23 02:17:04 --> Router Class Initialized
INFO - 2018-06-23 02:17:04 --> Output Class Initialized
INFO - 2018-06-23 02:17:04 --> Security Class Initialized
DEBUG - 2018-06-23 02:17:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 02:17:04 --> Input Class Initialized
INFO - 2018-06-23 02:17:04 --> Language Class Initialized
ERROR - 2018-06-23 02:17:04 --> 404 Page Not Found: /index
INFO - 2018-06-23 02:17:04 --> Config Class Initialized
INFO - 2018-06-23 02:17:04 --> Hooks Class Initialized
DEBUG - 2018-06-23 02:17:04 --> UTF-8 Support Enabled
INFO - 2018-06-23 02:17:04 --> Utf8 Class Initialized
INFO - 2018-06-23 02:17:04 --> URI Class Initialized
INFO - 2018-06-23 02:17:04 --> Router Class Initialized
INFO - 2018-06-23 02:17:04 --> Output Class Initialized
INFO - 2018-06-23 02:17:04 --> Security Class Initialized
DEBUG - 2018-06-23 02:17:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 02:17:04 --> Input Class Initialized
INFO - 2018-06-23 02:17:04 --> Language Class Initialized
ERROR - 2018-06-23 02:17:04 --> 404 Page Not Found: /index
INFO - 2018-06-23 04:17:17 --> Config Class Initialized
INFO - 2018-06-23 04:17:17 --> Hooks Class Initialized
DEBUG - 2018-06-23 04:17:17 --> UTF-8 Support Enabled
INFO - 2018-06-23 04:17:17 --> Utf8 Class Initialized
INFO - 2018-06-23 04:17:17 --> URI Class Initialized
DEBUG - 2018-06-23 04:17:17 --> No URI present. Default controller set.
INFO - 2018-06-23 04:17:17 --> Router Class Initialized
INFO - 2018-06-23 04:17:17 --> Output Class Initialized
INFO - 2018-06-23 04:17:17 --> Security Class Initialized
DEBUG - 2018-06-23 04:17:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 04:17:17 --> Input Class Initialized
INFO - 2018-06-23 04:17:17 --> Language Class Initialized
INFO - 2018-06-23 04:17:17 --> Language Class Initialized
INFO - 2018-06-23 04:17:17 --> Config Class Initialized
INFO - 2018-06-23 04:17:17 --> Loader Class Initialized
DEBUG - 2018-06-23 04:17:17 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-23 04:17:17 --> Helper loaded: url_helper
INFO - 2018-06-23 04:17:17 --> Helper loaded: form_helper
INFO - 2018-06-23 04:17:17 --> Helper loaded: date_helper
INFO - 2018-06-23 04:17:17 --> Helper loaded: util_helper
INFO - 2018-06-23 04:17:17 --> Helper loaded: text_helper
INFO - 2018-06-23 04:17:17 --> Helper loaded: string_helper
INFO - 2018-06-23 04:17:17 --> Database Driver Class Initialized
DEBUG - 2018-06-23 04:17:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-23 04:17:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-23 04:17:17 --> Email Class Initialized
INFO - 2018-06-23 04:17:17 --> Controller Class Initialized
DEBUG - 2018-06-23 04:17:17 --> Home MX_Controller Initialized
DEBUG - 2018-06-23 04:17:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-23 04:17:17 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-23 04:17:17 --> Login MX_Controller Initialized
INFO - 2018-06-23 04:17:17 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-23 04:17:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-23 04:17:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-23 04:17:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-06-23 04:17:22 --> Config Class Initialized
INFO - 2018-06-23 04:17:22 --> Hooks Class Initialized
DEBUG - 2018-06-23 04:17:22 --> UTF-8 Support Enabled
INFO - 2018-06-23 04:17:22 --> Utf8 Class Initialized
INFO - 2018-06-23 04:17:22 --> URI Class Initialized
INFO - 2018-06-23 04:17:22 --> Router Class Initialized
INFO - 2018-06-23 04:17:22 --> Output Class Initialized
INFO - 2018-06-23 04:17:22 --> Security Class Initialized
DEBUG - 2018-06-23 04:17:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 04:17:22 --> Input Class Initialized
INFO - 2018-06-23 04:17:22 --> Language Class Initialized
INFO - 2018-06-23 04:17:22 --> Language Class Initialized
INFO - 2018-06-23 04:17:22 --> Config Class Initialized
INFO - 2018-06-23 04:17:22 --> Loader Class Initialized
DEBUG - 2018-06-23 04:17:22 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-23 04:17:22 --> Helper loaded: url_helper
INFO - 2018-06-23 04:17:22 --> Helper loaded: form_helper
INFO - 2018-06-23 04:17:22 --> Helper loaded: date_helper
INFO - 2018-06-23 04:17:22 --> Helper loaded: util_helper
INFO - 2018-06-23 04:17:22 --> Helper loaded: text_helper
INFO - 2018-06-23 04:17:22 --> Helper loaded: string_helper
INFO - 2018-06-23 04:17:22 --> Database Driver Class Initialized
DEBUG - 2018-06-23 04:17:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-23 04:17:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-23 04:17:22 --> Email Class Initialized
INFO - 2018-06-23 04:17:22 --> Controller Class Initialized
DEBUG - 2018-06-23 04:17:23 --> Login MX_Controller Initialized
INFO - 2018-06-23 04:17:23 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-23 04:17:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-23 04:17:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-23 04:17:23 --> Email starts for user@colin.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-06-23 04:17:23 --> User session created for 4
INFO - 2018-06-23 04:17:23 --> Login status user@colin.com - success
INFO - 2018-06-23 04:17:23 --> Final output sent to browser
DEBUG - 2018-06-23 04:17:23 --> Total execution time: 0.5635
INFO - 2018-06-23 04:17:23 --> Config Class Initialized
INFO - 2018-06-23 04:17:23 --> Hooks Class Initialized
DEBUG - 2018-06-23 04:17:23 --> UTF-8 Support Enabled
INFO - 2018-06-23 04:17:23 --> Utf8 Class Initialized
INFO - 2018-06-23 04:17:23 --> URI Class Initialized
DEBUG - 2018-06-23 04:17:23 --> No URI present. Default controller set.
INFO - 2018-06-23 04:17:23 --> Router Class Initialized
INFO - 2018-06-23 04:17:23 --> Output Class Initialized
INFO - 2018-06-23 04:17:23 --> Security Class Initialized
DEBUG - 2018-06-23 04:17:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 04:17:23 --> Input Class Initialized
INFO - 2018-06-23 04:17:23 --> Language Class Initialized
INFO - 2018-06-23 04:17:23 --> Language Class Initialized
INFO - 2018-06-23 04:17:23 --> Config Class Initialized
INFO - 2018-06-23 04:17:23 --> Loader Class Initialized
DEBUG - 2018-06-23 04:17:23 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-23 04:17:23 --> Helper loaded: url_helper
INFO - 2018-06-23 04:17:23 --> Helper loaded: form_helper
INFO - 2018-06-23 04:17:23 --> Helper loaded: date_helper
INFO - 2018-06-23 04:17:23 --> Helper loaded: util_helper
INFO - 2018-06-23 04:17:23 --> Helper loaded: text_helper
INFO - 2018-06-23 04:17:23 --> Helper loaded: string_helper
INFO - 2018-06-23 04:17:23 --> Database Driver Class Initialized
DEBUG - 2018-06-23 04:17:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-23 04:17:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-23 04:17:23 --> Email Class Initialized
INFO - 2018-06-23 04:17:23 --> Controller Class Initialized
DEBUG - 2018-06-23 04:17:23 --> Home MX_Controller Initialized
DEBUG - 2018-06-23 04:17:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-23 04:17:23 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-23 04:17:23 --> Login MX_Controller Initialized
INFO - 2018-06-23 04:17:23 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-23 04:17:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-23 04:17:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-23 04:17:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-23 04:17:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-23 04:17:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-23 04:17:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-23 04:17:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-23 04:17:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-06-23 04:17:23 --> Final output sent to browser
DEBUG - 2018-06-23 04:17:23 --> Total execution time: 0.4796
INFO - 2018-06-23 04:17:24 --> Config Class Initialized
INFO - 2018-06-23 04:17:24 --> Hooks Class Initialized
DEBUG - 2018-06-23 04:17:24 --> UTF-8 Support Enabled
INFO - 2018-06-23 04:17:24 --> Utf8 Class Initialized
INFO - 2018-06-23 04:17:24 --> URI Class Initialized
INFO - 2018-06-23 04:17:24 --> Router Class Initialized
INFO - 2018-06-23 04:17:24 --> Output Class Initialized
INFO - 2018-06-23 04:17:24 --> Security Class Initialized
DEBUG - 2018-06-23 04:17:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 04:17:24 --> Input Class Initialized
INFO - 2018-06-23 04:17:24 --> Language Class Initialized
ERROR - 2018-06-23 04:17:24 --> 404 Page Not Found: /index
INFO - 2018-06-23 04:17:24 --> Config Class Initialized
INFO - 2018-06-23 04:17:25 --> Hooks Class Initialized
DEBUG - 2018-06-23 04:17:25 --> UTF-8 Support Enabled
INFO - 2018-06-23 04:17:25 --> Utf8 Class Initialized
INFO - 2018-06-23 04:17:25 --> URI Class Initialized
INFO - 2018-06-23 04:17:25 --> Router Class Initialized
INFO - 2018-06-23 04:17:25 --> Output Class Initialized
INFO - 2018-06-23 04:17:25 --> Security Class Initialized
DEBUG - 2018-06-23 04:17:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 04:17:25 --> Input Class Initialized
INFO - 2018-06-23 04:17:25 --> Language Class Initialized
ERROR - 2018-06-23 04:17:25 --> 404 Page Not Found: /index
INFO - 2018-06-23 04:17:25 --> Config Class Initialized
INFO - 2018-06-23 04:17:25 --> Hooks Class Initialized
DEBUG - 2018-06-23 04:17:25 --> UTF-8 Support Enabled
INFO - 2018-06-23 04:17:25 --> Utf8 Class Initialized
INFO - 2018-06-23 04:17:25 --> URI Class Initialized
INFO - 2018-06-23 04:17:25 --> Router Class Initialized
INFO - 2018-06-23 04:17:25 --> Output Class Initialized
INFO - 2018-06-23 04:17:25 --> Security Class Initialized
DEBUG - 2018-06-23 04:17:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 04:17:25 --> Input Class Initialized
INFO - 2018-06-23 04:17:25 --> Language Class Initialized
ERROR - 2018-06-23 04:17:25 --> 404 Page Not Found: /index
INFO - 2018-06-23 04:17:48 --> Config Class Initialized
INFO - 2018-06-23 04:17:48 --> Hooks Class Initialized
DEBUG - 2018-06-23 04:17:48 --> UTF-8 Support Enabled
INFO - 2018-06-23 04:17:48 --> Utf8 Class Initialized
INFO - 2018-06-23 04:17:48 --> URI Class Initialized
DEBUG - 2018-06-23 04:17:48 --> No URI present. Default controller set.
INFO - 2018-06-23 04:17:48 --> Router Class Initialized
INFO - 2018-06-23 04:17:48 --> Output Class Initialized
INFO - 2018-06-23 04:17:48 --> Security Class Initialized
DEBUG - 2018-06-23 04:17:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 04:17:48 --> Input Class Initialized
INFO - 2018-06-23 04:17:48 --> Language Class Initialized
INFO - 2018-06-23 04:17:48 --> Language Class Initialized
INFO - 2018-06-23 04:17:48 --> Config Class Initialized
INFO - 2018-06-23 04:17:48 --> Loader Class Initialized
DEBUG - 2018-06-23 04:17:48 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-23 04:17:48 --> Helper loaded: url_helper
INFO - 2018-06-23 04:17:48 --> Helper loaded: form_helper
INFO - 2018-06-23 04:17:48 --> Helper loaded: date_helper
INFO - 2018-06-23 04:17:48 --> Helper loaded: util_helper
INFO - 2018-06-23 04:17:48 --> Helper loaded: text_helper
INFO - 2018-06-23 04:17:48 --> Helper loaded: string_helper
INFO - 2018-06-23 04:17:48 --> Database Driver Class Initialized
DEBUG - 2018-06-23 04:17:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-23 04:17:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-23 04:17:48 --> Email Class Initialized
INFO - 2018-06-23 04:17:48 --> Controller Class Initialized
DEBUG - 2018-06-23 04:17:48 --> Home MX_Controller Initialized
DEBUG - 2018-06-23 04:17:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-23 04:17:48 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-23 04:17:48 --> Login MX_Controller Initialized
INFO - 2018-06-23 04:17:48 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-23 04:17:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-23 04:17:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-23 04:17:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-23 04:17:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-23 04:17:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-23 04:17:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-23 04:17:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-23 04:17:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-06-23 04:17:48 --> Final output sent to browser
DEBUG - 2018-06-23 04:17:48 --> Total execution time: 0.4637
INFO - 2018-06-23 04:17:50 --> Config Class Initialized
INFO - 2018-06-23 04:17:50 --> Hooks Class Initialized
DEBUG - 2018-06-23 04:17:50 --> UTF-8 Support Enabled
INFO - 2018-06-23 04:17:50 --> Utf8 Class Initialized
INFO - 2018-06-23 04:17:50 --> URI Class Initialized
INFO - 2018-06-23 04:17:50 --> Router Class Initialized
INFO - 2018-06-23 04:17:50 --> Output Class Initialized
INFO - 2018-06-23 04:17:50 --> Security Class Initialized
DEBUG - 2018-06-23 04:17:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 04:17:50 --> Input Class Initialized
INFO - 2018-06-23 04:17:50 --> Language Class Initialized
ERROR - 2018-06-23 04:17:50 --> 404 Page Not Found: /index
INFO - 2018-06-23 04:17:50 --> Config Class Initialized
INFO - 2018-06-23 04:17:50 --> Hooks Class Initialized
DEBUG - 2018-06-23 04:17:50 --> UTF-8 Support Enabled
INFO - 2018-06-23 04:17:50 --> Utf8 Class Initialized
INFO - 2018-06-23 04:17:50 --> URI Class Initialized
INFO - 2018-06-23 04:17:50 --> Router Class Initialized
INFO - 2018-06-23 04:17:50 --> Output Class Initialized
INFO - 2018-06-23 04:17:50 --> Security Class Initialized
DEBUG - 2018-06-23 04:17:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 04:17:50 --> Input Class Initialized
INFO - 2018-06-23 04:17:50 --> Language Class Initialized
ERROR - 2018-06-23 04:17:50 --> 404 Page Not Found: /index
INFO - 2018-06-23 04:17:50 --> Config Class Initialized
INFO - 2018-06-23 04:17:50 --> Hooks Class Initialized
DEBUG - 2018-06-23 04:17:50 --> UTF-8 Support Enabled
INFO - 2018-06-23 04:17:50 --> Utf8 Class Initialized
INFO - 2018-06-23 04:17:50 --> URI Class Initialized
INFO - 2018-06-23 04:17:50 --> Router Class Initialized
INFO - 2018-06-23 04:17:50 --> Output Class Initialized
INFO - 2018-06-23 04:17:50 --> Security Class Initialized
DEBUG - 2018-06-23 04:17:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 04:17:50 --> Input Class Initialized
INFO - 2018-06-23 04:17:50 --> Language Class Initialized
ERROR - 2018-06-23 04:17:50 --> 404 Page Not Found: /index
INFO - 2018-06-23 04:17:50 --> Config Class Initialized
INFO - 2018-06-23 04:17:50 --> Hooks Class Initialized
DEBUG - 2018-06-23 04:17:50 --> UTF-8 Support Enabled
INFO - 2018-06-23 04:17:50 --> Utf8 Class Initialized
INFO - 2018-06-23 04:17:50 --> URI Class Initialized
INFO - 2018-06-23 04:17:50 --> Router Class Initialized
INFO - 2018-06-23 04:17:50 --> Output Class Initialized
INFO - 2018-06-23 04:17:50 --> Security Class Initialized
DEBUG - 2018-06-23 04:17:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 04:17:50 --> Input Class Initialized
INFO - 2018-06-23 04:17:50 --> Language Class Initialized
ERROR - 2018-06-23 04:17:50 --> 404 Page Not Found: /index
INFO - 2018-06-23 04:17:50 --> Config Class Initialized
INFO - 2018-06-23 04:17:50 --> Hooks Class Initialized
DEBUG - 2018-06-23 04:17:50 --> UTF-8 Support Enabled
INFO - 2018-06-23 04:17:50 --> Utf8 Class Initialized
INFO - 2018-06-23 04:17:50 --> URI Class Initialized
INFO - 2018-06-23 04:17:50 --> Router Class Initialized
INFO - 2018-06-23 04:17:50 --> Output Class Initialized
INFO - 2018-06-23 04:17:50 --> Security Class Initialized
DEBUG - 2018-06-23 04:17:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 04:17:50 --> Input Class Initialized
INFO - 2018-06-23 04:17:50 --> Language Class Initialized
ERROR - 2018-06-23 04:17:50 --> 404 Page Not Found: /index
INFO - 2018-06-23 04:17:50 --> Config Class Initialized
INFO - 2018-06-23 04:17:50 --> Hooks Class Initialized
DEBUG - 2018-06-23 04:17:50 --> UTF-8 Support Enabled
INFO - 2018-06-23 04:17:50 --> Utf8 Class Initialized
INFO - 2018-06-23 04:17:50 --> URI Class Initialized
INFO - 2018-06-23 04:17:50 --> Router Class Initialized
INFO - 2018-06-23 04:17:50 --> Output Class Initialized
INFO - 2018-06-23 04:17:51 --> Security Class Initialized
DEBUG - 2018-06-23 04:17:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 04:17:51 --> Input Class Initialized
INFO - 2018-06-23 04:17:51 --> Language Class Initialized
ERROR - 2018-06-23 04:17:51 --> 404 Page Not Found: /index
INFO - 2018-06-23 04:19:02 --> Config Class Initialized
INFO - 2018-06-23 04:19:02 --> Hooks Class Initialized
DEBUG - 2018-06-23 04:19:02 --> UTF-8 Support Enabled
INFO - 2018-06-23 04:19:02 --> Utf8 Class Initialized
INFO - 2018-06-23 04:19:02 --> URI Class Initialized
DEBUG - 2018-06-23 04:19:02 --> No URI present. Default controller set.
INFO - 2018-06-23 04:19:02 --> Router Class Initialized
INFO - 2018-06-23 04:19:02 --> Output Class Initialized
INFO - 2018-06-23 04:19:02 --> Security Class Initialized
DEBUG - 2018-06-23 04:19:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 04:19:02 --> Input Class Initialized
INFO - 2018-06-23 04:19:02 --> Language Class Initialized
INFO - 2018-06-23 04:19:02 --> Language Class Initialized
INFO - 2018-06-23 04:19:02 --> Config Class Initialized
INFO - 2018-06-23 04:19:02 --> Loader Class Initialized
DEBUG - 2018-06-23 04:19:02 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-23 04:19:02 --> Helper loaded: url_helper
INFO - 2018-06-23 04:19:02 --> Helper loaded: form_helper
INFO - 2018-06-23 04:19:02 --> Helper loaded: date_helper
INFO - 2018-06-23 04:19:02 --> Helper loaded: util_helper
INFO - 2018-06-23 04:19:02 --> Helper loaded: text_helper
INFO - 2018-06-23 04:19:02 --> Helper loaded: string_helper
INFO - 2018-06-23 04:19:02 --> Database Driver Class Initialized
DEBUG - 2018-06-23 04:19:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-23 04:19:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-23 04:19:03 --> Email Class Initialized
INFO - 2018-06-23 04:19:03 --> Controller Class Initialized
DEBUG - 2018-06-23 04:19:03 --> Home MX_Controller Initialized
DEBUG - 2018-06-23 04:19:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-23 04:19:03 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-23 04:19:03 --> Login MX_Controller Initialized
INFO - 2018-06-23 04:19:03 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-23 04:19:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-23 04:19:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-23 04:19:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-23 04:19:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-23 04:19:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-23 04:19:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-23 04:19:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-23 04:19:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-06-23 04:19:03 --> Final output sent to browser
DEBUG - 2018-06-23 04:19:03 --> Total execution time: 0.4621
INFO - 2018-06-23 04:19:03 --> Config Class Initialized
INFO - 2018-06-23 04:19:03 --> Hooks Class Initialized
DEBUG - 2018-06-23 04:19:03 --> UTF-8 Support Enabled
INFO - 2018-06-23 04:19:03 --> Utf8 Class Initialized
INFO - 2018-06-23 04:19:03 --> URI Class Initialized
INFO - 2018-06-23 04:19:03 --> Router Class Initialized
INFO - 2018-06-23 04:19:03 --> Output Class Initialized
INFO - 2018-06-23 04:19:03 --> Security Class Initialized
DEBUG - 2018-06-23 04:19:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 04:19:03 --> Input Class Initialized
INFO - 2018-06-23 04:19:03 --> Language Class Initialized
ERROR - 2018-06-23 04:19:03 --> 404 Page Not Found: /index
INFO - 2018-06-23 04:19:03 --> Config Class Initialized
INFO - 2018-06-23 04:19:04 --> Hooks Class Initialized
DEBUG - 2018-06-23 04:19:04 --> UTF-8 Support Enabled
INFO - 2018-06-23 04:19:04 --> Utf8 Class Initialized
INFO - 2018-06-23 04:19:04 --> URI Class Initialized
INFO - 2018-06-23 04:19:04 --> Router Class Initialized
INFO - 2018-06-23 04:19:04 --> Output Class Initialized
INFO - 2018-06-23 04:19:04 --> Security Class Initialized
DEBUG - 2018-06-23 04:19:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 04:19:04 --> Input Class Initialized
INFO - 2018-06-23 04:19:04 --> Language Class Initialized
ERROR - 2018-06-23 04:19:04 --> 404 Page Not Found: /index
INFO - 2018-06-23 04:19:04 --> Config Class Initialized
INFO - 2018-06-23 04:19:04 --> Hooks Class Initialized
DEBUG - 2018-06-23 04:19:04 --> UTF-8 Support Enabled
INFO - 2018-06-23 04:19:04 --> Utf8 Class Initialized
INFO - 2018-06-23 04:19:04 --> URI Class Initialized
INFO - 2018-06-23 04:19:04 --> Router Class Initialized
INFO - 2018-06-23 04:19:04 --> Output Class Initialized
INFO - 2018-06-23 04:19:04 --> Security Class Initialized
DEBUG - 2018-06-23 04:19:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 04:19:04 --> Input Class Initialized
INFO - 2018-06-23 04:19:04 --> Language Class Initialized
ERROR - 2018-06-23 04:19:04 --> 404 Page Not Found: /index
INFO - 2018-06-23 04:19:04 --> Config Class Initialized
INFO - 2018-06-23 04:19:04 --> Hooks Class Initialized
DEBUG - 2018-06-23 04:19:04 --> UTF-8 Support Enabled
INFO - 2018-06-23 04:19:04 --> Utf8 Class Initialized
INFO - 2018-06-23 04:19:04 --> URI Class Initialized
INFO - 2018-06-23 04:19:04 --> Router Class Initialized
INFO - 2018-06-23 04:19:04 --> Output Class Initialized
INFO - 2018-06-23 04:19:04 --> Security Class Initialized
DEBUG - 2018-06-23 04:19:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 04:19:04 --> Input Class Initialized
INFO - 2018-06-23 04:19:04 --> Language Class Initialized
ERROR - 2018-06-23 04:19:04 --> 404 Page Not Found: /index
INFO - 2018-06-23 04:19:04 --> Config Class Initialized
INFO - 2018-06-23 04:19:04 --> Hooks Class Initialized
DEBUG - 2018-06-23 04:19:04 --> UTF-8 Support Enabled
INFO - 2018-06-23 04:19:04 --> Utf8 Class Initialized
INFO - 2018-06-23 04:19:04 --> URI Class Initialized
INFO - 2018-06-23 04:19:04 --> Router Class Initialized
INFO - 2018-06-23 04:19:04 --> Output Class Initialized
INFO - 2018-06-23 04:19:04 --> Security Class Initialized
DEBUG - 2018-06-23 04:19:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 04:19:04 --> Input Class Initialized
INFO - 2018-06-23 04:19:04 --> Language Class Initialized
ERROR - 2018-06-23 04:19:04 --> 404 Page Not Found: /index
INFO - 2018-06-23 04:19:04 --> Config Class Initialized
INFO - 2018-06-23 04:19:04 --> Hooks Class Initialized
DEBUG - 2018-06-23 04:19:04 --> UTF-8 Support Enabled
INFO - 2018-06-23 04:19:04 --> Utf8 Class Initialized
INFO - 2018-06-23 04:19:04 --> URI Class Initialized
INFO - 2018-06-23 04:19:04 --> Router Class Initialized
INFO - 2018-06-23 04:19:04 --> Output Class Initialized
INFO - 2018-06-23 04:19:04 --> Security Class Initialized
DEBUG - 2018-06-23 04:19:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 04:19:04 --> Input Class Initialized
INFO - 2018-06-23 04:19:04 --> Language Class Initialized
ERROR - 2018-06-23 04:19:04 --> 404 Page Not Found: /index
INFO - 2018-06-23 04:19:39 --> Config Class Initialized
INFO - 2018-06-23 04:19:39 --> Hooks Class Initialized
DEBUG - 2018-06-23 04:19:39 --> UTF-8 Support Enabled
INFO - 2018-06-23 04:19:39 --> Utf8 Class Initialized
INFO - 2018-06-23 04:19:39 --> URI Class Initialized
DEBUG - 2018-06-23 04:19:39 --> No URI present. Default controller set.
INFO - 2018-06-23 04:19:39 --> Router Class Initialized
INFO - 2018-06-23 04:19:39 --> Output Class Initialized
INFO - 2018-06-23 04:19:39 --> Security Class Initialized
DEBUG - 2018-06-23 04:19:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 04:19:39 --> Input Class Initialized
INFO - 2018-06-23 04:19:39 --> Language Class Initialized
INFO - 2018-06-23 04:19:39 --> Language Class Initialized
INFO - 2018-06-23 04:19:39 --> Config Class Initialized
INFO - 2018-06-23 04:19:39 --> Loader Class Initialized
DEBUG - 2018-06-23 04:19:39 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-23 04:19:39 --> Helper loaded: url_helper
INFO - 2018-06-23 04:19:39 --> Helper loaded: form_helper
INFO - 2018-06-23 04:19:39 --> Helper loaded: date_helper
INFO - 2018-06-23 04:19:39 --> Helper loaded: util_helper
INFO - 2018-06-23 04:19:39 --> Helper loaded: text_helper
INFO - 2018-06-23 04:19:39 --> Helper loaded: string_helper
INFO - 2018-06-23 04:19:39 --> Database Driver Class Initialized
DEBUG - 2018-06-23 04:19:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-23 04:19:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-23 04:19:40 --> Email Class Initialized
INFO - 2018-06-23 04:19:40 --> Controller Class Initialized
DEBUG - 2018-06-23 04:19:40 --> Home MX_Controller Initialized
DEBUG - 2018-06-23 04:19:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-23 04:19:40 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-23 04:19:40 --> Login MX_Controller Initialized
INFO - 2018-06-23 04:19:40 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-23 04:19:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-23 04:19:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-23 04:19:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-23 04:19:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-23 04:19:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-23 04:19:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-23 04:19:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-23 04:19:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-06-23 04:19:40 --> Final output sent to browser
DEBUG - 2018-06-23 04:19:40 --> Total execution time: 0.8328
INFO - 2018-06-23 05:45:06 --> Config Class Initialized
INFO - 2018-06-23 05:45:06 --> Hooks Class Initialized
DEBUG - 2018-06-23 05:45:06 --> UTF-8 Support Enabled
INFO - 2018-06-23 05:45:06 --> Utf8 Class Initialized
INFO - 2018-06-23 05:45:06 --> URI Class Initialized
DEBUG - 2018-06-23 05:45:06 --> No URI present. Default controller set.
INFO - 2018-06-23 05:45:06 --> Router Class Initialized
INFO - 2018-06-23 05:45:06 --> Output Class Initialized
INFO - 2018-06-23 05:45:06 --> Security Class Initialized
DEBUG - 2018-06-23 05:45:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 05:45:06 --> Input Class Initialized
INFO - 2018-06-23 05:45:06 --> Language Class Initialized
INFO - 2018-06-23 05:45:06 --> Language Class Initialized
INFO - 2018-06-23 05:45:06 --> Config Class Initialized
INFO - 2018-06-23 05:45:06 --> Loader Class Initialized
DEBUG - 2018-06-23 05:45:06 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-23 05:45:06 --> Helper loaded: url_helper
INFO - 2018-06-23 05:45:06 --> Helper loaded: form_helper
INFO - 2018-06-23 05:45:06 --> Helper loaded: date_helper
INFO - 2018-06-23 05:45:06 --> Helper loaded: util_helper
INFO - 2018-06-23 05:45:06 --> Helper loaded: text_helper
INFO - 2018-06-23 05:45:06 --> Helper loaded: string_helper
INFO - 2018-06-23 05:45:06 --> Database Driver Class Initialized
DEBUG - 2018-06-23 05:45:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-23 05:45:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-23 05:45:06 --> Email Class Initialized
INFO - 2018-06-23 05:45:06 --> Controller Class Initialized
DEBUG - 2018-06-23 05:45:06 --> Home MX_Controller Initialized
DEBUG - 2018-06-23 05:45:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-23 05:45:06 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-23 05:45:06 --> Login MX_Controller Initialized
INFO - 2018-06-23 05:45:06 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-23 05:45:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-23 05:45:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-23 05:45:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-23 05:45:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-23 05:45:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-23 05:45:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-23 05:45:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-23 05:45:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-06-23 05:45:06 --> Final output sent to browser
DEBUG - 2018-06-23 05:45:06 --> Total execution time: 0.6298
INFO - 2018-06-23 05:45:07 --> Config Class Initialized
INFO - 2018-06-23 05:45:07 --> Hooks Class Initialized
DEBUG - 2018-06-23 05:45:07 --> UTF-8 Support Enabled
INFO - 2018-06-23 05:45:07 --> Utf8 Class Initialized
INFO - 2018-06-23 05:45:07 --> URI Class Initialized
INFO - 2018-06-23 05:45:07 --> Router Class Initialized
INFO - 2018-06-23 05:45:07 --> Output Class Initialized
INFO - 2018-06-23 05:45:07 --> Security Class Initialized
DEBUG - 2018-06-23 05:45:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 05:45:07 --> Input Class Initialized
INFO - 2018-06-23 05:45:07 --> Language Class Initialized
ERROR - 2018-06-23 05:45:07 --> 404 Page Not Found: /index
INFO - 2018-06-23 05:45:07 --> Config Class Initialized
INFO - 2018-06-23 05:45:07 --> Hooks Class Initialized
DEBUG - 2018-06-23 05:45:07 --> UTF-8 Support Enabled
INFO - 2018-06-23 05:45:07 --> Utf8 Class Initialized
INFO - 2018-06-23 05:45:07 --> URI Class Initialized
INFO - 2018-06-23 05:45:07 --> Router Class Initialized
INFO - 2018-06-23 05:45:07 --> Output Class Initialized
INFO - 2018-06-23 05:45:07 --> Security Class Initialized
DEBUG - 2018-06-23 05:45:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 05:45:07 --> Input Class Initialized
INFO - 2018-06-23 05:45:07 --> Language Class Initialized
ERROR - 2018-06-23 05:45:07 --> 404 Page Not Found: /index
INFO - 2018-06-23 05:45:07 --> Config Class Initialized
INFO - 2018-06-23 05:45:07 --> Hooks Class Initialized
DEBUG - 2018-06-23 05:45:07 --> UTF-8 Support Enabled
INFO - 2018-06-23 05:45:07 --> Utf8 Class Initialized
INFO - 2018-06-23 05:45:07 --> URI Class Initialized
INFO - 2018-06-23 05:45:07 --> Router Class Initialized
INFO - 2018-06-23 05:45:07 --> Output Class Initialized
INFO - 2018-06-23 05:45:07 --> Security Class Initialized
DEBUG - 2018-06-23 05:45:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 05:45:07 --> Input Class Initialized
INFO - 2018-06-23 05:45:07 --> Language Class Initialized
ERROR - 2018-06-23 05:45:07 --> 404 Page Not Found: /index
INFO - 2018-06-23 05:45:15 --> Config Class Initialized
INFO - 2018-06-23 05:45:15 --> Hooks Class Initialized
DEBUG - 2018-06-23 05:45:15 --> UTF-8 Support Enabled
INFO - 2018-06-23 05:45:15 --> Utf8 Class Initialized
INFO - 2018-06-23 05:45:15 --> URI Class Initialized
INFO - 2018-06-23 05:45:15 --> Router Class Initialized
INFO - 2018-06-23 05:45:15 --> Output Class Initialized
INFO - 2018-06-23 05:45:15 --> Security Class Initialized
DEBUG - 2018-06-23 05:45:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 05:45:15 --> Input Class Initialized
INFO - 2018-06-23 05:45:15 --> Language Class Initialized
INFO - 2018-06-23 05:45:15 --> Language Class Initialized
INFO - 2018-06-23 05:45:15 --> Config Class Initialized
INFO - 2018-06-23 05:45:15 --> Loader Class Initialized
DEBUG - 2018-06-23 05:45:15 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-23 05:45:15 --> Helper loaded: url_helper
INFO - 2018-06-23 05:45:15 --> Helper loaded: form_helper
INFO - 2018-06-23 05:45:15 --> Helper loaded: date_helper
INFO - 2018-06-23 05:45:15 --> Helper loaded: util_helper
INFO - 2018-06-23 05:45:15 --> Helper loaded: text_helper
INFO - 2018-06-23 05:45:15 --> Helper loaded: string_helper
INFO - 2018-06-23 05:45:15 --> Database Driver Class Initialized
DEBUG - 2018-06-23 05:45:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-23 05:45:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-23 05:45:15 --> Email Class Initialized
INFO - 2018-06-23 05:45:15 --> Controller Class Initialized
DEBUG - 2018-06-23 05:45:15 --> Home MX_Controller Initialized
DEBUG - 2018-06-23 05:45:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-23 05:45:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-23 05:45:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-23 05:45:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-23 05:45:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-23 05:45:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-23 05:45:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/search_page.php
INFO - 2018-06-23 05:45:15 --> Final output sent to browser
DEBUG - 2018-06-23 05:45:15 --> Total execution time: 0.4047
INFO - 2018-06-23 05:45:15 --> Config Class Initialized
INFO - 2018-06-23 05:45:15 --> Hooks Class Initialized
DEBUG - 2018-06-23 05:45:15 --> UTF-8 Support Enabled
INFO - 2018-06-23 05:45:15 --> Utf8 Class Initialized
INFO - 2018-06-23 05:45:15 --> URI Class Initialized
INFO - 2018-06-23 05:45:15 --> Router Class Initialized
INFO - 2018-06-23 05:45:16 --> Output Class Initialized
INFO - 2018-06-23 05:45:16 --> Security Class Initialized
DEBUG - 2018-06-23 05:45:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 05:45:16 --> Input Class Initialized
INFO - 2018-06-23 05:45:16 --> Language Class Initialized
ERROR - 2018-06-23 05:45:16 --> 404 Page Not Found: /index
INFO - 2018-06-23 05:45:16 --> Config Class Initialized
INFO - 2018-06-23 05:45:16 --> Hooks Class Initialized
DEBUG - 2018-06-23 05:45:16 --> UTF-8 Support Enabled
INFO - 2018-06-23 05:45:16 --> Utf8 Class Initialized
INFO - 2018-06-23 05:45:16 --> URI Class Initialized
INFO - 2018-06-23 05:45:16 --> Router Class Initialized
INFO - 2018-06-23 05:45:16 --> Output Class Initialized
INFO - 2018-06-23 05:45:16 --> Security Class Initialized
DEBUG - 2018-06-23 05:45:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 05:45:16 --> Input Class Initialized
INFO - 2018-06-23 05:45:16 --> Language Class Initialized
ERROR - 2018-06-23 05:45:16 --> 404 Page Not Found: /index
INFO - 2018-06-23 05:45:16 --> Config Class Initialized
INFO - 2018-06-23 05:45:16 --> Hooks Class Initialized
DEBUG - 2018-06-23 05:45:16 --> UTF-8 Support Enabled
INFO - 2018-06-23 05:45:16 --> Utf8 Class Initialized
INFO - 2018-06-23 05:45:16 --> URI Class Initialized
INFO - 2018-06-23 05:45:16 --> Router Class Initialized
INFO - 2018-06-23 05:45:16 --> Output Class Initialized
INFO - 2018-06-23 05:45:16 --> Security Class Initialized
DEBUG - 2018-06-23 05:45:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 05:45:16 --> Input Class Initialized
INFO - 2018-06-23 05:45:16 --> Language Class Initialized
ERROR - 2018-06-23 05:45:16 --> 404 Page Not Found: /index
INFO - 2018-06-23 05:46:13 --> Config Class Initialized
INFO - 2018-06-23 05:46:13 --> Hooks Class Initialized
DEBUG - 2018-06-23 05:46:13 --> UTF-8 Support Enabled
INFO - 2018-06-23 05:46:13 --> Utf8 Class Initialized
INFO - 2018-06-23 05:46:13 --> URI Class Initialized
INFO - 2018-06-23 05:46:13 --> Router Class Initialized
INFO - 2018-06-23 05:46:13 --> Output Class Initialized
INFO - 2018-06-23 05:46:13 --> Security Class Initialized
DEBUG - 2018-06-23 05:46:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 05:46:13 --> Input Class Initialized
INFO - 2018-06-23 05:46:13 --> Language Class Initialized
INFO - 2018-06-23 05:46:13 --> Language Class Initialized
INFO - 2018-06-23 05:46:13 --> Config Class Initialized
INFO - 2018-06-23 05:46:13 --> Loader Class Initialized
DEBUG - 2018-06-23 05:46:13 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-23 05:46:13 --> Helper loaded: url_helper
INFO - 2018-06-23 05:46:13 --> Helper loaded: form_helper
INFO - 2018-06-23 05:46:13 --> Helper loaded: date_helper
INFO - 2018-06-23 05:46:13 --> Helper loaded: util_helper
INFO - 2018-06-23 05:46:13 --> Helper loaded: text_helper
INFO - 2018-06-23 05:46:13 --> Helper loaded: string_helper
INFO - 2018-06-23 05:46:13 --> Database Driver Class Initialized
DEBUG - 2018-06-23 05:46:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-23 05:46:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-23 05:46:13 --> Email Class Initialized
INFO - 2018-06-23 05:46:13 --> Controller Class Initialized
DEBUG - 2018-06-23 05:46:13 --> Home MX_Controller Initialized
DEBUG - 2018-06-23 05:46:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-23 05:46:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-23 05:46:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-23 05:46:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-23 05:46:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-23 05:46:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-23 05:46:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/search_page.php
INFO - 2018-06-23 05:46:14 --> Final output sent to browser
DEBUG - 2018-06-23 05:46:14 --> Total execution time: 0.4716
INFO - 2018-06-23 05:46:14 --> Config Class Initialized
INFO - 2018-06-23 05:46:14 --> Hooks Class Initialized
DEBUG - 2018-06-23 05:46:14 --> UTF-8 Support Enabled
INFO - 2018-06-23 05:46:14 --> Utf8 Class Initialized
INFO - 2018-06-23 05:46:14 --> URI Class Initialized
INFO - 2018-06-23 05:46:14 --> Router Class Initialized
INFO - 2018-06-23 05:46:14 --> Output Class Initialized
INFO - 2018-06-23 05:46:14 --> Security Class Initialized
DEBUG - 2018-06-23 05:46:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 05:46:14 --> Input Class Initialized
INFO - 2018-06-23 05:46:15 --> Language Class Initialized
ERROR - 2018-06-23 05:46:15 --> 404 Page Not Found: /index
INFO - 2018-06-23 05:46:15 --> Config Class Initialized
INFO - 2018-06-23 05:46:15 --> Hooks Class Initialized
DEBUG - 2018-06-23 05:46:15 --> UTF-8 Support Enabled
INFO - 2018-06-23 05:46:15 --> Utf8 Class Initialized
INFO - 2018-06-23 05:46:15 --> URI Class Initialized
INFO - 2018-06-23 05:46:15 --> Router Class Initialized
INFO - 2018-06-23 05:46:15 --> Output Class Initialized
INFO - 2018-06-23 05:46:15 --> Security Class Initialized
DEBUG - 2018-06-23 05:46:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 05:46:15 --> Input Class Initialized
INFO - 2018-06-23 05:46:15 --> Language Class Initialized
ERROR - 2018-06-23 05:46:15 --> 404 Page Not Found: /index
INFO - 2018-06-23 05:46:15 --> Config Class Initialized
INFO - 2018-06-23 05:46:15 --> Hooks Class Initialized
DEBUG - 2018-06-23 05:46:15 --> UTF-8 Support Enabled
INFO - 2018-06-23 05:46:15 --> Utf8 Class Initialized
INFO - 2018-06-23 05:46:15 --> URI Class Initialized
INFO - 2018-06-23 05:46:15 --> Router Class Initialized
INFO - 2018-06-23 05:46:15 --> Output Class Initialized
INFO - 2018-06-23 05:46:15 --> Security Class Initialized
DEBUG - 2018-06-23 05:46:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 05:46:15 --> Input Class Initialized
INFO - 2018-06-23 05:46:15 --> Language Class Initialized
ERROR - 2018-06-23 05:46:15 --> 404 Page Not Found: /index
INFO - 2018-06-23 05:46:15 --> Config Class Initialized
INFO - 2018-06-23 05:46:15 --> Hooks Class Initialized
DEBUG - 2018-06-23 05:46:15 --> UTF-8 Support Enabled
INFO - 2018-06-23 05:46:15 --> Utf8 Class Initialized
INFO - 2018-06-23 05:46:15 --> URI Class Initialized
INFO - 2018-06-23 05:46:15 --> Router Class Initialized
INFO - 2018-06-23 05:46:15 --> Output Class Initialized
INFO - 2018-06-23 05:46:15 --> Security Class Initialized
DEBUG - 2018-06-23 05:46:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 05:46:15 --> Input Class Initialized
INFO - 2018-06-23 05:46:15 --> Language Class Initialized
ERROR - 2018-06-23 05:46:15 --> 404 Page Not Found: /index
INFO - 2018-06-23 05:46:15 --> Config Class Initialized
INFO - 2018-06-23 05:46:15 --> Hooks Class Initialized
DEBUG - 2018-06-23 05:46:15 --> UTF-8 Support Enabled
INFO - 2018-06-23 05:46:15 --> Utf8 Class Initialized
INFO - 2018-06-23 05:46:15 --> URI Class Initialized
INFO - 2018-06-23 05:46:15 --> Router Class Initialized
INFO - 2018-06-23 05:46:15 --> Output Class Initialized
INFO - 2018-06-23 05:46:15 --> Security Class Initialized
DEBUG - 2018-06-23 05:46:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 05:46:15 --> Input Class Initialized
INFO - 2018-06-23 05:46:15 --> Language Class Initialized
ERROR - 2018-06-23 05:46:15 --> 404 Page Not Found: /index
INFO - 2018-06-23 05:46:15 --> Config Class Initialized
INFO - 2018-06-23 05:46:15 --> Hooks Class Initialized
DEBUG - 2018-06-23 05:46:15 --> UTF-8 Support Enabled
INFO - 2018-06-23 05:46:15 --> Utf8 Class Initialized
INFO - 2018-06-23 05:46:15 --> URI Class Initialized
INFO - 2018-06-23 05:46:15 --> Router Class Initialized
INFO - 2018-06-23 05:46:15 --> Output Class Initialized
INFO - 2018-06-23 05:46:15 --> Security Class Initialized
DEBUG - 2018-06-23 05:46:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 05:46:15 --> Input Class Initialized
INFO - 2018-06-23 05:46:15 --> Language Class Initialized
ERROR - 2018-06-23 05:46:15 --> 404 Page Not Found: /index
INFO - 2018-06-23 05:47:40 --> Config Class Initialized
INFO - 2018-06-23 05:47:40 --> Hooks Class Initialized
DEBUG - 2018-06-23 05:47:40 --> UTF-8 Support Enabled
INFO - 2018-06-23 05:47:40 --> Utf8 Class Initialized
INFO - 2018-06-23 05:47:40 --> URI Class Initialized
INFO - 2018-06-23 05:47:40 --> Router Class Initialized
INFO - 2018-06-23 05:47:40 --> Output Class Initialized
INFO - 2018-06-23 05:47:40 --> Security Class Initialized
DEBUG - 2018-06-23 05:47:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 05:47:40 --> Input Class Initialized
INFO - 2018-06-23 05:47:40 --> Language Class Initialized
INFO - 2018-06-23 05:47:40 --> Language Class Initialized
INFO - 2018-06-23 05:47:40 --> Config Class Initialized
INFO - 2018-06-23 05:47:40 --> Loader Class Initialized
DEBUG - 2018-06-23 05:47:40 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-23 05:47:40 --> Helper loaded: url_helper
INFO - 2018-06-23 05:47:40 --> Helper loaded: form_helper
INFO - 2018-06-23 05:47:40 --> Helper loaded: date_helper
INFO - 2018-06-23 05:47:40 --> Helper loaded: util_helper
INFO - 2018-06-23 05:47:40 --> Helper loaded: text_helper
INFO - 2018-06-23 05:47:40 --> Helper loaded: string_helper
INFO - 2018-06-23 05:47:40 --> Database Driver Class Initialized
DEBUG - 2018-06-23 05:47:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-23 05:47:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-23 05:47:40 --> Email Class Initialized
INFO - 2018-06-23 05:47:40 --> Controller Class Initialized
DEBUG - 2018-06-23 05:47:40 --> Home MX_Controller Initialized
DEBUG - 2018-06-23 05:47:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-23 05:47:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-23 05:47:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-23 05:47:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-23 05:47:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-23 05:47:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-23 05:47:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/search_page.php
INFO - 2018-06-23 05:47:40 --> Final output sent to browser
DEBUG - 2018-06-23 05:47:40 --> Total execution time: 0.4041
INFO - 2018-06-23 05:47:41 --> Config Class Initialized
INFO - 2018-06-23 05:47:41 --> Hooks Class Initialized
DEBUG - 2018-06-23 05:47:41 --> UTF-8 Support Enabled
INFO - 2018-06-23 05:47:41 --> Utf8 Class Initialized
INFO - 2018-06-23 05:47:41 --> URI Class Initialized
INFO - 2018-06-23 05:47:41 --> Router Class Initialized
INFO - 2018-06-23 05:47:41 --> Output Class Initialized
INFO - 2018-06-23 05:47:41 --> Security Class Initialized
DEBUG - 2018-06-23 05:47:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 05:47:41 --> Input Class Initialized
INFO - 2018-06-23 05:47:41 --> Language Class Initialized
ERROR - 2018-06-23 05:47:41 --> 404 Page Not Found: /index
INFO - 2018-06-23 05:47:41 --> Config Class Initialized
INFO - 2018-06-23 05:47:41 --> Hooks Class Initialized
DEBUG - 2018-06-23 05:47:41 --> UTF-8 Support Enabled
INFO - 2018-06-23 05:47:41 --> Utf8 Class Initialized
INFO - 2018-06-23 05:47:41 --> URI Class Initialized
INFO - 2018-06-23 05:47:41 --> Router Class Initialized
INFO - 2018-06-23 05:47:41 --> Output Class Initialized
INFO - 2018-06-23 05:47:41 --> Security Class Initialized
DEBUG - 2018-06-23 05:47:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 05:47:41 --> Input Class Initialized
INFO - 2018-06-23 05:47:41 --> Language Class Initialized
ERROR - 2018-06-23 05:47:41 --> 404 Page Not Found: /index
INFO - 2018-06-23 05:47:41 --> Config Class Initialized
INFO - 2018-06-23 05:47:41 --> Hooks Class Initialized
DEBUG - 2018-06-23 05:47:41 --> UTF-8 Support Enabled
INFO - 2018-06-23 05:47:41 --> Utf8 Class Initialized
INFO - 2018-06-23 05:47:41 --> URI Class Initialized
INFO - 2018-06-23 05:47:41 --> Router Class Initialized
INFO - 2018-06-23 05:47:41 --> Output Class Initialized
INFO - 2018-06-23 05:47:41 --> Security Class Initialized
DEBUG - 2018-06-23 05:47:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 05:47:41 --> Input Class Initialized
INFO - 2018-06-23 05:47:42 --> Language Class Initialized
ERROR - 2018-06-23 05:47:42 --> 404 Page Not Found: /index
INFO - 2018-06-23 05:47:42 --> Config Class Initialized
INFO - 2018-06-23 05:47:42 --> Hooks Class Initialized
DEBUG - 2018-06-23 05:47:42 --> UTF-8 Support Enabled
INFO - 2018-06-23 05:47:42 --> Utf8 Class Initialized
INFO - 2018-06-23 05:47:42 --> URI Class Initialized
INFO - 2018-06-23 05:47:42 --> Router Class Initialized
INFO - 2018-06-23 05:47:42 --> Output Class Initialized
INFO - 2018-06-23 05:47:42 --> Security Class Initialized
DEBUG - 2018-06-23 05:47:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 05:47:42 --> Input Class Initialized
INFO - 2018-06-23 05:47:42 --> Language Class Initialized
ERROR - 2018-06-23 05:47:42 --> 404 Page Not Found: /index
INFO - 2018-06-23 05:47:42 --> Config Class Initialized
INFO - 2018-06-23 05:47:42 --> Hooks Class Initialized
DEBUG - 2018-06-23 05:47:42 --> UTF-8 Support Enabled
INFO - 2018-06-23 05:47:42 --> Utf8 Class Initialized
INFO - 2018-06-23 05:47:42 --> URI Class Initialized
INFO - 2018-06-23 05:47:42 --> Router Class Initialized
INFO - 2018-06-23 05:47:42 --> Output Class Initialized
INFO - 2018-06-23 05:47:42 --> Security Class Initialized
DEBUG - 2018-06-23 05:47:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 05:47:42 --> Input Class Initialized
INFO - 2018-06-23 05:47:42 --> Language Class Initialized
ERROR - 2018-06-23 05:47:42 --> 404 Page Not Found: /index
INFO - 2018-06-23 05:47:42 --> Config Class Initialized
INFO - 2018-06-23 05:47:42 --> Hooks Class Initialized
DEBUG - 2018-06-23 05:47:42 --> UTF-8 Support Enabled
INFO - 2018-06-23 05:47:42 --> Utf8 Class Initialized
INFO - 2018-06-23 05:47:42 --> URI Class Initialized
INFO - 2018-06-23 05:47:42 --> Router Class Initialized
INFO - 2018-06-23 05:47:42 --> Output Class Initialized
INFO - 2018-06-23 05:47:42 --> Security Class Initialized
DEBUG - 2018-06-23 05:47:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 05:47:42 --> Input Class Initialized
INFO - 2018-06-23 05:47:42 --> Language Class Initialized
ERROR - 2018-06-23 05:47:42 --> 404 Page Not Found: /index
INFO - 2018-06-23 05:50:11 --> Config Class Initialized
INFO - 2018-06-23 05:50:11 --> Hooks Class Initialized
DEBUG - 2018-06-23 05:50:11 --> UTF-8 Support Enabled
INFO - 2018-06-23 05:50:11 --> Utf8 Class Initialized
INFO - 2018-06-23 05:50:11 --> URI Class Initialized
INFO - 2018-06-23 05:50:11 --> Router Class Initialized
INFO - 2018-06-23 05:50:11 --> Output Class Initialized
INFO - 2018-06-23 05:50:11 --> Security Class Initialized
DEBUG - 2018-06-23 05:50:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 05:50:11 --> Input Class Initialized
INFO - 2018-06-23 05:50:11 --> Language Class Initialized
INFO - 2018-06-23 05:50:11 --> Language Class Initialized
INFO - 2018-06-23 05:50:11 --> Config Class Initialized
INFO - 2018-06-23 05:50:11 --> Loader Class Initialized
DEBUG - 2018-06-23 05:50:11 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-23 05:50:11 --> Helper loaded: url_helper
INFO - 2018-06-23 05:50:11 --> Helper loaded: form_helper
INFO - 2018-06-23 05:50:11 --> Helper loaded: date_helper
INFO - 2018-06-23 05:50:11 --> Helper loaded: util_helper
INFO - 2018-06-23 05:50:11 --> Helper loaded: text_helper
INFO - 2018-06-23 05:50:11 --> Helper loaded: string_helper
INFO - 2018-06-23 05:50:11 --> Database Driver Class Initialized
DEBUG - 2018-06-23 05:50:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-23 05:50:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-23 05:50:11 --> Email Class Initialized
INFO - 2018-06-23 05:50:11 --> Controller Class Initialized
DEBUG - 2018-06-23 05:50:11 --> Home MX_Controller Initialized
DEBUG - 2018-06-23 05:50:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-23 05:50:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-23 05:50:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-23 05:50:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-23 05:50:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-23 05:50:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-23 05:50:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/search_page.php
INFO - 2018-06-23 05:50:12 --> Final output sent to browser
DEBUG - 2018-06-23 05:50:12 --> Total execution time: 0.4276
INFO - 2018-06-23 05:50:13 --> Config Class Initialized
INFO - 2018-06-23 05:50:13 --> Hooks Class Initialized
DEBUG - 2018-06-23 05:50:13 --> UTF-8 Support Enabled
INFO - 2018-06-23 05:50:13 --> Utf8 Class Initialized
INFO - 2018-06-23 05:50:13 --> URI Class Initialized
INFO - 2018-06-23 05:50:13 --> Router Class Initialized
INFO - 2018-06-23 05:50:13 --> Output Class Initialized
INFO - 2018-06-23 05:50:13 --> Security Class Initialized
DEBUG - 2018-06-23 05:50:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 05:50:13 --> Input Class Initialized
INFO - 2018-06-23 05:50:13 --> Language Class Initialized
ERROR - 2018-06-23 05:50:13 --> 404 Page Not Found: /index
INFO - 2018-06-23 05:50:13 --> Config Class Initialized
INFO - 2018-06-23 05:50:13 --> Hooks Class Initialized
DEBUG - 2018-06-23 05:50:13 --> UTF-8 Support Enabled
INFO - 2018-06-23 05:50:13 --> Utf8 Class Initialized
INFO - 2018-06-23 05:50:13 --> URI Class Initialized
INFO - 2018-06-23 05:50:14 --> Router Class Initialized
INFO - 2018-06-23 05:50:14 --> Output Class Initialized
INFO - 2018-06-23 05:50:14 --> Security Class Initialized
DEBUG - 2018-06-23 05:50:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 05:50:14 --> Input Class Initialized
INFO - 2018-06-23 05:50:14 --> Language Class Initialized
ERROR - 2018-06-23 05:50:14 --> 404 Page Not Found: /index
INFO - 2018-06-23 05:50:14 --> Config Class Initialized
INFO - 2018-06-23 05:50:14 --> Hooks Class Initialized
DEBUG - 2018-06-23 05:50:14 --> UTF-8 Support Enabled
INFO - 2018-06-23 05:50:14 --> Utf8 Class Initialized
INFO - 2018-06-23 05:50:14 --> URI Class Initialized
INFO - 2018-06-23 05:50:14 --> Router Class Initialized
INFO - 2018-06-23 05:50:14 --> Output Class Initialized
INFO - 2018-06-23 05:50:14 --> Security Class Initialized
DEBUG - 2018-06-23 05:50:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 05:50:14 --> Input Class Initialized
INFO - 2018-06-23 05:50:14 --> Language Class Initialized
ERROR - 2018-06-23 05:50:14 --> 404 Page Not Found: /index
INFO - 2018-06-23 05:50:14 --> Config Class Initialized
INFO - 2018-06-23 05:50:14 --> Hooks Class Initialized
DEBUG - 2018-06-23 05:50:14 --> UTF-8 Support Enabled
INFO - 2018-06-23 05:50:14 --> Utf8 Class Initialized
INFO - 2018-06-23 05:50:14 --> URI Class Initialized
INFO - 2018-06-23 05:50:14 --> Router Class Initialized
INFO - 2018-06-23 05:50:14 --> Output Class Initialized
INFO - 2018-06-23 05:50:14 --> Security Class Initialized
DEBUG - 2018-06-23 05:50:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 05:50:14 --> Input Class Initialized
INFO - 2018-06-23 05:50:14 --> Language Class Initialized
ERROR - 2018-06-23 05:50:14 --> 404 Page Not Found: /index
INFO - 2018-06-23 05:50:14 --> Config Class Initialized
INFO - 2018-06-23 05:50:14 --> Hooks Class Initialized
DEBUG - 2018-06-23 05:50:14 --> UTF-8 Support Enabled
INFO - 2018-06-23 05:50:14 --> Utf8 Class Initialized
INFO - 2018-06-23 05:50:14 --> URI Class Initialized
INFO - 2018-06-23 05:50:14 --> Router Class Initialized
INFO - 2018-06-23 05:50:14 --> Output Class Initialized
INFO - 2018-06-23 05:50:14 --> Security Class Initialized
DEBUG - 2018-06-23 05:50:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 05:50:14 --> Input Class Initialized
INFO - 2018-06-23 05:50:14 --> Language Class Initialized
ERROR - 2018-06-23 05:50:14 --> 404 Page Not Found: /index
INFO - 2018-06-23 05:50:14 --> Config Class Initialized
INFO - 2018-06-23 05:50:14 --> Hooks Class Initialized
DEBUG - 2018-06-23 05:50:14 --> UTF-8 Support Enabled
INFO - 2018-06-23 05:50:14 --> Utf8 Class Initialized
INFO - 2018-06-23 05:50:14 --> URI Class Initialized
INFO - 2018-06-23 05:50:14 --> Router Class Initialized
INFO - 2018-06-23 05:50:14 --> Output Class Initialized
INFO - 2018-06-23 05:50:14 --> Security Class Initialized
DEBUG - 2018-06-23 05:50:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 05:50:15 --> Input Class Initialized
INFO - 2018-06-23 05:50:15 --> Language Class Initialized
ERROR - 2018-06-23 05:50:15 --> 404 Page Not Found: /index
INFO - 2018-06-23 05:51:15 --> Config Class Initialized
INFO - 2018-06-23 05:51:15 --> Hooks Class Initialized
DEBUG - 2018-06-23 05:51:15 --> UTF-8 Support Enabled
INFO - 2018-06-23 05:51:15 --> Utf8 Class Initialized
INFO - 2018-06-23 05:51:15 --> URI Class Initialized
INFO - 2018-06-23 05:51:15 --> Router Class Initialized
INFO - 2018-06-23 05:51:15 --> Output Class Initialized
INFO - 2018-06-23 05:51:15 --> Security Class Initialized
DEBUG - 2018-06-23 05:51:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 05:51:15 --> Input Class Initialized
INFO - 2018-06-23 05:51:15 --> Language Class Initialized
INFO - 2018-06-23 05:51:15 --> Language Class Initialized
INFO - 2018-06-23 05:51:15 --> Config Class Initialized
INFO - 2018-06-23 05:51:15 --> Loader Class Initialized
DEBUG - 2018-06-23 05:51:15 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-23 05:51:15 --> Helper loaded: url_helper
INFO - 2018-06-23 05:51:15 --> Helper loaded: form_helper
INFO - 2018-06-23 05:51:15 --> Helper loaded: date_helper
INFO - 2018-06-23 05:51:15 --> Helper loaded: util_helper
INFO - 2018-06-23 05:51:15 --> Helper loaded: text_helper
INFO - 2018-06-23 05:51:15 --> Helper loaded: string_helper
INFO - 2018-06-23 05:51:15 --> Database Driver Class Initialized
DEBUG - 2018-06-23 05:51:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-23 05:51:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-23 05:51:15 --> Email Class Initialized
INFO - 2018-06-23 05:51:15 --> Controller Class Initialized
DEBUG - 2018-06-23 05:51:15 --> Home MX_Controller Initialized
DEBUG - 2018-06-23 05:51:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-23 05:51:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-23 05:51:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-23 05:51:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-23 05:51:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-23 05:51:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-23 05:51:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/search_page.php
INFO - 2018-06-23 05:51:15 --> Final output sent to browser
DEBUG - 2018-06-23 05:51:15 --> Total execution time: 0.4134
INFO - 2018-06-23 05:51:16 --> Config Class Initialized
INFO - 2018-06-23 05:51:16 --> Hooks Class Initialized
DEBUG - 2018-06-23 05:51:16 --> UTF-8 Support Enabled
INFO - 2018-06-23 05:51:16 --> Utf8 Class Initialized
INFO - 2018-06-23 05:51:17 --> URI Class Initialized
INFO - 2018-06-23 05:51:17 --> Router Class Initialized
INFO - 2018-06-23 05:51:17 --> Output Class Initialized
INFO - 2018-06-23 05:51:17 --> Security Class Initialized
DEBUG - 2018-06-23 05:51:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 05:51:17 --> Input Class Initialized
INFO - 2018-06-23 05:51:17 --> Language Class Initialized
ERROR - 2018-06-23 05:51:17 --> 404 Page Not Found: /index
INFO - 2018-06-23 05:51:17 --> Config Class Initialized
INFO - 2018-06-23 05:51:17 --> Hooks Class Initialized
DEBUG - 2018-06-23 05:51:17 --> UTF-8 Support Enabled
INFO - 2018-06-23 05:51:17 --> Utf8 Class Initialized
INFO - 2018-06-23 05:51:17 --> URI Class Initialized
INFO - 2018-06-23 05:51:17 --> Router Class Initialized
INFO - 2018-06-23 05:51:17 --> Output Class Initialized
INFO - 2018-06-23 05:51:17 --> Security Class Initialized
DEBUG - 2018-06-23 05:51:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 05:51:17 --> Input Class Initialized
INFO - 2018-06-23 05:51:17 --> Language Class Initialized
ERROR - 2018-06-23 05:51:17 --> 404 Page Not Found: /index
INFO - 2018-06-23 05:51:17 --> Config Class Initialized
INFO - 2018-06-23 05:51:17 --> Hooks Class Initialized
DEBUG - 2018-06-23 05:51:17 --> UTF-8 Support Enabled
INFO - 2018-06-23 05:51:17 --> Utf8 Class Initialized
INFO - 2018-06-23 05:51:17 --> URI Class Initialized
INFO - 2018-06-23 05:51:17 --> Router Class Initialized
INFO - 2018-06-23 05:51:17 --> Output Class Initialized
INFO - 2018-06-23 05:51:17 --> Security Class Initialized
DEBUG - 2018-06-23 05:51:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 05:51:17 --> Input Class Initialized
INFO - 2018-06-23 05:51:17 --> Language Class Initialized
ERROR - 2018-06-23 05:51:17 --> 404 Page Not Found: /index
INFO - 2018-06-23 05:51:17 --> Config Class Initialized
INFO - 2018-06-23 05:51:17 --> Hooks Class Initialized
DEBUG - 2018-06-23 05:51:17 --> UTF-8 Support Enabled
INFO - 2018-06-23 05:51:17 --> Utf8 Class Initialized
INFO - 2018-06-23 05:51:17 --> URI Class Initialized
INFO - 2018-06-23 05:51:17 --> Router Class Initialized
INFO - 2018-06-23 05:51:17 --> Output Class Initialized
INFO - 2018-06-23 05:51:17 --> Security Class Initialized
DEBUG - 2018-06-23 05:51:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 05:51:17 --> Input Class Initialized
INFO - 2018-06-23 05:51:17 --> Language Class Initialized
ERROR - 2018-06-23 05:51:17 --> 404 Page Not Found: /index
INFO - 2018-06-23 05:51:17 --> Config Class Initialized
INFO - 2018-06-23 05:51:17 --> Hooks Class Initialized
DEBUG - 2018-06-23 05:51:17 --> UTF-8 Support Enabled
INFO - 2018-06-23 05:51:17 --> Utf8 Class Initialized
INFO - 2018-06-23 05:51:17 --> URI Class Initialized
INFO - 2018-06-23 05:51:17 --> Router Class Initialized
INFO - 2018-06-23 05:51:17 --> Output Class Initialized
INFO - 2018-06-23 05:51:17 --> Security Class Initialized
DEBUG - 2018-06-23 05:51:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 05:51:17 --> Input Class Initialized
INFO - 2018-06-23 05:51:17 --> Language Class Initialized
ERROR - 2018-06-23 05:51:17 --> 404 Page Not Found: /index
INFO - 2018-06-23 05:51:17 --> Config Class Initialized
INFO - 2018-06-23 05:51:17 --> Hooks Class Initialized
DEBUG - 2018-06-23 05:51:17 --> UTF-8 Support Enabled
INFO - 2018-06-23 05:51:17 --> Utf8 Class Initialized
INFO - 2018-06-23 05:51:17 --> URI Class Initialized
INFO - 2018-06-23 05:51:17 --> Router Class Initialized
INFO - 2018-06-23 05:51:17 --> Output Class Initialized
INFO - 2018-06-23 05:51:17 --> Security Class Initialized
DEBUG - 2018-06-23 05:51:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 05:51:17 --> Input Class Initialized
INFO - 2018-06-23 05:51:17 --> Language Class Initialized
ERROR - 2018-06-23 05:51:17 --> 404 Page Not Found: /index
INFO - 2018-06-23 05:51:44 --> Config Class Initialized
INFO - 2018-06-23 05:51:44 --> Hooks Class Initialized
DEBUG - 2018-06-23 05:51:44 --> UTF-8 Support Enabled
INFO - 2018-06-23 05:51:44 --> Utf8 Class Initialized
INFO - 2018-06-23 05:51:44 --> URI Class Initialized
INFO - 2018-06-23 05:51:44 --> Router Class Initialized
INFO - 2018-06-23 05:51:44 --> Output Class Initialized
INFO - 2018-06-23 05:51:44 --> Security Class Initialized
DEBUG - 2018-06-23 05:51:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 05:51:44 --> Input Class Initialized
INFO - 2018-06-23 05:51:44 --> Language Class Initialized
INFO - 2018-06-23 05:51:44 --> Language Class Initialized
INFO - 2018-06-23 05:51:44 --> Config Class Initialized
INFO - 2018-06-23 05:51:44 --> Loader Class Initialized
DEBUG - 2018-06-23 05:51:44 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-23 05:51:44 --> Helper loaded: url_helper
INFO - 2018-06-23 05:51:44 --> Helper loaded: form_helper
INFO - 2018-06-23 05:51:44 --> Helper loaded: date_helper
INFO - 2018-06-23 05:51:44 --> Helper loaded: util_helper
INFO - 2018-06-23 05:51:44 --> Helper loaded: text_helper
INFO - 2018-06-23 05:51:44 --> Helper loaded: string_helper
INFO - 2018-06-23 05:51:44 --> Database Driver Class Initialized
DEBUG - 2018-06-23 05:51:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-23 05:51:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-23 05:51:44 --> Email Class Initialized
INFO - 2018-06-23 05:51:44 --> Controller Class Initialized
DEBUG - 2018-06-23 05:51:44 --> Home MX_Controller Initialized
DEBUG - 2018-06-23 05:51:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-23 05:51:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-23 05:51:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-23 05:51:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-23 05:51:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-23 05:51:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-23 05:51:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/search_page.php
INFO - 2018-06-23 05:51:44 --> Final output sent to browser
DEBUG - 2018-06-23 05:51:44 --> Total execution time: 0.4169
INFO - 2018-06-23 05:51:45 --> Config Class Initialized
INFO - 2018-06-23 05:51:45 --> Hooks Class Initialized
DEBUG - 2018-06-23 05:51:45 --> UTF-8 Support Enabled
INFO - 2018-06-23 05:51:45 --> Utf8 Class Initialized
INFO - 2018-06-23 05:51:45 --> URI Class Initialized
INFO - 2018-06-23 05:51:45 --> Router Class Initialized
INFO - 2018-06-23 05:51:45 --> Output Class Initialized
INFO - 2018-06-23 05:51:45 --> Security Class Initialized
DEBUG - 2018-06-23 05:51:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 05:51:45 --> Input Class Initialized
INFO - 2018-06-23 05:51:45 --> Language Class Initialized
ERROR - 2018-06-23 05:51:45 --> 404 Page Not Found: /index
INFO - 2018-06-23 05:51:45 --> Config Class Initialized
INFO - 2018-06-23 05:51:45 --> Hooks Class Initialized
DEBUG - 2018-06-23 05:51:45 --> UTF-8 Support Enabled
INFO - 2018-06-23 05:51:45 --> Utf8 Class Initialized
INFO - 2018-06-23 05:51:45 --> URI Class Initialized
INFO - 2018-06-23 05:51:45 --> Router Class Initialized
INFO - 2018-06-23 05:51:45 --> Output Class Initialized
INFO - 2018-06-23 05:51:45 --> Security Class Initialized
DEBUG - 2018-06-23 05:51:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 05:51:45 --> Input Class Initialized
INFO - 2018-06-23 05:51:45 --> Language Class Initialized
ERROR - 2018-06-23 05:51:45 --> 404 Page Not Found: /index
INFO - 2018-06-23 05:51:45 --> Config Class Initialized
INFO - 2018-06-23 05:51:45 --> Hooks Class Initialized
DEBUG - 2018-06-23 05:51:45 --> UTF-8 Support Enabled
INFO - 2018-06-23 05:51:45 --> Utf8 Class Initialized
INFO - 2018-06-23 05:51:45 --> URI Class Initialized
INFO - 2018-06-23 05:51:45 --> Router Class Initialized
INFO - 2018-06-23 05:51:45 --> Output Class Initialized
INFO - 2018-06-23 05:51:45 --> Security Class Initialized
DEBUG - 2018-06-23 05:51:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 05:51:45 --> Input Class Initialized
INFO - 2018-06-23 05:51:45 --> Language Class Initialized
ERROR - 2018-06-23 05:51:45 --> 404 Page Not Found: /index
INFO - 2018-06-23 05:51:45 --> Config Class Initialized
INFO - 2018-06-23 05:51:45 --> Hooks Class Initialized
DEBUG - 2018-06-23 05:51:45 --> UTF-8 Support Enabled
INFO - 2018-06-23 05:51:45 --> Utf8 Class Initialized
INFO - 2018-06-23 05:51:45 --> URI Class Initialized
INFO - 2018-06-23 05:51:45 --> Router Class Initialized
INFO - 2018-06-23 05:51:45 --> Output Class Initialized
INFO - 2018-06-23 05:51:45 --> Security Class Initialized
DEBUG - 2018-06-23 05:51:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 05:51:45 --> Input Class Initialized
INFO - 2018-06-23 05:51:45 --> Language Class Initialized
ERROR - 2018-06-23 05:51:45 --> 404 Page Not Found: /index
INFO - 2018-06-23 05:51:45 --> Config Class Initialized
INFO - 2018-06-23 05:51:45 --> Hooks Class Initialized
DEBUG - 2018-06-23 05:51:45 --> UTF-8 Support Enabled
INFO - 2018-06-23 05:51:45 --> Utf8 Class Initialized
INFO - 2018-06-23 05:51:45 --> URI Class Initialized
INFO - 2018-06-23 05:51:45 --> Router Class Initialized
INFO - 2018-06-23 05:51:45 --> Output Class Initialized
INFO - 2018-06-23 05:51:45 --> Security Class Initialized
DEBUG - 2018-06-23 05:51:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 05:51:45 --> Input Class Initialized
INFO - 2018-06-23 05:51:46 --> Language Class Initialized
ERROR - 2018-06-23 05:51:46 --> 404 Page Not Found: /index
INFO - 2018-06-23 05:51:46 --> Config Class Initialized
INFO - 2018-06-23 05:51:46 --> Hooks Class Initialized
DEBUG - 2018-06-23 05:51:46 --> UTF-8 Support Enabled
INFO - 2018-06-23 05:51:46 --> Utf8 Class Initialized
INFO - 2018-06-23 05:51:46 --> URI Class Initialized
INFO - 2018-06-23 05:51:46 --> Router Class Initialized
INFO - 2018-06-23 05:51:46 --> Output Class Initialized
INFO - 2018-06-23 05:51:46 --> Security Class Initialized
DEBUG - 2018-06-23 05:51:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 05:51:46 --> Input Class Initialized
INFO - 2018-06-23 05:51:46 --> Language Class Initialized
ERROR - 2018-06-23 05:51:46 --> 404 Page Not Found: /index
INFO - 2018-06-23 05:51:55 --> Config Class Initialized
INFO - 2018-06-23 05:51:56 --> Hooks Class Initialized
DEBUG - 2018-06-23 05:51:56 --> UTF-8 Support Enabled
INFO - 2018-06-23 05:51:56 --> Utf8 Class Initialized
INFO - 2018-06-23 05:51:56 --> URI Class Initialized
INFO - 2018-06-23 05:51:56 --> Router Class Initialized
INFO - 2018-06-23 05:51:56 --> Output Class Initialized
INFO - 2018-06-23 05:51:56 --> Security Class Initialized
DEBUG - 2018-06-23 05:51:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 05:51:56 --> Input Class Initialized
INFO - 2018-06-23 05:51:56 --> Language Class Initialized
INFO - 2018-06-23 05:51:56 --> Language Class Initialized
INFO - 2018-06-23 05:51:56 --> Config Class Initialized
INFO - 2018-06-23 05:51:56 --> Loader Class Initialized
DEBUG - 2018-06-23 05:51:56 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-23 05:51:56 --> Helper loaded: url_helper
INFO - 2018-06-23 05:51:56 --> Helper loaded: form_helper
INFO - 2018-06-23 05:51:56 --> Helper loaded: date_helper
INFO - 2018-06-23 05:51:56 --> Helper loaded: util_helper
INFO - 2018-06-23 05:51:56 --> Helper loaded: text_helper
INFO - 2018-06-23 05:51:56 --> Helper loaded: string_helper
INFO - 2018-06-23 05:51:56 --> Database Driver Class Initialized
DEBUG - 2018-06-23 05:51:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-23 05:51:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-23 05:51:56 --> Email Class Initialized
INFO - 2018-06-23 05:51:56 --> Controller Class Initialized
DEBUG - 2018-06-23 05:51:56 --> Home MX_Controller Initialized
DEBUG - 2018-06-23 05:51:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-23 05:51:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-23 05:51:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-23 05:51:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-23 05:51:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-23 05:51:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-23 05:51:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/search_page.php
INFO - 2018-06-23 05:51:56 --> Final output sent to browser
DEBUG - 2018-06-23 05:51:56 --> Total execution time: 0.4103
INFO - 2018-06-23 05:51:56 --> Config Class Initialized
INFO - 2018-06-23 05:51:56 --> Hooks Class Initialized
DEBUG - 2018-06-23 05:51:56 --> UTF-8 Support Enabled
INFO - 2018-06-23 05:51:56 --> Utf8 Class Initialized
INFO - 2018-06-23 05:51:56 --> URI Class Initialized
INFO - 2018-06-23 05:51:56 --> Router Class Initialized
INFO - 2018-06-23 05:51:56 --> Output Class Initialized
INFO - 2018-06-23 05:51:56 --> Security Class Initialized
DEBUG - 2018-06-23 05:51:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 05:51:57 --> Input Class Initialized
INFO - 2018-06-23 05:51:57 --> Language Class Initialized
ERROR - 2018-06-23 05:51:57 --> 404 Page Not Found: /index
INFO - 2018-06-23 05:51:57 --> Config Class Initialized
INFO - 2018-06-23 05:51:57 --> Hooks Class Initialized
DEBUG - 2018-06-23 05:51:57 --> UTF-8 Support Enabled
INFO - 2018-06-23 05:51:57 --> Utf8 Class Initialized
INFO - 2018-06-23 05:51:57 --> URI Class Initialized
INFO - 2018-06-23 05:51:57 --> Router Class Initialized
INFO - 2018-06-23 05:51:57 --> Output Class Initialized
INFO - 2018-06-23 05:51:57 --> Security Class Initialized
DEBUG - 2018-06-23 05:51:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 05:51:57 --> Input Class Initialized
INFO - 2018-06-23 05:51:57 --> Language Class Initialized
ERROR - 2018-06-23 05:51:57 --> 404 Page Not Found: /index
INFO - 2018-06-23 05:51:57 --> Config Class Initialized
INFO - 2018-06-23 05:51:57 --> Hooks Class Initialized
DEBUG - 2018-06-23 05:51:57 --> UTF-8 Support Enabled
INFO - 2018-06-23 05:51:57 --> Utf8 Class Initialized
INFO - 2018-06-23 05:51:57 --> URI Class Initialized
INFO - 2018-06-23 05:51:57 --> Router Class Initialized
INFO - 2018-06-23 05:51:57 --> Output Class Initialized
INFO - 2018-06-23 05:51:57 --> Security Class Initialized
DEBUG - 2018-06-23 05:51:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 05:51:57 --> Input Class Initialized
INFO - 2018-06-23 05:51:57 --> Language Class Initialized
ERROR - 2018-06-23 05:51:57 --> 404 Page Not Found: /index
INFO - 2018-06-23 05:51:57 --> Config Class Initialized
INFO - 2018-06-23 05:51:57 --> Hooks Class Initialized
DEBUG - 2018-06-23 05:51:57 --> UTF-8 Support Enabled
INFO - 2018-06-23 05:51:57 --> Utf8 Class Initialized
INFO - 2018-06-23 05:51:57 --> URI Class Initialized
INFO - 2018-06-23 05:51:57 --> Router Class Initialized
INFO - 2018-06-23 05:51:57 --> Output Class Initialized
INFO - 2018-06-23 05:51:57 --> Security Class Initialized
DEBUG - 2018-06-23 05:51:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 05:51:57 --> Input Class Initialized
INFO - 2018-06-23 05:51:57 --> Language Class Initialized
ERROR - 2018-06-23 05:51:57 --> 404 Page Not Found: /index
INFO - 2018-06-23 05:51:57 --> Config Class Initialized
INFO - 2018-06-23 05:51:57 --> Hooks Class Initialized
DEBUG - 2018-06-23 05:51:57 --> UTF-8 Support Enabled
INFO - 2018-06-23 05:51:57 --> Utf8 Class Initialized
INFO - 2018-06-23 05:51:57 --> URI Class Initialized
INFO - 2018-06-23 05:51:57 --> Router Class Initialized
INFO - 2018-06-23 05:51:57 --> Output Class Initialized
INFO - 2018-06-23 05:51:57 --> Security Class Initialized
DEBUG - 2018-06-23 05:51:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 05:51:57 --> Input Class Initialized
INFO - 2018-06-23 05:51:57 --> Language Class Initialized
ERROR - 2018-06-23 05:51:57 --> 404 Page Not Found: /index
INFO - 2018-06-23 05:51:57 --> Config Class Initialized
INFO - 2018-06-23 05:51:57 --> Hooks Class Initialized
DEBUG - 2018-06-23 05:51:57 --> UTF-8 Support Enabled
INFO - 2018-06-23 05:51:57 --> Utf8 Class Initialized
INFO - 2018-06-23 05:51:57 --> URI Class Initialized
INFO - 2018-06-23 05:51:57 --> Router Class Initialized
INFO - 2018-06-23 05:51:57 --> Output Class Initialized
INFO - 2018-06-23 05:51:57 --> Security Class Initialized
DEBUG - 2018-06-23 05:51:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 05:51:57 --> Input Class Initialized
INFO - 2018-06-23 05:51:57 --> Language Class Initialized
ERROR - 2018-06-23 05:51:57 --> 404 Page Not Found: /index
INFO - 2018-06-23 05:52:31 --> Config Class Initialized
INFO - 2018-06-23 05:52:31 --> Hooks Class Initialized
DEBUG - 2018-06-23 05:52:31 --> UTF-8 Support Enabled
INFO - 2018-06-23 05:52:31 --> Utf8 Class Initialized
INFO - 2018-06-23 05:52:31 --> URI Class Initialized
INFO - 2018-06-23 05:52:31 --> Router Class Initialized
INFO - 2018-06-23 05:52:31 --> Output Class Initialized
INFO - 2018-06-23 05:52:31 --> Security Class Initialized
DEBUG - 2018-06-23 05:52:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 05:52:31 --> Input Class Initialized
INFO - 2018-06-23 05:52:31 --> Language Class Initialized
INFO - 2018-06-23 05:52:31 --> Language Class Initialized
INFO - 2018-06-23 05:52:31 --> Config Class Initialized
INFO - 2018-06-23 05:52:31 --> Loader Class Initialized
DEBUG - 2018-06-23 05:52:31 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-23 05:52:31 --> Helper loaded: url_helper
INFO - 2018-06-23 05:52:31 --> Helper loaded: form_helper
INFO - 2018-06-23 05:52:31 --> Helper loaded: date_helper
INFO - 2018-06-23 05:52:31 --> Helper loaded: util_helper
INFO - 2018-06-23 05:52:31 --> Helper loaded: text_helper
INFO - 2018-06-23 05:52:31 --> Helper loaded: string_helper
INFO - 2018-06-23 05:52:31 --> Database Driver Class Initialized
DEBUG - 2018-06-23 05:52:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-23 05:52:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-23 05:52:31 --> Email Class Initialized
INFO - 2018-06-23 05:52:31 --> Controller Class Initialized
DEBUG - 2018-06-23 05:52:31 --> Home MX_Controller Initialized
DEBUG - 2018-06-23 05:52:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-23 05:52:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-23 05:52:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-23 05:52:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-23 05:52:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-23 05:52:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-23 05:52:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/search_page.php
INFO - 2018-06-23 05:52:31 --> Final output sent to browser
DEBUG - 2018-06-23 05:52:31 --> Total execution time: 0.4251
INFO - 2018-06-23 05:52:32 --> Config Class Initialized
INFO - 2018-06-23 05:52:32 --> Hooks Class Initialized
DEBUG - 2018-06-23 05:52:32 --> UTF-8 Support Enabled
INFO - 2018-06-23 05:52:32 --> Utf8 Class Initialized
INFO - 2018-06-23 05:52:32 --> URI Class Initialized
INFO - 2018-06-23 05:52:32 --> Router Class Initialized
INFO - 2018-06-23 05:52:32 --> Output Class Initialized
INFO - 2018-06-23 05:52:32 --> Security Class Initialized
DEBUG - 2018-06-23 05:52:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 05:52:32 --> Input Class Initialized
INFO - 2018-06-23 05:52:32 --> Language Class Initialized
ERROR - 2018-06-23 05:52:32 --> 404 Page Not Found: /index
INFO - 2018-06-23 05:52:32 --> Config Class Initialized
INFO - 2018-06-23 05:52:32 --> Hooks Class Initialized
DEBUG - 2018-06-23 05:52:32 --> UTF-8 Support Enabled
INFO - 2018-06-23 05:52:32 --> Utf8 Class Initialized
INFO - 2018-06-23 05:52:32 --> URI Class Initialized
INFO - 2018-06-23 05:52:32 --> Router Class Initialized
INFO - 2018-06-23 05:52:32 --> Output Class Initialized
INFO - 2018-06-23 05:52:32 --> Security Class Initialized
DEBUG - 2018-06-23 05:52:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 05:52:32 --> Input Class Initialized
INFO - 2018-06-23 05:52:32 --> Language Class Initialized
ERROR - 2018-06-23 05:52:32 --> 404 Page Not Found: /index
INFO - 2018-06-23 05:52:32 --> Config Class Initialized
INFO - 2018-06-23 05:52:32 --> Hooks Class Initialized
DEBUG - 2018-06-23 05:52:32 --> UTF-8 Support Enabled
INFO - 2018-06-23 05:52:32 --> Utf8 Class Initialized
INFO - 2018-06-23 05:52:32 --> URI Class Initialized
INFO - 2018-06-23 05:52:32 --> Router Class Initialized
INFO - 2018-06-23 05:52:32 --> Output Class Initialized
INFO - 2018-06-23 05:52:32 --> Security Class Initialized
DEBUG - 2018-06-23 05:52:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 05:52:32 --> Input Class Initialized
INFO - 2018-06-23 05:52:32 --> Language Class Initialized
ERROR - 2018-06-23 05:52:32 --> 404 Page Not Found: /index
INFO - 2018-06-23 05:52:32 --> Config Class Initialized
INFO - 2018-06-23 05:52:32 --> Hooks Class Initialized
DEBUG - 2018-06-23 05:52:32 --> UTF-8 Support Enabled
INFO - 2018-06-23 05:52:32 --> Utf8 Class Initialized
INFO - 2018-06-23 05:52:32 --> URI Class Initialized
INFO - 2018-06-23 05:52:32 --> Router Class Initialized
INFO - 2018-06-23 05:52:32 --> Output Class Initialized
INFO - 2018-06-23 05:52:32 --> Security Class Initialized
DEBUG - 2018-06-23 05:52:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 05:52:33 --> Input Class Initialized
INFO - 2018-06-23 05:52:33 --> Language Class Initialized
ERROR - 2018-06-23 05:52:33 --> 404 Page Not Found: /index
INFO - 2018-06-23 05:52:33 --> Config Class Initialized
INFO - 2018-06-23 05:52:33 --> Hooks Class Initialized
DEBUG - 2018-06-23 05:52:33 --> UTF-8 Support Enabled
INFO - 2018-06-23 05:52:33 --> Utf8 Class Initialized
INFO - 2018-06-23 05:52:33 --> URI Class Initialized
INFO - 2018-06-23 05:52:33 --> Router Class Initialized
INFO - 2018-06-23 05:52:33 --> Output Class Initialized
INFO - 2018-06-23 05:52:33 --> Security Class Initialized
DEBUG - 2018-06-23 05:52:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 05:52:33 --> Input Class Initialized
INFO - 2018-06-23 05:52:33 --> Language Class Initialized
ERROR - 2018-06-23 05:52:33 --> 404 Page Not Found: /index
INFO - 2018-06-23 05:52:33 --> Config Class Initialized
INFO - 2018-06-23 05:52:33 --> Hooks Class Initialized
DEBUG - 2018-06-23 05:52:33 --> UTF-8 Support Enabled
INFO - 2018-06-23 05:52:33 --> Utf8 Class Initialized
INFO - 2018-06-23 05:52:33 --> URI Class Initialized
INFO - 2018-06-23 05:52:33 --> Router Class Initialized
INFO - 2018-06-23 05:52:33 --> Output Class Initialized
INFO - 2018-06-23 05:52:33 --> Security Class Initialized
DEBUG - 2018-06-23 05:52:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 05:52:33 --> Input Class Initialized
INFO - 2018-06-23 05:52:33 --> Language Class Initialized
ERROR - 2018-06-23 05:52:33 --> 404 Page Not Found: /index
INFO - 2018-06-23 05:54:00 --> Config Class Initialized
INFO - 2018-06-23 05:54:00 --> Hooks Class Initialized
DEBUG - 2018-06-23 05:54:00 --> UTF-8 Support Enabled
INFO - 2018-06-23 05:54:00 --> Utf8 Class Initialized
INFO - 2018-06-23 05:54:00 --> URI Class Initialized
INFO - 2018-06-23 05:54:00 --> Router Class Initialized
INFO - 2018-06-23 05:54:00 --> Output Class Initialized
INFO - 2018-06-23 05:54:00 --> Security Class Initialized
DEBUG - 2018-06-23 05:54:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 05:54:00 --> Input Class Initialized
INFO - 2018-06-23 05:54:00 --> Language Class Initialized
INFO - 2018-06-23 05:54:00 --> Language Class Initialized
INFO - 2018-06-23 05:54:00 --> Config Class Initialized
INFO - 2018-06-23 05:54:00 --> Loader Class Initialized
DEBUG - 2018-06-23 05:54:00 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-23 05:54:00 --> Helper loaded: url_helper
INFO - 2018-06-23 05:54:00 --> Helper loaded: form_helper
INFO - 2018-06-23 05:54:00 --> Helper loaded: date_helper
INFO - 2018-06-23 05:54:00 --> Helper loaded: util_helper
INFO - 2018-06-23 05:54:00 --> Helper loaded: text_helper
INFO - 2018-06-23 05:54:00 --> Helper loaded: string_helper
INFO - 2018-06-23 05:54:00 --> Database Driver Class Initialized
DEBUG - 2018-06-23 05:54:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-23 05:54:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-23 05:54:00 --> Email Class Initialized
INFO - 2018-06-23 05:54:00 --> Controller Class Initialized
DEBUG - 2018-06-23 05:54:00 --> Home MX_Controller Initialized
DEBUG - 2018-06-23 05:54:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-23 05:54:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-23 05:54:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-23 05:54:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-23 05:54:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-23 05:54:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-23 05:54:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/search_page.php
INFO - 2018-06-23 05:54:00 --> Final output sent to browser
DEBUG - 2018-06-23 05:54:01 --> Total execution time: 0.4304
INFO - 2018-06-23 05:54:01 --> Config Class Initialized
INFO - 2018-06-23 05:54:01 --> Hooks Class Initialized
DEBUG - 2018-06-23 05:54:01 --> UTF-8 Support Enabled
INFO - 2018-06-23 05:54:01 --> Utf8 Class Initialized
INFO - 2018-06-23 05:54:01 --> URI Class Initialized
INFO - 2018-06-23 05:54:01 --> Router Class Initialized
INFO - 2018-06-23 05:54:01 --> Output Class Initialized
INFO - 2018-06-23 05:54:02 --> Security Class Initialized
DEBUG - 2018-06-23 05:54:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 05:54:02 --> Input Class Initialized
INFO - 2018-06-23 05:54:02 --> Language Class Initialized
ERROR - 2018-06-23 05:54:02 --> 404 Page Not Found: /index
INFO - 2018-06-23 05:54:02 --> Config Class Initialized
INFO - 2018-06-23 05:54:02 --> Hooks Class Initialized
DEBUG - 2018-06-23 05:54:02 --> UTF-8 Support Enabled
INFO - 2018-06-23 05:54:02 --> Utf8 Class Initialized
INFO - 2018-06-23 05:54:02 --> URI Class Initialized
INFO - 2018-06-23 05:54:02 --> Router Class Initialized
INFO - 2018-06-23 05:54:02 --> Output Class Initialized
INFO - 2018-06-23 05:54:02 --> Security Class Initialized
DEBUG - 2018-06-23 05:54:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 05:54:02 --> Input Class Initialized
INFO - 2018-06-23 05:54:02 --> Language Class Initialized
ERROR - 2018-06-23 05:54:02 --> 404 Page Not Found: /index
INFO - 2018-06-23 05:54:02 --> Config Class Initialized
INFO - 2018-06-23 05:54:02 --> Hooks Class Initialized
DEBUG - 2018-06-23 05:54:02 --> UTF-8 Support Enabled
INFO - 2018-06-23 05:54:02 --> Utf8 Class Initialized
INFO - 2018-06-23 05:54:02 --> URI Class Initialized
INFO - 2018-06-23 05:54:02 --> Router Class Initialized
INFO - 2018-06-23 05:54:02 --> Output Class Initialized
INFO - 2018-06-23 05:54:02 --> Security Class Initialized
DEBUG - 2018-06-23 05:54:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 05:54:02 --> Input Class Initialized
INFO - 2018-06-23 05:54:02 --> Language Class Initialized
ERROR - 2018-06-23 05:54:02 --> 404 Page Not Found: /index
INFO - 2018-06-23 05:54:02 --> Config Class Initialized
INFO - 2018-06-23 05:54:02 --> Hooks Class Initialized
DEBUG - 2018-06-23 05:54:02 --> UTF-8 Support Enabled
INFO - 2018-06-23 05:54:02 --> Utf8 Class Initialized
INFO - 2018-06-23 05:54:02 --> URI Class Initialized
INFO - 2018-06-23 05:54:02 --> Router Class Initialized
INFO - 2018-06-23 05:54:02 --> Output Class Initialized
INFO - 2018-06-23 05:54:02 --> Security Class Initialized
DEBUG - 2018-06-23 05:54:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 05:54:02 --> Input Class Initialized
INFO - 2018-06-23 05:54:02 --> Language Class Initialized
ERROR - 2018-06-23 05:54:02 --> 404 Page Not Found: /index
INFO - 2018-06-23 05:54:02 --> Config Class Initialized
INFO - 2018-06-23 05:54:02 --> Hooks Class Initialized
DEBUG - 2018-06-23 05:54:02 --> UTF-8 Support Enabled
INFO - 2018-06-23 05:54:02 --> Utf8 Class Initialized
INFO - 2018-06-23 05:54:02 --> URI Class Initialized
INFO - 2018-06-23 05:54:02 --> Router Class Initialized
INFO - 2018-06-23 05:54:02 --> Output Class Initialized
INFO - 2018-06-23 05:54:02 --> Security Class Initialized
DEBUG - 2018-06-23 05:54:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 05:54:02 --> Input Class Initialized
INFO - 2018-06-23 05:54:02 --> Language Class Initialized
ERROR - 2018-06-23 05:54:02 --> 404 Page Not Found: /index
INFO - 2018-06-23 05:54:02 --> Config Class Initialized
INFO - 2018-06-23 05:54:02 --> Hooks Class Initialized
DEBUG - 2018-06-23 05:54:02 --> UTF-8 Support Enabled
INFO - 2018-06-23 05:54:02 --> Utf8 Class Initialized
INFO - 2018-06-23 05:54:02 --> URI Class Initialized
INFO - 2018-06-23 05:54:02 --> Router Class Initialized
INFO - 2018-06-23 05:54:02 --> Output Class Initialized
INFO - 2018-06-23 05:54:02 --> Security Class Initialized
DEBUG - 2018-06-23 05:54:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 05:54:02 --> Input Class Initialized
INFO - 2018-06-23 05:54:02 --> Language Class Initialized
ERROR - 2018-06-23 05:54:02 --> 404 Page Not Found: /index
INFO - 2018-06-23 05:55:12 --> Config Class Initialized
INFO - 2018-06-23 05:55:12 --> Hooks Class Initialized
DEBUG - 2018-06-23 05:55:12 --> UTF-8 Support Enabled
INFO - 2018-06-23 05:55:12 --> Utf8 Class Initialized
INFO - 2018-06-23 05:55:12 --> URI Class Initialized
INFO - 2018-06-23 05:55:12 --> Router Class Initialized
INFO - 2018-06-23 05:55:12 --> Output Class Initialized
INFO - 2018-06-23 05:55:12 --> Security Class Initialized
DEBUG - 2018-06-23 05:55:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 05:55:12 --> Input Class Initialized
INFO - 2018-06-23 05:55:12 --> Language Class Initialized
INFO - 2018-06-23 05:55:12 --> Language Class Initialized
INFO - 2018-06-23 05:55:12 --> Config Class Initialized
INFO - 2018-06-23 05:55:12 --> Loader Class Initialized
DEBUG - 2018-06-23 05:55:12 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-23 05:55:12 --> Helper loaded: url_helper
INFO - 2018-06-23 05:55:12 --> Helper loaded: form_helper
INFO - 2018-06-23 05:55:12 --> Helper loaded: date_helper
INFO - 2018-06-23 05:55:12 --> Helper loaded: util_helper
INFO - 2018-06-23 05:55:12 --> Helper loaded: text_helper
INFO - 2018-06-23 05:55:12 --> Helper loaded: string_helper
INFO - 2018-06-23 05:55:12 --> Database Driver Class Initialized
DEBUG - 2018-06-23 05:55:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-23 05:55:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-23 05:55:13 --> Email Class Initialized
INFO - 2018-06-23 05:55:13 --> Controller Class Initialized
DEBUG - 2018-06-23 05:55:13 --> Home MX_Controller Initialized
DEBUG - 2018-06-23 05:55:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-23 05:55:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-23 05:55:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-23 05:55:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-23 05:55:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-23 05:55:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-23 05:55:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/search_page.php
INFO - 2018-06-23 05:55:13 --> Final output sent to browser
DEBUG - 2018-06-23 05:55:13 --> Total execution time: 0.4370
INFO - 2018-06-23 05:55:13 --> Config Class Initialized
INFO - 2018-06-23 05:55:13 --> Hooks Class Initialized
DEBUG - 2018-06-23 05:55:13 --> UTF-8 Support Enabled
INFO - 2018-06-23 05:55:13 --> Utf8 Class Initialized
INFO - 2018-06-23 05:55:13 --> URI Class Initialized
INFO - 2018-06-23 05:55:13 --> Router Class Initialized
INFO - 2018-06-23 05:55:13 --> Output Class Initialized
INFO - 2018-06-23 05:55:13 --> Security Class Initialized
DEBUG - 2018-06-23 05:55:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 05:55:13 --> Input Class Initialized
INFO - 2018-06-23 05:55:13 --> Language Class Initialized
ERROR - 2018-06-23 05:55:13 --> 404 Page Not Found: /index
INFO - 2018-06-23 05:55:13 --> Config Class Initialized
INFO - 2018-06-23 05:55:13 --> Hooks Class Initialized
DEBUG - 2018-06-23 05:55:13 --> UTF-8 Support Enabled
INFO - 2018-06-23 05:55:13 --> Utf8 Class Initialized
INFO - 2018-06-23 05:55:13 --> URI Class Initialized
INFO - 2018-06-23 05:55:13 --> Router Class Initialized
INFO - 2018-06-23 05:55:13 --> Output Class Initialized
INFO - 2018-06-23 05:55:13 --> Security Class Initialized
DEBUG - 2018-06-23 05:55:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 05:55:13 --> Input Class Initialized
INFO - 2018-06-23 05:55:13 --> Language Class Initialized
ERROR - 2018-06-23 05:55:14 --> 404 Page Not Found: /index
INFO - 2018-06-23 05:55:14 --> Config Class Initialized
INFO - 2018-06-23 05:55:14 --> Hooks Class Initialized
DEBUG - 2018-06-23 05:55:14 --> UTF-8 Support Enabled
INFO - 2018-06-23 05:55:14 --> Utf8 Class Initialized
INFO - 2018-06-23 05:55:14 --> URI Class Initialized
INFO - 2018-06-23 05:55:14 --> Router Class Initialized
INFO - 2018-06-23 05:55:14 --> Output Class Initialized
INFO - 2018-06-23 05:55:14 --> Security Class Initialized
DEBUG - 2018-06-23 05:55:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 05:55:14 --> Input Class Initialized
INFO - 2018-06-23 05:55:14 --> Language Class Initialized
ERROR - 2018-06-23 05:55:14 --> 404 Page Not Found: /index
INFO - 2018-06-23 05:55:14 --> Config Class Initialized
INFO - 2018-06-23 05:55:14 --> Hooks Class Initialized
DEBUG - 2018-06-23 05:55:14 --> UTF-8 Support Enabled
INFO - 2018-06-23 05:55:14 --> Utf8 Class Initialized
INFO - 2018-06-23 05:55:14 --> URI Class Initialized
INFO - 2018-06-23 05:55:14 --> Router Class Initialized
INFO - 2018-06-23 05:55:14 --> Output Class Initialized
INFO - 2018-06-23 05:55:14 --> Security Class Initialized
DEBUG - 2018-06-23 05:55:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 05:55:14 --> Input Class Initialized
INFO - 2018-06-23 05:55:14 --> Language Class Initialized
ERROR - 2018-06-23 05:55:14 --> 404 Page Not Found: /index
INFO - 2018-06-23 05:55:14 --> Config Class Initialized
INFO - 2018-06-23 05:55:14 --> Hooks Class Initialized
DEBUG - 2018-06-23 05:55:14 --> UTF-8 Support Enabled
INFO - 2018-06-23 05:55:14 --> Utf8 Class Initialized
INFO - 2018-06-23 05:55:14 --> URI Class Initialized
INFO - 2018-06-23 05:55:14 --> Router Class Initialized
INFO - 2018-06-23 05:55:14 --> Output Class Initialized
INFO - 2018-06-23 05:55:14 --> Security Class Initialized
DEBUG - 2018-06-23 05:55:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 05:55:14 --> Input Class Initialized
INFO - 2018-06-23 05:55:14 --> Language Class Initialized
ERROR - 2018-06-23 05:55:14 --> 404 Page Not Found: /index
INFO - 2018-06-23 05:55:14 --> Config Class Initialized
INFO - 2018-06-23 05:55:14 --> Hooks Class Initialized
DEBUG - 2018-06-23 05:55:14 --> UTF-8 Support Enabled
INFO - 2018-06-23 05:55:14 --> Utf8 Class Initialized
INFO - 2018-06-23 05:55:14 --> URI Class Initialized
INFO - 2018-06-23 05:55:14 --> Router Class Initialized
INFO - 2018-06-23 05:55:14 --> Output Class Initialized
INFO - 2018-06-23 05:55:14 --> Security Class Initialized
DEBUG - 2018-06-23 05:55:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 05:55:14 --> Input Class Initialized
INFO - 2018-06-23 05:55:14 --> Language Class Initialized
ERROR - 2018-06-23 05:55:14 --> 404 Page Not Found: /index
INFO - 2018-06-23 05:55:19 --> Config Class Initialized
INFO - 2018-06-23 05:55:19 --> Hooks Class Initialized
DEBUG - 2018-06-23 05:55:19 --> UTF-8 Support Enabled
INFO - 2018-06-23 05:55:19 --> Utf8 Class Initialized
INFO - 2018-06-23 05:55:19 --> URI Class Initialized
DEBUG - 2018-06-23 05:55:19 --> No URI present. Default controller set.
INFO - 2018-06-23 05:55:19 --> Router Class Initialized
INFO - 2018-06-23 05:55:19 --> Output Class Initialized
INFO - 2018-06-23 05:55:19 --> Security Class Initialized
DEBUG - 2018-06-23 05:55:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 05:55:19 --> Input Class Initialized
INFO - 2018-06-23 05:55:19 --> Language Class Initialized
INFO - 2018-06-23 05:55:19 --> Language Class Initialized
INFO - 2018-06-23 05:55:19 --> Config Class Initialized
INFO - 2018-06-23 05:55:19 --> Loader Class Initialized
DEBUG - 2018-06-23 05:55:19 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-23 05:55:19 --> Helper loaded: url_helper
INFO - 2018-06-23 05:55:19 --> Helper loaded: form_helper
INFO - 2018-06-23 05:55:19 --> Helper loaded: date_helper
INFO - 2018-06-23 05:55:19 --> Helper loaded: util_helper
INFO - 2018-06-23 05:55:19 --> Helper loaded: text_helper
INFO - 2018-06-23 05:55:19 --> Helper loaded: string_helper
INFO - 2018-06-23 05:55:19 --> Database Driver Class Initialized
DEBUG - 2018-06-23 05:55:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-23 05:55:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-23 05:55:19 --> Email Class Initialized
INFO - 2018-06-23 05:55:19 --> Controller Class Initialized
DEBUG - 2018-06-23 05:55:19 --> Home MX_Controller Initialized
DEBUG - 2018-06-23 05:55:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-23 05:55:19 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-23 05:55:19 --> Login MX_Controller Initialized
INFO - 2018-06-23 05:55:19 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-23 05:55:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-23 05:55:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-23 05:55:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-23 05:55:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-23 05:55:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-23 05:55:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-23 05:55:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-23 05:55:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-06-23 05:55:20 --> Final output sent to browser
DEBUG - 2018-06-23 05:55:20 --> Total execution time: 0.5096
INFO - 2018-06-23 05:55:20 --> Config Class Initialized
INFO - 2018-06-23 05:55:20 --> Hooks Class Initialized
DEBUG - 2018-06-23 05:55:20 --> UTF-8 Support Enabled
INFO - 2018-06-23 05:55:20 --> Utf8 Class Initialized
INFO - 2018-06-23 05:55:20 --> URI Class Initialized
INFO - 2018-06-23 05:55:20 --> Router Class Initialized
INFO - 2018-06-23 05:55:20 --> Output Class Initialized
INFO - 2018-06-23 05:55:20 --> Security Class Initialized
DEBUG - 2018-06-23 05:55:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 05:55:20 --> Input Class Initialized
INFO - 2018-06-23 05:55:20 --> Language Class Initialized
ERROR - 2018-06-23 05:55:20 --> 404 Page Not Found: /index
INFO - 2018-06-23 05:55:20 --> Config Class Initialized
INFO - 2018-06-23 05:55:20 --> Hooks Class Initialized
DEBUG - 2018-06-23 05:55:20 --> UTF-8 Support Enabled
INFO - 2018-06-23 05:55:20 --> Utf8 Class Initialized
INFO - 2018-06-23 05:55:20 --> URI Class Initialized
INFO - 2018-06-23 05:55:20 --> Router Class Initialized
INFO - 2018-06-23 05:55:20 --> Output Class Initialized
INFO - 2018-06-23 05:55:20 --> Security Class Initialized
DEBUG - 2018-06-23 05:55:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 05:55:20 --> Input Class Initialized
INFO - 2018-06-23 05:55:20 --> Language Class Initialized
ERROR - 2018-06-23 05:55:20 --> 404 Page Not Found: /index
INFO - 2018-06-23 05:55:21 --> Config Class Initialized
INFO - 2018-06-23 05:55:21 --> Hooks Class Initialized
DEBUG - 2018-06-23 05:55:21 --> UTF-8 Support Enabled
INFO - 2018-06-23 05:55:21 --> Utf8 Class Initialized
INFO - 2018-06-23 05:55:21 --> URI Class Initialized
INFO - 2018-06-23 05:55:21 --> Router Class Initialized
INFO - 2018-06-23 05:55:21 --> Output Class Initialized
INFO - 2018-06-23 05:55:21 --> Security Class Initialized
DEBUG - 2018-06-23 05:55:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 05:55:21 --> Input Class Initialized
INFO - 2018-06-23 05:55:21 --> Language Class Initialized
ERROR - 2018-06-23 05:55:21 --> 404 Page Not Found: /index
INFO - 2018-06-23 05:55:26 --> Config Class Initialized
INFO - 2018-06-23 05:55:26 --> Hooks Class Initialized
DEBUG - 2018-06-23 05:55:26 --> UTF-8 Support Enabled
INFO - 2018-06-23 05:55:26 --> Utf8 Class Initialized
INFO - 2018-06-23 05:55:26 --> URI Class Initialized
INFO - 2018-06-23 05:55:26 --> Router Class Initialized
INFO - 2018-06-23 05:55:26 --> Output Class Initialized
INFO - 2018-06-23 05:55:26 --> Security Class Initialized
DEBUG - 2018-06-23 05:55:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 05:55:26 --> Input Class Initialized
INFO - 2018-06-23 05:55:26 --> Language Class Initialized
INFO - 2018-06-23 05:55:26 --> Language Class Initialized
INFO - 2018-06-23 05:55:26 --> Config Class Initialized
INFO - 2018-06-23 05:55:26 --> Loader Class Initialized
DEBUG - 2018-06-23 05:55:26 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-23 05:55:26 --> Helper loaded: url_helper
INFO - 2018-06-23 05:55:26 --> Helper loaded: form_helper
INFO - 2018-06-23 05:55:26 --> Helper loaded: date_helper
INFO - 2018-06-23 05:55:26 --> Helper loaded: util_helper
INFO - 2018-06-23 05:55:26 --> Helper loaded: text_helper
INFO - 2018-06-23 05:55:26 --> Helper loaded: string_helper
INFO - 2018-06-23 05:55:26 --> Database Driver Class Initialized
DEBUG - 2018-06-23 05:55:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-23 05:55:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-23 05:55:26 --> Email Class Initialized
INFO - 2018-06-23 05:55:26 --> Controller Class Initialized
DEBUG - 2018-06-23 05:55:26 --> Home MX_Controller Initialized
DEBUG - 2018-06-23 05:55:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-23 05:55:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-23 05:55:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-23 05:55:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-23 05:55:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-23 05:55:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-23 05:55:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/search_page.php
INFO - 2018-06-23 05:55:26 --> Final output sent to browser
DEBUG - 2018-06-23 05:55:26 --> Total execution time: 0.4412
INFO - 2018-06-23 05:55:27 --> Config Class Initialized
INFO - 2018-06-23 05:55:27 --> Hooks Class Initialized
DEBUG - 2018-06-23 05:55:27 --> UTF-8 Support Enabled
INFO - 2018-06-23 05:55:27 --> Utf8 Class Initialized
INFO - 2018-06-23 05:55:27 --> URI Class Initialized
INFO - 2018-06-23 05:55:27 --> Router Class Initialized
INFO - 2018-06-23 05:55:27 --> Output Class Initialized
INFO - 2018-06-23 05:55:27 --> Security Class Initialized
DEBUG - 2018-06-23 05:55:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 05:55:27 --> Input Class Initialized
INFO - 2018-06-23 05:55:27 --> Language Class Initialized
ERROR - 2018-06-23 05:55:27 --> 404 Page Not Found: /index
INFO - 2018-06-23 05:55:27 --> Config Class Initialized
INFO - 2018-06-23 05:55:27 --> Hooks Class Initialized
DEBUG - 2018-06-23 05:55:27 --> UTF-8 Support Enabled
INFO - 2018-06-23 05:55:27 --> Utf8 Class Initialized
INFO - 2018-06-23 05:55:27 --> URI Class Initialized
INFO - 2018-06-23 05:55:27 --> Router Class Initialized
INFO - 2018-06-23 05:55:27 --> Output Class Initialized
INFO - 2018-06-23 05:55:27 --> Security Class Initialized
DEBUG - 2018-06-23 05:55:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 05:55:27 --> Input Class Initialized
INFO - 2018-06-23 05:55:27 --> Language Class Initialized
ERROR - 2018-06-23 05:55:27 --> 404 Page Not Found: /index
INFO - 2018-06-23 05:55:27 --> Config Class Initialized
INFO - 2018-06-23 05:55:27 --> Hooks Class Initialized
DEBUG - 2018-06-23 05:55:27 --> UTF-8 Support Enabled
INFO - 2018-06-23 05:55:27 --> Utf8 Class Initialized
INFO - 2018-06-23 05:55:27 --> URI Class Initialized
INFO - 2018-06-23 05:55:27 --> Router Class Initialized
INFO - 2018-06-23 05:55:27 --> Output Class Initialized
INFO - 2018-06-23 05:55:27 --> Security Class Initialized
DEBUG - 2018-06-23 05:55:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 05:55:27 --> Input Class Initialized
INFO - 2018-06-23 05:55:27 --> Language Class Initialized
ERROR - 2018-06-23 05:55:27 --> 404 Page Not Found: /index
INFO - 2018-06-23 05:55:30 --> Config Class Initialized
INFO - 2018-06-23 05:55:30 --> Hooks Class Initialized
DEBUG - 2018-06-23 05:55:30 --> UTF-8 Support Enabled
INFO - 2018-06-23 05:55:30 --> Utf8 Class Initialized
INFO - 2018-06-23 05:55:30 --> URI Class Initialized
DEBUG - 2018-06-23 05:55:30 --> No URI present. Default controller set.
INFO - 2018-06-23 05:55:30 --> Router Class Initialized
INFO - 2018-06-23 05:55:30 --> Output Class Initialized
INFO - 2018-06-23 05:55:30 --> Security Class Initialized
DEBUG - 2018-06-23 05:55:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 05:55:30 --> Input Class Initialized
INFO - 2018-06-23 05:55:30 --> Language Class Initialized
INFO - 2018-06-23 05:55:30 --> Language Class Initialized
INFO - 2018-06-23 05:55:30 --> Config Class Initialized
INFO - 2018-06-23 05:55:30 --> Loader Class Initialized
DEBUG - 2018-06-23 05:55:30 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-23 05:55:30 --> Helper loaded: url_helper
INFO - 2018-06-23 05:55:30 --> Helper loaded: form_helper
INFO - 2018-06-23 05:55:30 --> Helper loaded: date_helper
INFO - 2018-06-23 05:55:30 --> Helper loaded: util_helper
INFO - 2018-06-23 05:55:30 --> Helper loaded: text_helper
INFO - 2018-06-23 05:55:30 --> Helper loaded: string_helper
INFO - 2018-06-23 05:55:30 --> Database Driver Class Initialized
DEBUG - 2018-06-23 05:55:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-23 05:55:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-23 05:55:30 --> Email Class Initialized
INFO - 2018-06-23 05:55:30 --> Controller Class Initialized
DEBUG - 2018-06-23 05:55:30 --> Home MX_Controller Initialized
DEBUG - 2018-06-23 05:55:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-23 05:55:30 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-23 05:55:30 --> Login MX_Controller Initialized
INFO - 2018-06-23 05:55:30 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-23 05:55:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-23 05:55:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-23 05:55:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-23 05:55:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-23 05:55:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-23 05:55:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-23 05:55:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-23 05:55:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-06-23 05:55:30 --> Final output sent to browser
DEBUG - 2018-06-23 05:55:30 --> Total execution time: 0.6126
INFO - 2018-06-23 05:57:04 --> Config Class Initialized
INFO - 2018-06-23 05:57:04 --> Hooks Class Initialized
DEBUG - 2018-06-23 05:57:04 --> UTF-8 Support Enabled
INFO - 2018-06-23 05:57:04 --> Utf8 Class Initialized
INFO - 2018-06-23 05:57:04 --> URI Class Initialized
DEBUG - 2018-06-23 05:57:04 --> No URI present. Default controller set.
INFO - 2018-06-23 05:57:04 --> Router Class Initialized
INFO - 2018-06-23 05:57:04 --> Output Class Initialized
INFO - 2018-06-23 05:57:04 --> Security Class Initialized
DEBUG - 2018-06-23 05:57:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 05:57:04 --> Input Class Initialized
INFO - 2018-06-23 05:57:04 --> Language Class Initialized
INFO - 2018-06-23 05:57:04 --> Language Class Initialized
INFO - 2018-06-23 05:57:04 --> Config Class Initialized
INFO - 2018-06-23 05:57:04 --> Loader Class Initialized
DEBUG - 2018-06-23 05:57:04 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-23 05:57:04 --> Helper loaded: url_helper
INFO - 2018-06-23 05:57:04 --> Helper loaded: form_helper
INFO - 2018-06-23 05:57:04 --> Helper loaded: date_helper
INFO - 2018-06-23 05:57:04 --> Helper loaded: util_helper
INFO - 2018-06-23 05:57:04 --> Helper loaded: text_helper
INFO - 2018-06-23 05:57:04 --> Helper loaded: string_helper
INFO - 2018-06-23 05:57:04 --> Database Driver Class Initialized
DEBUG - 2018-06-23 05:57:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-23 05:57:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-23 05:57:04 --> Email Class Initialized
INFO - 2018-06-23 05:57:04 --> Controller Class Initialized
DEBUG - 2018-06-23 05:57:04 --> Home MX_Controller Initialized
DEBUG - 2018-06-23 05:57:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-23 05:57:04 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-23 05:57:04 --> Login MX_Controller Initialized
INFO - 2018-06-23 05:57:04 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-23 05:57:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-23 05:57:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-23 05:57:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-23 05:57:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-23 05:57:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-23 05:57:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-23 05:57:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-23 05:57:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-06-23 05:57:04 --> Final output sent to browser
DEBUG - 2018-06-23 05:57:04 --> Total execution time: 0.5265
INFO - 2018-06-23 05:57:05 --> Config Class Initialized
INFO - 2018-06-23 05:57:05 --> Hooks Class Initialized
DEBUG - 2018-06-23 05:57:05 --> UTF-8 Support Enabled
INFO - 2018-06-23 05:57:05 --> Utf8 Class Initialized
INFO - 2018-06-23 05:57:05 --> URI Class Initialized
INFO - 2018-06-23 05:57:05 --> Router Class Initialized
INFO - 2018-06-23 05:57:05 --> Output Class Initialized
INFO - 2018-06-23 05:57:05 --> Security Class Initialized
DEBUG - 2018-06-23 05:57:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 05:57:05 --> Input Class Initialized
INFO - 2018-06-23 05:57:05 --> Language Class Initialized
ERROR - 2018-06-23 05:57:05 --> 404 Page Not Found: /index
INFO - 2018-06-23 05:57:05 --> Config Class Initialized
INFO - 2018-06-23 05:57:05 --> Hooks Class Initialized
DEBUG - 2018-06-23 05:57:05 --> UTF-8 Support Enabled
INFO - 2018-06-23 05:57:05 --> Utf8 Class Initialized
INFO - 2018-06-23 05:57:05 --> URI Class Initialized
INFO - 2018-06-23 05:57:05 --> Router Class Initialized
INFO - 2018-06-23 05:57:05 --> Output Class Initialized
INFO - 2018-06-23 05:57:05 --> Security Class Initialized
DEBUG - 2018-06-23 05:57:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 05:57:05 --> Input Class Initialized
INFO - 2018-06-23 05:57:05 --> Language Class Initialized
ERROR - 2018-06-23 05:57:05 --> 404 Page Not Found: /index
INFO - 2018-06-23 05:57:05 --> Config Class Initialized
INFO - 2018-06-23 05:57:05 --> Hooks Class Initialized
DEBUG - 2018-06-23 05:57:05 --> UTF-8 Support Enabled
INFO - 2018-06-23 05:57:05 --> Utf8 Class Initialized
INFO - 2018-06-23 05:57:05 --> URI Class Initialized
INFO - 2018-06-23 05:57:05 --> Router Class Initialized
INFO - 2018-06-23 05:57:05 --> Output Class Initialized
INFO - 2018-06-23 05:57:05 --> Security Class Initialized
DEBUG - 2018-06-23 05:57:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 05:57:05 --> Input Class Initialized
INFO - 2018-06-23 05:57:05 --> Language Class Initialized
ERROR - 2018-06-23 05:57:05 --> 404 Page Not Found: /index
INFO - 2018-06-23 05:57:05 --> Config Class Initialized
INFO - 2018-06-23 05:57:06 --> Hooks Class Initialized
DEBUG - 2018-06-23 05:57:06 --> UTF-8 Support Enabled
INFO - 2018-06-23 05:57:06 --> Utf8 Class Initialized
INFO - 2018-06-23 05:57:06 --> URI Class Initialized
INFO - 2018-06-23 05:57:06 --> Router Class Initialized
INFO - 2018-06-23 05:57:06 --> Output Class Initialized
INFO - 2018-06-23 05:57:06 --> Security Class Initialized
DEBUG - 2018-06-23 05:57:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 05:57:06 --> Input Class Initialized
INFO - 2018-06-23 05:57:06 --> Language Class Initialized
ERROR - 2018-06-23 05:57:06 --> 404 Page Not Found: /index
INFO - 2018-06-23 05:57:06 --> Config Class Initialized
INFO - 2018-06-23 05:57:06 --> Hooks Class Initialized
DEBUG - 2018-06-23 05:57:06 --> UTF-8 Support Enabled
INFO - 2018-06-23 05:57:06 --> Utf8 Class Initialized
INFO - 2018-06-23 05:57:06 --> URI Class Initialized
INFO - 2018-06-23 05:57:06 --> Router Class Initialized
INFO - 2018-06-23 05:57:06 --> Output Class Initialized
INFO - 2018-06-23 05:57:06 --> Security Class Initialized
DEBUG - 2018-06-23 05:57:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 05:57:06 --> Input Class Initialized
INFO - 2018-06-23 05:57:06 --> Language Class Initialized
ERROR - 2018-06-23 05:57:06 --> 404 Page Not Found: /index
INFO - 2018-06-23 05:57:06 --> Config Class Initialized
INFO - 2018-06-23 05:57:06 --> Hooks Class Initialized
DEBUG - 2018-06-23 05:57:06 --> UTF-8 Support Enabled
INFO - 2018-06-23 05:57:06 --> Utf8 Class Initialized
INFO - 2018-06-23 05:57:06 --> URI Class Initialized
INFO - 2018-06-23 05:57:06 --> Router Class Initialized
INFO - 2018-06-23 05:57:06 --> Output Class Initialized
INFO - 2018-06-23 05:57:06 --> Security Class Initialized
DEBUG - 2018-06-23 05:57:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 05:57:06 --> Input Class Initialized
INFO - 2018-06-23 05:57:06 --> Language Class Initialized
ERROR - 2018-06-23 05:57:06 --> 404 Page Not Found: /index
INFO - 2018-06-23 05:57:08 --> Config Class Initialized
INFO - 2018-06-23 05:57:08 --> Hooks Class Initialized
DEBUG - 2018-06-23 05:57:08 --> UTF-8 Support Enabled
INFO - 2018-06-23 05:57:08 --> Utf8 Class Initialized
INFO - 2018-06-23 05:57:08 --> URI Class Initialized
INFO - 2018-06-23 05:57:08 --> Router Class Initialized
INFO - 2018-06-23 05:57:08 --> Output Class Initialized
INFO - 2018-06-23 05:57:08 --> Security Class Initialized
DEBUG - 2018-06-23 05:57:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 05:57:08 --> Input Class Initialized
INFO - 2018-06-23 05:57:08 --> Language Class Initialized
INFO - 2018-06-23 05:57:08 --> Language Class Initialized
INFO - 2018-06-23 05:57:08 --> Config Class Initialized
INFO - 2018-06-23 05:57:08 --> Loader Class Initialized
DEBUG - 2018-06-23 05:57:08 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-23 05:57:08 --> Helper loaded: url_helper
INFO - 2018-06-23 05:57:08 --> Helper loaded: form_helper
INFO - 2018-06-23 05:57:08 --> Helper loaded: date_helper
INFO - 2018-06-23 05:57:08 --> Helper loaded: util_helper
INFO - 2018-06-23 05:57:08 --> Helper loaded: text_helper
INFO - 2018-06-23 05:57:08 --> Helper loaded: string_helper
INFO - 2018-06-23 05:57:08 --> Database Driver Class Initialized
DEBUG - 2018-06-23 05:57:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-23 05:57:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-23 05:57:09 --> Email Class Initialized
INFO - 2018-06-23 05:57:09 --> Controller Class Initialized
DEBUG - 2018-06-23 05:57:09 --> Home MX_Controller Initialized
DEBUG - 2018-06-23 05:57:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-23 05:57:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-23 05:57:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-23 05:57:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-23 05:57:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-23 05:57:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-23 05:57:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/search_page.php
INFO - 2018-06-23 05:57:09 --> Final output sent to browser
DEBUG - 2018-06-23 05:57:09 --> Total execution time: 0.4704
INFO - 2018-06-23 05:57:09 --> Config Class Initialized
INFO - 2018-06-23 05:57:09 --> Hooks Class Initialized
DEBUG - 2018-06-23 05:57:09 --> UTF-8 Support Enabled
INFO - 2018-06-23 05:57:09 --> Utf8 Class Initialized
INFO - 2018-06-23 05:57:09 --> URI Class Initialized
INFO - 2018-06-23 05:57:09 --> Router Class Initialized
INFO - 2018-06-23 05:57:09 --> Output Class Initialized
INFO - 2018-06-23 05:57:09 --> Security Class Initialized
DEBUG - 2018-06-23 05:57:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 05:57:09 --> Input Class Initialized
INFO - 2018-06-23 05:57:09 --> Language Class Initialized
ERROR - 2018-06-23 05:57:09 --> 404 Page Not Found: /index
INFO - 2018-06-23 05:57:09 --> Config Class Initialized
INFO - 2018-06-23 05:57:09 --> Hooks Class Initialized
DEBUG - 2018-06-23 05:57:09 --> UTF-8 Support Enabled
INFO - 2018-06-23 05:57:09 --> Utf8 Class Initialized
INFO - 2018-06-23 05:57:09 --> URI Class Initialized
INFO - 2018-06-23 05:57:09 --> Router Class Initialized
INFO - 2018-06-23 05:57:09 --> Output Class Initialized
INFO - 2018-06-23 05:57:09 --> Security Class Initialized
DEBUG - 2018-06-23 05:57:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 05:57:09 --> Input Class Initialized
INFO - 2018-06-23 05:57:09 --> Language Class Initialized
ERROR - 2018-06-23 05:57:09 --> 404 Page Not Found: /index
INFO - 2018-06-23 05:57:09 --> Config Class Initialized
INFO - 2018-06-23 05:57:09 --> Hooks Class Initialized
DEBUG - 2018-06-23 05:57:09 --> UTF-8 Support Enabled
INFO - 2018-06-23 05:57:09 --> Utf8 Class Initialized
INFO - 2018-06-23 05:57:09 --> URI Class Initialized
INFO - 2018-06-23 05:57:10 --> Router Class Initialized
INFO - 2018-06-23 05:57:10 --> Output Class Initialized
INFO - 2018-06-23 05:57:10 --> Security Class Initialized
DEBUG - 2018-06-23 05:57:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 05:57:10 --> Input Class Initialized
INFO - 2018-06-23 05:57:10 --> Language Class Initialized
ERROR - 2018-06-23 05:57:10 --> 404 Page Not Found: /index
INFO - 2018-06-23 05:57:10 --> Config Class Initialized
INFO - 2018-06-23 05:57:10 --> Hooks Class Initialized
DEBUG - 2018-06-23 05:57:10 --> UTF-8 Support Enabled
INFO - 2018-06-23 05:57:10 --> Utf8 Class Initialized
INFO - 2018-06-23 05:57:10 --> URI Class Initialized
INFO - 2018-06-23 05:57:10 --> Router Class Initialized
INFO - 2018-06-23 05:57:10 --> Output Class Initialized
INFO - 2018-06-23 05:57:10 --> Security Class Initialized
DEBUG - 2018-06-23 05:57:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 05:57:10 --> Input Class Initialized
INFO - 2018-06-23 05:57:10 --> Language Class Initialized
ERROR - 2018-06-23 05:57:10 --> 404 Page Not Found: /index
INFO - 2018-06-23 05:57:10 --> Config Class Initialized
INFO - 2018-06-23 05:57:10 --> Hooks Class Initialized
DEBUG - 2018-06-23 05:57:10 --> UTF-8 Support Enabled
INFO - 2018-06-23 05:57:10 --> Utf8 Class Initialized
INFO - 2018-06-23 05:57:10 --> URI Class Initialized
INFO - 2018-06-23 05:57:10 --> Router Class Initialized
INFO - 2018-06-23 05:57:10 --> Output Class Initialized
INFO - 2018-06-23 05:57:10 --> Security Class Initialized
DEBUG - 2018-06-23 05:57:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 05:57:10 --> Input Class Initialized
INFO - 2018-06-23 05:57:10 --> Language Class Initialized
ERROR - 2018-06-23 05:57:10 --> 404 Page Not Found: /index
INFO - 2018-06-23 05:57:10 --> Config Class Initialized
INFO - 2018-06-23 05:57:10 --> Hooks Class Initialized
DEBUG - 2018-06-23 05:57:10 --> UTF-8 Support Enabled
INFO - 2018-06-23 05:57:10 --> Utf8 Class Initialized
INFO - 2018-06-23 05:57:10 --> URI Class Initialized
INFO - 2018-06-23 05:57:10 --> Router Class Initialized
INFO - 2018-06-23 05:57:10 --> Output Class Initialized
INFO - 2018-06-23 05:57:10 --> Security Class Initialized
DEBUG - 2018-06-23 05:57:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 05:57:10 --> Input Class Initialized
INFO - 2018-06-23 05:57:10 --> Language Class Initialized
ERROR - 2018-06-23 05:57:10 --> 404 Page Not Found: /index
INFO - 2018-06-23 05:57:31 --> Config Class Initialized
INFO - 2018-06-23 05:57:31 --> Hooks Class Initialized
DEBUG - 2018-06-23 05:57:31 --> UTF-8 Support Enabled
INFO - 2018-06-23 05:57:31 --> Utf8 Class Initialized
INFO - 2018-06-23 05:57:31 --> URI Class Initialized
INFO - 2018-06-23 05:57:31 --> Router Class Initialized
INFO - 2018-06-23 05:57:31 --> Output Class Initialized
INFO - 2018-06-23 05:57:31 --> Security Class Initialized
DEBUG - 2018-06-23 05:57:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 05:57:31 --> Input Class Initialized
INFO - 2018-06-23 05:57:31 --> Language Class Initialized
INFO - 2018-06-23 05:57:31 --> Language Class Initialized
INFO - 2018-06-23 05:57:31 --> Config Class Initialized
INFO - 2018-06-23 05:57:31 --> Loader Class Initialized
DEBUG - 2018-06-23 05:57:31 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-23 05:57:31 --> Helper loaded: url_helper
INFO - 2018-06-23 05:57:31 --> Helper loaded: form_helper
INFO - 2018-06-23 05:57:31 --> Helper loaded: date_helper
INFO - 2018-06-23 05:57:31 --> Helper loaded: util_helper
INFO - 2018-06-23 05:57:31 --> Helper loaded: text_helper
INFO - 2018-06-23 05:57:31 --> Helper loaded: string_helper
INFO - 2018-06-23 05:57:31 --> Database Driver Class Initialized
DEBUG - 2018-06-23 05:57:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-23 05:57:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-23 05:57:31 --> Email Class Initialized
INFO - 2018-06-23 05:57:31 --> Controller Class Initialized
DEBUG - 2018-06-23 05:57:31 --> Home MX_Controller Initialized
DEBUG - 2018-06-23 05:57:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-23 05:57:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-23 05:57:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-23 05:57:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-23 05:57:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-23 05:57:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-23 05:57:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/search_page.php
INFO - 2018-06-23 05:57:31 --> Final output sent to browser
DEBUG - 2018-06-23 05:57:31 --> Total execution time: 0.4560
INFO - 2018-06-23 05:57:32 --> Config Class Initialized
INFO - 2018-06-23 05:57:32 --> Hooks Class Initialized
DEBUG - 2018-06-23 05:57:32 --> UTF-8 Support Enabled
INFO - 2018-06-23 05:57:32 --> Utf8 Class Initialized
INFO - 2018-06-23 05:57:32 --> URI Class Initialized
INFO - 2018-06-23 05:57:32 --> Router Class Initialized
INFO - 2018-06-23 05:57:32 --> Output Class Initialized
INFO - 2018-06-23 05:57:32 --> Security Class Initialized
DEBUG - 2018-06-23 05:57:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 05:57:32 --> Input Class Initialized
INFO - 2018-06-23 05:57:32 --> Language Class Initialized
ERROR - 2018-06-23 05:57:32 --> 404 Page Not Found: /index
INFO - 2018-06-23 05:57:32 --> Config Class Initialized
INFO - 2018-06-23 05:57:32 --> Hooks Class Initialized
DEBUG - 2018-06-23 05:57:32 --> UTF-8 Support Enabled
INFO - 2018-06-23 05:57:32 --> Utf8 Class Initialized
INFO - 2018-06-23 05:57:32 --> URI Class Initialized
INFO - 2018-06-23 05:57:32 --> Router Class Initialized
INFO - 2018-06-23 05:57:32 --> Output Class Initialized
INFO - 2018-06-23 05:57:32 --> Security Class Initialized
DEBUG - 2018-06-23 05:57:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 05:57:32 --> Input Class Initialized
INFO - 2018-06-23 05:57:32 --> Language Class Initialized
ERROR - 2018-06-23 05:57:32 --> 404 Page Not Found: /index
INFO - 2018-06-23 05:57:32 --> Config Class Initialized
INFO - 2018-06-23 05:57:32 --> Hooks Class Initialized
DEBUG - 2018-06-23 05:57:32 --> UTF-8 Support Enabled
INFO - 2018-06-23 05:57:32 --> Utf8 Class Initialized
INFO - 2018-06-23 05:57:32 --> URI Class Initialized
INFO - 2018-06-23 05:57:32 --> Router Class Initialized
INFO - 2018-06-23 05:57:32 --> Output Class Initialized
INFO - 2018-06-23 05:57:32 --> Security Class Initialized
DEBUG - 2018-06-23 05:57:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 05:57:32 --> Input Class Initialized
INFO - 2018-06-23 05:57:32 --> Language Class Initialized
ERROR - 2018-06-23 05:57:32 --> 404 Page Not Found: /index
INFO - 2018-06-23 05:57:32 --> Config Class Initialized
INFO - 2018-06-23 05:57:32 --> Hooks Class Initialized
DEBUG - 2018-06-23 05:57:32 --> UTF-8 Support Enabled
INFO - 2018-06-23 05:57:32 --> Utf8 Class Initialized
INFO - 2018-06-23 05:57:32 --> URI Class Initialized
INFO - 2018-06-23 05:57:32 --> Router Class Initialized
INFO - 2018-06-23 05:57:32 --> Output Class Initialized
INFO - 2018-06-23 05:57:32 --> Security Class Initialized
DEBUG - 2018-06-23 05:57:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 05:57:32 --> Input Class Initialized
INFO - 2018-06-23 05:57:32 --> Language Class Initialized
ERROR - 2018-06-23 05:57:32 --> 404 Page Not Found: /index
INFO - 2018-06-23 05:57:32 --> Config Class Initialized
INFO - 2018-06-23 05:57:32 --> Hooks Class Initialized
DEBUG - 2018-06-23 05:57:32 --> UTF-8 Support Enabled
INFO - 2018-06-23 05:57:32 --> Utf8 Class Initialized
INFO - 2018-06-23 05:57:32 --> URI Class Initialized
INFO - 2018-06-23 05:57:32 --> Router Class Initialized
INFO - 2018-06-23 05:57:32 --> Output Class Initialized
INFO - 2018-06-23 05:57:32 --> Security Class Initialized
DEBUG - 2018-06-23 05:57:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 05:57:32 --> Input Class Initialized
INFO - 2018-06-23 05:57:32 --> Language Class Initialized
ERROR - 2018-06-23 05:57:32 --> 404 Page Not Found: /index
INFO - 2018-06-23 05:57:33 --> Config Class Initialized
INFO - 2018-06-23 05:57:33 --> Hooks Class Initialized
DEBUG - 2018-06-23 05:57:33 --> UTF-8 Support Enabled
INFO - 2018-06-23 05:57:33 --> Utf8 Class Initialized
INFO - 2018-06-23 05:57:33 --> URI Class Initialized
INFO - 2018-06-23 05:57:33 --> Router Class Initialized
INFO - 2018-06-23 05:57:33 --> Output Class Initialized
INFO - 2018-06-23 05:57:33 --> Security Class Initialized
DEBUG - 2018-06-23 05:57:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 05:57:33 --> Input Class Initialized
INFO - 2018-06-23 05:57:33 --> Language Class Initialized
ERROR - 2018-06-23 05:57:33 --> 404 Page Not Found: /index
INFO - 2018-06-23 05:58:11 --> Config Class Initialized
INFO - 2018-06-23 05:58:11 --> Hooks Class Initialized
DEBUG - 2018-06-23 05:58:11 --> UTF-8 Support Enabled
INFO - 2018-06-23 05:58:11 --> Utf8 Class Initialized
INFO - 2018-06-23 05:58:11 --> URI Class Initialized
INFO - 2018-06-23 05:58:11 --> Router Class Initialized
INFO - 2018-06-23 05:58:11 --> Output Class Initialized
INFO - 2018-06-23 05:58:11 --> Security Class Initialized
DEBUG - 2018-06-23 05:58:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 05:58:11 --> Input Class Initialized
INFO - 2018-06-23 05:58:11 --> Language Class Initialized
INFO - 2018-06-23 05:58:11 --> Language Class Initialized
INFO - 2018-06-23 05:58:11 --> Config Class Initialized
INFO - 2018-06-23 05:58:11 --> Loader Class Initialized
DEBUG - 2018-06-23 05:58:11 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-23 05:58:11 --> Helper loaded: url_helper
INFO - 2018-06-23 05:58:12 --> Helper loaded: form_helper
INFO - 2018-06-23 05:58:12 --> Helper loaded: date_helper
INFO - 2018-06-23 05:58:12 --> Helper loaded: util_helper
INFO - 2018-06-23 05:58:12 --> Helper loaded: text_helper
INFO - 2018-06-23 05:58:12 --> Helper loaded: string_helper
INFO - 2018-06-23 05:58:12 --> Database Driver Class Initialized
DEBUG - 2018-06-23 05:58:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-23 05:58:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-23 05:58:12 --> Email Class Initialized
INFO - 2018-06-23 05:58:12 --> Controller Class Initialized
DEBUG - 2018-06-23 05:58:12 --> Home MX_Controller Initialized
DEBUG - 2018-06-23 05:58:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-23 05:58:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-23 05:58:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-23 05:58:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-23 05:58:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-23 05:58:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-23 05:58:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/search_page.php
INFO - 2018-06-23 05:58:12 --> Final output sent to browser
DEBUG - 2018-06-23 05:58:12 --> Total execution time: 0.4550
INFO - 2018-06-23 05:58:12 --> Config Class Initialized
INFO - 2018-06-23 05:58:12 --> Hooks Class Initialized
DEBUG - 2018-06-23 05:58:12 --> UTF-8 Support Enabled
INFO - 2018-06-23 05:58:12 --> Utf8 Class Initialized
INFO - 2018-06-23 05:58:12 --> URI Class Initialized
INFO - 2018-06-23 05:58:12 --> Router Class Initialized
INFO - 2018-06-23 05:58:12 --> Output Class Initialized
INFO - 2018-06-23 05:58:12 --> Security Class Initialized
DEBUG - 2018-06-23 05:58:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 05:58:12 --> Input Class Initialized
INFO - 2018-06-23 05:58:12 --> Language Class Initialized
ERROR - 2018-06-23 05:58:12 --> 404 Page Not Found: /index
INFO - 2018-06-23 05:58:13 --> Config Class Initialized
INFO - 2018-06-23 05:58:13 --> Hooks Class Initialized
DEBUG - 2018-06-23 05:58:13 --> UTF-8 Support Enabled
INFO - 2018-06-23 05:58:13 --> Utf8 Class Initialized
INFO - 2018-06-23 05:58:13 --> URI Class Initialized
INFO - 2018-06-23 05:58:13 --> Router Class Initialized
INFO - 2018-06-23 05:58:13 --> Output Class Initialized
INFO - 2018-06-23 05:58:13 --> Security Class Initialized
DEBUG - 2018-06-23 05:58:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 05:58:13 --> Input Class Initialized
INFO - 2018-06-23 05:58:13 --> Language Class Initialized
ERROR - 2018-06-23 05:58:13 --> 404 Page Not Found: /index
INFO - 2018-06-23 05:58:13 --> Config Class Initialized
INFO - 2018-06-23 05:58:13 --> Hooks Class Initialized
DEBUG - 2018-06-23 05:58:13 --> UTF-8 Support Enabled
INFO - 2018-06-23 05:58:13 --> Utf8 Class Initialized
INFO - 2018-06-23 05:58:13 --> URI Class Initialized
INFO - 2018-06-23 05:58:13 --> Router Class Initialized
INFO - 2018-06-23 05:58:13 --> Output Class Initialized
INFO - 2018-06-23 05:58:13 --> Security Class Initialized
DEBUG - 2018-06-23 05:58:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 05:58:13 --> Input Class Initialized
INFO - 2018-06-23 05:58:13 --> Language Class Initialized
ERROR - 2018-06-23 05:58:13 --> 404 Page Not Found: /index
INFO - 2018-06-23 05:58:13 --> Config Class Initialized
INFO - 2018-06-23 05:58:13 --> Hooks Class Initialized
DEBUG - 2018-06-23 05:58:13 --> UTF-8 Support Enabled
INFO - 2018-06-23 05:58:13 --> Utf8 Class Initialized
INFO - 2018-06-23 05:58:13 --> URI Class Initialized
INFO - 2018-06-23 05:58:13 --> Router Class Initialized
INFO - 2018-06-23 05:58:13 --> Output Class Initialized
INFO - 2018-06-23 05:58:13 --> Security Class Initialized
DEBUG - 2018-06-23 05:58:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 05:58:13 --> Input Class Initialized
INFO - 2018-06-23 05:58:13 --> Language Class Initialized
ERROR - 2018-06-23 05:58:13 --> 404 Page Not Found: /index
INFO - 2018-06-23 05:58:13 --> Config Class Initialized
INFO - 2018-06-23 05:58:13 --> Hooks Class Initialized
DEBUG - 2018-06-23 05:58:13 --> UTF-8 Support Enabled
INFO - 2018-06-23 05:58:13 --> Utf8 Class Initialized
INFO - 2018-06-23 05:58:13 --> URI Class Initialized
INFO - 2018-06-23 05:58:13 --> Router Class Initialized
INFO - 2018-06-23 05:58:13 --> Output Class Initialized
INFO - 2018-06-23 05:58:13 --> Security Class Initialized
DEBUG - 2018-06-23 05:58:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 05:58:13 --> Input Class Initialized
INFO - 2018-06-23 05:58:13 --> Language Class Initialized
ERROR - 2018-06-23 05:58:13 --> 404 Page Not Found: /index
INFO - 2018-06-23 05:58:13 --> Config Class Initialized
INFO - 2018-06-23 05:58:13 --> Hooks Class Initialized
DEBUG - 2018-06-23 05:58:13 --> UTF-8 Support Enabled
INFO - 2018-06-23 05:58:13 --> Utf8 Class Initialized
INFO - 2018-06-23 05:58:13 --> URI Class Initialized
INFO - 2018-06-23 05:58:13 --> Router Class Initialized
INFO - 2018-06-23 05:58:13 --> Output Class Initialized
INFO - 2018-06-23 05:58:13 --> Security Class Initialized
DEBUG - 2018-06-23 05:58:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 05:58:13 --> Input Class Initialized
INFO - 2018-06-23 05:58:13 --> Language Class Initialized
ERROR - 2018-06-23 05:58:13 --> 404 Page Not Found: /index
INFO - 2018-06-23 05:58:33 --> Config Class Initialized
INFO - 2018-06-23 05:58:33 --> Hooks Class Initialized
DEBUG - 2018-06-23 05:58:33 --> UTF-8 Support Enabled
INFO - 2018-06-23 05:58:33 --> Utf8 Class Initialized
INFO - 2018-06-23 05:58:33 --> URI Class Initialized
INFO - 2018-06-23 05:58:33 --> Router Class Initialized
INFO - 2018-06-23 05:58:33 --> Output Class Initialized
INFO - 2018-06-23 05:58:33 --> Security Class Initialized
DEBUG - 2018-06-23 05:58:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 05:58:33 --> Input Class Initialized
INFO - 2018-06-23 05:58:33 --> Language Class Initialized
INFO - 2018-06-23 05:58:33 --> Language Class Initialized
INFO - 2018-06-23 05:58:33 --> Config Class Initialized
INFO - 2018-06-23 05:58:33 --> Loader Class Initialized
DEBUG - 2018-06-23 05:58:33 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-23 05:58:33 --> Helper loaded: url_helper
INFO - 2018-06-23 05:58:33 --> Helper loaded: form_helper
INFO - 2018-06-23 05:58:33 --> Helper loaded: date_helper
INFO - 2018-06-23 05:58:33 --> Helper loaded: util_helper
INFO - 2018-06-23 05:58:33 --> Helper loaded: text_helper
INFO - 2018-06-23 05:58:33 --> Helper loaded: string_helper
INFO - 2018-06-23 05:58:33 --> Database Driver Class Initialized
DEBUG - 2018-06-23 05:58:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-23 05:58:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-23 05:58:33 --> Email Class Initialized
INFO - 2018-06-23 05:58:33 --> Controller Class Initialized
DEBUG - 2018-06-23 05:58:33 --> Home MX_Controller Initialized
DEBUG - 2018-06-23 05:58:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-23 05:58:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-23 05:58:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-23 05:58:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-23 05:58:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-23 05:58:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-23 05:58:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/search_page.php
INFO - 2018-06-23 05:58:33 --> Final output sent to browser
DEBUG - 2018-06-23 05:58:34 --> Total execution time: 0.4571
INFO - 2018-06-23 05:58:34 --> Config Class Initialized
INFO - 2018-06-23 05:58:34 --> Hooks Class Initialized
DEBUG - 2018-06-23 05:58:34 --> UTF-8 Support Enabled
INFO - 2018-06-23 05:58:34 --> Utf8 Class Initialized
INFO - 2018-06-23 05:58:34 --> URI Class Initialized
INFO - 2018-06-23 05:58:34 --> Router Class Initialized
INFO - 2018-06-23 05:58:34 --> Output Class Initialized
INFO - 2018-06-23 05:58:34 --> Security Class Initialized
DEBUG - 2018-06-23 05:58:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 05:58:34 --> Input Class Initialized
INFO - 2018-06-23 05:58:34 --> Language Class Initialized
ERROR - 2018-06-23 05:58:34 --> 404 Page Not Found: /index
INFO - 2018-06-23 05:58:34 --> Config Class Initialized
INFO - 2018-06-23 05:58:34 --> Hooks Class Initialized
DEBUG - 2018-06-23 05:58:34 --> UTF-8 Support Enabled
INFO - 2018-06-23 05:58:34 --> Utf8 Class Initialized
INFO - 2018-06-23 05:58:34 --> URI Class Initialized
INFO - 2018-06-23 05:58:34 --> Router Class Initialized
INFO - 2018-06-23 05:58:34 --> Output Class Initialized
INFO - 2018-06-23 05:58:34 --> Security Class Initialized
DEBUG - 2018-06-23 05:58:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 05:58:34 --> Input Class Initialized
INFO - 2018-06-23 05:58:34 --> Language Class Initialized
ERROR - 2018-06-23 05:58:34 --> 404 Page Not Found: /index
INFO - 2018-06-23 05:58:34 --> Config Class Initialized
INFO - 2018-06-23 05:58:34 --> Hooks Class Initialized
DEBUG - 2018-06-23 05:58:34 --> UTF-8 Support Enabled
INFO - 2018-06-23 05:58:34 --> Utf8 Class Initialized
INFO - 2018-06-23 05:58:34 --> URI Class Initialized
INFO - 2018-06-23 05:58:34 --> Router Class Initialized
INFO - 2018-06-23 05:58:34 --> Output Class Initialized
INFO - 2018-06-23 05:58:35 --> Security Class Initialized
DEBUG - 2018-06-23 05:58:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 05:58:35 --> Input Class Initialized
INFO - 2018-06-23 05:58:35 --> Language Class Initialized
ERROR - 2018-06-23 05:58:35 --> 404 Page Not Found: /index
INFO - 2018-06-23 05:58:35 --> Config Class Initialized
INFO - 2018-06-23 05:58:35 --> Hooks Class Initialized
DEBUG - 2018-06-23 05:58:35 --> UTF-8 Support Enabled
INFO - 2018-06-23 05:58:35 --> Utf8 Class Initialized
INFO - 2018-06-23 05:58:35 --> URI Class Initialized
INFO - 2018-06-23 05:58:35 --> Router Class Initialized
INFO - 2018-06-23 05:58:35 --> Output Class Initialized
INFO - 2018-06-23 05:58:35 --> Security Class Initialized
DEBUG - 2018-06-23 05:58:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 05:58:35 --> Input Class Initialized
INFO - 2018-06-23 05:58:35 --> Language Class Initialized
ERROR - 2018-06-23 05:58:35 --> 404 Page Not Found: /index
INFO - 2018-06-23 05:58:35 --> Config Class Initialized
INFO - 2018-06-23 05:58:35 --> Hooks Class Initialized
DEBUG - 2018-06-23 05:58:35 --> UTF-8 Support Enabled
INFO - 2018-06-23 05:58:35 --> Utf8 Class Initialized
INFO - 2018-06-23 05:58:35 --> URI Class Initialized
INFO - 2018-06-23 05:58:35 --> Router Class Initialized
INFO - 2018-06-23 05:58:35 --> Output Class Initialized
INFO - 2018-06-23 05:58:35 --> Security Class Initialized
DEBUG - 2018-06-23 05:58:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 05:58:35 --> Input Class Initialized
INFO - 2018-06-23 05:58:35 --> Language Class Initialized
ERROR - 2018-06-23 05:58:35 --> 404 Page Not Found: /index
INFO - 2018-06-23 05:58:35 --> Config Class Initialized
INFO - 2018-06-23 05:58:35 --> Hooks Class Initialized
DEBUG - 2018-06-23 05:58:35 --> UTF-8 Support Enabled
INFO - 2018-06-23 05:58:35 --> Utf8 Class Initialized
INFO - 2018-06-23 05:58:35 --> URI Class Initialized
INFO - 2018-06-23 05:58:35 --> Router Class Initialized
INFO - 2018-06-23 05:58:35 --> Output Class Initialized
INFO - 2018-06-23 05:58:35 --> Security Class Initialized
DEBUG - 2018-06-23 05:58:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 05:58:35 --> Input Class Initialized
INFO - 2018-06-23 05:58:35 --> Language Class Initialized
ERROR - 2018-06-23 05:58:35 --> 404 Page Not Found: /index
INFO - 2018-06-23 05:58:49 --> Config Class Initialized
INFO - 2018-06-23 05:58:49 --> Hooks Class Initialized
DEBUG - 2018-06-23 05:58:49 --> UTF-8 Support Enabled
INFO - 2018-06-23 05:58:49 --> Utf8 Class Initialized
INFO - 2018-06-23 05:58:49 --> URI Class Initialized
INFO - 2018-06-23 05:58:49 --> Router Class Initialized
INFO - 2018-06-23 05:58:49 --> Output Class Initialized
INFO - 2018-06-23 05:58:49 --> Security Class Initialized
DEBUG - 2018-06-23 05:58:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 05:58:49 --> Input Class Initialized
INFO - 2018-06-23 05:58:49 --> Language Class Initialized
INFO - 2018-06-23 05:58:49 --> Language Class Initialized
INFO - 2018-06-23 05:58:49 --> Config Class Initialized
INFO - 2018-06-23 05:58:49 --> Loader Class Initialized
DEBUG - 2018-06-23 05:58:49 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-23 05:58:49 --> Helper loaded: url_helper
INFO - 2018-06-23 05:58:49 --> Helper loaded: form_helper
INFO - 2018-06-23 05:58:49 --> Helper loaded: date_helper
INFO - 2018-06-23 05:58:49 --> Helper loaded: util_helper
INFO - 2018-06-23 05:58:49 --> Helper loaded: text_helper
INFO - 2018-06-23 05:58:49 --> Helper loaded: string_helper
INFO - 2018-06-23 05:58:49 --> Database Driver Class Initialized
DEBUG - 2018-06-23 05:58:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-23 05:58:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-23 05:58:49 --> Email Class Initialized
INFO - 2018-06-23 05:58:49 --> Controller Class Initialized
DEBUG - 2018-06-23 05:58:49 --> Home MX_Controller Initialized
DEBUG - 2018-06-23 05:58:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-23 05:58:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-23 05:58:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-23 05:58:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-23 05:58:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-23 05:58:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-23 05:58:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/search_page.php
INFO - 2018-06-23 05:58:49 --> Final output sent to browser
DEBUG - 2018-06-23 05:58:49 --> Total execution time: 0.4581
INFO - 2018-06-23 05:58:50 --> Config Class Initialized
INFO - 2018-06-23 05:58:50 --> Hooks Class Initialized
DEBUG - 2018-06-23 05:58:50 --> UTF-8 Support Enabled
INFO - 2018-06-23 05:58:50 --> Utf8 Class Initialized
INFO - 2018-06-23 05:58:50 --> URI Class Initialized
INFO - 2018-06-23 05:58:50 --> Router Class Initialized
INFO - 2018-06-23 05:58:50 --> Output Class Initialized
INFO - 2018-06-23 05:58:50 --> Security Class Initialized
DEBUG - 2018-06-23 05:58:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 05:58:50 --> Input Class Initialized
INFO - 2018-06-23 05:58:50 --> Language Class Initialized
ERROR - 2018-06-23 05:58:50 --> 404 Page Not Found: /index
INFO - 2018-06-23 05:58:50 --> Config Class Initialized
INFO - 2018-06-23 05:58:50 --> Hooks Class Initialized
DEBUG - 2018-06-23 05:58:50 --> UTF-8 Support Enabled
INFO - 2018-06-23 05:58:50 --> Utf8 Class Initialized
INFO - 2018-06-23 05:58:50 --> URI Class Initialized
INFO - 2018-06-23 05:58:50 --> Router Class Initialized
INFO - 2018-06-23 05:58:50 --> Output Class Initialized
INFO - 2018-06-23 05:58:50 --> Security Class Initialized
DEBUG - 2018-06-23 05:58:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 05:58:50 --> Input Class Initialized
INFO - 2018-06-23 05:58:50 --> Language Class Initialized
ERROR - 2018-06-23 05:58:50 --> 404 Page Not Found: /index
INFO - 2018-06-23 05:58:50 --> Config Class Initialized
INFO - 2018-06-23 05:58:50 --> Hooks Class Initialized
DEBUG - 2018-06-23 05:58:50 --> UTF-8 Support Enabled
INFO - 2018-06-23 05:58:50 --> Utf8 Class Initialized
INFO - 2018-06-23 05:58:50 --> URI Class Initialized
INFO - 2018-06-23 05:58:50 --> Router Class Initialized
INFO - 2018-06-23 05:58:50 --> Output Class Initialized
INFO - 2018-06-23 05:58:50 --> Security Class Initialized
DEBUG - 2018-06-23 05:58:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 05:58:50 --> Input Class Initialized
INFO - 2018-06-23 05:58:50 --> Language Class Initialized
ERROR - 2018-06-23 05:58:50 --> 404 Page Not Found: /index
INFO - 2018-06-23 06:00:02 --> Config Class Initialized
INFO - 2018-06-23 06:00:02 --> Hooks Class Initialized
DEBUG - 2018-06-23 06:00:03 --> UTF-8 Support Enabled
INFO - 2018-06-23 06:00:03 --> Utf8 Class Initialized
INFO - 2018-06-23 06:00:03 --> URI Class Initialized
DEBUG - 2018-06-23 06:00:03 --> No URI present. Default controller set.
INFO - 2018-06-23 06:00:03 --> Router Class Initialized
INFO - 2018-06-23 06:00:03 --> Output Class Initialized
INFO - 2018-06-23 06:00:03 --> Security Class Initialized
DEBUG - 2018-06-23 06:00:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 06:00:03 --> Input Class Initialized
INFO - 2018-06-23 06:00:03 --> Language Class Initialized
INFO - 2018-06-23 06:00:03 --> Language Class Initialized
INFO - 2018-06-23 06:00:03 --> Config Class Initialized
INFO - 2018-06-23 06:00:03 --> Loader Class Initialized
DEBUG - 2018-06-23 06:00:03 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-23 06:00:03 --> Helper loaded: url_helper
INFO - 2018-06-23 06:00:03 --> Helper loaded: form_helper
INFO - 2018-06-23 06:00:03 --> Helper loaded: date_helper
INFO - 2018-06-23 06:00:03 --> Helper loaded: util_helper
INFO - 2018-06-23 06:00:03 --> Helper loaded: text_helper
INFO - 2018-06-23 06:00:03 --> Helper loaded: string_helper
INFO - 2018-06-23 06:00:03 --> Database Driver Class Initialized
DEBUG - 2018-06-23 06:00:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-23 06:00:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-23 06:00:03 --> Email Class Initialized
INFO - 2018-06-23 06:00:03 --> Controller Class Initialized
DEBUG - 2018-06-23 06:00:03 --> Home MX_Controller Initialized
DEBUG - 2018-06-23 06:00:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-23 06:00:03 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-23 06:00:03 --> Login MX_Controller Initialized
INFO - 2018-06-23 06:00:03 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-23 06:00:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-23 06:00:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-23 06:00:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-23 06:00:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-23 06:00:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-23 06:00:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-23 06:00:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-23 06:00:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-06-23 06:00:03 --> Final output sent to browser
DEBUG - 2018-06-23 06:00:03 --> Total execution time: 0.6619
INFO - 2018-06-23 06:00:04 --> Config Class Initialized
INFO - 2018-06-23 06:00:04 --> Hooks Class Initialized
DEBUG - 2018-06-23 06:00:04 --> UTF-8 Support Enabled
INFO - 2018-06-23 06:00:04 --> Utf8 Class Initialized
INFO - 2018-06-23 06:00:04 --> URI Class Initialized
INFO - 2018-06-23 06:00:04 --> Router Class Initialized
INFO - 2018-06-23 06:00:04 --> Output Class Initialized
INFO - 2018-06-23 06:00:04 --> Security Class Initialized
DEBUG - 2018-06-23 06:00:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 06:00:04 --> Input Class Initialized
INFO - 2018-06-23 06:00:04 --> Language Class Initialized
ERROR - 2018-06-23 06:00:04 --> 404 Page Not Found: /index
INFO - 2018-06-23 06:00:04 --> Config Class Initialized
INFO - 2018-06-23 06:00:04 --> Hooks Class Initialized
DEBUG - 2018-06-23 06:00:04 --> UTF-8 Support Enabled
INFO - 2018-06-23 06:00:04 --> Utf8 Class Initialized
INFO - 2018-06-23 06:00:04 --> URI Class Initialized
INFO - 2018-06-23 06:00:04 --> Router Class Initialized
INFO - 2018-06-23 06:00:04 --> Output Class Initialized
INFO - 2018-06-23 06:00:04 --> Security Class Initialized
DEBUG - 2018-06-23 06:00:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 06:00:04 --> Input Class Initialized
INFO - 2018-06-23 06:00:04 --> Language Class Initialized
ERROR - 2018-06-23 06:00:04 --> 404 Page Not Found: /index
INFO - 2018-06-23 06:00:04 --> Config Class Initialized
INFO - 2018-06-23 06:00:04 --> Hooks Class Initialized
DEBUG - 2018-06-23 06:00:04 --> UTF-8 Support Enabled
INFO - 2018-06-23 06:00:04 --> Utf8 Class Initialized
INFO - 2018-06-23 06:00:04 --> URI Class Initialized
INFO - 2018-06-23 06:00:04 --> Router Class Initialized
INFO - 2018-06-23 06:00:04 --> Output Class Initialized
INFO - 2018-06-23 06:00:04 --> Security Class Initialized
DEBUG - 2018-06-23 06:00:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 06:00:04 --> Input Class Initialized
INFO - 2018-06-23 06:00:04 --> Language Class Initialized
ERROR - 2018-06-23 06:00:04 --> 404 Page Not Found: /index
INFO - 2018-06-23 06:00:04 --> Config Class Initialized
INFO - 2018-06-23 06:00:04 --> Hooks Class Initialized
DEBUG - 2018-06-23 06:00:04 --> UTF-8 Support Enabled
INFO - 2018-06-23 06:00:04 --> Utf8 Class Initialized
INFO - 2018-06-23 06:00:04 --> URI Class Initialized
INFO - 2018-06-23 06:00:04 --> Router Class Initialized
INFO - 2018-06-23 06:00:04 --> Output Class Initialized
INFO - 2018-06-23 06:00:05 --> Security Class Initialized
DEBUG - 2018-06-23 06:00:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 06:00:05 --> Input Class Initialized
INFO - 2018-06-23 06:00:05 --> Language Class Initialized
ERROR - 2018-06-23 06:00:05 --> 404 Page Not Found: /index
INFO - 2018-06-23 06:00:05 --> Config Class Initialized
INFO - 2018-06-23 06:00:05 --> Hooks Class Initialized
DEBUG - 2018-06-23 06:00:05 --> UTF-8 Support Enabled
INFO - 2018-06-23 06:00:05 --> Utf8 Class Initialized
INFO - 2018-06-23 06:00:05 --> URI Class Initialized
INFO - 2018-06-23 06:00:05 --> Router Class Initialized
INFO - 2018-06-23 06:00:05 --> Output Class Initialized
INFO - 2018-06-23 06:00:05 --> Security Class Initialized
DEBUG - 2018-06-23 06:00:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 06:00:05 --> Input Class Initialized
INFO - 2018-06-23 06:00:05 --> Language Class Initialized
ERROR - 2018-06-23 06:00:05 --> 404 Page Not Found: /index
INFO - 2018-06-23 06:00:05 --> Config Class Initialized
INFO - 2018-06-23 06:00:05 --> Hooks Class Initialized
DEBUG - 2018-06-23 06:00:05 --> UTF-8 Support Enabled
INFO - 2018-06-23 06:00:05 --> Utf8 Class Initialized
INFO - 2018-06-23 06:00:05 --> URI Class Initialized
INFO - 2018-06-23 06:00:05 --> Router Class Initialized
INFO - 2018-06-23 06:00:05 --> Output Class Initialized
INFO - 2018-06-23 06:00:05 --> Security Class Initialized
DEBUG - 2018-06-23 06:00:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 06:00:05 --> Input Class Initialized
INFO - 2018-06-23 06:00:05 --> Language Class Initialized
ERROR - 2018-06-23 06:00:05 --> 404 Page Not Found: /index
INFO - 2018-06-23 06:01:42 --> Config Class Initialized
INFO - 2018-06-23 06:01:42 --> Hooks Class Initialized
DEBUG - 2018-06-23 06:01:42 --> UTF-8 Support Enabled
INFO - 2018-06-23 06:01:42 --> Utf8 Class Initialized
INFO - 2018-06-23 06:01:42 --> URI Class Initialized
INFO - 2018-06-23 06:01:42 --> Router Class Initialized
INFO - 2018-06-23 06:01:42 --> Output Class Initialized
INFO - 2018-06-23 06:01:42 --> Security Class Initialized
DEBUG - 2018-06-23 06:01:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 06:01:42 --> Input Class Initialized
INFO - 2018-06-23 06:01:42 --> Language Class Initialized
INFO - 2018-06-23 06:01:42 --> Language Class Initialized
INFO - 2018-06-23 06:01:42 --> Config Class Initialized
INFO - 2018-06-23 06:01:42 --> Loader Class Initialized
DEBUG - 2018-06-23 06:01:42 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-23 06:01:42 --> Helper loaded: url_helper
INFO - 2018-06-23 06:01:42 --> Helper loaded: form_helper
INFO - 2018-06-23 06:01:42 --> Helper loaded: date_helper
INFO - 2018-06-23 06:01:42 --> Helper loaded: util_helper
INFO - 2018-06-23 06:01:42 --> Helper loaded: text_helper
INFO - 2018-06-23 06:01:42 --> Helper loaded: string_helper
INFO - 2018-06-23 06:01:42 --> Database Driver Class Initialized
DEBUG - 2018-06-23 06:01:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-23 06:01:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-23 06:01:42 --> Email Class Initialized
INFO - 2018-06-23 06:01:42 --> Controller Class Initialized
DEBUG - 2018-06-23 06:01:42 --> videos MX_Controller Initialized
INFO - 2018-06-23 06:01:42 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-23 06:01:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-06-23 06:01:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-23 06:01:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-23 06:01:42 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-23 06:01:42 --> Login MX_Controller Initialized
DEBUG - 2018-06-23 06:01:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-23 06:01:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
INFO - 2018-06-23 06:01:42 --> Config Class Initialized
INFO - 2018-06-23 06:01:42 --> Hooks Class Initialized
DEBUG - 2018-06-23 06:01:42 --> UTF-8 Support Enabled
INFO - 2018-06-23 06:01:43 --> Utf8 Class Initialized
INFO - 2018-06-23 06:01:43 --> URI Class Initialized
INFO - 2018-06-23 06:01:43 --> Router Class Initialized
INFO - 2018-06-23 06:01:43 --> Output Class Initialized
INFO - 2018-06-23 06:01:43 --> Security Class Initialized
DEBUG - 2018-06-23 06:01:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 06:01:43 --> Input Class Initialized
INFO - 2018-06-23 06:01:43 --> Language Class Initialized
ERROR - 2018-06-23 06:01:43 --> 404 Page Not Found: /index
INFO - 2018-06-23 06:01:46 --> Config Class Initialized
INFO - 2018-06-23 06:01:46 --> Hooks Class Initialized
DEBUG - 2018-06-23 06:01:46 --> UTF-8 Support Enabled
INFO - 2018-06-23 06:01:46 --> Utf8 Class Initialized
INFO - 2018-06-23 06:01:46 --> URI Class Initialized
INFO - 2018-06-23 06:01:46 --> Router Class Initialized
INFO - 2018-06-23 06:01:46 --> Output Class Initialized
INFO - 2018-06-23 06:01:46 --> Security Class Initialized
DEBUG - 2018-06-23 06:01:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 06:01:46 --> Input Class Initialized
INFO - 2018-06-23 06:01:46 --> Language Class Initialized
INFO - 2018-06-23 06:01:46 --> Language Class Initialized
INFO - 2018-06-23 06:01:46 --> Config Class Initialized
INFO - 2018-06-23 06:01:46 --> Loader Class Initialized
DEBUG - 2018-06-23 06:01:46 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-23 06:01:46 --> Helper loaded: url_helper
INFO - 2018-06-23 06:01:46 --> Helper loaded: form_helper
INFO - 2018-06-23 06:01:46 --> Helper loaded: date_helper
INFO - 2018-06-23 06:01:46 --> Helper loaded: util_helper
INFO - 2018-06-23 06:01:46 --> Helper loaded: text_helper
INFO - 2018-06-23 06:01:46 --> Helper loaded: string_helper
INFO - 2018-06-23 06:01:46 --> Database Driver Class Initialized
DEBUG - 2018-06-23 06:01:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-23 06:01:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-23 06:01:46 --> Email Class Initialized
INFO - 2018-06-23 06:01:46 --> Controller Class Initialized
DEBUG - 2018-06-23 06:01:46 --> Login MX_Controller Initialized
INFO - 2018-06-23 06:01:46 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-23 06:01:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-23 06:01:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-23 06:01:46 --> Email starts for admin@colin.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-06-23 06:01:46 --> User session created for 1
INFO - 2018-06-23 06:01:46 --> Login status admin@colin.com - success
INFO - 2018-06-23 06:01:46 --> Final output sent to browser
DEBUG - 2018-06-23 06:01:46 --> Total execution time: 0.4746
INFO - 2018-06-23 06:01:46 --> Config Class Initialized
INFO - 2018-06-23 06:01:46 --> Hooks Class Initialized
DEBUG - 2018-06-23 06:01:46 --> UTF-8 Support Enabled
INFO - 2018-06-23 06:01:46 --> Utf8 Class Initialized
INFO - 2018-06-23 06:01:46 --> URI Class Initialized
INFO - 2018-06-23 06:01:46 --> Router Class Initialized
INFO - 2018-06-23 06:01:46 --> Output Class Initialized
INFO - 2018-06-23 06:01:46 --> Security Class Initialized
DEBUG - 2018-06-23 06:01:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 06:01:46 --> Input Class Initialized
INFO - 2018-06-23 06:01:46 --> Language Class Initialized
INFO - 2018-06-23 06:01:46 --> Language Class Initialized
INFO - 2018-06-23 06:01:46 --> Config Class Initialized
INFO - 2018-06-23 06:01:46 --> Loader Class Initialized
DEBUG - 2018-06-23 06:01:46 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-23 06:01:46 --> Helper loaded: url_helper
INFO - 2018-06-23 06:01:46 --> Helper loaded: form_helper
INFO - 2018-06-23 06:01:47 --> Helper loaded: date_helper
INFO - 2018-06-23 06:01:47 --> Helper loaded: util_helper
INFO - 2018-06-23 06:01:47 --> Helper loaded: text_helper
INFO - 2018-06-23 06:01:47 --> Helper loaded: string_helper
INFO - 2018-06-23 06:01:47 --> Database Driver Class Initialized
DEBUG - 2018-06-23 06:01:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-23 06:01:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-23 06:01:47 --> Email Class Initialized
INFO - 2018-06-23 06:01:47 --> Controller Class Initialized
DEBUG - 2018-06-23 06:01:47 --> videos MX_Controller Initialized
INFO - 2018-06-23 06:01:47 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-23 06:01:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-06-23 06:01:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-23 06:01:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-23 06:01:47 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-23 06:01:47 --> Login MX_Controller Initialized
DEBUG - 2018-06-23 06:01:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-23 06:01:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-23 06:01:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-23 06:01:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-23 06:01:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-23 06:01:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-23 06:01:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/videos/videos.php
INFO - 2018-06-23 06:01:47 --> Final output sent to browser
DEBUG - 2018-06-23 06:01:47 --> Total execution time: 0.5698
INFO - 2018-06-23 06:01:47 --> Config Class Initialized
INFO - 2018-06-23 06:01:47 --> Hooks Class Initialized
DEBUG - 2018-06-23 06:01:48 --> UTF-8 Support Enabled
INFO - 2018-06-23 06:01:48 --> Utf8 Class Initialized
INFO - 2018-06-23 06:01:48 --> URI Class Initialized
INFO - 2018-06-23 06:01:48 --> Router Class Initialized
INFO - 2018-06-23 06:01:48 --> Output Class Initialized
INFO - 2018-06-23 06:01:48 --> Security Class Initialized
DEBUG - 2018-06-23 06:01:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 06:01:48 --> Input Class Initialized
INFO - 2018-06-23 06:01:48 --> Language Class Initialized
INFO - 2018-06-23 06:01:48 --> Language Class Initialized
INFO - 2018-06-23 06:01:48 --> Config Class Initialized
INFO - 2018-06-23 06:01:48 --> Loader Class Initialized
DEBUG - 2018-06-23 06:01:48 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-23 06:01:48 --> Helper loaded: url_helper
INFO - 2018-06-23 06:01:48 --> Helper loaded: form_helper
INFO - 2018-06-23 06:01:48 --> Helper loaded: date_helper
INFO - 2018-06-23 06:01:48 --> Helper loaded: util_helper
INFO - 2018-06-23 06:01:48 --> Helper loaded: text_helper
INFO - 2018-06-23 06:01:48 --> Helper loaded: string_helper
INFO - 2018-06-23 06:01:48 --> Database Driver Class Initialized
DEBUG - 2018-06-23 06:01:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-23 06:01:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-23 06:01:48 --> Email Class Initialized
INFO - 2018-06-23 06:01:48 --> Controller Class Initialized
DEBUG - 2018-06-23 06:01:48 --> videos MX_Controller Initialized
INFO - 2018-06-23 06:01:48 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-23 06:01:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-06-23 06:01:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-23 06:01:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-23 06:01:48 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-23 06:01:48 --> Login MX_Controller Initialized
DEBUG - 2018-06-23 06:01:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-23 06:01:48 --> Final output sent to browser
DEBUG - 2018-06-23 06:01:48 --> Total execution time: 1.0249
INFO - 2018-06-23 06:02:26 --> Config Class Initialized
INFO - 2018-06-23 06:02:26 --> Hooks Class Initialized
DEBUG - 2018-06-23 06:02:26 --> UTF-8 Support Enabled
INFO - 2018-06-23 06:02:26 --> Utf8 Class Initialized
INFO - 2018-06-23 06:02:26 --> URI Class Initialized
DEBUG - 2018-06-23 06:02:26 --> No URI present. Default controller set.
INFO - 2018-06-23 06:02:26 --> Router Class Initialized
INFO - 2018-06-23 06:02:26 --> Output Class Initialized
INFO - 2018-06-23 06:02:26 --> Security Class Initialized
DEBUG - 2018-06-23 06:02:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 06:02:26 --> Input Class Initialized
INFO - 2018-06-23 06:02:26 --> Language Class Initialized
INFO - 2018-06-23 06:02:26 --> Language Class Initialized
INFO - 2018-06-23 06:02:26 --> Config Class Initialized
INFO - 2018-06-23 06:02:26 --> Loader Class Initialized
DEBUG - 2018-06-23 06:02:26 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-23 06:02:26 --> Helper loaded: url_helper
INFO - 2018-06-23 06:02:26 --> Helper loaded: form_helper
INFO - 2018-06-23 06:02:26 --> Helper loaded: date_helper
INFO - 2018-06-23 06:02:26 --> Helper loaded: util_helper
INFO - 2018-06-23 06:02:27 --> Helper loaded: text_helper
INFO - 2018-06-23 06:02:27 --> Helper loaded: string_helper
INFO - 2018-06-23 06:02:27 --> Database Driver Class Initialized
DEBUG - 2018-06-23 06:02:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-23 06:02:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-23 06:02:27 --> Email Class Initialized
INFO - 2018-06-23 06:02:27 --> Controller Class Initialized
DEBUG - 2018-06-23 06:02:27 --> Home MX_Controller Initialized
DEBUG - 2018-06-23 06:02:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-23 06:02:27 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-23 06:02:27 --> Login MX_Controller Initialized
INFO - 2018-06-23 06:02:27 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-23 06:02:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-23 06:02:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-23 06:02:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-23 06:02:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-23 06:02:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-23 06:02:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-23 06:02:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-23 06:02:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-06-23 06:02:27 --> Final output sent to browser
DEBUG - 2018-06-23 06:02:27 --> Total execution time: 0.5543
INFO - 2018-06-23 06:02:27 --> Config Class Initialized
INFO - 2018-06-23 06:02:27 --> Hooks Class Initialized
DEBUG - 2018-06-23 06:02:27 --> UTF-8 Support Enabled
INFO - 2018-06-23 06:02:27 --> Utf8 Class Initialized
INFO - 2018-06-23 06:02:27 --> URI Class Initialized
INFO - 2018-06-23 06:02:27 --> Router Class Initialized
INFO - 2018-06-23 06:02:27 --> Output Class Initialized
INFO - 2018-06-23 06:02:27 --> Security Class Initialized
DEBUG - 2018-06-23 06:02:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 06:02:27 --> Input Class Initialized
INFO - 2018-06-23 06:02:27 --> Language Class Initialized
ERROR - 2018-06-23 06:02:27 --> 404 Page Not Found: /index
INFO - 2018-06-23 06:02:28 --> Config Class Initialized
INFO - 2018-06-23 06:02:28 --> Hooks Class Initialized
DEBUG - 2018-06-23 06:02:28 --> UTF-8 Support Enabled
INFO - 2018-06-23 06:02:28 --> Utf8 Class Initialized
INFO - 2018-06-23 06:02:28 --> URI Class Initialized
INFO - 2018-06-23 06:02:28 --> Router Class Initialized
INFO - 2018-06-23 06:02:28 --> Output Class Initialized
INFO - 2018-06-23 06:02:28 --> Security Class Initialized
DEBUG - 2018-06-23 06:02:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 06:02:28 --> Input Class Initialized
INFO - 2018-06-23 06:02:28 --> Language Class Initialized
ERROR - 2018-06-23 06:02:28 --> 404 Page Not Found: /index
INFO - 2018-06-23 06:02:28 --> Config Class Initialized
INFO - 2018-06-23 06:02:28 --> Hooks Class Initialized
DEBUG - 2018-06-23 06:02:28 --> UTF-8 Support Enabled
INFO - 2018-06-23 06:02:28 --> Utf8 Class Initialized
INFO - 2018-06-23 06:02:28 --> URI Class Initialized
INFO - 2018-06-23 06:02:28 --> Router Class Initialized
INFO - 2018-06-23 06:02:28 --> Output Class Initialized
INFO - 2018-06-23 06:02:28 --> Security Class Initialized
DEBUG - 2018-06-23 06:02:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 06:02:28 --> Input Class Initialized
INFO - 2018-06-23 06:02:28 --> Language Class Initialized
ERROR - 2018-06-23 06:02:28 --> 404 Page Not Found: /index
INFO - 2018-06-23 06:02:31 --> Config Class Initialized
INFO - 2018-06-23 06:02:31 --> Hooks Class Initialized
DEBUG - 2018-06-23 06:02:31 --> UTF-8 Support Enabled
INFO - 2018-06-23 06:02:31 --> Utf8 Class Initialized
INFO - 2018-06-23 06:02:31 --> URI Class Initialized
INFO - 2018-06-23 06:02:31 --> Router Class Initialized
INFO - 2018-06-23 06:02:31 --> Output Class Initialized
INFO - 2018-06-23 06:02:31 --> Security Class Initialized
DEBUG - 2018-06-23 06:02:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 06:02:31 --> Input Class Initialized
INFO - 2018-06-23 06:02:31 --> Language Class Initialized
INFO - 2018-06-23 06:02:31 --> Language Class Initialized
INFO - 2018-06-23 06:02:31 --> Config Class Initialized
INFO - 2018-06-23 06:02:31 --> Loader Class Initialized
DEBUG - 2018-06-23 06:02:31 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-23 06:02:31 --> Helper loaded: url_helper
INFO - 2018-06-23 06:02:31 --> Helper loaded: form_helper
INFO - 2018-06-23 06:02:31 --> Helper loaded: date_helper
INFO - 2018-06-23 06:02:31 --> Helper loaded: util_helper
INFO - 2018-06-23 06:02:31 --> Helper loaded: text_helper
INFO - 2018-06-23 06:02:31 --> Helper loaded: string_helper
INFO - 2018-06-23 06:02:31 --> Database Driver Class Initialized
DEBUG - 2018-06-23 06:02:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-23 06:02:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-23 06:02:31 --> Email Class Initialized
INFO - 2018-06-23 06:02:31 --> Controller Class Initialized
DEBUG - 2018-06-23 06:02:31 --> Home MX_Controller Initialized
DEBUG - 2018-06-23 06:02:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-23 06:02:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-23 06:02:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-23 06:02:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-23 06:02:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-23 06:02:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-23 06:02:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/search_page.php
INFO - 2018-06-23 06:02:31 --> Final output sent to browser
DEBUG - 2018-06-23 06:02:31 --> Total execution time: 0.4869
INFO - 2018-06-23 06:02:31 --> Config Class Initialized
INFO - 2018-06-23 06:02:31 --> Hooks Class Initialized
DEBUG - 2018-06-23 06:02:31 --> UTF-8 Support Enabled
INFO - 2018-06-23 06:02:32 --> Utf8 Class Initialized
INFO - 2018-06-23 06:02:32 --> URI Class Initialized
INFO - 2018-06-23 06:02:32 --> Router Class Initialized
INFO - 2018-06-23 06:02:32 --> Output Class Initialized
INFO - 2018-06-23 06:02:32 --> Security Class Initialized
DEBUG - 2018-06-23 06:02:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 06:02:32 --> Input Class Initialized
INFO - 2018-06-23 06:02:32 --> Language Class Initialized
ERROR - 2018-06-23 06:02:32 --> 404 Page Not Found: /index
INFO - 2018-06-23 06:02:32 --> Config Class Initialized
INFO - 2018-06-23 06:02:32 --> Hooks Class Initialized
DEBUG - 2018-06-23 06:02:32 --> UTF-8 Support Enabled
INFO - 2018-06-23 06:02:32 --> Utf8 Class Initialized
INFO - 2018-06-23 06:02:32 --> URI Class Initialized
INFO - 2018-06-23 06:02:32 --> Router Class Initialized
INFO - 2018-06-23 06:02:32 --> Output Class Initialized
INFO - 2018-06-23 06:02:32 --> Security Class Initialized
DEBUG - 2018-06-23 06:02:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 06:02:32 --> Input Class Initialized
INFO - 2018-06-23 06:02:32 --> Language Class Initialized
ERROR - 2018-06-23 06:02:32 --> 404 Page Not Found: /index
INFO - 2018-06-23 06:02:32 --> Config Class Initialized
INFO - 2018-06-23 06:02:32 --> Hooks Class Initialized
DEBUG - 2018-06-23 06:02:32 --> UTF-8 Support Enabled
INFO - 2018-06-23 06:02:32 --> Utf8 Class Initialized
INFO - 2018-06-23 06:02:32 --> URI Class Initialized
INFO - 2018-06-23 06:02:32 --> Router Class Initialized
INFO - 2018-06-23 06:02:32 --> Output Class Initialized
INFO - 2018-06-23 06:02:32 --> Security Class Initialized
DEBUG - 2018-06-23 06:02:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 06:02:32 --> Input Class Initialized
INFO - 2018-06-23 06:02:32 --> Language Class Initialized
ERROR - 2018-06-23 06:02:32 --> 404 Page Not Found: /index
INFO - 2018-06-23 06:03:48 --> Config Class Initialized
INFO - 2018-06-23 06:03:48 --> Hooks Class Initialized
DEBUG - 2018-06-23 06:03:48 --> UTF-8 Support Enabled
INFO - 2018-06-23 06:03:48 --> Utf8 Class Initialized
INFO - 2018-06-23 06:03:48 --> URI Class Initialized
INFO - 2018-06-23 06:03:48 --> Router Class Initialized
INFO - 2018-06-23 06:03:48 --> Output Class Initialized
INFO - 2018-06-23 06:03:48 --> Security Class Initialized
DEBUG - 2018-06-23 06:03:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 06:03:48 --> Input Class Initialized
INFO - 2018-06-23 06:03:48 --> Language Class Initialized
INFO - 2018-06-23 06:03:48 --> Language Class Initialized
INFO - 2018-06-23 06:03:48 --> Config Class Initialized
INFO - 2018-06-23 06:03:48 --> Loader Class Initialized
DEBUG - 2018-06-23 06:03:48 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-23 06:03:48 --> Helper loaded: url_helper
INFO - 2018-06-23 06:03:48 --> Helper loaded: form_helper
INFO - 2018-06-23 06:03:48 --> Helper loaded: date_helper
INFO - 2018-06-23 06:03:48 --> Helper loaded: util_helper
INFO - 2018-06-23 06:03:48 --> Helper loaded: text_helper
INFO - 2018-06-23 06:03:48 --> Helper loaded: string_helper
INFO - 2018-06-23 06:03:48 --> Database Driver Class Initialized
DEBUG - 2018-06-23 06:03:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-23 06:03:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-23 06:03:48 --> Email Class Initialized
INFO - 2018-06-23 06:03:48 --> Controller Class Initialized
DEBUG - 2018-06-23 06:03:48 --> Home MX_Controller Initialized
DEBUG - 2018-06-23 06:03:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-23 06:03:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-23 06:03:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-23 06:03:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-23 06:03:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-23 06:03:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-23 06:03:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/search_page.php
INFO - 2018-06-23 06:03:49 --> Final output sent to browser
DEBUG - 2018-06-23 06:03:49 --> Total execution time: 0.7573
INFO - 2018-06-23 06:03:49 --> Config Class Initialized
INFO - 2018-06-23 06:03:49 --> Hooks Class Initialized
DEBUG - 2018-06-23 06:03:49 --> UTF-8 Support Enabled
INFO - 2018-06-23 06:03:49 --> Utf8 Class Initialized
INFO - 2018-06-23 06:03:49 --> URI Class Initialized
INFO - 2018-06-23 06:03:49 --> Router Class Initialized
INFO - 2018-06-23 06:03:49 --> Output Class Initialized
INFO - 2018-06-23 06:03:49 --> Security Class Initialized
DEBUG - 2018-06-23 06:03:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 06:03:49 --> Input Class Initialized
INFO - 2018-06-23 06:03:49 --> Language Class Initialized
ERROR - 2018-06-23 06:03:49 --> 404 Page Not Found: /index
INFO - 2018-06-23 06:03:49 --> Config Class Initialized
INFO - 2018-06-23 06:03:49 --> Hooks Class Initialized
DEBUG - 2018-06-23 06:03:49 --> UTF-8 Support Enabled
INFO - 2018-06-23 06:03:49 --> Utf8 Class Initialized
INFO - 2018-06-23 06:03:49 --> URI Class Initialized
INFO - 2018-06-23 06:03:49 --> Router Class Initialized
INFO - 2018-06-23 06:03:49 --> Output Class Initialized
INFO - 2018-06-23 06:03:49 --> Security Class Initialized
DEBUG - 2018-06-23 06:03:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 06:03:49 --> Input Class Initialized
INFO - 2018-06-23 06:03:49 --> Language Class Initialized
ERROR - 2018-06-23 06:03:49 --> 404 Page Not Found: /index
INFO - 2018-06-23 06:03:49 --> Config Class Initialized
INFO - 2018-06-23 06:03:49 --> Hooks Class Initialized
DEBUG - 2018-06-23 06:03:50 --> UTF-8 Support Enabled
INFO - 2018-06-23 06:03:50 --> Utf8 Class Initialized
INFO - 2018-06-23 06:03:50 --> URI Class Initialized
INFO - 2018-06-23 06:03:50 --> Router Class Initialized
INFO - 2018-06-23 06:03:50 --> Output Class Initialized
INFO - 2018-06-23 06:03:50 --> Security Class Initialized
DEBUG - 2018-06-23 06:03:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 06:03:50 --> Input Class Initialized
INFO - 2018-06-23 06:03:50 --> Language Class Initialized
ERROR - 2018-06-23 06:03:50 --> 404 Page Not Found: /index
INFO - 2018-06-23 06:03:52 --> Config Class Initialized
INFO - 2018-06-23 06:03:52 --> Hooks Class Initialized
DEBUG - 2018-06-23 06:03:52 --> UTF-8 Support Enabled
INFO - 2018-06-23 06:03:52 --> Utf8 Class Initialized
INFO - 2018-06-23 06:03:52 --> URI Class Initialized
INFO - 2018-06-23 06:03:52 --> Router Class Initialized
INFO - 2018-06-23 06:03:52 --> Output Class Initialized
INFO - 2018-06-23 06:03:52 --> Security Class Initialized
DEBUG - 2018-06-23 06:03:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 06:03:52 --> Input Class Initialized
INFO - 2018-06-23 06:03:52 --> Language Class Initialized
INFO - 2018-06-23 06:03:52 --> Language Class Initialized
INFO - 2018-06-23 06:03:52 --> Config Class Initialized
INFO - 2018-06-23 06:03:52 --> Loader Class Initialized
DEBUG - 2018-06-23 06:03:52 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-23 06:03:52 --> Helper loaded: url_helper
INFO - 2018-06-23 06:03:52 --> Helper loaded: form_helper
INFO - 2018-06-23 06:03:52 --> Helper loaded: date_helper
INFO - 2018-06-23 06:03:52 --> Helper loaded: util_helper
INFO - 2018-06-23 06:03:52 --> Helper loaded: text_helper
INFO - 2018-06-23 06:03:52 --> Helper loaded: string_helper
INFO - 2018-06-23 06:03:52 --> Database Driver Class Initialized
DEBUG - 2018-06-23 06:03:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-23 06:03:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-23 06:03:52 --> Email Class Initialized
INFO - 2018-06-23 06:03:52 --> Controller Class Initialized
DEBUG - 2018-06-23 06:03:52 --> Home MX_Controller Initialized
DEBUG - 2018-06-23 06:03:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-23 06:03:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-23 06:03:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-23 06:03:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-23 06:03:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-23 06:03:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-23 06:03:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/search_page.php
INFO - 2018-06-23 06:03:53 --> Final output sent to browser
DEBUG - 2018-06-23 06:03:53 --> Total execution time: 0.4802
INFO - 2018-06-23 06:03:53 --> Config Class Initialized
INFO - 2018-06-23 06:03:53 --> Hooks Class Initialized
DEBUG - 2018-06-23 06:03:53 --> UTF-8 Support Enabled
INFO - 2018-06-23 06:03:53 --> Utf8 Class Initialized
INFO - 2018-06-23 06:03:53 --> URI Class Initialized
INFO - 2018-06-23 06:03:53 --> Router Class Initialized
INFO - 2018-06-23 06:03:53 --> Output Class Initialized
INFO - 2018-06-23 06:03:53 --> Security Class Initialized
DEBUG - 2018-06-23 06:03:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 06:03:53 --> Input Class Initialized
INFO - 2018-06-23 06:03:53 --> Language Class Initialized
ERROR - 2018-06-23 06:03:53 --> 404 Page Not Found: /index
INFO - 2018-06-23 06:03:53 --> Config Class Initialized
INFO - 2018-06-23 06:03:53 --> Hooks Class Initialized
DEBUG - 2018-06-23 06:03:53 --> UTF-8 Support Enabled
INFO - 2018-06-23 06:03:53 --> Utf8 Class Initialized
INFO - 2018-06-23 06:03:53 --> URI Class Initialized
INFO - 2018-06-23 06:03:53 --> Router Class Initialized
INFO - 2018-06-23 06:03:53 --> Output Class Initialized
INFO - 2018-06-23 06:03:53 --> Security Class Initialized
DEBUG - 2018-06-23 06:03:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 06:03:53 --> Input Class Initialized
INFO - 2018-06-23 06:03:53 --> Language Class Initialized
ERROR - 2018-06-23 06:03:53 --> 404 Page Not Found: /index
INFO - 2018-06-23 06:03:53 --> Config Class Initialized
INFO - 2018-06-23 06:03:53 --> Hooks Class Initialized
DEBUG - 2018-06-23 06:03:53 --> UTF-8 Support Enabled
INFO - 2018-06-23 06:03:54 --> Utf8 Class Initialized
INFO - 2018-06-23 06:03:54 --> URI Class Initialized
INFO - 2018-06-23 06:03:54 --> Router Class Initialized
INFO - 2018-06-23 06:03:54 --> Output Class Initialized
INFO - 2018-06-23 06:03:54 --> Security Class Initialized
DEBUG - 2018-06-23 06:03:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 06:03:54 --> Input Class Initialized
INFO - 2018-06-23 06:03:54 --> Language Class Initialized
ERROR - 2018-06-23 06:03:54 --> 404 Page Not Found: /index
INFO - 2018-06-23 06:03:55 --> Config Class Initialized
INFO - 2018-06-23 06:03:55 --> Hooks Class Initialized
DEBUG - 2018-06-23 06:03:55 --> UTF-8 Support Enabled
INFO - 2018-06-23 06:03:55 --> Utf8 Class Initialized
INFO - 2018-06-23 06:03:55 --> URI Class Initialized
INFO - 2018-06-23 06:03:55 --> Router Class Initialized
INFO - 2018-06-23 06:03:55 --> Output Class Initialized
INFO - 2018-06-23 06:03:55 --> Security Class Initialized
DEBUG - 2018-06-23 06:03:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 06:03:55 --> Input Class Initialized
INFO - 2018-06-23 06:03:55 --> Language Class Initialized
INFO - 2018-06-23 06:03:55 --> Language Class Initialized
INFO - 2018-06-23 06:03:55 --> Config Class Initialized
INFO - 2018-06-23 06:03:55 --> Loader Class Initialized
DEBUG - 2018-06-23 06:03:56 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-23 06:03:56 --> Helper loaded: url_helper
INFO - 2018-06-23 06:03:56 --> Helper loaded: form_helper
INFO - 2018-06-23 06:03:56 --> Helper loaded: date_helper
INFO - 2018-06-23 06:03:56 --> Helper loaded: util_helper
INFO - 2018-06-23 06:03:56 --> Helper loaded: text_helper
INFO - 2018-06-23 06:03:56 --> Helper loaded: string_helper
INFO - 2018-06-23 06:03:56 --> Database Driver Class Initialized
DEBUG - 2018-06-23 06:03:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-23 06:03:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-23 06:03:56 --> Email Class Initialized
INFO - 2018-06-23 06:03:56 --> Controller Class Initialized
DEBUG - 2018-06-23 06:03:56 --> Home MX_Controller Initialized
DEBUG - 2018-06-23 06:03:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-23 06:03:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-23 06:03:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-23 06:03:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-23 06:03:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-23 06:03:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-23 06:03:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/search_page.php
INFO - 2018-06-23 06:03:56 --> Final output sent to browser
DEBUG - 2018-06-23 06:03:56 --> Total execution time: 0.4871
INFO - 2018-06-23 06:03:56 --> Config Class Initialized
INFO - 2018-06-23 06:03:56 --> Hooks Class Initialized
DEBUG - 2018-06-23 06:03:56 --> UTF-8 Support Enabled
INFO - 2018-06-23 06:03:56 --> Utf8 Class Initialized
INFO - 2018-06-23 06:03:56 --> URI Class Initialized
INFO - 2018-06-23 06:03:56 --> Router Class Initialized
INFO - 2018-06-23 06:03:56 --> Output Class Initialized
INFO - 2018-06-23 06:03:56 --> Security Class Initialized
DEBUG - 2018-06-23 06:03:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 06:03:56 --> Input Class Initialized
INFO - 2018-06-23 06:03:56 --> Language Class Initialized
ERROR - 2018-06-23 06:03:56 --> 404 Page Not Found: /index
INFO - 2018-06-23 06:03:56 --> Config Class Initialized
INFO - 2018-06-23 06:03:56 --> Hooks Class Initialized
DEBUG - 2018-06-23 06:03:56 --> UTF-8 Support Enabled
INFO - 2018-06-23 06:03:56 --> Utf8 Class Initialized
INFO - 2018-06-23 06:03:57 --> URI Class Initialized
INFO - 2018-06-23 06:03:57 --> Router Class Initialized
INFO - 2018-06-23 06:03:57 --> Output Class Initialized
INFO - 2018-06-23 06:03:57 --> Security Class Initialized
DEBUG - 2018-06-23 06:03:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 06:03:57 --> Input Class Initialized
INFO - 2018-06-23 06:03:57 --> Language Class Initialized
ERROR - 2018-06-23 06:03:57 --> 404 Page Not Found: /index
INFO - 2018-06-23 06:03:57 --> Config Class Initialized
INFO - 2018-06-23 06:03:57 --> Hooks Class Initialized
DEBUG - 2018-06-23 06:03:57 --> UTF-8 Support Enabled
INFO - 2018-06-23 06:03:57 --> Utf8 Class Initialized
INFO - 2018-06-23 06:03:57 --> URI Class Initialized
INFO - 2018-06-23 06:03:57 --> Router Class Initialized
INFO - 2018-06-23 06:03:57 --> Output Class Initialized
INFO - 2018-06-23 06:03:57 --> Security Class Initialized
DEBUG - 2018-06-23 06:03:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 06:03:57 --> Input Class Initialized
INFO - 2018-06-23 06:03:57 --> Language Class Initialized
ERROR - 2018-06-23 06:03:57 --> 404 Page Not Found: /index
INFO - 2018-06-23 06:04:33 --> Config Class Initialized
INFO - 2018-06-23 06:04:33 --> Hooks Class Initialized
DEBUG - 2018-06-23 06:04:33 --> UTF-8 Support Enabled
INFO - 2018-06-23 06:04:33 --> Utf8 Class Initialized
INFO - 2018-06-23 06:04:33 --> URI Class Initialized
INFO - 2018-06-23 06:04:33 --> Router Class Initialized
INFO - 2018-06-23 06:04:33 --> Output Class Initialized
INFO - 2018-06-23 06:04:33 --> Security Class Initialized
DEBUG - 2018-06-23 06:04:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 06:04:33 --> Input Class Initialized
INFO - 2018-06-23 06:04:33 --> Language Class Initialized
INFO - 2018-06-23 06:04:33 --> Language Class Initialized
INFO - 2018-06-23 06:04:33 --> Config Class Initialized
INFO - 2018-06-23 06:04:33 --> Loader Class Initialized
DEBUG - 2018-06-23 06:04:33 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-23 06:04:33 --> Helper loaded: url_helper
INFO - 2018-06-23 06:04:33 --> Helper loaded: form_helper
INFO - 2018-06-23 06:04:33 --> Helper loaded: date_helper
INFO - 2018-06-23 06:04:33 --> Helper loaded: util_helper
INFO - 2018-06-23 06:04:33 --> Helper loaded: text_helper
INFO - 2018-06-23 06:04:33 --> Helper loaded: string_helper
INFO - 2018-06-23 06:04:33 --> Database Driver Class Initialized
DEBUG - 2018-06-23 06:04:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-23 06:04:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-23 06:04:33 --> Email Class Initialized
INFO - 2018-06-23 06:04:33 --> Controller Class Initialized
DEBUG - 2018-06-23 06:04:33 --> Home MX_Controller Initialized
DEBUG - 2018-06-23 06:04:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-23 06:04:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-23 06:04:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-23 06:04:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-23 06:04:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-23 06:04:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-23 06:04:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/search_page.php
INFO - 2018-06-23 06:04:34 --> Final output sent to browser
DEBUG - 2018-06-23 06:04:34 --> Total execution time: 0.4868
INFO - 2018-06-23 06:04:38 --> Config Class Initialized
INFO - 2018-06-23 06:04:38 --> Hooks Class Initialized
DEBUG - 2018-06-23 06:04:38 --> UTF-8 Support Enabled
INFO - 2018-06-23 06:04:38 --> Utf8 Class Initialized
INFO - 2018-06-23 06:04:38 --> URI Class Initialized
INFO - 2018-06-23 06:04:38 --> Router Class Initialized
INFO - 2018-06-23 06:04:38 --> Output Class Initialized
INFO - 2018-06-23 06:04:38 --> Security Class Initialized
DEBUG - 2018-06-23 06:04:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 06:04:38 --> Input Class Initialized
INFO - 2018-06-23 06:04:38 --> Language Class Initialized
INFO - 2018-06-23 06:04:38 --> Language Class Initialized
INFO - 2018-06-23 06:04:38 --> Config Class Initialized
INFO - 2018-06-23 06:04:38 --> Loader Class Initialized
DEBUG - 2018-06-23 06:04:38 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-23 06:04:38 --> Helper loaded: url_helper
INFO - 2018-06-23 06:04:38 --> Helper loaded: form_helper
INFO - 2018-06-23 06:04:38 --> Helper loaded: date_helper
INFO - 2018-06-23 06:04:38 --> Helper loaded: util_helper
INFO - 2018-06-23 06:04:38 --> Helper loaded: text_helper
INFO - 2018-06-23 06:04:38 --> Helper loaded: string_helper
INFO - 2018-06-23 06:04:38 --> Database Driver Class Initialized
DEBUG - 2018-06-23 06:04:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-23 06:04:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-23 06:04:38 --> Email Class Initialized
INFO - 2018-06-23 06:04:38 --> Controller Class Initialized
DEBUG - 2018-06-23 06:04:38 --> Home MX_Controller Initialized
DEBUG - 2018-06-23 06:04:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-23 06:04:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-23 06:04:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-23 06:04:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-23 06:04:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-23 06:04:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-23 06:04:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/search_page.php
INFO - 2018-06-23 06:04:39 --> Final output sent to browser
DEBUG - 2018-06-23 06:04:39 --> Total execution time: 0.5830
INFO - 2018-06-23 06:04:39 --> Config Class Initialized
INFO - 2018-06-23 06:04:39 --> Hooks Class Initialized
DEBUG - 2018-06-23 06:04:39 --> UTF-8 Support Enabled
INFO - 2018-06-23 06:04:39 --> Utf8 Class Initialized
INFO - 2018-06-23 06:04:39 --> URI Class Initialized
INFO - 2018-06-23 06:04:39 --> Router Class Initialized
INFO - 2018-06-23 06:04:39 --> Output Class Initialized
INFO - 2018-06-23 06:04:39 --> Security Class Initialized
DEBUG - 2018-06-23 06:04:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 06:04:39 --> Input Class Initialized
INFO - 2018-06-23 06:04:39 --> Language Class Initialized
ERROR - 2018-06-23 06:04:39 --> 404 Page Not Found: /index
INFO - 2018-06-23 06:04:39 --> Config Class Initialized
INFO - 2018-06-23 06:04:39 --> Hooks Class Initialized
DEBUG - 2018-06-23 06:04:39 --> UTF-8 Support Enabled
INFO - 2018-06-23 06:04:39 --> Utf8 Class Initialized
INFO - 2018-06-23 06:04:39 --> URI Class Initialized
INFO - 2018-06-23 06:04:39 --> Router Class Initialized
INFO - 2018-06-23 06:04:39 --> Output Class Initialized
INFO - 2018-06-23 06:04:39 --> Security Class Initialized
DEBUG - 2018-06-23 06:04:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 06:04:39 --> Input Class Initialized
INFO - 2018-06-23 06:04:39 --> Language Class Initialized
ERROR - 2018-06-23 06:04:39 --> 404 Page Not Found: /index
INFO - 2018-06-23 06:04:39 --> Config Class Initialized
INFO - 2018-06-23 06:04:39 --> Hooks Class Initialized
DEBUG - 2018-06-23 06:04:39 --> UTF-8 Support Enabled
INFO - 2018-06-23 06:04:39 --> Utf8 Class Initialized
INFO - 2018-06-23 06:04:39 --> URI Class Initialized
INFO - 2018-06-23 06:04:39 --> Router Class Initialized
INFO - 2018-06-23 06:04:39 --> Output Class Initialized
INFO - 2018-06-23 06:04:39 --> Security Class Initialized
DEBUG - 2018-06-23 06:04:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 06:04:40 --> Input Class Initialized
INFO - 2018-06-23 06:04:40 --> Language Class Initialized
ERROR - 2018-06-23 06:04:40 --> 404 Page Not Found: /index
INFO - 2018-06-23 06:04:44 --> Config Class Initialized
INFO - 2018-06-23 06:04:44 --> Hooks Class Initialized
DEBUG - 2018-06-23 06:04:44 --> UTF-8 Support Enabled
INFO - 2018-06-23 06:04:44 --> Utf8 Class Initialized
INFO - 2018-06-23 06:04:44 --> URI Class Initialized
INFO - 2018-06-23 06:04:44 --> Router Class Initialized
INFO - 2018-06-23 06:04:44 --> Output Class Initialized
INFO - 2018-06-23 06:04:44 --> Security Class Initialized
DEBUG - 2018-06-23 06:04:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 06:04:44 --> Input Class Initialized
INFO - 2018-06-23 06:04:44 --> Language Class Initialized
INFO - 2018-06-23 06:04:44 --> Language Class Initialized
INFO - 2018-06-23 06:04:44 --> Config Class Initialized
INFO - 2018-06-23 06:04:44 --> Loader Class Initialized
DEBUG - 2018-06-23 06:04:44 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-23 06:04:44 --> Helper loaded: url_helper
INFO - 2018-06-23 06:04:44 --> Helper loaded: form_helper
INFO - 2018-06-23 06:04:44 --> Helper loaded: date_helper
INFO - 2018-06-23 06:04:44 --> Helper loaded: util_helper
INFO - 2018-06-23 06:04:44 --> Helper loaded: text_helper
INFO - 2018-06-23 06:04:44 --> Helper loaded: string_helper
INFO - 2018-06-23 06:04:44 --> Database Driver Class Initialized
DEBUG - 2018-06-23 06:04:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-23 06:04:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-23 06:04:44 --> Email Class Initialized
INFO - 2018-06-23 06:04:44 --> Controller Class Initialized
DEBUG - 2018-06-23 06:04:44 --> Home MX_Controller Initialized
DEBUG - 2018-06-23 06:04:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-23 06:04:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-23 06:04:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-23 06:04:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-23 06:04:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-23 06:04:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-23 06:04:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/search_page.php
INFO - 2018-06-23 06:04:44 --> Final output sent to browser
DEBUG - 2018-06-23 06:04:44 --> Total execution time: 0.4856
INFO - 2018-06-23 06:04:45 --> Config Class Initialized
INFO - 2018-06-23 06:04:45 --> Hooks Class Initialized
DEBUG - 2018-06-23 06:04:45 --> UTF-8 Support Enabled
INFO - 2018-06-23 06:04:45 --> Utf8 Class Initialized
INFO - 2018-06-23 06:04:45 --> URI Class Initialized
INFO - 2018-06-23 06:04:45 --> Router Class Initialized
INFO - 2018-06-23 06:04:45 --> Output Class Initialized
INFO - 2018-06-23 06:04:45 --> Security Class Initialized
DEBUG - 2018-06-23 06:04:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 06:04:45 --> Input Class Initialized
INFO - 2018-06-23 06:04:45 --> Language Class Initialized
ERROR - 2018-06-23 06:04:45 --> 404 Page Not Found: /index
INFO - 2018-06-23 06:04:45 --> Config Class Initialized
INFO - 2018-06-23 06:04:45 --> Hooks Class Initialized
DEBUG - 2018-06-23 06:04:45 --> UTF-8 Support Enabled
INFO - 2018-06-23 06:04:45 --> Utf8 Class Initialized
INFO - 2018-06-23 06:04:45 --> URI Class Initialized
INFO - 2018-06-23 06:04:45 --> Router Class Initialized
INFO - 2018-06-23 06:04:45 --> Output Class Initialized
INFO - 2018-06-23 06:04:45 --> Security Class Initialized
DEBUG - 2018-06-23 06:04:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 06:04:45 --> Input Class Initialized
INFO - 2018-06-23 06:04:45 --> Language Class Initialized
ERROR - 2018-06-23 06:04:45 --> 404 Page Not Found: /index
INFO - 2018-06-23 06:04:45 --> Config Class Initialized
INFO - 2018-06-23 06:04:45 --> Hooks Class Initialized
DEBUG - 2018-06-23 06:04:45 --> UTF-8 Support Enabled
INFO - 2018-06-23 06:04:45 --> Utf8 Class Initialized
INFO - 2018-06-23 06:04:45 --> URI Class Initialized
INFO - 2018-06-23 06:04:45 --> Router Class Initialized
INFO - 2018-06-23 06:04:45 --> Output Class Initialized
INFO - 2018-06-23 06:04:45 --> Security Class Initialized
DEBUG - 2018-06-23 06:04:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 06:04:45 --> Input Class Initialized
INFO - 2018-06-23 06:04:45 --> Language Class Initialized
ERROR - 2018-06-23 06:04:45 --> 404 Page Not Found: /index
INFO - 2018-06-23 06:07:06 --> Config Class Initialized
INFO - 2018-06-23 06:07:06 --> Hooks Class Initialized
DEBUG - 2018-06-23 06:07:06 --> UTF-8 Support Enabled
INFO - 2018-06-23 06:07:06 --> Utf8 Class Initialized
INFO - 2018-06-23 06:07:06 --> URI Class Initialized
INFO - 2018-06-23 06:07:06 --> Router Class Initialized
INFO - 2018-06-23 06:07:06 --> Output Class Initialized
INFO - 2018-06-23 06:07:06 --> Security Class Initialized
DEBUG - 2018-06-23 06:07:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 06:07:06 --> Input Class Initialized
INFO - 2018-06-23 06:07:06 --> Language Class Initialized
INFO - 2018-06-23 06:07:06 --> Language Class Initialized
INFO - 2018-06-23 06:07:06 --> Config Class Initialized
INFO - 2018-06-23 06:07:06 --> Loader Class Initialized
DEBUG - 2018-06-23 06:07:06 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-23 06:07:06 --> Helper loaded: url_helper
INFO - 2018-06-23 06:07:06 --> Helper loaded: form_helper
INFO - 2018-06-23 06:07:06 --> Helper loaded: date_helper
INFO - 2018-06-23 06:07:06 --> Helper loaded: util_helper
INFO - 2018-06-23 06:07:06 --> Helper loaded: text_helper
INFO - 2018-06-23 06:07:06 --> Helper loaded: string_helper
INFO - 2018-06-23 06:07:06 --> Database Driver Class Initialized
DEBUG - 2018-06-23 06:07:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-23 06:07:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-23 06:07:07 --> Email Class Initialized
INFO - 2018-06-23 06:07:07 --> Controller Class Initialized
DEBUG - 2018-06-23 06:07:07 --> Home MX_Controller Initialized
DEBUG - 2018-06-23 06:07:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-23 06:07:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-23 06:07:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-23 06:07:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-23 06:07:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-23 06:07:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-23 06:07:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/search_page.php
INFO - 2018-06-23 06:07:07 --> Final output sent to browser
DEBUG - 2018-06-23 06:07:07 --> Total execution time: 0.5031
INFO - 2018-06-23 06:07:08 --> Config Class Initialized
INFO - 2018-06-23 06:07:08 --> Hooks Class Initialized
DEBUG - 2018-06-23 06:07:08 --> UTF-8 Support Enabled
INFO - 2018-06-23 06:07:08 --> Utf8 Class Initialized
INFO - 2018-06-23 06:07:08 --> URI Class Initialized
INFO - 2018-06-23 06:07:08 --> Router Class Initialized
INFO - 2018-06-23 06:07:08 --> Output Class Initialized
INFO - 2018-06-23 06:07:08 --> Security Class Initialized
DEBUG - 2018-06-23 06:07:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 06:07:08 --> Input Class Initialized
INFO - 2018-06-23 06:07:08 --> Language Class Initialized
ERROR - 2018-06-23 06:07:08 --> 404 Page Not Found: /index
INFO - 2018-06-23 06:07:08 --> Config Class Initialized
INFO - 2018-06-23 06:07:08 --> Hooks Class Initialized
DEBUG - 2018-06-23 06:07:08 --> UTF-8 Support Enabled
INFO - 2018-06-23 06:07:08 --> Utf8 Class Initialized
INFO - 2018-06-23 06:07:08 --> URI Class Initialized
INFO - 2018-06-23 06:07:08 --> Router Class Initialized
INFO - 2018-06-23 06:07:08 --> Output Class Initialized
INFO - 2018-06-23 06:07:08 --> Security Class Initialized
DEBUG - 2018-06-23 06:07:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 06:07:08 --> Input Class Initialized
INFO - 2018-06-23 06:07:08 --> Language Class Initialized
ERROR - 2018-06-23 06:07:08 --> 404 Page Not Found: /index
INFO - 2018-06-23 06:07:08 --> Config Class Initialized
INFO - 2018-06-23 06:07:08 --> Hooks Class Initialized
DEBUG - 2018-06-23 06:07:08 --> UTF-8 Support Enabled
INFO - 2018-06-23 06:07:08 --> Utf8 Class Initialized
INFO - 2018-06-23 06:07:09 --> URI Class Initialized
INFO - 2018-06-23 06:07:09 --> Router Class Initialized
INFO - 2018-06-23 06:07:09 --> Output Class Initialized
INFO - 2018-06-23 06:07:09 --> Security Class Initialized
DEBUG - 2018-06-23 06:07:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 06:07:09 --> Input Class Initialized
INFO - 2018-06-23 06:07:09 --> Language Class Initialized
ERROR - 2018-06-23 06:07:09 --> 404 Page Not Found: /index
INFO - 2018-06-23 06:07:09 --> Config Class Initialized
INFO - 2018-06-23 06:07:09 --> Hooks Class Initialized
DEBUG - 2018-06-23 06:07:09 --> UTF-8 Support Enabled
INFO - 2018-06-23 06:07:09 --> Utf8 Class Initialized
INFO - 2018-06-23 06:07:09 --> URI Class Initialized
INFO - 2018-06-23 06:07:09 --> Router Class Initialized
INFO - 2018-06-23 06:07:09 --> Output Class Initialized
INFO - 2018-06-23 06:07:09 --> Security Class Initialized
DEBUG - 2018-06-23 06:07:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 06:07:09 --> Input Class Initialized
INFO - 2018-06-23 06:07:09 --> Language Class Initialized
ERROR - 2018-06-23 06:07:09 --> 404 Page Not Found: /index
INFO - 2018-06-23 06:07:09 --> Config Class Initialized
INFO - 2018-06-23 06:07:09 --> Hooks Class Initialized
DEBUG - 2018-06-23 06:07:09 --> UTF-8 Support Enabled
INFO - 2018-06-23 06:07:09 --> Utf8 Class Initialized
INFO - 2018-06-23 06:07:09 --> URI Class Initialized
INFO - 2018-06-23 06:07:09 --> Router Class Initialized
INFO - 2018-06-23 06:07:09 --> Output Class Initialized
INFO - 2018-06-23 06:07:09 --> Security Class Initialized
DEBUG - 2018-06-23 06:07:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 06:07:09 --> Input Class Initialized
INFO - 2018-06-23 06:07:09 --> Language Class Initialized
ERROR - 2018-06-23 06:07:09 --> 404 Page Not Found: /index
INFO - 2018-06-23 06:07:09 --> Config Class Initialized
INFO - 2018-06-23 06:07:09 --> Hooks Class Initialized
DEBUG - 2018-06-23 06:07:09 --> UTF-8 Support Enabled
INFO - 2018-06-23 06:07:09 --> Utf8 Class Initialized
INFO - 2018-06-23 06:07:09 --> URI Class Initialized
INFO - 2018-06-23 06:07:09 --> Router Class Initialized
INFO - 2018-06-23 06:07:09 --> Output Class Initialized
INFO - 2018-06-23 06:07:09 --> Security Class Initialized
DEBUG - 2018-06-23 06:07:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 06:07:09 --> Input Class Initialized
INFO - 2018-06-23 06:07:09 --> Language Class Initialized
ERROR - 2018-06-23 06:07:09 --> 404 Page Not Found: /index
INFO - 2018-06-23 06:07:28 --> Config Class Initialized
INFO - 2018-06-23 06:07:28 --> Hooks Class Initialized
DEBUG - 2018-06-23 06:07:28 --> UTF-8 Support Enabled
INFO - 2018-06-23 06:07:28 --> Utf8 Class Initialized
INFO - 2018-06-23 06:07:28 --> URI Class Initialized
INFO - 2018-06-23 06:07:28 --> Router Class Initialized
INFO - 2018-06-23 06:07:28 --> Output Class Initialized
INFO - 2018-06-23 06:07:29 --> Security Class Initialized
DEBUG - 2018-06-23 06:07:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 06:07:29 --> Input Class Initialized
INFO - 2018-06-23 06:07:29 --> Language Class Initialized
INFO - 2018-06-23 06:07:29 --> Language Class Initialized
INFO - 2018-06-23 06:07:29 --> Config Class Initialized
INFO - 2018-06-23 06:07:29 --> Loader Class Initialized
DEBUG - 2018-06-23 06:07:29 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-23 06:07:29 --> Helper loaded: url_helper
INFO - 2018-06-23 06:07:29 --> Helper loaded: form_helper
INFO - 2018-06-23 06:07:29 --> Helper loaded: date_helper
INFO - 2018-06-23 06:07:29 --> Helper loaded: util_helper
INFO - 2018-06-23 06:07:29 --> Helper loaded: text_helper
INFO - 2018-06-23 06:07:29 --> Helper loaded: string_helper
INFO - 2018-06-23 06:07:29 --> Database Driver Class Initialized
DEBUG - 2018-06-23 06:07:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-23 06:07:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-23 06:07:29 --> Email Class Initialized
INFO - 2018-06-23 06:07:29 --> Controller Class Initialized
DEBUG - 2018-06-23 06:07:29 --> Home MX_Controller Initialized
DEBUG - 2018-06-23 06:07:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-23 06:07:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-23 06:07:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-23 06:07:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-23 06:07:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-23 06:07:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-23 06:07:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/search_page.php
INFO - 2018-06-23 06:07:29 --> Final output sent to browser
DEBUG - 2018-06-23 06:07:29 --> Total execution time: 0.5232
INFO - 2018-06-23 06:07:29 --> Config Class Initialized
INFO - 2018-06-23 06:07:29 --> Hooks Class Initialized
DEBUG - 2018-06-23 06:07:29 --> UTF-8 Support Enabled
INFO - 2018-06-23 06:07:29 --> Utf8 Class Initialized
INFO - 2018-06-23 06:07:29 --> URI Class Initialized
INFO - 2018-06-23 06:07:30 --> Router Class Initialized
INFO - 2018-06-23 06:07:30 --> Output Class Initialized
INFO - 2018-06-23 06:07:30 --> Security Class Initialized
DEBUG - 2018-06-23 06:07:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 06:07:30 --> Input Class Initialized
INFO - 2018-06-23 06:07:30 --> Language Class Initialized
ERROR - 2018-06-23 06:07:30 --> 404 Page Not Found: /index
INFO - 2018-06-23 06:07:30 --> Config Class Initialized
INFO - 2018-06-23 06:07:30 --> Hooks Class Initialized
DEBUG - 2018-06-23 06:07:30 --> UTF-8 Support Enabled
INFO - 2018-06-23 06:07:30 --> Utf8 Class Initialized
INFO - 2018-06-23 06:07:30 --> URI Class Initialized
INFO - 2018-06-23 06:07:30 --> Router Class Initialized
INFO - 2018-06-23 06:07:30 --> Output Class Initialized
INFO - 2018-06-23 06:07:30 --> Security Class Initialized
DEBUG - 2018-06-23 06:07:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 06:07:30 --> Input Class Initialized
INFO - 2018-06-23 06:07:30 --> Language Class Initialized
ERROR - 2018-06-23 06:07:30 --> 404 Page Not Found: /index
INFO - 2018-06-23 06:07:30 --> Config Class Initialized
INFO - 2018-06-23 06:07:30 --> Hooks Class Initialized
DEBUG - 2018-06-23 06:07:30 --> UTF-8 Support Enabled
INFO - 2018-06-23 06:07:30 --> Utf8 Class Initialized
INFO - 2018-06-23 06:07:30 --> URI Class Initialized
INFO - 2018-06-23 06:07:30 --> Router Class Initialized
INFO - 2018-06-23 06:07:30 --> Output Class Initialized
INFO - 2018-06-23 06:07:30 --> Security Class Initialized
DEBUG - 2018-06-23 06:07:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 06:07:30 --> Input Class Initialized
INFO - 2018-06-23 06:07:30 --> Language Class Initialized
ERROR - 2018-06-23 06:07:30 --> 404 Page Not Found: /index
INFO - 2018-06-23 06:07:30 --> Config Class Initialized
INFO - 2018-06-23 06:07:30 --> Hooks Class Initialized
DEBUG - 2018-06-23 06:07:30 --> UTF-8 Support Enabled
INFO - 2018-06-23 06:07:30 --> Utf8 Class Initialized
INFO - 2018-06-23 06:07:30 --> URI Class Initialized
INFO - 2018-06-23 06:07:30 --> Router Class Initialized
INFO - 2018-06-23 06:07:30 --> Output Class Initialized
INFO - 2018-06-23 06:07:30 --> Security Class Initialized
DEBUG - 2018-06-23 06:07:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 06:07:30 --> Input Class Initialized
INFO - 2018-06-23 06:07:30 --> Language Class Initialized
ERROR - 2018-06-23 06:07:30 --> 404 Page Not Found: /index
INFO - 2018-06-23 06:07:30 --> Config Class Initialized
INFO - 2018-06-23 06:07:30 --> Hooks Class Initialized
DEBUG - 2018-06-23 06:07:30 --> UTF-8 Support Enabled
INFO - 2018-06-23 06:07:30 --> Utf8 Class Initialized
INFO - 2018-06-23 06:07:30 --> URI Class Initialized
INFO - 2018-06-23 06:07:30 --> Router Class Initialized
INFO - 2018-06-23 06:07:30 --> Output Class Initialized
INFO - 2018-06-23 06:07:30 --> Security Class Initialized
DEBUG - 2018-06-23 06:07:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 06:07:30 --> Input Class Initialized
INFO - 2018-06-23 06:07:30 --> Language Class Initialized
ERROR - 2018-06-23 06:07:30 --> 404 Page Not Found: /index
INFO - 2018-06-23 06:07:30 --> Config Class Initialized
INFO - 2018-06-23 06:07:30 --> Hooks Class Initialized
DEBUG - 2018-06-23 06:07:30 --> UTF-8 Support Enabled
INFO - 2018-06-23 06:07:31 --> Utf8 Class Initialized
INFO - 2018-06-23 06:07:31 --> URI Class Initialized
INFO - 2018-06-23 06:07:31 --> Router Class Initialized
INFO - 2018-06-23 06:07:31 --> Output Class Initialized
INFO - 2018-06-23 06:07:31 --> Security Class Initialized
DEBUG - 2018-06-23 06:07:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 06:07:31 --> Input Class Initialized
INFO - 2018-06-23 06:07:31 --> Language Class Initialized
ERROR - 2018-06-23 06:07:31 --> 404 Page Not Found: /index
INFO - 2018-06-23 06:07:43 --> Config Class Initialized
INFO - 2018-06-23 06:07:43 --> Hooks Class Initialized
DEBUG - 2018-06-23 06:07:43 --> UTF-8 Support Enabled
INFO - 2018-06-23 06:07:43 --> Utf8 Class Initialized
INFO - 2018-06-23 06:07:43 --> URI Class Initialized
INFO - 2018-06-23 06:07:43 --> Router Class Initialized
INFO - 2018-06-23 06:07:43 --> Output Class Initialized
INFO - 2018-06-23 06:07:43 --> Security Class Initialized
DEBUG - 2018-06-23 06:07:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 06:07:43 --> Input Class Initialized
INFO - 2018-06-23 06:07:43 --> Language Class Initialized
INFO - 2018-06-23 06:07:43 --> Language Class Initialized
INFO - 2018-06-23 06:07:43 --> Config Class Initialized
INFO - 2018-06-23 06:07:43 --> Loader Class Initialized
DEBUG - 2018-06-23 06:07:43 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-23 06:07:43 --> Helper loaded: url_helper
INFO - 2018-06-23 06:07:43 --> Helper loaded: form_helper
INFO - 2018-06-23 06:07:43 --> Helper loaded: date_helper
INFO - 2018-06-23 06:07:43 --> Helper loaded: util_helper
INFO - 2018-06-23 06:07:43 --> Helper loaded: text_helper
INFO - 2018-06-23 06:07:43 --> Helper loaded: string_helper
INFO - 2018-06-23 06:07:43 --> Database Driver Class Initialized
DEBUG - 2018-06-23 06:07:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-23 06:07:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-23 06:07:43 --> Email Class Initialized
INFO - 2018-06-23 06:07:43 --> Controller Class Initialized
DEBUG - 2018-06-23 06:07:43 --> Home MX_Controller Initialized
DEBUG - 2018-06-23 06:07:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-23 06:07:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-23 06:07:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-23 06:07:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-23 06:07:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-23 06:07:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-23 06:07:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/search_page.php
INFO - 2018-06-23 06:07:44 --> Final output sent to browser
DEBUG - 2018-06-23 06:07:44 --> Total execution time: 0.5118
INFO - 2018-06-23 06:07:44 --> Config Class Initialized
INFO - 2018-06-23 06:07:44 --> Hooks Class Initialized
DEBUG - 2018-06-23 06:07:44 --> UTF-8 Support Enabled
INFO - 2018-06-23 06:07:44 --> Utf8 Class Initialized
INFO - 2018-06-23 06:07:44 --> URI Class Initialized
INFO - 2018-06-23 06:07:44 --> Router Class Initialized
INFO - 2018-06-23 06:07:44 --> Output Class Initialized
INFO - 2018-06-23 06:07:44 --> Security Class Initialized
DEBUG - 2018-06-23 06:07:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 06:07:44 --> Input Class Initialized
INFO - 2018-06-23 06:07:44 --> Language Class Initialized
ERROR - 2018-06-23 06:07:44 --> 404 Page Not Found: /index
INFO - 2018-06-23 06:07:44 --> Config Class Initialized
INFO - 2018-06-23 06:07:44 --> Hooks Class Initialized
DEBUG - 2018-06-23 06:07:44 --> UTF-8 Support Enabled
INFO - 2018-06-23 06:07:44 --> Utf8 Class Initialized
INFO - 2018-06-23 06:07:44 --> URI Class Initialized
INFO - 2018-06-23 06:07:44 --> Router Class Initialized
INFO - 2018-06-23 06:07:44 --> Output Class Initialized
INFO - 2018-06-23 06:07:44 --> Security Class Initialized
DEBUG - 2018-06-23 06:07:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 06:07:44 --> Input Class Initialized
INFO - 2018-06-23 06:07:44 --> Language Class Initialized
ERROR - 2018-06-23 06:07:44 --> 404 Page Not Found: /index
INFO - 2018-06-23 06:07:44 --> Config Class Initialized
INFO - 2018-06-23 06:07:44 --> Hooks Class Initialized
DEBUG - 2018-06-23 06:07:44 --> UTF-8 Support Enabled
INFO - 2018-06-23 06:07:44 --> Utf8 Class Initialized
INFO - 2018-06-23 06:07:44 --> URI Class Initialized
INFO - 2018-06-23 06:07:44 --> Router Class Initialized
INFO - 2018-06-23 06:07:44 --> Output Class Initialized
INFO - 2018-06-23 06:07:44 --> Security Class Initialized
DEBUG - 2018-06-23 06:07:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 06:07:44 --> Input Class Initialized
INFO - 2018-06-23 06:07:45 --> Language Class Initialized
ERROR - 2018-06-23 06:07:45 --> 404 Page Not Found: /index
INFO - 2018-06-23 06:07:45 --> Config Class Initialized
INFO - 2018-06-23 06:07:45 --> Hooks Class Initialized
DEBUG - 2018-06-23 06:07:45 --> UTF-8 Support Enabled
INFO - 2018-06-23 06:07:45 --> Utf8 Class Initialized
INFO - 2018-06-23 06:07:45 --> URI Class Initialized
INFO - 2018-06-23 06:07:45 --> Router Class Initialized
INFO - 2018-06-23 06:07:45 --> Output Class Initialized
INFO - 2018-06-23 06:07:45 --> Security Class Initialized
DEBUG - 2018-06-23 06:07:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 06:07:45 --> Input Class Initialized
INFO - 2018-06-23 06:07:45 --> Language Class Initialized
ERROR - 2018-06-23 06:07:45 --> 404 Page Not Found: /index
INFO - 2018-06-23 06:07:45 --> Config Class Initialized
INFO - 2018-06-23 06:07:45 --> Hooks Class Initialized
DEBUG - 2018-06-23 06:07:45 --> UTF-8 Support Enabled
INFO - 2018-06-23 06:07:45 --> Utf8 Class Initialized
INFO - 2018-06-23 06:07:45 --> URI Class Initialized
INFO - 2018-06-23 06:07:45 --> Router Class Initialized
INFO - 2018-06-23 06:07:45 --> Output Class Initialized
INFO - 2018-06-23 06:07:45 --> Security Class Initialized
DEBUG - 2018-06-23 06:07:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 06:07:45 --> Input Class Initialized
INFO - 2018-06-23 06:07:45 --> Language Class Initialized
ERROR - 2018-06-23 06:07:45 --> 404 Page Not Found: /index
INFO - 2018-06-23 06:07:45 --> Config Class Initialized
INFO - 2018-06-23 06:07:45 --> Hooks Class Initialized
DEBUG - 2018-06-23 06:07:45 --> UTF-8 Support Enabled
INFO - 2018-06-23 06:07:45 --> Utf8 Class Initialized
INFO - 2018-06-23 06:07:45 --> URI Class Initialized
INFO - 2018-06-23 06:07:45 --> Router Class Initialized
INFO - 2018-06-23 06:07:45 --> Output Class Initialized
INFO - 2018-06-23 06:07:45 --> Security Class Initialized
DEBUG - 2018-06-23 06:07:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-23 06:07:45 --> Input Class Initialized
INFO - 2018-06-23 06:07:45 --> Language Class Initialized
ERROR - 2018-06-23 06:07:45 --> 404 Page Not Found: /index
