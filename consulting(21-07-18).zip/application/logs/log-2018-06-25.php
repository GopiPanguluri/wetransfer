<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-06-25 21:39:55 --> Config Class Initialized
INFO - 2018-06-25 21:39:55 --> Hooks Class Initialized
DEBUG - 2018-06-25 21:39:55 --> UTF-8 Support Enabled
INFO - 2018-06-25 21:39:55 --> Utf8 Class Initialized
INFO - 2018-06-25 21:39:55 --> URI Class Initialized
INFO - 2018-06-25 21:39:55 --> Router Class Initialized
INFO - 2018-06-25 21:39:56 --> Output Class Initialized
INFO - 2018-06-25 21:39:56 --> Security Class Initialized
DEBUG - 2018-06-25 21:39:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 21:39:56 --> Input Class Initialized
INFO - 2018-06-25 21:39:56 --> Language Class Initialized
INFO - 2018-06-25 21:39:56 --> Language Class Initialized
INFO - 2018-06-25 21:39:56 --> Config Class Initialized
INFO - 2018-06-25 21:39:56 --> Loader Class Initialized
DEBUG - 2018-06-25 21:39:56 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-25 21:39:56 --> Helper loaded: url_helper
INFO - 2018-06-25 21:39:56 --> Helper loaded: form_helper
INFO - 2018-06-25 21:39:56 --> Helper loaded: date_helper
INFO - 2018-06-25 21:39:56 --> Helper loaded: util_helper
INFO - 2018-06-25 21:39:56 --> Helper loaded: text_helper
INFO - 2018-06-25 21:39:56 --> Helper loaded: string_helper
INFO - 2018-06-25 21:39:56 --> Database Driver Class Initialized
ERROR - 2018-06-25 21:39:58 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 E:\xampp\htdocs\consulting\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2018-06-25 21:39:58 --> Unable to connect to the database
INFO - 2018-06-25 21:39:58 --> Language file loaded: language/english/db_lang.php
INFO - 2018-06-25 21:40:03 --> Config Class Initialized
INFO - 2018-06-25 21:40:03 --> Hooks Class Initialized
DEBUG - 2018-06-25 21:40:03 --> UTF-8 Support Enabled
INFO - 2018-06-25 21:40:03 --> Utf8 Class Initialized
INFO - 2018-06-25 21:40:03 --> URI Class Initialized
INFO - 2018-06-25 21:40:03 --> Router Class Initialized
INFO - 2018-06-25 21:40:03 --> Output Class Initialized
INFO - 2018-06-25 21:40:03 --> Security Class Initialized
DEBUG - 2018-06-25 21:40:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 21:40:03 --> Input Class Initialized
INFO - 2018-06-25 21:40:03 --> Language Class Initialized
INFO - 2018-06-25 21:40:03 --> Language Class Initialized
INFO - 2018-06-25 21:40:03 --> Config Class Initialized
INFO - 2018-06-25 21:40:04 --> Loader Class Initialized
DEBUG - 2018-06-25 21:40:04 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-25 21:40:04 --> Helper loaded: url_helper
INFO - 2018-06-25 21:40:04 --> Helper loaded: form_helper
INFO - 2018-06-25 21:40:04 --> Helper loaded: date_helper
INFO - 2018-06-25 21:40:04 --> Helper loaded: util_helper
INFO - 2018-06-25 21:40:04 --> Helper loaded: text_helper
INFO - 2018-06-25 21:40:04 --> Helper loaded: string_helper
INFO - 2018-06-25 21:40:04 --> Database Driver Class Initialized
DEBUG - 2018-06-25 21:40:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-25 21:40:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-25 21:40:04 --> Email Class Initialized
INFO - 2018-06-25 21:40:04 --> Controller Class Initialized
DEBUG - 2018-06-25 21:40:04 --> Home MX_Controller Initialized
DEBUG - 2018-06-25 21:40:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-25 21:40:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-25 21:40:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
ERROR - 2018-06-25 21:40:04 --> Severity: Notice --> Undefined index: home_name E:\xampp\htdocs\consulting\application\modules\home\views\common\header.php 32
DEBUG - 2018-06-25 21:40:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-25 21:40:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-25 21:40:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-25 21:40:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/search_page.php
INFO - 2018-06-25 21:40:04 --> Final output sent to browser
DEBUG - 2018-06-25 21:40:04 --> Total execution time: 0.9512
INFO - 2018-06-25 21:40:05 --> Config Class Initialized
INFO - 2018-06-25 21:40:05 --> Hooks Class Initialized
DEBUG - 2018-06-25 21:40:05 --> UTF-8 Support Enabled
INFO - 2018-06-25 21:40:05 --> Utf8 Class Initialized
INFO - 2018-06-25 21:40:05 --> URI Class Initialized
INFO - 2018-06-25 21:40:05 --> Router Class Initialized
INFO - 2018-06-25 21:40:05 --> Output Class Initialized
INFO - 2018-06-25 21:40:05 --> Security Class Initialized
DEBUG - 2018-06-25 21:40:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 21:40:05 --> Input Class Initialized
INFO - 2018-06-25 21:40:05 --> Language Class Initialized
INFO - 2018-06-25 21:40:05 --> Language Class Initialized
INFO - 2018-06-25 21:40:05 --> Config Class Initialized
INFO - 2018-06-25 21:40:05 --> Loader Class Initialized
DEBUG - 2018-06-25 21:40:05 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-25 21:40:05 --> Helper loaded: url_helper
INFO - 2018-06-25 21:40:05 --> Helper loaded: form_helper
INFO - 2018-06-25 21:40:05 --> Helper loaded: date_helper
INFO - 2018-06-25 21:40:05 --> Helper loaded: util_helper
INFO - 2018-06-25 21:40:05 --> Helper loaded: text_helper
INFO - 2018-06-25 21:40:05 --> Helper loaded: string_helper
INFO - 2018-06-25 21:40:05 --> Database Driver Class Initialized
DEBUG - 2018-06-25 21:40:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-25 21:40:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-25 21:40:05 --> Email Class Initialized
INFO - 2018-06-25 21:40:05 --> Controller Class Initialized
DEBUG - 2018-06-25 21:40:05 --> videos MX_Controller Initialized
INFO - 2018-06-25 21:40:05 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-25 21:40:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-06-25 21:40:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-25 21:40:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-25 21:40:05 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-25 21:40:05 --> Login MX_Controller Initialized
DEBUG - 2018-06-25 21:40:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-25 21:40:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
INFO - 2018-06-25 21:40:05 --> Config Class Initialized
INFO - 2018-06-25 21:40:05 --> Hooks Class Initialized
DEBUG - 2018-06-25 21:40:05 --> UTF-8 Support Enabled
INFO - 2018-06-25 21:40:05 --> Utf8 Class Initialized
INFO - 2018-06-25 21:40:05 --> URI Class Initialized
INFO - 2018-06-25 21:40:05 --> Router Class Initialized
INFO - 2018-06-25 21:40:05 --> Output Class Initialized
INFO - 2018-06-25 21:40:05 --> Security Class Initialized
DEBUG - 2018-06-25 21:40:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 21:40:05 --> Input Class Initialized
INFO - 2018-06-25 21:40:05 --> Language Class Initialized
ERROR - 2018-06-25 21:40:05 --> 404 Page Not Found: /index
INFO - 2018-06-25 21:40:06 --> Config Class Initialized
INFO - 2018-06-25 21:40:06 --> Hooks Class Initialized
DEBUG - 2018-06-25 21:40:06 --> UTF-8 Support Enabled
INFO - 2018-06-25 21:40:06 --> Utf8 Class Initialized
INFO - 2018-06-25 21:40:06 --> Config Class Initialized
INFO - 2018-06-25 21:40:06 --> Hooks Class Initialized
INFO - 2018-06-25 21:40:06 --> URI Class Initialized
DEBUG - 2018-06-25 21:40:06 --> UTF-8 Support Enabled
INFO - 2018-06-25 21:40:06 --> Router Class Initialized
INFO - 2018-06-25 21:40:06 --> Utf8 Class Initialized
INFO - 2018-06-25 21:40:06 --> Output Class Initialized
INFO - 2018-06-25 21:40:06 --> URI Class Initialized
INFO - 2018-06-25 21:40:06 --> Security Class Initialized
INFO - 2018-06-25 21:40:06 --> Router Class Initialized
DEBUG - 2018-06-25 21:40:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 21:40:06 --> Input Class Initialized
INFO - 2018-06-25 21:40:06 --> Output Class Initialized
INFO - 2018-06-25 21:40:06 --> Language Class Initialized
INFO - 2018-06-25 21:40:06 --> Security Class Initialized
DEBUG - 2018-06-25 21:40:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-06-25 21:40:06 --> 404 Page Not Found: /index
INFO - 2018-06-25 21:40:06 --> Input Class Initialized
INFO - 2018-06-25 21:40:06 --> Language Class Initialized
ERROR - 2018-06-25 21:40:06 --> 404 Page Not Found: /index
INFO - 2018-06-25 21:40:06 --> Config Class Initialized
INFO - 2018-06-25 21:40:06 --> Hooks Class Initialized
DEBUG - 2018-06-25 21:40:06 --> UTF-8 Support Enabled
INFO - 2018-06-25 21:40:06 --> Utf8 Class Initialized
INFO - 2018-06-25 21:40:06 --> URI Class Initialized
INFO - 2018-06-25 21:40:06 --> Router Class Initialized
INFO - 2018-06-25 21:40:06 --> Output Class Initialized
INFO - 2018-06-25 21:40:06 --> Security Class Initialized
DEBUG - 2018-06-25 21:40:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 21:40:06 --> Input Class Initialized
INFO - 2018-06-25 21:40:06 --> Language Class Initialized
ERROR - 2018-06-25 21:40:06 --> 404 Page Not Found: /index
INFO - 2018-06-25 21:40:06 --> Config Class Initialized
INFO - 2018-06-25 21:40:06 --> Hooks Class Initialized
DEBUG - 2018-06-25 21:40:06 --> UTF-8 Support Enabled
INFO - 2018-06-25 21:40:06 --> Utf8 Class Initialized
INFO - 2018-06-25 21:40:06 --> URI Class Initialized
INFO - 2018-06-25 21:40:06 --> Router Class Initialized
INFO - 2018-06-25 21:40:06 --> Output Class Initialized
INFO - 2018-06-25 21:40:06 --> Security Class Initialized
DEBUG - 2018-06-25 21:40:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 21:40:06 --> Input Class Initialized
INFO - 2018-06-25 21:40:06 --> Language Class Initialized
ERROR - 2018-06-25 21:40:06 --> 404 Page Not Found: /index
INFO - 2018-06-25 21:40:07 --> Config Class Initialized
INFO - 2018-06-25 21:40:07 --> Hooks Class Initialized
DEBUG - 2018-06-25 21:40:07 --> UTF-8 Support Enabled
INFO - 2018-06-25 21:40:07 --> Utf8 Class Initialized
INFO - 2018-06-25 21:40:07 --> URI Class Initialized
INFO - 2018-06-25 21:40:07 --> Router Class Initialized
INFO - 2018-06-25 21:40:07 --> Output Class Initialized
INFO - 2018-06-25 21:40:07 --> Security Class Initialized
DEBUG - 2018-06-25 21:40:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 21:40:07 --> Input Class Initialized
INFO - 2018-06-25 21:40:07 --> Language Class Initialized
ERROR - 2018-06-25 21:40:07 --> 404 Page Not Found: /index
INFO - 2018-06-25 21:40:07 --> Config Class Initialized
INFO - 2018-06-25 21:40:07 --> Hooks Class Initialized
DEBUG - 2018-06-25 21:40:07 --> UTF-8 Support Enabled
INFO - 2018-06-25 21:40:07 --> Utf8 Class Initialized
INFO - 2018-06-25 21:40:07 --> URI Class Initialized
INFO - 2018-06-25 21:40:07 --> Router Class Initialized
INFO - 2018-06-25 21:40:07 --> Output Class Initialized
INFO - 2018-06-25 21:40:07 --> Security Class Initialized
DEBUG - 2018-06-25 21:40:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 21:40:07 --> Input Class Initialized
INFO - 2018-06-25 21:40:07 --> Language Class Initialized
ERROR - 2018-06-25 21:40:07 --> 404 Page Not Found: /index
INFO - 2018-06-25 21:40:07 --> Config Class Initialized
INFO - 2018-06-25 21:40:07 --> Hooks Class Initialized
DEBUG - 2018-06-25 21:40:07 --> UTF-8 Support Enabled
INFO - 2018-06-25 21:40:07 --> Utf8 Class Initialized
INFO - 2018-06-25 21:40:07 --> URI Class Initialized
INFO - 2018-06-25 21:40:07 --> Router Class Initialized
INFO - 2018-06-25 21:40:07 --> Output Class Initialized
INFO - 2018-06-25 21:40:07 --> Security Class Initialized
DEBUG - 2018-06-25 21:40:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 21:40:07 --> Input Class Initialized
INFO - 2018-06-25 21:40:07 --> Language Class Initialized
ERROR - 2018-06-25 21:40:07 --> 404 Page Not Found: /index
INFO - 2018-06-25 21:40:16 --> Config Class Initialized
INFO - 2018-06-25 21:40:16 --> Hooks Class Initialized
DEBUG - 2018-06-25 21:40:16 --> UTF-8 Support Enabled
INFO - 2018-06-25 21:40:16 --> Utf8 Class Initialized
INFO - 2018-06-25 21:40:16 --> URI Class Initialized
INFO - 2018-06-25 21:40:16 --> Router Class Initialized
INFO - 2018-06-25 21:40:16 --> Output Class Initialized
INFO - 2018-06-25 21:40:16 --> Security Class Initialized
DEBUG - 2018-06-25 21:40:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 21:40:16 --> Input Class Initialized
INFO - 2018-06-25 21:40:16 --> Language Class Initialized
INFO - 2018-06-25 21:40:16 --> Language Class Initialized
INFO - 2018-06-25 21:40:16 --> Config Class Initialized
INFO - 2018-06-25 21:40:16 --> Loader Class Initialized
DEBUG - 2018-06-25 21:40:16 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-25 21:40:16 --> Helper loaded: url_helper
INFO - 2018-06-25 21:40:16 --> Helper loaded: form_helper
INFO - 2018-06-25 21:40:16 --> Helper loaded: date_helper
INFO - 2018-06-25 21:40:16 --> Helper loaded: util_helper
INFO - 2018-06-25 21:40:16 --> Helper loaded: text_helper
INFO - 2018-06-25 21:40:16 --> Helper loaded: string_helper
INFO - 2018-06-25 21:40:16 --> Database Driver Class Initialized
DEBUG - 2018-06-25 21:40:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-25 21:40:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-25 21:40:16 --> Email Class Initialized
INFO - 2018-06-25 21:40:16 --> Controller Class Initialized
DEBUG - 2018-06-25 21:40:16 --> Home MX_Controller Initialized
DEBUG - 2018-06-25 21:40:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-25 21:40:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-25 21:40:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
ERROR - 2018-06-25 21:40:16 --> Severity: Notice --> Undefined index: home_name E:\xampp\htdocs\consulting\application\modules\home\views\common\header.php 32
DEBUG - 2018-06-25 21:40:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-25 21:40:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-25 21:40:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-25 21:40:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/search_page.php
INFO - 2018-06-25 21:40:16 --> Final output sent to browser
DEBUG - 2018-06-25 21:40:16 --> Total execution time: 0.3080
INFO - 2018-06-25 21:40:18 --> Config Class Initialized
INFO - 2018-06-25 21:40:18 --> Hooks Class Initialized
DEBUG - 2018-06-25 21:40:18 --> UTF-8 Support Enabled
INFO - 2018-06-25 21:40:18 --> Utf8 Class Initialized
INFO - 2018-06-25 21:40:18 --> URI Class Initialized
INFO - 2018-06-25 21:40:18 --> Router Class Initialized
INFO - 2018-06-25 21:40:18 --> Output Class Initialized
INFO - 2018-06-25 21:40:18 --> Security Class Initialized
DEBUG - 2018-06-25 21:40:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 21:40:18 --> Input Class Initialized
INFO - 2018-06-25 21:40:18 --> Language Class Initialized
INFO - 2018-06-25 21:40:18 --> Language Class Initialized
INFO - 2018-06-25 21:40:18 --> Config Class Initialized
INFO - 2018-06-25 21:40:18 --> Loader Class Initialized
DEBUG - 2018-06-25 21:40:18 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-25 21:40:18 --> Helper loaded: url_helper
INFO - 2018-06-25 21:40:18 --> Helper loaded: form_helper
INFO - 2018-06-25 21:40:18 --> Helper loaded: date_helper
INFO - 2018-06-25 21:40:18 --> Helper loaded: util_helper
INFO - 2018-06-25 21:40:18 --> Helper loaded: text_helper
INFO - 2018-06-25 21:40:18 --> Helper loaded: string_helper
INFO - 2018-06-25 21:40:18 --> Database Driver Class Initialized
DEBUG - 2018-06-25 21:40:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-25 21:40:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-25 21:40:18 --> Email Class Initialized
INFO - 2018-06-25 21:40:18 --> Controller Class Initialized
DEBUG - 2018-06-25 21:40:18 --> Home MX_Controller Initialized
DEBUG - 2018-06-25 21:40:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-25 21:40:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-25 21:40:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
ERROR - 2018-06-25 21:40:18 --> Severity: Notice --> Undefined index: home_name E:\xampp\htdocs\consulting\application\modules\home\views\common\header.php 32
DEBUG - 2018-06-25 21:40:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-25 21:40:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-25 21:40:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-25 21:40:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/search_page.php
INFO - 2018-06-25 21:40:18 --> Final output sent to browser
DEBUG - 2018-06-25 21:40:19 --> Total execution time: 0.3166
INFO - 2018-06-25 21:40:19 --> Config Class Initialized
INFO - 2018-06-25 21:40:19 --> Hooks Class Initialized
DEBUG - 2018-06-25 21:40:19 --> UTF-8 Support Enabled
INFO - 2018-06-25 21:40:19 --> Utf8 Class Initialized
INFO - 2018-06-25 21:40:19 --> URI Class Initialized
INFO - 2018-06-25 21:40:19 --> Router Class Initialized
INFO - 2018-06-25 21:40:19 --> Output Class Initialized
INFO - 2018-06-25 21:40:19 --> Security Class Initialized
DEBUG - 2018-06-25 21:40:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 21:40:19 --> Input Class Initialized
INFO - 2018-06-25 21:40:19 --> Language Class Initialized
INFO - 2018-06-25 21:40:19 --> Language Class Initialized
INFO - 2018-06-25 21:40:19 --> Config Class Initialized
INFO - 2018-06-25 21:40:19 --> Loader Class Initialized
DEBUG - 2018-06-25 21:40:19 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-25 21:40:19 --> Helper loaded: url_helper
INFO - 2018-06-25 21:40:19 --> Helper loaded: form_helper
INFO - 2018-06-25 21:40:19 --> Helper loaded: date_helper
INFO - 2018-06-25 21:40:19 --> Helper loaded: util_helper
INFO - 2018-06-25 21:40:19 --> Helper loaded: text_helper
INFO - 2018-06-25 21:40:19 --> Helper loaded: string_helper
INFO - 2018-06-25 21:40:19 --> Config Class Initialized
INFO - 2018-06-25 21:40:19 --> Hooks Class Initialized
INFO - 2018-06-25 21:40:19 --> Database Driver Class Initialized
DEBUG - 2018-06-25 21:40:19 --> UTF-8 Support Enabled
DEBUG - 2018-06-25 21:40:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-25 21:40:19 --> Utf8 Class Initialized
INFO - 2018-06-25 21:40:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-25 21:40:19 --> URI Class Initialized
INFO - 2018-06-25 21:40:19 --> Email Class Initialized
INFO - 2018-06-25 21:40:19 --> Controller Class Initialized
INFO - 2018-06-25 21:40:19 --> Router Class Initialized
DEBUG - 2018-06-25 21:40:19 --> Home MX_Controller Initialized
INFO - 2018-06-25 21:40:19 --> Output Class Initialized
DEBUG - 2018-06-25 21:40:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-06-25 21:40:19 --> Security Class Initialized
DEBUG - 2018-06-25 21:40:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-25 21:40:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-25 21:40:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 21:40:19 --> Input Class Initialized
ERROR - 2018-06-25 21:40:19 --> Severity: Notice --> Undefined index: home_name E:\xampp\htdocs\consulting\application\modules\home\views\common\header.php 32
INFO - 2018-06-25 21:40:19 --> Language Class Initialized
DEBUG - 2018-06-25 21:40:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
INFO - 2018-06-25 21:40:19 --> Language Class Initialized
INFO - 2018-06-25 21:40:19 --> Config Class Initialized
DEBUG - 2018-06-25 21:40:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-25 21:40:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
INFO - 2018-06-25 21:40:19 --> Loader Class Initialized
DEBUG - 2018-06-25 21:40:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/search_page.php
DEBUG - 2018-06-25 21:40:19 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-25 21:40:19 --> Final output sent to browser
INFO - 2018-06-25 21:40:19 --> Helper loaded: url_helper
DEBUG - 2018-06-25 21:40:19 --> Total execution time: 0.4000
INFO - 2018-06-25 21:40:19 --> Helper loaded: form_helper
INFO - 2018-06-25 21:40:19 --> Helper loaded: date_helper
INFO - 2018-06-25 21:40:19 --> Helper loaded: util_helper
INFO - 2018-06-25 21:40:19 --> Helper loaded: text_helper
INFO - 2018-06-25 21:40:19 --> Helper loaded: string_helper
INFO - 2018-06-25 21:40:19 --> Database Driver Class Initialized
DEBUG - 2018-06-25 21:40:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-25 21:40:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-25 21:40:19 --> Email Class Initialized
INFO - 2018-06-25 21:40:19 --> Controller Class Initialized
DEBUG - 2018-06-25 21:40:19 --> Home MX_Controller Initialized
DEBUG - 2018-06-25 21:40:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-25 21:40:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-25 21:40:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
ERROR - 2018-06-25 21:40:19 --> Severity: Notice --> Undefined index: home_name E:\xampp\htdocs\consulting\application\modules\home\views\common\header.php 32
DEBUG - 2018-06-25 21:40:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-25 21:40:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-25 21:40:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-25 21:40:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/search_page.php
INFO - 2018-06-25 21:40:19 --> Final output sent to browser
DEBUG - 2018-06-25 21:40:19 --> Total execution time: 0.4261
INFO - 2018-06-25 21:40:28 --> Config Class Initialized
INFO - 2018-06-25 21:40:28 --> Hooks Class Initialized
DEBUG - 2018-06-25 21:40:28 --> UTF-8 Support Enabled
INFO - 2018-06-25 21:40:28 --> Utf8 Class Initialized
INFO - 2018-06-25 21:40:28 --> URI Class Initialized
DEBUG - 2018-06-25 21:40:28 --> No URI present. Default controller set.
INFO - 2018-06-25 21:40:28 --> Router Class Initialized
INFO - 2018-06-25 21:40:28 --> Output Class Initialized
INFO - 2018-06-25 21:40:28 --> Security Class Initialized
DEBUG - 2018-06-25 21:40:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 21:40:28 --> Input Class Initialized
INFO - 2018-06-25 21:40:28 --> Language Class Initialized
INFO - 2018-06-25 21:40:28 --> Language Class Initialized
INFO - 2018-06-25 21:40:28 --> Config Class Initialized
INFO - 2018-06-25 21:40:28 --> Loader Class Initialized
DEBUG - 2018-06-25 21:40:28 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-25 21:40:28 --> Helper loaded: url_helper
INFO - 2018-06-25 21:40:28 --> Helper loaded: form_helper
INFO - 2018-06-25 21:40:28 --> Helper loaded: date_helper
INFO - 2018-06-25 21:40:28 --> Helper loaded: util_helper
INFO - 2018-06-25 21:40:28 --> Helper loaded: text_helper
INFO - 2018-06-25 21:40:28 --> Helper loaded: string_helper
INFO - 2018-06-25 21:40:28 --> Database Driver Class Initialized
DEBUG - 2018-06-25 21:40:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-25 21:40:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-25 21:40:28 --> Email Class Initialized
INFO - 2018-06-25 21:40:28 --> Controller Class Initialized
DEBUG - 2018-06-25 21:40:28 --> Home MX_Controller Initialized
DEBUG - 2018-06-25 21:40:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-25 21:40:28 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-25 21:40:28 --> Login MX_Controller Initialized
INFO - 2018-06-25 21:40:28 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-25 21:40:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-25 21:40:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-25 21:40:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-06-25 21:40:28 --> Config Class Initialized
INFO - 2018-06-25 21:40:28 --> Hooks Class Initialized
DEBUG - 2018-06-25 21:40:28 --> UTF-8 Support Enabled
INFO - 2018-06-25 21:40:28 --> Utf8 Class Initialized
INFO - 2018-06-25 21:40:28 --> URI Class Initialized
DEBUG - 2018-06-25 21:40:28 --> No URI present. Default controller set.
INFO - 2018-06-25 21:40:28 --> Router Class Initialized
INFO - 2018-06-25 21:40:28 --> Output Class Initialized
INFO - 2018-06-25 21:40:28 --> Security Class Initialized
DEBUG - 2018-06-25 21:40:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 21:40:28 --> Input Class Initialized
INFO - 2018-06-25 21:40:28 --> Language Class Initialized
INFO - 2018-06-25 21:40:28 --> Language Class Initialized
INFO - 2018-06-25 21:40:28 --> Config Class Initialized
INFO - 2018-06-25 21:40:28 --> Loader Class Initialized
DEBUG - 2018-06-25 21:40:29 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-25 21:40:29 --> Helper loaded: url_helper
INFO - 2018-06-25 21:40:29 --> Helper loaded: form_helper
INFO - 2018-06-25 21:40:29 --> Helper loaded: date_helper
INFO - 2018-06-25 21:40:29 --> Helper loaded: util_helper
INFO - 2018-06-25 21:40:29 --> Helper loaded: text_helper
INFO - 2018-06-25 21:40:29 --> Helper loaded: string_helper
INFO - 2018-06-25 21:40:29 --> Database Driver Class Initialized
DEBUG - 2018-06-25 21:40:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-25 21:40:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-25 21:40:29 --> Email Class Initialized
INFO - 2018-06-25 21:40:29 --> Controller Class Initialized
DEBUG - 2018-06-25 21:40:29 --> Home MX_Controller Initialized
DEBUG - 2018-06-25 21:40:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-25 21:40:29 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-25 21:40:29 --> Login MX_Controller Initialized
INFO - 2018-06-25 21:40:29 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-25 21:40:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-25 21:40:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-25 21:40:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-06-25 21:40:32 --> Config Class Initialized
INFO - 2018-06-25 21:40:32 --> Hooks Class Initialized
DEBUG - 2018-06-25 21:40:32 --> UTF-8 Support Enabled
INFO - 2018-06-25 21:40:32 --> Utf8 Class Initialized
INFO - 2018-06-25 21:40:32 --> URI Class Initialized
INFO - 2018-06-25 21:40:32 --> Router Class Initialized
INFO - 2018-06-25 21:40:32 --> Output Class Initialized
INFO - 2018-06-25 21:40:32 --> Security Class Initialized
DEBUG - 2018-06-25 21:40:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 21:40:32 --> Input Class Initialized
INFO - 2018-06-25 21:40:32 --> Language Class Initialized
INFO - 2018-06-25 21:40:32 --> Language Class Initialized
INFO - 2018-06-25 21:40:32 --> Config Class Initialized
INFO - 2018-06-25 21:40:32 --> Loader Class Initialized
DEBUG - 2018-06-25 21:40:32 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-25 21:40:32 --> Helper loaded: url_helper
INFO - 2018-06-25 21:40:32 --> Helper loaded: form_helper
INFO - 2018-06-25 21:40:32 --> Helper loaded: date_helper
INFO - 2018-06-25 21:40:32 --> Helper loaded: util_helper
INFO - 2018-06-25 21:40:32 --> Helper loaded: text_helper
INFO - 2018-06-25 21:40:32 --> Helper loaded: string_helper
INFO - 2018-06-25 21:40:32 --> Database Driver Class Initialized
DEBUG - 2018-06-25 21:40:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-25 21:40:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-25 21:40:32 --> Email Class Initialized
INFO - 2018-06-25 21:40:32 --> Controller Class Initialized
DEBUG - 2018-06-25 21:40:32 --> Login MX_Controller Initialized
INFO - 2018-06-25 21:40:32 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-25 21:40:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-25 21:40:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-25 21:40:32 --> Email starts for user@colin.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-06-25 21:40:32 --> User session created for 4
INFO - 2018-06-25 21:40:32 --> Login status user@colin.com - success
INFO - 2018-06-25 21:40:32 --> Final output sent to browser
DEBUG - 2018-06-25 21:40:32 --> Total execution time: 0.3894
INFO - 2018-06-25 21:40:32 --> Config Class Initialized
INFO - 2018-06-25 21:40:32 --> Hooks Class Initialized
DEBUG - 2018-06-25 21:40:33 --> UTF-8 Support Enabled
INFO - 2018-06-25 21:40:33 --> Utf8 Class Initialized
INFO - 2018-06-25 21:40:33 --> URI Class Initialized
DEBUG - 2018-06-25 21:40:33 --> No URI present. Default controller set.
INFO - 2018-06-25 21:40:33 --> Router Class Initialized
INFO - 2018-06-25 21:40:33 --> Output Class Initialized
INFO - 2018-06-25 21:40:33 --> Security Class Initialized
DEBUG - 2018-06-25 21:40:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 21:40:33 --> Input Class Initialized
INFO - 2018-06-25 21:40:33 --> Language Class Initialized
INFO - 2018-06-25 21:40:33 --> Language Class Initialized
INFO - 2018-06-25 21:40:33 --> Config Class Initialized
INFO - 2018-06-25 21:40:33 --> Loader Class Initialized
DEBUG - 2018-06-25 21:40:33 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-25 21:40:33 --> Helper loaded: url_helper
INFO - 2018-06-25 21:40:33 --> Helper loaded: form_helper
INFO - 2018-06-25 21:40:33 --> Helper loaded: date_helper
INFO - 2018-06-25 21:40:33 --> Helper loaded: util_helper
INFO - 2018-06-25 21:40:33 --> Helper loaded: text_helper
INFO - 2018-06-25 21:40:33 --> Helper loaded: string_helper
INFO - 2018-06-25 21:40:33 --> Database Driver Class Initialized
DEBUG - 2018-06-25 21:40:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-25 21:40:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-25 21:40:33 --> Email Class Initialized
INFO - 2018-06-25 21:40:33 --> Controller Class Initialized
DEBUG - 2018-06-25 21:40:33 --> Home MX_Controller Initialized
DEBUG - 2018-06-25 21:40:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-25 21:40:33 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-25 21:40:33 --> Login MX_Controller Initialized
INFO - 2018-06-25 21:40:33 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-25 21:40:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-25 21:40:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-25 21:40:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-25 21:40:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-25 21:40:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-25 21:40:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-25 21:40:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-25 21:40:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-06-25 21:40:33 --> Final output sent to browser
DEBUG - 2018-06-25 21:40:33 --> Total execution time: 0.5575
INFO - 2018-06-25 21:40:34 --> Config Class Initialized
INFO - 2018-06-25 21:40:34 --> Hooks Class Initialized
DEBUG - 2018-06-25 21:40:34 --> UTF-8 Support Enabled
INFO - 2018-06-25 21:40:34 --> Utf8 Class Initialized
INFO - 2018-06-25 21:40:34 --> URI Class Initialized
INFO - 2018-06-25 21:40:34 --> Router Class Initialized
INFO - 2018-06-25 21:40:34 --> Output Class Initialized
INFO - 2018-06-25 21:40:34 --> Security Class Initialized
DEBUG - 2018-06-25 21:40:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 21:40:34 --> Input Class Initialized
INFO - 2018-06-25 21:40:34 --> Language Class Initialized
ERROR - 2018-06-25 21:40:34 --> 404 Page Not Found: /index
INFO - 2018-06-25 21:40:34 --> Config Class Initialized
INFO - 2018-06-25 21:40:34 --> Hooks Class Initialized
DEBUG - 2018-06-25 21:40:34 --> UTF-8 Support Enabled
INFO - 2018-06-25 21:40:34 --> Utf8 Class Initialized
INFO - 2018-06-25 21:40:34 --> URI Class Initialized
INFO - 2018-06-25 21:40:34 --> Router Class Initialized
INFO - 2018-06-25 21:40:34 --> Output Class Initialized
INFO - 2018-06-25 21:40:34 --> Security Class Initialized
DEBUG - 2018-06-25 21:40:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 21:40:34 --> Input Class Initialized
INFO - 2018-06-25 21:40:34 --> Language Class Initialized
ERROR - 2018-06-25 21:40:34 --> 404 Page Not Found: /index
INFO - 2018-06-25 21:40:34 --> Config Class Initialized
INFO - 2018-06-25 21:40:34 --> Hooks Class Initialized
DEBUG - 2018-06-25 21:40:34 --> UTF-8 Support Enabled
INFO - 2018-06-25 21:40:34 --> Utf8 Class Initialized
INFO - 2018-06-25 21:40:34 --> URI Class Initialized
INFO - 2018-06-25 21:40:34 --> Router Class Initialized
INFO - 2018-06-25 21:40:34 --> Output Class Initialized
INFO - 2018-06-25 21:40:34 --> Security Class Initialized
DEBUG - 2018-06-25 21:40:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 21:40:34 --> Input Class Initialized
INFO - 2018-06-25 21:40:34 --> Language Class Initialized
ERROR - 2018-06-25 21:40:34 --> 404 Page Not Found: /index
INFO - 2018-06-25 21:40:37 --> Config Class Initialized
INFO - 2018-06-25 21:40:37 --> Hooks Class Initialized
DEBUG - 2018-06-25 21:40:37 --> UTF-8 Support Enabled
INFO - 2018-06-25 21:40:37 --> Utf8 Class Initialized
INFO - 2018-06-25 21:40:37 --> URI Class Initialized
INFO - 2018-06-25 21:40:37 --> Router Class Initialized
INFO - 2018-06-25 21:40:37 --> Output Class Initialized
INFO - 2018-06-25 21:40:37 --> Security Class Initialized
DEBUG - 2018-06-25 21:40:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 21:40:37 --> Input Class Initialized
INFO - 2018-06-25 21:40:37 --> Language Class Initialized
INFO - 2018-06-25 21:40:37 --> Language Class Initialized
INFO - 2018-06-25 21:40:37 --> Config Class Initialized
INFO - 2018-06-25 21:40:37 --> Loader Class Initialized
DEBUG - 2018-06-25 21:40:37 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-25 21:40:37 --> Helper loaded: url_helper
INFO - 2018-06-25 21:40:37 --> Helper loaded: form_helper
INFO - 2018-06-25 21:40:37 --> Helper loaded: date_helper
INFO - 2018-06-25 21:40:37 --> Helper loaded: util_helper
INFO - 2018-06-25 21:40:37 --> Helper loaded: text_helper
INFO - 2018-06-25 21:40:37 --> Helper loaded: string_helper
INFO - 2018-06-25 21:40:37 --> Database Driver Class Initialized
DEBUG - 2018-06-25 21:40:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-25 21:40:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-25 21:40:37 --> Email Class Initialized
INFO - 2018-06-25 21:40:37 --> Controller Class Initialized
DEBUG - 2018-06-25 21:40:37 --> Login MX_Controller Initialized
INFO - 2018-06-25 21:40:37 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-25 21:40:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-25 21:40:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-25 21:40:37 --> Email starts for admin@colin.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-06-25 21:40:37 --> User session created for 1
INFO - 2018-06-25 21:40:37 --> Login status admin@colin.com - success
INFO - 2018-06-25 21:40:37 --> Final output sent to browser
DEBUG - 2018-06-25 21:40:37 --> Total execution time: 0.4536
INFO - 2018-06-25 21:40:37 --> Config Class Initialized
INFO - 2018-06-25 21:40:37 --> Hooks Class Initialized
DEBUG - 2018-06-25 21:40:37 --> UTF-8 Support Enabled
INFO - 2018-06-25 21:40:37 --> Utf8 Class Initialized
INFO - 2018-06-25 21:40:37 --> URI Class Initialized
INFO - 2018-06-25 21:40:37 --> Router Class Initialized
INFO - 2018-06-25 21:40:37 --> Output Class Initialized
INFO - 2018-06-25 21:40:37 --> Security Class Initialized
DEBUG - 2018-06-25 21:40:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 21:40:37 --> Input Class Initialized
INFO - 2018-06-25 21:40:37 --> Language Class Initialized
INFO - 2018-06-25 21:40:37 --> Language Class Initialized
INFO - 2018-06-25 21:40:37 --> Config Class Initialized
INFO - 2018-06-25 21:40:37 --> Loader Class Initialized
DEBUG - 2018-06-25 21:40:37 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-25 21:40:37 --> Helper loaded: url_helper
INFO - 2018-06-25 21:40:37 --> Helper loaded: form_helper
INFO - 2018-06-25 21:40:37 --> Helper loaded: date_helper
INFO - 2018-06-25 21:40:37 --> Helper loaded: util_helper
INFO - 2018-06-25 21:40:37 --> Helper loaded: text_helper
INFO - 2018-06-25 21:40:37 --> Helper loaded: string_helper
INFO - 2018-06-25 21:40:37 --> Database Driver Class Initialized
DEBUG - 2018-06-25 21:40:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-25 21:40:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-25 21:40:37 --> Email Class Initialized
INFO - 2018-06-25 21:40:37 --> Controller Class Initialized
DEBUG - 2018-06-25 21:40:37 --> videos MX_Controller Initialized
INFO - 2018-06-25 21:40:37 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-25 21:40:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-06-25 21:40:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-25 21:40:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-25 21:40:37 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-25 21:40:37 --> Login MX_Controller Initialized
DEBUG - 2018-06-25 21:40:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-25 21:40:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-25 21:40:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-25 21:40:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-25 21:40:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-25 21:40:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-25 21:40:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/videos/videos.php
INFO - 2018-06-25 21:40:38 --> Final output sent to browser
DEBUG - 2018-06-25 21:40:38 --> Total execution time: 0.5986
INFO - 2018-06-25 21:40:39 --> Config Class Initialized
INFO - 2018-06-25 21:40:39 --> Hooks Class Initialized
DEBUG - 2018-06-25 21:40:39 --> UTF-8 Support Enabled
INFO - 2018-06-25 21:40:39 --> Utf8 Class Initialized
INFO - 2018-06-25 21:40:39 --> URI Class Initialized
INFO - 2018-06-25 21:40:39 --> Router Class Initialized
INFO - 2018-06-25 21:40:39 --> Output Class Initialized
INFO - 2018-06-25 21:40:39 --> Security Class Initialized
DEBUG - 2018-06-25 21:40:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 21:40:39 --> Input Class Initialized
INFO - 2018-06-25 21:40:39 --> Language Class Initialized
INFO - 2018-06-25 21:40:39 --> Language Class Initialized
INFO - 2018-06-25 21:40:39 --> Config Class Initialized
INFO - 2018-06-25 21:40:39 --> Loader Class Initialized
DEBUG - 2018-06-25 21:40:39 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-25 21:40:39 --> Helper loaded: url_helper
INFO - 2018-06-25 21:40:39 --> Helper loaded: form_helper
INFO - 2018-06-25 21:40:39 --> Helper loaded: date_helper
INFO - 2018-06-25 21:40:39 --> Helper loaded: util_helper
INFO - 2018-06-25 21:40:39 --> Helper loaded: text_helper
INFO - 2018-06-25 21:40:39 --> Helper loaded: string_helper
INFO - 2018-06-25 21:40:39 --> Database Driver Class Initialized
DEBUG - 2018-06-25 21:40:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-25 21:40:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-25 21:40:39 --> Email Class Initialized
INFO - 2018-06-25 21:40:39 --> Controller Class Initialized
DEBUG - 2018-06-25 21:40:39 --> videos MX_Controller Initialized
INFO - 2018-06-25 21:40:40 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-25 21:40:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-06-25 21:40:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-25 21:40:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-25 21:40:40 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-25 21:40:40 --> Login MX_Controller Initialized
DEBUG - 2018-06-25 21:40:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-25 21:40:40 --> Final output sent to browser
DEBUG - 2018-06-25 21:40:40 --> Total execution time: 0.6423
INFO - 2018-06-25 21:40:48 --> Config Class Initialized
INFO - 2018-06-25 21:40:48 --> Hooks Class Initialized
DEBUG - 2018-06-25 21:40:48 --> UTF-8 Support Enabled
INFO - 2018-06-25 21:40:48 --> Utf8 Class Initialized
INFO - 2018-06-25 21:40:48 --> URI Class Initialized
INFO - 2018-06-25 21:40:48 --> Router Class Initialized
INFO - 2018-06-25 21:40:48 --> Output Class Initialized
INFO - 2018-06-25 21:40:48 --> Security Class Initialized
DEBUG - 2018-06-25 21:40:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 21:40:48 --> Input Class Initialized
INFO - 2018-06-25 21:40:48 --> Language Class Initialized
INFO - 2018-06-25 21:40:48 --> Language Class Initialized
INFO - 2018-06-25 21:40:48 --> Config Class Initialized
INFO - 2018-06-25 21:40:48 --> Loader Class Initialized
DEBUG - 2018-06-25 21:40:48 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-25 21:40:48 --> Helper loaded: url_helper
INFO - 2018-06-25 21:40:48 --> Helper loaded: form_helper
INFO - 2018-06-25 21:40:48 --> Helper loaded: date_helper
INFO - 2018-06-25 21:40:48 --> Helper loaded: util_helper
INFO - 2018-06-25 21:40:48 --> Helper loaded: text_helper
INFO - 2018-06-25 21:40:48 --> Helper loaded: string_helper
INFO - 2018-06-25 21:40:48 --> Database Driver Class Initialized
DEBUG - 2018-06-25 21:40:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-25 21:40:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-25 21:40:48 --> Email Class Initialized
INFO - 2018-06-25 21:40:48 --> Controller Class Initialized
DEBUG - 2018-06-25 21:40:48 --> Home MX_Controller Initialized
DEBUG - 2018-06-25 21:40:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-25 21:40:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-25 21:40:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-25 21:40:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-25 21:40:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-25 21:40:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-25 21:40:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/search_page.php
INFO - 2018-06-25 21:40:48 --> Final output sent to browser
DEBUG - 2018-06-25 21:40:48 --> Total execution time: 0.4070
INFO - 2018-06-25 21:40:49 --> Config Class Initialized
INFO - 2018-06-25 21:40:49 --> Hooks Class Initialized
DEBUG - 2018-06-25 21:40:49 --> UTF-8 Support Enabled
INFO - 2018-06-25 21:40:49 --> Utf8 Class Initialized
INFO - 2018-06-25 21:40:49 --> URI Class Initialized
INFO - 2018-06-25 21:40:49 --> Router Class Initialized
INFO - 2018-06-25 21:40:49 --> Output Class Initialized
INFO - 2018-06-25 21:40:49 --> Security Class Initialized
DEBUG - 2018-06-25 21:40:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 21:40:49 --> Input Class Initialized
INFO - 2018-06-25 21:40:49 --> Language Class Initialized
ERROR - 2018-06-25 21:40:49 --> 404 Page Not Found: /index
INFO - 2018-06-25 21:40:49 --> Config Class Initialized
INFO - 2018-06-25 21:40:49 --> Hooks Class Initialized
DEBUG - 2018-06-25 21:40:49 --> UTF-8 Support Enabled
INFO - 2018-06-25 21:40:49 --> Utf8 Class Initialized
INFO - 2018-06-25 21:40:49 --> URI Class Initialized
INFO - 2018-06-25 21:40:49 --> Router Class Initialized
INFO - 2018-06-25 21:40:49 --> Output Class Initialized
INFO - 2018-06-25 21:40:49 --> Security Class Initialized
DEBUG - 2018-06-25 21:40:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 21:40:49 --> Input Class Initialized
INFO - 2018-06-25 21:40:49 --> Language Class Initialized
ERROR - 2018-06-25 21:40:49 --> 404 Page Not Found: /index
INFO - 2018-06-25 21:40:49 --> Config Class Initialized
INFO - 2018-06-25 21:40:49 --> Hooks Class Initialized
DEBUG - 2018-06-25 21:40:49 --> UTF-8 Support Enabled
INFO - 2018-06-25 21:40:49 --> Utf8 Class Initialized
INFO - 2018-06-25 21:40:49 --> URI Class Initialized
INFO - 2018-06-25 21:40:49 --> Router Class Initialized
INFO - 2018-06-25 21:40:49 --> Output Class Initialized
INFO - 2018-06-25 21:40:49 --> Security Class Initialized
DEBUG - 2018-06-25 21:40:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 21:40:49 --> Input Class Initialized
INFO - 2018-06-25 21:40:49 --> Language Class Initialized
ERROR - 2018-06-25 21:40:49 --> 404 Page Not Found: /index
INFO - 2018-06-25 21:42:30 --> Config Class Initialized
INFO - 2018-06-25 21:42:30 --> Hooks Class Initialized
DEBUG - 2018-06-25 21:42:31 --> UTF-8 Support Enabled
INFO - 2018-06-25 21:42:31 --> Utf8 Class Initialized
INFO - 2018-06-25 21:42:31 --> URI Class Initialized
INFO - 2018-06-25 21:42:31 --> Router Class Initialized
INFO - 2018-06-25 21:42:31 --> Output Class Initialized
INFO - 2018-06-25 21:42:31 --> Security Class Initialized
DEBUG - 2018-06-25 21:42:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 21:42:31 --> Input Class Initialized
INFO - 2018-06-25 21:42:31 --> Language Class Initialized
INFO - 2018-06-25 21:42:31 --> Language Class Initialized
INFO - 2018-06-25 21:42:31 --> Config Class Initialized
INFO - 2018-06-25 21:42:31 --> Loader Class Initialized
DEBUG - 2018-06-25 21:42:31 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-25 21:42:31 --> Helper loaded: url_helper
INFO - 2018-06-25 21:42:31 --> Helper loaded: form_helper
INFO - 2018-06-25 21:42:31 --> Helper loaded: date_helper
INFO - 2018-06-25 21:42:31 --> Helper loaded: util_helper
INFO - 2018-06-25 21:42:31 --> Helper loaded: text_helper
INFO - 2018-06-25 21:42:31 --> Helper loaded: string_helper
INFO - 2018-06-25 21:42:31 --> Database Driver Class Initialized
DEBUG - 2018-06-25 21:42:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-25 21:42:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-25 21:42:31 --> Email Class Initialized
INFO - 2018-06-25 21:42:31 --> Controller Class Initialized
DEBUG - 2018-06-25 21:42:31 --> Home MX_Controller Initialized
DEBUG - 2018-06-25 21:42:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-25 21:42:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-25 21:42:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-25 21:42:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-25 21:42:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-25 21:42:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-25 21:42:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/search_page.php
INFO - 2018-06-25 21:42:31 --> Final output sent to browser
DEBUG - 2018-06-25 21:42:31 --> Total execution time: 0.3936
INFO - 2018-06-25 21:42:31 --> Config Class Initialized
INFO - 2018-06-25 21:42:31 --> Hooks Class Initialized
DEBUG - 2018-06-25 21:42:31 --> UTF-8 Support Enabled
INFO - 2018-06-25 21:42:31 --> Utf8 Class Initialized
INFO - 2018-06-25 21:42:31 --> URI Class Initialized
INFO - 2018-06-25 21:42:31 --> Router Class Initialized
INFO - 2018-06-25 21:42:31 --> Output Class Initialized
INFO - 2018-06-25 21:42:31 --> Security Class Initialized
DEBUG - 2018-06-25 21:42:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 21:42:31 --> Input Class Initialized
INFO - 2018-06-25 21:42:31 --> Language Class Initialized
ERROR - 2018-06-25 21:42:31 --> 404 Page Not Found: /index
INFO - 2018-06-25 21:42:31 --> Config Class Initialized
INFO - 2018-06-25 21:42:31 --> Hooks Class Initialized
DEBUG - 2018-06-25 21:42:31 --> UTF-8 Support Enabled
INFO - 2018-06-25 21:42:31 --> Utf8 Class Initialized
INFO - 2018-06-25 21:42:31 --> URI Class Initialized
INFO - 2018-06-25 21:42:31 --> Router Class Initialized
INFO - 2018-06-25 21:42:31 --> Output Class Initialized
INFO - 2018-06-25 21:42:31 --> Security Class Initialized
DEBUG - 2018-06-25 21:42:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 21:42:31 --> Input Class Initialized
INFO - 2018-06-25 21:42:32 --> Language Class Initialized
ERROR - 2018-06-25 21:42:32 --> 404 Page Not Found: /index
INFO - 2018-06-25 21:42:32 --> Config Class Initialized
INFO - 2018-06-25 21:42:32 --> Hooks Class Initialized
DEBUG - 2018-06-25 21:42:32 --> UTF-8 Support Enabled
INFO - 2018-06-25 21:42:32 --> Utf8 Class Initialized
INFO - 2018-06-25 21:42:32 --> URI Class Initialized
INFO - 2018-06-25 21:42:32 --> Router Class Initialized
INFO - 2018-06-25 21:42:32 --> Output Class Initialized
INFO - 2018-06-25 21:42:32 --> Security Class Initialized
DEBUG - 2018-06-25 21:42:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 21:42:32 --> Input Class Initialized
INFO - 2018-06-25 21:42:32 --> Language Class Initialized
ERROR - 2018-06-25 21:42:32 --> 404 Page Not Found: /index
INFO - 2018-06-25 21:43:45 --> Config Class Initialized
INFO - 2018-06-25 21:43:45 --> Hooks Class Initialized
DEBUG - 2018-06-25 21:43:45 --> UTF-8 Support Enabled
INFO - 2018-06-25 21:43:45 --> Utf8 Class Initialized
INFO - 2018-06-25 21:43:45 --> URI Class Initialized
INFO - 2018-06-25 21:43:45 --> Router Class Initialized
INFO - 2018-06-25 21:43:45 --> Output Class Initialized
INFO - 2018-06-25 21:43:45 --> Security Class Initialized
DEBUG - 2018-06-25 21:43:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 21:43:45 --> Input Class Initialized
INFO - 2018-06-25 21:43:45 --> Language Class Initialized
INFO - 2018-06-25 21:43:45 --> Language Class Initialized
INFO - 2018-06-25 21:43:45 --> Config Class Initialized
INFO - 2018-06-25 21:43:45 --> Loader Class Initialized
DEBUG - 2018-06-25 21:43:45 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-25 21:43:45 --> Helper loaded: url_helper
INFO - 2018-06-25 21:43:45 --> Helper loaded: form_helper
INFO - 2018-06-25 21:43:45 --> Helper loaded: date_helper
INFO - 2018-06-25 21:43:45 --> Helper loaded: util_helper
INFO - 2018-06-25 21:43:45 --> Helper loaded: text_helper
INFO - 2018-06-25 21:43:45 --> Helper loaded: string_helper
INFO - 2018-06-25 21:43:45 --> Database Driver Class Initialized
DEBUG - 2018-06-25 21:43:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-25 21:43:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-25 21:43:45 --> Email Class Initialized
INFO - 2018-06-25 21:43:45 --> Controller Class Initialized
DEBUG - 2018-06-25 21:43:45 --> Home MX_Controller Initialized
DEBUG - 2018-06-25 21:43:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-06-25 21:46:29 --> Config Class Initialized
INFO - 2018-06-25 21:46:29 --> Hooks Class Initialized
DEBUG - 2018-06-25 21:46:29 --> UTF-8 Support Enabled
INFO - 2018-06-25 21:46:29 --> Utf8 Class Initialized
INFO - 2018-06-25 21:46:29 --> URI Class Initialized
INFO - 2018-06-25 21:46:29 --> Router Class Initialized
INFO - 2018-06-25 21:46:29 --> Output Class Initialized
INFO - 2018-06-25 21:46:29 --> Security Class Initialized
DEBUG - 2018-06-25 21:46:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 21:46:29 --> Input Class Initialized
INFO - 2018-06-25 21:46:29 --> Language Class Initialized
INFO - 2018-06-25 21:46:29 --> Language Class Initialized
INFO - 2018-06-25 21:46:29 --> Config Class Initialized
INFO - 2018-06-25 21:46:29 --> Loader Class Initialized
DEBUG - 2018-06-25 21:46:29 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-25 21:46:29 --> Helper loaded: url_helper
INFO - 2018-06-25 21:46:29 --> Helper loaded: form_helper
INFO - 2018-06-25 21:46:29 --> Helper loaded: date_helper
INFO - 2018-06-25 21:46:29 --> Helper loaded: util_helper
INFO - 2018-06-25 21:46:29 --> Helper loaded: text_helper
INFO - 2018-06-25 21:46:29 --> Helper loaded: string_helper
INFO - 2018-06-25 21:46:29 --> Database Driver Class Initialized
DEBUG - 2018-06-25 21:46:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-25 21:46:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-25 21:46:30 --> Email Class Initialized
INFO - 2018-06-25 21:46:30 --> Controller Class Initialized
DEBUG - 2018-06-25 21:46:30 --> Home MX_Controller Initialized
DEBUG - 2018-06-25 21:46:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-06-25 21:50:11 --> Config Class Initialized
INFO - 2018-06-25 21:50:11 --> Hooks Class Initialized
DEBUG - 2018-06-25 21:50:11 --> UTF-8 Support Enabled
INFO - 2018-06-25 21:50:11 --> Utf8 Class Initialized
INFO - 2018-06-25 21:50:11 --> URI Class Initialized
INFO - 2018-06-25 21:50:11 --> Router Class Initialized
INFO - 2018-06-25 21:50:11 --> Output Class Initialized
INFO - 2018-06-25 21:50:11 --> Security Class Initialized
DEBUG - 2018-06-25 21:50:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 21:50:11 --> Input Class Initialized
INFO - 2018-06-25 21:50:11 --> Language Class Initialized
INFO - 2018-06-25 21:50:11 --> Language Class Initialized
INFO - 2018-06-25 21:50:11 --> Config Class Initialized
INFO - 2018-06-25 21:50:11 --> Loader Class Initialized
DEBUG - 2018-06-25 21:50:11 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-25 21:50:11 --> Helper loaded: url_helper
INFO - 2018-06-25 21:50:11 --> Helper loaded: form_helper
INFO - 2018-06-25 21:50:11 --> Helper loaded: date_helper
INFO - 2018-06-25 21:50:11 --> Helper loaded: util_helper
INFO - 2018-06-25 21:50:11 --> Helper loaded: text_helper
INFO - 2018-06-25 21:50:11 --> Helper loaded: string_helper
INFO - 2018-06-25 21:50:11 --> Database Driver Class Initialized
DEBUG - 2018-06-25 21:50:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-25 21:50:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-25 21:50:11 --> Email Class Initialized
INFO - 2018-06-25 21:50:11 --> Controller Class Initialized
DEBUG - 2018-06-25 21:50:11 --> Home MX_Controller Initialized
DEBUG - 2018-06-25 21:50:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
ERROR - 2018-06-25 21:50:11 --> Query error: Unknown column 'name' in 'where clause' - Invalid query: SELECT *
FROM `videos`
WHERE  name  LIKE '%Health%' ESCAPE '!' 
INFO - 2018-06-25 21:50:11 --> Language file loaded: language/english/db_lang.php
INFO - 2018-06-25 21:50:30 --> Config Class Initialized
INFO - 2018-06-25 21:50:30 --> Hooks Class Initialized
DEBUG - 2018-06-25 21:50:30 --> UTF-8 Support Enabled
INFO - 2018-06-25 21:50:30 --> Utf8 Class Initialized
INFO - 2018-06-25 21:50:30 --> URI Class Initialized
INFO - 2018-06-25 21:50:30 --> Router Class Initialized
INFO - 2018-06-25 21:50:30 --> Output Class Initialized
INFO - 2018-06-25 21:50:30 --> Security Class Initialized
DEBUG - 2018-06-25 21:50:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 21:50:30 --> Input Class Initialized
INFO - 2018-06-25 21:50:30 --> Language Class Initialized
INFO - 2018-06-25 21:50:30 --> Language Class Initialized
INFO - 2018-06-25 21:50:30 --> Config Class Initialized
INFO - 2018-06-25 21:50:30 --> Loader Class Initialized
DEBUG - 2018-06-25 21:50:30 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-25 21:50:30 --> Helper loaded: url_helper
INFO - 2018-06-25 21:50:30 --> Helper loaded: form_helper
INFO - 2018-06-25 21:50:30 --> Helper loaded: date_helper
INFO - 2018-06-25 21:50:30 --> Helper loaded: util_helper
INFO - 2018-06-25 21:50:30 --> Helper loaded: text_helper
INFO - 2018-06-25 21:50:30 --> Helper loaded: string_helper
INFO - 2018-06-25 21:50:30 --> Database Driver Class Initialized
DEBUG - 2018-06-25 21:50:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-25 21:50:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-25 21:50:30 --> Email Class Initialized
INFO - 2018-06-25 21:50:30 --> Controller Class Initialized
DEBUG - 2018-06-25 21:50:30 --> Home MX_Controller Initialized
DEBUG - 2018-06-25 21:50:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-06-25 21:51:59 --> Config Class Initialized
INFO - 2018-06-25 21:51:59 --> Hooks Class Initialized
DEBUG - 2018-06-25 21:51:59 --> UTF-8 Support Enabled
INFO - 2018-06-25 21:51:59 --> Utf8 Class Initialized
INFO - 2018-06-25 21:51:59 --> URI Class Initialized
INFO - 2018-06-25 21:51:59 --> Router Class Initialized
INFO - 2018-06-25 21:51:59 --> Output Class Initialized
INFO - 2018-06-25 21:51:59 --> Security Class Initialized
DEBUG - 2018-06-25 21:51:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 21:51:59 --> Input Class Initialized
INFO - 2018-06-25 21:51:59 --> Language Class Initialized
INFO - 2018-06-25 21:51:59 --> Language Class Initialized
INFO - 2018-06-25 21:51:59 --> Config Class Initialized
INFO - 2018-06-25 21:51:59 --> Loader Class Initialized
DEBUG - 2018-06-25 21:51:59 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-25 21:51:59 --> Helper loaded: url_helper
INFO - 2018-06-25 21:51:59 --> Helper loaded: form_helper
INFO - 2018-06-25 21:51:59 --> Helper loaded: date_helper
INFO - 2018-06-25 21:51:59 --> Helper loaded: util_helper
INFO - 2018-06-25 21:51:59 --> Helper loaded: text_helper
INFO - 2018-06-25 21:51:59 --> Helper loaded: string_helper
INFO - 2018-06-25 21:51:59 --> Database Driver Class Initialized
DEBUG - 2018-06-25 21:51:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-25 21:51:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-25 21:51:59 --> Email Class Initialized
INFO - 2018-06-25 21:51:59 --> Controller Class Initialized
DEBUG - 2018-06-25 21:51:59 --> Home MX_Controller Initialized
DEBUG - 2018-06-25 21:51:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-06-25 21:52:09 --> Config Class Initialized
INFO - 2018-06-25 21:52:09 --> Hooks Class Initialized
DEBUG - 2018-06-25 21:52:09 --> UTF-8 Support Enabled
INFO - 2018-06-25 21:52:09 --> Utf8 Class Initialized
INFO - 2018-06-25 21:52:09 --> URI Class Initialized
INFO - 2018-06-25 21:52:09 --> Router Class Initialized
INFO - 2018-06-25 21:52:09 --> Output Class Initialized
INFO - 2018-06-25 21:52:09 --> Security Class Initialized
DEBUG - 2018-06-25 21:52:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 21:52:09 --> Input Class Initialized
INFO - 2018-06-25 21:52:09 --> Language Class Initialized
INFO - 2018-06-25 21:52:09 --> Language Class Initialized
INFO - 2018-06-25 21:52:09 --> Config Class Initialized
INFO - 2018-06-25 21:52:09 --> Loader Class Initialized
DEBUG - 2018-06-25 21:52:09 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-25 21:52:09 --> Helper loaded: url_helper
INFO - 2018-06-25 21:52:09 --> Helper loaded: form_helper
INFO - 2018-06-25 21:52:09 --> Helper loaded: date_helper
INFO - 2018-06-25 21:52:09 --> Helper loaded: util_helper
INFO - 2018-06-25 21:52:09 --> Helper loaded: text_helper
INFO - 2018-06-25 21:52:09 --> Helper loaded: string_helper
INFO - 2018-06-25 21:52:09 --> Database Driver Class Initialized
DEBUG - 2018-06-25 21:52:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-25 21:52:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-25 21:52:09 --> Email Class Initialized
INFO - 2018-06-25 21:52:09 --> Controller Class Initialized
DEBUG - 2018-06-25 21:52:09 --> Home MX_Controller Initialized
DEBUG - 2018-06-25 21:52:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-25 21:52:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-25 21:52:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-25 21:52:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-25 21:52:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-25 21:52:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-25 21:52:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/search_page.php
INFO - 2018-06-25 21:52:09 --> Final output sent to browser
DEBUG - 2018-06-25 21:52:09 --> Total execution time: 0.3479
INFO - 2018-06-25 21:52:09 --> Config Class Initialized
INFO - 2018-06-25 21:52:10 --> Hooks Class Initialized
DEBUG - 2018-06-25 21:52:10 --> UTF-8 Support Enabled
INFO - 2018-06-25 21:52:10 --> Utf8 Class Initialized
INFO - 2018-06-25 21:52:10 --> URI Class Initialized
INFO - 2018-06-25 21:52:10 --> Router Class Initialized
INFO - 2018-06-25 21:52:10 --> Output Class Initialized
INFO - 2018-06-25 21:52:10 --> Security Class Initialized
DEBUG - 2018-06-25 21:52:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 21:52:10 --> Input Class Initialized
INFO - 2018-06-25 21:52:10 --> Language Class Initialized
ERROR - 2018-06-25 21:52:10 --> 404 Page Not Found: /index
INFO - 2018-06-25 21:52:10 --> Config Class Initialized
INFO - 2018-06-25 21:52:10 --> Hooks Class Initialized
DEBUG - 2018-06-25 21:52:10 --> UTF-8 Support Enabled
INFO - 2018-06-25 21:52:10 --> Utf8 Class Initialized
INFO - 2018-06-25 21:52:10 --> URI Class Initialized
INFO - 2018-06-25 21:52:10 --> Router Class Initialized
INFO - 2018-06-25 21:52:10 --> Output Class Initialized
INFO - 2018-06-25 21:52:10 --> Security Class Initialized
DEBUG - 2018-06-25 21:52:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 21:52:10 --> Input Class Initialized
INFO - 2018-06-25 21:52:10 --> Language Class Initialized
ERROR - 2018-06-25 21:52:10 --> 404 Page Not Found: /index
INFO - 2018-06-25 21:52:10 --> Config Class Initialized
INFO - 2018-06-25 21:52:10 --> Hooks Class Initialized
DEBUG - 2018-06-25 21:52:10 --> UTF-8 Support Enabled
INFO - 2018-06-25 21:52:10 --> Utf8 Class Initialized
INFO - 2018-06-25 21:52:10 --> URI Class Initialized
INFO - 2018-06-25 21:52:10 --> Router Class Initialized
INFO - 2018-06-25 21:52:10 --> Output Class Initialized
INFO - 2018-06-25 21:52:10 --> Security Class Initialized
DEBUG - 2018-06-25 21:52:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 21:52:10 --> Input Class Initialized
INFO - 2018-06-25 21:52:10 --> Language Class Initialized
ERROR - 2018-06-25 21:52:10 --> 404 Page Not Found: /index
INFO - 2018-06-25 21:54:34 --> Config Class Initialized
INFO - 2018-06-25 21:54:34 --> Hooks Class Initialized
DEBUG - 2018-06-25 21:54:34 --> UTF-8 Support Enabled
INFO - 2018-06-25 21:54:34 --> Utf8 Class Initialized
INFO - 2018-06-25 21:54:34 --> URI Class Initialized
INFO - 2018-06-25 21:54:34 --> Router Class Initialized
INFO - 2018-06-25 21:54:34 --> Output Class Initialized
INFO - 2018-06-25 21:54:34 --> Security Class Initialized
DEBUG - 2018-06-25 21:54:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 21:54:34 --> Input Class Initialized
INFO - 2018-06-25 21:54:34 --> Language Class Initialized
INFO - 2018-06-25 21:54:34 --> Language Class Initialized
INFO - 2018-06-25 21:54:34 --> Config Class Initialized
INFO - 2018-06-25 21:54:34 --> Loader Class Initialized
DEBUG - 2018-06-25 21:54:34 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-25 21:54:34 --> Helper loaded: url_helper
INFO - 2018-06-25 21:54:34 --> Helper loaded: form_helper
INFO - 2018-06-25 21:54:34 --> Helper loaded: date_helper
INFO - 2018-06-25 21:54:34 --> Helper loaded: util_helper
INFO - 2018-06-25 21:54:34 --> Helper loaded: text_helper
INFO - 2018-06-25 21:54:34 --> Helper loaded: string_helper
INFO - 2018-06-25 21:54:34 --> Database Driver Class Initialized
DEBUG - 2018-06-25 21:54:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-25 21:54:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-25 21:54:34 --> Email Class Initialized
INFO - 2018-06-25 21:54:34 --> Controller Class Initialized
DEBUG - 2018-06-25 21:54:34 --> Home MX_Controller Initialized
DEBUG - 2018-06-25 21:54:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-06-25 21:55:23 --> Config Class Initialized
INFO - 2018-06-25 21:55:23 --> Hooks Class Initialized
DEBUG - 2018-06-25 21:55:23 --> UTF-8 Support Enabled
INFO - 2018-06-25 21:55:23 --> Utf8 Class Initialized
INFO - 2018-06-25 21:55:23 --> URI Class Initialized
INFO - 2018-06-25 21:55:23 --> Router Class Initialized
INFO - 2018-06-25 21:55:23 --> Output Class Initialized
INFO - 2018-06-25 21:55:23 --> Security Class Initialized
DEBUG - 2018-06-25 21:55:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 21:55:23 --> Input Class Initialized
INFO - 2018-06-25 21:55:23 --> Language Class Initialized
INFO - 2018-06-25 21:55:23 --> Language Class Initialized
INFO - 2018-06-25 21:55:23 --> Config Class Initialized
INFO - 2018-06-25 21:55:23 --> Loader Class Initialized
DEBUG - 2018-06-25 21:55:23 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-25 21:55:23 --> Helper loaded: url_helper
INFO - 2018-06-25 21:55:23 --> Helper loaded: form_helper
INFO - 2018-06-25 21:55:23 --> Helper loaded: date_helper
INFO - 2018-06-25 21:55:23 --> Helper loaded: util_helper
INFO - 2018-06-25 21:55:23 --> Helper loaded: text_helper
INFO - 2018-06-25 21:55:23 --> Helper loaded: string_helper
INFO - 2018-06-25 21:55:23 --> Database Driver Class Initialized
DEBUG - 2018-06-25 21:55:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-25 21:55:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-25 21:55:23 --> Email Class Initialized
INFO - 2018-06-25 21:55:24 --> Controller Class Initialized
DEBUG - 2018-06-25 21:55:24 --> Home MX_Controller Initialized
DEBUG - 2018-06-25 21:55:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-06-25 21:55:38 --> Config Class Initialized
INFO - 2018-06-25 21:55:38 --> Hooks Class Initialized
DEBUG - 2018-06-25 21:55:38 --> UTF-8 Support Enabled
INFO - 2018-06-25 21:55:38 --> Utf8 Class Initialized
INFO - 2018-06-25 21:55:38 --> URI Class Initialized
INFO - 2018-06-25 21:55:38 --> Router Class Initialized
INFO - 2018-06-25 21:55:38 --> Output Class Initialized
INFO - 2018-06-25 21:55:38 --> Security Class Initialized
DEBUG - 2018-06-25 21:55:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 21:55:38 --> Input Class Initialized
INFO - 2018-06-25 21:55:38 --> Language Class Initialized
INFO - 2018-06-25 21:55:38 --> Language Class Initialized
INFO - 2018-06-25 21:55:38 --> Config Class Initialized
INFO - 2018-06-25 21:55:38 --> Loader Class Initialized
DEBUG - 2018-06-25 21:55:38 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-25 21:55:38 --> Helper loaded: url_helper
INFO - 2018-06-25 21:55:38 --> Helper loaded: form_helper
INFO - 2018-06-25 21:55:38 --> Helper loaded: date_helper
INFO - 2018-06-25 21:55:38 --> Helper loaded: util_helper
INFO - 2018-06-25 21:55:38 --> Helper loaded: text_helper
INFO - 2018-06-25 21:55:38 --> Helper loaded: string_helper
INFO - 2018-06-25 21:55:38 --> Database Driver Class Initialized
DEBUG - 2018-06-25 21:55:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-25 21:55:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-25 21:55:38 --> Email Class Initialized
INFO - 2018-06-25 21:55:38 --> Controller Class Initialized
DEBUG - 2018-06-25 21:55:38 --> Home MX_Controller Initialized
DEBUG - 2018-06-25 21:55:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-25 21:55:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-25 21:55:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-25 21:55:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-25 21:55:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-25 21:55:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-25 21:55:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/search_page.php
INFO - 2018-06-25 21:55:39 --> Final output sent to browser
DEBUG - 2018-06-25 21:55:39 --> Total execution time: 0.3705
INFO - 2018-06-25 21:55:39 --> Config Class Initialized
INFO - 2018-06-25 21:55:39 --> Hooks Class Initialized
DEBUG - 2018-06-25 21:55:39 --> UTF-8 Support Enabled
INFO - 2018-06-25 21:55:39 --> Utf8 Class Initialized
INFO - 2018-06-25 21:55:39 --> URI Class Initialized
INFO - 2018-06-25 21:55:39 --> Router Class Initialized
INFO - 2018-06-25 21:55:39 --> Output Class Initialized
INFO - 2018-06-25 21:55:39 --> Security Class Initialized
DEBUG - 2018-06-25 21:55:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 21:55:39 --> Input Class Initialized
INFO - 2018-06-25 21:55:39 --> Language Class Initialized
ERROR - 2018-06-25 21:55:39 --> 404 Page Not Found: /index
INFO - 2018-06-25 21:55:39 --> Config Class Initialized
INFO - 2018-06-25 21:55:39 --> Hooks Class Initialized
DEBUG - 2018-06-25 21:55:39 --> UTF-8 Support Enabled
INFO - 2018-06-25 21:55:39 --> Utf8 Class Initialized
INFO - 2018-06-25 21:55:39 --> URI Class Initialized
INFO - 2018-06-25 21:55:39 --> Router Class Initialized
INFO - 2018-06-25 21:55:39 --> Output Class Initialized
INFO - 2018-06-25 21:55:39 --> Security Class Initialized
DEBUG - 2018-06-25 21:55:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 21:55:39 --> Input Class Initialized
INFO - 2018-06-25 21:55:39 --> Language Class Initialized
ERROR - 2018-06-25 21:55:39 --> 404 Page Not Found: /index
INFO - 2018-06-25 21:55:39 --> Config Class Initialized
INFO - 2018-06-25 21:55:39 --> Hooks Class Initialized
DEBUG - 2018-06-25 21:55:39 --> UTF-8 Support Enabled
INFO - 2018-06-25 21:55:39 --> Utf8 Class Initialized
INFO - 2018-06-25 21:55:39 --> URI Class Initialized
INFO - 2018-06-25 21:55:39 --> Router Class Initialized
INFO - 2018-06-25 21:55:39 --> Output Class Initialized
INFO - 2018-06-25 21:55:39 --> Security Class Initialized
DEBUG - 2018-06-25 21:55:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 21:55:39 --> Input Class Initialized
INFO - 2018-06-25 21:55:39 --> Language Class Initialized
ERROR - 2018-06-25 21:55:39 --> 404 Page Not Found: /index
INFO - 2018-06-25 21:55:39 --> Config Class Initialized
INFO - 2018-06-25 21:55:39 --> Hooks Class Initialized
DEBUG - 2018-06-25 21:55:39 --> UTF-8 Support Enabled
INFO - 2018-06-25 21:55:39 --> Utf8 Class Initialized
INFO - 2018-06-25 21:55:39 --> URI Class Initialized
INFO - 2018-06-25 21:55:39 --> Router Class Initialized
INFO - 2018-06-25 21:55:39 --> Output Class Initialized
INFO - 2018-06-25 21:55:39 --> Security Class Initialized
DEBUG - 2018-06-25 21:55:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 21:55:39 --> Input Class Initialized
INFO - 2018-06-25 21:55:39 --> Language Class Initialized
ERROR - 2018-06-25 21:55:39 --> 404 Page Not Found: /index
INFO - 2018-06-25 21:55:39 --> Config Class Initialized
INFO - 2018-06-25 21:55:39 --> Hooks Class Initialized
DEBUG - 2018-06-25 21:55:39 --> UTF-8 Support Enabled
INFO - 2018-06-25 21:55:39 --> Utf8 Class Initialized
INFO - 2018-06-25 21:55:39 --> URI Class Initialized
INFO - 2018-06-25 21:55:39 --> Router Class Initialized
INFO - 2018-06-25 21:55:39 --> Output Class Initialized
INFO - 2018-06-25 21:55:39 --> Security Class Initialized
DEBUG - 2018-06-25 21:55:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 21:55:40 --> Input Class Initialized
INFO - 2018-06-25 21:55:40 --> Language Class Initialized
ERROR - 2018-06-25 21:55:40 --> 404 Page Not Found: /index
INFO - 2018-06-25 21:55:40 --> Config Class Initialized
INFO - 2018-06-25 21:55:40 --> Hooks Class Initialized
DEBUG - 2018-06-25 21:55:40 --> UTF-8 Support Enabled
INFO - 2018-06-25 21:55:40 --> Utf8 Class Initialized
INFO - 2018-06-25 21:55:40 --> URI Class Initialized
INFO - 2018-06-25 21:55:40 --> Router Class Initialized
INFO - 2018-06-25 21:55:40 --> Output Class Initialized
INFO - 2018-06-25 21:55:40 --> Security Class Initialized
DEBUG - 2018-06-25 21:55:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 21:55:40 --> Input Class Initialized
INFO - 2018-06-25 21:55:40 --> Language Class Initialized
ERROR - 2018-06-25 21:55:40 --> 404 Page Not Found: /index
INFO - 2018-06-25 21:55:50 --> Config Class Initialized
INFO - 2018-06-25 21:55:50 --> Hooks Class Initialized
DEBUG - 2018-06-25 21:55:50 --> UTF-8 Support Enabled
INFO - 2018-06-25 21:55:50 --> Utf8 Class Initialized
INFO - 2018-06-25 21:55:50 --> URI Class Initialized
DEBUG - 2018-06-25 21:55:50 --> No URI present. Default controller set.
INFO - 2018-06-25 21:55:50 --> Router Class Initialized
INFO - 2018-06-25 21:55:50 --> Output Class Initialized
INFO - 2018-06-25 21:55:50 --> Security Class Initialized
DEBUG - 2018-06-25 21:55:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 21:55:50 --> Input Class Initialized
INFO - 2018-06-25 21:55:50 --> Language Class Initialized
INFO - 2018-06-25 21:55:50 --> Language Class Initialized
INFO - 2018-06-25 21:55:50 --> Config Class Initialized
INFO - 2018-06-25 21:55:50 --> Loader Class Initialized
DEBUG - 2018-06-25 21:55:50 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-25 21:55:50 --> Helper loaded: url_helper
INFO - 2018-06-25 21:55:50 --> Helper loaded: form_helper
INFO - 2018-06-25 21:55:50 --> Helper loaded: date_helper
INFO - 2018-06-25 21:55:50 --> Helper loaded: util_helper
INFO - 2018-06-25 21:55:50 --> Helper loaded: text_helper
INFO - 2018-06-25 21:55:50 --> Helper loaded: string_helper
INFO - 2018-06-25 21:55:50 --> Database Driver Class Initialized
DEBUG - 2018-06-25 21:55:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-25 21:55:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-25 21:55:50 --> Email Class Initialized
INFO - 2018-06-25 21:55:50 --> Controller Class Initialized
DEBUG - 2018-06-25 21:55:50 --> Home MX_Controller Initialized
DEBUG - 2018-06-25 21:55:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-25 21:55:50 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-25 21:55:50 --> Login MX_Controller Initialized
INFO - 2018-06-25 21:55:50 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-25 21:55:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-25 21:55:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-25 21:55:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-25 21:55:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-25 21:55:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-25 21:55:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-25 21:55:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-25 21:55:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-06-25 21:55:50 --> Final output sent to browser
DEBUG - 2018-06-25 21:55:50 --> Total execution time: 0.5327
INFO - 2018-06-25 21:55:51 --> Config Class Initialized
INFO - 2018-06-25 21:55:51 --> Hooks Class Initialized
DEBUG - 2018-06-25 21:55:51 --> UTF-8 Support Enabled
INFO - 2018-06-25 21:55:51 --> Utf8 Class Initialized
INFO - 2018-06-25 21:55:51 --> URI Class Initialized
INFO - 2018-06-25 21:55:51 --> Router Class Initialized
INFO - 2018-06-25 21:55:51 --> Output Class Initialized
INFO - 2018-06-25 21:55:51 --> Security Class Initialized
DEBUG - 2018-06-25 21:55:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 21:55:51 --> Input Class Initialized
INFO - 2018-06-25 21:55:51 --> Language Class Initialized
ERROR - 2018-06-25 21:55:51 --> 404 Page Not Found: /index
INFO - 2018-06-25 21:55:51 --> Config Class Initialized
INFO - 2018-06-25 21:55:51 --> Hooks Class Initialized
DEBUG - 2018-06-25 21:55:51 --> UTF-8 Support Enabled
INFO - 2018-06-25 21:55:51 --> Utf8 Class Initialized
INFO - 2018-06-25 21:55:51 --> URI Class Initialized
INFO - 2018-06-25 21:55:51 --> Router Class Initialized
INFO - 2018-06-25 21:55:51 --> Output Class Initialized
INFO - 2018-06-25 21:55:51 --> Security Class Initialized
DEBUG - 2018-06-25 21:55:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 21:55:51 --> Input Class Initialized
INFO - 2018-06-25 21:55:51 --> Language Class Initialized
ERROR - 2018-06-25 21:55:51 --> 404 Page Not Found: /index
INFO - 2018-06-25 21:55:51 --> Config Class Initialized
INFO - 2018-06-25 21:55:51 --> Hooks Class Initialized
DEBUG - 2018-06-25 21:55:51 --> UTF-8 Support Enabled
INFO - 2018-06-25 21:55:51 --> Utf8 Class Initialized
INFO - 2018-06-25 21:55:51 --> URI Class Initialized
INFO - 2018-06-25 21:55:51 --> Router Class Initialized
INFO - 2018-06-25 21:55:51 --> Output Class Initialized
INFO - 2018-06-25 21:55:51 --> Security Class Initialized
DEBUG - 2018-06-25 21:55:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 21:55:51 --> Input Class Initialized
INFO - 2018-06-25 21:55:51 --> Language Class Initialized
ERROR - 2018-06-25 21:55:51 --> 404 Page Not Found: /index
INFO - 2018-06-25 21:55:53 --> Config Class Initialized
INFO - 2018-06-25 21:55:54 --> Hooks Class Initialized
DEBUG - 2018-06-25 21:55:54 --> UTF-8 Support Enabled
INFO - 2018-06-25 21:55:54 --> Utf8 Class Initialized
INFO - 2018-06-25 21:55:54 --> URI Class Initialized
INFO - 2018-06-25 21:55:54 --> Router Class Initialized
INFO - 2018-06-25 21:55:54 --> Output Class Initialized
INFO - 2018-06-25 21:55:54 --> Security Class Initialized
DEBUG - 2018-06-25 21:55:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 21:55:54 --> Input Class Initialized
INFO - 2018-06-25 21:55:54 --> Language Class Initialized
INFO - 2018-06-25 21:55:54 --> Language Class Initialized
INFO - 2018-06-25 21:55:54 --> Config Class Initialized
INFO - 2018-06-25 21:55:54 --> Loader Class Initialized
DEBUG - 2018-06-25 21:55:54 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-25 21:55:54 --> Helper loaded: url_helper
INFO - 2018-06-25 21:55:54 --> Helper loaded: form_helper
INFO - 2018-06-25 21:55:54 --> Helper loaded: date_helper
INFO - 2018-06-25 21:55:54 --> Helper loaded: util_helper
INFO - 2018-06-25 21:55:54 --> Helper loaded: text_helper
INFO - 2018-06-25 21:55:54 --> Helper loaded: string_helper
INFO - 2018-06-25 21:55:54 --> Database Driver Class Initialized
DEBUG - 2018-06-25 21:55:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-25 21:55:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-25 21:55:54 --> Email Class Initialized
INFO - 2018-06-25 21:55:54 --> Controller Class Initialized
DEBUG - 2018-06-25 21:55:54 --> Home MX_Controller Initialized
DEBUG - 2018-06-25 21:55:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-25 21:55:54 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-25 21:55:54 --> Login MX_Controller Initialized
INFO - 2018-06-25 21:55:54 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-25 21:55:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-25 21:55:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-25 21:55:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-25 21:55:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-25 21:55:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-25 21:55:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-25 21:55:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-25 21:55:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-06-25 21:55:54 --> Final output sent to browser
DEBUG - 2018-06-25 21:55:54 --> Total execution time: 0.4808
INFO - 2018-06-25 21:55:54 --> Config Class Initialized
INFO - 2018-06-25 21:55:54 --> Hooks Class Initialized
INFO - 2018-06-25 21:55:54 --> Config Class Initialized
DEBUG - 2018-06-25 21:55:54 --> UTF-8 Support Enabled
INFO - 2018-06-25 21:55:54 --> Hooks Class Initialized
INFO - 2018-06-25 21:55:54 --> Utf8 Class Initialized
INFO - 2018-06-25 21:55:54 --> URI Class Initialized
DEBUG - 2018-06-25 21:55:54 --> UTF-8 Support Enabled
INFO - 2018-06-25 21:55:54 --> Utf8 Class Initialized
INFO - 2018-06-25 21:55:54 --> Router Class Initialized
INFO - 2018-06-25 21:55:54 --> URI Class Initialized
INFO - 2018-06-25 21:55:54 --> Output Class Initialized
INFO - 2018-06-25 21:55:54 --> Router Class Initialized
INFO - 2018-06-25 21:55:54 --> Output Class Initialized
INFO - 2018-06-25 21:55:54 --> Security Class Initialized
INFO - 2018-06-25 21:55:54 --> Security Class Initialized
DEBUG - 2018-06-25 21:55:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-06-25 21:55:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 21:55:54 --> Input Class Initialized
INFO - 2018-06-25 21:55:54 --> Input Class Initialized
INFO - 2018-06-25 21:55:54 --> Language Class Initialized
ERROR - 2018-06-25 21:55:54 --> 404 Page Not Found: /index
INFO - 2018-06-25 21:55:54 --> Language Class Initialized
ERROR - 2018-06-25 21:55:54 --> 404 Page Not Found: /index
INFO - 2018-06-25 21:55:54 --> Config Class Initialized
INFO - 2018-06-25 21:55:54 --> Hooks Class Initialized
DEBUG - 2018-06-25 21:55:55 --> UTF-8 Support Enabled
INFO - 2018-06-25 21:55:55 --> Utf8 Class Initialized
INFO - 2018-06-25 21:55:55 --> URI Class Initialized
INFO - 2018-06-25 21:55:55 --> Router Class Initialized
INFO - 2018-06-25 21:55:55 --> Output Class Initialized
INFO - 2018-06-25 21:55:55 --> Security Class Initialized
DEBUG - 2018-06-25 21:55:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 21:55:55 --> Input Class Initialized
INFO - 2018-06-25 21:55:55 --> Language Class Initialized
ERROR - 2018-06-25 21:55:55 --> 404 Page Not Found: /index
INFO - 2018-06-25 21:55:55 --> Config Class Initialized
INFO - 2018-06-25 21:55:55 --> Hooks Class Initialized
DEBUG - 2018-06-25 21:55:55 --> UTF-8 Support Enabled
INFO - 2018-06-25 21:55:55 --> Utf8 Class Initialized
INFO - 2018-06-25 21:55:55 --> URI Class Initialized
INFO - 2018-06-25 21:55:55 --> Router Class Initialized
INFO - 2018-06-25 21:55:55 --> Output Class Initialized
INFO - 2018-06-25 21:55:55 --> Security Class Initialized
DEBUG - 2018-06-25 21:55:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 21:55:55 --> Input Class Initialized
INFO - 2018-06-25 21:55:55 --> Language Class Initialized
ERROR - 2018-06-25 21:55:55 --> 404 Page Not Found: /index
INFO - 2018-06-25 21:56:11 --> Config Class Initialized
INFO - 2018-06-25 21:56:11 --> Hooks Class Initialized
DEBUG - 2018-06-25 21:56:11 --> UTF-8 Support Enabled
INFO - 2018-06-25 21:56:12 --> Utf8 Class Initialized
INFO - 2018-06-25 21:56:12 --> URI Class Initialized
INFO - 2018-06-25 21:56:12 --> Router Class Initialized
INFO - 2018-06-25 21:56:12 --> Output Class Initialized
INFO - 2018-06-25 21:56:12 --> Security Class Initialized
DEBUG - 2018-06-25 21:56:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 21:56:12 --> Input Class Initialized
INFO - 2018-06-25 21:56:12 --> Language Class Initialized
INFO - 2018-06-25 21:56:12 --> Language Class Initialized
INFO - 2018-06-25 21:56:12 --> Config Class Initialized
INFO - 2018-06-25 21:56:12 --> Loader Class Initialized
DEBUG - 2018-06-25 21:56:12 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-25 21:56:12 --> Helper loaded: url_helper
INFO - 2018-06-25 21:56:12 --> Helper loaded: form_helper
INFO - 2018-06-25 21:56:12 --> Helper loaded: date_helper
INFO - 2018-06-25 21:56:12 --> Helper loaded: util_helper
INFO - 2018-06-25 21:56:12 --> Helper loaded: text_helper
INFO - 2018-06-25 21:56:12 --> Helper loaded: string_helper
INFO - 2018-06-25 21:56:12 --> Database Driver Class Initialized
DEBUG - 2018-06-25 21:56:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-25 21:56:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-25 21:56:12 --> Email Class Initialized
INFO - 2018-06-25 21:56:12 --> Controller Class Initialized
DEBUG - 2018-06-25 21:56:12 --> Home MX_Controller Initialized
DEBUG - 2018-06-25 21:56:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-25 21:56:12 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-25 21:56:12 --> Login MX_Controller Initialized
INFO - 2018-06-25 21:56:12 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-25 21:56:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-25 21:56:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-25 21:56:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-25 21:56:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-25 21:56:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-25 21:56:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-25 21:56:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-25 21:56:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-06-25 21:56:12 --> Final output sent to browser
DEBUG - 2018-06-25 21:56:12 --> Total execution time: 0.4173
INFO - 2018-06-25 21:56:12 --> Config Class Initialized
INFO - 2018-06-25 21:56:12 --> Config Class Initialized
INFO - 2018-06-25 21:56:12 --> Hooks Class Initialized
INFO - 2018-06-25 21:56:12 --> Hooks Class Initialized
DEBUG - 2018-06-25 21:56:12 --> UTF-8 Support Enabled
DEBUG - 2018-06-25 21:56:12 --> UTF-8 Support Enabled
INFO - 2018-06-25 21:56:12 --> Utf8 Class Initialized
INFO - 2018-06-25 21:56:12 --> Utf8 Class Initialized
INFO - 2018-06-25 21:56:12 --> URI Class Initialized
INFO - 2018-06-25 21:56:12 --> URI Class Initialized
INFO - 2018-06-25 21:56:12 --> Router Class Initialized
INFO - 2018-06-25 21:56:12 --> Router Class Initialized
INFO - 2018-06-25 21:56:12 --> Output Class Initialized
INFO - 2018-06-25 21:56:12 --> Output Class Initialized
INFO - 2018-06-25 21:56:12 --> Security Class Initialized
INFO - 2018-06-25 21:56:12 --> Security Class Initialized
DEBUG - 2018-06-25 21:56:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-06-25 21:56:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 21:56:12 --> Input Class Initialized
INFO - 2018-06-25 21:56:12 --> Input Class Initialized
INFO - 2018-06-25 21:56:12 --> Language Class Initialized
ERROR - 2018-06-25 21:56:12 --> 404 Page Not Found: /index
INFO - 2018-06-25 21:56:12 --> Language Class Initialized
ERROR - 2018-06-25 21:56:12 --> 404 Page Not Found: /index
INFO - 2018-06-25 21:56:12 --> Config Class Initialized
INFO - 2018-06-25 21:56:12 --> Hooks Class Initialized
DEBUG - 2018-06-25 21:56:12 --> UTF-8 Support Enabled
INFO - 2018-06-25 21:56:12 --> Utf8 Class Initialized
INFO - 2018-06-25 21:56:12 --> URI Class Initialized
INFO - 2018-06-25 21:56:12 --> Router Class Initialized
INFO - 2018-06-25 21:56:13 --> Output Class Initialized
INFO - 2018-06-25 21:56:13 --> Security Class Initialized
DEBUG - 2018-06-25 21:56:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 21:56:13 --> Input Class Initialized
INFO - 2018-06-25 21:56:13 --> Language Class Initialized
ERROR - 2018-06-25 21:56:13 --> 404 Page Not Found: /index
INFO - 2018-06-25 21:56:13 --> Config Class Initialized
INFO - 2018-06-25 21:56:13 --> Hooks Class Initialized
DEBUG - 2018-06-25 21:56:13 --> UTF-8 Support Enabled
INFO - 2018-06-25 21:56:13 --> Utf8 Class Initialized
INFO - 2018-06-25 21:56:13 --> URI Class Initialized
INFO - 2018-06-25 21:56:13 --> Router Class Initialized
INFO - 2018-06-25 21:56:13 --> Output Class Initialized
INFO - 2018-06-25 21:56:13 --> Security Class Initialized
DEBUG - 2018-06-25 21:56:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 21:56:13 --> Input Class Initialized
INFO - 2018-06-25 21:56:13 --> Language Class Initialized
ERROR - 2018-06-25 21:56:13 --> 404 Page Not Found: /index
INFO - 2018-06-25 21:56:17 --> Config Class Initialized
INFO - 2018-06-25 21:56:17 --> Hooks Class Initialized
DEBUG - 2018-06-25 21:56:17 --> UTF-8 Support Enabled
INFO - 2018-06-25 21:56:17 --> Utf8 Class Initialized
INFO - 2018-06-25 21:56:17 --> URI Class Initialized
INFO - 2018-06-25 21:56:17 --> Router Class Initialized
INFO - 2018-06-25 21:56:17 --> Output Class Initialized
INFO - 2018-06-25 21:56:17 --> Security Class Initialized
DEBUG - 2018-06-25 21:56:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 21:56:17 --> Input Class Initialized
INFO - 2018-06-25 21:56:17 --> Language Class Initialized
INFO - 2018-06-25 21:56:17 --> Language Class Initialized
INFO - 2018-06-25 21:56:17 --> Config Class Initialized
INFO - 2018-06-25 21:56:17 --> Loader Class Initialized
DEBUG - 2018-06-25 21:56:17 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-25 21:56:17 --> Helper loaded: url_helper
INFO - 2018-06-25 21:56:17 --> Helper loaded: form_helper
INFO - 2018-06-25 21:56:17 --> Helper loaded: date_helper
INFO - 2018-06-25 21:56:18 --> Helper loaded: util_helper
INFO - 2018-06-25 21:56:18 --> Helper loaded: text_helper
INFO - 2018-06-25 21:56:18 --> Helper loaded: string_helper
INFO - 2018-06-25 21:56:18 --> Database Driver Class Initialized
DEBUG - 2018-06-25 21:56:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-25 21:56:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-25 21:56:18 --> Email Class Initialized
INFO - 2018-06-25 21:56:18 --> Controller Class Initialized
DEBUG - 2018-06-25 21:56:18 --> Home MX_Controller Initialized
DEBUG - 2018-06-25 21:56:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-25 21:56:18 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-25 21:56:18 --> Login MX_Controller Initialized
INFO - 2018-06-25 21:56:18 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-25 21:56:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-25 21:56:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-25 21:56:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-25 21:56:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-25 21:56:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-25 21:56:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-25 21:56:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-25 21:56:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-06-25 21:56:18 --> Final output sent to browser
DEBUG - 2018-06-25 21:56:18 --> Total execution time: 0.4357
INFO - 2018-06-25 21:56:18 --> Config Class Initialized
INFO - 2018-06-25 21:56:18 --> Config Class Initialized
INFO - 2018-06-25 21:56:18 --> Hooks Class Initialized
INFO - 2018-06-25 21:56:18 --> Hooks Class Initialized
DEBUG - 2018-06-25 21:56:18 --> UTF-8 Support Enabled
DEBUG - 2018-06-25 21:56:18 --> UTF-8 Support Enabled
INFO - 2018-06-25 21:56:18 --> Utf8 Class Initialized
INFO - 2018-06-25 21:56:18 --> Utf8 Class Initialized
INFO - 2018-06-25 21:56:18 --> URI Class Initialized
INFO - 2018-06-25 21:56:18 --> URI Class Initialized
INFO - 2018-06-25 21:56:18 --> Router Class Initialized
INFO - 2018-06-25 21:56:18 --> Output Class Initialized
INFO - 2018-06-25 21:56:18 --> Router Class Initialized
INFO - 2018-06-25 21:56:18 --> Security Class Initialized
DEBUG - 2018-06-25 21:56:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 21:56:18 --> Input Class Initialized
INFO - 2018-06-25 21:56:18 --> Language Class Initialized
ERROR - 2018-06-25 21:56:18 --> 404 Page Not Found: /index
INFO - 2018-06-25 21:56:18 --> Output Class Initialized
INFO - 2018-06-25 21:56:18 --> Security Class Initialized
DEBUG - 2018-06-25 21:56:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 21:56:18 --> Input Class Initialized
INFO - 2018-06-25 21:56:18 --> Language Class Initialized
ERROR - 2018-06-25 21:56:18 --> 404 Page Not Found: /index
INFO - 2018-06-25 21:56:18 --> Config Class Initialized
INFO - 2018-06-25 21:56:18 --> Hooks Class Initialized
DEBUG - 2018-06-25 21:56:18 --> UTF-8 Support Enabled
INFO - 2018-06-25 21:56:18 --> Utf8 Class Initialized
INFO - 2018-06-25 21:56:18 --> URI Class Initialized
INFO - 2018-06-25 21:56:18 --> Router Class Initialized
INFO - 2018-06-25 21:56:18 --> Output Class Initialized
INFO - 2018-06-25 21:56:18 --> Security Class Initialized
DEBUG - 2018-06-25 21:56:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 21:56:19 --> Input Class Initialized
INFO - 2018-06-25 21:56:19 --> Language Class Initialized
ERROR - 2018-06-25 21:56:19 --> 404 Page Not Found: /index
INFO - 2018-06-25 21:56:19 --> Config Class Initialized
INFO - 2018-06-25 21:56:19 --> Hooks Class Initialized
DEBUG - 2018-06-25 21:56:19 --> UTF-8 Support Enabled
INFO - 2018-06-25 21:56:19 --> Utf8 Class Initialized
INFO - 2018-06-25 21:56:19 --> URI Class Initialized
INFO - 2018-06-25 21:56:19 --> Router Class Initialized
INFO - 2018-06-25 21:56:19 --> Output Class Initialized
INFO - 2018-06-25 21:56:19 --> Security Class Initialized
DEBUG - 2018-06-25 21:56:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 21:56:19 --> Input Class Initialized
INFO - 2018-06-25 21:56:19 --> Language Class Initialized
ERROR - 2018-06-25 21:56:19 --> 404 Page Not Found: /index
INFO - 2018-06-25 21:56:22 --> Config Class Initialized
INFO - 2018-06-25 21:56:22 --> Hooks Class Initialized
DEBUG - 2018-06-25 21:56:22 --> UTF-8 Support Enabled
INFO - 2018-06-25 21:56:22 --> Utf8 Class Initialized
INFO - 2018-06-25 21:56:22 --> URI Class Initialized
INFO - 2018-06-25 21:56:22 --> Router Class Initialized
INFO - 2018-06-25 21:56:22 --> Output Class Initialized
INFO - 2018-06-25 21:56:22 --> Security Class Initialized
DEBUG - 2018-06-25 21:56:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 21:56:22 --> Input Class Initialized
INFO - 2018-06-25 21:56:22 --> Language Class Initialized
INFO - 2018-06-25 21:56:22 --> Language Class Initialized
INFO - 2018-06-25 21:56:22 --> Config Class Initialized
INFO - 2018-06-25 21:56:22 --> Loader Class Initialized
DEBUG - 2018-06-25 21:56:22 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-25 21:56:22 --> Helper loaded: url_helper
INFO - 2018-06-25 21:56:22 --> Helper loaded: form_helper
INFO - 2018-06-25 21:56:22 --> Helper loaded: date_helper
INFO - 2018-06-25 21:56:22 --> Helper loaded: util_helper
INFO - 2018-06-25 21:56:22 --> Helper loaded: text_helper
INFO - 2018-06-25 21:56:22 --> Helper loaded: string_helper
INFO - 2018-06-25 21:56:22 --> Database Driver Class Initialized
DEBUG - 2018-06-25 21:56:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-25 21:56:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-25 21:56:22 --> Email Class Initialized
INFO - 2018-06-25 21:56:22 --> Controller Class Initialized
DEBUG - 2018-06-25 21:56:22 --> Home MX_Controller Initialized
DEBUG - 2018-06-25 21:56:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-25 21:56:22 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-25 21:56:22 --> Login MX_Controller Initialized
INFO - 2018-06-25 21:56:22 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-25 21:56:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-25 21:56:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-25 21:56:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-25 21:56:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-25 21:56:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-25 21:56:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-25 21:56:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-25 21:56:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-06-25 21:56:22 --> Final output sent to browser
DEBUG - 2018-06-25 21:56:22 --> Total execution time: 0.4449
INFO - 2018-06-25 21:56:23 --> Config Class Initialized
INFO - 2018-06-25 21:56:23 --> Config Class Initialized
INFO - 2018-06-25 21:56:23 --> Hooks Class Initialized
INFO - 2018-06-25 21:56:23 --> Hooks Class Initialized
DEBUG - 2018-06-25 21:56:23 --> UTF-8 Support Enabled
DEBUG - 2018-06-25 21:56:23 --> UTF-8 Support Enabled
INFO - 2018-06-25 21:56:23 --> Utf8 Class Initialized
INFO - 2018-06-25 21:56:23 --> Utf8 Class Initialized
INFO - 2018-06-25 21:56:23 --> URI Class Initialized
INFO - 2018-06-25 21:56:23 --> URI Class Initialized
INFO - 2018-06-25 21:56:23 --> Router Class Initialized
INFO - 2018-06-25 21:56:23 --> Router Class Initialized
INFO - 2018-06-25 21:56:23 --> Output Class Initialized
INFO - 2018-06-25 21:56:23 --> Output Class Initialized
INFO - 2018-06-25 21:56:23 --> Security Class Initialized
INFO - 2018-06-25 21:56:23 --> Security Class Initialized
DEBUG - 2018-06-25 21:56:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-06-25 21:56:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 21:56:23 --> Input Class Initialized
INFO - 2018-06-25 21:56:23 --> Input Class Initialized
INFO - 2018-06-25 21:56:23 --> Language Class Initialized
INFO - 2018-06-25 21:56:23 --> Language Class Initialized
ERROR - 2018-06-25 21:56:23 --> 404 Page Not Found: /index
ERROR - 2018-06-25 21:56:23 --> 404 Page Not Found: /index
INFO - 2018-06-25 21:56:23 --> Config Class Initialized
INFO - 2018-06-25 21:56:23 --> Hooks Class Initialized
DEBUG - 2018-06-25 21:56:23 --> UTF-8 Support Enabled
INFO - 2018-06-25 21:56:23 --> Utf8 Class Initialized
INFO - 2018-06-25 21:56:23 --> URI Class Initialized
INFO - 2018-06-25 21:56:23 --> Router Class Initialized
INFO - 2018-06-25 21:56:23 --> Output Class Initialized
INFO - 2018-06-25 21:56:23 --> Security Class Initialized
DEBUG - 2018-06-25 21:56:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 21:56:23 --> Input Class Initialized
INFO - 2018-06-25 21:56:23 --> Language Class Initialized
ERROR - 2018-06-25 21:56:23 --> 404 Page Not Found: /index
INFO - 2018-06-25 21:56:23 --> Config Class Initialized
INFO - 2018-06-25 21:56:23 --> Hooks Class Initialized
DEBUG - 2018-06-25 21:56:23 --> UTF-8 Support Enabled
INFO - 2018-06-25 21:56:23 --> Utf8 Class Initialized
INFO - 2018-06-25 21:56:23 --> URI Class Initialized
INFO - 2018-06-25 21:56:23 --> Router Class Initialized
INFO - 2018-06-25 21:56:23 --> Output Class Initialized
INFO - 2018-06-25 21:56:23 --> Security Class Initialized
DEBUG - 2018-06-25 21:56:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 21:56:23 --> Input Class Initialized
INFO - 2018-06-25 21:56:23 --> Language Class Initialized
ERROR - 2018-06-25 21:56:23 --> 404 Page Not Found: /index
INFO - 2018-06-25 22:10:44 --> Config Class Initialized
INFO - 2018-06-25 22:10:44 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:10:44 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:10:44 --> Utf8 Class Initialized
INFO - 2018-06-25 22:10:44 --> URI Class Initialized
INFO - 2018-06-25 22:10:44 --> Router Class Initialized
INFO - 2018-06-25 22:10:44 --> Output Class Initialized
INFO - 2018-06-25 22:10:44 --> Security Class Initialized
DEBUG - 2018-06-25 22:10:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:10:44 --> Input Class Initialized
INFO - 2018-06-25 22:10:44 --> Language Class Initialized
INFO - 2018-06-25 22:10:44 --> Language Class Initialized
INFO - 2018-06-25 22:10:44 --> Config Class Initialized
INFO - 2018-06-25 22:10:44 --> Loader Class Initialized
DEBUG - 2018-06-25 22:10:44 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-25 22:10:44 --> Helper loaded: url_helper
INFO - 2018-06-25 22:10:44 --> Helper loaded: form_helper
INFO - 2018-06-25 22:10:44 --> Helper loaded: date_helper
INFO - 2018-06-25 22:10:44 --> Helper loaded: util_helper
INFO - 2018-06-25 22:10:44 --> Helper loaded: text_helper
INFO - 2018-06-25 22:10:44 --> Helper loaded: string_helper
INFO - 2018-06-25 22:10:44 --> Database Driver Class Initialized
DEBUG - 2018-06-25 22:10:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-25 22:10:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-25 22:10:44 --> Email Class Initialized
INFO - 2018-06-25 22:10:44 --> Controller Class Initialized
DEBUG - 2018-06-25 22:10:44 --> Home MX_Controller Initialized
DEBUG - 2018-06-25 22:10:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-25 22:10:44 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-25 22:10:44 --> Login MX_Controller Initialized
INFO - 2018-06-25 22:10:44 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-25 22:10:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-25 22:10:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-25 22:10:45 --> Config Class Initialized
INFO - 2018-06-25 22:10:45 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:10:45 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:10:45 --> Utf8 Class Initialized
INFO - 2018-06-25 22:10:45 --> URI Class Initialized
DEBUG - 2018-06-25 22:10:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-25 22:10:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
INFO - 2018-06-25 22:10:45 --> Router Class Initialized
DEBUG - 2018-06-25 22:10:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
INFO - 2018-06-25 22:10:45 --> Output Class Initialized
DEBUG - 2018-06-25 22:10:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
INFO - 2018-06-25 22:10:45 --> Security Class Initialized
DEBUG - 2018-06-25 22:10:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-25 22:10:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:10:45 --> Input Class Initialized
DEBUG - 2018-06-25 22:10:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-06-25 22:10:45 --> Language Class Initialized
INFO - 2018-06-25 22:10:45 --> Final output sent to browser
DEBUG - 2018-06-25 22:10:45 --> Total execution time: 0.6129
INFO - 2018-06-25 22:10:45 --> Language Class Initialized
INFO - 2018-06-25 22:10:45 --> Config Class Initialized
INFO - 2018-06-25 22:10:45 --> Loader Class Initialized
DEBUG - 2018-06-25 22:10:45 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-25 22:10:45 --> Helper loaded: url_helper
INFO - 2018-06-25 22:10:45 --> Helper loaded: form_helper
INFO - 2018-06-25 22:10:45 --> Helper loaded: date_helper
INFO - 2018-06-25 22:10:45 --> Helper loaded: util_helper
INFO - 2018-06-25 22:10:45 --> Helper loaded: text_helper
INFO - 2018-06-25 22:10:45 --> Helper loaded: string_helper
INFO - 2018-06-25 22:10:45 --> Database Driver Class Initialized
DEBUG - 2018-06-25 22:10:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-25 22:10:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-25 22:10:45 --> Email Class Initialized
INFO - 2018-06-25 22:10:45 --> Controller Class Initialized
DEBUG - 2018-06-25 22:10:45 --> Home MX_Controller Initialized
DEBUG - 2018-06-25 22:10:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-25 22:10:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-25 22:10:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-25 22:10:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-25 22:10:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-25 22:10:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-25 22:10:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/search_page.php
INFO - 2018-06-25 22:10:45 --> Final output sent to browser
DEBUG - 2018-06-25 22:10:45 --> Total execution time: 0.4726
INFO - 2018-06-25 22:10:45 --> Config Class Initialized
INFO - 2018-06-25 22:10:45 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:10:45 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:10:45 --> Utf8 Class Initialized
INFO - 2018-06-25 22:10:45 --> URI Class Initialized
INFO - 2018-06-25 22:10:45 --> Router Class Initialized
INFO - 2018-06-25 22:10:45 --> Output Class Initialized
INFO - 2018-06-25 22:10:45 --> Security Class Initialized
DEBUG - 2018-06-25 22:10:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:10:45 --> Input Class Initialized
INFO - 2018-06-25 22:10:45 --> Language Class Initialized
INFO - 2018-06-25 22:10:45 --> Language Class Initialized
INFO - 2018-06-25 22:10:45 --> Config Class Initialized
INFO - 2018-06-25 22:10:45 --> Loader Class Initialized
DEBUG - 2018-06-25 22:10:45 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-25 22:10:45 --> Helper loaded: url_helper
INFO - 2018-06-25 22:10:45 --> Helper loaded: form_helper
INFO - 2018-06-25 22:10:45 --> Helper loaded: date_helper
INFO - 2018-06-25 22:10:45 --> Helper loaded: util_helper
INFO - 2018-06-25 22:10:46 --> Helper loaded: text_helper
INFO - 2018-06-25 22:10:46 --> Helper loaded: string_helper
INFO - 2018-06-25 22:10:46 --> Database Driver Class Initialized
DEBUG - 2018-06-25 22:10:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-25 22:10:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-25 22:10:46 --> Email Class Initialized
INFO - 2018-06-25 22:10:46 --> Controller Class Initialized
DEBUG - 2018-06-25 22:10:46 --> Home MX_Controller Initialized
DEBUG - 2018-06-25 22:10:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-25 22:10:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-25 22:10:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-25 22:10:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-25 22:10:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-25 22:10:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-25 22:10:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/search_page.php
INFO - 2018-06-25 22:10:46 --> Final output sent to browser
DEBUG - 2018-06-25 22:10:46 --> Total execution time: 0.4287
INFO - 2018-06-25 22:10:46 --> Config Class Initialized
INFO - 2018-06-25 22:10:46 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:10:46 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:10:46 --> Utf8 Class Initialized
INFO - 2018-06-25 22:10:46 --> URI Class Initialized
INFO - 2018-06-25 22:10:46 --> Router Class Initialized
INFO - 2018-06-25 22:10:46 --> Output Class Initialized
INFO - 2018-06-25 22:10:46 --> Security Class Initialized
INFO - 2018-06-25 22:10:46 --> Config Class Initialized
INFO - 2018-06-25 22:10:46 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:10:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:10:46 --> Input Class Initialized
DEBUG - 2018-06-25 22:10:46 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:10:46 --> Utf8 Class Initialized
INFO - 2018-06-25 22:10:46 --> Language Class Initialized
INFO - 2018-06-25 22:10:46 --> URI Class Initialized
INFO - 2018-06-25 22:10:46 --> Router Class Initialized
ERROR - 2018-06-25 22:10:46 --> 404 Page Not Found: /index
INFO - 2018-06-25 22:10:46 --> Output Class Initialized
INFO - 2018-06-25 22:10:46 --> Config Class Initialized
INFO - 2018-06-25 22:10:46 --> Security Class Initialized
INFO - 2018-06-25 22:10:46 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:10:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-06-25 22:10:46 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:10:46 --> Input Class Initialized
INFO - 2018-06-25 22:10:46 --> Utf8 Class Initialized
INFO - 2018-06-25 22:10:46 --> Language Class Initialized
INFO - 2018-06-25 22:10:46 --> URI Class Initialized
INFO - 2018-06-25 22:10:46 --> Language Class Initialized
INFO - 2018-06-25 22:10:46 --> Router Class Initialized
INFO - 2018-06-25 22:10:46 --> Config Class Initialized
INFO - 2018-06-25 22:10:46 --> Output Class Initialized
INFO - 2018-06-25 22:10:46 --> Config Class Initialized
INFO - 2018-06-25 22:10:46 --> Hooks Class Initialized
INFO - 2018-06-25 22:10:46 --> Loader Class Initialized
DEBUG - 2018-06-25 22:10:46 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
DEBUG - 2018-06-25 22:10:46 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:10:46 --> Utf8 Class Initialized
INFO - 2018-06-25 22:10:46 --> Helper loaded: url_helper
INFO - 2018-06-25 22:10:46 --> Security Class Initialized
INFO - 2018-06-25 22:10:46 --> URI Class Initialized
INFO - 2018-06-25 22:10:46 --> Helper loaded: form_helper
DEBUG - 2018-06-25 22:10:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:10:46 --> Router Class Initialized
INFO - 2018-06-25 22:10:46 --> Input Class Initialized
INFO - 2018-06-25 22:10:46 --> Helper loaded: date_helper
INFO - 2018-06-25 22:10:46 --> Helper loaded: util_helper
INFO - 2018-06-25 22:10:46 --> Language Class Initialized
INFO - 2018-06-25 22:10:46 --> Output Class Initialized
INFO - 2018-06-25 22:10:46 --> Security Class Initialized
ERROR - 2018-06-25 22:10:46 --> 404 Page Not Found: /index
INFO - 2018-06-25 22:10:46 --> Helper loaded: text_helper
DEBUG - 2018-06-25 22:10:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:10:46 --> Helper loaded: string_helper
INFO - 2018-06-25 22:10:46 --> Config Class Initialized
INFO - 2018-06-25 22:10:46 --> Input Class Initialized
INFO - 2018-06-25 22:10:46 --> Hooks Class Initialized
INFO - 2018-06-25 22:10:46 --> Language Class Initialized
INFO - 2018-06-25 22:10:46 --> Database Driver Class Initialized
ERROR - 2018-06-25 22:10:46 --> 404 Page Not Found: /index
DEBUG - 2018-06-25 22:10:46 --> UTF-8 Support Enabled
DEBUG - 2018-06-25 22:10:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-25 22:10:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-25 22:10:46 --> Utf8 Class Initialized
INFO - 2018-06-25 22:10:46 --> URI Class Initialized
INFO - 2018-06-25 22:10:46 --> Email Class Initialized
INFO - 2018-06-25 22:10:47 --> Controller Class Initialized
INFO - 2018-06-25 22:10:47 --> Router Class Initialized
DEBUG - 2018-06-25 22:10:47 --> videos MX_Controller Initialized
INFO - 2018-06-25 22:10:47 --> Output Class Initialized
INFO - 2018-06-25 22:10:47 --> Language file loaded: language/english/data_lang.php
INFO - 2018-06-25 22:10:47 --> Security Class Initialized
DEBUG - 2018-06-25 22:10:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-06-25 22:10:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:10:47 --> Input Class Initialized
DEBUG - 2018-06-25 22:10:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-25 22:10:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
INFO - 2018-06-25 22:10:47 --> Language Class Initialized
DEBUG - 2018-06-25 22:10:47 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
ERROR - 2018-06-25 22:10:47 --> 404 Page Not Found: /index
DEBUG - 2018-06-25 22:10:47 --> Login MX_Controller Initialized
DEBUG - 2018-06-25 22:10:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-25 22:10:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-25 22:10:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-25 22:10:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-25 22:10:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-25 22:10:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-25 22:10:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/videos/videos.php
INFO - 2018-06-25 22:10:47 --> Final output sent to browser
DEBUG - 2018-06-25 22:10:47 --> Total execution time: 0.5918
INFO - 2018-06-25 22:10:47 --> Config Class Initialized
INFO - 2018-06-25 22:10:47 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:10:47 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:10:47 --> Utf8 Class Initialized
INFO - 2018-06-25 22:10:47 --> URI Class Initialized
INFO - 2018-06-25 22:10:47 --> Router Class Initialized
INFO - 2018-06-25 22:10:47 --> Output Class Initialized
INFO - 2018-06-25 22:10:47 --> Security Class Initialized
DEBUG - 2018-06-25 22:10:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:10:47 --> Input Class Initialized
INFO - 2018-06-25 22:10:47 --> Language Class Initialized
ERROR - 2018-06-25 22:10:47 --> 404 Page Not Found: /index
INFO - 2018-06-25 22:10:48 --> Config Class Initialized
INFO - 2018-06-25 22:10:48 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:10:48 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:10:48 --> Utf8 Class Initialized
INFO - 2018-06-25 22:10:48 --> URI Class Initialized
INFO - 2018-06-25 22:10:48 --> Router Class Initialized
INFO - 2018-06-25 22:10:48 --> Output Class Initialized
INFO - 2018-06-25 22:10:48 --> Security Class Initialized
DEBUG - 2018-06-25 22:10:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:10:48 --> Input Class Initialized
INFO - 2018-06-25 22:10:48 --> Language Class Initialized
INFO - 2018-06-25 22:10:48 --> Language Class Initialized
INFO - 2018-06-25 22:10:48 --> Config Class Initialized
INFO - 2018-06-25 22:10:48 --> Loader Class Initialized
DEBUG - 2018-06-25 22:10:48 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-25 22:10:48 --> Helper loaded: url_helper
INFO - 2018-06-25 22:10:48 --> Helper loaded: form_helper
INFO - 2018-06-25 22:10:48 --> Helper loaded: date_helper
INFO - 2018-06-25 22:10:48 --> Helper loaded: util_helper
INFO - 2018-06-25 22:10:48 --> Helper loaded: text_helper
INFO - 2018-06-25 22:10:48 --> Helper loaded: string_helper
INFO - 2018-06-25 22:10:48 --> Database Driver Class Initialized
DEBUG - 2018-06-25 22:10:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-25 22:10:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-25 22:10:48 --> Email Class Initialized
INFO - 2018-06-25 22:10:48 --> Controller Class Initialized
DEBUG - 2018-06-25 22:10:48 --> videos MX_Controller Initialized
INFO - 2018-06-25 22:10:48 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-25 22:10:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
INFO - 2018-06-25 22:10:48 --> Config Class Initialized
DEBUG - 2018-06-25 22:10:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-06-25 22:10:48 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:10:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-25 22:10:48 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-25 22:10:48 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:10:48 --> Utf8 Class Initialized
DEBUG - 2018-06-25 22:10:48 --> Login MX_Controller Initialized
INFO - 2018-06-25 22:10:48 --> URI Class Initialized
DEBUG - 2018-06-25 22:10:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-25 22:10:48 --> Router Class Initialized
INFO - 2018-06-25 22:10:48 --> Final output sent to browser
DEBUG - 2018-06-25 22:10:48 --> Total execution time: 0.5376
INFO - 2018-06-25 22:10:48 --> Output Class Initialized
INFO - 2018-06-25 22:10:48 --> Security Class Initialized
DEBUG - 2018-06-25 22:10:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:10:48 --> Input Class Initialized
INFO - 2018-06-25 22:10:48 --> Language Class Initialized
ERROR - 2018-06-25 22:10:48 --> 404 Page Not Found: /index
INFO - 2018-06-25 22:10:48 --> Config Class Initialized
INFO - 2018-06-25 22:10:48 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:10:48 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:10:48 --> Utf8 Class Initialized
INFO - 2018-06-25 22:10:48 --> URI Class Initialized
INFO - 2018-06-25 22:10:48 --> Router Class Initialized
INFO - 2018-06-25 22:10:48 --> Output Class Initialized
INFO - 2018-06-25 22:10:48 --> Security Class Initialized
INFO - 2018-06-25 22:10:48 --> Config Class Initialized
INFO - 2018-06-25 22:10:48 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:10:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:10:48 --> Input Class Initialized
DEBUG - 2018-06-25 22:10:48 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:10:48 --> Language Class Initialized
INFO - 2018-06-25 22:10:49 --> Utf8 Class Initialized
ERROR - 2018-06-25 22:10:49 --> 404 Page Not Found: /index
INFO - 2018-06-25 22:10:49 --> URI Class Initialized
INFO - 2018-06-25 22:10:49 --> Router Class Initialized
INFO - 2018-06-25 22:10:49 --> Output Class Initialized
INFO - 2018-06-25 22:10:49 --> Security Class Initialized
DEBUG - 2018-06-25 22:10:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:10:49 --> Input Class Initialized
INFO - 2018-06-25 22:10:49 --> Language Class Initialized
ERROR - 2018-06-25 22:10:49 --> 404 Page Not Found: /index
INFO - 2018-06-25 22:10:49 --> Config Class Initialized
INFO - 2018-06-25 22:10:49 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:10:49 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:10:49 --> Utf8 Class Initialized
INFO - 2018-06-25 22:10:49 --> URI Class Initialized
INFO - 2018-06-25 22:10:49 --> Router Class Initialized
INFO - 2018-06-25 22:10:49 --> Output Class Initialized
INFO - 2018-06-25 22:10:49 --> Security Class Initialized
DEBUG - 2018-06-25 22:10:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:10:49 --> Input Class Initialized
INFO - 2018-06-25 22:10:49 --> Language Class Initialized
ERROR - 2018-06-25 22:10:49 --> 404 Page Not Found: /index
INFO - 2018-06-25 22:10:49 --> Config Class Initialized
INFO - 2018-06-25 22:10:49 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:10:49 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:10:49 --> Utf8 Class Initialized
INFO - 2018-06-25 22:10:49 --> URI Class Initialized
INFO - 2018-06-25 22:10:49 --> Router Class Initialized
INFO - 2018-06-25 22:10:49 --> Output Class Initialized
INFO - 2018-06-25 22:10:49 --> Security Class Initialized
DEBUG - 2018-06-25 22:10:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:10:49 --> Input Class Initialized
INFO - 2018-06-25 22:10:49 --> Language Class Initialized
ERROR - 2018-06-25 22:10:49 --> 404 Page Not Found: /index
INFO - 2018-06-25 22:10:49 --> Config Class Initialized
INFO - 2018-06-25 22:10:49 --> Config Class Initialized
INFO - 2018-06-25 22:10:49 --> Hooks Class Initialized
INFO - 2018-06-25 22:10:49 --> Config Class Initialized
INFO - 2018-06-25 22:10:49 --> Hooks Class Initialized
INFO - 2018-06-25 22:10:49 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:10:49 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:10:49 --> Utf8 Class Initialized
DEBUG - 2018-06-25 22:10:49 --> UTF-8 Support Enabled
DEBUG - 2018-06-25 22:10:49 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:10:49 --> Utf8 Class Initialized
INFO - 2018-06-25 22:10:49 --> Utf8 Class Initialized
INFO - 2018-06-25 22:10:49 --> URI Class Initialized
INFO - 2018-06-25 22:10:49 --> URI Class Initialized
INFO - 2018-06-25 22:10:49 --> Router Class Initialized
INFO - 2018-06-25 22:10:49 --> URI Class Initialized
INFO - 2018-06-25 22:10:49 --> Output Class Initialized
INFO - 2018-06-25 22:10:49 --> Router Class Initialized
INFO - 2018-06-25 22:10:49 --> Output Class Initialized
INFO - 2018-06-25 22:10:49 --> Security Class Initialized
INFO - 2018-06-25 22:10:49 --> Router Class Initialized
INFO - 2018-06-25 22:10:49 --> Security Class Initialized
INFO - 2018-06-25 22:10:49 --> Output Class Initialized
DEBUG - 2018-06-25 22:10:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:10:49 --> Input Class Initialized
DEBUG - 2018-06-25 22:10:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:10:49 --> Security Class Initialized
INFO - 2018-06-25 22:10:49 --> Language Class Initialized
INFO - 2018-06-25 22:10:49 --> Input Class Initialized
ERROR - 2018-06-25 22:10:49 --> 404 Page Not Found: /index
INFO - 2018-06-25 22:10:49 --> Language Class Initialized
ERROR - 2018-06-25 22:10:49 --> 404 Page Not Found: /index
DEBUG - 2018-06-25 22:10:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:10:49 --> Input Class Initialized
INFO - 2018-06-25 22:10:49 --> Config Class Initialized
INFO - 2018-06-25 22:10:49 --> Hooks Class Initialized
INFO - 2018-06-25 22:10:49 --> Language Class Initialized
DEBUG - 2018-06-25 22:10:49 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:10:49 --> Utf8 Class Initialized
INFO - 2018-06-25 22:10:49 --> Config Class Initialized
INFO - 2018-06-25 22:10:49 --> URI Class Initialized
ERROR - 2018-06-25 22:10:49 --> 404 Page Not Found: /index
INFO - 2018-06-25 22:10:49 --> Hooks Class Initialized
INFO - 2018-06-25 22:10:49 --> Router Class Initialized
DEBUG - 2018-06-25 22:10:49 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:10:49 --> Output Class Initialized
INFO - 2018-06-25 22:10:49 --> Utf8 Class Initialized
INFO - 2018-06-25 22:10:49 --> Security Class Initialized
INFO - 2018-06-25 22:10:49 --> URI Class Initialized
DEBUG - 2018-06-25 22:10:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:10:49 --> Input Class Initialized
INFO - 2018-06-25 22:10:49 --> Router Class Initialized
INFO - 2018-06-25 22:10:49 --> Language Class Initialized
INFO - 2018-06-25 22:10:49 --> Output Class Initialized
INFO - 2018-06-25 22:10:49 --> Security Class Initialized
ERROR - 2018-06-25 22:10:49 --> 404 Page Not Found: /index
DEBUG - 2018-06-25 22:10:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:10:50 --> Input Class Initialized
INFO - 2018-06-25 22:10:50 --> Language Class Initialized
ERROR - 2018-06-25 22:10:50 --> 404 Page Not Found: /index
INFO - 2018-06-25 22:10:50 --> Config Class Initialized
INFO - 2018-06-25 22:10:50 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:10:50 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:10:50 --> Utf8 Class Initialized
INFO - 2018-06-25 22:10:50 --> URI Class Initialized
INFO - 2018-06-25 22:10:50 --> Router Class Initialized
INFO - 2018-06-25 22:10:50 --> Output Class Initialized
INFO - 2018-06-25 22:10:50 --> Security Class Initialized
DEBUG - 2018-06-25 22:10:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:10:50 --> Input Class Initialized
INFO - 2018-06-25 22:10:50 --> Language Class Initialized
ERROR - 2018-06-25 22:10:50 --> 404 Page Not Found: /index
INFO - 2018-06-25 22:10:50 --> Config Class Initialized
INFO - 2018-06-25 22:10:50 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:10:50 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:10:50 --> Utf8 Class Initialized
INFO - 2018-06-25 22:10:50 --> URI Class Initialized
INFO - 2018-06-25 22:10:50 --> Router Class Initialized
INFO - 2018-06-25 22:10:50 --> Output Class Initialized
INFO - 2018-06-25 22:10:50 --> Security Class Initialized
DEBUG - 2018-06-25 22:10:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:10:50 --> Input Class Initialized
INFO - 2018-06-25 22:10:50 --> Language Class Initialized
ERROR - 2018-06-25 22:10:50 --> 404 Page Not Found: /index
INFO - 2018-06-25 22:11:17 --> Config Class Initialized
INFO - 2018-06-25 22:11:17 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:11:17 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:11:17 --> Utf8 Class Initialized
INFO - 2018-06-25 22:11:17 --> URI Class Initialized
INFO - 2018-06-25 22:11:17 --> Router Class Initialized
INFO - 2018-06-25 22:11:17 --> Output Class Initialized
INFO - 2018-06-25 22:11:17 --> Security Class Initialized
DEBUG - 2018-06-25 22:11:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:11:17 --> Input Class Initialized
INFO - 2018-06-25 22:11:17 --> Language Class Initialized
INFO - 2018-06-25 22:11:17 --> Language Class Initialized
INFO - 2018-06-25 22:11:17 --> Config Class Initialized
INFO - 2018-06-25 22:11:17 --> Loader Class Initialized
DEBUG - 2018-06-25 22:11:17 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-25 22:11:17 --> Helper loaded: url_helper
INFO - 2018-06-25 22:11:17 --> Helper loaded: form_helper
INFO - 2018-06-25 22:11:17 --> Helper loaded: date_helper
INFO - 2018-06-25 22:11:17 --> Helper loaded: util_helper
INFO - 2018-06-25 22:11:17 --> Helper loaded: text_helper
INFO - 2018-06-25 22:11:17 --> Helper loaded: string_helper
INFO - 2018-06-25 22:11:17 --> Database Driver Class Initialized
DEBUG - 2018-06-25 22:11:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-25 22:11:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-25 22:11:17 --> Email Class Initialized
INFO - 2018-06-25 22:11:17 --> Controller Class Initialized
DEBUG - 2018-06-25 22:11:17 --> Home MX_Controller Initialized
DEBUG - 2018-06-25 22:11:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-06-25 22:16:06 --> Config Class Initialized
INFO - 2018-06-25 22:16:06 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:16:06 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:16:06 --> Utf8 Class Initialized
INFO - 2018-06-25 22:16:06 --> URI Class Initialized
INFO - 2018-06-25 22:16:06 --> Router Class Initialized
INFO - 2018-06-25 22:16:06 --> Output Class Initialized
INFO - 2018-06-25 22:16:06 --> Security Class Initialized
DEBUG - 2018-06-25 22:16:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:16:06 --> Input Class Initialized
INFO - 2018-06-25 22:16:06 --> Language Class Initialized
INFO - 2018-06-25 22:16:06 --> Language Class Initialized
INFO - 2018-06-25 22:16:06 --> Config Class Initialized
INFO - 2018-06-25 22:16:06 --> Loader Class Initialized
DEBUG - 2018-06-25 22:16:06 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-25 22:16:06 --> Helper loaded: url_helper
INFO - 2018-06-25 22:16:06 --> Helper loaded: form_helper
INFO - 2018-06-25 22:16:06 --> Helper loaded: date_helper
INFO - 2018-06-25 22:16:06 --> Helper loaded: util_helper
INFO - 2018-06-25 22:16:06 --> Helper loaded: text_helper
INFO - 2018-06-25 22:16:06 --> Helper loaded: string_helper
INFO - 2018-06-25 22:16:06 --> Database Driver Class Initialized
DEBUG - 2018-06-25 22:16:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-25 22:16:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-25 22:16:06 --> Email Class Initialized
INFO - 2018-06-25 22:16:06 --> Controller Class Initialized
DEBUG - 2018-06-25 22:16:06 --> Home MX_Controller Initialized
DEBUG - 2018-06-25 22:16:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-25 22:16:06 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-25 22:16:06 --> Login MX_Controller Initialized
INFO - 2018-06-25 22:16:06 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-25 22:16:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-25 22:16:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-25 22:16:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-25 22:16:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-25 22:16:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-25 22:16:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-25 22:16:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-25 22:16:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-06-25 22:16:06 --> Final output sent to browser
DEBUG - 2018-06-25 22:16:06 --> Total execution time: 0.4369
INFO - 2018-06-25 22:16:07 --> Config Class Initialized
INFO - 2018-06-25 22:16:07 --> Config Class Initialized
INFO - 2018-06-25 22:16:07 --> Hooks Class Initialized
INFO - 2018-06-25 22:16:07 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:16:07 --> UTF-8 Support Enabled
DEBUG - 2018-06-25 22:16:07 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:16:07 --> Utf8 Class Initialized
INFO - 2018-06-25 22:16:07 --> Utf8 Class Initialized
INFO - 2018-06-25 22:16:07 --> URI Class Initialized
INFO - 2018-06-25 22:16:07 --> URI Class Initialized
INFO - 2018-06-25 22:16:07 --> Router Class Initialized
INFO - 2018-06-25 22:16:07 --> Router Class Initialized
INFO - 2018-06-25 22:16:07 --> Output Class Initialized
INFO - 2018-06-25 22:16:07 --> Output Class Initialized
INFO - 2018-06-25 22:16:07 --> Security Class Initialized
INFO - 2018-06-25 22:16:07 --> Security Class Initialized
DEBUG - 2018-06-25 22:16:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-06-25 22:16:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:16:07 --> Input Class Initialized
INFO - 2018-06-25 22:16:07 --> Input Class Initialized
INFO - 2018-06-25 22:16:07 --> Language Class Initialized
INFO - 2018-06-25 22:16:07 --> Language Class Initialized
ERROR - 2018-06-25 22:16:07 --> 404 Page Not Found: /index
ERROR - 2018-06-25 22:16:07 --> 404 Page Not Found: /index
INFO - 2018-06-25 22:16:07 --> Config Class Initialized
INFO - 2018-06-25 22:16:07 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:16:07 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:16:07 --> Utf8 Class Initialized
INFO - 2018-06-25 22:16:07 --> URI Class Initialized
INFO - 2018-06-25 22:16:07 --> Router Class Initialized
INFO - 2018-06-25 22:16:07 --> Output Class Initialized
INFO - 2018-06-25 22:16:07 --> Security Class Initialized
DEBUG - 2018-06-25 22:16:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:16:07 --> Input Class Initialized
INFO - 2018-06-25 22:16:07 --> Language Class Initialized
ERROR - 2018-06-25 22:16:07 --> 404 Page Not Found: /index
INFO - 2018-06-25 22:16:07 --> Config Class Initialized
INFO - 2018-06-25 22:16:07 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:16:07 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:16:07 --> Utf8 Class Initialized
INFO - 2018-06-25 22:16:07 --> URI Class Initialized
INFO - 2018-06-25 22:16:07 --> Router Class Initialized
INFO - 2018-06-25 22:16:07 --> Output Class Initialized
INFO - 2018-06-25 22:16:07 --> Security Class Initialized
DEBUG - 2018-06-25 22:16:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:16:07 --> Input Class Initialized
INFO - 2018-06-25 22:16:07 --> Language Class Initialized
ERROR - 2018-06-25 22:16:07 --> 404 Page Not Found: /index
INFO - 2018-06-25 22:16:07 --> Config Class Initialized
INFO - 2018-06-25 22:16:07 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:16:07 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:16:07 --> Utf8 Class Initialized
INFO - 2018-06-25 22:16:07 --> URI Class Initialized
INFO - 2018-06-25 22:16:07 --> Router Class Initialized
INFO - 2018-06-25 22:16:07 --> Output Class Initialized
INFO - 2018-06-25 22:16:07 --> Security Class Initialized
DEBUG - 2018-06-25 22:16:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:16:07 --> Input Class Initialized
INFO - 2018-06-25 22:16:07 --> Language Class Initialized
ERROR - 2018-06-25 22:16:07 --> 404 Page Not Found: /index
INFO - 2018-06-25 22:16:07 --> Config Class Initialized
INFO - 2018-06-25 22:16:07 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:16:08 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:16:08 --> Utf8 Class Initialized
INFO - 2018-06-25 22:16:08 --> URI Class Initialized
INFO - 2018-06-25 22:16:08 --> Router Class Initialized
INFO - 2018-06-25 22:16:08 --> Output Class Initialized
INFO - 2018-06-25 22:16:08 --> Security Class Initialized
DEBUG - 2018-06-25 22:16:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:16:08 --> Input Class Initialized
INFO - 2018-06-25 22:16:08 --> Language Class Initialized
ERROR - 2018-06-25 22:16:08 --> 404 Page Not Found: /index
INFO - 2018-06-25 22:16:08 --> Config Class Initialized
INFO - 2018-06-25 22:16:08 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:16:08 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:16:08 --> Utf8 Class Initialized
INFO - 2018-06-25 22:16:08 --> URI Class Initialized
INFO - 2018-06-25 22:16:08 --> Router Class Initialized
INFO - 2018-06-25 22:16:08 --> Output Class Initialized
INFO - 2018-06-25 22:16:08 --> Security Class Initialized
DEBUG - 2018-06-25 22:16:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:16:08 --> Input Class Initialized
INFO - 2018-06-25 22:16:08 --> Language Class Initialized
ERROR - 2018-06-25 22:16:08 --> 404 Page Not Found: /index
INFO - 2018-06-25 22:18:45 --> Config Class Initialized
INFO - 2018-06-25 22:18:45 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:18:45 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:18:45 --> Utf8 Class Initialized
INFO - 2018-06-25 22:18:45 --> URI Class Initialized
INFO - 2018-06-25 22:18:45 --> Router Class Initialized
INFO - 2018-06-25 22:18:45 --> Output Class Initialized
INFO - 2018-06-25 22:18:45 --> Security Class Initialized
DEBUG - 2018-06-25 22:18:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:18:45 --> Input Class Initialized
INFO - 2018-06-25 22:18:45 --> Language Class Initialized
INFO - 2018-06-25 22:18:45 --> Language Class Initialized
INFO - 2018-06-25 22:18:45 --> Config Class Initialized
INFO - 2018-06-25 22:18:45 --> Loader Class Initialized
DEBUG - 2018-06-25 22:18:45 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-25 22:18:45 --> Helper loaded: url_helper
INFO - 2018-06-25 22:18:45 --> Helper loaded: form_helper
INFO - 2018-06-25 22:18:45 --> Helper loaded: date_helper
INFO - 2018-06-25 22:18:45 --> Helper loaded: util_helper
INFO - 2018-06-25 22:18:45 --> Helper loaded: text_helper
INFO - 2018-06-25 22:18:45 --> Helper loaded: string_helper
INFO - 2018-06-25 22:18:45 --> Database Driver Class Initialized
DEBUG - 2018-06-25 22:18:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-25 22:18:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-25 22:18:45 --> Email Class Initialized
INFO - 2018-06-25 22:18:45 --> Controller Class Initialized
DEBUG - 2018-06-25 22:18:45 --> Home MX_Controller Initialized
DEBUG - 2018-06-25 22:18:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-06-25 22:19:19 --> Config Class Initialized
INFO - 2018-06-25 22:19:19 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:19:19 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:19:19 --> Utf8 Class Initialized
INFO - 2018-06-25 22:19:19 --> URI Class Initialized
INFO - 2018-06-25 22:19:19 --> Router Class Initialized
INFO - 2018-06-25 22:19:20 --> Output Class Initialized
INFO - 2018-06-25 22:19:20 --> Security Class Initialized
DEBUG - 2018-06-25 22:19:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:19:20 --> Input Class Initialized
INFO - 2018-06-25 22:19:20 --> Language Class Initialized
INFO - 2018-06-25 22:19:20 --> Language Class Initialized
INFO - 2018-06-25 22:19:20 --> Config Class Initialized
INFO - 2018-06-25 22:19:20 --> Loader Class Initialized
DEBUG - 2018-06-25 22:19:20 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-25 22:19:20 --> Helper loaded: url_helper
INFO - 2018-06-25 22:19:20 --> Helper loaded: form_helper
INFO - 2018-06-25 22:19:20 --> Helper loaded: date_helper
INFO - 2018-06-25 22:19:20 --> Helper loaded: util_helper
INFO - 2018-06-25 22:19:20 --> Helper loaded: text_helper
INFO - 2018-06-25 22:19:20 --> Helper loaded: string_helper
INFO - 2018-06-25 22:19:20 --> Database Driver Class Initialized
DEBUG - 2018-06-25 22:19:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-25 22:19:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-25 22:19:20 --> Email Class Initialized
INFO - 2018-06-25 22:19:20 --> Controller Class Initialized
DEBUG - 2018-06-25 22:19:20 --> Home MX_Controller Initialized
DEBUG - 2018-06-25 22:19:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-06-25 22:22:47 --> Config Class Initialized
INFO - 2018-06-25 22:22:47 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:22:47 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:22:47 --> Utf8 Class Initialized
INFO - 2018-06-25 22:22:47 --> URI Class Initialized
INFO - 2018-06-25 22:22:47 --> Router Class Initialized
INFO - 2018-06-25 22:22:47 --> Output Class Initialized
INFO - 2018-06-25 22:22:47 --> Security Class Initialized
DEBUG - 2018-06-25 22:22:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:22:48 --> Input Class Initialized
INFO - 2018-06-25 22:22:48 --> Language Class Initialized
INFO - 2018-06-25 22:22:48 --> Language Class Initialized
INFO - 2018-06-25 22:22:48 --> Config Class Initialized
INFO - 2018-06-25 22:22:48 --> Loader Class Initialized
DEBUG - 2018-06-25 22:22:48 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-25 22:22:48 --> Helper loaded: url_helper
INFO - 2018-06-25 22:22:48 --> Helper loaded: form_helper
INFO - 2018-06-25 22:22:48 --> Helper loaded: date_helper
INFO - 2018-06-25 22:22:48 --> Helper loaded: util_helper
INFO - 2018-06-25 22:22:48 --> Helper loaded: text_helper
INFO - 2018-06-25 22:22:48 --> Helper loaded: string_helper
INFO - 2018-06-25 22:22:48 --> Database Driver Class Initialized
DEBUG - 2018-06-25 22:22:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-25 22:22:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-25 22:22:48 --> Email Class Initialized
INFO - 2018-06-25 22:22:48 --> Controller Class Initialized
DEBUG - 2018-06-25 22:22:48 --> Home MX_Controller Initialized
DEBUG - 2018-06-25 22:22:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-25 22:22:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-25 22:22:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-25 22:22:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-25 22:22:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-25 22:22:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-25 22:22:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/search_page.php
INFO - 2018-06-25 22:22:48 --> Final output sent to browser
DEBUG - 2018-06-25 22:22:48 --> Total execution time: 0.4932
INFO - 2018-06-25 22:22:48 --> Config Class Initialized
INFO - 2018-06-25 22:22:49 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:22:49 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:22:49 --> Utf8 Class Initialized
INFO - 2018-06-25 22:22:49 --> URI Class Initialized
INFO - 2018-06-25 22:22:49 --> Router Class Initialized
INFO - 2018-06-25 22:22:49 --> Output Class Initialized
INFO - 2018-06-25 22:22:49 --> Security Class Initialized
DEBUG - 2018-06-25 22:22:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:22:49 --> Input Class Initialized
INFO - 2018-06-25 22:22:49 --> Language Class Initialized
ERROR - 2018-06-25 22:22:49 --> 404 Page Not Found: /index
INFO - 2018-06-25 22:22:49 --> Config Class Initialized
INFO - 2018-06-25 22:22:49 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:22:49 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:22:49 --> Utf8 Class Initialized
INFO - 2018-06-25 22:22:49 --> URI Class Initialized
INFO - 2018-06-25 22:22:49 --> Router Class Initialized
INFO - 2018-06-25 22:22:49 --> Output Class Initialized
INFO - 2018-06-25 22:22:49 --> Security Class Initialized
DEBUG - 2018-06-25 22:22:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:22:49 --> Input Class Initialized
INFO - 2018-06-25 22:22:49 --> Language Class Initialized
ERROR - 2018-06-25 22:22:49 --> 404 Page Not Found: /index
INFO - 2018-06-25 22:22:49 --> Config Class Initialized
INFO - 2018-06-25 22:22:49 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:22:49 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:22:49 --> Utf8 Class Initialized
INFO - 2018-06-25 22:22:49 --> URI Class Initialized
INFO - 2018-06-25 22:22:49 --> Router Class Initialized
INFO - 2018-06-25 22:22:49 --> Output Class Initialized
INFO - 2018-06-25 22:22:49 --> Security Class Initialized
DEBUG - 2018-06-25 22:22:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:22:49 --> Input Class Initialized
INFO - 2018-06-25 22:22:49 --> Language Class Initialized
ERROR - 2018-06-25 22:22:49 --> 404 Page Not Found: /index
INFO - 2018-06-25 22:22:49 --> Config Class Initialized
INFO - 2018-06-25 22:22:49 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:22:49 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:22:49 --> Utf8 Class Initialized
INFO - 2018-06-25 22:22:49 --> URI Class Initialized
INFO - 2018-06-25 22:22:49 --> Router Class Initialized
INFO - 2018-06-25 22:22:49 --> Output Class Initialized
INFO - 2018-06-25 22:22:49 --> Security Class Initialized
DEBUG - 2018-06-25 22:22:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:22:49 --> Input Class Initialized
INFO - 2018-06-25 22:22:49 --> Language Class Initialized
ERROR - 2018-06-25 22:22:49 --> 404 Page Not Found: /index
INFO - 2018-06-25 22:22:49 --> Config Class Initialized
INFO - 2018-06-25 22:22:49 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:22:49 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:22:49 --> Utf8 Class Initialized
INFO - 2018-06-25 22:22:49 --> URI Class Initialized
INFO - 2018-06-25 22:22:49 --> Router Class Initialized
INFO - 2018-06-25 22:22:49 --> Output Class Initialized
INFO - 2018-06-25 22:22:49 --> Security Class Initialized
DEBUG - 2018-06-25 22:22:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:22:49 --> Input Class Initialized
INFO - 2018-06-25 22:22:49 --> Language Class Initialized
ERROR - 2018-06-25 22:22:49 --> 404 Page Not Found: /index
INFO - 2018-06-25 22:22:49 --> Config Class Initialized
INFO - 2018-06-25 22:22:49 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:22:49 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:22:49 --> Utf8 Class Initialized
INFO - 2018-06-25 22:22:49 --> URI Class Initialized
INFO - 2018-06-25 22:22:49 --> Router Class Initialized
INFO - 2018-06-25 22:22:49 --> Output Class Initialized
INFO - 2018-06-25 22:22:49 --> Security Class Initialized
DEBUG - 2018-06-25 22:22:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:22:49 --> Input Class Initialized
INFO - 2018-06-25 22:22:49 --> Language Class Initialized
ERROR - 2018-06-25 22:22:49 --> 404 Page Not Found: /index
INFO - 2018-06-25 22:22:53 --> Config Class Initialized
INFO - 2018-06-25 22:22:53 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:22:53 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:22:53 --> Utf8 Class Initialized
INFO - 2018-06-25 22:22:53 --> URI Class Initialized
INFO - 2018-06-25 22:22:53 --> Router Class Initialized
INFO - 2018-06-25 22:22:53 --> Output Class Initialized
INFO - 2018-06-25 22:22:53 --> Security Class Initialized
DEBUG - 2018-06-25 22:22:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:22:53 --> Input Class Initialized
INFO - 2018-06-25 22:22:53 --> Language Class Initialized
INFO - 2018-06-25 22:22:53 --> Language Class Initialized
INFO - 2018-06-25 22:22:53 --> Config Class Initialized
INFO - 2018-06-25 22:22:53 --> Loader Class Initialized
DEBUG - 2018-06-25 22:22:53 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-25 22:22:53 --> Helper loaded: url_helper
INFO - 2018-06-25 22:22:53 --> Helper loaded: form_helper
INFO - 2018-06-25 22:22:53 --> Helper loaded: date_helper
INFO - 2018-06-25 22:22:53 --> Helper loaded: util_helper
INFO - 2018-06-25 22:22:53 --> Helper loaded: text_helper
INFO - 2018-06-25 22:22:53 --> Helper loaded: string_helper
INFO - 2018-06-25 22:22:53 --> Database Driver Class Initialized
DEBUG - 2018-06-25 22:22:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-25 22:22:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-25 22:22:53 --> Email Class Initialized
INFO - 2018-06-25 22:22:53 --> Controller Class Initialized
DEBUG - 2018-06-25 22:22:53 --> Home MX_Controller Initialized
DEBUG - 2018-06-25 22:22:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-25 22:22:53 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-25 22:22:53 --> Login MX_Controller Initialized
INFO - 2018-06-25 22:22:53 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-25 22:22:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-25 22:22:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-25 22:22:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-25 22:22:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-25 22:22:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-25 22:22:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-25 22:22:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-25 22:22:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-06-25 22:22:53 --> Final output sent to browser
DEBUG - 2018-06-25 22:22:53 --> Total execution time: 0.6161
INFO - 2018-06-25 22:22:53 --> Config Class Initialized
INFO - 2018-06-25 22:22:53 --> Hooks Class Initialized
INFO - 2018-06-25 22:22:53 --> Config Class Initialized
INFO - 2018-06-25 22:22:53 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:22:53 --> UTF-8 Support Enabled
DEBUG - 2018-06-25 22:22:54 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:22:54 --> Utf8 Class Initialized
INFO - 2018-06-25 22:22:54 --> URI Class Initialized
INFO - 2018-06-25 22:22:54 --> Router Class Initialized
INFO - 2018-06-25 22:22:54 --> Output Class Initialized
INFO - 2018-06-25 22:22:54 --> Security Class Initialized
DEBUG - 2018-06-25 22:22:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:22:54 --> Input Class Initialized
INFO - 2018-06-25 22:22:54 --> Language Class Initialized
ERROR - 2018-06-25 22:22:54 --> 404 Page Not Found: /index
INFO - 2018-06-25 22:22:54 --> Utf8 Class Initialized
INFO - 2018-06-25 22:22:54 --> Config Class Initialized
INFO - 2018-06-25 22:22:54 --> Hooks Class Initialized
INFO - 2018-06-25 22:22:54 --> URI Class Initialized
DEBUG - 2018-06-25 22:22:54 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:22:54 --> Router Class Initialized
INFO - 2018-06-25 22:22:54 --> Utf8 Class Initialized
INFO - 2018-06-25 22:22:54 --> Output Class Initialized
INFO - 2018-06-25 22:22:54 --> URI Class Initialized
INFO - 2018-06-25 22:22:54 --> Security Class Initialized
DEBUG - 2018-06-25 22:22:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:22:54 --> Router Class Initialized
INFO - 2018-06-25 22:22:54 --> Input Class Initialized
INFO - 2018-06-25 22:22:54 --> Output Class Initialized
INFO - 2018-06-25 22:22:54 --> Security Class Initialized
INFO - 2018-06-25 22:22:54 --> Language Class Initialized
DEBUG - 2018-06-25 22:22:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-06-25 22:22:54 --> 404 Page Not Found: /index
INFO - 2018-06-25 22:22:54 --> Input Class Initialized
INFO - 2018-06-25 22:22:54 --> Language Class Initialized
ERROR - 2018-06-25 22:22:54 --> 404 Page Not Found: /index
INFO - 2018-06-25 22:22:54 --> Config Class Initialized
INFO - 2018-06-25 22:22:54 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:22:54 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:22:54 --> Utf8 Class Initialized
INFO - 2018-06-25 22:22:54 --> URI Class Initialized
INFO - 2018-06-25 22:22:54 --> Router Class Initialized
INFO - 2018-06-25 22:22:54 --> Output Class Initialized
INFO - 2018-06-25 22:22:54 --> Security Class Initialized
DEBUG - 2018-06-25 22:22:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:22:54 --> Input Class Initialized
INFO - 2018-06-25 22:22:54 --> Language Class Initialized
ERROR - 2018-06-25 22:22:54 --> 404 Page Not Found: /index
INFO - 2018-06-25 22:23:23 --> Config Class Initialized
INFO - 2018-06-25 22:23:23 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:23:23 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:23:23 --> Utf8 Class Initialized
INFO - 2018-06-25 22:23:23 --> URI Class Initialized
INFO - 2018-06-25 22:23:23 --> Router Class Initialized
INFO - 2018-06-25 22:23:23 --> Output Class Initialized
INFO - 2018-06-25 22:23:23 --> Security Class Initialized
DEBUG - 2018-06-25 22:23:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:23:23 --> Input Class Initialized
INFO - 2018-06-25 22:23:23 --> Language Class Initialized
INFO - 2018-06-25 22:23:23 --> Language Class Initialized
INFO - 2018-06-25 22:23:23 --> Config Class Initialized
INFO - 2018-06-25 22:23:23 --> Loader Class Initialized
DEBUG - 2018-06-25 22:23:23 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-25 22:23:23 --> Helper loaded: url_helper
INFO - 2018-06-25 22:23:23 --> Helper loaded: form_helper
INFO - 2018-06-25 22:23:23 --> Helper loaded: date_helper
INFO - 2018-06-25 22:23:23 --> Helper loaded: util_helper
INFO - 2018-06-25 22:23:23 --> Helper loaded: text_helper
INFO - 2018-06-25 22:23:23 --> Helper loaded: string_helper
INFO - 2018-06-25 22:23:23 --> Database Driver Class Initialized
DEBUG - 2018-06-25 22:23:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-25 22:23:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-25 22:23:23 --> Email Class Initialized
INFO - 2018-06-25 22:23:23 --> Controller Class Initialized
DEBUG - 2018-06-25 22:23:23 --> Home MX_Controller Initialized
DEBUG - 2018-06-25 22:23:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-25 22:23:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-25 22:23:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-25 22:23:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-25 22:23:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-25 22:23:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-25 22:23:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/search_page.php
INFO - 2018-06-25 22:23:23 --> Final output sent to browser
DEBUG - 2018-06-25 22:23:23 --> Total execution time: 0.3963
INFO - 2018-06-25 22:23:24 --> Config Class Initialized
INFO - 2018-06-25 22:23:24 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:23:24 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:23:24 --> Utf8 Class Initialized
INFO - 2018-06-25 22:23:24 --> URI Class Initialized
INFO - 2018-06-25 22:23:24 --> Router Class Initialized
INFO - 2018-06-25 22:23:24 --> Output Class Initialized
INFO - 2018-06-25 22:23:24 --> Security Class Initialized
DEBUG - 2018-06-25 22:23:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:23:24 --> Input Class Initialized
INFO - 2018-06-25 22:23:24 --> Language Class Initialized
ERROR - 2018-06-25 22:23:24 --> 404 Page Not Found: /index
INFO - 2018-06-25 22:23:24 --> Config Class Initialized
INFO - 2018-06-25 22:23:24 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:23:24 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:23:24 --> Utf8 Class Initialized
INFO - 2018-06-25 22:23:24 --> URI Class Initialized
INFO - 2018-06-25 22:23:24 --> Router Class Initialized
INFO - 2018-06-25 22:23:24 --> Output Class Initialized
INFO - 2018-06-25 22:23:24 --> Security Class Initialized
DEBUG - 2018-06-25 22:23:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:23:24 --> Input Class Initialized
INFO - 2018-06-25 22:23:24 --> Language Class Initialized
ERROR - 2018-06-25 22:23:24 --> 404 Page Not Found: /index
INFO - 2018-06-25 22:23:24 --> Config Class Initialized
INFO - 2018-06-25 22:23:24 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:23:24 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:23:24 --> Utf8 Class Initialized
INFO - 2018-06-25 22:23:24 --> URI Class Initialized
INFO - 2018-06-25 22:23:24 --> Router Class Initialized
INFO - 2018-06-25 22:23:24 --> Output Class Initialized
INFO - 2018-06-25 22:23:24 --> Security Class Initialized
DEBUG - 2018-06-25 22:23:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:23:24 --> Input Class Initialized
INFO - 2018-06-25 22:23:24 --> Language Class Initialized
ERROR - 2018-06-25 22:23:24 --> 404 Page Not Found: /index
INFO - 2018-06-25 22:23:24 --> Config Class Initialized
INFO - 2018-06-25 22:23:24 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:23:24 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:23:24 --> Utf8 Class Initialized
INFO - 2018-06-25 22:23:24 --> URI Class Initialized
INFO - 2018-06-25 22:23:24 --> Router Class Initialized
INFO - 2018-06-25 22:23:24 --> Output Class Initialized
INFO - 2018-06-25 22:23:24 --> Security Class Initialized
DEBUG - 2018-06-25 22:23:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:23:24 --> Input Class Initialized
INFO - 2018-06-25 22:23:24 --> Language Class Initialized
ERROR - 2018-06-25 22:23:24 --> 404 Page Not Found: /index
INFO - 2018-06-25 22:23:24 --> Config Class Initialized
INFO - 2018-06-25 22:23:24 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:23:24 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:23:24 --> Utf8 Class Initialized
INFO - 2018-06-25 22:23:24 --> URI Class Initialized
INFO - 2018-06-25 22:23:24 --> Router Class Initialized
INFO - 2018-06-25 22:23:24 --> Output Class Initialized
INFO - 2018-06-25 22:23:24 --> Security Class Initialized
DEBUG - 2018-06-25 22:23:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:23:24 --> Input Class Initialized
INFO - 2018-06-25 22:23:24 --> Language Class Initialized
ERROR - 2018-06-25 22:23:24 --> 404 Page Not Found: /index
INFO - 2018-06-25 22:23:24 --> Config Class Initialized
INFO - 2018-06-25 22:23:24 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:23:24 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:23:24 --> Utf8 Class Initialized
INFO - 2018-06-25 22:23:24 --> URI Class Initialized
INFO - 2018-06-25 22:23:25 --> Router Class Initialized
INFO - 2018-06-25 22:23:25 --> Output Class Initialized
INFO - 2018-06-25 22:23:25 --> Security Class Initialized
DEBUG - 2018-06-25 22:23:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:23:25 --> Input Class Initialized
INFO - 2018-06-25 22:23:25 --> Language Class Initialized
ERROR - 2018-06-25 22:23:25 --> 404 Page Not Found: /index
INFO - 2018-06-25 22:24:15 --> Config Class Initialized
INFO - 2018-06-25 22:24:15 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:24:15 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:24:15 --> Utf8 Class Initialized
INFO - 2018-06-25 22:24:15 --> URI Class Initialized
INFO - 2018-06-25 22:24:15 --> Router Class Initialized
INFO - 2018-06-25 22:24:15 --> Output Class Initialized
INFO - 2018-06-25 22:24:15 --> Security Class Initialized
DEBUG - 2018-06-25 22:24:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:24:15 --> Input Class Initialized
INFO - 2018-06-25 22:24:15 --> Language Class Initialized
INFO - 2018-06-25 22:24:15 --> Language Class Initialized
INFO - 2018-06-25 22:24:15 --> Config Class Initialized
INFO - 2018-06-25 22:24:15 --> Loader Class Initialized
DEBUG - 2018-06-25 22:24:15 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-25 22:24:15 --> Helper loaded: url_helper
INFO - 2018-06-25 22:24:15 --> Helper loaded: form_helper
INFO - 2018-06-25 22:24:15 --> Helper loaded: date_helper
INFO - 2018-06-25 22:24:15 --> Helper loaded: util_helper
INFO - 2018-06-25 22:24:15 --> Helper loaded: text_helper
INFO - 2018-06-25 22:24:15 --> Helper loaded: string_helper
INFO - 2018-06-25 22:24:15 --> Database Driver Class Initialized
DEBUG - 2018-06-25 22:24:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-25 22:24:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-25 22:24:15 --> Email Class Initialized
INFO - 2018-06-25 22:24:15 --> Controller Class Initialized
DEBUG - 2018-06-25 22:24:15 --> Home MX_Controller Initialized
DEBUG - 2018-06-25 22:24:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-25 22:24:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-25 22:24:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-25 22:24:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-25 22:24:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-25 22:24:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-25 22:24:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/search_page.php
INFO - 2018-06-25 22:24:15 --> Final output sent to browser
DEBUG - 2018-06-25 22:24:15 --> Total execution time: 0.4243
INFO - 2018-06-25 22:24:15 --> Config Class Initialized
INFO - 2018-06-25 22:24:15 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:24:15 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:24:16 --> Utf8 Class Initialized
INFO - 2018-06-25 22:24:16 --> URI Class Initialized
INFO - 2018-06-25 22:24:16 --> Router Class Initialized
INFO - 2018-06-25 22:24:16 --> Output Class Initialized
INFO - 2018-06-25 22:24:16 --> Security Class Initialized
DEBUG - 2018-06-25 22:24:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:24:16 --> Input Class Initialized
INFO - 2018-06-25 22:24:16 --> Language Class Initialized
ERROR - 2018-06-25 22:24:16 --> 404 Page Not Found: /index
INFO - 2018-06-25 22:24:16 --> Config Class Initialized
INFO - 2018-06-25 22:24:16 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:24:16 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:24:16 --> Utf8 Class Initialized
INFO - 2018-06-25 22:24:16 --> URI Class Initialized
INFO - 2018-06-25 22:24:16 --> Router Class Initialized
INFO - 2018-06-25 22:24:16 --> Output Class Initialized
INFO - 2018-06-25 22:24:16 --> Security Class Initialized
DEBUG - 2018-06-25 22:24:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:24:16 --> Input Class Initialized
INFO - 2018-06-25 22:24:16 --> Language Class Initialized
ERROR - 2018-06-25 22:24:16 --> 404 Page Not Found: /index
INFO - 2018-06-25 22:24:16 --> Config Class Initialized
INFO - 2018-06-25 22:24:16 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:24:16 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:24:16 --> Utf8 Class Initialized
INFO - 2018-06-25 22:24:16 --> URI Class Initialized
INFO - 2018-06-25 22:24:16 --> Router Class Initialized
INFO - 2018-06-25 22:24:16 --> Output Class Initialized
INFO - 2018-06-25 22:24:16 --> Security Class Initialized
DEBUG - 2018-06-25 22:24:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:24:16 --> Input Class Initialized
INFO - 2018-06-25 22:24:16 --> Language Class Initialized
ERROR - 2018-06-25 22:24:16 --> 404 Page Not Found: /index
INFO - 2018-06-25 22:24:16 --> Config Class Initialized
INFO - 2018-06-25 22:24:16 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:24:16 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:24:16 --> Utf8 Class Initialized
INFO - 2018-06-25 22:24:16 --> URI Class Initialized
INFO - 2018-06-25 22:24:16 --> Router Class Initialized
INFO - 2018-06-25 22:24:16 --> Output Class Initialized
INFO - 2018-06-25 22:24:16 --> Security Class Initialized
DEBUG - 2018-06-25 22:24:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:24:16 --> Input Class Initialized
INFO - 2018-06-25 22:24:16 --> Language Class Initialized
ERROR - 2018-06-25 22:24:16 --> 404 Page Not Found: /index
INFO - 2018-06-25 22:24:16 --> Config Class Initialized
INFO - 2018-06-25 22:24:16 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:24:16 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:24:16 --> Utf8 Class Initialized
INFO - 2018-06-25 22:24:16 --> URI Class Initialized
INFO - 2018-06-25 22:24:16 --> Router Class Initialized
INFO - 2018-06-25 22:24:16 --> Output Class Initialized
INFO - 2018-06-25 22:24:16 --> Security Class Initialized
DEBUG - 2018-06-25 22:24:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:24:16 --> Input Class Initialized
INFO - 2018-06-25 22:24:16 --> Language Class Initialized
ERROR - 2018-06-25 22:24:16 --> 404 Page Not Found: /index
INFO - 2018-06-25 22:24:16 --> Config Class Initialized
INFO - 2018-06-25 22:24:16 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:24:16 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:24:16 --> Utf8 Class Initialized
INFO - 2018-06-25 22:24:16 --> URI Class Initialized
INFO - 2018-06-25 22:24:16 --> Router Class Initialized
INFO - 2018-06-25 22:24:16 --> Output Class Initialized
INFO - 2018-06-25 22:24:16 --> Security Class Initialized
DEBUG - 2018-06-25 22:24:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:24:16 --> Input Class Initialized
INFO - 2018-06-25 22:24:16 --> Language Class Initialized
ERROR - 2018-06-25 22:24:16 --> 404 Page Not Found: /index
INFO - 2018-06-25 22:28:10 --> Config Class Initialized
INFO - 2018-06-25 22:28:10 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:28:10 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:28:10 --> Utf8 Class Initialized
INFO - 2018-06-25 22:28:10 --> URI Class Initialized
INFO - 2018-06-25 22:28:10 --> Router Class Initialized
INFO - 2018-06-25 22:28:10 --> Output Class Initialized
INFO - 2018-06-25 22:28:10 --> Security Class Initialized
DEBUG - 2018-06-25 22:28:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:28:10 --> Input Class Initialized
INFO - 2018-06-25 22:28:10 --> Language Class Initialized
INFO - 2018-06-25 22:28:10 --> Language Class Initialized
INFO - 2018-06-25 22:28:10 --> Config Class Initialized
INFO - 2018-06-25 22:28:10 --> Loader Class Initialized
DEBUG - 2018-06-25 22:28:10 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-25 22:28:10 --> Helper loaded: url_helper
INFO - 2018-06-25 22:28:10 --> Helper loaded: form_helper
INFO - 2018-06-25 22:28:10 --> Helper loaded: date_helper
INFO - 2018-06-25 22:28:10 --> Helper loaded: util_helper
INFO - 2018-06-25 22:28:10 --> Helper loaded: text_helper
INFO - 2018-06-25 22:28:10 --> Helper loaded: string_helper
INFO - 2018-06-25 22:28:10 --> Database Driver Class Initialized
DEBUG - 2018-06-25 22:28:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-25 22:28:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-25 22:28:10 --> Email Class Initialized
INFO - 2018-06-25 22:28:10 --> Controller Class Initialized
DEBUG - 2018-06-25 22:28:10 --> Home MX_Controller Initialized
DEBUG - 2018-06-25 22:28:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-25 22:28:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-25 22:28:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-25 22:28:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-25 22:28:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-25 22:28:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-25 22:28:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/search_page.php
INFO - 2018-06-25 22:28:10 --> Final output sent to browser
DEBUG - 2018-06-25 22:28:10 --> Total execution time: 0.3966
INFO - 2018-06-25 22:28:10 --> Config Class Initialized
INFO - 2018-06-25 22:28:10 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:28:10 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:28:10 --> Utf8 Class Initialized
INFO - 2018-06-25 22:28:10 --> URI Class Initialized
INFO - 2018-06-25 22:28:10 --> Router Class Initialized
INFO - 2018-06-25 22:28:10 --> Output Class Initialized
INFO - 2018-06-25 22:28:10 --> Security Class Initialized
DEBUG - 2018-06-25 22:28:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:28:10 --> Input Class Initialized
INFO - 2018-06-25 22:28:10 --> Language Class Initialized
ERROR - 2018-06-25 22:28:11 --> 404 Page Not Found: /index
INFO - 2018-06-25 22:28:11 --> Config Class Initialized
INFO - 2018-06-25 22:28:11 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:28:11 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:28:11 --> Utf8 Class Initialized
INFO - 2018-06-25 22:28:11 --> URI Class Initialized
INFO - 2018-06-25 22:28:11 --> Router Class Initialized
INFO - 2018-06-25 22:28:11 --> Output Class Initialized
INFO - 2018-06-25 22:28:11 --> Security Class Initialized
DEBUG - 2018-06-25 22:28:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:28:11 --> Input Class Initialized
INFO - 2018-06-25 22:28:11 --> Language Class Initialized
ERROR - 2018-06-25 22:28:11 --> 404 Page Not Found: /index
INFO - 2018-06-25 22:28:11 --> Config Class Initialized
INFO - 2018-06-25 22:28:11 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:28:11 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:28:11 --> Utf8 Class Initialized
INFO - 2018-06-25 22:28:11 --> URI Class Initialized
INFO - 2018-06-25 22:28:11 --> Router Class Initialized
INFO - 2018-06-25 22:28:11 --> Output Class Initialized
INFO - 2018-06-25 22:28:11 --> Security Class Initialized
DEBUG - 2018-06-25 22:28:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:28:11 --> Input Class Initialized
INFO - 2018-06-25 22:28:11 --> Language Class Initialized
ERROR - 2018-06-25 22:28:11 --> 404 Page Not Found: /index
INFO - 2018-06-25 22:28:11 --> Config Class Initialized
INFO - 2018-06-25 22:28:11 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:28:11 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:28:11 --> Utf8 Class Initialized
INFO - 2018-06-25 22:28:11 --> URI Class Initialized
INFO - 2018-06-25 22:28:11 --> Router Class Initialized
INFO - 2018-06-25 22:28:11 --> Output Class Initialized
INFO - 2018-06-25 22:28:11 --> Security Class Initialized
DEBUG - 2018-06-25 22:28:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:28:11 --> Input Class Initialized
INFO - 2018-06-25 22:28:11 --> Language Class Initialized
ERROR - 2018-06-25 22:28:11 --> 404 Page Not Found: /index
INFO - 2018-06-25 22:28:11 --> Config Class Initialized
INFO - 2018-06-25 22:28:11 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:28:11 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:28:11 --> Utf8 Class Initialized
INFO - 2018-06-25 22:28:11 --> URI Class Initialized
INFO - 2018-06-25 22:28:11 --> Router Class Initialized
INFO - 2018-06-25 22:28:11 --> Output Class Initialized
INFO - 2018-06-25 22:28:11 --> Security Class Initialized
DEBUG - 2018-06-25 22:28:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:28:11 --> Input Class Initialized
INFO - 2018-06-25 22:28:11 --> Language Class Initialized
ERROR - 2018-06-25 22:28:11 --> 404 Page Not Found: /index
INFO - 2018-06-25 22:28:11 --> Config Class Initialized
INFO - 2018-06-25 22:28:11 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:28:11 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:28:11 --> Utf8 Class Initialized
INFO - 2018-06-25 22:28:11 --> URI Class Initialized
INFO - 2018-06-25 22:28:11 --> Router Class Initialized
INFO - 2018-06-25 22:28:11 --> Output Class Initialized
INFO - 2018-06-25 22:28:11 --> Security Class Initialized
DEBUG - 2018-06-25 22:28:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:28:11 --> Input Class Initialized
INFO - 2018-06-25 22:28:11 --> Language Class Initialized
ERROR - 2018-06-25 22:28:11 --> 404 Page Not Found: /index
INFO - 2018-06-25 22:28:14 --> Config Class Initialized
INFO - 2018-06-25 22:28:14 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:28:14 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:28:14 --> Utf8 Class Initialized
INFO - 2018-06-25 22:28:14 --> URI Class Initialized
INFO - 2018-06-25 22:28:14 --> Router Class Initialized
INFO - 2018-06-25 22:28:14 --> Output Class Initialized
INFO - 2018-06-25 22:28:14 --> Security Class Initialized
DEBUG - 2018-06-25 22:28:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:28:14 --> Input Class Initialized
INFO - 2018-06-25 22:28:14 --> Language Class Initialized
INFO - 2018-06-25 22:28:14 --> Language Class Initialized
INFO - 2018-06-25 22:28:14 --> Config Class Initialized
INFO - 2018-06-25 22:28:14 --> Loader Class Initialized
DEBUG - 2018-06-25 22:28:14 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-25 22:28:14 --> Helper loaded: url_helper
INFO - 2018-06-25 22:28:14 --> Helper loaded: form_helper
INFO - 2018-06-25 22:28:14 --> Helper loaded: date_helper
INFO - 2018-06-25 22:28:14 --> Helper loaded: util_helper
INFO - 2018-06-25 22:28:14 --> Helper loaded: text_helper
INFO - 2018-06-25 22:28:14 --> Helper loaded: string_helper
INFO - 2018-06-25 22:28:14 --> Database Driver Class Initialized
DEBUG - 2018-06-25 22:28:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-25 22:28:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-25 22:28:15 --> Email Class Initialized
INFO - 2018-06-25 22:28:15 --> Controller Class Initialized
DEBUG - 2018-06-25 22:28:15 --> Home MX_Controller Initialized
DEBUG - 2018-06-25 22:28:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-25 22:28:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-25 22:28:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-25 22:28:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-25 22:28:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-25 22:28:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-25 22:28:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/search_page.php
INFO - 2018-06-25 22:28:15 --> Final output sent to browser
DEBUG - 2018-06-25 22:28:15 --> Total execution time: 0.3973
INFO - 2018-06-25 22:28:15 --> Config Class Initialized
INFO - 2018-06-25 22:28:15 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:28:15 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:28:15 --> Utf8 Class Initialized
INFO - 2018-06-25 22:28:15 --> URI Class Initialized
INFO - 2018-06-25 22:28:15 --> Router Class Initialized
INFO - 2018-06-25 22:28:15 --> Output Class Initialized
INFO - 2018-06-25 22:28:15 --> Security Class Initialized
DEBUG - 2018-06-25 22:28:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:28:15 --> Input Class Initialized
INFO - 2018-06-25 22:28:15 --> Language Class Initialized
ERROR - 2018-06-25 22:28:15 --> 404 Page Not Found: /index
INFO - 2018-06-25 22:28:15 --> Config Class Initialized
INFO - 2018-06-25 22:28:15 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:28:15 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:28:15 --> Utf8 Class Initialized
INFO - 2018-06-25 22:28:15 --> URI Class Initialized
INFO - 2018-06-25 22:28:15 --> Router Class Initialized
INFO - 2018-06-25 22:28:15 --> Output Class Initialized
INFO - 2018-06-25 22:28:15 --> Security Class Initialized
DEBUG - 2018-06-25 22:28:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:28:15 --> Input Class Initialized
INFO - 2018-06-25 22:28:15 --> Language Class Initialized
ERROR - 2018-06-25 22:28:15 --> 404 Page Not Found: /index
INFO - 2018-06-25 22:28:15 --> Config Class Initialized
INFO - 2018-06-25 22:28:15 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:28:15 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:28:15 --> Utf8 Class Initialized
INFO - 2018-06-25 22:28:15 --> URI Class Initialized
INFO - 2018-06-25 22:28:15 --> Router Class Initialized
INFO - 2018-06-25 22:28:15 --> Output Class Initialized
INFO - 2018-06-25 22:28:15 --> Security Class Initialized
DEBUG - 2018-06-25 22:28:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:28:15 --> Input Class Initialized
INFO - 2018-06-25 22:28:15 --> Language Class Initialized
ERROR - 2018-06-25 22:28:15 --> 404 Page Not Found: /index
INFO - 2018-06-25 22:28:19 --> Config Class Initialized
INFO - 2018-06-25 22:28:19 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:28:19 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:28:19 --> Utf8 Class Initialized
INFO - 2018-06-25 22:28:19 --> URI Class Initialized
INFO - 2018-06-25 22:28:19 --> Router Class Initialized
INFO - 2018-06-25 22:28:19 --> Output Class Initialized
INFO - 2018-06-25 22:28:19 --> Security Class Initialized
DEBUG - 2018-06-25 22:28:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:28:19 --> Input Class Initialized
INFO - 2018-06-25 22:28:19 --> Language Class Initialized
INFO - 2018-06-25 22:28:19 --> Language Class Initialized
INFO - 2018-06-25 22:28:20 --> Config Class Initialized
INFO - 2018-06-25 22:28:20 --> Loader Class Initialized
DEBUG - 2018-06-25 22:28:20 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-25 22:28:20 --> Helper loaded: url_helper
INFO - 2018-06-25 22:28:20 --> Helper loaded: form_helper
INFO - 2018-06-25 22:28:20 --> Helper loaded: date_helper
INFO - 2018-06-25 22:28:20 --> Helper loaded: util_helper
INFO - 2018-06-25 22:28:20 --> Helper loaded: text_helper
INFO - 2018-06-25 22:28:20 --> Helper loaded: string_helper
INFO - 2018-06-25 22:28:20 --> Database Driver Class Initialized
DEBUG - 2018-06-25 22:28:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-25 22:28:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-25 22:28:20 --> Email Class Initialized
INFO - 2018-06-25 22:28:20 --> Controller Class Initialized
DEBUG - 2018-06-25 22:28:20 --> Home MX_Controller Initialized
DEBUG - 2018-06-25 22:28:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-25 22:28:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-25 22:28:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-25 22:28:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-25 22:28:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-25 22:28:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-25 22:28:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/search_page.php
INFO - 2018-06-25 22:28:20 --> Final output sent to browser
DEBUG - 2018-06-25 22:28:20 --> Total execution time: 0.4678
INFO - 2018-06-25 22:28:20 --> Config Class Initialized
INFO - 2018-06-25 22:28:20 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:28:20 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:28:20 --> Utf8 Class Initialized
INFO - 2018-06-25 22:28:20 --> URI Class Initialized
INFO - 2018-06-25 22:28:20 --> Router Class Initialized
INFO - 2018-06-25 22:28:20 --> Output Class Initialized
INFO - 2018-06-25 22:28:20 --> Security Class Initialized
DEBUG - 2018-06-25 22:28:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:28:20 --> Input Class Initialized
INFO - 2018-06-25 22:28:20 --> Language Class Initialized
ERROR - 2018-06-25 22:28:20 --> 404 Page Not Found: /index
INFO - 2018-06-25 22:28:20 --> Config Class Initialized
INFO - 2018-06-25 22:28:20 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:28:20 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:28:20 --> Utf8 Class Initialized
INFO - 2018-06-25 22:28:20 --> URI Class Initialized
INFO - 2018-06-25 22:28:20 --> Router Class Initialized
INFO - 2018-06-25 22:28:20 --> Output Class Initialized
INFO - 2018-06-25 22:28:20 --> Security Class Initialized
DEBUG - 2018-06-25 22:28:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:28:20 --> Input Class Initialized
INFO - 2018-06-25 22:28:20 --> Language Class Initialized
ERROR - 2018-06-25 22:28:20 --> 404 Page Not Found: /index
INFO - 2018-06-25 22:28:20 --> Config Class Initialized
INFO - 2018-06-25 22:28:20 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:28:20 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:28:20 --> Utf8 Class Initialized
INFO - 2018-06-25 22:28:20 --> URI Class Initialized
INFO - 2018-06-25 22:28:20 --> Router Class Initialized
INFO - 2018-06-25 22:28:20 --> Output Class Initialized
INFO - 2018-06-25 22:28:20 --> Security Class Initialized
DEBUG - 2018-06-25 22:28:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:28:20 --> Input Class Initialized
INFO - 2018-06-25 22:28:20 --> Language Class Initialized
ERROR - 2018-06-25 22:28:20 --> 404 Page Not Found: /index
INFO - 2018-06-25 22:28:28 --> Config Class Initialized
INFO - 2018-06-25 22:28:28 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:28:28 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:28:28 --> Utf8 Class Initialized
INFO - 2018-06-25 22:28:28 --> URI Class Initialized
INFO - 2018-06-25 22:28:28 --> Router Class Initialized
INFO - 2018-06-25 22:28:28 --> Output Class Initialized
INFO - 2018-06-25 22:28:28 --> Security Class Initialized
DEBUG - 2018-06-25 22:28:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:28:28 --> Input Class Initialized
INFO - 2018-06-25 22:28:28 --> Language Class Initialized
INFO - 2018-06-25 22:28:28 --> Language Class Initialized
INFO - 2018-06-25 22:28:28 --> Config Class Initialized
INFO - 2018-06-25 22:28:28 --> Loader Class Initialized
DEBUG - 2018-06-25 22:28:28 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-25 22:28:28 --> Helper loaded: url_helper
INFO - 2018-06-25 22:28:28 --> Helper loaded: form_helper
INFO - 2018-06-25 22:28:28 --> Helper loaded: date_helper
INFO - 2018-06-25 22:28:28 --> Helper loaded: util_helper
INFO - 2018-06-25 22:28:28 --> Helper loaded: text_helper
INFO - 2018-06-25 22:28:28 --> Helper loaded: string_helper
INFO - 2018-06-25 22:28:28 --> Database Driver Class Initialized
DEBUG - 2018-06-25 22:28:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-25 22:28:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-25 22:28:28 --> Email Class Initialized
INFO - 2018-06-25 22:28:28 --> Controller Class Initialized
DEBUG - 2018-06-25 22:28:28 --> Home MX_Controller Initialized
DEBUG - 2018-06-25 22:28:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-25 22:28:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-25 22:28:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-25 22:28:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-25 22:28:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-25 22:28:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-25 22:28:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/search_page.php
INFO - 2018-06-25 22:28:28 --> Final output sent to browser
DEBUG - 2018-06-25 22:28:28 --> Total execution time: 0.3951
INFO - 2018-06-25 22:28:28 --> Config Class Initialized
INFO - 2018-06-25 22:28:28 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:28:28 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:28:28 --> Utf8 Class Initialized
INFO - 2018-06-25 22:28:28 --> URI Class Initialized
INFO - 2018-06-25 22:28:28 --> Router Class Initialized
INFO - 2018-06-25 22:28:28 --> Output Class Initialized
INFO - 2018-06-25 22:28:28 --> Security Class Initialized
DEBUG - 2018-06-25 22:28:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:28:29 --> Input Class Initialized
INFO - 2018-06-25 22:28:29 --> Language Class Initialized
ERROR - 2018-06-25 22:28:29 --> 404 Page Not Found: /index
INFO - 2018-06-25 22:28:29 --> Config Class Initialized
INFO - 2018-06-25 22:28:29 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:28:29 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:28:29 --> Utf8 Class Initialized
INFO - 2018-06-25 22:28:29 --> URI Class Initialized
INFO - 2018-06-25 22:28:29 --> Router Class Initialized
INFO - 2018-06-25 22:28:29 --> Output Class Initialized
INFO - 2018-06-25 22:28:29 --> Security Class Initialized
DEBUG - 2018-06-25 22:28:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:28:29 --> Input Class Initialized
INFO - 2018-06-25 22:28:29 --> Language Class Initialized
ERROR - 2018-06-25 22:28:29 --> 404 Page Not Found: /index
INFO - 2018-06-25 22:28:29 --> Config Class Initialized
INFO - 2018-06-25 22:28:29 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:28:29 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:28:29 --> Utf8 Class Initialized
INFO - 2018-06-25 22:28:29 --> URI Class Initialized
INFO - 2018-06-25 22:28:29 --> Router Class Initialized
INFO - 2018-06-25 22:28:29 --> Output Class Initialized
INFO - 2018-06-25 22:28:29 --> Security Class Initialized
DEBUG - 2018-06-25 22:28:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:28:29 --> Input Class Initialized
INFO - 2018-06-25 22:28:29 --> Language Class Initialized
ERROR - 2018-06-25 22:28:29 --> 404 Page Not Found: /index
INFO - 2018-06-25 22:28:33 --> Config Class Initialized
INFO - 2018-06-25 22:28:33 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:28:33 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:28:33 --> Utf8 Class Initialized
INFO - 2018-06-25 22:28:33 --> URI Class Initialized
INFO - 2018-06-25 22:28:33 --> Router Class Initialized
INFO - 2018-06-25 22:28:33 --> Output Class Initialized
INFO - 2018-06-25 22:28:33 --> Security Class Initialized
DEBUG - 2018-06-25 22:28:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:28:33 --> Input Class Initialized
INFO - 2018-06-25 22:28:33 --> Language Class Initialized
INFO - 2018-06-25 22:28:33 --> Language Class Initialized
INFO - 2018-06-25 22:28:33 --> Config Class Initialized
INFO - 2018-06-25 22:28:33 --> Loader Class Initialized
DEBUG - 2018-06-25 22:28:33 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-25 22:28:33 --> Helper loaded: url_helper
INFO - 2018-06-25 22:28:33 --> Helper loaded: form_helper
INFO - 2018-06-25 22:28:33 --> Helper loaded: date_helper
INFO - 2018-06-25 22:28:33 --> Helper loaded: util_helper
INFO - 2018-06-25 22:28:33 --> Helper loaded: text_helper
INFO - 2018-06-25 22:28:33 --> Helper loaded: string_helper
INFO - 2018-06-25 22:28:33 --> Database Driver Class Initialized
DEBUG - 2018-06-25 22:28:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-25 22:28:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-25 22:28:33 --> Email Class Initialized
INFO - 2018-06-25 22:28:33 --> Controller Class Initialized
DEBUG - 2018-06-25 22:28:33 --> Home MX_Controller Initialized
DEBUG - 2018-06-25 22:28:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-25 22:28:33 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-25 22:28:33 --> Login MX_Controller Initialized
INFO - 2018-06-25 22:28:33 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-25 22:28:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-25 22:28:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-25 22:28:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-25 22:28:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-25 22:28:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-25 22:28:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-25 22:28:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-25 22:28:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-06-25 22:28:33 --> Final output sent to browser
DEBUG - 2018-06-25 22:28:33 --> Total execution time: 0.6595
INFO - 2018-06-25 22:28:33 --> Config Class Initialized
INFO - 2018-06-25 22:28:33 --> Config Class Initialized
INFO - 2018-06-25 22:28:33 --> Hooks Class Initialized
INFO - 2018-06-25 22:28:33 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:28:33 --> UTF-8 Support Enabled
DEBUG - 2018-06-25 22:28:33 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:28:33 --> Utf8 Class Initialized
INFO - 2018-06-25 22:28:33 --> Utf8 Class Initialized
INFO - 2018-06-25 22:28:33 --> URI Class Initialized
INFO - 2018-06-25 22:28:34 --> Router Class Initialized
INFO - 2018-06-25 22:28:34 --> URI Class Initialized
INFO - 2018-06-25 22:28:34 --> Output Class Initialized
INFO - 2018-06-25 22:28:34 --> Security Class Initialized
DEBUG - 2018-06-25 22:28:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:28:34 --> Input Class Initialized
INFO - 2018-06-25 22:28:34 --> Language Class Initialized
ERROR - 2018-06-25 22:28:34 --> 404 Page Not Found: /index
INFO - 2018-06-25 22:28:34 --> Config Class Initialized
INFO - 2018-06-25 22:28:34 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:28:34 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:28:34 --> Utf8 Class Initialized
INFO - 2018-06-25 22:28:34 --> URI Class Initialized
INFO - 2018-06-25 22:28:34 --> Router Class Initialized
INFO - 2018-06-25 22:28:34 --> Router Class Initialized
INFO - 2018-06-25 22:28:34 --> Output Class Initialized
INFO - 2018-06-25 22:28:34 --> Output Class Initialized
INFO - 2018-06-25 22:28:34 --> Security Class Initialized
DEBUG - 2018-06-25 22:28:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:28:34 --> Input Class Initialized
INFO - 2018-06-25 22:28:34 --> Language Class Initialized
ERROR - 2018-06-25 22:28:34 --> 404 Page Not Found: /index
INFO - 2018-06-25 22:28:34 --> Config Class Initialized
INFO - 2018-06-25 22:28:34 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:28:34 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:28:34 --> Utf8 Class Initialized
INFO - 2018-06-25 22:28:34 --> Security Class Initialized
INFO - 2018-06-25 22:28:34 --> URI Class Initialized
INFO - 2018-06-25 22:28:34 --> Router Class Initialized
DEBUG - 2018-06-25 22:28:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:28:34 --> Input Class Initialized
INFO - 2018-06-25 22:28:34 --> Output Class Initialized
INFO - 2018-06-25 22:28:34 --> Language Class Initialized
INFO - 2018-06-25 22:28:34 --> Security Class Initialized
ERROR - 2018-06-25 22:28:34 --> 404 Page Not Found: /index
DEBUG - 2018-06-25 22:28:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:28:34 --> Input Class Initialized
INFO - 2018-06-25 22:28:34 --> Language Class Initialized
ERROR - 2018-06-25 22:28:34 --> 404 Page Not Found: /index
INFO - 2018-06-25 22:28:35 --> Config Class Initialized
INFO - 2018-06-25 22:28:35 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:28:35 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:28:35 --> Utf8 Class Initialized
INFO - 2018-06-25 22:28:35 --> URI Class Initialized
INFO - 2018-06-25 22:28:35 --> Router Class Initialized
INFO - 2018-06-25 22:28:35 --> Output Class Initialized
INFO - 2018-06-25 22:28:35 --> Security Class Initialized
DEBUG - 2018-06-25 22:28:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:28:35 --> Input Class Initialized
INFO - 2018-06-25 22:28:35 --> Language Class Initialized
INFO - 2018-06-25 22:28:35 --> Language Class Initialized
INFO - 2018-06-25 22:28:35 --> Config Class Initialized
INFO - 2018-06-25 22:28:35 --> Loader Class Initialized
DEBUG - 2018-06-25 22:28:35 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-25 22:28:35 --> Helper loaded: url_helper
INFO - 2018-06-25 22:28:35 --> Helper loaded: form_helper
INFO - 2018-06-25 22:28:35 --> Helper loaded: date_helper
INFO - 2018-06-25 22:28:35 --> Helper loaded: util_helper
INFO - 2018-06-25 22:28:35 --> Helper loaded: text_helper
INFO - 2018-06-25 22:28:36 --> Helper loaded: string_helper
INFO - 2018-06-25 22:28:36 --> Database Driver Class Initialized
DEBUG - 2018-06-25 22:28:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-25 22:28:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-25 22:28:36 --> Email Class Initialized
INFO - 2018-06-25 22:28:36 --> Controller Class Initialized
DEBUG - 2018-06-25 22:28:36 --> Home MX_Controller Initialized
DEBUG - 2018-06-25 22:28:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-25 22:28:36 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-25 22:28:36 --> Login MX_Controller Initialized
INFO - 2018-06-25 22:28:36 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-25 22:28:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-25 22:28:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-25 22:28:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-25 22:28:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-25 22:28:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-25 22:28:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-25 22:28:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-25 22:28:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-06-25 22:28:36 --> Final output sent to browser
DEBUG - 2018-06-25 22:28:36 --> Total execution time: 0.4990
INFO - 2018-06-25 22:28:36 --> Config Class Initialized
INFO - 2018-06-25 22:28:36 --> Config Class Initialized
INFO - 2018-06-25 22:28:36 --> Hooks Class Initialized
INFO - 2018-06-25 22:28:36 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:28:36 --> UTF-8 Support Enabled
DEBUG - 2018-06-25 22:28:36 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:28:36 --> Utf8 Class Initialized
INFO - 2018-06-25 22:28:36 --> Utf8 Class Initialized
INFO - 2018-06-25 22:28:36 --> URI Class Initialized
INFO - 2018-06-25 22:28:36 --> URI Class Initialized
INFO - 2018-06-25 22:28:36 --> Router Class Initialized
INFO - 2018-06-25 22:28:36 --> Router Class Initialized
INFO - 2018-06-25 22:28:36 --> Output Class Initialized
INFO - 2018-06-25 22:28:36 --> Output Class Initialized
INFO - 2018-06-25 22:28:36 --> Security Class Initialized
INFO - 2018-06-25 22:28:36 --> Security Class Initialized
DEBUG - 2018-06-25 22:28:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-06-25 22:28:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:28:36 --> Input Class Initialized
INFO - 2018-06-25 22:28:36 --> Input Class Initialized
INFO - 2018-06-25 22:28:36 --> Language Class Initialized
INFO - 2018-06-25 22:28:36 --> Language Class Initialized
ERROR - 2018-06-25 22:28:36 --> 404 Page Not Found: /index
ERROR - 2018-06-25 22:28:36 --> 404 Page Not Found: /index
INFO - 2018-06-25 22:28:36 --> Config Class Initialized
INFO - 2018-06-25 22:28:36 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:28:36 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:28:36 --> Utf8 Class Initialized
INFO - 2018-06-25 22:28:36 --> URI Class Initialized
INFO - 2018-06-25 22:28:36 --> Router Class Initialized
INFO - 2018-06-25 22:28:36 --> Output Class Initialized
INFO - 2018-06-25 22:28:36 --> Security Class Initialized
DEBUG - 2018-06-25 22:28:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:28:36 --> Input Class Initialized
INFO - 2018-06-25 22:28:36 --> Language Class Initialized
ERROR - 2018-06-25 22:28:36 --> 404 Page Not Found: /index
INFO - 2018-06-25 22:28:36 --> Config Class Initialized
INFO - 2018-06-25 22:28:36 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:28:36 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:28:36 --> Utf8 Class Initialized
INFO - 2018-06-25 22:28:36 --> URI Class Initialized
INFO - 2018-06-25 22:28:37 --> Router Class Initialized
INFO - 2018-06-25 22:28:37 --> Output Class Initialized
INFO - 2018-06-25 22:28:37 --> Security Class Initialized
DEBUG - 2018-06-25 22:28:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:28:37 --> Input Class Initialized
INFO - 2018-06-25 22:28:37 --> Language Class Initialized
ERROR - 2018-06-25 22:28:37 --> 404 Page Not Found: /index
INFO - 2018-06-25 22:29:32 --> Config Class Initialized
INFO - 2018-06-25 22:29:32 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:29:32 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:29:32 --> Utf8 Class Initialized
INFO - 2018-06-25 22:29:32 --> URI Class Initialized
INFO - 2018-06-25 22:29:32 --> Router Class Initialized
INFO - 2018-06-25 22:29:32 --> Output Class Initialized
INFO - 2018-06-25 22:29:32 --> Security Class Initialized
DEBUG - 2018-06-25 22:29:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:29:32 --> Input Class Initialized
INFO - 2018-06-25 22:29:32 --> Language Class Initialized
INFO - 2018-06-25 22:29:32 --> Language Class Initialized
INFO - 2018-06-25 22:29:32 --> Config Class Initialized
INFO - 2018-06-25 22:29:32 --> Loader Class Initialized
DEBUG - 2018-06-25 22:29:32 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-25 22:29:32 --> Helper loaded: url_helper
INFO - 2018-06-25 22:29:32 --> Helper loaded: form_helper
INFO - 2018-06-25 22:29:32 --> Helper loaded: date_helper
INFO - 2018-06-25 22:29:32 --> Helper loaded: util_helper
INFO - 2018-06-25 22:29:32 --> Helper loaded: text_helper
INFO - 2018-06-25 22:29:32 --> Helper loaded: string_helper
INFO - 2018-06-25 22:29:33 --> Database Driver Class Initialized
DEBUG - 2018-06-25 22:29:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-25 22:29:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-25 22:29:33 --> Email Class Initialized
INFO - 2018-06-25 22:29:33 --> Controller Class Initialized
DEBUG - 2018-06-25 22:29:33 --> Home MX_Controller Initialized
DEBUG - 2018-06-25 22:29:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-25 22:29:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-25 22:29:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-25 22:29:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-25 22:29:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-25 22:29:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-25 22:29:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/search_page.php
INFO - 2018-06-25 22:29:33 --> Final output sent to browser
DEBUG - 2018-06-25 22:29:33 --> Total execution time: 0.4100
INFO - 2018-06-25 22:29:33 --> Config Class Initialized
INFO - 2018-06-25 22:29:33 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:29:33 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:29:33 --> Utf8 Class Initialized
INFO - 2018-06-25 22:29:33 --> URI Class Initialized
INFO - 2018-06-25 22:29:33 --> Router Class Initialized
INFO - 2018-06-25 22:29:33 --> Output Class Initialized
INFO - 2018-06-25 22:29:33 --> Security Class Initialized
DEBUG - 2018-06-25 22:29:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:29:33 --> Input Class Initialized
INFO - 2018-06-25 22:29:33 --> Language Class Initialized
ERROR - 2018-06-25 22:29:33 --> 404 Page Not Found: /index
INFO - 2018-06-25 22:29:33 --> Config Class Initialized
INFO - 2018-06-25 22:29:33 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:29:33 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:29:33 --> Utf8 Class Initialized
INFO - 2018-06-25 22:29:33 --> URI Class Initialized
INFO - 2018-06-25 22:29:33 --> Router Class Initialized
INFO - 2018-06-25 22:29:33 --> Output Class Initialized
INFO - 2018-06-25 22:29:33 --> Security Class Initialized
DEBUG - 2018-06-25 22:29:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:29:33 --> Input Class Initialized
INFO - 2018-06-25 22:29:33 --> Language Class Initialized
ERROR - 2018-06-25 22:29:33 --> 404 Page Not Found: /index
INFO - 2018-06-25 22:29:33 --> Config Class Initialized
INFO - 2018-06-25 22:29:33 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:29:33 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:29:33 --> Utf8 Class Initialized
INFO - 2018-06-25 22:29:33 --> URI Class Initialized
INFO - 2018-06-25 22:29:33 --> Router Class Initialized
INFO - 2018-06-25 22:29:33 --> Output Class Initialized
INFO - 2018-06-25 22:29:33 --> Security Class Initialized
DEBUG - 2018-06-25 22:29:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:29:33 --> Input Class Initialized
INFO - 2018-06-25 22:29:33 --> Language Class Initialized
ERROR - 2018-06-25 22:29:33 --> 404 Page Not Found: /index
INFO - 2018-06-25 22:29:33 --> Config Class Initialized
INFO - 2018-06-25 22:29:33 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:29:33 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:29:34 --> Utf8 Class Initialized
INFO - 2018-06-25 22:29:34 --> URI Class Initialized
INFO - 2018-06-25 22:29:34 --> Router Class Initialized
INFO - 2018-06-25 22:29:34 --> Output Class Initialized
INFO - 2018-06-25 22:29:34 --> Security Class Initialized
DEBUG - 2018-06-25 22:29:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:29:34 --> Input Class Initialized
INFO - 2018-06-25 22:29:34 --> Language Class Initialized
ERROR - 2018-06-25 22:29:34 --> 404 Page Not Found: /index
INFO - 2018-06-25 22:29:34 --> Config Class Initialized
INFO - 2018-06-25 22:29:34 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:29:34 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:29:34 --> Utf8 Class Initialized
INFO - 2018-06-25 22:29:34 --> URI Class Initialized
INFO - 2018-06-25 22:29:34 --> Router Class Initialized
INFO - 2018-06-25 22:29:34 --> Output Class Initialized
INFO - 2018-06-25 22:29:34 --> Security Class Initialized
DEBUG - 2018-06-25 22:29:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:29:34 --> Input Class Initialized
INFO - 2018-06-25 22:29:34 --> Language Class Initialized
ERROR - 2018-06-25 22:29:34 --> 404 Page Not Found: /index
INFO - 2018-06-25 22:29:34 --> Config Class Initialized
INFO - 2018-06-25 22:29:34 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:29:34 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:29:34 --> Utf8 Class Initialized
INFO - 2018-06-25 22:29:34 --> URI Class Initialized
INFO - 2018-06-25 22:29:34 --> Router Class Initialized
INFO - 2018-06-25 22:29:34 --> Output Class Initialized
INFO - 2018-06-25 22:29:34 --> Security Class Initialized
DEBUG - 2018-06-25 22:29:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:29:34 --> Input Class Initialized
INFO - 2018-06-25 22:29:34 --> Language Class Initialized
ERROR - 2018-06-25 22:29:34 --> 404 Page Not Found: /index
INFO - 2018-06-25 22:29:46 --> Config Class Initialized
INFO - 2018-06-25 22:29:46 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:29:46 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:29:46 --> Utf8 Class Initialized
INFO - 2018-06-25 22:29:46 --> URI Class Initialized
INFO - 2018-06-25 22:29:46 --> Router Class Initialized
INFO - 2018-06-25 22:29:46 --> Output Class Initialized
INFO - 2018-06-25 22:29:46 --> Security Class Initialized
DEBUG - 2018-06-25 22:29:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:29:46 --> Input Class Initialized
INFO - 2018-06-25 22:29:46 --> Language Class Initialized
INFO - 2018-06-25 22:29:46 --> Language Class Initialized
INFO - 2018-06-25 22:29:46 --> Config Class Initialized
INFO - 2018-06-25 22:29:46 --> Loader Class Initialized
DEBUG - 2018-06-25 22:29:46 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-25 22:29:46 --> Helper loaded: url_helper
INFO - 2018-06-25 22:29:46 --> Helper loaded: form_helper
INFO - 2018-06-25 22:29:46 --> Helper loaded: date_helper
INFO - 2018-06-25 22:29:46 --> Helper loaded: util_helper
INFO - 2018-06-25 22:29:46 --> Helper loaded: text_helper
INFO - 2018-06-25 22:29:46 --> Helper loaded: string_helper
INFO - 2018-06-25 22:29:47 --> Database Driver Class Initialized
DEBUG - 2018-06-25 22:29:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-25 22:29:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-25 22:29:47 --> Email Class Initialized
INFO - 2018-06-25 22:29:47 --> Controller Class Initialized
DEBUG - 2018-06-25 22:29:47 --> Home MX_Controller Initialized
DEBUG - 2018-06-25 22:29:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-25 22:29:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-25 22:29:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-25 22:29:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-25 22:29:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-25 22:29:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-25 22:29:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/search_page.php
INFO - 2018-06-25 22:29:47 --> Final output sent to browser
DEBUG - 2018-06-25 22:29:47 --> Total execution time: 0.4040
INFO - 2018-06-25 22:29:47 --> Config Class Initialized
INFO - 2018-06-25 22:29:47 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:29:47 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:29:47 --> Utf8 Class Initialized
INFO - 2018-06-25 22:29:47 --> URI Class Initialized
INFO - 2018-06-25 22:29:47 --> Router Class Initialized
INFO - 2018-06-25 22:29:47 --> Output Class Initialized
INFO - 2018-06-25 22:29:47 --> Security Class Initialized
DEBUG - 2018-06-25 22:29:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:29:47 --> Input Class Initialized
INFO - 2018-06-25 22:29:47 --> Language Class Initialized
ERROR - 2018-06-25 22:29:47 --> 404 Page Not Found: /index
INFO - 2018-06-25 22:29:47 --> Config Class Initialized
INFO - 2018-06-25 22:29:47 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:29:47 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:29:47 --> Utf8 Class Initialized
INFO - 2018-06-25 22:29:47 --> URI Class Initialized
INFO - 2018-06-25 22:29:47 --> Router Class Initialized
INFO - 2018-06-25 22:29:47 --> Output Class Initialized
INFO - 2018-06-25 22:29:47 --> Security Class Initialized
DEBUG - 2018-06-25 22:29:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:29:47 --> Input Class Initialized
INFO - 2018-06-25 22:29:47 --> Language Class Initialized
ERROR - 2018-06-25 22:29:47 --> 404 Page Not Found: /index
INFO - 2018-06-25 22:29:47 --> Config Class Initialized
INFO - 2018-06-25 22:29:47 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:29:47 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:29:47 --> Utf8 Class Initialized
INFO - 2018-06-25 22:29:47 --> URI Class Initialized
INFO - 2018-06-25 22:29:47 --> Router Class Initialized
INFO - 2018-06-25 22:29:47 --> Output Class Initialized
INFO - 2018-06-25 22:29:47 --> Security Class Initialized
DEBUG - 2018-06-25 22:29:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:29:47 --> Input Class Initialized
INFO - 2018-06-25 22:29:47 --> Language Class Initialized
ERROR - 2018-06-25 22:29:47 --> 404 Page Not Found: /index
INFO - 2018-06-25 22:29:47 --> Config Class Initialized
INFO - 2018-06-25 22:29:47 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:29:47 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:29:47 --> Utf8 Class Initialized
INFO - 2018-06-25 22:29:47 --> URI Class Initialized
INFO - 2018-06-25 22:29:48 --> Router Class Initialized
INFO - 2018-06-25 22:29:48 --> Output Class Initialized
INFO - 2018-06-25 22:29:48 --> Security Class Initialized
DEBUG - 2018-06-25 22:29:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:29:48 --> Input Class Initialized
INFO - 2018-06-25 22:29:48 --> Language Class Initialized
ERROR - 2018-06-25 22:29:48 --> 404 Page Not Found: /index
INFO - 2018-06-25 22:29:48 --> Config Class Initialized
INFO - 2018-06-25 22:29:48 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:29:48 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:29:48 --> Utf8 Class Initialized
INFO - 2018-06-25 22:29:48 --> URI Class Initialized
INFO - 2018-06-25 22:29:48 --> Router Class Initialized
INFO - 2018-06-25 22:29:48 --> Output Class Initialized
INFO - 2018-06-25 22:29:48 --> Security Class Initialized
DEBUG - 2018-06-25 22:29:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:29:48 --> Input Class Initialized
INFO - 2018-06-25 22:29:48 --> Language Class Initialized
ERROR - 2018-06-25 22:29:48 --> 404 Page Not Found: /index
INFO - 2018-06-25 22:29:48 --> Config Class Initialized
INFO - 2018-06-25 22:29:48 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:29:48 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:29:48 --> Utf8 Class Initialized
INFO - 2018-06-25 22:29:48 --> URI Class Initialized
INFO - 2018-06-25 22:29:48 --> Router Class Initialized
INFO - 2018-06-25 22:29:48 --> Output Class Initialized
INFO - 2018-06-25 22:29:48 --> Security Class Initialized
DEBUG - 2018-06-25 22:29:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:29:48 --> Input Class Initialized
INFO - 2018-06-25 22:29:48 --> Language Class Initialized
ERROR - 2018-06-25 22:29:48 --> 404 Page Not Found: /index
INFO - 2018-06-25 22:30:04 --> Config Class Initialized
INFO - 2018-06-25 22:30:04 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:30:04 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:30:04 --> Utf8 Class Initialized
INFO - 2018-06-25 22:30:04 --> URI Class Initialized
DEBUG - 2018-06-25 22:30:04 --> No URI present. Default controller set.
INFO - 2018-06-25 22:30:04 --> Router Class Initialized
INFO - 2018-06-25 22:30:04 --> Output Class Initialized
INFO - 2018-06-25 22:30:04 --> Security Class Initialized
DEBUG - 2018-06-25 22:30:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:30:04 --> Input Class Initialized
INFO - 2018-06-25 22:30:04 --> Language Class Initialized
INFO - 2018-06-25 22:30:04 --> Language Class Initialized
INFO - 2018-06-25 22:30:04 --> Config Class Initialized
INFO - 2018-06-25 22:30:04 --> Loader Class Initialized
DEBUG - 2018-06-25 22:30:04 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-25 22:30:04 --> Helper loaded: url_helper
INFO - 2018-06-25 22:30:04 --> Helper loaded: form_helper
INFO - 2018-06-25 22:30:04 --> Helper loaded: date_helper
INFO - 2018-06-25 22:30:04 --> Helper loaded: util_helper
INFO - 2018-06-25 22:30:04 --> Helper loaded: text_helper
INFO - 2018-06-25 22:30:04 --> Helper loaded: string_helper
INFO - 2018-06-25 22:30:04 --> Database Driver Class Initialized
DEBUG - 2018-06-25 22:30:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-25 22:30:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-25 22:30:04 --> Email Class Initialized
INFO - 2018-06-25 22:30:04 --> Controller Class Initialized
DEBUG - 2018-06-25 22:30:04 --> Home MX_Controller Initialized
DEBUG - 2018-06-25 22:30:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-25 22:30:04 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-25 22:30:04 --> Login MX_Controller Initialized
INFO - 2018-06-25 22:30:04 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-25 22:30:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-25 22:30:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-25 22:30:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-25 22:30:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-25 22:30:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-25 22:30:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-25 22:30:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-25 22:30:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-06-25 22:30:04 --> Final output sent to browser
DEBUG - 2018-06-25 22:30:04 --> Total execution time: 0.4771
INFO - 2018-06-25 22:30:04 --> Config Class Initialized
INFO - 2018-06-25 22:30:04 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:30:04 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:30:04 --> Utf8 Class Initialized
INFO - 2018-06-25 22:30:04 --> URI Class Initialized
INFO - 2018-06-25 22:30:04 --> Router Class Initialized
INFO - 2018-06-25 22:30:04 --> Output Class Initialized
INFO - 2018-06-25 22:30:04 --> Security Class Initialized
DEBUG - 2018-06-25 22:30:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:30:04 --> Input Class Initialized
INFO - 2018-06-25 22:30:04 --> Language Class Initialized
ERROR - 2018-06-25 22:30:04 --> 404 Page Not Found: /index
INFO - 2018-06-25 22:30:04 --> Config Class Initialized
INFO - 2018-06-25 22:30:05 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:30:05 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:30:05 --> Utf8 Class Initialized
INFO - 2018-06-25 22:30:05 --> URI Class Initialized
INFO - 2018-06-25 22:30:05 --> Router Class Initialized
INFO - 2018-06-25 22:30:05 --> Output Class Initialized
INFO - 2018-06-25 22:30:05 --> Security Class Initialized
DEBUG - 2018-06-25 22:30:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:30:05 --> Input Class Initialized
INFO - 2018-06-25 22:30:05 --> Language Class Initialized
ERROR - 2018-06-25 22:30:05 --> 404 Page Not Found: /index
INFO - 2018-06-25 22:30:05 --> Config Class Initialized
INFO - 2018-06-25 22:30:05 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:30:05 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:30:05 --> Utf8 Class Initialized
INFO - 2018-06-25 22:30:05 --> URI Class Initialized
INFO - 2018-06-25 22:30:05 --> Router Class Initialized
INFO - 2018-06-25 22:30:05 --> Output Class Initialized
INFO - 2018-06-25 22:30:05 --> Security Class Initialized
DEBUG - 2018-06-25 22:30:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:30:05 --> Input Class Initialized
INFO - 2018-06-25 22:30:05 --> Language Class Initialized
ERROR - 2018-06-25 22:30:05 --> 404 Page Not Found: /index
INFO - 2018-06-25 22:30:08 --> Config Class Initialized
INFO - 2018-06-25 22:30:09 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:30:09 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:30:09 --> Utf8 Class Initialized
INFO - 2018-06-25 22:30:09 --> URI Class Initialized
INFO - 2018-06-25 22:30:09 --> Router Class Initialized
INFO - 2018-06-25 22:30:09 --> Output Class Initialized
INFO - 2018-06-25 22:30:09 --> Security Class Initialized
DEBUG - 2018-06-25 22:30:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:30:09 --> Input Class Initialized
INFO - 2018-06-25 22:30:09 --> Language Class Initialized
INFO - 2018-06-25 22:30:09 --> Language Class Initialized
INFO - 2018-06-25 22:30:09 --> Config Class Initialized
INFO - 2018-06-25 22:30:09 --> Loader Class Initialized
DEBUG - 2018-06-25 22:30:09 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-25 22:30:09 --> Helper loaded: url_helper
INFO - 2018-06-25 22:30:09 --> Helper loaded: form_helper
INFO - 2018-06-25 22:30:09 --> Helper loaded: date_helper
INFO - 2018-06-25 22:30:09 --> Helper loaded: util_helper
INFO - 2018-06-25 22:30:09 --> Helper loaded: text_helper
INFO - 2018-06-25 22:30:09 --> Helper loaded: string_helper
INFO - 2018-06-25 22:30:09 --> Database Driver Class Initialized
DEBUG - 2018-06-25 22:30:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-25 22:30:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-25 22:30:09 --> Email Class Initialized
INFO - 2018-06-25 22:30:09 --> Controller Class Initialized
DEBUG - 2018-06-25 22:30:09 --> Home MX_Controller Initialized
DEBUG - 2018-06-25 22:30:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-25 22:30:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-25 22:30:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-25 22:30:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-25 22:30:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-25 22:30:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-25 22:30:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/search_page.php
INFO - 2018-06-25 22:30:09 --> Final output sent to browser
DEBUG - 2018-06-25 22:30:09 --> Total execution time: 0.5159
INFO - 2018-06-25 22:30:09 --> Config Class Initialized
INFO - 2018-06-25 22:30:09 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:30:09 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:30:09 --> Utf8 Class Initialized
INFO - 2018-06-25 22:30:09 --> URI Class Initialized
INFO - 2018-06-25 22:30:09 --> Router Class Initialized
INFO - 2018-06-25 22:30:09 --> Output Class Initialized
INFO - 2018-06-25 22:30:09 --> Security Class Initialized
DEBUG - 2018-06-25 22:30:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:30:09 --> Input Class Initialized
INFO - 2018-06-25 22:30:09 --> Language Class Initialized
ERROR - 2018-06-25 22:30:09 --> 404 Page Not Found: /index
INFO - 2018-06-25 22:30:09 --> Config Class Initialized
INFO - 2018-06-25 22:30:09 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:30:09 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:30:09 --> Utf8 Class Initialized
INFO - 2018-06-25 22:30:09 --> URI Class Initialized
INFO - 2018-06-25 22:30:09 --> Router Class Initialized
INFO - 2018-06-25 22:30:09 --> Output Class Initialized
INFO - 2018-06-25 22:30:09 --> Security Class Initialized
DEBUG - 2018-06-25 22:30:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:30:09 --> Input Class Initialized
INFO - 2018-06-25 22:30:09 --> Language Class Initialized
ERROR - 2018-06-25 22:30:09 --> 404 Page Not Found: /index
INFO - 2018-06-25 22:30:09 --> Config Class Initialized
INFO - 2018-06-25 22:30:10 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:30:10 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:30:10 --> Utf8 Class Initialized
INFO - 2018-06-25 22:30:10 --> URI Class Initialized
INFO - 2018-06-25 22:30:10 --> Router Class Initialized
INFO - 2018-06-25 22:30:10 --> Output Class Initialized
INFO - 2018-06-25 22:30:10 --> Security Class Initialized
DEBUG - 2018-06-25 22:30:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:30:10 --> Input Class Initialized
INFO - 2018-06-25 22:30:10 --> Language Class Initialized
ERROR - 2018-06-25 22:30:10 --> 404 Page Not Found: /index
INFO - 2018-06-25 22:30:13 --> Config Class Initialized
INFO - 2018-06-25 22:30:14 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:30:14 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:30:14 --> Utf8 Class Initialized
INFO - 2018-06-25 22:30:14 --> URI Class Initialized
INFO - 2018-06-25 22:30:14 --> Router Class Initialized
INFO - 2018-06-25 22:30:14 --> Output Class Initialized
INFO - 2018-06-25 22:30:14 --> Security Class Initialized
DEBUG - 2018-06-25 22:30:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:30:14 --> Input Class Initialized
INFO - 2018-06-25 22:30:14 --> Language Class Initialized
INFO - 2018-06-25 22:30:14 --> Language Class Initialized
INFO - 2018-06-25 22:30:14 --> Config Class Initialized
INFO - 2018-06-25 22:30:14 --> Loader Class Initialized
DEBUG - 2018-06-25 22:30:14 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-25 22:30:14 --> Helper loaded: url_helper
INFO - 2018-06-25 22:30:14 --> Helper loaded: form_helper
INFO - 2018-06-25 22:30:14 --> Helper loaded: date_helper
INFO - 2018-06-25 22:30:14 --> Helper loaded: util_helper
INFO - 2018-06-25 22:30:14 --> Helper loaded: text_helper
INFO - 2018-06-25 22:30:14 --> Helper loaded: string_helper
INFO - 2018-06-25 22:30:14 --> Database Driver Class Initialized
DEBUG - 2018-06-25 22:30:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-25 22:30:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-25 22:30:14 --> Email Class Initialized
INFO - 2018-06-25 22:30:14 --> Controller Class Initialized
DEBUG - 2018-06-25 22:30:14 --> Home MX_Controller Initialized
DEBUG - 2018-06-25 22:30:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-25 22:30:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-25 22:30:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-25 22:30:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-25 22:30:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-25 22:30:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-25 22:30:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/search_page.php
INFO - 2018-06-25 22:30:14 --> Final output sent to browser
DEBUG - 2018-06-25 22:30:14 --> Total execution time: 0.4988
INFO - 2018-06-25 22:30:14 --> Config Class Initialized
INFO - 2018-06-25 22:30:14 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:30:14 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:30:14 --> Utf8 Class Initialized
INFO - 2018-06-25 22:30:14 --> URI Class Initialized
INFO - 2018-06-25 22:30:14 --> Router Class Initialized
INFO - 2018-06-25 22:30:14 --> Output Class Initialized
INFO - 2018-06-25 22:30:14 --> Security Class Initialized
DEBUG - 2018-06-25 22:30:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:30:14 --> Input Class Initialized
INFO - 2018-06-25 22:30:14 --> Language Class Initialized
ERROR - 2018-06-25 22:30:14 --> 404 Page Not Found: /index
INFO - 2018-06-25 22:30:14 --> Config Class Initialized
INFO - 2018-06-25 22:30:14 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:30:14 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:30:14 --> Utf8 Class Initialized
INFO - 2018-06-25 22:30:14 --> URI Class Initialized
INFO - 2018-06-25 22:30:14 --> Router Class Initialized
INFO - 2018-06-25 22:30:14 --> Output Class Initialized
INFO - 2018-06-25 22:30:14 --> Security Class Initialized
DEBUG - 2018-06-25 22:30:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:30:14 --> Input Class Initialized
INFO - 2018-06-25 22:30:14 --> Language Class Initialized
ERROR - 2018-06-25 22:30:14 --> 404 Page Not Found: /index
INFO - 2018-06-25 22:30:15 --> Config Class Initialized
INFO - 2018-06-25 22:30:15 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:30:15 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:30:15 --> Utf8 Class Initialized
INFO - 2018-06-25 22:30:15 --> URI Class Initialized
INFO - 2018-06-25 22:30:15 --> Router Class Initialized
INFO - 2018-06-25 22:30:15 --> Output Class Initialized
INFO - 2018-06-25 22:30:15 --> Security Class Initialized
DEBUG - 2018-06-25 22:30:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:30:15 --> Input Class Initialized
INFO - 2018-06-25 22:30:15 --> Language Class Initialized
ERROR - 2018-06-25 22:30:15 --> 404 Page Not Found: /index
INFO - 2018-06-25 22:30:16 --> Config Class Initialized
INFO - 2018-06-25 22:30:16 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:30:16 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:30:17 --> Utf8 Class Initialized
INFO - 2018-06-25 22:30:17 --> URI Class Initialized
DEBUG - 2018-06-25 22:30:17 --> No URI present. Default controller set.
INFO - 2018-06-25 22:30:17 --> Router Class Initialized
INFO - 2018-06-25 22:30:17 --> Output Class Initialized
INFO - 2018-06-25 22:30:17 --> Security Class Initialized
DEBUG - 2018-06-25 22:30:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:30:17 --> Input Class Initialized
INFO - 2018-06-25 22:30:17 --> Language Class Initialized
INFO - 2018-06-25 22:30:17 --> Language Class Initialized
INFO - 2018-06-25 22:30:17 --> Config Class Initialized
INFO - 2018-06-25 22:30:17 --> Loader Class Initialized
DEBUG - 2018-06-25 22:30:17 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-25 22:30:17 --> Helper loaded: url_helper
INFO - 2018-06-25 22:30:17 --> Helper loaded: form_helper
INFO - 2018-06-25 22:30:17 --> Helper loaded: date_helper
INFO - 2018-06-25 22:30:17 --> Helper loaded: util_helper
INFO - 2018-06-25 22:30:17 --> Helper loaded: text_helper
INFO - 2018-06-25 22:30:17 --> Helper loaded: string_helper
INFO - 2018-06-25 22:30:17 --> Database Driver Class Initialized
DEBUG - 2018-06-25 22:30:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-25 22:30:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-25 22:30:17 --> Email Class Initialized
INFO - 2018-06-25 22:30:17 --> Controller Class Initialized
DEBUG - 2018-06-25 22:30:17 --> Home MX_Controller Initialized
DEBUG - 2018-06-25 22:30:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-25 22:30:17 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-25 22:30:17 --> Login MX_Controller Initialized
INFO - 2018-06-25 22:30:17 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-25 22:30:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-25 22:30:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-25 22:30:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-25 22:30:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-25 22:30:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-25 22:30:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-25 22:30:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-25 22:30:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-06-25 22:30:17 --> Final output sent to browser
DEBUG - 2018-06-25 22:30:17 --> Total execution time: 0.4976
INFO - 2018-06-25 22:30:17 --> Config Class Initialized
INFO - 2018-06-25 22:30:17 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:30:17 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:30:17 --> Utf8 Class Initialized
INFO - 2018-06-25 22:30:17 --> URI Class Initialized
INFO - 2018-06-25 22:30:17 --> Router Class Initialized
INFO - 2018-06-25 22:30:17 --> Output Class Initialized
INFO - 2018-06-25 22:30:17 --> Security Class Initialized
DEBUG - 2018-06-25 22:30:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:30:17 --> Input Class Initialized
INFO - 2018-06-25 22:30:17 --> Language Class Initialized
ERROR - 2018-06-25 22:30:17 --> 404 Page Not Found: /index
INFO - 2018-06-25 22:30:17 --> Config Class Initialized
INFO - 2018-06-25 22:30:17 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:30:17 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:30:17 --> Utf8 Class Initialized
INFO - 2018-06-25 22:30:17 --> URI Class Initialized
INFO - 2018-06-25 22:30:17 --> Router Class Initialized
INFO - 2018-06-25 22:30:17 --> Output Class Initialized
INFO - 2018-06-25 22:30:17 --> Security Class Initialized
DEBUG - 2018-06-25 22:30:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:30:17 --> Input Class Initialized
INFO - 2018-06-25 22:30:17 --> Language Class Initialized
ERROR - 2018-06-25 22:30:17 --> 404 Page Not Found: /index
INFO - 2018-06-25 22:30:17 --> Config Class Initialized
INFO - 2018-06-25 22:30:17 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:30:18 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:30:18 --> Utf8 Class Initialized
INFO - 2018-06-25 22:30:18 --> URI Class Initialized
INFO - 2018-06-25 22:30:18 --> Router Class Initialized
INFO - 2018-06-25 22:30:18 --> Output Class Initialized
INFO - 2018-06-25 22:30:18 --> Security Class Initialized
DEBUG - 2018-06-25 22:30:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:30:18 --> Input Class Initialized
INFO - 2018-06-25 22:30:18 --> Language Class Initialized
ERROR - 2018-06-25 22:30:18 --> 404 Page Not Found: /index
INFO - 2018-06-25 22:40:27 --> Config Class Initialized
INFO - 2018-06-25 22:40:28 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:40:28 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:40:28 --> Utf8 Class Initialized
INFO - 2018-06-25 22:40:28 --> URI Class Initialized
DEBUG - 2018-06-25 22:40:28 --> No URI present. Default controller set.
INFO - 2018-06-25 22:40:28 --> Router Class Initialized
INFO - 2018-06-25 22:40:28 --> Output Class Initialized
INFO - 2018-06-25 22:40:28 --> Security Class Initialized
DEBUG - 2018-06-25 22:40:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:40:28 --> Input Class Initialized
INFO - 2018-06-25 22:40:28 --> Language Class Initialized
INFO - 2018-06-25 22:40:28 --> Language Class Initialized
INFO - 2018-06-25 22:40:28 --> Config Class Initialized
INFO - 2018-06-25 22:40:28 --> Loader Class Initialized
DEBUG - 2018-06-25 22:40:28 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-25 22:40:28 --> Helper loaded: url_helper
INFO - 2018-06-25 22:40:28 --> Helper loaded: form_helper
INFO - 2018-06-25 22:40:28 --> Helper loaded: date_helper
INFO - 2018-06-25 22:40:28 --> Helper loaded: util_helper
INFO - 2018-06-25 22:40:28 --> Helper loaded: text_helper
INFO - 2018-06-25 22:40:28 --> Helper loaded: string_helper
INFO - 2018-06-25 22:40:28 --> Database Driver Class Initialized
DEBUG - 2018-06-25 22:40:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-25 22:40:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-25 22:40:28 --> Email Class Initialized
INFO - 2018-06-25 22:40:28 --> Controller Class Initialized
DEBUG - 2018-06-25 22:40:28 --> Home MX_Controller Initialized
DEBUG - 2018-06-25 22:40:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-25 22:40:28 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-25 22:40:28 --> Login MX_Controller Initialized
INFO - 2018-06-25 22:40:28 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-25 22:40:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-25 22:40:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-25 22:40:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-25 22:40:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-25 22:40:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-25 22:40:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-25 22:40:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-25 22:40:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-06-25 22:40:28 --> Final output sent to browser
DEBUG - 2018-06-25 22:40:28 --> Total execution time: 0.5111
INFO - 2018-06-25 22:44:05 --> Config Class Initialized
INFO - 2018-06-25 22:44:05 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:44:05 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:44:05 --> Utf8 Class Initialized
INFO - 2018-06-25 22:44:05 --> URI Class Initialized
INFO - 2018-06-25 22:44:05 --> Router Class Initialized
INFO - 2018-06-25 22:44:05 --> Output Class Initialized
INFO - 2018-06-25 22:44:05 --> Security Class Initialized
DEBUG - 2018-06-25 22:44:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:44:05 --> Input Class Initialized
INFO - 2018-06-25 22:44:05 --> Config Class Initialized
INFO - 2018-06-25 22:44:05 --> Hooks Class Initialized
INFO - 2018-06-25 22:44:05 --> Language Class Initialized
DEBUG - 2018-06-25 22:44:05 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:44:05 --> Utf8 Class Initialized
INFO - 2018-06-25 22:44:05 --> URI Class Initialized
INFO - 2018-06-25 22:44:05 --> Router Class Initialized
INFO - 2018-06-25 22:44:05 --> Output Class Initialized
ERROR - 2018-06-25 22:44:05 --> 404 Page Not Found: /index
INFO - 2018-06-25 22:44:05 --> Security Class Initialized
DEBUG - 2018-06-25 22:44:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:44:05 --> Input Class Initialized
INFO - 2018-06-25 22:44:06 --> Language Class Initialized
ERROR - 2018-06-25 22:44:06 --> 404 Page Not Found: /index
INFO - 2018-06-25 22:44:06 --> Config Class Initialized
INFO - 2018-06-25 22:44:06 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:44:06 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:44:06 --> Utf8 Class Initialized
INFO - 2018-06-25 22:44:06 --> URI Class Initialized
INFO - 2018-06-25 22:44:06 --> Router Class Initialized
INFO - 2018-06-25 22:44:06 --> Output Class Initialized
INFO - 2018-06-25 22:44:06 --> Security Class Initialized
DEBUG - 2018-06-25 22:44:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:44:06 --> Input Class Initialized
INFO - 2018-06-25 22:44:06 --> Language Class Initialized
ERROR - 2018-06-25 22:44:06 --> 404 Page Not Found: /index
INFO - 2018-06-25 22:44:06 --> Config Class Initialized
INFO - 2018-06-25 22:44:06 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:44:06 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:44:06 --> Utf8 Class Initialized
INFO - 2018-06-25 22:44:06 --> URI Class Initialized
INFO - 2018-06-25 22:44:06 --> Router Class Initialized
INFO - 2018-06-25 22:44:06 --> Output Class Initialized
INFO - 2018-06-25 22:44:06 --> Security Class Initialized
DEBUG - 2018-06-25 22:44:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:44:06 --> Input Class Initialized
INFO - 2018-06-25 22:44:06 --> Language Class Initialized
ERROR - 2018-06-25 22:44:06 --> 404 Page Not Found: /index
INFO - 2018-06-25 22:49:36 --> Config Class Initialized
INFO - 2018-06-25 22:49:36 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:49:36 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:49:36 --> Utf8 Class Initialized
INFO - 2018-06-25 22:49:36 --> URI Class Initialized
INFO - 2018-06-25 22:49:36 --> Router Class Initialized
INFO - 2018-06-25 22:49:36 --> Output Class Initialized
INFO - 2018-06-25 22:49:36 --> Security Class Initialized
DEBUG - 2018-06-25 22:49:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:49:36 --> Input Class Initialized
INFO - 2018-06-25 22:49:37 --> Language Class Initialized
ERROR - 2018-06-25 22:49:37 --> 404 Page Not Found: /index
INFO - 2018-06-25 22:49:37 --> Config Class Initialized
INFO - 2018-06-25 22:49:37 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:49:37 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:49:37 --> Utf8 Class Initialized
INFO - 2018-06-25 22:49:37 --> URI Class Initialized
INFO - 2018-06-25 22:49:37 --> Router Class Initialized
INFO - 2018-06-25 22:49:37 --> Output Class Initialized
INFO - 2018-06-25 22:49:37 --> Security Class Initialized
DEBUG - 2018-06-25 22:49:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:49:37 --> Input Class Initialized
INFO - 2018-06-25 22:49:37 --> Language Class Initialized
ERROR - 2018-06-25 22:49:37 --> 404 Page Not Found: /index
INFO - 2018-06-25 22:49:37 --> Config Class Initialized
INFO - 2018-06-25 22:49:37 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:49:37 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:49:37 --> Utf8 Class Initialized
INFO - 2018-06-25 22:49:37 --> URI Class Initialized
INFO - 2018-06-25 22:49:37 --> Router Class Initialized
INFO - 2018-06-25 22:49:37 --> Output Class Initialized
INFO - 2018-06-25 22:49:37 --> Security Class Initialized
DEBUG - 2018-06-25 22:49:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:49:37 --> Input Class Initialized
INFO - 2018-06-25 22:49:37 --> Language Class Initialized
ERROR - 2018-06-25 22:49:37 --> 404 Page Not Found: /index
INFO - 2018-06-25 22:49:37 --> Config Class Initialized
INFO - 2018-06-25 22:49:37 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:49:37 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:49:37 --> Utf8 Class Initialized
INFO - 2018-06-25 22:49:37 --> URI Class Initialized
INFO - 2018-06-25 22:49:37 --> Router Class Initialized
INFO - 2018-06-25 22:49:37 --> Output Class Initialized
INFO - 2018-06-25 22:49:37 --> Security Class Initialized
DEBUG - 2018-06-25 22:49:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:49:37 --> Input Class Initialized
INFO - 2018-06-25 22:49:37 --> Language Class Initialized
ERROR - 2018-06-25 22:49:37 --> 404 Page Not Found: /index
INFO - 2018-06-25 22:53:55 --> Config Class Initialized
INFO - 2018-06-25 22:53:55 --> Config Class Initialized
INFO - 2018-06-25 22:53:55 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:53:55 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:53:55 --> Utf8 Class Initialized
INFO - 2018-06-25 22:53:55 --> URI Class Initialized
INFO - 2018-06-25 22:53:55 --> Router Class Initialized
INFO - 2018-06-25 22:53:55 --> Output Class Initialized
INFO - 2018-06-25 22:53:55 --> Security Class Initialized
INFO - 2018-06-25 22:53:55 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:53:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:53:55 --> Input Class Initialized
DEBUG - 2018-06-25 22:53:55 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:53:55 --> Language Class Initialized
INFO - 2018-06-25 22:53:55 --> Utf8 Class Initialized
INFO - 2018-06-25 22:53:55 --> URI Class Initialized
ERROR - 2018-06-25 22:53:55 --> 404 Page Not Found: /index
INFO - 2018-06-25 22:53:55 --> Router Class Initialized
INFO - 2018-06-25 22:53:55 --> Output Class Initialized
INFO - 2018-06-25 22:53:55 --> Security Class Initialized
DEBUG - 2018-06-25 22:53:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:53:55 --> Input Class Initialized
INFO - 2018-06-25 22:53:55 --> Language Class Initialized
ERROR - 2018-06-25 22:53:55 --> 404 Page Not Found: /index
INFO - 2018-06-25 22:53:55 --> Config Class Initialized
INFO - 2018-06-25 22:53:55 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:53:55 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:53:55 --> Utf8 Class Initialized
INFO - 2018-06-25 22:53:55 --> URI Class Initialized
INFO - 2018-06-25 22:53:55 --> Router Class Initialized
INFO - 2018-06-25 22:53:55 --> Output Class Initialized
INFO - 2018-06-25 22:53:55 --> Security Class Initialized
DEBUG - 2018-06-25 22:53:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:53:55 --> Input Class Initialized
INFO - 2018-06-25 22:53:55 --> Language Class Initialized
ERROR - 2018-06-25 22:53:55 --> 404 Page Not Found: /index
INFO - 2018-06-25 22:53:55 --> Config Class Initialized
INFO - 2018-06-25 22:53:55 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:53:55 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:53:55 --> Utf8 Class Initialized
INFO - 2018-06-25 22:53:55 --> URI Class Initialized
INFO - 2018-06-25 22:53:55 --> Router Class Initialized
INFO - 2018-06-25 22:53:55 --> Output Class Initialized
INFO - 2018-06-25 22:53:55 --> Security Class Initialized
DEBUG - 2018-06-25 22:53:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:53:55 --> Input Class Initialized
INFO - 2018-06-25 22:53:55 --> Language Class Initialized
ERROR - 2018-06-25 22:53:55 --> 404 Page Not Found: /index
INFO - 2018-06-25 22:53:55 --> Config Class Initialized
INFO - 2018-06-25 22:53:55 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:53:55 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:53:55 --> Utf8 Class Initialized
INFO - 2018-06-25 22:53:55 --> URI Class Initialized
INFO - 2018-06-25 22:53:55 --> Router Class Initialized
INFO - 2018-06-25 22:53:55 --> Output Class Initialized
INFO - 2018-06-25 22:53:55 --> Security Class Initialized
DEBUG - 2018-06-25 22:53:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:53:55 --> Input Class Initialized
INFO - 2018-06-25 22:53:55 --> Language Class Initialized
ERROR - 2018-06-25 22:53:55 --> 404 Page Not Found: /index
INFO - 2018-06-25 22:54:26 --> Config Class Initialized
INFO - 2018-06-25 22:54:26 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:54:26 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:54:26 --> Utf8 Class Initialized
INFO - 2018-06-25 22:54:26 --> URI Class Initialized
INFO - 2018-06-25 22:54:26 --> Router Class Initialized
INFO - 2018-06-25 22:54:26 --> Output Class Initialized
INFO - 2018-06-25 22:54:26 --> Security Class Initialized
DEBUG - 2018-06-25 22:54:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:54:26 --> Input Class Initialized
INFO - 2018-06-25 22:54:26 --> Language Class Initialized
INFO - 2018-06-25 22:54:26 --> Config Class Initialized
INFO - 2018-06-25 22:54:26 --> Hooks Class Initialized
ERROR - 2018-06-25 22:54:26 --> 404 Page Not Found: /index
DEBUG - 2018-06-25 22:54:26 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:54:26 --> Utf8 Class Initialized
INFO - 2018-06-25 22:54:26 --> URI Class Initialized
INFO - 2018-06-25 22:54:26 --> Router Class Initialized
INFO - 2018-06-25 22:54:26 --> Output Class Initialized
INFO - 2018-06-25 22:54:26 --> Security Class Initialized
DEBUG - 2018-06-25 22:54:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:54:26 --> Input Class Initialized
INFO - 2018-06-25 22:54:26 --> Language Class Initialized
ERROR - 2018-06-25 22:54:26 --> 404 Page Not Found: /index
INFO - 2018-06-25 22:54:26 --> Config Class Initialized
INFO - 2018-06-25 22:54:26 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:54:26 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:54:26 --> Utf8 Class Initialized
INFO - 2018-06-25 22:54:26 --> URI Class Initialized
INFO - 2018-06-25 22:54:26 --> Router Class Initialized
INFO - 2018-06-25 22:54:26 --> Output Class Initialized
INFO - 2018-06-25 22:54:26 --> Security Class Initialized
DEBUG - 2018-06-25 22:54:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:54:26 --> Input Class Initialized
INFO - 2018-06-25 22:54:26 --> Language Class Initialized
ERROR - 2018-06-25 22:54:26 --> 404 Page Not Found: /index
INFO - 2018-06-25 22:54:26 --> Config Class Initialized
INFO - 2018-06-25 22:54:26 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:54:26 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:54:26 --> Utf8 Class Initialized
INFO - 2018-06-25 22:54:26 --> URI Class Initialized
INFO - 2018-06-25 22:54:26 --> Router Class Initialized
INFO - 2018-06-25 22:54:26 --> Output Class Initialized
INFO - 2018-06-25 22:54:26 --> Security Class Initialized
DEBUG - 2018-06-25 22:54:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:54:27 --> Input Class Initialized
INFO - 2018-06-25 22:54:27 --> Language Class Initialized
ERROR - 2018-06-25 22:54:27 --> 404 Page Not Found: /index
INFO - 2018-06-25 22:54:56 --> Config Class Initialized
INFO - 2018-06-25 22:54:56 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:54:56 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:54:56 --> Utf8 Class Initialized
INFO - 2018-06-25 22:54:56 --> URI Class Initialized
INFO - 2018-06-25 22:54:56 --> Router Class Initialized
INFO - 2018-06-25 22:54:56 --> Output Class Initialized
INFO - 2018-06-25 22:54:56 --> Security Class Initialized
DEBUG - 2018-06-25 22:54:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:54:56 --> Input Class Initialized
INFO - 2018-06-25 22:54:56 --> Language Class Initialized
ERROR - 2018-06-25 22:54:56 --> 404 Page Not Found: /index
INFO - 2018-06-25 22:54:56 --> Config Class Initialized
INFO - 2018-06-25 22:54:56 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:54:56 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:54:56 --> Utf8 Class Initialized
INFO - 2018-06-25 22:54:56 --> URI Class Initialized
INFO - 2018-06-25 22:54:56 --> Router Class Initialized
INFO - 2018-06-25 22:54:56 --> Output Class Initialized
INFO - 2018-06-25 22:54:56 --> Security Class Initialized
DEBUG - 2018-06-25 22:54:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:54:56 --> Input Class Initialized
INFO - 2018-06-25 22:54:56 --> Language Class Initialized
ERROR - 2018-06-25 22:54:56 --> 404 Page Not Found: /index
INFO - 2018-06-25 22:54:56 --> Config Class Initialized
INFO - 2018-06-25 22:54:56 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:54:56 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:54:56 --> Utf8 Class Initialized
INFO - 2018-06-25 22:54:56 --> URI Class Initialized
INFO - 2018-06-25 22:54:56 --> Router Class Initialized
INFO - 2018-06-25 22:54:56 --> Output Class Initialized
INFO - 2018-06-25 22:54:56 --> Security Class Initialized
DEBUG - 2018-06-25 22:54:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:54:56 --> Input Class Initialized
INFO - 2018-06-25 22:54:56 --> Language Class Initialized
ERROR - 2018-06-25 22:54:56 --> 404 Page Not Found: /index
INFO - 2018-06-25 22:54:57 --> Config Class Initialized
INFO - 2018-06-25 22:54:57 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:54:57 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:54:57 --> Utf8 Class Initialized
INFO - 2018-06-25 22:54:57 --> URI Class Initialized
INFO - 2018-06-25 22:54:57 --> Router Class Initialized
INFO - 2018-06-25 22:54:57 --> Output Class Initialized
INFO - 2018-06-25 22:54:57 --> Security Class Initialized
DEBUG - 2018-06-25 22:54:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:54:57 --> Input Class Initialized
INFO - 2018-06-25 22:54:57 --> Language Class Initialized
ERROR - 2018-06-25 22:54:57 --> 404 Page Not Found: /index
INFO - 2018-06-25 22:55:00 --> Config Class Initialized
INFO - 2018-06-25 22:55:01 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:55:01 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:55:01 --> Utf8 Class Initialized
INFO - 2018-06-25 22:55:01 --> URI Class Initialized
INFO - 2018-06-25 22:55:01 --> Router Class Initialized
INFO - 2018-06-25 22:55:01 --> Config Class Initialized
INFO - 2018-06-25 22:55:01 --> Output Class Initialized
INFO - 2018-06-25 22:55:01 --> Hooks Class Initialized
INFO - 2018-06-25 22:55:01 --> Security Class Initialized
DEBUG - 2018-06-25 22:55:01 --> UTF-8 Support Enabled
DEBUG - 2018-06-25 22:55:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:55:01 --> Input Class Initialized
INFO - 2018-06-25 22:55:01 --> Language Class Initialized
ERROR - 2018-06-25 22:55:01 --> 404 Page Not Found: /index
INFO - 2018-06-25 22:55:01 --> Utf8 Class Initialized
INFO - 2018-06-25 22:55:01 --> URI Class Initialized
INFO - 2018-06-25 22:55:01 --> Router Class Initialized
INFO - 2018-06-25 22:55:01 --> Output Class Initialized
INFO - 2018-06-25 22:55:01 --> Security Class Initialized
DEBUG - 2018-06-25 22:55:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:55:01 --> Input Class Initialized
INFO - 2018-06-25 22:55:01 --> Language Class Initialized
ERROR - 2018-06-25 22:55:01 --> 404 Page Not Found: /index
INFO - 2018-06-25 22:55:01 --> Config Class Initialized
INFO - 2018-06-25 22:55:01 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:55:01 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:55:01 --> Utf8 Class Initialized
INFO - 2018-06-25 22:55:01 --> URI Class Initialized
INFO - 2018-06-25 22:55:01 --> Router Class Initialized
INFO - 2018-06-25 22:55:01 --> Output Class Initialized
INFO - 2018-06-25 22:55:01 --> Security Class Initialized
DEBUG - 2018-06-25 22:55:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:55:01 --> Input Class Initialized
INFO - 2018-06-25 22:55:01 --> Language Class Initialized
ERROR - 2018-06-25 22:55:01 --> 404 Page Not Found: /index
INFO - 2018-06-25 22:55:01 --> Config Class Initialized
INFO - 2018-06-25 22:55:01 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:55:01 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:55:01 --> Utf8 Class Initialized
INFO - 2018-06-25 22:55:01 --> URI Class Initialized
INFO - 2018-06-25 22:55:01 --> Router Class Initialized
INFO - 2018-06-25 22:55:01 --> Output Class Initialized
INFO - 2018-06-25 22:55:01 --> Security Class Initialized
DEBUG - 2018-06-25 22:55:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:55:02 --> Input Class Initialized
INFO - 2018-06-25 22:55:02 --> Language Class Initialized
ERROR - 2018-06-25 22:55:02 --> 404 Page Not Found: /index
INFO - 2018-06-25 22:56:08 --> Config Class Initialized
INFO - 2018-06-25 22:56:08 --> Config Class Initialized
INFO - 2018-06-25 22:56:08 --> Hooks Class Initialized
INFO - 2018-06-25 22:56:08 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:56:08 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:56:08 --> Utf8 Class Initialized
INFO - 2018-06-25 22:56:08 --> URI Class Initialized
INFO - 2018-06-25 22:56:08 --> Router Class Initialized
INFO - 2018-06-25 22:56:08 --> Output Class Initialized
INFO - 2018-06-25 22:56:08 --> Security Class Initialized
DEBUG - 2018-06-25 22:56:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:56:08 --> Input Class Initialized
INFO - 2018-06-25 22:56:08 --> Language Class Initialized
INFO - 2018-06-25 22:56:08 --> Config Class Initialized
DEBUG - 2018-06-25 22:56:08 --> UTF-8 Support Enabled
ERROR - 2018-06-25 22:56:08 --> 404 Page Not Found: /index
INFO - 2018-06-25 22:56:08 --> Hooks Class Initialized
INFO - 2018-06-25 22:56:08 --> Utf8 Class Initialized
INFO - 2018-06-25 22:56:08 --> URI Class Initialized
INFO - 2018-06-25 22:56:08 --> Router Class Initialized
INFO - 2018-06-25 22:56:08 --> Output Class Initialized
INFO - 2018-06-25 22:56:08 --> Security Class Initialized
DEBUG - 2018-06-25 22:56:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:56:08 --> Input Class Initialized
INFO - 2018-06-25 22:56:08 --> Language Class Initialized
INFO - 2018-06-25 22:56:08 --> Config Class Initialized
DEBUG - 2018-06-25 22:56:08 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:56:08 --> Hooks Class Initialized
ERROR - 2018-06-25 22:56:08 --> 404 Page Not Found: /index
DEBUG - 2018-06-25 22:56:08 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:56:08 --> Utf8 Class Initialized
INFO - 2018-06-25 22:56:08 --> Utf8 Class Initialized
INFO - 2018-06-25 22:56:08 --> URI Class Initialized
INFO - 2018-06-25 22:56:08 --> URI Class Initialized
INFO - 2018-06-25 22:56:09 --> Router Class Initialized
INFO - 2018-06-25 22:56:09 --> Output Class Initialized
INFO - 2018-06-25 22:56:09 --> Security Class Initialized
INFO - 2018-06-25 22:56:09 --> Router Class Initialized
DEBUG - 2018-06-25 22:56:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:56:09 --> Input Class Initialized
INFO - 2018-06-25 22:56:09 --> Language Class Initialized
ERROR - 2018-06-25 22:56:09 --> 404 Page Not Found: /index
INFO - 2018-06-25 22:56:09 --> Output Class Initialized
INFO - 2018-06-25 22:56:09 --> Config Class Initialized
INFO - 2018-06-25 22:56:09 --> Hooks Class Initialized
INFO - 2018-06-25 22:56:09 --> Security Class Initialized
DEBUG - 2018-06-25 22:56:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-06-25 22:56:09 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:56:09 --> Input Class Initialized
INFO - 2018-06-25 22:56:09 --> Utf8 Class Initialized
INFO - 2018-06-25 22:56:09 --> Language Class Initialized
INFO - 2018-06-25 22:56:09 --> URI Class Initialized
ERROR - 2018-06-25 22:56:09 --> 404 Page Not Found: /index
INFO - 2018-06-25 22:56:09 --> Router Class Initialized
INFO - 2018-06-25 22:56:09 --> Output Class Initialized
INFO - 2018-06-25 22:56:09 --> Security Class Initialized
DEBUG - 2018-06-25 22:56:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:56:09 --> Input Class Initialized
INFO - 2018-06-25 22:56:09 --> Language Class Initialized
ERROR - 2018-06-25 22:56:09 --> 404 Page Not Found: /index
INFO - 2018-06-25 22:56:09 --> Config Class Initialized
INFO - 2018-06-25 22:56:09 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:56:09 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:56:09 --> Utf8 Class Initialized
INFO - 2018-06-25 22:56:09 --> URI Class Initialized
INFO - 2018-06-25 22:56:09 --> Router Class Initialized
INFO - 2018-06-25 22:56:09 --> Output Class Initialized
INFO - 2018-06-25 22:56:09 --> Security Class Initialized
DEBUG - 2018-06-25 22:56:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:56:09 --> Input Class Initialized
INFO - 2018-06-25 22:56:09 --> Language Class Initialized
ERROR - 2018-06-25 22:56:09 --> 404 Page Not Found: /index
INFO - 2018-06-25 22:56:24 --> Config Class Initialized
INFO - 2018-06-25 22:56:24 --> Config Class Initialized
INFO - 2018-06-25 22:56:24 --> Hooks Class Initialized
INFO - 2018-06-25 22:56:24 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:56:24 --> UTF-8 Support Enabled
DEBUG - 2018-06-25 22:56:24 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:56:24 --> Utf8 Class Initialized
INFO - 2018-06-25 22:56:24 --> Utf8 Class Initialized
INFO - 2018-06-25 22:56:24 --> URI Class Initialized
INFO - 2018-06-25 22:56:24 --> URI Class Initialized
INFO - 2018-06-25 22:56:24 --> Router Class Initialized
INFO - 2018-06-25 22:56:24 --> Router Class Initialized
INFO - 2018-06-25 22:56:24 --> Output Class Initialized
INFO - 2018-06-25 22:56:24 --> Output Class Initialized
INFO - 2018-06-25 22:56:25 --> Security Class Initialized
INFO - 2018-06-25 22:56:25 --> Security Class Initialized
DEBUG - 2018-06-25 22:56:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:56:25 --> Input Class Initialized
DEBUG - 2018-06-25 22:56:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:56:25 --> Input Class Initialized
INFO - 2018-06-25 22:56:25 --> Language Class Initialized
ERROR - 2018-06-25 22:56:25 --> 404 Page Not Found: /index
INFO - 2018-06-25 22:56:25 --> Language Class Initialized
ERROR - 2018-06-25 22:56:25 --> 404 Page Not Found: /index
INFO - 2018-06-25 22:56:25 --> Config Class Initialized
INFO - 2018-06-25 22:56:25 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:56:25 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:56:25 --> Utf8 Class Initialized
INFO - 2018-06-25 22:56:25 --> Config Class Initialized
INFO - 2018-06-25 22:56:25 --> Hooks Class Initialized
INFO - 2018-06-25 22:56:25 --> URI Class Initialized
INFO - 2018-06-25 22:56:25 --> Router Class Initialized
DEBUG - 2018-06-25 22:56:25 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:56:25 --> Output Class Initialized
INFO - 2018-06-25 22:56:25 --> Security Class Initialized
DEBUG - 2018-06-25 22:56:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:56:25 --> Input Class Initialized
INFO - 2018-06-25 22:56:25 --> Language Class Initialized
INFO - 2018-06-25 22:56:25 --> Utf8 Class Initialized
ERROR - 2018-06-25 22:56:25 --> 404 Page Not Found: /index
INFO - 2018-06-25 22:56:25 --> URI Class Initialized
INFO - 2018-06-25 22:56:26 --> Router Class Initialized
INFO - 2018-06-25 22:56:26 --> Output Class Initialized
INFO - 2018-06-25 22:56:26 --> Security Class Initialized
DEBUG - 2018-06-25 22:56:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:56:26 --> Config Class Initialized
INFO - 2018-06-25 22:56:26 --> Hooks Class Initialized
INFO - 2018-06-25 22:56:26 --> Input Class Initialized
DEBUG - 2018-06-25 22:56:26 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:56:26 --> Utf8 Class Initialized
INFO - 2018-06-25 22:56:26 --> URI Class Initialized
INFO - 2018-06-25 22:56:26 --> Router Class Initialized
INFO - 2018-06-25 22:56:26 --> Language Class Initialized
INFO - 2018-06-25 22:56:26 --> Output Class Initialized
ERROR - 2018-06-25 22:56:26 --> 404 Page Not Found: /index
INFO - 2018-06-25 22:56:26 --> Security Class Initialized
DEBUG - 2018-06-25 22:56:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:56:26 --> Input Class Initialized
INFO - 2018-06-25 22:56:26 --> Language Class Initialized
ERROR - 2018-06-25 22:56:26 --> 404 Page Not Found: /index
INFO - 2018-06-25 22:56:26 --> Config Class Initialized
INFO - 2018-06-25 22:56:26 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:56:26 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:56:26 --> Utf8 Class Initialized
INFO - 2018-06-25 22:56:26 --> URI Class Initialized
INFO - 2018-06-25 22:56:26 --> Router Class Initialized
INFO - 2018-06-25 22:56:26 --> Output Class Initialized
INFO - 2018-06-25 22:56:26 --> Security Class Initialized
DEBUG - 2018-06-25 22:56:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:56:26 --> Input Class Initialized
INFO - 2018-06-25 22:56:26 --> Language Class Initialized
ERROR - 2018-06-25 22:56:27 --> 404 Page Not Found: /index
INFO - 2018-06-25 22:56:34 --> Config Class Initialized
INFO - 2018-06-25 22:56:34 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:56:34 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:56:34 --> Utf8 Class Initialized
INFO - 2018-06-25 22:56:34 --> URI Class Initialized
INFO - 2018-06-25 22:56:34 --> Router Class Initialized
INFO - 2018-06-25 22:56:34 --> Output Class Initialized
INFO - 2018-06-25 22:56:34 --> Security Class Initialized
DEBUG - 2018-06-25 22:56:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:56:34 --> Input Class Initialized
INFO - 2018-06-25 22:56:34 --> Language Class Initialized
ERROR - 2018-06-25 22:56:34 --> 404 Page Not Found: /index
INFO - 2018-06-25 22:56:34 --> Config Class Initialized
INFO - 2018-06-25 22:56:34 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:56:34 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:56:34 --> Utf8 Class Initialized
INFO - 2018-06-25 22:56:34 --> URI Class Initialized
INFO - 2018-06-25 22:56:35 --> Router Class Initialized
INFO - 2018-06-25 22:56:35 --> Output Class Initialized
INFO - 2018-06-25 22:56:35 --> Security Class Initialized
DEBUG - 2018-06-25 22:56:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:56:35 --> Input Class Initialized
INFO - 2018-06-25 22:56:35 --> Language Class Initialized
ERROR - 2018-06-25 22:56:35 --> 404 Page Not Found: /index
INFO - 2018-06-25 22:56:35 --> Config Class Initialized
INFO - 2018-06-25 22:56:35 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:56:35 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:56:35 --> Utf8 Class Initialized
INFO - 2018-06-25 22:56:35 --> URI Class Initialized
INFO - 2018-06-25 22:56:35 --> Router Class Initialized
INFO - 2018-06-25 22:56:35 --> Output Class Initialized
INFO - 2018-06-25 22:56:35 --> Security Class Initialized
DEBUG - 2018-06-25 22:56:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:56:35 --> Input Class Initialized
INFO - 2018-06-25 22:56:35 --> Language Class Initialized
ERROR - 2018-06-25 22:56:35 --> 404 Page Not Found: /index
INFO - 2018-06-25 22:56:36 --> Config Class Initialized
INFO - 2018-06-25 22:56:36 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:56:36 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:56:36 --> Utf8 Class Initialized
INFO - 2018-06-25 22:56:36 --> URI Class Initialized
INFO - 2018-06-25 22:56:36 --> Router Class Initialized
INFO - 2018-06-25 22:56:36 --> Output Class Initialized
INFO - 2018-06-25 22:56:36 --> Security Class Initialized
DEBUG - 2018-06-25 22:56:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:56:36 --> Input Class Initialized
INFO - 2018-06-25 22:56:36 --> Language Class Initialized
ERROR - 2018-06-25 22:56:36 --> 404 Page Not Found: /index
INFO - 2018-06-25 22:58:44 --> Config Class Initialized
INFO - 2018-06-25 22:58:45 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:58:45 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:58:45 --> Utf8 Class Initialized
INFO - 2018-06-25 22:58:45 --> URI Class Initialized
INFO - 2018-06-25 22:58:45 --> Router Class Initialized
INFO - 2018-06-25 22:58:45 --> Output Class Initialized
INFO - 2018-06-25 22:58:45 --> Security Class Initialized
DEBUG - 2018-06-25 22:58:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:58:45 --> Input Class Initialized
INFO - 2018-06-25 22:58:45 --> Language Class Initialized
ERROR - 2018-06-25 22:58:45 --> 404 Page Not Found: /index
INFO - 2018-06-25 22:58:45 --> Config Class Initialized
INFO - 2018-06-25 22:58:45 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:58:45 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:58:45 --> Utf8 Class Initialized
INFO - 2018-06-25 22:58:45 --> URI Class Initialized
INFO - 2018-06-25 22:58:45 --> Router Class Initialized
INFO - 2018-06-25 22:58:45 --> Output Class Initialized
INFO - 2018-06-25 22:58:45 --> Security Class Initialized
DEBUG - 2018-06-25 22:58:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:58:45 --> Input Class Initialized
INFO - 2018-06-25 22:58:45 --> Language Class Initialized
ERROR - 2018-06-25 22:58:45 --> 404 Page Not Found: /index
INFO - 2018-06-25 22:58:45 --> Config Class Initialized
INFO - 2018-06-25 22:58:45 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:58:46 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:58:46 --> Utf8 Class Initialized
INFO - 2018-06-25 22:58:46 --> URI Class Initialized
INFO - 2018-06-25 22:58:46 --> Router Class Initialized
INFO - 2018-06-25 22:58:46 --> Output Class Initialized
INFO - 2018-06-25 22:58:46 --> Security Class Initialized
DEBUG - 2018-06-25 22:58:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:58:46 --> Input Class Initialized
INFO - 2018-06-25 22:58:46 --> Language Class Initialized
ERROR - 2018-06-25 22:58:46 --> 404 Page Not Found: /index
INFO - 2018-06-25 22:58:46 --> Config Class Initialized
INFO - 2018-06-25 22:58:46 --> Hooks Class Initialized
DEBUG - 2018-06-25 22:58:46 --> UTF-8 Support Enabled
INFO - 2018-06-25 22:58:46 --> Utf8 Class Initialized
INFO - 2018-06-25 22:58:46 --> URI Class Initialized
INFO - 2018-06-25 22:58:46 --> Router Class Initialized
INFO - 2018-06-25 22:58:46 --> Output Class Initialized
INFO - 2018-06-25 22:58:46 --> Security Class Initialized
DEBUG - 2018-06-25 22:58:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 22:58:46 --> Input Class Initialized
INFO - 2018-06-25 22:58:46 --> Language Class Initialized
ERROR - 2018-06-25 22:58:46 --> 404 Page Not Found: /index
INFO - 2018-06-25 23:11:33 --> Config Class Initialized
INFO - 2018-06-25 23:11:33 --> Hooks Class Initialized
DEBUG - 2018-06-25 23:11:33 --> UTF-8 Support Enabled
INFO - 2018-06-25 23:11:33 --> Utf8 Class Initialized
INFO - 2018-06-25 23:11:33 --> URI Class Initialized
INFO - 2018-06-25 23:11:33 --> Router Class Initialized
INFO - 2018-06-25 23:11:33 --> Output Class Initialized
INFO - 2018-06-25 23:11:33 --> Security Class Initialized
DEBUG - 2018-06-25 23:11:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 23:11:33 --> Input Class Initialized
INFO - 2018-06-25 23:11:33 --> Language Class Initialized
ERROR - 2018-06-25 23:11:33 --> 404 Page Not Found: /index
INFO - 2018-06-25 23:11:33 --> Config Class Initialized
INFO - 2018-06-25 23:11:33 --> Hooks Class Initialized
DEBUG - 2018-06-25 23:11:33 --> UTF-8 Support Enabled
INFO - 2018-06-25 23:11:33 --> Utf8 Class Initialized
INFO - 2018-06-25 23:11:33 --> URI Class Initialized
INFO - 2018-06-25 23:11:33 --> Router Class Initialized
INFO - 2018-06-25 23:11:33 --> Output Class Initialized
INFO - 2018-06-25 23:11:33 --> Security Class Initialized
DEBUG - 2018-06-25 23:11:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 23:11:33 --> Input Class Initialized
INFO - 2018-06-25 23:11:33 --> Language Class Initialized
ERROR - 2018-06-25 23:11:33 --> 404 Page Not Found: /index
INFO - 2018-06-25 23:11:33 --> Config Class Initialized
INFO - 2018-06-25 23:11:33 --> Hooks Class Initialized
DEBUG - 2018-06-25 23:11:33 --> UTF-8 Support Enabled
INFO - 2018-06-25 23:11:33 --> Utf8 Class Initialized
INFO - 2018-06-25 23:11:33 --> URI Class Initialized
INFO - 2018-06-25 23:11:33 --> Router Class Initialized
INFO - 2018-06-25 23:11:33 --> Output Class Initialized
INFO - 2018-06-25 23:11:33 --> Security Class Initialized
DEBUG - 2018-06-25 23:11:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 23:11:34 --> Input Class Initialized
INFO - 2018-06-25 23:11:34 --> Language Class Initialized
ERROR - 2018-06-25 23:11:34 --> 404 Page Not Found: /index
INFO - 2018-06-25 23:11:34 --> Config Class Initialized
INFO - 2018-06-25 23:11:34 --> Hooks Class Initialized
DEBUG - 2018-06-25 23:11:34 --> UTF-8 Support Enabled
INFO - 2018-06-25 23:11:34 --> Utf8 Class Initialized
INFO - 2018-06-25 23:11:34 --> URI Class Initialized
INFO - 2018-06-25 23:11:34 --> Router Class Initialized
INFO - 2018-06-25 23:11:34 --> Output Class Initialized
INFO - 2018-06-25 23:11:34 --> Security Class Initialized
DEBUG - 2018-06-25 23:11:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 23:11:34 --> Input Class Initialized
INFO - 2018-06-25 23:11:34 --> Language Class Initialized
ERROR - 2018-06-25 23:11:34 --> 404 Page Not Found: /index
INFO - 2018-06-25 23:19:46 --> Config Class Initialized
INFO - 2018-06-25 23:19:46 --> Hooks Class Initialized
DEBUG - 2018-06-25 23:19:46 --> UTF-8 Support Enabled
INFO - 2018-06-25 23:19:46 --> Utf8 Class Initialized
INFO - 2018-06-25 23:19:46 --> URI Class Initialized
INFO - 2018-06-25 23:19:46 --> Router Class Initialized
INFO - 2018-06-25 23:19:46 --> Output Class Initialized
INFO - 2018-06-25 23:19:46 --> Security Class Initialized
DEBUG - 2018-06-25 23:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 23:19:46 --> Input Class Initialized
INFO - 2018-06-25 23:19:46 --> Language Class Initialized
ERROR - 2018-06-25 23:19:46 --> 404 Page Not Found: /index
INFO - 2018-06-25 23:19:47 --> Config Class Initialized
INFO - 2018-06-25 23:19:47 --> Hooks Class Initialized
DEBUG - 2018-06-25 23:19:47 --> UTF-8 Support Enabled
INFO - 2018-06-25 23:19:47 --> Utf8 Class Initialized
INFO - 2018-06-25 23:19:47 --> URI Class Initialized
INFO - 2018-06-25 23:19:47 --> Router Class Initialized
INFO - 2018-06-25 23:19:47 --> Output Class Initialized
INFO - 2018-06-25 23:19:47 --> Security Class Initialized
DEBUG - 2018-06-25 23:19:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 23:19:47 --> Input Class Initialized
INFO - 2018-06-25 23:19:47 --> Language Class Initialized
ERROR - 2018-06-25 23:19:47 --> 404 Page Not Found: /index
INFO - 2018-06-25 23:19:47 --> Config Class Initialized
INFO - 2018-06-25 23:19:47 --> Hooks Class Initialized
DEBUG - 2018-06-25 23:19:47 --> UTF-8 Support Enabled
INFO - 2018-06-25 23:19:47 --> Utf8 Class Initialized
INFO - 2018-06-25 23:19:47 --> URI Class Initialized
INFO - 2018-06-25 23:19:47 --> Router Class Initialized
INFO - 2018-06-25 23:19:47 --> Output Class Initialized
INFO - 2018-06-25 23:19:47 --> Security Class Initialized
DEBUG - 2018-06-25 23:19:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 23:19:47 --> Input Class Initialized
INFO - 2018-06-25 23:19:47 --> Language Class Initialized
ERROR - 2018-06-25 23:19:47 --> 404 Page Not Found: /index
INFO - 2018-06-25 23:19:47 --> Config Class Initialized
INFO - 2018-06-25 23:19:47 --> Hooks Class Initialized
DEBUG - 2018-06-25 23:19:47 --> UTF-8 Support Enabled
INFO - 2018-06-25 23:19:47 --> Utf8 Class Initialized
INFO - 2018-06-25 23:19:47 --> URI Class Initialized
INFO - 2018-06-25 23:19:48 --> Router Class Initialized
INFO - 2018-06-25 23:19:48 --> Output Class Initialized
INFO - 2018-06-25 23:19:48 --> Security Class Initialized
DEBUG - 2018-06-25 23:19:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 23:19:48 --> Input Class Initialized
INFO - 2018-06-25 23:19:48 --> Language Class Initialized
ERROR - 2018-06-25 23:19:48 --> 404 Page Not Found: /index
INFO - 2018-06-25 23:21:40 --> Config Class Initialized
INFO - 2018-06-25 23:21:40 --> Hooks Class Initialized
DEBUG - 2018-06-25 23:21:40 --> UTF-8 Support Enabled
INFO - 2018-06-25 23:21:40 --> Utf8 Class Initialized
INFO - 2018-06-25 23:21:40 --> URI Class Initialized
DEBUG - 2018-06-25 23:21:40 --> No URI present. Default controller set.
INFO - 2018-06-25 23:21:40 --> Router Class Initialized
INFO - 2018-06-25 23:21:40 --> Output Class Initialized
INFO - 2018-06-25 23:21:40 --> Security Class Initialized
DEBUG - 2018-06-25 23:21:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 23:21:40 --> Input Class Initialized
INFO - 2018-06-25 23:21:40 --> Language Class Initialized
INFO - 2018-06-25 23:21:40 --> Language Class Initialized
INFO - 2018-06-25 23:21:40 --> Config Class Initialized
INFO - 2018-06-25 23:21:40 --> Loader Class Initialized
DEBUG - 2018-06-25 23:21:40 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-25 23:21:40 --> Helper loaded: url_helper
INFO - 2018-06-25 23:21:40 --> Helper loaded: form_helper
INFO - 2018-06-25 23:21:40 --> Helper loaded: date_helper
INFO - 2018-06-25 23:21:40 --> Helper loaded: util_helper
INFO - 2018-06-25 23:21:40 --> Helper loaded: text_helper
INFO - 2018-06-25 23:21:40 --> Helper loaded: string_helper
INFO - 2018-06-25 23:21:40 --> Database Driver Class Initialized
DEBUG - 2018-06-25 23:21:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-25 23:21:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-25 23:21:41 --> Email Class Initialized
INFO - 2018-06-25 23:21:41 --> Controller Class Initialized
DEBUG - 2018-06-25 23:21:41 --> Home MX_Controller Initialized
DEBUG - 2018-06-25 23:21:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-25 23:21:41 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-25 23:21:41 --> Login MX_Controller Initialized
INFO - 2018-06-25 23:21:41 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-25 23:21:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-25 23:21:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-25 23:21:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-25 23:21:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-25 23:21:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-25 23:21:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-25 23:21:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-25 23:21:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-06-25 23:21:41 --> Final output sent to browser
INFO - 2018-06-25 23:21:41 --> Config Class Initialized
DEBUG - 2018-06-25 23:21:41 --> Total execution time: 0.5294
INFO - 2018-06-25 23:21:41 --> Hooks Class Initialized
DEBUG - 2018-06-25 23:21:41 --> UTF-8 Support Enabled
INFO - 2018-06-25 23:21:41 --> Utf8 Class Initialized
INFO - 2018-06-25 23:21:41 --> URI Class Initialized
INFO - 2018-06-25 23:21:41 --> Router Class Initialized
INFO - 2018-06-25 23:21:41 --> Output Class Initialized
INFO - 2018-06-25 23:21:41 --> Config Class Initialized
INFO - 2018-06-25 23:21:41 --> Hooks Class Initialized
INFO - 2018-06-25 23:21:41 --> Security Class Initialized
DEBUG - 2018-06-25 23:21:41 --> UTF-8 Support Enabled
INFO - 2018-06-25 23:21:41 --> Utf8 Class Initialized
INFO - 2018-06-25 23:21:41 --> URI Class Initialized
INFO - 2018-06-25 23:21:41 --> Router Class Initialized
INFO - 2018-06-25 23:21:41 --> Config Class Initialized
DEBUG - 2018-06-25 23:21:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 23:21:41 --> Hooks Class Initialized
INFO - 2018-06-25 23:21:41 --> Input Class Initialized
INFO - 2018-06-25 23:21:41 --> Output Class Initialized
INFO - 2018-06-25 23:21:41 --> Language Class Initialized
DEBUG - 2018-06-25 23:21:41 --> UTF-8 Support Enabled
INFO - 2018-06-25 23:21:41 --> Security Class Initialized
INFO - 2018-06-25 23:21:41 --> Utf8 Class Initialized
ERROR - 2018-06-25 23:21:41 --> 404 Page Not Found: /index
DEBUG - 2018-06-25 23:21:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 23:21:41 --> URI Class Initialized
INFO - 2018-06-25 23:21:41 --> Router Class Initialized
INFO - 2018-06-25 23:21:41 --> Output Class Initialized
INFO - 2018-06-25 23:21:41 --> Security Class Initialized
DEBUG - 2018-06-25 23:21:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 23:21:41 --> Input Class Initialized
INFO - 2018-06-25 23:21:41 --> Input Class Initialized
INFO - 2018-06-25 23:21:41 --> Language Class Initialized
INFO - 2018-06-25 23:21:41 --> Language Class Initialized
ERROR - 2018-06-25 23:21:41 --> 404 Page Not Found: /index
ERROR - 2018-06-25 23:21:41 --> 404 Page Not Found: /index
INFO - 2018-06-25 23:21:41 --> Config Class Initialized
INFO - 2018-06-25 23:21:41 --> Hooks Class Initialized
DEBUG - 2018-06-25 23:21:41 --> UTF-8 Support Enabled
INFO - 2018-06-25 23:21:41 --> Utf8 Class Initialized
INFO - 2018-06-25 23:21:41 --> URI Class Initialized
INFO - 2018-06-25 23:21:41 --> Router Class Initialized
INFO - 2018-06-25 23:21:41 --> Output Class Initialized
INFO - 2018-06-25 23:21:41 --> Security Class Initialized
DEBUG - 2018-06-25 23:21:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 23:21:41 --> Input Class Initialized
INFO - 2018-06-25 23:21:41 --> Language Class Initialized
ERROR - 2018-06-25 23:21:41 --> 404 Page Not Found: /index
INFO - 2018-06-25 23:21:41 --> Config Class Initialized
INFO - 2018-06-25 23:21:41 --> Hooks Class Initialized
DEBUG - 2018-06-25 23:21:41 --> UTF-8 Support Enabled
INFO - 2018-06-25 23:21:41 --> Utf8 Class Initialized
INFO - 2018-06-25 23:21:41 --> URI Class Initialized
INFO - 2018-06-25 23:21:41 --> Router Class Initialized
INFO - 2018-06-25 23:21:42 --> Output Class Initialized
INFO - 2018-06-25 23:21:42 --> Security Class Initialized
DEBUG - 2018-06-25 23:21:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 23:21:42 --> Input Class Initialized
INFO - 2018-06-25 23:21:42 --> Language Class Initialized
ERROR - 2018-06-25 23:21:42 --> 404 Page Not Found: /index
INFO - 2018-06-25 23:21:44 --> Config Class Initialized
INFO - 2018-06-25 23:21:44 --> Hooks Class Initialized
DEBUG - 2018-06-25 23:21:44 --> UTF-8 Support Enabled
INFO - 2018-06-25 23:21:44 --> Utf8 Class Initialized
INFO - 2018-06-25 23:21:44 --> URI Class Initialized
INFO - 2018-06-25 23:21:44 --> Router Class Initialized
INFO - 2018-06-25 23:21:44 --> Output Class Initialized
INFO - 2018-06-25 23:21:44 --> Security Class Initialized
DEBUG - 2018-06-25 23:21:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 23:21:44 --> Input Class Initialized
INFO - 2018-06-25 23:21:44 --> Language Class Initialized
ERROR - 2018-06-25 23:21:44 --> 404 Page Not Found: /index
INFO - 2018-06-25 23:21:50 --> Config Class Initialized
INFO - 2018-06-25 23:21:50 --> Hooks Class Initialized
DEBUG - 2018-06-25 23:21:50 --> UTF-8 Support Enabled
INFO - 2018-06-25 23:21:50 --> Utf8 Class Initialized
INFO - 2018-06-25 23:21:50 --> URI Class Initialized
INFO - 2018-06-25 23:21:50 --> Router Class Initialized
INFO - 2018-06-25 23:21:50 --> Output Class Initialized
INFO - 2018-06-25 23:21:50 --> Security Class Initialized
DEBUG - 2018-06-25 23:21:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 23:21:50 --> Input Class Initialized
INFO - 2018-06-25 23:21:50 --> Language Class Initialized
ERROR - 2018-06-25 23:21:50 --> 404 Page Not Found: /index
INFO - 2018-06-25 23:22:44 --> Config Class Initialized
INFO - 2018-06-25 23:22:44 --> Hooks Class Initialized
DEBUG - 2018-06-25 23:22:44 --> UTF-8 Support Enabled
INFO - 2018-06-25 23:22:44 --> Utf8 Class Initialized
INFO - 2018-06-25 23:22:44 --> URI Class Initialized
DEBUG - 2018-06-25 23:22:44 --> No URI present. Default controller set.
INFO - 2018-06-25 23:22:44 --> Router Class Initialized
INFO - 2018-06-25 23:22:44 --> Output Class Initialized
INFO - 2018-06-25 23:22:44 --> Security Class Initialized
DEBUG - 2018-06-25 23:22:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 23:22:44 --> Input Class Initialized
INFO - 2018-06-25 23:22:44 --> Language Class Initialized
INFO - 2018-06-25 23:22:44 --> Language Class Initialized
INFO - 2018-06-25 23:22:44 --> Config Class Initialized
INFO - 2018-06-25 23:22:44 --> Loader Class Initialized
DEBUG - 2018-06-25 23:22:44 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-25 23:22:44 --> Helper loaded: url_helper
INFO - 2018-06-25 23:22:44 --> Helper loaded: form_helper
INFO - 2018-06-25 23:22:44 --> Helper loaded: date_helper
INFO - 2018-06-25 23:22:44 --> Helper loaded: util_helper
INFO - 2018-06-25 23:22:44 --> Helper loaded: text_helper
INFO - 2018-06-25 23:22:44 --> Helper loaded: string_helper
INFO - 2018-06-25 23:22:44 --> Database Driver Class Initialized
DEBUG - 2018-06-25 23:22:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-25 23:22:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-25 23:22:44 --> Email Class Initialized
INFO - 2018-06-25 23:22:44 --> Controller Class Initialized
DEBUG - 2018-06-25 23:22:44 --> Home MX_Controller Initialized
DEBUG - 2018-06-25 23:22:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-25 23:22:44 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-25 23:22:44 --> Login MX_Controller Initialized
INFO - 2018-06-25 23:22:44 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-25 23:22:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-25 23:22:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-25 23:22:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-25 23:22:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-25 23:22:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-25 23:22:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-25 23:22:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-25 23:22:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-06-25 23:22:44 --> Final output sent to browser
DEBUG - 2018-06-25 23:22:44 --> Total execution time: 0.5287
INFO - 2018-06-25 23:22:44 --> Config Class Initialized
INFO - 2018-06-25 23:22:44 --> Hooks Class Initialized
DEBUG - 2018-06-25 23:22:45 --> UTF-8 Support Enabled
INFO - 2018-06-25 23:22:45 --> Utf8 Class Initialized
INFO - 2018-06-25 23:22:45 --> URI Class Initialized
INFO - 2018-06-25 23:22:45 --> Router Class Initialized
INFO - 2018-06-25 23:22:45 --> Output Class Initialized
INFO - 2018-06-25 23:22:45 --> Security Class Initialized
DEBUG - 2018-06-25 23:22:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 23:22:45 --> Input Class Initialized
INFO - 2018-06-25 23:22:45 --> Language Class Initialized
ERROR - 2018-06-25 23:22:45 --> 404 Page Not Found: /index
INFO - 2018-06-25 23:22:45 --> Config Class Initialized
INFO - 2018-06-25 23:22:45 --> Hooks Class Initialized
DEBUG - 2018-06-25 23:22:45 --> UTF-8 Support Enabled
INFO - 2018-06-25 23:22:45 --> Utf8 Class Initialized
INFO - 2018-06-25 23:22:45 --> URI Class Initialized
INFO - 2018-06-25 23:22:45 --> Router Class Initialized
INFO - 2018-06-25 23:22:45 --> Output Class Initialized
INFO - 2018-06-25 23:22:45 --> Security Class Initialized
DEBUG - 2018-06-25 23:22:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 23:22:45 --> Input Class Initialized
INFO - 2018-06-25 23:22:45 --> Language Class Initialized
ERROR - 2018-06-25 23:22:45 --> 404 Page Not Found: /index
INFO - 2018-06-25 23:22:45 --> Config Class Initialized
INFO - 2018-06-25 23:22:45 --> Hooks Class Initialized
DEBUG - 2018-06-25 23:22:45 --> UTF-8 Support Enabled
INFO - 2018-06-25 23:22:45 --> Utf8 Class Initialized
INFO - 2018-06-25 23:22:45 --> URI Class Initialized
INFO - 2018-06-25 23:22:45 --> Router Class Initialized
INFO - 2018-06-25 23:22:45 --> Output Class Initialized
INFO - 2018-06-25 23:22:45 --> Security Class Initialized
DEBUG - 2018-06-25 23:22:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 23:22:45 --> Input Class Initialized
INFO - 2018-06-25 23:22:45 --> Language Class Initialized
ERROR - 2018-06-25 23:22:45 --> 404 Page Not Found: /index
INFO - 2018-06-25 23:22:45 --> Config Class Initialized
INFO - 2018-06-25 23:22:45 --> Hooks Class Initialized
DEBUG - 2018-06-25 23:22:45 --> UTF-8 Support Enabled
INFO - 2018-06-25 23:22:45 --> Utf8 Class Initialized
INFO - 2018-06-25 23:22:45 --> URI Class Initialized
INFO - 2018-06-25 23:22:45 --> Router Class Initialized
INFO - 2018-06-25 23:22:45 --> Output Class Initialized
INFO - 2018-06-25 23:22:45 --> Security Class Initialized
DEBUG - 2018-06-25 23:22:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 23:22:45 --> Input Class Initialized
INFO - 2018-06-25 23:22:45 --> Language Class Initialized
ERROR - 2018-06-25 23:22:45 --> 404 Page Not Found: /index
INFO - 2018-06-25 23:22:45 --> Config Class Initialized
INFO - 2018-06-25 23:22:45 --> Hooks Class Initialized
DEBUG - 2018-06-25 23:22:45 --> UTF-8 Support Enabled
INFO - 2018-06-25 23:22:45 --> Utf8 Class Initialized
INFO - 2018-06-25 23:22:45 --> URI Class Initialized
INFO - 2018-06-25 23:22:45 --> Router Class Initialized
INFO - 2018-06-25 23:22:45 --> Output Class Initialized
INFO - 2018-06-25 23:22:45 --> Security Class Initialized
DEBUG - 2018-06-25 23:22:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 23:22:45 --> Input Class Initialized
INFO - 2018-06-25 23:22:45 --> Language Class Initialized
ERROR - 2018-06-25 23:22:45 --> 404 Page Not Found: /index
INFO - 2018-06-25 23:22:45 --> Config Class Initialized
INFO - 2018-06-25 23:22:45 --> Hooks Class Initialized
DEBUG - 2018-06-25 23:22:45 --> UTF-8 Support Enabled
INFO - 2018-06-25 23:22:45 --> Utf8 Class Initialized
INFO - 2018-06-25 23:22:45 --> URI Class Initialized
INFO - 2018-06-25 23:22:45 --> Router Class Initialized
INFO - 2018-06-25 23:22:45 --> Output Class Initialized
INFO - 2018-06-25 23:22:45 --> Security Class Initialized
DEBUG - 2018-06-25 23:22:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-25 23:22:46 --> Input Class Initialized
INFO - 2018-06-25 23:22:46 --> Language Class Initialized
ERROR - 2018-06-25 23:22:46 --> 404 Page Not Found: /index
