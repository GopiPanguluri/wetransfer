<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-06-26 00:34:37 --> Config Class Initialized
INFO - 2018-06-26 00:34:37 --> Hooks Class Initialized
DEBUG - 2018-06-26 00:34:37 --> UTF-8 Support Enabled
INFO - 2018-06-26 00:34:37 --> Utf8 Class Initialized
INFO - 2018-06-26 00:34:37 --> URI Class Initialized
INFO - 2018-06-26 00:34:37 --> Router Class Initialized
INFO - 2018-06-26 00:34:37 --> Output Class Initialized
INFO - 2018-06-26 00:34:37 --> Security Class Initialized
DEBUG - 2018-06-26 00:34:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-26 00:34:37 --> Input Class Initialized
INFO - 2018-06-26 00:34:37 --> Language Class Initialized
INFO - 2018-06-26 00:34:37 --> Language Class Initialized
INFO - 2018-06-26 00:34:37 --> Config Class Initialized
INFO - 2018-06-26 00:34:37 --> Loader Class Initialized
DEBUG - 2018-06-26 00:34:37 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-26 00:34:37 --> Helper loaded: url_helper
INFO - 2018-06-26 00:34:37 --> Helper loaded: form_helper
INFO - 2018-06-26 00:34:37 --> Helper loaded: date_helper
INFO - 2018-06-26 00:34:37 --> Helper loaded: util_helper
INFO - 2018-06-26 00:34:37 --> Helper loaded: text_helper
INFO - 2018-06-26 00:34:37 --> Helper loaded: string_helper
INFO - 2018-06-26 00:34:37 --> Database Driver Class Initialized
DEBUG - 2018-06-26 00:34:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-26 00:34:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-26 00:34:37 --> Email Class Initialized
INFO - 2018-06-26 00:34:37 --> Controller Class Initialized
DEBUG - 2018-06-26 00:34:37 --> videos MX_Controller Initialized
INFO - 2018-06-26 00:34:37 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-26 00:34:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-06-26 00:34:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-26 00:34:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-26 00:34:37 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-26 00:34:37 --> Login MX_Controller Initialized
DEBUG - 2018-06-26 00:34:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-26 00:34:37 --> Final output sent to browser
DEBUG - 2018-06-26 00:34:37 --> Total execution time: 0.3022
INFO - 2018-06-26 00:34:38 --> Config Class Initialized
INFO - 2018-06-26 00:34:38 --> Hooks Class Initialized
DEBUG - 2018-06-26 00:34:38 --> UTF-8 Support Enabled
INFO - 2018-06-26 00:34:38 --> Utf8 Class Initialized
INFO - 2018-06-26 00:34:38 --> URI Class Initialized
INFO - 2018-06-26 00:34:38 --> Router Class Initialized
INFO - 2018-06-26 00:34:38 --> Output Class Initialized
INFO - 2018-06-26 00:34:38 --> Security Class Initialized
DEBUG - 2018-06-26 00:34:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-26 00:34:38 --> Input Class Initialized
INFO - 2018-06-26 00:34:38 --> Language Class Initialized
INFO - 2018-06-26 00:34:38 --> Language Class Initialized
INFO - 2018-06-26 00:34:38 --> Config Class Initialized
INFO - 2018-06-26 00:34:39 --> Loader Class Initialized
DEBUG - 2018-06-26 00:34:39 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-26 00:34:39 --> Helper loaded: url_helper
INFO - 2018-06-26 00:34:39 --> Helper loaded: form_helper
INFO - 2018-06-26 00:34:39 --> Helper loaded: date_helper
INFO - 2018-06-26 00:34:39 --> Helper loaded: util_helper
INFO - 2018-06-26 00:34:39 --> Helper loaded: text_helper
INFO - 2018-06-26 00:34:39 --> Helper loaded: string_helper
INFO - 2018-06-26 00:34:39 --> Database Driver Class Initialized
DEBUG - 2018-06-26 00:34:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-26 00:34:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-26 00:34:39 --> Email Class Initialized
INFO - 2018-06-26 00:34:39 --> Controller Class Initialized
DEBUG - 2018-06-26 00:34:39 --> videos MX_Controller Initialized
INFO - 2018-06-26 00:34:39 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-26 00:34:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-06-26 00:34:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-26 00:34:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-26 00:34:39 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-26 00:34:39 --> Login MX_Controller Initialized
DEBUG - 2018-06-26 00:34:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-26 00:34:39 --> Final output sent to browser
DEBUG - 2018-06-26 00:34:39 --> Total execution time: 0.3363
INFO - 2018-06-26 00:34:49 --> Config Class Initialized
INFO - 2018-06-26 00:34:49 --> Hooks Class Initialized
DEBUG - 2018-06-26 00:34:49 --> UTF-8 Support Enabled
INFO - 2018-06-26 00:34:49 --> Utf8 Class Initialized
INFO - 2018-06-26 00:34:49 --> URI Class Initialized
INFO - 2018-06-26 00:34:49 --> Router Class Initialized
INFO - 2018-06-26 00:34:49 --> Output Class Initialized
INFO - 2018-06-26 00:34:49 --> Security Class Initialized
DEBUG - 2018-06-26 00:34:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-26 00:34:49 --> Input Class Initialized
INFO - 2018-06-26 00:34:49 --> Language Class Initialized
INFO - 2018-06-26 00:34:49 --> Language Class Initialized
INFO - 2018-06-26 00:34:49 --> Config Class Initialized
INFO - 2018-06-26 00:34:49 --> Loader Class Initialized
DEBUG - 2018-06-26 00:34:49 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-26 00:34:49 --> Helper loaded: url_helper
INFO - 2018-06-26 00:34:49 --> Helper loaded: form_helper
INFO - 2018-06-26 00:34:49 --> Helper loaded: date_helper
INFO - 2018-06-26 00:34:49 --> Helper loaded: util_helper
INFO - 2018-06-26 00:34:49 --> Helper loaded: text_helper
INFO - 2018-06-26 00:34:49 --> Helper loaded: string_helper
INFO - 2018-06-26 00:34:49 --> Database Driver Class Initialized
DEBUG - 2018-06-26 00:34:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-26 00:34:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-26 00:34:49 --> Email Class Initialized
INFO - 2018-06-26 00:34:49 --> Controller Class Initialized
DEBUG - 2018-06-26 00:34:49 --> videos MX_Controller Initialized
INFO - 2018-06-26 00:34:49 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-26 00:34:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-06-26 00:34:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-26 00:34:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-26 00:34:49 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-26 00:34:49 --> Login MX_Controller Initialized
DEBUG - 2018-06-26 00:34:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-26 00:34:49 --> Final output sent to browser
DEBUG - 2018-06-26 00:34:49 --> Total execution time: 0.3136
INFO - 2018-06-26 00:48:24 --> Config Class Initialized
INFO - 2018-06-26 00:48:24 --> Hooks Class Initialized
DEBUG - 2018-06-26 00:48:24 --> UTF-8 Support Enabled
INFO - 2018-06-26 00:48:24 --> Utf8 Class Initialized
INFO - 2018-06-26 00:48:24 --> URI Class Initialized
DEBUG - 2018-06-26 00:48:24 --> No URI present. Default controller set.
INFO - 2018-06-26 00:48:24 --> Router Class Initialized
INFO - 2018-06-26 00:48:24 --> Output Class Initialized
INFO - 2018-06-26 00:48:24 --> Security Class Initialized
DEBUG - 2018-06-26 00:48:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-26 00:48:24 --> Input Class Initialized
INFO - 2018-06-26 00:48:24 --> Language Class Initialized
INFO - 2018-06-26 00:48:24 --> Language Class Initialized
INFO - 2018-06-26 00:48:24 --> Config Class Initialized
INFO - 2018-06-26 00:48:24 --> Loader Class Initialized
DEBUG - 2018-06-26 00:48:24 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-26 00:48:24 --> Helper loaded: url_helper
INFO - 2018-06-26 00:48:24 --> Helper loaded: form_helper
INFO - 2018-06-26 00:48:24 --> Helper loaded: date_helper
INFO - 2018-06-26 00:48:24 --> Helper loaded: util_helper
INFO - 2018-06-26 00:48:24 --> Helper loaded: text_helper
INFO - 2018-06-26 00:48:24 --> Helper loaded: string_helper
INFO - 2018-06-26 00:48:24 --> Database Driver Class Initialized
DEBUG - 2018-06-26 00:48:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-26 00:48:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-26 00:48:24 --> Email Class Initialized
INFO - 2018-06-26 00:48:24 --> Controller Class Initialized
DEBUG - 2018-06-26 00:48:24 --> Home MX_Controller Initialized
DEBUG - 2018-06-26 00:48:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-26 00:48:24 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-26 00:48:24 --> Login MX_Controller Initialized
INFO - 2018-06-26 00:48:24 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-26 00:48:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-26 00:48:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-26 00:48:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-26 00:48:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-26 00:48:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-26 00:48:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-26 00:48:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-26 00:48:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-06-26 00:48:24 --> Final output sent to browser
DEBUG - 2018-06-26 00:48:24 --> Total execution time: 0.3728
INFO - 2018-06-26 00:48:26 --> Config Class Initialized
INFO - 2018-06-26 00:48:26 --> Hooks Class Initialized
DEBUG - 2018-06-26 00:48:26 --> UTF-8 Support Enabled
INFO - 2018-06-26 00:48:26 --> Utf8 Class Initialized
INFO - 2018-06-26 00:48:26 --> URI Class Initialized
DEBUG - 2018-06-26 00:48:26 --> No URI present. Default controller set.
INFO - 2018-06-26 00:48:26 --> Router Class Initialized
INFO - 2018-06-26 00:48:26 --> Output Class Initialized
INFO - 2018-06-26 00:48:26 --> Security Class Initialized
DEBUG - 2018-06-26 00:48:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-26 00:48:26 --> Input Class Initialized
INFO - 2018-06-26 00:48:26 --> Language Class Initialized
INFO - 2018-06-26 00:48:26 --> Language Class Initialized
INFO - 2018-06-26 00:48:26 --> Config Class Initialized
INFO - 2018-06-26 00:48:26 --> Loader Class Initialized
DEBUG - 2018-06-26 00:48:26 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-26 00:48:26 --> Helper loaded: url_helper
INFO - 2018-06-26 00:48:26 --> Helper loaded: form_helper
INFO - 2018-06-26 00:48:26 --> Helper loaded: date_helper
INFO - 2018-06-26 00:48:26 --> Helper loaded: util_helper
INFO - 2018-06-26 00:48:26 --> Helper loaded: text_helper
INFO - 2018-06-26 00:48:26 --> Helper loaded: string_helper
INFO - 2018-06-26 00:48:27 --> Database Driver Class Initialized
DEBUG - 2018-06-26 00:48:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-26 00:48:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-26 00:48:27 --> Email Class Initialized
INFO - 2018-06-26 00:48:27 --> Controller Class Initialized
DEBUG - 2018-06-26 00:48:27 --> Home MX_Controller Initialized
DEBUG - 2018-06-26 00:48:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-26 00:48:27 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-26 00:48:27 --> Login MX_Controller Initialized
INFO - 2018-06-26 00:48:27 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-26 00:48:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-26 00:48:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-26 00:48:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-26 00:48:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-26 00:48:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-26 00:48:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-26 00:48:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-26 00:48:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-06-26 00:48:27 --> Final output sent to browser
DEBUG - 2018-06-26 00:48:27 --> Total execution time: 0.3902
INFO - 2018-06-26 00:48:28 --> Config Class Initialized
INFO - 2018-06-26 00:48:28 --> Hooks Class Initialized
DEBUG - 2018-06-26 00:48:28 --> UTF-8 Support Enabled
INFO - 2018-06-26 00:48:28 --> Utf8 Class Initialized
INFO - 2018-06-26 00:48:28 --> URI Class Initialized
INFO - 2018-06-26 00:48:28 --> Router Class Initialized
INFO - 2018-06-26 00:48:28 --> Output Class Initialized
INFO - 2018-06-26 00:48:28 --> Security Class Initialized
DEBUG - 2018-06-26 00:48:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-26 00:48:28 --> Input Class Initialized
INFO - 2018-06-26 00:48:28 --> Language Class Initialized
ERROR - 2018-06-26 00:48:28 --> 404 Page Not Found: /index
INFO - 2018-06-26 00:48:28 --> Config Class Initialized
INFO - 2018-06-26 00:48:28 --> Hooks Class Initialized
DEBUG - 2018-06-26 00:48:28 --> UTF-8 Support Enabled
INFO - 2018-06-26 00:48:28 --> Utf8 Class Initialized
INFO - 2018-06-26 00:48:28 --> URI Class Initialized
INFO - 2018-06-26 00:48:28 --> Router Class Initialized
INFO - 2018-06-26 00:48:28 --> Output Class Initialized
INFO - 2018-06-26 00:48:28 --> Security Class Initialized
DEBUG - 2018-06-26 00:48:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-26 00:48:28 --> Input Class Initialized
INFO - 2018-06-26 00:48:28 --> Language Class Initialized
ERROR - 2018-06-26 00:48:28 --> 404 Page Not Found: /index
INFO - 2018-06-26 00:48:28 --> Config Class Initialized
INFO - 2018-06-26 00:48:28 --> Hooks Class Initialized
DEBUG - 2018-06-26 00:48:28 --> UTF-8 Support Enabled
INFO - 2018-06-26 00:48:28 --> Utf8 Class Initialized
INFO - 2018-06-26 00:48:28 --> URI Class Initialized
INFO - 2018-06-26 00:48:28 --> Router Class Initialized
INFO - 2018-06-26 00:48:28 --> Output Class Initialized
INFO - 2018-06-26 00:48:28 --> Security Class Initialized
DEBUG - 2018-06-26 00:48:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-26 00:48:28 --> Input Class Initialized
INFO - 2018-06-26 00:48:28 --> Language Class Initialized
ERROR - 2018-06-26 00:48:28 --> 404 Page Not Found: /index
INFO - 2018-06-26 00:48:38 --> Config Class Initialized
INFO - 2018-06-26 00:48:38 --> Hooks Class Initialized
DEBUG - 2018-06-26 00:48:38 --> UTF-8 Support Enabled
INFO - 2018-06-26 00:48:38 --> Utf8 Class Initialized
INFO - 2018-06-26 00:48:38 --> URI Class Initialized
INFO - 2018-06-26 00:48:38 --> Router Class Initialized
INFO - 2018-06-26 00:48:38 --> Output Class Initialized
INFO - 2018-06-26 00:48:38 --> Security Class Initialized
DEBUG - 2018-06-26 00:48:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-26 00:48:38 --> Input Class Initialized
INFO - 2018-06-26 00:48:38 --> Language Class Initialized
INFO - 2018-06-26 00:48:38 --> Language Class Initialized
INFO - 2018-06-26 00:48:38 --> Config Class Initialized
INFO - 2018-06-26 00:48:38 --> Loader Class Initialized
DEBUG - 2018-06-26 00:48:38 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-26 00:48:38 --> Helper loaded: url_helper
INFO - 2018-06-26 00:48:38 --> Helper loaded: form_helper
INFO - 2018-06-26 00:48:38 --> Helper loaded: date_helper
INFO - 2018-06-26 00:48:38 --> Helper loaded: util_helper
INFO - 2018-06-26 00:48:38 --> Helper loaded: text_helper
INFO - 2018-06-26 00:48:38 --> Helper loaded: string_helper
INFO - 2018-06-26 00:48:38 --> Database Driver Class Initialized
DEBUG - 2018-06-26 00:48:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-26 00:48:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-26 00:48:38 --> Email Class Initialized
INFO - 2018-06-26 00:48:38 --> Controller Class Initialized
DEBUG - 2018-06-26 00:48:38 --> Home MX_Controller Initialized
DEBUG - 2018-06-26 00:48:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-26 00:48:38 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-26 00:48:38 --> Login MX_Controller Initialized
INFO - 2018-06-26 00:48:38 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-26 00:48:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-26 00:48:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-26 00:48:38 --> Config Class Initialized
INFO - 2018-06-26 00:48:38 --> Hooks Class Initialized
DEBUG - 2018-06-26 00:48:38 --> UTF-8 Support Enabled
INFO - 2018-06-26 00:48:38 --> Utf8 Class Initialized
INFO - 2018-06-26 00:48:38 --> URI Class Initialized
INFO - 2018-06-26 00:48:38 --> Router Class Initialized
INFO - 2018-06-26 00:48:38 --> Output Class Initialized
INFO - 2018-06-26 00:48:38 --> Security Class Initialized
DEBUG - 2018-06-26 00:48:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-26 00:48:38 --> Input Class Initialized
INFO - 2018-06-26 00:48:38 --> Language Class Initialized
INFO - 2018-06-26 00:48:39 --> Language Class Initialized
INFO - 2018-06-26 00:48:39 --> Config Class Initialized
INFO - 2018-06-26 00:48:39 --> Loader Class Initialized
DEBUG - 2018-06-26 00:48:39 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-26 00:48:39 --> Helper loaded: url_helper
INFO - 2018-06-26 00:48:39 --> Helper loaded: form_helper
INFO - 2018-06-26 00:48:39 --> Helper loaded: date_helper
INFO - 2018-06-26 00:48:39 --> Helper loaded: util_helper
INFO - 2018-06-26 00:48:39 --> Helper loaded: text_helper
INFO - 2018-06-26 00:48:39 --> Helper loaded: string_helper
INFO - 2018-06-26 00:48:39 --> Database Driver Class Initialized
DEBUG - 2018-06-26 00:48:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-26 00:48:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-26 00:48:39 --> Email Class Initialized
INFO - 2018-06-26 00:48:39 --> Controller Class Initialized
DEBUG - 2018-06-26 00:48:39 --> Home MX_Controller Initialized
DEBUG - 2018-06-26 00:48:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-26 00:48:39 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-26 00:48:39 --> Login MX_Controller Initialized
INFO - 2018-06-26 00:48:39 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-26 00:48:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-26 00:48:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-26 00:48:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-26 00:48:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-26 00:48:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-26 00:48:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-26 00:48:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-26 00:48:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-06-26 00:48:39 --> Final output sent to browser
DEBUG - 2018-06-26 00:48:39 --> Total execution time: 0.3738
INFO - 2018-06-26 00:48:39 --> Config Class Initialized
INFO - 2018-06-26 00:48:39 --> Hooks Class Initialized
DEBUG - 2018-06-26 00:48:39 --> UTF-8 Support Enabled
INFO - 2018-06-26 00:48:39 --> Utf8 Class Initialized
INFO - 2018-06-26 00:48:39 --> URI Class Initialized
INFO - 2018-06-26 00:48:39 --> Router Class Initialized
INFO - 2018-06-26 00:48:39 --> Output Class Initialized
INFO - 2018-06-26 00:48:39 --> Security Class Initialized
DEBUG - 2018-06-26 00:48:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-26 00:48:39 --> Input Class Initialized
INFO - 2018-06-26 00:48:39 --> Language Class Initialized
ERROR - 2018-06-26 00:48:40 --> 404 Page Not Found: /index
INFO - 2018-06-26 00:48:40 --> Config Class Initialized
INFO - 2018-06-26 00:48:40 --> Hooks Class Initialized
DEBUG - 2018-06-26 00:48:40 --> UTF-8 Support Enabled
INFO - 2018-06-26 00:48:40 --> Utf8 Class Initialized
INFO - 2018-06-26 00:48:40 --> URI Class Initialized
INFO - 2018-06-26 00:48:40 --> Router Class Initialized
INFO - 2018-06-26 00:48:40 --> Output Class Initialized
INFO - 2018-06-26 00:48:40 --> Security Class Initialized
DEBUG - 2018-06-26 00:48:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-26 00:48:40 --> Input Class Initialized
INFO - 2018-06-26 00:48:40 --> Language Class Initialized
ERROR - 2018-06-26 00:48:40 --> 404 Page Not Found: /index
INFO - 2018-06-26 00:48:40 --> Config Class Initialized
INFO - 2018-06-26 00:48:40 --> Hooks Class Initialized
DEBUG - 2018-06-26 00:48:40 --> UTF-8 Support Enabled
INFO - 2018-06-26 00:48:40 --> Utf8 Class Initialized
INFO - 2018-06-26 00:48:40 --> URI Class Initialized
INFO - 2018-06-26 00:48:40 --> Router Class Initialized
INFO - 2018-06-26 00:48:40 --> Output Class Initialized
INFO - 2018-06-26 00:48:40 --> Security Class Initialized
DEBUG - 2018-06-26 00:48:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-26 00:48:40 --> Input Class Initialized
INFO - 2018-06-26 00:48:40 --> Language Class Initialized
ERROR - 2018-06-26 00:48:40 --> 404 Page Not Found: /index
INFO - 2018-06-26 02:48:11 --> Config Class Initialized
INFO - 2018-06-26 02:48:11 --> Hooks Class Initialized
DEBUG - 2018-06-26 02:48:11 --> UTF-8 Support Enabled
INFO - 2018-06-26 02:48:11 --> Utf8 Class Initialized
INFO - 2018-06-26 02:48:11 --> URI Class Initialized
DEBUG - 2018-06-26 02:48:11 --> No URI present. Default controller set.
INFO - 2018-06-26 02:48:11 --> Router Class Initialized
INFO - 2018-06-26 02:48:11 --> Output Class Initialized
INFO - 2018-06-26 02:48:11 --> Security Class Initialized
DEBUG - 2018-06-26 02:48:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-26 02:48:11 --> Input Class Initialized
INFO - 2018-06-26 02:48:11 --> Language Class Initialized
INFO - 2018-06-26 02:48:11 --> Language Class Initialized
INFO - 2018-06-26 02:48:11 --> Config Class Initialized
INFO - 2018-06-26 02:48:11 --> Loader Class Initialized
DEBUG - 2018-06-26 02:48:11 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-26 02:48:11 --> Helper loaded: url_helper
INFO - 2018-06-26 02:48:11 --> Helper loaded: form_helper
INFO - 2018-06-26 02:48:11 --> Helper loaded: date_helper
INFO - 2018-06-26 02:48:11 --> Helper loaded: util_helper
INFO - 2018-06-26 02:48:11 --> Helper loaded: text_helper
INFO - 2018-06-26 02:48:11 --> Helper loaded: string_helper
INFO - 2018-06-26 02:48:11 --> Database Driver Class Initialized
DEBUG - 2018-06-26 02:48:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-26 02:48:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-26 02:48:11 --> Email Class Initialized
INFO - 2018-06-26 02:48:11 --> Controller Class Initialized
DEBUG - 2018-06-26 02:48:11 --> Home MX_Controller Initialized
DEBUG - 2018-06-26 02:48:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-26 02:48:11 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-26 02:48:11 --> Login MX_Controller Initialized
INFO - 2018-06-26 02:48:11 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-26 02:48:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-26 02:48:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-26 02:48:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-06-26 04:49:10 --> Config Class Initialized
INFO - 2018-06-26 04:49:10 --> Hooks Class Initialized
DEBUG - 2018-06-26 04:49:10 --> UTF-8 Support Enabled
INFO - 2018-06-26 04:49:10 --> Utf8 Class Initialized
INFO - 2018-06-26 04:49:10 --> URI Class Initialized
INFO - 2018-06-26 04:49:10 --> Router Class Initialized
INFO - 2018-06-26 04:49:10 --> Output Class Initialized
INFO - 2018-06-26 04:49:10 --> Security Class Initialized
DEBUG - 2018-06-26 04:49:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-26 04:49:10 --> Input Class Initialized
INFO - 2018-06-26 04:49:10 --> Language Class Initialized
INFO - 2018-06-26 04:49:10 --> Language Class Initialized
INFO - 2018-06-26 04:49:10 --> Config Class Initialized
INFO - 2018-06-26 04:49:10 --> Loader Class Initialized
DEBUG - 2018-06-26 04:49:10 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-26 04:49:10 --> Helper loaded: url_helper
INFO - 2018-06-26 04:49:10 --> Helper loaded: form_helper
INFO - 2018-06-26 04:49:10 --> Helper loaded: date_helper
INFO - 2018-06-26 04:49:10 --> Helper loaded: util_helper
INFO - 2018-06-26 04:49:10 --> Helper loaded: text_helper
INFO - 2018-06-26 04:49:10 --> Helper loaded: string_helper
INFO - 2018-06-26 04:49:10 --> Database Driver Class Initialized
DEBUG - 2018-06-26 04:49:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-26 04:49:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-26 04:49:10 --> Email Class Initialized
INFO - 2018-06-26 04:49:10 --> Controller Class Initialized
DEBUG - 2018-06-26 04:49:10 --> Home MX_Controller Initialized
DEBUG - 2018-06-26 04:49:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-26 04:49:10 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-26 04:49:10 --> Login MX_Controller Initialized
INFO - 2018-06-26 04:49:10 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-26 04:49:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-26 04:49:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-26 04:49:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-06-26 21:06:20 --> Config Class Initialized
INFO - 2018-06-26 21:06:20 --> Hooks Class Initialized
DEBUG - 2018-06-26 21:06:20 --> UTF-8 Support Enabled
INFO - 2018-06-26 21:06:20 --> Utf8 Class Initialized
INFO - 2018-06-26 21:06:20 --> URI Class Initialized
INFO - 2018-06-26 21:06:20 --> Router Class Initialized
INFO - 2018-06-26 21:06:20 --> Output Class Initialized
INFO - 2018-06-26 21:06:20 --> Security Class Initialized
DEBUG - 2018-06-26 21:06:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-26 21:06:20 --> Input Class Initialized
INFO - 2018-06-26 21:06:20 --> Language Class Initialized
INFO - 2018-06-26 21:06:21 --> Language Class Initialized
INFO - 2018-06-26 21:06:21 --> Config Class Initialized
INFO - 2018-06-26 21:06:21 --> Loader Class Initialized
DEBUG - 2018-06-26 21:06:21 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-26 21:06:21 --> Helper loaded: url_helper
INFO - 2018-06-26 21:06:21 --> Helper loaded: form_helper
INFO - 2018-06-26 21:06:21 --> Helper loaded: date_helper
INFO - 2018-06-26 21:06:21 --> Helper loaded: util_helper
INFO - 2018-06-26 21:06:21 --> Helper loaded: text_helper
INFO - 2018-06-26 21:06:21 --> Helper loaded: string_helper
INFO - 2018-06-26 21:06:21 --> Database Driver Class Initialized
DEBUG - 2018-06-26 21:06:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-26 21:06:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-26 21:06:21 --> Email Class Initialized
INFO - 2018-06-26 21:06:21 --> Controller Class Initialized
DEBUG - 2018-06-26 21:06:21 --> videos MX_Controller Initialized
INFO - 2018-06-26 21:06:21 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-26 21:06:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-06-26 21:06:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-26 21:06:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-26 21:06:22 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-26 21:06:22 --> Login MX_Controller Initialized
DEBUG - 2018-06-26 21:06:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-26 21:06:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
INFO - 2018-06-26 21:06:22 --> Config Class Initialized
INFO - 2018-06-26 21:06:22 --> Hooks Class Initialized
DEBUG - 2018-06-26 21:06:23 --> UTF-8 Support Enabled
INFO - 2018-06-26 21:06:23 --> Utf8 Class Initialized
INFO - 2018-06-26 21:06:23 --> URI Class Initialized
INFO - 2018-06-26 21:06:23 --> Router Class Initialized
INFO - 2018-06-26 21:06:23 --> Output Class Initialized
INFO - 2018-06-26 21:06:23 --> Security Class Initialized
DEBUG - 2018-06-26 21:06:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-26 21:06:23 --> Input Class Initialized
INFO - 2018-06-26 21:06:23 --> Language Class Initialized
ERROR - 2018-06-26 21:06:23 --> 404 Page Not Found: /index
INFO - 2018-06-26 21:11:46 --> Config Class Initialized
INFO - 2018-06-26 21:11:46 --> Hooks Class Initialized
DEBUG - 2018-06-26 21:11:46 --> UTF-8 Support Enabled
INFO - 2018-06-26 21:11:46 --> Utf8 Class Initialized
INFO - 2018-06-26 21:11:46 --> URI Class Initialized
DEBUG - 2018-06-26 21:11:46 --> No URI present. Default controller set.
INFO - 2018-06-26 21:11:46 --> Router Class Initialized
INFO - 2018-06-26 21:11:46 --> Output Class Initialized
INFO - 2018-06-26 21:11:46 --> Security Class Initialized
DEBUG - 2018-06-26 21:11:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-26 21:11:46 --> Input Class Initialized
INFO - 2018-06-26 21:11:46 --> Language Class Initialized
INFO - 2018-06-26 21:11:46 --> Language Class Initialized
INFO - 2018-06-26 21:11:46 --> Config Class Initialized
INFO - 2018-06-26 21:11:46 --> Loader Class Initialized
DEBUG - 2018-06-26 21:11:46 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-26 21:11:46 --> Helper loaded: url_helper
INFO - 2018-06-26 21:11:46 --> Helper loaded: form_helper
INFO - 2018-06-26 21:11:46 --> Helper loaded: date_helper
INFO - 2018-06-26 21:11:46 --> Helper loaded: util_helper
INFO - 2018-06-26 21:11:46 --> Helper loaded: text_helper
INFO - 2018-06-26 21:11:46 --> Helper loaded: string_helper
INFO - 2018-06-26 21:11:46 --> Database Driver Class Initialized
DEBUG - 2018-06-26 21:11:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-26 21:11:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-26 21:11:47 --> Email Class Initialized
INFO - 2018-06-26 21:11:47 --> Controller Class Initialized
DEBUG - 2018-06-26 21:11:47 --> Home MX_Controller Initialized
DEBUG - 2018-06-26 21:11:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-26 21:11:47 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-26 21:11:47 --> Login MX_Controller Initialized
INFO - 2018-06-26 21:11:47 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-26 21:11:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-26 21:11:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-26 21:11:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-06-26 21:15:59 --> Config Class Initialized
INFO - 2018-06-26 21:15:59 --> Hooks Class Initialized
DEBUG - 2018-06-26 21:15:59 --> UTF-8 Support Enabled
INFO - 2018-06-26 21:15:59 --> Utf8 Class Initialized
INFO - 2018-06-26 21:15:59 --> URI Class Initialized
INFO - 2018-06-26 21:15:59 --> Router Class Initialized
INFO - 2018-06-26 21:15:59 --> Output Class Initialized
INFO - 2018-06-26 21:15:59 --> Security Class Initialized
DEBUG - 2018-06-26 21:15:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-26 21:15:59 --> Input Class Initialized
INFO - 2018-06-26 21:15:59 --> Language Class Initialized
INFO - 2018-06-26 21:15:59 --> Language Class Initialized
INFO - 2018-06-26 21:15:59 --> Config Class Initialized
INFO - 2018-06-26 21:15:59 --> Loader Class Initialized
DEBUG - 2018-06-26 21:15:59 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-26 21:15:59 --> Helper loaded: url_helper
INFO - 2018-06-26 21:15:59 --> Helper loaded: form_helper
INFO - 2018-06-26 21:15:59 --> Helper loaded: date_helper
INFO - 2018-06-26 21:15:59 --> Helper loaded: util_helper
INFO - 2018-06-26 21:15:59 --> Helper loaded: text_helper
INFO - 2018-06-26 21:15:59 --> Helper loaded: string_helper
INFO - 2018-06-26 21:15:59 --> Database Driver Class Initialized
DEBUG - 2018-06-26 21:15:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-26 21:15:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-26 21:15:59 --> Email Class Initialized
INFO - 2018-06-26 21:15:59 --> Controller Class Initialized
DEBUG - 2018-06-26 21:15:59 --> Home MX_Controller Initialized
DEBUG - 2018-06-26 21:15:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-26 21:15:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-26 21:15:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
ERROR - 2018-06-26 21:15:59 --> Severity: Notice --> Undefined index: home_name E:\xampp\htdocs\consulting\application\modules\home\views\common\header.php 32
DEBUG - 2018-06-26 21:15:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-26 21:15:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-26 21:15:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-26 21:15:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/search_page.php
INFO - 2018-06-26 21:15:59 --> Final output sent to browser
DEBUG - 2018-06-26 21:15:59 --> Total execution time: 0.6131
INFO - 2018-06-26 21:16:00 --> Config Class Initialized
INFO - 2018-06-26 21:16:00 --> Hooks Class Initialized
DEBUG - 2018-06-26 21:16:00 --> UTF-8 Support Enabled
INFO - 2018-06-26 21:16:00 --> Utf8 Class Initialized
INFO - 2018-06-26 21:16:00 --> URI Class Initialized
INFO - 2018-06-26 21:16:00 --> Router Class Initialized
INFO - 2018-06-26 21:16:00 --> Output Class Initialized
INFO - 2018-06-26 21:16:00 --> Security Class Initialized
DEBUG - 2018-06-26 21:16:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-26 21:16:00 --> Input Class Initialized
INFO - 2018-06-26 21:16:00 --> Language Class Initialized
ERROR - 2018-06-26 21:16:00 --> 404 Page Not Found: /index
INFO - 2018-06-26 21:16:00 --> Config Class Initialized
INFO - 2018-06-26 21:16:00 --> Hooks Class Initialized
DEBUG - 2018-06-26 21:16:00 --> UTF-8 Support Enabled
INFO - 2018-06-26 21:16:00 --> Utf8 Class Initialized
INFO - 2018-06-26 21:16:00 --> URI Class Initialized
INFO - 2018-06-26 21:16:00 --> Router Class Initialized
INFO - 2018-06-26 21:16:00 --> Output Class Initialized
INFO - 2018-06-26 21:16:00 --> Security Class Initialized
DEBUG - 2018-06-26 21:16:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-26 21:16:00 --> Input Class Initialized
INFO - 2018-06-26 21:16:00 --> Language Class Initialized
ERROR - 2018-06-26 21:16:00 --> 404 Page Not Found: /index
INFO - 2018-06-26 21:16:00 --> Config Class Initialized
INFO - 2018-06-26 21:16:00 --> Hooks Class Initialized
DEBUG - 2018-06-26 21:16:00 --> UTF-8 Support Enabled
INFO - 2018-06-26 21:16:00 --> Utf8 Class Initialized
INFO - 2018-06-26 21:16:00 --> URI Class Initialized
INFO - 2018-06-26 21:16:00 --> Router Class Initialized
INFO - 2018-06-26 21:16:00 --> Config Class Initialized
INFO - 2018-06-26 21:16:00 --> Hooks Class Initialized
INFO - 2018-06-26 21:16:00 --> Output Class Initialized
INFO - 2018-06-26 21:16:00 --> Security Class Initialized
DEBUG - 2018-06-26 21:16:00 --> UTF-8 Support Enabled
INFO - 2018-06-26 21:16:00 --> Utf8 Class Initialized
DEBUG - 2018-06-26 21:16:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-26 21:16:00 --> Input Class Initialized
INFO - 2018-06-26 21:16:00 --> URI Class Initialized
INFO - 2018-06-26 21:16:00 --> Language Class Initialized
INFO - 2018-06-26 21:16:00 --> Router Class Initialized
ERROR - 2018-06-26 21:16:00 --> 404 Page Not Found: /index
INFO - 2018-06-26 21:16:00 --> Output Class Initialized
INFO - 2018-06-26 21:16:00 --> Security Class Initialized
DEBUG - 2018-06-26 21:16:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-26 21:16:00 --> Input Class Initialized
INFO - 2018-06-26 21:16:00 --> Language Class Initialized
INFO - 2018-06-26 21:16:00 --> Language Class Initialized
INFO - 2018-06-26 21:16:00 --> Config Class Initialized
INFO - 2018-06-26 21:16:00 --> Loader Class Initialized
DEBUG - 2018-06-26 21:16:00 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-26 21:16:00 --> Helper loaded: url_helper
INFO - 2018-06-26 21:16:00 --> Helper loaded: form_helper
INFO - 2018-06-26 21:16:00 --> Helper loaded: date_helper
INFO - 2018-06-26 21:16:00 --> Helper loaded: util_helper
INFO - 2018-06-26 21:16:00 --> Helper loaded: text_helper
INFO - 2018-06-26 21:16:00 --> Helper loaded: string_helper
INFO - 2018-06-26 21:16:00 --> Database Driver Class Initialized
DEBUG - 2018-06-26 21:16:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-26 21:16:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-26 21:16:00 --> Email Class Initialized
INFO - 2018-06-26 21:16:00 --> Controller Class Initialized
DEBUG - 2018-06-26 21:16:00 --> Home MX_Controller Initialized
DEBUG - 2018-06-26 21:16:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-26 21:16:01 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-26 21:16:01 --> Login MX_Controller Initialized
INFO - 2018-06-26 21:16:01 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-26 21:16:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-26 21:16:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-26 21:16:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-06-26 21:16:01 --> Config Class Initialized
INFO - 2018-06-26 21:16:01 --> Hooks Class Initialized
DEBUG - 2018-06-26 21:16:01 --> UTF-8 Support Enabled
INFO - 2018-06-26 21:16:01 --> Utf8 Class Initialized
INFO - 2018-06-26 21:16:01 --> URI Class Initialized
INFO - 2018-06-26 21:16:01 --> Router Class Initialized
INFO - 2018-06-26 21:16:01 --> Output Class Initialized
INFO - 2018-06-26 21:16:01 --> Security Class Initialized
DEBUG - 2018-06-26 21:16:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-26 21:16:01 --> Input Class Initialized
INFO - 2018-06-26 21:16:01 --> Language Class Initialized
ERROR - 2018-06-26 21:16:01 --> 404 Page Not Found: /index
INFO - 2018-06-26 21:16:01 --> Config Class Initialized
INFO - 2018-06-26 21:16:01 --> Hooks Class Initialized
DEBUG - 2018-06-26 21:16:01 --> UTF-8 Support Enabled
INFO - 2018-06-26 21:16:01 --> Utf8 Class Initialized
INFO - 2018-06-26 21:16:01 --> URI Class Initialized
INFO - 2018-06-26 21:16:01 --> Router Class Initialized
INFO - 2018-06-26 21:16:01 --> Output Class Initialized
INFO - 2018-06-26 21:16:01 --> Security Class Initialized
DEBUG - 2018-06-26 21:16:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-26 21:16:01 --> Input Class Initialized
INFO - 2018-06-26 21:16:01 --> Language Class Initialized
ERROR - 2018-06-26 21:16:01 --> 404 Page Not Found: /index
INFO - 2018-06-26 21:16:01 --> Config Class Initialized
INFO - 2018-06-26 21:16:01 --> Hooks Class Initialized
DEBUG - 2018-06-26 21:16:01 --> UTF-8 Support Enabled
INFO - 2018-06-26 21:16:01 --> Utf8 Class Initialized
INFO - 2018-06-26 21:16:01 --> URI Class Initialized
INFO - 2018-06-26 21:16:01 --> Router Class Initialized
INFO - 2018-06-26 21:16:01 --> Output Class Initialized
INFO - 2018-06-26 21:16:01 --> Security Class Initialized
DEBUG - 2018-06-26 21:16:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-26 21:16:01 --> Input Class Initialized
INFO - 2018-06-26 21:16:01 --> Language Class Initialized
ERROR - 2018-06-26 21:16:01 --> 404 Page Not Found: /index
INFO - 2018-06-26 21:16:02 --> Config Class Initialized
INFO - 2018-06-26 21:16:02 --> Hooks Class Initialized
DEBUG - 2018-06-26 21:16:02 --> UTF-8 Support Enabled
INFO - 2018-06-26 21:16:02 --> Utf8 Class Initialized
INFO - 2018-06-26 21:16:02 --> URI Class Initialized
DEBUG - 2018-06-26 21:16:02 --> No URI present. Default controller set.
INFO - 2018-06-26 21:16:02 --> Router Class Initialized
INFO - 2018-06-26 21:16:02 --> Output Class Initialized
INFO - 2018-06-26 21:16:02 --> Security Class Initialized
DEBUG - 2018-06-26 21:16:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-26 21:16:02 --> Input Class Initialized
INFO - 2018-06-26 21:16:02 --> Language Class Initialized
INFO - 2018-06-26 21:16:02 --> Language Class Initialized
INFO - 2018-06-26 21:16:02 --> Config Class Initialized
INFO - 2018-06-26 21:16:02 --> Loader Class Initialized
DEBUG - 2018-06-26 21:16:02 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-26 21:16:02 --> Helper loaded: url_helper
INFO - 2018-06-26 21:16:02 --> Helper loaded: form_helper
INFO - 2018-06-26 21:16:02 --> Helper loaded: date_helper
INFO - 2018-06-26 21:16:02 --> Helper loaded: util_helper
INFO - 2018-06-26 21:16:02 --> Helper loaded: text_helper
INFO - 2018-06-26 21:16:02 --> Helper loaded: string_helper
INFO - 2018-06-26 21:16:02 --> Database Driver Class Initialized
DEBUG - 2018-06-26 21:16:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-26 21:16:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-26 21:16:02 --> Email Class Initialized
INFO - 2018-06-26 21:16:02 --> Controller Class Initialized
DEBUG - 2018-06-26 21:16:02 --> Home MX_Controller Initialized
DEBUG - 2018-06-26 21:16:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-26 21:16:02 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-26 21:16:02 --> Login MX_Controller Initialized
INFO - 2018-06-26 21:16:02 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-26 21:16:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-26 21:16:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-26 21:16:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-06-26 21:18:11 --> Config Class Initialized
INFO - 2018-06-26 21:18:11 --> Hooks Class Initialized
DEBUG - 2018-06-26 21:18:11 --> UTF-8 Support Enabled
INFO - 2018-06-26 21:18:11 --> Utf8 Class Initialized
INFO - 2018-06-26 21:18:11 --> URI Class Initialized
INFO - 2018-06-26 21:18:11 --> Router Class Initialized
INFO - 2018-06-26 21:18:11 --> Output Class Initialized
INFO - 2018-06-26 21:18:11 --> Security Class Initialized
DEBUG - 2018-06-26 21:18:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-26 21:18:12 --> Input Class Initialized
INFO - 2018-06-26 21:18:12 --> Language Class Initialized
INFO - 2018-06-26 21:18:12 --> Language Class Initialized
INFO - 2018-06-26 21:18:12 --> Config Class Initialized
INFO - 2018-06-26 21:18:12 --> Loader Class Initialized
DEBUG - 2018-06-26 21:18:12 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-26 21:18:12 --> Helper loaded: url_helper
INFO - 2018-06-26 21:18:12 --> Helper loaded: form_helper
INFO - 2018-06-26 21:18:12 --> Helper loaded: date_helper
INFO - 2018-06-26 21:18:12 --> Helper loaded: util_helper
INFO - 2018-06-26 21:18:12 --> Helper loaded: text_helper
INFO - 2018-06-26 21:18:12 --> Helper loaded: string_helper
INFO - 2018-06-26 21:18:12 --> Database Driver Class Initialized
DEBUG - 2018-06-26 21:18:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-26 21:18:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-26 21:18:12 --> Email Class Initialized
INFO - 2018-06-26 21:18:12 --> Controller Class Initialized
DEBUG - 2018-06-26 21:18:12 --> Home MX_Controller Initialized
DEBUG - 2018-06-26 21:18:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-26 21:18:12 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-26 21:18:12 --> Login MX_Controller Initialized
INFO - 2018-06-26 21:18:12 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-26 21:18:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-26 21:18:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-26 21:18:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-06-26 21:18:20 --> Config Class Initialized
INFO - 2018-06-26 21:18:20 --> Hooks Class Initialized
DEBUG - 2018-06-26 21:18:20 --> UTF-8 Support Enabled
INFO - 2018-06-26 21:18:20 --> Utf8 Class Initialized
INFO - 2018-06-26 21:18:20 --> URI Class Initialized
DEBUG - 2018-06-26 21:18:20 --> No URI present. Default controller set.
INFO - 2018-06-26 21:18:20 --> Router Class Initialized
INFO - 2018-06-26 21:18:20 --> Output Class Initialized
INFO - 2018-06-26 21:18:20 --> Security Class Initialized
DEBUG - 2018-06-26 21:18:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-26 21:18:20 --> Input Class Initialized
INFO - 2018-06-26 21:18:20 --> Language Class Initialized
INFO - 2018-06-26 21:18:20 --> Language Class Initialized
INFO - 2018-06-26 21:18:20 --> Config Class Initialized
INFO - 2018-06-26 21:18:20 --> Loader Class Initialized
DEBUG - 2018-06-26 21:18:20 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-26 21:18:20 --> Helper loaded: url_helper
INFO - 2018-06-26 21:18:20 --> Helper loaded: form_helper
INFO - 2018-06-26 21:18:20 --> Helper loaded: date_helper
INFO - 2018-06-26 21:18:20 --> Helper loaded: util_helper
INFO - 2018-06-26 21:18:20 --> Helper loaded: text_helper
INFO - 2018-06-26 21:18:20 --> Helper loaded: string_helper
INFO - 2018-06-26 21:18:20 --> Database Driver Class Initialized
DEBUG - 2018-06-26 21:18:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-26 21:18:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-26 21:18:20 --> Email Class Initialized
INFO - 2018-06-26 21:18:20 --> Controller Class Initialized
DEBUG - 2018-06-26 21:18:20 --> Home MX_Controller Initialized
DEBUG - 2018-06-26 21:18:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-26 21:18:20 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-26 21:18:20 --> Login MX_Controller Initialized
INFO - 2018-06-26 21:18:20 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-26 21:18:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-26 21:18:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-26 21:18:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-06-26 22:53:26 --> Config Class Initialized
INFO - 2018-06-26 22:53:26 --> Hooks Class Initialized
DEBUG - 2018-06-26 22:53:26 --> UTF-8 Support Enabled
INFO - 2018-06-26 22:53:26 --> Utf8 Class Initialized
INFO - 2018-06-26 22:53:26 --> URI Class Initialized
DEBUG - 2018-06-26 22:53:26 --> No URI present. Default controller set.
INFO - 2018-06-26 22:53:26 --> Router Class Initialized
INFO - 2018-06-26 22:53:26 --> Output Class Initialized
INFO - 2018-06-26 22:53:26 --> Security Class Initialized
DEBUG - 2018-06-26 22:53:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-26 22:53:26 --> Input Class Initialized
INFO - 2018-06-26 22:53:26 --> Language Class Initialized
INFO - 2018-06-26 22:53:26 --> Language Class Initialized
INFO - 2018-06-26 22:53:26 --> Config Class Initialized
INFO - 2018-06-26 22:53:27 --> Loader Class Initialized
DEBUG - 2018-06-26 22:53:27 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-26 22:53:27 --> Helper loaded: url_helper
INFO - 2018-06-26 22:53:27 --> Helper loaded: form_helper
INFO - 2018-06-26 22:53:27 --> Helper loaded: date_helper
INFO - 2018-06-26 22:53:27 --> Helper loaded: util_helper
INFO - 2018-06-26 22:53:27 --> Helper loaded: text_helper
INFO - 2018-06-26 22:53:27 --> Helper loaded: string_helper
INFO - 2018-06-26 22:53:27 --> Database Driver Class Initialized
DEBUG - 2018-06-26 22:53:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-26 22:53:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-26 22:53:27 --> Email Class Initialized
INFO - 2018-06-26 22:53:27 --> Controller Class Initialized
DEBUG - 2018-06-26 22:53:27 --> Home MX_Controller Initialized
DEBUG - 2018-06-26 22:53:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-26 22:53:27 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-26 22:53:27 --> Login MX_Controller Initialized
INFO - 2018-06-26 22:53:27 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-26 22:53:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-26 22:53:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-26 22:53:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
