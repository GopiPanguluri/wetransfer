<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-06-27 01:47:40 --> Config Class Initialized
INFO - 2018-06-27 01:47:40 --> Hooks Class Initialized
DEBUG - 2018-06-27 01:47:40 --> UTF-8 Support Enabled
INFO - 2018-06-27 01:47:40 --> Utf8 Class Initialized
INFO - 2018-06-27 01:47:40 --> URI Class Initialized
INFO - 2018-06-27 01:47:40 --> Router Class Initialized
INFO - 2018-06-27 01:47:40 --> Output Class Initialized
INFO - 2018-06-27 01:47:40 --> Security Class Initialized
DEBUG - 2018-06-27 01:47:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-27 01:47:40 --> Input Class Initialized
INFO - 2018-06-27 01:47:40 --> Language Class Initialized
INFO - 2018-06-27 01:47:40 --> Language Class Initialized
INFO - 2018-06-27 01:47:40 --> Config Class Initialized
INFO - 2018-06-27 01:47:40 --> Loader Class Initialized
DEBUG - 2018-06-27 01:47:40 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-27 01:47:40 --> Helper loaded: url_helper
INFO - 2018-06-27 01:47:40 --> Helper loaded: form_helper
INFO - 2018-06-27 01:47:40 --> Helper loaded: date_helper
INFO - 2018-06-27 01:47:40 --> Helper loaded: util_helper
INFO - 2018-06-27 01:47:40 --> Helper loaded: text_helper
INFO - 2018-06-27 01:47:40 --> Helper loaded: string_helper
INFO - 2018-06-27 01:47:41 --> Database Driver Class Initialized
DEBUG - 2018-06-27 01:47:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-27 01:47:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-27 01:47:41 --> Email Class Initialized
INFO - 2018-06-27 01:47:41 --> Controller Class Initialized
DEBUG - 2018-06-27 01:47:41 --> Login MX_Controller Initialized
INFO - 2018-06-27 01:47:41 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-27 01:47:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-27 01:47:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-27 01:47:41 --> Email starts for admin@colin.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-06-27 01:47:41 --> User session created for 1
INFO - 2018-06-27 01:47:41 --> Login status admin@colin.com - success
INFO - 2018-06-27 01:47:41 --> Final output sent to browser
DEBUG - 2018-06-27 01:47:41 --> Total execution time: 1.0127
INFO - 2018-06-27 01:47:41 --> Config Class Initialized
INFO - 2018-06-27 01:47:41 --> Hooks Class Initialized
DEBUG - 2018-06-27 01:47:41 --> UTF-8 Support Enabled
INFO - 2018-06-27 01:47:41 --> Utf8 Class Initialized
INFO - 2018-06-27 01:47:41 --> URI Class Initialized
INFO - 2018-06-27 01:47:41 --> Router Class Initialized
INFO - 2018-06-27 01:47:41 --> Output Class Initialized
INFO - 2018-06-27 01:47:41 --> Security Class Initialized
DEBUG - 2018-06-27 01:47:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-27 01:47:41 --> Input Class Initialized
INFO - 2018-06-27 01:47:41 --> Language Class Initialized
INFO - 2018-06-27 01:47:41 --> Language Class Initialized
INFO - 2018-06-27 01:47:41 --> Config Class Initialized
INFO - 2018-06-27 01:47:41 --> Loader Class Initialized
DEBUG - 2018-06-27 01:47:41 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-27 01:47:41 --> Helper loaded: url_helper
INFO - 2018-06-27 01:47:41 --> Helper loaded: form_helper
INFO - 2018-06-27 01:47:41 --> Helper loaded: date_helper
INFO - 2018-06-27 01:47:41 --> Helper loaded: util_helper
INFO - 2018-06-27 01:47:41 --> Helper loaded: text_helper
INFO - 2018-06-27 01:47:41 --> Helper loaded: string_helper
INFO - 2018-06-27 01:47:41 --> Database Driver Class Initialized
DEBUG - 2018-06-27 01:47:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-27 01:47:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-27 01:47:41 --> Email Class Initialized
INFO - 2018-06-27 01:47:41 --> Controller Class Initialized
DEBUG - 2018-06-27 01:47:41 --> videos MX_Controller Initialized
INFO - 2018-06-27 01:47:41 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-27 01:47:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-06-27 01:47:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-27 01:47:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-27 01:47:41 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-27 01:47:41 --> Login MX_Controller Initialized
DEBUG - 2018-06-27 01:47:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-27 01:47:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-27 01:47:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-27 01:47:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-27 01:47:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-27 01:47:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-27 01:47:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/videos/videos.php
INFO - 2018-06-27 01:47:41 --> Final output sent to browser
DEBUG - 2018-06-27 01:47:42 --> Total execution time: 0.5699
INFO - 2018-06-27 01:47:43 --> Config Class Initialized
INFO - 2018-06-27 01:47:43 --> Hooks Class Initialized
DEBUG - 2018-06-27 01:47:43 --> UTF-8 Support Enabled
INFO - 2018-06-27 01:47:43 --> Utf8 Class Initialized
INFO - 2018-06-27 01:47:43 --> URI Class Initialized
INFO - 2018-06-27 01:47:43 --> Router Class Initialized
INFO - 2018-06-27 01:47:43 --> Output Class Initialized
INFO - 2018-06-27 01:47:43 --> Security Class Initialized
DEBUG - 2018-06-27 01:47:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-27 01:47:43 --> Input Class Initialized
INFO - 2018-06-27 01:47:43 --> Language Class Initialized
INFO - 2018-06-27 01:47:43 --> Language Class Initialized
INFO - 2018-06-27 01:47:43 --> Config Class Initialized
INFO - 2018-06-27 01:47:43 --> Loader Class Initialized
DEBUG - 2018-06-27 01:47:43 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-27 01:47:43 --> Helper loaded: url_helper
INFO - 2018-06-27 01:47:43 --> Helper loaded: form_helper
INFO - 2018-06-27 01:47:43 --> Helper loaded: date_helper
INFO - 2018-06-27 01:47:43 --> Helper loaded: util_helper
INFO - 2018-06-27 01:47:43 --> Helper loaded: text_helper
INFO - 2018-06-27 01:47:43 --> Helper loaded: string_helper
INFO - 2018-06-27 01:47:43 --> Database Driver Class Initialized
DEBUG - 2018-06-27 01:47:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-27 01:47:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-27 01:47:43 --> Email Class Initialized
INFO - 2018-06-27 01:47:43 --> Controller Class Initialized
DEBUG - 2018-06-27 01:47:43 --> videos MX_Controller Initialized
INFO - 2018-06-27 01:47:43 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-27 01:47:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-06-27 01:47:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-27 01:47:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-27 01:47:43 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-27 01:47:43 --> Login MX_Controller Initialized
DEBUG - 2018-06-27 01:47:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-27 01:47:44 --> Final output sent to browser
DEBUG - 2018-06-27 01:47:44 --> Total execution time: 0.9252
INFO - 2018-06-27 01:47:48 --> Config Class Initialized
INFO - 2018-06-27 01:47:48 --> Hooks Class Initialized
DEBUG - 2018-06-27 01:47:49 --> UTF-8 Support Enabled
INFO - 2018-06-27 01:47:49 --> Utf8 Class Initialized
INFO - 2018-06-27 01:47:49 --> URI Class Initialized
INFO - 2018-06-27 01:47:49 --> Router Class Initialized
INFO - 2018-06-27 01:47:49 --> Output Class Initialized
INFO - 2018-06-27 01:47:49 --> Security Class Initialized
DEBUG - 2018-06-27 01:47:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-27 01:47:49 --> Input Class Initialized
INFO - 2018-06-27 01:47:49 --> Language Class Initialized
INFO - 2018-06-27 01:47:49 --> Language Class Initialized
INFO - 2018-06-27 01:47:49 --> Config Class Initialized
INFO - 2018-06-27 01:47:49 --> Loader Class Initialized
DEBUG - 2018-06-27 01:47:49 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-27 01:47:49 --> Helper loaded: url_helper
INFO - 2018-06-27 01:47:49 --> Helper loaded: form_helper
INFO - 2018-06-27 01:47:49 --> Helper loaded: date_helper
INFO - 2018-06-27 01:47:49 --> Helper loaded: util_helper
INFO - 2018-06-27 01:47:49 --> Helper loaded: text_helper
INFO - 2018-06-27 01:47:49 --> Helper loaded: string_helper
INFO - 2018-06-27 01:47:49 --> Database Driver Class Initialized
DEBUG - 2018-06-27 01:47:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-27 01:47:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-27 01:47:49 --> Email Class Initialized
INFO - 2018-06-27 01:47:49 --> Controller Class Initialized
DEBUG - 2018-06-27 01:47:49 --> Users MX_Controller Initialized
DEBUG - 2018-06-27 01:47:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-27 01:47:49 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-27 01:47:49 --> Login MX_Controller Initialized
INFO - 2018-06-27 01:47:49 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-27 01:47:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-27 01:47:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-27 01:47:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-27 01:47:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-27 01:47:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-27 01:47:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-27 01:47:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-06-27 01:47:49 --> Final output sent to browser
DEBUG - 2018-06-27 01:47:49 --> Total execution time: 0.4040
INFO - 2018-06-27 01:47:49 --> Config Class Initialized
INFO - 2018-06-27 01:47:49 --> Hooks Class Initialized
DEBUG - 2018-06-27 01:47:49 --> UTF-8 Support Enabled
INFO - 2018-06-27 01:47:49 --> Utf8 Class Initialized
INFO - 2018-06-27 01:47:49 --> URI Class Initialized
INFO - 2018-06-27 01:47:49 --> Router Class Initialized
INFO - 2018-06-27 01:47:49 --> Output Class Initialized
INFO - 2018-06-27 01:47:49 --> Security Class Initialized
DEBUG - 2018-06-27 01:47:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-27 01:47:49 --> Input Class Initialized
INFO - 2018-06-27 01:47:49 --> Language Class Initialized
INFO - 2018-06-27 01:47:49 --> Language Class Initialized
INFO - 2018-06-27 01:47:49 --> Config Class Initialized
INFO - 2018-06-27 01:47:49 --> Loader Class Initialized
DEBUG - 2018-06-27 01:47:49 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-27 01:47:49 --> Helper loaded: url_helper
INFO - 2018-06-27 01:47:49 --> Helper loaded: form_helper
INFO - 2018-06-27 01:47:49 --> Helper loaded: date_helper
INFO - 2018-06-27 01:47:49 --> Helper loaded: util_helper
INFO - 2018-06-27 01:47:49 --> Helper loaded: text_helper
INFO - 2018-06-27 01:47:49 --> Helper loaded: string_helper
INFO - 2018-06-27 01:47:50 --> Database Driver Class Initialized
DEBUG - 2018-06-27 01:47:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-27 01:47:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-27 01:47:50 --> Email Class Initialized
INFO - 2018-06-27 01:47:50 --> Controller Class Initialized
DEBUG - 2018-06-27 01:47:50 --> Users MX_Controller Initialized
DEBUG - 2018-06-27 01:47:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-27 01:47:50 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-27 01:47:50 --> Login MX_Controller Initialized
INFO - 2018-06-27 01:47:50 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-27 01:47:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-27 01:47:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-06-27 01:47:50 --> Final output sent to browser
DEBUG - 2018-06-27 01:47:50 --> Total execution time: 0.5085
INFO - 2018-06-27 02:50:54 --> Config Class Initialized
INFO - 2018-06-27 02:50:54 --> Hooks Class Initialized
DEBUG - 2018-06-27 02:50:54 --> UTF-8 Support Enabled
INFO - 2018-06-27 02:50:54 --> Utf8 Class Initialized
INFO - 2018-06-27 02:50:54 --> URI Class Initialized
DEBUG - 2018-06-27 02:50:54 --> No URI present. Default controller set.
INFO - 2018-06-27 02:50:54 --> Router Class Initialized
INFO - 2018-06-27 02:50:54 --> Output Class Initialized
INFO - 2018-06-27 02:50:54 --> Security Class Initialized
DEBUG - 2018-06-27 02:50:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-27 02:50:54 --> Input Class Initialized
INFO - 2018-06-27 02:50:54 --> Language Class Initialized
INFO - 2018-06-27 02:50:54 --> Language Class Initialized
INFO - 2018-06-27 02:50:54 --> Config Class Initialized
INFO - 2018-06-27 02:50:54 --> Loader Class Initialized
DEBUG - 2018-06-27 02:50:54 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-27 02:50:54 --> Helper loaded: url_helper
INFO - 2018-06-27 02:50:54 --> Helper loaded: form_helper
INFO - 2018-06-27 02:50:54 --> Helper loaded: date_helper
INFO - 2018-06-27 02:50:54 --> Helper loaded: util_helper
INFO - 2018-06-27 02:50:54 --> Helper loaded: text_helper
INFO - 2018-06-27 02:50:54 --> Helper loaded: string_helper
INFO - 2018-06-27 02:50:54 --> Database Driver Class Initialized
DEBUG - 2018-06-27 02:50:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-27 02:50:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-27 02:50:54 --> Email Class Initialized
INFO - 2018-06-27 02:50:54 --> Controller Class Initialized
DEBUG - 2018-06-27 02:50:54 --> Home MX_Controller Initialized
DEBUG - 2018-06-27 02:50:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-27 02:50:54 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-27 02:50:54 --> Login MX_Controller Initialized
INFO - 2018-06-27 02:50:54 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-27 02:50:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-27 02:50:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-27 02:50:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-06-27 04:56:24 --> Config Class Initialized
INFO - 2018-06-27 04:56:24 --> Hooks Class Initialized
DEBUG - 2018-06-27 04:56:24 --> UTF-8 Support Enabled
INFO - 2018-06-27 04:56:24 --> Utf8 Class Initialized
INFO - 2018-06-27 04:56:24 --> URI Class Initialized
INFO - 2018-06-27 04:56:24 --> Router Class Initialized
INFO - 2018-06-27 04:56:24 --> Output Class Initialized
INFO - 2018-06-27 04:56:24 --> Security Class Initialized
DEBUG - 2018-06-27 04:56:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-27 04:56:24 --> Input Class Initialized
INFO - 2018-06-27 04:56:24 --> Language Class Initialized
INFO - 2018-06-27 04:56:24 --> Language Class Initialized
INFO - 2018-06-27 04:56:24 --> Config Class Initialized
INFO - 2018-06-27 04:56:24 --> Loader Class Initialized
DEBUG - 2018-06-27 04:56:24 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-27 04:56:24 --> Helper loaded: url_helper
INFO - 2018-06-27 04:56:24 --> Helper loaded: form_helper
INFO - 2018-06-27 04:56:24 --> Helper loaded: date_helper
INFO - 2018-06-27 04:56:24 --> Helper loaded: util_helper
INFO - 2018-06-27 04:56:24 --> Helper loaded: text_helper
INFO - 2018-06-27 04:56:24 --> Helper loaded: string_helper
INFO - 2018-06-27 04:56:24 --> Database Driver Class Initialized
DEBUG - 2018-06-27 04:56:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-27 04:56:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-27 04:56:25 --> Email Class Initialized
INFO - 2018-06-27 04:56:25 --> Controller Class Initialized
DEBUG - 2018-06-27 04:56:25 --> Programs MX_Controller Initialized
INFO - 2018-06-27 04:56:25 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-27 04:56:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-06-27 04:56:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-27 04:56:25 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-27 04:56:25 --> Login MX_Controller Initialized
DEBUG - 2018-06-27 04:56:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-27 04:56:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
INFO - 2018-06-27 04:56:25 --> Config Class Initialized
INFO - 2018-06-27 04:56:25 --> Hooks Class Initialized
DEBUG - 2018-06-27 04:56:25 --> UTF-8 Support Enabled
INFO - 2018-06-27 04:56:25 --> Utf8 Class Initialized
INFO - 2018-06-27 04:56:25 --> URI Class Initialized
INFO - 2018-06-27 04:56:25 --> Router Class Initialized
INFO - 2018-06-27 04:56:25 --> Output Class Initialized
INFO - 2018-06-27 04:56:25 --> Security Class Initialized
DEBUG - 2018-06-27 04:56:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-27 04:56:25 --> Input Class Initialized
INFO - 2018-06-27 04:56:25 --> Language Class Initialized
ERROR - 2018-06-27 04:56:25 --> 404 Page Not Found: /index
INFO - 2018-06-27 04:56:28 --> Config Class Initialized
INFO - 2018-06-27 04:56:28 --> Hooks Class Initialized
DEBUG - 2018-06-27 04:56:28 --> UTF-8 Support Enabled
INFO - 2018-06-27 04:56:28 --> Utf8 Class Initialized
INFO - 2018-06-27 04:56:28 --> URI Class Initialized
INFO - 2018-06-27 04:56:28 --> Router Class Initialized
INFO - 2018-06-27 04:56:28 --> Output Class Initialized
INFO - 2018-06-27 04:56:28 --> Security Class Initialized
DEBUG - 2018-06-27 04:56:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-27 04:56:28 --> Input Class Initialized
INFO - 2018-06-27 04:56:28 --> Language Class Initialized
INFO - 2018-06-27 04:56:28 --> Language Class Initialized
INFO - 2018-06-27 04:56:28 --> Config Class Initialized
INFO - 2018-06-27 04:56:28 --> Loader Class Initialized
DEBUG - 2018-06-27 04:56:28 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-27 04:56:28 --> Helper loaded: url_helper
INFO - 2018-06-27 04:56:28 --> Helper loaded: form_helper
INFO - 2018-06-27 04:56:28 --> Helper loaded: date_helper
INFO - 2018-06-27 04:56:28 --> Helper loaded: util_helper
INFO - 2018-06-27 04:56:28 --> Helper loaded: text_helper
INFO - 2018-06-27 04:56:28 --> Helper loaded: string_helper
INFO - 2018-06-27 04:56:28 --> Database Driver Class Initialized
DEBUG - 2018-06-27 04:56:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-27 04:56:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-27 04:56:28 --> Email Class Initialized
INFO - 2018-06-27 04:56:28 --> Controller Class Initialized
DEBUG - 2018-06-27 04:56:28 --> Login MX_Controller Initialized
INFO - 2018-06-27 04:56:28 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-27 04:56:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-27 04:56:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-27 04:56:28 --> Email starts for admin@colin.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-06-27 04:56:28 --> User session created for 1
INFO - 2018-06-27 04:56:28 --> Login status admin@colin.com - success
INFO - 2018-06-27 04:56:28 --> Final output sent to browser
DEBUG - 2018-06-27 04:56:28 --> Total execution time: 0.4108
INFO - 2018-06-27 04:56:28 --> Config Class Initialized
INFO - 2018-06-27 04:56:28 --> Hooks Class Initialized
DEBUG - 2018-06-27 04:56:28 --> UTF-8 Support Enabled
INFO - 2018-06-27 04:56:28 --> Utf8 Class Initialized
INFO - 2018-06-27 04:56:28 --> URI Class Initialized
INFO - 2018-06-27 04:56:28 --> Router Class Initialized
INFO - 2018-06-27 04:56:28 --> Output Class Initialized
INFO - 2018-06-27 04:56:28 --> Security Class Initialized
DEBUG - 2018-06-27 04:56:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-27 04:56:28 --> Input Class Initialized
INFO - 2018-06-27 04:56:29 --> Language Class Initialized
INFO - 2018-06-27 04:56:29 --> Language Class Initialized
INFO - 2018-06-27 04:56:29 --> Config Class Initialized
INFO - 2018-06-27 04:56:29 --> Loader Class Initialized
DEBUG - 2018-06-27 04:56:29 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-27 04:56:29 --> Helper loaded: url_helper
INFO - 2018-06-27 04:56:29 --> Helper loaded: form_helper
INFO - 2018-06-27 04:56:29 --> Helper loaded: date_helper
INFO - 2018-06-27 04:56:29 --> Helper loaded: util_helper
INFO - 2018-06-27 04:56:29 --> Helper loaded: text_helper
INFO - 2018-06-27 04:56:29 --> Helper loaded: string_helper
INFO - 2018-06-27 04:56:29 --> Database Driver Class Initialized
DEBUG - 2018-06-27 04:56:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-27 04:56:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-27 04:56:29 --> Email Class Initialized
INFO - 2018-06-27 04:56:29 --> Controller Class Initialized
DEBUG - 2018-06-27 04:56:29 --> Programs MX_Controller Initialized
INFO - 2018-06-27 04:56:29 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-27 04:56:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-06-27 04:56:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-27 04:56:29 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-27 04:56:29 --> Login MX_Controller Initialized
DEBUG - 2018-06-27 04:56:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-27 04:56:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-27 04:56:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-27 04:56:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-27 04:56:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-27 04:56:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-27 04:56:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/programs.php
INFO - 2018-06-27 04:56:29 --> Final output sent to browser
DEBUG - 2018-06-27 04:56:29 --> Total execution time: 0.4341
INFO - 2018-06-27 04:56:29 --> Config Class Initialized
INFO - 2018-06-27 04:56:29 --> Hooks Class Initialized
DEBUG - 2018-06-27 04:56:29 --> UTF-8 Support Enabled
INFO - 2018-06-27 04:56:30 --> Utf8 Class Initialized
INFO - 2018-06-27 04:56:30 --> URI Class Initialized
INFO - 2018-06-27 04:56:30 --> Router Class Initialized
INFO - 2018-06-27 04:56:30 --> Output Class Initialized
INFO - 2018-06-27 04:56:30 --> Security Class Initialized
DEBUG - 2018-06-27 04:56:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-27 04:56:30 --> Input Class Initialized
INFO - 2018-06-27 04:56:30 --> Language Class Initialized
INFO - 2018-06-27 04:56:30 --> Language Class Initialized
INFO - 2018-06-27 04:56:30 --> Config Class Initialized
INFO - 2018-06-27 04:56:30 --> Loader Class Initialized
DEBUG - 2018-06-27 04:56:30 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-27 04:56:30 --> Helper loaded: url_helper
INFO - 2018-06-27 04:56:30 --> Helper loaded: form_helper
INFO - 2018-06-27 04:56:30 --> Helper loaded: date_helper
INFO - 2018-06-27 04:56:30 --> Helper loaded: util_helper
INFO - 2018-06-27 04:56:30 --> Helper loaded: text_helper
INFO - 2018-06-27 04:56:30 --> Helper loaded: string_helper
INFO - 2018-06-27 04:56:30 --> Database Driver Class Initialized
DEBUG - 2018-06-27 04:56:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-27 04:56:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-27 04:56:30 --> Email Class Initialized
INFO - 2018-06-27 04:56:30 --> Controller Class Initialized
DEBUG - 2018-06-27 04:56:30 --> Programs MX_Controller Initialized
INFO - 2018-06-27 04:56:30 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-27 04:56:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-06-27 04:56:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-27 04:56:31 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-27 04:56:31 --> Login MX_Controller Initialized
DEBUG - 2018-06-27 04:56:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-27 04:56:31 --> Final output sent to browser
DEBUG - 2018-06-27 04:56:31 --> Total execution time: 1.3032
INFO - 2018-06-27 04:56:56 --> Config Class Initialized
INFO - 2018-06-27 04:56:56 --> Hooks Class Initialized
DEBUG - 2018-06-27 04:56:56 --> UTF-8 Support Enabled
INFO - 2018-06-27 04:56:56 --> Utf8 Class Initialized
INFO - 2018-06-27 04:56:56 --> URI Class Initialized
INFO - 2018-06-27 04:56:56 --> Router Class Initialized
INFO - 2018-06-27 04:56:56 --> Output Class Initialized
INFO - 2018-06-27 04:56:56 --> Security Class Initialized
DEBUG - 2018-06-27 04:56:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-27 04:56:56 --> Input Class Initialized
INFO - 2018-06-27 04:56:56 --> Language Class Initialized
INFO - 2018-06-27 04:56:56 --> Language Class Initialized
INFO - 2018-06-27 04:56:56 --> Config Class Initialized
INFO - 2018-06-27 04:56:56 --> Loader Class Initialized
DEBUG - 2018-06-27 04:56:56 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-27 04:56:56 --> Helper loaded: url_helper
INFO - 2018-06-27 04:56:56 --> Helper loaded: form_helper
INFO - 2018-06-27 04:56:56 --> Helper loaded: date_helper
INFO - 2018-06-27 04:56:56 --> Helper loaded: util_helper
INFO - 2018-06-27 04:56:56 --> Helper loaded: text_helper
INFO - 2018-06-27 04:56:56 --> Helper loaded: string_helper
INFO - 2018-06-27 04:56:56 --> Database Driver Class Initialized
DEBUG - 2018-06-27 04:56:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-27 04:56:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-27 04:56:56 --> Email Class Initialized
INFO - 2018-06-27 04:56:56 --> Controller Class Initialized
DEBUG - 2018-06-27 04:56:56 --> Programs MX_Controller Initialized
INFO - 2018-06-27 04:56:56 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-27 04:56:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-06-27 04:56:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-27 04:56:56 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-27 04:56:56 --> Login MX_Controller Initialized
DEBUG - 2018-06-27 04:56:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-27 04:56:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-27 04:56:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-27 04:56:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-27 04:56:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-27 04:56:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-27 04:56:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/programs.php
INFO - 2018-06-27 04:56:56 --> Final output sent to browser
DEBUG - 2018-06-27 04:56:56 --> Total execution time: 0.3696
INFO - 2018-06-27 04:56:57 --> Config Class Initialized
INFO - 2018-06-27 04:56:57 --> Hooks Class Initialized
DEBUG - 2018-06-27 04:56:57 --> UTF-8 Support Enabled
INFO - 2018-06-27 04:56:57 --> Utf8 Class Initialized
INFO - 2018-06-27 04:56:57 --> URI Class Initialized
INFO - 2018-06-27 04:56:58 --> Router Class Initialized
INFO - 2018-06-27 04:56:58 --> Output Class Initialized
INFO - 2018-06-27 04:56:58 --> Security Class Initialized
DEBUG - 2018-06-27 04:56:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-27 04:56:58 --> Input Class Initialized
INFO - 2018-06-27 04:56:58 --> Language Class Initialized
INFO - 2018-06-27 04:56:58 --> Language Class Initialized
INFO - 2018-06-27 04:56:58 --> Config Class Initialized
INFO - 2018-06-27 04:56:58 --> Loader Class Initialized
DEBUG - 2018-06-27 04:56:58 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-27 04:56:58 --> Helper loaded: url_helper
INFO - 2018-06-27 04:56:58 --> Helper loaded: form_helper
INFO - 2018-06-27 04:56:58 --> Helper loaded: date_helper
INFO - 2018-06-27 04:56:58 --> Helper loaded: util_helper
INFO - 2018-06-27 04:56:58 --> Helper loaded: text_helper
INFO - 2018-06-27 04:56:58 --> Helper loaded: string_helper
INFO - 2018-06-27 04:56:58 --> Database Driver Class Initialized
DEBUG - 2018-06-27 04:56:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-27 04:56:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-27 04:56:58 --> Email Class Initialized
INFO - 2018-06-27 04:56:58 --> Controller Class Initialized
DEBUG - 2018-06-27 04:56:58 --> Programs MX_Controller Initialized
INFO - 2018-06-27 04:56:58 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-27 04:56:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-06-27 04:56:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-27 04:56:58 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-27 04:56:58 --> Login MX_Controller Initialized
DEBUG - 2018-06-27 04:56:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-27 04:56:58 --> Final output sent to browser
DEBUG - 2018-06-27 04:56:58 --> Total execution time: 0.7197
INFO - 2018-06-27 04:57:54 --> Config Class Initialized
INFO - 2018-06-27 04:57:54 --> Hooks Class Initialized
DEBUG - 2018-06-27 04:57:54 --> UTF-8 Support Enabled
INFO - 2018-06-27 04:57:54 --> Utf8 Class Initialized
INFO - 2018-06-27 04:57:54 --> URI Class Initialized
INFO - 2018-06-27 04:57:54 --> Router Class Initialized
INFO - 2018-06-27 04:57:54 --> Output Class Initialized
INFO - 2018-06-27 04:57:54 --> Security Class Initialized
DEBUG - 2018-06-27 04:57:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-27 04:57:54 --> Input Class Initialized
INFO - 2018-06-27 04:57:54 --> Language Class Initialized
INFO - 2018-06-27 04:57:54 --> Language Class Initialized
INFO - 2018-06-27 04:57:54 --> Config Class Initialized
INFO - 2018-06-27 04:57:54 --> Loader Class Initialized
DEBUG - 2018-06-27 04:57:54 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-27 04:57:54 --> Helper loaded: url_helper
INFO - 2018-06-27 04:57:54 --> Helper loaded: form_helper
INFO - 2018-06-27 04:57:54 --> Helper loaded: date_helper
INFO - 2018-06-27 04:57:54 --> Helper loaded: util_helper
INFO - 2018-06-27 04:57:54 --> Helper loaded: text_helper
INFO - 2018-06-27 04:57:54 --> Helper loaded: string_helper
INFO - 2018-06-27 04:57:54 --> Database Driver Class Initialized
DEBUG - 2018-06-27 04:57:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-27 04:57:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-27 04:57:54 --> Email Class Initialized
INFO - 2018-06-27 04:57:54 --> Controller Class Initialized
DEBUG - 2018-06-27 04:57:54 --> Programs MX_Controller Initialized
INFO - 2018-06-27 04:57:54 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-27 04:57:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-06-27 04:57:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-27 04:57:54 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-27 04:57:54 --> Login MX_Controller Initialized
DEBUG - 2018-06-27 04:57:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-27 04:57:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-27 04:57:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-27 04:57:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-27 04:57:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-27 04:57:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-27 04:57:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/programs.php
INFO - 2018-06-27 04:57:54 --> Final output sent to browser
DEBUG - 2018-06-27 04:57:54 --> Total execution time: 0.3950
INFO - 2018-06-27 04:57:55 --> Config Class Initialized
INFO - 2018-06-27 04:57:55 --> Hooks Class Initialized
DEBUG - 2018-06-27 04:57:55 --> UTF-8 Support Enabled
INFO - 2018-06-27 04:57:56 --> Utf8 Class Initialized
INFO - 2018-06-27 04:57:56 --> URI Class Initialized
INFO - 2018-06-27 04:57:56 --> Router Class Initialized
INFO - 2018-06-27 04:57:56 --> Output Class Initialized
INFO - 2018-06-27 04:57:56 --> Security Class Initialized
DEBUG - 2018-06-27 04:57:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-27 04:57:56 --> Input Class Initialized
INFO - 2018-06-27 04:57:56 --> Language Class Initialized
INFO - 2018-06-27 04:57:56 --> Language Class Initialized
INFO - 2018-06-27 04:57:56 --> Config Class Initialized
INFO - 2018-06-27 04:57:56 --> Loader Class Initialized
DEBUG - 2018-06-27 04:57:56 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-27 04:57:56 --> Helper loaded: url_helper
INFO - 2018-06-27 04:57:56 --> Helper loaded: form_helper
INFO - 2018-06-27 04:57:56 --> Helper loaded: date_helper
INFO - 2018-06-27 04:57:56 --> Helper loaded: util_helper
INFO - 2018-06-27 04:57:56 --> Helper loaded: text_helper
INFO - 2018-06-27 04:57:56 --> Helper loaded: string_helper
INFO - 2018-06-27 04:57:56 --> Database Driver Class Initialized
DEBUG - 2018-06-27 04:57:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-27 04:57:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-27 04:57:57 --> Email Class Initialized
INFO - 2018-06-27 04:57:57 --> Controller Class Initialized
DEBUG - 2018-06-27 04:57:57 --> Programs MX_Controller Initialized
INFO - 2018-06-27 04:57:57 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-27 04:57:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-06-27 04:57:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-27 04:57:57 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-27 04:57:57 --> Login MX_Controller Initialized
DEBUG - 2018-06-27 04:57:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-27 04:57:57 --> Final output sent to browser
DEBUG - 2018-06-27 04:57:57 --> Total execution time: 1.3475
INFO - 2018-06-27 04:58:26 --> Config Class Initialized
INFO - 2018-06-27 04:58:26 --> Hooks Class Initialized
DEBUG - 2018-06-27 04:58:26 --> UTF-8 Support Enabled
INFO - 2018-06-27 04:58:26 --> Utf8 Class Initialized
INFO - 2018-06-27 04:58:26 --> URI Class Initialized
INFO - 2018-06-27 04:58:26 --> Router Class Initialized
INFO - 2018-06-27 04:58:26 --> Output Class Initialized
INFO - 2018-06-27 04:58:26 --> Security Class Initialized
DEBUG - 2018-06-27 04:58:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-27 04:58:26 --> Input Class Initialized
INFO - 2018-06-27 04:58:26 --> Language Class Initialized
INFO - 2018-06-27 04:58:26 --> Language Class Initialized
INFO - 2018-06-27 04:58:26 --> Config Class Initialized
INFO - 2018-06-27 04:58:26 --> Loader Class Initialized
DEBUG - 2018-06-27 04:58:26 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-27 04:58:26 --> Helper loaded: url_helper
INFO - 2018-06-27 04:58:26 --> Helper loaded: form_helper
INFO - 2018-06-27 04:58:26 --> Helper loaded: date_helper
INFO - 2018-06-27 04:58:26 --> Helper loaded: util_helper
INFO - 2018-06-27 04:58:26 --> Helper loaded: text_helper
INFO - 2018-06-27 04:58:26 --> Helper loaded: string_helper
INFO - 2018-06-27 04:58:26 --> Database Driver Class Initialized
DEBUG - 2018-06-27 04:58:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-27 04:58:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-27 04:58:26 --> Email Class Initialized
INFO - 2018-06-27 04:58:26 --> Controller Class Initialized
DEBUG - 2018-06-27 04:58:26 --> Programs MX_Controller Initialized
INFO - 2018-06-27 04:58:26 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-27 04:58:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-06-27 04:58:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-27 04:58:26 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-27 04:58:26 --> Login MX_Controller Initialized
DEBUG - 2018-06-27 04:58:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-27 04:58:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-27 04:58:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-27 04:58:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-27 04:58:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-27 04:58:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-27 04:58:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/programs.php
INFO - 2018-06-27 04:58:27 --> Final output sent to browser
DEBUG - 2018-06-27 04:58:27 --> Total execution time: 0.3756
INFO - 2018-06-27 04:58:28 --> Config Class Initialized
INFO - 2018-06-27 04:58:28 --> Hooks Class Initialized
DEBUG - 2018-06-27 04:58:28 --> UTF-8 Support Enabled
INFO - 2018-06-27 04:58:28 --> Utf8 Class Initialized
INFO - 2018-06-27 04:58:28 --> URI Class Initialized
INFO - 2018-06-27 04:58:28 --> Router Class Initialized
INFO - 2018-06-27 04:58:28 --> Output Class Initialized
INFO - 2018-06-27 04:58:28 --> Security Class Initialized
DEBUG - 2018-06-27 04:58:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-27 04:58:28 --> Input Class Initialized
INFO - 2018-06-27 04:58:28 --> Language Class Initialized
INFO - 2018-06-27 04:58:28 --> Language Class Initialized
INFO - 2018-06-27 04:58:28 --> Config Class Initialized
INFO - 2018-06-27 04:58:28 --> Loader Class Initialized
DEBUG - 2018-06-27 04:58:28 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-27 04:58:28 --> Helper loaded: url_helper
INFO - 2018-06-27 04:58:28 --> Helper loaded: form_helper
INFO - 2018-06-27 04:58:28 --> Helper loaded: date_helper
INFO - 2018-06-27 04:58:28 --> Helper loaded: util_helper
INFO - 2018-06-27 04:58:28 --> Helper loaded: text_helper
INFO - 2018-06-27 04:58:28 --> Helper loaded: string_helper
INFO - 2018-06-27 04:58:28 --> Database Driver Class Initialized
DEBUG - 2018-06-27 04:58:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-27 04:58:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-27 04:58:28 --> Email Class Initialized
INFO - 2018-06-27 04:58:28 --> Controller Class Initialized
DEBUG - 2018-06-27 04:58:28 --> Programs MX_Controller Initialized
INFO - 2018-06-27 04:58:28 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-27 04:58:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-06-27 04:58:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-27 04:58:28 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-27 04:58:28 --> Login MX_Controller Initialized
DEBUG - 2018-06-27 04:58:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-27 04:58:28 --> Final output sent to browser
DEBUG - 2018-06-27 04:58:28 --> Total execution time: 0.6519
INFO - 2018-06-27 04:58:38 --> Config Class Initialized
INFO - 2018-06-27 04:58:38 --> Hooks Class Initialized
DEBUG - 2018-06-27 04:58:38 --> UTF-8 Support Enabled
INFO - 2018-06-27 04:58:38 --> Utf8 Class Initialized
INFO - 2018-06-27 04:58:38 --> URI Class Initialized
INFO - 2018-06-27 04:58:38 --> Router Class Initialized
INFO - 2018-06-27 04:58:38 --> Output Class Initialized
INFO - 2018-06-27 04:58:38 --> Security Class Initialized
DEBUG - 2018-06-27 04:58:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-27 04:58:38 --> Input Class Initialized
INFO - 2018-06-27 04:58:38 --> Language Class Initialized
INFO - 2018-06-27 04:58:38 --> Language Class Initialized
INFO - 2018-06-27 04:58:38 --> Config Class Initialized
INFO - 2018-06-27 04:58:38 --> Loader Class Initialized
DEBUG - 2018-06-27 04:58:39 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-27 04:58:39 --> Helper loaded: url_helper
INFO - 2018-06-27 04:58:39 --> Helper loaded: form_helper
INFO - 2018-06-27 04:58:39 --> Helper loaded: date_helper
INFO - 2018-06-27 04:58:39 --> Helper loaded: util_helper
INFO - 2018-06-27 04:58:39 --> Helper loaded: text_helper
INFO - 2018-06-27 04:58:39 --> Helper loaded: string_helper
INFO - 2018-06-27 04:58:39 --> Database Driver Class Initialized
DEBUG - 2018-06-27 04:58:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-27 04:58:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-27 04:58:39 --> Email Class Initialized
INFO - 2018-06-27 04:58:39 --> Controller Class Initialized
DEBUG - 2018-06-27 04:58:39 --> Programs MX_Controller Initialized
INFO - 2018-06-27 04:58:39 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-27 04:58:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-06-27 04:58:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-27 04:58:39 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-27 04:58:39 --> Login MX_Controller Initialized
DEBUG - 2018-06-27 04:58:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-27 04:58:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-27 04:58:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-27 04:58:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-27 04:58:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-27 04:58:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-27 04:58:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/programs.php
INFO - 2018-06-27 04:58:39 --> Final output sent to browser
DEBUG - 2018-06-27 04:58:39 --> Total execution time: 0.4007
INFO - 2018-06-27 04:58:40 --> Config Class Initialized
INFO - 2018-06-27 04:58:40 --> Hooks Class Initialized
DEBUG - 2018-06-27 04:58:40 --> UTF-8 Support Enabled
INFO - 2018-06-27 04:58:40 --> Utf8 Class Initialized
INFO - 2018-06-27 04:58:40 --> URI Class Initialized
INFO - 2018-06-27 04:58:40 --> Router Class Initialized
INFO - 2018-06-27 04:58:40 --> Output Class Initialized
INFO - 2018-06-27 04:58:40 --> Security Class Initialized
DEBUG - 2018-06-27 04:58:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-27 04:58:40 --> Input Class Initialized
INFO - 2018-06-27 04:58:40 --> Language Class Initialized
INFO - 2018-06-27 04:58:40 --> Language Class Initialized
INFO - 2018-06-27 04:58:40 --> Config Class Initialized
INFO - 2018-06-27 04:58:40 --> Loader Class Initialized
DEBUG - 2018-06-27 04:58:40 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-27 04:58:40 --> Helper loaded: url_helper
INFO - 2018-06-27 04:58:40 --> Helper loaded: form_helper
INFO - 2018-06-27 04:58:40 --> Helper loaded: date_helper
INFO - 2018-06-27 04:58:40 --> Helper loaded: util_helper
INFO - 2018-06-27 04:58:40 --> Helper loaded: text_helper
INFO - 2018-06-27 04:58:40 --> Helper loaded: string_helper
INFO - 2018-06-27 04:58:40 --> Database Driver Class Initialized
DEBUG - 2018-06-27 04:58:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-27 04:58:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-27 04:58:40 --> Email Class Initialized
INFO - 2018-06-27 04:58:41 --> Controller Class Initialized
DEBUG - 2018-06-27 04:58:41 --> Programs MX_Controller Initialized
INFO - 2018-06-27 04:58:41 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-27 04:58:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-06-27 04:58:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-27 04:58:41 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-27 04:58:41 --> Login MX_Controller Initialized
DEBUG - 2018-06-27 04:58:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-27 04:58:41 --> Final output sent to browser
DEBUG - 2018-06-27 04:58:41 --> Total execution time: 0.7058
INFO - 2018-06-27 04:58:58 --> Config Class Initialized
INFO - 2018-06-27 04:58:58 --> Hooks Class Initialized
DEBUG - 2018-06-27 04:58:58 --> UTF-8 Support Enabled
INFO - 2018-06-27 04:58:58 --> Utf8 Class Initialized
INFO - 2018-06-27 04:58:58 --> URI Class Initialized
INFO - 2018-06-27 04:58:58 --> Router Class Initialized
INFO - 2018-06-27 04:58:58 --> Output Class Initialized
INFO - 2018-06-27 04:58:58 --> Security Class Initialized
DEBUG - 2018-06-27 04:58:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-27 04:58:58 --> Input Class Initialized
INFO - 2018-06-27 04:58:58 --> Language Class Initialized
INFO - 2018-06-27 04:58:58 --> Language Class Initialized
INFO - 2018-06-27 04:58:58 --> Config Class Initialized
INFO - 2018-06-27 04:58:58 --> Loader Class Initialized
DEBUG - 2018-06-27 04:58:58 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-27 04:58:58 --> Helper loaded: url_helper
INFO - 2018-06-27 04:58:58 --> Helper loaded: form_helper
INFO - 2018-06-27 04:58:58 --> Helper loaded: date_helper
INFO - 2018-06-27 04:58:58 --> Helper loaded: util_helper
INFO - 2018-06-27 04:58:58 --> Helper loaded: text_helper
INFO - 2018-06-27 04:58:58 --> Helper loaded: string_helper
INFO - 2018-06-27 04:58:58 --> Database Driver Class Initialized
DEBUG - 2018-06-27 04:58:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-27 04:58:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-27 04:58:58 --> Email Class Initialized
INFO - 2018-06-27 04:58:58 --> Controller Class Initialized
DEBUG - 2018-06-27 04:58:58 --> Programs MX_Controller Initialized
INFO - 2018-06-27 04:58:58 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-27 04:58:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-06-27 04:58:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-27 04:58:58 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-27 04:58:58 --> Login MX_Controller Initialized
DEBUG - 2018-06-27 04:58:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-27 04:58:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-27 04:58:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-27 04:58:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-27 04:58:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-27 04:58:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-27 04:58:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/programs.php
INFO - 2018-06-27 04:58:58 --> Final output sent to browser
DEBUG - 2018-06-27 04:58:58 --> Total execution time: 0.3993
INFO - 2018-06-27 04:58:59 --> Config Class Initialized
INFO - 2018-06-27 04:58:59 --> Hooks Class Initialized
DEBUG - 2018-06-27 04:58:59 --> UTF-8 Support Enabled
INFO - 2018-06-27 04:58:59 --> Utf8 Class Initialized
INFO - 2018-06-27 04:58:59 --> URI Class Initialized
INFO - 2018-06-27 04:58:59 --> Router Class Initialized
INFO - 2018-06-27 04:58:59 --> Output Class Initialized
INFO - 2018-06-27 04:58:59 --> Security Class Initialized
DEBUG - 2018-06-27 04:58:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-27 04:58:59 --> Input Class Initialized
INFO - 2018-06-27 04:58:59 --> Language Class Initialized
INFO - 2018-06-27 04:58:59 --> Language Class Initialized
INFO - 2018-06-27 04:58:59 --> Config Class Initialized
INFO - 2018-06-27 04:58:59 --> Loader Class Initialized
DEBUG - 2018-06-27 04:59:00 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-27 04:59:00 --> Helper loaded: url_helper
INFO - 2018-06-27 04:59:00 --> Helper loaded: form_helper
INFO - 2018-06-27 04:59:00 --> Helper loaded: date_helper
INFO - 2018-06-27 04:59:00 --> Helper loaded: util_helper
INFO - 2018-06-27 04:59:00 --> Helper loaded: text_helper
INFO - 2018-06-27 04:59:00 --> Helper loaded: string_helper
INFO - 2018-06-27 04:59:00 --> Database Driver Class Initialized
DEBUG - 2018-06-27 04:59:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-27 04:59:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-27 04:59:00 --> Email Class Initialized
INFO - 2018-06-27 04:59:00 --> Controller Class Initialized
DEBUG - 2018-06-27 04:59:00 --> Programs MX_Controller Initialized
INFO - 2018-06-27 04:59:00 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-27 04:59:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-06-27 04:59:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-27 04:59:00 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-27 04:59:00 --> Login MX_Controller Initialized
DEBUG - 2018-06-27 04:59:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-27 04:59:00 --> Final output sent to browser
DEBUG - 2018-06-27 04:59:00 --> Total execution time: 0.7130
INFO - 2018-06-27 05:01:45 --> Config Class Initialized
INFO - 2018-06-27 05:01:45 --> Hooks Class Initialized
DEBUG - 2018-06-27 05:01:45 --> UTF-8 Support Enabled
INFO - 2018-06-27 05:01:45 --> Utf8 Class Initialized
INFO - 2018-06-27 05:01:45 --> URI Class Initialized
INFO - 2018-06-27 05:01:45 --> Router Class Initialized
INFO - 2018-06-27 05:01:45 --> Output Class Initialized
INFO - 2018-06-27 05:01:45 --> Security Class Initialized
DEBUG - 2018-06-27 05:01:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-27 05:01:45 --> Input Class Initialized
INFO - 2018-06-27 05:01:45 --> Language Class Initialized
INFO - 2018-06-27 05:01:45 --> Language Class Initialized
INFO - 2018-06-27 05:01:45 --> Config Class Initialized
INFO - 2018-06-27 05:01:45 --> Loader Class Initialized
DEBUG - 2018-06-27 05:01:45 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-27 05:01:45 --> Helper loaded: url_helper
INFO - 2018-06-27 05:01:45 --> Helper loaded: form_helper
INFO - 2018-06-27 05:01:45 --> Helper loaded: date_helper
INFO - 2018-06-27 05:01:45 --> Helper loaded: util_helper
INFO - 2018-06-27 05:01:45 --> Helper loaded: text_helper
INFO - 2018-06-27 05:01:45 --> Helper loaded: string_helper
INFO - 2018-06-27 05:01:45 --> Database Driver Class Initialized
DEBUG - 2018-06-27 05:01:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-27 05:01:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-27 05:01:45 --> Email Class Initialized
INFO - 2018-06-27 05:01:45 --> Controller Class Initialized
DEBUG - 2018-06-27 05:01:45 --> Programs MX_Controller Initialized
INFO - 2018-06-27 05:01:45 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-27 05:01:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-06-27 05:01:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-27 05:01:45 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-27 05:01:45 --> Login MX_Controller Initialized
DEBUG - 2018-06-27 05:01:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-27 05:01:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-27 05:01:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-27 05:01:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-27 05:01:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-27 05:01:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-27 05:01:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/programs.php
INFO - 2018-06-27 05:01:45 --> Final output sent to browser
DEBUG - 2018-06-27 05:01:45 --> Total execution time: 0.4156
INFO - 2018-06-27 05:01:46 --> Config Class Initialized
INFO - 2018-06-27 05:01:46 --> Hooks Class Initialized
DEBUG - 2018-06-27 05:01:46 --> UTF-8 Support Enabled
INFO - 2018-06-27 05:01:47 --> Utf8 Class Initialized
INFO - 2018-06-27 05:01:47 --> URI Class Initialized
INFO - 2018-06-27 05:01:47 --> Router Class Initialized
INFO - 2018-06-27 05:01:47 --> Output Class Initialized
INFO - 2018-06-27 05:01:47 --> Security Class Initialized
DEBUG - 2018-06-27 05:01:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-27 05:01:47 --> Input Class Initialized
INFO - 2018-06-27 05:01:47 --> Language Class Initialized
INFO - 2018-06-27 05:01:47 --> Language Class Initialized
INFO - 2018-06-27 05:01:47 --> Config Class Initialized
INFO - 2018-06-27 05:01:47 --> Loader Class Initialized
DEBUG - 2018-06-27 05:01:47 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-27 05:01:47 --> Helper loaded: url_helper
INFO - 2018-06-27 05:01:47 --> Helper loaded: form_helper
INFO - 2018-06-27 05:01:47 --> Helper loaded: date_helper
INFO - 2018-06-27 05:01:47 --> Helper loaded: util_helper
INFO - 2018-06-27 05:01:47 --> Helper loaded: text_helper
INFO - 2018-06-27 05:01:47 --> Helper loaded: string_helper
INFO - 2018-06-27 05:01:47 --> Database Driver Class Initialized
DEBUG - 2018-06-27 05:01:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-27 05:01:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-27 05:01:47 --> Email Class Initialized
INFO - 2018-06-27 05:01:47 --> Controller Class Initialized
DEBUG - 2018-06-27 05:01:47 --> Programs MX_Controller Initialized
INFO - 2018-06-27 05:01:47 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-27 05:01:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-06-27 05:01:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-27 05:01:47 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-27 05:01:47 --> Login MX_Controller Initialized
DEBUG - 2018-06-27 05:01:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-27 05:01:47 --> Final output sent to browser
DEBUG - 2018-06-27 05:01:47 --> Total execution time: 0.7988
INFO - 2018-06-27 05:02:12 --> Config Class Initialized
INFO - 2018-06-27 05:02:12 --> Hooks Class Initialized
DEBUG - 2018-06-27 05:02:12 --> UTF-8 Support Enabled
INFO - 2018-06-27 05:02:12 --> Utf8 Class Initialized
INFO - 2018-06-27 05:02:12 --> URI Class Initialized
INFO - 2018-06-27 05:02:12 --> Router Class Initialized
INFO - 2018-06-27 05:02:12 --> Output Class Initialized
INFO - 2018-06-27 05:02:12 --> Security Class Initialized
DEBUG - 2018-06-27 05:02:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-27 05:02:12 --> Input Class Initialized
INFO - 2018-06-27 05:02:12 --> Language Class Initialized
INFO - 2018-06-27 05:02:12 --> Language Class Initialized
INFO - 2018-06-27 05:02:12 --> Config Class Initialized
INFO - 2018-06-27 05:02:12 --> Loader Class Initialized
DEBUG - 2018-06-27 05:02:12 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-27 05:02:12 --> Helper loaded: url_helper
INFO - 2018-06-27 05:02:12 --> Helper loaded: form_helper
INFO - 2018-06-27 05:02:12 --> Helper loaded: date_helper
INFO - 2018-06-27 05:02:12 --> Helper loaded: util_helper
INFO - 2018-06-27 05:02:12 --> Helper loaded: text_helper
INFO - 2018-06-27 05:02:12 --> Helper loaded: string_helper
INFO - 2018-06-27 05:02:12 --> Database Driver Class Initialized
DEBUG - 2018-06-27 05:02:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-27 05:02:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-27 05:02:12 --> Email Class Initialized
INFO - 2018-06-27 05:02:12 --> Controller Class Initialized
DEBUG - 2018-06-27 05:02:12 --> Programs MX_Controller Initialized
INFO - 2018-06-27 05:02:12 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-27 05:02:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-06-27 05:02:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-27 05:02:12 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-27 05:02:12 --> Login MX_Controller Initialized
DEBUG - 2018-06-27 05:02:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-27 05:02:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-27 05:02:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-27 05:02:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-27 05:02:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-27 05:02:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-27 05:02:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/programs.php
INFO - 2018-06-27 05:02:12 --> Final output sent to browser
DEBUG - 2018-06-27 05:02:13 --> Total execution time: 0.3932
INFO - 2018-06-27 05:02:14 --> Config Class Initialized
INFO - 2018-06-27 05:02:14 --> Hooks Class Initialized
DEBUG - 2018-06-27 05:02:14 --> UTF-8 Support Enabled
INFO - 2018-06-27 05:02:14 --> Utf8 Class Initialized
INFO - 2018-06-27 05:02:14 --> URI Class Initialized
INFO - 2018-06-27 05:02:14 --> Router Class Initialized
INFO - 2018-06-27 05:02:14 --> Output Class Initialized
INFO - 2018-06-27 05:02:14 --> Security Class Initialized
DEBUG - 2018-06-27 05:02:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-27 05:02:14 --> Input Class Initialized
INFO - 2018-06-27 05:02:14 --> Language Class Initialized
INFO - 2018-06-27 05:02:14 --> Language Class Initialized
INFO - 2018-06-27 05:02:14 --> Config Class Initialized
INFO - 2018-06-27 05:02:14 --> Loader Class Initialized
DEBUG - 2018-06-27 05:02:14 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-27 05:02:14 --> Helper loaded: url_helper
INFO - 2018-06-27 05:02:14 --> Helper loaded: form_helper
INFO - 2018-06-27 05:02:14 --> Helper loaded: date_helper
INFO - 2018-06-27 05:02:14 --> Helper loaded: util_helper
INFO - 2018-06-27 05:02:14 --> Helper loaded: text_helper
INFO - 2018-06-27 05:02:14 --> Helper loaded: string_helper
INFO - 2018-06-27 05:02:14 --> Database Driver Class Initialized
DEBUG - 2018-06-27 05:02:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-27 05:02:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-27 05:02:14 --> Email Class Initialized
INFO - 2018-06-27 05:02:14 --> Controller Class Initialized
DEBUG - 2018-06-27 05:02:14 --> Programs MX_Controller Initialized
INFO - 2018-06-27 05:02:14 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-27 05:02:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-06-27 05:02:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-27 05:02:14 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-27 05:02:14 --> Login MX_Controller Initialized
DEBUG - 2018-06-27 05:02:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-27 05:02:14 --> Final output sent to browser
DEBUG - 2018-06-27 05:02:14 --> Total execution time: 0.6980
INFO - 2018-06-27 05:03:57 --> Config Class Initialized
INFO - 2018-06-27 05:03:57 --> Hooks Class Initialized
DEBUG - 2018-06-27 05:03:57 --> UTF-8 Support Enabled
INFO - 2018-06-27 05:03:57 --> Utf8 Class Initialized
INFO - 2018-06-27 05:03:57 --> URI Class Initialized
INFO - 2018-06-27 05:03:57 --> Router Class Initialized
INFO - 2018-06-27 05:03:57 --> Output Class Initialized
INFO - 2018-06-27 05:03:57 --> Security Class Initialized
DEBUG - 2018-06-27 05:03:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-27 05:03:57 --> Input Class Initialized
INFO - 2018-06-27 05:03:57 --> Language Class Initialized
INFO - 2018-06-27 05:03:57 --> Language Class Initialized
INFO - 2018-06-27 05:03:57 --> Config Class Initialized
INFO - 2018-06-27 05:03:57 --> Loader Class Initialized
DEBUG - 2018-06-27 05:03:57 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-27 05:03:57 --> Helper loaded: url_helper
INFO - 2018-06-27 05:03:57 --> Helper loaded: form_helper
INFO - 2018-06-27 05:03:57 --> Helper loaded: date_helper
INFO - 2018-06-27 05:03:57 --> Helper loaded: util_helper
INFO - 2018-06-27 05:03:57 --> Helper loaded: text_helper
INFO - 2018-06-27 05:03:57 --> Helper loaded: string_helper
INFO - 2018-06-27 05:03:57 --> Database Driver Class Initialized
DEBUG - 2018-06-27 05:03:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-27 05:03:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-27 05:03:57 --> Email Class Initialized
INFO - 2018-06-27 05:03:57 --> Controller Class Initialized
DEBUG - 2018-06-27 05:03:57 --> Users MX_Controller Initialized
DEBUG - 2018-06-27 05:03:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-27 05:03:58 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-27 05:03:58 --> Login MX_Controller Initialized
INFO - 2018-06-27 05:03:58 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-27 05:03:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-27 05:03:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-27 05:03:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-27 05:03:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-27 05:03:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-27 05:03:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-27 05:03:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-06-27 05:03:58 --> Final output sent to browser
DEBUG - 2018-06-27 05:03:58 --> Total execution time: 0.4081
INFO - 2018-06-27 05:03:58 --> Config Class Initialized
INFO - 2018-06-27 05:03:58 --> Hooks Class Initialized
DEBUG - 2018-06-27 05:03:58 --> UTF-8 Support Enabled
INFO - 2018-06-27 05:03:58 --> Utf8 Class Initialized
INFO - 2018-06-27 05:03:58 --> URI Class Initialized
INFO - 2018-06-27 05:03:58 --> Router Class Initialized
INFO - 2018-06-27 05:03:58 --> Output Class Initialized
INFO - 2018-06-27 05:03:58 --> Security Class Initialized
DEBUG - 2018-06-27 05:03:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-27 05:03:58 --> Input Class Initialized
INFO - 2018-06-27 05:03:58 --> Language Class Initialized
INFO - 2018-06-27 05:03:58 --> Language Class Initialized
INFO - 2018-06-27 05:03:58 --> Config Class Initialized
INFO - 2018-06-27 05:03:58 --> Loader Class Initialized
DEBUG - 2018-06-27 05:03:58 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-27 05:03:58 --> Helper loaded: url_helper
INFO - 2018-06-27 05:03:58 --> Helper loaded: form_helper
INFO - 2018-06-27 05:03:58 --> Helper loaded: date_helper
INFO - 2018-06-27 05:03:58 --> Helper loaded: util_helper
INFO - 2018-06-27 05:03:58 --> Helper loaded: text_helper
INFO - 2018-06-27 05:03:58 --> Helper loaded: string_helper
INFO - 2018-06-27 05:03:58 --> Database Driver Class Initialized
DEBUG - 2018-06-27 05:03:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-27 05:03:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-27 05:03:59 --> Email Class Initialized
INFO - 2018-06-27 05:03:59 --> Controller Class Initialized
DEBUG - 2018-06-27 05:03:59 --> Users MX_Controller Initialized
DEBUG - 2018-06-27 05:03:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-27 05:03:59 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-27 05:03:59 --> Login MX_Controller Initialized
INFO - 2018-06-27 05:03:59 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-27 05:03:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-27 05:03:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-06-27 05:03:59 --> Final output sent to browser
DEBUG - 2018-06-27 05:03:59 --> Total execution time: 0.5315
INFO - 2018-06-27 05:04:05 --> Config Class Initialized
INFO - 2018-06-27 05:04:05 --> Hooks Class Initialized
DEBUG - 2018-06-27 05:04:05 --> UTF-8 Support Enabled
INFO - 2018-06-27 05:04:05 --> Utf8 Class Initialized
INFO - 2018-06-27 05:04:05 --> URI Class Initialized
INFO - 2018-06-27 05:04:05 --> Router Class Initialized
INFO - 2018-06-27 05:04:05 --> Output Class Initialized
INFO - 2018-06-27 05:04:05 --> Security Class Initialized
DEBUG - 2018-06-27 05:04:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-27 05:04:05 --> Input Class Initialized
INFO - 2018-06-27 05:04:05 --> Language Class Initialized
INFO - 2018-06-27 05:04:05 --> Language Class Initialized
INFO - 2018-06-27 05:04:05 --> Config Class Initialized
INFO - 2018-06-27 05:04:05 --> Loader Class Initialized
DEBUG - 2018-06-27 05:04:05 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-27 05:04:05 --> Helper loaded: url_helper
INFO - 2018-06-27 05:04:05 --> Helper loaded: form_helper
INFO - 2018-06-27 05:04:05 --> Helper loaded: date_helper
INFO - 2018-06-27 05:04:05 --> Helper loaded: util_helper
INFO - 2018-06-27 05:04:05 --> Helper loaded: text_helper
INFO - 2018-06-27 05:04:05 --> Helper loaded: string_helper
INFO - 2018-06-27 05:04:05 --> Database Driver Class Initialized
DEBUG - 2018-06-27 05:04:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-27 05:04:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-27 05:04:05 --> Email Class Initialized
INFO - 2018-06-27 05:04:05 --> Controller Class Initialized
DEBUG - 2018-06-27 05:04:05 --> Programs MX_Controller Initialized
INFO - 2018-06-27 05:04:05 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-27 05:04:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-06-27 05:04:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-27 05:04:05 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-27 05:04:05 --> Login MX_Controller Initialized
DEBUG - 2018-06-27 05:04:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-27 05:04:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-27 05:04:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-27 05:04:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-27 05:04:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-27 05:04:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-27 05:04:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/programs.php
INFO - 2018-06-27 05:04:05 --> Final output sent to browser
DEBUG - 2018-06-27 05:04:05 --> Total execution time: 0.4153
INFO - 2018-06-27 05:04:05 --> Config Class Initialized
INFO - 2018-06-27 05:04:05 --> Hooks Class Initialized
DEBUG - 2018-06-27 05:04:05 --> UTF-8 Support Enabled
INFO - 2018-06-27 05:04:05 --> Utf8 Class Initialized
INFO - 2018-06-27 05:04:06 --> URI Class Initialized
INFO - 2018-06-27 05:04:06 --> Router Class Initialized
INFO - 2018-06-27 05:04:06 --> Output Class Initialized
INFO - 2018-06-27 05:04:06 --> Security Class Initialized
DEBUG - 2018-06-27 05:04:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-27 05:04:06 --> Input Class Initialized
INFO - 2018-06-27 05:04:06 --> Language Class Initialized
INFO - 2018-06-27 05:04:06 --> Language Class Initialized
INFO - 2018-06-27 05:04:06 --> Config Class Initialized
INFO - 2018-06-27 05:04:06 --> Loader Class Initialized
DEBUG - 2018-06-27 05:04:06 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-27 05:04:06 --> Helper loaded: url_helper
INFO - 2018-06-27 05:04:06 --> Helper loaded: form_helper
INFO - 2018-06-27 05:04:06 --> Helper loaded: date_helper
INFO - 2018-06-27 05:04:06 --> Helper loaded: util_helper
INFO - 2018-06-27 05:04:06 --> Helper loaded: text_helper
INFO - 2018-06-27 05:04:06 --> Helper loaded: string_helper
INFO - 2018-06-27 05:04:06 --> Database Driver Class Initialized
DEBUG - 2018-06-27 05:04:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-27 05:04:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-27 05:04:06 --> Email Class Initialized
INFO - 2018-06-27 05:04:06 --> Controller Class Initialized
DEBUG - 2018-06-27 05:04:06 --> Programs MX_Controller Initialized
INFO - 2018-06-27 05:04:06 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-27 05:04:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-06-27 05:04:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-27 05:04:06 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-27 05:04:06 --> Login MX_Controller Initialized
DEBUG - 2018-06-27 05:04:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-27 05:04:06 --> Final output sent to browser
DEBUG - 2018-06-27 05:04:06 --> Total execution time: 0.5150
INFO - 2018-06-27 05:04:08 --> Config Class Initialized
INFO - 2018-06-27 05:04:08 --> Hooks Class Initialized
DEBUG - 2018-06-27 05:04:08 --> UTF-8 Support Enabled
INFO - 2018-06-27 05:04:08 --> Utf8 Class Initialized
INFO - 2018-06-27 05:04:08 --> URI Class Initialized
INFO - 2018-06-27 05:04:08 --> Router Class Initialized
INFO - 2018-06-27 05:04:08 --> Output Class Initialized
INFO - 2018-06-27 05:04:08 --> Security Class Initialized
DEBUG - 2018-06-27 05:04:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-27 05:04:08 --> Input Class Initialized
INFO - 2018-06-27 05:04:08 --> Language Class Initialized
INFO - 2018-06-27 05:04:08 --> Language Class Initialized
INFO - 2018-06-27 05:04:08 --> Config Class Initialized
INFO - 2018-06-27 05:04:08 --> Loader Class Initialized
DEBUG - 2018-06-27 05:04:08 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-27 05:04:08 --> Helper loaded: url_helper
INFO - 2018-06-27 05:04:08 --> Helper loaded: form_helper
INFO - 2018-06-27 05:04:08 --> Helper loaded: date_helper
INFO - 2018-06-27 05:04:08 --> Helper loaded: util_helper
INFO - 2018-06-27 05:04:08 --> Helper loaded: text_helper
INFO - 2018-06-27 05:04:08 --> Helper loaded: string_helper
INFO - 2018-06-27 05:04:08 --> Database Driver Class Initialized
DEBUG - 2018-06-27 05:04:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-27 05:04:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-27 05:04:08 --> Email Class Initialized
INFO - 2018-06-27 05:04:08 --> Controller Class Initialized
DEBUG - 2018-06-27 05:04:08 --> Chapters MX_Controller Initialized
INFO - 2018-06-27 05:04:08 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-27 05:04:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Chapters_model.php
DEBUG - 2018-06-27 05:04:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-27 05:04:09 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-27 05:04:09 --> Login MX_Controller Initialized
DEBUG - 2018-06-27 05:04:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-27 05:04:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-27 05:04:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-27 05:04:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-27 05:04:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-27 05:04:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-27 05:04:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/chapters/chapters.php
INFO - 2018-06-27 05:04:09 --> Final output sent to browser
DEBUG - 2018-06-27 05:04:09 --> Total execution time: 0.4044
INFO - 2018-06-27 05:04:09 --> Config Class Initialized
INFO - 2018-06-27 05:04:09 --> Hooks Class Initialized
DEBUG - 2018-06-27 05:04:09 --> UTF-8 Support Enabled
INFO - 2018-06-27 05:04:09 --> Utf8 Class Initialized
INFO - 2018-06-27 05:04:09 --> URI Class Initialized
INFO - 2018-06-27 05:04:09 --> Router Class Initialized
INFO - 2018-06-27 05:04:09 --> Output Class Initialized
INFO - 2018-06-27 05:04:09 --> Security Class Initialized
DEBUG - 2018-06-27 05:04:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-27 05:04:09 --> Input Class Initialized
INFO - 2018-06-27 05:04:09 --> Language Class Initialized
INFO - 2018-06-27 05:04:09 --> Language Class Initialized
INFO - 2018-06-27 05:04:09 --> Config Class Initialized
INFO - 2018-06-27 05:04:09 --> Loader Class Initialized
DEBUG - 2018-06-27 05:04:09 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-27 05:04:09 --> Helper loaded: url_helper
INFO - 2018-06-27 05:04:09 --> Helper loaded: form_helper
INFO - 2018-06-27 05:04:09 --> Helper loaded: date_helper
INFO - 2018-06-27 05:04:09 --> Helper loaded: util_helper
INFO - 2018-06-27 05:04:09 --> Helper loaded: text_helper
INFO - 2018-06-27 05:04:09 --> Helper loaded: string_helper
INFO - 2018-06-27 05:04:09 --> Database Driver Class Initialized
DEBUG - 2018-06-27 05:04:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-27 05:04:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-27 05:04:09 --> Email Class Initialized
INFO - 2018-06-27 05:04:09 --> Controller Class Initialized
DEBUG - 2018-06-27 05:04:09 --> Chapters MX_Controller Initialized
INFO - 2018-06-27 05:04:09 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-27 05:04:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Chapters_model.php
DEBUG - 2018-06-27 05:04:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-27 05:04:09 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-27 05:04:09 --> Login MX_Controller Initialized
DEBUG - 2018-06-27 05:04:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-27 05:04:09 --> Final output sent to browser
DEBUG - 2018-06-27 05:04:09 --> Total execution time: 0.5296
INFO - 2018-06-27 05:04:11 --> Config Class Initialized
INFO - 2018-06-27 05:04:11 --> Hooks Class Initialized
DEBUG - 2018-06-27 05:04:11 --> UTF-8 Support Enabled
INFO - 2018-06-27 05:04:11 --> Utf8 Class Initialized
INFO - 2018-06-27 05:04:11 --> URI Class Initialized
INFO - 2018-06-27 05:04:11 --> Router Class Initialized
INFO - 2018-06-27 05:04:11 --> Output Class Initialized
INFO - 2018-06-27 05:04:11 --> Security Class Initialized
DEBUG - 2018-06-27 05:04:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-27 05:04:11 --> Input Class Initialized
INFO - 2018-06-27 05:04:11 --> Language Class Initialized
INFO - 2018-06-27 05:04:11 --> Language Class Initialized
INFO - 2018-06-27 05:04:11 --> Config Class Initialized
INFO - 2018-06-27 05:04:11 --> Loader Class Initialized
DEBUG - 2018-06-27 05:04:11 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-27 05:04:11 --> Helper loaded: url_helper
INFO - 2018-06-27 05:04:11 --> Helper loaded: form_helper
INFO - 2018-06-27 05:04:11 --> Helper loaded: date_helper
INFO - 2018-06-27 05:04:11 --> Helper loaded: util_helper
INFO - 2018-06-27 05:04:11 --> Helper loaded: text_helper
INFO - 2018-06-27 05:04:11 --> Helper loaded: string_helper
INFO - 2018-06-27 05:04:11 --> Database Driver Class Initialized
DEBUG - 2018-06-27 05:04:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-27 05:04:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-27 05:04:11 --> Email Class Initialized
INFO - 2018-06-27 05:04:11 --> Controller Class Initialized
DEBUG - 2018-06-27 05:04:11 --> Lessions MX_Controller Initialized
INFO - 2018-06-27 05:04:11 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-27 05:04:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Lessions_model.php
DEBUG - 2018-06-27 05:04:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-27 05:04:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-27 05:04:11 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-27 05:04:11 --> Login MX_Controller Initialized
DEBUG - 2018-06-27 05:04:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-27 05:04:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-27 05:04:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-27 05:04:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-27 05:04:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-27 05:04:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-27 05:04:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/lessions/lessions.php
INFO - 2018-06-27 05:04:11 --> Final output sent to browser
DEBUG - 2018-06-27 05:04:11 --> Total execution time: 0.4439
INFO - 2018-06-27 05:04:11 --> Config Class Initialized
INFO - 2018-06-27 05:04:11 --> Hooks Class Initialized
DEBUG - 2018-06-27 05:04:11 --> UTF-8 Support Enabled
INFO - 2018-06-27 05:04:12 --> Utf8 Class Initialized
INFO - 2018-06-27 05:04:12 --> URI Class Initialized
INFO - 2018-06-27 05:04:12 --> Router Class Initialized
INFO - 2018-06-27 05:04:12 --> Output Class Initialized
INFO - 2018-06-27 05:04:12 --> Security Class Initialized
DEBUG - 2018-06-27 05:04:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-27 05:04:12 --> Input Class Initialized
INFO - 2018-06-27 05:04:12 --> Language Class Initialized
INFO - 2018-06-27 05:04:12 --> Language Class Initialized
INFO - 2018-06-27 05:04:12 --> Config Class Initialized
INFO - 2018-06-27 05:04:12 --> Loader Class Initialized
DEBUG - 2018-06-27 05:04:12 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-27 05:04:12 --> Helper loaded: url_helper
INFO - 2018-06-27 05:04:12 --> Helper loaded: form_helper
INFO - 2018-06-27 05:04:12 --> Helper loaded: date_helper
INFO - 2018-06-27 05:04:12 --> Helper loaded: util_helper
INFO - 2018-06-27 05:04:12 --> Helper loaded: text_helper
INFO - 2018-06-27 05:04:12 --> Helper loaded: string_helper
INFO - 2018-06-27 05:04:12 --> Database Driver Class Initialized
DEBUG - 2018-06-27 05:04:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-27 05:04:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-27 05:04:12 --> Email Class Initialized
INFO - 2018-06-27 05:04:12 --> Controller Class Initialized
DEBUG - 2018-06-27 05:04:12 --> Lessions MX_Controller Initialized
INFO - 2018-06-27 05:04:12 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-27 05:04:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Lessions_model.php
DEBUG - 2018-06-27 05:04:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-27 05:04:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-27 05:04:12 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-27 05:04:12 --> Login MX_Controller Initialized
DEBUG - 2018-06-27 05:04:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-27 05:04:12 --> Final output sent to browser
DEBUG - 2018-06-27 05:04:12 --> Total execution time: 0.5515
INFO - 2018-06-27 05:04:13 --> Config Class Initialized
INFO - 2018-06-27 05:04:13 --> Hooks Class Initialized
DEBUG - 2018-06-27 05:04:13 --> UTF-8 Support Enabled
INFO - 2018-06-27 05:04:13 --> Utf8 Class Initialized
INFO - 2018-06-27 05:04:13 --> URI Class Initialized
INFO - 2018-06-27 05:04:13 --> Router Class Initialized
INFO - 2018-06-27 05:04:13 --> Output Class Initialized
INFO - 2018-06-27 05:04:13 --> Security Class Initialized
DEBUG - 2018-06-27 05:04:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-27 05:04:13 --> Input Class Initialized
INFO - 2018-06-27 05:04:13 --> Language Class Initialized
INFO - 2018-06-27 05:04:13 --> Language Class Initialized
INFO - 2018-06-27 05:04:13 --> Config Class Initialized
INFO - 2018-06-27 05:04:13 --> Loader Class Initialized
DEBUG - 2018-06-27 05:04:14 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-27 05:04:14 --> Helper loaded: url_helper
INFO - 2018-06-27 05:04:14 --> Helper loaded: form_helper
INFO - 2018-06-27 05:04:14 --> Helper loaded: date_helper
INFO - 2018-06-27 05:04:14 --> Helper loaded: util_helper
INFO - 2018-06-27 05:04:14 --> Helper loaded: text_helper
INFO - 2018-06-27 05:04:14 --> Helper loaded: string_helper
INFO - 2018-06-27 05:04:14 --> Database Driver Class Initialized
DEBUG - 2018-06-27 05:04:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-27 05:04:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-27 05:04:14 --> Email Class Initialized
INFO - 2018-06-27 05:04:14 --> Controller Class Initialized
DEBUG - 2018-06-27 05:04:14 --> videos MX_Controller Initialized
INFO - 2018-06-27 05:04:14 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-27 05:04:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-06-27 05:04:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-27 05:04:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-27 05:04:14 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-27 05:04:14 --> Login MX_Controller Initialized
DEBUG - 2018-06-27 05:04:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-27 05:04:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-27 05:04:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-27 05:04:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-27 05:04:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-27 05:04:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-27 05:04:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/videos/videos.php
INFO - 2018-06-27 05:04:14 --> Final output sent to browser
DEBUG - 2018-06-27 05:04:14 --> Total execution time: 0.4112
INFO - 2018-06-27 05:04:14 --> Config Class Initialized
INFO - 2018-06-27 05:04:14 --> Hooks Class Initialized
DEBUG - 2018-06-27 05:04:14 --> UTF-8 Support Enabled
INFO - 2018-06-27 05:04:14 --> Utf8 Class Initialized
INFO - 2018-06-27 05:04:14 --> URI Class Initialized
INFO - 2018-06-27 05:04:14 --> Router Class Initialized
INFO - 2018-06-27 05:04:14 --> Output Class Initialized
INFO - 2018-06-27 05:04:14 --> Security Class Initialized
DEBUG - 2018-06-27 05:04:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-27 05:04:14 --> Input Class Initialized
INFO - 2018-06-27 05:04:14 --> Language Class Initialized
INFO - 2018-06-27 05:04:14 --> Language Class Initialized
INFO - 2018-06-27 05:04:14 --> Config Class Initialized
INFO - 2018-06-27 05:04:14 --> Loader Class Initialized
DEBUG - 2018-06-27 05:04:14 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-27 05:04:14 --> Helper loaded: url_helper
INFO - 2018-06-27 05:04:14 --> Helper loaded: form_helper
INFO - 2018-06-27 05:04:14 --> Helper loaded: date_helper
INFO - 2018-06-27 05:04:14 --> Helper loaded: util_helper
INFO - 2018-06-27 05:04:14 --> Helper loaded: text_helper
INFO - 2018-06-27 05:04:14 --> Helper loaded: string_helper
INFO - 2018-06-27 05:04:14 --> Database Driver Class Initialized
DEBUG - 2018-06-27 05:04:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-27 05:04:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-27 05:04:14 --> Email Class Initialized
INFO - 2018-06-27 05:04:14 --> Controller Class Initialized
DEBUG - 2018-06-27 05:04:14 --> videos MX_Controller Initialized
INFO - 2018-06-27 05:04:14 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-27 05:04:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-06-27 05:04:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-27 05:04:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-27 05:04:14 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-27 05:04:14 --> Login MX_Controller Initialized
DEBUG - 2018-06-27 05:04:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-27 05:04:15 --> Final output sent to browser
DEBUG - 2018-06-27 05:04:15 --> Total execution time: 0.5342
INFO - 2018-06-27 05:04:33 --> Config Class Initialized
INFO - 2018-06-27 05:04:33 --> Hooks Class Initialized
DEBUG - 2018-06-27 05:04:33 --> UTF-8 Support Enabled
INFO - 2018-06-27 05:04:33 --> Utf8 Class Initialized
INFO - 2018-06-27 05:04:33 --> URI Class Initialized
INFO - 2018-06-27 05:04:33 --> Router Class Initialized
INFO - 2018-06-27 05:04:33 --> Output Class Initialized
INFO - 2018-06-27 05:04:33 --> Security Class Initialized
DEBUG - 2018-06-27 05:04:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-27 05:04:33 --> Input Class Initialized
INFO - 2018-06-27 05:04:33 --> Language Class Initialized
INFO - 2018-06-27 05:04:33 --> Language Class Initialized
INFO - 2018-06-27 05:04:33 --> Config Class Initialized
INFO - 2018-06-27 05:04:33 --> Loader Class Initialized
DEBUG - 2018-06-27 05:04:33 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-27 05:04:33 --> Helper loaded: url_helper
INFO - 2018-06-27 05:04:33 --> Helper loaded: form_helper
INFO - 2018-06-27 05:04:33 --> Helper loaded: date_helper
INFO - 2018-06-27 05:04:33 --> Helper loaded: util_helper
INFO - 2018-06-27 05:04:33 --> Helper loaded: text_helper
INFO - 2018-06-27 05:04:33 --> Helper loaded: string_helper
INFO - 2018-06-27 05:04:33 --> Database Driver Class Initialized
DEBUG - 2018-06-27 05:04:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-27 05:04:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-27 05:04:33 --> Email Class Initialized
INFO - 2018-06-27 05:04:33 --> Controller Class Initialized
DEBUG - 2018-06-27 05:04:33 --> videos MX_Controller Initialized
INFO - 2018-06-27 05:04:33 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-27 05:04:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-06-27 05:04:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-27 05:04:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-27 05:04:33 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-27 05:04:33 --> Login MX_Controller Initialized
DEBUG - 2018-06-27 05:04:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-27 05:04:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-27 05:04:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-27 05:04:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-27 05:04:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-27 05:04:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-27 05:04:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/videos/videos.php
INFO - 2018-06-27 05:04:34 --> Final output sent to browser
DEBUG - 2018-06-27 05:04:34 --> Total execution time: 0.4438
INFO - 2018-06-27 05:04:34 --> Config Class Initialized
INFO - 2018-06-27 05:04:34 --> Hooks Class Initialized
DEBUG - 2018-06-27 05:04:34 --> UTF-8 Support Enabled
INFO - 2018-06-27 05:04:34 --> Utf8 Class Initialized
INFO - 2018-06-27 05:04:34 --> URI Class Initialized
INFO - 2018-06-27 05:04:34 --> Router Class Initialized
INFO - 2018-06-27 05:04:34 --> Output Class Initialized
INFO - 2018-06-27 05:04:34 --> Security Class Initialized
DEBUG - 2018-06-27 05:04:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-27 05:04:34 --> Input Class Initialized
INFO - 2018-06-27 05:04:34 --> Language Class Initialized
INFO - 2018-06-27 05:04:34 --> Language Class Initialized
INFO - 2018-06-27 05:04:34 --> Config Class Initialized
INFO - 2018-06-27 05:04:34 --> Loader Class Initialized
DEBUG - 2018-06-27 05:04:34 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-27 05:04:34 --> Helper loaded: url_helper
INFO - 2018-06-27 05:04:34 --> Helper loaded: form_helper
INFO - 2018-06-27 05:04:34 --> Helper loaded: date_helper
INFO - 2018-06-27 05:04:34 --> Helper loaded: util_helper
INFO - 2018-06-27 05:04:34 --> Helper loaded: text_helper
INFO - 2018-06-27 05:04:34 --> Helper loaded: string_helper
INFO - 2018-06-27 05:04:34 --> Database Driver Class Initialized
DEBUG - 2018-06-27 05:04:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-27 05:04:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-27 05:04:34 --> Email Class Initialized
INFO - 2018-06-27 05:04:34 --> Controller Class Initialized
DEBUG - 2018-06-27 05:04:34 --> videos MX_Controller Initialized
INFO - 2018-06-27 05:04:34 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-27 05:04:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-06-27 05:04:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-27 05:04:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-27 05:04:35 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-27 05:04:35 --> Login MX_Controller Initialized
DEBUG - 2018-06-27 05:04:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-27 05:04:35 --> Final output sent to browser
DEBUG - 2018-06-27 05:04:35 --> Total execution time: 0.5323
INFO - 2018-06-27 05:12:41 --> Config Class Initialized
INFO - 2018-06-27 05:12:41 --> Hooks Class Initialized
DEBUG - 2018-06-27 05:12:41 --> UTF-8 Support Enabled
INFO - 2018-06-27 05:12:41 --> Utf8 Class Initialized
INFO - 2018-06-27 05:12:41 --> URI Class Initialized
INFO - 2018-06-27 05:12:41 --> Router Class Initialized
INFO - 2018-06-27 05:12:41 --> Output Class Initialized
INFO - 2018-06-27 05:12:41 --> Security Class Initialized
DEBUG - 2018-06-27 05:12:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-27 05:12:41 --> Input Class Initialized
INFO - 2018-06-27 05:12:41 --> Language Class Initialized
INFO - 2018-06-27 05:12:41 --> Language Class Initialized
INFO - 2018-06-27 05:12:41 --> Config Class Initialized
INFO - 2018-06-27 05:12:41 --> Loader Class Initialized
DEBUG - 2018-06-27 05:12:41 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-27 05:12:41 --> Helper loaded: url_helper
INFO - 2018-06-27 05:12:41 --> Helper loaded: form_helper
INFO - 2018-06-27 05:12:41 --> Helper loaded: date_helper
INFO - 2018-06-27 05:12:41 --> Helper loaded: util_helper
INFO - 2018-06-27 05:12:41 --> Helper loaded: text_helper
INFO - 2018-06-27 05:12:41 --> Helper loaded: string_helper
INFO - 2018-06-27 05:12:41 --> Database Driver Class Initialized
DEBUG - 2018-06-27 05:12:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-27 05:12:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-27 05:12:41 --> Email Class Initialized
INFO - 2018-06-27 05:12:41 --> Controller Class Initialized
DEBUG - 2018-06-27 05:12:41 --> videos MX_Controller Initialized
INFO - 2018-06-27 05:12:41 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-27 05:12:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-06-27 05:12:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-27 05:12:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-27 05:12:41 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-27 05:12:41 --> Login MX_Controller Initialized
DEBUG - 2018-06-27 05:12:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-27 05:12:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-27 05:12:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-27 05:12:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-27 05:12:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-27 05:12:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-27 05:12:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/videos/videos.php
INFO - 2018-06-27 05:12:42 --> Final output sent to browser
DEBUG - 2018-06-27 05:12:42 --> Total execution time: 0.4475
INFO - 2018-06-27 05:12:42 --> Config Class Initialized
INFO - 2018-06-27 05:12:42 --> Hooks Class Initialized
DEBUG - 2018-06-27 05:12:42 --> UTF-8 Support Enabled
INFO - 2018-06-27 05:12:42 --> Utf8 Class Initialized
INFO - 2018-06-27 05:12:42 --> URI Class Initialized
INFO - 2018-06-27 05:12:42 --> Router Class Initialized
INFO - 2018-06-27 05:12:42 --> Output Class Initialized
INFO - 2018-06-27 05:12:42 --> Security Class Initialized
DEBUG - 2018-06-27 05:12:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-27 05:12:42 --> Input Class Initialized
INFO - 2018-06-27 05:12:42 --> Language Class Initialized
INFO - 2018-06-27 05:12:42 --> Language Class Initialized
INFO - 2018-06-27 05:12:42 --> Config Class Initialized
INFO - 2018-06-27 05:12:42 --> Loader Class Initialized
DEBUG - 2018-06-27 05:12:42 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-27 05:12:42 --> Helper loaded: url_helper
INFO - 2018-06-27 05:12:42 --> Helper loaded: form_helper
INFO - 2018-06-27 05:12:42 --> Helper loaded: date_helper
INFO - 2018-06-27 05:12:42 --> Helper loaded: util_helper
INFO - 2018-06-27 05:12:42 --> Helper loaded: text_helper
INFO - 2018-06-27 05:12:42 --> Helper loaded: string_helper
INFO - 2018-06-27 05:12:42 --> Database Driver Class Initialized
DEBUG - 2018-06-27 05:12:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-27 05:12:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-27 05:12:42 --> Email Class Initialized
INFO - 2018-06-27 05:12:42 --> Controller Class Initialized
DEBUG - 2018-06-27 05:12:43 --> videos MX_Controller Initialized
INFO - 2018-06-27 05:12:43 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-27 05:12:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-06-27 05:12:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-27 05:12:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-27 05:12:43 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-27 05:12:43 --> Login MX_Controller Initialized
DEBUG - 2018-06-27 05:12:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-27 05:12:43 --> Final output sent to browser
DEBUG - 2018-06-27 05:12:43 --> Total execution time: 0.5940
INFO - 2018-06-27 05:38:51 --> Config Class Initialized
INFO - 2018-06-27 05:38:51 --> Hooks Class Initialized
DEBUG - 2018-06-27 05:38:51 --> UTF-8 Support Enabled
INFO - 2018-06-27 05:38:51 --> Utf8 Class Initialized
INFO - 2018-06-27 05:38:51 --> URI Class Initialized
INFO - 2018-06-27 05:38:51 --> Router Class Initialized
INFO - 2018-06-27 05:38:51 --> Output Class Initialized
INFO - 2018-06-27 05:38:51 --> Security Class Initialized
DEBUG - 2018-06-27 05:38:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-27 05:38:51 --> Input Class Initialized
INFO - 2018-06-27 05:38:51 --> Language Class Initialized
INFO - 2018-06-27 05:38:51 --> Language Class Initialized
INFO - 2018-06-27 05:38:51 --> Config Class Initialized
INFO - 2018-06-27 05:38:51 --> Loader Class Initialized
DEBUG - 2018-06-27 05:38:51 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-27 05:38:51 --> Helper loaded: url_helper
INFO - 2018-06-27 05:38:51 --> Helper loaded: form_helper
INFO - 2018-06-27 05:38:51 --> Helper loaded: date_helper
INFO - 2018-06-27 05:38:51 --> Helper loaded: util_helper
INFO - 2018-06-27 05:38:51 --> Helper loaded: text_helper
INFO - 2018-06-27 05:38:51 --> Helper loaded: string_helper
INFO - 2018-06-27 05:38:51 --> Database Driver Class Initialized
DEBUG - 2018-06-27 05:38:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-27 05:38:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-27 05:38:52 --> Email Class Initialized
INFO - 2018-06-27 05:38:52 --> Controller Class Initialized
DEBUG - 2018-06-27 05:38:52 --> videos MX_Controller Initialized
INFO - 2018-06-27 05:38:52 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-27 05:38:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-06-27 05:38:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-27 05:38:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-27 05:38:52 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-27 05:38:52 --> Login MX_Controller Initialized
DEBUG - 2018-06-27 05:38:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-27 05:38:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-27 05:38:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-27 05:38:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-27 05:38:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-27 05:38:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-27 05:38:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/videos/videos.php
INFO - 2018-06-27 05:38:52 --> Final output sent to browser
DEBUG - 2018-06-27 05:38:52 --> Total execution time: 0.4329
INFO - 2018-06-27 05:38:52 --> Config Class Initialized
INFO - 2018-06-27 05:38:52 --> Hooks Class Initialized
DEBUG - 2018-06-27 05:38:52 --> UTF-8 Support Enabled
INFO - 2018-06-27 05:38:52 --> Utf8 Class Initialized
INFO - 2018-06-27 05:38:52 --> URI Class Initialized
INFO - 2018-06-27 05:38:52 --> Router Class Initialized
INFO - 2018-06-27 05:38:52 --> Output Class Initialized
INFO - 2018-06-27 05:38:52 --> Security Class Initialized
DEBUG - 2018-06-27 05:38:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-27 05:38:52 --> Input Class Initialized
INFO - 2018-06-27 05:38:52 --> Language Class Initialized
INFO - 2018-06-27 05:38:52 --> Language Class Initialized
INFO - 2018-06-27 05:38:52 --> Config Class Initialized
INFO - 2018-06-27 05:38:52 --> Loader Class Initialized
DEBUG - 2018-06-27 05:38:52 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-27 05:38:52 --> Helper loaded: url_helper
INFO - 2018-06-27 05:38:52 --> Helper loaded: form_helper
INFO - 2018-06-27 05:38:52 --> Helper loaded: date_helper
INFO - 2018-06-27 05:38:52 --> Helper loaded: util_helper
INFO - 2018-06-27 05:38:53 --> Helper loaded: text_helper
INFO - 2018-06-27 05:38:53 --> Helper loaded: string_helper
INFO - 2018-06-27 05:38:53 --> Database Driver Class Initialized
DEBUG - 2018-06-27 05:38:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-27 05:38:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-27 05:38:53 --> Email Class Initialized
INFO - 2018-06-27 05:38:53 --> Controller Class Initialized
DEBUG - 2018-06-27 05:38:53 --> videos MX_Controller Initialized
INFO - 2018-06-27 05:38:53 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-27 05:38:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-06-27 05:38:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-27 05:38:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-27 05:38:53 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-27 05:38:53 --> Login MX_Controller Initialized
DEBUG - 2018-06-27 05:38:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-27 05:38:53 --> Final output sent to browser
DEBUG - 2018-06-27 05:38:53 --> Total execution time: 0.5528
INFO - 2018-06-27 21:22:24 --> Config Class Initialized
INFO - 2018-06-27 21:22:24 --> Hooks Class Initialized
DEBUG - 2018-06-27 21:22:25 --> UTF-8 Support Enabled
INFO - 2018-06-27 21:22:25 --> Utf8 Class Initialized
INFO - 2018-06-27 21:22:25 --> URI Class Initialized
INFO - 2018-06-27 21:22:25 --> Router Class Initialized
INFO - 2018-06-27 21:22:25 --> Output Class Initialized
INFO - 2018-06-27 21:22:25 --> Security Class Initialized
DEBUG - 2018-06-27 21:22:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-27 21:22:25 --> Input Class Initialized
INFO - 2018-06-27 21:22:25 --> Language Class Initialized
INFO - 2018-06-27 21:22:25 --> Config Class Initialized
INFO - 2018-06-27 21:22:25 --> Hooks Class Initialized
INFO - 2018-06-27 21:22:25 --> Language Class Initialized
DEBUG - 2018-06-27 21:22:25 --> UTF-8 Support Enabled
INFO - 2018-06-27 21:22:25 --> Utf8 Class Initialized
INFO - 2018-06-27 21:22:25 --> Config Class Initialized
INFO - 2018-06-27 21:22:25 --> URI Class Initialized
INFO - 2018-06-27 21:22:25 --> Router Class Initialized
INFO - 2018-06-27 21:22:25 --> Output Class Initialized
INFO - 2018-06-27 21:22:25 --> Security Class Initialized
DEBUG - 2018-06-27 21:22:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-27 21:22:25 --> Loader Class Initialized
INFO - 2018-06-27 21:22:25 --> Input Class Initialized
INFO - 2018-06-27 21:22:25 --> Language Class Initialized
INFO - 2018-06-27 21:22:25 --> Language Class Initialized
INFO - 2018-06-27 21:22:25 --> Config Class Initialized
INFO - 2018-06-27 21:22:25 --> Loader Class Initialized
DEBUG - 2018-06-27 21:22:25 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
DEBUG - 2018-06-27 21:22:25 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-27 21:22:25 --> Helper loaded: url_helper
INFO - 2018-06-27 21:22:25 --> Helper loaded: url_helper
INFO - 2018-06-27 21:22:25 --> Helper loaded: form_helper
INFO - 2018-06-27 21:22:25 --> Helper loaded: form_helper
INFO - 2018-06-27 21:22:25 --> Helper loaded: date_helper
INFO - 2018-06-27 21:22:25 --> Helper loaded: date_helper
INFO - 2018-06-27 21:22:25 --> Helper loaded: util_helper
INFO - 2018-06-27 21:22:25 --> Helper loaded: util_helper
INFO - 2018-06-27 21:22:25 --> Helper loaded: text_helper
INFO - 2018-06-27 21:22:25 --> Helper loaded: text_helper
INFO - 2018-06-27 21:22:25 --> Helper loaded: string_helper
INFO - 2018-06-27 21:22:25 --> Helper loaded: string_helper
INFO - 2018-06-27 21:22:25 --> Database Driver Class Initialized
INFO - 2018-06-27 21:22:25 --> Database Driver Class Initialized
DEBUG - 2018-06-27 21:22:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-06-27 21:22:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-27 21:22:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-27 21:22:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-27 21:22:26 --> Email Class Initialized
INFO - 2018-06-27 21:22:26 --> Email Class Initialized
INFO - 2018-06-27 21:22:26 --> Controller Class Initialized
INFO - 2018-06-27 21:22:26 --> Controller Class Initialized
DEBUG - 2018-06-27 21:22:26 --> Home MX_Controller Initialized
DEBUG - 2018-06-27 21:22:26 --> Home MX_Controller Initialized
DEBUG - 2018-06-27 21:22:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-06-27 21:22:26 --> Config Class Initialized
DEBUG - 2018-06-27 21:22:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-06-27 21:22:26 --> Hooks Class Initialized
DEBUG - 2018-06-27 21:22:26 --> UTF-8 Support Enabled
INFO - 2018-06-27 21:22:26 --> Utf8 Class Initialized
INFO - 2018-06-27 21:22:26 --> URI Class Initialized
DEBUG - 2018-06-27 21:22:26 --> No URI present. Default controller set.
INFO - 2018-06-27 21:22:26 --> Router Class Initialized
INFO - 2018-06-27 21:22:26 --> Output Class Initialized
INFO - 2018-06-27 21:22:26 --> Security Class Initialized
DEBUG - 2018-06-27 21:22:26 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-27 21:22:26 --> Login MX_Controller Initialized
DEBUG - 2018-06-27 21:22:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-06-27 21:22:26 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-27 21:22:26 --> Login MX_Controller Initialized
INFO - 2018-06-27 21:22:26 --> Input Class Initialized
INFO - 2018-06-27 21:22:26 --> Language file loaded: language/english/data_lang.php
INFO - 2018-06-27 21:22:26 --> Language Class Initialized
INFO - 2018-06-27 21:22:26 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-27 21:22:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-27 21:22:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-06-27 21:22:26 --> Language Class Initialized
INFO - 2018-06-27 21:22:26 --> Config Class Initialized
INFO - 2018-06-27 21:22:26 --> Loader Class Initialized
DEBUG - 2018-06-27 21:22:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-27 21:22:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-27 21:22:26 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-27 21:22:26 --> Helper loaded: url_helper
INFO - 2018-06-27 21:22:26 --> Helper loaded: form_helper
INFO - 2018-06-27 21:22:26 --> Helper loaded: date_helper
INFO - 2018-06-27 21:22:26 --> Helper loaded: util_helper
DEBUG - 2018-06-27 21:22:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
DEBUG - 2018-06-27 21:22:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-06-27 21:22:26 --> Helper loaded: text_helper
INFO - 2018-06-27 21:22:26 --> Helper loaded: string_helper
INFO - 2018-06-27 21:22:26 --> Database Driver Class Initialized
DEBUG - 2018-06-27 21:22:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-27 21:22:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-27 21:22:26 --> Email Class Initialized
INFO - 2018-06-27 21:22:26 --> Controller Class Initialized
DEBUG - 2018-06-27 21:22:26 --> Home MX_Controller Initialized
DEBUG - 2018-06-27 21:22:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-27 21:22:26 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-27 21:22:26 --> Login MX_Controller Initialized
INFO - 2018-06-27 21:22:26 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-27 21:22:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-27 21:22:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-27 21:22:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-06-27 21:22:26 --> Config Class Initialized
INFO - 2018-06-27 21:22:26 --> Hooks Class Initialized
DEBUG - 2018-06-27 21:22:26 --> UTF-8 Support Enabled
INFO - 2018-06-27 21:22:26 --> Utf8 Class Initialized
INFO - 2018-06-27 21:22:27 --> URI Class Initialized
INFO - 2018-06-27 21:22:27 --> Router Class Initialized
INFO - 2018-06-27 21:22:27 --> Output Class Initialized
INFO - 2018-06-27 21:22:27 --> Security Class Initialized
DEBUG - 2018-06-27 21:22:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-27 21:22:27 --> Input Class Initialized
INFO - 2018-06-27 21:22:27 --> Language Class Initialized
INFO - 2018-06-27 21:22:27 --> Language Class Initialized
INFO - 2018-06-27 21:22:27 --> Config Class Initialized
INFO - 2018-06-27 21:22:27 --> Loader Class Initialized
DEBUG - 2018-06-27 21:22:27 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-27 21:22:27 --> Helper loaded: url_helper
INFO - 2018-06-27 21:22:27 --> Helper loaded: form_helper
INFO - 2018-06-27 21:22:27 --> Helper loaded: date_helper
INFO - 2018-06-27 21:22:27 --> Helper loaded: util_helper
INFO - 2018-06-27 21:22:27 --> Helper loaded: text_helper
INFO - 2018-06-27 21:22:27 --> Helper loaded: string_helper
INFO - 2018-06-27 21:22:27 --> Database Driver Class Initialized
DEBUG - 2018-06-27 21:22:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-27 21:22:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-27 21:22:27 --> Email Class Initialized
INFO - 2018-06-27 21:22:27 --> Controller Class Initialized
DEBUG - 2018-06-27 21:22:27 --> videos MX_Controller Initialized
INFO - 2018-06-27 21:22:27 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-27 21:22:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-06-27 21:22:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-27 21:22:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-27 21:22:27 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-27 21:22:27 --> Login MX_Controller Initialized
DEBUG - 2018-06-27 21:22:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-27 21:22:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
INFO - 2018-06-27 21:22:27 --> Config Class Initialized
INFO - 2018-06-27 21:22:27 --> Hooks Class Initialized
DEBUG - 2018-06-27 21:22:27 --> UTF-8 Support Enabled
INFO - 2018-06-27 21:22:27 --> Utf8 Class Initialized
INFO - 2018-06-27 21:22:27 --> URI Class Initialized
INFO - 2018-06-27 21:22:28 --> Router Class Initialized
INFO - 2018-06-27 21:22:28 --> Output Class Initialized
INFO - 2018-06-27 21:22:28 --> Security Class Initialized
DEBUG - 2018-06-27 21:22:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-27 21:22:28 --> Input Class Initialized
INFO - 2018-06-27 21:22:28 --> Language Class Initialized
ERROR - 2018-06-27 21:22:28 --> 404 Page Not Found: /index
INFO - 2018-06-27 21:22:28 --> Config Class Initialized
INFO - 2018-06-27 21:22:28 --> Hooks Class Initialized
DEBUG - 2018-06-27 21:22:28 --> UTF-8 Support Enabled
INFO - 2018-06-27 21:22:28 --> Utf8 Class Initialized
INFO - 2018-06-27 21:22:28 --> URI Class Initialized
INFO - 2018-06-27 21:22:28 --> Router Class Initialized
INFO - 2018-06-27 21:22:28 --> Output Class Initialized
INFO - 2018-06-27 21:22:28 --> Security Class Initialized
DEBUG - 2018-06-27 21:22:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-27 21:22:28 --> Input Class Initialized
INFO - 2018-06-27 21:22:28 --> Language Class Initialized
ERROR - 2018-06-27 21:22:28 --> 404 Page Not Found: /index
INFO - 2018-06-27 21:45:29 --> Config Class Initialized
INFO - 2018-06-27 21:45:29 --> Hooks Class Initialized
DEBUG - 2018-06-27 21:45:29 --> UTF-8 Support Enabled
INFO - 2018-06-27 21:45:29 --> Utf8 Class Initialized
INFO - 2018-06-27 21:45:29 --> URI Class Initialized
INFO - 2018-06-27 21:45:29 --> Router Class Initialized
INFO - 2018-06-27 21:45:29 --> Output Class Initialized
INFO - 2018-06-27 21:45:29 --> Security Class Initialized
DEBUG - 2018-06-27 21:45:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-27 21:45:29 --> Input Class Initialized
INFO - 2018-06-27 21:45:29 --> Language Class Initialized
INFO - 2018-06-27 21:45:29 --> Language Class Initialized
INFO - 2018-06-27 21:45:29 --> Config Class Initialized
INFO - 2018-06-27 21:45:29 --> Loader Class Initialized
DEBUG - 2018-06-27 21:45:29 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-27 21:45:29 --> Helper loaded: url_helper
INFO - 2018-06-27 21:45:29 --> Helper loaded: form_helper
INFO - 2018-06-27 21:45:29 --> Helper loaded: date_helper
INFO - 2018-06-27 21:45:29 --> Helper loaded: util_helper
INFO - 2018-06-27 21:45:29 --> Helper loaded: text_helper
INFO - 2018-06-27 21:45:29 --> Helper loaded: string_helper
INFO - 2018-06-27 21:45:29 --> Database Driver Class Initialized
DEBUG - 2018-06-27 21:45:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-27 21:45:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-27 21:45:29 --> Email Class Initialized
INFO - 2018-06-27 21:45:29 --> Controller Class Initialized
DEBUG - 2018-06-27 21:45:29 --> Login MX_Controller Initialized
INFO - 2018-06-27 21:45:29 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-27 21:45:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-27 21:45:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-27 21:45:29 --> Email starts for user@colin.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-06-27 21:45:29 --> User session created for 4
INFO - 2018-06-27 21:45:29 --> Login status user@colin.com - success
INFO - 2018-06-27 21:45:29 --> Final output sent to browser
DEBUG - 2018-06-27 21:45:29 --> Total execution time: 0.4808
INFO - 2018-06-27 21:45:29 --> Config Class Initialized
INFO - 2018-06-27 21:45:29 --> Hooks Class Initialized
DEBUG - 2018-06-27 21:45:29 --> UTF-8 Support Enabled
INFO - 2018-06-27 21:45:29 --> Utf8 Class Initialized
INFO - 2018-06-27 21:45:29 --> URI Class Initialized
INFO - 2018-06-27 21:45:29 --> Router Class Initialized
INFO - 2018-06-27 21:45:30 --> Output Class Initialized
INFO - 2018-06-27 21:45:30 --> Security Class Initialized
DEBUG - 2018-06-27 21:45:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-27 21:45:30 --> Input Class Initialized
INFO - 2018-06-27 21:45:30 --> Language Class Initialized
INFO - 2018-06-27 21:45:30 --> Language Class Initialized
INFO - 2018-06-27 21:45:30 --> Config Class Initialized
INFO - 2018-06-27 21:45:30 --> Loader Class Initialized
DEBUG - 2018-06-27 21:45:30 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-27 21:45:30 --> Helper loaded: url_helper
INFO - 2018-06-27 21:45:30 --> Helper loaded: form_helper
INFO - 2018-06-27 21:45:30 --> Helper loaded: date_helper
INFO - 2018-06-27 21:45:30 --> Helper loaded: util_helper
INFO - 2018-06-27 21:45:30 --> Helper loaded: text_helper
INFO - 2018-06-27 21:45:30 --> Helper loaded: string_helper
INFO - 2018-06-27 21:45:30 --> Database Driver Class Initialized
DEBUG - 2018-06-27 21:45:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-27 21:45:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-27 21:45:30 --> Email Class Initialized
INFO - 2018-06-27 21:45:30 --> Controller Class Initialized
DEBUG - 2018-06-27 21:45:30 --> Home MX_Controller Initialized
DEBUG - 2018-06-27 21:45:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-27 21:45:30 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-27 21:45:30 --> Login MX_Controller Initialized
INFO - 2018-06-27 21:45:30 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-27 21:45:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-27 21:45:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-27 21:45:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-27 21:45:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-27 21:45:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-27 21:45:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-27 21:45:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-27 21:45:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/search_page.php
INFO - 2018-06-27 21:45:30 --> Final output sent to browser
DEBUG - 2018-06-27 21:45:30 --> Total execution time: 0.7793
INFO - 2018-06-27 21:45:32 --> Config Class Initialized
INFO - 2018-06-27 21:45:32 --> Hooks Class Initialized
DEBUG - 2018-06-27 21:45:32 --> UTF-8 Support Enabled
INFO - 2018-06-27 21:45:32 --> Utf8 Class Initialized
INFO - 2018-06-27 21:45:32 --> URI Class Initialized
INFO - 2018-06-27 21:45:32 --> Router Class Initialized
INFO - 2018-06-27 21:45:32 --> Output Class Initialized
INFO - 2018-06-27 21:45:32 --> Security Class Initialized
DEBUG - 2018-06-27 21:45:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-27 21:45:32 --> Input Class Initialized
INFO - 2018-06-27 21:45:32 --> Language Class Initialized
ERROR - 2018-06-27 21:45:32 --> 404 Page Not Found: /index
INFO - 2018-06-27 21:45:32 --> Config Class Initialized
INFO - 2018-06-27 21:45:32 --> Hooks Class Initialized
DEBUG - 2018-06-27 21:45:32 --> UTF-8 Support Enabled
INFO - 2018-06-27 21:45:32 --> Utf8 Class Initialized
INFO - 2018-06-27 21:45:32 --> URI Class Initialized
INFO - 2018-06-27 21:45:32 --> Router Class Initialized
INFO - 2018-06-27 21:45:32 --> Output Class Initialized
INFO - 2018-06-27 21:45:32 --> Security Class Initialized
DEBUG - 2018-06-27 21:45:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-27 21:45:32 --> Input Class Initialized
INFO - 2018-06-27 21:45:32 --> Language Class Initialized
ERROR - 2018-06-27 21:45:32 --> 404 Page Not Found: /index
INFO - 2018-06-27 21:45:32 --> Config Class Initialized
INFO - 2018-06-27 21:45:32 --> Hooks Class Initialized
DEBUG - 2018-06-27 21:45:32 --> UTF-8 Support Enabled
INFO - 2018-06-27 21:45:32 --> Utf8 Class Initialized
INFO - 2018-06-27 21:45:32 --> URI Class Initialized
INFO - 2018-06-27 21:45:32 --> Router Class Initialized
INFO - 2018-06-27 21:45:32 --> Output Class Initialized
INFO - 2018-06-27 21:45:32 --> Security Class Initialized
DEBUG - 2018-06-27 21:45:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-27 21:45:32 --> Input Class Initialized
INFO - 2018-06-27 21:45:32 --> Language Class Initialized
ERROR - 2018-06-27 21:45:32 --> 404 Page Not Found: /index
INFO - 2018-06-27 21:45:32 --> Config Class Initialized
INFO - 2018-06-27 21:45:32 --> Hooks Class Initialized
DEBUG - 2018-06-27 21:45:32 --> UTF-8 Support Enabled
INFO - 2018-06-27 21:45:32 --> Utf8 Class Initialized
INFO - 2018-06-27 21:45:32 --> URI Class Initialized
INFO - 2018-06-27 21:45:32 --> Router Class Initialized
INFO - 2018-06-27 21:45:32 --> Output Class Initialized
INFO - 2018-06-27 21:45:32 --> Security Class Initialized
DEBUG - 2018-06-27 21:45:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-27 21:45:32 --> Input Class Initialized
INFO - 2018-06-27 21:45:32 --> Language Class Initialized
ERROR - 2018-06-27 21:45:32 --> 404 Page Not Found: /index
INFO - 2018-06-27 21:45:32 --> Config Class Initialized
INFO - 2018-06-27 21:45:32 --> Hooks Class Initialized
DEBUG - 2018-06-27 21:45:32 --> UTF-8 Support Enabled
INFO - 2018-06-27 21:45:32 --> Utf8 Class Initialized
INFO - 2018-06-27 21:45:32 --> URI Class Initialized
INFO - 2018-06-27 21:45:32 --> Router Class Initialized
INFO - 2018-06-27 21:45:32 --> Output Class Initialized
INFO - 2018-06-27 21:45:32 --> Security Class Initialized
DEBUG - 2018-06-27 21:45:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-27 21:45:32 --> Input Class Initialized
INFO - 2018-06-27 21:45:32 --> Language Class Initialized
ERROR - 2018-06-27 21:45:32 --> 404 Page Not Found: /index
INFO - 2018-06-27 21:45:33 --> Config Class Initialized
INFO - 2018-06-27 21:45:33 --> Hooks Class Initialized
DEBUG - 2018-06-27 21:45:33 --> UTF-8 Support Enabled
INFO - 2018-06-27 21:45:33 --> Utf8 Class Initialized
INFO - 2018-06-27 21:45:33 --> URI Class Initialized
INFO - 2018-06-27 21:45:33 --> Router Class Initialized
INFO - 2018-06-27 21:45:33 --> Output Class Initialized
INFO - 2018-06-27 21:45:33 --> Security Class Initialized
DEBUG - 2018-06-27 21:45:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-27 21:45:33 --> Input Class Initialized
INFO - 2018-06-27 21:45:33 --> Language Class Initialized
ERROR - 2018-06-27 21:45:33 --> 404 Page Not Found: /index
INFO - 2018-06-27 21:45:39 --> Config Class Initialized
INFO - 2018-06-27 21:45:39 --> Hooks Class Initialized
DEBUG - 2018-06-27 21:45:39 --> UTF-8 Support Enabled
INFO - 2018-06-27 21:45:39 --> Utf8 Class Initialized
INFO - 2018-06-27 21:45:39 --> URI Class Initialized
INFO - 2018-06-27 21:45:39 --> Router Class Initialized
INFO - 2018-06-27 21:45:39 --> Output Class Initialized
INFO - 2018-06-27 21:45:39 --> Security Class Initialized
DEBUG - 2018-06-27 21:45:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-27 21:45:40 --> Input Class Initialized
INFO - 2018-06-27 21:45:40 --> Language Class Initialized
INFO - 2018-06-27 21:45:40 --> Language Class Initialized
INFO - 2018-06-27 21:45:40 --> Config Class Initialized
INFO - 2018-06-27 21:45:40 --> Loader Class Initialized
DEBUG - 2018-06-27 21:45:40 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-27 21:45:40 --> Helper loaded: url_helper
INFO - 2018-06-27 21:45:40 --> Helper loaded: form_helper
INFO - 2018-06-27 21:45:40 --> Helper loaded: date_helper
INFO - 2018-06-27 21:45:40 --> Helper loaded: util_helper
INFO - 2018-06-27 21:45:40 --> Helper loaded: text_helper
INFO - 2018-06-27 21:45:40 --> Helper loaded: string_helper
INFO - 2018-06-27 21:45:40 --> Database Driver Class Initialized
DEBUG - 2018-06-27 21:45:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-27 21:45:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-27 21:45:40 --> Email Class Initialized
INFO - 2018-06-27 21:45:40 --> Controller Class Initialized
DEBUG - 2018-06-27 21:45:40 --> Login MX_Controller Initialized
INFO - 2018-06-27 21:45:40 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-27 21:45:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-27 21:45:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-27 21:45:40 --> Email starts for user@colin.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-06-27 21:45:40 --> User session created for 4
INFO - 2018-06-27 21:45:40 --> Login status user@colin.com - success
INFO - 2018-06-27 21:45:40 --> Final output sent to browser
DEBUG - 2018-06-27 21:45:40 --> Total execution time: 0.4026
INFO - 2018-06-27 21:45:40 --> Config Class Initialized
INFO - 2018-06-27 21:45:40 --> Hooks Class Initialized
DEBUG - 2018-06-27 21:45:40 --> UTF-8 Support Enabled
INFO - 2018-06-27 21:45:40 --> Utf8 Class Initialized
INFO - 2018-06-27 21:45:40 --> URI Class Initialized
INFO - 2018-06-27 21:45:40 --> Router Class Initialized
INFO - 2018-06-27 21:45:40 --> Output Class Initialized
INFO - 2018-06-27 21:45:40 --> Security Class Initialized
DEBUG - 2018-06-27 21:45:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-27 21:45:40 --> Input Class Initialized
INFO - 2018-06-27 21:45:40 --> Language Class Initialized
INFO - 2018-06-27 21:45:40 --> Language Class Initialized
INFO - 2018-06-27 21:45:40 --> Config Class Initialized
INFO - 2018-06-27 21:45:40 --> Loader Class Initialized
DEBUG - 2018-06-27 21:45:40 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-27 21:45:40 --> Helper loaded: url_helper
INFO - 2018-06-27 21:45:40 --> Helper loaded: form_helper
INFO - 2018-06-27 21:45:40 --> Helper loaded: date_helper
INFO - 2018-06-27 21:45:40 --> Helper loaded: util_helper
INFO - 2018-06-27 21:45:40 --> Helper loaded: text_helper
INFO - 2018-06-27 21:45:40 --> Helper loaded: string_helper
INFO - 2018-06-27 21:45:40 --> Database Driver Class Initialized
DEBUG - 2018-06-27 21:45:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-27 21:45:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-27 21:45:40 --> Email Class Initialized
INFO - 2018-06-27 21:45:40 --> Controller Class Initialized
DEBUG - 2018-06-27 21:45:40 --> Home MX_Controller Initialized
DEBUG - 2018-06-27 21:45:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-27 21:45:40 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-27 21:45:40 --> Login MX_Controller Initialized
INFO - 2018-06-27 21:45:40 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-27 21:45:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-27 21:45:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-27 21:45:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-27 21:45:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-27 21:45:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-27 21:45:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-27 21:45:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-27 21:45:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-06-27 21:45:40 --> Final output sent to browser
DEBUG - 2018-06-27 21:45:40 --> Total execution time: 0.5440
INFO - 2018-06-27 21:45:42 --> Config Class Initialized
INFO - 2018-06-27 21:45:42 --> Hooks Class Initialized
DEBUG - 2018-06-27 21:45:42 --> UTF-8 Support Enabled
INFO - 2018-06-27 21:45:42 --> Utf8 Class Initialized
INFO - 2018-06-27 21:45:42 --> URI Class Initialized
INFO - 2018-06-27 21:45:42 --> Router Class Initialized
INFO - 2018-06-27 21:45:42 --> Output Class Initialized
INFO - 2018-06-27 21:45:42 --> Security Class Initialized
DEBUG - 2018-06-27 21:45:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-27 21:45:42 --> Input Class Initialized
INFO - 2018-06-27 21:45:42 --> Language Class Initialized
ERROR - 2018-06-27 21:45:42 --> 404 Page Not Found: /index
INFO - 2018-06-27 21:45:42 --> Config Class Initialized
INFO - 2018-06-27 21:45:42 --> Hooks Class Initialized
DEBUG - 2018-06-27 21:45:42 --> UTF-8 Support Enabled
INFO - 2018-06-27 21:45:42 --> Utf8 Class Initialized
INFO - 2018-06-27 21:45:42 --> URI Class Initialized
INFO - 2018-06-27 21:45:42 --> Router Class Initialized
INFO - 2018-06-27 21:45:42 --> Output Class Initialized
INFO - 2018-06-27 21:45:42 --> Security Class Initialized
DEBUG - 2018-06-27 21:45:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-27 21:45:42 --> Input Class Initialized
INFO - 2018-06-27 21:45:42 --> Language Class Initialized
ERROR - 2018-06-27 21:45:42 --> 404 Page Not Found: /index
INFO - 2018-06-27 21:45:42 --> Config Class Initialized
INFO - 2018-06-27 21:45:42 --> Hooks Class Initialized
DEBUG - 2018-06-27 21:45:42 --> UTF-8 Support Enabled
INFO - 2018-06-27 21:45:42 --> Utf8 Class Initialized
INFO - 2018-06-27 21:45:42 --> URI Class Initialized
INFO - 2018-06-27 21:45:42 --> Router Class Initialized
INFO - 2018-06-27 21:45:42 --> Output Class Initialized
INFO - 2018-06-27 21:45:42 --> Security Class Initialized
DEBUG - 2018-06-27 21:45:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-27 21:45:42 --> Input Class Initialized
INFO - 2018-06-27 21:45:42 --> Language Class Initialized
ERROR - 2018-06-27 21:45:42 --> 404 Page Not Found: /index
INFO - 2018-06-27 21:45:45 --> Config Class Initialized
INFO - 2018-06-27 21:45:45 --> Hooks Class Initialized
DEBUG - 2018-06-27 21:45:45 --> UTF-8 Support Enabled
INFO - 2018-06-27 21:45:45 --> Utf8 Class Initialized
INFO - 2018-06-27 21:45:45 --> URI Class Initialized
INFO - 2018-06-27 21:45:45 --> Router Class Initialized
INFO - 2018-06-27 21:45:45 --> Output Class Initialized
INFO - 2018-06-27 21:45:45 --> Security Class Initialized
DEBUG - 2018-06-27 21:45:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-27 21:45:45 --> Input Class Initialized
INFO - 2018-06-27 21:45:45 --> Language Class Initialized
INFO - 2018-06-27 21:45:45 --> Language Class Initialized
INFO - 2018-06-27 21:45:45 --> Config Class Initialized
INFO - 2018-06-27 21:45:45 --> Loader Class Initialized
DEBUG - 2018-06-27 21:45:45 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-27 21:45:45 --> Helper loaded: url_helper
INFO - 2018-06-27 21:45:45 --> Helper loaded: form_helper
INFO - 2018-06-27 21:45:45 --> Helper loaded: date_helper
INFO - 2018-06-27 21:45:45 --> Helper loaded: util_helper
INFO - 2018-06-27 21:45:45 --> Helper loaded: text_helper
INFO - 2018-06-27 21:45:45 --> Helper loaded: string_helper
INFO - 2018-06-27 21:45:45 --> Database Driver Class Initialized
DEBUG - 2018-06-27 21:45:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-27 21:45:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-27 21:45:45 --> Email Class Initialized
INFO - 2018-06-27 21:45:45 --> Controller Class Initialized
DEBUG - 2018-06-27 21:45:45 --> Login MX_Controller Initialized
INFO - 2018-06-27 21:45:45 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-27 21:45:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-27 21:45:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-27 21:45:45 --> Email starts for admin@colin.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-06-27 21:45:45 --> User session created for 1
INFO - 2018-06-27 21:45:45 --> Login status admin@colin.com - success
INFO - 2018-06-27 21:45:45 --> Final output sent to browser
DEBUG - 2018-06-27 21:45:45 --> Total execution time: 0.4084
INFO - 2018-06-27 21:45:45 --> Config Class Initialized
INFO - 2018-06-27 21:45:45 --> Hooks Class Initialized
DEBUG - 2018-06-27 21:45:45 --> UTF-8 Support Enabled
INFO - 2018-06-27 21:45:45 --> Utf8 Class Initialized
INFO - 2018-06-27 21:45:45 --> URI Class Initialized
DEBUG - 2018-06-27 21:45:45 --> No URI present. Default controller set.
INFO - 2018-06-27 21:45:45 --> Router Class Initialized
INFO - 2018-06-27 21:45:45 --> Output Class Initialized
INFO - 2018-06-27 21:45:45 --> Security Class Initialized
DEBUG - 2018-06-27 21:45:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-27 21:45:45 --> Input Class Initialized
INFO - 2018-06-27 21:45:45 --> Language Class Initialized
INFO - 2018-06-27 21:45:45 --> Language Class Initialized
INFO - 2018-06-27 21:45:45 --> Config Class Initialized
INFO - 2018-06-27 21:45:45 --> Loader Class Initialized
DEBUG - 2018-06-27 21:45:45 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-27 21:45:45 --> Helper loaded: url_helper
INFO - 2018-06-27 21:45:45 --> Helper loaded: form_helper
INFO - 2018-06-27 21:45:45 --> Helper loaded: date_helper
INFO - 2018-06-27 21:45:45 --> Helper loaded: util_helper
INFO - 2018-06-27 21:45:45 --> Helper loaded: text_helper
INFO - 2018-06-27 21:45:45 --> Helper loaded: string_helper
INFO - 2018-06-27 21:45:45 --> Database Driver Class Initialized
DEBUG - 2018-06-27 21:45:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-27 21:45:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-27 21:45:45 --> Email Class Initialized
INFO - 2018-06-27 21:45:45 --> Controller Class Initialized
DEBUG - 2018-06-27 21:45:45 --> Home MX_Controller Initialized
DEBUG - 2018-06-27 21:45:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-27 21:45:45 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-27 21:45:45 --> Login MX_Controller Initialized
INFO - 2018-06-27 21:45:45 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-27 21:45:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-27 21:45:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-27 21:45:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-27 21:45:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-27 21:45:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-27 21:45:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-27 21:45:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-27 21:45:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-06-27 21:45:45 --> Final output sent to browser
DEBUG - 2018-06-27 21:45:46 --> Total execution time: 0.4463
INFO - 2018-06-27 21:45:48 --> Config Class Initialized
INFO - 2018-06-27 21:45:48 --> Hooks Class Initialized
DEBUG - 2018-06-27 21:45:48 --> UTF-8 Support Enabled
INFO - 2018-06-27 21:45:49 --> Utf8 Class Initialized
INFO - 2018-06-27 21:45:49 --> URI Class Initialized
INFO - 2018-06-27 21:45:49 --> Router Class Initialized
INFO - 2018-06-27 21:45:49 --> Output Class Initialized
INFO - 2018-06-27 21:45:49 --> Security Class Initialized
DEBUG - 2018-06-27 21:45:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-27 21:45:49 --> Input Class Initialized
INFO - 2018-06-27 21:45:49 --> Language Class Initialized
ERROR - 2018-06-27 21:45:49 --> 404 Page Not Found: /index
INFO - 2018-06-27 21:45:49 --> Config Class Initialized
INFO - 2018-06-27 21:45:49 --> Hooks Class Initialized
DEBUG - 2018-06-27 21:45:49 --> UTF-8 Support Enabled
INFO - 2018-06-27 21:45:49 --> Utf8 Class Initialized
INFO - 2018-06-27 21:45:49 --> URI Class Initialized
INFO - 2018-06-27 21:45:49 --> Router Class Initialized
INFO - 2018-06-27 21:45:49 --> Output Class Initialized
INFO - 2018-06-27 21:45:49 --> Security Class Initialized
DEBUG - 2018-06-27 21:45:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-27 21:45:49 --> Input Class Initialized
INFO - 2018-06-27 21:45:49 --> Language Class Initialized
ERROR - 2018-06-27 21:45:49 --> 404 Page Not Found: /index
INFO - 2018-06-27 21:45:49 --> Config Class Initialized
INFO - 2018-06-27 21:45:49 --> Hooks Class Initialized
DEBUG - 2018-06-27 21:45:49 --> UTF-8 Support Enabled
INFO - 2018-06-27 21:45:49 --> Utf8 Class Initialized
INFO - 2018-06-27 21:45:49 --> URI Class Initialized
INFO - 2018-06-27 21:45:49 --> Router Class Initialized
INFO - 2018-06-27 21:45:49 --> Output Class Initialized
INFO - 2018-06-27 21:45:49 --> Security Class Initialized
DEBUG - 2018-06-27 21:45:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-27 21:45:49 --> Input Class Initialized
INFO - 2018-06-27 21:45:49 --> Language Class Initialized
INFO - 2018-06-27 21:45:49 --> Config Class Initialized
INFO - 2018-06-27 21:45:49 --> Hooks Class Initialized
ERROR - 2018-06-27 21:45:49 --> 404 Page Not Found: /index
DEBUG - 2018-06-27 21:45:49 --> UTF-8 Support Enabled
INFO - 2018-06-27 21:45:49 --> Utf8 Class Initialized
INFO - 2018-06-27 21:45:49 --> URI Class Initialized
INFO - 2018-06-27 21:45:49 --> Router Class Initialized
INFO - 2018-06-27 21:45:49 --> Output Class Initialized
INFO - 2018-06-27 21:45:49 --> Security Class Initialized
DEBUG - 2018-06-27 21:45:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-27 21:45:49 --> Input Class Initialized
INFO - 2018-06-27 21:45:49 --> Language Class Initialized
ERROR - 2018-06-27 21:45:49 --> 404 Page Not Found: /index
INFO - 2018-06-27 21:45:49 --> Config Class Initialized
INFO - 2018-06-27 21:45:49 --> Hooks Class Initialized
DEBUG - 2018-06-27 21:45:49 --> UTF-8 Support Enabled
INFO - 2018-06-27 21:45:49 --> Utf8 Class Initialized
INFO - 2018-06-27 21:45:49 --> URI Class Initialized
INFO - 2018-06-27 21:45:49 --> Router Class Initialized
INFO - 2018-06-27 21:45:49 --> Output Class Initialized
INFO - 2018-06-27 21:45:49 --> Security Class Initialized
DEBUG - 2018-06-27 21:45:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-27 21:45:49 --> Input Class Initialized
INFO - 2018-06-27 21:45:49 --> Language Class Initialized
ERROR - 2018-06-27 21:45:49 --> 404 Page Not Found: /index
INFO - 2018-06-27 21:45:49 --> Config Class Initialized
INFO - 2018-06-27 21:45:49 --> Hooks Class Initialized
DEBUG - 2018-06-27 21:45:49 --> UTF-8 Support Enabled
INFO - 2018-06-27 21:45:49 --> Utf8 Class Initialized
INFO - 2018-06-27 21:45:50 --> URI Class Initialized
INFO - 2018-06-27 21:45:50 --> Router Class Initialized
INFO - 2018-06-27 21:45:50 --> Output Class Initialized
INFO - 2018-06-27 21:45:50 --> Security Class Initialized
DEBUG - 2018-06-27 21:45:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-27 21:45:50 --> Input Class Initialized
INFO - 2018-06-27 21:45:50 --> Language Class Initialized
ERROR - 2018-06-27 21:45:50 --> 404 Page Not Found: /index
INFO - 2018-06-27 21:45:50 --> Config Class Initialized
INFO - 2018-06-27 21:45:50 --> Hooks Class Initialized
DEBUG - 2018-06-27 21:45:50 --> UTF-8 Support Enabled
INFO - 2018-06-27 21:45:50 --> Utf8 Class Initialized
INFO - 2018-06-27 21:45:50 --> URI Class Initialized
INFO - 2018-06-27 21:45:50 --> Router Class Initialized
INFO - 2018-06-27 21:45:50 --> Output Class Initialized
INFO - 2018-06-27 21:45:50 --> Security Class Initialized
DEBUG - 2018-06-27 21:45:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-27 21:45:50 --> Input Class Initialized
INFO - 2018-06-27 21:45:50 --> Language Class Initialized
ERROR - 2018-06-27 21:45:50 --> 404 Page Not Found: /index
INFO - 2018-06-27 22:00:10 --> Config Class Initialized
INFO - 2018-06-27 22:00:10 --> Hooks Class Initialized
DEBUG - 2018-06-27 22:00:10 --> UTF-8 Support Enabled
INFO - 2018-06-27 22:00:10 --> Utf8 Class Initialized
INFO - 2018-06-27 22:00:10 --> URI Class Initialized
INFO - 2018-06-27 22:00:10 --> Router Class Initialized
INFO - 2018-06-27 22:00:10 --> Output Class Initialized
INFO - 2018-06-27 22:00:10 --> Security Class Initialized
DEBUG - 2018-06-27 22:00:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-27 22:00:10 --> Input Class Initialized
INFO - 2018-06-27 22:00:10 --> Language Class Initialized
INFO - 2018-06-27 22:00:10 --> Language Class Initialized
INFO - 2018-06-27 22:00:10 --> Config Class Initialized
INFO - 2018-06-27 22:00:10 --> Loader Class Initialized
DEBUG - 2018-06-27 22:00:10 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-27 22:00:10 --> Helper loaded: url_helper
INFO - 2018-06-27 22:00:10 --> Helper loaded: form_helper
INFO - 2018-06-27 22:00:10 --> Helper loaded: date_helper
INFO - 2018-06-27 22:00:10 --> Helper loaded: util_helper
INFO - 2018-06-27 22:00:10 --> Helper loaded: text_helper
INFO - 2018-06-27 22:00:10 --> Helper loaded: string_helper
INFO - 2018-06-27 22:00:10 --> Database Driver Class Initialized
DEBUG - 2018-06-27 22:00:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-27 22:00:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-27 22:00:10 --> Email Class Initialized
INFO - 2018-06-27 22:00:10 --> Controller Class Initialized
DEBUG - 2018-06-27 22:00:10 --> Login MX_Controller Initialized
INFO - 2018-06-27 22:00:10 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-27 22:00:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-27 22:00:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-27 22:00:10 --> Email starts for admin@colin.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-06-27 22:00:10 --> User session created for 1
INFO - 2018-06-27 22:00:10 --> Login status admin@colin.com - success
INFO - 2018-06-27 22:00:10 --> Final output sent to browser
DEBUG - 2018-06-27 22:00:10 --> Total execution time: 0.4149
INFO - 2018-06-27 22:00:10 --> Config Class Initialized
INFO - 2018-06-27 22:00:10 --> Hooks Class Initialized
DEBUG - 2018-06-27 22:00:10 --> UTF-8 Support Enabled
INFO - 2018-06-27 22:00:10 --> Utf8 Class Initialized
INFO - 2018-06-27 22:00:10 --> URI Class Initialized
INFO - 2018-06-27 22:00:10 --> Router Class Initialized
INFO - 2018-06-27 22:00:10 --> Output Class Initialized
INFO - 2018-06-27 22:00:10 --> Security Class Initialized
DEBUG - 2018-06-27 22:00:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-27 22:00:10 --> Input Class Initialized
INFO - 2018-06-27 22:00:10 --> Language Class Initialized
INFO - 2018-06-27 22:00:10 --> Language Class Initialized
INFO - 2018-06-27 22:00:10 --> Config Class Initialized
INFO - 2018-06-27 22:00:10 --> Loader Class Initialized
DEBUG - 2018-06-27 22:00:10 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-27 22:00:10 --> Helper loaded: url_helper
INFO - 2018-06-27 22:00:10 --> Helper loaded: form_helper
INFO - 2018-06-27 22:00:11 --> Helper loaded: date_helper
INFO - 2018-06-27 22:00:11 --> Helper loaded: util_helper
INFO - 2018-06-27 22:00:11 --> Helper loaded: text_helper
INFO - 2018-06-27 22:00:11 --> Helper loaded: string_helper
INFO - 2018-06-27 22:00:11 --> Database Driver Class Initialized
DEBUG - 2018-06-27 22:00:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-27 22:00:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-27 22:00:11 --> Email Class Initialized
INFO - 2018-06-27 22:00:11 --> Controller Class Initialized
DEBUG - 2018-06-27 22:00:11 --> videos MX_Controller Initialized
INFO - 2018-06-27 22:00:11 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-27 22:00:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-06-27 22:00:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-27 22:00:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-27 22:00:11 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-27 22:00:11 --> Login MX_Controller Initialized
DEBUG - 2018-06-27 22:00:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-27 22:00:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-27 22:00:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-27 22:00:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-27 22:00:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-27 22:00:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-27 22:00:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/videos/videos.php
INFO - 2018-06-27 22:00:11 --> Final output sent to browser
DEBUG - 2018-06-27 22:00:11 --> Total execution time: 0.7121
INFO - 2018-06-27 22:00:12 --> Config Class Initialized
INFO - 2018-06-27 22:00:12 --> Hooks Class Initialized
DEBUG - 2018-06-27 22:00:13 --> UTF-8 Support Enabled
INFO - 2018-06-27 22:00:13 --> Utf8 Class Initialized
INFO - 2018-06-27 22:00:13 --> URI Class Initialized
INFO - 2018-06-27 22:00:13 --> Router Class Initialized
INFO - 2018-06-27 22:00:13 --> Output Class Initialized
INFO - 2018-06-27 22:00:13 --> Security Class Initialized
DEBUG - 2018-06-27 22:00:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-27 22:00:13 --> Input Class Initialized
INFO - 2018-06-27 22:00:13 --> Language Class Initialized
INFO - 2018-06-27 22:00:13 --> Language Class Initialized
INFO - 2018-06-27 22:00:13 --> Config Class Initialized
INFO - 2018-06-27 22:00:13 --> Loader Class Initialized
DEBUG - 2018-06-27 22:00:13 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-27 22:00:13 --> Helper loaded: url_helper
INFO - 2018-06-27 22:00:13 --> Helper loaded: form_helper
INFO - 2018-06-27 22:00:13 --> Helper loaded: date_helper
INFO - 2018-06-27 22:00:13 --> Helper loaded: util_helper
INFO - 2018-06-27 22:00:13 --> Helper loaded: text_helper
INFO - 2018-06-27 22:00:13 --> Helper loaded: string_helper
INFO - 2018-06-27 22:00:13 --> Database Driver Class Initialized
DEBUG - 2018-06-27 22:00:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-27 22:00:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-27 22:00:13 --> Email Class Initialized
INFO - 2018-06-27 22:00:13 --> Controller Class Initialized
DEBUG - 2018-06-27 22:00:13 --> videos MX_Controller Initialized
INFO - 2018-06-27 22:00:13 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-27 22:00:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-06-27 22:00:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-27 22:00:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-27 22:00:13 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-27 22:00:13 --> Login MX_Controller Initialized
DEBUG - 2018-06-27 22:00:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-27 22:00:13 --> Final output sent to browser
DEBUG - 2018-06-27 22:00:13 --> Total execution time: 0.6941
INFO - 2018-06-27 22:00:29 --> Config Class Initialized
INFO - 2018-06-27 22:00:29 --> Hooks Class Initialized
DEBUG - 2018-06-27 22:00:29 --> UTF-8 Support Enabled
INFO - 2018-06-27 22:00:29 --> Utf8 Class Initialized
INFO - 2018-06-27 22:00:29 --> URI Class Initialized
INFO - 2018-06-27 22:00:29 --> Router Class Initialized
INFO - 2018-06-27 22:00:29 --> Output Class Initialized
INFO - 2018-06-27 22:00:29 --> Security Class Initialized
DEBUG - 2018-06-27 22:00:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-27 22:00:29 --> Input Class Initialized
INFO - 2018-06-27 22:00:29 --> Language Class Initialized
INFO - 2018-06-27 22:00:29 --> Language Class Initialized
INFO - 2018-06-27 22:00:29 --> Config Class Initialized
INFO - 2018-06-27 22:00:29 --> Loader Class Initialized
DEBUG - 2018-06-27 22:00:29 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-27 22:00:29 --> Helper loaded: url_helper
INFO - 2018-06-27 22:00:29 --> Helper loaded: form_helper
INFO - 2018-06-27 22:00:29 --> Helper loaded: date_helper
INFO - 2018-06-27 22:00:29 --> Helper loaded: util_helper
INFO - 2018-06-27 22:00:29 --> Helper loaded: text_helper
INFO - 2018-06-27 22:00:29 --> Helper loaded: string_helper
INFO - 2018-06-27 22:00:29 --> Database Driver Class Initialized
DEBUG - 2018-06-27 22:00:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-27 22:00:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-27 22:00:29 --> Email Class Initialized
INFO - 2018-06-27 22:00:29 --> Controller Class Initialized
DEBUG - 2018-06-27 22:00:29 --> Lessions MX_Controller Initialized
INFO - 2018-06-27 22:00:29 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-27 22:00:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Lessions_model.php
DEBUG - 2018-06-27 22:00:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-27 22:00:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-27 22:00:29 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-27 22:00:29 --> Login MX_Controller Initialized
DEBUG - 2018-06-27 22:00:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-27 22:00:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-27 22:00:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-27 22:00:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-27 22:00:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-27 22:00:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-27 22:00:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/lessions/lessions.php
INFO - 2018-06-27 22:00:29 --> Final output sent to browser
DEBUG - 2018-06-27 22:00:30 --> Total execution time: 0.4890
INFO - 2018-06-27 22:00:30 --> Config Class Initialized
INFO - 2018-06-27 22:00:30 --> Hooks Class Initialized
DEBUG - 2018-06-27 22:00:30 --> UTF-8 Support Enabled
INFO - 2018-06-27 22:00:30 --> Utf8 Class Initialized
INFO - 2018-06-27 22:00:30 --> URI Class Initialized
INFO - 2018-06-27 22:00:30 --> Router Class Initialized
INFO - 2018-06-27 22:00:30 --> Output Class Initialized
INFO - 2018-06-27 22:00:30 --> Security Class Initialized
DEBUG - 2018-06-27 22:00:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-27 22:00:30 --> Input Class Initialized
INFO - 2018-06-27 22:00:30 --> Language Class Initialized
INFO - 2018-06-27 22:00:30 --> Language Class Initialized
INFO - 2018-06-27 22:00:30 --> Config Class Initialized
INFO - 2018-06-27 22:00:30 --> Loader Class Initialized
DEBUG - 2018-06-27 22:00:30 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-27 22:00:30 --> Helper loaded: url_helper
INFO - 2018-06-27 22:00:30 --> Helper loaded: form_helper
INFO - 2018-06-27 22:00:30 --> Helper loaded: date_helper
INFO - 2018-06-27 22:00:30 --> Helper loaded: util_helper
INFO - 2018-06-27 22:00:30 --> Helper loaded: text_helper
INFO - 2018-06-27 22:00:30 --> Helper loaded: string_helper
INFO - 2018-06-27 22:00:30 --> Database Driver Class Initialized
DEBUG - 2018-06-27 22:00:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-27 22:00:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-27 22:00:30 --> Email Class Initialized
INFO - 2018-06-27 22:00:30 --> Controller Class Initialized
DEBUG - 2018-06-27 22:00:30 --> Lessions MX_Controller Initialized
INFO - 2018-06-27 22:00:30 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-27 22:00:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Lessions_model.php
DEBUG - 2018-06-27 22:00:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-27 22:00:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-27 22:00:30 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-27 22:00:30 --> Login MX_Controller Initialized
DEBUG - 2018-06-27 22:00:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-27 22:00:30 --> Final output sent to browser
DEBUG - 2018-06-27 22:00:30 --> Total execution time: 0.4587
INFO - 2018-06-27 22:00:40 --> Config Class Initialized
INFO - 2018-06-27 22:00:40 --> Hooks Class Initialized
DEBUG - 2018-06-27 22:00:40 --> UTF-8 Support Enabled
INFO - 2018-06-27 22:00:40 --> Utf8 Class Initialized
INFO - 2018-06-27 22:00:40 --> URI Class Initialized
INFO - 2018-06-27 22:00:40 --> Router Class Initialized
INFO - 2018-06-27 22:00:40 --> Output Class Initialized
INFO - 2018-06-27 22:00:40 --> Security Class Initialized
DEBUG - 2018-06-27 22:00:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-27 22:00:40 --> Input Class Initialized
INFO - 2018-06-27 22:00:40 --> Language Class Initialized
INFO - 2018-06-27 22:00:40 --> Language Class Initialized
INFO - 2018-06-27 22:00:40 --> Config Class Initialized
INFO - 2018-06-27 22:00:40 --> Loader Class Initialized
DEBUG - 2018-06-27 22:00:40 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-27 22:00:40 --> Helper loaded: url_helper
INFO - 2018-06-27 22:00:40 --> Helper loaded: form_helper
INFO - 2018-06-27 22:00:40 --> Helper loaded: date_helper
INFO - 2018-06-27 22:00:40 --> Helper loaded: util_helper
INFO - 2018-06-27 22:00:40 --> Helper loaded: text_helper
INFO - 2018-06-27 22:00:40 --> Helper loaded: string_helper
INFO - 2018-06-27 22:00:40 --> Database Driver Class Initialized
DEBUG - 2018-06-27 22:00:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-27 22:00:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-27 22:00:40 --> Email Class Initialized
INFO - 2018-06-27 22:00:40 --> Controller Class Initialized
DEBUG - 2018-06-27 22:00:41 --> Admin MX_Controller Initialized
INFO - 2018-06-27 22:00:41 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-27 22:00:41 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-27 22:00:41 --> Login MX_Controller Initialized
DEBUG - 2018-06-27 22:00:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-27 22:00:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-27 22:00:41 --> Final output sent to browser
DEBUG - 2018-06-27 22:00:41 --> Total execution time: 0.4687
INFO - 2018-06-27 22:00:41 --> Config Class Initialized
INFO - 2018-06-27 22:00:41 --> Hooks Class Initialized
DEBUG - 2018-06-27 22:00:41 --> UTF-8 Support Enabled
INFO - 2018-06-27 22:00:41 --> Utf8 Class Initialized
INFO - 2018-06-27 22:00:41 --> URI Class Initialized
INFO - 2018-06-27 22:00:41 --> Router Class Initialized
INFO - 2018-06-27 22:00:41 --> Output Class Initialized
INFO - 2018-06-27 22:00:41 --> Security Class Initialized
DEBUG - 2018-06-27 22:00:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-27 22:00:41 --> Input Class Initialized
INFO - 2018-06-27 22:00:41 --> Language Class Initialized
INFO - 2018-06-27 22:00:41 --> Language Class Initialized
INFO - 2018-06-27 22:00:41 --> Config Class Initialized
INFO - 2018-06-27 22:00:41 --> Loader Class Initialized
DEBUG - 2018-06-27 22:00:41 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-27 22:00:41 --> Helper loaded: url_helper
INFO - 2018-06-27 22:00:41 --> Helper loaded: form_helper
INFO - 2018-06-27 22:00:41 --> Helper loaded: date_helper
INFO - 2018-06-27 22:00:41 --> Helper loaded: util_helper
INFO - 2018-06-27 22:00:41 --> Helper loaded: text_helper
INFO - 2018-06-27 22:00:41 --> Helper loaded: string_helper
INFO - 2018-06-27 22:00:41 --> Database Driver Class Initialized
DEBUG - 2018-06-27 22:00:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-27 22:00:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-27 22:00:41 --> Email Class Initialized
INFO - 2018-06-27 22:00:41 --> Controller Class Initialized
DEBUG - 2018-06-27 22:00:41 --> Admin MX_Controller Initialized
INFO - 2018-06-27 22:00:41 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-27 22:00:41 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-27 22:00:41 --> Login MX_Controller Initialized
DEBUG - 2018-06-27 22:00:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-27 22:00:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-27 22:00:41 --> Final output sent to browser
DEBUG - 2018-06-27 22:00:41 --> Total execution time: 0.4117
INFO - 2018-06-27 22:00:42 --> Config Class Initialized
INFO - 2018-06-27 22:00:42 --> Hooks Class Initialized
DEBUG - 2018-06-27 22:00:42 --> UTF-8 Support Enabled
INFO - 2018-06-27 22:00:42 --> Utf8 Class Initialized
INFO - 2018-06-27 22:00:42 --> URI Class Initialized
INFO - 2018-06-27 22:00:42 --> Router Class Initialized
INFO - 2018-06-27 22:00:42 --> Output Class Initialized
INFO - 2018-06-27 22:00:42 --> Security Class Initialized
DEBUG - 2018-06-27 22:00:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-27 22:00:42 --> Input Class Initialized
INFO - 2018-06-27 22:00:42 --> Language Class Initialized
INFO - 2018-06-27 22:00:42 --> Language Class Initialized
INFO - 2018-06-27 22:00:42 --> Config Class Initialized
INFO - 2018-06-27 22:00:42 --> Loader Class Initialized
DEBUG - 2018-06-27 22:00:42 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-27 22:00:42 --> Helper loaded: url_helper
INFO - 2018-06-27 22:00:42 --> Helper loaded: form_helper
INFO - 2018-06-27 22:00:42 --> Helper loaded: date_helper
INFO - 2018-06-27 22:00:42 --> Helper loaded: util_helper
INFO - 2018-06-27 22:00:42 --> Helper loaded: text_helper
INFO - 2018-06-27 22:00:42 --> Helper loaded: string_helper
INFO - 2018-06-27 22:00:42 --> Database Driver Class Initialized
DEBUG - 2018-06-27 22:00:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-27 22:00:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-27 22:00:42 --> Email Class Initialized
INFO - 2018-06-27 22:00:42 --> Controller Class Initialized
DEBUG - 2018-06-27 22:00:42 --> Admin MX_Controller Initialized
INFO - 2018-06-27 22:00:42 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-27 22:00:42 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-27 22:00:42 --> Login MX_Controller Initialized
DEBUG - 2018-06-27 22:00:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-27 22:00:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-27 22:00:43 --> Final output sent to browser
DEBUG - 2018-06-27 22:00:43 --> Total execution time: 0.4083
INFO - 2018-06-27 22:01:01 --> Config Class Initialized
INFO - 2018-06-27 22:01:01 --> Hooks Class Initialized
DEBUG - 2018-06-27 22:01:01 --> UTF-8 Support Enabled
INFO - 2018-06-27 22:01:01 --> Utf8 Class Initialized
INFO - 2018-06-27 22:01:01 --> URI Class Initialized
INFO - 2018-06-27 22:01:01 --> Router Class Initialized
INFO - 2018-06-27 22:01:01 --> Output Class Initialized
INFO - 2018-06-27 22:01:01 --> Security Class Initialized
DEBUG - 2018-06-27 22:01:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-27 22:01:01 --> Input Class Initialized
INFO - 2018-06-27 22:01:01 --> Language Class Initialized
INFO - 2018-06-27 22:01:01 --> Language Class Initialized
INFO - 2018-06-27 22:01:01 --> Config Class Initialized
INFO - 2018-06-27 22:01:01 --> Loader Class Initialized
DEBUG - 2018-06-27 22:01:01 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-27 22:01:01 --> Helper loaded: url_helper
INFO - 2018-06-27 22:01:01 --> Helper loaded: form_helper
INFO - 2018-06-27 22:01:01 --> Helper loaded: date_helper
INFO - 2018-06-27 22:01:01 --> Helper loaded: util_helper
INFO - 2018-06-27 22:01:01 --> Helper loaded: text_helper
INFO - 2018-06-27 22:01:01 --> Helper loaded: string_helper
INFO - 2018-06-27 22:01:01 --> Database Driver Class Initialized
DEBUG - 2018-06-27 22:01:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-27 22:01:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-27 22:01:01 --> Email Class Initialized
INFO - 2018-06-27 22:01:01 --> Controller Class Initialized
DEBUG - 2018-06-27 22:01:01 --> Users MX_Controller Initialized
DEBUG - 2018-06-27 22:01:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-27 22:01:01 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-27 22:01:01 --> Login MX_Controller Initialized
INFO - 2018-06-27 22:01:01 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-27 22:01:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-27 22:01:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-27 22:01:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-27 22:01:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-27 22:01:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-27 22:01:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-27 22:01:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-06-27 22:01:02 --> Final output sent to browser
DEBUG - 2018-06-27 22:01:02 --> Total execution time: 0.4793
INFO - 2018-06-27 22:01:02 --> Config Class Initialized
INFO - 2018-06-27 22:01:02 --> Hooks Class Initialized
DEBUG - 2018-06-27 22:01:02 --> UTF-8 Support Enabled
INFO - 2018-06-27 22:01:02 --> Utf8 Class Initialized
INFO - 2018-06-27 22:01:02 --> URI Class Initialized
INFO - 2018-06-27 22:01:02 --> Router Class Initialized
INFO - 2018-06-27 22:01:02 --> Output Class Initialized
INFO - 2018-06-27 22:01:02 --> Security Class Initialized
DEBUG - 2018-06-27 22:01:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-27 22:01:02 --> Input Class Initialized
INFO - 2018-06-27 22:01:02 --> Language Class Initialized
INFO - 2018-06-27 22:01:02 --> Language Class Initialized
INFO - 2018-06-27 22:01:02 --> Config Class Initialized
INFO - 2018-06-27 22:01:02 --> Loader Class Initialized
DEBUG - 2018-06-27 22:01:02 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-27 22:01:02 --> Helper loaded: url_helper
INFO - 2018-06-27 22:01:02 --> Helper loaded: form_helper
INFO - 2018-06-27 22:01:02 --> Helper loaded: date_helper
INFO - 2018-06-27 22:01:02 --> Helper loaded: util_helper
INFO - 2018-06-27 22:01:02 --> Helper loaded: text_helper
INFO - 2018-06-27 22:01:02 --> Helper loaded: string_helper
INFO - 2018-06-27 22:01:02 --> Database Driver Class Initialized
DEBUG - 2018-06-27 22:01:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-27 22:01:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-27 22:01:02 --> Email Class Initialized
INFO - 2018-06-27 22:01:02 --> Controller Class Initialized
DEBUG - 2018-06-27 22:01:02 --> Users MX_Controller Initialized
DEBUG - 2018-06-27 22:01:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-27 22:01:02 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-27 22:01:02 --> Login MX_Controller Initialized
INFO - 2018-06-27 22:01:02 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-27 22:01:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-27 22:01:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-06-27 22:01:03 --> Final output sent to browser
DEBUG - 2018-06-27 22:01:03 --> Total execution time: 0.5652
INFO - 2018-06-27 22:22:09 --> Config Class Initialized
INFO - 2018-06-27 22:22:09 --> Hooks Class Initialized
DEBUG - 2018-06-27 22:22:09 --> UTF-8 Support Enabled
INFO - 2018-06-27 22:22:09 --> Utf8 Class Initialized
INFO - 2018-06-27 22:22:09 --> URI Class Initialized
INFO - 2018-06-27 22:22:09 --> Router Class Initialized
INFO - 2018-06-27 22:22:09 --> Output Class Initialized
INFO - 2018-06-27 22:22:09 --> Security Class Initialized
DEBUG - 2018-06-27 22:22:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-27 22:22:09 --> Input Class Initialized
INFO - 2018-06-27 22:22:09 --> Language Class Initialized
INFO - 2018-06-27 22:22:09 --> Language Class Initialized
INFO - 2018-06-27 22:22:09 --> Config Class Initialized
INFO - 2018-06-27 22:22:09 --> Loader Class Initialized
DEBUG - 2018-06-27 22:22:09 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-27 22:22:09 --> Helper loaded: url_helper
INFO - 2018-06-27 22:22:09 --> Helper loaded: form_helper
INFO - 2018-06-27 22:22:09 --> Helper loaded: date_helper
INFO - 2018-06-27 22:22:09 --> Helper loaded: util_helper
INFO - 2018-06-27 22:22:09 --> Helper loaded: text_helper
INFO - 2018-06-27 22:22:09 --> Helper loaded: string_helper
INFO - 2018-06-27 22:22:09 --> Database Driver Class Initialized
DEBUG - 2018-06-27 22:22:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-27 22:22:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-27 22:22:09 --> Email Class Initialized
INFO - 2018-06-27 22:22:10 --> Controller Class Initialized
DEBUG - 2018-06-27 22:22:10 --> Users MX_Controller Initialized
DEBUG - 2018-06-27 22:22:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-27 22:22:10 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-27 22:22:10 --> Login MX_Controller Initialized
INFO - 2018-06-27 22:22:10 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-27 22:22:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-27 22:22:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-27 22:22:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-27 22:22:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-27 22:22:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-27 22:22:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-27 22:22:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-06-27 22:22:10 --> Final output sent to browser
DEBUG - 2018-06-27 22:22:10 --> Total execution time: 0.5245
INFO - 2018-06-27 22:22:10 --> Config Class Initialized
INFO - 2018-06-27 22:22:10 --> Hooks Class Initialized
DEBUG - 2018-06-27 22:22:10 --> UTF-8 Support Enabled
INFO - 2018-06-27 22:22:10 --> Utf8 Class Initialized
INFO - 2018-06-27 22:22:10 --> URI Class Initialized
INFO - 2018-06-27 22:22:10 --> Router Class Initialized
INFO - 2018-06-27 22:22:10 --> Output Class Initialized
INFO - 2018-06-27 22:22:10 --> Security Class Initialized
DEBUG - 2018-06-27 22:22:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-27 22:22:10 --> Input Class Initialized
INFO - 2018-06-27 22:22:10 --> Language Class Initialized
INFO - 2018-06-27 22:22:10 --> Language Class Initialized
INFO - 2018-06-27 22:22:10 --> Config Class Initialized
INFO - 2018-06-27 22:22:10 --> Loader Class Initialized
DEBUG - 2018-06-27 22:22:10 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-27 22:22:10 --> Helper loaded: url_helper
INFO - 2018-06-27 22:22:10 --> Helper loaded: form_helper
INFO - 2018-06-27 22:22:10 --> Helper loaded: date_helper
INFO - 2018-06-27 22:22:10 --> Helper loaded: util_helper
INFO - 2018-06-27 22:22:10 --> Helper loaded: text_helper
INFO - 2018-06-27 22:22:10 --> Helper loaded: string_helper
INFO - 2018-06-27 22:22:10 --> Database Driver Class Initialized
DEBUG - 2018-06-27 22:22:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-27 22:22:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-27 22:22:10 --> Email Class Initialized
INFO - 2018-06-27 22:22:11 --> Controller Class Initialized
DEBUG - 2018-06-27 22:22:11 --> Users MX_Controller Initialized
DEBUG - 2018-06-27 22:22:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-27 22:22:11 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-27 22:22:11 --> Login MX_Controller Initialized
INFO - 2018-06-27 22:22:11 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-27 22:22:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-27 22:22:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-06-27 22:22:11 --> Final output sent to browser
DEBUG - 2018-06-27 22:22:11 --> Total execution time: 0.4620
INFO - 2018-06-27 22:22:28 --> Config Class Initialized
INFO - 2018-06-27 22:22:28 --> Hooks Class Initialized
DEBUG - 2018-06-27 22:22:28 --> UTF-8 Support Enabled
INFO - 2018-06-27 22:22:28 --> Utf8 Class Initialized
INFO - 2018-06-27 22:22:28 --> URI Class Initialized
INFO - 2018-06-27 22:22:28 --> Router Class Initialized
INFO - 2018-06-27 22:22:28 --> Output Class Initialized
INFO - 2018-06-27 22:22:28 --> Security Class Initialized
DEBUG - 2018-06-27 22:22:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-27 22:22:28 --> Input Class Initialized
INFO - 2018-06-27 22:22:28 --> Language Class Initialized
INFO - 2018-06-27 22:22:28 --> Language Class Initialized
INFO - 2018-06-27 22:22:28 --> Config Class Initialized
INFO - 2018-06-27 22:22:28 --> Loader Class Initialized
DEBUG - 2018-06-27 22:22:28 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-27 22:22:28 --> Helper loaded: url_helper
INFO - 2018-06-27 22:22:28 --> Helper loaded: form_helper
INFO - 2018-06-27 22:22:28 --> Helper loaded: date_helper
INFO - 2018-06-27 22:22:28 --> Helper loaded: util_helper
INFO - 2018-06-27 22:22:28 --> Helper loaded: text_helper
INFO - 2018-06-27 22:22:28 --> Helper loaded: string_helper
INFO - 2018-06-27 22:22:28 --> Database Driver Class Initialized
DEBUG - 2018-06-27 22:22:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-27 22:22:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-27 22:22:28 --> Email Class Initialized
INFO - 2018-06-27 22:22:28 --> Controller Class Initialized
DEBUG - 2018-06-27 22:22:28 --> Users MX_Controller Initialized
DEBUG - 2018-06-27 22:22:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-27 22:22:28 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-27 22:22:28 --> Login MX_Controller Initialized
INFO - 2018-06-27 22:22:28 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-27 22:22:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-27 22:22:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-27 22:22:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-27 22:22:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-27 22:22:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-27 22:22:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-27 22:22:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-06-27 22:22:29 --> Final output sent to browser
DEBUG - 2018-06-27 22:22:29 --> Total execution time: 0.4290
INFO - 2018-06-27 22:22:29 --> Config Class Initialized
INFO - 2018-06-27 22:22:29 --> Hooks Class Initialized
DEBUG - 2018-06-27 22:22:29 --> UTF-8 Support Enabled
INFO - 2018-06-27 22:22:29 --> Utf8 Class Initialized
INFO - 2018-06-27 22:22:29 --> URI Class Initialized
INFO - 2018-06-27 22:22:29 --> Router Class Initialized
INFO - 2018-06-27 22:22:29 --> Output Class Initialized
INFO - 2018-06-27 22:22:29 --> Security Class Initialized
DEBUG - 2018-06-27 22:22:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-27 22:22:29 --> Input Class Initialized
INFO - 2018-06-27 22:22:29 --> Language Class Initialized
INFO - 2018-06-27 22:22:29 --> Language Class Initialized
INFO - 2018-06-27 22:22:29 --> Config Class Initialized
INFO - 2018-06-27 22:22:29 --> Loader Class Initialized
DEBUG - 2018-06-27 22:22:29 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-27 22:22:29 --> Helper loaded: url_helper
INFO - 2018-06-27 22:22:29 --> Helper loaded: form_helper
INFO - 2018-06-27 22:22:29 --> Helper loaded: date_helper
INFO - 2018-06-27 22:22:29 --> Helper loaded: util_helper
INFO - 2018-06-27 22:22:29 --> Helper loaded: text_helper
INFO - 2018-06-27 22:22:29 --> Helper loaded: string_helper
INFO - 2018-06-27 22:22:29 --> Database Driver Class Initialized
DEBUG - 2018-06-27 22:22:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-27 22:22:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-27 22:22:29 --> Email Class Initialized
INFO - 2018-06-27 22:22:29 --> Controller Class Initialized
DEBUG - 2018-06-27 22:22:29 --> Users MX_Controller Initialized
DEBUG - 2018-06-27 22:22:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-27 22:22:29 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-27 22:22:29 --> Login MX_Controller Initialized
INFO - 2018-06-27 22:22:29 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-27 22:22:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-27 22:22:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-06-27 22:22:29 --> Final output sent to browser
DEBUG - 2018-06-27 22:22:29 --> Total execution time: 0.4630
INFO - 2018-06-27 22:43:47 --> Config Class Initialized
INFO - 2018-06-27 22:43:47 --> Hooks Class Initialized
DEBUG - 2018-06-27 22:43:47 --> UTF-8 Support Enabled
INFO - 2018-06-27 22:43:47 --> Utf8 Class Initialized
INFO - 2018-06-27 22:43:47 --> URI Class Initialized
INFO - 2018-06-27 22:43:47 --> Router Class Initialized
INFO - 2018-06-27 22:43:47 --> Output Class Initialized
INFO - 2018-06-27 22:43:47 --> Security Class Initialized
DEBUG - 2018-06-27 22:43:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-27 22:43:47 --> Input Class Initialized
INFO - 2018-06-27 22:43:47 --> Language Class Initialized
INFO - 2018-06-27 22:43:47 --> Language Class Initialized
INFO - 2018-06-27 22:43:47 --> Config Class Initialized
INFO - 2018-06-27 22:43:47 --> Loader Class Initialized
DEBUG - 2018-06-27 22:43:47 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-27 22:43:47 --> Helper loaded: url_helper
INFO - 2018-06-27 22:43:47 --> Helper loaded: form_helper
INFO - 2018-06-27 22:43:47 --> Helper loaded: date_helper
INFO - 2018-06-27 22:43:47 --> Helper loaded: util_helper
INFO - 2018-06-27 22:43:47 --> Helper loaded: text_helper
INFO - 2018-06-27 22:43:47 --> Helper loaded: string_helper
INFO - 2018-06-27 22:43:47 --> Database Driver Class Initialized
DEBUG - 2018-06-27 22:43:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-27 22:43:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-27 22:43:48 --> Email Class Initialized
INFO - 2018-06-27 22:43:48 --> Controller Class Initialized
DEBUG - 2018-06-27 22:43:48 --> Profile MX_Controller Initialized
DEBUG - 2018-06-27 22:43:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-27 22:43:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-27 22:43:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-27 22:43:48 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-27 22:43:48 --> Login MX_Controller Initialized
INFO - 2018-06-27 22:43:48 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-27 22:43:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-27 22:43:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-27 22:43:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-27 22:43:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-27 22:43:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-06-27 22:43:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-27 22:43:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-27 22:43:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/profile.php
INFO - 2018-06-27 22:43:48 --> Final output sent to browser
DEBUG - 2018-06-27 22:43:48 --> Total execution time: 0.6130
INFO - 2018-06-27 22:43:49 --> Config Class Initialized
INFO - 2018-06-27 22:43:49 --> Hooks Class Initialized
DEBUG - 2018-06-27 22:43:49 --> UTF-8 Support Enabled
INFO - 2018-06-27 22:43:49 --> Utf8 Class Initialized
INFO - 2018-06-27 22:43:49 --> URI Class Initialized
INFO - 2018-06-27 22:43:49 --> Router Class Initialized
INFO - 2018-06-27 22:43:49 --> Output Class Initialized
INFO - 2018-06-27 22:43:49 --> Security Class Initialized
DEBUG - 2018-06-27 22:43:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-27 22:43:49 --> Input Class Initialized
INFO - 2018-06-27 22:43:49 --> Language Class Initialized
ERROR - 2018-06-27 22:43:49 --> 404 Page Not Found: /index
INFO - 2018-06-27 22:43:49 --> Config Class Initialized
INFO - 2018-06-27 22:43:49 --> Hooks Class Initialized
DEBUG - 2018-06-27 22:43:49 --> UTF-8 Support Enabled
INFO - 2018-06-27 22:43:49 --> Utf8 Class Initialized
INFO - 2018-06-27 22:43:49 --> URI Class Initialized
INFO - 2018-06-27 22:43:49 --> Router Class Initialized
INFO - 2018-06-27 22:43:49 --> Output Class Initialized
INFO - 2018-06-27 22:43:49 --> Security Class Initialized
DEBUG - 2018-06-27 22:43:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-27 22:43:49 --> Input Class Initialized
INFO - 2018-06-27 22:43:49 --> Language Class Initialized
ERROR - 2018-06-27 22:43:49 --> 404 Page Not Found: /index
INFO - 2018-06-27 22:43:49 --> Config Class Initialized
INFO - 2018-06-27 22:43:50 --> Hooks Class Initialized
DEBUG - 2018-06-27 22:43:50 --> UTF-8 Support Enabled
INFO - 2018-06-27 22:43:50 --> Utf8 Class Initialized
INFO - 2018-06-27 22:43:50 --> URI Class Initialized
INFO - 2018-06-27 22:43:50 --> Router Class Initialized
INFO - 2018-06-27 22:43:50 --> Output Class Initialized
INFO - 2018-06-27 22:43:50 --> Security Class Initialized
DEBUG - 2018-06-27 22:43:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-27 22:43:50 --> Input Class Initialized
INFO - 2018-06-27 22:43:50 --> Language Class Initialized
ERROR - 2018-06-27 22:43:50 --> 404 Page Not Found: /index
INFO - 2018-06-27 22:43:53 --> Config Class Initialized
INFO - 2018-06-27 22:43:53 --> Hooks Class Initialized
DEBUG - 2018-06-27 22:43:53 --> UTF-8 Support Enabled
INFO - 2018-06-27 22:43:53 --> Utf8 Class Initialized
INFO - 2018-06-27 22:43:53 --> URI Class Initialized
INFO - 2018-06-27 22:43:53 --> Router Class Initialized
INFO - 2018-06-27 22:43:53 --> Output Class Initialized
INFO - 2018-06-27 22:43:53 --> Security Class Initialized
DEBUG - 2018-06-27 22:43:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-27 22:43:53 --> Input Class Initialized
INFO - 2018-06-27 22:43:53 --> Language Class Initialized
INFO - 2018-06-27 22:43:53 --> Language Class Initialized
INFO - 2018-06-27 22:43:53 --> Config Class Initialized
INFO - 2018-06-27 22:43:53 --> Loader Class Initialized
DEBUG - 2018-06-27 22:43:53 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-27 22:43:53 --> Helper loaded: url_helper
INFO - 2018-06-27 22:43:53 --> Helper loaded: form_helper
INFO - 2018-06-27 22:43:53 --> Helper loaded: date_helper
INFO - 2018-06-27 22:43:53 --> Helper loaded: util_helper
INFO - 2018-06-27 22:43:53 --> Helper loaded: text_helper
INFO - 2018-06-27 22:43:53 --> Helper loaded: string_helper
INFO - 2018-06-27 22:43:53 --> Database Driver Class Initialized
DEBUG - 2018-06-27 22:43:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-27 22:43:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-27 22:43:54 --> Email Class Initialized
INFO - 2018-06-27 22:43:54 --> Controller Class Initialized
DEBUG - 2018-06-27 22:43:54 --> Profile MX_Controller Initialized
DEBUG - 2018-06-27 22:43:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-27 22:43:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-27 22:43:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-27 22:43:54 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-27 22:43:54 --> Login MX_Controller Initialized
INFO - 2018-06-27 22:43:54 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-27 22:43:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-27 22:43:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-27 22:43:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-27 22:43:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-27 22:43:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-06-27 22:43:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-27 22:43:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-27 22:43:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/reset_password.php
INFO - 2018-06-27 22:43:54 --> Final output sent to browser
DEBUG - 2018-06-27 22:43:54 --> Total execution time: 0.4939
INFO - 2018-06-27 22:43:54 --> Config Class Initialized
INFO - 2018-06-27 22:43:54 --> Hooks Class Initialized
DEBUG - 2018-06-27 22:43:54 --> UTF-8 Support Enabled
INFO - 2018-06-27 22:43:54 --> Utf8 Class Initialized
INFO - 2018-06-27 22:43:54 --> URI Class Initialized
INFO - 2018-06-27 22:43:54 --> Router Class Initialized
INFO - 2018-06-27 22:43:54 --> Output Class Initialized
INFO - 2018-06-27 22:43:54 --> Security Class Initialized
DEBUG - 2018-06-27 22:43:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-27 22:43:54 --> Input Class Initialized
INFO - 2018-06-27 22:43:54 --> Language Class Initialized
ERROR - 2018-06-27 22:43:54 --> 404 Page Not Found: /index
INFO - 2018-06-27 22:43:54 --> Config Class Initialized
INFO - 2018-06-27 22:43:54 --> Hooks Class Initialized
DEBUG - 2018-06-27 22:43:54 --> UTF-8 Support Enabled
INFO - 2018-06-27 22:43:54 --> Utf8 Class Initialized
INFO - 2018-06-27 22:43:54 --> URI Class Initialized
INFO - 2018-06-27 22:43:54 --> Router Class Initialized
INFO - 2018-06-27 22:43:54 --> Output Class Initialized
INFO - 2018-06-27 22:43:54 --> Security Class Initialized
DEBUG - 2018-06-27 22:43:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-27 22:43:54 --> Input Class Initialized
INFO - 2018-06-27 22:43:54 --> Language Class Initialized
ERROR - 2018-06-27 22:43:54 --> 404 Page Not Found: /index
INFO - 2018-06-27 22:43:54 --> Config Class Initialized
INFO - 2018-06-27 22:43:54 --> Hooks Class Initialized
DEBUG - 2018-06-27 22:43:55 --> UTF-8 Support Enabled
INFO - 2018-06-27 22:43:55 --> Utf8 Class Initialized
INFO - 2018-06-27 22:43:55 --> URI Class Initialized
INFO - 2018-06-27 22:43:55 --> Router Class Initialized
INFO - 2018-06-27 22:43:55 --> Output Class Initialized
INFO - 2018-06-27 22:43:55 --> Security Class Initialized
DEBUG - 2018-06-27 22:43:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-27 22:43:55 --> Input Class Initialized
INFO - 2018-06-27 22:43:55 --> Language Class Initialized
ERROR - 2018-06-27 22:43:55 --> 404 Page Not Found: /index
INFO - 2018-06-27 22:46:43 --> Config Class Initialized
INFO - 2018-06-27 22:46:43 --> Hooks Class Initialized
DEBUG - 2018-06-27 22:46:44 --> UTF-8 Support Enabled
INFO - 2018-06-27 22:46:44 --> Utf8 Class Initialized
INFO - 2018-06-27 22:46:44 --> URI Class Initialized
INFO - 2018-06-27 22:46:44 --> Router Class Initialized
INFO - 2018-06-27 22:46:44 --> Output Class Initialized
INFO - 2018-06-27 22:46:44 --> Security Class Initialized
DEBUG - 2018-06-27 22:46:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-27 22:46:44 --> Input Class Initialized
INFO - 2018-06-27 22:46:44 --> Language Class Initialized
INFO - 2018-06-27 22:46:44 --> Language Class Initialized
INFO - 2018-06-27 22:46:44 --> Config Class Initialized
INFO - 2018-06-27 22:46:44 --> Loader Class Initialized
DEBUG - 2018-06-27 22:46:44 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-27 22:46:44 --> Helper loaded: url_helper
INFO - 2018-06-27 22:46:44 --> Helper loaded: form_helper
INFO - 2018-06-27 22:46:44 --> Helper loaded: date_helper
INFO - 2018-06-27 22:46:44 --> Helper loaded: util_helper
INFO - 2018-06-27 22:46:44 --> Helper loaded: text_helper
INFO - 2018-06-27 22:46:44 --> Helper loaded: string_helper
INFO - 2018-06-27 22:46:44 --> Database Driver Class Initialized
DEBUG - 2018-06-27 22:46:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-27 22:46:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-27 22:46:44 --> Email Class Initialized
INFO - 2018-06-27 22:46:44 --> Controller Class Initialized
DEBUG - 2018-06-27 22:46:44 --> Profile MX_Controller Initialized
DEBUG - 2018-06-27 22:46:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-27 22:46:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-27 22:46:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-27 22:46:44 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-27 22:46:44 --> Login MX_Controller Initialized
INFO - 2018-06-27 22:46:44 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-27 22:46:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-27 22:46:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-27 22:46:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-27 22:46:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-27 22:46:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-06-27 22:46:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-27 22:46:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-27 22:46:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/profile.php
INFO - 2018-06-27 22:46:45 --> Final output sent to browser
DEBUG - 2018-06-27 22:46:45 --> Total execution time: 1.3302
INFO - 2018-06-27 22:46:46 --> Config Class Initialized
INFO - 2018-06-27 22:46:46 --> Hooks Class Initialized
DEBUG - 2018-06-27 22:46:46 --> UTF-8 Support Enabled
INFO - 2018-06-27 22:46:46 --> Utf8 Class Initialized
INFO - 2018-06-27 22:46:46 --> URI Class Initialized
INFO - 2018-06-27 22:46:46 --> Router Class Initialized
INFO - 2018-06-27 22:46:46 --> Output Class Initialized
INFO - 2018-06-27 22:46:46 --> Security Class Initialized
DEBUG - 2018-06-27 22:46:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-27 22:46:46 --> Input Class Initialized
INFO - 2018-06-27 22:46:46 --> Language Class Initialized
ERROR - 2018-06-27 22:46:46 --> 404 Page Not Found: /index
INFO - 2018-06-27 22:46:46 --> Config Class Initialized
INFO - 2018-06-27 22:46:46 --> Hooks Class Initialized
DEBUG - 2018-06-27 22:46:46 --> UTF-8 Support Enabled
INFO - 2018-06-27 22:46:46 --> Utf8 Class Initialized
INFO - 2018-06-27 22:46:46 --> URI Class Initialized
INFO - 2018-06-27 22:46:46 --> Router Class Initialized
INFO - 2018-06-27 22:46:46 --> Output Class Initialized
INFO - 2018-06-27 22:46:46 --> Security Class Initialized
DEBUG - 2018-06-27 22:46:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-27 22:46:46 --> Input Class Initialized
INFO - 2018-06-27 22:46:46 --> Language Class Initialized
ERROR - 2018-06-27 22:46:46 --> 404 Page Not Found: /index
INFO - 2018-06-27 22:46:46 --> Config Class Initialized
INFO - 2018-06-27 22:46:46 --> Hooks Class Initialized
DEBUG - 2018-06-27 22:46:46 --> UTF-8 Support Enabled
INFO - 2018-06-27 22:46:46 --> Utf8 Class Initialized
INFO - 2018-06-27 22:46:46 --> URI Class Initialized
INFO - 2018-06-27 22:46:46 --> Router Class Initialized
INFO - 2018-06-27 22:46:46 --> Output Class Initialized
INFO - 2018-06-27 22:46:46 --> Security Class Initialized
DEBUG - 2018-06-27 22:46:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-27 22:46:46 --> Input Class Initialized
INFO - 2018-06-27 22:46:46 --> Language Class Initialized
ERROR - 2018-06-27 22:46:46 --> 404 Page Not Found: /index
