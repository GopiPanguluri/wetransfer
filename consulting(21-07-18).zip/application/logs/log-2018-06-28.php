<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-06-28 21:14:41 --> Config Class Initialized
INFO - 2018-06-28 21:14:41 --> Hooks Class Initialized
DEBUG - 2018-06-28 21:14:42 --> UTF-8 Support Enabled
INFO - 2018-06-28 21:14:42 --> Utf8 Class Initialized
INFO - 2018-06-28 21:14:42 --> URI Class Initialized
INFO - 2018-06-28 21:14:42 --> Router Class Initialized
INFO - 2018-06-28 21:14:42 --> Output Class Initialized
INFO - 2018-06-28 21:14:42 --> Security Class Initialized
DEBUG - 2018-06-28 21:14:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-28 21:14:42 --> Input Class Initialized
INFO - 2018-06-28 21:14:42 --> Language Class Initialized
INFO - 2018-06-28 21:14:42 --> Language Class Initialized
INFO - 2018-06-28 21:14:42 --> Config Class Initialized
INFO - 2018-06-28 21:14:42 --> Loader Class Initialized
DEBUG - 2018-06-28 21:14:42 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-28 21:14:42 --> Helper loaded: url_helper
INFO - 2018-06-28 21:14:42 --> Helper loaded: form_helper
INFO - 2018-06-28 21:14:42 --> Helper loaded: date_helper
INFO - 2018-06-28 21:14:42 --> Helper loaded: util_helper
INFO - 2018-06-28 21:14:42 --> Helper loaded: text_helper
INFO - 2018-06-28 21:14:42 --> Helper loaded: string_helper
INFO - 2018-06-28 21:14:42 --> Config Class Initialized
INFO - 2018-06-28 21:14:42 --> Hooks Class Initialized
DEBUG - 2018-06-28 21:14:42 --> UTF-8 Support Enabled
INFO - 2018-06-28 21:14:42 --> Utf8 Class Initialized
INFO - 2018-06-28 21:14:42 --> URI Class Initialized
INFO - 2018-06-28 21:14:42 --> Router Class Initialized
INFO - 2018-06-28 21:14:42 --> Database Driver Class Initialized
INFO - 2018-06-28 21:14:42 --> Output Class Initialized
INFO - 2018-06-28 21:14:42 --> Security Class Initialized
DEBUG - 2018-06-28 21:14:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-28 21:14:43 --> Input Class Initialized
INFO - 2018-06-28 21:14:43 --> Language Class Initialized
DEBUG - 2018-06-28 21:14:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-28 21:14:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-28 21:14:43 --> Email Class Initialized
INFO - 2018-06-28 21:14:43 --> Controller Class Initialized
DEBUG - 2018-06-28 21:14:43 --> Home MX_Controller Initialized
INFO - 2018-06-28 21:14:43 --> Language Class Initialized
DEBUG - 2018-06-28 21:14:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-06-28 21:14:43 --> Config Class Initialized
INFO - 2018-06-28 21:14:43 --> Loader Class Initialized
DEBUG - 2018-06-28 21:14:43 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-28 21:14:43 --> Helper loaded: url_helper
INFO - 2018-06-28 21:14:43 --> Helper loaded: form_helper
INFO - 2018-06-28 21:14:43 --> Helper loaded: date_helper
INFO - 2018-06-28 21:14:43 --> Helper loaded: util_helper
INFO - 2018-06-28 21:14:43 --> Helper loaded: text_helper
DEBUG - 2018-06-28 21:14:43 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
INFO - 2018-06-28 21:14:43 --> Helper loaded: string_helper
DEBUG - 2018-06-28 21:14:43 --> Login MX_Controller Initialized
INFO - 2018-06-28 21:14:43 --> Database Driver Class Initialized
INFO - 2018-06-28 21:14:43 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-28 21:14:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-06-28 21:14:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-06-28 21:14:43 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-06-28 21:14:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-28 21:14:43 --> Email Class Initialized
INFO - 2018-06-28 21:14:43 --> Controller Class Initialized
DEBUG - 2018-06-28 21:14:43 --> Profile MX_Controller Initialized
DEBUG - 2018-06-28 21:14:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-28 21:14:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
DEBUG - 2018-06-28 21:14:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-28 21:14:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-06-28 21:14:43 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-28 21:14:43 --> Login MX_Controller Initialized
INFO - 2018-06-28 21:14:43 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-28 21:14:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-28 21:14:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-06-28 21:14:44 --> Config Class Initialized
INFO - 2018-06-28 21:14:44 --> Hooks Class Initialized
DEBUG - 2018-06-28 21:14:44 --> UTF-8 Support Enabled
INFO - 2018-06-28 21:14:44 --> Utf8 Class Initialized
INFO - 2018-06-28 21:14:44 --> URI Class Initialized
INFO - 2018-06-28 21:14:44 --> Router Class Initialized
INFO - 2018-06-28 21:14:44 --> Output Class Initialized
INFO - 2018-06-28 21:14:44 --> Security Class Initialized
DEBUG - 2018-06-28 21:14:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-28 21:14:44 --> Input Class Initialized
INFO - 2018-06-28 21:14:44 --> Language Class Initialized
INFO - 2018-06-28 21:14:44 --> Language Class Initialized
INFO - 2018-06-28 21:14:44 --> Config Class Initialized
INFO - 2018-06-28 21:14:44 --> Loader Class Initialized
DEBUG - 2018-06-28 21:14:44 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-28 21:14:44 --> Helper loaded: url_helper
INFO - 2018-06-28 21:14:44 --> Helper loaded: form_helper
INFO - 2018-06-28 21:14:44 --> Helper loaded: date_helper
INFO - 2018-06-28 21:14:44 --> Helper loaded: util_helper
INFO - 2018-06-28 21:14:44 --> Helper loaded: text_helper
INFO - 2018-06-28 21:14:44 --> Helper loaded: string_helper
INFO - 2018-06-28 21:14:44 --> Database Driver Class Initialized
DEBUG - 2018-06-28 21:14:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-28 21:14:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-28 21:14:44 --> Email Class Initialized
INFO - 2018-06-28 21:14:44 --> Controller Class Initialized
DEBUG - 2018-06-28 21:14:44 --> Home MX_Controller Initialized
DEBUG - 2018-06-28 21:14:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-28 21:14:44 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-28 21:14:44 --> Login MX_Controller Initialized
INFO - 2018-06-28 21:14:44 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-28 21:14:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-28 21:14:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-28 21:14:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-06-28 21:14:44 --> Config Class Initialized
INFO - 2018-06-28 21:14:44 --> Hooks Class Initialized
DEBUG - 2018-06-28 21:14:44 --> UTF-8 Support Enabled
INFO - 2018-06-28 21:14:44 --> Utf8 Class Initialized
INFO - 2018-06-28 21:14:44 --> URI Class Initialized
DEBUG - 2018-06-28 21:14:44 --> No URI present. Default controller set.
INFO - 2018-06-28 21:14:44 --> Router Class Initialized
INFO - 2018-06-28 21:14:44 --> Output Class Initialized
INFO - 2018-06-28 21:14:44 --> Security Class Initialized
DEBUG - 2018-06-28 21:14:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-28 21:14:44 --> Input Class Initialized
INFO - 2018-06-28 21:14:44 --> Language Class Initialized
INFO - 2018-06-28 21:14:44 --> Language Class Initialized
INFO - 2018-06-28 21:14:44 --> Config Class Initialized
INFO - 2018-06-28 21:14:44 --> Loader Class Initialized
DEBUG - 2018-06-28 21:14:44 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-28 21:14:44 --> Helper loaded: url_helper
INFO - 2018-06-28 21:14:44 --> Helper loaded: form_helper
INFO - 2018-06-28 21:14:44 --> Helper loaded: date_helper
INFO - 2018-06-28 21:14:44 --> Helper loaded: util_helper
INFO - 2018-06-28 21:14:44 --> Helper loaded: text_helper
INFO - 2018-06-28 21:14:45 --> Helper loaded: string_helper
INFO - 2018-06-28 21:14:45 --> Database Driver Class Initialized
DEBUG - 2018-06-28 21:14:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-28 21:14:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-28 21:14:45 --> Email Class Initialized
INFO - 2018-06-28 21:14:45 --> Controller Class Initialized
DEBUG - 2018-06-28 21:14:45 --> Home MX_Controller Initialized
DEBUG - 2018-06-28 21:14:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-28 21:14:45 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-28 21:14:45 --> Login MX_Controller Initialized
INFO - 2018-06-28 21:14:45 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-28 21:14:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-28 21:14:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-28 21:14:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-06-28 21:14:45 --> Config Class Initialized
INFO - 2018-06-28 21:14:45 --> Hooks Class Initialized
DEBUG - 2018-06-28 21:14:45 --> UTF-8 Support Enabled
INFO - 2018-06-28 21:14:45 --> Utf8 Class Initialized
INFO - 2018-06-28 21:14:45 --> URI Class Initialized
INFO - 2018-06-28 21:14:45 --> Router Class Initialized
INFO - 2018-06-28 21:14:45 --> Output Class Initialized
INFO - 2018-06-28 21:14:45 --> Security Class Initialized
DEBUG - 2018-06-28 21:14:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-28 21:14:45 --> Input Class Initialized
INFO - 2018-06-28 21:14:45 --> Language Class Initialized
INFO - 2018-06-28 21:14:45 --> Language Class Initialized
INFO - 2018-06-28 21:14:45 --> Config Class Initialized
INFO - 2018-06-28 21:14:45 --> Loader Class Initialized
DEBUG - 2018-06-28 21:14:45 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-28 21:14:45 --> Helper loaded: url_helper
INFO - 2018-06-28 21:14:45 --> Helper loaded: form_helper
INFO - 2018-06-28 21:14:45 --> Helper loaded: date_helper
INFO - 2018-06-28 21:14:45 --> Helper loaded: util_helper
INFO - 2018-06-28 21:14:45 --> Helper loaded: text_helper
INFO - 2018-06-28 21:14:45 --> Helper loaded: string_helper
INFO - 2018-06-28 21:14:45 --> Database Driver Class Initialized
DEBUG - 2018-06-28 21:14:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-28 21:14:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-28 21:14:45 --> Email Class Initialized
INFO - 2018-06-28 21:14:45 --> Controller Class Initialized
DEBUG - 2018-06-28 21:14:45 --> Users MX_Controller Initialized
DEBUG - 2018-06-28 21:14:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-28 21:14:45 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-28 21:14:45 --> Login MX_Controller Initialized
INFO - 2018-06-28 21:14:45 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-28 21:14:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-28 21:14:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
INFO - 2018-06-28 21:14:46 --> Config Class Initialized
INFO - 2018-06-28 21:14:46 --> Hooks Class Initialized
DEBUG - 2018-06-28 21:14:46 --> UTF-8 Support Enabled
INFO - 2018-06-28 21:14:46 --> Utf8 Class Initialized
INFO - 2018-06-28 21:14:46 --> URI Class Initialized
INFO - 2018-06-28 21:14:46 --> Router Class Initialized
INFO - 2018-06-28 21:14:46 --> Output Class Initialized
INFO - 2018-06-28 21:14:46 --> Security Class Initialized
DEBUG - 2018-06-28 21:14:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-28 21:14:46 --> Input Class Initialized
INFO - 2018-06-28 21:14:46 --> Language Class Initialized
ERROR - 2018-06-28 21:14:46 --> 404 Page Not Found: /index
INFO - 2018-06-28 21:14:46 --> Config Class Initialized
INFO - 2018-06-28 21:14:46 --> Hooks Class Initialized
DEBUG - 2018-06-28 21:14:46 --> UTF-8 Support Enabled
INFO - 2018-06-28 21:14:46 --> Utf8 Class Initialized
INFO - 2018-06-28 21:14:46 --> URI Class Initialized
INFO - 2018-06-28 21:14:46 --> Router Class Initialized
INFO - 2018-06-28 21:14:46 --> Output Class Initialized
INFO - 2018-06-28 21:14:46 --> Security Class Initialized
DEBUG - 2018-06-28 21:14:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-28 21:14:46 --> Input Class Initialized
INFO - 2018-06-28 21:14:46 --> Language Class Initialized
ERROR - 2018-06-28 21:14:46 --> 404 Page Not Found: /index
INFO - 2018-06-28 22:43:28 --> Config Class Initialized
INFO - 2018-06-28 22:43:28 --> Hooks Class Initialized
DEBUG - 2018-06-28 22:43:28 --> UTF-8 Support Enabled
INFO - 2018-06-28 22:43:28 --> Utf8 Class Initialized
INFO - 2018-06-28 22:43:28 --> URI Class Initialized
INFO - 2018-06-28 22:43:28 --> Router Class Initialized
INFO - 2018-06-28 22:43:28 --> Output Class Initialized
INFO - 2018-06-28 22:43:28 --> Security Class Initialized
DEBUG - 2018-06-28 22:43:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-28 22:43:28 --> Input Class Initialized
INFO - 2018-06-28 22:43:28 --> Language Class Initialized
INFO - 2018-06-28 22:43:28 --> Language Class Initialized
INFO - 2018-06-28 22:43:28 --> Config Class Initialized
INFO - 2018-06-28 22:43:28 --> Loader Class Initialized
DEBUG - 2018-06-28 22:43:28 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-28 22:43:28 --> Helper loaded: url_helper
INFO - 2018-06-28 22:43:29 --> Helper loaded: form_helper
INFO - 2018-06-28 22:43:29 --> Helper loaded: date_helper
INFO - 2018-06-28 22:43:29 --> Helper loaded: util_helper
INFO - 2018-06-28 22:43:29 --> Helper loaded: text_helper
INFO - 2018-06-28 22:43:29 --> Helper loaded: string_helper
INFO - 2018-06-28 22:43:29 --> Database Driver Class Initialized
DEBUG - 2018-06-28 22:43:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-28 22:43:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-28 22:43:29 --> Email Class Initialized
INFO - 2018-06-28 22:43:29 --> Controller Class Initialized
DEBUG - 2018-06-28 22:43:29 --> Home MX_Controller Initialized
DEBUG - 2018-06-28 22:43:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-28 22:43:29 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-28 22:43:29 --> Login MX_Controller Initialized
INFO - 2018-06-28 22:43:29 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-28 22:43:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-28 22:43:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-28 22:43:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-06-28 22:43:29 --> Config Class Initialized
INFO - 2018-06-28 22:43:29 --> Hooks Class Initialized
DEBUG - 2018-06-28 22:43:29 --> UTF-8 Support Enabled
INFO - 2018-06-28 22:43:29 --> Utf8 Class Initialized
INFO - 2018-06-28 22:43:29 --> URI Class Initialized
INFO - 2018-06-28 22:43:29 --> Router Class Initialized
INFO - 2018-06-28 22:43:29 --> Output Class Initialized
INFO - 2018-06-28 22:43:29 --> Security Class Initialized
DEBUG - 2018-06-28 22:43:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-28 22:43:29 --> Input Class Initialized
INFO - 2018-06-28 22:43:30 --> Language Class Initialized
INFO - 2018-06-28 22:43:30 --> Language Class Initialized
INFO - 2018-06-28 22:43:30 --> Config Class Initialized
INFO - 2018-06-28 22:43:30 --> Loader Class Initialized
DEBUG - 2018-06-28 22:43:30 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-28 22:43:30 --> Helper loaded: url_helper
INFO - 2018-06-28 22:43:30 --> Helper loaded: form_helper
INFO - 2018-06-28 22:43:30 --> Helper loaded: date_helper
INFO - 2018-06-28 22:43:30 --> Helper loaded: util_helper
INFO - 2018-06-28 22:43:30 --> Helper loaded: text_helper
INFO - 2018-06-28 22:43:30 --> Helper loaded: string_helper
INFO - 2018-06-28 22:43:30 --> Database Driver Class Initialized
DEBUG - 2018-06-28 22:43:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-28 22:43:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-28 22:43:30 --> Email Class Initialized
INFO - 2018-06-28 22:43:30 --> Controller Class Initialized
DEBUG - 2018-06-28 22:43:30 --> Users MX_Controller Initialized
DEBUG - 2018-06-28 22:43:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-28 22:43:30 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-28 22:43:30 --> Login MX_Controller Initialized
INFO - 2018-06-28 22:43:30 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-28 22:43:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-28 22:43:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
INFO - 2018-06-28 22:43:30 --> Config Class Initialized
INFO - 2018-06-28 22:43:30 --> Hooks Class Initialized
DEBUG - 2018-06-28 22:43:30 --> UTF-8 Support Enabled
INFO - 2018-06-28 22:43:30 --> Utf8 Class Initialized
INFO - 2018-06-28 22:43:30 --> URI Class Initialized
INFO - 2018-06-28 22:43:30 --> Router Class Initialized
INFO - 2018-06-28 22:43:30 --> Output Class Initialized
INFO - 2018-06-28 22:43:30 --> Security Class Initialized
DEBUG - 2018-06-28 22:43:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-28 22:43:30 --> Input Class Initialized
INFO - 2018-06-28 22:43:30 --> Language Class Initialized
ERROR - 2018-06-28 22:43:30 --> 404 Page Not Found: /index
