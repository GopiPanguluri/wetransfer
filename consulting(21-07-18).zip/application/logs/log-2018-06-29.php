<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-06-29 05:46:58 --> Config Class Initialized
INFO - 2018-06-29 05:46:58 --> Hooks Class Initialized
DEBUG - 2018-06-29 05:46:58 --> UTF-8 Support Enabled
INFO - 2018-06-29 05:46:58 --> Utf8 Class Initialized
INFO - 2018-06-29 05:46:58 --> URI Class Initialized
INFO - 2018-06-29 05:46:58 --> Router Class Initialized
INFO - 2018-06-29 05:46:58 --> Output Class Initialized
INFO - 2018-06-29 05:46:58 --> Security Class Initialized
DEBUG - 2018-06-29 05:46:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 05:46:58 --> Input Class Initialized
INFO - 2018-06-29 05:46:58 --> Language Class Initialized
INFO - 2018-06-29 05:46:58 --> Language Class Initialized
INFO - 2018-06-29 05:46:58 --> Config Class Initialized
INFO - 2018-06-29 05:46:58 --> Loader Class Initialized
DEBUG - 2018-06-29 05:46:58 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-29 05:46:58 --> Helper loaded: url_helper
INFO - 2018-06-29 05:46:58 --> Helper loaded: form_helper
INFO - 2018-06-29 05:46:58 --> Helper loaded: date_helper
INFO - 2018-06-29 05:46:58 --> Helper loaded: util_helper
INFO - 2018-06-29 05:46:58 --> Helper loaded: text_helper
INFO - 2018-06-29 05:46:58 --> Helper loaded: string_helper
INFO - 2018-06-29 05:46:58 --> Database Driver Class Initialized
DEBUG - 2018-06-29 05:46:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 05:46:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 05:46:58 --> Email Class Initialized
INFO - 2018-06-29 05:46:58 --> Controller Class Initialized
DEBUG - 2018-06-29 05:46:58 --> Login MX_Controller Initialized
INFO - 2018-06-29 05:46:58 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-29 05:46:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-29 05:46:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-29 05:46:58 --> Email starts for user@colin.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-06-29 05:46:58 --> User session created for 4
INFO - 2018-06-29 05:46:58 --> Login status user@colin.com - success
INFO - 2018-06-29 05:46:58 --> Final output sent to browser
DEBUG - 2018-06-29 05:46:58 --> Total execution time: 0.3930
INFO - 2018-06-29 05:46:59 --> Config Class Initialized
INFO - 2018-06-29 05:46:59 --> Hooks Class Initialized
DEBUG - 2018-06-29 05:46:59 --> UTF-8 Support Enabled
INFO - 2018-06-29 05:46:59 --> Utf8 Class Initialized
INFO - 2018-06-29 05:46:59 --> URI Class Initialized
INFO - 2018-06-29 05:46:59 --> Router Class Initialized
INFO - 2018-06-29 05:46:59 --> Output Class Initialized
INFO - 2018-06-29 05:46:59 --> Security Class Initialized
DEBUG - 2018-06-29 05:46:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 05:46:59 --> Input Class Initialized
INFO - 2018-06-29 05:46:59 --> Language Class Initialized
INFO - 2018-06-29 05:46:59 --> Language Class Initialized
INFO - 2018-06-29 05:46:59 --> Config Class Initialized
INFO - 2018-06-29 05:46:59 --> Loader Class Initialized
DEBUG - 2018-06-29 05:46:59 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-29 05:46:59 --> Helper loaded: url_helper
INFO - 2018-06-29 05:46:59 --> Helper loaded: form_helper
INFO - 2018-06-29 05:46:59 --> Helper loaded: date_helper
INFO - 2018-06-29 05:46:59 --> Helper loaded: util_helper
INFO - 2018-06-29 05:46:59 --> Helper loaded: text_helper
INFO - 2018-06-29 05:46:59 --> Helper loaded: string_helper
INFO - 2018-06-29 05:46:59 --> Database Driver Class Initialized
DEBUG - 2018-06-29 05:46:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 05:46:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 05:46:59 --> Email Class Initialized
INFO - 2018-06-29 05:46:59 --> Controller Class Initialized
DEBUG - 2018-06-29 05:46:59 --> Home MX_Controller Initialized
DEBUG - 2018-06-29 05:46:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-06-29 05:46:59 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-29 05:46:59 --> Login MX_Controller Initialized
INFO - 2018-06-29 05:46:59 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-29 05:46:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-29 05:46:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-29 05:46:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-06-29 05:46:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-06-29 05:46:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-06-29 05:46:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-06-29 05:46:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-06-29 05:46:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/search_page.php
INFO - 2018-06-29 05:46:59 --> Final output sent to browser
DEBUG - 2018-06-29 05:46:59 --> Total execution time: 0.5310
INFO - 2018-06-29 05:47:01 --> Config Class Initialized
INFO - 2018-06-29 05:47:01 --> Hooks Class Initialized
DEBUG - 2018-06-29 05:47:01 --> UTF-8 Support Enabled
INFO - 2018-06-29 05:47:01 --> Utf8 Class Initialized
INFO - 2018-06-29 05:47:01 --> URI Class Initialized
INFO - 2018-06-29 05:47:01 --> Router Class Initialized
INFO - 2018-06-29 05:47:01 --> Output Class Initialized
INFO - 2018-06-29 05:47:01 --> Security Class Initialized
DEBUG - 2018-06-29 05:47:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 05:47:01 --> Input Class Initialized
INFO - 2018-06-29 05:47:01 --> Language Class Initialized
INFO - 2018-06-29 05:47:01 --> Language Class Initialized
INFO - 2018-06-29 05:47:01 --> Config Class Initialized
INFO - 2018-06-29 05:47:01 --> Loader Class Initialized
DEBUG - 2018-06-29 05:47:01 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-29 05:47:01 --> Helper loaded: url_helper
INFO - 2018-06-29 05:47:01 --> Helper loaded: form_helper
INFO - 2018-06-29 05:47:01 --> Helper loaded: date_helper
INFO - 2018-06-29 05:47:01 --> Helper loaded: util_helper
INFO - 2018-06-29 05:47:01 --> Helper loaded: text_helper
INFO - 2018-06-29 05:47:01 --> Helper loaded: string_helper
INFO - 2018-06-29 05:47:01 --> Database Driver Class Initialized
DEBUG - 2018-06-29 05:47:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 05:47:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 05:47:01 --> Email Class Initialized
INFO - 2018-06-29 05:47:01 --> Controller Class Initialized
DEBUG - 2018-06-29 05:47:01 --> Login MX_Controller Initialized
INFO - 2018-06-29 05:47:01 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-29 05:47:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-29 05:47:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-06-29 05:47:02 --> Email starts for admin@colin.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-06-29 05:47:02 --> User session created for 1
INFO - 2018-06-29 05:47:02 --> Login status admin@colin.com - success
INFO - 2018-06-29 05:47:02 --> Final output sent to browser
DEBUG - 2018-06-29 05:47:02 --> Total execution time: 0.4370
INFO - 2018-06-29 05:47:02 --> Config Class Initialized
INFO - 2018-06-29 05:47:02 --> Hooks Class Initialized
DEBUG - 2018-06-29 05:47:02 --> UTF-8 Support Enabled
INFO - 2018-06-29 05:47:02 --> Utf8 Class Initialized
INFO - 2018-06-29 05:47:02 --> URI Class Initialized
INFO - 2018-06-29 05:47:02 --> Router Class Initialized
INFO - 2018-06-29 05:47:02 --> Output Class Initialized
INFO - 2018-06-29 05:47:02 --> Security Class Initialized
DEBUG - 2018-06-29 05:47:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 05:47:02 --> Input Class Initialized
INFO - 2018-06-29 05:47:02 --> Language Class Initialized
INFO - 2018-06-29 05:47:02 --> Language Class Initialized
INFO - 2018-06-29 05:47:02 --> Config Class Initialized
INFO - 2018-06-29 05:47:02 --> Loader Class Initialized
DEBUG - 2018-06-29 05:47:02 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-29 05:47:02 --> Helper loaded: url_helper
INFO - 2018-06-29 05:47:02 --> Helper loaded: form_helper
INFO - 2018-06-29 05:47:02 --> Helper loaded: date_helper
INFO - 2018-06-29 05:47:02 --> Helper loaded: util_helper
INFO - 2018-06-29 05:47:02 --> Helper loaded: text_helper
INFO - 2018-06-29 05:47:02 --> Helper loaded: string_helper
INFO - 2018-06-29 05:47:02 --> Database Driver Class Initialized
DEBUG - 2018-06-29 05:47:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 05:47:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 05:47:02 --> Email Class Initialized
INFO - 2018-06-29 05:47:02 --> Controller Class Initialized
DEBUG - 2018-06-29 05:47:02 --> Users MX_Controller Initialized
DEBUG - 2018-06-29 05:47:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-29 05:47:02 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-29 05:47:02 --> Login MX_Controller Initialized
INFO - 2018-06-29 05:47:02 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-29 05:47:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-29 05:47:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-06-29 05:47:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-06-29 05:47:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-06-29 05:47:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-06-29 05:47:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-06-29 05:47:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-06-29 05:47:02 --> Final output sent to browser
DEBUG - 2018-06-29 05:47:02 --> Total execution time: 0.4463
INFO - 2018-06-29 05:47:03 --> Config Class Initialized
INFO - 2018-06-29 05:47:03 --> Hooks Class Initialized
DEBUG - 2018-06-29 05:47:03 --> UTF-8 Support Enabled
INFO - 2018-06-29 05:47:03 --> Utf8 Class Initialized
INFO - 2018-06-29 05:47:03 --> URI Class Initialized
INFO - 2018-06-29 05:47:03 --> Router Class Initialized
INFO - 2018-06-29 05:47:03 --> Output Class Initialized
INFO - 2018-06-29 05:47:03 --> Security Class Initialized
DEBUG - 2018-06-29 05:47:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 05:47:03 --> Input Class Initialized
INFO - 2018-06-29 05:47:03 --> Language Class Initialized
INFO - 2018-06-29 05:47:03 --> Language Class Initialized
INFO - 2018-06-29 05:47:03 --> Config Class Initialized
INFO - 2018-06-29 05:47:03 --> Loader Class Initialized
DEBUG - 2018-06-29 05:47:03 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-06-29 05:47:03 --> Helper loaded: url_helper
INFO - 2018-06-29 05:47:03 --> Helper loaded: form_helper
INFO - 2018-06-29 05:47:03 --> Helper loaded: date_helper
INFO - 2018-06-29 05:47:03 --> Helper loaded: util_helper
INFO - 2018-06-29 05:47:03 --> Helper loaded: text_helper
INFO - 2018-06-29 05:47:03 --> Helper loaded: string_helper
INFO - 2018-06-29 05:47:03 --> Database Driver Class Initialized
DEBUG - 2018-06-29 05:47:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-29 05:47:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-29 05:47:04 --> Email Class Initialized
INFO - 2018-06-29 05:47:04 --> Controller Class Initialized
DEBUG - 2018-06-29 05:47:04 --> Users MX_Controller Initialized
DEBUG - 2018-06-29 05:47:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-06-29 05:47:04 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-06-29 05:47:04 --> Login MX_Controller Initialized
INFO - 2018-06-29 05:47:04 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-06-29 05:47:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-06-29 05:47:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-06-29 05:47:04 --> Final output sent to browser
DEBUG - 2018-06-29 05:47:04 --> Total execution time: 0.5866
INFO - 2018-06-29 05:47:11 --> Config Class Initialized
INFO - 2018-06-29 05:47:12 --> Hooks Class Initialized
DEBUG - 2018-06-29 05:47:12 --> UTF-8 Support Enabled
INFO - 2018-06-29 05:47:12 --> Utf8 Class Initialized
INFO - 2018-06-29 05:47:12 --> URI Class Initialized
INFO - 2018-06-29 05:47:12 --> Router Class Initialized
INFO - 2018-06-29 05:47:12 --> Output Class Initialized
INFO - 2018-06-29 05:47:12 --> Security Class Initialized
DEBUG - 2018-06-29 05:47:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 05:47:12 --> Input Class Initialized
INFO - 2018-06-29 05:47:12 --> Language Class Initialized
ERROR - 2018-06-29 05:47:12 --> 404 Page Not Found: /index
INFO - 2018-06-29 05:47:12 --> Config Class Initialized
INFO - 2018-06-29 05:47:12 --> Hooks Class Initialized
DEBUG - 2018-06-29 05:47:12 --> UTF-8 Support Enabled
INFO - 2018-06-29 05:47:12 --> Utf8 Class Initialized
INFO - 2018-06-29 05:47:12 --> URI Class Initialized
INFO - 2018-06-29 05:47:12 --> Router Class Initialized
INFO - 2018-06-29 05:47:12 --> Output Class Initialized
INFO - 2018-06-29 05:47:12 --> Security Class Initialized
DEBUG - 2018-06-29 05:47:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 05:47:12 --> Input Class Initialized
INFO - 2018-06-29 05:47:12 --> Language Class Initialized
ERROR - 2018-06-29 05:47:12 --> 404 Page Not Found: /index
INFO - 2018-06-29 05:47:12 --> Config Class Initialized
INFO - 2018-06-29 05:47:12 --> Hooks Class Initialized
DEBUG - 2018-06-29 05:47:12 --> UTF-8 Support Enabled
INFO - 2018-06-29 05:47:12 --> Utf8 Class Initialized
INFO - 2018-06-29 05:47:12 --> URI Class Initialized
INFO - 2018-06-29 05:47:12 --> Router Class Initialized
INFO - 2018-06-29 05:47:12 --> Output Class Initialized
INFO - 2018-06-29 05:47:12 --> Security Class Initialized
DEBUG - 2018-06-29 05:47:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 05:47:12 --> Input Class Initialized
INFO - 2018-06-29 05:47:12 --> Language Class Initialized
ERROR - 2018-06-29 05:47:12 --> 404 Page Not Found: /index
INFO - 2018-06-29 05:47:13 --> Config Class Initialized
INFO - 2018-06-29 05:47:13 --> Hooks Class Initialized
DEBUG - 2018-06-29 05:47:13 --> UTF-8 Support Enabled
INFO - 2018-06-29 05:47:13 --> Utf8 Class Initialized
INFO - 2018-06-29 05:47:13 --> URI Class Initialized
INFO - 2018-06-29 05:47:13 --> Router Class Initialized
INFO - 2018-06-29 05:47:13 --> Output Class Initialized
INFO - 2018-06-29 05:47:13 --> Security Class Initialized
DEBUG - 2018-06-29 05:47:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 05:47:13 --> Input Class Initialized
INFO - 2018-06-29 05:47:13 --> Language Class Initialized
ERROR - 2018-06-29 05:47:13 --> 404 Page Not Found: /index
INFO - 2018-06-29 05:47:13 --> Config Class Initialized
INFO - 2018-06-29 05:47:13 --> Hooks Class Initialized
DEBUG - 2018-06-29 05:47:13 --> UTF-8 Support Enabled
INFO - 2018-06-29 05:47:13 --> Utf8 Class Initialized
INFO - 2018-06-29 05:47:13 --> URI Class Initialized
INFO - 2018-06-29 05:47:13 --> Router Class Initialized
INFO - 2018-06-29 05:47:13 --> Output Class Initialized
INFO - 2018-06-29 05:47:13 --> Security Class Initialized
DEBUG - 2018-06-29 05:47:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 05:47:13 --> Input Class Initialized
INFO - 2018-06-29 05:47:13 --> Language Class Initialized
ERROR - 2018-06-29 05:47:13 --> 404 Page Not Found: /index
INFO - 2018-06-29 05:47:13 --> Config Class Initialized
INFO - 2018-06-29 05:47:13 --> Hooks Class Initialized
DEBUG - 2018-06-29 05:47:13 --> UTF-8 Support Enabled
INFO - 2018-06-29 05:47:13 --> Utf8 Class Initialized
INFO - 2018-06-29 05:47:13 --> URI Class Initialized
INFO - 2018-06-29 05:47:13 --> Router Class Initialized
INFO - 2018-06-29 05:47:13 --> Output Class Initialized
INFO - 2018-06-29 05:47:13 --> Security Class Initialized
DEBUG - 2018-06-29 05:47:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-29 05:47:13 --> Input Class Initialized
INFO - 2018-06-29 05:47:13 --> Language Class Initialized
ERROR - 2018-06-29 05:47:13 --> 404 Page Not Found: /index
