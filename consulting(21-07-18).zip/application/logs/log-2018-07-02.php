<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-07-02 21:35:04 --> Config Class Initialized
INFO - 2018-07-02 21:35:04 --> Hooks Class Initialized
DEBUG - 2018-07-02 21:35:04 --> UTF-8 Support Enabled
INFO - 2018-07-02 21:35:04 --> Utf8 Class Initialized
INFO - 2018-07-02 21:35:04 --> URI Class Initialized
DEBUG - 2018-07-02 21:35:04 --> No URI present. Default controller set.
INFO - 2018-07-02 21:35:04 --> Router Class Initialized
INFO - 2018-07-02 21:35:04 --> Output Class Initialized
INFO - 2018-07-02 21:35:04 --> Security Class Initialized
DEBUG - 2018-07-02 21:35:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-02 21:35:04 --> Input Class Initialized
INFO - 2018-07-02 21:35:04 --> Language Class Initialized
INFO - 2018-07-02 21:35:04 --> Language Class Initialized
INFO - 2018-07-02 21:35:04 --> Config Class Initialized
INFO - 2018-07-02 21:35:04 --> Loader Class Initialized
DEBUG - 2018-07-02 21:35:04 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-02 21:35:04 --> Helper loaded: url_helper
INFO - 2018-07-02 21:35:04 --> Helper loaded: form_helper
INFO - 2018-07-02 21:35:04 --> Helper loaded: date_helper
INFO - 2018-07-02 21:35:04 --> Helper loaded: util_helper
INFO - 2018-07-02 21:35:04 --> Helper loaded: text_helper
INFO - 2018-07-02 21:35:04 --> Helper loaded: string_helper
INFO - 2018-07-02 21:35:04 --> Database Driver Class Initialized
DEBUG - 2018-07-02 21:35:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-02 21:35:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-02 21:35:04 --> Email Class Initialized
INFO - 2018-07-02 21:35:04 --> Controller Class Initialized
DEBUG - 2018-07-02 21:35:04 --> Home MX_Controller Initialized
DEBUG - 2018-07-02 21:35:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-02 21:35:05 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-02 21:35:05 --> Login MX_Controller Initialized
INFO - 2018-07-02 21:35:05 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-02 21:35:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-02 21:35:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-02 21:35:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-07-02 21:35:08 --> Config Class Initialized
INFO - 2018-07-02 21:35:08 --> Hooks Class Initialized
DEBUG - 2018-07-02 21:35:08 --> UTF-8 Support Enabled
INFO - 2018-07-02 21:35:08 --> Utf8 Class Initialized
INFO - 2018-07-02 21:35:08 --> URI Class Initialized
INFO - 2018-07-02 21:35:08 --> Router Class Initialized
INFO - 2018-07-02 21:35:08 --> Output Class Initialized
INFO - 2018-07-02 21:35:08 --> Security Class Initialized
DEBUG - 2018-07-02 21:35:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-02 21:35:08 --> Input Class Initialized
INFO - 2018-07-02 21:35:08 --> Language Class Initialized
INFO - 2018-07-02 21:35:08 --> Language Class Initialized
INFO - 2018-07-02 21:35:08 --> Config Class Initialized
INFO - 2018-07-02 21:35:08 --> Loader Class Initialized
DEBUG - 2018-07-02 21:35:08 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-02 21:35:08 --> Helper loaded: url_helper
INFO - 2018-07-02 21:35:08 --> Helper loaded: form_helper
INFO - 2018-07-02 21:35:08 --> Helper loaded: date_helper
INFO - 2018-07-02 21:35:08 --> Helper loaded: util_helper
INFO - 2018-07-02 21:35:08 --> Helper loaded: text_helper
INFO - 2018-07-02 21:35:08 --> Helper loaded: string_helper
INFO - 2018-07-02 21:35:08 --> Database Driver Class Initialized
DEBUG - 2018-07-02 21:35:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-02 21:35:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-02 21:35:08 --> Email Class Initialized
INFO - 2018-07-02 21:35:08 --> Controller Class Initialized
DEBUG - 2018-07-02 21:35:08 --> Login MX_Controller Initialized
INFO - 2018-07-02 21:35:08 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-02 21:35:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-02 21:35:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-02 21:35:08 --> Email starts for user@colin.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-07-02 21:35:09 --> User session created for 4
INFO - 2018-07-02 21:35:09 --> Login status user@colin.com - success
INFO - 2018-07-02 21:35:09 --> Final output sent to browser
DEBUG - 2018-07-02 21:35:09 --> Total execution time: 0.3317
INFO - 2018-07-02 21:35:09 --> Config Class Initialized
INFO - 2018-07-02 21:35:09 --> Hooks Class Initialized
DEBUG - 2018-07-02 21:35:09 --> UTF-8 Support Enabled
INFO - 2018-07-02 21:35:09 --> Utf8 Class Initialized
INFO - 2018-07-02 21:35:09 --> URI Class Initialized
DEBUG - 2018-07-02 21:35:09 --> No URI present. Default controller set.
INFO - 2018-07-02 21:35:09 --> Router Class Initialized
INFO - 2018-07-02 21:35:09 --> Output Class Initialized
INFO - 2018-07-02 21:35:09 --> Security Class Initialized
DEBUG - 2018-07-02 21:35:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-02 21:35:09 --> Input Class Initialized
INFO - 2018-07-02 21:35:09 --> Language Class Initialized
INFO - 2018-07-02 21:35:09 --> Language Class Initialized
INFO - 2018-07-02 21:35:09 --> Config Class Initialized
INFO - 2018-07-02 21:35:09 --> Loader Class Initialized
DEBUG - 2018-07-02 21:35:09 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-02 21:35:09 --> Helper loaded: url_helper
INFO - 2018-07-02 21:35:09 --> Helper loaded: form_helper
INFO - 2018-07-02 21:35:09 --> Helper loaded: date_helper
INFO - 2018-07-02 21:35:09 --> Helper loaded: util_helper
INFO - 2018-07-02 21:35:09 --> Helper loaded: text_helper
INFO - 2018-07-02 21:35:09 --> Helper loaded: string_helper
INFO - 2018-07-02 21:35:09 --> Database Driver Class Initialized
DEBUG - 2018-07-02 21:35:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-02 21:35:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-02 21:35:09 --> Email Class Initialized
INFO - 2018-07-02 21:35:09 --> Controller Class Initialized
DEBUG - 2018-07-02 21:35:09 --> Home MX_Controller Initialized
DEBUG - 2018-07-02 21:35:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-02 21:35:09 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-02 21:35:09 --> Login MX_Controller Initialized
INFO - 2018-07-02 21:35:09 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-02 21:35:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-02 21:35:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-02 21:35:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-02 21:35:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-02 21:35:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-02 21:35:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-02 21:35:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-02 21:35:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-02 21:35:09 --> Final output sent to browser
DEBUG - 2018-07-02 21:35:09 --> Total execution time: 0.5740
INFO - 2018-07-02 21:35:10 --> Config Class Initialized
INFO - 2018-07-02 21:35:10 --> Hooks Class Initialized
DEBUG - 2018-07-02 21:35:10 --> UTF-8 Support Enabled
INFO - 2018-07-02 21:35:10 --> Utf8 Class Initialized
INFO - 2018-07-02 21:35:10 --> URI Class Initialized
INFO - 2018-07-02 21:35:10 --> Router Class Initialized
INFO - 2018-07-02 21:35:10 --> Output Class Initialized
INFO - 2018-07-02 21:35:10 --> Security Class Initialized
DEBUG - 2018-07-02 21:35:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-02 21:35:10 --> Input Class Initialized
INFO - 2018-07-02 21:35:10 --> Language Class Initialized
ERROR - 2018-07-02 21:35:10 --> 404 Page Not Found: /index
INFO - 2018-07-02 21:35:11 --> Config Class Initialized
INFO - 2018-07-02 21:35:11 --> Hooks Class Initialized
DEBUG - 2018-07-02 21:35:11 --> UTF-8 Support Enabled
INFO - 2018-07-02 21:35:11 --> Utf8 Class Initialized
INFO - 2018-07-02 21:35:11 --> URI Class Initialized
INFO - 2018-07-02 21:35:11 --> Router Class Initialized
INFO - 2018-07-02 21:35:11 --> Output Class Initialized
INFO - 2018-07-02 21:35:11 --> Security Class Initialized
DEBUG - 2018-07-02 21:35:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-02 21:35:11 --> Input Class Initialized
INFO - 2018-07-02 21:35:11 --> Language Class Initialized
ERROR - 2018-07-02 21:35:11 --> 404 Page Not Found: /index
INFO - 2018-07-02 21:35:11 --> Config Class Initialized
INFO - 2018-07-02 21:35:11 --> Hooks Class Initialized
DEBUG - 2018-07-02 21:35:11 --> UTF-8 Support Enabled
INFO - 2018-07-02 21:35:11 --> Utf8 Class Initialized
INFO - 2018-07-02 21:35:11 --> URI Class Initialized
INFO - 2018-07-02 21:35:11 --> Router Class Initialized
INFO - 2018-07-02 21:35:11 --> Output Class Initialized
INFO - 2018-07-02 21:35:11 --> Security Class Initialized
DEBUG - 2018-07-02 21:35:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-02 21:35:11 --> Input Class Initialized
INFO - 2018-07-02 21:35:11 --> Language Class Initialized
ERROR - 2018-07-02 21:35:11 --> 404 Page Not Found: /index
INFO - 2018-07-02 21:35:11 --> Config Class Initialized
INFO - 2018-07-02 21:35:11 --> Hooks Class Initialized
DEBUG - 2018-07-02 21:35:11 --> UTF-8 Support Enabled
INFO - 2018-07-02 21:35:11 --> Utf8 Class Initialized
INFO - 2018-07-02 21:35:11 --> URI Class Initialized
INFO - 2018-07-02 21:35:11 --> Router Class Initialized
INFO - 2018-07-02 21:35:11 --> Output Class Initialized
INFO - 2018-07-02 21:35:11 --> Security Class Initialized
DEBUG - 2018-07-02 21:35:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-02 21:35:11 --> Input Class Initialized
INFO - 2018-07-02 21:35:11 --> Language Class Initialized
ERROR - 2018-07-02 21:35:11 --> 404 Page Not Found: /index
INFO - 2018-07-02 21:35:11 --> Config Class Initialized
INFO - 2018-07-02 21:35:11 --> Hooks Class Initialized
DEBUG - 2018-07-02 21:35:11 --> UTF-8 Support Enabled
INFO - 2018-07-02 21:35:11 --> Utf8 Class Initialized
INFO - 2018-07-02 21:35:11 --> URI Class Initialized
INFO - 2018-07-02 21:35:11 --> Router Class Initialized
INFO - 2018-07-02 21:35:11 --> Output Class Initialized
INFO - 2018-07-02 21:35:11 --> Security Class Initialized
DEBUG - 2018-07-02 21:35:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-02 21:35:11 --> Input Class Initialized
INFO - 2018-07-02 21:35:11 --> Language Class Initialized
ERROR - 2018-07-02 21:35:11 --> 404 Page Not Found: /index
INFO - 2018-07-02 21:35:11 --> Config Class Initialized
INFO - 2018-07-02 21:35:11 --> Hooks Class Initialized
DEBUG - 2018-07-02 21:35:11 --> UTF-8 Support Enabled
INFO - 2018-07-02 21:35:11 --> Utf8 Class Initialized
INFO - 2018-07-02 21:35:11 --> URI Class Initialized
INFO - 2018-07-02 21:35:11 --> Router Class Initialized
INFO - 2018-07-02 21:35:11 --> Output Class Initialized
INFO - 2018-07-02 21:35:11 --> Security Class Initialized
DEBUG - 2018-07-02 21:35:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-02 21:35:11 --> Input Class Initialized
INFO - 2018-07-02 21:35:11 --> Language Class Initialized
ERROR - 2018-07-02 21:35:11 --> 404 Page Not Found: /index
INFO - 2018-07-02 22:44:43 --> Config Class Initialized
INFO - 2018-07-02 22:44:43 --> Hooks Class Initialized
DEBUG - 2018-07-02 22:44:43 --> UTF-8 Support Enabled
INFO - 2018-07-02 22:44:43 --> Utf8 Class Initialized
INFO - 2018-07-02 22:44:43 --> URI Class Initialized
DEBUG - 2018-07-02 22:44:43 --> No URI present. Default controller set.
INFO - 2018-07-02 22:44:43 --> Router Class Initialized
INFO - 2018-07-02 22:44:43 --> Output Class Initialized
INFO - 2018-07-02 22:44:43 --> Security Class Initialized
DEBUG - 2018-07-02 22:44:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-02 22:44:43 --> Input Class Initialized
INFO - 2018-07-02 22:44:43 --> Language Class Initialized
INFO - 2018-07-02 22:44:43 --> Language Class Initialized
INFO - 2018-07-02 22:44:43 --> Config Class Initialized
INFO - 2018-07-02 22:44:43 --> Loader Class Initialized
DEBUG - 2018-07-02 22:44:43 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-02 22:44:43 --> Helper loaded: url_helper
INFO - 2018-07-02 22:44:43 --> Helper loaded: form_helper
INFO - 2018-07-02 22:44:43 --> Helper loaded: date_helper
INFO - 2018-07-02 22:44:43 --> Helper loaded: util_helper
INFO - 2018-07-02 22:44:43 --> Helper loaded: text_helper
INFO - 2018-07-02 22:44:43 --> Helper loaded: string_helper
INFO - 2018-07-02 22:44:43 --> Database Driver Class Initialized
DEBUG - 2018-07-02 22:44:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-02 22:44:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-02 22:44:43 --> Email Class Initialized
INFO - 2018-07-02 22:44:43 --> Controller Class Initialized
DEBUG - 2018-07-02 22:44:43 --> Home MX_Controller Initialized
DEBUG - 2018-07-02 22:44:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-02 22:44:43 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-02 22:44:43 --> Login MX_Controller Initialized
INFO - 2018-07-02 22:44:43 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-02 22:44:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-02 22:44:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-02 22:44:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-02 22:44:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-02 22:44:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-02 22:44:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-02 22:44:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-02 22:44:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-02 22:44:44 --> Final output sent to browser
DEBUG - 2018-07-02 22:44:44 --> Total execution time: 0.3665
INFO - 2018-07-02 22:44:44 --> Config Class Initialized
INFO - 2018-07-02 22:44:44 --> Hooks Class Initialized
DEBUG - 2018-07-02 22:44:44 --> UTF-8 Support Enabled
INFO - 2018-07-02 22:44:44 --> Utf8 Class Initialized
INFO - 2018-07-02 22:44:44 --> URI Class Initialized
INFO - 2018-07-02 22:44:44 --> Router Class Initialized
INFO - 2018-07-02 22:44:44 --> Output Class Initialized
INFO - 2018-07-02 22:44:44 --> Security Class Initialized
DEBUG - 2018-07-02 22:44:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-02 22:44:44 --> Input Class Initialized
INFO - 2018-07-02 22:44:44 --> Language Class Initialized
ERROR - 2018-07-02 22:44:44 --> 404 Page Not Found: /index
INFO - 2018-07-02 22:44:44 --> Config Class Initialized
INFO - 2018-07-02 22:44:44 --> Hooks Class Initialized
DEBUG - 2018-07-02 22:44:44 --> UTF-8 Support Enabled
INFO - 2018-07-02 22:44:44 --> Utf8 Class Initialized
INFO - 2018-07-02 22:44:44 --> URI Class Initialized
INFO - 2018-07-02 22:44:44 --> Router Class Initialized
INFO - 2018-07-02 22:44:44 --> Output Class Initialized
INFO - 2018-07-02 22:44:44 --> Security Class Initialized
DEBUG - 2018-07-02 22:44:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-02 22:44:44 --> Input Class Initialized
INFO - 2018-07-02 22:44:44 --> Language Class Initialized
ERROR - 2018-07-02 22:44:44 --> 404 Page Not Found: /index
INFO - 2018-07-02 22:44:44 --> Config Class Initialized
INFO - 2018-07-02 22:44:44 --> Hooks Class Initialized
DEBUG - 2018-07-02 22:44:44 --> UTF-8 Support Enabled
INFO - 2018-07-02 22:44:44 --> Utf8 Class Initialized
INFO - 2018-07-02 22:44:44 --> URI Class Initialized
INFO - 2018-07-02 22:44:44 --> Router Class Initialized
INFO - 2018-07-02 22:44:44 --> Output Class Initialized
INFO - 2018-07-02 22:44:44 --> Security Class Initialized
DEBUG - 2018-07-02 22:44:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-02 22:44:44 --> Input Class Initialized
INFO - 2018-07-02 22:44:44 --> Language Class Initialized
ERROR - 2018-07-02 22:44:44 --> 404 Page Not Found: /index
INFO - 2018-07-02 22:44:49 --> Config Class Initialized
INFO - 2018-07-02 22:44:49 --> Hooks Class Initialized
DEBUG - 2018-07-02 22:44:49 --> UTF-8 Support Enabled
INFO - 2018-07-02 22:44:49 --> Utf8 Class Initialized
INFO - 2018-07-02 22:44:49 --> URI Class Initialized
INFO - 2018-07-02 22:44:49 --> Router Class Initialized
INFO - 2018-07-02 22:44:49 --> Output Class Initialized
INFO - 2018-07-02 22:44:49 --> Security Class Initialized
DEBUG - 2018-07-02 22:44:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-02 22:44:49 --> Input Class Initialized
INFO - 2018-07-02 22:44:49 --> Language Class Initialized
INFO - 2018-07-02 22:44:50 --> Language Class Initialized
INFO - 2018-07-02 22:44:50 --> Config Class Initialized
INFO - 2018-07-02 22:44:50 --> Loader Class Initialized
DEBUG - 2018-07-02 22:44:50 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-02 22:44:50 --> Helper loaded: url_helper
INFO - 2018-07-02 22:44:50 --> Helper loaded: form_helper
INFO - 2018-07-02 22:44:50 --> Helper loaded: date_helper
INFO - 2018-07-02 22:44:50 --> Helper loaded: util_helper
INFO - 2018-07-02 22:44:50 --> Helper loaded: text_helper
INFO - 2018-07-02 22:44:50 --> Helper loaded: string_helper
INFO - 2018-07-02 22:44:50 --> Database Driver Class Initialized
DEBUG - 2018-07-02 22:44:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-02 22:44:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-02 22:44:50 --> Email Class Initialized
INFO - 2018-07-02 22:44:50 --> Controller Class Initialized
DEBUG - 2018-07-02 22:44:50 --> Admin MX_Controller Initialized
INFO - 2018-07-02 22:44:50 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-02 22:44:50 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-02 22:44:50 --> Login MX_Controller Initialized
DEBUG - 2018-07-02 22:44:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-02 22:44:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-02 22:44:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
INFO - 2018-07-02 22:44:50 --> Config Class Initialized
INFO - 2018-07-02 22:44:50 --> Hooks Class Initialized
DEBUG - 2018-07-02 22:44:50 --> UTF-8 Support Enabled
INFO - 2018-07-02 22:44:50 --> Utf8 Class Initialized
INFO - 2018-07-02 22:44:50 --> URI Class Initialized
INFO - 2018-07-02 22:44:50 --> Router Class Initialized
INFO - 2018-07-02 22:44:50 --> Output Class Initialized
INFO - 2018-07-02 22:44:50 --> Security Class Initialized
DEBUG - 2018-07-02 22:44:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-02 22:44:50 --> Input Class Initialized
INFO - 2018-07-02 22:44:50 --> Language Class Initialized
ERROR - 2018-07-02 22:44:50 --> 404 Page Not Found: /index
INFO - 2018-07-02 22:44:50 --> Config Class Initialized
INFO - 2018-07-02 22:44:50 --> Hooks Class Initialized
DEBUG - 2018-07-02 22:44:50 --> UTF-8 Support Enabled
INFO - 2018-07-02 22:44:50 --> Utf8 Class Initialized
INFO - 2018-07-02 22:44:50 --> URI Class Initialized
INFO - 2018-07-02 22:44:50 --> Router Class Initialized
INFO - 2018-07-02 22:44:50 --> Output Class Initialized
INFO - 2018-07-02 22:44:50 --> Security Class Initialized
DEBUG - 2018-07-02 22:44:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-02 22:44:50 --> Input Class Initialized
INFO - 2018-07-02 22:44:50 --> Language Class Initialized
ERROR - 2018-07-02 22:44:50 --> 404 Page Not Found: /index
INFO - 2018-07-02 22:45:17 --> Config Class Initialized
INFO - 2018-07-02 22:45:17 --> Hooks Class Initialized
DEBUG - 2018-07-02 22:45:17 --> UTF-8 Support Enabled
INFO - 2018-07-02 22:45:17 --> Utf8 Class Initialized
INFO - 2018-07-02 22:45:17 --> URI Class Initialized
INFO - 2018-07-02 22:45:17 --> Router Class Initialized
INFO - 2018-07-02 22:45:17 --> Output Class Initialized
INFO - 2018-07-02 22:45:17 --> Security Class Initialized
DEBUG - 2018-07-02 22:45:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-02 22:45:17 --> Input Class Initialized
INFO - 2018-07-02 22:45:17 --> Language Class Initialized
INFO - 2018-07-02 22:45:17 --> Language Class Initialized
INFO - 2018-07-02 22:45:17 --> Config Class Initialized
INFO - 2018-07-02 22:45:17 --> Loader Class Initialized
DEBUG - 2018-07-02 22:45:17 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-02 22:45:17 --> Helper loaded: url_helper
INFO - 2018-07-02 22:45:17 --> Helper loaded: form_helper
INFO - 2018-07-02 22:45:17 --> Helper loaded: date_helper
INFO - 2018-07-02 22:45:17 --> Helper loaded: util_helper
INFO - 2018-07-02 22:45:17 --> Helper loaded: text_helper
INFO - 2018-07-02 22:45:17 --> Helper loaded: string_helper
INFO - 2018-07-02 22:45:17 --> Database Driver Class Initialized
DEBUG - 2018-07-02 22:45:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-02 22:45:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-02 22:45:17 --> Email Class Initialized
INFO - 2018-07-02 22:45:17 --> Controller Class Initialized
DEBUG - 2018-07-02 22:45:18 --> Login MX_Controller Initialized
INFO - 2018-07-02 22:45:18 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-02 22:45:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-02 22:45:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-02 22:45:18 --> Email starts for admin@colin.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-07-02 22:45:18 --> User session created for 1
INFO - 2018-07-02 22:45:18 --> Login status admin@colin.com - success
INFO - 2018-07-02 22:45:18 --> Final output sent to browser
DEBUG - 2018-07-02 22:45:18 --> Total execution time: 0.3325
INFO - 2018-07-02 22:45:18 --> Config Class Initialized
INFO - 2018-07-02 22:45:18 --> Hooks Class Initialized
DEBUG - 2018-07-02 22:45:18 --> UTF-8 Support Enabled
INFO - 2018-07-02 22:45:18 --> Utf8 Class Initialized
INFO - 2018-07-02 22:45:18 --> URI Class Initialized
INFO - 2018-07-02 22:45:18 --> Router Class Initialized
INFO - 2018-07-02 22:45:18 --> Output Class Initialized
INFO - 2018-07-02 22:45:18 --> Security Class Initialized
DEBUG - 2018-07-02 22:45:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-02 22:45:18 --> Input Class Initialized
INFO - 2018-07-02 22:45:18 --> Language Class Initialized
INFO - 2018-07-02 22:45:18 --> Language Class Initialized
INFO - 2018-07-02 22:45:18 --> Config Class Initialized
INFO - 2018-07-02 22:45:18 --> Loader Class Initialized
DEBUG - 2018-07-02 22:45:18 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-02 22:45:18 --> Helper loaded: url_helper
INFO - 2018-07-02 22:45:18 --> Helper loaded: form_helper
INFO - 2018-07-02 22:45:18 --> Helper loaded: date_helper
INFO - 2018-07-02 22:45:18 --> Helper loaded: util_helper
INFO - 2018-07-02 22:45:18 --> Helper loaded: text_helper
INFO - 2018-07-02 22:45:18 --> Helper loaded: string_helper
INFO - 2018-07-02 22:45:18 --> Database Driver Class Initialized
DEBUG - 2018-07-02 22:45:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-02 22:45:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-02 22:45:18 --> Email Class Initialized
INFO - 2018-07-02 22:45:18 --> Controller Class Initialized
DEBUG - 2018-07-02 22:45:18 --> Admin MX_Controller Initialized
INFO - 2018-07-02 22:45:18 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-02 22:45:18 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-02 22:45:18 --> Login MX_Controller Initialized
DEBUG - 2018-07-02 22:45:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-02 22:45:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-02 22:45:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-02 22:45:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-02 22:45:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-02 22:45:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-02 22:45:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-02 22:45:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/dashboard.php
INFO - 2018-07-02 22:45:18 --> Final output sent to browser
DEBUG - 2018-07-02 22:45:18 --> Total execution time: 0.4873
INFO - 2018-07-02 22:45:18 --> Config Class Initialized
INFO - 2018-07-02 22:45:18 --> Hooks Class Initialized
DEBUG - 2018-07-02 22:45:18 --> UTF-8 Support Enabled
INFO - 2018-07-02 22:45:18 --> Utf8 Class Initialized
INFO - 2018-07-02 22:45:18 --> URI Class Initialized
INFO - 2018-07-02 22:45:18 --> Router Class Initialized
INFO - 2018-07-02 22:45:18 --> Output Class Initialized
INFO - 2018-07-02 22:45:18 --> Security Class Initialized
DEBUG - 2018-07-02 22:45:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-02 22:45:18 --> Input Class Initialized
INFO - 2018-07-02 22:45:19 --> Language Class Initialized
ERROR - 2018-07-02 22:45:19 --> 404 Page Not Found: /index
INFO - 2018-07-02 22:45:19 --> Config Class Initialized
INFO - 2018-07-02 22:45:19 --> Hooks Class Initialized
DEBUG - 2018-07-02 22:45:19 --> UTF-8 Support Enabled
INFO - 2018-07-02 22:45:19 --> Utf8 Class Initialized
INFO - 2018-07-02 22:45:19 --> URI Class Initialized
INFO - 2018-07-02 22:45:19 --> Router Class Initialized
INFO - 2018-07-02 22:45:19 --> Output Class Initialized
INFO - 2018-07-02 22:45:19 --> Security Class Initialized
DEBUG - 2018-07-02 22:45:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-02 22:45:19 --> Input Class Initialized
INFO - 2018-07-02 22:45:19 --> Language Class Initialized
ERROR - 2018-07-02 22:45:19 --> 404 Page Not Found: /index
INFO - 2018-07-02 22:45:19 --> Config Class Initialized
INFO - 2018-07-02 22:45:19 --> Hooks Class Initialized
DEBUG - 2018-07-02 22:45:19 --> UTF-8 Support Enabled
INFO - 2018-07-02 22:45:19 --> Utf8 Class Initialized
INFO - 2018-07-02 22:45:19 --> URI Class Initialized
INFO - 2018-07-02 22:45:19 --> Router Class Initialized
INFO - 2018-07-02 22:45:19 --> Output Class Initialized
INFO - 2018-07-02 22:45:19 --> Security Class Initialized
DEBUG - 2018-07-02 22:45:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-02 22:45:19 --> Input Class Initialized
INFO - 2018-07-02 22:45:20 --> Language Class Initialized
ERROR - 2018-07-02 22:45:20 --> 404 Page Not Found: /index
INFO - 2018-07-02 22:49:06 --> Config Class Initialized
INFO - 2018-07-02 22:49:06 --> Hooks Class Initialized
DEBUG - 2018-07-02 22:49:06 --> UTF-8 Support Enabled
INFO - 2018-07-02 22:49:06 --> Utf8 Class Initialized
INFO - 2018-07-02 22:49:06 --> URI Class Initialized
DEBUG - 2018-07-02 22:49:06 --> No URI present. Default controller set.
INFO - 2018-07-02 22:49:06 --> Router Class Initialized
INFO - 2018-07-02 22:49:06 --> Output Class Initialized
INFO - 2018-07-02 22:49:06 --> Security Class Initialized
DEBUG - 2018-07-02 22:49:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-02 22:49:06 --> Input Class Initialized
INFO - 2018-07-02 22:49:06 --> Language Class Initialized
INFO - 2018-07-02 22:49:06 --> Language Class Initialized
INFO - 2018-07-02 22:49:06 --> Config Class Initialized
INFO - 2018-07-02 22:49:06 --> Loader Class Initialized
DEBUG - 2018-07-02 22:49:06 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-02 22:49:06 --> Helper loaded: url_helper
INFO - 2018-07-02 22:49:06 --> Helper loaded: form_helper
INFO - 2018-07-02 22:49:06 --> Helper loaded: date_helper
INFO - 2018-07-02 22:49:06 --> Helper loaded: util_helper
INFO - 2018-07-02 22:49:06 --> Helper loaded: text_helper
INFO - 2018-07-02 22:49:06 --> Helper loaded: string_helper
INFO - 2018-07-02 22:49:06 --> Database Driver Class Initialized
DEBUG - 2018-07-02 22:49:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-02 22:49:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-02 22:49:06 --> Email Class Initialized
INFO - 2018-07-02 22:49:06 --> Controller Class Initialized
DEBUG - 2018-07-02 22:49:06 --> Home MX_Controller Initialized
DEBUG - 2018-07-02 22:49:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-02 22:49:06 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-02 22:49:07 --> Login MX_Controller Initialized
INFO - 2018-07-02 22:49:07 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-02 22:49:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-02 22:49:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-02 22:49:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-02 22:49:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-02 22:49:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-02 22:49:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-02 22:49:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-02 22:49:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-02 22:49:07 --> Final output sent to browser
DEBUG - 2018-07-02 22:49:07 --> Total execution time: 0.3842
INFO - 2018-07-02 22:49:07 --> Config Class Initialized
INFO - 2018-07-02 22:49:07 --> Hooks Class Initialized
DEBUG - 2018-07-02 22:49:07 --> UTF-8 Support Enabled
INFO - 2018-07-02 22:49:07 --> Utf8 Class Initialized
INFO - 2018-07-02 22:49:07 --> URI Class Initialized
INFO - 2018-07-02 22:49:07 --> Router Class Initialized
INFO - 2018-07-02 22:49:07 --> Output Class Initialized
INFO - 2018-07-02 22:49:07 --> Security Class Initialized
DEBUG - 2018-07-02 22:49:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-02 22:49:07 --> Input Class Initialized
INFO - 2018-07-02 22:49:07 --> Language Class Initialized
ERROR - 2018-07-02 22:49:07 --> 404 Page Not Found: /index
INFO - 2018-07-02 22:49:07 --> Config Class Initialized
INFO - 2018-07-02 22:49:07 --> Hooks Class Initialized
DEBUG - 2018-07-02 22:49:07 --> UTF-8 Support Enabled
INFO - 2018-07-02 22:49:07 --> Utf8 Class Initialized
INFO - 2018-07-02 22:49:07 --> URI Class Initialized
INFO - 2018-07-02 22:49:07 --> Router Class Initialized
INFO - 2018-07-02 22:49:07 --> Output Class Initialized
INFO - 2018-07-02 22:49:07 --> Security Class Initialized
DEBUG - 2018-07-02 22:49:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-02 22:49:07 --> Input Class Initialized
INFO - 2018-07-02 22:49:07 --> Language Class Initialized
ERROR - 2018-07-02 22:49:07 --> 404 Page Not Found: /index
INFO - 2018-07-02 22:49:07 --> Config Class Initialized
INFO - 2018-07-02 22:49:07 --> Hooks Class Initialized
DEBUG - 2018-07-02 22:49:07 --> UTF-8 Support Enabled
INFO - 2018-07-02 22:49:07 --> Utf8 Class Initialized
INFO - 2018-07-02 22:49:07 --> URI Class Initialized
INFO - 2018-07-02 22:49:07 --> Router Class Initialized
INFO - 2018-07-02 22:49:07 --> Output Class Initialized
INFO - 2018-07-02 22:49:07 --> Security Class Initialized
DEBUG - 2018-07-02 22:49:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-02 22:49:07 --> Input Class Initialized
INFO - 2018-07-02 22:49:07 --> Language Class Initialized
ERROR - 2018-07-02 22:49:07 --> 404 Page Not Found: /index
