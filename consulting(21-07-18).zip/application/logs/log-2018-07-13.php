<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-07-13 05:07:12 --> Config Class Initialized
INFO - 2018-07-13 05:07:12 --> Hooks Class Initialized
DEBUG - 2018-07-13 05:07:12 --> UTF-8 Support Enabled
INFO - 2018-07-13 05:07:12 --> Utf8 Class Initialized
INFO - 2018-07-13 05:07:12 --> URI Class Initialized
DEBUG - 2018-07-13 05:07:12 --> No URI present. Default controller set.
INFO - 2018-07-13 05:07:12 --> Router Class Initialized
INFO - 2018-07-13 05:07:12 --> Output Class Initialized
INFO - 2018-07-13 05:07:12 --> Security Class Initialized
DEBUG - 2018-07-13 05:07:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 05:07:13 --> Input Class Initialized
INFO - 2018-07-13 05:07:13 --> Language Class Initialized
INFO - 2018-07-13 05:07:13 --> Language Class Initialized
INFO - 2018-07-13 05:07:13 --> Config Class Initialized
INFO - 2018-07-13 05:07:13 --> Loader Class Initialized
DEBUG - 2018-07-13 05:07:13 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-13 05:07:13 --> Helper loaded: url_helper
INFO - 2018-07-13 05:07:13 --> Helper loaded: form_helper
INFO - 2018-07-13 05:07:13 --> Helper loaded: date_helper
INFO - 2018-07-13 05:07:13 --> Helper loaded: util_helper
INFO - 2018-07-13 05:07:13 --> Helper loaded: text_helper
INFO - 2018-07-13 05:07:13 --> Helper loaded: string_helper
INFO - 2018-07-13 05:07:13 --> Database Driver Class Initialized
DEBUG - 2018-07-13 05:07:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 05:07:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 05:07:13 --> Email Class Initialized
INFO - 2018-07-13 05:07:13 --> Controller Class Initialized
DEBUG - 2018-07-13 05:07:13 --> Home MX_Controller Initialized
DEBUG - 2018-07-13 05:07:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-13 05:07:13 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-13 05:07:13 --> Login MX_Controller Initialized
INFO - 2018-07-13 05:07:14 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-13 05:07:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-13 05:07:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-13 05:07:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-07-13 05:07:18 --> Config Class Initialized
INFO - 2018-07-13 05:07:18 --> Hooks Class Initialized
DEBUG - 2018-07-13 05:07:18 --> UTF-8 Support Enabled
INFO - 2018-07-13 05:07:18 --> Utf8 Class Initialized
INFO - 2018-07-13 05:07:18 --> URI Class Initialized
INFO - 2018-07-13 05:07:18 --> Router Class Initialized
INFO - 2018-07-13 05:07:19 --> Output Class Initialized
INFO - 2018-07-13 05:07:19 --> Security Class Initialized
DEBUG - 2018-07-13 05:07:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 05:07:19 --> Input Class Initialized
INFO - 2018-07-13 05:07:19 --> Language Class Initialized
INFO - 2018-07-13 05:07:19 --> Language Class Initialized
INFO - 2018-07-13 05:07:19 --> Config Class Initialized
INFO - 2018-07-13 05:07:19 --> Loader Class Initialized
DEBUG - 2018-07-13 05:07:19 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-13 05:07:19 --> Helper loaded: url_helper
INFO - 2018-07-13 05:07:19 --> Helper loaded: form_helper
INFO - 2018-07-13 05:07:19 --> Helper loaded: date_helper
INFO - 2018-07-13 05:07:19 --> Helper loaded: util_helper
INFO - 2018-07-13 05:07:19 --> Helper loaded: text_helper
INFO - 2018-07-13 05:07:19 --> Helper loaded: string_helper
INFO - 2018-07-13 05:07:19 --> Database Driver Class Initialized
DEBUG - 2018-07-13 05:07:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 05:07:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 05:07:19 --> Email Class Initialized
INFO - 2018-07-13 05:07:19 --> Controller Class Initialized
DEBUG - 2018-07-13 05:07:19 --> Users MX_Controller Initialized
DEBUG - 2018-07-13 05:07:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-13 05:07:19 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-13 05:07:19 --> Login MX_Controller Initialized
INFO - 2018-07-13 05:07:19 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-13 05:07:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-13 05:07:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
INFO - 2018-07-13 05:07:19 --> Config Class Initialized
INFO - 2018-07-13 05:07:19 --> Hooks Class Initialized
DEBUG - 2018-07-13 05:07:19 --> UTF-8 Support Enabled
INFO - 2018-07-13 05:07:19 --> Utf8 Class Initialized
INFO - 2018-07-13 05:07:19 --> URI Class Initialized
INFO - 2018-07-13 05:07:19 --> Router Class Initialized
INFO - 2018-07-13 05:07:19 --> Output Class Initialized
INFO - 2018-07-13 05:07:19 --> Security Class Initialized
DEBUG - 2018-07-13 05:07:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 05:07:19 --> Input Class Initialized
INFO - 2018-07-13 05:07:19 --> Language Class Initialized
ERROR - 2018-07-13 05:07:19 --> 404 Page Not Found: /index
INFO - 2018-07-13 05:07:20 --> Config Class Initialized
INFO - 2018-07-13 05:07:20 --> Hooks Class Initialized
DEBUG - 2018-07-13 05:07:20 --> UTF-8 Support Enabled
INFO - 2018-07-13 05:07:20 --> Utf8 Class Initialized
INFO - 2018-07-13 05:07:20 --> URI Class Initialized
INFO - 2018-07-13 05:07:20 --> Router Class Initialized
INFO - 2018-07-13 05:07:20 --> Output Class Initialized
INFO - 2018-07-13 05:07:20 --> Security Class Initialized
DEBUG - 2018-07-13 05:07:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 05:07:20 --> Input Class Initialized
INFO - 2018-07-13 05:07:20 --> Language Class Initialized
ERROR - 2018-07-13 05:07:20 --> 404 Page Not Found: /index
INFO - 2018-07-13 05:07:22 --> Config Class Initialized
INFO - 2018-07-13 05:07:22 --> Hooks Class Initialized
DEBUG - 2018-07-13 05:07:22 --> UTF-8 Support Enabled
INFO - 2018-07-13 05:07:22 --> Utf8 Class Initialized
INFO - 2018-07-13 05:07:22 --> URI Class Initialized
INFO - 2018-07-13 05:07:22 --> Router Class Initialized
INFO - 2018-07-13 05:07:22 --> Output Class Initialized
INFO - 2018-07-13 05:07:22 --> Security Class Initialized
DEBUG - 2018-07-13 05:07:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 05:07:22 --> Input Class Initialized
INFO - 2018-07-13 05:07:22 --> Language Class Initialized
INFO - 2018-07-13 05:07:22 --> Language Class Initialized
INFO - 2018-07-13 05:07:22 --> Config Class Initialized
INFO - 2018-07-13 05:07:22 --> Loader Class Initialized
DEBUG - 2018-07-13 05:07:22 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-13 05:07:22 --> Helper loaded: url_helper
INFO - 2018-07-13 05:07:22 --> Helper loaded: form_helper
INFO - 2018-07-13 05:07:22 --> Helper loaded: date_helper
INFO - 2018-07-13 05:07:22 --> Helper loaded: util_helper
INFO - 2018-07-13 05:07:22 --> Helper loaded: text_helper
INFO - 2018-07-13 05:07:22 --> Helper loaded: string_helper
INFO - 2018-07-13 05:07:22 --> Database Driver Class Initialized
DEBUG - 2018-07-13 05:07:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 05:07:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 05:07:22 --> Email Class Initialized
INFO - 2018-07-13 05:07:22 --> Controller Class Initialized
DEBUG - 2018-07-13 05:07:22 --> Login MX_Controller Initialized
INFO - 2018-07-13 05:07:22 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-13 05:07:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-13 05:07:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-13 05:07:22 --> Email starts for gopipanguluri123@gmail.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-07-13 05:07:22 --> Login status gopipanguluri123@gmail.com - failure
INFO - 2018-07-13 05:07:22 --> Final output sent to browser
DEBUG - 2018-07-13 05:07:22 --> Total execution time: 0.3351
INFO - 2018-07-13 05:07:32 --> Config Class Initialized
INFO - 2018-07-13 05:07:32 --> Hooks Class Initialized
DEBUG - 2018-07-13 05:07:32 --> UTF-8 Support Enabled
INFO - 2018-07-13 05:07:32 --> Utf8 Class Initialized
INFO - 2018-07-13 05:07:32 --> URI Class Initialized
INFO - 2018-07-13 05:07:32 --> Router Class Initialized
INFO - 2018-07-13 05:07:32 --> Output Class Initialized
INFO - 2018-07-13 05:07:32 --> Security Class Initialized
DEBUG - 2018-07-13 05:07:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 05:07:32 --> Input Class Initialized
INFO - 2018-07-13 05:07:32 --> Language Class Initialized
INFO - 2018-07-13 05:07:32 --> Language Class Initialized
INFO - 2018-07-13 05:07:32 --> Config Class Initialized
INFO - 2018-07-13 05:07:32 --> Loader Class Initialized
DEBUG - 2018-07-13 05:07:32 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-13 05:07:32 --> Helper loaded: url_helper
INFO - 2018-07-13 05:07:32 --> Helper loaded: form_helper
INFO - 2018-07-13 05:07:32 --> Helper loaded: date_helper
INFO - 2018-07-13 05:07:32 --> Helper loaded: util_helper
INFO - 2018-07-13 05:07:32 --> Helper loaded: text_helper
INFO - 2018-07-13 05:07:32 --> Helper loaded: string_helper
INFO - 2018-07-13 05:07:32 --> Database Driver Class Initialized
DEBUG - 2018-07-13 05:07:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 05:07:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 05:07:32 --> Email Class Initialized
INFO - 2018-07-13 05:07:32 --> Controller Class Initialized
DEBUG - 2018-07-13 05:07:32 --> Login MX_Controller Initialized
INFO - 2018-07-13 05:07:32 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-13 05:07:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-13 05:07:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-13 05:07:32 --> Email starts for admin@colin.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-07-13 05:07:32 --> User session created for 1
INFO - 2018-07-13 05:07:32 --> Login status admin@colin.com - success
INFO - 2018-07-13 05:07:32 --> Final output sent to browser
DEBUG - 2018-07-13 05:07:32 --> Total execution time: 0.3428
INFO - 2018-07-13 05:07:32 --> Config Class Initialized
INFO - 2018-07-13 05:07:32 --> Hooks Class Initialized
DEBUG - 2018-07-13 05:07:32 --> UTF-8 Support Enabled
INFO - 2018-07-13 05:07:32 --> Utf8 Class Initialized
INFO - 2018-07-13 05:07:32 --> URI Class Initialized
INFO - 2018-07-13 05:07:32 --> Router Class Initialized
INFO - 2018-07-13 05:07:32 --> Output Class Initialized
INFO - 2018-07-13 05:07:33 --> Security Class Initialized
DEBUG - 2018-07-13 05:07:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 05:07:33 --> Input Class Initialized
INFO - 2018-07-13 05:07:33 --> Language Class Initialized
INFO - 2018-07-13 05:07:33 --> Language Class Initialized
INFO - 2018-07-13 05:07:33 --> Config Class Initialized
INFO - 2018-07-13 05:07:33 --> Loader Class Initialized
DEBUG - 2018-07-13 05:07:33 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-13 05:07:33 --> Helper loaded: url_helper
INFO - 2018-07-13 05:07:33 --> Helper loaded: form_helper
INFO - 2018-07-13 05:07:33 --> Helper loaded: date_helper
INFO - 2018-07-13 05:07:33 --> Helper loaded: util_helper
INFO - 2018-07-13 05:07:33 --> Helper loaded: text_helper
INFO - 2018-07-13 05:07:33 --> Helper loaded: string_helper
INFO - 2018-07-13 05:07:33 --> Database Driver Class Initialized
DEBUG - 2018-07-13 05:07:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 05:07:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 05:07:33 --> Email Class Initialized
INFO - 2018-07-13 05:07:33 --> Controller Class Initialized
DEBUG - 2018-07-13 05:07:33 --> Users MX_Controller Initialized
DEBUG - 2018-07-13 05:07:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-13 05:07:33 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-13 05:07:33 --> Login MX_Controller Initialized
INFO - 2018-07-13 05:07:33 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-13 05:07:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-13 05:07:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-13 05:07:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-13 05:07:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-13 05:07:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-13 05:07:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-13 05:07:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-07-13 05:07:33 --> Final output sent to browser
DEBUG - 2018-07-13 05:07:33 --> Total execution time: 0.5397
INFO - 2018-07-13 05:07:35 --> Config Class Initialized
INFO - 2018-07-13 05:07:35 --> Hooks Class Initialized
DEBUG - 2018-07-13 05:07:35 --> UTF-8 Support Enabled
INFO - 2018-07-13 05:07:35 --> Utf8 Class Initialized
INFO - 2018-07-13 05:07:35 --> URI Class Initialized
INFO - 2018-07-13 05:07:35 --> Router Class Initialized
INFO - 2018-07-13 05:07:35 --> Output Class Initialized
INFO - 2018-07-13 05:07:35 --> Security Class Initialized
DEBUG - 2018-07-13 05:07:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 05:07:35 --> Input Class Initialized
INFO - 2018-07-13 05:07:35 --> Language Class Initialized
INFO - 2018-07-13 05:07:35 --> Language Class Initialized
INFO - 2018-07-13 05:07:35 --> Config Class Initialized
INFO - 2018-07-13 05:07:35 --> Loader Class Initialized
DEBUG - 2018-07-13 05:07:35 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-13 05:07:35 --> Helper loaded: url_helper
INFO - 2018-07-13 05:07:35 --> Helper loaded: form_helper
INFO - 2018-07-13 05:07:35 --> Helper loaded: date_helper
INFO - 2018-07-13 05:07:35 --> Helper loaded: util_helper
INFO - 2018-07-13 05:07:35 --> Helper loaded: text_helper
INFO - 2018-07-13 05:07:35 --> Helper loaded: string_helper
INFO - 2018-07-13 05:07:35 --> Database Driver Class Initialized
DEBUG - 2018-07-13 05:07:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 05:07:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 05:07:35 --> Email Class Initialized
INFO - 2018-07-13 05:07:35 --> Controller Class Initialized
DEBUG - 2018-07-13 05:07:35 --> Users MX_Controller Initialized
DEBUG - 2018-07-13 05:07:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-13 05:07:35 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-13 05:07:35 --> Login MX_Controller Initialized
INFO - 2018-07-13 05:07:35 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-13 05:07:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-13 05:07:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-13 05:07:36 --> Final output sent to browser
DEBUG - 2018-07-13 05:07:36 --> Total execution time: 0.8141
INFO - 2018-07-13 05:11:28 --> Config Class Initialized
INFO - 2018-07-13 05:11:28 --> Hooks Class Initialized
DEBUG - 2018-07-13 05:11:28 --> UTF-8 Support Enabled
INFO - 2018-07-13 05:11:28 --> Utf8 Class Initialized
INFO - 2018-07-13 05:11:28 --> URI Class Initialized
INFO - 2018-07-13 05:11:28 --> Router Class Initialized
INFO - 2018-07-13 05:11:28 --> Output Class Initialized
INFO - 2018-07-13 05:11:28 --> Security Class Initialized
DEBUG - 2018-07-13 05:11:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 05:11:28 --> Input Class Initialized
INFO - 2018-07-13 05:11:28 --> Language Class Initialized
INFO - 2018-07-13 05:11:28 --> Language Class Initialized
INFO - 2018-07-13 05:11:28 --> Config Class Initialized
INFO - 2018-07-13 05:11:28 --> Loader Class Initialized
DEBUG - 2018-07-13 05:11:28 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-13 05:11:28 --> Helper loaded: url_helper
INFO - 2018-07-13 05:11:28 --> Helper loaded: form_helper
INFO - 2018-07-13 05:11:28 --> Helper loaded: date_helper
INFO - 2018-07-13 05:11:28 --> Helper loaded: util_helper
INFO - 2018-07-13 05:11:28 --> Helper loaded: text_helper
INFO - 2018-07-13 05:11:28 --> Helper loaded: string_helper
INFO - 2018-07-13 05:11:28 --> Database Driver Class Initialized
DEBUG - 2018-07-13 05:11:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 05:11:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 05:11:29 --> Email Class Initialized
INFO - 2018-07-13 05:11:29 --> Controller Class Initialized
DEBUG - 2018-07-13 05:11:29 --> Users MX_Controller Initialized
DEBUG - 2018-07-13 05:11:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-13 05:11:29 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-13 05:11:29 --> Login MX_Controller Initialized
INFO - 2018-07-13 05:11:29 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-13 05:11:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-13 05:11:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-13 05:11:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-13 05:11:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-13 05:11:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-13 05:11:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-13 05:11:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-07-13 05:11:29 --> Final output sent to browser
DEBUG - 2018-07-13 05:11:29 --> Total execution time: 0.4219
INFO - 2018-07-13 05:11:29 --> Config Class Initialized
INFO - 2018-07-13 05:11:29 --> Hooks Class Initialized
DEBUG - 2018-07-13 05:11:29 --> UTF-8 Support Enabled
INFO - 2018-07-13 05:11:29 --> Utf8 Class Initialized
INFO - 2018-07-13 05:11:29 --> URI Class Initialized
INFO - 2018-07-13 05:11:29 --> Router Class Initialized
INFO - 2018-07-13 05:11:29 --> Output Class Initialized
INFO - 2018-07-13 05:11:29 --> Security Class Initialized
DEBUG - 2018-07-13 05:11:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 05:11:29 --> Input Class Initialized
INFO - 2018-07-13 05:11:29 --> Language Class Initialized
INFO - 2018-07-13 05:11:29 --> Language Class Initialized
INFO - 2018-07-13 05:11:29 --> Config Class Initialized
INFO - 2018-07-13 05:11:29 --> Loader Class Initialized
DEBUG - 2018-07-13 05:11:29 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-13 05:11:29 --> Helper loaded: url_helper
INFO - 2018-07-13 05:11:29 --> Helper loaded: form_helper
INFO - 2018-07-13 05:11:30 --> Helper loaded: date_helper
INFO - 2018-07-13 05:11:30 --> Helper loaded: util_helper
INFO - 2018-07-13 05:11:30 --> Helper loaded: text_helper
INFO - 2018-07-13 05:11:30 --> Helper loaded: string_helper
INFO - 2018-07-13 05:11:30 --> Database Driver Class Initialized
DEBUG - 2018-07-13 05:11:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 05:11:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 05:11:30 --> Email Class Initialized
INFO - 2018-07-13 05:11:30 --> Controller Class Initialized
DEBUG - 2018-07-13 05:11:30 --> Users MX_Controller Initialized
DEBUG - 2018-07-13 05:11:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-13 05:11:30 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-13 05:11:30 --> Login MX_Controller Initialized
INFO - 2018-07-13 05:11:30 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-13 05:11:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-13 05:11:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-13 05:11:30 --> Final output sent to browser
DEBUG - 2018-07-13 05:11:30 --> Total execution time: 0.5349
INFO - 2018-07-13 05:13:03 --> Config Class Initialized
INFO - 2018-07-13 05:13:03 --> Hooks Class Initialized
DEBUG - 2018-07-13 05:13:03 --> UTF-8 Support Enabled
INFO - 2018-07-13 05:13:04 --> Utf8 Class Initialized
INFO - 2018-07-13 05:13:04 --> URI Class Initialized
INFO - 2018-07-13 05:13:04 --> Router Class Initialized
INFO - 2018-07-13 05:13:04 --> Output Class Initialized
INFO - 2018-07-13 05:13:04 --> Security Class Initialized
DEBUG - 2018-07-13 05:13:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 05:13:04 --> Input Class Initialized
INFO - 2018-07-13 05:13:04 --> Language Class Initialized
INFO - 2018-07-13 05:13:04 --> Language Class Initialized
INFO - 2018-07-13 05:13:04 --> Config Class Initialized
INFO - 2018-07-13 05:13:04 --> Loader Class Initialized
DEBUG - 2018-07-13 05:13:04 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-13 05:13:04 --> Helper loaded: url_helper
INFO - 2018-07-13 05:13:04 --> Helper loaded: form_helper
INFO - 2018-07-13 05:13:04 --> Helper loaded: date_helper
INFO - 2018-07-13 05:13:04 --> Helper loaded: util_helper
INFO - 2018-07-13 05:13:04 --> Helper loaded: text_helper
INFO - 2018-07-13 05:13:04 --> Helper loaded: string_helper
INFO - 2018-07-13 05:13:04 --> Database Driver Class Initialized
DEBUG - 2018-07-13 05:13:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 05:13:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 05:13:04 --> Email Class Initialized
INFO - 2018-07-13 05:13:04 --> Controller Class Initialized
DEBUG - 2018-07-13 05:13:04 --> Users MX_Controller Initialized
DEBUG - 2018-07-13 05:13:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-13 05:13:04 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-13 05:13:04 --> Login MX_Controller Initialized
INFO - 2018-07-13 05:13:04 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-13 05:13:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-13 05:13:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-13 05:13:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-13 05:13:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-13 05:13:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-13 05:13:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-13 05:13:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-07-13 05:13:04 --> Final output sent to browser
DEBUG - 2018-07-13 05:13:04 --> Total execution time: 0.3680
INFO - 2018-07-13 05:20:48 --> Config Class Initialized
INFO - 2018-07-13 05:20:48 --> Hooks Class Initialized
DEBUG - 2018-07-13 05:20:48 --> UTF-8 Support Enabled
INFO - 2018-07-13 05:20:48 --> Utf8 Class Initialized
INFO - 2018-07-13 05:20:48 --> URI Class Initialized
DEBUG - 2018-07-13 05:20:48 --> No URI present. Default controller set.
INFO - 2018-07-13 05:20:48 --> Router Class Initialized
INFO - 2018-07-13 05:20:48 --> Output Class Initialized
INFO - 2018-07-13 05:20:48 --> Security Class Initialized
DEBUG - 2018-07-13 05:20:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 05:20:48 --> Input Class Initialized
INFO - 2018-07-13 05:20:48 --> Language Class Initialized
INFO - 2018-07-13 05:20:48 --> Language Class Initialized
INFO - 2018-07-13 05:20:48 --> Config Class Initialized
INFO - 2018-07-13 05:20:48 --> Loader Class Initialized
DEBUG - 2018-07-13 05:20:48 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-13 05:20:48 --> Helper loaded: url_helper
INFO - 2018-07-13 05:20:48 --> Helper loaded: form_helper
INFO - 2018-07-13 05:20:48 --> Helper loaded: date_helper
INFO - 2018-07-13 05:20:48 --> Helper loaded: util_helper
INFO - 2018-07-13 05:20:48 --> Helper loaded: text_helper
INFO - 2018-07-13 05:20:48 --> Helper loaded: string_helper
INFO - 2018-07-13 05:20:48 --> Database Driver Class Initialized
DEBUG - 2018-07-13 05:20:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 05:20:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 05:20:48 --> Email Class Initialized
INFO - 2018-07-13 05:20:48 --> Controller Class Initialized
DEBUG - 2018-07-13 05:20:48 --> Home MX_Controller Initialized
DEBUG - 2018-07-13 05:20:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-13 05:20:48 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-13 05:20:48 --> Login MX_Controller Initialized
INFO - 2018-07-13 05:20:48 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-13 05:20:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-13 05:20:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-13 05:20:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-07-13 05:31:35 --> Config Class Initialized
INFO - 2018-07-13 05:31:35 --> Hooks Class Initialized
DEBUG - 2018-07-13 05:31:35 --> UTF-8 Support Enabled
INFO - 2018-07-13 05:31:35 --> Utf8 Class Initialized
INFO - 2018-07-13 05:31:35 --> URI Class Initialized
INFO - 2018-07-13 05:31:35 --> Router Class Initialized
INFO - 2018-07-13 05:31:35 --> Output Class Initialized
INFO - 2018-07-13 05:31:35 --> Security Class Initialized
DEBUG - 2018-07-13 05:31:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 05:31:35 --> Input Class Initialized
INFO - 2018-07-13 05:31:35 --> Language Class Initialized
INFO - 2018-07-13 05:31:35 --> Language Class Initialized
INFO - 2018-07-13 05:31:35 --> Config Class Initialized
INFO - 2018-07-13 05:31:35 --> Loader Class Initialized
DEBUG - 2018-07-13 05:31:35 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-13 05:31:35 --> Helper loaded: url_helper
INFO - 2018-07-13 05:31:35 --> Helper loaded: form_helper
INFO - 2018-07-13 05:31:35 --> Helper loaded: date_helper
INFO - 2018-07-13 05:31:35 --> Helper loaded: util_helper
INFO - 2018-07-13 05:31:35 --> Helper loaded: text_helper
INFO - 2018-07-13 05:31:35 --> Helper loaded: string_helper
INFO - 2018-07-13 05:31:35 --> Database Driver Class Initialized
DEBUG - 2018-07-13 05:31:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 05:31:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 05:31:36 --> Email Class Initialized
INFO - 2018-07-13 05:31:36 --> Controller Class Initialized
DEBUG - 2018-07-13 05:31:36 --> Users MX_Controller Initialized
DEBUG - 2018-07-13 05:31:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-13 05:31:36 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-13 05:31:36 --> Login MX_Controller Initialized
INFO - 2018-07-13 05:31:36 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-13 05:31:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-13 05:31:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-13 05:31:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-13 05:31:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-13 05:31:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-13 05:31:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-13 05:31:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-07-13 05:31:36 --> Final output sent to browser
DEBUG - 2018-07-13 05:31:36 --> Total execution time: 0.3838
INFO - 2018-07-13 05:31:37 --> Config Class Initialized
INFO - 2018-07-13 05:31:37 --> Hooks Class Initialized
DEBUG - 2018-07-13 05:31:37 --> UTF-8 Support Enabled
INFO - 2018-07-13 05:31:37 --> Utf8 Class Initialized
INFO - 2018-07-13 05:31:37 --> URI Class Initialized
INFO - 2018-07-13 05:31:37 --> Router Class Initialized
INFO - 2018-07-13 05:31:37 --> Output Class Initialized
INFO - 2018-07-13 05:31:37 --> Security Class Initialized
DEBUG - 2018-07-13 05:31:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 05:31:37 --> Input Class Initialized
INFO - 2018-07-13 05:31:37 --> Language Class Initialized
INFO - 2018-07-13 05:31:37 --> Language Class Initialized
INFO - 2018-07-13 05:31:37 --> Config Class Initialized
INFO - 2018-07-13 05:31:37 --> Loader Class Initialized
DEBUG - 2018-07-13 05:31:37 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-13 05:31:37 --> Helper loaded: url_helper
INFO - 2018-07-13 05:31:37 --> Helper loaded: form_helper
INFO - 2018-07-13 05:31:37 --> Helper loaded: date_helper
INFO - 2018-07-13 05:31:37 --> Helper loaded: util_helper
INFO - 2018-07-13 05:31:37 --> Helper loaded: text_helper
INFO - 2018-07-13 05:31:37 --> Helper loaded: string_helper
INFO - 2018-07-13 05:31:37 --> Database Driver Class Initialized
DEBUG - 2018-07-13 05:31:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 05:31:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 05:31:37 --> Email Class Initialized
INFO - 2018-07-13 05:31:37 --> Controller Class Initialized
DEBUG - 2018-07-13 05:31:37 --> Users MX_Controller Initialized
DEBUG - 2018-07-13 05:31:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-13 05:31:37 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-13 05:31:37 --> Login MX_Controller Initialized
INFO - 2018-07-13 05:31:37 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-13 05:31:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-13 05:31:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-13 05:31:37 --> Final output sent to browser
DEBUG - 2018-07-13 05:31:37 --> Total execution time: 0.4322
INFO - 2018-07-13 05:31:43 --> Config Class Initialized
INFO - 2018-07-13 05:31:44 --> Hooks Class Initialized
DEBUG - 2018-07-13 05:31:44 --> UTF-8 Support Enabled
INFO - 2018-07-13 05:31:44 --> Utf8 Class Initialized
INFO - 2018-07-13 05:31:44 --> URI Class Initialized
INFO - 2018-07-13 05:31:44 --> Router Class Initialized
INFO - 2018-07-13 05:31:44 --> Output Class Initialized
INFO - 2018-07-13 05:31:44 --> Security Class Initialized
DEBUG - 2018-07-13 05:31:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 05:31:44 --> Input Class Initialized
INFO - 2018-07-13 05:31:44 --> Language Class Initialized
INFO - 2018-07-13 05:31:44 --> Language Class Initialized
INFO - 2018-07-13 05:31:44 --> Config Class Initialized
INFO - 2018-07-13 05:31:44 --> Loader Class Initialized
DEBUG - 2018-07-13 05:31:44 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-13 05:31:44 --> Helper loaded: url_helper
INFO - 2018-07-13 05:31:44 --> Helper loaded: form_helper
INFO - 2018-07-13 05:31:44 --> Helper loaded: date_helper
INFO - 2018-07-13 05:31:44 --> Helper loaded: util_helper
INFO - 2018-07-13 05:31:44 --> Helper loaded: text_helper
INFO - 2018-07-13 05:31:44 --> Helper loaded: string_helper
INFO - 2018-07-13 05:31:44 --> Database Driver Class Initialized
DEBUG - 2018-07-13 05:31:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 05:31:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 05:31:44 --> Email Class Initialized
INFO - 2018-07-13 05:31:44 --> Controller Class Initialized
DEBUG - 2018-07-13 05:31:44 --> Users MX_Controller Initialized
DEBUG - 2018-07-13 05:31:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-13 05:31:44 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-13 05:31:44 --> Login MX_Controller Initialized
INFO - 2018-07-13 05:31:44 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-13 05:31:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-13 05:31:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-13 05:31:44 --> Final output sent to browser
DEBUG - 2018-07-13 05:31:44 --> Total execution time: 0.3758
INFO - 2018-07-13 05:31:45 --> Config Class Initialized
INFO - 2018-07-13 05:31:45 --> Hooks Class Initialized
DEBUG - 2018-07-13 05:31:45 --> UTF-8 Support Enabled
INFO - 2018-07-13 05:31:45 --> Utf8 Class Initialized
INFO - 2018-07-13 05:31:45 --> URI Class Initialized
INFO - 2018-07-13 05:31:45 --> Router Class Initialized
INFO - 2018-07-13 05:31:45 --> Output Class Initialized
INFO - 2018-07-13 05:31:45 --> Security Class Initialized
DEBUG - 2018-07-13 05:31:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 05:31:45 --> Input Class Initialized
INFO - 2018-07-13 05:31:45 --> Language Class Initialized
INFO - 2018-07-13 05:31:45 --> Language Class Initialized
INFO - 2018-07-13 05:31:45 --> Config Class Initialized
INFO - 2018-07-13 05:31:45 --> Loader Class Initialized
DEBUG - 2018-07-13 05:31:45 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-13 05:31:45 --> Helper loaded: url_helper
INFO - 2018-07-13 05:31:46 --> Helper loaded: form_helper
INFO - 2018-07-13 05:31:46 --> Helper loaded: date_helper
INFO - 2018-07-13 05:31:46 --> Helper loaded: util_helper
INFO - 2018-07-13 05:31:46 --> Helper loaded: text_helper
INFO - 2018-07-13 05:31:46 --> Helper loaded: string_helper
INFO - 2018-07-13 05:31:46 --> Database Driver Class Initialized
DEBUG - 2018-07-13 05:31:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 05:31:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 05:31:46 --> Email Class Initialized
INFO - 2018-07-13 05:31:46 --> Controller Class Initialized
DEBUG - 2018-07-13 05:31:46 --> Users MX_Controller Initialized
DEBUG - 2018-07-13 05:31:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-13 05:31:46 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-13 05:31:46 --> Login MX_Controller Initialized
INFO - 2018-07-13 05:31:46 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-13 05:31:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-13 05:31:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-13 05:31:46 --> Final output sent to browser
DEBUG - 2018-07-13 05:31:46 --> Total execution time: 0.3426
INFO - 2018-07-13 05:31:48 --> Config Class Initialized
INFO - 2018-07-13 05:31:48 --> Hooks Class Initialized
DEBUG - 2018-07-13 05:31:48 --> UTF-8 Support Enabled
INFO - 2018-07-13 05:31:48 --> Utf8 Class Initialized
INFO - 2018-07-13 05:31:48 --> URI Class Initialized
INFO - 2018-07-13 05:31:48 --> Router Class Initialized
INFO - 2018-07-13 05:31:48 --> Output Class Initialized
INFO - 2018-07-13 05:31:48 --> Security Class Initialized
DEBUG - 2018-07-13 05:31:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 05:31:48 --> Input Class Initialized
INFO - 2018-07-13 05:31:48 --> Language Class Initialized
INFO - 2018-07-13 05:31:48 --> Language Class Initialized
INFO - 2018-07-13 05:31:48 --> Config Class Initialized
INFO - 2018-07-13 05:31:48 --> Loader Class Initialized
DEBUG - 2018-07-13 05:31:48 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-13 05:31:48 --> Helper loaded: url_helper
INFO - 2018-07-13 05:31:48 --> Helper loaded: form_helper
INFO - 2018-07-13 05:31:48 --> Helper loaded: date_helper
INFO - 2018-07-13 05:31:48 --> Helper loaded: util_helper
INFO - 2018-07-13 05:31:48 --> Helper loaded: text_helper
INFO - 2018-07-13 05:31:48 --> Helper loaded: string_helper
INFO - 2018-07-13 05:31:48 --> Database Driver Class Initialized
DEBUG - 2018-07-13 05:31:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 05:31:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 05:31:48 --> Email Class Initialized
INFO - 2018-07-13 05:31:48 --> Controller Class Initialized
DEBUG - 2018-07-13 05:31:48 --> Users MX_Controller Initialized
DEBUG - 2018-07-13 05:31:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-13 05:31:48 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-13 05:31:48 --> Login MX_Controller Initialized
INFO - 2018-07-13 05:31:48 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-13 05:31:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-13 05:31:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-13 05:31:48 --> Final output sent to browser
DEBUG - 2018-07-13 05:31:48 --> Total execution time: 0.3400
INFO - 2018-07-13 05:31:51 --> Config Class Initialized
INFO - 2018-07-13 05:31:51 --> Hooks Class Initialized
DEBUG - 2018-07-13 05:31:51 --> UTF-8 Support Enabled
INFO - 2018-07-13 05:31:51 --> Utf8 Class Initialized
INFO - 2018-07-13 05:31:51 --> URI Class Initialized
INFO - 2018-07-13 05:31:51 --> Router Class Initialized
INFO - 2018-07-13 05:31:51 --> Output Class Initialized
INFO - 2018-07-13 05:31:51 --> Security Class Initialized
DEBUG - 2018-07-13 05:31:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 05:31:51 --> Input Class Initialized
INFO - 2018-07-13 05:31:51 --> Language Class Initialized
INFO - 2018-07-13 05:31:51 --> Language Class Initialized
INFO - 2018-07-13 05:31:51 --> Config Class Initialized
INFO - 2018-07-13 05:31:51 --> Loader Class Initialized
DEBUG - 2018-07-13 05:31:51 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-13 05:31:51 --> Helper loaded: url_helper
INFO - 2018-07-13 05:31:51 --> Helper loaded: form_helper
INFO - 2018-07-13 05:31:51 --> Helper loaded: date_helper
INFO - 2018-07-13 05:31:51 --> Helper loaded: util_helper
INFO - 2018-07-13 05:31:51 --> Helper loaded: text_helper
INFO - 2018-07-13 05:31:51 --> Helper loaded: string_helper
INFO - 2018-07-13 05:31:51 --> Database Driver Class Initialized
DEBUG - 2018-07-13 05:31:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 05:31:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 05:31:51 --> Email Class Initialized
INFO - 2018-07-13 05:31:51 --> Controller Class Initialized
DEBUG - 2018-07-13 05:31:51 --> Users MX_Controller Initialized
DEBUG - 2018-07-13 05:31:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-13 05:31:51 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-13 05:31:51 --> Login MX_Controller Initialized
INFO - 2018-07-13 05:31:51 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-13 05:31:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-13 05:31:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-13 05:31:51 --> Final output sent to browser
DEBUG - 2018-07-13 05:31:51 --> Total execution time: 0.3446
INFO - 2018-07-13 05:31:52 --> Config Class Initialized
INFO - 2018-07-13 05:31:52 --> Hooks Class Initialized
DEBUG - 2018-07-13 05:31:52 --> UTF-8 Support Enabled
INFO - 2018-07-13 05:31:52 --> Utf8 Class Initialized
INFO - 2018-07-13 05:31:52 --> URI Class Initialized
INFO - 2018-07-13 05:31:52 --> Router Class Initialized
INFO - 2018-07-13 05:31:52 --> Output Class Initialized
INFO - 2018-07-13 05:31:52 --> Security Class Initialized
DEBUG - 2018-07-13 05:31:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 05:31:52 --> Input Class Initialized
INFO - 2018-07-13 05:31:52 --> Language Class Initialized
INFO - 2018-07-13 05:31:52 --> Language Class Initialized
INFO - 2018-07-13 05:31:52 --> Config Class Initialized
INFO - 2018-07-13 05:31:52 --> Loader Class Initialized
DEBUG - 2018-07-13 05:31:52 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-13 05:31:52 --> Helper loaded: url_helper
INFO - 2018-07-13 05:31:52 --> Helper loaded: form_helper
INFO - 2018-07-13 05:31:52 --> Helper loaded: date_helper
INFO - 2018-07-13 05:31:52 --> Helper loaded: util_helper
INFO - 2018-07-13 05:31:52 --> Helper loaded: text_helper
INFO - 2018-07-13 05:31:52 --> Helper loaded: string_helper
INFO - 2018-07-13 05:31:52 --> Database Driver Class Initialized
DEBUG - 2018-07-13 05:31:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 05:31:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 05:31:52 --> Email Class Initialized
INFO - 2018-07-13 05:31:52 --> Controller Class Initialized
DEBUG - 2018-07-13 05:31:52 --> Users MX_Controller Initialized
DEBUG - 2018-07-13 05:31:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-13 05:31:52 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-13 05:31:52 --> Login MX_Controller Initialized
INFO - 2018-07-13 05:31:52 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-13 05:31:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-13 05:31:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-13 05:31:52 --> Final output sent to browser
DEBUG - 2018-07-13 05:31:52 --> Total execution time: 0.3627
INFO - 2018-07-13 05:32:07 --> Config Class Initialized
INFO - 2018-07-13 05:32:07 --> Hooks Class Initialized
DEBUG - 2018-07-13 05:32:08 --> UTF-8 Support Enabled
INFO - 2018-07-13 05:32:08 --> Utf8 Class Initialized
INFO - 2018-07-13 05:32:08 --> URI Class Initialized
INFO - 2018-07-13 05:32:08 --> Router Class Initialized
INFO - 2018-07-13 05:32:08 --> Output Class Initialized
INFO - 2018-07-13 05:32:08 --> Security Class Initialized
DEBUG - 2018-07-13 05:32:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 05:32:08 --> Input Class Initialized
INFO - 2018-07-13 05:32:08 --> Language Class Initialized
INFO - 2018-07-13 05:32:08 --> Language Class Initialized
INFO - 2018-07-13 05:32:08 --> Config Class Initialized
INFO - 2018-07-13 05:32:08 --> Loader Class Initialized
DEBUG - 2018-07-13 05:32:08 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-13 05:32:08 --> Helper loaded: url_helper
INFO - 2018-07-13 05:32:08 --> Helper loaded: form_helper
INFO - 2018-07-13 05:32:08 --> Helper loaded: date_helper
INFO - 2018-07-13 05:32:08 --> Helper loaded: util_helper
INFO - 2018-07-13 05:32:08 --> Helper loaded: text_helper
INFO - 2018-07-13 05:32:08 --> Helper loaded: string_helper
INFO - 2018-07-13 05:32:08 --> Database Driver Class Initialized
DEBUG - 2018-07-13 05:32:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 05:32:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 05:32:08 --> Email Class Initialized
INFO - 2018-07-13 05:32:08 --> Controller Class Initialized
DEBUG - 2018-07-13 05:32:08 --> Users MX_Controller Initialized
DEBUG - 2018-07-13 05:32:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-13 05:32:08 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-13 05:32:08 --> Login MX_Controller Initialized
INFO - 2018-07-13 05:32:08 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-13 05:32:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-13 05:32:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-13 05:32:08 --> Final output sent to browser
DEBUG - 2018-07-13 05:32:08 --> Total execution time: 0.3516
INFO - 2018-07-13 05:32:08 --> Config Class Initialized
INFO - 2018-07-13 05:32:08 --> Hooks Class Initialized
DEBUG - 2018-07-13 05:32:08 --> UTF-8 Support Enabled
INFO - 2018-07-13 05:32:08 --> Utf8 Class Initialized
INFO - 2018-07-13 05:32:08 --> URI Class Initialized
INFO - 2018-07-13 05:32:08 --> Router Class Initialized
INFO - 2018-07-13 05:32:08 --> Output Class Initialized
INFO - 2018-07-13 05:32:08 --> Security Class Initialized
DEBUG - 2018-07-13 05:32:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 05:32:08 --> Input Class Initialized
INFO - 2018-07-13 05:32:08 --> Language Class Initialized
INFO - 2018-07-13 05:32:08 --> Language Class Initialized
INFO - 2018-07-13 05:32:08 --> Config Class Initialized
INFO - 2018-07-13 05:32:08 --> Loader Class Initialized
DEBUG - 2018-07-13 05:32:08 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-13 05:32:08 --> Helper loaded: url_helper
INFO - 2018-07-13 05:32:08 --> Helper loaded: form_helper
INFO - 2018-07-13 05:32:08 --> Helper loaded: date_helper
INFO - 2018-07-13 05:32:08 --> Helper loaded: util_helper
INFO - 2018-07-13 05:32:08 --> Helper loaded: text_helper
INFO - 2018-07-13 05:32:08 --> Helper loaded: string_helper
INFO - 2018-07-13 05:32:08 --> Database Driver Class Initialized
DEBUG - 2018-07-13 05:32:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 05:32:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 05:32:08 --> Email Class Initialized
INFO - 2018-07-13 05:32:08 --> Controller Class Initialized
DEBUG - 2018-07-13 05:32:08 --> Users MX_Controller Initialized
DEBUG - 2018-07-13 05:32:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-13 05:32:08 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-13 05:32:08 --> Login MX_Controller Initialized
INFO - 2018-07-13 05:32:08 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-13 05:32:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-13 05:32:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-13 05:32:08 --> Final output sent to browser
DEBUG - 2018-07-13 05:32:08 --> Total execution time: 0.3288
INFO - 2018-07-13 05:32:10 --> Config Class Initialized
INFO - 2018-07-13 05:32:10 --> Hooks Class Initialized
DEBUG - 2018-07-13 05:32:10 --> UTF-8 Support Enabled
INFO - 2018-07-13 05:32:10 --> Utf8 Class Initialized
INFO - 2018-07-13 05:32:10 --> URI Class Initialized
INFO - 2018-07-13 05:32:10 --> Router Class Initialized
INFO - 2018-07-13 05:32:10 --> Output Class Initialized
INFO - 2018-07-13 05:32:10 --> Security Class Initialized
DEBUG - 2018-07-13 05:32:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 05:32:11 --> Input Class Initialized
INFO - 2018-07-13 05:32:11 --> Language Class Initialized
INFO - 2018-07-13 05:32:11 --> Language Class Initialized
INFO - 2018-07-13 05:32:11 --> Config Class Initialized
INFO - 2018-07-13 05:32:11 --> Loader Class Initialized
DEBUG - 2018-07-13 05:32:11 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-13 05:32:11 --> Helper loaded: url_helper
INFO - 2018-07-13 05:32:11 --> Helper loaded: form_helper
INFO - 2018-07-13 05:32:11 --> Helper loaded: date_helper
INFO - 2018-07-13 05:32:11 --> Helper loaded: util_helper
INFO - 2018-07-13 05:32:11 --> Helper loaded: text_helper
INFO - 2018-07-13 05:32:11 --> Helper loaded: string_helper
INFO - 2018-07-13 05:32:11 --> Database Driver Class Initialized
DEBUG - 2018-07-13 05:32:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 05:32:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 05:32:11 --> Email Class Initialized
INFO - 2018-07-13 05:32:11 --> Controller Class Initialized
DEBUG - 2018-07-13 05:32:11 --> Users MX_Controller Initialized
DEBUG - 2018-07-13 05:32:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-13 05:32:11 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-13 05:32:11 --> Login MX_Controller Initialized
INFO - 2018-07-13 05:32:11 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-13 05:32:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-13 05:32:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-13 05:32:11 --> Final output sent to browser
DEBUG - 2018-07-13 05:32:11 --> Total execution time: 0.3597
INFO - 2018-07-13 05:32:21 --> Config Class Initialized
INFO - 2018-07-13 05:32:21 --> Hooks Class Initialized
DEBUG - 2018-07-13 05:32:21 --> UTF-8 Support Enabled
INFO - 2018-07-13 05:32:21 --> Utf8 Class Initialized
INFO - 2018-07-13 05:32:21 --> URI Class Initialized
INFO - 2018-07-13 05:32:21 --> Router Class Initialized
INFO - 2018-07-13 05:32:21 --> Output Class Initialized
INFO - 2018-07-13 05:32:21 --> Security Class Initialized
DEBUG - 2018-07-13 05:32:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 05:32:21 --> Input Class Initialized
INFO - 2018-07-13 05:32:21 --> Language Class Initialized
INFO - 2018-07-13 05:32:21 --> Language Class Initialized
INFO - 2018-07-13 05:32:21 --> Config Class Initialized
INFO - 2018-07-13 05:32:21 --> Loader Class Initialized
DEBUG - 2018-07-13 05:32:21 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-13 05:32:21 --> Helper loaded: url_helper
INFO - 2018-07-13 05:32:21 --> Helper loaded: form_helper
INFO - 2018-07-13 05:32:21 --> Helper loaded: date_helper
INFO - 2018-07-13 05:32:21 --> Helper loaded: util_helper
INFO - 2018-07-13 05:32:21 --> Helper loaded: text_helper
INFO - 2018-07-13 05:32:21 --> Helper loaded: string_helper
INFO - 2018-07-13 05:32:21 --> Database Driver Class Initialized
DEBUG - 2018-07-13 05:32:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 05:32:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 05:32:21 --> Email Class Initialized
INFO - 2018-07-13 05:32:21 --> Controller Class Initialized
DEBUG - 2018-07-13 05:32:21 --> Admin MX_Controller Initialized
INFO - 2018-07-13 05:32:21 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-13 05:32:21 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-13 05:32:21 --> Login MX_Controller Initialized
DEBUG - 2018-07-13 05:32:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-13 05:32:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-13 05:32:21 --> Final output sent to browser
DEBUG - 2018-07-13 05:32:21 --> Total execution time: 0.4538
INFO - 2018-07-13 05:32:22 --> Config Class Initialized
INFO - 2018-07-13 05:32:22 --> Hooks Class Initialized
DEBUG - 2018-07-13 05:32:22 --> UTF-8 Support Enabled
INFO - 2018-07-13 05:32:22 --> Utf8 Class Initialized
INFO - 2018-07-13 05:32:22 --> URI Class Initialized
INFO - 2018-07-13 05:32:22 --> Router Class Initialized
INFO - 2018-07-13 05:32:22 --> Output Class Initialized
INFO - 2018-07-13 05:32:22 --> Security Class Initialized
DEBUG - 2018-07-13 05:32:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 05:32:22 --> Input Class Initialized
INFO - 2018-07-13 05:32:22 --> Language Class Initialized
INFO - 2018-07-13 05:32:22 --> Language Class Initialized
INFO - 2018-07-13 05:32:22 --> Config Class Initialized
INFO - 2018-07-13 05:32:22 --> Loader Class Initialized
DEBUG - 2018-07-13 05:32:22 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-13 05:32:22 --> Helper loaded: url_helper
INFO - 2018-07-13 05:32:22 --> Helper loaded: form_helper
INFO - 2018-07-13 05:32:22 --> Helper loaded: date_helper
INFO - 2018-07-13 05:32:22 --> Helper loaded: util_helper
INFO - 2018-07-13 05:32:22 --> Helper loaded: text_helper
INFO - 2018-07-13 05:32:22 --> Helper loaded: string_helper
INFO - 2018-07-13 05:32:22 --> Database Driver Class Initialized
DEBUG - 2018-07-13 05:32:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 05:32:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 05:32:23 --> Email Class Initialized
INFO - 2018-07-13 05:32:23 --> Controller Class Initialized
DEBUG - 2018-07-13 05:32:23 --> Admin MX_Controller Initialized
INFO - 2018-07-13 05:32:23 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-13 05:32:23 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-13 05:32:23 --> Login MX_Controller Initialized
DEBUG - 2018-07-13 05:32:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-13 05:32:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-13 05:32:23 --> Final output sent to browser
DEBUG - 2018-07-13 05:32:23 --> Total execution time: 0.3932
INFO - 2018-07-13 05:32:24 --> Config Class Initialized
INFO - 2018-07-13 05:32:24 --> Hooks Class Initialized
DEBUG - 2018-07-13 05:32:24 --> UTF-8 Support Enabled
INFO - 2018-07-13 05:32:24 --> Utf8 Class Initialized
INFO - 2018-07-13 05:32:24 --> URI Class Initialized
INFO - 2018-07-13 05:32:24 --> Router Class Initialized
INFO - 2018-07-13 05:32:24 --> Output Class Initialized
INFO - 2018-07-13 05:32:24 --> Security Class Initialized
DEBUG - 2018-07-13 05:32:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 05:32:24 --> Input Class Initialized
INFO - 2018-07-13 05:32:24 --> Language Class Initialized
INFO - 2018-07-13 05:32:24 --> Language Class Initialized
INFO - 2018-07-13 05:32:24 --> Config Class Initialized
INFO - 2018-07-13 05:32:24 --> Loader Class Initialized
DEBUG - 2018-07-13 05:32:24 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-13 05:32:24 --> Helper loaded: url_helper
INFO - 2018-07-13 05:32:24 --> Helper loaded: form_helper
INFO - 2018-07-13 05:32:24 --> Helper loaded: date_helper
INFO - 2018-07-13 05:32:24 --> Helper loaded: util_helper
INFO - 2018-07-13 05:32:24 --> Helper loaded: text_helper
INFO - 2018-07-13 05:32:24 --> Helper loaded: string_helper
INFO - 2018-07-13 05:32:24 --> Database Driver Class Initialized
DEBUG - 2018-07-13 05:32:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 05:32:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 05:32:24 --> Email Class Initialized
INFO - 2018-07-13 05:32:24 --> Controller Class Initialized
DEBUG - 2018-07-13 05:32:24 --> Admin MX_Controller Initialized
INFO - 2018-07-13 05:32:24 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-13 05:32:24 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-13 05:32:24 --> Login MX_Controller Initialized
DEBUG - 2018-07-13 05:32:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-13 05:32:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-13 05:32:24 --> Final output sent to browser
DEBUG - 2018-07-13 05:32:24 --> Total execution time: 0.4061
INFO - 2018-07-13 05:32:25 --> Config Class Initialized
INFO - 2018-07-13 05:32:25 --> Hooks Class Initialized
DEBUG - 2018-07-13 05:32:25 --> UTF-8 Support Enabled
INFO - 2018-07-13 05:32:25 --> Utf8 Class Initialized
INFO - 2018-07-13 05:32:25 --> URI Class Initialized
INFO - 2018-07-13 05:32:25 --> Router Class Initialized
INFO - 2018-07-13 05:32:25 --> Output Class Initialized
INFO - 2018-07-13 05:32:25 --> Security Class Initialized
DEBUG - 2018-07-13 05:32:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 05:32:25 --> Input Class Initialized
INFO - 2018-07-13 05:32:25 --> Language Class Initialized
INFO - 2018-07-13 05:32:25 --> Language Class Initialized
INFO - 2018-07-13 05:32:25 --> Config Class Initialized
INFO - 2018-07-13 05:32:25 --> Loader Class Initialized
DEBUG - 2018-07-13 05:32:25 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-13 05:32:25 --> Helper loaded: url_helper
INFO - 2018-07-13 05:32:25 --> Helper loaded: form_helper
INFO - 2018-07-13 05:32:25 --> Helper loaded: date_helper
INFO - 2018-07-13 05:32:25 --> Helper loaded: util_helper
INFO - 2018-07-13 05:32:25 --> Helper loaded: text_helper
INFO - 2018-07-13 05:32:25 --> Helper loaded: string_helper
INFO - 2018-07-13 05:32:25 --> Database Driver Class Initialized
DEBUG - 2018-07-13 05:32:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 05:32:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 05:32:25 --> Email Class Initialized
INFO - 2018-07-13 05:32:25 --> Controller Class Initialized
DEBUG - 2018-07-13 05:32:25 --> Admin MX_Controller Initialized
INFO - 2018-07-13 05:32:25 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-13 05:32:25 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-13 05:32:25 --> Login MX_Controller Initialized
DEBUG - 2018-07-13 05:32:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-13 05:32:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-13 05:32:25 --> Final output sent to browser
DEBUG - 2018-07-13 05:32:25 --> Total execution time: 0.4206
INFO - 2018-07-13 05:32:31 --> Config Class Initialized
INFO - 2018-07-13 05:32:31 --> Hooks Class Initialized
DEBUG - 2018-07-13 05:32:31 --> UTF-8 Support Enabled
INFO - 2018-07-13 05:32:32 --> Utf8 Class Initialized
INFO - 2018-07-13 05:32:32 --> URI Class Initialized
INFO - 2018-07-13 05:32:32 --> Router Class Initialized
INFO - 2018-07-13 05:32:32 --> Output Class Initialized
INFO - 2018-07-13 05:32:32 --> Security Class Initialized
DEBUG - 2018-07-13 05:32:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 05:32:32 --> Input Class Initialized
INFO - 2018-07-13 05:32:32 --> Language Class Initialized
INFO - 2018-07-13 05:32:32 --> Language Class Initialized
INFO - 2018-07-13 05:32:32 --> Config Class Initialized
INFO - 2018-07-13 05:32:32 --> Loader Class Initialized
DEBUG - 2018-07-13 05:32:32 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-13 05:32:32 --> Helper loaded: url_helper
INFO - 2018-07-13 05:32:32 --> Helper loaded: form_helper
INFO - 2018-07-13 05:32:32 --> Helper loaded: date_helper
INFO - 2018-07-13 05:32:32 --> Helper loaded: util_helper
INFO - 2018-07-13 05:32:32 --> Helper loaded: text_helper
INFO - 2018-07-13 05:32:32 --> Helper loaded: string_helper
INFO - 2018-07-13 05:32:32 --> Database Driver Class Initialized
DEBUG - 2018-07-13 05:32:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 05:32:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 05:32:32 --> Email Class Initialized
INFO - 2018-07-13 05:32:32 --> Controller Class Initialized
DEBUG - 2018-07-13 05:32:32 --> Admin MX_Controller Initialized
INFO - 2018-07-13 05:32:32 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-13 05:32:32 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-13 05:32:32 --> Login MX_Controller Initialized
DEBUG - 2018-07-13 05:32:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-13 05:32:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-13 05:32:32 --> Final output sent to browser
DEBUG - 2018-07-13 05:32:32 --> Total execution time: 0.4097
INFO - 2018-07-13 05:32:32 --> Config Class Initialized
INFO - 2018-07-13 05:32:33 --> Hooks Class Initialized
DEBUG - 2018-07-13 05:32:33 --> UTF-8 Support Enabled
INFO - 2018-07-13 05:32:33 --> Utf8 Class Initialized
INFO - 2018-07-13 05:32:33 --> URI Class Initialized
INFO - 2018-07-13 05:32:33 --> Router Class Initialized
INFO - 2018-07-13 05:32:33 --> Output Class Initialized
INFO - 2018-07-13 05:32:33 --> Security Class Initialized
DEBUG - 2018-07-13 05:32:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 05:32:33 --> Input Class Initialized
INFO - 2018-07-13 05:32:33 --> Language Class Initialized
INFO - 2018-07-13 05:32:33 --> Language Class Initialized
INFO - 2018-07-13 05:32:33 --> Config Class Initialized
INFO - 2018-07-13 05:32:33 --> Loader Class Initialized
DEBUG - 2018-07-13 05:32:33 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-13 05:32:33 --> Helper loaded: url_helper
INFO - 2018-07-13 05:32:33 --> Helper loaded: form_helper
INFO - 2018-07-13 05:32:33 --> Helper loaded: date_helper
INFO - 2018-07-13 05:32:33 --> Helper loaded: util_helper
INFO - 2018-07-13 05:32:33 --> Helper loaded: text_helper
INFO - 2018-07-13 05:32:33 --> Helper loaded: string_helper
INFO - 2018-07-13 05:32:33 --> Database Driver Class Initialized
DEBUG - 2018-07-13 05:32:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 05:32:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 05:32:33 --> Email Class Initialized
INFO - 2018-07-13 05:32:33 --> Controller Class Initialized
DEBUG - 2018-07-13 05:32:33 --> Admin MX_Controller Initialized
INFO - 2018-07-13 05:32:33 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-13 05:32:33 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-13 05:32:33 --> Login MX_Controller Initialized
DEBUG - 2018-07-13 05:32:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-13 05:32:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-13 05:32:33 --> Final output sent to browser
DEBUG - 2018-07-13 05:32:33 --> Total execution time: 0.3904
INFO - 2018-07-13 21:41:11 --> Config Class Initialized
INFO - 2018-07-13 21:41:11 --> Hooks Class Initialized
DEBUG - 2018-07-13 21:41:11 --> UTF-8 Support Enabled
INFO - 2018-07-13 21:41:11 --> Utf8 Class Initialized
INFO - 2018-07-13 21:41:11 --> URI Class Initialized
INFO - 2018-07-13 21:41:11 --> Router Class Initialized
INFO - 2018-07-13 21:41:11 --> Output Class Initialized
INFO - 2018-07-13 21:41:11 --> Security Class Initialized
DEBUG - 2018-07-13 21:41:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 21:41:11 --> Input Class Initialized
INFO - 2018-07-13 21:41:11 --> Language Class Initialized
INFO - 2018-07-13 21:41:11 --> Language Class Initialized
INFO - 2018-07-13 21:41:11 --> Config Class Initialized
INFO - 2018-07-13 21:41:12 --> Loader Class Initialized
DEBUG - 2018-07-13 21:41:12 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-13 21:41:12 --> Helper loaded: url_helper
INFO - 2018-07-13 21:41:12 --> Helper loaded: form_helper
INFO - 2018-07-13 21:41:12 --> Helper loaded: date_helper
INFO - 2018-07-13 21:41:12 --> Helper loaded: util_helper
INFO - 2018-07-13 21:41:12 --> Helper loaded: text_helper
INFO - 2018-07-13 21:41:12 --> Helper loaded: string_helper
INFO - 2018-07-13 21:41:12 --> Database Driver Class Initialized
DEBUG - 2018-07-13 21:41:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 21:41:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 21:41:14 --> Email Class Initialized
INFO - 2018-07-13 21:41:14 --> Controller Class Initialized
DEBUG - 2018-07-13 21:41:14 --> Users MX_Controller Initialized
DEBUG - 2018-07-13 21:41:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-13 21:41:14 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-13 21:41:14 --> Login MX_Controller Initialized
INFO - 2018-07-13 21:41:14 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-13 21:41:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-13 21:41:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
INFO - 2018-07-13 21:41:15 --> Config Class Initialized
INFO - 2018-07-13 21:41:15 --> Hooks Class Initialized
DEBUG - 2018-07-13 21:41:15 --> UTF-8 Support Enabled
INFO - 2018-07-13 21:41:15 --> Utf8 Class Initialized
INFO - 2018-07-13 21:41:15 --> URI Class Initialized
INFO - 2018-07-13 21:41:15 --> Router Class Initialized
INFO - 2018-07-13 21:41:15 --> Output Class Initialized
INFO - 2018-07-13 21:41:15 --> Security Class Initialized
DEBUG - 2018-07-13 21:41:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 21:41:15 --> Input Class Initialized
INFO - 2018-07-13 21:41:15 --> Language Class Initialized
ERROR - 2018-07-13 21:41:16 --> 404 Page Not Found: /index
INFO - 2018-07-13 21:41:17 --> Config Class Initialized
INFO - 2018-07-13 21:41:17 --> Hooks Class Initialized
DEBUG - 2018-07-13 21:41:17 --> UTF-8 Support Enabled
INFO - 2018-07-13 21:41:17 --> Utf8 Class Initialized
INFO - 2018-07-13 21:41:17 --> URI Class Initialized
INFO - 2018-07-13 21:41:17 --> Router Class Initialized
INFO - 2018-07-13 21:41:17 --> Output Class Initialized
INFO - 2018-07-13 21:41:17 --> Security Class Initialized
DEBUG - 2018-07-13 21:41:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 21:41:17 --> Input Class Initialized
INFO - 2018-07-13 21:41:17 --> Language Class Initialized
ERROR - 2018-07-13 21:41:17 --> 404 Page Not Found: /index
INFO - 2018-07-13 21:46:30 --> Config Class Initialized
INFO - 2018-07-13 21:46:30 --> Hooks Class Initialized
DEBUG - 2018-07-13 21:46:30 --> UTF-8 Support Enabled
INFO - 2018-07-13 21:46:30 --> Utf8 Class Initialized
INFO - 2018-07-13 21:46:30 --> URI Class Initialized
INFO - 2018-07-13 21:46:30 --> Router Class Initialized
INFO - 2018-07-13 21:46:30 --> Output Class Initialized
INFO - 2018-07-13 21:46:30 --> Security Class Initialized
DEBUG - 2018-07-13 21:46:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 21:46:30 --> Input Class Initialized
INFO - 2018-07-13 21:46:30 --> Language Class Initialized
INFO - 2018-07-13 21:46:30 --> Language Class Initialized
INFO - 2018-07-13 21:46:30 --> Config Class Initialized
INFO - 2018-07-13 21:46:30 --> Loader Class Initialized
DEBUG - 2018-07-13 21:46:30 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-13 21:46:30 --> Helper loaded: url_helper
INFO - 2018-07-13 21:46:30 --> Helper loaded: form_helper
INFO - 2018-07-13 21:46:30 --> Helper loaded: date_helper
INFO - 2018-07-13 21:46:30 --> Helper loaded: util_helper
INFO - 2018-07-13 21:46:30 --> Helper loaded: text_helper
INFO - 2018-07-13 21:46:30 --> Helper loaded: string_helper
INFO - 2018-07-13 21:46:30 --> Database Driver Class Initialized
DEBUG - 2018-07-13 21:46:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 21:46:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 21:46:30 --> Email Class Initialized
INFO - 2018-07-13 21:46:30 --> Controller Class Initialized
DEBUG - 2018-07-13 21:46:30 --> Login MX_Controller Initialized
INFO - 2018-07-13 21:46:30 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-13 21:46:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-13 21:46:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-13 21:46:30 --> Email starts for admin@colin.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-07-13 21:46:30 --> User session created for 1
INFO - 2018-07-13 21:46:30 --> Login status admin@colin.com - success
INFO - 2018-07-13 21:46:30 --> Final output sent to browser
DEBUG - 2018-07-13 21:46:30 --> Total execution time: 0.4670
INFO - 2018-07-13 21:46:30 --> Config Class Initialized
INFO - 2018-07-13 21:46:30 --> Hooks Class Initialized
DEBUG - 2018-07-13 21:46:30 --> UTF-8 Support Enabled
INFO - 2018-07-13 21:46:30 --> Utf8 Class Initialized
INFO - 2018-07-13 21:46:30 --> URI Class Initialized
INFO - 2018-07-13 21:46:30 --> Router Class Initialized
INFO - 2018-07-13 21:46:30 --> Output Class Initialized
INFO - 2018-07-13 21:46:30 --> Security Class Initialized
DEBUG - 2018-07-13 21:46:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 21:46:30 --> Input Class Initialized
INFO - 2018-07-13 21:46:30 --> Language Class Initialized
INFO - 2018-07-13 21:46:30 --> Language Class Initialized
INFO - 2018-07-13 21:46:30 --> Config Class Initialized
INFO - 2018-07-13 21:46:30 --> Loader Class Initialized
DEBUG - 2018-07-13 21:46:30 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-13 21:46:30 --> Helper loaded: url_helper
INFO - 2018-07-13 21:46:30 --> Helper loaded: form_helper
INFO - 2018-07-13 21:46:30 --> Helper loaded: date_helper
INFO - 2018-07-13 21:46:30 --> Helper loaded: util_helper
INFO - 2018-07-13 21:46:30 --> Helper loaded: text_helper
INFO - 2018-07-13 21:46:30 --> Helper loaded: string_helper
INFO - 2018-07-13 21:46:30 --> Database Driver Class Initialized
DEBUG - 2018-07-13 21:46:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 21:46:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 21:46:30 --> Email Class Initialized
INFO - 2018-07-13 21:46:30 --> Controller Class Initialized
DEBUG - 2018-07-13 21:46:30 --> Users MX_Controller Initialized
DEBUG - 2018-07-13 21:46:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-13 21:46:30 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-13 21:46:30 --> Login MX_Controller Initialized
INFO - 2018-07-13 21:46:30 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-13 21:46:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-13 21:46:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-13 21:46:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-13 21:46:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-13 21:46:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-13 21:46:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-13 21:46:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-07-13 21:46:31 --> Final output sent to browser
DEBUG - 2018-07-13 21:46:31 --> Total execution time: 0.9150
INFO - 2018-07-13 21:46:34 --> Config Class Initialized
INFO - 2018-07-13 21:46:34 --> Hooks Class Initialized
DEBUG - 2018-07-13 21:46:34 --> UTF-8 Support Enabled
INFO - 2018-07-13 21:46:34 --> Utf8 Class Initialized
INFO - 2018-07-13 21:46:34 --> URI Class Initialized
INFO - 2018-07-13 21:46:34 --> Router Class Initialized
INFO - 2018-07-13 21:46:34 --> Output Class Initialized
INFO - 2018-07-13 21:46:34 --> Security Class Initialized
DEBUG - 2018-07-13 21:46:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 21:46:34 --> Input Class Initialized
INFO - 2018-07-13 21:46:34 --> Language Class Initialized
INFO - 2018-07-13 21:46:34 --> Language Class Initialized
INFO - 2018-07-13 21:46:34 --> Config Class Initialized
INFO - 2018-07-13 21:46:34 --> Loader Class Initialized
DEBUG - 2018-07-13 21:46:34 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-13 21:46:34 --> Helper loaded: url_helper
INFO - 2018-07-13 21:46:34 --> Helper loaded: form_helper
INFO - 2018-07-13 21:46:34 --> Helper loaded: date_helper
INFO - 2018-07-13 21:46:34 --> Helper loaded: util_helper
INFO - 2018-07-13 21:46:34 --> Helper loaded: text_helper
INFO - 2018-07-13 21:46:34 --> Helper loaded: string_helper
INFO - 2018-07-13 21:46:34 --> Database Driver Class Initialized
DEBUG - 2018-07-13 21:46:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 21:46:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 21:46:34 --> Email Class Initialized
INFO - 2018-07-13 21:46:34 --> Controller Class Initialized
DEBUG - 2018-07-13 21:46:34 --> Users MX_Controller Initialized
DEBUG - 2018-07-13 21:46:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-13 21:46:34 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-13 21:46:34 --> Login MX_Controller Initialized
INFO - 2018-07-13 21:46:34 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-13 21:46:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-13 21:46:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-13 21:46:35 --> Final output sent to browser
DEBUG - 2018-07-13 21:46:35 --> Total execution time: 0.8985
INFO - 2018-07-13 22:37:21 --> Config Class Initialized
INFO - 2018-07-13 22:37:21 --> Hooks Class Initialized
DEBUG - 2018-07-13 22:37:21 --> UTF-8 Support Enabled
INFO - 2018-07-13 22:37:21 --> Utf8 Class Initialized
INFO - 2018-07-13 22:37:21 --> URI Class Initialized
INFO - 2018-07-13 22:37:21 --> Router Class Initialized
INFO - 2018-07-13 22:37:21 --> Output Class Initialized
INFO - 2018-07-13 22:37:21 --> Security Class Initialized
DEBUG - 2018-07-13 22:37:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 22:37:21 --> Input Class Initialized
INFO - 2018-07-13 22:37:21 --> Language Class Initialized
INFO - 2018-07-13 22:37:21 --> Language Class Initialized
INFO - 2018-07-13 22:37:21 --> Config Class Initialized
INFO - 2018-07-13 22:37:21 --> Loader Class Initialized
DEBUG - 2018-07-13 22:37:21 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-13 22:37:21 --> Helper loaded: url_helper
INFO - 2018-07-13 22:37:21 --> Helper loaded: form_helper
INFO - 2018-07-13 22:37:21 --> Helper loaded: date_helper
INFO - 2018-07-13 22:37:21 --> Helper loaded: util_helper
INFO - 2018-07-13 22:37:21 --> Helper loaded: text_helper
INFO - 2018-07-13 22:37:21 --> Helper loaded: string_helper
INFO - 2018-07-13 22:37:21 --> Database Driver Class Initialized
DEBUG - 2018-07-13 22:37:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 22:37:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 22:37:21 --> Email Class Initialized
INFO - 2018-07-13 22:37:21 --> Controller Class Initialized
DEBUG - 2018-07-13 22:37:21 --> Users MX_Controller Initialized
DEBUG - 2018-07-13 22:37:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-13 22:37:21 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-13 22:37:21 --> Login MX_Controller Initialized
INFO - 2018-07-13 22:37:21 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-13 22:37:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-13 22:37:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-13 22:37:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-13 22:37:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-13 22:37:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-13 22:37:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-13 22:37:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-07-13 22:37:21 --> Final output sent to browser
DEBUG - 2018-07-13 22:37:21 --> Total execution time: 0.3652
INFO - 2018-07-13 22:37:22 --> Config Class Initialized
INFO - 2018-07-13 22:37:22 --> Hooks Class Initialized
DEBUG - 2018-07-13 22:37:22 --> UTF-8 Support Enabled
INFO - 2018-07-13 22:37:22 --> Utf8 Class Initialized
INFO - 2018-07-13 22:37:22 --> URI Class Initialized
INFO - 2018-07-13 22:37:22 --> Router Class Initialized
INFO - 2018-07-13 22:37:22 --> Output Class Initialized
INFO - 2018-07-13 22:37:22 --> Security Class Initialized
DEBUG - 2018-07-13 22:37:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 22:37:22 --> Input Class Initialized
INFO - 2018-07-13 22:37:22 --> Language Class Initialized
INFO - 2018-07-13 22:37:22 --> Language Class Initialized
INFO - 2018-07-13 22:37:22 --> Config Class Initialized
INFO - 2018-07-13 22:37:22 --> Loader Class Initialized
DEBUG - 2018-07-13 22:37:22 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-13 22:37:22 --> Helper loaded: url_helper
INFO - 2018-07-13 22:37:22 --> Helper loaded: form_helper
INFO - 2018-07-13 22:37:22 --> Helper loaded: date_helper
INFO - 2018-07-13 22:37:22 --> Helper loaded: util_helper
INFO - 2018-07-13 22:37:22 --> Helper loaded: text_helper
INFO - 2018-07-13 22:37:22 --> Helper loaded: string_helper
INFO - 2018-07-13 22:37:22 --> Database Driver Class Initialized
DEBUG - 2018-07-13 22:37:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 22:37:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 22:37:22 --> Email Class Initialized
INFO - 2018-07-13 22:37:22 --> Controller Class Initialized
DEBUG - 2018-07-13 22:37:22 --> Users MX_Controller Initialized
DEBUG - 2018-07-13 22:37:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-13 22:37:22 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-13 22:37:22 --> Login MX_Controller Initialized
INFO - 2018-07-13 22:37:22 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-13 22:37:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-13 22:37:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-13 22:37:22 --> Final output sent to browser
DEBUG - 2018-07-13 22:37:22 --> Total execution time: 0.3934
