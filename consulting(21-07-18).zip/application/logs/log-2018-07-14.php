<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-07-14 01:56:31 --> Config Class Initialized
INFO - 2018-07-14 01:56:31 --> Hooks Class Initialized
DEBUG - 2018-07-14 01:56:31 --> UTF-8 Support Enabled
INFO - 2018-07-14 01:56:31 --> Utf8 Class Initialized
INFO - 2018-07-14 01:56:31 --> URI Class Initialized
INFO - 2018-07-14 01:56:31 --> Router Class Initialized
INFO - 2018-07-14 01:56:31 --> Output Class Initialized
INFO - 2018-07-14 01:56:31 --> Security Class Initialized
DEBUG - 2018-07-14 01:56:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 01:56:31 --> Input Class Initialized
INFO - 2018-07-14 01:56:31 --> Language Class Initialized
INFO - 2018-07-14 01:56:31 --> Language Class Initialized
INFO - 2018-07-14 01:56:31 --> Config Class Initialized
INFO - 2018-07-14 01:56:31 --> Loader Class Initialized
DEBUG - 2018-07-14 01:56:31 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-14 01:56:31 --> Helper loaded: url_helper
INFO - 2018-07-14 01:56:31 --> Helper loaded: form_helper
INFO - 2018-07-14 01:56:31 --> Helper loaded: date_helper
INFO - 2018-07-14 01:56:31 --> Helper loaded: util_helper
INFO - 2018-07-14 01:56:31 --> Helper loaded: text_helper
INFO - 2018-07-14 01:56:31 --> Helper loaded: string_helper
INFO - 2018-07-14 01:56:31 --> Database Driver Class Initialized
DEBUG - 2018-07-14 01:56:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-14 01:56:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-14 01:56:31 --> Email Class Initialized
INFO - 2018-07-14 01:56:31 --> Controller Class Initialized
DEBUG - 2018-07-14 01:56:31 --> Admin MX_Controller Initialized
INFO - 2018-07-14 01:56:31 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-14 01:56:31 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-14 01:56:31 --> Login MX_Controller Initialized
DEBUG - 2018-07-14 01:56:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-14 01:56:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-14 01:56:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
INFO - 2018-07-14 01:56:31 --> Config Class Initialized
INFO - 2018-07-14 01:56:31 --> Hooks Class Initialized
DEBUG - 2018-07-14 01:56:31 --> UTF-8 Support Enabled
INFO - 2018-07-14 01:56:31 --> Utf8 Class Initialized
INFO - 2018-07-14 01:56:31 --> URI Class Initialized
INFO - 2018-07-14 01:56:31 --> Router Class Initialized
INFO - 2018-07-14 01:56:32 --> Output Class Initialized
INFO - 2018-07-14 01:56:32 --> Security Class Initialized
DEBUG - 2018-07-14 01:56:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 01:56:32 --> Input Class Initialized
INFO - 2018-07-14 01:56:32 --> Language Class Initialized
ERROR - 2018-07-14 01:56:32 --> 404 Page Not Found: /index
INFO - 2018-07-14 01:56:42 --> Config Class Initialized
INFO - 2018-07-14 01:56:42 --> Hooks Class Initialized
DEBUG - 2018-07-14 01:56:42 --> UTF-8 Support Enabled
INFO - 2018-07-14 01:56:42 --> Utf8 Class Initialized
INFO - 2018-07-14 01:56:42 --> URI Class Initialized
INFO - 2018-07-14 01:56:42 --> Router Class Initialized
INFO - 2018-07-14 01:56:42 --> Output Class Initialized
INFO - 2018-07-14 01:56:42 --> Security Class Initialized
DEBUG - 2018-07-14 01:56:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 01:56:42 --> Input Class Initialized
INFO - 2018-07-14 01:56:42 --> Language Class Initialized
INFO - 2018-07-14 01:56:42 --> Language Class Initialized
INFO - 2018-07-14 01:56:42 --> Config Class Initialized
INFO - 2018-07-14 01:56:42 --> Loader Class Initialized
DEBUG - 2018-07-14 01:56:42 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-14 01:56:42 --> Helper loaded: url_helper
INFO - 2018-07-14 01:56:42 --> Helper loaded: form_helper
INFO - 2018-07-14 01:56:42 --> Helper loaded: date_helper
INFO - 2018-07-14 01:56:42 --> Helper loaded: util_helper
INFO - 2018-07-14 01:56:42 --> Helper loaded: text_helper
INFO - 2018-07-14 01:56:42 --> Helper loaded: string_helper
INFO - 2018-07-14 01:56:42 --> Database Driver Class Initialized
DEBUG - 2018-07-14 01:56:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-14 01:56:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-14 01:56:42 --> Email Class Initialized
INFO - 2018-07-14 01:56:42 --> Controller Class Initialized
DEBUG - 2018-07-14 01:56:42 --> Login MX_Controller Initialized
INFO - 2018-07-14 01:56:42 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-14 01:56:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-14 01:56:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-14 01:56:42 --> Email starts for admin@colin.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-07-14 01:56:42 --> User session created for 1
INFO - 2018-07-14 01:56:42 --> Login status admin@colin.com - success
INFO - 2018-07-14 01:56:42 --> Final output sent to browser
DEBUG - 2018-07-14 01:56:42 --> Total execution time: 0.2824
INFO - 2018-07-14 01:56:42 --> Config Class Initialized
INFO - 2018-07-14 01:56:42 --> Hooks Class Initialized
DEBUG - 2018-07-14 01:56:42 --> UTF-8 Support Enabled
INFO - 2018-07-14 01:56:42 --> Utf8 Class Initialized
INFO - 2018-07-14 01:56:42 --> URI Class Initialized
INFO - 2018-07-14 01:56:42 --> Router Class Initialized
INFO - 2018-07-14 01:56:42 --> Output Class Initialized
INFO - 2018-07-14 01:56:42 --> Security Class Initialized
DEBUG - 2018-07-14 01:56:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 01:56:42 --> Input Class Initialized
INFO - 2018-07-14 01:56:42 --> Language Class Initialized
INFO - 2018-07-14 01:56:42 --> Language Class Initialized
INFO - 2018-07-14 01:56:42 --> Config Class Initialized
INFO - 2018-07-14 01:56:42 --> Loader Class Initialized
DEBUG - 2018-07-14 01:56:42 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-14 01:56:42 --> Helper loaded: url_helper
INFO - 2018-07-14 01:56:42 --> Helper loaded: form_helper
INFO - 2018-07-14 01:56:42 --> Helper loaded: date_helper
INFO - 2018-07-14 01:56:42 --> Helper loaded: util_helper
INFO - 2018-07-14 01:56:42 --> Helper loaded: text_helper
INFO - 2018-07-14 01:56:42 --> Helper loaded: string_helper
INFO - 2018-07-14 01:56:42 --> Database Driver Class Initialized
DEBUG - 2018-07-14 01:56:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-14 01:56:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-14 01:56:42 --> Email Class Initialized
INFO - 2018-07-14 01:56:42 --> Controller Class Initialized
DEBUG - 2018-07-14 01:56:42 --> Admin MX_Controller Initialized
INFO - 2018-07-14 01:56:42 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-14 01:56:42 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-14 01:56:42 --> Login MX_Controller Initialized
DEBUG - 2018-07-14 01:56:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-14 01:56:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-14 01:56:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-14 01:56:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-14 01:56:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-14 01:56:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-14 01:56:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-14 01:56:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/dashboard.php
INFO - 2018-07-14 01:56:43 --> Final output sent to browser
DEBUG - 2018-07-14 01:56:43 --> Total execution time: 0.4168
INFO - 2018-07-14 01:56:43 --> Config Class Initialized
INFO - 2018-07-14 01:56:43 --> Hooks Class Initialized
DEBUG - 2018-07-14 01:56:43 --> UTF-8 Support Enabled
INFO - 2018-07-14 01:56:43 --> Utf8 Class Initialized
INFO - 2018-07-14 01:56:43 --> URI Class Initialized
INFO - 2018-07-14 01:56:43 --> Router Class Initialized
INFO - 2018-07-14 01:56:43 --> Output Class Initialized
INFO - 2018-07-14 01:56:43 --> Security Class Initialized
DEBUG - 2018-07-14 01:56:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 01:56:43 --> Input Class Initialized
INFO - 2018-07-14 01:56:43 --> Language Class Initialized
ERROR - 2018-07-14 01:56:43 --> 404 Page Not Found: /index
INFO - 2018-07-14 01:56:43 --> Config Class Initialized
INFO - 2018-07-14 01:56:43 --> Hooks Class Initialized
DEBUG - 2018-07-14 01:56:43 --> UTF-8 Support Enabled
INFO - 2018-07-14 01:56:43 --> Utf8 Class Initialized
INFO - 2018-07-14 01:56:43 --> URI Class Initialized
INFO - 2018-07-14 01:56:43 --> Router Class Initialized
INFO - 2018-07-14 01:56:43 --> Output Class Initialized
INFO - 2018-07-14 01:56:43 --> Security Class Initialized
DEBUG - 2018-07-14 01:56:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 01:56:43 --> Input Class Initialized
INFO - 2018-07-14 01:56:43 --> Language Class Initialized
ERROR - 2018-07-14 01:56:43 --> 404 Page Not Found: /index
