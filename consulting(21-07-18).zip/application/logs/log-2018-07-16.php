<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-07-16 21:44:51 --> Config Class Initialized
INFO - 2018-07-16 21:44:51 --> Hooks Class Initialized
DEBUG - 2018-07-16 21:44:51 --> UTF-8 Support Enabled
INFO - 2018-07-16 21:44:51 --> Utf8 Class Initialized
INFO - 2018-07-16 21:44:51 --> URI Class Initialized
DEBUG - 2018-07-16 21:44:51 --> No URI present. Default controller set.
INFO - 2018-07-16 21:44:51 --> Router Class Initialized
INFO - 2018-07-16 21:44:51 --> Output Class Initialized
INFO - 2018-07-16 21:44:51 --> Security Class Initialized
DEBUG - 2018-07-16 21:44:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 21:44:51 --> Input Class Initialized
INFO - 2018-07-16 21:44:51 --> Language Class Initialized
INFO - 2018-07-16 21:44:52 --> Language Class Initialized
INFO - 2018-07-16 21:44:52 --> Config Class Initialized
INFO - 2018-07-16 21:44:52 --> Loader Class Initialized
DEBUG - 2018-07-16 21:44:52 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 21:44:52 --> Helper loaded: url_helper
INFO - 2018-07-16 21:44:52 --> Helper loaded: form_helper
INFO - 2018-07-16 21:44:52 --> Helper loaded: date_helper
INFO - 2018-07-16 21:44:52 --> Helper loaded: util_helper
INFO - 2018-07-16 21:44:52 --> Helper loaded: text_helper
INFO - 2018-07-16 21:44:52 --> Helper loaded: string_helper
INFO - 2018-07-16 21:44:52 --> Database Driver Class Initialized
DEBUG - 2018-07-16 21:44:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 21:44:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 21:44:53 --> Email Class Initialized
INFO - 2018-07-16 21:44:53 --> Controller Class Initialized
DEBUG - 2018-07-16 21:44:53 --> Home MX_Controller Initialized
DEBUG - 2018-07-16 21:44:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-16 21:44:53 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-16 21:44:53 --> Login MX_Controller Initialized
INFO - 2018-07-16 21:44:53 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 21:44:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 21:44:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-16 21:44:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-07-16 21:44:59 --> Config Class Initialized
INFO - 2018-07-16 21:44:59 --> Hooks Class Initialized
DEBUG - 2018-07-16 21:44:59 --> UTF-8 Support Enabled
INFO - 2018-07-16 21:44:59 --> Utf8 Class Initialized
INFO - 2018-07-16 21:44:59 --> URI Class Initialized
INFO - 2018-07-16 21:44:59 --> Router Class Initialized
INFO - 2018-07-16 21:44:59 --> Output Class Initialized
INFO - 2018-07-16 21:44:59 --> Security Class Initialized
DEBUG - 2018-07-16 21:44:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 21:44:59 --> Input Class Initialized
INFO - 2018-07-16 21:44:59 --> Language Class Initialized
INFO - 2018-07-16 21:44:59 --> Language Class Initialized
INFO - 2018-07-16 21:44:59 --> Config Class Initialized
INFO - 2018-07-16 21:44:59 --> Loader Class Initialized
DEBUG - 2018-07-16 21:44:59 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 21:44:59 --> Helper loaded: url_helper
INFO - 2018-07-16 21:44:59 --> Helper loaded: form_helper
INFO - 2018-07-16 21:44:59 --> Helper loaded: date_helper
INFO - 2018-07-16 21:44:59 --> Helper loaded: util_helper
INFO - 2018-07-16 21:44:59 --> Helper loaded: text_helper
INFO - 2018-07-16 21:44:59 --> Helper loaded: string_helper
INFO - 2018-07-16 21:44:59 --> Database Driver Class Initialized
DEBUG - 2018-07-16 21:44:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 21:44:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 21:44:59 --> Email Class Initialized
INFO - 2018-07-16 21:44:59 --> Controller Class Initialized
DEBUG - 2018-07-16 21:44:59 --> Admin MX_Controller Initialized
INFO - 2018-07-16 21:44:59 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 21:44:59 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-16 21:44:59 --> Login MX_Controller Initialized
DEBUG - 2018-07-16 21:44:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 21:44:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-16 21:45:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
INFO - 2018-07-16 21:45:00 --> Config Class Initialized
INFO - 2018-07-16 21:45:00 --> Hooks Class Initialized
DEBUG - 2018-07-16 21:45:00 --> UTF-8 Support Enabled
INFO - 2018-07-16 21:45:00 --> Utf8 Class Initialized
INFO - 2018-07-16 21:45:00 --> URI Class Initialized
INFO - 2018-07-16 21:45:00 --> Router Class Initialized
INFO - 2018-07-16 21:45:00 --> Output Class Initialized
INFO - 2018-07-16 21:45:00 --> Security Class Initialized
DEBUG - 2018-07-16 21:45:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 21:45:00 --> Input Class Initialized
INFO - 2018-07-16 21:45:00 --> Language Class Initialized
ERROR - 2018-07-16 21:45:00 --> 404 Page Not Found: /index
INFO - 2018-07-16 21:45:12 --> Config Class Initialized
INFO - 2018-07-16 21:45:12 --> Hooks Class Initialized
DEBUG - 2018-07-16 21:45:12 --> UTF-8 Support Enabled
INFO - 2018-07-16 21:45:12 --> Utf8 Class Initialized
INFO - 2018-07-16 21:45:12 --> URI Class Initialized
INFO - 2018-07-16 21:45:12 --> Router Class Initialized
INFO - 2018-07-16 21:45:12 --> Output Class Initialized
INFO - 2018-07-16 21:45:12 --> Security Class Initialized
DEBUG - 2018-07-16 21:45:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 21:45:12 --> Input Class Initialized
INFO - 2018-07-16 21:45:12 --> Language Class Initialized
INFO - 2018-07-16 21:45:12 --> Language Class Initialized
INFO - 2018-07-16 21:45:12 --> Config Class Initialized
INFO - 2018-07-16 21:45:12 --> Loader Class Initialized
DEBUG - 2018-07-16 21:45:12 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 21:45:12 --> Helper loaded: url_helper
INFO - 2018-07-16 21:45:12 --> Helper loaded: form_helper
INFO - 2018-07-16 21:45:12 --> Helper loaded: date_helper
INFO - 2018-07-16 21:45:12 --> Helper loaded: util_helper
INFO - 2018-07-16 21:45:12 --> Helper loaded: text_helper
INFO - 2018-07-16 21:45:12 --> Helper loaded: string_helper
INFO - 2018-07-16 21:45:12 --> Database Driver Class Initialized
DEBUG - 2018-07-16 21:45:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 21:45:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 21:45:12 --> Email Class Initialized
INFO - 2018-07-16 21:45:12 --> Controller Class Initialized
DEBUG - 2018-07-16 21:45:12 --> Login MX_Controller Initialized
INFO - 2018-07-16 21:45:12 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 21:45:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 21:45:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-16 21:45:12 --> Email starts for admin@colin.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-07-16 21:45:12 --> User session created for 1
INFO - 2018-07-16 21:45:12 --> Login status admin@colin.com - success
INFO - 2018-07-16 21:45:12 --> Final output sent to browser
DEBUG - 2018-07-16 21:45:12 --> Total execution time: 0.4223
INFO - 2018-07-16 21:45:12 --> Config Class Initialized
INFO - 2018-07-16 21:45:12 --> Hooks Class Initialized
DEBUG - 2018-07-16 21:45:12 --> UTF-8 Support Enabled
INFO - 2018-07-16 21:45:12 --> Utf8 Class Initialized
INFO - 2018-07-16 21:45:12 --> URI Class Initialized
INFO - 2018-07-16 21:45:12 --> Router Class Initialized
INFO - 2018-07-16 21:45:12 --> Output Class Initialized
INFO - 2018-07-16 21:45:12 --> Security Class Initialized
DEBUG - 2018-07-16 21:45:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 21:45:12 --> Input Class Initialized
INFO - 2018-07-16 21:45:12 --> Language Class Initialized
INFO - 2018-07-16 21:45:12 --> Language Class Initialized
INFO - 2018-07-16 21:45:12 --> Config Class Initialized
INFO - 2018-07-16 21:45:12 --> Loader Class Initialized
DEBUG - 2018-07-16 21:45:12 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 21:45:12 --> Helper loaded: url_helper
INFO - 2018-07-16 21:45:12 --> Helper loaded: form_helper
INFO - 2018-07-16 21:45:12 --> Helper loaded: date_helper
INFO - 2018-07-16 21:45:12 --> Helper loaded: util_helper
INFO - 2018-07-16 21:45:12 --> Helper loaded: text_helper
INFO - 2018-07-16 21:45:12 --> Helper loaded: string_helper
INFO - 2018-07-16 21:45:12 --> Database Driver Class Initialized
DEBUG - 2018-07-16 21:45:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 21:45:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 21:45:12 --> Email Class Initialized
INFO - 2018-07-16 21:45:12 --> Controller Class Initialized
DEBUG - 2018-07-16 21:45:12 --> Admin MX_Controller Initialized
INFO - 2018-07-16 21:45:12 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 21:45:12 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-16 21:45:12 --> Login MX_Controller Initialized
DEBUG - 2018-07-16 21:45:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 21:45:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-16 21:45:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-16 21:45:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-16 21:45:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-16 21:45:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-16 21:45:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-16 21:45:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/dashboard.php
INFO - 2018-07-16 21:45:13 --> Final output sent to browser
DEBUG - 2018-07-16 21:45:13 --> Total execution time: 0.5607
INFO - 2018-07-16 21:45:13 --> Config Class Initialized
INFO - 2018-07-16 21:45:13 --> Hooks Class Initialized
DEBUG - 2018-07-16 21:45:13 --> UTF-8 Support Enabled
INFO - 2018-07-16 21:45:13 --> Utf8 Class Initialized
INFO - 2018-07-16 21:45:13 --> URI Class Initialized
INFO - 2018-07-16 21:45:13 --> Router Class Initialized
INFO - 2018-07-16 21:45:13 --> Output Class Initialized
INFO - 2018-07-16 21:45:13 --> Security Class Initialized
DEBUG - 2018-07-16 21:45:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 21:45:13 --> Input Class Initialized
INFO - 2018-07-16 21:45:13 --> Language Class Initialized
ERROR - 2018-07-16 21:45:13 --> 404 Page Not Found: /index
INFO - 2018-07-16 21:45:14 --> Config Class Initialized
INFO - 2018-07-16 21:45:14 --> Hooks Class Initialized
DEBUG - 2018-07-16 21:45:14 --> UTF-8 Support Enabled
INFO - 2018-07-16 21:45:14 --> Utf8 Class Initialized
INFO - 2018-07-16 21:45:14 --> URI Class Initialized
INFO - 2018-07-16 21:45:14 --> Router Class Initialized
INFO - 2018-07-16 21:45:14 --> Output Class Initialized
INFO - 2018-07-16 21:45:14 --> Security Class Initialized
DEBUG - 2018-07-16 21:45:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 21:45:14 --> Input Class Initialized
INFO - 2018-07-16 21:45:14 --> Language Class Initialized
ERROR - 2018-07-16 21:45:14 --> 404 Page Not Found: /index
INFO - 2018-07-16 21:45:14 --> Config Class Initialized
INFO - 2018-07-16 21:45:14 --> Hooks Class Initialized
DEBUG - 2018-07-16 21:45:14 --> UTF-8 Support Enabled
INFO - 2018-07-16 21:45:14 --> Utf8 Class Initialized
INFO - 2018-07-16 21:45:14 --> URI Class Initialized
INFO - 2018-07-16 21:45:14 --> Router Class Initialized
INFO - 2018-07-16 21:45:14 --> Output Class Initialized
INFO - 2018-07-16 21:45:14 --> Security Class Initialized
DEBUG - 2018-07-16 21:45:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 21:45:14 --> Input Class Initialized
INFO - 2018-07-16 21:45:14 --> Language Class Initialized
ERROR - 2018-07-16 21:45:14 --> 404 Page Not Found: /index
INFO - 2018-07-16 21:45:16 --> Config Class Initialized
INFO - 2018-07-16 21:45:16 --> Hooks Class Initialized
DEBUG - 2018-07-16 21:45:16 --> UTF-8 Support Enabled
INFO - 2018-07-16 21:45:16 --> Utf8 Class Initialized
INFO - 2018-07-16 21:45:17 --> URI Class Initialized
INFO - 2018-07-16 21:45:17 --> Router Class Initialized
INFO - 2018-07-16 21:45:17 --> Output Class Initialized
INFO - 2018-07-16 21:45:17 --> Security Class Initialized
DEBUG - 2018-07-16 21:45:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 21:45:17 --> Input Class Initialized
INFO - 2018-07-16 21:45:17 --> Language Class Initialized
INFO - 2018-07-16 21:45:17 --> Language Class Initialized
INFO - 2018-07-16 21:45:17 --> Config Class Initialized
INFO - 2018-07-16 21:45:17 --> Loader Class Initialized
DEBUG - 2018-07-16 21:45:17 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 21:45:17 --> Helper loaded: url_helper
INFO - 2018-07-16 21:45:17 --> Helper loaded: form_helper
INFO - 2018-07-16 21:45:17 --> Helper loaded: date_helper
INFO - 2018-07-16 21:45:17 --> Helper loaded: util_helper
INFO - 2018-07-16 21:45:17 --> Helper loaded: text_helper
INFO - 2018-07-16 21:45:17 --> Helper loaded: string_helper
INFO - 2018-07-16 21:45:17 --> Database Driver Class Initialized
DEBUG - 2018-07-16 21:45:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 21:45:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 21:45:17 --> Email Class Initialized
INFO - 2018-07-16 21:45:17 --> Controller Class Initialized
DEBUG - 2018-07-16 21:45:17 --> Users MX_Controller Initialized
DEBUG - 2018-07-16 21:45:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 21:45:17 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-16 21:45:17 --> Login MX_Controller Initialized
INFO - 2018-07-16 21:45:17 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 21:45:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-16 21:45:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-16 21:45:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-16 21:45:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-16 21:45:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-16 21:45:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-16 21:45:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-07-16 21:45:17 --> Final output sent to browser
DEBUG - 2018-07-16 21:45:17 --> Total execution time: 0.4284
INFO - 2018-07-16 21:45:17 --> Config Class Initialized
INFO - 2018-07-16 21:45:17 --> Hooks Class Initialized
DEBUG - 2018-07-16 21:45:17 --> UTF-8 Support Enabled
INFO - 2018-07-16 21:45:17 --> Utf8 Class Initialized
INFO - 2018-07-16 21:45:17 --> URI Class Initialized
INFO - 2018-07-16 21:45:17 --> Router Class Initialized
INFO - 2018-07-16 21:45:17 --> Output Class Initialized
INFO - 2018-07-16 21:45:17 --> Security Class Initialized
DEBUG - 2018-07-16 21:45:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 21:45:17 --> Input Class Initialized
INFO - 2018-07-16 21:45:17 --> Language Class Initialized
INFO - 2018-07-16 21:45:17 --> Language Class Initialized
INFO - 2018-07-16 21:45:17 --> Config Class Initialized
INFO - 2018-07-16 21:45:17 --> Loader Class Initialized
DEBUG - 2018-07-16 21:45:17 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 21:45:17 --> Helper loaded: url_helper
INFO - 2018-07-16 21:45:18 --> Helper loaded: form_helper
INFO - 2018-07-16 21:45:18 --> Helper loaded: date_helper
INFO - 2018-07-16 21:45:18 --> Helper loaded: util_helper
INFO - 2018-07-16 21:45:18 --> Helper loaded: text_helper
INFO - 2018-07-16 21:45:18 --> Helper loaded: string_helper
INFO - 2018-07-16 21:45:18 --> Database Driver Class Initialized
DEBUG - 2018-07-16 21:45:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 21:45:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 21:45:18 --> Email Class Initialized
INFO - 2018-07-16 21:45:18 --> Controller Class Initialized
DEBUG - 2018-07-16 21:45:18 --> Users MX_Controller Initialized
DEBUG - 2018-07-16 21:45:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 21:45:18 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-16 21:45:18 --> Login MX_Controller Initialized
INFO - 2018-07-16 21:45:18 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 21:45:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-16 21:45:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-16 21:45:18 --> Final output sent to browser
DEBUG - 2018-07-16 21:45:18 --> Total execution time: 0.7480
INFO - 2018-07-16 21:45:21 --> Config Class Initialized
INFO - 2018-07-16 21:45:21 --> Hooks Class Initialized
DEBUG - 2018-07-16 21:45:21 --> UTF-8 Support Enabled
INFO - 2018-07-16 21:45:21 --> Utf8 Class Initialized
INFO - 2018-07-16 21:45:21 --> URI Class Initialized
INFO - 2018-07-16 21:45:21 --> Router Class Initialized
INFO - 2018-07-16 21:45:21 --> Output Class Initialized
INFO - 2018-07-16 21:45:21 --> Security Class Initialized
DEBUG - 2018-07-16 21:45:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 21:45:21 --> Input Class Initialized
INFO - 2018-07-16 21:45:21 --> Language Class Initialized
INFO - 2018-07-16 21:45:21 --> Language Class Initialized
INFO - 2018-07-16 21:45:21 --> Config Class Initialized
INFO - 2018-07-16 21:45:21 --> Loader Class Initialized
DEBUG - 2018-07-16 21:45:21 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 21:45:21 --> Helper loaded: url_helper
INFO - 2018-07-16 21:45:21 --> Helper loaded: form_helper
INFO - 2018-07-16 21:45:21 --> Helper loaded: date_helper
INFO - 2018-07-16 21:45:21 --> Helper loaded: util_helper
INFO - 2018-07-16 21:45:21 --> Helper loaded: text_helper
INFO - 2018-07-16 21:45:21 --> Helper loaded: string_helper
INFO - 2018-07-16 21:45:21 --> Database Driver Class Initialized
DEBUG - 2018-07-16 21:45:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 21:45:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 21:45:21 --> Email Class Initialized
INFO - 2018-07-16 21:45:21 --> Controller Class Initialized
DEBUG - 2018-07-16 21:45:21 --> Users MX_Controller Initialized
DEBUG - 2018-07-16 21:45:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 21:45:21 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-16 21:45:21 --> Login MX_Controller Initialized
INFO - 2018-07-16 21:45:21 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 21:45:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-16 21:45:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-07-16 21:45:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-16 21:45:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-16 21:45:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-16 21:45:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-16 21:45:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-16 21:45:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-07-16 21:45:21 --> Final output sent to browser
DEBUG - 2018-07-16 21:45:21 --> Total execution time: 0.3922
INFO - 2018-07-16 21:45:32 --> Config Class Initialized
INFO - 2018-07-16 21:45:32 --> Hooks Class Initialized
DEBUG - 2018-07-16 21:45:32 --> UTF-8 Support Enabled
INFO - 2018-07-16 21:45:32 --> Utf8 Class Initialized
INFO - 2018-07-16 21:45:32 --> URI Class Initialized
INFO - 2018-07-16 21:45:32 --> Router Class Initialized
INFO - 2018-07-16 21:45:32 --> Output Class Initialized
INFO - 2018-07-16 21:45:32 --> Security Class Initialized
DEBUG - 2018-07-16 21:45:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 21:45:32 --> Input Class Initialized
INFO - 2018-07-16 21:45:32 --> Language Class Initialized
INFO - 2018-07-16 21:45:32 --> Language Class Initialized
INFO - 2018-07-16 21:45:32 --> Config Class Initialized
INFO - 2018-07-16 21:45:32 --> Loader Class Initialized
DEBUG - 2018-07-16 21:45:32 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 21:45:32 --> Helper loaded: url_helper
INFO - 2018-07-16 21:45:32 --> Helper loaded: form_helper
INFO - 2018-07-16 21:45:32 --> Helper loaded: date_helper
INFO - 2018-07-16 21:45:32 --> Helper loaded: util_helper
INFO - 2018-07-16 21:45:32 --> Helper loaded: text_helper
INFO - 2018-07-16 21:45:32 --> Helper loaded: string_helper
INFO - 2018-07-16 21:45:32 --> Database Driver Class Initialized
DEBUG - 2018-07-16 21:45:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 21:45:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 21:45:32 --> Email Class Initialized
INFO - 2018-07-16 21:45:32 --> Controller Class Initialized
DEBUG - 2018-07-16 21:45:32 --> Users MX_Controller Initialized
DEBUG - 2018-07-16 21:45:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 21:45:32 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-16 21:45:32 --> Login MX_Controller Initialized
INFO - 2018-07-16 21:45:32 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 21:45:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-16 21:45:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-16 21:45:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-16 21:45:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-16 21:45:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-16 21:45:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-16 21:45:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-07-16 21:45:32 --> Final output sent to browser
DEBUG - 2018-07-16 21:45:32 --> Total execution time: 0.3707
INFO - 2018-07-16 21:45:33 --> Config Class Initialized
INFO - 2018-07-16 21:45:33 --> Hooks Class Initialized
DEBUG - 2018-07-16 21:45:33 --> UTF-8 Support Enabled
INFO - 2018-07-16 21:45:33 --> Utf8 Class Initialized
INFO - 2018-07-16 21:45:33 --> URI Class Initialized
INFO - 2018-07-16 21:45:33 --> Router Class Initialized
INFO - 2018-07-16 21:45:33 --> Output Class Initialized
INFO - 2018-07-16 21:45:33 --> Security Class Initialized
DEBUG - 2018-07-16 21:45:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 21:45:33 --> Input Class Initialized
INFO - 2018-07-16 21:45:33 --> Language Class Initialized
INFO - 2018-07-16 21:45:33 --> Language Class Initialized
INFO - 2018-07-16 21:45:33 --> Config Class Initialized
INFO - 2018-07-16 21:45:33 --> Loader Class Initialized
DEBUG - 2018-07-16 21:45:33 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 21:45:33 --> Helper loaded: url_helper
INFO - 2018-07-16 21:45:33 --> Helper loaded: form_helper
INFO - 2018-07-16 21:45:33 --> Helper loaded: date_helper
INFO - 2018-07-16 21:45:33 --> Helper loaded: util_helper
INFO - 2018-07-16 21:45:33 --> Helper loaded: text_helper
INFO - 2018-07-16 21:45:33 --> Helper loaded: string_helper
INFO - 2018-07-16 21:45:33 --> Database Driver Class Initialized
DEBUG - 2018-07-16 21:45:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 21:45:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 21:45:33 --> Email Class Initialized
INFO - 2018-07-16 21:45:33 --> Controller Class Initialized
DEBUG - 2018-07-16 21:45:33 --> Users MX_Controller Initialized
DEBUG - 2018-07-16 21:45:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 21:45:33 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-16 21:45:33 --> Login MX_Controller Initialized
INFO - 2018-07-16 21:45:33 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 21:45:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-16 21:45:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-16 21:45:33 --> Final output sent to browser
DEBUG - 2018-07-16 21:45:33 --> Total execution time: 0.4109
INFO - 2018-07-16 21:45:38 --> Config Class Initialized
INFO - 2018-07-16 21:45:38 --> Hooks Class Initialized
DEBUG - 2018-07-16 21:45:38 --> UTF-8 Support Enabled
INFO - 2018-07-16 21:45:38 --> Utf8 Class Initialized
INFO - 2018-07-16 21:45:38 --> URI Class Initialized
INFO - 2018-07-16 21:45:38 --> Router Class Initialized
INFO - 2018-07-16 21:45:38 --> Output Class Initialized
INFO - 2018-07-16 21:45:38 --> Security Class Initialized
DEBUG - 2018-07-16 21:45:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 21:45:38 --> Input Class Initialized
INFO - 2018-07-16 21:45:38 --> Language Class Initialized
INFO - 2018-07-16 21:45:38 --> Language Class Initialized
INFO - 2018-07-16 21:45:38 --> Config Class Initialized
INFO - 2018-07-16 21:45:38 --> Loader Class Initialized
DEBUG - 2018-07-16 21:45:38 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 21:45:38 --> Helper loaded: url_helper
INFO - 2018-07-16 21:45:38 --> Helper loaded: form_helper
INFO - 2018-07-16 21:45:38 --> Helper loaded: date_helper
INFO - 2018-07-16 21:45:38 --> Helper loaded: util_helper
INFO - 2018-07-16 21:45:38 --> Helper loaded: text_helper
INFO - 2018-07-16 21:45:38 --> Helper loaded: string_helper
INFO - 2018-07-16 21:45:38 --> Database Driver Class Initialized
DEBUG - 2018-07-16 21:45:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 21:45:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 21:45:38 --> Email Class Initialized
INFO - 2018-07-16 21:45:38 --> Controller Class Initialized
DEBUG - 2018-07-16 21:45:38 --> Users MX_Controller Initialized
DEBUG - 2018-07-16 21:45:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 21:45:38 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-16 21:45:38 --> Login MX_Controller Initialized
INFO - 2018-07-16 21:45:38 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 21:45:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-16 21:45:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-07-16 21:45:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-16 21:45:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-16 21:45:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-16 21:45:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-16 21:45:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-16 21:45:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-07-16 21:45:38 --> Final output sent to browser
DEBUG - 2018-07-16 21:45:38 --> Total execution time: 0.3496
INFO - 2018-07-16 21:45:50 --> Config Class Initialized
INFO - 2018-07-16 21:45:50 --> Hooks Class Initialized
DEBUG - 2018-07-16 21:45:50 --> UTF-8 Support Enabled
INFO - 2018-07-16 21:45:50 --> Utf8 Class Initialized
INFO - 2018-07-16 21:45:50 --> URI Class Initialized
INFO - 2018-07-16 21:45:50 --> Router Class Initialized
INFO - 2018-07-16 21:45:50 --> Output Class Initialized
INFO - 2018-07-16 21:45:50 --> Security Class Initialized
DEBUG - 2018-07-16 21:45:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 21:45:50 --> Input Class Initialized
INFO - 2018-07-16 21:45:50 --> Language Class Initialized
INFO - 2018-07-16 21:45:50 --> Language Class Initialized
INFO - 2018-07-16 21:45:50 --> Config Class Initialized
INFO - 2018-07-16 21:45:50 --> Loader Class Initialized
DEBUG - 2018-07-16 21:45:50 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 21:45:50 --> Helper loaded: url_helper
INFO - 2018-07-16 21:45:50 --> Helper loaded: form_helper
INFO - 2018-07-16 21:45:50 --> Helper loaded: date_helper
INFO - 2018-07-16 21:45:50 --> Helper loaded: util_helper
INFO - 2018-07-16 21:45:50 --> Helper loaded: text_helper
INFO - 2018-07-16 21:45:50 --> Helper loaded: string_helper
INFO - 2018-07-16 21:45:50 --> Database Driver Class Initialized
DEBUG - 2018-07-16 21:45:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 21:45:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 21:45:50 --> Email Class Initialized
INFO - 2018-07-16 21:45:50 --> Controller Class Initialized
DEBUG - 2018-07-16 21:45:50 --> Users MX_Controller Initialized
DEBUG - 2018-07-16 21:45:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 21:45:50 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-16 21:45:50 --> Login MX_Controller Initialized
INFO - 2018-07-16 21:45:50 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 21:45:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-16 21:45:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-16 21:45:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-16 21:45:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-16 21:45:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-16 21:45:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-16 21:45:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-07-16 21:45:50 --> Final output sent to browser
DEBUG - 2018-07-16 21:45:50 --> Total execution time: 0.3439
INFO - 2018-07-16 21:45:51 --> Config Class Initialized
INFO - 2018-07-16 21:45:51 --> Hooks Class Initialized
DEBUG - 2018-07-16 21:45:51 --> UTF-8 Support Enabled
INFO - 2018-07-16 21:45:51 --> Utf8 Class Initialized
INFO - 2018-07-16 21:45:51 --> URI Class Initialized
INFO - 2018-07-16 21:45:51 --> Router Class Initialized
INFO - 2018-07-16 21:45:51 --> Output Class Initialized
INFO - 2018-07-16 21:45:51 --> Security Class Initialized
DEBUG - 2018-07-16 21:45:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 21:45:51 --> Input Class Initialized
INFO - 2018-07-16 21:45:51 --> Language Class Initialized
INFO - 2018-07-16 21:45:51 --> Language Class Initialized
INFO - 2018-07-16 21:45:51 --> Config Class Initialized
INFO - 2018-07-16 21:45:51 --> Loader Class Initialized
DEBUG - 2018-07-16 21:45:51 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 21:45:51 --> Helper loaded: url_helper
INFO - 2018-07-16 21:45:51 --> Helper loaded: form_helper
INFO - 2018-07-16 21:45:51 --> Helper loaded: date_helper
INFO - 2018-07-16 21:45:51 --> Helper loaded: util_helper
INFO - 2018-07-16 21:45:51 --> Helper loaded: text_helper
INFO - 2018-07-16 21:45:51 --> Helper loaded: string_helper
INFO - 2018-07-16 21:45:51 --> Database Driver Class Initialized
DEBUG - 2018-07-16 21:45:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 21:45:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 21:45:51 --> Email Class Initialized
INFO - 2018-07-16 21:45:51 --> Controller Class Initialized
DEBUG - 2018-07-16 21:45:51 --> Users MX_Controller Initialized
DEBUG - 2018-07-16 21:45:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 21:45:51 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-16 21:45:51 --> Login MX_Controller Initialized
INFO - 2018-07-16 21:45:51 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 21:45:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-16 21:45:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-16 21:45:51 --> Final output sent to browser
DEBUG - 2018-07-16 21:45:51 --> Total execution time: 0.3822
INFO - 2018-07-16 21:45:57 --> Config Class Initialized
INFO - 2018-07-16 21:45:57 --> Hooks Class Initialized
DEBUG - 2018-07-16 21:45:57 --> UTF-8 Support Enabled
INFO - 2018-07-16 21:45:57 --> Utf8 Class Initialized
INFO - 2018-07-16 21:45:57 --> URI Class Initialized
INFO - 2018-07-16 21:45:57 --> Router Class Initialized
INFO - 2018-07-16 21:45:57 --> Output Class Initialized
INFO - 2018-07-16 21:45:57 --> Security Class Initialized
DEBUG - 2018-07-16 21:45:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 21:45:57 --> Input Class Initialized
INFO - 2018-07-16 21:45:57 --> Language Class Initialized
INFO - 2018-07-16 21:45:57 --> Language Class Initialized
INFO - 2018-07-16 21:45:57 --> Config Class Initialized
INFO - 2018-07-16 21:45:57 --> Loader Class Initialized
DEBUG - 2018-07-16 21:45:57 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 21:45:57 --> Helper loaded: url_helper
INFO - 2018-07-16 21:45:57 --> Helper loaded: form_helper
INFO - 2018-07-16 21:45:57 --> Helper loaded: date_helper
INFO - 2018-07-16 21:45:57 --> Helper loaded: util_helper
INFO - 2018-07-16 21:45:57 --> Helper loaded: text_helper
INFO - 2018-07-16 21:45:57 --> Helper loaded: string_helper
INFO - 2018-07-16 21:45:57 --> Database Driver Class Initialized
DEBUG - 2018-07-16 21:45:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 21:45:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 21:45:57 --> Email Class Initialized
INFO - 2018-07-16 21:45:57 --> Controller Class Initialized
DEBUG - 2018-07-16 21:45:57 --> Login MX_Controller Initialized
INFO - 2018-07-16 21:45:57 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 21:45:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 21:45:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-16 21:45:57 --> 1 Loggedout
INFO - 2018-07-16 21:45:57 --> Config Class Initialized
INFO - 2018-07-16 21:45:57 --> Hooks Class Initialized
DEBUG - 2018-07-16 21:45:57 --> UTF-8 Support Enabled
INFO - 2018-07-16 21:45:57 --> Utf8 Class Initialized
INFO - 2018-07-16 21:45:57 --> URI Class Initialized
INFO - 2018-07-16 21:45:57 --> Router Class Initialized
INFO - 2018-07-16 21:45:57 --> Output Class Initialized
INFO - 2018-07-16 21:45:57 --> Security Class Initialized
DEBUG - 2018-07-16 21:45:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 21:45:57 --> Input Class Initialized
INFO - 2018-07-16 21:45:57 --> Language Class Initialized
INFO - 2018-07-16 21:45:57 --> Language Class Initialized
INFO - 2018-07-16 21:45:57 --> Config Class Initialized
INFO - 2018-07-16 21:45:57 --> Loader Class Initialized
DEBUG - 2018-07-16 21:45:57 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 21:45:57 --> Helper loaded: url_helper
INFO - 2018-07-16 21:45:57 --> Helper loaded: form_helper
INFO - 2018-07-16 21:45:57 --> Helper loaded: date_helper
INFO - 2018-07-16 21:45:57 --> Helper loaded: util_helper
INFO - 2018-07-16 21:45:57 --> Helper loaded: text_helper
INFO - 2018-07-16 21:45:57 --> Helper loaded: string_helper
INFO - 2018-07-16 21:45:57 --> Database Driver Class Initialized
DEBUG - 2018-07-16 21:45:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 21:45:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 21:45:57 --> Email Class Initialized
INFO - 2018-07-16 21:45:57 --> Controller Class Initialized
DEBUG - 2018-07-16 21:45:57 --> Admin MX_Controller Initialized
INFO - 2018-07-16 21:45:57 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 21:45:57 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-16 21:45:57 --> Login MX_Controller Initialized
DEBUG - 2018-07-16 21:45:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 21:45:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-16 21:45:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
INFO - 2018-07-16 21:45:58 --> Config Class Initialized
INFO - 2018-07-16 21:45:58 --> Hooks Class Initialized
DEBUG - 2018-07-16 21:45:58 --> UTF-8 Support Enabled
INFO - 2018-07-16 21:45:58 --> Utf8 Class Initialized
INFO - 2018-07-16 21:45:58 --> URI Class Initialized
INFO - 2018-07-16 21:45:58 --> Router Class Initialized
INFO - 2018-07-16 21:45:58 --> Output Class Initialized
INFO - 2018-07-16 21:45:58 --> Security Class Initialized
DEBUG - 2018-07-16 21:45:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 21:45:58 --> Input Class Initialized
INFO - 2018-07-16 21:45:58 --> Language Class Initialized
ERROR - 2018-07-16 21:45:58 --> 404 Page Not Found: /index
INFO - 2018-07-16 21:46:00 --> Config Class Initialized
INFO - 2018-07-16 21:46:00 --> Hooks Class Initialized
DEBUG - 2018-07-16 21:46:00 --> UTF-8 Support Enabled
INFO - 2018-07-16 21:46:00 --> Utf8 Class Initialized
INFO - 2018-07-16 21:46:00 --> URI Class Initialized
INFO - 2018-07-16 21:46:00 --> Router Class Initialized
INFO - 2018-07-16 21:46:00 --> Output Class Initialized
INFO - 2018-07-16 21:46:00 --> Security Class Initialized
DEBUG - 2018-07-16 21:46:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 21:46:00 --> Input Class Initialized
INFO - 2018-07-16 21:46:00 --> Language Class Initialized
INFO - 2018-07-16 21:46:00 --> Language Class Initialized
INFO - 2018-07-16 21:46:00 --> Config Class Initialized
INFO - 2018-07-16 21:46:00 --> Loader Class Initialized
DEBUG - 2018-07-16 21:46:00 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 21:46:00 --> Helper loaded: url_helper
INFO - 2018-07-16 21:46:00 --> Helper loaded: form_helper
INFO - 2018-07-16 21:46:00 --> Helper loaded: date_helper
INFO - 2018-07-16 21:46:00 --> Helper loaded: util_helper
INFO - 2018-07-16 21:46:00 --> Helper loaded: text_helper
INFO - 2018-07-16 21:46:00 --> Helper loaded: string_helper
INFO - 2018-07-16 21:46:00 --> Database Driver Class Initialized
DEBUG - 2018-07-16 21:46:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 21:46:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 21:46:00 --> Email Class Initialized
INFO - 2018-07-16 21:46:00 --> Controller Class Initialized
DEBUG - 2018-07-16 21:46:00 --> Login MX_Controller Initialized
INFO - 2018-07-16 21:46:00 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 21:46:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 21:46:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-16 21:46:00 --> Email starts for gopi.lion123@gmail.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-07-16 21:46:00 --> User session created for 6
INFO - 2018-07-16 21:46:00 --> Login status gopi.lion123@gmail.com - success
INFO - 2018-07-16 21:46:00 --> Final output sent to browser
DEBUG - 2018-07-16 21:46:00 --> Total execution time: 0.3300
INFO - 2018-07-16 21:46:00 --> Config Class Initialized
INFO - 2018-07-16 21:46:00 --> Hooks Class Initialized
DEBUG - 2018-07-16 21:46:00 --> UTF-8 Support Enabled
INFO - 2018-07-16 21:46:00 --> Utf8 Class Initialized
INFO - 2018-07-16 21:46:00 --> URI Class Initialized
INFO - 2018-07-16 21:46:00 --> Router Class Initialized
INFO - 2018-07-16 21:46:00 --> Output Class Initialized
INFO - 2018-07-16 21:46:00 --> Security Class Initialized
DEBUG - 2018-07-16 21:46:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 21:46:00 --> Input Class Initialized
INFO - 2018-07-16 21:46:00 --> Language Class Initialized
INFO - 2018-07-16 21:46:00 --> Language Class Initialized
INFO - 2018-07-16 21:46:00 --> Config Class Initialized
INFO - 2018-07-16 21:46:00 --> Loader Class Initialized
DEBUG - 2018-07-16 21:46:00 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 21:46:00 --> Helper loaded: url_helper
INFO - 2018-07-16 21:46:00 --> Helper loaded: form_helper
INFO - 2018-07-16 21:46:00 --> Helper loaded: date_helper
INFO - 2018-07-16 21:46:00 --> Helper loaded: util_helper
INFO - 2018-07-16 21:46:00 --> Helper loaded: text_helper
INFO - 2018-07-16 21:46:00 --> Helper loaded: string_helper
INFO - 2018-07-16 21:46:00 --> Database Driver Class Initialized
DEBUG - 2018-07-16 21:46:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 21:46:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 21:46:00 --> Email Class Initialized
INFO - 2018-07-16 21:46:00 --> Controller Class Initialized
DEBUG - 2018-07-16 21:46:00 --> Admin MX_Controller Initialized
INFO - 2018-07-16 21:46:00 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 21:46:00 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-16 21:46:00 --> Login MX_Controller Initialized
DEBUG - 2018-07-16 21:46:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 21:46:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-16 21:46:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-16 21:46:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-16 21:46:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-16 21:46:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-16 21:46:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-16 21:46:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/dashboard.php
INFO - 2018-07-16 21:46:01 --> Final output sent to browser
DEBUG - 2018-07-16 21:46:01 --> Total execution time: 0.3419
INFO - 2018-07-16 21:46:01 --> Config Class Initialized
INFO - 2018-07-16 21:46:01 --> Hooks Class Initialized
DEBUG - 2018-07-16 21:46:01 --> UTF-8 Support Enabled
INFO - 2018-07-16 21:46:01 --> Utf8 Class Initialized
INFO - 2018-07-16 21:46:01 --> URI Class Initialized
INFO - 2018-07-16 21:46:01 --> Router Class Initialized
INFO - 2018-07-16 21:46:01 --> Output Class Initialized
INFO - 2018-07-16 21:46:01 --> Config Class Initialized
INFO - 2018-07-16 21:46:01 --> Hooks Class Initialized
INFO - 2018-07-16 21:46:01 --> Security Class Initialized
DEBUG - 2018-07-16 21:46:01 --> UTF-8 Support Enabled
INFO - 2018-07-16 21:46:01 --> Utf8 Class Initialized
INFO - 2018-07-16 21:46:01 --> URI Class Initialized
DEBUG - 2018-07-16 21:46:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 21:46:01 --> Input Class Initialized
INFO - 2018-07-16 21:46:01 --> Router Class Initialized
INFO - 2018-07-16 21:46:01 --> Language Class Initialized
INFO - 2018-07-16 21:46:01 --> Output Class Initialized
ERROR - 2018-07-16 21:46:01 --> 404 Page Not Found: /index
INFO - 2018-07-16 21:46:01 --> Security Class Initialized
DEBUG - 2018-07-16 21:46:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 21:46:01 --> Input Class Initialized
INFO - 2018-07-16 21:46:01 --> Language Class Initialized
ERROR - 2018-07-16 21:46:01 --> 404 Page Not Found: /index
INFO - 2018-07-16 21:46:01 --> Config Class Initialized
INFO - 2018-07-16 21:46:01 --> Hooks Class Initialized
DEBUG - 2018-07-16 21:46:01 --> UTF-8 Support Enabled
INFO - 2018-07-16 21:46:01 --> Utf8 Class Initialized
INFO - 2018-07-16 21:46:01 --> URI Class Initialized
INFO - 2018-07-16 21:46:01 --> Router Class Initialized
INFO - 2018-07-16 21:46:01 --> Output Class Initialized
INFO - 2018-07-16 21:46:01 --> Security Class Initialized
DEBUG - 2018-07-16 21:46:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 21:46:01 --> Input Class Initialized
INFO - 2018-07-16 21:46:01 --> Language Class Initialized
ERROR - 2018-07-16 21:46:01 --> 404 Page Not Found: /index
INFO - 2018-07-16 21:46:04 --> Config Class Initialized
INFO - 2018-07-16 21:46:04 --> Hooks Class Initialized
DEBUG - 2018-07-16 21:46:04 --> UTF-8 Support Enabled
INFO - 2018-07-16 21:46:04 --> Utf8 Class Initialized
INFO - 2018-07-16 21:46:04 --> URI Class Initialized
INFO - 2018-07-16 21:46:04 --> Router Class Initialized
INFO - 2018-07-16 21:46:04 --> Output Class Initialized
INFO - 2018-07-16 21:46:04 --> Security Class Initialized
DEBUG - 2018-07-16 21:46:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 21:46:04 --> Input Class Initialized
INFO - 2018-07-16 21:46:04 --> Language Class Initialized
INFO - 2018-07-16 21:46:04 --> Language Class Initialized
INFO - 2018-07-16 21:46:04 --> Config Class Initialized
INFO - 2018-07-16 21:46:04 --> Loader Class Initialized
DEBUG - 2018-07-16 21:46:04 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 21:46:04 --> Helper loaded: url_helper
INFO - 2018-07-16 21:46:04 --> Helper loaded: form_helper
INFO - 2018-07-16 21:46:04 --> Helper loaded: date_helper
INFO - 2018-07-16 21:46:04 --> Helper loaded: util_helper
INFO - 2018-07-16 21:46:04 --> Helper loaded: text_helper
INFO - 2018-07-16 21:46:04 --> Helper loaded: string_helper
INFO - 2018-07-16 21:46:04 --> Database Driver Class Initialized
DEBUG - 2018-07-16 21:46:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 21:46:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 21:46:04 --> Email Class Initialized
INFO - 2018-07-16 21:46:04 --> Controller Class Initialized
DEBUG - 2018-07-16 21:46:04 --> Users MX_Controller Initialized
DEBUG - 2018-07-16 21:46:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 21:46:04 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-16 21:46:04 --> Login MX_Controller Initialized
INFO - 2018-07-16 21:46:04 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 21:46:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-16 21:46:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-16 21:46:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-16 21:46:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-16 21:46:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-16 21:46:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-16 21:46:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-07-16 21:46:05 --> Final output sent to browser
DEBUG - 2018-07-16 21:46:05 --> Total execution time: 0.3665
INFO - 2018-07-16 21:46:05 --> Config Class Initialized
INFO - 2018-07-16 21:46:05 --> Hooks Class Initialized
DEBUG - 2018-07-16 21:46:05 --> UTF-8 Support Enabled
INFO - 2018-07-16 21:46:05 --> Utf8 Class Initialized
INFO - 2018-07-16 21:46:05 --> URI Class Initialized
INFO - 2018-07-16 21:46:05 --> Router Class Initialized
INFO - 2018-07-16 21:46:05 --> Output Class Initialized
INFO - 2018-07-16 21:46:05 --> Security Class Initialized
DEBUG - 2018-07-16 21:46:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 21:46:05 --> Input Class Initialized
INFO - 2018-07-16 21:46:05 --> Language Class Initialized
INFO - 2018-07-16 21:46:05 --> Language Class Initialized
INFO - 2018-07-16 21:46:05 --> Config Class Initialized
INFO - 2018-07-16 21:46:05 --> Loader Class Initialized
DEBUG - 2018-07-16 21:46:05 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 21:46:05 --> Helper loaded: url_helper
INFO - 2018-07-16 21:46:05 --> Helper loaded: form_helper
INFO - 2018-07-16 21:46:05 --> Helper loaded: date_helper
INFO - 2018-07-16 21:46:05 --> Helper loaded: util_helper
INFO - 2018-07-16 21:46:05 --> Helper loaded: text_helper
INFO - 2018-07-16 21:46:05 --> Helper loaded: string_helper
INFO - 2018-07-16 21:46:05 --> Database Driver Class Initialized
DEBUG - 2018-07-16 21:46:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 21:46:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 21:46:05 --> Email Class Initialized
INFO - 2018-07-16 21:46:05 --> Controller Class Initialized
DEBUG - 2018-07-16 21:46:05 --> Users MX_Controller Initialized
DEBUG - 2018-07-16 21:46:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 21:46:05 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-16 21:46:05 --> Login MX_Controller Initialized
INFO - 2018-07-16 21:46:05 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 21:46:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-16 21:46:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-16 21:46:05 --> Final output sent to browser
DEBUG - 2018-07-16 21:46:05 --> Total execution time: 0.4191
INFO - 2018-07-16 21:46:25 --> Config Class Initialized
INFO - 2018-07-16 21:46:25 --> Hooks Class Initialized
DEBUG - 2018-07-16 21:46:25 --> UTF-8 Support Enabled
INFO - 2018-07-16 21:46:25 --> Utf8 Class Initialized
INFO - 2018-07-16 21:46:25 --> URI Class Initialized
INFO - 2018-07-16 21:46:25 --> Router Class Initialized
INFO - 2018-07-16 21:46:25 --> Output Class Initialized
INFO - 2018-07-16 21:46:25 --> Security Class Initialized
DEBUG - 2018-07-16 21:46:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 21:46:25 --> Input Class Initialized
INFO - 2018-07-16 21:46:25 --> Language Class Initialized
INFO - 2018-07-16 21:46:25 --> Language Class Initialized
INFO - 2018-07-16 21:46:25 --> Config Class Initialized
INFO - 2018-07-16 21:46:25 --> Loader Class Initialized
DEBUG - 2018-07-16 21:46:25 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 21:46:25 --> Helper loaded: url_helper
INFO - 2018-07-16 21:46:25 --> Helper loaded: form_helper
INFO - 2018-07-16 21:46:25 --> Helper loaded: date_helper
INFO - 2018-07-16 21:46:25 --> Helper loaded: util_helper
INFO - 2018-07-16 21:46:25 --> Helper loaded: text_helper
INFO - 2018-07-16 21:46:25 --> Helper loaded: string_helper
INFO - 2018-07-16 21:46:25 --> Database Driver Class Initialized
DEBUG - 2018-07-16 21:46:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 21:46:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 21:46:25 --> Email Class Initialized
INFO - 2018-07-16 21:46:25 --> Controller Class Initialized
DEBUG - 2018-07-16 21:46:25 --> Users MX_Controller Initialized
DEBUG - 2018-07-16 21:46:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 21:46:25 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-16 21:46:25 --> Login MX_Controller Initialized
INFO - 2018-07-16 21:46:25 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 21:46:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-16 21:46:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-07-16 21:46:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-16 21:46:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-16 21:46:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-16 21:46:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-16 21:46:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-16 21:46:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-07-16 21:46:25 --> Final output sent to browser
DEBUG - 2018-07-16 21:46:25 --> Total execution time: 0.3670
INFO - 2018-07-16 21:51:49 --> Config Class Initialized
INFO - 2018-07-16 21:51:49 --> Hooks Class Initialized
DEBUG - 2018-07-16 21:51:50 --> UTF-8 Support Enabled
INFO - 2018-07-16 21:51:50 --> Utf8 Class Initialized
INFO - 2018-07-16 21:51:50 --> URI Class Initialized
DEBUG - 2018-07-16 21:51:50 --> No URI present. Default controller set.
INFO - 2018-07-16 21:51:50 --> Router Class Initialized
INFO - 2018-07-16 21:51:50 --> Output Class Initialized
INFO - 2018-07-16 21:51:50 --> Security Class Initialized
DEBUG - 2018-07-16 21:51:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 21:51:50 --> Input Class Initialized
INFO - 2018-07-16 21:51:50 --> Language Class Initialized
INFO - 2018-07-16 21:51:50 --> Language Class Initialized
INFO - 2018-07-16 21:51:50 --> Config Class Initialized
INFO - 2018-07-16 21:51:50 --> Loader Class Initialized
DEBUG - 2018-07-16 21:51:50 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 21:51:50 --> Helper loaded: url_helper
INFO - 2018-07-16 21:51:50 --> Helper loaded: form_helper
INFO - 2018-07-16 21:51:50 --> Helper loaded: date_helper
INFO - 2018-07-16 21:51:50 --> Helper loaded: util_helper
INFO - 2018-07-16 21:51:50 --> Helper loaded: text_helper
INFO - 2018-07-16 21:51:50 --> Helper loaded: string_helper
INFO - 2018-07-16 21:51:50 --> Database Driver Class Initialized
DEBUG - 2018-07-16 21:51:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 21:51:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 21:51:50 --> Email Class Initialized
INFO - 2018-07-16 21:51:50 --> Controller Class Initialized
DEBUG - 2018-07-16 21:51:50 --> Home MX_Controller Initialized
DEBUG - 2018-07-16 21:51:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-16 21:51:50 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-16 21:51:50 --> Login MX_Controller Initialized
INFO - 2018-07-16 21:51:50 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 21:51:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 21:51:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-16 21:51:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-07-16 21:51:54 --> Config Class Initialized
INFO - 2018-07-16 21:51:54 --> Hooks Class Initialized
DEBUG - 2018-07-16 21:51:54 --> UTF-8 Support Enabled
INFO - 2018-07-16 21:51:54 --> Utf8 Class Initialized
INFO - 2018-07-16 21:51:54 --> URI Class Initialized
INFO - 2018-07-16 21:51:54 --> Router Class Initialized
INFO - 2018-07-16 21:51:54 --> Output Class Initialized
INFO - 2018-07-16 21:51:54 --> Security Class Initialized
DEBUG - 2018-07-16 21:51:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 21:51:54 --> Input Class Initialized
INFO - 2018-07-16 21:51:54 --> Language Class Initialized
INFO - 2018-07-16 21:51:54 --> Language Class Initialized
INFO - 2018-07-16 21:51:54 --> Config Class Initialized
INFO - 2018-07-16 21:51:54 --> Loader Class Initialized
DEBUG - 2018-07-16 21:51:54 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 21:51:54 --> Helper loaded: url_helper
INFO - 2018-07-16 21:51:54 --> Helper loaded: form_helper
INFO - 2018-07-16 21:51:54 --> Helper loaded: date_helper
INFO - 2018-07-16 21:51:54 --> Helper loaded: util_helper
INFO - 2018-07-16 21:51:54 --> Helper loaded: text_helper
INFO - 2018-07-16 21:51:54 --> Helper loaded: string_helper
INFO - 2018-07-16 21:51:54 --> Database Driver Class Initialized
DEBUG - 2018-07-16 21:51:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 21:51:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 21:51:54 --> Email Class Initialized
INFO - 2018-07-16 21:51:54 --> Controller Class Initialized
DEBUG - 2018-07-16 21:51:54 --> Login MX_Controller Initialized
INFO - 2018-07-16 21:51:54 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 21:51:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 21:51:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-16 21:51:54 --> Email starts for user@colin.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-07-16 21:51:54 --> User session created for 4
INFO - 2018-07-16 21:51:55 --> Login status user@colin.com - success
INFO - 2018-07-16 21:51:55 --> Final output sent to browser
DEBUG - 2018-07-16 21:51:55 --> Total execution time: 0.3366
INFO - 2018-07-16 21:51:55 --> Config Class Initialized
INFO - 2018-07-16 21:51:55 --> Hooks Class Initialized
DEBUG - 2018-07-16 21:51:55 --> UTF-8 Support Enabled
INFO - 2018-07-16 21:51:55 --> Utf8 Class Initialized
INFO - 2018-07-16 21:51:55 --> URI Class Initialized
DEBUG - 2018-07-16 21:51:55 --> No URI present. Default controller set.
INFO - 2018-07-16 21:51:55 --> Router Class Initialized
INFO - 2018-07-16 21:51:55 --> Output Class Initialized
INFO - 2018-07-16 21:51:55 --> Security Class Initialized
DEBUG - 2018-07-16 21:51:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 21:51:55 --> Input Class Initialized
INFO - 2018-07-16 21:51:55 --> Language Class Initialized
INFO - 2018-07-16 21:51:55 --> Language Class Initialized
INFO - 2018-07-16 21:51:55 --> Config Class Initialized
INFO - 2018-07-16 21:51:55 --> Loader Class Initialized
DEBUG - 2018-07-16 21:51:55 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 21:51:55 --> Helper loaded: url_helper
INFO - 2018-07-16 21:51:55 --> Helper loaded: form_helper
INFO - 2018-07-16 21:51:55 --> Helper loaded: date_helper
INFO - 2018-07-16 21:51:55 --> Helper loaded: util_helper
INFO - 2018-07-16 21:51:55 --> Helper loaded: text_helper
INFO - 2018-07-16 21:51:55 --> Helper loaded: string_helper
INFO - 2018-07-16 21:51:55 --> Database Driver Class Initialized
DEBUG - 2018-07-16 21:51:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 21:51:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 21:51:55 --> Email Class Initialized
INFO - 2018-07-16 21:51:55 --> Controller Class Initialized
DEBUG - 2018-07-16 21:51:55 --> Home MX_Controller Initialized
DEBUG - 2018-07-16 21:51:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-16 21:51:55 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-16 21:51:55 --> Login MX_Controller Initialized
INFO - 2018-07-16 21:51:55 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 21:51:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 21:51:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-16 21:51:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-16 21:51:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-16 21:51:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-16 21:51:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-16 21:51:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-16 21:51:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-16 21:51:55 --> Final output sent to browser
DEBUG - 2018-07-16 21:51:55 --> Total execution time: 0.6514
INFO - 2018-07-16 21:51:56 --> Config Class Initialized
INFO - 2018-07-16 21:51:56 --> Hooks Class Initialized
DEBUG - 2018-07-16 21:51:56 --> UTF-8 Support Enabled
INFO - 2018-07-16 21:51:56 --> Utf8 Class Initialized
INFO - 2018-07-16 21:51:56 --> URI Class Initialized
INFO - 2018-07-16 21:51:56 --> Router Class Initialized
INFO - 2018-07-16 21:51:56 --> Output Class Initialized
INFO - 2018-07-16 21:51:56 --> Security Class Initialized
DEBUG - 2018-07-16 21:51:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 21:51:56 --> Input Class Initialized
INFO - 2018-07-16 21:51:56 --> Language Class Initialized
ERROR - 2018-07-16 21:51:56 --> 404 Page Not Found: /index
INFO - 2018-07-16 21:51:56 --> Config Class Initialized
INFO - 2018-07-16 21:51:56 --> Hooks Class Initialized
DEBUG - 2018-07-16 21:51:56 --> UTF-8 Support Enabled
INFO - 2018-07-16 21:51:56 --> Utf8 Class Initialized
INFO - 2018-07-16 21:51:56 --> URI Class Initialized
INFO - 2018-07-16 21:51:56 --> Router Class Initialized
INFO - 2018-07-16 21:51:56 --> Output Class Initialized
INFO - 2018-07-16 21:51:56 --> Security Class Initialized
DEBUG - 2018-07-16 21:51:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 21:51:56 --> Input Class Initialized
INFO - 2018-07-16 21:51:56 --> Language Class Initialized
ERROR - 2018-07-16 21:51:56 --> 404 Page Not Found: /index
INFO - 2018-07-16 21:51:56 --> Config Class Initialized
INFO - 2018-07-16 21:51:57 --> Hooks Class Initialized
DEBUG - 2018-07-16 21:51:57 --> UTF-8 Support Enabled
INFO - 2018-07-16 21:51:57 --> Utf8 Class Initialized
INFO - 2018-07-16 21:51:57 --> URI Class Initialized
INFO - 2018-07-16 21:51:57 --> Router Class Initialized
INFO - 2018-07-16 21:51:57 --> Output Class Initialized
INFO - 2018-07-16 21:51:57 --> Security Class Initialized
DEBUG - 2018-07-16 21:51:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 21:51:57 --> Input Class Initialized
INFO - 2018-07-16 21:51:57 --> Language Class Initialized
ERROR - 2018-07-16 21:51:57 --> 404 Page Not Found: /index
INFO - 2018-07-16 21:51:57 --> Config Class Initialized
INFO - 2018-07-16 21:51:57 --> Hooks Class Initialized
DEBUG - 2018-07-16 21:51:57 --> UTF-8 Support Enabled
INFO - 2018-07-16 21:51:57 --> Utf8 Class Initialized
INFO - 2018-07-16 21:51:57 --> URI Class Initialized
INFO - 2018-07-16 21:51:57 --> Router Class Initialized
INFO - 2018-07-16 21:51:57 --> Output Class Initialized
INFO - 2018-07-16 21:51:57 --> Security Class Initialized
DEBUG - 2018-07-16 21:51:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 21:51:57 --> Input Class Initialized
INFO - 2018-07-16 21:51:57 --> Language Class Initialized
ERROR - 2018-07-16 21:51:57 --> 404 Page Not Found: /index
INFO - 2018-07-16 21:51:57 --> Config Class Initialized
INFO - 2018-07-16 21:51:57 --> Hooks Class Initialized
DEBUG - 2018-07-16 21:51:57 --> UTF-8 Support Enabled
INFO - 2018-07-16 21:51:57 --> Utf8 Class Initialized
INFO - 2018-07-16 21:51:57 --> URI Class Initialized
INFO - 2018-07-16 21:51:57 --> Router Class Initialized
INFO - 2018-07-16 21:51:57 --> Output Class Initialized
INFO - 2018-07-16 21:51:57 --> Security Class Initialized
DEBUG - 2018-07-16 21:51:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 21:51:57 --> Input Class Initialized
INFO - 2018-07-16 21:51:57 --> Language Class Initialized
ERROR - 2018-07-16 21:51:57 --> 404 Page Not Found: /index
INFO - 2018-07-16 21:51:57 --> Config Class Initialized
INFO - 2018-07-16 21:51:57 --> Hooks Class Initialized
DEBUG - 2018-07-16 21:51:57 --> UTF-8 Support Enabled
INFO - 2018-07-16 21:51:57 --> Utf8 Class Initialized
INFO - 2018-07-16 21:51:57 --> URI Class Initialized
INFO - 2018-07-16 21:51:57 --> Router Class Initialized
INFO - 2018-07-16 21:51:57 --> Output Class Initialized
INFO - 2018-07-16 21:51:57 --> Security Class Initialized
DEBUG - 2018-07-16 21:51:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 21:51:57 --> Input Class Initialized
INFO - 2018-07-16 21:51:57 --> Language Class Initialized
ERROR - 2018-07-16 21:51:57 --> 404 Page Not Found: /index
INFO - 2018-07-16 21:51:59 --> Config Class Initialized
INFO - 2018-07-16 21:51:59 --> Hooks Class Initialized
DEBUG - 2018-07-16 21:51:59 --> UTF-8 Support Enabled
INFO - 2018-07-16 21:51:59 --> Utf8 Class Initialized
INFO - 2018-07-16 21:51:59 --> URI Class Initialized
INFO - 2018-07-16 21:51:59 --> Router Class Initialized
INFO - 2018-07-16 21:51:59 --> Output Class Initialized
INFO - 2018-07-16 21:51:59 --> Security Class Initialized
DEBUG - 2018-07-16 21:51:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 21:51:59 --> Input Class Initialized
INFO - 2018-07-16 21:51:59 --> Language Class Initialized
INFO - 2018-07-16 21:51:59 --> Language Class Initialized
INFO - 2018-07-16 21:51:59 --> Config Class Initialized
INFO - 2018-07-16 21:51:59 --> Loader Class Initialized
DEBUG - 2018-07-16 21:51:59 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 21:51:59 --> Helper loaded: url_helper
INFO - 2018-07-16 21:51:59 --> Helper loaded: form_helper
INFO - 2018-07-16 21:51:59 --> Helper loaded: date_helper
INFO - 2018-07-16 21:51:59 --> Helper loaded: util_helper
INFO - 2018-07-16 21:51:59 --> Helper loaded: text_helper
INFO - 2018-07-16 21:51:59 --> Helper loaded: string_helper
INFO - 2018-07-16 21:51:59 --> Database Driver Class Initialized
DEBUG - 2018-07-16 21:51:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 21:51:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 21:51:59 --> Email Class Initialized
INFO - 2018-07-16 21:51:59 --> Controller Class Initialized
DEBUG - 2018-07-16 21:51:59 --> Home MX_Controller Initialized
DEBUG - 2018-07-16 21:51:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-16 21:51:59 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-16 21:51:59 --> Login MX_Controller Initialized
INFO - 2018-07-16 21:51:59 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 21:51:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 21:51:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-16 21:52:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-16 21:52:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-16 21:52:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-16 21:52:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-16 21:52:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-16 21:52:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-07-16 21:52:00 --> Final output sent to browser
DEBUG - 2018-07-16 21:52:00 --> Total execution time: 0.5357
INFO - 2018-07-16 21:52:00 --> Config Class Initialized
INFO - 2018-07-16 21:52:00 --> Config Class Initialized
INFO - 2018-07-16 21:52:00 --> Hooks Class Initialized
INFO - 2018-07-16 21:52:00 --> Hooks Class Initialized
DEBUG - 2018-07-16 21:52:00 --> UTF-8 Support Enabled
DEBUG - 2018-07-16 21:52:00 --> UTF-8 Support Enabled
INFO - 2018-07-16 21:52:00 --> Utf8 Class Initialized
INFO - 2018-07-16 21:52:00 --> Utf8 Class Initialized
INFO - 2018-07-16 21:52:00 --> URI Class Initialized
INFO - 2018-07-16 21:52:00 --> URI Class Initialized
INFO - 2018-07-16 21:52:00 --> Router Class Initialized
INFO - 2018-07-16 21:52:00 --> Router Class Initialized
INFO - 2018-07-16 21:52:00 --> Output Class Initialized
INFO - 2018-07-16 21:52:00 --> Security Class Initialized
DEBUG - 2018-07-16 21:52:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 21:52:00 --> Input Class Initialized
INFO - 2018-07-16 21:52:00 --> Language Class Initialized
ERROR - 2018-07-16 21:52:00 --> 404 Page Not Found: /index
INFO - 2018-07-16 21:52:00 --> Output Class Initialized
INFO - 2018-07-16 21:52:00 --> Security Class Initialized
DEBUG - 2018-07-16 21:52:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 21:52:00 --> Input Class Initialized
INFO - 2018-07-16 21:52:00 --> Language Class Initialized
ERROR - 2018-07-16 21:52:00 --> 404 Page Not Found: /index
INFO - 2018-07-16 21:52:00 --> Config Class Initialized
INFO - 2018-07-16 21:52:00 --> Hooks Class Initialized
DEBUG - 2018-07-16 21:52:00 --> UTF-8 Support Enabled
INFO - 2018-07-16 21:52:00 --> Utf8 Class Initialized
INFO - 2018-07-16 21:52:00 --> URI Class Initialized
INFO - 2018-07-16 21:52:00 --> Router Class Initialized
INFO - 2018-07-16 21:52:00 --> Output Class Initialized
INFO - 2018-07-16 21:52:00 --> Security Class Initialized
DEBUG - 2018-07-16 21:52:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 21:52:00 --> Input Class Initialized
INFO - 2018-07-16 21:52:00 --> Language Class Initialized
ERROR - 2018-07-16 21:52:00 --> 404 Page Not Found: /index
INFO - 2018-07-16 21:52:00 --> Config Class Initialized
INFO - 2018-07-16 21:52:00 --> Hooks Class Initialized
DEBUG - 2018-07-16 21:52:00 --> UTF-8 Support Enabled
INFO - 2018-07-16 21:52:00 --> Utf8 Class Initialized
INFO - 2018-07-16 21:52:00 --> URI Class Initialized
INFO - 2018-07-16 21:52:00 --> Router Class Initialized
INFO - 2018-07-16 21:52:00 --> Output Class Initialized
INFO - 2018-07-16 21:52:00 --> Security Class Initialized
DEBUG - 2018-07-16 21:52:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 21:52:00 --> Input Class Initialized
INFO - 2018-07-16 21:52:00 --> Language Class Initialized
ERROR - 2018-07-16 21:52:00 --> 404 Page Not Found: /index
INFO - 2018-07-16 21:52:05 --> Config Class Initialized
INFO - 2018-07-16 21:52:05 --> Hooks Class Initialized
DEBUG - 2018-07-16 21:52:05 --> UTF-8 Support Enabled
INFO - 2018-07-16 21:52:05 --> Utf8 Class Initialized
INFO - 2018-07-16 21:52:05 --> URI Class Initialized
INFO - 2018-07-16 21:52:05 --> Router Class Initialized
INFO - 2018-07-16 21:52:05 --> Output Class Initialized
INFO - 2018-07-16 21:52:05 --> Security Class Initialized
DEBUG - 2018-07-16 21:52:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 21:52:05 --> Input Class Initialized
INFO - 2018-07-16 21:52:05 --> Language Class Initialized
INFO - 2018-07-16 21:52:05 --> Language Class Initialized
INFO - 2018-07-16 21:52:05 --> Config Class Initialized
INFO - 2018-07-16 21:52:05 --> Loader Class Initialized
DEBUG - 2018-07-16 21:52:05 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 21:52:05 --> Helper loaded: url_helper
INFO - 2018-07-16 21:52:05 --> Helper loaded: form_helper
INFO - 2018-07-16 21:52:05 --> Helper loaded: date_helper
INFO - 2018-07-16 21:52:05 --> Helper loaded: util_helper
INFO - 2018-07-16 21:52:05 --> Helper loaded: text_helper
INFO - 2018-07-16 21:52:05 --> Helper loaded: string_helper
INFO - 2018-07-16 21:52:05 --> Database Driver Class Initialized
DEBUG - 2018-07-16 21:52:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 21:52:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 21:52:05 --> Email Class Initialized
INFO - 2018-07-16 21:52:05 --> Controller Class Initialized
DEBUG - 2018-07-16 21:52:05 --> videos MX_Controller Initialized
INFO - 2018-07-16 21:52:05 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 21:52:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-07-16 21:52:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 21:52:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-07-16 21:52:05 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-16 21:52:05 --> Login MX_Controller Initialized
DEBUG - 2018-07-16 21:52:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-16 21:52:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-16 21:52:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-16 21:52:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-16 21:52:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-16 21:52:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-16 21:52:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/videos/videos.php
INFO - 2018-07-16 21:52:05 --> Final output sent to browser
DEBUG - 2018-07-16 21:52:06 --> Total execution time: 0.4956
INFO - 2018-07-16 21:52:06 --> Config Class Initialized
INFO - 2018-07-16 21:52:06 --> Hooks Class Initialized
DEBUG - 2018-07-16 21:52:06 --> UTF-8 Support Enabled
INFO - 2018-07-16 21:52:06 --> Utf8 Class Initialized
INFO - 2018-07-16 21:52:06 --> URI Class Initialized
INFO - 2018-07-16 21:52:06 --> Router Class Initialized
INFO - 2018-07-16 21:52:06 --> Output Class Initialized
INFO - 2018-07-16 21:52:06 --> Security Class Initialized
DEBUG - 2018-07-16 21:52:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 21:52:06 --> Input Class Initialized
INFO - 2018-07-16 21:52:06 --> Language Class Initialized
INFO - 2018-07-16 21:52:06 --> Language Class Initialized
INFO - 2018-07-16 21:52:06 --> Config Class Initialized
INFO - 2018-07-16 21:52:06 --> Loader Class Initialized
DEBUG - 2018-07-16 21:52:06 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 21:52:06 --> Helper loaded: url_helper
INFO - 2018-07-16 21:52:06 --> Helper loaded: form_helper
INFO - 2018-07-16 21:52:06 --> Helper loaded: date_helper
INFO - 2018-07-16 21:52:06 --> Helper loaded: util_helper
INFO - 2018-07-16 21:52:06 --> Helper loaded: text_helper
INFO - 2018-07-16 21:52:06 --> Helper loaded: string_helper
INFO - 2018-07-16 21:52:06 --> Database Driver Class Initialized
DEBUG - 2018-07-16 21:52:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 21:52:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 21:52:06 --> Email Class Initialized
INFO - 2018-07-16 21:52:06 --> Controller Class Initialized
DEBUG - 2018-07-16 21:52:06 --> videos MX_Controller Initialized
INFO - 2018-07-16 21:52:06 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 21:52:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-07-16 21:52:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 21:52:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-07-16 21:52:06 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-16 21:52:06 --> Login MX_Controller Initialized
DEBUG - 2018-07-16 21:52:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-16 21:52:06 --> Final output sent to browser
DEBUG - 2018-07-16 21:52:06 --> Total execution time: 0.4170
INFO - 2018-07-16 21:53:44 --> Config Class Initialized
INFO - 2018-07-16 21:53:44 --> Hooks Class Initialized
DEBUG - 2018-07-16 21:53:44 --> UTF-8 Support Enabled
INFO - 2018-07-16 21:53:44 --> Utf8 Class Initialized
INFO - 2018-07-16 21:53:44 --> URI Class Initialized
INFO - 2018-07-16 21:53:44 --> Router Class Initialized
INFO - 2018-07-16 21:53:44 --> Output Class Initialized
INFO - 2018-07-16 21:53:44 --> Security Class Initialized
DEBUG - 2018-07-16 21:53:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 21:53:44 --> Input Class Initialized
INFO - 2018-07-16 21:53:44 --> Language Class Initialized
INFO - 2018-07-16 21:53:44 --> Language Class Initialized
INFO - 2018-07-16 21:53:44 --> Config Class Initialized
INFO - 2018-07-16 21:53:44 --> Loader Class Initialized
DEBUG - 2018-07-16 21:53:44 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 21:53:44 --> Helper loaded: url_helper
INFO - 2018-07-16 21:53:44 --> Helper loaded: form_helper
INFO - 2018-07-16 21:53:44 --> Helper loaded: date_helper
INFO - 2018-07-16 21:53:44 --> Helper loaded: util_helper
INFO - 2018-07-16 21:53:44 --> Helper loaded: text_helper
INFO - 2018-07-16 21:53:44 --> Helper loaded: string_helper
INFO - 2018-07-16 21:53:44 --> Database Driver Class Initialized
DEBUG - 2018-07-16 21:53:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 21:53:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 21:53:44 --> Email Class Initialized
INFO - 2018-07-16 21:53:44 --> Controller Class Initialized
DEBUG - 2018-07-16 21:53:44 --> videos MX_Controller Initialized
INFO - 2018-07-16 21:53:44 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 21:53:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-07-16 21:53:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 21:53:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-07-16 21:53:44 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-16 21:53:44 --> Login MX_Controller Initialized
DEBUG - 2018-07-16 21:53:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-16 21:53:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-16 21:53:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-16 21:53:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-16 21:53:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-16 21:53:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-16 21:53:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/videos/videos.php
INFO - 2018-07-16 21:53:44 --> Final output sent to browser
DEBUG - 2018-07-16 21:53:45 --> Total execution time: 0.3830
INFO - 2018-07-16 21:53:45 --> Config Class Initialized
INFO - 2018-07-16 21:53:45 --> Hooks Class Initialized
DEBUG - 2018-07-16 21:53:45 --> UTF-8 Support Enabled
INFO - 2018-07-16 21:53:45 --> Utf8 Class Initialized
INFO - 2018-07-16 21:53:45 --> URI Class Initialized
INFO - 2018-07-16 21:53:45 --> Router Class Initialized
INFO - 2018-07-16 21:53:45 --> Output Class Initialized
INFO - 2018-07-16 21:53:45 --> Security Class Initialized
DEBUG - 2018-07-16 21:53:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 21:53:45 --> Input Class Initialized
INFO - 2018-07-16 21:53:45 --> Language Class Initialized
INFO - 2018-07-16 21:53:45 --> Language Class Initialized
INFO - 2018-07-16 21:53:45 --> Config Class Initialized
INFO - 2018-07-16 21:53:45 --> Loader Class Initialized
DEBUG - 2018-07-16 21:53:45 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 21:53:45 --> Helper loaded: url_helper
INFO - 2018-07-16 21:53:45 --> Helper loaded: form_helper
INFO - 2018-07-16 21:53:45 --> Helper loaded: date_helper
INFO - 2018-07-16 21:53:45 --> Helper loaded: util_helper
INFO - 2018-07-16 21:53:45 --> Helper loaded: text_helper
INFO - 2018-07-16 21:53:45 --> Helper loaded: string_helper
INFO - 2018-07-16 21:53:45 --> Database Driver Class Initialized
DEBUG - 2018-07-16 21:53:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 21:53:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 21:53:45 --> Email Class Initialized
INFO - 2018-07-16 21:53:45 --> Controller Class Initialized
DEBUG - 2018-07-16 21:53:45 --> videos MX_Controller Initialized
INFO - 2018-07-16 21:53:45 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 21:53:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-07-16 21:53:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 21:53:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-07-16 21:53:45 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-16 21:53:46 --> Login MX_Controller Initialized
DEBUG - 2018-07-16 21:53:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-16 21:53:46 --> Config Class Initialized
INFO - 2018-07-16 21:53:46 --> Final output sent to browser
INFO - 2018-07-16 21:53:46 --> Hooks Class Initialized
DEBUG - 2018-07-16 21:53:46 --> Total execution time: 0.4501
DEBUG - 2018-07-16 21:53:46 --> UTF-8 Support Enabled
INFO - 2018-07-16 21:53:46 --> Utf8 Class Initialized
INFO - 2018-07-16 21:53:46 --> URI Class Initialized
INFO - 2018-07-16 21:53:46 --> Router Class Initialized
INFO - 2018-07-16 21:53:46 --> Output Class Initialized
INFO - 2018-07-16 21:53:46 --> Security Class Initialized
DEBUG - 2018-07-16 21:53:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 21:53:46 --> Input Class Initialized
INFO - 2018-07-16 21:53:46 --> Language Class Initialized
INFO - 2018-07-16 21:53:46 --> Language Class Initialized
INFO - 2018-07-16 21:53:46 --> Config Class Initialized
INFO - 2018-07-16 21:53:46 --> Loader Class Initialized
DEBUG - 2018-07-16 21:53:46 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 21:53:46 --> Helper loaded: url_helper
INFO - 2018-07-16 21:53:46 --> Helper loaded: form_helper
INFO - 2018-07-16 21:53:46 --> Helper loaded: date_helper
INFO - 2018-07-16 21:53:46 --> Helper loaded: util_helper
INFO - 2018-07-16 21:53:46 --> Helper loaded: text_helper
INFO - 2018-07-16 21:53:46 --> Helper loaded: string_helper
INFO - 2018-07-16 21:53:46 --> Database Driver Class Initialized
DEBUG - 2018-07-16 21:53:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 21:53:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 21:53:46 --> Email Class Initialized
INFO - 2018-07-16 21:53:46 --> Controller Class Initialized
DEBUG - 2018-07-16 21:53:46 --> Users MX_Controller Initialized
DEBUG - 2018-07-16 21:53:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 21:53:46 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-16 21:53:46 --> Login MX_Controller Initialized
INFO - 2018-07-16 21:53:46 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 21:53:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-16 21:53:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-16 21:53:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-16 21:53:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-16 21:53:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-16 21:53:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-16 21:53:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-07-16 21:53:46 --> Final output sent to browser
DEBUG - 2018-07-16 21:53:46 --> Total execution time: 0.4119
INFO - 2018-07-16 21:53:46 --> Config Class Initialized
INFO - 2018-07-16 21:53:46 --> Hooks Class Initialized
DEBUG - 2018-07-16 21:53:46 --> UTF-8 Support Enabled
INFO - 2018-07-16 21:53:46 --> Utf8 Class Initialized
INFO - 2018-07-16 21:53:46 --> URI Class Initialized
INFO - 2018-07-16 21:53:46 --> Router Class Initialized
INFO - 2018-07-16 21:53:46 --> Output Class Initialized
INFO - 2018-07-16 21:53:46 --> Security Class Initialized
DEBUG - 2018-07-16 21:53:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 21:53:46 --> Input Class Initialized
INFO - 2018-07-16 21:53:46 --> Language Class Initialized
INFO - 2018-07-16 21:53:46 --> Language Class Initialized
INFO - 2018-07-16 21:53:46 --> Config Class Initialized
INFO - 2018-07-16 21:53:46 --> Loader Class Initialized
DEBUG - 2018-07-16 21:53:46 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 21:53:46 --> Helper loaded: url_helper
INFO - 2018-07-16 21:53:46 --> Helper loaded: form_helper
INFO - 2018-07-16 21:53:46 --> Helper loaded: date_helper
INFO - 2018-07-16 21:53:46 --> Helper loaded: util_helper
INFO - 2018-07-16 21:53:46 --> Helper loaded: text_helper
INFO - 2018-07-16 21:53:47 --> Helper loaded: string_helper
INFO - 2018-07-16 21:53:47 --> Database Driver Class Initialized
DEBUG - 2018-07-16 21:53:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 21:53:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 21:53:47 --> Email Class Initialized
INFO - 2018-07-16 21:53:47 --> Controller Class Initialized
DEBUG - 2018-07-16 21:53:47 --> Users MX_Controller Initialized
DEBUG - 2018-07-16 21:53:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 21:53:47 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-16 21:53:47 --> Login MX_Controller Initialized
INFO - 2018-07-16 21:53:47 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 21:53:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-16 21:53:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-16 21:53:47 --> Final output sent to browser
DEBUG - 2018-07-16 21:53:47 --> Total execution time: 0.4305
INFO - 2018-07-16 21:54:00 --> Config Class Initialized
INFO - 2018-07-16 21:54:00 --> Hooks Class Initialized
DEBUG - 2018-07-16 21:54:00 --> UTF-8 Support Enabled
INFO - 2018-07-16 21:54:00 --> Utf8 Class Initialized
INFO - 2018-07-16 21:54:00 --> URI Class Initialized
INFO - 2018-07-16 21:54:00 --> Router Class Initialized
INFO - 2018-07-16 21:54:00 --> Output Class Initialized
INFO - 2018-07-16 21:54:00 --> Security Class Initialized
DEBUG - 2018-07-16 21:54:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 21:54:00 --> Input Class Initialized
INFO - 2018-07-16 21:54:00 --> Language Class Initialized
INFO - 2018-07-16 21:54:00 --> Language Class Initialized
INFO - 2018-07-16 21:54:00 --> Config Class Initialized
INFO - 2018-07-16 21:54:00 --> Loader Class Initialized
DEBUG - 2018-07-16 21:54:00 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 21:54:00 --> Helper loaded: url_helper
INFO - 2018-07-16 21:54:00 --> Helper loaded: form_helper
INFO - 2018-07-16 21:54:00 --> Helper loaded: date_helper
INFO - 2018-07-16 21:54:00 --> Helper loaded: util_helper
INFO - 2018-07-16 21:54:00 --> Helper loaded: text_helper
INFO - 2018-07-16 21:54:00 --> Helper loaded: string_helper
INFO - 2018-07-16 21:54:00 --> Database Driver Class Initialized
DEBUG - 2018-07-16 21:54:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 21:54:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 21:54:00 --> Email Class Initialized
INFO - 2018-07-16 21:54:00 --> Controller Class Initialized
DEBUG - 2018-07-16 21:54:00 --> Users MX_Controller Initialized
DEBUG - 2018-07-16 21:54:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 21:54:00 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-16 21:54:00 --> Login MX_Controller Initialized
INFO - 2018-07-16 21:54:00 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 21:54:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-16 21:54:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-16 21:54:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-16 21:54:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-16 21:54:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-16 21:54:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-16 21:54:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-07-16 21:54:00 --> Final output sent to browser
DEBUG - 2018-07-16 21:54:00 --> Total execution time: 0.3700
INFO - 2018-07-16 21:54:01 --> Config Class Initialized
INFO - 2018-07-16 21:54:01 --> Hooks Class Initialized
DEBUG - 2018-07-16 21:54:01 --> UTF-8 Support Enabled
INFO - 2018-07-16 21:54:01 --> Utf8 Class Initialized
INFO - 2018-07-16 21:54:01 --> URI Class Initialized
INFO - 2018-07-16 21:54:01 --> Router Class Initialized
INFO - 2018-07-16 21:54:01 --> Output Class Initialized
INFO - 2018-07-16 21:54:01 --> Security Class Initialized
DEBUG - 2018-07-16 21:54:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 21:54:01 --> Input Class Initialized
INFO - 2018-07-16 21:54:01 --> Language Class Initialized
INFO - 2018-07-16 21:54:01 --> Language Class Initialized
INFO - 2018-07-16 21:54:01 --> Config Class Initialized
INFO - 2018-07-16 21:54:01 --> Loader Class Initialized
DEBUG - 2018-07-16 21:54:01 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 21:54:01 --> Helper loaded: url_helper
INFO - 2018-07-16 21:54:01 --> Helper loaded: form_helper
INFO - 2018-07-16 21:54:01 --> Helper loaded: date_helper
INFO - 2018-07-16 21:54:01 --> Helper loaded: util_helper
INFO - 2018-07-16 21:54:01 --> Helper loaded: text_helper
INFO - 2018-07-16 21:54:01 --> Helper loaded: string_helper
INFO - 2018-07-16 21:54:01 --> Database Driver Class Initialized
DEBUG - 2018-07-16 21:54:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 21:54:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 21:54:01 --> Email Class Initialized
INFO - 2018-07-16 21:54:01 --> Controller Class Initialized
DEBUG - 2018-07-16 21:54:01 --> Users MX_Controller Initialized
DEBUG - 2018-07-16 21:54:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 21:54:01 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-16 21:54:01 --> Login MX_Controller Initialized
INFO - 2018-07-16 21:54:01 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 21:54:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-16 21:54:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-16 21:54:01 --> Final output sent to browser
DEBUG - 2018-07-16 21:54:01 --> Total execution time: 0.4018
INFO - 2018-07-16 21:55:02 --> Config Class Initialized
INFO - 2018-07-16 21:55:02 --> Hooks Class Initialized
DEBUG - 2018-07-16 21:55:02 --> UTF-8 Support Enabled
INFO - 2018-07-16 21:55:02 --> Utf8 Class Initialized
INFO - 2018-07-16 21:55:02 --> URI Class Initialized
INFO - 2018-07-16 21:55:02 --> Router Class Initialized
INFO - 2018-07-16 21:55:02 --> Output Class Initialized
INFO - 2018-07-16 21:55:02 --> Security Class Initialized
DEBUG - 2018-07-16 21:55:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 21:55:02 --> Input Class Initialized
INFO - 2018-07-16 21:55:02 --> Language Class Initialized
INFO - 2018-07-16 21:55:02 --> Language Class Initialized
INFO - 2018-07-16 21:55:02 --> Config Class Initialized
INFO - 2018-07-16 21:55:02 --> Loader Class Initialized
DEBUG - 2018-07-16 21:55:02 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 21:55:02 --> Helper loaded: url_helper
INFO - 2018-07-16 21:55:02 --> Helper loaded: form_helper
INFO - 2018-07-16 21:55:02 --> Helper loaded: date_helper
INFO - 2018-07-16 21:55:02 --> Helper loaded: util_helper
INFO - 2018-07-16 21:55:02 --> Helper loaded: text_helper
INFO - 2018-07-16 21:55:02 --> Helper loaded: string_helper
INFO - 2018-07-16 21:55:02 --> Database Driver Class Initialized
DEBUG - 2018-07-16 21:55:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 21:55:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 21:55:02 --> Email Class Initialized
INFO - 2018-07-16 21:55:02 --> Controller Class Initialized
DEBUG - 2018-07-16 21:55:02 --> videos MX_Controller Initialized
INFO - 2018-07-16 21:55:02 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 21:55:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-07-16 21:55:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 21:55:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-07-16 21:55:02 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-16 21:55:02 --> Login MX_Controller Initialized
DEBUG - 2018-07-16 21:55:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-16 21:55:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-16 21:55:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-16 21:55:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-16 21:55:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-16 21:55:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-16 21:55:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/videos/videos.php
INFO - 2018-07-16 21:55:02 --> Final output sent to browser
DEBUG - 2018-07-16 21:55:02 --> Total execution time: 0.3905
INFO - 2018-07-16 21:55:02 --> Config Class Initialized
INFO - 2018-07-16 21:55:02 --> Hooks Class Initialized
DEBUG - 2018-07-16 21:55:02 --> UTF-8 Support Enabled
INFO - 2018-07-16 21:55:02 --> Utf8 Class Initialized
INFO - 2018-07-16 21:55:02 --> URI Class Initialized
INFO - 2018-07-16 21:55:02 --> Router Class Initialized
INFO - 2018-07-16 21:55:03 --> Output Class Initialized
INFO - 2018-07-16 21:55:03 --> Security Class Initialized
DEBUG - 2018-07-16 21:55:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 21:55:03 --> Input Class Initialized
INFO - 2018-07-16 21:55:03 --> Language Class Initialized
INFO - 2018-07-16 21:55:03 --> Language Class Initialized
INFO - 2018-07-16 21:55:03 --> Config Class Initialized
INFO - 2018-07-16 21:55:03 --> Loader Class Initialized
DEBUG - 2018-07-16 21:55:03 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 21:55:03 --> Helper loaded: url_helper
INFO - 2018-07-16 21:55:03 --> Helper loaded: form_helper
INFO - 2018-07-16 21:55:03 --> Helper loaded: date_helper
INFO - 2018-07-16 21:55:03 --> Helper loaded: util_helper
INFO - 2018-07-16 21:55:03 --> Helper loaded: text_helper
INFO - 2018-07-16 21:55:03 --> Helper loaded: string_helper
INFO - 2018-07-16 21:55:03 --> Database Driver Class Initialized
DEBUG - 2018-07-16 21:55:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 21:55:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 21:55:03 --> Email Class Initialized
INFO - 2018-07-16 21:55:03 --> Controller Class Initialized
DEBUG - 2018-07-16 21:55:03 --> videos MX_Controller Initialized
INFO - 2018-07-16 21:55:03 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 21:55:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-07-16 21:55:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 21:55:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-07-16 21:55:03 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-16 21:55:03 --> Login MX_Controller Initialized
DEBUG - 2018-07-16 21:55:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-16 21:55:03 --> Final output sent to browser
DEBUG - 2018-07-16 21:55:03 --> Total execution time: 0.4604
INFO - 2018-07-16 21:55:04 --> Config Class Initialized
INFO - 2018-07-16 21:55:04 --> Hooks Class Initialized
DEBUG - 2018-07-16 21:55:04 --> UTF-8 Support Enabled
INFO - 2018-07-16 21:55:04 --> Utf8 Class Initialized
INFO - 2018-07-16 21:55:04 --> URI Class Initialized
INFO - 2018-07-16 21:55:04 --> Router Class Initialized
INFO - 2018-07-16 21:55:04 --> Output Class Initialized
INFO - 2018-07-16 21:55:04 --> Security Class Initialized
DEBUG - 2018-07-16 21:55:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 21:55:04 --> Input Class Initialized
INFO - 2018-07-16 21:55:04 --> Language Class Initialized
INFO - 2018-07-16 21:55:04 --> Language Class Initialized
INFO - 2018-07-16 21:55:04 --> Config Class Initialized
INFO - 2018-07-16 21:55:04 --> Loader Class Initialized
DEBUG - 2018-07-16 21:55:04 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 21:55:04 --> Helper loaded: url_helper
INFO - 2018-07-16 21:55:04 --> Helper loaded: form_helper
INFO - 2018-07-16 21:55:04 --> Helper loaded: date_helper
INFO - 2018-07-16 21:55:04 --> Helper loaded: util_helper
INFO - 2018-07-16 21:55:04 --> Helper loaded: text_helper
INFO - 2018-07-16 21:55:04 --> Helper loaded: string_helper
INFO - 2018-07-16 21:55:04 --> Database Driver Class Initialized
DEBUG - 2018-07-16 21:55:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 21:55:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 21:55:04 --> Email Class Initialized
INFO - 2018-07-16 21:55:04 --> Controller Class Initialized
DEBUG - 2018-07-16 21:55:04 --> Users MX_Controller Initialized
DEBUG - 2018-07-16 21:55:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 21:55:04 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-16 21:55:04 --> Login MX_Controller Initialized
INFO - 2018-07-16 21:55:04 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 21:55:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-16 21:55:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-16 21:55:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-16 21:55:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-16 21:55:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-16 21:55:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-16 21:55:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-07-16 21:55:04 --> Final output sent to browser
DEBUG - 2018-07-16 21:55:04 --> Total execution time: 0.3816
INFO - 2018-07-16 21:55:04 --> Config Class Initialized
INFO - 2018-07-16 21:55:04 --> Hooks Class Initialized
DEBUG - 2018-07-16 21:55:05 --> UTF-8 Support Enabled
INFO - 2018-07-16 21:55:05 --> Utf8 Class Initialized
INFO - 2018-07-16 21:55:05 --> URI Class Initialized
INFO - 2018-07-16 21:55:05 --> Router Class Initialized
INFO - 2018-07-16 21:55:05 --> Output Class Initialized
INFO - 2018-07-16 21:55:05 --> Security Class Initialized
DEBUG - 2018-07-16 21:55:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 21:55:05 --> Input Class Initialized
INFO - 2018-07-16 21:55:05 --> Language Class Initialized
INFO - 2018-07-16 21:55:05 --> Language Class Initialized
INFO - 2018-07-16 21:55:05 --> Config Class Initialized
INFO - 2018-07-16 21:55:05 --> Loader Class Initialized
DEBUG - 2018-07-16 21:55:05 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 21:55:05 --> Helper loaded: url_helper
INFO - 2018-07-16 21:55:05 --> Helper loaded: form_helper
INFO - 2018-07-16 21:55:05 --> Helper loaded: date_helper
INFO - 2018-07-16 21:55:05 --> Helper loaded: util_helper
INFO - 2018-07-16 21:55:05 --> Helper loaded: text_helper
INFO - 2018-07-16 21:55:05 --> Helper loaded: string_helper
INFO - 2018-07-16 21:55:05 --> Database Driver Class Initialized
DEBUG - 2018-07-16 21:55:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 21:55:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 21:55:05 --> Email Class Initialized
INFO - 2018-07-16 21:55:05 --> Controller Class Initialized
DEBUG - 2018-07-16 21:55:05 --> Users MX_Controller Initialized
DEBUG - 2018-07-16 21:55:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 21:55:05 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-16 21:55:05 --> Login MX_Controller Initialized
INFO - 2018-07-16 21:55:05 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 21:55:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-16 21:55:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-16 21:55:05 --> Final output sent to browser
DEBUG - 2018-07-16 21:55:05 --> Total execution time: 0.4346
INFO - 2018-07-16 21:55:07 --> Config Class Initialized
INFO - 2018-07-16 21:55:07 --> Hooks Class Initialized
DEBUG - 2018-07-16 21:55:07 --> UTF-8 Support Enabled
INFO - 2018-07-16 21:55:07 --> Utf8 Class Initialized
INFO - 2018-07-16 21:55:07 --> URI Class Initialized
INFO - 2018-07-16 21:55:07 --> Router Class Initialized
INFO - 2018-07-16 21:55:07 --> Output Class Initialized
INFO - 2018-07-16 21:55:07 --> Security Class Initialized
DEBUG - 2018-07-16 21:55:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 21:55:07 --> Input Class Initialized
INFO - 2018-07-16 21:55:07 --> Language Class Initialized
INFO - 2018-07-16 21:55:07 --> Language Class Initialized
INFO - 2018-07-16 21:55:07 --> Config Class Initialized
INFO - 2018-07-16 21:55:07 --> Loader Class Initialized
DEBUG - 2018-07-16 21:55:07 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 21:55:07 --> Helper loaded: url_helper
INFO - 2018-07-16 21:55:07 --> Helper loaded: form_helper
INFO - 2018-07-16 21:55:07 --> Helper loaded: date_helper
INFO - 2018-07-16 21:55:07 --> Helper loaded: util_helper
INFO - 2018-07-16 21:55:07 --> Helper loaded: text_helper
INFO - 2018-07-16 21:55:07 --> Helper loaded: string_helper
INFO - 2018-07-16 21:55:07 --> Database Driver Class Initialized
DEBUG - 2018-07-16 21:55:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 21:55:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 21:55:07 --> Email Class Initialized
INFO - 2018-07-16 21:55:07 --> Controller Class Initialized
DEBUG - 2018-07-16 21:55:07 --> Users MX_Controller Initialized
DEBUG - 2018-07-16 21:55:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 21:55:07 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-16 21:55:07 --> Login MX_Controller Initialized
INFO - 2018-07-16 21:55:07 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 21:55:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-16 21:55:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-07-16 21:55:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-16 21:55:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-16 21:55:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-16 21:55:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-16 21:55:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-16 21:55:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-07-16 21:55:08 --> Final output sent to browser
DEBUG - 2018-07-16 21:55:08 --> Total execution time: 0.4066
INFO - 2018-07-16 21:55:12 --> Config Class Initialized
INFO - 2018-07-16 21:55:12 --> Hooks Class Initialized
DEBUG - 2018-07-16 21:55:12 --> UTF-8 Support Enabled
INFO - 2018-07-16 21:55:12 --> Utf8 Class Initialized
INFO - 2018-07-16 21:55:12 --> URI Class Initialized
INFO - 2018-07-16 21:55:12 --> Router Class Initialized
INFO - 2018-07-16 21:55:12 --> Output Class Initialized
INFO - 2018-07-16 21:55:12 --> Security Class Initialized
DEBUG - 2018-07-16 21:55:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 21:55:12 --> Input Class Initialized
INFO - 2018-07-16 21:55:12 --> Language Class Initialized
INFO - 2018-07-16 21:55:12 --> Language Class Initialized
INFO - 2018-07-16 21:55:12 --> Config Class Initialized
INFO - 2018-07-16 21:55:12 --> Loader Class Initialized
DEBUG - 2018-07-16 21:55:12 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 21:55:12 --> Helper loaded: url_helper
INFO - 2018-07-16 21:55:12 --> Helper loaded: form_helper
INFO - 2018-07-16 21:55:12 --> Helper loaded: date_helper
INFO - 2018-07-16 21:55:12 --> Helper loaded: util_helper
INFO - 2018-07-16 21:55:12 --> Helper loaded: text_helper
INFO - 2018-07-16 21:55:12 --> Helper loaded: string_helper
INFO - 2018-07-16 21:55:12 --> Database Driver Class Initialized
DEBUG - 2018-07-16 21:55:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 21:55:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 21:55:12 --> Email Class Initialized
INFO - 2018-07-16 21:55:12 --> Controller Class Initialized
DEBUG - 2018-07-16 21:55:12 --> Users MX_Controller Initialized
DEBUG - 2018-07-16 21:55:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 21:55:12 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-16 21:55:12 --> Login MX_Controller Initialized
INFO - 2018-07-16 21:55:12 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 21:55:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-16 21:55:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-16 21:55:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-16 21:55:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-16 21:55:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-16 21:55:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-16 21:55:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-07-16 21:55:12 --> Final output sent to browser
DEBUG - 2018-07-16 21:55:12 --> Total execution time: 0.4123
INFO - 2018-07-16 21:55:12 --> Config Class Initialized
INFO - 2018-07-16 21:55:12 --> Hooks Class Initialized
DEBUG - 2018-07-16 21:55:12 --> UTF-8 Support Enabled
INFO - 2018-07-16 21:55:12 --> Utf8 Class Initialized
INFO - 2018-07-16 21:55:12 --> URI Class Initialized
INFO - 2018-07-16 21:55:12 --> Router Class Initialized
INFO - 2018-07-16 21:55:12 --> Output Class Initialized
INFO - 2018-07-16 21:55:12 --> Security Class Initialized
DEBUG - 2018-07-16 21:55:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 21:55:12 --> Input Class Initialized
INFO - 2018-07-16 21:55:12 --> Language Class Initialized
INFO - 2018-07-16 21:55:12 --> Language Class Initialized
INFO - 2018-07-16 21:55:12 --> Config Class Initialized
INFO - 2018-07-16 21:55:12 --> Loader Class Initialized
DEBUG - 2018-07-16 21:55:12 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 21:55:13 --> Helper loaded: url_helper
INFO - 2018-07-16 21:55:13 --> Helper loaded: form_helper
INFO - 2018-07-16 21:55:13 --> Helper loaded: date_helper
INFO - 2018-07-16 21:55:13 --> Helper loaded: util_helper
INFO - 2018-07-16 21:55:13 --> Helper loaded: text_helper
INFO - 2018-07-16 21:55:13 --> Helper loaded: string_helper
INFO - 2018-07-16 21:55:13 --> Database Driver Class Initialized
DEBUG - 2018-07-16 21:55:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 21:55:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 21:55:13 --> Email Class Initialized
INFO - 2018-07-16 21:55:13 --> Controller Class Initialized
DEBUG - 2018-07-16 21:55:13 --> Users MX_Controller Initialized
DEBUG - 2018-07-16 21:55:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 21:55:13 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-16 21:55:13 --> Login MX_Controller Initialized
INFO - 2018-07-16 21:55:13 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 21:55:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-16 21:55:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-16 21:55:13 --> Final output sent to browser
DEBUG - 2018-07-16 21:55:13 --> Total execution time: 0.4852
INFO - 2018-07-16 21:57:27 --> Config Class Initialized
INFO - 2018-07-16 21:57:27 --> Hooks Class Initialized
DEBUG - 2018-07-16 21:57:27 --> UTF-8 Support Enabled
INFO - 2018-07-16 21:57:27 --> Utf8 Class Initialized
INFO - 2018-07-16 21:57:27 --> URI Class Initialized
INFO - 2018-07-16 21:57:27 --> Router Class Initialized
INFO - 2018-07-16 21:57:27 --> Output Class Initialized
INFO - 2018-07-16 21:57:27 --> Security Class Initialized
DEBUG - 2018-07-16 21:57:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 21:57:27 --> Input Class Initialized
INFO - 2018-07-16 21:57:28 --> Language Class Initialized
INFO - 2018-07-16 21:57:28 --> Language Class Initialized
INFO - 2018-07-16 21:57:28 --> Config Class Initialized
INFO - 2018-07-16 21:57:28 --> Loader Class Initialized
DEBUG - 2018-07-16 21:57:28 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 21:57:28 --> Helper loaded: url_helper
INFO - 2018-07-16 21:57:28 --> Helper loaded: form_helper
INFO - 2018-07-16 21:57:28 --> Helper loaded: date_helper
INFO - 2018-07-16 21:57:28 --> Helper loaded: util_helper
INFO - 2018-07-16 21:57:28 --> Helper loaded: text_helper
INFO - 2018-07-16 21:57:28 --> Helper loaded: string_helper
INFO - 2018-07-16 21:57:28 --> Database Driver Class Initialized
DEBUG - 2018-07-16 21:57:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 21:57:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 21:57:28 --> Email Class Initialized
INFO - 2018-07-16 21:57:28 --> Controller Class Initialized
DEBUG - 2018-07-16 21:57:28 --> Users MX_Controller Initialized
DEBUG - 2018-07-16 21:57:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 21:57:28 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-16 21:57:28 --> Login MX_Controller Initialized
INFO - 2018-07-16 21:57:28 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 21:57:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-16 21:57:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-16 21:57:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-16 21:57:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-16 21:57:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-16 21:57:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-16 21:57:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-07-16 21:57:28 --> Final output sent to browser
DEBUG - 2018-07-16 21:57:28 --> Total execution time: 0.4581
INFO - 2018-07-16 21:57:28 --> Config Class Initialized
INFO - 2018-07-16 21:57:28 --> Hooks Class Initialized
DEBUG - 2018-07-16 21:57:28 --> UTF-8 Support Enabled
INFO - 2018-07-16 21:57:28 --> Utf8 Class Initialized
INFO - 2018-07-16 21:57:28 --> URI Class Initialized
INFO - 2018-07-16 21:57:28 --> Router Class Initialized
INFO - 2018-07-16 21:57:29 --> Output Class Initialized
INFO - 2018-07-16 21:57:29 --> Security Class Initialized
DEBUG - 2018-07-16 21:57:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 21:57:29 --> Input Class Initialized
INFO - 2018-07-16 21:57:29 --> Language Class Initialized
INFO - 2018-07-16 21:57:29 --> Language Class Initialized
INFO - 2018-07-16 21:57:29 --> Config Class Initialized
INFO - 2018-07-16 21:57:29 --> Loader Class Initialized
DEBUG - 2018-07-16 21:57:29 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 21:57:29 --> Helper loaded: url_helper
INFO - 2018-07-16 21:57:29 --> Helper loaded: form_helper
INFO - 2018-07-16 21:57:29 --> Helper loaded: date_helper
INFO - 2018-07-16 21:57:29 --> Helper loaded: util_helper
INFO - 2018-07-16 21:57:29 --> Helper loaded: text_helper
INFO - 2018-07-16 21:57:29 --> Helper loaded: string_helper
INFO - 2018-07-16 21:57:29 --> Database Driver Class Initialized
DEBUG - 2018-07-16 21:57:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 21:57:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 21:57:29 --> Email Class Initialized
INFO - 2018-07-16 21:57:29 --> Controller Class Initialized
DEBUG - 2018-07-16 21:57:29 --> Users MX_Controller Initialized
DEBUG - 2018-07-16 21:57:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 21:57:29 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-16 21:57:29 --> Login MX_Controller Initialized
INFO - 2018-07-16 21:57:29 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 21:57:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-16 21:57:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-16 21:57:29 --> Final output sent to browser
DEBUG - 2018-07-16 21:57:29 --> Total execution time: 0.4436
INFO - 2018-07-16 21:57:31 --> Config Class Initialized
INFO - 2018-07-16 21:57:31 --> Hooks Class Initialized
DEBUG - 2018-07-16 21:57:31 --> UTF-8 Support Enabled
INFO - 2018-07-16 21:57:31 --> Utf8 Class Initialized
INFO - 2018-07-16 21:57:31 --> URI Class Initialized
INFO - 2018-07-16 21:57:31 --> Router Class Initialized
INFO - 2018-07-16 21:57:31 --> Output Class Initialized
INFO - 2018-07-16 21:57:31 --> Security Class Initialized
DEBUG - 2018-07-16 21:57:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 21:57:31 --> Input Class Initialized
INFO - 2018-07-16 21:57:31 --> Language Class Initialized
ERROR - 2018-07-16 21:57:31 --> 404 Page Not Found: /index
INFO - 2018-07-16 21:57:32 --> Config Class Initialized
INFO - 2018-07-16 21:57:32 --> Hooks Class Initialized
DEBUG - 2018-07-16 21:57:32 --> UTF-8 Support Enabled
INFO - 2018-07-16 21:57:32 --> Utf8 Class Initialized
INFO - 2018-07-16 21:57:32 --> URI Class Initialized
INFO - 2018-07-16 21:57:32 --> Router Class Initialized
INFO - 2018-07-16 21:57:32 --> Output Class Initialized
INFO - 2018-07-16 21:57:32 --> Security Class Initialized
DEBUG - 2018-07-16 21:57:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 21:57:32 --> Input Class Initialized
INFO - 2018-07-16 21:57:32 --> Language Class Initialized
ERROR - 2018-07-16 21:57:32 --> 404 Page Not Found: /index
INFO - 2018-07-16 21:57:32 --> Config Class Initialized
INFO - 2018-07-16 21:57:32 --> Hooks Class Initialized
DEBUG - 2018-07-16 21:57:32 --> UTF-8 Support Enabled
INFO - 2018-07-16 21:57:32 --> Utf8 Class Initialized
INFO - 2018-07-16 21:57:32 --> URI Class Initialized
INFO - 2018-07-16 21:57:32 --> Router Class Initialized
INFO - 2018-07-16 21:57:32 --> Output Class Initialized
INFO - 2018-07-16 21:57:32 --> Security Class Initialized
DEBUG - 2018-07-16 21:57:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 21:57:32 --> Input Class Initialized
INFO - 2018-07-16 21:57:32 --> Language Class Initialized
ERROR - 2018-07-16 21:57:32 --> 404 Page Not Found: /index
INFO - 2018-07-16 21:57:32 --> Config Class Initialized
INFO - 2018-07-16 21:57:32 --> Hooks Class Initialized
DEBUG - 2018-07-16 21:57:32 --> UTF-8 Support Enabled
INFO - 2018-07-16 21:57:32 --> Utf8 Class Initialized
INFO - 2018-07-16 21:57:32 --> URI Class Initialized
INFO - 2018-07-16 21:57:32 --> Router Class Initialized
INFO - 2018-07-16 21:57:32 --> Output Class Initialized
INFO - 2018-07-16 21:57:32 --> Security Class Initialized
DEBUG - 2018-07-16 21:57:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 21:57:32 --> Input Class Initialized
INFO - 2018-07-16 21:57:32 --> Language Class Initialized
ERROR - 2018-07-16 21:57:32 --> 404 Page Not Found: /index
INFO - 2018-07-16 21:57:37 --> Config Class Initialized
INFO - 2018-07-16 21:57:37 --> Hooks Class Initialized
DEBUG - 2018-07-16 21:57:37 --> UTF-8 Support Enabled
INFO - 2018-07-16 21:57:37 --> Utf8 Class Initialized
INFO - 2018-07-16 21:57:37 --> URI Class Initialized
INFO - 2018-07-16 21:57:37 --> Router Class Initialized
INFO - 2018-07-16 21:57:37 --> Output Class Initialized
INFO - 2018-07-16 21:57:37 --> Security Class Initialized
DEBUG - 2018-07-16 21:57:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 21:57:37 --> Input Class Initialized
INFO - 2018-07-16 21:57:37 --> Language Class Initialized
ERROR - 2018-07-16 21:57:37 --> 404 Page Not Found: /index
INFO - 2018-07-16 21:58:05 --> Config Class Initialized
INFO - 2018-07-16 21:58:05 --> Hooks Class Initialized
DEBUG - 2018-07-16 21:58:05 --> UTF-8 Support Enabled
INFO - 2018-07-16 21:58:05 --> Utf8 Class Initialized
INFO - 2018-07-16 21:58:05 --> URI Class Initialized
INFO - 2018-07-16 21:58:05 --> Router Class Initialized
INFO - 2018-07-16 21:58:05 --> Output Class Initialized
INFO - 2018-07-16 21:58:05 --> Security Class Initialized
DEBUG - 2018-07-16 21:58:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 21:58:05 --> Input Class Initialized
INFO - 2018-07-16 21:58:05 --> Language Class Initialized
ERROR - 2018-07-16 21:58:05 --> 404 Page Not Found: /index
INFO - 2018-07-16 21:59:39 --> Config Class Initialized
INFO - 2018-07-16 21:59:39 --> Hooks Class Initialized
DEBUG - 2018-07-16 21:59:39 --> UTF-8 Support Enabled
INFO - 2018-07-16 21:59:39 --> Utf8 Class Initialized
INFO - 2018-07-16 21:59:39 --> URI Class Initialized
DEBUG - 2018-07-16 21:59:39 --> No URI present. Default controller set.
INFO - 2018-07-16 21:59:39 --> Router Class Initialized
INFO - 2018-07-16 21:59:39 --> Output Class Initialized
INFO - 2018-07-16 21:59:39 --> Security Class Initialized
DEBUG - 2018-07-16 21:59:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 21:59:39 --> Input Class Initialized
INFO - 2018-07-16 21:59:39 --> Language Class Initialized
INFO - 2018-07-16 21:59:39 --> Language Class Initialized
INFO - 2018-07-16 21:59:39 --> Config Class Initialized
INFO - 2018-07-16 21:59:39 --> Loader Class Initialized
DEBUG - 2018-07-16 21:59:39 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 21:59:39 --> Helper loaded: url_helper
INFO - 2018-07-16 21:59:39 --> Helper loaded: form_helper
INFO - 2018-07-16 21:59:39 --> Helper loaded: date_helper
INFO - 2018-07-16 21:59:39 --> Helper loaded: util_helper
INFO - 2018-07-16 21:59:39 --> Helper loaded: text_helper
INFO - 2018-07-16 21:59:39 --> Helper loaded: string_helper
INFO - 2018-07-16 21:59:39 --> Database Driver Class Initialized
DEBUG - 2018-07-16 21:59:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 21:59:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 21:59:39 --> Email Class Initialized
INFO - 2018-07-16 21:59:39 --> Controller Class Initialized
DEBUG - 2018-07-16 21:59:39 --> Home MX_Controller Initialized
DEBUG - 2018-07-16 21:59:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-16 21:59:39 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-16 21:59:39 --> Login MX_Controller Initialized
INFO - 2018-07-16 21:59:39 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 21:59:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 21:59:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-16 21:59:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-16 21:59:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-16 21:59:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-16 21:59:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-16 21:59:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-16 21:59:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-16 21:59:39 --> Final output sent to browser
DEBUG - 2018-07-16 21:59:39 --> Total execution time: 0.4058
INFO - 2018-07-16 21:59:40 --> Config Class Initialized
INFO - 2018-07-16 21:59:40 --> Hooks Class Initialized
DEBUG - 2018-07-16 21:59:40 --> UTF-8 Support Enabled
INFO - 2018-07-16 21:59:40 --> Utf8 Class Initialized
INFO - 2018-07-16 21:59:40 --> URI Class Initialized
INFO - 2018-07-16 21:59:40 --> Router Class Initialized
INFO - 2018-07-16 21:59:40 --> Output Class Initialized
INFO - 2018-07-16 21:59:40 --> Security Class Initialized
DEBUG - 2018-07-16 21:59:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 21:59:40 --> Input Class Initialized
INFO - 2018-07-16 21:59:40 --> Language Class Initialized
ERROR - 2018-07-16 21:59:40 --> 404 Page Not Found: /index
INFO - 2018-07-16 21:59:40 --> Config Class Initialized
INFO - 2018-07-16 21:59:40 --> Hooks Class Initialized
DEBUG - 2018-07-16 21:59:40 --> UTF-8 Support Enabled
INFO - 2018-07-16 21:59:40 --> Utf8 Class Initialized
INFO - 2018-07-16 21:59:40 --> URI Class Initialized
INFO - 2018-07-16 21:59:40 --> Router Class Initialized
INFO - 2018-07-16 21:59:40 --> Output Class Initialized
INFO - 2018-07-16 21:59:40 --> Security Class Initialized
DEBUG - 2018-07-16 21:59:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 21:59:40 --> Input Class Initialized
INFO - 2018-07-16 21:59:40 --> Language Class Initialized
ERROR - 2018-07-16 21:59:40 --> 404 Page Not Found: /index
INFO - 2018-07-16 21:59:40 --> Config Class Initialized
INFO - 2018-07-16 21:59:40 --> Hooks Class Initialized
DEBUG - 2018-07-16 21:59:40 --> UTF-8 Support Enabled
INFO - 2018-07-16 21:59:40 --> Utf8 Class Initialized
INFO - 2018-07-16 21:59:40 --> URI Class Initialized
INFO - 2018-07-16 21:59:40 --> Router Class Initialized
INFO - 2018-07-16 21:59:40 --> Output Class Initialized
INFO - 2018-07-16 21:59:40 --> Security Class Initialized
DEBUG - 2018-07-16 21:59:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 21:59:40 --> Input Class Initialized
INFO - 2018-07-16 21:59:40 --> Language Class Initialized
ERROR - 2018-07-16 21:59:40 --> 404 Page Not Found: /index
INFO - 2018-07-16 21:59:40 --> Config Class Initialized
INFO - 2018-07-16 21:59:40 --> Hooks Class Initialized
DEBUG - 2018-07-16 21:59:40 --> UTF-8 Support Enabled
INFO - 2018-07-16 21:59:40 --> Utf8 Class Initialized
INFO - 2018-07-16 21:59:40 --> URI Class Initialized
INFO - 2018-07-16 21:59:40 --> Router Class Initialized
INFO - 2018-07-16 21:59:40 --> Output Class Initialized
INFO - 2018-07-16 21:59:40 --> Security Class Initialized
DEBUG - 2018-07-16 21:59:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 21:59:40 --> Input Class Initialized
INFO - 2018-07-16 21:59:40 --> Language Class Initialized
ERROR - 2018-07-16 21:59:40 --> 404 Page Not Found: /index
INFO - 2018-07-16 21:59:40 --> Config Class Initialized
INFO - 2018-07-16 21:59:40 --> Hooks Class Initialized
DEBUG - 2018-07-16 21:59:40 --> UTF-8 Support Enabled
INFO - 2018-07-16 21:59:40 --> Utf8 Class Initialized
INFO - 2018-07-16 21:59:40 --> URI Class Initialized
INFO - 2018-07-16 21:59:40 --> Router Class Initialized
INFO - 2018-07-16 21:59:40 --> Output Class Initialized
INFO - 2018-07-16 21:59:40 --> Security Class Initialized
DEBUG - 2018-07-16 21:59:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 21:59:40 --> Input Class Initialized
INFO - 2018-07-16 21:59:40 --> Language Class Initialized
ERROR - 2018-07-16 21:59:40 --> 404 Page Not Found: /index
INFO - 2018-07-16 21:59:40 --> Config Class Initialized
INFO - 2018-07-16 21:59:40 --> Hooks Class Initialized
DEBUG - 2018-07-16 21:59:40 --> UTF-8 Support Enabled
INFO - 2018-07-16 21:59:40 --> Utf8 Class Initialized
INFO - 2018-07-16 21:59:40 --> URI Class Initialized
INFO - 2018-07-16 21:59:40 --> Router Class Initialized
INFO - 2018-07-16 21:59:40 --> Output Class Initialized
INFO - 2018-07-16 21:59:40 --> Security Class Initialized
DEBUG - 2018-07-16 21:59:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 21:59:41 --> Input Class Initialized
INFO - 2018-07-16 21:59:41 --> Language Class Initialized
ERROR - 2018-07-16 21:59:41 --> 404 Page Not Found: /index
INFO - 2018-07-16 22:02:43 --> Config Class Initialized
INFO - 2018-07-16 22:02:43 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:02:43 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:02:43 --> Utf8 Class Initialized
INFO - 2018-07-16 22:02:43 --> URI Class Initialized
INFO - 2018-07-16 22:02:43 --> Router Class Initialized
INFO - 2018-07-16 22:02:43 --> Output Class Initialized
INFO - 2018-07-16 22:02:43 --> Security Class Initialized
DEBUG - 2018-07-16 22:02:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:02:43 --> Input Class Initialized
INFO - 2018-07-16 22:02:43 --> Language Class Initialized
INFO - 2018-07-16 22:02:43 --> Language Class Initialized
INFO - 2018-07-16 22:02:43 --> Config Class Initialized
INFO - 2018-07-16 22:02:43 --> Loader Class Initialized
DEBUG - 2018-07-16 22:02:43 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 22:02:43 --> Helper loaded: url_helper
INFO - 2018-07-16 22:02:43 --> Helper loaded: form_helper
INFO - 2018-07-16 22:02:43 --> Helper loaded: date_helper
INFO - 2018-07-16 22:02:43 --> Helper loaded: util_helper
INFO - 2018-07-16 22:02:43 --> Helper loaded: text_helper
INFO - 2018-07-16 22:02:43 --> Helper loaded: string_helper
INFO - 2018-07-16 22:02:43 --> Database Driver Class Initialized
DEBUG - 2018-07-16 22:02:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 22:02:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 22:02:43 --> Email Class Initialized
INFO - 2018-07-16 22:02:43 --> Controller Class Initialized
DEBUG - 2018-07-16 22:02:43 --> Home MX_Controller Initialized
DEBUG - 2018-07-16 22:02:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-16 22:02:43 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-16 22:02:43 --> Login MX_Controller Initialized
INFO - 2018-07-16 22:02:43 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 22:02:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 22:02:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-16 22:02:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-16 22:02:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-16 22:02:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-16 22:02:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-16 22:02:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-16 22:02:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-07-16 22:02:43 --> Final output sent to browser
DEBUG - 2018-07-16 22:02:43 --> Total execution time: 0.4054
INFO - 2018-07-16 22:02:44 --> Config Class Initialized
INFO - 2018-07-16 22:02:44 --> Config Class Initialized
INFO - 2018-07-16 22:02:44 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:02:44 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:02:44 --> Utf8 Class Initialized
INFO - 2018-07-16 22:02:44 --> URI Class Initialized
INFO - 2018-07-16 22:02:44 --> Router Class Initialized
INFO - 2018-07-16 22:02:44 --> Hooks Class Initialized
INFO - 2018-07-16 22:02:44 --> Output Class Initialized
DEBUG - 2018-07-16 22:02:44 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:02:44 --> Utf8 Class Initialized
INFO - 2018-07-16 22:02:44 --> URI Class Initialized
INFO - 2018-07-16 22:02:44 --> Router Class Initialized
INFO - 2018-07-16 22:02:44 --> Output Class Initialized
INFO - 2018-07-16 22:02:44 --> Security Class Initialized
DEBUG - 2018-07-16 22:02:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:02:44 --> Input Class Initialized
INFO - 2018-07-16 22:02:44 --> Language Class Initialized
ERROR - 2018-07-16 22:02:44 --> 404 Page Not Found: /index
INFO - 2018-07-16 22:02:44 --> Security Class Initialized
DEBUG - 2018-07-16 22:02:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:02:44 --> Input Class Initialized
INFO - 2018-07-16 22:02:44 --> Config Class Initialized
INFO - 2018-07-16 22:02:44 --> Language Class Initialized
ERROR - 2018-07-16 22:02:44 --> 404 Page Not Found: /index
INFO - 2018-07-16 22:02:44 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:02:44 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:02:44 --> Utf8 Class Initialized
INFO - 2018-07-16 22:02:44 --> URI Class Initialized
INFO - 2018-07-16 22:02:44 --> Router Class Initialized
INFO - 2018-07-16 22:02:44 --> Output Class Initialized
INFO - 2018-07-16 22:02:44 --> Security Class Initialized
DEBUG - 2018-07-16 22:02:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:02:44 --> Input Class Initialized
INFO - 2018-07-16 22:02:44 --> Language Class Initialized
ERROR - 2018-07-16 22:02:44 --> 404 Page Not Found: /index
INFO - 2018-07-16 22:02:44 --> Config Class Initialized
INFO - 2018-07-16 22:02:45 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:02:45 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:02:45 --> Utf8 Class Initialized
INFO - 2018-07-16 22:02:45 --> URI Class Initialized
INFO - 2018-07-16 22:02:45 --> Router Class Initialized
INFO - 2018-07-16 22:02:45 --> Output Class Initialized
INFO - 2018-07-16 22:02:45 --> Security Class Initialized
DEBUG - 2018-07-16 22:02:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:02:45 --> Input Class Initialized
INFO - 2018-07-16 22:02:45 --> Language Class Initialized
ERROR - 2018-07-16 22:02:45 --> 404 Page Not Found: /index
INFO - 2018-07-16 22:03:01 --> Config Class Initialized
INFO - 2018-07-16 22:03:01 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:03:01 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:03:01 --> Utf8 Class Initialized
INFO - 2018-07-16 22:03:01 --> URI Class Initialized
INFO - 2018-07-16 22:03:01 --> Router Class Initialized
INFO - 2018-07-16 22:03:01 --> Output Class Initialized
INFO - 2018-07-16 22:03:01 --> Security Class Initialized
DEBUG - 2018-07-16 22:03:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:03:01 --> Input Class Initialized
INFO - 2018-07-16 22:03:01 --> Language Class Initialized
INFO - 2018-07-16 22:03:01 --> Language Class Initialized
INFO - 2018-07-16 22:03:01 --> Config Class Initialized
INFO - 2018-07-16 22:03:01 --> Loader Class Initialized
DEBUG - 2018-07-16 22:03:01 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 22:03:01 --> Helper loaded: url_helper
INFO - 2018-07-16 22:03:01 --> Helper loaded: form_helper
INFO - 2018-07-16 22:03:01 --> Helper loaded: date_helper
INFO - 2018-07-16 22:03:01 --> Helper loaded: util_helper
INFO - 2018-07-16 22:03:01 --> Helper loaded: text_helper
INFO - 2018-07-16 22:03:01 --> Helper loaded: string_helper
INFO - 2018-07-16 22:03:01 --> Database Driver Class Initialized
DEBUG - 2018-07-16 22:03:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 22:03:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 22:03:01 --> Email Class Initialized
INFO - 2018-07-16 22:03:01 --> Controller Class Initialized
DEBUG - 2018-07-16 22:03:01 --> Home MX_Controller Initialized
DEBUG - 2018-07-16 22:03:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-16 22:03:01 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-16 22:03:01 --> Login MX_Controller Initialized
INFO - 2018-07-16 22:03:01 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 22:03:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 22:03:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-16 22:03:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-16 22:03:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-16 22:03:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-16 22:03:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-16 22:03:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-16 22:03:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/progress.php
INFO - 2018-07-16 22:03:01 --> Final output sent to browser
DEBUG - 2018-07-16 22:03:01 --> Total execution time: 0.4682
INFO - 2018-07-16 22:03:02 --> Config Class Initialized
INFO - 2018-07-16 22:03:02 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:03:02 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:03:02 --> Utf8 Class Initialized
INFO - 2018-07-16 22:03:02 --> URI Class Initialized
INFO - 2018-07-16 22:03:02 --> Router Class Initialized
INFO - 2018-07-16 22:03:02 --> Output Class Initialized
INFO - 2018-07-16 22:03:02 --> Security Class Initialized
DEBUG - 2018-07-16 22:03:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:03:02 --> Input Class Initialized
INFO - 2018-07-16 22:03:02 --> Language Class Initialized
ERROR - 2018-07-16 22:03:02 --> 404 Page Not Found: /index
INFO - 2018-07-16 22:03:02 --> Config Class Initialized
INFO - 2018-07-16 22:03:02 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:03:02 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:03:02 --> Utf8 Class Initialized
INFO - 2018-07-16 22:03:02 --> URI Class Initialized
INFO - 2018-07-16 22:03:02 --> Router Class Initialized
INFO - 2018-07-16 22:03:02 --> Output Class Initialized
INFO - 2018-07-16 22:03:02 --> Security Class Initialized
DEBUG - 2018-07-16 22:03:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:03:02 --> Input Class Initialized
INFO - 2018-07-16 22:03:02 --> Language Class Initialized
ERROR - 2018-07-16 22:03:02 --> 404 Page Not Found: /index
INFO - 2018-07-16 22:03:02 --> Config Class Initialized
INFO - 2018-07-16 22:03:02 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:03:02 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:03:02 --> Utf8 Class Initialized
INFO - 2018-07-16 22:03:02 --> URI Class Initialized
INFO - 2018-07-16 22:03:02 --> Router Class Initialized
INFO - 2018-07-16 22:03:02 --> Output Class Initialized
INFO - 2018-07-16 22:03:02 --> Security Class Initialized
DEBUG - 2018-07-16 22:03:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:03:02 --> Input Class Initialized
INFO - 2018-07-16 22:03:02 --> Language Class Initialized
ERROR - 2018-07-16 22:03:02 --> 404 Page Not Found: /index
INFO - 2018-07-16 22:04:27 --> Config Class Initialized
INFO - 2018-07-16 22:04:27 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:04:27 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:04:27 --> Utf8 Class Initialized
INFO - 2018-07-16 22:04:27 --> URI Class Initialized
INFO - 2018-07-16 22:04:27 --> Router Class Initialized
INFO - 2018-07-16 22:04:27 --> Output Class Initialized
INFO - 2018-07-16 22:04:27 --> Security Class Initialized
DEBUG - 2018-07-16 22:04:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:04:27 --> Input Class Initialized
INFO - 2018-07-16 22:04:27 --> Language Class Initialized
INFO - 2018-07-16 22:04:27 --> Language Class Initialized
INFO - 2018-07-16 22:04:27 --> Config Class Initialized
INFO - 2018-07-16 22:04:27 --> Loader Class Initialized
DEBUG - 2018-07-16 22:04:27 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 22:04:27 --> Helper loaded: url_helper
INFO - 2018-07-16 22:04:27 --> Helper loaded: form_helper
INFO - 2018-07-16 22:04:27 --> Helper loaded: date_helper
INFO - 2018-07-16 22:04:27 --> Helper loaded: util_helper
INFO - 2018-07-16 22:04:27 --> Helper loaded: text_helper
INFO - 2018-07-16 22:04:27 --> Helper loaded: string_helper
INFO - 2018-07-16 22:04:27 --> Database Driver Class Initialized
DEBUG - 2018-07-16 22:04:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 22:04:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 22:04:27 --> Email Class Initialized
INFO - 2018-07-16 22:04:27 --> Controller Class Initialized
DEBUG - 2018-07-16 22:04:27 --> Home MX_Controller Initialized
DEBUG - 2018-07-16 22:04:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-16 22:04:27 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-16 22:04:27 --> Login MX_Controller Initialized
INFO - 2018-07-16 22:04:27 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 22:04:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 22:04:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-16 22:04:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-16 22:04:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-16 22:04:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-16 22:04:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-16 22:04:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-16 22:04:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-07-16 22:04:28 --> Final output sent to browser
DEBUG - 2018-07-16 22:04:28 --> Total execution time: 0.4287
INFO - 2018-07-16 22:04:30 --> Config Class Initialized
INFO - 2018-07-16 22:04:30 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:04:30 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:04:30 --> Utf8 Class Initialized
INFO - 2018-07-16 22:04:30 --> URI Class Initialized
DEBUG - 2018-07-16 22:04:30 --> No URI present. Default controller set.
INFO - 2018-07-16 22:04:30 --> Router Class Initialized
INFO - 2018-07-16 22:04:30 --> Output Class Initialized
INFO - 2018-07-16 22:04:30 --> Security Class Initialized
DEBUG - 2018-07-16 22:04:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:04:30 --> Input Class Initialized
INFO - 2018-07-16 22:04:30 --> Language Class Initialized
INFO - 2018-07-16 22:04:30 --> Language Class Initialized
INFO - 2018-07-16 22:04:30 --> Config Class Initialized
INFO - 2018-07-16 22:04:30 --> Loader Class Initialized
DEBUG - 2018-07-16 22:04:30 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 22:04:30 --> Helper loaded: url_helper
INFO - 2018-07-16 22:04:30 --> Helper loaded: form_helper
INFO - 2018-07-16 22:04:30 --> Helper loaded: date_helper
INFO - 2018-07-16 22:04:30 --> Helper loaded: util_helper
INFO - 2018-07-16 22:04:30 --> Helper loaded: text_helper
INFO - 2018-07-16 22:04:30 --> Helper loaded: string_helper
INFO - 2018-07-16 22:04:30 --> Database Driver Class Initialized
DEBUG - 2018-07-16 22:04:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 22:04:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 22:04:30 --> Email Class Initialized
INFO - 2018-07-16 22:04:30 --> Controller Class Initialized
DEBUG - 2018-07-16 22:04:30 --> Home MX_Controller Initialized
DEBUG - 2018-07-16 22:04:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-16 22:04:30 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-16 22:04:30 --> Login MX_Controller Initialized
INFO - 2018-07-16 22:04:30 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 22:04:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 22:04:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-16 22:04:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-16 22:04:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-16 22:04:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-16 22:04:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-16 22:04:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-16 22:04:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-16 22:04:30 --> Final output sent to browser
DEBUG - 2018-07-16 22:04:30 --> Total execution time: 0.4629
INFO - 2018-07-16 22:04:30 --> Config Class Initialized
INFO - 2018-07-16 22:04:30 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:04:30 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:04:30 --> Utf8 Class Initialized
INFO - 2018-07-16 22:04:30 --> URI Class Initialized
INFO - 2018-07-16 22:04:30 --> Router Class Initialized
INFO - 2018-07-16 22:04:30 --> Output Class Initialized
INFO - 2018-07-16 22:04:30 --> Security Class Initialized
DEBUG - 2018-07-16 22:04:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:04:31 --> Input Class Initialized
INFO - 2018-07-16 22:04:31 --> Language Class Initialized
ERROR - 2018-07-16 22:04:31 --> 404 Page Not Found: /index
INFO - 2018-07-16 22:04:31 --> Config Class Initialized
INFO - 2018-07-16 22:04:31 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:04:31 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:04:31 --> Utf8 Class Initialized
INFO - 2018-07-16 22:04:31 --> URI Class Initialized
INFO - 2018-07-16 22:04:31 --> Router Class Initialized
INFO - 2018-07-16 22:04:31 --> Output Class Initialized
INFO - 2018-07-16 22:04:31 --> Security Class Initialized
DEBUG - 2018-07-16 22:04:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:04:31 --> Input Class Initialized
INFO - 2018-07-16 22:04:31 --> Language Class Initialized
ERROR - 2018-07-16 22:04:31 --> 404 Page Not Found: /index
INFO - 2018-07-16 22:04:31 --> Config Class Initialized
INFO - 2018-07-16 22:04:31 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:04:31 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:04:31 --> Utf8 Class Initialized
INFO - 2018-07-16 22:04:31 --> URI Class Initialized
INFO - 2018-07-16 22:04:31 --> Router Class Initialized
INFO - 2018-07-16 22:04:31 --> Output Class Initialized
INFO - 2018-07-16 22:04:31 --> Security Class Initialized
DEBUG - 2018-07-16 22:04:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:04:31 --> Input Class Initialized
INFO - 2018-07-16 22:04:31 --> Language Class Initialized
ERROR - 2018-07-16 22:04:31 --> 404 Page Not Found: /index
INFO - 2018-07-16 22:05:11 --> Config Class Initialized
INFO - 2018-07-16 22:05:11 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:05:11 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:05:11 --> Utf8 Class Initialized
INFO - 2018-07-16 22:05:11 --> URI Class Initialized
INFO - 2018-07-16 22:05:11 --> Router Class Initialized
INFO - 2018-07-16 22:05:11 --> Output Class Initialized
INFO - 2018-07-16 22:05:11 --> Security Class Initialized
DEBUG - 2018-07-16 22:05:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:05:11 --> Input Class Initialized
INFO - 2018-07-16 22:05:11 --> Language Class Initialized
INFO - 2018-07-16 22:05:11 --> Language Class Initialized
INFO - 2018-07-16 22:05:11 --> Config Class Initialized
INFO - 2018-07-16 22:05:11 --> Loader Class Initialized
DEBUG - 2018-07-16 22:05:11 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 22:05:12 --> Helper loaded: url_helper
INFO - 2018-07-16 22:05:12 --> Helper loaded: form_helper
INFO - 2018-07-16 22:05:12 --> Helper loaded: date_helper
INFO - 2018-07-16 22:05:12 --> Helper loaded: util_helper
INFO - 2018-07-16 22:05:12 --> Helper loaded: text_helper
INFO - 2018-07-16 22:05:12 --> Helper loaded: string_helper
INFO - 2018-07-16 22:05:12 --> Database Driver Class Initialized
DEBUG - 2018-07-16 22:05:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 22:05:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 22:05:12 --> Email Class Initialized
INFO - 2018-07-16 22:05:12 --> Controller Class Initialized
DEBUG - 2018-07-16 22:05:12 --> Home MX_Controller Initialized
DEBUG - 2018-07-16 22:05:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-16 22:05:12 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-16 22:05:12 --> Login MX_Controller Initialized
INFO - 2018-07-16 22:05:12 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 22:05:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 22:05:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-16 22:05:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-16 22:05:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-16 22:05:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-16 22:05:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-16 22:05:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-16 22:05:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/search_page.php
INFO - 2018-07-16 22:05:12 --> Final output sent to browser
DEBUG - 2018-07-16 22:05:12 --> Total execution time: 0.4698
INFO - 2018-07-16 22:05:12 --> Config Class Initialized
INFO - 2018-07-16 22:05:12 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:05:12 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:05:12 --> Utf8 Class Initialized
INFO - 2018-07-16 22:05:12 --> URI Class Initialized
INFO - 2018-07-16 22:05:12 --> Router Class Initialized
INFO - 2018-07-16 22:05:12 --> Output Class Initialized
INFO - 2018-07-16 22:05:12 --> Security Class Initialized
DEBUG - 2018-07-16 22:05:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:05:12 --> Input Class Initialized
INFO - 2018-07-16 22:05:12 --> Language Class Initialized
ERROR - 2018-07-16 22:05:12 --> 404 Page Not Found: /index
INFO - 2018-07-16 22:05:12 --> Config Class Initialized
INFO - 2018-07-16 22:05:12 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:05:12 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:05:12 --> Utf8 Class Initialized
INFO - 2018-07-16 22:05:12 --> URI Class Initialized
INFO - 2018-07-16 22:05:12 --> Router Class Initialized
INFO - 2018-07-16 22:05:12 --> Output Class Initialized
INFO - 2018-07-16 22:05:12 --> Security Class Initialized
DEBUG - 2018-07-16 22:05:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:05:12 --> Input Class Initialized
INFO - 2018-07-16 22:05:12 --> Language Class Initialized
ERROR - 2018-07-16 22:05:12 --> 404 Page Not Found: /index
INFO - 2018-07-16 22:05:12 --> Config Class Initialized
INFO - 2018-07-16 22:05:12 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:05:12 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:05:12 --> Utf8 Class Initialized
INFO - 2018-07-16 22:05:12 --> URI Class Initialized
INFO - 2018-07-16 22:05:12 --> Router Class Initialized
INFO - 2018-07-16 22:05:12 --> Output Class Initialized
INFO - 2018-07-16 22:05:12 --> Security Class Initialized
DEBUG - 2018-07-16 22:05:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:05:12 --> Input Class Initialized
INFO - 2018-07-16 22:05:12 --> Language Class Initialized
ERROR - 2018-07-16 22:05:12 --> 404 Page Not Found: /index
INFO - 2018-07-16 22:05:19 --> Config Class Initialized
INFO - 2018-07-16 22:05:19 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:05:19 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:05:19 --> Utf8 Class Initialized
INFO - 2018-07-16 22:05:19 --> URI Class Initialized
INFO - 2018-07-16 22:05:19 --> Router Class Initialized
INFO - 2018-07-16 22:05:19 --> Output Class Initialized
INFO - 2018-07-16 22:05:19 --> Security Class Initialized
DEBUG - 2018-07-16 22:05:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:05:19 --> Input Class Initialized
INFO - 2018-07-16 22:05:19 --> Language Class Initialized
INFO - 2018-07-16 22:05:19 --> Language Class Initialized
INFO - 2018-07-16 22:05:19 --> Config Class Initialized
INFO - 2018-07-16 22:05:19 --> Loader Class Initialized
DEBUG - 2018-07-16 22:05:19 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 22:05:19 --> Helper loaded: url_helper
INFO - 2018-07-16 22:05:19 --> Helper loaded: form_helper
INFO - 2018-07-16 22:05:19 --> Helper loaded: date_helper
INFO - 2018-07-16 22:05:19 --> Helper loaded: util_helper
INFO - 2018-07-16 22:05:19 --> Helper loaded: text_helper
INFO - 2018-07-16 22:05:19 --> Helper loaded: string_helper
INFO - 2018-07-16 22:05:19 --> Database Driver Class Initialized
DEBUG - 2018-07-16 22:05:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 22:05:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 22:05:19 --> Email Class Initialized
INFO - 2018-07-16 22:05:20 --> Controller Class Initialized
DEBUG - 2018-07-16 22:05:20 --> Home MX_Controller Initialized
DEBUG - 2018-07-16 22:05:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-16 22:05:20 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-16 22:05:20 --> Login MX_Controller Initialized
INFO - 2018-07-16 22:05:20 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 22:05:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 22:05:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-16 22:05:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-16 22:05:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-16 22:05:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-16 22:05:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-16 22:05:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-16 22:05:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-07-16 22:05:20 --> Final output sent to browser
DEBUG - 2018-07-16 22:05:20 --> Total execution time: 0.4568
INFO - 2018-07-16 22:05:20 --> Config Class Initialized
INFO - 2018-07-16 22:05:20 --> Config Class Initialized
INFO - 2018-07-16 22:05:20 --> Hooks Class Initialized
INFO - 2018-07-16 22:05:20 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:05:20 --> UTF-8 Support Enabled
DEBUG - 2018-07-16 22:05:20 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:05:20 --> Utf8 Class Initialized
INFO - 2018-07-16 22:05:20 --> Utf8 Class Initialized
INFO - 2018-07-16 22:05:20 --> URI Class Initialized
INFO - 2018-07-16 22:05:20 --> URI Class Initialized
INFO - 2018-07-16 22:05:20 --> Router Class Initialized
INFO - 2018-07-16 22:05:20 --> Router Class Initialized
INFO - 2018-07-16 22:05:20 --> Output Class Initialized
INFO - 2018-07-16 22:05:20 --> Output Class Initialized
INFO - 2018-07-16 22:05:20 --> Security Class Initialized
INFO - 2018-07-16 22:05:20 --> Security Class Initialized
DEBUG - 2018-07-16 22:05:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:05:20 --> Input Class Initialized
INFO - 2018-07-16 22:05:20 --> Language Class Initialized
ERROR - 2018-07-16 22:05:20 --> 404 Page Not Found: /index
DEBUG - 2018-07-16 22:05:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:05:20 --> Config Class Initialized
INFO - 2018-07-16 22:05:20 --> Hooks Class Initialized
INFO - 2018-07-16 22:05:20 --> Input Class Initialized
INFO - 2018-07-16 22:05:20 --> Language Class Initialized
DEBUG - 2018-07-16 22:05:20 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:05:20 --> Utf8 Class Initialized
ERROR - 2018-07-16 22:05:20 --> 404 Page Not Found: /index
INFO - 2018-07-16 22:05:20 --> URI Class Initialized
INFO - 2018-07-16 22:05:20 --> Router Class Initialized
INFO - 2018-07-16 22:05:20 --> Output Class Initialized
INFO - 2018-07-16 22:05:20 --> Security Class Initialized
DEBUG - 2018-07-16 22:05:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:05:20 --> Input Class Initialized
INFO - 2018-07-16 22:05:20 --> Language Class Initialized
ERROR - 2018-07-16 22:05:20 --> 404 Page Not Found: /index
INFO - 2018-07-16 22:05:20 --> Config Class Initialized
INFO - 2018-07-16 22:05:20 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:05:20 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:05:20 --> Utf8 Class Initialized
INFO - 2018-07-16 22:05:20 --> URI Class Initialized
INFO - 2018-07-16 22:05:20 --> Router Class Initialized
INFO - 2018-07-16 22:05:20 --> Output Class Initialized
INFO - 2018-07-16 22:05:20 --> Security Class Initialized
DEBUG - 2018-07-16 22:05:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:05:20 --> Input Class Initialized
INFO - 2018-07-16 22:05:20 --> Language Class Initialized
ERROR - 2018-07-16 22:05:20 --> 404 Page Not Found: /index
INFO - 2018-07-16 22:05:23 --> Config Class Initialized
INFO - 2018-07-16 22:05:23 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:05:23 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:05:23 --> Utf8 Class Initialized
INFO - 2018-07-16 22:05:23 --> URI Class Initialized
DEBUG - 2018-07-16 22:05:23 --> No URI present. Default controller set.
INFO - 2018-07-16 22:05:23 --> Router Class Initialized
INFO - 2018-07-16 22:05:23 --> Output Class Initialized
INFO - 2018-07-16 22:05:23 --> Security Class Initialized
DEBUG - 2018-07-16 22:05:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:05:23 --> Input Class Initialized
INFO - 2018-07-16 22:05:23 --> Language Class Initialized
INFO - 2018-07-16 22:05:23 --> Language Class Initialized
INFO - 2018-07-16 22:05:23 --> Config Class Initialized
INFO - 2018-07-16 22:05:23 --> Loader Class Initialized
DEBUG - 2018-07-16 22:05:23 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 22:05:23 --> Helper loaded: url_helper
INFO - 2018-07-16 22:05:23 --> Helper loaded: form_helper
INFO - 2018-07-16 22:05:23 --> Helper loaded: date_helper
INFO - 2018-07-16 22:05:23 --> Helper loaded: util_helper
INFO - 2018-07-16 22:05:23 --> Helper loaded: text_helper
INFO - 2018-07-16 22:05:23 --> Helper loaded: string_helper
INFO - 2018-07-16 22:05:23 --> Database Driver Class Initialized
DEBUG - 2018-07-16 22:05:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 22:05:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 22:05:23 --> Email Class Initialized
INFO - 2018-07-16 22:05:23 --> Controller Class Initialized
DEBUG - 2018-07-16 22:05:23 --> Home MX_Controller Initialized
DEBUG - 2018-07-16 22:05:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-16 22:05:23 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-16 22:05:23 --> Login MX_Controller Initialized
INFO - 2018-07-16 22:05:23 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 22:05:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 22:05:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-16 22:05:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-16 22:05:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-16 22:05:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-16 22:05:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-16 22:05:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-16 22:05:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-16 22:05:23 --> Final output sent to browser
DEBUG - 2018-07-16 22:05:23 --> Total execution time: 0.4574
INFO - 2018-07-16 22:06:54 --> Config Class Initialized
INFO - 2018-07-16 22:06:54 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:06:54 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:06:54 --> Utf8 Class Initialized
INFO - 2018-07-16 22:06:54 --> URI Class Initialized
INFO - 2018-07-16 22:06:54 --> Router Class Initialized
INFO - 2018-07-16 22:06:54 --> Output Class Initialized
INFO - 2018-07-16 22:06:54 --> Security Class Initialized
DEBUG - 2018-07-16 22:06:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:06:54 --> Input Class Initialized
INFO - 2018-07-16 22:06:54 --> Language Class Initialized
INFO - 2018-07-16 22:06:54 --> Language Class Initialized
INFO - 2018-07-16 22:06:54 --> Config Class Initialized
INFO - 2018-07-16 22:06:54 --> Loader Class Initialized
DEBUG - 2018-07-16 22:06:54 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 22:06:54 --> Helper loaded: url_helper
INFO - 2018-07-16 22:06:54 --> Helper loaded: form_helper
INFO - 2018-07-16 22:06:54 --> Helper loaded: date_helper
INFO - 2018-07-16 22:06:54 --> Helper loaded: util_helper
INFO - 2018-07-16 22:06:54 --> Helper loaded: text_helper
INFO - 2018-07-16 22:06:54 --> Helper loaded: string_helper
INFO - 2018-07-16 22:06:54 --> Database Driver Class Initialized
DEBUG - 2018-07-16 22:06:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 22:06:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 22:06:54 --> Email Class Initialized
INFO - 2018-07-16 22:06:54 --> Controller Class Initialized
DEBUG - 2018-07-16 22:06:54 --> Home MX_Controller Initialized
DEBUG - 2018-07-16 22:06:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-16 22:06:54 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-16 22:06:54 --> Login MX_Controller Initialized
INFO - 2018-07-16 22:06:54 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 22:06:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 22:06:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-16 22:06:54 --> Config Class Initialized
INFO - 2018-07-16 22:06:54 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:06:54 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:06:54 --> Utf8 Class Initialized
INFO - 2018-07-16 22:06:54 --> URI Class Initialized
INFO - 2018-07-16 22:06:54 --> Router Class Initialized
INFO - 2018-07-16 22:06:54 --> Output Class Initialized
INFO - 2018-07-16 22:06:54 --> Security Class Initialized
DEBUG - 2018-07-16 22:06:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:06:54 --> Input Class Initialized
INFO - 2018-07-16 22:06:54 --> Language Class Initialized
INFO - 2018-07-16 22:06:54 --> Language Class Initialized
INFO - 2018-07-16 22:06:54 --> Config Class Initialized
INFO - 2018-07-16 22:06:54 --> Loader Class Initialized
DEBUG - 2018-07-16 22:06:54 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 22:06:54 --> Helper loaded: url_helper
INFO - 2018-07-16 22:06:54 --> Helper loaded: form_helper
INFO - 2018-07-16 22:06:54 --> Helper loaded: date_helper
INFO - 2018-07-16 22:06:54 --> Helper loaded: util_helper
INFO - 2018-07-16 22:06:54 --> Helper loaded: text_helper
INFO - 2018-07-16 22:06:54 --> Helper loaded: string_helper
INFO - 2018-07-16 22:06:54 --> Database Driver Class Initialized
DEBUG - 2018-07-16 22:06:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 22:06:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 22:06:55 --> Email Class Initialized
INFO - 2018-07-16 22:06:55 --> Controller Class Initialized
DEBUG - 2018-07-16 22:06:55 --> Home MX_Controller Initialized
DEBUG - 2018-07-16 22:06:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-16 22:06:55 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-16 22:06:55 --> Login MX_Controller Initialized
INFO - 2018-07-16 22:06:55 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 22:06:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 22:06:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-16 22:06:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-16 22:06:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-16 22:06:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-16 22:06:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-16 22:06:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-16 22:06:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-16 22:06:55 --> Final output sent to browser
DEBUG - 2018-07-16 22:06:55 --> Total execution time: 0.4189
INFO - 2018-07-16 22:06:55 --> Config Class Initialized
INFO - 2018-07-16 22:06:55 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:06:55 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:06:55 --> Utf8 Class Initialized
INFO - 2018-07-16 22:06:55 --> URI Class Initialized
INFO - 2018-07-16 22:06:55 --> Router Class Initialized
INFO - 2018-07-16 22:06:55 --> Output Class Initialized
INFO - 2018-07-16 22:06:55 --> Security Class Initialized
DEBUG - 2018-07-16 22:06:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:06:55 --> Input Class Initialized
INFO - 2018-07-16 22:06:55 --> Language Class Initialized
ERROR - 2018-07-16 22:06:55 --> 404 Page Not Found: /index
INFO - 2018-07-16 22:06:55 --> Config Class Initialized
INFO - 2018-07-16 22:06:55 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:06:55 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:06:55 --> Utf8 Class Initialized
INFO - 2018-07-16 22:06:55 --> URI Class Initialized
INFO - 2018-07-16 22:06:55 --> Router Class Initialized
INFO - 2018-07-16 22:06:55 --> Output Class Initialized
INFO - 2018-07-16 22:06:55 --> Security Class Initialized
DEBUG - 2018-07-16 22:06:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:06:55 --> Input Class Initialized
INFO - 2018-07-16 22:06:55 --> Language Class Initialized
ERROR - 2018-07-16 22:06:55 --> 404 Page Not Found: /index
INFO - 2018-07-16 22:06:55 --> Config Class Initialized
INFO - 2018-07-16 22:06:55 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:06:55 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:06:55 --> Utf8 Class Initialized
INFO - 2018-07-16 22:06:55 --> URI Class Initialized
INFO - 2018-07-16 22:06:55 --> Router Class Initialized
INFO - 2018-07-16 22:06:55 --> Output Class Initialized
INFO - 2018-07-16 22:06:55 --> Security Class Initialized
DEBUG - 2018-07-16 22:06:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:06:55 --> Input Class Initialized
INFO - 2018-07-16 22:06:55 --> Language Class Initialized
ERROR - 2018-07-16 22:06:55 --> 404 Page Not Found: /index
INFO - 2018-07-16 22:06:57 --> Config Class Initialized
INFO - 2018-07-16 22:06:57 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:06:57 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:06:57 --> Utf8 Class Initialized
INFO - 2018-07-16 22:06:57 --> URI Class Initialized
INFO - 2018-07-16 22:06:57 --> Router Class Initialized
INFO - 2018-07-16 22:06:57 --> Output Class Initialized
INFO - 2018-07-16 22:06:57 --> Security Class Initialized
DEBUG - 2018-07-16 22:06:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:06:57 --> Input Class Initialized
INFO - 2018-07-16 22:06:57 --> Language Class Initialized
INFO - 2018-07-16 22:06:57 --> Language Class Initialized
INFO - 2018-07-16 22:06:57 --> Config Class Initialized
INFO - 2018-07-16 22:06:57 --> Loader Class Initialized
DEBUG - 2018-07-16 22:06:57 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 22:06:57 --> Helper loaded: url_helper
INFO - 2018-07-16 22:06:57 --> Helper loaded: form_helper
INFO - 2018-07-16 22:06:58 --> Helper loaded: date_helper
INFO - 2018-07-16 22:06:58 --> Helper loaded: util_helper
INFO - 2018-07-16 22:06:58 --> Helper loaded: text_helper
INFO - 2018-07-16 22:06:58 --> Helper loaded: string_helper
INFO - 2018-07-16 22:06:58 --> Database Driver Class Initialized
DEBUG - 2018-07-16 22:06:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 22:06:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 22:06:58 --> Email Class Initialized
INFO - 2018-07-16 22:06:58 --> Controller Class Initialized
DEBUG - 2018-07-16 22:06:58 --> Home MX_Controller Initialized
DEBUG - 2018-07-16 22:06:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-16 22:06:58 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-16 22:06:58 --> Login MX_Controller Initialized
INFO - 2018-07-16 22:06:58 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 22:06:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 22:06:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-16 22:06:58 --> Config Class Initialized
INFO - 2018-07-16 22:06:58 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:06:58 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:06:58 --> Utf8 Class Initialized
INFO - 2018-07-16 22:06:58 --> URI Class Initialized
INFO - 2018-07-16 22:06:58 --> Router Class Initialized
INFO - 2018-07-16 22:06:58 --> Output Class Initialized
INFO - 2018-07-16 22:06:58 --> Security Class Initialized
DEBUG - 2018-07-16 22:06:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:06:58 --> Input Class Initialized
INFO - 2018-07-16 22:06:58 --> Language Class Initialized
INFO - 2018-07-16 22:06:58 --> Language Class Initialized
INFO - 2018-07-16 22:06:58 --> Config Class Initialized
INFO - 2018-07-16 22:06:58 --> Loader Class Initialized
DEBUG - 2018-07-16 22:06:58 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 22:06:58 --> Helper loaded: url_helper
INFO - 2018-07-16 22:06:58 --> Helper loaded: form_helper
INFO - 2018-07-16 22:06:58 --> Helper loaded: date_helper
INFO - 2018-07-16 22:06:58 --> Helper loaded: util_helper
INFO - 2018-07-16 22:06:58 --> Helper loaded: text_helper
INFO - 2018-07-16 22:06:58 --> Helper loaded: string_helper
INFO - 2018-07-16 22:06:58 --> Database Driver Class Initialized
DEBUG - 2018-07-16 22:06:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 22:06:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 22:06:58 --> Email Class Initialized
INFO - 2018-07-16 22:06:58 --> Controller Class Initialized
DEBUG - 2018-07-16 22:06:58 --> Home MX_Controller Initialized
DEBUG - 2018-07-16 22:06:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-16 22:06:58 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-16 22:06:58 --> Login MX_Controller Initialized
INFO - 2018-07-16 22:06:58 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 22:06:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 22:06:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-16 22:06:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-16 22:06:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-16 22:06:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-16 22:06:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-16 22:06:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-16 22:06:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-16 22:06:58 --> Final output sent to browser
DEBUG - 2018-07-16 22:06:58 --> Total execution time: 0.4228
INFO - 2018-07-16 22:06:58 --> Config Class Initialized
INFO - 2018-07-16 22:06:58 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:06:58 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:06:58 --> Utf8 Class Initialized
INFO - 2018-07-16 22:06:58 --> URI Class Initialized
INFO - 2018-07-16 22:06:58 --> Router Class Initialized
INFO - 2018-07-16 22:06:58 --> Output Class Initialized
INFO - 2018-07-16 22:06:58 --> Security Class Initialized
DEBUG - 2018-07-16 22:06:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:06:58 --> Input Class Initialized
INFO - 2018-07-16 22:06:58 --> Language Class Initialized
ERROR - 2018-07-16 22:06:58 --> 404 Page Not Found: /index
INFO - 2018-07-16 22:06:58 --> Config Class Initialized
INFO - 2018-07-16 22:06:58 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:06:58 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:06:58 --> Utf8 Class Initialized
INFO - 2018-07-16 22:06:58 --> URI Class Initialized
INFO - 2018-07-16 22:06:58 --> Router Class Initialized
INFO - 2018-07-16 22:06:59 --> Output Class Initialized
INFO - 2018-07-16 22:06:59 --> Security Class Initialized
DEBUG - 2018-07-16 22:06:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:06:59 --> Input Class Initialized
INFO - 2018-07-16 22:06:59 --> Language Class Initialized
ERROR - 2018-07-16 22:06:59 --> 404 Page Not Found: /index
INFO - 2018-07-16 22:06:59 --> Config Class Initialized
INFO - 2018-07-16 22:06:59 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:06:59 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:06:59 --> Utf8 Class Initialized
INFO - 2018-07-16 22:06:59 --> URI Class Initialized
INFO - 2018-07-16 22:06:59 --> Router Class Initialized
INFO - 2018-07-16 22:06:59 --> Output Class Initialized
INFO - 2018-07-16 22:06:59 --> Security Class Initialized
DEBUG - 2018-07-16 22:06:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:06:59 --> Input Class Initialized
INFO - 2018-07-16 22:06:59 --> Language Class Initialized
ERROR - 2018-07-16 22:06:59 --> 404 Page Not Found: /index
INFO - 2018-07-16 22:08:59 --> Config Class Initialized
INFO - 2018-07-16 22:08:59 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:08:59 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:08:59 --> Utf8 Class Initialized
INFO - 2018-07-16 22:08:59 --> URI Class Initialized
INFO - 2018-07-16 22:08:59 --> Router Class Initialized
INFO - 2018-07-16 22:08:59 --> Output Class Initialized
INFO - 2018-07-16 22:08:59 --> Security Class Initialized
DEBUG - 2018-07-16 22:08:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:08:59 --> Input Class Initialized
INFO - 2018-07-16 22:08:59 --> Language Class Initialized
INFO - 2018-07-16 22:08:59 --> Language Class Initialized
INFO - 2018-07-16 22:08:59 --> Config Class Initialized
INFO - 2018-07-16 22:08:59 --> Loader Class Initialized
DEBUG - 2018-07-16 22:08:59 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 22:08:59 --> Helper loaded: url_helper
INFO - 2018-07-16 22:08:59 --> Helper loaded: form_helper
INFO - 2018-07-16 22:08:59 --> Helper loaded: date_helper
INFO - 2018-07-16 22:08:59 --> Helper loaded: util_helper
INFO - 2018-07-16 22:08:59 --> Helper loaded: text_helper
INFO - 2018-07-16 22:08:59 --> Helper loaded: string_helper
INFO - 2018-07-16 22:08:59 --> Database Driver Class Initialized
DEBUG - 2018-07-16 22:08:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 22:08:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 22:08:59 --> Email Class Initialized
INFO - 2018-07-16 22:09:00 --> Controller Class Initialized
DEBUG - 2018-07-16 22:09:00 --> Home MX_Controller Initialized
DEBUG - 2018-07-16 22:09:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-16 22:09:00 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-16 22:09:00 --> Login MX_Controller Initialized
INFO - 2018-07-16 22:09:00 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 22:09:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 22:09:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-16 22:09:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-16 22:09:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-16 22:09:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-16 22:09:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-16 22:09:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-16 22:09:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-16 22:09:00 --> Final output sent to browser
DEBUG - 2018-07-16 22:09:00 --> Total execution time: 0.4588
INFO - 2018-07-16 22:09:00 --> Config Class Initialized
INFO - 2018-07-16 22:09:00 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:09:00 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:09:00 --> Utf8 Class Initialized
INFO - 2018-07-16 22:09:00 --> URI Class Initialized
INFO - 2018-07-16 22:09:00 --> Router Class Initialized
INFO - 2018-07-16 22:09:00 --> Output Class Initialized
INFO - 2018-07-16 22:09:00 --> Security Class Initialized
DEBUG - 2018-07-16 22:09:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:09:00 --> Input Class Initialized
INFO - 2018-07-16 22:09:00 --> Language Class Initialized
ERROR - 2018-07-16 22:09:00 --> 404 Page Not Found: /index
INFO - 2018-07-16 22:09:00 --> Config Class Initialized
INFO - 2018-07-16 22:09:00 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:09:00 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:09:00 --> Utf8 Class Initialized
INFO - 2018-07-16 22:09:00 --> URI Class Initialized
INFO - 2018-07-16 22:09:00 --> Router Class Initialized
INFO - 2018-07-16 22:09:00 --> Output Class Initialized
INFO - 2018-07-16 22:09:00 --> Security Class Initialized
DEBUG - 2018-07-16 22:09:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:09:00 --> Input Class Initialized
INFO - 2018-07-16 22:09:00 --> Language Class Initialized
ERROR - 2018-07-16 22:09:00 --> 404 Page Not Found: /index
INFO - 2018-07-16 22:09:00 --> Config Class Initialized
INFO - 2018-07-16 22:09:00 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:09:00 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:09:00 --> Utf8 Class Initialized
INFO - 2018-07-16 22:09:00 --> URI Class Initialized
INFO - 2018-07-16 22:09:00 --> Router Class Initialized
INFO - 2018-07-16 22:09:00 --> Output Class Initialized
INFO - 2018-07-16 22:09:00 --> Security Class Initialized
DEBUG - 2018-07-16 22:09:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:09:00 --> Input Class Initialized
INFO - 2018-07-16 22:09:00 --> Language Class Initialized
ERROR - 2018-07-16 22:09:00 --> 404 Page Not Found: /index
INFO - 2018-07-16 22:09:01 --> Config Class Initialized
INFO - 2018-07-16 22:09:01 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:09:01 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:09:01 --> Utf8 Class Initialized
INFO - 2018-07-16 22:09:02 --> URI Class Initialized
INFO - 2018-07-16 22:09:02 --> Router Class Initialized
INFO - 2018-07-16 22:09:02 --> Output Class Initialized
INFO - 2018-07-16 22:09:02 --> Security Class Initialized
DEBUG - 2018-07-16 22:09:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:09:02 --> Input Class Initialized
INFO - 2018-07-16 22:09:02 --> Language Class Initialized
INFO - 2018-07-16 22:09:02 --> Language Class Initialized
INFO - 2018-07-16 22:09:02 --> Config Class Initialized
INFO - 2018-07-16 22:09:02 --> Loader Class Initialized
DEBUG - 2018-07-16 22:09:02 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 22:09:02 --> Helper loaded: url_helper
INFO - 2018-07-16 22:09:02 --> Helper loaded: form_helper
INFO - 2018-07-16 22:09:02 --> Helper loaded: date_helper
INFO - 2018-07-16 22:09:02 --> Helper loaded: util_helper
INFO - 2018-07-16 22:09:02 --> Helper loaded: text_helper
INFO - 2018-07-16 22:09:02 --> Helper loaded: string_helper
INFO - 2018-07-16 22:09:02 --> Database Driver Class Initialized
DEBUG - 2018-07-16 22:09:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 22:09:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 22:09:02 --> Email Class Initialized
INFO - 2018-07-16 22:09:02 --> Controller Class Initialized
DEBUG - 2018-07-16 22:09:02 --> Profile MX_Controller Initialized
DEBUG - 2018-07-16 22:09:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-16 22:09:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 22:09:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-07-16 22:09:02 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-16 22:09:02 --> Login MX_Controller Initialized
INFO - 2018-07-16 22:09:02 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 22:09:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-16 22:09:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-16 22:09:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-16 22:09:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-16 22:09:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-07-16 22:09:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-16 22:09:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-16 22:09:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/profile.php
INFO - 2018-07-16 22:09:02 --> Final output sent to browser
DEBUG - 2018-07-16 22:09:02 --> Total execution time: 0.6694
INFO - 2018-07-16 22:09:02 --> Config Class Initialized
INFO - 2018-07-16 22:09:02 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:09:02 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:09:02 --> Utf8 Class Initialized
INFO - 2018-07-16 22:09:02 --> URI Class Initialized
INFO - 2018-07-16 22:09:02 --> Router Class Initialized
INFO - 2018-07-16 22:09:02 --> Output Class Initialized
INFO - 2018-07-16 22:09:02 --> Security Class Initialized
DEBUG - 2018-07-16 22:09:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:09:02 --> Input Class Initialized
INFO - 2018-07-16 22:09:02 --> Language Class Initialized
ERROR - 2018-07-16 22:09:02 --> 404 Page Not Found: /index
INFO - 2018-07-16 22:09:02 --> Config Class Initialized
INFO - 2018-07-16 22:09:02 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:09:02 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:09:03 --> Utf8 Class Initialized
INFO - 2018-07-16 22:09:03 --> URI Class Initialized
INFO - 2018-07-16 22:09:03 --> Router Class Initialized
INFO - 2018-07-16 22:09:03 --> Output Class Initialized
INFO - 2018-07-16 22:09:03 --> Security Class Initialized
DEBUG - 2018-07-16 22:09:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:09:03 --> Input Class Initialized
INFO - 2018-07-16 22:09:03 --> Language Class Initialized
ERROR - 2018-07-16 22:09:03 --> 404 Page Not Found: /index
INFO - 2018-07-16 22:09:03 --> Config Class Initialized
INFO - 2018-07-16 22:09:03 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:09:03 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:09:03 --> Utf8 Class Initialized
INFO - 2018-07-16 22:09:03 --> URI Class Initialized
INFO - 2018-07-16 22:09:03 --> Router Class Initialized
INFO - 2018-07-16 22:09:03 --> Output Class Initialized
INFO - 2018-07-16 22:09:03 --> Security Class Initialized
DEBUG - 2018-07-16 22:09:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:09:03 --> Input Class Initialized
INFO - 2018-07-16 22:09:03 --> Language Class Initialized
ERROR - 2018-07-16 22:09:03 --> 404 Page Not Found: /index
INFO - 2018-07-16 22:09:56 --> Config Class Initialized
INFO - 2018-07-16 22:09:56 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:09:56 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:09:56 --> Utf8 Class Initialized
INFO - 2018-07-16 22:09:56 --> URI Class Initialized
INFO - 2018-07-16 22:09:56 --> Router Class Initialized
INFO - 2018-07-16 22:09:56 --> Output Class Initialized
INFO - 2018-07-16 22:09:56 --> Security Class Initialized
DEBUG - 2018-07-16 22:09:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:09:56 --> Input Class Initialized
INFO - 2018-07-16 22:09:56 --> Language Class Initialized
INFO - 2018-07-16 22:09:56 --> Language Class Initialized
INFO - 2018-07-16 22:09:56 --> Config Class Initialized
INFO - 2018-07-16 22:09:56 --> Loader Class Initialized
DEBUG - 2018-07-16 22:09:56 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 22:09:56 --> Helper loaded: url_helper
INFO - 2018-07-16 22:09:56 --> Helper loaded: form_helper
INFO - 2018-07-16 22:09:56 --> Helper loaded: date_helper
INFO - 2018-07-16 22:09:56 --> Helper loaded: util_helper
INFO - 2018-07-16 22:09:56 --> Helper loaded: text_helper
INFO - 2018-07-16 22:09:56 --> Helper loaded: string_helper
INFO - 2018-07-16 22:09:56 --> Database Driver Class Initialized
DEBUG - 2018-07-16 22:09:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 22:09:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 22:09:57 --> Email Class Initialized
INFO - 2018-07-16 22:09:57 --> Controller Class Initialized
DEBUG - 2018-07-16 22:09:57 --> Profile MX_Controller Initialized
DEBUG - 2018-07-16 22:09:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-16 22:09:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 22:09:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-07-16 22:09:57 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-16 22:09:57 --> Login MX_Controller Initialized
INFO - 2018-07-16 22:09:57 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 22:09:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-16 22:09:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-16 22:09:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-16 22:09:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-16 22:09:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-07-16 22:09:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-16 22:09:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-16 22:09:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/reset_password.php
INFO - 2018-07-16 22:09:57 --> Final output sent to browser
DEBUG - 2018-07-16 22:09:57 --> Total execution time: 0.5020
INFO - 2018-07-16 22:09:57 --> Config Class Initialized
INFO - 2018-07-16 22:09:57 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:09:57 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:09:57 --> Utf8 Class Initialized
INFO - 2018-07-16 22:09:57 --> URI Class Initialized
INFO - 2018-07-16 22:09:57 --> Router Class Initialized
INFO - 2018-07-16 22:09:57 --> Output Class Initialized
INFO - 2018-07-16 22:09:57 --> Security Class Initialized
DEBUG - 2018-07-16 22:09:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:09:57 --> Input Class Initialized
INFO - 2018-07-16 22:09:57 --> Language Class Initialized
ERROR - 2018-07-16 22:09:57 --> 404 Page Not Found: /index
INFO - 2018-07-16 22:09:57 --> Config Class Initialized
INFO - 2018-07-16 22:09:57 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:09:57 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:09:57 --> Utf8 Class Initialized
INFO - 2018-07-16 22:09:57 --> URI Class Initialized
INFO - 2018-07-16 22:09:57 --> Router Class Initialized
INFO - 2018-07-16 22:09:57 --> Output Class Initialized
INFO - 2018-07-16 22:09:57 --> Security Class Initialized
DEBUG - 2018-07-16 22:09:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:09:57 --> Input Class Initialized
INFO - 2018-07-16 22:09:57 --> Language Class Initialized
ERROR - 2018-07-16 22:09:57 --> 404 Page Not Found: /index
INFO - 2018-07-16 22:09:57 --> Config Class Initialized
INFO - 2018-07-16 22:09:57 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:09:57 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:09:57 --> Utf8 Class Initialized
INFO - 2018-07-16 22:09:57 --> URI Class Initialized
INFO - 2018-07-16 22:09:57 --> Router Class Initialized
INFO - 2018-07-16 22:09:57 --> Output Class Initialized
INFO - 2018-07-16 22:09:57 --> Security Class Initialized
DEBUG - 2018-07-16 22:09:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:09:57 --> Input Class Initialized
INFO - 2018-07-16 22:09:57 --> Language Class Initialized
ERROR - 2018-07-16 22:09:57 --> 404 Page Not Found: /index
INFO - 2018-07-16 22:09:57 --> Config Class Initialized
INFO - 2018-07-16 22:09:58 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:09:58 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:09:58 --> Utf8 Class Initialized
INFO - 2018-07-16 22:09:58 --> URI Class Initialized
INFO - 2018-07-16 22:09:58 --> Router Class Initialized
INFO - 2018-07-16 22:09:58 --> Output Class Initialized
INFO - 2018-07-16 22:09:58 --> Security Class Initialized
DEBUG - 2018-07-16 22:09:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:09:58 --> Input Class Initialized
INFO - 2018-07-16 22:09:58 --> Language Class Initialized
INFO - 2018-07-16 22:09:58 --> Language Class Initialized
INFO - 2018-07-16 22:09:58 --> Config Class Initialized
INFO - 2018-07-16 22:09:58 --> Loader Class Initialized
DEBUG - 2018-07-16 22:09:58 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 22:09:58 --> Helper loaded: url_helper
INFO - 2018-07-16 22:09:58 --> Helper loaded: form_helper
INFO - 2018-07-16 22:09:58 --> Helper loaded: date_helper
INFO - 2018-07-16 22:09:58 --> Helper loaded: util_helper
INFO - 2018-07-16 22:09:58 --> Helper loaded: text_helper
INFO - 2018-07-16 22:09:58 --> Helper loaded: string_helper
INFO - 2018-07-16 22:09:58 --> Database Driver Class Initialized
DEBUG - 2018-07-16 22:09:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 22:09:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 22:09:58 --> Email Class Initialized
INFO - 2018-07-16 22:09:58 --> Controller Class Initialized
DEBUG - 2018-07-16 22:09:58 --> Profile MX_Controller Initialized
DEBUG - 2018-07-16 22:09:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-16 22:09:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 22:09:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-07-16 22:09:58 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-16 22:09:58 --> Login MX_Controller Initialized
INFO - 2018-07-16 22:09:58 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 22:09:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-16 22:09:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-16 22:09:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-16 22:09:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-16 22:09:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-07-16 22:09:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-16 22:09:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-16 22:09:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/addresses.php
INFO - 2018-07-16 22:09:58 --> Final output sent to browser
DEBUG - 2018-07-16 22:09:58 --> Total execution time: 0.6206
INFO - 2018-07-16 22:09:58 --> Config Class Initialized
INFO - 2018-07-16 22:09:58 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:09:58 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:09:58 --> Utf8 Class Initialized
INFO - 2018-07-16 22:09:58 --> URI Class Initialized
INFO - 2018-07-16 22:09:58 --> Router Class Initialized
INFO - 2018-07-16 22:09:58 --> Output Class Initialized
INFO - 2018-07-16 22:09:58 --> Security Class Initialized
DEBUG - 2018-07-16 22:09:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:09:58 --> Input Class Initialized
INFO - 2018-07-16 22:09:58 --> Language Class Initialized
ERROR - 2018-07-16 22:09:58 --> 404 Page Not Found: /index
INFO - 2018-07-16 22:09:58 --> Config Class Initialized
INFO - 2018-07-16 22:09:58 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:09:58 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:09:59 --> Utf8 Class Initialized
INFO - 2018-07-16 22:09:59 --> URI Class Initialized
INFO - 2018-07-16 22:09:59 --> Router Class Initialized
INFO - 2018-07-16 22:09:59 --> Output Class Initialized
INFO - 2018-07-16 22:09:59 --> Security Class Initialized
DEBUG - 2018-07-16 22:09:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:09:59 --> Input Class Initialized
INFO - 2018-07-16 22:09:59 --> Language Class Initialized
ERROR - 2018-07-16 22:09:59 --> 404 Page Not Found: /index
INFO - 2018-07-16 22:09:59 --> Config Class Initialized
INFO - 2018-07-16 22:09:59 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:09:59 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:09:59 --> Utf8 Class Initialized
INFO - 2018-07-16 22:09:59 --> URI Class Initialized
INFO - 2018-07-16 22:09:59 --> Router Class Initialized
INFO - 2018-07-16 22:09:59 --> Output Class Initialized
INFO - 2018-07-16 22:09:59 --> Security Class Initialized
DEBUG - 2018-07-16 22:09:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:09:59 --> Input Class Initialized
INFO - 2018-07-16 22:09:59 --> Language Class Initialized
ERROR - 2018-07-16 22:09:59 --> 404 Page Not Found: /index
INFO - 2018-07-16 22:28:45 --> Config Class Initialized
INFO - 2018-07-16 22:28:45 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:28:45 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:28:45 --> Utf8 Class Initialized
INFO - 2018-07-16 22:28:45 --> URI Class Initialized
DEBUG - 2018-07-16 22:28:45 --> No URI present. Default controller set.
INFO - 2018-07-16 22:28:45 --> Router Class Initialized
INFO - 2018-07-16 22:28:45 --> Output Class Initialized
INFO - 2018-07-16 22:28:45 --> Security Class Initialized
DEBUG - 2018-07-16 22:28:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:28:45 --> Input Class Initialized
INFO - 2018-07-16 22:28:45 --> Language Class Initialized
INFO - 2018-07-16 22:28:45 --> Language Class Initialized
INFO - 2018-07-16 22:28:45 --> Config Class Initialized
INFO - 2018-07-16 22:28:45 --> Loader Class Initialized
DEBUG - 2018-07-16 22:28:45 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 22:28:45 --> Helper loaded: url_helper
INFO - 2018-07-16 22:28:45 --> Helper loaded: form_helper
INFO - 2018-07-16 22:28:45 --> Helper loaded: date_helper
INFO - 2018-07-16 22:28:45 --> Helper loaded: util_helper
INFO - 2018-07-16 22:28:45 --> Helper loaded: text_helper
INFO - 2018-07-16 22:28:45 --> Helper loaded: string_helper
INFO - 2018-07-16 22:28:45 --> Database Driver Class Initialized
DEBUG - 2018-07-16 22:28:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 22:28:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 22:28:45 --> Email Class Initialized
INFO - 2018-07-16 22:28:45 --> Controller Class Initialized
DEBUG - 2018-07-16 22:28:45 --> Home MX_Controller Initialized
DEBUG - 2018-07-16 22:28:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-16 22:28:45 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-16 22:28:45 --> Login MX_Controller Initialized
INFO - 2018-07-16 22:28:45 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 22:28:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 22:28:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-16 22:28:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-16 22:28:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-16 22:28:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-16 22:28:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-16 22:28:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-16 22:28:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-16 22:28:46 --> Final output sent to browser
DEBUG - 2018-07-16 22:28:46 --> Total execution time: 0.4790
INFO - 2018-07-16 22:28:46 --> Config Class Initialized
INFO - 2018-07-16 22:28:46 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:28:46 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:28:46 --> Utf8 Class Initialized
INFO - 2018-07-16 22:28:46 --> URI Class Initialized
INFO - 2018-07-16 22:28:46 --> Router Class Initialized
INFO - 2018-07-16 22:28:46 --> Output Class Initialized
INFO - 2018-07-16 22:28:46 --> Security Class Initialized
DEBUG - 2018-07-16 22:28:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:28:46 --> Input Class Initialized
INFO - 2018-07-16 22:28:46 --> Language Class Initialized
ERROR - 2018-07-16 22:28:46 --> 404 Page Not Found: /index
INFO - 2018-07-16 22:28:46 --> Config Class Initialized
INFO - 2018-07-16 22:28:46 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:28:46 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:28:46 --> Utf8 Class Initialized
INFO - 2018-07-16 22:28:46 --> URI Class Initialized
INFO - 2018-07-16 22:28:46 --> Router Class Initialized
INFO - 2018-07-16 22:28:46 --> Output Class Initialized
INFO - 2018-07-16 22:28:46 --> Security Class Initialized
DEBUG - 2018-07-16 22:28:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:28:46 --> Input Class Initialized
INFO - 2018-07-16 22:28:46 --> Language Class Initialized
ERROR - 2018-07-16 22:28:46 --> 404 Page Not Found: /index
INFO - 2018-07-16 22:28:46 --> Config Class Initialized
INFO - 2018-07-16 22:28:46 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:28:46 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:28:46 --> Utf8 Class Initialized
INFO - 2018-07-16 22:28:46 --> URI Class Initialized
INFO - 2018-07-16 22:28:46 --> Router Class Initialized
INFO - 2018-07-16 22:28:46 --> Output Class Initialized
INFO - 2018-07-16 22:28:46 --> Security Class Initialized
DEBUG - 2018-07-16 22:28:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:28:46 --> Input Class Initialized
INFO - 2018-07-16 22:28:46 --> Language Class Initialized
ERROR - 2018-07-16 22:28:46 --> 404 Page Not Found: /index
INFO - 2018-07-16 22:34:14 --> Config Class Initialized
INFO - 2018-07-16 22:34:14 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:34:14 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:34:14 --> Utf8 Class Initialized
INFO - 2018-07-16 22:34:14 --> URI Class Initialized
DEBUG - 2018-07-16 22:34:14 --> No URI present. Default controller set.
INFO - 2018-07-16 22:34:14 --> Router Class Initialized
INFO - 2018-07-16 22:34:14 --> Output Class Initialized
INFO - 2018-07-16 22:34:14 --> Security Class Initialized
DEBUG - 2018-07-16 22:34:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:34:14 --> Input Class Initialized
INFO - 2018-07-16 22:34:14 --> Language Class Initialized
INFO - 2018-07-16 22:34:14 --> Language Class Initialized
INFO - 2018-07-16 22:34:14 --> Config Class Initialized
INFO - 2018-07-16 22:34:14 --> Loader Class Initialized
DEBUG - 2018-07-16 22:34:14 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 22:34:14 --> Helper loaded: url_helper
INFO - 2018-07-16 22:34:14 --> Helper loaded: form_helper
INFO - 2018-07-16 22:34:14 --> Helper loaded: date_helper
INFO - 2018-07-16 22:34:14 --> Helper loaded: util_helper
INFO - 2018-07-16 22:34:14 --> Helper loaded: text_helper
INFO - 2018-07-16 22:34:14 --> Helper loaded: string_helper
INFO - 2018-07-16 22:34:14 --> Database Driver Class Initialized
DEBUG - 2018-07-16 22:34:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 22:34:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 22:34:14 --> Email Class Initialized
INFO - 2018-07-16 22:34:14 --> Controller Class Initialized
DEBUG - 2018-07-16 22:34:14 --> Home MX_Controller Initialized
DEBUG - 2018-07-16 22:34:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-16 22:34:14 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-16 22:34:14 --> Login MX_Controller Initialized
INFO - 2018-07-16 22:34:14 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 22:34:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 22:34:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-16 22:34:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-16 22:34:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-16 22:34:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-16 22:34:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-16 22:34:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-16 22:34:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-16 22:34:14 --> Final output sent to browser
DEBUG - 2018-07-16 22:34:14 --> Total execution time: 0.4682
INFO - 2018-07-16 22:34:15 --> Config Class Initialized
INFO - 2018-07-16 22:34:15 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:34:15 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:34:15 --> Utf8 Class Initialized
INFO - 2018-07-16 22:34:15 --> URI Class Initialized
INFO - 2018-07-16 22:34:15 --> Router Class Initialized
INFO - 2018-07-16 22:34:15 --> Output Class Initialized
INFO - 2018-07-16 22:34:15 --> Security Class Initialized
DEBUG - 2018-07-16 22:34:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:34:15 --> Input Class Initialized
INFO - 2018-07-16 22:34:15 --> Language Class Initialized
ERROR - 2018-07-16 22:34:15 --> 404 Page Not Found: /index
INFO - 2018-07-16 22:34:15 --> Config Class Initialized
INFO - 2018-07-16 22:34:15 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:34:15 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:34:15 --> Utf8 Class Initialized
INFO - 2018-07-16 22:34:15 --> URI Class Initialized
INFO - 2018-07-16 22:34:15 --> Router Class Initialized
INFO - 2018-07-16 22:34:15 --> Output Class Initialized
INFO - 2018-07-16 22:34:15 --> Security Class Initialized
DEBUG - 2018-07-16 22:34:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:34:15 --> Input Class Initialized
INFO - 2018-07-16 22:34:15 --> Language Class Initialized
ERROR - 2018-07-16 22:34:15 --> 404 Page Not Found: /index
INFO - 2018-07-16 22:34:15 --> Config Class Initialized
INFO - 2018-07-16 22:34:15 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:34:15 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:34:15 --> Utf8 Class Initialized
INFO - 2018-07-16 22:34:15 --> URI Class Initialized
INFO - 2018-07-16 22:34:15 --> Router Class Initialized
INFO - 2018-07-16 22:34:15 --> Output Class Initialized
INFO - 2018-07-16 22:34:15 --> Security Class Initialized
DEBUG - 2018-07-16 22:34:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:34:15 --> Input Class Initialized
INFO - 2018-07-16 22:34:15 --> Language Class Initialized
ERROR - 2018-07-16 22:34:15 --> 404 Page Not Found: /index
INFO - 2018-07-16 23:11:44 --> Config Class Initialized
INFO - 2018-07-16 23:11:44 --> Hooks Class Initialized
DEBUG - 2018-07-16 23:11:44 --> UTF-8 Support Enabled
INFO - 2018-07-16 23:11:44 --> Utf8 Class Initialized
INFO - 2018-07-16 23:11:44 --> URI Class Initialized
INFO - 2018-07-16 23:11:44 --> Router Class Initialized
INFO - 2018-07-16 23:11:44 --> Output Class Initialized
INFO - 2018-07-16 23:11:44 --> Security Class Initialized
DEBUG - 2018-07-16 23:11:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 23:11:44 --> Input Class Initialized
INFO - 2018-07-16 23:11:44 --> Language Class Initialized
INFO - 2018-07-16 23:11:44 --> Language Class Initialized
INFO - 2018-07-16 23:11:44 --> Config Class Initialized
INFO - 2018-07-16 23:11:44 --> Loader Class Initialized
DEBUG - 2018-07-16 23:11:44 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 23:11:44 --> Helper loaded: url_helper
INFO - 2018-07-16 23:11:44 --> Helper loaded: form_helper
INFO - 2018-07-16 23:11:44 --> Helper loaded: date_helper
INFO - 2018-07-16 23:11:44 --> Helper loaded: util_helper
INFO - 2018-07-16 23:11:44 --> Helper loaded: text_helper
INFO - 2018-07-16 23:11:44 --> Helper loaded: string_helper
INFO - 2018-07-16 23:11:44 --> Database Driver Class Initialized
DEBUG - 2018-07-16 23:11:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 23:11:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 23:11:44 --> Email Class Initialized
INFO - 2018-07-16 23:11:44 --> Controller Class Initialized
DEBUG - 2018-07-16 23:11:44 --> Users MX_Controller Initialized
DEBUG - 2018-07-16 23:11:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 23:11:44 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-16 23:11:44 --> Login MX_Controller Initialized
INFO - 2018-07-16 23:11:44 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 23:11:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-16 23:11:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-16 23:11:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-16 23:11:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-16 23:11:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-16 23:11:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-16 23:11:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-07-16 23:11:44 --> Final output sent to browser
DEBUG - 2018-07-16 23:11:44 --> Total execution time: 0.4815
INFO - 2018-07-16 23:11:45 --> Config Class Initialized
INFO - 2018-07-16 23:11:45 --> Hooks Class Initialized
DEBUG - 2018-07-16 23:11:45 --> UTF-8 Support Enabled
INFO - 2018-07-16 23:11:45 --> Utf8 Class Initialized
INFO - 2018-07-16 23:11:45 --> URI Class Initialized
INFO - 2018-07-16 23:11:45 --> Router Class Initialized
INFO - 2018-07-16 23:11:45 --> Output Class Initialized
INFO - 2018-07-16 23:11:45 --> Security Class Initialized
DEBUG - 2018-07-16 23:11:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 23:11:45 --> Input Class Initialized
INFO - 2018-07-16 23:11:45 --> Language Class Initialized
INFO - 2018-07-16 23:11:45 --> Language Class Initialized
INFO - 2018-07-16 23:11:45 --> Config Class Initialized
INFO - 2018-07-16 23:11:45 --> Loader Class Initialized
DEBUG - 2018-07-16 23:11:45 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 23:11:45 --> Helper loaded: url_helper
INFO - 2018-07-16 23:11:45 --> Helper loaded: form_helper
INFO - 2018-07-16 23:11:45 --> Helper loaded: date_helper
INFO - 2018-07-16 23:11:45 --> Helper loaded: util_helper
INFO - 2018-07-16 23:11:45 --> Helper loaded: text_helper
INFO - 2018-07-16 23:11:45 --> Helper loaded: string_helper
INFO - 2018-07-16 23:11:45 --> Database Driver Class Initialized
DEBUG - 2018-07-16 23:11:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 23:11:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 23:11:45 --> Email Class Initialized
INFO - 2018-07-16 23:11:45 --> Controller Class Initialized
DEBUG - 2018-07-16 23:11:45 --> Users MX_Controller Initialized
DEBUG - 2018-07-16 23:11:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 23:11:45 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-16 23:11:45 --> Login MX_Controller Initialized
INFO - 2018-07-16 23:11:45 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 23:11:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-16 23:11:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-16 23:11:46 --> Final output sent to browser
DEBUG - 2018-07-16 23:11:46 --> Total execution time: 0.5331
INFO - 2018-07-16 23:11:52 --> Config Class Initialized
INFO - 2018-07-16 23:11:52 --> Hooks Class Initialized
DEBUG - 2018-07-16 23:11:52 --> UTF-8 Support Enabled
INFO - 2018-07-16 23:11:52 --> Utf8 Class Initialized
INFO - 2018-07-16 23:11:52 --> URI Class Initialized
INFO - 2018-07-16 23:11:52 --> Router Class Initialized
INFO - 2018-07-16 23:11:52 --> Output Class Initialized
INFO - 2018-07-16 23:11:52 --> Security Class Initialized
DEBUG - 2018-07-16 23:11:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 23:11:52 --> Input Class Initialized
INFO - 2018-07-16 23:11:52 --> Language Class Initialized
INFO - 2018-07-16 23:11:53 --> Language Class Initialized
INFO - 2018-07-16 23:11:53 --> Config Class Initialized
INFO - 2018-07-16 23:11:53 --> Loader Class Initialized
DEBUG - 2018-07-16 23:11:53 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 23:11:53 --> Helper loaded: url_helper
INFO - 2018-07-16 23:11:53 --> Helper loaded: form_helper
INFO - 2018-07-16 23:11:53 --> Helper loaded: date_helper
INFO - 2018-07-16 23:11:53 --> Helper loaded: util_helper
INFO - 2018-07-16 23:11:53 --> Helper loaded: text_helper
INFO - 2018-07-16 23:11:53 --> Helper loaded: string_helper
INFO - 2018-07-16 23:11:53 --> Database Driver Class Initialized
DEBUG - 2018-07-16 23:11:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 23:11:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 23:11:53 --> Email Class Initialized
INFO - 2018-07-16 23:11:53 --> Controller Class Initialized
DEBUG - 2018-07-16 23:11:53 --> Users MX_Controller Initialized
DEBUG - 2018-07-16 23:11:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 23:11:53 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-16 23:11:53 --> Login MX_Controller Initialized
INFO - 2018-07-16 23:11:53 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 23:11:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-16 23:11:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-16 23:11:53 --> Final output sent to browser
DEBUG - 2018-07-16 23:11:53 --> Total execution time: 0.4368
INFO - 2018-07-16 23:11:55 --> Config Class Initialized
INFO - 2018-07-16 23:11:55 --> Hooks Class Initialized
DEBUG - 2018-07-16 23:11:55 --> UTF-8 Support Enabled
INFO - 2018-07-16 23:11:55 --> Utf8 Class Initialized
INFO - 2018-07-16 23:11:55 --> URI Class Initialized
INFO - 2018-07-16 23:11:55 --> Router Class Initialized
INFO - 2018-07-16 23:11:55 --> Output Class Initialized
INFO - 2018-07-16 23:11:55 --> Security Class Initialized
DEBUG - 2018-07-16 23:11:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 23:11:55 --> Input Class Initialized
INFO - 2018-07-16 23:11:55 --> Language Class Initialized
INFO - 2018-07-16 23:11:55 --> Language Class Initialized
INFO - 2018-07-16 23:11:55 --> Config Class Initialized
INFO - 2018-07-16 23:11:55 --> Loader Class Initialized
DEBUG - 2018-07-16 23:11:55 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 23:11:55 --> Helper loaded: url_helper
INFO - 2018-07-16 23:11:55 --> Helper loaded: form_helper
INFO - 2018-07-16 23:11:55 --> Helper loaded: date_helper
INFO - 2018-07-16 23:11:55 --> Helper loaded: util_helper
INFO - 2018-07-16 23:11:55 --> Helper loaded: text_helper
INFO - 2018-07-16 23:11:55 --> Helper loaded: string_helper
INFO - 2018-07-16 23:11:55 --> Database Driver Class Initialized
DEBUG - 2018-07-16 23:11:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 23:11:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 23:11:55 --> Email Class Initialized
INFO - 2018-07-16 23:11:55 --> Controller Class Initialized
DEBUG - 2018-07-16 23:11:55 --> Users MX_Controller Initialized
DEBUG - 2018-07-16 23:11:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 23:11:55 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-16 23:11:55 --> Login MX_Controller Initialized
INFO - 2018-07-16 23:11:55 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 23:11:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-16 23:11:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-16 23:11:55 --> Final output sent to browser
DEBUG - 2018-07-16 23:11:55 --> Total execution time: 0.4698
INFO - 2018-07-16 23:12:02 --> Config Class Initialized
INFO - 2018-07-16 23:12:02 --> Hooks Class Initialized
DEBUG - 2018-07-16 23:12:02 --> UTF-8 Support Enabled
INFO - 2018-07-16 23:12:02 --> Utf8 Class Initialized
INFO - 2018-07-16 23:12:02 --> URI Class Initialized
INFO - 2018-07-16 23:12:02 --> Router Class Initialized
INFO - 2018-07-16 23:12:02 --> Output Class Initialized
INFO - 2018-07-16 23:12:02 --> Security Class Initialized
DEBUG - 2018-07-16 23:12:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 23:12:02 --> Input Class Initialized
INFO - 2018-07-16 23:12:02 --> Language Class Initialized
INFO - 2018-07-16 23:12:02 --> Language Class Initialized
INFO - 2018-07-16 23:12:02 --> Config Class Initialized
INFO - 2018-07-16 23:12:02 --> Loader Class Initialized
INFO - 2018-07-16 23:12:02 --> Config Class Initialized
INFO - 2018-07-16 23:12:02 --> Hooks Class Initialized
DEBUG - 2018-07-16 23:12:02 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 23:12:02 --> Helper loaded: url_helper
DEBUG - 2018-07-16 23:12:02 --> UTF-8 Support Enabled
INFO - 2018-07-16 23:12:02 --> Utf8 Class Initialized
INFO - 2018-07-16 23:12:02 --> Helper loaded: form_helper
INFO - 2018-07-16 23:12:02 --> URI Class Initialized
INFO - 2018-07-16 23:12:02 --> Helper loaded: date_helper
INFO - 2018-07-16 23:12:02 --> Helper loaded: util_helper
INFO - 2018-07-16 23:12:02 --> Router Class Initialized
INFO - 2018-07-16 23:12:02 --> Output Class Initialized
INFO - 2018-07-16 23:12:02 --> Helper loaded: text_helper
INFO - 2018-07-16 23:12:02 --> Security Class Initialized
INFO - 2018-07-16 23:12:02 --> Helper loaded: string_helper
DEBUG - 2018-07-16 23:12:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 23:12:03 --> Input Class Initialized
INFO - 2018-07-16 23:12:03 --> Database Driver Class Initialized
INFO - 2018-07-16 23:12:03 --> Language Class Initialized
DEBUG - 2018-07-16 23:12:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 23:12:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 23:12:03 --> Language Class Initialized
INFO - 2018-07-16 23:12:03 --> Config Class Initialized
INFO - 2018-07-16 23:12:03 --> Email Class Initialized
INFO - 2018-07-16 23:12:03 --> Config Class Initialized
INFO - 2018-07-16 23:12:03 --> Hooks Class Initialized
INFO - 2018-07-16 23:12:03 --> Controller Class Initialized
DEBUG - 2018-07-16 23:12:03 --> UTF-8 Support Enabled
INFO - 2018-07-16 23:12:03 --> Loader Class Initialized
INFO - 2018-07-16 23:12:03 --> Utf8 Class Initialized
DEBUG - 2018-07-16 23:12:03 --> Users MX_Controller Initialized
DEBUG - 2018-07-16 23:12:03 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 23:12:03 --> Helper loaded: url_helper
DEBUG - 2018-07-16 23:12:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-16 23:12:03 --> URI Class Initialized
INFO - 2018-07-16 23:12:03 --> Helper loaded: form_helper
INFO - 2018-07-16 23:12:03 --> Router Class Initialized
DEBUG - 2018-07-16 23:12:03 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-16 23:12:03 --> Login MX_Controller Initialized
INFO - 2018-07-16 23:12:03 --> Helper loaded: date_helper
INFO - 2018-07-16 23:12:03 --> Output Class Initialized
INFO - 2018-07-16 23:12:03 --> Helper loaded: util_helper
INFO - 2018-07-16 23:12:03 --> Security Class Initialized
INFO - 2018-07-16 23:12:03 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 23:12:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-07-16 23:12:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-16 23:12:03 --> Helper loaded: text_helper
INFO - 2018-07-16 23:12:03 --> Input Class Initialized
INFO - 2018-07-16 23:12:03 --> Helper loaded: string_helper
DEBUG - 2018-07-16 23:12:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-16 23:12:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
INFO - 2018-07-16 23:12:03 --> Language Class Initialized
INFO - 2018-07-16 23:12:03 --> Database Driver Class Initialized
DEBUG - 2018-07-16 23:12:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
INFO - 2018-07-16 23:12:03 --> Language Class Initialized
DEBUG - 2018-07-16 23:12:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 23:12:03 --> Config Class Initialized
DEBUG - 2018-07-16 23:12:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-16 23:12:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
INFO - 2018-07-16 23:12:03 --> Loader Class Initialized
DEBUG - 2018-07-16 23:12:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
DEBUG - 2018-07-16 23:12:03 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 23:12:03 --> Final output sent to browser
INFO - 2018-07-16 23:12:03 --> Helper loaded: url_helper
DEBUG - 2018-07-16 23:12:03 --> Total execution time: 0.5284
INFO - 2018-07-16 23:12:03 --> Helper loaded: form_helper
INFO - 2018-07-16 23:12:03 --> Helper loaded: date_helper
INFO - 2018-07-16 23:12:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 23:12:03 --> Helper loaded: util_helper
INFO - 2018-07-16 23:12:03 --> Email Class Initialized
INFO - 2018-07-16 23:12:03 --> Helper loaded: text_helper
INFO - 2018-07-16 23:12:03 --> Helper loaded: string_helper
INFO - 2018-07-16 23:12:03 --> Controller Class Initialized
INFO - 2018-07-16 23:12:03 --> Database Driver Class Initialized
DEBUG - 2018-07-16 23:12:03 --> Users MX_Controller Initialized
DEBUG - 2018-07-16 23:12:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-07-16 23:12:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 23:12:03 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-16 23:12:03 --> Login MX_Controller Initialized
INFO - 2018-07-16 23:12:03 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 23:12:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-16 23:12:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-16 23:12:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-16 23:12:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-16 23:12:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-16 23:12:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-16 23:12:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-07-16 23:12:03 --> Final output sent to browser
DEBUG - 2018-07-16 23:12:03 --> Total execution time: 0.5841
INFO - 2018-07-16 23:12:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 23:12:03 --> Email Class Initialized
INFO - 2018-07-16 23:12:03 --> Controller Class Initialized
DEBUG - 2018-07-16 23:12:03 --> Users MX_Controller Initialized
DEBUG - 2018-07-16 23:12:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 23:12:03 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-16 23:12:03 --> Login MX_Controller Initialized
INFO - 2018-07-16 23:12:03 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 23:12:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-16 23:12:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-16 23:12:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-16 23:12:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-16 23:12:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-16 23:12:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-16 23:12:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-07-16 23:12:03 --> Final output sent to browser
DEBUG - 2018-07-16 23:12:03 --> Total execution time: 0.6274
INFO - 2018-07-16 23:12:04 --> Config Class Initialized
INFO - 2018-07-16 23:12:04 --> Hooks Class Initialized
DEBUG - 2018-07-16 23:12:04 --> UTF-8 Support Enabled
INFO - 2018-07-16 23:12:04 --> Utf8 Class Initialized
INFO - 2018-07-16 23:12:04 --> URI Class Initialized
INFO - 2018-07-16 23:12:04 --> Router Class Initialized
INFO - 2018-07-16 23:12:04 --> Output Class Initialized
INFO - 2018-07-16 23:12:04 --> Security Class Initialized
DEBUG - 2018-07-16 23:12:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 23:12:04 --> Input Class Initialized
INFO - 2018-07-16 23:12:04 --> Language Class Initialized
INFO - 2018-07-16 23:12:04 --> Language Class Initialized
INFO - 2018-07-16 23:12:04 --> Config Class Initialized
INFO - 2018-07-16 23:12:04 --> Loader Class Initialized
DEBUG - 2018-07-16 23:12:04 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 23:12:04 --> Helper loaded: url_helper
INFO - 2018-07-16 23:12:04 --> Helper loaded: form_helper
INFO - 2018-07-16 23:12:04 --> Helper loaded: date_helper
INFO - 2018-07-16 23:12:04 --> Helper loaded: util_helper
INFO - 2018-07-16 23:12:04 --> Helper loaded: text_helper
INFO - 2018-07-16 23:12:04 --> Helper loaded: string_helper
INFO - 2018-07-16 23:12:04 --> Database Driver Class Initialized
DEBUG - 2018-07-16 23:12:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 23:12:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 23:12:04 --> Email Class Initialized
INFO - 2018-07-16 23:12:04 --> Controller Class Initialized
DEBUG - 2018-07-16 23:12:04 --> Users MX_Controller Initialized
DEBUG - 2018-07-16 23:12:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 23:12:04 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-16 23:12:04 --> Login MX_Controller Initialized
INFO - 2018-07-16 23:12:04 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 23:12:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-16 23:12:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-16 23:12:04 --> Final output sent to browser
DEBUG - 2018-07-16 23:12:04 --> Total execution time: 0.5060
INFO - 2018-07-16 23:12:07 --> Config Class Initialized
INFO - 2018-07-16 23:12:07 --> Hooks Class Initialized
DEBUG - 2018-07-16 23:12:07 --> UTF-8 Support Enabled
INFO - 2018-07-16 23:12:07 --> Utf8 Class Initialized
INFO - 2018-07-16 23:12:07 --> URI Class Initialized
INFO - 2018-07-16 23:12:07 --> Router Class Initialized
INFO - 2018-07-16 23:12:07 --> Output Class Initialized
INFO - 2018-07-16 23:12:07 --> Security Class Initialized
DEBUG - 2018-07-16 23:12:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 23:12:07 --> Input Class Initialized
INFO - 2018-07-16 23:12:07 --> Language Class Initialized
INFO - 2018-07-16 23:12:07 --> Config Class Initialized
INFO - 2018-07-16 23:12:07 --> Hooks Class Initialized
INFO - 2018-07-16 23:12:07 --> Language Class Initialized
DEBUG - 2018-07-16 23:12:07 --> UTF-8 Support Enabled
INFO - 2018-07-16 23:12:07 --> Utf8 Class Initialized
INFO - 2018-07-16 23:12:07 --> URI Class Initialized
INFO - 2018-07-16 23:12:07 --> Router Class Initialized
INFO - 2018-07-16 23:12:08 --> Output Class Initialized
INFO - 2018-07-16 23:12:08 --> Security Class Initialized
DEBUG - 2018-07-16 23:12:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 23:12:08 --> Input Class Initialized
INFO - 2018-07-16 23:12:08 --> Language Class Initialized
INFO - 2018-07-16 23:12:08 --> Language Class Initialized
INFO - 2018-07-16 23:12:08 --> Config Class Initialized
INFO - 2018-07-16 23:12:08 --> Config Class Initialized
INFO - 2018-07-16 23:12:08 --> Loader Class Initialized
INFO - 2018-07-16 23:12:08 --> Loader Class Initialized
DEBUG - 2018-07-16 23:12:08 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
DEBUG - 2018-07-16 23:12:08 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 23:12:08 --> Helper loaded: url_helper
INFO - 2018-07-16 23:12:08 --> Helper loaded: url_helper
INFO - 2018-07-16 23:12:08 --> Helper loaded: form_helper
INFO - 2018-07-16 23:12:08 --> Helper loaded: form_helper
INFO - 2018-07-16 23:12:08 --> Helper loaded: date_helper
INFO - 2018-07-16 23:12:08 --> Helper loaded: date_helper
INFO - 2018-07-16 23:12:08 --> Helper loaded: util_helper
INFO - 2018-07-16 23:12:08 --> Helper loaded: util_helper
INFO - 2018-07-16 23:12:08 --> Helper loaded: text_helper
INFO - 2018-07-16 23:12:08 --> Helper loaded: text_helper
INFO - 2018-07-16 23:12:08 --> Helper loaded: string_helper
INFO - 2018-07-16 23:12:08 --> Helper loaded: string_helper
INFO - 2018-07-16 23:12:08 --> Database Driver Class Initialized
INFO - 2018-07-16 23:12:08 --> Database Driver Class Initialized
DEBUG - 2018-07-16 23:12:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-07-16 23:12:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 23:12:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 23:12:08 --> Email Class Initialized
INFO - 2018-07-16 23:12:08 --> Controller Class Initialized
DEBUG - 2018-07-16 23:12:08 --> Users MX_Controller Initialized
DEBUG - 2018-07-16 23:12:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 23:12:08 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-16 23:12:08 --> Login MX_Controller Initialized
INFO - 2018-07-16 23:12:08 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 23:12:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-16 23:12:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-16 23:12:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-16 23:12:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-16 23:12:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-16 23:12:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-16 23:12:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-07-16 23:12:08 --> Final output sent to browser
DEBUG - 2018-07-16 23:12:08 --> Total execution time: 0.5686
INFO - 2018-07-16 23:12:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 23:12:08 --> Email Class Initialized
INFO - 2018-07-16 23:12:08 --> Controller Class Initialized
DEBUG - 2018-07-16 23:12:08 --> Users MX_Controller Initialized
DEBUG - 2018-07-16 23:12:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 23:12:08 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-16 23:12:08 --> Login MX_Controller Initialized
INFO - 2018-07-16 23:12:08 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 23:12:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-16 23:12:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-16 23:12:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-16 23:12:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-16 23:12:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-16 23:12:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-16 23:12:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-07-16 23:12:08 --> Final output sent to browser
DEBUG - 2018-07-16 23:12:09 --> Total execution time: 1.3083
INFO - 2018-07-16 23:12:09 --> Config Class Initialized
INFO - 2018-07-16 23:12:09 --> Hooks Class Initialized
DEBUG - 2018-07-16 23:12:09 --> UTF-8 Support Enabled
INFO - 2018-07-16 23:12:09 --> Utf8 Class Initialized
INFO - 2018-07-16 23:12:09 --> URI Class Initialized
INFO - 2018-07-16 23:12:09 --> Router Class Initialized
INFO - 2018-07-16 23:12:09 --> Output Class Initialized
INFO - 2018-07-16 23:12:09 --> Security Class Initialized
DEBUG - 2018-07-16 23:12:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 23:12:09 --> Input Class Initialized
INFO - 2018-07-16 23:12:09 --> Language Class Initialized
INFO - 2018-07-16 23:12:09 --> Language Class Initialized
INFO - 2018-07-16 23:12:09 --> Config Class Initialized
INFO - 2018-07-16 23:12:09 --> Loader Class Initialized
DEBUG - 2018-07-16 23:12:09 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 23:12:09 --> Helper loaded: url_helper
INFO - 2018-07-16 23:12:09 --> Helper loaded: form_helper
INFO - 2018-07-16 23:12:09 --> Helper loaded: date_helper
INFO - 2018-07-16 23:12:09 --> Helper loaded: util_helper
INFO - 2018-07-16 23:12:09 --> Helper loaded: text_helper
INFO - 2018-07-16 23:12:09 --> Helper loaded: string_helper
INFO - 2018-07-16 23:12:09 --> Database Driver Class Initialized
DEBUG - 2018-07-16 23:12:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 23:12:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 23:12:09 --> Email Class Initialized
INFO - 2018-07-16 23:12:09 --> Controller Class Initialized
DEBUG - 2018-07-16 23:12:09 --> Users MX_Controller Initialized
DEBUG - 2018-07-16 23:12:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 23:12:09 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-16 23:12:09 --> Login MX_Controller Initialized
INFO - 2018-07-16 23:12:09 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 23:12:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-16 23:12:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-16 23:12:09 --> Final output sent to browser
DEBUG - 2018-07-16 23:12:09 --> Total execution time: 0.5043
INFO - 2018-07-16 23:15:06 --> Config Class Initialized
INFO - 2018-07-16 23:15:06 --> Hooks Class Initialized
DEBUG - 2018-07-16 23:15:06 --> UTF-8 Support Enabled
INFO - 2018-07-16 23:15:06 --> Utf8 Class Initialized
INFO - 2018-07-16 23:15:06 --> URI Class Initialized
INFO - 2018-07-16 23:15:06 --> Router Class Initialized
INFO - 2018-07-16 23:15:06 --> Output Class Initialized
INFO - 2018-07-16 23:15:06 --> Security Class Initialized
DEBUG - 2018-07-16 23:15:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 23:15:06 --> Input Class Initialized
INFO - 2018-07-16 23:15:06 --> Language Class Initialized
INFO - 2018-07-16 23:15:06 --> Language Class Initialized
INFO - 2018-07-16 23:15:06 --> Config Class Initialized
INFO - 2018-07-16 23:15:06 --> Loader Class Initialized
DEBUG - 2018-07-16 23:15:06 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 23:15:06 --> Helper loaded: url_helper
INFO - 2018-07-16 23:15:06 --> Helper loaded: form_helper
INFO - 2018-07-16 23:15:06 --> Helper loaded: date_helper
INFO - 2018-07-16 23:15:06 --> Helper loaded: util_helper
INFO - 2018-07-16 23:15:06 --> Helper loaded: text_helper
INFO - 2018-07-16 23:15:06 --> Helper loaded: string_helper
INFO - 2018-07-16 23:15:06 --> Database Driver Class Initialized
DEBUG - 2018-07-16 23:15:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 23:15:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 23:15:06 --> Email Class Initialized
INFO - 2018-07-16 23:15:06 --> Controller Class Initialized
DEBUG - 2018-07-16 23:15:06 --> Users MX_Controller Initialized
DEBUG - 2018-07-16 23:15:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 23:15:06 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-16 23:15:06 --> Login MX_Controller Initialized
INFO - 2018-07-16 23:15:06 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 23:15:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-16 23:15:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-16 23:15:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-16 23:15:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-16 23:15:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-16 23:15:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-16 23:15:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-07-16 23:15:06 --> Final output sent to browser
DEBUG - 2018-07-16 23:15:07 --> Total execution time: 0.5179
INFO - 2018-07-16 23:15:07 --> Config Class Initialized
INFO - 2018-07-16 23:15:07 --> Hooks Class Initialized
DEBUG - 2018-07-16 23:15:07 --> UTF-8 Support Enabled
INFO - 2018-07-16 23:15:07 --> Utf8 Class Initialized
INFO - 2018-07-16 23:15:07 --> URI Class Initialized
INFO - 2018-07-16 23:15:07 --> Router Class Initialized
INFO - 2018-07-16 23:15:07 --> Output Class Initialized
INFO - 2018-07-16 23:15:07 --> Security Class Initialized
DEBUG - 2018-07-16 23:15:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 23:15:07 --> Input Class Initialized
INFO - 2018-07-16 23:15:07 --> Language Class Initialized
INFO - 2018-07-16 23:15:07 --> Language Class Initialized
INFO - 2018-07-16 23:15:07 --> Config Class Initialized
INFO - 2018-07-16 23:15:07 --> Loader Class Initialized
DEBUG - 2018-07-16 23:15:07 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 23:15:08 --> Helper loaded: url_helper
INFO - 2018-07-16 23:15:08 --> Helper loaded: form_helper
INFO - 2018-07-16 23:15:08 --> Helper loaded: date_helper
INFO - 2018-07-16 23:15:08 --> Helper loaded: util_helper
INFO - 2018-07-16 23:15:08 --> Helper loaded: text_helper
INFO - 2018-07-16 23:15:08 --> Helper loaded: string_helper
INFO - 2018-07-16 23:15:08 --> Database Driver Class Initialized
DEBUG - 2018-07-16 23:15:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 23:15:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 23:15:08 --> Email Class Initialized
INFO - 2018-07-16 23:15:08 --> Controller Class Initialized
DEBUG - 2018-07-16 23:15:08 --> Users MX_Controller Initialized
DEBUG - 2018-07-16 23:15:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 23:15:08 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-16 23:15:08 --> Login MX_Controller Initialized
INFO - 2018-07-16 23:15:08 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 23:15:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-16 23:15:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-16 23:15:08 --> Final output sent to browser
DEBUG - 2018-07-16 23:15:08 --> Total execution time: 0.5175
INFO - 2018-07-16 23:15:18 --> Config Class Initialized
INFO - 2018-07-16 23:15:18 --> Hooks Class Initialized
DEBUG - 2018-07-16 23:15:18 --> UTF-8 Support Enabled
INFO - 2018-07-16 23:15:18 --> Utf8 Class Initialized
INFO - 2018-07-16 23:15:18 --> URI Class Initialized
DEBUG - 2018-07-16 23:15:18 --> No URI present. Default controller set.
INFO - 2018-07-16 23:15:18 --> Router Class Initialized
INFO - 2018-07-16 23:15:18 --> Output Class Initialized
INFO - 2018-07-16 23:15:18 --> Security Class Initialized
DEBUG - 2018-07-16 23:15:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 23:15:18 --> Input Class Initialized
INFO - 2018-07-16 23:15:18 --> Language Class Initialized
INFO - 2018-07-16 23:15:18 --> Language Class Initialized
INFO - 2018-07-16 23:15:18 --> Config Class Initialized
INFO - 2018-07-16 23:15:18 --> Loader Class Initialized
DEBUG - 2018-07-16 23:15:18 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 23:15:18 --> Helper loaded: url_helper
INFO - 2018-07-16 23:15:18 --> Helper loaded: form_helper
INFO - 2018-07-16 23:15:18 --> Helper loaded: date_helper
INFO - 2018-07-16 23:15:18 --> Helper loaded: util_helper
INFO - 2018-07-16 23:15:18 --> Helper loaded: text_helper
INFO - 2018-07-16 23:15:18 --> Helper loaded: string_helper
INFO - 2018-07-16 23:15:18 --> Database Driver Class Initialized
DEBUG - 2018-07-16 23:15:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 23:15:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 23:15:19 --> Email Class Initialized
INFO - 2018-07-16 23:15:19 --> Controller Class Initialized
DEBUG - 2018-07-16 23:15:19 --> Home MX_Controller Initialized
DEBUG - 2018-07-16 23:15:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-16 23:15:19 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-16 23:15:19 --> Login MX_Controller Initialized
INFO - 2018-07-16 23:15:19 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 23:15:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 23:15:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-16 23:15:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-16 23:15:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-16 23:15:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-16 23:15:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-16 23:15:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-16 23:15:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-16 23:15:19 --> Final output sent to browser
DEBUG - 2018-07-16 23:15:19 --> Total execution time: 0.5511
INFO - 2018-07-16 23:15:20 --> Config Class Initialized
INFO - 2018-07-16 23:15:20 --> Hooks Class Initialized
DEBUG - 2018-07-16 23:15:20 --> UTF-8 Support Enabled
INFO - 2018-07-16 23:15:20 --> Utf8 Class Initialized
INFO - 2018-07-16 23:15:20 --> URI Class Initialized
INFO - 2018-07-16 23:15:20 --> Router Class Initialized
INFO - 2018-07-16 23:15:20 --> Output Class Initialized
INFO - 2018-07-16 23:15:20 --> Security Class Initialized
DEBUG - 2018-07-16 23:15:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 23:15:20 --> Input Class Initialized
INFO - 2018-07-16 23:15:20 --> Language Class Initialized
ERROR - 2018-07-16 23:15:20 --> 404 Page Not Found: /index
INFO - 2018-07-16 23:16:35 --> Config Class Initialized
INFO - 2018-07-16 23:16:35 --> Hooks Class Initialized
DEBUG - 2018-07-16 23:16:35 --> UTF-8 Support Enabled
INFO - 2018-07-16 23:16:35 --> Utf8 Class Initialized
INFO - 2018-07-16 23:16:35 --> URI Class Initialized
INFO - 2018-07-16 23:16:35 --> Router Class Initialized
INFO - 2018-07-16 23:16:35 --> Output Class Initialized
INFO - 2018-07-16 23:16:35 --> Security Class Initialized
DEBUG - 2018-07-16 23:16:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 23:16:35 --> Input Class Initialized
INFO - 2018-07-16 23:16:35 --> Language Class Initialized
INFO - 2018-07-16 23:16:35 --> Language Class Initialized
INFO - 2018-07-16 23:16:35 --> Config Class Initialized
INFO - 2018-07-16 23:16:35 --> Loader Class Initialized
DEBUG - 2018-07-16 23:16:35 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 23:16:35 --> Helper loaded: url_helper
INFO - 2018-07-16 23:16:35 --> Helper loaded: form_helper
INFO - 2018-07-16 23:16:35 --> Helper loaded: date_helper
INFO - 2018-07-16 23:16:35 --> Helper loaded: util_helper
INFO - 2018-07-16 23:16:35 --> Helper loaded: text_helper
INFO - 2018-07-16 23:16:35 --> Helper loaded: string_helper
INFO - 2018-07-16 23:16:35 --> Database Driver Class Initialized
DEBUG - 2018-07-16 23:16:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 23:16:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 23:16:35 --> Email Class Initialized
INFO - 2018-07-16 23:16:35 --> Controller Class Initialized
DEBUG - 2018-07-16 23:16:35 --> Profile MX_Controller Initialized
INFO - 2018-07-16 23:16:35 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 23:16:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 23:16:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Profile_model.php
DEBUG - 2018-07-16 23:16:35 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-16 23:16:35 --> Login MX_Controller Initialized
DEBUG - 2018-07-16 23:16:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-16 23:16:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-16 23:16:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-16 23:16:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-16 23:16:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-16 23:16:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-16 23:16:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/profile.php
INFO - 2018-07-16 23:16:36 --> Final output sent to browser
DEBUG - 2018-07-16 23:16:36 --> Total execution time: 0.5043
INFO - 2018-07-16 23:17:33 --> Config Class Initialized
INFO - 2018-07-16 23:17:33 --> Hooks Class Initialized
DEBUG - 2018-07-16 23:17:33 --> UTF-8 Support Enabled
INFO - 2018-07-16 23:17:33 --> Utf8 Class Initialized
INFO - 2018-07-16 23:17:33 --> URI Class Initialized
INFO - 2018-07-16 23:17:33 --> Router Class Initialized
INFO - 2018-07-16 23:17:33 --> Output Class Initialized
INFO - 2018-07-16 23:17:33 --> Security Class Initialized
DEBUG - 2018-07-16 23:17:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 23:17:33 --> Input Class Initialized
INFO - 2018-07-16 23:17:33 --> Language Class Initialized
INFO - 2018-07-16 23:17:33 --> Language Class Initialized
INFO - 2018-07-16 23:17:33 --> Config Class Initialized
INFO - 2018-07-16 23:17:33 --> Loader Class Initialized
DEBUG - 2018-07-16 23:17:33 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 23:17:33 --> Helper loaded: url_helper
INFO - 2018-07-16 23:17:33 --> Helper loaded: form_helper
INFO - 2018-07-16 23:17:33 --> Helper loaded: date_helper
INFO - 2018-07-16 23:17:33 --> Helper loaded: util_helper
INFO - 2018-07-16 23:17:33 --> Helper loaded: text_helper
INFO - 2018-07-16 23:17:33 --> Helper loaded: string_helper
INFO - 2018-07-16 23:17:33 --> Database Driver Class Initialized
DEBUG - 2018-07-16 23:17:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 23:17:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 23:17:33 --> Email Class Initialized
INFO - 2018-07-16 23:17:33 --> Controller Class Initialized
DEBUG - 2018-07-16 23:17:33 --> Profile MX_Controller Initialized
INFO - 2018-07-16 23:17:33 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 23:17:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 23:17:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Profile_model.php
DEBUG - 2018-07-16 23:17:33 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-16 23:17:33 --> Login MX_Controller Initialized
DEBUG - 2018-07-16 23:17:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-16 23:17:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-16 23:17:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-16 23:17:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-16 23:17:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-16 23:17:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-16 23:17:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/profile.php
INFO - 2018-07-16 23:17:33 --> Final output sent to browser
DEBUG - 2018-07-16 23:17:33 --> Total execution time: 0.5234
INFO - 2018-07-16 23:17:40 --> Config Class Initialized
INFO - 2018-07-16 23:17:40 --> Hooks Class Initialized
DEBUG - 2018-07-16 23:17:40 --> UTF-8 Support Enabled
INFO - 2018-07-16 23:17:40 --> Utf8 Class Initialized
INFO - 2018-07-16 23:17:40 --> URI Class Initialized
INFO - 2018-07-16 23:17:40 --> Router Class Initialized
INFO - 2018-07-16 23:17:40 --> Output Class Initialized
INFO - 2018-07-16 23:17:40 --> Security Class Initialized
DEBUG - 2018-07-16 23:17:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 23:17:40 --> Input Class Initialized
INFO - 2018-07-16 23:17:41 --> Language Class Initialized
INFO - 2018-07-16 23:17:41 --> Language Class Initialized
INFO - 2018-07-16 23:17:41 --> Config Class Initialized
INFO - 2018-07-16 23:17:41 --> Loader Class Initialized
DEBUG - 2018-07-16 23:17:41 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 23:17:41 --> Helper loaded: url_helper
INFO - 2018-07-16 23:17:41 --> Helper loaded: form_helper
INFO - 2018-07-16 23:17:41 --> Helper loaded: date_helper
INFO - 2018-07-16 23:17:41 --> Helper loaded: util_helper
INFO - 2018-07-16 23:17:41 --> Helper loaded: text_helper
INFO - 2018-07-16 23:17:41 --> Helper loaded: string_helper
INFO - 2018-07-16 23:17:41 --> Database Driver Class Initialized
DEBUG - 2018-07-16 23:17:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 23:17:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 23:17:41 --> Email Class Initialized
INFO - 2018-07-16 23:17:41 --> Controller Class Initialized
DEBUG - 2018-07-16 23:17:41 --> Profile MX_Controller Initialized
INFO - 2018-07-16 23:17:41 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 23:17:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 23:17:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Profile_model.php
DEBUG - 2018-07-16 23:17:41 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-16 23:17:41 --> Login MX_Controller Initialized
DEBUG - 2018-07-16 23:17:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-16 23:17:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-16 23:17:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-16 23:17:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-16 23:17:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-16 23:17:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-16 23:17:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/profile.php
INFO - 2018-07-16 23:17:41 --> Final output sent to browser
DEBUG - 2018-07-16 23:17:41 --> Total execution time: 0.5855
INFO - 2018-07-16 23:17:46 --> Config Class Initialized
INFO - 2018-07-16 23:17:46 --> Hooks Class Initialized
DEBUG - 2018-07-16 23:17:46 --> UTF-8 Support Enabled
INFO - 2018-07-16 23:17:46 --> Utf8 Class Initialized
INFO - 2018-07-16 23:17:46 --> URI Class Initialized
INFO - 2018-07-16 23:17:46 --> Router Class Initialized
INFO - 2018-07-16 23:17:46 --> Output Class Initialized
INFO - 2018-07-16 23:17:46 --> Security Class Initialized
DEBUG - 2018-07-16 23:17:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 23:17:46 --> Input Class Initialized
INFO - 2018-07-16 23:17:46 --> Language Class Initialized
INFO - 2018-07-16 23:17:46 --> Language Class Initialized
INFO - 2018-07-16 23:17:46 --> Config Class Initialized
INFO - 2018-07-16 23:17:46 --> Loader Class Initialized
DEBUG - 2018-07-16 23:17:46 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 23:17:46 --> Helper loaded: url_helper
INFO - 2018-07-16 23:17:46 --> Helper loaded: form_helper
INFO - 2018-07-16 23:17:46 --> Helper loaded: date_helper
INFO - 2018-07-16 23:17:46 --> Helper loaded: util_helper
INFO - 2018-07-16 23:17:46 --> Helper loaded: text_helper
INFO - 2018-07-16 23:17:46 --> Helper loaded: string_helper
INFO - 2018-07-16 23:17:46 --> Database Driver Class Initialized
DEBUG - 2018-07-16 23:17:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 23:17:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 23:17:46 --> Email Class Initialized
INFO - 2018-07-16 23:17:46 --> Controller Class Initialized
DEBUG - 2018-07-16 23:17:46 --> Profile MX_Controller Initialized
INFO - 2018-07-16 23:17:46 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 23:17:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 23:17:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Profile_model.php
DEBUG - 2018-07-16 23:17:46 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-16 23:17:46 --> Login MX_Controller Initialized
DEBUG - 2018-07-16 23:17:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-16 23:17:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-16 23:17:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-16 23:17:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-16 23:17:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-16 23:17:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-16 23:17:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/profile.php
INFO - 2018-07-16 23:17:46 --> Final output sent to browser
DEBUG - 2018-07-16 23:17:47 --> Total execution time: 0.6048
INFO - 2018-07-16 23:18:02 --> Config Class Initialized
INFO - 2018-07-16 23:18:02 --> Hooks Class Initialized
DEBUG - 2018-07-16 23:18:02 --> UTF-8 Support Enabled
INFO - 2018-07-16 23:18:02 --> Utf8 Class Initialized
INFO - 2018-07-16 23:18:02 --> URI Class Initialized
INFO - 2018-07-16 23:18:02 --> Router Class Initialized
INFO - 2018-07-16 23:18:02 --> Output Class Initialized
INFO - 2018-07-16 23:18:02 --> Security Class Initialized
DEBUG - 2018-07-16 23:18:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 23:18:02 --> Input Class Initialized
INFO - 2018-07-16 23:18:02 --> Language Class Initialized
INFO - 2018-07-16 23:18:02 --> Language Class Initialized
INFO - 2018-07-16 23:18:02 --> Config Class Initialized
INFO - 2018-07-16 23:18:02 --> Loader Class Initialized
DEBUG - 2018-07-16 23:18:02 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 23:18:02 --> Helper loaded: url_helper
INFO - 2018-07-16 23:18:02 --> Helper loaded: form_helper
INFO - 2018-07-16 23:18:02 --> Helper loaded: date_helper
INFO - 2018-07-16 23:18:02 --> Helper loaded: util_helper
INFO - 2018-07-16 23:18:02 --> Helper loaded: text_helper
INFO - 2018-07-16 23:18:02 --> Helper loaded: string_helper
INFO - 2018-07-16 23:18:02 --> Database Driver Class Initialized
DEBUG - 2018-07-16 23:18:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 23:18:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 23:18:02 --> Email Class Initialized
INFO - 2018-07-16 23:18:02 --> Controller Class Initialized
DEBUG - 2018-07-16 23:18:02 --> Profile MX_Controller Initialized
INFO - 2018-07-16 23:18:02 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 23:18:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 23:18:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Profile_model.php
DEBUG - 2018-07-16 23:18:02 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-16 23:18:02 --> Login MX_Controller Initialized
DEBUG - 2018-07-16 23:18:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-16 23:18:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-16 23:18:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-16 23:18:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-16 23:18:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-16 23:18:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-16 23:18:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/profile.php
INFO - 2018-07-16 23:18:02 --> Final output sent to browser
DEBUG - 2018-07-16 23:18:02 --> Total execution time: 0.5502
INFO - 2018-07-16 23:18:45 --> Config Class Initialized
INFO - 2018-07-16 23:18:45 --> Hooks Class Initialized
DEBUG - 2018-07-16 23:18:45 --> UTF-8 Support Enabled
INFO - 2018-07-16 23:18:45 --> Utf8 Class Initialized
INFO - 2018-07-16 23:18:45 --> URI Class Initialized
INFO - 2018-07-16 23:18:45 --> Router Class Initialized
INFO - 2018-07-16 23:18:45 --> Output Class Initialized
INFO - 2018-07-16 23:18:45 --> Security Class Initialized
DEBUG - 2018-07-16 23:18:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 23:18:45 --> Input Class Initialized
INFO - 2018-07-16 23:18:45 --> Language Class Initialized
INFO - 2018-07-16 23:18:45 --> Language Class Initialized
INFO - 2018-07-16 23:18:45 --> Config Class Initialized
INFO - 2018-07-16 23:18:45 --> Loader Class Initialized
DEBUG - 2018-07-16 23:18:45 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 23:18:45 --> Helper loaded: url_helper
INFO - 2018-07-16 23:18:45 --> Helper loaded: form_helper
INFO - 2018-07-16 23:18:45 --> Helper loaded: date_helper
INFO - 2018-07-16 23:18:45 --> Helper loaded: util_helper
INFO - 2018-07-16 23:18:45 --> Helper loaded: text_helper
INFO - 2018-07-16 23:18:46 --> Helper loaded: string_helper
INFO - 2018-07-16 23:18:46 --> Database Driver Class Initialized
DEBUG - 2018-07-16 23:18:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 23:18:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 23:18:46 --> Email Class Initialized
INFO - 2018-07-16 23:18:46 --> Controller Class Initialized
DEBUG - 2018-07-16 23:18:46 --> Profile MX_Controller Initialized
INFO - 2018-07-16 23:18:46 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 23:18:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 23:18:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Profile_model.php
DEBUG - 2018-07-16 23:18:46 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-16 23:18:46 --> Login MX_Controller Initialized
DEBUG - 2018-07-16 23:18:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-16 23:18:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-16 23:18:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-16 23:18:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-16 23:18:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-16 23:18:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-16 23:18:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/profile.php
INFO - 2018-07-16 23:18:46 --> Final output sent to browser
DEBUG - 2018-07-16 23:18:46 --> Total execution time: 0.5089
INFO - 2018-07-16 23:19:31 --> Config Class Initialized
INFO - 2018-07-16 23:19:31 --> Hooks Class Initialized
DEBUG - 2018-07-16 23:19:31 --> UTF-8 Support Enabled
INFO - 2018-07-16 23:19:31 --> Utf8 Class Initialized
INFO - 2018-07-16 23:19:31 --> URI Class Initialized
INFO - 2018-07-16 23:19:31 --> Router Class Initialized
INFO - 2018-07-16 23:19:31 --> Output Class Initialized
INFO - 2018-07-16 23:19:31 --> Security Class Initialized
DEBUG - 2018-07-16 23:19:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 23:19:31 --> Input Class Initialized
INFO - 2018-07-16 23:19:31 --> Language Class Initialized
INFO - 2018-07-16 23:19:31 --> Language Class Initialized
INFO - 2018-07-16 23:19:31 --> Config Class Initialized
INFO - 2018-07-16 23:19:31 --> Loader Class Initialized
DEBUG - 2018-07-16 23:19:31 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 23:19:31 --> Helper loaded: url_helper
INFO - 2018-07-16 23:19:31 --> Helper loaded: form_helper
INFO - 2018-07-16 23:19:31 --> Helper loaded: date_helper
INFO - 2018-07-16 23:19:31 --> Helper loaded: util_helper
INFO - 2018-07-16 23:19:31 --> Helper loaded: text_helper
INFO - 2018-07-16 23:19:31 --> Helper loaded: string_helper
INFO - 2018-07-16 23:19:31 --> Database Driver Class Initialized
DEBUG - 2018-07-16 23:19:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 23:19:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 23:19:31 --> Email Class Initialized
INFO - 2018-07-16 23:19:31 --> Controller Class Initialized
DEBUG - 2018-07-16 23:19:31 --> Profile MX_Controller Initialized
INFO - 2018-07-16 23:19:31 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 23:19:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 23:19:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Profile_model.php
DEBUG - 2018-07-16 23:19:31 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-16 23:19:31 --> Login MX_Controller Initialized
DEBUG - 2018-07-16 23:19:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-16 23:19:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-16 23:19:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-16 23:19:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-16 23:19:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-16 23:19:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-16 23:19:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/profile.php
INFO - 2018-07-16 23:19:31 --> Final output sent to browser
DEBUG - 2018-07-16 23:19:32 --> Total execution time: 0.5194
INFO - 2018-07-16 23:19:55 --> Config Class Initialized
INFO - 2018-07-16 23:19:55 --> Hooks Class Initialized
DEBUG - 2018-07-16 23:19:55 --> UTF-8 Support Enabled
INFO - 2018-07-16 23:19:55 --> Utf8 Class Initialized
INFO - 2018-07-16 23:19:55 --> URI Class Initialized
INFO - 2018-07-16 23:19:55 --> Router Class Initialized
INFO - 2018-07-16 23:19:55 --> Output Class Initialized
INFO - 2018-07-16 23:19:55 --> Security Class Initialized
DEBUG - 2018-07-16 23:19:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 23:19:55 --> Input Class Initialized
INFO - 2018-07-16 23:19:55 --> Language Class Initialized
INFO - 2018-07-16 23:19:55 --> Language Class Initialized
INFO - 2018-07-16 23:19:55 --> Config Class Initialized
INFO - 2018-07-16 23:19:55 --> Loader Class Initialized
DEBUG - 2018-07-16 23:19:55 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 23:19:55 --> Helper loaded: url_helper
INFO - 2018-07-16 23:19:55 --> Helper loaded: form_helper
INFO - 2018-07-16 23:19:55 --> Helper loaded: date_helper
INFO - 2018-07-16 23:19:55 --> Helper loaded: util_helper
INFO - 2018-07-16 23:19:55 --> Helper loaded: text_helper
INFO - 2018-07-16 23:19:55 --> Helper loaded: string_helper
INFO - 2018-07-16 23:19:55 --> Database Driver Class Initialized
DEBUG - 2018-07-16 23:19:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 23:19:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 23:19:55 --> Email Class Initialized
INFO - 2018-07-16 23:19:55 --> Controller Class Initialized
DEBUG - 2018-07-16 23:19:55 --> Profile MX_Controller Initialized
INFO - 2018-07-16 23:19:55 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 23:19:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 23:19:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Profile_model.php
DEBUG - 2018-07-16 23:19:55 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-16 23:19:55 --> Login MX_Controller Initialized
DEBUG - 2018-07-16 23:19:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-16 23:19:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-16 23:19:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-16 23:19:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-16 23:19:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-16 23:19:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-16 23:19:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/profile.php
INFO - 2018-07-16 23:19:55 --> Final output sent to browser
DEBUG - 2018-07-16 23:19:55 --> Total execution time: 0.5124
INFO - 2018-07-16 23:20:00 --> Config Class Initialized
INFO - 2018-07-16 23:20:00 --> Hooks Class Initialized
DEBUG - 2018-07-16 23:20:00 --> UTF-8 Support Enabled
INFO - 2018-07-16 23:20:00 --> Utf8 Class Initialized
INFO - 2018-07-16 23:20:00 --> URI Class Initialized
INFO - 2018-07-16 23:20:00 --> Router Class Initialized
INFO - 2018-07-16 23:20:00 --> Output Class Initialized
INFO - 2018-07-16 23:20:00 --> Security Class Initialized
DEBUG - 2018-07-16 23:20:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 23:20:01 --> Input Class Initialized
INFO - 2018-07-16 23:20:01 --> Language Class Initialized
INFO - 2018-07-16 23:20:01 --> Language Class Initialized
INFO - 2018-07-16 23:20:01 --> Config Class Initialized
INFO - 2018-07-16 23:20:01 --> Loader Class Initialized
DEBUG - 2018-07-16 23:20:01 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 23:20:01 --> Helper loaded: url_helper
INFO - 2018-07-16 23:20:01 --> Helper loaded: form_helper
INFO - 2018-07-16 23:20:01 --> Helper loaded: date_helper
INFO - 2018-07-16 23:20:01 --> Helper loaded: util_helper
INFO - 2018-07-16 23:20:01 --> Helper loaded: text_helper
INFO - 2018-07-16 23:20:01 --> Helper loaded: string_helper
INFO - 2018-07-16 23:20:01 --> Database Driver Class Initialized
DEBUG - 2018-07-16 23:20:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 23:20:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 23:20:01 --> Email Class Initialized
INFO - 2018-07-16 23:20:01 --> Controller Class Initialized
DEBUG - 2018-07-16 23:20:01 --> Profile MX_Controller Initialized
INFO - 2018-07-16 23:20:01 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 23:20:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 23:20:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Profile_model.php
DEBUG - 2018-07-16 23:20:01 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-16 23:20:01 --> Login MX_Controller Initialized
DEBUG - 2018-07-16 23:20:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-16 23:20:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-16 23:20:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-16 23:20:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-16 23:20:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-16 23:20:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-16 23:20:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/profile.php
INFO - 2018-07-16 23:20:01 --> Final output sent to browser
DEBUG - 2018-07-16 23:20:01 --> Total execution time: 0.5199
INFO - 2018-07-16 23:20:39 --> Config Class Initialized
INFO - 2018-07-16 23:20:39 --> Hooks Class Initialized
DEBUG - 2018-07-16 23:20:39 --> UTF-8 Support Enabled
INFO - 2018-07-16 23:20:39 --> Utf8 Class Initialized
INFO - 2018-07-16 23:20:39 --> URI Class Initialized
INFO - 2018-07-16 23:20:39 --> Router Class Initialized
INFO - 2018-07-16 23:20:39 --> Output Class Initialized
INFO - 2018-07-16 23:20:39 --> Security Class Initialized
DEBUG - 2018-07-16 23:20:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 23:20:39 --> Input Class Initialized
INFO - 2018-07-16 23:20:39 --> Language Class Initialized
INFO - 2018-07-16 23:20:39 --> Language Class Initialized
INFO - 2018-07-16 23:20:39 --> Config Class Initialized
INFO - 2018-07-16 23:20:39 --> Loader Class Initialized
DEBUG - 2018-07-16 23:20:39 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 23:20:39 --> Helper loaded: url_helper
INFO - 2018-07-16 23:20:39 --> Helper loaded: form_helper
INFO - 2018-07-16 23:20:39 --> Helper loaded: date_helper
INFO - 2018-07-16 23:20:39 --> Helper loaded: util_helper
INFO - 2018-07-16 23:20:39 --> Helper loaded: text_helper
INFO - 2018-07-16 23:20:39 --> Helper loaded: string_helper
INFO - 2018-07-16 23:20:39 --> Database Driver Class Initialized
DEBUG - 2018-07-16 23:20:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 23:20:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 23:20:40 --> Email Class Initialized
INFO - 2018-07-16 23:20:40 --> Controller Class Initialized
DEBUG - 2018-07-16 23:20:40 --> Profile MX_Controller Initialized
INFO - 2018-07-16 23:20:40 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 23:20:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 23:20:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Profile_model.php
DEBUG - 2018-07-16 23:20:40 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-16 23:20:40 --> Login MX_Controller Initialized
DEBUG - 2018-07-16 23:20:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-16 23:20:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-16 23:20:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-16 23:20:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-16 23:20:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-16 23:20:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-16 23:20:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/profile.php
INFO - 2018-07-16 23:20:40 --> Final output sent to browser
DEBUG - 2018-07-16 23:20:40 --> Total execution time: 0.7191
INFO - 2018-07-16 23:21:24 --> Config Class Initialized
INFO - 2018-07-16 23:21:24 --> Hooks Class Initialized
DEBUG - 2018-07-16 23:21:24 --> UTF-8 Support Enabled
INFO - 2018-07-16 23:21:24 --> Utf8 Class Initialized
INFO - 2018-07-16 23:21:24 --> URI Class Initialized
INFO - 2018-07-16 23:21:24 --> Router Class Initialized
INFO - 2018-07-16 23:21:24 --> Output Class Initialized
INFO - 2018-07-16 23:21:24 --> Security Class Initialized
DEBUG - 2018-07-16 23:21:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 23:21:24 --> Input Class Initialized
INFO - 2018-07-16 23:21:24 --> Language Class Initialized
INFO - 2018-07-16 23:21:24 --> Language Class Initialized
INFO - 2018-07-16 23:21:24 --> Config Class Initialized
INFO - 2018-07-16 23:21:25 --> Loader Class Initialized
DEBUG - 2018-07-16 23:21:25 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 23:21:25 --> Helper loaded: url_helper
INFO - 2018-07-16 23:21:25 --> Helper loaded: form_helper
INFO - 2018-07-16 23:21:25 --> Helper loaded: date_helper
INFO - 2018-07-16 23:21:25 --> Helper loaded: util_helper
INFO - 2018-07-16 23:21:25 --> Helper loaded: text_helper
INFO - 2018-07-16 23:21:25 --> Helper loaded: string_helper
INFO - 2018-07-16 23:21:25 --> Database Driver Class Initialized
DEBUG - 2018-07-16 23:21:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 23:21:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 23:21:25 --> Email Class Initialized
INFO - 2018-07-16 23:21:25 --> Controller Class Initialized
DEBUG - 2018-07-16 23:21:25 --> Profile MX_Controller Initialized
INFO - 2018-07-16 23:21:25 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 23:21:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 23:21:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Profile_model.php
DEBUG - 2018-07-16 23:21:25 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-16 23:21:25 --> Login MX_Controller Initialized
DEBUG - 2018-07-16 23:21:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-16 23:21:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-16 23:21:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-16 23:21:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-16 23:21:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-16 23:21:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-16 23:21:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/profile.php
INFO - 2018-07-16 23:21:25 --> Final output sent to browser
DEBUG - 2018-07-16 23:21:25 --> Total execution time: 0.5362
INFO - 2018-07-16 23:22:01 --> Config Class Initialized
INFO - 2018-07-16 23:22:01 --> Hooks Class Initialized
DEBUG - 2018-07-16 23:22:01 --> UTF-8 Support Enabled
INFO - 2018-07-16 23:22:01 --> Utf8 Class Initialized
INFO - 2018-07-16 23:22:01 --> URI Class Initialized
INFO - 2018-07-16 23:22:01 --> Router Class Initialized
INFO - 2018-07-16 23:22:01 --> Output Class Initialized
INFO - 2018-07-16 23:22:01 --> Security Class Initialized
DEBUG - 2018-07-16 23:22:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 23:22:01 --> Input Class Initialized
INFO - 2018-07-16 23:22:01 --> Language Class Initialized
INFO - 2018-07-16 23:22:01 --> Language Class Initialized
INFO - 2018-07-16 23:22:01 --> Config Class Initialized
INFO - 2018-07-16 23:22:01 --> Loader Class Initialized
DEBUG - 2018-07-16 23:22:01 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 23:22:01 --> Helper loaded: url_helper
INFO - 2018-07-16 23:22:01 --> Helper loaded: form_helper
INFO - 2018-07-16 23:22:01 --> Helper loaded: date_helper
INFO - 2018-07-16 23:22:01 --> Helper loaded: util_helper
INFO - 2018-07-16 23:22:01 --> Helper loaded: text_helper
INFO - 2018-07-16 23:22:01 --> Helper loaded: string_helper
INFO - 2018-07-16 23:22:01 --> Database Driver Class Initialized
DEBUG - 2018-07-16 23:22:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 23:22:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 23:22:01 --> Email Class Initialized
INFO - 2018-07-16 23:22:01 --> Controller Class Initialized
DEBUG - 2018-07-16 23:22:01 --> Profile MX_Controller Initialized
INFO - 2018-07-16 23:22:01 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 23:22:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 23:22:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Profile_model.php
DEBUG - 2018-07-16 23:22:02 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-16 23:22:02 --> Login MX_Controller Initialized
DEBUG - 2018-07-16 23:22:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-16 23:22:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-16 23:22:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-16 23:22:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-16 23:22:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-16 23:22:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-16 23:22:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/profile.php
INFO - 2018-07-16 23:22:02 --> Final output sent to browser
DEBUG - 2018-07-16 23:22:02 --> Total execution time: 0.5396
INFO - 2018-07-16 23:22:24 --> Config Class Initialized
INFO - 2018-07-16 23:22:24 --> Hooks Class Initialized
DEBUG - 2018-07-16 23:22:24 --> UTF-8 Support Enabled
INFO - 2018-07-16 23:22:24 --> Utf8 Class Initialized
INFO - 2018-07-16 23:22:24 --> URI Class Initialized
INFO - 2018-07-16 23:22:24 --> Router Class Initialized
INFO - 2018-07-16 23:22:24 --> Output Class Initialized
INFO - 2018-07-16 23:22:24 --> Security Class Initialized
DEBUG - 2018-07-16 23:22:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 23:22:24 --> Input Class Initialized
INFO - 2018-07-16 23:22:24 --> Language Class Initialized
INFO - 2018-07-16 23:22:24 --> Language Class Initialized
INFO - 2018-07-16 23:22:24 --> Config Class Initialized
INFO - 2018-07-16 23:22:24 --> Loader Class Initialized
DEBUG - 2018-07-16 23:22:24 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 23:22:24 --> Helper loaded: url_helper
INFO - 2018-07-16 23:22:24 --> Helper loaded: form_helper
INFO - 2018-07-16 23:22:24 --> Helper loaded: date_helper
INFO - 2018-07-16 23:22:24 --> Helper loaded: util_helper
INFO - 2018-07-16 23:22:24 --> Helper loaded: text_helper
INFO - 2018-07-16 23:22:24 --> Helper loaded: string_helper
INFO - 2018-07-16 23:22:24 --> Database Driver Class Initialized
DEBUG - 2018-07-16 23:22:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 23:22:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 23:22:24 --> Email Class Initialized
INFO - 2018-07-16 23:22:24 --> Controller Class Initialized
DEBUG - 2018-07-16 23:22:24 --> Profile MX_Controller Initialized
INFO - 2018-07-16 23:22:24 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 23:22:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 23:22:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Profile_model.php
DEBUG - 2018-07-16 23:22:24 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-16 23:22:24 --> Login MX_Controller Initialized
DEBUG - 2018-07-16 23:22:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-16 23:22:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-16 23:22:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-16 23:22:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-16 23:22:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-16 23:22:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-16 23:22:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/profile.php
INFO - 2018-07-16 23:22:24 --> Final output sent to browser
DEBUG - 2018-07-16 23:22:24 --> Total execution time: 0.5253
INFO - 2018-07-16 23:22:45 --> Config Class Initialized
INFO - 2018-07-16 23:22:45 --> Hooks Class Initialized
DEBUG - 2018-07-16 23:22:45 --> UTF-8 Support Enabled
INFO - 2018-07-16 23:22:45 --> Utf8 Class Initialized
INFO - 2018-07-16 23:22:45 --> URI Class Initialized
INFO - 2018-07-16 23:22:45 --> Router Class Initialized
INFO - 2018-07-16 23:22:45 --> Output Class Initialized
INFO - 2018-07-16 23:22:45 --> Security Class Initialized
DEBUG - 2018-07-16 23:22:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 23:22:45 --> Input Class Initialized
INFO - 2018-07-16 23:22:45 --> Language Class Initialized
INFO - 2018-07-16 23:22:45 --> Language Class Initialized
INFO - 2018-07-16 23:22:45 --> Config Class Initialized
INFO - 2018-07-16 23:22:45 --> Loader Class Initialized
DEBUG - 2018-07-16 23:22:45 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 23:22:45 --> Helper loaded: url_helper
INFO - 2018-07-16 23:22:45 --> Helper loaded: form_helper
INFO - 2018-07-16 23:22:45 --> Helper loaded: date_helper
INFO - 2018-07-16 23:22:45 --> Helper loaded: util_helper
INFO - 2018-07-16 23:22:45 --> Helper loaded: text_helper
INFO - 2018-07-16 23:22:45 --> Helper loaded: string_helper
INFO - 2018-07-16 23:22:45 --> Database Driver Class Initialized
DEBUG - 2018-07-16 23:22:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 23:22:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 23:22:45 --> Email Class Initialized
INFO - 2018-07-16 23:22:45 --> Controller Class Initialized
DEBUG - 2018-07-16 23:22:45 --> Profile MX_Controller Initialized
INFO - 2018-07-16 23:22:45 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 23:22:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 23:22:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Profile_model.php
DEBUG - 2018-07-16 23:22:45 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-16 23:22:45 --> Login MX_Controller Initialized
DEBUG - 2018-07-16 23:22:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-16 23:22:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-16 23:22:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-16 23:22:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-16 23:22:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-16 23:22:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-16 23:22:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/profile.php
INFO - 2018-07-16 23:22:45 --> Final output sent to browser
DEBUG - 2018-07-16 23:22:45 --> Total execution time: 0.5298
INFO - 2018-07-16 23:22:53 --> Config Class Initialized
INFO - 2018-07-16 23:22:53 --> Hooks Class Initialized
DEBUG - 2018-07-16 23:22:53 --> UTF-8 Support Enabled
INFO - 2018-07-16 23:22:53 --> Utf8 Class Initialized
INFO - 2018-07-16 23:22:53 --> URI Class Initialized
INFO - 2018-07-16 23:22:53 --> Router Class Initialized
INFO - 2018-07-16 23:22:53 --> Output Class Initialized
INFO - 2018-07-16 23:22:53 --> Security Class Initialized
DEBUG - 2018-07-16 23:22:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 23:22:53 --> Input Class Initialized
INFO - 2018-07-16 23:22:53 --> Language Class Initialized
INFO - 2018-07-16 23:22:53 --> Language Class Initialized
INFO - 2018-07-16 23:22:54 --> Config Class Initialized
INFO - 2018-07-16 23:22:54 --> Loader Class Initialized
DEBUG - 2018-07-16 23:22:54 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 23:22:54 --> Helper loaded: url_helper
INFO - 2018-07-16 23:22:54 --> Helper loaded: form_helper
INFO - 2018-07-16 23:22:54 --> Helper loaded: date_helper
INFO - 2018-07-16 23:22:54 --> Helper loaded: util_helper
INFO - 2018-07-16 23:22:54 --> Helper loaded: text_helper
INFO - 2018-07-16 23:22:54 --> Helper loaded: string_helper
INFO - 2018-07-16 23:22:54 --> Database Driver Class Initialized
DEBUG - 2018-07-16 23:22:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 23:22:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 23:22:54 --> Email Class Initialized
INFO - 2018-07-16 23:22:54 --> Controller Class Initialized
DEBUG - 2018-07-16 23:22:54 --> Profile MX_Controller Initialized
INFO - 2018-07-16 23:22:54 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 23:22:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 23:22:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Profile_model.php
DEBUG - 2018-07-16 23:22:54 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-16 23:22:54 --> Login MX_Controller Initialized
DEBUG - 2018-07-16 23:22:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-16 23:22:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-16 23:22:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-16 23:22:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-16 23:22:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-16 23:22:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-16 23:22:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/profile.php
INFO - 2018-07-16 23:22:54 --> Final output sent to browser
DEBUG - 2018-07-16 23:22:54 --> Total execution time: 0.5277
INFO - 2018-07-16 23:23:04 --> Config Class Initialized
INFO - 2018-07-16 23:23:04 --> Hooks Class Initialized
DEBUG - 2018-07-16 23:23:04 --> UTF-8 Support Enabled
INFO - 2018-07-16 23:23:04 --> Utf8 Class Initialized
INFO - 2018-07-16 23:23:04 --> URI Class Initialized
INFO - 2018-07-16 23:23:04 --> Router Class Initialized
INFO - 2018-07-16 23:23:04 --> Output Class Initialized
INFO - 2018-07-16 23:23:04 --> Security Class Initialized
DEBUG - 2018-07-16 23:23:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 23:23:04 --> Input Class Initialized
INFO - 2018-07-16 23:23:04 --> Language Class Initialized
INFO - 2018-07-16 23:23:04 --> Language Class Initialized
INFO - 2018-07-16 23:23:04 --> Config Class Initialized
INFO - 2018-07-16 23:23:04 --> Loader Class Initialized
DEBUG - 2018-07-16 23:23:04 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 23:23:04 --> Helper loaded: url_helper
INFO - 2018-07-16 23:23:04 --> Helper loaded: form_helper
INFO - 2018-07-16 23:23:04 --> Helper loaded: date_helper
INFO - 2018-07-16 23:23:04 --> Helper loaded: util_helper
INFO - 2018-07-16 23:23:04 --> Helper loaded: text_helper
INFO - 2018-07-16 23:23:04 --> Helper loaded: string_helper
INFO - 2018-07-16 23:23:04 --> Database Driver Class Initialized
DEBUG - 2018-07-16 23:23:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 23:23:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 23:23:04 --> Email Class Initialized
INFO - 2018-07-16 23:23:04 --> Controller Class Initialized
DEBUG - 2018-07-16 23:23:04 --> Login MX_Controller Initialized
INFO - 2018-07-16 23:23:04 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 23:23:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 23:23:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-16 23:23:04 --> 6 Loggedout
INFO - 2018-07-16 23:23:04 --> Config Class Initialized
INFO - 2018-07-16 23:23:04 --> Hooks Class Initialized
DEBUG - 2018-07-16 23:23:04 --> UTF-8 Support Enabled
INFO - 2018-07-16 23:23:04 --> Utf8 Class Initialized
INFO - 2018-07-16 23:23:04 --> URI Class Initialized
INFO - 2018-07-16 23:23:04 --> Router Class Initialized
INFO - 2018-07-16 23:23:04 --> Output Class Initialized
INFO - 2018-07-16 23:23:04 --> Security Class Initialized
DEBUG - 2018-07-16 23:23:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 23:23:04 --> Input Class Initialized
INFO - 2018-07-16 23:23:04 --> Language Class Initialized
INFO - 2018-07-16 23:23:04 --> Language Class Initialized
INFO - 2018-07-16 23:23:04 --> Config Class Initialized
INFO - 2018-07-16 23:23:04 --> Loader Class Initialized
DEBUG - 2018-07-16 23:23:04 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 23:23:04 --> Helper loaded: url_helper
INFO - 2018-07-16 23:23:04 --> Helper loaded: form_helper
INFO - 2018-07-16 23:23:04 --> Helper loaded: date_helper
INFO - 2018-07-16 23:23:04 --> Helper loaded: util_helper
INFO - 2018-07-16 23:23:04 --> Helper loaded: text_helper
INFO - 2018-07-16 23:23:04 --> Helper loaded: string_helper
INFO - 2018-07-16 23:23:04 --> Database Driver Class Initialized
DEBUG - 2018-07-16 23:23:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 23:23:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 23:23:05 --> Email Class Initialized
INFO - 2018-07-16 23:23:05 --> Controller Class Initialized
DEBUG - 2018-07-16 23:23:05 --> Admin MX_Controller Initialized
INFO - 2018-07-16 23:23:05 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 23:23:05 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-16 23:23:05 --> Login MX_Controller Initialized
DEBUG - 2018-07-16 23:23:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 23:23:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-16 23:23:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
INFO - 2018-07-16 23:23:05 --> Config Class Initialized
INFO - 2018-07-16 23:23:05 --> Hooks Class Initialized
DEBUG - 2018-07-16 23:23:05 --> UTF-8 Support Enabled
INFO - 2018-07-16 23:23:05 --> Utf8 Class Initialized
INFO - 2018-07-16 23:23:05 --> URI Class Initialized
INFO - 2018-07-16 23:23:05 --> Router Class Initialized
INFO - 2018-07-16 23:23:05 --> Output Class Initialized
INFO - 2018-07-16 23:23:05 --> Security Class Initialized
DEBUG - 2018-07-16 23:23:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 23:23:05 --> Input Class Initialized
INFO - 2018-07-16 23:23:05 --> Language Class Initialized
ERROR - 2018-07-16 23:23:05 --> 404 Page Not Found: /index
INFO - 2018-07-16 23:23:09 --> Config Class Initialized
INFO - 2018-07-16 23:23:09 --> Hooks Class Initialized
DEBUG - 2018-07-16 23:23:09 --> UTF-8 Support Enabled
INFO - 2018-07-16 23:23:09 --> Utf8 Class Initialized
INFO - 2018-07-16 23:23:09 --> URI Class Initialized
INFO - 2018-07-16 23:23:09 --> Router Class Initialized
INFO - 2018-07-16 23:23:09 --> Output Class Initialized
INFO - 2018-07-16 23:23:09 --> Security Class Initialized
DEBUG - 2018-07-16 23:23:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 23:23:09 --> Input Class Initialized
INFO - 2018-07-16 23:23:09 --> Language Class Initialized
INFO - 2018-07-16 23:23:09 --> Language Class Initialized
INFO - 2018-07-16 23:23:09 --> Config Class Initialized
INFO - 2018-07-16 23:23:09 --> Loader Class Initialized
DEBUG - 2018-07-16 23:23:09 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 23:23:09 --> Helper loaded: url_helper
INFO - 2018-07-16 23:23:09 --> Helper loaded: form_helper
INFO - 2018-07-16 23:23:09 --> Helper loaded: date_helper
INFO - 2018-07-16 23:23:09 --> Helper loaded: util_helper
INFO - 2018-07-16 23:23:09 --> Helper loaded: text_helper
INFO - 2018-07-16 23:23:09 --> Helper loaded: string_helper
INFO - 2018-07-16 23:23:09 --> Database Driver Class Initialized
DEBUG - 2018-07-16 23:23:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 23:23:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 23:23:09 --> Email Class Initialized
INFO - 2018-07-16 23:23:09 --> Controller Class Initialized
DEBUG - 2018-07-16 23:23:09 --> Login MX_Controller Initialized
INFO - 2018-07-16 23:23:09 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 23:23:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 23:23:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-16 23:23:09 --> Email starts for admin@colin.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-07-16 23:23:09 --> User session created for 1
INFO - 2018-07-16 23:23:09 --> Login status admin@colin.com - success
INFO - 2018-07-16 23:23:09 --> Final output sent to browser
DEBUG - 2018-07-16 23:23:09 --> Total execution time: 0.4890
INFO - 2018-07-16 23:23:09 --> Config Class Initialized
INFO - 2018-07-16 23:23:10 --> Hooks Class Initialized
DEBUG - 2018-07-16 23:23:10 --> UTF-8 Support Enabled
INFO - 2018-07-16 23:23:10 --> Utf8 Class Initialized
INFO - 2018-07-16 23:23:10 --> URI Class Initialized
INFO - 2018-07-16 23:23:10 --> Router Class Initialized
INFO - 2018-07-16 23:23:10 --> Output Class Initialized
INFO - 2018-07-16 23:23:10 --> Security Class Initialized
DEBUG - 2018-07-16 23:23:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 23:23:10 --> Input Class Initialized
INFO - 2018-07-16 23:23:10 --> Language Class Initialized
INFO - 2018-07-16 23:23:10 --> Language Class Initialized
INFO - 2018-07-16 23:23:10 --> Config Class Initialized
INFO - 2018-07-16 23:23:10 --> Loader Class Initialized
DEBUG - 2018-07-16 23:23:10 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 23:23:10 --> Helper loaded: url_helper
INFO - 2018-07-16 23:23:10 --> Helper loaded: form_helper
INFO - 2018-07-16 23:23:10 --> Helper loaded: date_helper
INFO - 2018-07-16 23:23:10 --> Helper loaded: util_helper
INFO - 2018-07-16 23:23:10 --> Helper loaded: text_helper
INFO - 2018-07-16 23:23:10 --> Helper loaded: string_helper
INFO - 2018-07-16 23:23:10 --> Database Driver Class Initialized
DEBUG - 2018-07-16 23:23:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 23:23:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 23:23:10 --> Email Class Initialized
INFO - 2018-07-16 23:23:10 --> Controller Class Initialized
DEBUG - 2018-07-16 23:23:10 --> Admin MX_Controller Initialized
INFO - 2018-07-16 23:23:10 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 23:23:10 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-16 23:23:10 --> Login MX_Controller Initialized
DEBUG - 2018-07-16 23:23:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 23:23:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-16 23:23:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-16 23:23:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-16 23:23:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-16 23:23:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-16 23:23:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-16 23:23:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/dashboard.php
INFO - 2018-07-16 23:23:10 --> Final output sent to browser
DEBUG - 2018-07-16 23:23:10 --> Total execution time: 0.5610
INFO - 2018-07-16 23:23:10 --> Config Class Initialized
INFO - 2018-07-16 23:23:10 --> Hooks Class Initialized
DEBUG - 2018-07-16 23:23:10 --> UTF-8 Support Enabled
INFO - 2018-07-16 23:23:10 --> Utf8 Class Initialized
INFO - 2018-07-16 23:23:10 --> URI Class Initialized
INFO - 2018-07-16 23:23:10 --> Router Class Initialized
INFO - 2018-07-16 23:23:10 --> Output Class Initialized
INFO - 2018-07-16 23:23:10 --> Security Class Initialized
INFO - 2018-07-16 23:23:10 --> Config Class Initialized
INFO - 2018-07-16 23:23:10 --> Hooks Class Initialized
DEBUG - 2018-07-16 23:23:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 23:23:10 --> Input Class Initialized
DEBUG - 2018-07-16 23:23:10 --> UTF-8 Support Enabled
INFO - 2018-07-16 23:23:10 --> Utf8 Class Initialized
INFO - 2018-07-16 23:23:10 --> Language Class Initialized
INFO - 2018-07-16 23:23:10 --> URI Class Initialized
ERROR - 2018-07-16 23:23:10 --> 404 Page Not Found: /index
INFO - 2018-07-16 23:23:11 --> Router Class Initialized
INFO - 2018-07-16 23:23:11 --> Output Class Initialized
INFO - 2018-07-16 23:23:11 --> Security Class Initialized
DEBUG - 2018-07-16 23:23:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 23:23:11 --> Input Class Initialized
INFO - 2018-07-16 23:23:11 --> Language Class Initialized
ERROR - 2018-07-16 23:23:11 --> 404 Page Not Found: /index
INFO - 2018-07-16 23:23:14 --> Config Class Initialized
INFO - 2018-07-16 23:23:14 --> Hooks Class Initialized
DEBUG - 2018-07-16 23:23:14 --> UTF-8 Support Enabled
INFO - 2018-07-16 23:23:14 --> Utf8 Class Initialized
INFO - 2018-07-16 23:23:14 --> URI Class Initialized
INFO - 2018-07-16 23:23:14 --> Router Class Initialized
INFO - 2018-07-16 23:23:14 --> Output Class Initialized
INFO - 2018-07-16 23:23:14 --> Security Class Initialized
DEBUG - 2018-07-16 23:23:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 23:23:14 --> Input Class Initialized
INFO - 2018-07-16 23:23:14 --> Language Class Initialized
INFO - 2018-07-16 23:23:14 --> Language Class Initialized
INFO - 2018-07-16 23:23:14 --> Config Class Initialized
INFO - 2018-07-16 23:23:14 --> Loader Class Initialized
DEBUG - 2018-07-16 23:23:14 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 23:23:14 --> Helper loaded: url_helper
INFO - 2018-07-16 23:23:14 --> Helper loaded: form_helper
INFO - 2018-07-16 23:23:14 --> Helper loaded: date_helper
INFO - 2018-07-16 23:23:14 --> Helper loaded: util_helper
INFO - 2018-07-16 23:23:14 --> Helper loaded: text_helper
INFO - 2018-07-16 23:23:14 --> Helper loaded: string_helper
INFO - 2018-07-16 23:23:14 --> Database Driver Class Initialized
DEBUG - 2018-07-16 23:23:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 23:23:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 23:23:14 --> Email Class Initialized
INFO - 2018-07-16 23:23:14 --> Controller Class Initialized
DEBUG - 2018-07-16 23:23:14 --> Profile MX_Controller Initialized
INFO - 2018-07-16 23:23:14 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 23:23:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 23:23:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Profile_model.php
DEBUG - 2018-07-16 23:23:14 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-16 23:23:14 --> Login MX_Controller Initialized
DEBUG - 2018-07-16 23:23:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-16 23:23:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-16 23:23:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-16 23:23:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-16 23:23:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-16 23:23:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-16 23:23:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/admin_password.php
INFO - 2018-07-16 23:23:14 --> Final output sent to browser
DEBUG - 2018-07-16 23:23:14 --> Total execution time: 0.6366
INFO - 2018-07-16 23:23:15 --> Config Class Initialized
INFO - 2018-07-16 23:23:15 --> Hooks Class Initialized
DEBUG - 2018-07-16 23:23:15 --> UTF-8 Support Enabled
INFO - 2018-07-16 23:23:15 --> Utf8 Class Initialized
INFO - 2018-07-16 23:23:15 --> URI Class Initialized
INFO - 2018-07-16 23:23:15 --> Router Class Initialized
INFO - 2018-07-16 23:23:15 --> Output Class Initialized
INFO - 2018-07-16 23:23:15 --> Security Class Initialized
DEBUG - 2018-07-16 23:23:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 23:23:15 --> Input Class Initialized
INFO - 2018-07-16 23:23:15 --> Language Class Initialized
INFO - 2018-07-16 23:23:15 --> Language Class Initialized
INFO - 2018-07-16 23:23:15 --> Config Class Initialized
INFO - 2018-07-16 23:23:15 --> Loader Class Initialized
DEBUG - 2018-07-16 23:23:16 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 23:23:16 --> Helper loaded: url_helper
INFO - 2018-07-16 23:23:16 --> Helper loaded: form_helper
INFO - 2018-07-16 23:23:16 --> Helper loaded: date_helper
INFO - 2018-07-16 23:23:16 --> Helper loaded: util_helper
INFO - 2018-07-16 23:23:16 --> Helper loaded: text_helper
INFO - 2018-07-16 23:23:16 --> Helper loaded: string_helper
INFO - 2018-07-16 23:23:16 --> Database Driver Class Initialized
DEBUG - 2018-07-16 23:23:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 23:23:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 23:23:16 --> Email Class Initialized
INFO - 2018-07-16 23:23:16 --> Controller Class Initialized
DEBUG - 2018-07-16 23:23:16 --> Profile MX_Controller Initialized
INFO - 2018-07-16 23:23:16 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 23:23:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 23:23:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Profile_model.php
DEBUG - 2018-07-16 23:23:16 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-16 23:23:16 --> Login MX_Controller Initialized
DEBUG - 2018-07-16 23:23:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-16 23:23:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-16 23:23:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-16 23:23:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-16 23:23:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-16 23:23:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-16 23:23:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/profile.php
INFO - 2018-07-16 23:23:16 --> Final output sent to browser
DEBUG - 2018-07-16 23:23:16 --> Total execution time: 0.8689
INFO - 2018-07-16 23:26:02 --> Config Class Initialized
INFO - 2018-07-16 23:26:02 --> Hooks Class Initialized
DEBUG - 2018-07-16 23:26:02 --> UTF-8 Support Enabled
INFO - 2018-07-16 23:26:02 --> Utf8 Class Initialized
INFO - 2018-07-16 23:26:02 --> URI Class Initialized
INFO - 2018-07-16 23:26:02 --> Router Class Initialized
INFO - 2018-07-16 23:26:02 --> Output Class Initialized
INFO - 2018-07-16 23:26:02 --> Security Class Initialized
DEBUG - 2018-07-16 23:26:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 23:26:02 --> Input Class Initialized
INFO - 2018-07-16 23:26:02 --> Language Class Initialized
INFO - 2018-07-16 23:26:02 --> Language Class Initialized
INFO - 2018-07-16 23:26:02 --> Config Class Initialized
INFO - 2018-07-16 23:26:02 --> Loader Class Initialized
DEBUG - 2018-07-16 23:26:02 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 23:26:02 --> Helper loaded: url_helper
INFO - 2018-07-16 23:26:02 --> Helper loaded: form_helper
INFO - 2018-07-16 23:26:02 --> Helper loaded: date_helper
INFO - 2018-07-16 23:26:02 --> Helper loaded: util_helper
INFO - 2018-07-16 23:26:02 --> Helper loaded: text_helper
INFO - 2018-07-16 23:26:02 --> Helper loaded: string_helper
INFO - 2018-07-16 23:26:02 --> Database Driver Class Initialized
DEBUG - 2018-07-16 23:26:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 23:26:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 23:26:02 --> Email Class Initialized
INFO - 2018-07-16 23:26:02 --> Controller Class Initialized
DEBUG - 2018-07-16 23:26:02 --> Profile MX_Controller Initialized
INFO - 2018-07-16 23:26:02 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 23:26:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 23:26:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Profile_model.php
DEBUG - 2018-07-16 23:26:02 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-16 23:26:02 --> Login MX_Controller Initialized
DEBUG - 2018-07-16 23:26:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-16 23:26:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-16 23:26:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-16 23:26:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-16 23:26:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-16 23:26:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-16 23:26:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/profile.php
INFO - 2018-07-16 23:26:03 --> Final output sent to browser
DEBUG - 2018-07-16 23:26:03 --> Total execution time: 0.5452
INFO - 2018-07-16 23:27:43 --> Config Class Initialized
INFO - 2018-07-16 23:27:43 --> Hooks Class Initialized
DEBUG - 2018-07-16 23:27:43 --> UTF-8 Support Enabled
INFO - 2018-07-16 23:27:43 --> Utf8 Class Initialized
INFO - 2018-07-16 23:27:43 --> URI Class Initialized
DEBUG - 2018-07-16 23:27:43 --> No URI present. Default controller set.
INFO - 2018-07-16 23:27:43 --> Router Class Initialized
INFO - 2018-07-16 23:27:43 --> Output Class Initialized
INFO - 2018-07-16 23:27:43 --> Security Class Initialized
DEBUG - 2018-07-16 23:27:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 23:27:43 --> Input Class Initialized
INFO - 2018-07-16 23:27:43 --> Language Class Initialized
INFO - 2018-07-16 23:27:43 --> Language Class Initialized
INFO - 2018-07-16 23:27:43 --> Config Class Initialized
INFO - 2018-07-16 23:27:43 --> Loader Class Initialized
DEBUG - 2018-07-16 23:27:43 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 23:27:43 --> Helper loaded: url_helper
INFO - 2018-07-16 23:27:43 --> Helper loaded: form_helper
INFO - 2018-07-16 23:27:43 --> Helper loaded: date_helper
INFO - 2018-07-16 23:27:43 --> Helper loaded: util_helper
INFO - 2018-07-16 23:27:43 --> Helper loaded: text_helper
INFO - 2018-07-16 23:27:43 --> Helper loaded: string_helper
INFO - 2018-07-16 23:27:43 --> Database Driver Class Initialized
DEBUG - 2018-07-16 23:27:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 23:27:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 23:27:43 --> Email Class Initialized
INFO - 2018-07-16 23:27:43 --> Controller Class Initialized
DEBUG - 2018-07-16 23:27:43 --> Home MX_Controller Initialized
DEBUG - 2018-07-16 23:27:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-16 23:27:43 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-16 23:27:43 --> Login MX_Controller Initialized
INFO - 2018-07-16 23:27:43 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 23:27:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 23:27:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-16 23:27:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-16 23:27:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-16 23:27:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-16 23:27:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-16 23:27:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-16 23:27:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-16 23:27:43 --> Final output sent to browser
DEBUG - 2018-07-16 23:27:43 --> Total execution time: 0.6559
INFO - 2018-07-16 23:27:44 --> Config Class Initialized
INFO - 2018-07-16 23:27:44 --> Hooks Class Initialized
DEBUG - 2018-07-16 23:27:44 --> UTF-8 Support Enabled
INFO - 2018-07-16 23:27:44 --> Utf8 Class Initialized
INFO - 2018-07-16 23:27:44 --> URI Class Initialized
INFO - 2018-07-16 23:27:44 --> Router Class Initialized
INFO - 2018-07-16 23:27:44 --> Output Class Initialized
INFO - 2018-07-16 23:27:44 --> Security Class Initialized
DEBUG - 2018-07-16 23:27:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 23:27:44 --> Input Class Initialized
INFO - 2018-07-16 23:27:44 --> Language Class Initialized
ERROR - 2018-07-16 23:27:44 --> 404 Page Not Found: /index
INFO - 2018-07-16 23:27:44 --> Config Class Initialized
INFO - 2018-07-16 23:27:44 --> Hooks Class Initialized
DEBUG - 2018-07-16 23:27:44 --> UTF-8 Support Enabled
INFO - 2018-07-16 23:27:45 --> Utf8 Class Initialized
INFO - 2018-07-16 23:27:45 --> URI Class Initialized
INFO - 2018-07-16 23:27:45 --> Router Class Initialized
INFO - 2018-07-16 23:27:45 --> Output Class Initialized
INFO - 2018-07-16 23:27:45 --> Security Class Initialized
DEBUG - 2018-07-16 23:27:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 23:27:45 --> Input Class Initialized
INFO - 2018-07-16 23:27:45 --> Language Class Initialized
ERROR - 2018-07-16 23:27:45 --> 404 Page Not Found: /index
INFO - 2018-07-16 23:27:45 --> Config Class Initialized
INFO - 2018-07-16 23:27:45 --> Hooks Class Initialized
DEBUG - 2018-07-16 23:27:45 --> UTF-8 Support Enabled
INFO - 2018-07-16 23:27:45 --> Utf8 Class Initialized
INFO - 2018-07-16 23:27:45 --> URI Class Initialized
INFO - 2018-07-16 23:27:45 --> Router Class Initialized
INFO - 2018-07-16 23:27:45 --> Output Class Initialized
INFO - 2018-07-16 23:27:45 --> Security Class Initialized
DEBUG - 2018-07-16 23:27:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 23:27:45 --> Input Class Initialized
INFO - 2018-07-16 23:27:45 --> Language Class Initialized
ERROR - 2018-07-16 23:27:45 --> 404 Page Not Found: /index
INFO - 2018-07-16 23:27:45 --> Config Class Initialized
INFO - 2018-07-16 23:27:45 --> Hooks Class Initialized
DEBUG - 2018-07-16 23:27:45 --> UTF-8 Support Enabled
INFO - 2018-07-16 23:27:45 --> Utf8 Class Initialized
INFO - 2018-07-16 23:27:45 --> URI Class Initialized
INFO - 2018-07-16 23:27:45 --> Router Class Initialized
INFO - 2018-07-16 23:27:45 --> Output Class Initialized
INFO - 2018-07-16 23:27:45 --> Security Class Initialized
DEBUG - 2018-07-16 23:27:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 23:27:45 --> Input Class Initialized
INFO - 2018-07-16 23:27:45 --> Language Class Initialized
ERROR - 2018-07-16 23:27:45 --> 404 Page Not Found: /index
INFO - 2018-07-16 23:27:45 --> Config Class Initialized
INFO - 2018-07-16 23:27:45 --> Hooks Class Initialized
DEBUG - 2018-07-16 23:27:45 --> UTF-8 Support Enabled
INFO - 2018-07-16 23:27:45 --> Utf8 Class Initialized
INFO - 2018-07-16 23:27:45 --> URI Class Initialized
INFO - 2018-07-16 23:27:45 --> Router Class Initialized
INFO - 2018-07-16 23:27:45 --> Output Class Initialized
INFO - 2018-07-16 23:27:45 --> Security Class Initialized
DEBUG - 2018-07-16 23:27:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 23:27:45 --> Input Class Initialized
INFO - 2018-07-16 23:27:45 --> Language Class Initialized
ERROR - 2018-07-16 23:27:45 --> 404 Page Not Found: /index
INFO - 2018-07-16 23:39:31 --> Config Class Initialized
INFO - 2018-07-16 23:39:31 --> Hooks Class Initialized
DEBUG - 2018-07-16 23:39:31 --> UTF-8 Support Enabled
INFO - 2018-07-16 23:39:31 --> Utf8 Class Initialized
INFO - 2018-07-16 23:39:31 --> URI Class Initialized
INFO - 2018-07-16 23:39:31 --> Router Class Initialized
INFO - 2018-07-16 23:39:31 --> Output Class Initialized
INFO - 2018-07-16 23:39:31 --> Security Class Initialized
DEBUG - 2018-07-16 23:39:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 23:39:31 --> Input Class Initialized
INFO - 2018-07-16 23:39:31 --> Language Class Initialized
INFO - 2018-07-16 23:39:31 --> Language Class Initialized
INFO - 2018-07-16 23:39:31 --> Config Class Initialized
INFO - 2018-07-16 23:39:31 --> Loader Class Initialized
DEBUG - 2018-07-16 23:39:31 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 23:39:31 --> Helper loaded: url_helper
INFO - 2018-07-16 23:39:31 --> Helper loaded: form_helper
INFO - 2018-07-16 23:39:31 --> Helper loaded: date_helper
INFO - 2018-07-16 23:39:31 --> Helper loaded: util_helper
INFO - 2018-07-16 23:39:31 --> Helper loaded: text_helper
INFO - 2018-07-16 23:39:31 --> Helper loaded: string_helper
INFO - 2018-07-16 23:39:31 --> Database Driver Class Initialized
DEBUG - 2018-07-16 23:39:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 23:39:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 23:39:31 --> Email Class Initialized
INFO - 2018-07-16 23:39:31 --> Controller Class Initialized
DEBUG - 2018-07-16 23:39:31 --> Profile MX_Controller Initialized
INFO - 2018-07-16 23:39:31 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 23:39:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 23:39:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Profile_model.php
DEBUG - 2018-07-16 23:39:31 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-16 23:39:31 --> Login MX_Controller Initialized
DEBUG - 2018-07-16 23:39:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-16 23:39:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-16 23:39:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-16 23:39:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-16 23:39:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-16 23:39:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-16 23:39:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/profile.php
INFO - 2018-07-16 23:39:31 --> Final output sent to browser
DEBUG - 2018-07-16 23:39:32 --> Total execution time: 0.5396
INFO - 2018-07-16 23:39:37 --> Config Class Initialized
INFO - 2018-07-16 23:39:37 --> Hooks Class Initialized
DEBUG - 2018-07-16 23:39:37 --> UTF-8 Support Enabled
INFO - 2018-07-16 23:39:37 --> Utf8 Class Initialized
INFO - 2018-07-16 23:39:37 --> URI Class Initialized
INFO - 2018-07-16 23:39:37 --> Router Class Initialized
INFO - 2018-07-16 23:39:37 --> Output Class Initialized
INFO - 2018-07-16 23:39:37 --> Security Class Initialized
DEBUG - 2018-07-16 23:39:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 23:39:37 --> Input Class Initialized
INFO - 2018-07-16 23:39:37 --> Language Class Initialized
ERROR - 2018-07-16 23:39:37 --> 404 Page Not Found: /index
INFO - 2018-07-16 23:39:44 --> Config Class Initialized
INFO - 2018-07-16 23:39:44 --> Hooks Class Initialized
DEBUG - 2018-07-16 23:39:44 --> UTF-8 Support Enabled
INFO - 2018-07-16 23:39:44 --> Utf8 Class Initialized
INFO - 2018-07-16 23:39:44 --> URI Class Initialized
INFO - 2018-07-16 23:39:44 --> Router Class Initialized
INFO - 2018-07-16 23:39:44 --> Output Class Initialized
INFO - 2018-07-16 23:39:44 --> Security Class Initialized
DEBUG - 2018-07-16 23:39:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 23:39:44 --> Input Class Initialized
INFO - 2018-07-16 23:39:44 --> Language Class Initialized
INFO - 2018-07-16 23:39:44 --> Language Class Initialized
INFO - 2018-07-16 23:39:44 --> Config Class Initialized
INFO - 2018-07-16 23:39:44 --> Loader Class Initialized
DEBUG - 2018-07-16 23:39:44 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 23:39:44 --> Helper loaded: url_helper
INFO - 2018-07-16 23:39:44 --> Helper loaded: form_helper
INFO - 2018-07-16 23:39:44 --> Helper loaded: date_helper
INFO - 2018-07-16 23:39:44 --> Helper loaded: util_helper
INFO - 2018-07-16 23:39:44 --> Helper loaded: text_helper
INFO - 2018-07-16 23:39:44 --> Helper loaded: string_helper
INFO - 2018-07-16 23:39:44 --> Database Driver Class Initialized
DEBUG - 2018-07-16 23:39:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 23:39:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 23:39:44 --> Email Class Initialized
INFO - 2018-07-16 23:39:44 --> Controller Class Initialized
DEBUG - 2018-07-16 23:39:44 --> Users MX_Controller Initialized
DEBUG - 2018-07-16 23:39:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 23:39:44 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-16 23:39:44 --> Login MX_Controller Initialized
INFO - 2018-07-16 23:39:44 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 23:39:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-16 23:39:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-16 23:39:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-16 23:39:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-16 23:39:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-16 23:39:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-16 23:39:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-07-16 23:39:44 --> Final output sent to browser
DEBUG - 2018-07-16 23:39:44 --> Total execution time: 0.5768
INFO - 2018-07-16 23:39:45 --> Config Class Initialized
INFO - 2018-07-16 23:39:45 --> Hooks Class Initialized
DEBUG - 2018-07-16 23:39:45 --> UTF-8 Support Enabled
INFO - 2018-07-16 23:39:45 --> Utf8 Class Initialized
INFO - 2018-07-16 23:39:45 --> URI Class Initialized
INFO - 2018-07-16 23:39:45 --> Router Class Initialized
INFO - 2018-07-16 23:39:45 --> Output Class Initialized
INFO - 2018-07-16 23:39:45 --> Security Class Initialized
DEBUG - 2018-07-16 23:39:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 23:39:45 --> Input Class Initialized
INFO - 2018-07-16 23:39:45 --> Language Class Initialized
INFO - 2018-07-16 23:39:45 --> Language Class Initialized
INFO - 2018-07-16 23:39:45 --> Config Class Initialized
INFO - 2018-07-16 23:39:45 --> Loader Class Initialized
DEBUG - 2018-07-16 23:39:45 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 23:39:45 --> Helper loaded: url_helper
INFO - 2018-07-16 23:39:45 --> Helper loaded: form_helper
INFO - 2018-07-16 23:39:45 --> Helper loaded: date_helper
INFO - 2018-07-16 23:39:45 --> Helper loaded: util_helper
INFO - 2018-07-16 23:39:45 --> Helper loaded: text_helper
INFO - 2018-07-16 23:39:45 --> Helper loaded: string_helper
INFO - 2018-07-16 23:39:45 --> Database Driver Class Initialized
DEBUG - 2018-07-16 23:39:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 23:39:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 23:39:45 --> Email Class Initialized
INFO - 2018-07-16 23:39:45 --> Controller Class Initialized
DEBUG - 2018-07-16 23:39:45 --> Users MX_Controller Initialized
DEBUG - 2018-07-16 23:39:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 23:39:45 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-16 23:39:45 --> Login MX_Controller Initialized
INFO - 2018-07-16 23:39:45 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 23:39:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-16 23:39:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-16 23:39:45 --> Final output sent to browser
DEBUG - 2018-07-16 23:39:45 --> Total execution time: 0.5944
INFO - 2018-07-16 23:39:57 --> Config Class Initialized
INFO - 2018-07-16 23:39:57 --> Hooks Class Initialized
DEBUG - 2018-07-16 23:39:57 --> UTF-8 Support Enabled
INFO - 2018-07-16 23:39:57 --> Utf8 Class Initialized
INFO - 2018-07-16 23:39:57 --> URI Class Initialized
INFO - 2018-07-16 23:39:57 --> Router Class Initialized
INFO - 2018-07-16 23:39:57 --> Output Class Initialized
INFO - 2018-07-16 23:39:57 --> Security Class Initialized
DEBUG - 2018-07-16 23:39:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 23:39:57 --> Input Class Initialized
INFO - 2018-07-16 23:39:57 --> Language Class Initialized
INFO - 2018-07-16 23:39:57 --> Language Class Initialized
INFO - 2018-07-16 23:39:57 --> Config Class Initialized
INFO - 2018-07-16 23:39:57 --> Loader Class Initialized
DEBUG - 2018-07-16 23:39:57 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 23:39:57 --> Helper loaded: url_helper
INFO - 2018-07-16 23:39:57 --> Helper loaded: form_helper
INFO - 2018-07-16 23:39:57 --> Helper loaded: date_helper
INFO - 2018-07-16 23:39:57 --> Helper loaded: util_helper
INFO - 2018-07-16 23:39:57 --> Helper loaded: text_helper
INFO - 2018-07-16 23:39:57 --> Helper loaded: string_helper
INFO - 2018-07-16 23:39:57 --> Database Driver Class Initialized
DEBUG - 2018-07-16 23:39:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 23:39:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 23:39:57 --> Email Class Initialized
INFO - 2018-07-16 23:39:57 --> Controller Class Initialized
DEBUG - 2018-07-16 23:39:57 --> Login MX_Controller Initialized
INFO - 2018-07-16 23:39:57 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 23:39:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 23:39:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-16 23:39:58 --> 1 Loggedout
INFO - 2018-07-16 23:39:58 --> Config Class Initialized
INFO - 2018-07-16 23:39:58 --> Hooks Class Initialized
DEBUG - 2018-07-16 23:39:58 --> UTF-8 Support Enabled
INFO - 2018-07-16 23:39:58 --> Utf8 Class Initialized
INFO - 2018-07-16 23:39:58 --> URI Class Initialized
INFO - 2018-07-16 23:39:58 --> Router Class Initialized
INFO - 2018-07-16 23:39:58 --> Output Class Initialized
INFO - 2018-07-16 23:39:58 --> Security Class Initialized
DEBUG - 2018-07-16 23:39:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 23:39:58 --> Input Class Initialized
INFO - 2018-07-16 23:39:58 --> Language Class Initialized
INFO - 2018-07-16 23:39:58 --> Language Class Initialized
INFO - 2018-07-16 23:39:58 --> Config Class Initialized
INFO - 2018-07-16 23:39:58 --> Loader Class Initialized
DEBUG - 2018-07-16 23:39:58 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 23:39:58 --> Helper loaded: url_helper
INFO - 2018-07-16 23:39:58 --> Helper loaded: form_helper
INFO - 2018-07-16 23:39:58 --> Helper loaded: date_helper
INFO - 2018-07-16 23:39:58 --> Helper loaded: util_helper
INFO - 2018-07-16 23:39:58 --> Helper loaded: text_helper
INFO - 2018-07-16 23:39:58 --> Helper loaded: string_helper
INFO - 2018-07-16 23:39:58 --> Database Driver Class Initialized
DEBUG - 2018-07-16 23:39:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 23:39:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 23:39:58 --> Email Class Initialized
INFO - 2018-07-16 23:39:58 --> Controller Class Initialized
DEBUG - 2018-07-16 23:39:58 --> Admin MX_Controller Initialized
INFO - 2018-07-16 23:39:58 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 23:39:58 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-16 23:39:58 --> Login MX_Controller Initialized
DEBUG - 2018-07-16 23:39:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 23:39:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-16 23:39:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
INFO - 2018-07-16 23:39:58 --> Config Class Initialized
INFO - 2018-07-16 23:39:58 --> Hooks Class Initialized
DEBUG - 2018-07-16 23:39:58 --> UTF-8 Support Enabled
INFO - 2018-07-16 23:39:58 --> Utf8 Class Initialized
INFO - 2018-07-16 23:39:58 --> URI Class Initialized
INFO - 2018-07-16 23:39:58 --> Router Class Initialized
INFO - 2018-07-16 23:39:58 --> Output Class Initialized
INFO - 2018-07-16 23:39:58 --> Security Class Initialized
DEBUG - 2018-07-16 23:39:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 23:39:58 --> Input Class Initialized
INFO - 2018-07-16 23:39:58 --> Language Class Initialized
ERROR - 2018-07-16 23:39:58 --> 404 Page Not Found: /index
INFO - 2018-07-16 23:40:01 --> Config Class Initialized
INFO - 2018-07-16 23:40:01 --> Hooks Class Initialized
DEBUG - 2018-07-16 23:40:01 --> UTF-8 Support Enabled
INFO - 2018-07-16 23:40:01 --> Utf8 Class Initialized
INFO - 2018-07-16 23:40:01 --> URI Class Initialized
INFO - 2018-07-16 23:40:01 --> Router Class Initialized
INFO - 2018-07-16 23:40:01 --> Output Class Initialized
INFO - 2018-07-16 23:40:01 --> Security Class Initialized
DEBUG - 2018-07-16 23:40:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 23:40:01 --> Input Class Initialized
INFO - 2018-07-16 23:40:01 --> Language Class Initialized
INFO - 2018-07-16 23:40:01 --> Language Class Initialized
INFO - 2018-07-16 23:40:01 --> Config Class Initialized
INFO - 2018-07-16 23:40:01 --> Loader Class Initialized
DEBUG - 2018-07-16 23:40:01 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 23:40:01 --> Helper loaded: url_helper
INFO - 2018-07-16 23:40:01 --> Helper loaded: form_helper
INFO - 2018-07-16 23:40:01 --> Helper loaded: date_helper
INFO - 2018-07-16 23:40:01 --> Helper loaded: util_helper
INFO - 2018-07-16 23:40:01 --> Helper loaded: text_helper
INFO - 2018-07-16 23:40:01 --> Helper loaded: string_helper
INFO - 2018-07-16 23:40:01 --> Database Driver Class Initialized
DEBUG - 2018-07-16 23:40:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 23:40:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 23:40:01 --> Email Class Initialized
INFO - 2018-07-16 23:40:01 --> Controller Class Initialized
DEBUG - 2018-07-16 23:40:01 --> Login MX_Controller Initialized
INFO - 2018-07-16 23:40:01 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 23:40:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 23:40:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-16 23:40:01 --> Email starts for user@colin.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-07-16 23:40:01 --> User session created for 4
INFO - 2018-07-16 23:40:01 --> Login status user@colin.com - success
INFO - 2018-07-16 23:40:01 --> Final output sent to browser
DEBUG - 2018-07-16 23:40:01 --> Total execution time: 0.5281
INFO - 2018-07-16 23:40:01 --> Config Class Initialized
INFO - 2018-07-16 23:40:01 --> Hooks Class Initialized
DEBUG - 2018-07-16 23:40:01 --> UTF-8 Support Enabled
INFO - 2018-07-16 23:40:01 --> Utf8 Class Initialized
INFO - 2018-07-16 23:40:01 --> URI Class Initialized
INFO - 2018-07-16 23:40:01 --> Router Class Initialized
INFO - 2018-07-16 23:40:01 --> Output Class Initialized
INFO - 2018-07-16 23:40:01 --> Security Class Initialized
DEBUG - 2018-07-16 23:40:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 23:40:01 --> Input Class Initialized
INFO - 2018-07-16 23:40:01 --> Language Class Initialized
INFO - 2018-07-16 23:40:01 --> Language Class Initialized
INFO - 2018-07-16 23:40:01 --> Config Class Initialized
INFO - 2018-07-16 23:40:01 --> Loader Class Initialized
DEBUG - 2018-07-16 23:40:01 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 23:40:01 --> Helper loaded: url_helper
INFO - 2018-07-16 23:40:01 --> Helper loaded: form_helper
INFO - 2018-07-16 23:40:02 --> Helper loaded: date_helper
INFO - 2018-07-16 23:40:02 --> Helper loaded: util_helper
INFO - 2018-07-16 23:40:02 --> Helper loaded: text_helper
INFO - 2018-07-16 23:40:02 --> Helper loaded: string_helper
INFO - 2018-07-16 23:40:02 --> Database Driver Class Initialized
DEBUG - 2018-07-16 23:40:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 23:40:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 23:40:02 --> Email Class Initialized
INFO - 2018-07-16 23:40:02 --> Controller Class Initialized
DEBUG - 2018-07-16 23:40:02 --> Admin MX_Controller Initialized
INFO - 2018-07-16 23:40:02 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 23:40:02 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-16 23:40:02 --> Login MX_Controller Initialized
DEBUG - 2018-07-16 23:40:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 23:40:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-16 23:40:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
INFO - 2018-07-16 23:40:02 --> Config Class Initialized
INFO - 2018-07-16 23:40:02 --> Hooks Class Initialized
DEBUG - 2018-07-16 23:40:02 --> UTF-8 Support Enabled
INFO - 2018-07-16 23:40:02 --> Utf8 Class Initialized
INFO - 2018-07-16 23:40:02 --> URI Class Initialized
INFO - 2018-07-16 23:40:02 --> Router Class Initialized
INFO - 2018-07-16 23:40:02 --> Output Class Initialized
INFO - 2018-07-16 23:40:02 --> Security Class Initialized
DEBUG - 2018-07-16 23:40:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 23:40:02 --> Input Class Initialized
INFO - 2018-07-16 23:40:02 --> Language Class Initialized
ERROR - 2018-07-16 23:40:02 --> 404 Page Not Found: /index
INFO - 2018-07-16 23:40:05 --> Config Class Initialized
INFO - 2018-07-16 23:40:05 --> Hooks Class Initialized
DEBUG - 2018-07-16 23:40:05 --> UTF-8 Support Enabled
INFO - 2018-07-16 23:40:05 --> Utf8 Class Initialized
INFO - 2018-07-16 23:40:05 --> URI Class Initialized
INFO - 2018-07-16 23:40:05 --> Router Class Initialized
INFO - 2018-07-16 23:40:05 --> Output Class Initialized
INFO - 2018-07-16 23:40:05 --> Security Class Initialized
DEBUG - 2018-07-16 23:40:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 23:40:05 --> Input Class Initialized
INFO - 2018-07-16 23:40:05 --> Language Class Initialized
INFO - 2018-07-16 23:40:05 --> Language Class Initialized
INFO - 2018-07-16 23:40:05 --> Config Class Initialized
INFO - 2018-07-16 23:40:05 --> Loader Class Initialized
DEBUG - 2018-07-16 23:40:05 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 23:40:05 --> Helper loaded: url_helper
INFO - 2018-07-16 23:40:05 --> Helper loaded: form_helper
INFO - 2018-07-16 23:40:05 --> Helper loaded: date_helper
INFO - 2018-07-16 23:40:05 --> Helper loaded: util_helper
INFO - 2018-07-16 23:40:05 --> Helper loaded: text_helper
INFO - 2018-07-16 23:40:05 --> Helper loaded: string_helper
INFO - 2018-07-16 23:40:05 --> Database Driver Class Initialized
DEBUG - 2018-07-16 23:40:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 23:40:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 23:40:05 --> Email Class Initialized
INFO - 2018-07-16 23:40:05 --> Controller Class Initialized
DEBUG - 2018-07-16 23:40:05 --> Admin MX_Controller Initialized
INFO - 2018-07-16 23:40:05 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 23:40:05 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-16 23:40:05 --> Login MX_Controller Initialized
DEBUG - 2018-07-16 23:40:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 23:40:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-16 23:40:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
INFO - 2018-07-16 23:40:05 --> Config Class Initialized
INFO - 2018-07-16 23:40:05 --> Hooks Class Initialized
DEBUG - 2018-07-16 23:40:05 --> UTF-8 Support Enabled
INFO - 2018-07-16 23:40:05 --> Utf8 Class Initialized
INFO - 2018-07-16 23:40:05 --> URI Class Initialized
INFO - 2018-07-16 23:40:05 --> Router Class Initialized
INFO - 2018-07-16 23:40:05 --> Output Class Initialized
INFO - 2018-07-16 23:40:05 --> Security Class Initialized
DEBUG - 2018-07-16 23:40:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 23:40:05 --> Input Class Initialized
INFO - 2018-07-16 23:40:05 --> Language Class Initialized
ERROR - 2018-07-16 23:40:05 --> 404 Page Not Found: /index
INFO - 2018-07-16 23:46:05 --> Config Class Initialized
INFO - 2018-07-16 23:46:05 --> Hooks Class Initialized
DEBUG - 2018-07-16 23:46:05 --> UTF-8 Support Enabled
INFO - 2018-07-16 23:46:05 --> Utf8 Class Initialized
INFO - 2018-07-16 23:46:05 --> URI Class Initialized
INFO - 2018-07-16 23:46:05 --> Router Class Initialized
INFO - 2018-07-16 23:46:05 --> Output Class Initialized
INFO - 2018-07-16 23:46:05 --> Security Class Initialized
DEBUG - 2018-07-16 23:46:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 23:46:05 --> Input Class Initialized
INFO - 2018-07-16 23:46:05 --> Language Class Initialized
INFO - 2018-07-16 23:46:05 --> Language Class Initialized
INFO - 2018-07-16 23:46:05 --> Config Class Initialized
INFO - 2018-07-16 23:46:05 --> Loader Class Initialized
DEBUG - 2018-07-16 23:46:05 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 23:46:05 --> Helper loaded: url_helper
INFO - 2018-07-16 23:46:05 --> Helper loaded: form_helper
INFO - 2018-07-16 23:46:05 --> Helper loaded: date_helper
INFO - 2018-07-16 23:46:05 --> Helper loaded: util_helper
INFO - 2018-07-16 23:46:05 --> Helper loaded: text_helper
INFO - 2018-07-16 23:46:05 --> Helper loaded: string_helper
INFO - 2018-07-16 23:46:05 --> Database Driver Class Initialized
DEBUG - 2018-07-16 23:46:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 23:46:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 23:46:05 --> Email Class Initialized
INFO - 2018-07-16 23:46:05 --> Controller Class Initialized
DEBUG - 2018-07-16 23:46:05 --> Login MX_Controller Initialized
INFO - 2018-07-16 23:46:05 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 23:46:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 23:46:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-16 23:46:05 --> Email starts for user@colin.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-07-16 23:46:05 --> User session created for 4
INFO - 2018-07-16 23:46:05 --> Login status user@colin.com - success
INFO - 2018-07-16 23:46:05 --> Final output sent to browser
DEBUG - 2018-07-16 23:46:05 --> Total execution time: 0.6085
INFO - 2018-07-16 23:46:05 --> Config Class Initialized
INFO - 2018-07-16 23:46:05 --> Hooks Class Initialized
DEBUG - 2018-07-16 23:46:05 --> UTF-8 Support Enabled
INFO - 2018-07-16 23:46:06 --> Utf8 Class Initialized
INFO - 2018-07-16 23:46:06 --> URI Class Initialized
INFO - 2018-07-16 23:46:06 --> Router Class Initialized
INFO - 2018-07-16 23:46:06 --> Output Class Initialized
INFO - 2018-07-16 23:46:06 --> Security Class Initialized
DEBUG - 2018-07-16 23:46:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 23:46:06 --> Input Class Initialized
INFO - 2018-07-16 23:46:06 --> Language Class Initialized
INFO - 2018-07-16 23:46:06 --> Language Class Initialized
INFO - 2018-07-16 23:46:06 --> Config Class Initialized
INFO - 2018-07-16 23:46:06 --> Loader Class Initialized
DEBUG - 2018-07-16 23:46:06 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 23:46:06 --> Helper loaded: url_helper
INFO - 2018-07-16 23:46:06 --> Helper loaded: form_helper
INFO - 2018-07-16 23:46:06 --> Helper loaded: date_helper
INFO - 2018-07-16 23:46:06 --> Helper loaded: util_helper
INFO - 2018-07-16 23:46:06 --> Helper loaded: text_helper
INFO - 2018-07-16 23:46:06 --> Helper loaded: string_helper
INFO - 2018-07-16 23:46:06 --> Database Driver Class Initialized
DEBUG - 2018-07-16 23:46:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 23:46:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 23:46:06 --> Email Class Initialized
INFO - 2018-07-16 23:46:06 --> Controller Class Initialized
DEBUG - 2018-07-16 23:46:06 --> Admin MX_Controller Initialized
INFO - 2018-07-16 23:46:06 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 23:46:06 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-16 23:46:06 --> Login MX_Controller Initialized
DEBUG - 2018-07-16 23:46:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 23:46:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-16 23:46:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
INFO - 2018-07-16 23:46:06 --> Config Class Initialized
INFO - 2018-07-16 23:46:06 --> Hooks Class Initialized
DEBUG - 2018-07-16 23:46:06 --> UTF-8 Support Enabled
INFO - 2018-07-16 23:46:06 --> Utf8 Class Initialized
INFO - 2018-07-16 23:46:06 --> URI Class Initialized
INFO - 2018-07-16 23:46:06 --> Router Class Initialized
INFO - 2018-07-16 23:46:06 --> Output Class Initialized
INFO - 2018-07-16 23:46:06 --> Security Class Initialized
DEBUG - 2018-07-16 23:46:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 23:46:06 --> Input Class Initialized
INFO - 2018-07-16 23:46:06 --> Language Class Initialized
ERROR - 2018-07-16 23:46:06 --> 404 Page Not Found: /index
INFO - 2018-07-16 23:46:19 --> Config Class Initialized
INFO - 2018-07-16 23:46:19 --> Hooks Class Initialized
DEBUG - 2018-07-16 23:46:19 --> UTF-8 Support Enabled
INFO - 2018-07-16 23:46:19 --> Utf8 Class Initialized
INFO - 2018-07-16 23:46:19 --> URI Class Initialized
INFO - 2018-07-16 23:46:19 --> Router Class Initialized
INFO - 2018-07-16 23:46:19 --> Output Class Initialized
INFO - 2018-07-16 23:46:19 --> Security Class Initialized
DEBUG - 2018-07-16 23:46:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 23:46:19 --> Input Class Initialized
INFO - 2018-07-16 23:46:19 --> Language Class Initialized
INFO - 2018-07-16 23:46:19 --> Language Class Initialized
INFO - 2018-07-16 23:46:19 --> Config Class Initialized
INFO - 2018-07-16 23:46:19 --> Loader Class Initialized
DEBUG - 2018-07-16 23:46:19 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 23:46:19 --> Helper loaded: url_helper
INFO - 2018-07-16 23:46:19 --> Helper loaded: form_helper
INFO - 2018-07-16 23:46:19 --> Helper loaded: date_helper
INFO - 2018-07-16 23:46:19 --> Helper loaded: util_helper
INFO - 2018-07-16 23:46:19 --> Helper loaded: text_helper
INFO - 2018-07-16 23:46:19 --> Helper loaded: string_helper
INFO - 2018-07-16 23:46:19 --> Database Driver Class Initialized
DEBUG - 2018-07-16 23:46:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 23:46:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 23:46:19 --> Email Class Initialized
INFO - 2018-07-16 23:46:19 --> Controller Class Initialized
DEBUG - 2018-07-16 23:46:19 --> Login MX_Controller Initialized
INFO - 2018-07-16 23:46:19 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 23:46:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 23:46:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-16 23:46:19 --> Email starts for gopipanguluri123@gmail.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-07-16 23:47:10 --> Config Class Initialized
INFO - 2018-07-16 23:47:10 --> Hooks Class Initialized
DEBUG - 2018-07-16 23:47:10 --> UTF-8 Support Enabled
INFO - 2018-07-16 23:47:10 --> Utf8 Class Initialized
INFO - 2018-07-16 23:47:10 --> URI Class Initialized
INFO - 2018-07-16 23:47:10 --> Router Class Initialized
INFO - 2018-07-16 23:47:10 --> Output Class Initialized
INFO - 2018-07-16 23:47:10 --> Security Class Initialized
DEBUG - 2018-07-16 23:47:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 23:47:10 --> Input Class Initialized
INFO - 2018-07-16 23:47:10 --> Language Class Initialized
INFO - 2018-07-16 23:47:10 --> Language Class Initialized
INFO - 2018-07-16 23:47:10 --> Config Class Initialized
INFO - 2018-07-16 23:47:10 --> Loader Class Initialized
DEBUG - 2018-07-16 23:47:10 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 23:47:10 --> Helper loaded: url_helper
INFO - 2018-07-16 23:47:10 --> Helper loaded: form_helper
INFO - 2018-07-16 23:47:10 --> Helper loaded: date_helper
INFO - 2018-07-16 23:47:10 --> Helper loaded: util_helper
INFO - 2018-07-16 23:47:10 --> Helper loaded: text_helper
INFO - 2018-07-16 23:47:10 --> Helper loaded: string_helper
INFO - 2018-07-16 23:47:10 --> Database Driver Class Initialized
DEBUG - 2018-07-16 23:47:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 23:47:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 23:47:10 --> Email Class Initialized
INFO - 2018-07-16 23:47:10 --> Controller Class Initialized
DEBUG - 2018-07-16 23:47:10 --> Login MX_Controller Initialized
INFO - 2018-07-16 23:47:10 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 23:47:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 23:47:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-16 23:47:10 --> Email starts for gopipanguluri123@gmail.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-07-16 23:47:21 --> Config Class Initialized
INFO - 2018-07-16 23:47:21 --> Hooks Class Initialized
DEBUG - 2018-07-16 23:47:21 --> UTF-8 Support Enabled
INFO - 2018-07-16 23:47:21 --> Utf8 Class Initialized
INFO - 2018-07-16 23:47:21 --> URI Class Initialized
INFO - 2018-07-16 23:47:21 --> Router Class Initialized
INFO - 2018-07-16 23:47:21 --> Output Class Initialized
INFO - 2018-07-16 23:47:21 --> Security Class Initialized
DEBUG - 2018-07-16 23:47:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 23:47:21 --> Input Class Initialized
INFO - 2018-07-16 23:47:21 --> Language Class Initialized
INFO - 2018-07-16 23:47:21 --> Language Class Initialized
INFO - 2018-07-16 23:47:21 --> Config Class Initialized
INFO - 2018-07-16 23:47:21 --> Loader Class Initialized
DEBUG - 2018-07-16 23:47:21 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 23:47:21 --> Helper loaded: url_helper
INFO - 2018-07-16 23:47:21 --> Helper loaded: form_helper
INFO - 2018-07-16 23:47:21 --> Helper loaded: date_helper
INFO - 2018-07-16 23:47:21 --> Helper loaded: util_helper
INFO - 2018-07-16 23:47:21 --> Helper loaded: text_helper
INFO - 2018-07-16 23:47:21 --> Helper loaded: string_helper
INFO - 2018-07-16 23:47:21 --> Database Driver Class Initialized
DEBUG - 2018-07-16 23:47:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 23:47:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 23:47:21 --> Email Class Initialized
INFO - 2018-07-16 23:47:21 --> Controller Class Initialized
DEBUG - 2018-07-16 23:47:21 --> Login MX_Controller Initialized
INFO - 2018-07-16 23:47:21 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 23:47:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 23:47:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-16 23:47:21 --> Email starts for user@colin.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-07-16 23:47:45 --> Config Class Initialized
INFO - 2018-07-16 23:47:45 --> Hooks Class Initialized
DEBUG - 2018-07-16 23:47:45 --> UTF-8 Support Enabled
INFO - 2018-07-16 23:47:45 --> Utf8 Class Initialized
INFO - 2018-07-16 23:47:45 --> URI Class Initialized
INFO - 2018-07-16 23:47:45 --> Router Class Initialized
INFO - 2018-07-16 23:47:45 --> Output Class Initialized
INFO - 2018-07-16 23:47:45 --> Security Class Initialized
DEBUG - 2018-07-16 23:47:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 23:47:45 --> Input Class Initialized
INFO - 2018-07-16 23:47:45 --> Language Class Initialized
INFO - 2018-07-16 23:47:45 --> Language Class Initialized
INFO - 2018-07-16 23:47:45 --> Config Class Initialized
INFO - 2018-07-16 23:47:45 --> Loader Class Initialized
DEBUG - 2018-07-16 23:47:45 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 23:47:45 --> Helper loaded: url_helper
INFO - 2018-07-16 23:47:45 --> Helper loaded: form_helper
INFO - 2018-07-16 23:47:45 --> Helper loaded: date_helper
INFO - 2018-07-16 23:47:45 --> Helper loaded: util_helper
INFO - 2018-07-16 23:47:45 --> Helper loaded: text_helper
INFO - 2018-07-16 23:47:45 --> Helper loaded: string_helper
INFO - 2018-07-16 23:47:45 --> Database Driver Class Initialized
DEBUG - 2018-07-16 23:47:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 23:47:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 23:47:45 --> Email Class Initialized
INFO - 2018-07-16 23:47:45 --> Controller Class Initialized
DEBUG - 2018-07-16 23:47:45 --> Admin MX_Controller Initialized
INFO - 2018-07-16 23:47:45 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 23:47:45 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-16 23:47:45 --> Login MX_Controller Initialized
DEBUG - 2018-07-16 23:47:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 23:47:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-16 23:47:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
INFO - 2018-07-16 23:47:45 --> Config Class Initialized
INFO - 2018-07-16 23:47:45 --> Hooks Class Initialized
DEBUG - 2018-07-16 23:47:45 --> UTF-8 Support Enabled
INFO - 2018-07-16 23:47:46 --> Utf8 Class Initialized
INFO - 2018-07-16 23:47:46 --> URI Class Initialized
INFO - 2018-07-16 23:47:46 --> Router Class Initialized
INFO - 2018-07-16 23:47:46 --> Output Class Initialized
INFO - 2018-07-16 23:47:46 --> Security Class Initialized
DEBUG - 2018-07-16 23:47:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 23:47:46 --> Input Class Initialized
INFO - 2018-07-16 23:47:46 --> Language Class Initialized
ERROR - 2018-07-16 23:47:46 --> 404 Page Not Found: /index
INFO - 2018-07-16 23:47:46 --> Config Class Initialized
INFO - 2018-07-16 23:47:46 --> Hooks Class Initialized
DEBUG - 2018-07-16 23:47:46 --> UTF-8 Support Enabled
INFO - 2018-07-16 23:47:46 --> Utf8 Class Initialized
INFO - 2018-07-16 23:47:46 --> URI Class Initialized
INFO - 2018-07-16 23:47:46 --> Router Class Initialized
INFO - 2018-07-16 23:47:46 --> Output Class Initialized
INFO - 2018-07-16 23:47:46 --> Security Class Initialized
DEBUG - 2018-07-16 23:47:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 23:47:46 --> Input Class Initialized
INFO - 2018-07-16 23:47:46 --> Language Class Initialized
ERROR - 2018-07-16 23:47:46 --> 404 Page Not Found: /index
INFO - 2018-07-16 23:47:53 --> Config Class Initialized
INFO - 2018-07-16 23:47:53 --> Hooks Class Initialized
DEBUG - 2018-07-16 23:47:53 --> UTF-8 Support Enabled
INFO - 2018-07-16 23:47:53 --> Utf8 Class Initialized
INFO - 2018-07-16 23:47:53 --> URI Class Initialized
INFO - 2018-07-16 23:47:53 --> Router Class Initialized
INFO - 2018-07-16 23:47:53 --> Output Class Initialized
INFO - 2018-07-16 23:47:53 --> Security Class Initialized
DEBUG - 2018-07-16 23:47:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 23:47:53 --> Input Class Initialized
INFO - 2018-07-16 23:47:53 --> Language Class Initialized
INFO - 2018-07-16 23:47:53 --> Language Class Initialized
INFO - 2018-07-16 23:47:53 --> Config Class Initialized
INFO - 2018-07-16 23:47:53 --> Loader Class Initialized
DEBUG - 2018-07-16 23:47:53 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 23:47:53 --> Helper loaded: url_helper
INFO - 2018-07-16 23:47:53 --> Helper loaded: form_helper
INFO - 2018-07-16 23:47:53 --> Helper loaded: date_helper
INFO - 2018-07-16 23:47:53 --> Helper loaded: util_helper
INFO - 2018-07-16 23:47:53 --> Helper loaded: text_helper
INFO - 2018-07-16 23:47:53 --> Helper loaded: string_helper
INFO - 2018-07-16 23:47:53 --> Database Driver Class Initialized
DEBUG - 2018-07-16 23:47:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 23:47:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 23:47:53 --> Email Class Initialized
INFO - 2018-07-16 23:47:53 --> Controller Class Initialized
DEBUG - 2018-07-16 23:47:53 --> Login MX_Controller Initialized
INFO - 2018-07-16 23:47:53 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 23:47:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 23:47:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-16 23:47:53 --> Email starts for admin@colin.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-07-16 23:48:12 --> Config Class Initialized
INFO - 2018-07-16 23:48:12 --> Hooks Class Initialized
DEBUG - 2018-07-16 23:48:12 --> UTF-8 Support Enabled
INFO - 2018-07-16 23:48:12 --> Utf8 Class Initialized
INFO - 2018-07-16 23:48:12 --> URI Class Initialized
INFO - 2018-07-16 23:48:12 --> Router Class Initialized
INFO - 2018-07-16 23:48:12 --> Output Class Initialized
INFO - 2018-07-16 23:48:12 --> Security Class Initialized
DEBUG - 2018-07-16 23:48:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 23:48:12 --> Input Class Initialized
INFO - 2018-07-16 23:48:12 --> Language Class Initialized
INFO - 2018-07-16 23:48:12 --> Language Class Initialized
INFO - 2018-07-16 23:48:12 --> Config Class Initialized
INFO - 2018-07-16 23:48:12 --> Loader Class Initialized
DEBUG - 2018-07-16 23:48:12 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 23:48:12 --> Helper loaded: url_helper
INFO - 2018-07-16 23:48:12 --> Helper loaded: form_helper
INFO - 2018-07-16 23:48:12 --> Helper loaded: date_helper
INFO - 2018-07-16 23:48:12 --> Helper loaded: util_helper
INFO - 2018-07-16 23:48:12 --> Helper loaded: text_helper
INFO - 2018-07-16 23:48:12 --> Helper loaded: string_helper
INFO - 2018-07-16 23:48:12 --> Database Driver Class Initialized
DEBUG - 2018-07-16 23:48:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 23:48:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 23:48:12 --> Email Class Initialized
INFO - 2018-07-16 23:48:12 --> Controller Class Initialized
DEBUG - 2018-07-16 23:48:12 --> Login MX_Controller Initialized
INFO - 2018-07-16 23:48:12 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 23:48:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 23:48:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-16 23:48:13 --> Email starts for admin@colin.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-07-16 23:48:13 --> User session created for 1
INFO - 2018-07-16 23:48:13 --> Login status admin@colin.com - success
INFO - 2018-07-16 23:48:13 --> Final output sent to browser
DEBUG - 2018-07-16 23:48:13 --> Total execution time: 0.5641
INFO - 2018-07-16 23:48:13 --> Config Class Initialized
INFO - 2018-07-16 23:48:13 --> Hooks Class Initialized
DEBUG - 2018-07-16 23:48:13 --> UTF-8 Support Enabled
INFO - 2018-07-16 23:48:13 --> Utf8 Class Initialized
INFO - 2018-07-16 23:48:13 --> URI Class Initialized
INFO - 2018-07-16 23:48:13 --> Router Class Initialized
INFO - 2018-07-16 23:48:13 --> Output Class Initialized
INFO - 2018-07-16 23:48:13 --> Security Class Initialized
DEBUG - 2018-07-16 23:48:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 23:48:13 --> Input Class Initialized
INFO - 2018-07-16 23:48:13 --> Language Class Initialized
INFO - 2018-07-16 23:48:13 --> Language Class Initialized
INFO - 2018-07-16 23:48:13 --> Config Class Initialized
INFO - 2018-07-16 23:48:13 --> Loader Class Initialized
DEBUG - 2018-07-16 23:48:13 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 23:48:13 --> Helper loaded: url_helper
INFO - 2018-07-16 23:48:13 --> Helper loaded: form_helper
INFO - 2018-07-16 23:48:13 --> Helper loaded: date_helper
INFO - 2018-07-16 23:48:13 --> Helper loaded: util_helper
INFO - 2018-07-16 23:48:13 --> Helper loaded: text_helper
INFO - 2018-07-16 23:48:13 --> Helper loaded: string_helper
INFO - 2018-07-16 23:48:13 --> Database Driver Class Initialized
DEBUG - 2018-07-16 23:48:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 23:48:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 23:48:13 --> Email Class Initialized
INFO - 2018-07-16 23:48:13 --> Controller Class Initialized
DEBUG - 2018-07-16 23:48:13 --> Admin MX_Controller Initialized
INFO - 2018-07-16 23:48:13 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 23:48:13 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-16 23:48:13 --> Login MX_Controller Initialized
DEBUG - 2018-07-16 23:48:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 23:48:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-16 23:48:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-16 23:48:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-16 23:48:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-16 23:48:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-16 23:48:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-16 23:48:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/dashboard.php
INFO - 2018-07-16 23:48:13 --> Final output sent to browser
DEBUG - 2018-07-16 23:48:13 --> Total execution time: 0.5693
INFO - 2018-07-16 23:48:13 --> Config Class Initialized
INFO - 2018-07-16 23:48:13 --> Config Class Initialized
INFO - 2018-07-16 23:48:13 --> Hooks Class Initialized
INFO - 2018-07-16 23:48:13 --> Hooks Class Initialized
DEBUG - 2018-07-16 23:48:13 --> UTF-8 Support Enabled
DEBUG - 2018-07-16 23:48:13 --> UTF-8 Support Enabled
INFO - 2018-07-16 23:48:13 --> Utf8 Class Initialized
INFO - 2018-07-16 23:48:13 --> Utf8 Class Initialized
INFO - 2018-07-16 23:48:14 --> URI Class Initialized
INFO - 2018-07-16 23:48:14 --> URI Class Initialized
INFO - 2018-07-16 23:48:14 --> Router Class Initialized
INFO - 2018-07-16 23:48:14 --> Router Class Initialized
INFO - 2018-07-16 23:48:14 --> Output Class Initialized
INFO - 2018-07-16 23:48:14 --> Output Class Initialized
INFO - 2018-07-16 23:48:14 --> Security Class Initialized
INFO - 2018-07-16 23:48:14 --> Security Class Initialized
DEBUG - 2018-07-16 23:48:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-07-16 23:48:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 23:48:14 --> Input Class Initialized
INFO - 2018-07-16 23:48:14 --> Input Class Initialized
INFO - 2018-07-16 23:48:14 --> Language Class Initialized
INFO - 2018-07-16 23:48:14 --> Language Class Initialized
ERROR - 2018-07-16 23:48:14 --> 404 Page Not Found: /index
ERROR - 2018-07-16 23:48:14 --> 404 Page Not Found: /index
INFO - 2018-07-16 23:48:17 --> Config Class Initialized
INFO - 2018-07-16 23:48:17 --> Hooks Class Initialized
DEBUG - 2018-07-16 23:48:17 --> UTF-8 Support Enabled
INFO - 2018-07-16 23:48:17 --> Utf8 Class Initialized
INFO - 2018-07-16 23:48:17 --> URI Class Initialized
INFO - 2018-07-16 23:48:17 --> Router Class Initialized
INFO - 2018-07-16 23:48:17 --> Output Class Initialized
INFO - 2018-07-16 23:48:17 --> Security Class Initialized
DEBUG - 2018-07-16 23:48:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 23:48:17 --> Input Class Initialized
INFO - 2018-07-16 23:48:17 --> Language Class Initialized
INFO - 2018-07-16 23:48:17 --> Language Class Initialized
INFO - 2018-07-16 23:48:17 --> Config Class Initialized
INFO - 2018-07-16 23:48:17 --> Loader Class Initialized
DEBUG - 2018-07-16 23:48:17 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 23:48:17 --> Helper loaded: url_helper
INFO - 2018-07-16 23:48:17 --> Helper loaded: form_helper
INFO - 2018-07-16 23:48:17 --> Helper loaded: date_helper
INFO - 2018-07-16 23:48:17 --> Helper loaded: util_helper
INFO - 2018-07-16 23:48:17 --> Helper loaded: text_helper
INFO - 2018-07-16 23:48:17 --> Helper loaded: string_helper
INFO - 2018-07-16 23:48:17 --> Database Driver Class Initialized
DEBUG - 2018-07-16 23:48:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 23:48:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 23:48:17 --> Email Class Initialized
INFO - 2018-07-16 23:48:17 --> Controller Class Initialized
DEBUG - 2018-07-16 23:48:17 --> Users MX_Controller Initialized
DEBUG - 2018-07-16 23:48:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 23:48:17 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-16 23:48:17 --> Login MX_Controller Initialized
INFO - 2018-07-16 23:48:17 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 23:48:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-16 23:48:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-16 23:48:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-16 23:48:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-16 23:48:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-16 23:48:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-16 23:48:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-07-16 23:48:18 --> Final output sent to browser
DEBUG - 2018-07-16 23:48:18 --> Total execution time: 0.6734
INFO - 2018-07-16 23:48:18 --> Config Class Initialized
INFO - 2018-07-16 23:48:18 --> Hooks Class Initialized
DEBUG - 2018-07-16 23:48:18 --> UTF-8 Support Enabled
INFO - 2018-07-16 23:48:18 --> Utf8 Class Initialized
INFO - 2018-07-16 23:48:18 --> URI Class Initialized
INFO - 2018-07-16 23:48:18 --> Router Class Initialized
INFO - 2018-07-16 23:48:18 --> Output Class Initialized
INFO - 2018-07-16 23:48:18 --> Security Class Initialized
DEBUG - 2018-07-16 23:48:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 23:48:18 --> Input Class Initialized
INFO - 2018-07-16 23:48:18 --> Language Class Initialized
INFO - 2018-07-16 23:48:18 --> Language Class Initialized
INFO - 2018-07-16 23:48:18 --> Config Class Initialized
INFO - 2018-07-16 23:48:18 --> Loader Class Initialized
DEBUG - 2018-07-16 23:48:18 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 23:48:18 --> Helper loaded: url_helper
INFO - 2018-07-16 23:48:18 --> Helper loaded: form_helper
INFO - 2018-07-16 23:48:18 --> Helper loaded: date_helper
INFO - 2018-07-16 23:48:18 --> Helper loaded: util_helper
INFO - 2018-07-16 23:48:18 --> Helper loaded: text_helper
INFO - 2018-07-16 23:48:18 --> Helper loaded: string_helper
INFO - 2018-07-16 23:48:18 --> Database Driver Class Initialized
DEBUG - 2018-07-16 23:48:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 23:48:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 23:48:18 --> Email Class Initialized
INFO - 2018-07-16 23:48:18 --> Controller Class Initialized
DEBUG - 2018-07-16 23:48:18 --> Users MX_Controller Initialized
DEBUG - 2018-07-16 23:48:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 23:48:18 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-16 23:48:18 --> Login MX_Controller Initialized
INFO - 2018-07-16 23:48:18 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 23:48:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-16 23:48:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-16 23:48:18 --> Final output sent to browser
DEBUG - 2018-07-16 23:48:18 --> Total execution time: 0.6085
INFO - 2018-07-16 23:48:53 --> Config Class Initialized
INFO - 2018-07-16 23:48:53 --> Hooks Class Initialized
DEBUG - 2018-07-16 23:48:53 --> UTF-8 Support Enabled
INFO - 2018-07-16 23:48:53 --> Utf8 Class Initialized
INFO - 2018-07-16 23:48:53 --> URI Class Initialized
INFO - 2018-07-16 23:48:53 --> Router Class Initialized
INFO - 2018-07-16 23:48:53 --> Output Class Initialized
INFO - 2018-07-16 23:48:53 --> Security Class Initialized
DEBUG - 2018-07-16 23:48:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 23:48:53 --> Input Class Initialized
INFO - 2018-07-16 23:48:53 --> Language Class Initialized
INFO - 2018-07-16 23:48:53 --> Language Class Initialized
INFO - 2018-07-16 23:48:53 --> Config Class Initialized
INFO - 2018-07-16 23:48:53 --> Loader Class Initialized
DEBUG - 2018-07-16 23:48:53 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 23:48:53 --> Helper loaded: url_helper
INFO - 2018-07-16 23:48:53 --> Helper loaded: form_helper
INFO - 2018-07-16 23:48:53 --> Helper loaded: date_helper
INFO - 2018-07-16 23:48:53 --> Helper loaded: util_helper
INFO - 2018-07-16 23:48:53 --> Helper loaded: text_helper
INFO - 2018-07-16 23:48:53 --> Helper loaded: string_helper
INFO - 2018-07-16 23:48:53 --> Database Driver Class Initialized
DEBUG - 2018-07-16 23:48:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 23:48:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 23:48:53 --> Email Class Initialized
INFO - 2018-07-16 23:48:53 --> Controller Class Initialized
DEBUG - 2018-07-16 23:48:53 --> Login MX_Controller Initialized
INFO - 2018-07-16 23:48:53 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 23:48:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 23:48:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-16 23:48:53 --> Email starts for gopipanguluri@gmail.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-07-16 23:49:55 --> Config Class Initialized
INFO - 2018-07-16 23:49:55 --> Hooks Class Initialized
DEBUG - 2018-07-16 23:49:55 --> UTF-8 Support Enabled
INFO - 2018-07-16 23:49:55 --> Utf8 Class Initialized
INFO - 2018-07-16 23:49:55 --> URI Class Initialized
INFO - 2018-07-16 23:49:55 --> Router Class Initialized
INFO - 2018-07-16 23:49:55 --> Output Class Initialized
INFO - 2018-07-16 23:49:55 --> Security Class Initialized
DEBUG - 2018-07-16 23:49:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 23:49:55 --> Input Class Initialized
INFO - 2018-07-16 23:49:55 --> Language Class Initialized
INFO - 2018-07-16 23:49:55 --> Language Class Initialized
INFO - 2018-07-16 23:49:55 --> Config Class Initialized
INFO - 2018-07-16 23:49:55 --> Loader Class Initialized
DEBUG - 2018-07-16 23:49:55 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 23:49:55 --> Helper loaded: url_helper
INFO - 2018-07-16 23:49:55 --> Helper loaded: form_helper
INFO - 2018-07-16 23:49:55 --> Helper loaded: date_helper
INFO - 2018-07-16 23:49:55 --> Helper loaded: util_helper
INFO - 2018-07-16 23:49:55 --> Helper loaded: text_helper
INFO - 2018-07-16 23:49:55 --> Helper loaded: string_helper
INFO - 2018-07-16 23:49:55 --> Database Driver Class Initialized
DEBUG - 2018-07-16 23:49:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 23:49:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 23:49:55 --> Email Class Initialized
INFO - 2018-07-16 23:49:55 --> Controller Class Initialized
DEBUG - 2018-07-16 23:49:55 --> Login MX_Controller Initialized
INFO - 2018-07-16 23:49:55 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 23:49:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 23:49:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-16 23:49:55 --> Email starts for gopipanguluri@gmail.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
ERROR - 2018-07-16 23:49:55 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '3' at line 5 - Invalid query: SELECT *
FROM `users`
WHERE `email` = 'gopipanguluri@gmail.com'
AND `password` = 'e10adc3949ba59abbe56e057f20f883e'
AND `role_id` != `=` 3
INFO - 2018-07-16 23:49:55 --> Language file loaded: language/english/db_lang.php
INFO - 2018-07-16 23:50:26 --> Config Class Initialized
INFO - 2018-07-16 23:50:27 --> Hooks Class Initialized
DEBUG - 2018-07-16 23:50:27 --> UTF-8 Support Enabled
INFO - 2018-07-16 23:50:27 --> Utf8 Class Initialized
INFO - 2018-07-16 23:50:27 --> URI Class Initialized
INFO - 2018-07-16 23:50:27 --> Router Class Initialized
INFO - 2018-07-16 23:50:27 --> Output Class Initialized
INFO - 2018-07-16 23:50:27 --> Security Class Initialized
DEBUG - 2018-07-16 23:50:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 23:50:27 --> Input Class Initialized
INFO - 2018-07-16 23:50:27 --> Language Class Initialized
INFO - 2018-07-16 23:50:27 --> Language Class Initialized
INFO - 2018-07-16 23:50:27 --> Config Class Initialized
INFO - 2018-07-16 23:50:27 --> Loader Class Initialized
DEBUG - 2018-07-16 23:50:27 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 23:50:27 --> Helper loaded: url_helper
INFO - 2018-07-16 23:50:27 --> Helper loaded: form_helper
INFO - 2018-07-16 23:50:27 --> Helper loaded: date_helper
INFO - 2018-07-16 23:50:27 --> Helper loaded: util_helper
INFO - 2018-07-16 23:50:27 --> Helper loaded: text_helper
INFO - 2018-07-16 23:50:27 --> Helper loaded: string_helper
INFO - 2018-07-16 23:50:27 --> Database Driver Class Initialized
DEBUG - 2018-07-16 23:50:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 23:50:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 23:50:27 --> Email Class Initialized
INFO - 2018-07-16 23:50:27 --> Controller Class Initialized
DEBUG - 2018-07-16 23:50:27 --> Login MX_Controller Initialized
INFO - 2018-07-16 23:50:27 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 23:50:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 23:50:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-16 23:50:27 --> Email starts for gopipanguluri@gmail.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-07-16 23:50:41 --> Config Class Initialized
INFO - 2018-07-16 23:50:41 --> Hooks Class Initialized
DEBUG - 2018-07-16 23:50:41 --> UTF-8 Support Enabled
INFO - 2018-07-16 23:50:41 --> Utf8 Class Initialized
INFO - 2018-07-16 23:50:41 --> URI Class Initialized
INFO - 2018-07-16 23:50:41 --> Router Class Initialized
INFO - 2018-07-16 23:50:41 --> Output Class Initialized
INFO - 2018-07-16 23:50:41 --> Security Class Initialized
DEBUG - 2018-07-16 23:50:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 23:50:41 --> Input Class Initialized
INFO - 2018-07-16 23:50:41 --> Language Class Initialized
INFO - 2018-07-16 23:50:41 --> Language Class Initialized
INFO - 2018-07-16 23:50:41 --> Config Class Initialized
INFO - 2018-07-16 23:50:41 --> Loader Class Initialized
DEBUG - 2018-07-16 23:50:41 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 23:50:41 --> Helper loaded: url_helper
INFO - 2018-07-16 23:50:41 --> Helper loaded: form_helper
INFO - 2018-07-16 23:50:41 --> Helper loaded: date_helper
INFO - 2018-07-16 23:50:41 --> Helper loaded: util_helper
INFO - 2018-07-16 23:50:41 --> Helper loaded: text_helper
INFO - 2018-07-16 23:50:41 --> Helper loaded: string_helper
INFO - 2018-07-16 23:50:41 --> Database Driver Class Initialized
DEBUG - 2018-07-16 23:50:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 23:50:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 23:50:41 --> Email Class Initialized
INFO - 2018-07-16 23:50:41 --> Controller Class Initialized
DEBUG - 2018-07-16 23:50:41 --> Login MX_Controller Initialized
INFO - 2018-07-16 23:50:41 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 23:50:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 23:50:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-16 23:50:41 --> Email starts for gopipanguluri@gmail.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-07-16 23:50:41 --> Login status gopipanguluri@gmail.com - failure
INFO - 2018-07-16 23:50:41 --> Final output sent to browser
DEBUG - 2018-07-16 23:50:41 --> Total execution time: 0.5638
INFO - 2018-07-16 23:50:47 --> Config Class Initialized
INFO - 2018-07-16 23:50:47 --> Hooks Class Initialized
DEBUG - 2018-07-16 23:50:47 --> UTF-8 Support Enabled
INFO - 2018-07-16 23:50:47 --> Utf8 Class Initialized
INFO - 2018-07-16 23:50:47 --> URI Class Initialized
INFO - 2018-07-16 23:50:47 --> Router Class Initialized
INFO - 2018-07-16 23:50:47 --> Output Class Initialized
INFO - 2018-07-16 23:50:47 --> Security Class Initialized
DEBUG - 2018-07-16 23:50:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 23:50:47 --> Input Class Initialized
INFO - 2018-07-16 23:50:47 --> Language Class Initialized
INFO - 2018-07-16 23:50:47 --> Language Class Initialized
INFO - 2018-07-16 23:50:47 --> Config Class Initialized
INFO - 2018-07-16 23:50:47 --> Loader Class Initialized
DEBUG - 2018-07-16 23:50:47 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 23:50:47 --> Helper loaded: url_helper
INFO - 2018-07-16 23:50:47 --> Helper loaded: form_helper
INFO - 2018-07-16 23:50:47 --> Helper loaded: date_helper
INFO - 2018-07-16 23:50:47 --> Helper loaded: util_helper
INFO - 2018-07-16 23:50:47 --> Helper loaded: text_helper
INFO - 2018-07-16 23:50:47 --> Helper loaded: string_helper
INFO - 2018-07-16 23:50:47 --> Database Driver Class Initialized
DEBUG - 2018-07-16 23:50:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 23:50:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 23:50:47 --> Email Class Initialized
INFO - 2018-07-16 23:50:47 --> Controller Class Initialized
DEBUG - 2018-07-16 23:50:47 --> Login MX_Controller Initialized
INFO - 2018-07-16 23:50:47 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 23:50:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 23:50:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-16 23:50:47 --> Email starts for admin@colin.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-07-16 23:50:47 --> User session created for 1
INFO - 2018-07-16 23:50:47 --> Login status admin@colin.com - success
INFO - 2018-07-16 23:50:47 --> Final output sent to browser
DEBUG - 2018-07-16 23:50:47 --> Total execution time: 0.5248
INFO - 2018-07-16 23:50:47 --> Config Class Initialized
INFO - 2018-07-16 23:50:47 --> Hooks Class Initialized
DEBUG - 2018-07-16 23:50:47 --> UTF-8 Support Enabled
INFO - 2018-07-16 23:50:47 --> Utf8 Class Initialized
INFO - 2018-07-16 23:50:47 --> URI Class Initialized
INFO - 2018-07-16 23:50:47 --> Router Class Initialized
INFO - 2018-07-16 23:50:47 --> Output Class Initialized
INFO - 2018-07-16 23:50:47 --> Security Class Initialized
DEBUG - 2018-07-16 23:50:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 23:50:47 --> Input Class Initialized
INFO - 2018-07-16 23:50:47 --> Language Class Initialized
INFO - 2018-07-16 23:50:47 --> Language Class Initialized
INFO - 2018-07-16 23:50:47 --> Config Class Initialized
INFO - 2018-07-16 23:50:47 --> Loader Class Initialized
DEBUG - 2018-07-16 23:50:48 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 23:50:48 --> Helper loaded: url_helper
INFO - 2018-07-16 23:50:48 --> Helper loaded: form_helper
INFO - 2018-07-16 23:50:48 --> Helper loaded: date_helper
INFO - 2018-07-16 23:50:48 --> Helper loaded: util_helper
INFO - 2018-07-16 23:50:48 --> Helper loaded: text_helper
INFO - 2018-07-16 23:50:48 --> Helper loaded: string_helper
INFO - 2018-07-16 23:50:48 --> Database Driver Class Initialized
DEBUG - 2018-07-16 23:50:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 23:50:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 23:50:48 --> Email Class Initialized
INFO - 2018-07-16 23:50:48 --> Controller Class Initialized
DEBUG - 2018-07-16 23:50:48 --> Admin MX_Controller Initialized
INFO - 2018-07-16 23:50:48 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 23:50:48 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-16 23:50:48 --> Login MX_Controller Initialized
DEBUG - 2018-07-16 23:50:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 23:50:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-16 23:50:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-16 23:50:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-16 23:50:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-16 23:50:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-16 23:50:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-16 23:50:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/dashboard.php
INFO - 2018-07-16 23:50:48 --> Final output sent to browser
DEBUG - 2018-07-16 23:50:48 --> Total execution time: 0.6114
INFO - 2018-07-16 23:50:48 --> Config Class Initialized
INFO - 2018-07-16 23:50:48 --> Hooks Class Initialized
DEBUG - 2018-07-16 23:50:48 --> UTF-8 Support Enabled
INFO - 2018-07-16 23:50:48 --> Utf8 Class Initialized
INFO - 2018-07-16 23:50:48 --> URI Class Initialized
INFO - 2018-07-16 23:50:48 --> Router Class Initialized
INFO - 2018-07-16 23:50:48 --> Output Class Initialized
INFO - 2018-07-16 23:50:48 --> Security Class Initialized
DEBUG - 2018-07-16 23:50:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 23:50:49 --> Input Class Initialized
INFO - 2018-07-16 23:50:49 --> Config Class Initialized
INFO - 2018-07-16 23:50:49 --> Hooks Class Initialized
INFO - 2018-07-16 23:50:49 --> Language Class Initialized
DEBUG - 2018-07-16 23:50:49 --> UTF-8 Support Enabled
ERROR - 2018-07-16 23:50:49 --> 404 Page Not Found: /index
INFO - 2018-07-16 23:50:49 --> Utf8 Class Initialized
INFO - 2018-07-16 23:50:49 --> URI Class Initialized
INFO - 2018-07-16 23:50:49 --> Router Class Initialized
INFO - 2018-07-16 23:50:49 --> Output Class Initialized
INFO - 2018-07-16 23:50:49 --> Security Class Initialized
DEBUG - 2018-07-16 23:50:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 23:50:49 --> Input Class Initialized
INFO - 2018-07-16 23:50:49 --> Language Class Initialized
ERROR - 2018-07-16 23:50:49 --> 404 Page Not Found: /index
INFO - 2018-07-16 23:50:52 --> Config Class Initialized
INFO - 2018-07-16 23:50:52 --> Hooks Class Initialized
DEBUG - 2018-07-16 23:50:52 --> UTF-8 Support Enabled
INFO - 2018-07-16 23:50:52 --> Utf8 Class Initialized
INFO - 2018-07-16 23:50:52 --> URI Class Initialized
INFO - 2018-07-16 23:50:52 --> Router Class Initialized
INFO - 2018-07-16 23:50:52 --> Output Class Initialized
INFO - 2018-07-16 23:50:52 --> Security Class Initialized
DEBUG - 2018-07-16 23:50:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 23:50:52 --> Input Class Initialized
INFO - 2018-07-16 23:50:52 --> Language Class Initialized
INFO - 2018-07-16 23:50:52 --> Language Class Initialized
INFO - 2018-07-16 23:50:53 --> Config Class Initialized
INFO - 2018-07-16 23:50:53 --> Loader Class Initialized
DEBUG - 2018-07-16 23:50:53 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 23:50:53 --> Helper loaded: url_helper
INFO - 2018-07-16 23:50:53 --> Helper loaded: form_helper
INFO - 2018-07-16 23:50:53 --> Helper loaded: date_helper
INFO - 2018-07-16 23:50:53 --> Helper loaded: util_helper
INFO - 2018-07-16 23:50:53 --> Helper loaded: text_helper
INFO - 2018-07-16 23:50:53 --> Helper loaded: string_helper
INFO - 2018-07-16 23:50:53 --> Database Driver Class Initialized
DEBUG - 2018-07-16 23:50:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 23:50:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 23:50:53 --> Email Class Initialized
INFO - 2018-07-16 23:50:53 --> Controller Class Initialized
DEBUG - 2018-07-16 23:50:53 --> Login MX_Controller Initialized
INFO - 2018-07-16 23:50:53 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 23:50:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 23:50:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-16 23:50:53 --> 1 Loggedout
INFO - 2018-07-16 23:50:53 --> Config Class Initialized
INFO - 2018-07-16 23:50:53 --> Hooks Class Initialized
DEBUG - 2018-07-16 23:50:53 --> UTF-8 Support Enabled
INFO - 2018-07-16 23:50:53 --> Utf8 Class Initialized
INFO - 2018-07-16 23:50:53 --> URI Class Initialized
INFO - 2018-07-16 23:50:53 --> Router Class Initialized
INFO - 2018-07-16 23:50:53 --> Output Class Initialized
INFO - 2018-07-16 23:50:53 --> Security Class Initialized
DEBUG - 2018-07-16 23:50:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 23:50:53 --> Input Class Initialized
INFO - 2018-07-16 23:50:53 --> Language Class Initialized
INFO - 2018-07-16 23:50:53 --> Language Class Initialized
INFO - 2018-07-16 23:50:53 --> Config Class Initialized
INFO - 2018-07-16 23:50:53 --> Loader Class Initialized
DEBUG - 2018-07-16 23:50:53 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 23:50:53 --> Helper loaded: url_helper
INFO - 2018-07-16 23:50:53 --> Helper loaded: form_helper
INFO - 2018-07-16 23:50:53 --> Helper loaded: date_helper
INFO - 2018-07-16 23:50:53 --> Helper loaded: util_helper
INFO - 2018-07-16 23:50:53 --> Helper loaded: text_helper
INFO - 2018-07-16 23:50:53 --> Helper loaded: string_helper
INFO - 2018-07-16 23:50:53 --> Database Driver Class Initialized
DEBUG - 2018-07-16 23:50:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 23:50:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 23:50:53 --> Email Class Initialized
INFO - 2018-07-16 23:50:53 --> Controller Class Initialized
DEBUG - 2018-07-16 23:50:53 --> Admin MX_Controller Initialized
INFO - 2018-07-16 23:50:53 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 23:50:53 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-16 23:50:53 --> Login MX_Controller Initialized
DEBUG - 2018-07-16 23:50:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 23:50:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-16 23:50:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
INFO - 2018-07-16 23:50:53 --> Config Class Initialized
INFO - 2018-07-16 23:50:53 --> Hooks Class Initialized
DEBUG - 2018-07-16 23:50:54 --> UTF-8 Support Enabled
INFO - 2018-07-16 23:50:54 --> Utf8 Class Initialized
INFO - 2018-07-16 23:50:54 --> URI Class Initialized
INFO - 2018-07-16 23:50:54 --> Router Class Initialized
INFO - 2018-07-16 23:50:54 --> Output Class Initialized
INFO - 2018-07-16 23:50:54 --> Security Class Initialized
DEBUG - 2018-07-16 23:50:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 23:50:54 --> Input Class Initialized
INFO - 2018-07-16 23:50:54 --> Language Class Initialized
ERROR - 2018-07-16 23:50:54 --> 404 Page Not Found: /index
INFO - 2018-07-16 23:50:55 --> Config Class Initialized
INFO - 2018-07-16 23:50:55 --> Hooks Class Initialized
DEBUG - 2018-07-16 23:50:55 --> UTF-8 Support Enabled
INFO - 2018-07-16 23:50:55 --> Utf8 Class Initialized
INFO - 2018-07-16 23:50:55 --> URI Class Initialized
DEBUG - 2018-07-16 23:50:55 --> No URI present. Default controller set.
INFO - 2018-07-16 23:50:55 --> Router Class Initialized
INFO - 2018-07-16 23:50:55 --> Output Class Initialized
INFO - 2018-07-16 23:50:55 --> Security Class Initialized
DEBUG - 2018-07-16 23:50:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 23:50:55 --> Input Class Initialized
INFO - 2018-07-16 23:50:55 --> Language Class Initialized
INFO - 2018-07-16 23:50:56 --> Language Class Initialized
INFO - 2018-07-16 23:50:56 --> Config Class Initialized
INFO - 2018-07-16 23:50:56 --> Loader Class Initialized
DEBUG - 2018-07-16 23:50:56 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 23:50:56 --> Helper loaded: url_helper
INFO - 2018-07-16 23:50:56 --> Helper loaded: form_helper
INFO - 2018-07-16 23:50:56 --> Helper loaded: date_helper
INFO - 2018-07-16 23:50:56 --> Helper loaded: util_helper
INFO - 2018-07-16 23:50:56 --> Helper loaded: text_helper
INFO - 2018-07-16 23:50:56 --> Helper loaded: string_helper
INFO - 2018-07-16 23:50:56 --> Database Driver Class Initialized
DEBUG - 2018-07-16 23:50:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 23:50:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 23:50:56 --> Email Class Initialized
INFO - 2018-07-16 23:50:56 --> Controller Class Initialized
DEBUG - 2018-07-16 23:50:56 --> Home MX_Controller Initialized
DEBUG - 2018-07-16 23:50:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-16 23:50:56 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-16 23:50:56 --> Login MX_Controller Initialized
INFO - 2018-07-16 23:50:56 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 23:50:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 23:50:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-16 23:50:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-16 23:50:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-16 23:50:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-16 23:50:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-16 23:50:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-16 23:50:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-16 23:50:56 --> Final output sent to browser
DEBUG - 2018-07-16 23:50:56 --> Total execution time: 0.6308
INFO - 2018-07-16 23:50:56 --> Config Class Initialized
INFO - 2018-07-16 23:50:56 --> Hooks Class Initialized
DEBUG - 2018-07-16 23:50:56 --> UTF-8 Support Enabled
INFO - 2018-07-16 23:50:56 --> Utf8 Class Initialized
INFO - 2018-07-16 23:50:56 --> URI Class Initialized
INFO - 2018-07-16 23:50:56 --> Router Class Initialized
INFO - 2018-07-16 23:50:56 --> Output Class Initialized
INFO - 2018-07-16 23:50:57 --> Security Class Initialized
DEBUG - 2018-07-16 23:50:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 23:50:57 --> Input Class Initialized
INFO - 2018-07-16 23:50:57 --> Language Class Initialized
ERROR - 2018-07-16 23:50:57 --> 404 Page Not Found: /index
INFO - 2018-07-16 23:50:57 --> Config Class Initialized
INFO - 2018-07-16 23:50:57 --> Hooks Class Initialized
DEBUG - 2018-07-16 23:50:57 --> UTF-8 Support Enabled
INFO - 2018-07-16 23:50:57 --> Utf8 Class Initialized
INFO - 2018-07-16 23:50:57 --> URI Class Initialized
INFO - 2018-07-16 23:50:57 --> Router Class Initialized
INFO - 2018-07-16 23:50:57 --> Output Class Initialized
INFO - 2018-07-16 23:50:57 --> Security Class Initialized
DEBUG - 2018-07-16 23:50:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 23:50:57 --> Input Class Initialized
INFO - 2018-07-16 23:50:57 --> Language Class Initialized
ERROR - 2018-07-16 23:50:57 --> 404 Page Not Found: /index
INFO - 2018-07-16 23:50:57 --> Config Class Initialized
INFO - 2018-07-16 23:50:57 --> Hooks Class Initialized
DEBUG - 2018-07-16 23:50:57 --> UTF-8 Support Enabled
INFO - 2018-07-16 23:50:57 --> Utf8 Class Initialized
INFO - 2018-07-16 23:50:57 --> URI Class Initialized
INFO - 2018-07-16 23:50:57 --> Router Class Initialized
INFO - 2018-07-16 23:50:57 --> Output Class Initialized
INFO - 2018-07-16 23:50:57 --> Security Class Initialized
DEBUG - 2018-07-16 23:50:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 23:50:57 --> Input Class Initialized
INFO - 2018-07-16 23:50:57 --> Language Class Initialized
ERROR - 2018-07-16 23:50:57 --> 404 Page Not Found: /index
INFO - 2018-07-16 23:50:57 --> Config Class Initialized
INFO - 2018-07-16 23:50:57 --> Hooks Class Initialized
DEBUG - 2018-07-16 23:50:58 --> UTF-8 Support Enabled
INFO - 2018-07-16 23:50:58 --> Utf8 Class Initialized
INFO - 2018-07-16 23:50:58 --> URI Class Initialized
INFO - 2018-07-16 23:50:58 --> Router Class Initialized
INFO - 2018-07-16 23:50:58 --> Output Class Initialized
INFO - 2018-07-16 23:50:58 --> Security Class Initialized
DEBUG - 2018-07-16 23:50:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 23:50:58 --> Input Class Initialized
INFO - 2018-07-16 23:50:58 --> Language Class Initialized
ERROR - 2018-07-16 23:50:58 --> 404 Page Not Found: /index
INFO - 2018-07-16 23:50:58 --> Config Class Initialized
INFO - 2018-07-16 23:50:58 --> Config Class Initialized
INFO - 2018-07-16 23:50:58 --> Hooks Class Initialized
INFO - 2018-07-16 23:50:58 --> Hooks Class Initialized
DEBUG - 2018-07-16 23:50:58 --> UTF-8 Support Enabled
DEBUG - 2018-07-16 23:50:58 --> UTF-8 Support Enabled
INFO - 2018-07-16 23:50:58 --> Utf8 Class Initialized
INFO - 2018-07-16 23:50:58 --> Utf8 Class Initialized
INFO - 2018-07-16 23:50:58 --> URI Class Initialized
INFO - 2018-07-16 23:50:58 --> URI Class Initialized
INFO - 2018-07-16 23:50:58 --> Router Class Initialized
INFO - 2018-07-16 23:50:58 --> Router Class Initialized
INFO - 2018-07-16 23:50:58 --> Output Class Initialized
INFO - 2018-07-16 23:50:58 --> Security Class Initialized
INFO - 2018-07-16 23:50:58 --> Output Class Initialized
INFO - 2018-07-16 23:50:58 --> Security Class Initialized
DEBUG - 2018-07-16 23:50:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-07-16 23:50:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 23:50:58 --> Input Class Initialized
INFO - 2018-07-16 23:50:58 --> Input Class Initialized
INFO - 2018-07-16 23:50:58 --> Language Class Initialized
INFO - 2018-07-16 23:50:58 --> Language Class Initialized
ERROR - 2018-07-16 23:50:58 --> 404 Page Not Found: /index
INFO - 2018-07-16 23:50:58 --> Language Class Initialized
INFO - 2018-07-16 23:50:58 --> Config Class Initialized
INFO - 2018-07-16 23:50:58 --> Loader Class Initialized
DEBUG - 2018-07-16 23:50:58 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 23:50:58 --> Helper loaded: url_helper
INFO - 2018-07-16 23:50:58 --> Helper loaded: form_helper
INFO - 2018-07-16 23:50:58 --> Helper loaded: date_helper
INFO - 2018-07-16 23:50:58 --> Helper loaded: util_helper
INFO - 2018-07-16 23:50:58 --> Helper loaded: text_helper
INFO - 2018-07-16 23:50:58 --> Helper loaded: string_helper
INFO - 2018-07-16 23:50:58 --> Database Driver Class Initialized
DEBUG - 2018-07-16 23:50:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 23:50:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 23:50:58 --> Email Class Initialized
INFO - 2018-07-16 23:50:58 --> Controller Class Initialized
DEBUG - 2018-07-16 23:50:58 --> Login MX_Controller Initialized
INFO - 2018-07-16 23:50:58 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 23:50:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 23:50:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-16 23:50:59 --> 4 Loggedout
INFO - 2018-07-16 23:50:59 --> Config Class Initialized
INFO - 2018-07-16 23:50:59 --> Hooks Class Initialized
DEBUG - 2018-07-16 23:50:59 --> UTF-8 Support Enabled
INFO - 2018-07-16 23:50:59 --> Utf8 Class Initialized
INFO - 2018-07-16 23:50:59 --> URI Class Initialized
INFO - 2018-07-16 23:50:59 --> Router Class Initialized
INFO - 2018-07-16 23:50:59 --> Output Class Initialized
INFO - 2018-07-16 23:50:59 --> Security Class Initialized
DEBUG - 2018-07-16 23:50:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 23:50:59 --> Input Class Initialized
INFO - 2018-07-16 23:50:59 --> Language Class Initialized
INFO - 2018-07-16 23:50:59 --> Language Class Initialized
INFO - 2018-07-16 23:50:59 --> Config Class Initialized
INFO - 2018-07-16 23:50:59 --> Loader Class Initialized
DEBUG - 2018-07-16 23:50:59 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 23:50:59 --> Helper loaded: url_helper
INFO - 2018-07-16 23:50:59 --> Helper loaded: form_helper
INFO - 2018-07-16 23:50:59 --> Helper loaded: date_helper
INFO - 2018-07-16 23:50:59 --> Helper loaded: util_helper
INFO - 2018-07-16 23:50:59 --> Helper loaded: text_helper
INFO - 2018-07-16 23:50:59 --> Helper loaded: string_helper
INFO - 2018-07-16 23:50:59 --> Database Driver Class Initialized
DEBUG - 2018-07-16 23:50:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 23:50:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 23:50:59 --> Email Class Initialized
INFO - 2018-07-16 23:50:59 --> Controller Class Initialized
DEBUG - 2018-07-16 23:50:59 --> Home MX_Controller Initialized
DEBUG - 2018-07-16 23:50:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-16 23:50:59 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-16 23:50:59 --> Login MX_Controller Initialized
INFO - 2018-07-16 23:50:59 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 23:50:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 23:50:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-16 23:50:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-07-16 23:51:03 --> Config Class Initialized
INFO - 2018-07-16 23:51:03 --> Hooks Class Initialized
DEBUG - 2018-07-16 23:51:03 --> UTF-8 Support Enabled
INFO - 2018-07-16 23:51:03 --> Utf8 Class Initialized
INFO - 2018-07-16 23:51:03 --> URI Class Initialized
INFO - 2018-07-16 23:51:03 --> Router Class Initialized
INFO - 2018-07-16 23:51:03 --> Output Class Initialized
INFO - 2018-07-16 23:51:03 --> Security Class Initialized
DEBUG - 2018-07-16 23:51:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 23:51:04 --> Input Class Initialized
INFO - 2018-07-16 23:51:04 --> Language Class Initialized
INFO - 2018-07-16 23:51:04 --> Language Class Initialized
INFO - 2018-07-16 23:51:04 --> Config Class Initialized
INFO - 2018-07-16 23:51:04 --> Loader Class Initialized
DEBUG - 2018-07-16 23:51:04 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 23:51:04 --> Helper loaded: url_helper
INFO - 2018-07-16 23:51:04 --> Helper loaded: form_helper
INFO - 2018-07-16 23:51:04 --> Helper loaded: date_helper
INFO - 2018-07-16 23:51:04 --> Helper loaded: util_helper
INFO - 2018-07-16 23:51:04 --> Helper loaded: text_helper
INFO - 2018-07-16 23:51:04 --> Helper loaded: string_helper
INFO - 2018-07-16 23:51:04 --> Database Driver Class Initialized
DEBUG - 2018-07-16 23:51:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 23:51:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 23:51:04 --> Email Class Initialized
INFO - 2018-07-16 23:51:04 --> Controller Class Initialized
DEBUG - 2018-07-16 23:51:04 --> Login MX_Controller Initialized
INFO - 2018-07-16 23:51:04 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 23:51:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 23:51:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-16 23:51:04 --> Email starts for gopipanguluri123@gmail.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-07-16 23:51:04 --> Login status gopipanguluri123@gmail.com - failure
INFO - 2018-07-16 23:51:04 --> Final output sent to browser
DEBUG - 2018-07-16 23:51:04 --> Total execution time: 0.4697
INFO - 2018-07-16 23:51:10 --> Config Class Initialized
INFO - 2018-07-16 23:51:10 --> Hooks Class Initialized
DEBUG - 2018-07-16 23:51:10 --> UTF-8 Support Enabled
INFO - 2018-07-16 23:51:10 --> Utf8 Class Initialized
INFO - 2018-07-16 23:51:10 --> URI Class Initialized
INFO - 2018-07-16 23:51:10 --> Router Class Initialized
INFO - 2018-07-16 23:51:10 --> Output Class Initialized
INFO - 2018-07-16 23:51:10 --> Security Class Initialized
DEBUG - 2018-07-16 23:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 23:51:10 --> Input Class Initialized
INFO - 2018-07-16 23:51:10 --> Language Class Initialized
INFO - 2018-07-16 23:51:10 --> Language Class Initialized
INFO - 2018-07-16 23:51:10 --> Config Class Initialized
INFO - 2018-07-16 23:51:10 --> Loader Class Initialized
DEBUG - 2018-07-16 23:51:10 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 23:51:10 --> Helper loaded: url_helper
INFO - 2018-07-16 23:51:10 --> Helper loaded: form_helper
INFO - 2018-07-16 23:51:10 --> Helper loaded: date_helper
INFO - 2018-07-16 23:51:10 --> Helper loaded: util_helper
INFO - 2018-07-16 23:51:10 --> Helper loaded: text_helper
INFO - 2018-07-16 23:51:10 --> Helper loaded: string_helper
INFO - 2018-07-16 23:51:10 --> Database Driver Class Initialized
DEBUG - 2018-07-16 23:51:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 23:51:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 23:51:10 --> Email Class Initialized
INFO - 2018-07-16 23:51:10 --> Controller Class Initialized
DEBUG - 2018-07-16 23:51:10 --> Login MX_Controller Initialized
INFO - 2018-07-16 23:51:10 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 23:51:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 23:51:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-16 23:51:10 --> Email starts for user@colin.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-07-16 23:51:10 --> Login status user@colin.com - failure
INFO - 2018-07-16 23:51:10 --> Final output sent to browser
DEBUG - 2018-07-16 23:51:10 --> Total execution time: 0.4788
INFO - 2018-07-16 23:51:16 --> Config Class Initialized
INFO - 2018-07-16 23:51:16 --> Hooks Class Initialized
DEBUG - 2018-07-16 23:51:16 --> UTF-8 Support Enabled
INFO - 2018-07-16 23:51:16 --> Utf8 Class Initialized
INFO - 2018-07-16 23:51:16 --> URI Class Initialized
INFO - 2018-07-16 23:51:16 --> Router Class Initialized
INFO - 2018-07-16 23:51:16 --> Output Class Initialized
INFO - 2018-07-16 23:51:16 --> Security Class Initialized
DEBUG - 2018-07-16 23:51:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 23:51:16 --> Input Class Initialized
INFO - 2018-07-16 23:51:16 --> Language Class Initialized
INFO - 2018-07-16 23:51:16 --> Language Class Initialized
INFO - 2018-07-16 23:51:16 --> Config Class Initialized
INFO - 2018-07-16 23:51:16 --> Loader Class Initialized
DEBUG - 2018-07-16 23:51:16 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 23:51:16 --> Helper loaded: url_helper
INFO - 2018-07-16 23:51:16 --> Helper loaded: form_helper
INFO - 2018-07-16 23:51:16 --> Helper loaded: date_helper
INFO - 2018-07-16 23:51:16 --> Helper loaded: util_helper
INFO - 2018-07-16 23:51:16 --> Helper loaded: text_helper
INFO - 2018-07-16 23:51:16 --> Helper loaded: string_helper
INFO - 2018-07-16 23:51:16 --> Database Driver Class Initialized
DEBUG - 2018-07-16 23:51:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 23:51:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 23:51:16 --> Email Class Initialized
INFO - 2018-07-16 23:51:16 --> Controller Class Initialized
DEBUG - 2018-07-16 23:51:16 --> Login MX_Controller Initialized
INFO - 2018-07-16 23:51:16 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 23:51:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 23:51:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-16 23:51:16 --> Email starts for user@colin.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-07-16 23:51:16 --> Login status user@colin.com - failure
INFO - 2018-07-16 23:51:16 --> Final output sent to browser
DEBUG - 2018-07-16 23:51:16 --> Total execution time: 0.5264
INFO - 2018-07-16 23:51:24 --> Config Class Initialized
INFO - 2018-07-16 23:51:24 --> Hooks Class Initialized
DEBUG - 2018-07-16 23:51:24 --> UTF-8 Support Enabled
INFO - 2018-07-16 23:51:24 --> Utf8 Class Initialized
INFO - 2018-07-16 23:51:24 --> URI Class Initialized
INFO - 2018-07-16 23:51:24 --> Router Class Initialized
INFO - 2018-07-16 23:51:24 --> Output Class Initialized
INFO - 2018-07-16 23:51:24 --> Security Class Initialized
DEBUG - 2018-07-16 23:51:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 23:51:24 --> Input Class Initialized
INFO - 2018-07-16 23:51:24 --> Language Class Initialized
INFO - 2018-07-16 23:51:24 --> Language Class Initialized
INFO - 2018-07-16 23:51:24 --> Config Class Initialized
INFO - 2018-07-16 23:51:24 --> Loader Class Initialized
DEBUG - 2018-07-16 23:51:24 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 23:51:24 --> Helper loaded: url_helper
INFO - 2018-07-16 23:51:24 --> Helper loaded: form_helper
INFO - 2018-07-16 23:51:24 --> Helper loaded: date_helper
INFO - 2018-07-16 23:51:24 --> Helper loaded: util_helper
INFO - 2018-07-16 23:51:24 --> Helper loaded: text_helper
INFO - 2018-07-16 23:51:24 --> Helper loaded: string_helper
INFO - 2018-07-16 23:51:25 --> Database Driver Class Initialized
DEBUG - 2018-07-16 23:51:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 23:51:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 23:51:25 --> Email Class Initialized
INFO - 2018-07-16 23:51:25 --> Controller Class Initialized
DEBUG - 2018-07-16 23:51:25 --> Login MX_Controller Initialized
INFO - 2018-07-16 23:51:25 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 23:51:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 23:51:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-16 23:51:25 --> Email starts for user@colin.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-07-16 23:53:29 --> Config Class Initialized
INFO - 2018-07-16 23:53:29 --> Hooks Class Initialized
DEBUG - 2018-07-16 23:53:29 --> UTF-8 Support Enabled
INFO - 2018-07-16 23:53:29 --> Utf8 Class Initialized
INFO - 2018-07-16 23:53:29 --> URI Class Initialized
INFO - 2018-07-16 23:53:29 --> Router Class Initialized
INFO - 2018-07-16 23:53:29 --> Output Class Initialized
INFO - 2018-07-16 23:53:29 --> Security Class Initialized
DEBUG - 2018-07-16 23:53:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 23:53:29 --> Input Class Initialized
INFO - 2018-07-16 23:53:29 --> Language Class Initialized
INFO - 2018-07-16 23:53:29 --> Language Class Initialized
INFO - 2018-07-16 23:53:29 --> Config Class Initialized
INFO - 2018-07-16 23:53:29 --> Loader Class Initialized
DEBUG - 2018-07-16 23:53:29 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 23:53:29 --> Helper loaded: url_helper
INFO - 2018-07-16 23:53:29 --> Helper loaded: form_helper
INFO - 2018-07-16 23:53:29 --> Helper loaded: date_helper
INFO - 2018-07-16 23:53:29 --> Helper loaded: util_helper
INFO - 2018-07-16 23:53:29 --> Helper loaded: text_helper
INFO - 2018-07-16 23:53:29 --> Helper loaded: string_helper
INFO - 2018-07-16 23:53:29 --> Database Driver Class Initialized
DEBUG - 2018-07-16 23:53:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 23:53:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 23:53:30 --> Email Class Initialized
INFO - 2018-07-16 23:53:30 --> Controller Class Initialized
DEBUG - 2018-07-16 23:53:30 --> Login MX_Controller Initialized
INFO - 2018-07-16 23:53:30 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 23:53:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 23:53:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-16 23:53:30 --> Email starts for user@colin.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-07-16 23:53:48 --> Config Class Initialized
INFO - 2018-07-16 23:53:48 --> Hooks Class Initialized
DEBUG - 2018-07-16 23:53:48 --> UTF-8 Support Enabled
INFO - 2018-07-16 23:53:48 --> Utf8 Class Initialized
INFO - 2018-07-16 23:53:48 --> URI Class Initialized
INFO - 2018-07-16 23:53:48 --> Router Class Initialized
INFO - 2018-07-16 23:53:48 --> Output Class Initialized
INFO - 2018-07-16 23:53:49 --> Security Class Initialized
DEBUG - 2018-07-16 23:53:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 23:53:49 --> Input Class Initialized
INFO - 2018-07-16 23:53:49 --> Language Class Initialized
INFO - 2018-07-16 23:53:49 --> Language Class Initialized
INFO - 2018-07-16 23:53:49 --> Config Class Initialized
INFO - 2018-07-16 23:53:49 --> Loader Class Initialized
DEBUG - 2018-07-16 23:53:49 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 23:53:49 --> Helper loaded: url_helper
INFO - 2018-07-16 23:53:49 --> Helper loaded: form_helper
INFO - 2018-07-16 23:53:49 --> Helper loaded: date_helper
INFO - 2018-07-16 23:53:49 --> Helper loaded: util_helper
INFO - 2018-07-16 23:53:49 --> Helper loaded: text_helper
INFO - 2018-07-16 23:53:49 --> Helper loaded: string_helper
INFO - 2018-07-16 23:53:49 --> Database Driver Class Initialized
DEBUG - 2018-07-16 23:53:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 23:53:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 23:53:49 --> Email Class Initialized
INFO - 2018-07-16 23:53:49 --> Controller Class Initialized
DEBUG - 2018-07-16 23:53:49 --> Login MX_Controller Initialized
INFO - 2018-07-16 23:53:49 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 23:53:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 23:53:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-16 23:53:49 --> Email starts for user@colin.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-07-16 23:53:49 --> User session created for 4
INFO - 2018-07-16 23:53:49 --> Login status user@colin.com - success
INFO - 2018-07-16 23:53:49 --> Final output sent to browser
DEBUG - 2018-07-16 23:53:49 --> Total execution time: 0.7000
INFO - 2018-07-16 23:53:49 --> Config Class Initialized
INFO - 2018-07-16 23:53:49 --> Hooks Class Initialized
DEBUG - 2018-07-16 23:53:49 --> UTF-8 Support Enabled
INFO - 2018-07-16 23:53:49 --> Utf8 Class Initialized
INFO - 2018-07-16 23:53:49 --> URI Class Initialized
INFO - 2018-07-16 23:53:49 --> Router Class Initialized
INFO - 2018-07-16 23:53:49 --> Output Class Initialized
INFO - 2018-07-16 23:53:49 --> Security Class Initialized
DEBUG - 2018-07-16 23:53:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 23:53:49 --> Input Class Initialized
INFO - 2018-07-16 23:53:49 --> Language Class Initialized
INFO - 2018-07-16 23:53:49 --> Language Class Initialized
INFO - 2018-07-16 23:53:50 --> Config Class Initialized
INFO - 2018-07-16 23:53:50 --> Loader Class Initialized
DEBUG - 2018-07-16 23:53:50 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 23:53:50 --> Helper loaded: url_helper
INFO - 2018-07-16 23:53:50 --> Helper loaded: form_helper
INFO - 2018-07-16 23:53:50 --> Helper loaded: date_helper
INFO - 2018-07-16 23:53:50 --> Helper loaded: util_helper
INFO - 2018-07-16 23:53:50 --> Helper loaded: text_helper
INFO - 2018-07-16 23:53:50 --> Helper loaded: string_helper
INFO - 2018-07-16 23:53:50 --> Database Driver Class Initialized
DEBUG - 2018-07-16 23:53:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 23:53:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 23:53:50 --> Email Class Initialized
INFO - 2018-07-16 23:53:50 --> Controller Class Initialized
DEBUG - 2018-07-16 23:53:50 --> Home MX_Controller Initialized
DEBUG - 2018-07-16 23:53:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-16 23:53:50 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-16 23:53:50 --> Login MX_Controller Initialized
INFO - 2018-07-16 23:53:50 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 23:53:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 23:53:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-16 23:53:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-16 23:53:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-16 23:53:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-16 23:53:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-16 23:53:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-16 23:53:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-16 23:53:50 --> Final output sent to browser
DEBUG - 2018-07-16 23:53:50 --> Total execution time: 0.8563
INFO - 2018-07-16 23:53:51 --> Config Class Initialized
INFO - 2018-07-16 23:53:51 --> Hooks Class Initialized
DEBUG - 2018-07-16 23:53:51 --> UTF-8 Support Enabled
INFO - 2018-07-16 23:53:51 --> Utf8 Class Initialized
INFO - 2018-07-16 23:53:51 --> URI Class Initialized
INFO - 2018-07-16 23:53:51 --> Router Class Initialized
INFO - 2018-07-16 23:53:51 --> Output Class Initialized
INFO - 2018-07-16 23:53:51 --> Security Class Initialized
DEBUG - 2018-07-16 23:53:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 23:53:51 --> Input Class Initialized
INFO - 2018-07-16 23:53:51 --> Language Class Initialized
ERROR - 2018-07-16 23:53:51 --> 404 Page Not Found: /index
INFO - 2018-07-16 23:53:51 --> Config Class Initialized
INFO - 2018-07-16 23:53:51 --> Hooks Class Initialized
DEBUG - 2018-07-16 23:53:51 --> UTF-8 Support Enabled
INFO - 2018-07-16 23:53:51 --> Utf8 Class Initialized
INFO - 2018-07-16 23:53:51 --> URI Class Initialized
INFO - 2018-07-16 23:53:51 --> Router Class Initialized
INFO - 2018-07-16 23:53:51 --> Output Class Initialized
INFO - 2018-07-16 23:53:51 --> Security Class Initialized
DEBUG - 2018-07-16 23:53:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 23:53:51 --> Input Class Initialized
INFO - 2018-07-16 23:53:51 --> Language Class Initialized
ERROR - 2018-07-16 23:53:51 --> 404 Page Not Found: /index
INFO - 2018-07-16 23:53:51 --> Config Class Initialized
INFO - 2018-07-16 23:53:51 --> Hooks Class Initialized
DEBUG - 2018-07-16 23:53:51 --> UTF-8 Support Enabled
INFO - 2018-07-16 23:53:51 --> Utf8 Class Initialized
INFO - 2018-07-16 23:53:51 --> URI Class Initialized
INFO - 2018-07-16 23:53:51 --> Router Class Initialized
INFO - 2018-07-16 23:53:51 --> Output Class Initialized
INFO - 2018-07-16 23:53:51 --> Security Class Initialized
DEBUG - 2018-07-16 23:53:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 23:53:51 --> Input Class Initialized
INFO - 2018-07-16 23:53:51 --> Language Class Initialized
ERROR - 2018-07-16 23:53:51 --> 404 Page Not Found: /index
INFO - 2018-07-16 23:53:55 --> Config Class Initialized
INFO - 2018-07-16 23:53:55 --> Hooks Class Initialized
DEBUG - 2018-07-16 23:53:55 --> UTF-8 Support Enabled
INFO - 2018-07-16 23:53:55 --> Utf8 Class Initialized
INFO - 2018-07-16 23:53:55 --> URI Class Initialized
INFO - 2018-07-16 23:53:55 --> Router Class Initialized
INFO - 2018-07-16 23:53:55 --> Output Class Initialized
INFO - 2018-07-16 23:53:55 --> Security Class Initialized
DEBUG - 2018-07-16 23:53:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 23:53:55 --> Input Class Initialized
INFO - 2018-07-16 23:53:55 --> Language Class Initialized
INFO - 2018-07-16 23:53:55 --> Language Class Initialized
INFO - 2018-07-16 23:53:55 --> Config Class Initialized
INFO - 2018-07-16 23:53:55 --> Loader Class Initialized
DEBUG - 2018-07-16 23:53:55 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 23:53:55 --> Helper loaded: url_helper
INFO - 2018-07-16 23:53:55 --> Helper loaded: form_helper
INFO - 2018-07-16 23:53:55 --> Helper loaded: date_helper
INFO - 2018-07-16 23:53:55 --> Helper loaded: util_helper
INFO - 2018-07-16 23:53:55 --> Helper loaded: text_helper
INFO - 2018-07-16 23:53:55 --> Helper loaded: string_helper
INFO - 2018-07-16 23:53:55 --> Database Driver Class Initialized
DEBUG - 2018-07-16 23:53:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 23:53:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 23:53:55 --> Email Class Initialized
INFO - 2018-07-16 23:53:55 --> Controller Class Initialized
DEBUG - 2018-07-16 23:53:55 --> Login MX_Controller Initialized
INFO - 2018-07-16 23:53:55 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 23:53:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 23:53:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-16 23:53:56 --> 4 Loggedout
INFO - 2018-07-16 23:53:56 --> Config Class Initialized
INFO - 2018-07-16 23:53:56 --> Hooks Class Initialized
DEBUG - 2018-07-16 23:53:56 --> UTF-8 Support Enabled
INFO - 2018-07-16 23:53:56 --> Utf8 Class Initialized
INFO - 2018-07-16 23:53:56 --> URI Class Initialized
INFO - 2018-07-16 23:53:56 --> Router Class Initialized
INFO - 2018-07-16 23:53:56 --> Output Class Initialized
INFO - 2018-07-16 23:53:56 --> Security Class Initialized
DEBUG - 2018-07-16 23:53:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 23:53:56 --> Input Class Initialized
INFO - 2018-07-16 23:53:56 --> Language Class Initialized
INFO - 2018-07-16 23:53:56 --> Language Class Initialized
INFO - 2018-07-16 23:53:56 --> Config Class Initialized
INFO - 2018-07-16 23:53:56 --> Loader Class Initialized
DEBUG - 2018-07-16 23:53:56 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 23:53:56 --> Helper loaded: url_helper
INFO - 2018-07-16 23:53:56 --> Helper loaded: form_helper
INFO - 2018-07-16 23:53:56 --> Helper loaded: date_helper
INFO - 2018-07-16 23:53:56 --> Helper loaded: util_helper
INFO - 2018-07-16 23:53:56 --> Helper loaded: text_helper
INFO - 2018-07-16 23:53:56 --> Helper loaded: string_helper
INFO - 2018-07-16 23:53:56 --> Database Driver Class Initialized
DEBUG - 2018-07-16 23:53:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 23:53:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 23:53:56 --> Email Class Initialized
INFO - 2018-07-16 23:53:56 --> Controller Class Initialized
DEBUG - 2018-07-16 23:53:56 --> Home MX_Controller Initialized
DEBUG - 2018-07-16 23:53:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-16 23:53:56 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-16 23:53:56 --> Login MX_Controller Initialized
INFO - 2018-07-16 23:53:56 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 23:53:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 23:53:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-16 23:53:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-07-16 23:53:59 --> Config Class Initialized
INFO - 2018-07-16 23:53:59 --> Hooks Class Initialized
DEBUG - 2018-07-16 23:53:59 --> UTF-8 Support Enabled
INFO - 2018-07-16 23:53:59 --> Utf8 Class Initialized
INFO - 2018-07-16 23:53:59 --> URI Class Initialized
INFO - 2018-07-16 23:53:59 --> Router Class Initialized
INFO - 2018-07-16 23:53:59 --> Output Class Initialized
INFO - 2018-07-16 23:53:59 --> Security Class Initialized
DEBUG - 2018-07-16 23:53:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 23:53:59 --> Input Class Initialized
INFO - 2018-07-16 23:53:59 --> Language Class Initialized
INFO - 2018-07-16 23:53:59 --> Language Class Initialized
INFO - 2018-07-16 23:53:59 --> Config Class Initialized
INFO - 2018-07-16 23:53:59 --> Loader Class Initialized
DEBUG - 2018-07-16 23:53:59 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 23:53:59 --> Helper loaded: url_helper
INFO - 2018-07-16 23:53:59 --> Helper loaded: form_helper
INFO - 2018-07-16 23:53:59 --> Helper loaded: date_helper
INFO - 2018-07-16 23:53:59 --> Helper loaded: util_helper
INFO - 2018-07-16 23:53:59 --> Helper loaded: text_helper
INFO - 2018-07-16 23:53:59 --> Helper loaded: string_helper
INFO - 2018-07-16 23:53:59 --> Database Driver Class Initialized
DEBUG - 2018-07-16 23:53:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 23:53:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 23:53:59 --> Email Class Initialized
INFO - 2018-07-16 23:53:59 --> Controller Class Initialized
DEBUG - 2018-07-16 23:53:59 --> Login MX_Controller Initialized
INFO - 2018-07-16 23:53:59 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 23:53:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 23:53:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-16 23:53:59 --> Email starts for gopipanguluri123@gmail.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-07-16 23:53:59 --> Login status gopipanguluri123@gmail.com - failure
INFO - 2018-07-16 23:53:59 --> Final output sent to browser
DEBUG - 2018-07-16 23:53:59 --> Total execution time: 0.4773
INFO - 2018-07-16 23:54:05 --> Config Class Initialized
INFO - 2018-07-16 23:54:05 --> Hooks Class Initialized
DEBUG - 2018-07-16 23:54:05 --> UTF-8 Support Enabled
INFO - 2018-07-16 23:54:05 --> Utf8 Class Initialized
INFO - 2018-07-16 23:54:05 --> URI Class Initialized
INFO - 2018-07-16 23:54:05 --> Router Class Initialized
INFO - 2018-07-16 23:54:05 --> Output Class Initialized
INFO - 2018-07-16 23:54:05 --> Security Class Initialized
DEBUG - 2018-07-16 23:54:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 23:54:05 --> Input Class Initialized
INFO - 2018-07-16 23:54:05 --> Language Class Initialized
INFO - 2018-07-16 23:54:05 --> Language Class Initialized
INFO - 2018-07-16 23:54:05 --> Config Class Initialized
INFO - 2018-07-16 23:54:05 --> Loader Class Initialized
DEBUG - 2018-07-16 23:54:05 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 23:54:05 --> Helper loaded: url_helper
INFO - 2018-07-16 23:54:05 --> Helper loaded: form_helper
INFO - 2018-07-16 23:54:05 --> Helper loaded: date_helper
INFO - 2018-07-16 23:54:05 --> Helper loaded: util_helper
INFO - 2018-07-16 23:54:05 --> Helper loaded: text_helper
INFO - 2018-07-16 23:54:05 --> Helper loaded: string_helper
INFO - 2018-07-16 23:54:05 --> Database Driver Class Initialized
DEBUG - 2018-07-16 23:54:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 23:54:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 23:54:06 --> Email Class Initialized
INFO - 2018-07-16 23:54:06 --> Controller Class Initialized
DEBUG - 2018-07-16 23:54:06 --> Login MX_Controller Initialized
INFO - 2018-07-16 23:54:06 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 23:54:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 23:54:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-16 23:54:06 --> Email starts for admin@colin.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-07-16 23:54:06 --> User session created for 1
INFO - 2018-07-16 23:54:06 --> Login status admin@colin.com - success
INFO - 2018-07-16 23:54:06 --> Final output sent to browser
DEBUG - 2018-07-16 23:54:06 --> Total execution time: 0.5506
INFO - 2018-07-16 23:54:06 --> Config Class Initialized
INFO - 2018-07-16 23:54:06 --> Hooks Class Initialized
DEBUG - 2018-07-16 23:54:06 --> UTF-8 Support Enabled
INFO - 2018-07-16 23:54:06 --> Utf8 Class Initialized
INFO - 2018-07-16 23:54:06 --> URI Class Initialized
INFO - 2018-07-16 23:54:06 --> Router Class Initialized
INFO - 2018-07-16 23:54:06 --> Output Class Initialized
INFO - 2018-07-16 23:54:06 --> Security Class Initialized
DEBUG - 2018-07-16 23:54:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 23:54:06 --> Input Class Initialized
INFO - 2018-07-16 23:54:06 --> Language Class Initialized
INFO - 2018-07-16 23:54:06 --> Language Class Initialized
INFO - 2018-07-16 23:54:06 --> Config Class Initialized
INFO - 2018-07-16 23:54:06 --> Loader Class Initialized
DEBUG - 2018-07-16 23:54:06 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 23:54:06 --> Helper loaded: url_helper
INFO - 2018-07-16 23:54:06 --> Helper loaded: form_helper
INFO - 2018-07-16 23:54:06 --> Helper loaded: date_helper
INFO - 2018-07-16 23:54:06 --> Helper loaded: util_helper
INFO - 2018-07-16 23:54:06 --> Helper loaded: text_helper
INFO - 2018-07-16 23:54:06 --> Helper loaded: string_helper
INFO - 2018-07-16 23:54:06 --> Database Driver Class Initialized
DEBUG - 2018-07-16 23:54:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 23:54:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 23:54:06 --> Email Class Initialized
INFO - 2018-07-16 23:54:06 --> Controller Class Initialized
DEBUG - 2018-07-16 23:54:06 --> Admin MX_Controller Initialized
INFO - 2018-07-16 23:54:06 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 23:54:06 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-16 23:54:06 --> Login MX_Controller Initialized
DEBUG - 2018-07-16 23:54:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 23:54:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-16 23:54:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-16 23:54:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-16 23:54:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-16 23:54:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-16 23:54:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-16 23:54:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/dashboard.php
INFO - 2018-07-16 23:54:06 --> Final output sent to browser
DEBUG - 2018-07-16 23:54:06 --> Total execution time: 0.6291
INFO - 2018-07-16 23:54:06 --> Config Class Initialized
INFO - 2018-07-16 23:54:07 --> Hooks Class Initialized
DEBUG - 2018-07-16 23:54:07 --> UTF-8 Support Enabled
INFO - 2018-07-16 23:54:07 --> Utf8 Class Initialized
INFO - 2018-07-16 23:54:07 --> URI Class Initialized
INFO - 2018-07-16 23:54:07 --> Router Class Initialized
INFO - 2018-07-16 23:54:07 --> Output Class Initialized
INFO - 2018-07-16 23:54:07 --> Security Class Initialized
INFO - 2018-07-16 23:54:07 --> Config Class Initialized
INFO - 2018-07-16 23:54:07 --> Hooks Class Initialized
DEBUG - 2018-07-16 23:54:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 23:54:07 --> Input Class Initialized
DEBUG - 2018-07-16 23:54:07 --> UTF-8 Support Enabled
INFO - 2018-07-16 23:54:07 --> Utf8 Class Initialized
INFO - 2018-07-16 23:54:07 --> Language Class Initialized
INFO - 2018-07-16 23:54:07 --> URI Class Initialized
ERROR - 2018-07-16 23:54:07 --> 404 Page Not Found: /index
INFO - 2018-07-16 23:54:07 --> Router Class Initialized
INFO - 2018-07-16 23:54:07 --> Output Class Initialized
INFO - 2018-07-16 23:54:07 --> Security Class Initialized
DEBUG - 2018-07-16 23:54:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 23:54:07 --> Input Class Initialized
INFO - 2018-07-16 23:54:07 --> Language Class Initialized
ERROR - 2018-07-16 23:54:07 --> 404 Page Not Found: /index
INFO - 2018-07-16 23:54:10 --> Config Class Initialized
INFO - 2018-07-16 23:54:10 --> Hooks Class Initialized
DEBUG - 2018-07-16 23:54:10 --> UTF-8 Support Enabled
INFO - 2018-07-16 23:54:10 --> Utf8 Class Initialized
INFO - 2018-07-16 23:54:10 --> URI Class Initialized
INFO - 2018-07-16 23:54:10 --> Router Class Initialized
INFO - 2018-07-16 23:54:10 --> Output Class Initialized
INFO - 2018-07-16 23:54:10 --> Security Class Initialized
DEBUG - 2018-07-16 23:54:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 23:54:11 --> Input Class Initialized
INFO - 2018-07-16 23:54:11 --> Language Class Initialized
INFO - 2018-07-16 23:54:11 --> Language Class Initialized
INFO - 2018-07-16 23:54:11 --> Config Class Initialized
INFO - 2018-07-16 23:54:11 --> Loader Class Initialized
DEBUG - 2018-07-16 23:54:11 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 23:54:11 --> Helper loaded: url_helper
INFO - 2018-07-16 23:54:11 --> Helper loaded: form_helper
INFO - 2018-07-16 23:54:11 --> Helper loaded: date_helper
INFO - 2018-07-16 23:54:11 --> Helper loaded: util_helper
INFO - 2018-07-16 23:54:11 --> Helper loaded: text_helper
INFO - 2018-07-16 23:54:11 --> Helper loaded: string_helper
INFO - 2018-07-16 23:54:11 --> Database Driver Class Initialized
DEBUG - 2018-07-16 23:54:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 23:54:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 23:54:11 --> Email Class Initialized
INFO - 2018-07-16 23:54:11 --> Controller Class Initialized
DEBUG - 2018-07-16 23:54:11 --> Login MX_Controller Initialized
INFO - 2018-07-16 23:54:11 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 23:54:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 23:54:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-16 23:54:11 --> 1 Loggedout
INFO - 2018-07-16 23:54:11 --> Config Class Initialized
INFO - 2018-07-16 23:54:11 --> Hooks Class Initialized
DEBUG - 2018-07-16 23:54:11 --> UTF-8 Support Enabled
INFO - 2018-07-16 23:54:11 --> Utf8 Class Initialized
INFO - 2018-07-16 23:54:11 --> URI Class Initialized
INFO - 2018-07-16 23:54:11 --> Router Class Initialized
INFO - 2018-07-16 23:54:11 --> Output Class Initialized
INFO - 2018-07-16 23:54:11 --> Security Class Initialized
DEBUG - 2018-07-16 23:54:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 23:54:11 --> Input Class Initialized
INFO - 2018-07-16 23:54:11 --> Language Class Initialized
INFO - 2018-07-16 23:54:11 --> Language Class Initialized
INFO - 2018-07-16 23:54:12 --> Config Class Initialized
INFO - 2018-07-16 23:54:12 --> Loader Class Initialized
DEBUG - 2018-07-16 23:54:12 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 23:54:12 --> Helper loaded: url_helper
INFO - 2018-07-16 23:54:12 --> Helper loaded: form_helper
INFO - 2018-07-16 23:54:12 --> Helper loaded: date_helper
INFO - 2018-07-16 23:54:12 --> Helper loaded: util_helper
INFO - 2018-07-16 23:54:12 --> Helper loaded: text_helper
INFO - 2018-07-16 23:54:12 --> Helper loaded: string_helper
INFO - 2018-07-16 23:54:12 --> Database Driver Class Initialized
DEBUG - 2018-07-16 23:54:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 23:54:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 23:54:12 --> Email Class Initialized
INFO - 2018-07-16 23:54:12 --> Controller Class Initialized
DEBUG - 2018-07-16 23:54:12 --> Admin MX_Controller Initialized
INFO - 2018-07-16 23:54:12 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 23:54:12 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-16 23:54:12 --> Login MX_Controller Initialized
DEBUG - 2018-07-16 23:54:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 23:54:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-16 23:54:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
INFO - 2018-07-16 23:54:12 --> Config Class Initialized
INFO - 2018-07-16 23:54:12 --> Hooks Class Initialized
DEBUG - 2018-07-16 23:54:12 --> UTF-8 Support Enabled
INFO - 2018-07-16 23:54:12 --> Utf8 Class Initialized
INFO - 2018-07-16 23:54:12 --> URI Class Initialized
INFO - 2018-07-16 23:54:12 --> Router Class Initialized
INFO - 2018-07-16 23:54:12 --> Output Class Initialized
INFO - 2018-07-16 23:54:12 --> Security Class Initialized
DEBUG - 2018-07-16 23:54:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 23:54:12 --> Input Class Initialized
INFO - 2018-07-16 23:54:12 --> Language Class Initialized
ERROR - 2018-07-16 23:54:12 --> 404 Page Not Found: /index
INFO - 2018-07-16 23:54:15 --> Config Class Initialized
INFO - 2018-07-16 23:54:15 --> Hooks Class Initialized
DEBUG - 2018-07-16 23:54:15 --> UTF-8 Support Enabled
INFO - 2018-07-16 23:54:15 --> Utf8 Class Initialized
INFO - 2018-07-16 23:54:15 --> URI Class Initialized
INFO - 2018-07-16 23:54:15 --> Router Class Initialized
INFO - 2018-07-16 23:54:15 --> Output Class Initialized
INFO - 2018-07-16 23:54:15 --> Security Class Initialized
DEBUG - 2018-07-16 23:54:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 23:54:15 --> Input Class Initialized
INFO - 2018-07-16 23:54:15 --> Language Class Initialized
INFO - 2018-07-16 23:54:15 --> Language Class Initialized
INFO - 2018-07-16 23:54:15 --> Config Class Initialized
INFO - 2018-07-16 23:54:15 --> Loader Class Initialized
DEBUG - 2018-07-16 23:54:15 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 23:54:15 --> Helper loaded: url_helper
INFO - 2018-07-16 23:54:15 --> Helper loaded: form_helper
INFO - 2018-07-16 23:54:15 --> Helper loaded: date_helper
INFO - 2018-07-16 23:54:15 --> Helper loaded: util_helper
INFO - 2018-07-16 23:54:15 --> Helper loaded: text_helper
INFO - 2018-07-16 23:54:15 --> Helper loaded: string_helper
INFO - 2018-07-16 23:54:15 --> Database Driver Class Initialized
DEBUG - 2018-07-16 23:54:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 23:54:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 23:54:15 --> Email Class Initialized
INFO - 2018-07-16 23:54:15 --> Controller Class Initialized
DEBUG - 2018-07-16 23:54:15 --> Login MX_Controller Initialized
INFO - 2018-07-16 23:54:15 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 23:54:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 23:54:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-16 23:54:15 --> Email starts for gopipanguluri123@gmail.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-07-16 23:54:15 --> Login status gopipanguluri123@gmail.com - failure
INFO - 2018-07-16 23:54:15 --> Final output sent to browser
DEBUG - 2018-07-16 23:54:15 --> Total execution time: 0.5207
INFO - 2018-07-16 23:54:24 --> Config Class Initialized
INFO - 2018-07-16 23:54:24 --> Hooks Class Initialized
DEBUG - 2018-07-16 23:54:25 --> UTF-8 Support Enabled
INFO - 2018-07-16 23:54:25 --> Utf8 Class Initialized
INFO - 2018-07-16 23:54:25 --> URI Class Initialized
INFO - 2018-07-16 23:54:25 --> Router Class Initialized
INFO - 2018-07-16 23:54:25 --> Output Class Initialized
INFO - 2018-07-16 23:54:25 --> Security Class Initialized
DEBUG - 2018-07-16 23:54:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 23:54:25 --> Input Class Initialized
INFO - 2018-07-16 23:54:25 --> Language Class Initialized
INFO - 2018-07-16 23:54:25 --> Language Class Initialized
INFO - 2018-07-16 23:54:25 --> Config Class Initialized
INFO - 2018-07-16 23:54:25 --> Loader Class Initialized
DEBUG - 2018-07-16 23:54:25 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 23:54:25 --> Helper loaded: url_helper
INFO - 2018-07-16 23:54:25 --> Helper loaded: form_helper
INFO - 2018-07-16 23:54:25 --> Helper loaded: date_helper
INFO - 2018-07-16 23:54:25 --> Helper loaded: util_helper
INFO - 2018-07-16 23:54:25 --> Helper loaded: text_helper
INFO - 2018-07-16 23:54:25 --> Helper loaded: string_helper
INFO - 2018-07-16 23:54:25 --> Database Driver Class Initialized
DEBUG - 2018-07-16 23:54:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 23:54:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 23:54:25 --> Email Class Initialized
INFO - 2018-07-16 23:54:25 --> Controller Class Initialized
DEBUG - 2018-07-16 23:54:25 --> Login MX_Controller Initialized
INFO - 2018-07-16 23:54:25 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 23:54:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 23:54:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
ERROR - 2018-07-16 23:54:25 --> Query error: Table 'consulting.product_categories' doesn't exist - Invalid query: SELECT *
FROM `product_categories`
WHERE `parent_id` IN('0')
INFO - 2018-07-16 23:54:25 --> Language file loaded: language/english/db_lang.php
INFO - 2018-07-16 23:54:32 --> Config Class Initialized
INFO - 2018-07-16 23:54:32 --> Hooks Class Initialized
DEBUG - 2018-07-16 23:54:32 --> UTF-8 Support Enabled
INFO - 2018-07-16 23:54:32 --> Utf8 Class Initialized
INFO - 2018-07-16 23:54:32 --> URI Class Initialized
INFO - 2018-07-16 23:54:33 --> Router Class Initialized
INFO - 2018-07-16 23:54:33 --> Output Class Initialized
INFO - 2018-07-16 23:54:33 --> Security Class Initialized
DEBUG - 2018-07-16 23:54:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 23:54:33 --> Input Class Initialized
INFO - 2018-07-16 23:54:33 --> Language Class Initialized
INFO - 2018-07-16 23:54:33 --> Language Class Initialized
INFO - 2018-07-16 23:54:33 --> Config Class Initialized
INFO - 2018-07-16 23:54:33 --> Loader Class Initialized
DEBUG - 2018-07-16 23:54:33 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 23:54:33 --> Helper loaded: url_helper
INFO - 2018-07-16 23:54:33 --> Helper loaded: form_helper
INFO - 2018-07-16 23:54:33 --> Helper loaded: date_helper
INFO - 2018-07-16 23:54:33 --> Helper loaded: util_helper
INFO - 2018-07-16 23:54:33 --> Helper loaded: text_helper
INFO - 2018-07-16 23:54:33 --> Helper loaded: string_helper
INFO - 2018-07-16 23:54:33 --> Database Driver Class Initialized
DEBUG - 2018-07-16 23:54:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 23:54:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 23:54:33 --> Email Class Initialized
INFO - 2018-07-16 23:54:33 --> Controller Class Initialized
DEBUG - 2018-07-16 23:54:33 --> Admin MX_Controller Initialized
INFO - 2018-07-16 23:54:33 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 23:54:33 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-16 23:54:33 --> Login MX_Controller Initialized
DEBUG - 2018-07-16 23:54:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 23:54:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-16 23:54:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
INFO - 2018-07-16 23:54:46 --> Config Class Initialized
INFO - 2018-07-16 23:54:46 --> Hooks Class Initialized
DEBUG - 2018-07-16 23:54:46 --> UTF-8 Support Enabled
INFO - 2018-07-16 23:54:46 --> Utf8 Class Initialized
INFO - 2018-07-16 23:54:46 --> URI Class Initialized
INFO - 2018-07-16 23:54:46 --> Router Class Initialized
INFO - 2018-07-16 23:54:46 --> Output Class Initialized
INFO - 2018-07-16 23:54:46 --> Security Class Initialized
DEBUG - 2018-07-16 23:54:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 23:54:46 --> Input Class Initialized
INFO - 2018-07-16 23:54:46 --> Language Class Initialized
INFO - 2018-07-16 23:54:46 --> Language Class Initialized
INFO - 2018-07-16 23:54:46 --> Config Class Initialized
INFO - 2018-07-16 23:54:46 --> Loader Class Initialized
DEBUG - 2018-07-16 23:54:46 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 23:54:46 --> Helper loaded: url_helper
INFO - 2018-07-16 23:54:46 --> Helper loaded: form_helper
INFO - 2018-07-16 23:54:46 --> Helper loaded: date_helper
INFO - 2018-07-16 23:54:46 --> Helper loaded: util_helper
INFO - 2018-07-16 23:54:46 --> Helper loaded: text_helper
INFO - 2018-07-16 23:54:46 --> Helper loaded: string_helper
INFO - 2018-07-16 23:54:46 --> Database Driver Class Initialized
DEBUG - 2018-07-16 23:54:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 23:54:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 23:54:46 --> Email Class Initialized
INFO - 2018-07-16 23:54:46 --> Controller Class Initialized
DEBUG - 2018-07-16 23:54:46 --> Home MX_Controller Initialized
DEBUG - 2018-07-16 23:54:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-16 23:54:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/register.php
INFO - 2018-07-16 23:54:46 --> Final output sent to browser
DEBUG - 2018-07-16 23:54:46 --> Total execution time: 0.5932
INFO - 2018-07-16 23:54:50 --> Config Class Initialized
INFO - 2018-07-16 23:54:50 --> Hooks Class Initialized
DEBUG - 2018-07-16 23:54:50 --> UTF-8 Support Enabled
INFO - 2018-07-16 23:54:50 --> Utf8 Class Initialized
INFO - 2018-07-16 23:54:50 --> URI Class Initialized
INFO - 2018-07-16 23:54:50 --> Router Class Initialized
INFO - 2018-07-16 23:54:50 --> Output Class Initialized
INFO - 2018-07-16 23:54:50 --> Security Class Initialized
DEBUG - 2018-07-16 23:54:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 23:54:50 --> Input Class Initialized
INFO - 2018-07-16 23:54:50 --> Language Class Initialized
INFO - 2018-07-16 23:54:50 --> Language Class Initialized
INFO - 2018-07-16 23:54:50 --> Config Class Initialized
INFO - 2018-07-16 23:54:50 --> Loader Class Initialized
DEBUG - 2018-07-16 23:54:50 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 23:54:50 --> Helper loaded: url_helper
INFO - 2018-07-16 23:54:50 --> Helper loaded: form_helper
INFO - 2018-07-16 23:54:50 --> Helper loaded: date_helper
INFO - 2018-07-16 23:54:50 --> Helper loaded: util_helper
INFO - 2018-07-16 23:54:50 --> Helper loaded: text_helper
INFO - 2018-07-16 23:54:50 --> Helper loaded: string_helper
INFO - 2018-07-16 23:54:50 --> Database Driver Class Initialized
DEBUG - 2018-07-16 23:54:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 23:54:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 23:54:50 --> Email Class Initialized
INFO - 2018-07-16 23:54:50 --> Controller Class Initialized
DEBUG - 2018-07-16 23:54:50 --> Login MX_Controller Initialized
INFO - 2018-07-16 23:54:50 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 23:54:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 23:54:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
ERROR - 2018-07-16 23:54:50 --> Query error: Table 'consulting.product_categories' doesn't exist - Invalid query: SELECT *
FROM `product_categories`
WHERE `parent_id` IN('0')
INFO - 2018-07-16 23:54:50 --> Language file loaded: language/english/db_lang.php
INFO - 2018-07-16 23:54:53 --> Config Class Initialized
INFO - 2018-07-16 23:54:53 --> Hooks Class Initialized
DEBUG - 2018-07-16 23:54:53 --> UTF-8 Support Enabled
INFO - 2018-07-16 23:54:53 --> Utf8 Class Initialized
INFO - 2018-07-16 23:54:53 --> URI Class Initialized
INFO - 2018-07-16 23:54:53 --> Router Class Initialized
INFO - 2018-07-16 23:54:53 --> Output Class Initialized
INFO - 2018-07-16 23:54:53 --> Security Class Initialized
DEBUG - 2018-07-16 23:54:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 23:54:53 --> Input Class Initialized
INFO - 2018-07-16 23:54:53 --> Language Class Initialized
INFO - 2018-07-16 23:54:53 --> Language Class Initialized
INFO - 2018-07-16 23:54:53 --> Config Class Initialized
INFO - 2018-07-16 23:54:53 --> Loader Class Initialized
DEBUG - 2018-07-16 23:54:53 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 23:54:53 --> Helper loaded: url_helper
INFO - 2018-07-16 23:54:53 --> Helper loaded: form_helper
INFO - 2018-07-16 23:54:53 --> Helper loaded: date_helper
INFO - 2018-07-16 23:54:53 --> Helper loaded: util_helper
INFO - 2018-07-16 23:54:53 --> Helper loaded: text_helper
INFO - 2018-07-16 23:54:53 --> Helper loaded: string_helper
INFO - 2018-07-16 23:54:53 --> Database Driver Class Initialized
DEBUG - 2018-07-16 23:54:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 23:54:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 23:54:53 --> Email Class Initialized
INFO - 2018-07-16 23:54:53 --> Controller Class Initialized
DEBUG - 2018-07-16 23:54:53 --> Admin MX_Controller Initialized
INFO - 2018-07-16 23:54:53 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 23:54:53 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-16 23:54:53 --> Login MX_Controller Initialized
DEBUG - 2018-07-16 23:54:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 23:54:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-16 23:54:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
INFO - 2018-07-16 23:55:28 --> Config Class Initialized
INFO - 2018-07-16 23:55:28 --> Hooks Class Initialized
DEBUG - 2018-07-16 23:55:28 --> UTF-8 Support Enabled
INFO - 2018-07-16 23:55:28 --> Utf8 Class Initialized
INFO - 2018-07-16 23:55:28 --> URI Class Initialized
INFO - 2018-07-16 23:55:28 --> Router Class Initialized
INFO - 2018-07-16 23:55:28 --> Output Class Initialized
INFO - 2018-07-16 23:55:28 --> Security Class Initialized
DEBUG - 2018-07-16 23:55:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 23:55:28 --> Input Class Initialized
INFO - 2018-07-16 23:55:28 --> Language Class Initialized
INFO - 2018-07-16 23:55:28 --> Language Class Initialized
INFO - 2018-07-16 23:55:28 --> Config Class Initialized
INFO - 2018-07-16 23:55:28 --> Loader Class Initialized
DEBUG - 2018-07-16 23:55:28 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-16 23:55:28 --> Helper loaded: url_helper
INFO - 2018-07-16 23:55:28 --> Helper loaded: form_helper
INFO - 2018-07-16 23:55:28 --> Helper loaded: date_helper
INFO - 2018-07-16 23:55:28 --> Helper loaded: util_helper
INFO - 2018-07-16 23:55:28 --> Helper loaded: text_helper
INFO - 2018-07-16 23:55:28 --> Helper loaded: string_helper
INFO - 2018-07-16 23:55:28 --> Database Driver Class Initialized
DEBUG - 2018-07-16 23:55:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 23:55:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 23:55:28 --> Email Class Initialized
INFO - 2018-07-16 23:55:28 --> Controller Class Initialized
DEBUG - 2018-07-16 23:55:28 --> Admin MX_Controller Initialized
INFO - 2018-07-16 23:55:28 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-16 23:55:28 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-16 23:55:28 --> Login MX_Controller Initialized
DEBUG - 2018-07-16 23:55:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-16 23:55:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-16 23:55:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
INFO - 2018-07-16 23:55:28 --> Config Class Initialized
INFO - 2018-07-16 23:55:28 --> Hooks Class Initialized
DEBUG - 2018-07-16 23:55:28 --> UTF-8 Support Enabled
INFO - 2018-07-16 23:55:28 --> Utf8 Class Initialized
INFO - 2018-07-16 23:55:28 --> URI Class Initialized
INFO - 2018-07-16 23:55:28 --> Router Class Initialized
INFO - 2018-07-16 23:55:28 --> Output Class Initialized
INFO - 2018-07-16 23:55:28 --> Security Class Initialized
DEBUG - 2018-07-16 23:55:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 23:55:28 --> Input Class Initialized
INFO - 2018-07-16 23:55:29 --> Language Class Initialized
ERROR - 2018-07-16 23:55:29 --> 404 Page Not Found: /index
INFO - 2018-07-16 23:55:29 --> Config Class Initialized
INFO - 2018-07-16 23:55:29 --> Hooks Class Initialized
DEBUG - 2018-07-16 23:55:29 --> UTF-8 Support Enabled
INFO - 2018-07-16 23:55:29 --> Utf8 Class Initialized
INFO - 2018-07-16 23:55:29 --> URI Class Initialized
INFO - 2018-07-16 23:55:29 --> Router Class Initialized
INFO - 2018-07-16 23:55:29 --> Output Class Initialized
INFO - 2018-07-16 23:55:29 --> Security Class Initialized
DEBUG - 2018-07-16 23:55:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 23:55:29 --> Input Class Initialized
INFO - 2018-07-16 23:55:29 --> Language Class Initialized
ERROR - 2018-07-16 23:55:29 --> 404 Page Not Found: /index
