<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-07-17 00:15:42 --> Config Class Initialized
INFO - 2018-07-17 00:15:42 --> Hooks Class Initialized
DEBUG - 2018-07-17 00:15:42 --> UTF-8 Support Enabled
INFO - 2018-07-17 00:15:42 --> Utf8 Class Initialized
INFO - 2018-07-17 00:15:42 --> URI Class Initialized
INFO - 2018-07-17 00:15:42 --> Router Class Initialized
INFO - 2018-07-17 00:15:42 --> Output Class Initialized
INFO - 2018-07-17 00:15:42 --> Security Class Initialized
DEBUG - 2018-07-17 00:15:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 00:15:42 --> Input Class Initialized
INFO - 2018-07-17 00:15:42 --> Language Class Initialized
INFO - 2018-07-17 00:15:42 --> Language Class Initialized
INFO - 2018-07-17 00:15:42 --> Config Class Initialized
INFO - 2018-07-17 00:15:42 --> Loader Class Initialized
DEBUG - 2018-07-17 00:15:42 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-17 00:15:42 --> Helper loaded: url_helper
INFO - 2018-07-17 00:15:42 --> Helper loaded: form_helper
INFO - 2018-07-17 00:15:42 --> Helper loaded: date_helper
INFO - 2018-07-17 00:15:42 --> Helper loaded: util_helper
INFO - 2018-07-17 00:15:42 --> Helper loaded: text_helper
INFO - 2018-07-17 00:15:42 --> Helper loaded: string_helper
INFO - 2018-07-17 00:15:42 --> Database Driver Class Initialized
DEBUG - 2018-07-17 00:15:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-17 00:15:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-17 00:15:42 --> Email Class Initialized
INFO - 2018-07-17 00:15:42 --> Controller Class Initialized
DEBUG - 2018-07-17 00:15:42 --> Users MX_Controller Initialized
DEBUG - 2018-07-17 00:15:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-17 00:15:42 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-17 00:15:42 --> Login MX_Controller Initialized
INFO - 2018-07-17 00:15:42 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-17 00:15:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-17 00:15:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-17 00:15:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-17 00:15:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-17 00:15:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-17 00:15:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-17 00:15:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-07-17 00:15:42 --> Final output sent to browser
DEBUG - 2018-07-17 00:15:42 --> Total execution time: 0.3031
INFO - 2018-07-17 00:15:42 --> Config Class Initialized
INFO - 2018-07-17 00:15:42 --> Hooks Class Initialized
DEBUG - 2018-07-17 00:15:42 --> UTF-8 Support Enabled
INFO - 2018-07-17 00:15:42 --> Utf8 Class Initialized
INFO - 2018-07-17 00:15:42 --> URI Class Initialized
INFO - 2018-07-17 00:15:42 --> Router Class Initialized
INFO - 2018-07-17 00:15:42 --> Output Class Initialized
INFO - 2018-07-17 00:15:42 --> Security Class Initialized
DEBUG - 2018-07-17 00:15:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 00:15:42 --> Input Class Initialized
INFO - 2018-07-17 00:15:43 --> Language Class Initialized
INFO - 2018-07-17 00:15:43 --> Language Class Initialized
INFO - 2018-07-17 00:15:43 --> Config Class Initialized
INFO - 2018-07-17 00:15:43 --> Loader Class Initialized
DEBUG - 2018-07-17 00:15:43 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-17 00:15:43 --> Helper loaded: url_helper
INFO - 2018-07-17 00:15:43 --> Helper loaded: form_helper
INFO - 2018-07-17 00:15:43 --> Helper loaded: date_helper
INFO - 2018-07-17 00:15:43 --> Helper loaded: util_helper
INFO - 2018-07-17 00:15:43 --> Helper loaded: text_helper
INFO - 2018-07-17 00:15:43 --> Helper loaded: string_helper
INFO - 2018-07-17 00:15:43 --> Database Driver Class Initialized
DEBUG - 2018-07-17 00:15:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-17 00:15:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-17 00:15:43 --> Email Class Initialized
INFO - 2018-07-17 00:15:43 --> Controller Class Initialized
DEBUG - 2018-07-17 00:15:43 --> Users MX_Controller Initialized
DEBUG - 2018-07-17 00:15:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-17 00:15:43 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-17 00:15:43 --> Login MX_Controller Initialized
INFO - 2018-07-17 00:15:43 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-17 00:15:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-17 00:15:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-17 00:15:43 --> Final output sent to browser
DEBUG - 2018-07-17 00:15:43 --> Total execution time: 0.3886
INFO - 2018-07-17 00:16:36 --> Config Class Initialized
INFO - 2018-07-17 00:16:37 --> Hooks Class Initialized
DEBUG - 2018-07-17 00:16:37 --> UTF-8 Support Enabled
INFO - 2018-07-17 00:16:37 --> Utf8 Class Initialized
INFO - 2018-07-17 00:16:37 --> URI Class Initialized
INFO - 2018-07-17 00:16:37 --> Router Class Initialized
INFO - 2018-07-17 00:16:37 --> Output Class Initialized
INFO - 2018-07-17 00:16:37 --> Security Class Initialized
DEBUG - 2018-07-17 00:16:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 00:16:37 --> Input Class Initialized
INFO - 2018-07-17 00:16:37 --> Language Class Initialized
INFO - 2018-07-17 00:16:37 --> Language Class Initialized
INFO - 2018-07-17 00:16:37 --> Config Class Initialized
INFO - 2018-07-17 00:16:37 --> Loader Class Initialized
DEBUG - 2018-07-17 00:16:37 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-17 00:16:37 --> Helper loaded: url_helper
INFO - 2018-07-17 00:16:37 --> Helper loaded: form_helper
INFO - 2018-07-17 00:16:37 --> Helper loaded: date_helper
INFO - 2018-07-17 00:16:37 --> Helper loaded: util_helper
INFO - 2018-07-17 00:16:37 --> Helper loaded: text_helper
INFO - 2018-07-17 00:16:37 --> Helper loaded: string_helper
INFO - 2018-07-17 00:16:37 --> Database Driver Class Initialized
DEBUG - 2018-07-17 00:16:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-17 00:16:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-17 00:16:37 --> Email Class Initialized
INFO - 2018-07-17 00:16:37 --> Controller Class Initialized
DEBUG - 2018-07-17 00:16:37 --> Users MX_Controller Initialized
DEBUG - 2018-07-17 00:16:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-17 00:16:37 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-17 00:16:37 --> Login MX_Controller Initialized
INFO - 2018-07-17 00:16:37 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-17 00:16:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-17 00:16:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-17 00:16:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-17 00:16:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-17 00:16:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-17 00:16:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-17 00:16:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-07-17 00:16:37 --> Final output sent to browser
DEBUG - 2018-07-17 00:16:37 --> Total execution time: 0.3091
INFO - 2018-07-17 00:16:37 --> Config Class Initialized
INFO - 2018-07-17 00:16:37 --> Hooks Class Initialized
DEBUG - 2018-07-17 00:16:37 --> UTF-8 Support Enabled
INFO - 2018-07-17 00:16:37 --> Utf8 Class Initialized
INFO - 2018-07-17 00:16:37 --> URI Class Initialized
INFO - 2018-07-17 00:16:37 --> Router Class Initialized
INFO - 2018-07-17 00:16:37 --> Output Class Initialized
INFO - 2018-07-17 00:16:37 --> Security Class Initialized
DEBUG - 2018-07-17 00:16:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 00:16:37 --> Input Class Initialized
INFO - 2018-07-17 00:16:37 --> Language Class Initialized
INFO - 2018-07-17 00:16:37 --> Language Class Initialized
INFO - 2018-07-17 00:16:37 --> Config Class Initialized
INFO - 2018-07-17 00:16:37 --> Loader Class Initialized
DEBUG - 2018-07-17 00:16:37 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-17 00:16:37 --> Helper loaded: url_helper
INFO - 2018-07-17 00:16:37 --> Helper loaded: form_helper
INFO - 2018-07-17 00:16:37 --> Helper loaded: date_helper
INFO - 2018-07-17 00:16:37 --> Helper loaded: util_helper
INFO - 2018-07-17 00:16:37 --> Helper loaded: text_helper
INFO - 2018-07-17 00:16:37 --> Helper loaded: string_helper
INFO - 2018-07-17 00:16:37 --> Database Driver Class Initialized
DEBUG - 2018-07-17 00:16:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-17 00:16:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-17 00:16:37 --> Email Class Initialized
INFO - 2018-07-17 00:16:37 --> Controller Class Initialized
DEBUG - 2018-07-17 00:16:37 --> Users MX_Controller Initialized
DEBUG - 2018-07-17 00:16:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-17 00:16:38 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-17 00:16:38 --> Login MX_Controller Initialized
INFO - 2018-07-17 00:16:38 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-17 00:16:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-17 00:16:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-17 00:16:38 --> Final output sent to browser
DEBUG - 2018-07-17 00:16:38 --> Total execution time: 0.3593
INFO - 2018-07-17 00:16:46 --> Config Class Initialized
INFO - 2018-07-17 00:16:46 --> Hooks Class Initialized
DEBUG - 2018-07-17 00:16:46 --> UTF-8 Support Enabled
INFO - 2018-07-17 00:16:46 --> Utf8 Class Initialized
INFO - 2018-07-17 00:16:46 --> URI Class Initialized
INFO - 2018-07-17 00:16:46 --> Router Class Initialized
INFO - 2018-07-17 00:16:46 --> Output Class Initialized
INFO - 2018-07-17 00:16:46 --> Security Class Initialized
DEBUG - 2018-07-17 00:16:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 00:16:46 --> Input Class Initialized
INFO - 2018-07-17 00:16:46 --> Language Class Initialized
INFO - 2018-07-17 00:16:46 --> Language Class Initialized
INFO - 2018-07-17 00:16:46 --> Config Class Initialized
INFO - 2018-07-17 00:16:46 --> Loader Class Initialized
DEBUG - 2018-07-17 00:16:46 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-17 00:16:46 --> Helper loaded: url_helper
INFO - 2018-07-17 00:16:46 --> Helper loaded: form_helper
INFO - 2018-07-17 00:16:46 --> Helper loaded: date_helper
INFO - 2018-07-17 00:16:46 --> Helper loaded: util_helper
INFO - 2018-07-17 00:16:46 --> Helper loaded: text_helper
INFO - 2018-07-17 00:16:46 --> Helper loaded: string_helper
INFO - 2018-07-17 00:16:46 --> Database Driver Class Initialized
DEBUG - 2018-07-17 00:16:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-17 00:16:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-17 00:16:46 --> Email Class Initialized
INFO - 2018-07-17 00:16:46 --> Controller Class Initialized
DEBUG - 2018-07-17 00:16:46 --> Home MX_Controller Initialized
DEBUG - 2018-07-17 00:16:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-17 00:16:46 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-17 00:16:46 --> Login MX_Controller Initialized
INFO - 2018-07-17 00:16:46 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-17 00:16:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-17 00:16:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-17 00:16:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-07-17 00:16:51 --> Config Class Initialized
INFO - 2018-07-17 00:16:51 --> Hooks Class Initialized
DEBUG - 2018-07-17 00:16:51 --> UTF-8 Support Enabled
INFO - 2018-07-17 00:16:51 --> Utf8 Class Initialized
INFO - 2018-07-17 00:16:51 --> URI Class Initialized
INFO - 2018-07-17 00:16:51 --> Router Class Initialized
INFO - 2018-07-17 00:16:51 --> Output Class Initialized
INFO - 2018-07-17 00:16:51 --> Security Class Initialized
DEBUG - 2018-07-17 00:16:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 00:16:51 --> Input Class Initialized
INFO - 2018-07-17 00:16:51 --> Language Class Initialized
INFO - 2018-07-17 00:16:51 --> Language Class Initialized
INFO - 2018-07-17 00:16:51 --> Config Class Initialized
INFO - 2018-07-17 00:16:51 --> Loader Class Initialized
DEBUG - 2018-07-17 00:16:51 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-17 00:16:51 --> Helper loaded: url_helper
INFO - 2018-07-17 00:16:51 --> Helper loaded: form_helper
INFO - 2018-07-17 00:16:51 --> Helper loaded: date_helper
INFO - 2018-07-17 00:16:51 --> Helper loaded: util_helper
INFO - 2018-07-17 00:16:51 --> Helper loaded: text_helper
INFO - 2018-07-17 00:16:51 --> Helper loaded: string_helper
INFO - 2018-07-17 00:16:51 --> Database Driver Class Initialized
DEBUG - 2018-07-17 00:16:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-17 00:16:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-17 00:16:51 --> Email Class Initialized
INFO - 2018-07-17 00:16:51 --> Controller Class Initialized
DEBUG - 2018-07-17 00:16:51 --> Login MX_Controller Initialized
INFO - 2018-07-17 00:16:51 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-17 00:16:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-17 00:16:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-17 00:16:51 --> Email starts for user@colin.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-07-17 00:16:51 --> User session created for 4
INFO - 2018-07-17 00:16:51 --> Login status user@colin.com - success
INFO - 2018-07-17 00:16:51 --> Final output sent to browser
DEBUG - 2018-07-17 00:16:51 --> Total execution time: 0.3405
INFO - 2018-07-17 00:16:52 --> Config Class Initialized
INFO - 2018-07-17 00:16:52 --> Hooks Class Initialized
DEBUG - 2018-07-17 00:16:52 --> UTF-8 Support Enabled
INFO - 2018-07-17 00:16:52 --> Utf8 Class Initialized
INFO - 2018-07-17 00:16:52 --> URI Class Initialized
INFO - 2018-07-17 00:16:52 --> Router Class Initialized
INFO - 2018-07-17 00:16:52 --> Output Class Initialized
INFO - 2018-07-17 00:16:52 --> Security Class Initialized
DEBUG - 2018-07-17 00:16:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 00:16:52 --> Input Class Initialized
INFO - 2018-07-17 00:16:52 --> Language Class Initialized
INFO - 2018-07-17 00:16:52 --> Language Class Initialized
INFO - 2018-07-17 00:16:52 --> Config Class Initialized
INFO - 2018-07-17 00:16:52 --> Loader Class Initialized
DEBUG - 2018-07-17 00:16:52 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-17 00:16:52 --> Helper loaded: url_helper
INFO - 2018-07-17 00:16:52 --> Helper loaded: form_helper
INFO - 2018-07-17 00:16:52 --> Helper loaded: date_helper
INFO - 2018-07-17 00:16:52 --> Helper loaded: util_helper
INFO - 2018-07-17 00:16:52 --> Helper loaded: text_helper
INFO - 2018-07-17 00:16:52 --> Helper loaded: string_helper
INFO - 2018-07-17 00:16:52 --> Database Driver Class Initialized
DEBUG - 2018-07-17 00:16:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-17 00:16:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-17 00:16:52 --> Email Class Initialized
INFO - 2018-07-17 00:16:52 --> Controller Class Initialized
DEBUG - 2018-07-17 00:16:52 --> Home MX_Controller Initialized
DEBUG - 2018-07-17 00:16:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-17 00:16:52 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-17 00:16:52 --> Login MX_Controller Initialized
INFO - 2018-07-17 00:16:52 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-17 00:16:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-17 00:16:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-17 00:16:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-17 00:16:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-17 00:16:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-17 00:16:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-17 00:16:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-17 00:16:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-17 00:16:52 --> Final output sent to browser
DEBUG - 2018-07-17 00:16:52 --> Total execution time: 0.3607
INFO - 2018-07-17 00:16:52 --> Config Class Initialized
INFO - 2018-07-17 00:16:52 --> Hooks Class Initialized
DEBUG - 2018-07-17 00:16:52 --> UTF-8 Support Enabled
INFO - 2018-07-17 00:16:52 --> Utf8 Class Initialized
INFO - 2018-07-17 00:16:52 --> URI Class Initialized
INFO - 2018-07-17 00:16:52 --> Router Class Initialized
INFO - 2018-07-17 00:16:52 --> Output Class Initialized
INFO - 2018-07-17 00:16:52 --> Security Class Initialized
DEBUG - 2018-07-17 00:16:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 00:16:52 --> Input Class Initialized
INFO - 2018-07-17 00:16:52 --> Language Class Initialized
ERROR - 2018-07-17 00:16:52 --> 404 Page Not Found: /index
INFO - 2018-07-17 00:16:52 --> Config Class Initialized
INFO - 2018-07-17 00:16:52 --> Hooks Class Initialized
DEBUG - 2018-07-17 00:16:52 --> UTF-8 Support Enabled
INFO - 2018-07-17 00:16:52 --> Utf8 Class Initialized
INFO - 2018-07-17 00:16:52 --> URI Class Initialized
INFO - 2018-07-17 00:16:52 --> Router Class Initialized
INFO - 2018-07-17 00:16:52 --> Output Class Initialized
INFO - 2018-07-17 00:16:52 --> Security Class Initialized
DEBUG - 2018-07-17 00:16:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 00:16:53 --> Input Class Initialized
INFO - 2018-07-17 00:16:53 --> Language Class Initialized
ERROR - 2018-07-17 00:16:53 --> 404 Page Not Found: /index
INFO - 2018-07-17 00:16:53 --> Config Class Initialized
INFO - 2018-07-17 00:16:53 --> Hooks Class Initialized
DEBUG - 2018-07-17 00:16:53 --> UTF-8 Support Enabled
INFO - 2018-07-17 00:16:53 --> Utf8 Class Initialized
INFO - 2018-07-17 00:16:53 --> URI Class Initialized
INFO - 2018-07-17 00:16:53 --> Router Class Initialized
INFO - 2018-07-17 00:16:53 --> Output Class Initialized
INFO - 2018-07-17 00:16:53 --> Security Class Initialized
DEBUG - 2018-07-17 00:16:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 00:16:53 --> Input Class Initialized
INFO - 2018-07-17 00:16:53 --> Language Class Initialized
ERROR - 2018-07-17 00:16:53 --> 404 Page Not Found: /index
INFO - 2018-07-17 00:16:53 --> Config Class Initialized
INFO - 2018-07-17 00:16:53 --> Hooks Class Initialized
DEBUG - 2018-07-17 00:16:53 --> UTF-8 Support Enabled
INFO - 2018-07-17 00:16:53 --> Utf8 Class Initialized
INFO - 2018-07-17 00:16:53 --> URI Class Initialized
INFO - 2018-07-17 00:16:53 --> Router Class Initialized
INFO - 2018-07-17 00:16:53 --> Output Class Initialized
INFO - 2018-07-17 00:16:53 --> Security Class Initialized
DEBUG - 2018-07-17 00:16:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 00:16:53 --> Input Class Initialized
INFO - 2018-07-17 00:16:53 --> Language Class Initialized
ERROR - 2018-07-17 00:16:53 --> 404 Page Not Found: /index
INFO - 2018-07-17 00:16:53 --> Config Class Initialized
INFO - 2018-07-17 00:16:53 --> Hooks Class Initialized
DEBUG - 2018-07-17 00:16:53 --> UTF-8 Support Enabled
INFO - 2018-07-17 00:16:53 --> Utf8 Class Initialized
INFO - 2018-07-17 00:16:53 --> URI Class Initialized
INFO - 2018-07-17 00:16:53 --> Router Class Initialized
INFO - 2018-07-17 00:16:53 --> Output Class Initialized
INFO - 2018-07-17 00:16:53 --> Security Class Initialized
DEBUG - 2018-07-17 00:16:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 00:16:53 --> Input Class Initialized
INFO - 2018-07-17 00:16:53 --> Language Class Initialized
ERROR - 2018-07-17 00:16:53 --> 404 Page Not Found: /index
INFO - 2018-07-17 00:16:53 --> Config Class Initialized
INFO - 2018-07-17 00:16:53 --> Hooks Class Initialized
DEBUG - 2018-07-17 00:16:53 --> UTF-8 Support Enabled
INFO - 2018-07-17 00:16:53 --> Utf8 Class Initialized
INFO - 2018-07-17 00:16:53 --> URI Class Initialized
INFO - 2018-07-17 00:16:53 --> Router Class Initialized
INFO - 2018-07-17 00:16:53 --> Output Class Initialized
INFO - 2018-07-17 00:16:53 --> Security Class Initialized
DEBUG - 2018-07-17 00:16:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 00:16:53 --> Input Class Initialized
INFO - 2018-07-17 00:16:53 --> Language Class Initialized
ERROR - 2018-07-17 00:16:53 --> 404 Page Not Found: /index
INFO - 2018-07-17 02:48:08 --> Config Class Initialized
INFO - 2018-07-17 02:48:08 --> Hooks Class Initialized
DEBUG - 2018-07-17 02:48:08 --> UTF-8 Support Enabled
INFO - 2018-07-17 02:48:08 --> Utf8 Class Initialized
INFO - 2018-07-17 02:48:08 --> URI Class Initialized
INFO - 2018-07-17 02:48:08 --> Router Class Initialized
INFO - 2018-07-17 02:48:08 --> Output Class Initialized
INFO - 2018-07-17 02:48:08 --> Security Class Initialized
DEBUG - 2018-07-17 02:48:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 02:48:08 --> Input Class Initialized
INFO - 2018-07-17 02:48:08 --> Language Class Initialized
INFO - 2018-07-17 02:48:08 --> Language Class Initialized
INFO - 2018-07-17 02:48:08 --> Config Class Initialized
INFO - 2018-07-17 02:48:08 --> Loader Class Initialized
DEBUG - 2018-07-17 02:48:08 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-17 02:48:08 --> Helper loaded: url_helper
INFO - 2018-07-17 02:48:08 --> Helper loaded: form_helper
INFO - 2018-07-17 02:48:08 --> Helper loaded: date_helper
INFO - 2018-07-17 02:48:08 --> Helper loaded: util_helper
INFO - 2018-07-17 02:48:08 --> Helper loaded: text_helper
INFO - 2018-07-17 02:48:08 --> Helper loaded: string_helper
INFO - 2018-07-17 02:48:08 --> Database Driver Class Initialized
DEBUG - 2018-07-17 02:48:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-17 02:48:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-17 02:48:08 --> Email Class Initialized
INFO - 2018-07-17 02:48:08 --> Controller Class Initialized
DEBUG - 2018-07-17 02:48:08 --> Login MX_Controller Initialized
INFO - 2018-07-17 02:48:08 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-17 02:48:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-17 02:48:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-17 02:48:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
INFO - 2018-07-17 02:48:09 --> Final output sent to browser
DEBUG - 2018-07-17 02:48:09 --> Total execution time: 0.3015
INFO - 2018-07-17 02:48:09 --> Config Class Initialized
INFO - 2018-07-17 02:48:09 --> Hooks Class Initialized
DEBUG - 2018-07-17 02:48:09 --> UTF-8 Support Enabled
INFO - 2018-07-17 02:48:09 --> Utf8 Class Initialized
INFO - 2018-07-17 02:48:09 --> URI Class Initialized
INFO - 2018-07-17 02:48:09 --> Router Class Initialized
INFO - 2018-07-17 02:48:09 --> Output Class Initialized
INFO - 2018-07-17 02:48:09 --> Security Class Initialized
DEBUG - 2018-07-17 02:48:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 02:48:09 --> Input Class Initialized
INFO - 2018-07-17 02:48:09 --> Language Class Initialized
ERROR - 2018-07-17 02:48:09 --> 404 Page Not Found: /index
INFO - 2018-07-17 02:48:09 --> Config Class Initialized
INFO - 2018-07-17 02:48:09 --> Hooks Class Initialized
DEBUG - 2018-07-17 02:48:09 --> UTF-8 Support Enabled
INFO - 2018-07-17 02:48:09 --> Utf8 Class Initialized
INFO - 2018-07-17 02:48:09 --> URI Class Initialized
INFO - 2018-07-17 02:48:09 --> Router Class Initialized
INFO - 2018-07-17 02:48:09 --> Output Class Initialized
INFO - 2018-07-17 02:48:09 --> Security Class Initialized
DEBUG - 2018-07-17 02:48:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 02:48:09 --> Input Class Initialized
INFO - 2018-07-17 02:48:09 --> Language Class Initialized
ERROR - 2018-07-17 02:48:09 --> 404 Page Not Found: /index
INFO - 2018-07-17 02:49:08 --> Config Class Initialized
INFO - 2018-07-17 02:49:08 --> Hooks Class Initialized
DEBUG - 2018-07-17 02:49:08 --> UTF-8 Support Enabled
INFO - 2018-07-17 02:49:08 --> Utf8 Class Initialized
INFO - 2018-07-17 02:49:08 --> URI Class Initialized
INFO - 2018-07-17 02:49:08 --> Router Class Initialized
INFO - 2018-07-17 02:49:08 --> Output Class Initialized
INFO - 2018-07-17 02:49:08 --> Security Class Initialized
DEBUG - 2018-07-17 02:49:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 02:49:08 --> Input Class Initialized
INFO - 2018-07-17 02:49:08 --> Language Class Initialized
INFO - 2018-07-17 02:49:08 --> Language Class Initialized
INFO - 2018-07-17 02:49:08 --> Config Class Initialized
INFO - 2018-07-17 02:49:08 --> Loader Class Initialized
DEBUG - 2018-07-17 02:49:08 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-17 02:49:08 --> Helper loaded: url_helper
INFO - 2018-07-17 02:49:08 --> Helper loaded: form_helper
INFO - 2018-07-17 02:49:08 --> Helper loaded: date_helper
INFO - 2018-07-17 02:49:08 --> Helper loaded: util_helper
INFO - 2018-07-17 02:49:08 --> Helper loaded: text_helper
INFO - 2018-07-17 02:49:08 --> Helper loaded: string_helper
INFO - 2018-07-17 02:49:08 --> Database Driver Class Initialized
DEBUG - 2018-07-17 02:49:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-17 02:49:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-17 02:49:08 --> Email Class Initialized
INFO - 2018-07-17 02:49:08 --> Controller Class Initialized
DEBUG - 2018-07-17 02:49:08 --> Login MX_Controller Initialized
INFO - 2018-07-17 02:49:08 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-17 02:49:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-17 02:49:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-17 02:49:08 --> Email starts for admin@colin.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-07-17 02:49:08 --> User session created for 1
INFO - 2018-07-17 02:49:08 --> Login status admin@colin.com - success
INFO - 2018-07-17 02:49:08 --> Final output sent to browser
DEBUG - 2018-07-17 02:49:08 --> Total execution time: 0.3172
INFO - 2018-07-17 02:49:08 --> Config Class Initialized
INFO - 2018-07-17 02:49:08 --> Hooks Class Initialized
DEBUG - 2018-07-17 02:49:08 --> UTF-8 Support Enabled
INFO - 2018-07-17 02:49:08 --> Utf8 Class Initialized
INFO - 2018-07-17 02:49:08 --> URI Class Initialized
INFO - 2018-07-17 02:49:08 --> Router Class Initialized
INFO - 2018-07-17 02:49:08 --> Output Class Initialized
INFO - 2018-07-17 02:49:08 --> Security Class Initialized
DEBUG - 2018-07-17 02:49:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 02:49:08 --> Input Class Initialized
INFO - 2018-07-17 02:49:08 --> Language Class Initialized
INFO - 2018-07-17 02:49:08 --> Language Class Initialized
INFO - 2018-07-17 02:49:08 --> Config Class Initialized
INFO - 2018-07-17 02:49:08 --> Loader Class Initialized
DEBUG - 2018-07-17 02:49:08 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-17 02:49:08 --> Helper loaded: url_helper
INFO - 2018-07-17 02:49:08 --> Helper loaded: form_helper
INFO - 2018-07-17 02:49:08 --> Helper loaded: date_helper
INFO - 2018-07-17 02:49:08 --> Helper loaded: util_helper
INFO - 2018-07-17 02:49:08 --> Helper loaded: text_helper
INFO - 2018-07-17 02:49:08 --> Helper loaded: string_helper
INFO - 2018-07-17 02:49:08 --> Database Driver Class Initialized
DEBUG - 2018-07-17 02:49:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-17 02:49:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-17 02:49:08 --> Email Class Initialized
INFO - 2018-07-17 02:49:08 --> Controller Class Initialized
DEBUG - 2018-07-17 02:49:08 --> Login MX_Controller Initialized
INFO - 2018-07-17 02:49:08 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-17 02:49:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-17 02:49:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-17 02:49:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
INFO - 2018-07-17 02:49:08 --> Final output sent to browser
DEBUG - 2018-07-17 02:49:08 --> Total execution time: 0.2998
INFO - 2018-07-17 02:49:09 --> Config Class Initialized
INFO - 2018-07-17 02:49:09 --> Hooks Class Initialized
DEBUG - 2018-07-17 02:49:09 --> UTF-8 Support Enabled
INFO - 2018-07-17 02:49:09 --> Utf8 Class Initialized
INFO - 2018-07-17 02:49:09 --> URI Class Initialized
INFO - 2018-07-17 02:49:09 --> Router Class Initialized
INFO - 2018-07-17 02:49:09 --> Output Class Initialized
INFO - 2018-07-17 02:49:09 --> Security Class Initialized
DEBUG - 2018-07-17 02:49:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 02:49:09 --> Input Class Initialized
INFO - 2018-07-17 02:49:09 --> Language Class Initialized
ERROR - 2018-07-17 02:49:09 --> 404 Page Not Found: /index
INFO - 2018-07-17 02:49:14 --> Config Class Initialized
INFO - 2018-07-17 02:49:14 --> Hooks Class Initialized
DEBUG - 2018-07-17 02:49:14 --> UTF-8 Support Enabled
INFO - 2018-07-17 02:49:14 --> Utf8 Class Initialized
INFO - 2018-07-17 02:49:14 --> URI Class Initialized
INFO - 2018-07-17 02:49:14 --> Router Class Initialized
INFO - 2018-07-17 02:49:14 --> Output Class Initialized
INFO - 2018-07-17 02:49:14 --> Security Class Initialized
DEBUG - 2018-07-17 02:49:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 02:49:14 --> Input Class Initialized
INFO - 2018-07-17 02:49:14 --> Language Class Initialized
INFO - 2018-07-17 02:49:14 --> Language Class Initialized
INFO - 2018-07-17 02:49:14 --> Config Class Initialized
INFO - 2018-07-17 02:49:14 --> Loader Class Initialized
DEBUG - 2018-07-17 02:49:14 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-17 02:49:14 --> Helper loaded: url_helper
INFO - 2018-07-17 02:49:14 --> Helper loaded: form_helper
INFO - 2018-07-17 02:49:14 --> Helper loaded: date_helper
INFO - 2018-07-17 02:49:14 --> Helper loaded: util_helper
INFO - 2018-07-17 02:49:14 --> Helper loaded: text_helper
INFO - 2018-07-17 02:49:14 --> Helper loaded: string_helper
INFO - 2018-07-17 02:49:14 --> Database Driver Class Initialized
DEBUG - 2018-07-17 02:49:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-17 02:49:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-17 02:49:14 --> Email Class Initialized
INFO - 2018-07-17 02:49:14 --> Controller Class Initialized
DEBUG - 2018-07-17 02:49:14 --> Admin MX_Controller Initialized
INFO - 2018-07-17 02:49:14 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-17 02:49:14 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-17 02:49:14 --> Login MX_Controller Initialized
DEBUG - 2018-07-17 02:49:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-17 02:49:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-17 02:49:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-17 02:49:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-17 02:49:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-17 02:49:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-17 02:49:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-17 02:49:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/dashboard.php
INFO - 2018-07-17 02:49:14 --> Final output sent to browser
DEBUG - 2018-07-17 02:49:14 --> Total execution time: 0.3462
INFO - 2018-07-17 02:49:15 --> Config Class Initialized
INFO - 2018-07-17 02:49:15 --> Hooks Class Initialized
DEBUG - 2018-07-17 02:49:15 --> UTF-8 Support Enabled
INFO - 2018-07-17 02:49:15 --> Utf8 Class Initialized
INFO - 2018-07-17 02:49:15 --> Config Class Initialized
INFO - 2018-07-17 02:49:15 --> Hooks Class Initialized
INFO - 2018-07-17 02:49:15 --> URI Class Initialized
DEBUG - 2018-07-17 02:49:15 --> UTF-8 Support Enabled
INFO - 2018-07-17 02:49:15 --> Router Class Initialized
INFO - 2018-07-17 02:49:15 --> Utf8 Class Initialized
INFO - 2018-07-17 02:49:15 --> URI Class Initialized
INFO - 2018-07-17 02:49:15 --> Router Class Initialized
INFO - 2018-07-17 02:49:15 --> Output Class Initialized
INFO - 2018-07-17 02:49:15 --> Output Class Initialized
INFO - 2018-07-17 02:49:15 --> Security Class Initialized
DEBUG - 2018-07-17 02:49:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 02:49:15 --> Input Class Initialized
INFO - 2018-07-17 02:49:15 --> Language Class Initialized
ERROR - 2018-07-17 02:49:15 --> 404 Page Not Found: /index
INFO - 2018-07-17 02:49:15 --> Security Class Initialized
DEBUG - 2018-07-17 02:49:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 02:49:15 --> Input Class Initialized
INFO - 2018-07-17 02:49:15 --> Language Class Initialized
ERROR - 2018-07-17 02:49:15 --> 404 Page Not Found: /index
INFO - 2018-07-17 02:49:15 --> Config Class Initialized
INFO - 2018-07-17 02:49:15 --> Hooks Class Initialized
DEBUG - 2018-07-17 02:49:15 --> UTF-8 Support Enabled
INFO - 2018-07-17 02:49:15 --> Utf8 Class Initialized
INFO - 2018-07-17 02:49:15 --> URI Class Initialized
INFO - 2018-07-17 02:49:15 --> Router Class Initialized
INFO - 2018-07-17 02:49:15 --> Output Class Initialized
INFO - 2018-07-17 02:49:15 --> Security Class Initialized
DEBUG - 2018-07-17 02:49:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 02:49:15 --> Input Class Initialized
INFO - 2018-07-17 02:49:15 --> Language Class Initialized
ERROR - 2018-07-17 02:49:15 --> 404 Page Not Found: /index
INFO - 2018-07-17 02:49:20 --> Config Class Initialized
INFO - 2018-07-17 02:49:20 --> Hooks Class Initialized
DEBUG - 2018-07-17 02:49:20 --> UTF-8 Support Enabled
INFO - 2018-07-17 02:49:20 --> Utf8 Class Initialized
INFO - 2018-07-17 02:49:20 --> URI Class Initialized
INFO - 2018-07-17 02:49:20 --> Router Class Initialized
INFO - 2018-07-17 02:49:20 --> Output Class Initialized
INFO - 2018-07-17 02:49:20 --> Security Class Initialized
DEBUG - 2018-07-17 02:49:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 02:49:20 --> Input Class Initialized
INFO - 2018-07-17 02:49:20 --> Language Class Initialized
INFO - 2018-07-17 02:49:20 --> Language Class Initialized
INFO - 2018-07-17 02:49:20 --> Config Class Initialized
INFO - 2018-07-17 02:49:20 --> Loader Class Initialized
DEBUG - 2018-07-17 02:49:20 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-17 02:49:20 --> Helper loaded: url_helper
INFO - 2018-07-17 02:49:20 --> Helper loaded: form_helper
INFO - 2018-07-17 02:49:20 --> Helper loaded: date_helper
INFO - 2018-07-17 02:49:20 --> Helper loaded: util_helper
INFO - 2018-07-17 02:49:20 --> Helper loaded: text_helper
INFO - 2018-07-17 02:49:20 --> Helper loaded: string_helper
INFO - 2018-07-17 02:49:20 --> Database Driver Class Initialized
DEBUG - 2018-07-17 02:49:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-17 02:49:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-17 02:49:20 --> Email Class Initialized
INFO - 2018-07-17 02:49:20 --> Controller Class Initialized
DEBUG - 2018-07-17 02:49:20 --> Login MX_Controller Initialized
INFO - 2018-07-17 02:49:20 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-17 02:49:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-17 02:49:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-17 02:49:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
INFO - 2018-07-17 02:49:21 --> Final output sent to browser
DEBUG - 2018-07-17 02:49:21 --> Total execution time: 0.2983
INFO - 2018-07-17 02:49:21 --> Config Class Initialized
INFO - 2018-07-17 02:49:21 --> Hooks Class Initialized
DEBUG - 2018-07-17 02:49:21 --> UTF-8 Support Enabled
INFO - 2018-07-17 02:49:21 --> Utf8 Class Initialized
INFO - 2018-07-17 02:49:21 --> URI Class Initialized
INFO - 2018-07-17 02:49:21 --> Router Class Initialized
INFO - 2018-07-17 02:49:21 --> Output Class Initialized
INFO - 2018-07-17 02:49:21 --> Security Class Initialized
DEBUG - 2018-07-17 02:49:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 02:49:21 --> Input Class Initialized
INFO - 2018-07-17 02:49:21 --> Language Class Initialized
ERROR - 2018-07-17 02:49:21 --> 404 Page Not Found: /index
INFO - 2018-07-17 02:49:23 --> Config Class Initialized
INFO - 2018-07-17 02:49:23 --> Hooks Class Initialized
DEBUG - 2018-07-17 02:49:23 --> UTF-8 Support Enabled
INFO - 2018-07-17 02:49:23 --> Utf8 Class Initialized
INFO - 2018-07-17 02:49:23 --> URI Class Initialized
INFO - 2018-07-17 02:49:23 --> Router Class Initialized
INFO - 2018-07-17 02:49:23 --> Output Class Initialized
INFO - 2018-07-17 02:49:23 --> Security Class Initialized
DEBUG - 2018-07-17 02:49:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 02:49:23 --> Input Class Initialized
INFO - 2018-07-17 02:49:23 --> Language Class Initialized
INFO - 2018-07-17 02:49:23 --> Language Class Initialized
INFO - 2018-07-17 02:49:23 --> Config Class Initialized
INFO - 2018-07-17 02:49:23 --> Loader Class Initialized
DEBUG - 2018-07-17 02:49:23 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-17 02:49:23 --> Helper loaded: url_helper
INFO - 2018-07-17 02:49:23 --> Helper loaded: form_helper
INFO - 2018-07-17 02:49:23 --> Helper loaded: date_helper
INFO - 2018-07-17 02:49:23 --> Helper loaded: util_helper
INFO - 2018-07-17 02:49:23 --> Helper loaded: text_helper
INFO - 2018-07-17 02:49:23 --> Helper loaded: string_helper
INFO - 2018-07-17 02:49:23 --> Database Driver Class Initialized
DEBUG - 2018-07-17 02:49:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-17 02:49:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-17 02:49:23 --> Email Class Initialized
INFO - 2018-07-17 02:49:23 --> Controller Class Initialized
DEBUG - 2018-07-17 02:49:23 --> Admin MX_Controller Initialized
INFO - 2018-07-17 02:49:23 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-17 02:49:23 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-17 02:49:23 --> Login MX_Controller Initialized
DEBUG - 2018-07-17 02:49:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-17 02:49:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-17 02:49:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-17 02:49:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-17 02:49:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-17 02:49:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-17 02:49:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-17 02:49:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/dashboard.php
INFO - 2018-07-17 02:49:23 --> Final output sent to browser
DEBUG - 2018-07-17 02:49:23 --> Total execution time: 0.3471
INFO - 2018-07-17 02:49:23 --> Config Class Initialized
INFO - 2018-07-17 02:49:23 --> Hooks Class Initialized
DEBUG - 2018-07-17 02:49:23 --> UTF-8 Support Enabled
INFO - 2018-07-17 02:49:23 --> Utf8 Class Initialized
INFO - 2018-07-17 02:49:23 --> Config Class Initialized
INFO - 2018-07-17 02:49:23 --> Hooks Class Initialized
INFO - 2018-07-17 02:49:23 --> URI Class Initialized
DEBUG - 2018-07-17 02:49:23 --> UTF-8 Support Enabled
INFO - 2018-07-17 02:49:23 --> Utf8 Class Initialized
INFO - 2018-07-17 02:49:23 --> URI Class Initialized
INFO - 2018-07-17 02:49:23 --> Router Class Initialized
INFO - 2018-07-17 02:49:23 --> Router Class Initialized
INFO - 2018-07-17 02:49:23 --> Output Class Initialized
INFO - 2018-07-17 02:49:23 --> Security Class Initialized
DEBUG - 2018-07-17 02:49:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 02:49:23 --> Input Class Initialized
INFO - 2018-07-17 02:49:23 --> Language Class Initialized
ERROR - 2018-07-17 02:49:23 --> 404 Page Not Found: /index
INFO - 2018-07-17 02:49:23 --> Output Class Initialized
INFO - 2018-07-17 02:49:23 --> Security Class Initialized
DEBUG - 2018-07-17 02:49:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 02:49:24 --> Input Class Initialized
INFO - 2018-07-17 02:49:24 --> Language Class Initialized
ERROR - 2018-07-17 02:49:24 --> 404 Page Not Found: /index
INFO - 2018-07-17 02:49:24 --> Config Class Initialized
INFO - 2018-07-17 02:49:24 --> Hooks Class Initialized
DEBUG - 2018-07-17 02:49:24 --> UTF-8 Support Enabled
INFO - 2018-07-17 02:49:24 --> Utf8 Class Initialized
INFO - 2018-07-17 02:49:24 --> URI Class Initialized
INFO - 2018-07-17 02:49:24 --> Router Class Initialized
INFO - 2018-07-17 02:49:24 --> Output Class Initialized
INFO - 2018-07-17 02:49:24 --> Security Class Initialized
DEBUG - 2018-07-17 02:49:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 02:49:24 --> Input Class Initialized
INFO - 2018-07-17 02:49:24 --> Language Class Initialized
ERROR - 2018-07-17 02:49:24 --> 404 Page Not Found: /index
INFO - 2018-07-17 02:55:20 --> Config Class Initialized
INFO - 2018-07-17 02:55:20 --> Hooks Class Initialized
DEBUG - 2018-07-17 02:55:20 --> UTF-8 Support Enabled
INFO - 2018-07-17 02:55:20 --> Utf8 Class Initialized
INFO - 2018-07-17 02:55:20 --> URI Class Initialized
INFO - 2018-07-17 02:55:20 --> Router Class Initialized
INFO - 2018-07-17 02:55:20 --> Output Class Initialized
INFO - 2018-07-17 02:55:20 --> Security Class Initialized
DEBUG - 2018-07-17 02:55:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 02:55:20 --> Input Class Initialized
INFO - 2018-07-17 02:55:20 --> Language Class Initialized
INFO - 2018-07-17 02:55:20 --> Language Class Initialized
INFO - 2018-07-17 02:55:20 --> Config Class Initialized
INFO - 2018-07-17 02:55:20 --> Loader Class Initialized
DEBUG - 2018-07-17 02:55:20 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-17 02:55:20 --> Helper loaded: url_helper
INFO - 2018-07-17 02:55:20 --> Helper loaded: form_helper
INFO - 2018-07-17 02:55:20 --> Helper loaded: date_helper
INFO - 2018-07-17 02:55:20 --> Helper loaded: util_helper
INFO - 2018-07-17 02:55:20 --> Helper loaded: text_helper
INFO - 2018-07-17 02:55:20 --> Helper loaded: string_helper
INFO - 2018-07-17 02:55:20 --> Database Driver Class Initialized
DEBUG - 2018-07-17 02:55:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-17 02:55:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-17 02:55:20 --> Email Class Initialized
INFO - 2018-07-17 02:55:20 --> Controller Class Initialized
DEBUG - 2018-07-17 02:55:20 --> Login MX_Controller Initialized
INFO - 2018-07-17 02:55:20 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-17 02:55:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-17 02:55:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-17 02:55:20 --> 1 Loggedout
INFO - 2018-07-17 02:55:20 --> Config Class Initialized
INFO - 2018-07-17 02:55:20 --> Hooks Class Initialized
DEBUG - 2018-07-17 02:55:20 --> UTF-8 Support Enabled
INFO - 2018-07-17 02:55:20 --> Utf8 Class Initialized
INFO - 2018-07-17 02:55:20 --> URI Class Initialized
INFO - 2018-07-17 02:55:20 --> Router Class Initialized
INFO - 2018-07-17 02:55:20 --> Output Class Initialized
INFO - 2018-07-17 02:55:20 --> Security Class Initialized
DEBUG - 2018-07-17 02:55:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 02:55:20 --> Input Class Initialized
INFO - 2018-07-17 02:55:20 --> Language Class Initialized
INFO - 2018-07-17 02:55:20 --> Language Class Initialized
INFO - 2018-07-17 02:55:20 --> Config Class Initialized
INFO - 2018-07-17 02:55:20 --> Loader Class Initialized
DEBUG - 2018-07-17 02:55:20 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-17 02:55:20 --> Helper loaded: url_helper
INFO - 2018-07-17 02:55:20 --> Helper loaded: form_helper
INFO - 2018-07-17 02:55:20 --> Helper loaded: date_helper
INFO - 2018-07-17 02:55:20 --> Helper loaded: util_helper
INFO - 2018-07-17 02:55:20 --> Helper loaded: text_helper
INFO - 2018-07-17 02:55:20 --> Helper loaded: string_helper
INFO - 2018-07-17 02:55:20 --> Database Driver Class Initialized
DEBUG - 2018-07-17 02:55:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-17 02:55:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-17 02:55:20 --> Email Class Initialized
INFO - 2018-07-17 02:55:20 --> Controller Class Initialized
DEBUG - 2018-07-17 02:55:20 --> Admin MX_Controller Initialized
INFO - 2018-07-17 02:55:20 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-17 02:55:20 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-17 02:55:20 --> Login MX_Controller Initialized
DEBUG - 2018-07-17 02:55:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-17 02:55:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-17 02:55:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
INFO - 2018-07-17 02:55:21 --> Config Class Initialized
INFO - 2018-07-17 02:55:21 --> Hooks Class Initialized
DEBUG - 2018-07-17 02:55:21 --> UTF-8 Support Enabled
INFO - 2018-07-17 02:55:21 --> Utf8 Class Initialized
INFO - 2018-07-17 02:55:21 --> URI Class Initialized
INFO - 2018-07-17 02:55:21 --> Router Class Initialized
INFO - 2018-07-17 02:55:21 --> Output Class Initialized
INFO - 2018-07-17 02:55:21 --> Security Class Initialized
DEBUG - 2018-07-17 02:55:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 02:55:21 --> Input Class Initialized
INFO - 2018-07-17 02:55:21 --> Language Class Initialized
ERROR - 2018-07-17 02:55:21 --> 404 Page Not Found: /index
INFO - 2018-07-17 02:55:23 --> Config Class Initialized
INFO - 2018-07-17 02:55:23 --> Hooks Class Initialized
DEBUG - 2018-07-17 02:55:23 --> UTF-8 Support Enabled
INFO - 2018-07-17 02:55:23 --> Utf8 Class Initialized
INFO - 2018-07-17 02:55:24 --> URI Class Initialized
INFO - 2018-07-17 02:55:24 --> Router Class Initialized
INFO - 2018-07-17 02:55:24 --> Output Class Initialized
INFO - 2018-07-17 02:55:24 --> Security Class Initialized
DEBUG - 2018-07-17 02:55:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 02:55:24 --> Input Class Initialized
INFO - 2018-07-17 02:55:24 --> Language Class Initialized
INFO - 2018-07-17 02:55:24 --> Language Class Initialized
INFO - 2018-07-17 02:55:24 --> Config Class Initialized
INFO - 2018-07-17 02:55:24 --> Loader Class Initialized
DEBUG - 2018-07-17 02:55:24 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-17 02:55:24 --> Helper loaded: url_helper
INFO - 2018-07-17 02:55:24 --> Helper loaded: form_helper
INFO - 2018-07-17 02:55:24 --> Helper loaded: date_helper
INFO - 2018-07-17 02:55:24 --> Helper loaded: util_helper
INFO - 2018-07-17 02:55:24 --> Helper loaded: text_helper
INFO - 2018-07-17 02:55:24 --> Helper loaded: string_helper
INFO - 2018-07-17 02:55:24 --> Database Driver Class Initialized
DEBUG - 2018-07-17 02:55:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-17 02:55:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-17 02:55:24 --> Email Class Initialized
INFO - 2018-07-17 02:55:24 --> Controller Class Initialized
DEBUG - 2018-07-17 02:55:24 --> Login MX_Controller Initialized
INFO - 2018-07-17 02:55:24 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-17 02:55:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-17 02:55:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
ERROR - 2018-07-17 02:55:24 --> Severity: Notice --> Undefined index: home_user_id E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php 517
INFO - 2018-07-17 02:55:24 --> Config Class Initialized
INFO - 2018-07-17 02:55:24 --> Hooks Class Initialized
DEBUG - 2018-07-17 02:55:24 --> UTF-8 Support Enabled
INFO - 2018-07-17 02:55:24 --> Utf8 Class Initialized
INFO - 2018-07-17 02:55:24 --> URI Class Initialized
INFO - 2018-07-17 02:55:24 --> Router Class Initialized
INFO - 2018-07-17 02:55:24 --> Output Class Initialized
INFO - 2018-07-17 02:55:24 --> Security Class Initialized
DEBUG - 2018-07-17 02:55:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 02:55:24 --> Input Class Initialized
INFO - 2018-07-17 02:55:24 --> Language Class Initialized
INFO - 2018-07-17 02:55:24 --> Language Class Initialized
INFO - 2018-07-17 02:55:24 --> Config Class Initialized
INFO - 2018-07-17 02:55:24 --> Loader Class Initialized
DEBUG - 2018-07-17 02:55:24 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-17 02:55:24 --> Helper loaded: url_helper
INFO - 2018-07-17 02:55:24 --> Helper loaded: form_helper
INFO - 2018-07-17 02:55:24 --> Helper loaded: date_helper
INFO - 2018-07-17 02:55:24 --> Helper loaded: util_helper
INFO - 2018-07-17 02:55:24 --> Helper loaded: text_helper
INFO - 2018-07-17 02:55:24 --> Helper loaded: string_helper
INFO - 2018-07-17 02:55:24 --> Database Driver Class Initialized
DEBUG - 2018-07-17 02:55:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-17 02:55:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-17 02:55:24 --> Email Class Initialized
INFO - 2018-07-17 02:55:24 --> Controller Class Initialized
DEBUG - 2018-07-17 02:55:24 --> Home MX_Controller Initialized
DEBUG - 2018-07-17 02:55:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-17 02:55:24 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-17 02:55:24 --> Login MX_Controller Initialized
INFO - 2018-07-17 02:55:24 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-17 02:55:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-17 02:55:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-17 02:55:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-07-17 02:55:27 --> Config Class Initialized
INFO - 2018-07-17 02:55:27 --> Hooks Class Initialized
DEBUG - 2018-07-17 02:55:27 --> UTF-8 Support Enabled
INFO - 2018-07-17 02:55:27 --> Utf8 Class Initialized
INFO - 2018-07-17 02:55:27 --> URI Class Initialized
INFO - 2018-07-17 02:55:27 --> Router Class Initialized
INFO - 2018-07-17 02:55:27 --> Output Class Initialized
INFO - 2018-07-17 02:55:27 --> Security Class Initialized
DEBUG - 2018-07-17 02:55:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 02:55:27 --> Input Class Initialized
INFO - 2018-07-17 02:55:27 --> Language Class Initialized
INFO - 2018-07-17 02:55:27 --> Language Class Initialized
INFO - 2018-07-17 02:55:27 --> Config Class Initialized
INFO - 2018-07-17 02:55:27 --> Loader Class Initialized
DEBUG - 2018-07-17 02:55:27 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-17 02:55:27 --> Helper loaded: url_helper
INFO - 2018-07-17 02:55:27 --> Helper loaded: form_helper
INFO - 2018-07-17 02:55:27 --> Helper loaded: date_helper
INFO - 2018-07-17 02:55:27 --> Helper loaded: util_helper
INFO - 2018-07-17 02:55:27 --> Helper loaded: text_helper
INFO - 2018-07-17 02:55:27 --> Helper loaded: string_helper
INFO - 2018-07-17 02:55:27 --> Database Driver Class Initialized
DEBUG - 2018-07-17 02:55:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-17 02:55:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-17 02:55:27 --> Email Class Initialized
INFO - 2018-07-17 02:55:27 --> Controller Class Initialized
DEBUG - 2018-07-17 02:55:27 --> Login MX_Controller Initialized
INFO - 2018-07-17 02:55:27 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-17 02:55:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-17 02:55:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-17 02:55:27 --> Email starts for gopaltesting@yopmail.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-07-17 02:55:27 --> User session created for 36
INFO - 2018-07-17 02:55:27 --> Login status gopaltesting@yopmail.com - success
INFO - 2018-07-17 02:55:27 --> Final output sent to browser
DEBUG - 2018-07-17 02:55:27 --> Total execution time: 0.3409
INFO - 2018-07-17 02:55:27 --> Config Class Initialized
INFO - 2018-07-17 02:55:27 --> Hooks Class Initialized
DEBUG - 2018-07-17 02:55:27 --> UTF-8 Support Enabled
INFO - 2018-07-17 02:55:27 --> Utf8 Class Initialized
INFO - 2018-07-17 02:55:28 --> URI Class Initialized
INFO - 2018-07-17 02:55:28 --> Router Class Initialized
INFO - 2018-07-17 02:55:28 --> Output Class Initialized
INFO - 2018-07-17 02:55:28 --> Security Class Initialized
DEBUG - 2018-07-17 02:55:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 02:55:28 --> Input Class Initialized
INFO - 2018-07-17 02:55:28 --> Language Class Initialized
INFO - 2018-07-17 02:55:28 --> Language Class Initialized
INFO - 2018-07-17 02:55:28 --> Config Class Initialized
INFO - 2018-07-17 02:55:28 --> Loader Class Initialized
DEBUG - 2018-07-17 02:55:28 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-17 02:55:28 --> Helper loaded: url_helper
INFO - 2018-07-17 02:55:28 --> Helper loaded: form_helper
INFO - 2018-07-17 02:55:28 --> Helper loaded: date_helper
INFO - 2018-07-17 02:55:28 --> Helper loaded: util_helper
INFO - 2018-07-17 02:55:28 --> Helper loaded: text_helper
INFO - 2018-07-17 02:55:28 --> Helper loaded: string_helper
INFO - 2018-07-17 02:55:28 --> Database Driver Class Initialized
DEBUG - 2018-07-17 02:55:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-17 02:55:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-17 02:55:28 --> Email Class Initialized
INFO - 2018-07-17 02:55:28 --> Controller Class Initialized
DEBUG - 2018-07-17 02:55:28 --> Home MX_Controller Initialized
DEBUG - 2018-07-17 02:55:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-17 02:55:28 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-17 02:55:28 --> Login MX_Controller Initialized
INFO - 2018-07-17 02:55:28 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-17 02:55:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-17 02:55:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-17 02:55:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-17 02:55:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-17 02:55:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-17 02:55:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-17 02:55:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-17 02:55:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-17 02:55:28 --> Final output sent to browser
DEBUG - 2018-07-17 02:55:28 --> Total execution time: 0.3897
INFO - 2018-07-17 02:55:29 --> Config Class Initialized
INFO - 2018-07-17 02:55:29 --> Hooks Class Initialized
DEBUG - 2018-07-17 02:55:29 --> UTF-8 Support Enabled
INFO - 2018-07-17 02:55:29 --> Utf8 Class Initialized
INFO - 2018-07-17 02:55:30 --> URI Class Initialized
INFO - 2018-07-17 02:55:30 --> Router Class Initialized
INFO - 2018-07-17 02:55:30 --> Output Class Initialized
INFO - 2018-07-17 02:55:30 --> Security Class Initialized
DEBUG - 2018-07-17 02:55:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 02:55:30 --> Input Class Initialized
INFO - 2018-07-17 02:55:30 --> Language Class Initialized
ERROR - 2018-07-17 02:55:30 --> 404 Page Not Found: /index
INFO - 2018-07-17 02:55:30 --> Config Class Initialized
INFO - 2018-07-17 02:55:30 --> Hooks Class Initialized
DEBUG - 2018-07-17 02:55:30 --> UTF-8 Support Enabled
INFO - 2018-07-17 02:55:30 --> Utf8 Class Initialized
INFO - 2018-07-17 02:55:30 --> URI Class Initialized
INFO - 2018-07-17 02:55:30 --> Router Class Initialized
INFO - 2018-07-17 02:55:30 --> Output Class Initialized
INFO - 2018-07-17 02:55:30 --> Security Class Initialized
DEBUG - 2018-07-17 02:55:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 02:55:30 --> Input Class Initialized
INFO - 2018-07-17 02:55:30 --> Language Class Initialized
ERROR - 2018-07-17 02:55:30 --> 404 Page Not Found: /index
INFO - 2018-07-17 02:55:30 --> Config Class Initialized
INFO - 2018-07-17 02:55:30 --> Hooks Class Initialized
DEBUG - 2018-07-17 02:55:30 --> UTF-8 Support Enabled
INFO - 2018-07-17 02:55:30 --> Utf8 Class Initialized
INFO - 2018-07-17 02:55:30 --> Config Class Initialized
INFO - 2018-07-17 02:55:30 --> Hooks Class Initialized
INFO - 2018-07-17 02:55:30 --> URI Class Initialized
DEBUG - 2018-07-17 02:55:30 --> UTF-8 Support Enabled
INFO - 2018-07-17 02:55:30 --> Router Class Initialized
INFO - 2018-07-17 02:55:30 --> Utf8 Class Initialized
INFO - 2018-07-17 02:55:30 --> Output Class Initialized
INFO - 2018-07-17 02:55:30 --> URI Class Initialized
INFO - 2018-07-17 02:55:30 --> Security Class Initialized
INFO - 2018-07-17 02:55:30 --> Router Class Initialized
DEBUG - 2018-07-17 02:55:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 02:55:30 --> Input Class Initialized
INFO - 2018-07-17 02:55:30 --> Output Class Initialized
INFO - 2018-07-17 02:55:30 --> Security Class Initialized
INFO - 2018-07-17 02:55:30 --> Language Class Initialized
DEBUG - 2018-07-17 02:55:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-07-17 02:55:30 --> 404 Page Not Found: /index
INFO - 2018-07-17 02:55:30 --> Input Class Initialized
INFO - 2018-07-17 02:55:30 --> Language Class Initialized
ERROR - 2018-07-17 02:55:30 --> 404 Page Not Found: /index
INFO - 2018-07-17 02:55:30 --> Config Class Initialized
INFO - 2018-07-17 02:55:30 --> Hooks Class Initialized
DEBUG - 2018-07-17 02:55:30 --> UTF-8 Support Enabled
INFO - 2018-07-17 02:55:30 --> Utf8 Class Initialized
INFO - 2018-07-17 02:55:30 --> URI Class Initialized
INFO - 2018-07-17 02:55:30 --> Router Class Initialized
INFO - 2018-07-17 02:55:30 --> Output Class Initialized
INFO - 2018-07-17 02:55:30 --> Security Class Initialized
DEBUG - 2018-07-17 02:55:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 02:55:30 --> Input Class Initialized
INFO - 2018-07-17 02:55:30 --> Language Class Initialized
ERROR - 2018-07-17 02:55:30 --> 404 Page Not Found: /index
INFO - 2018-07-17 02:55:30 --> Config Class Initialized
INFO - 2018-07-17 02:55:30 --> Hooks Class Initialized
DEBUG - 2018-07-17 02:55:30 --> UTF-8 Support Enabled
INFO - 2018-07-17 02:55:30 --> Utf8 Class Initialized
INFO - 2018-07-17 02:55:30 --> URI Class Initialized
INFO - 2018-07-17 02:55:30 --> Router Class Initialized
INFO - 2018-07-17 02:55:30 --> Output Class Initialized
INFO - 2018-07-17 02:55:30 --> Security Class Initialized
DEBUG - 2018-07-17 02:55:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 02:55:30 --> Input Class Initialized
INFO - 2018-07-17 02:55:30 --> Language Class Initialized
ERROR - 2018-07-17 02:55:30 --> 404 Page Not Found: /index
INFO - 2018-07-17 02:55:30 --> Config Class Initialized
INFO - 2018-07-17 02:55:30 --> Hooks Class Initialized
DEBUG - 2018-07-17 02:55:30 --> UTF-8 Support Enabled
INFO - 2018-07-17 02:55:31 --> Utf8 Class Initialized
INFO - 2018-07-17 02:55:31 --> URI Class Initialized
INFO - 2018-07-17 02:55:31 --> Router Class Initialized
INFO - 2018-07-17 02:55:31 --> Output Class Initialized
INFO - 2018-07-17 02:55:31 --> Security Class Initialized
DEBUG - 2018-07-17 02:55:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 02:55:31 --> Input Class Initialized
INFO - 2018-07-17 02:55:31 --> Language Class Initialized
ERROR - 2018-07-17 02:55:31 --> 404 Page Not Found: /index
INFO - 2018-07-17 04:31:29 --> Config Class Initialized
INFO - 2018-07-17 04:31:29 --> Hooks Class Initialized
DEBUG - 2018-07-17 04:31:29 --> UTF-8 Support Enabled
INFO - 2018-07-17 04:31:29 --> Utf8 Class Initialized
INFO - 2018-07-17 04:31:29 --> URI Class Initialized
INFO - 2018-07-17 04:31:29 --> Router Class Initialized
INFO - 2018-07-17 04:31:29 --> Output Class Initialized
INFO - 2018-07-17 04:31:29 --> Security Class Initialized
DEBUG - 2018-07-17 04:31:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 04:31:29 --> Input Class Initialized
INFO - 2018-07-17 04:31:29 --> Language Class Initialized
INFO - 2018-07-17 04:31:29 --> Language Class Initialized
INFO - 2018-07-17 04:31:29 --> Config Class Initialized
INFO - 2018-07-17 04:31:29 --> Loader Class Initialized
DEBUG - 2018-07-17 04:31:29 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-17 04:31:29 --> Helper loaded: url_helper
INFO - 2018-07-17 04:31:29 --> Helper loaded: form_helper
INFO - 2018-07-17 04:31:29 --> Helper loaded: date_helper
INFO - 2018-07-17 04:31:29 --> Helper loaded: util_helper
INFO - 2018-07-17 04:31:29 --> Helper loaded: text_helper
INFO - 2018-07-17 04:31:29 --> Helper loaded: string_helper
INFO - 2018-07-17 04:31:29 --> Database Driver Class Initialized
DEBUG - 2018-07-17 04:31:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-17 04:31:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-17 04:31:29 --> Email Class Initialized
INFO - 2018-07-17 04:31:29 --> Controller Class Initialized
DEBUG - 2018-07-17 04:31:29 --> Home MX_Controller Initialized
DEBUG - 2018-07-17 04:31:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-17 04:31:29 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-17 04:31:29 --> Login MX_Controller Initialized
INFO - 2018-07-17 04:31:30 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-17 04:31:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-17 04:31:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-17 04:31:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-17 04:31:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-17 04:31:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-17 04:31:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-17 04:31:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-17 04:31:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-07-17 04:31:30 --> Final output sent to browser
DEBUG - 2018-07-17 04:31:30 --> Total execution time: 0.4210
INFO - 2018-07-17 04:31:31 --> Config Class Initialized
INFO - 2018-07-17 04:31:31 --> Config Class Initialized
INFO - 2018-07-17 04:31:31 --> Hooks Class Initialized
INFO - 2018-07-17 04:31:31 --> Hooks Class Initialized
DEBUG - 2018-07-17 04:31:31 --> UTF-8 Support Enabled
INFO - 2018-07-17 04:31:31 --> Utf8 Class Initialized
INFO - 2018-07-17 04:31:31 --> URI Class Initialized
INFO - 2018-07-17 04:31:31 --> Router Class Initialized
DEBUG - 2018-07-17 04:31:31 --> UTF-8 Support Enabled
INFO - 2018-07-17 04:31:31 --> Utf8 Class Initialized
INFO - 2018-07-17 04:31:31 --> Output Class Initialized
INFO - 2018-07-17 04:31:31 --> Security Class Initialized
INFO - 2018-07-17 04:31:31 --> URI Class Initialized
DEBUG - 2018-07-17 04:31:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 04:31:32 --> Router Class Initialized
INFO - 2018-07-17 04:31:32 --> Input Class Initialized
INFO - 2018-07-17 04:31:32 --> Output Class Initialized
INFO - 2018-07-17 04:31:32 --> Security Class Initialized
INFO - 2018-07-17 04:31:32 --> Language Class Initialized
ERROR - 2018-07-17 04:31:32 --> 404 Page Not Found: /index
DEBUG - 2018-07-17 04:31:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 04:31:32 --> Input Class Initialized
INFO - 2018-07-17 04:31:32 --> Config Class Initialized
INFO - 2018-07-17 04:31:32 --> Hooks Class Initialized
INFO - 2018-07-17 04:31:32 --> Language Class Initialized
DEBUG - 2018-07-17 04:31:32 --> UTF-8 Support Enabled
INFO - 2018-07-17 04:31:32 --> Utf8 Class Initialized
INFO - 2018-07-17 04:31:32 --> URI Class Initialized
INFO - 2018-07-17 04:31:32 --> Router Class Initialized
ERROR - 2018-07-17 04:31:32 --> 404 Page Not Found: /index
INFO - 2018-07-17 04:31:32 --> Output Class Initialized
INFO - 2018-07-17 04:31:32 --> Security Class Initialized
DEBUG - 2018-07-17 04:31:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 04:31:32 --> Input Class Initialized
INFO - 2018-07-17 04:31:32 --> Language Class Initialized
ERROR - 2018-07-17 04:31:32 --> 404 Page Not Found: /index
INFO - 2018-07-17 04:31:32 --> Config Class Initialized
INFO - 2018-07-17 04:31:32 --> Hooks Class Initialized
DEBUG - 2018-07-17 04:31:32 --> UTF-8 Support Enabled
INFO - 2018-07-17 04:31:32 --> Utf8 Class Initialized
INFO - 2018-07-17 04:31:32 --> URI Class Initialized
INFO - 2018-07-17 04:31:32 --> Router Class Initialized
INFO - 2018-07-17 04:31:32 --> Output Class Initialized
INFO - 2018-07-17 04:31:32 --> Security Class Initialized
DEBUG - 2018-07-17 04:31:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 04:31:32 --> Input Class Initialized
INFO - 2018-07-17 04:31:32 --> Language Class Initialized
ERROR - 2018-07-17 04:31:32 --> 404 Page Not Found: /index
INFO - 2018-07-17 04:31:45 --> Config Class Initialized
INFO - 2018-07-17 04:31:45 --> Hooks Class Initialized
DEBUG - 2018-07-17 04:31:45 --> UTF-8 Support Enabled
INFO - 2018-07-17 04:31:45 --> Utf8 Class Initialized
INFO - 2018-07-17 04:31:45 --> URI Class Initialized
INFO - 2018-07-17 04:31:45 --> Router Class Initialized
INFO - 2018-07-17 04:31:45 --> Output Class Initialized
INFO - 2018-07-17 04:31:45 --> Security Class Initialized
DEBUG - 2018-07-17 04:31:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 04:31:45 --> Input Class Initialized
INFO - 2018-07-17 04:31:45 --> Language Class Initialized
INFO - 2018-07-17 04:31:45 --> Language Class Initialized
INFO - 2018-07-17 04:31:45 --> Config Class Initialized
INFO - 2018-07-17 04:31:45 --> Loader Class Initialized
DEBUG - 2018-07-17 04:31:45 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-17 04:31:45 --> Helper loaded: url_helper
INFO - 2018-07-17 04:31:45 --> Helper loaded: form_helper
INFO - 2018-07-17 04:31:45 --> Helper loaded: date_helper
INFO - 2018-07-17 04:31:45 --> Helper loaded: util_helper
INFO - 2018-07-17 04:31:45 --> Helper loaded: text_helper
INFO - 2018-07-17 04:31:45 --> Helper loaded: string_helper
INFO - 2018-07-17 04:31:45 --> Database Driver Class Initialized
DEBUG - 2018-07-17 04:31:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-17 04:31:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-17 04:31:45 --> Email Class Initialized
INFO - 2018-07-17 04:31:45 --> Controller Class Initialized
DEBUG - 2018-07-17 04:31:45 --> Home MX_Controller Initialized
DEBUG - 2018-07-17 04:31:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-17 04:31:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-17 04:31:45 --> Final output sent to browser
DEBUG - 2018-07-17 04:31:45 --> Total execution time: 0.3332
INFO - 2018-07-17 04:31:45 --> Config Class Initialized
INFO - 2018-07-17 04:31:45 --> Hooks Class Initialized
DEBUG - 2018-07-17 04:31:45 --> UTF-8 Support Enabled
INFO - 2018-07-17 04:31:45 --> Utf8 Class Initialized
INFO - 2018-07-17 04:31:45 --> URI Class Initialized
INFO - 2018-07-17 04:31:45 --> Router Class Initialized
INFO - 2018-07-17 04:31:45 --> Output Class Initialized
INFO - 2018-07-17 04:31:45 --> Security Class Initialized
DEBUG - 2018-07-17 04:31:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 04:31:45 --> Input Class Initialized
INFO - 2018-07-17 04:31:45 --> Language Class Initialized
INFO - 2018-07-17 04:31:45 --> Language Class Initialized
INFO - 2018-07-17 04:31:45 --> Config Class Initialized
INFO - 2018-07-17 04:31:45 --> Loader Class Initialized
DEBUG - 2018-07-17 04:31:45 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-17 04:31:45 --> Helper loaded: url_helper
INFO - 2018-07-17 04:31:45 --> Helper loaded: form_helper
INFO - 2018-07-17 04:31:45 --> Helper loaded: date_helper
INFO - 2018-07-17 04:31:45 --> Helper loaded: util_helper
INFO - 2018-07-17 04:31:45 --> Helper loaded: text_helper
INFO - 2018-07-17 04:31:45 --> Helper loaded: string_helper
INFO - 2018-07-17 04:31:45 --> Database Driver Class Initialized
DEBUG - 2018-07-17 04:31:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-17 04:31:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-17 04:31:45 --> Email Class Initialized
INFO - 2018-07-17 04:31:45 --> Controller Class Initialized
DEBUG - 2018-07-17 04:31:45 --> Home MX_Controller Initialized
DEBUG - 2018-07-17 04:31:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-07-17 04:40:52 --> Config Class Initialized
INFO - 2018-07-17 04:40:52 --> Hooks Class Initialized
DEBUG - 2018-07-17 04:40:52 --> UTF-8 Support Enabled
INFO - 2018-07-17 04:40:52 --> Utf8 Class Initialized
INFO - 2018-07-17 04:40:52 --> URI Class Initialized
INFO - 2018-07-17 04:40:52 --> Router Class Initialized
INFO - 2018-07-17 04:40:52 --> Output Class Initialized
INFO - 2018-07-17 04:40:52 --> Security Class Initialized
DEBUG - 2018-07-17 04:40:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 04:40:52 --> Input Class Initialized
INFO - 2018-07-17 04:40:52 --> Language Class Initialized
INFO - 2018-07-17 04:40:52 --> Language Class Initialized
INFO - 2018-07-17 04:40:52 --> Config Class Initialized
INFO - 2018-07-17 04:40:52 --> Loader Class Initialized
DEBUG - 2018-07-17 04:40:52 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-17 04:40:52 --> Helper loaded: url_helper
INFO - 2018-07-17 04:40:52 --> Helper loaded: form_helper
INFO - 2018-07-17 04:40:52 --> Helper loaded: date_helper
INFO - 2018-07-17 04:40:52 --> Helper loaded: util_helper
INFO - 2018-07-17 04:40:52 --> Helper loaded: text_helper
INFO - 2018-07-17 04:40:52 --> Helper loaded: string_helper
INFO - 2018-07-17 04:40:52 --> Database Driver Class Initialized
DEBUG - 2018-07-17 04:40:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-17 04:40:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-17 04:40:52 --> Email Class Initialized
INFO - 2018-07-17 04:40:52 --> Controller Class Initialized
DEBUG - 2018-07-17 04:40:52 --> Users MX_Controller Initialized
DEBUG - 2018-07-17 04:40:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-17 04:40:52 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-17 04:40:52 --> Login MX_Controller Initialized
INFO - 2018-07-17 04:40:52 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-17 04:40:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-17 04:40:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
INFO - 2018-07-17 04:40:52 --> Config Class Initialized
INFO - 2018-07-17 04:40:52 --> Hooks Class Initialized
DEBUG - 2018-07-17 04:40:52 --> UTF-8 Support Enabled
INFO - 2018-07-17 04:40:52 --> Utf8 Class Initialized
INFO - 2018-07-17 04:40:52 --> URI Class Initialized
INFO - 2018-07-17 04:40:52 --> Router Class Initialized
INFO - 2018-07-17 04:40:52 --> Output Class Initialized
INFO - 2018-07-17 04:40:52 --> Security Class Initialized
DEBUG - 2018-07-17 04:40:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 04:40:52 --> Input Class Initialized
INFO - 2018-07-17 04:40:52 --> Language Class Initialized
ERROR - 2018-07-17 04:40:52 --> 404 Page Not Found: /index
INFO - 2018-07-17 04:40:55 --> Config Class Initialized
INFO - 2018-07-17 04:40:55 --> Hooks Class Initialized
DEBUG - 2018-07-17 04:40:55 --> UTF-8 Support Enabled
INFO - 2018-07-17 04:40:55 --> Utf8 Class Initialized
INFO - 2018-07-17 04:40:55 --> URI Class Initialized
INFO - 2018-07-17 04:40:55 --> Router Class Initialized
INFO - 2018-07-17 04:40:55 --> Output Class Initialized
INFO - 2018-07-17 04:40:55 --> Security Class Initialized
DEBUG - 2018-07-17 04:40:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 04:40:55 --> Input Class Initialized
INFO - 2018-07-17 04:40:55 --> Language Class Initialized
INFO - 2018-07-17 04:40:55 --> Language Class Initialized
INFO - 2018-07-17 04:40:55 --> Config Class Initialized
INFO - 2018-07-17 04:40:55 --> Loader Class Initialized
DEBUG - 2018-07-17 04:40:55 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-17 04:40:55 --> Helper loaded: url_helper
INFO - 2018-07-17 04:40:55 --> Helper loaded: form_helper
INFO - 2018-07-17 04:40:55 --> Helper loaded: date_helper
INFO - 2018-07-17 04:40:55 --> Helper loaded: util_helper
INFO - 2018-07-17 04:40:55 --> Helper loaded: text_helper
INFO - 2018-07-17 04:40:55 --> Helper loaded: string_helper
INFO - 2018-07-17 04:40:55 --> Database Driver Class Initialized
DEBUG - 2018-07-17 04:40:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-17 04:40:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-17 04:40:55 --> Email Class Initialized
INFO - 2018-07-17 04:40:55 --> Controller Class Initialized
DEBUG - 2018-07-17 04:40:55 --> Admin MX_Controller Initialized
INFO - 2018-07-17 04:40:55 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-17 04:40:55 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-17 04:40:55 --> Login MX_Controller Initialized
DEBUG - 2018-07-17 04:40:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-17 04:40:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-17 04:40:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
INFO - 2018-07-17 04:40:55 --> Config Class Initialized
INFO - 2018-07-17 04:40:55 --> Hooks Class Initialized
DEBUG - 2018-07-17 04:40:55 --> UTF-8 Support Enabled
INFO - 2018-07-17 04:40:55 --> Utf8 Class Initialized
INFO - 2018-07-17 04:40:55 --> URI Class Initialized
INFO - 2018-07-17 04:40:55 --> Router Class Initialized
INFO - 2018-07-17 04:40:55 --> Output Class Initialized
INFO - 2018-07-17 04:40:55 --> Security Class Initialized
DEBUG - 2018-07-17 04:40:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 04:40:55 --> Input Class Initialized
INFO - 2018-07-17 04:40:55 --> Language Class Initialized
ERROR - 2018-07-17 04:40:55 --> 404 Page Not Found: /index
INFO - 2018-07-17 04:41:01 --> Config Class Initialized
INFO - 2018-07-17 04:41:01 --> Hooks Class Initialized
DEBUG - 2018-07-17 04:41:01 --> UTF-8 Support Enabled
INFO - 2018-07-17 04:41:01 --> Utf8 Class Initialized
INFO - 2018-07-17 04:41:01 --> URI Class Initialized
INFO - 2018-07-17 04:41:01 --> Router Class Initialized
INFO - 2018-07-17 04:41:01 --> Output Class Initialized
INFO - 2018-07-17 04:41:01 --> Security Class Initialized
DEBUG - 2018-07-17 04:41:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 04:41:01 --> Input Class Initialized
INFO - 2018-07-17 04:41:01 --> Language Class Initialized
INFO - 2018-07-17 04:41:01 --> Language Class Initialized
INFO - 2018-07-17 04:41:01 --> Config Class Initialized
INFO - 2018-07-17 04:41:01 --> Loader Class Initialized
DEBUG - 2018-07-17 04:41:01 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-17 04:41:01 --> Helper loaded: url_helper
INFO - 2018-07-17 04:41:01 --> Helper loaded: form_helper
INFO - 2018-07-17 04:41:01 --> Helper loaded: date_helper
INFO - 2018-07-17 04:41:01 --> Helper loaded: util_helper
INFO - 2018-07-17 04:41:01 --> Helper loaded: text_helper
INFO - 2018-07-17 04:41:01 --> Helper loaded: string_helper
INFO - 2018-07-17 04:41:01 --> Database Driver Class Initialized
DEBUG - 2018-07-17 04:41:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-17 04:41:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-17 04:41:01 --> Email Class Initialized
INFO - 2018-07-17 04:41:02 --> Controller Class Initialized
DEBUG - 2018-07-17 04:41:02 --> Login MX_Controller Initialized
INFO - 2018-07-17 04:41:02 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-17 04:41:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-17 04:41:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-17 04:41:02 --> Email starts for admin@colin.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-07-17 04:41:02 --> User session created for 1
INFO - 2018-07-17 04:41:02 --> Login status admin@colin.com - success
INFO - 2018-07-17 04:41:02 --> Final output sent to browser
DEBUG - 2018-07-17 04:41:02 --> Total execution time: 0.3768
INFO - 2018-07-17 04:41:02 --> Config Class Initialized
INFO - 2018-07-17 04:41:02 --> Hooks Class Initialized
DEBUG - 2018-07-17 04:41:02 --> UTF-8 Support Enabled
INFO - 2018-07-17 04:41:02 --> Utf8 Class Initialized
INFO - 2018-07-17 04:41:02 --> URI Class Initialized
INFO - 2018-07-17 04:41:02 --> Router Class Initialized
INFO - 2018-07-17 04:41:02 --> Output Class Initialized
INFO - 2018-07-17 04:41:02 --> Security Class Initialized
DEBUG - 2018-07-17 04:41:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 04:41:02 --> Input Class Initialized
INFO - 2018-07-17 04:41:02 --> Language Class Initialized
INFO - 2018-07-17 04:41:02 --> Language Class Initialized
INFO - 2018-07-17 04:41:02 --> Config Class Initialized
INFO - 2018-07-17 04:41:02 --> Loader Class Initialized
DEBUG - 2018-07-17 04:41:02 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-17 04:41:02 --> Helper loaded: url_helper
INFO - 2018-07-17 04:41:02 --> Helper loaded: form_helper
INFO - 2018-07-17 04:41:02 --> Helper loaded: date_helper
INFO - 2018-07-17 04:41:02 --> Helper loaded: util_helper
INFO - 2018-07-17 04:41:02 --> Helper loaded: text_helper
INFO - 2018-07-17 04:41:02 --> Helper loaded: string_helper
INFO - 2018-07-17 04:41:02 --> Database Driver Class Initialized
DEBUG - 2018-07-17 04:41:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-17 04:41:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-17 04:41:02 --> Email Class Initialized
INFO - 2018-07-17 04:41:02 --> Controller Class Initialized
DEBUG - 2018-07-17 04:41:02 --> Admin MX_Controller Initialized
INFO - 2018-07-17 04:41:02 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-17 04:41:02 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-17 04:41:02 --> Login MX_Controller Initialized
DEBUG - 2018-07-17 04:41:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-17 04:41:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-17 04:41:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-17 04:41:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-17 04:41:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-17 04:41:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-17 04:41:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-17 04:41:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/dashboard.php
INFO - 2018-07-17 04:41:02 --> Final output sent to browser
DEBUG - 2018-07-17 04:41:02 --> Total execution time: 0.3995
INFO - 2018-07-17 04:41:02 --> Config Class Initialized
INFO - 2018-07-17 04:41:02 --> Config Class Initialized
INFO - 2018-07-17 04:41:02 --> Hooks Class Initialized
INFO - 2018-07-17 04:41:02 --> Hooks Class Initialized
DEBUG - 2018-07-17 04:41:02 --> UTF-8 Support Enabled
INFO - 2018-07-17 04:41:02 --> Utf8 Class Initialized
DEBUG - 2018-07-17 04:41:02 --> UTF-8 Support Enabled
INFO - 2018-07-17 04:41:02 --> Utf8 Class Initialized
INFO - 2018-07-17 04:41:02 --> URI Class Initialized
INFO - 2018-07-17 04:41:02 --> URI Class Initialized
INFO - 2018-07-17 04:41:02 --> Router Class Initialized
INFO - 2018-07-17 04:41:02 --> Output Class Initialized
INFO - 2018-07-17 04:41:02 --> Router Class Initialized
INFO - 2018-07-17 04:41:02 --> Output Class Initialized
INFO - 2018-07-17 04:41:02 --> Security Class Initialized
INFO - 2018-07-17 04:41:02 --> Security Class Initialized
DEBUG - 2018-07-17 04:41:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 04:41:02 --> Input Class Initialized
DEBUG - 2018-07-17 04:41:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 04:41:02 --> Input Class Initialized
INFO - 2018-07-17 04:41:02 --> Language Class Initialized
INFO - 2018-07-17 04:41:02 --> Language Class Initialized
ERROR - 2018-07-17 04:41:02 --> 404 Page Not Found: /index
ERROR - 2018-07-17 04:41:02 --> 404 Page Not Found: /index
INFO - 2018-07-17 04:41:02 --> Config Class Initialized
INFO - 2018-07-17 04:41:03 --> Hooks Class Initialized
DEBUG - 2018-07-17 04:41:03 --> UTF-8 Support Enabled
INFO - 2018-07-17 04:41:03 --> Utf8 Class Initialized
INFO - 2018-07-17 04:41:03 --> URI Class Initialized
INFO - 2018-07-17 04:41:03 --> Router Class Initialized
INFO - 2018-07-17 04:41:03 --> Output Class Initialized
INFO - 2018-07-17 04:41:03 --> Security Class Initialized
DEBUG - 2018-07-17 04:41:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 04:41:03 --> Input Class Initialized
INFO - 2018-07-17 04:41:03 --> Language Class Initialized
ERROR - 2018-07-17 04:41:03 --> 404 Page Not Found: /index
INFO - 2018-07-17 04:41:08 --> Config Class Initialized
INFO - 2018-07-17 04:41:08 --> Hooks Class Initialized
DEBUG - 2018-07-17 04:41:08 --> UTF-8 Support Enabled
INFO - 2018-07-17 04:41:08 --> Utf8 Class Initialized
INFO - 2018-07-17 04:41:08 --> URI Class Initialized
INFO - 2018-07-17 04:41:08 --> Router Class Initialized
INFO - 2018-07-17 04:41:08 --> Output Class Initialized
INFO - 2018-07-17 04:41:08 --> Security Class Initialized
DEBUG - 2018-07-17 04:41:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 04:41:08 --> Input Class Initialized
INFO - 2018-07-17 04:41:08 --> Language Class Initialized
INFO - 2018-07-17 04:41:08 --> Language Class Initialized
INFO - 2018-07-17 04:41:08 --> Config Class Initialized
INFO - 2018-07-17 04:41:08 --> Loader Class Initialized
DEBUG - 2018-07-17 04:41:08 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-17 04:41:09 --> Helper loaded: url_helper
INFO - 2018-07-17 04:41:09 --> Helper loaded: form_helper
INFO - 2018-07-17 04:41:09 --> Helper loaded: date_helper
INFO - 2018-07-17 04:41:09 --> Helper loaded: util_helper
INFO - 2018-07-17 04:41:09 --> Helper loaded: text_helper
INFO - 2018-07-17 04:41:09 --> Helper loaded: string_helper
INFO - 2018-07-17 04:41:09 --> Database Driver Class Initialized
DEBUG - 2018-07-17 04:41:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-17 04:41:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-17 04:41:09 --> Email Class Initialized
INFO - 2018-07-17 04:41:09 --> Controller Class Initialized
DEBUG - 2018-07-17 04:41:09 --> Login MX_Controller Initialized
INFO - 2018-07-17 04:41:09 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-17 04:41:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-17 04:41:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-17 04:41:09 --> Config Class Initialized
INFO - 2018-07-17 04:41:09 --> Hooks Class Initialized
DEBUG - 2018-07-17 04:41:09 --> UTF-8 Support Enabled
INFO - 2018-07-17 04:41:09 --> Utf8 Class Initialized
INFO - 2018-07-17 04:41:09 --> URI Class Initialized
INFO - 2018-07-17 04:41:09 --> Router Class Initialized
INFO - 2018-07-17 04:41:09 --> Output Class Initialized
INFO - 2018-07-17 04:41:09 --> Security Class Initialized
DEBUG - 2018-07-17 04:41:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 04:41:09 --> Input Class Initialized
INFO - 2018-07-17 04:41:09 --> Language Class Initialized
INFO - 2018-07-17 04:41:09 --> Language Class Initialized
INFO - 2018-07-17 04:41:09 --> Config Class Initialized
INFO - 2018-07-17 04:41:09 --> Loader Class Initialized
DEBUG - 2018-07-17 04:41:09 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-17 04:41:09 --> Helper loaded: url_helper
INFO - 2018-07-17 04:41:09 --> Helper loaded: form_helper
INFO - 2018-07-17 04:41:09 --> Helper loaded: date_helper
INFO - 2018-07-17 04:41:09 --> Helper loaded: util_helper
INFO - 2018-07-17 04:41:09 --> Helper loaded: text_helper
INFO - 2018-07-17 04:41:09 --> Helper loaded: string_helper
INFO - 2018-07-17 04:41:09 --> Database Driver Class Initialized
DEBUG - 2018-07-17 04:41:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-17 04:41:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-17 04:41:09 --> Email Class Initialized
INFO - 2018-07-17 04:41:09 --> Controller Class Initialized
DEBUG - 2018-07-17 04:41:09 --> Admin MX_Controller Initialized
INFO - 2018-07-17 04:41:09 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-17 04:41:09 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-17 04:41:09 --> Login MX_Controller Initialized
DEBUG - 2018-07-17 04:41:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-17 04:41:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-17 04:41:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-17 04:41:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-17 04:41:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-17 04:41:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-17 04:41:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-17 04:41:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/dashboard.php
INFO - 2018-07-17 04:41:09 --> Final output sent to browser
INFO - 2018-07-17 04:41:09 --> Config Class Initialized
INFO - 2018-07-17 04:41:09 --> Config Class Initialized
INFO - 2018-07-17 04:41:09 --> Hooks Class Initialized
INFO - 2018-07-17 04:41:09 --> Hooks Class Initialized
DEBUG - 2018-07-17 04:41:09 --> Total execution time: 0.4167
DEBUG - 2018-07-17 04:41:09 --> UTF-8 Support Enabled
DEBUG - 2018-07-17 04:41:09 --> UTF-8 Support Enabled
INFO - 2018-07-17 04:41:09 --> Utf8 Class Initialized
INFO - 2018-07-17 04:41:09 --> Utf8 Class Initialized
INFO - 2018-07-17 04:41:09 --> URI Class Initialized
INFO - 2018-07-17 04:41:09 --> URI Class Initialized
INFO - 2018-07-17 04:41:09 --> Router Class Initialized
INFO - 2018-07-17 04:41:09 --> Router Class Initialized
INFO - 2018-07-17 04:41:09 --> Output Class Initialized
INFO - 2018-07-17 04:41:09 --> Output Class Initialized
INFO - 2018-07-17 04:41:09 --> Security Class Initialized
INFO - 2018-07-17 04:41:09 --> Security Class Initialized
DEBUG - 2018-07-17 04:41:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-07-17 04:41:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 04:41:09 --> Input Class Initialized
INFO - 2018-07-17 04:41:09 --> Input Class Initialized
INFO - 2018-07-17 04:41:09 --> Language Class Initialized
INFO - 2018-07-17 04:41:09 --> Language Class Initialized
ERROR - 2018-07-17 04:41:09 --> 404 Page Not Found: /index
ERROR - 2018-07-17 04:41:09 --> 404 Page Not Found: /index
INFO - 2018-07-17 04:41:09 --> Config Class Initialized
INFO - 2018-07-17 04:41:09 --> Hooks Class Initialized
DEBUG - 2018-07-17 04:41:09 --> UTF-8 Support Enabled
INFO - 2018-07-17 04:41:09 --> Utf8 Class Initialized
INFO - 2018-07-17 04:41:09 --> URI Class Initialized
INFO - 2018-07-17 04:41:09 --> Router Class Initialized
INFO - 2018-07-17 04:41:09 --> Output Class Initialized
INFO - 2018-07-17 04:41:09 --> Security Class Initialized
DEBUG - 2018-07-17 04:41:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 04:41:10 --> Input Class Initialized
INFO - 2018-07-17 04:41:10 --> Language Class Initialized
ERROR - 2018-07-17 04:41:10 --> 404 Page Not Found: /index
INFO - 2018-07-17 04:41:19 --> Config Class Initialized
INFO - 2018-07-17 04:41:19 --> Hooks Class Initialized
DEBUG - 2018-07-17 04:41:19 --> UTF-8 Support Enabled
INFO - 2018-07-17 04:41:19 --> Utf8 Class Initialized
INFO - 2018-07-17 04:41:19 --> URI Class Initialized
INFO - 2018-07-17 04:41:19 --> Router Class Initialized
INFO - 2018-07-17 04:41:19 --> Output Class Initialized
INFO - 2018-07-17 04:41:19 --> Security Class Initialized
DEBUG - 2018-07-17 04:41:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 04:41:19 --> Input Class Initialized
INFO - 2018-07-17 04:41:19 --> Language Class Initialized
INFO - 2018-07-17 04:41:19 --> Language Class Initialized
INFO - 2018-07-17 04:41:19 --> Config Class Initialized
INFO - 2018-07-17 04:41:19 --> Loader Class Initialized
DEBUG - 2018-07-17 04:41:19 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-17 04:41:19 --> Helper loaded: url_helper
INFO - 2018-07-17 04:41:19 --> Helper loaded: form_helper
INFO - 2018-07-17 04:41:19 --> Helper loaded: date_helper
INFO - 2018-07-17 04:41:19 --> Helper loaded: util_helper
INFO - 2018-07-17 04:41:19 --> Helper loaded: text_helper
INFO - 2018-07-17 04:41:19 --> Helper loaded: string_helper
INFO - 2018-07-17 04:41:19 --> Database Driver Class Initialized
DEBUG - 2018-07-17 04:41:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-17 04:41:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-17 04:41:19 --> Email Class Initialized
INFO - 2018-07-17 04:41:19 --> Controller Class Initialized
DEBUG - 2018-07-17 04:41:19 --> Login MX_Controller Initialized
INFO - 2018-07-17 04:41:19 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-17 04:41:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-17 04:41:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-17 04:41:19 --> 1 Loggedout
INFO - 2018-07-17 04:41:19 --> Config Class Initialized
INFO - 2018-07-17 04:41:19 --> Hooks Class Initialized
DEBUG - 2018-07-17 04:41:19 --> UTF-8 Support Enabled
INFO - 2018-07-17 04:41:19 --> Utf8 Class Initialized
INFO - 2018-07-17 04:41:19 --> URI Class Initialized
INFO - 2018-07-17 04:41:19 --> Router Class Initialized
INFO - 2018-07-17 04:41:19 --> Output Class Initialized
INFO - 2018-07-17 04:41:19 --> Security Class Initialized
DEBUG - 2018-07-17 04:41:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 04:41:19 --> Input Class Initialized
INFO - 2018-07-17 04:41:19 --> Language Class Initialized
INFO - 2018-07-17 04:41:19 --> Language Class Initialized
INFO - 2018-07-17 04:41:19 --> Config Class Initialized
INFO - 2018-07-17 04:41:19 --> Loader Class Initialized
DEBUG - 2018-07-17 04:41:19 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-17 04:41:19 --> Helper loaded: url_helper
INFO - 2018-07-17 04:41:19 --> Helper loaded: form_helper
INFO - 2018-07-17 04:41:19 --> Helper loaded: date_helper
INFO - 2018-07-17 04:41:19 --> Helper loaded: util_helper
INFO - 2018-07-17 04:41:19 --> Helper loaded: text_helper
INFO - 2018-07-17 04:41:19 --> Helper loaded: string_helper
INFO - 2018-07-17 04:41:19 --> Database Driver Class Initialized
DEBUG - 2018-07-17 04:41:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-17 04:41:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-17 04:41:19 --> Email Class Initialized
INFO - 2018-07-17 04:41:19 --> Controller Class Initialized
DEBUG - 2018-07-17 04:41:19 --> Admin MX_Controller Initialized
INFO - 2018-07-17 04:41:19 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-17 04:41:20 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-17 04:41:20 --> Login MX_Controller Initialized
DEBUG - 2018-07-17 04:41:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-17 04:41:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-17 04:41:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
INFO - 2018-07-17 04:41:20 --> Config Class Initialized
INFO - 2018-07-17 04:41:20 --> Hooks Class Initialized
DEBUG - 2018-07-17 04:41:20 --> UTF-8 Support Enabled
INFO - 2018-07-17 04:41:20 --> Utf8 Class Initialized
INFO - 2018-07-17 04:41:20 --> URI Class Initialized
INFO - 2018-07-17 04:41:20 --> Router Class Initialized
INFO - 2018-07-17 04:41:20 --> Output Class Initialized
INFO - 2018-07-17 04:41:20 --> Security Class Initialized
DEBUG - 2018-07-17 04:41:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 04:41:20 --> Input Class Initialized
INFO - 2018-07-17 04:41:20 --> Language Class Initialized
ERROR - 2018-07-17 04:41:20 --> 404 Page Not Found: /index
INFO - 2018-07-17 04:41:23 --> Config Class Initialized
INFO - 2018-07-17 04:41:23 --> Hooks Class Initialized
DEBUG - 2018-07-17 04:41:23 --> UTF-8 Support Enabled
INFO - 2018-07-17 04:41:23 --> Utf8 Class Initialized
INFO - 2018-07-17 04:41:23 --> URI Class Initialized
INFO - 2018-07-17 04:41:23 --> Router Class Initialized
INFO - 2018-07-17 04:41:23 --> Output Class Initialized
INFO - 2018-07-17 04:41:23 --> Security Class Initialized
DEBUG - 2018-07-17 04:41:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 04:41:23 --> Input Class Initialized
INFO - 2018-07-17 04:41:23 --> Language Class Initialized
INFO - 2018-07-17 04:41:23 --> Language Class Initialized
INFO - 2018-07-17 04:41:23 --> Config Class Initialized
INFO - 2018-07-17 04:41:23 --> Loader Class Initialized
DEBUG - 2018-07-17 04:41:23 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-17 04:41:23 --> Helper loaded: url_helper
INFO - 2018-07-17 04:41:23 --> Helper loaded: form_helper
INFO - 2018-07-17 04:41:23 --> Helper loaded: date_helper
INFO - 2018-07-17 04:41:23 --> Helper loaded: util_helper
INFO - 2018-07-17 04:41:23 --> Helper loaded: text_helper
INFO - 2018-07-17 04:41:24 --> Helper loaded: string_helper
INFO - 2018-07-17 04:41:24 --> Database Driver Class Initialized
DEBUG - 2018-07-17 04:41:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-17 04:41:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-17 04:41:24 --> Email Class Initialized
INFO - 2018-07-17 04:41:24 --> Controller Class Initialized
DEBUG - 2018-07-17 04:41:24 --> Login MX_Controller Initialized
INFO - 2018-07-17 04:41:24 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-17 04:41:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-17 04:41:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-17 04:41:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
INFO - 2018-07-17 04:41:24 --> Final output sent to browser
DEBUG - 2018-07-17 04:41:24 --> Total execution time: 0.3313
INFO - 2018-07-17 04:41:24 --> Config Class Initialized
INFO - 2018-07-17 04:41:24 --> Hooks Class Initialized
DEBUG - 2018-07-17 04:41:24 --> UTF-8 Support Enabled
INFO - 2018-07-17 04:41:24 --> Utf8 Class Initialized
INFO - 2018-07-17 04:41:24 --> URI Class Initialized
INFO - 2018-07-17 04:41:24 --> Router Class Initialized
INFO - 2018-07-17 04:41:24 --> Output Class Initialized
INFO - 2018-07-17 04:41:24 --> Security Class Initialized
DEBUG - 2018-07-17 04:41:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 04:41:24 --> Input Class Initialized
INFO - 2018-07-17 04:41:24 --> Language Class Initialized
ERROR - 2018-07-17 04:41:24 --> 404 Page Not Found: /index
INFO - 2018-07-17 04:41:31 --> Config Class Initialized
INFO - 2018-07-17 04:41:31 --> Hooks Class Initialized
DEBUG - 2018-07-17 04:41:31 --> UTF-8 Support Enabled
INFO - 2018-07-17 04:41:31 --> Utf8 Class Initialized
INFO - 2018-07-17 04:41:31 --> URI Class Initialized
INFO - 2018-07-17 04:41:31 --> Router Class Initialized
INFO - 2018-07-17 04:41:31 --> Output Class Initialized
INFO - 2018-07-17 04:41:31 --> Security Class Initialized
DEBUG - 2018-07-17 04:41:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 04:41:31 --> Input Class Initialized
INFO - 2018-07-17 04:41:31 --> Language Class Initialized
INFO - 2018-07-17 04:41:31 --> Language Class Initialized
INFO - 2018-07-17 04:41:31 --> Config Class Initialized
INFO - 2018-07-17 04:41:31 --> Loader Class Initialized
DEBUG - 2018-07-17 04:41:31 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-17 04:41:31 --> Helper loaded: url_helper
INFO - 2018-07-17 04:41:31 --> Helper loaded: form_helper
INFO - 2018-07-17 04:41:31 --> Helper loaded: date_helper
INFO - 2018-07-17 04:41:31 --> Helper loaded: util_helper
INFO - 2018-07-17 04:41:31 --> Helper loaded: text_helper
INFO - 2018-07-17 04:41:31 --> Helper loaded: string_helper
INFO - 2018-07-17 04:41:31 --> Database Driver Class Initialized
DEBUG - 2018-07-17 04:41:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-17 04:41:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-17 04:41:31 --> Email Class Initialized
INFO - 2018-07-17 04:41:31 --> Controller Class Initialized
DEBUG - 2018-07-17 04:41:31 --> Admin MX_Controller Initialized
INFO - 2018-07-17 04:41:31 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-17 04:41:31 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-17 04:41:31 --> Login MX_Controller Initialized
DEBUG - 2018-07-17 04:41:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-17 04:41:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-17 04:41:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
INFO - 2018-07-17 04:41:31 --> Config Class Initialized
INFO - 2018-07-17 04:41:31 --> Hooks Class Initialized
DEBUG - 2018-07-17 04:41:31 --> UTF-8 Support Enabled
INFO - 2018-07-17 04:41:31 --> Utf8 Class Initialized
INFO - 2018-07-17 04:41:31 --> URI Class Initialized
INFO - 2018-07-17 04:41:31 --> Router Class Initialized
INFO - 2018-07-17 04:41:31 --> Output Class Initialized
INFO - 2018-07-17 04:41:31 --> Security Class Initialized
DEBUG - 2018-07-17 04:41:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 04:41:31 --> Input Class Initialized
INFO - 2018-07-17 04:41:31 --> Language Class Initialized
ERROR - 2018-07-17 04:41:31 --> 404 Page Not Found: /index
INFO - 2018-07-17 04:41:39 --> Config Class Initialized
INFO - 2018-07-17 04:41:39 --> Hooks Class Initialized
DEBUG - 2018-07-17 04:41:39 --> UTF-8 Support Enabled
INFO - 2018-07-17 04:41:39 --> Utf8 Class Initialized
INFO - 2018-07-17 04:41:39 --> URI Class Initialized
INFO - 2018-07-17 04:41:39 --> Router Class Initialized
INFO - 2018-07-17 04:41:39 --> Output Class Initialized
INFO - 2018-07-17 04:41:39 --> Security Class Initialized
DEBUG - 2018-07-17 04:41:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 04:41:39 --> Input Class Initialized
INFO - 2018-07-17 04:41:39 --> Language Class Initialized
INFO - 2018-07-17 04:41:39 --> Language Class Initialized
INFO - 2018-07-17 04:41:39 --> Config Class Initialized
INFO - 2018-07-17 04:41:39 --> Loader Class Initialized
DEBUG - 2018-07-17 04:41:39 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-17 04:41:39 --> Helper loaded: url_helper
INFO - 2018-07-17 04:41:39 --> Helper loaded: form_helper
INFO - 2018-07-17 04:41:39 --> Helper loaded: date_helper
INFO - 2018-07-17 04:41:39 --> Helper loaded: util_helper
INFO - 2018-07-17 04:41:39 --> Helper loaded: text_helper
INFO - 2018-07-17 04:41:39 --> Helper loaded: string_helper
INFO - 2018-07-17 04:41:39 --> Database Driver Class Initialized
DEBUG - 2018-07-17 04:41:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-17 04:41:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-17 04:41:39 --> Email Class Initialized
INFO - 2018-07-17 04:41:39 --> Controller Class Initialized
DEBUG - 2018-07-17 04:41:39 --> Admin MX_Controller Initialized
INFO - 2018-07-17 04:41:39 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-17 04:41:39 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-17 04:41:39 --> Login MX_Controller Initialized
DEBUG - 2018-07-17 04:41:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-17 04:41:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-17 04:41:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
INFO - 2018-07-17 04:41:40 --> Config Class Initialized
INFO - 2018-07-17 04:41:40 --> Hooks Class Initialized
DEBUG - 2018-07-17 04:41:40 --> UTF-8 Support Enabled
INFO - 2018-07-17 04:41:40 --> Utf8 Class Initialized
INFO - 2018-07-17 04:41:40 --> URI Class Initialized
INFO - 2018-07-17 04:41:40 --> Config Class Initialized
INFO - 2018-07-17 04:41:40 --> Hooks Class Initialized
INFO - 2018-07-17 04:41:40 --> Router Class Initialized
DEBUG - 2018-07-17 04:41:40 --> UTF-8 Support Enabled
INFO - 2018-07-17 04:41:40 --> Output Class Initialized
INFO - 2018-07-17 04:41:40 --> Utf8 Class Initialized
INFO - 2018-07-17 04:41:40 --> URI Class Initialized
INFO - 2018-07-17 04:41:40 --> Router Class Initialized
INFO - 2018-07-17 04:41:40 --> Security Class Initialized
INFO - 2018-07-17 04:41:40 --> Output Class Initialized
INFO - 2018-07-17 04:41:40 --> Security Class Initialized
DEBUG - 2018-07-17 04:41:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 04:41:40 --> Input Class Initialized
INFO - 2018-07-17 04:41:40 --> Language Class Initialized
ERROR - 2018-07-17 04:41:40 --> 404 Page Not Found: /index
DEBUG - 2018-07-17 04:41:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 04:41:40 --> Input Class Initialized
INFO - 2018-07-17 04:41:40 --> Language Class Initialized
INFO - 2018-07-17 04:41:40 --> Language Class Initialized
INFO - 2018-07-17 04:41:40 --> Config Class Initialized
INFO - 2018-07-17 04:41:40 --> Loader Class Initialized
DEBUG - 2018-07-17 04:41:40 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-17 04:41:40 --> Helper loaded: url_helper
INFO - 2018-07-17 04:41:40 --> Helper loaded: form_helper
INFO - 2018-07-17 04:41:40 --> Helper loaded: date_helper
INFO - 2018-07-17 04:41:40 --> Helper loaded: util_helper
INFO - 2018-07-17 04:41:40 --> Helper loaded: text_helper
INFO - 2018-07-17 04:41:40 --> Helper loaded: string_helper
INFO - 2018-07-17 04:41:40 --> Database Driver Class Initialized
DEBUG - 2018-07-17 04:41:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-17 04:41:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-17 04:41:40 --> Email Class Initialized
INFO - 2018-07-17 04:41:40 --> Controller Class Initialized
DEBUG - 2018-07-17 04:41:40 --> Admin MX_Controller Initialized
INFO - 2018-07-17 04:41:40 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-17 04:41:40 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-17 04:41:40 --> Login MX_Controller Initialized
DEBUG - 2018-07-17 04:41:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-17 04:41:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-17 04:41:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
INFO - 2018-07-17 04:41:40 --> Config Class Initialized
INFO - 2018-07-17 04:41:40 --> Hooks Class Initialized
DEBUG - 2018-07-17 04:41:40 --> UTF-8 Support Enabled
INFO - 2018-07-17 04:41:40 --> Utf8 Class Initialized
INFO - 2018-07-17 04:41:40 --> URI Class Initialized
INFO - 2018-07-17 04:41:40 --> Router Class Initialized
INFO - 2018-07-17 04:41:40 --> Output Class Initialized
INFO - 2018-07-17 04:41:40 --> Security Class Initialized
DEBUG - 2018-07-17 04:41:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 04:41:40 --> Input Class Initialized
INFO - 2018-07-17 04:41:40 --> Language Class Initialized
ERROR - 2018-07-17 04:41:40 --> 404 Page Not Found: /index
INFO - 2018-07-17 04:44:43 --> Config Class Initialized
INFO - 2018-07-17 04:44:43 --> Hooks Class Initialized
DEBUG - 2018-07-17 04:44:43 --> UTF-8 Support Enabled
INFO - 2018-07-17 04:44:43 --> Utf8 Class Initialized
INFO - 2018-07-17 04:44:43 --> URI Class Initialized
INFO - 2018-07-17 04:44:43 --> Router Class Initialized
INFO - 2018-07-17 04:44:43 --> Output Class Initialized
INFO - 2018-07-17 04:44:43 --> Security Class Initialized
DEBUG - 2018-07-17 04:44:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 04:44:43 --> Input Class Initialized
INFO - 2018-07-17 04:44:43 --> Language Class Initialized
INFO - 2018-07-17 04:44:43 --> Language Class Initialized
INFO - 2018-07-17 04:44:43 --> Config Class Initialized
INFO - 2018-07-17 04:44:43 --> Loader Class Initialized
DEBUG - 2018-07-17 04:44:43 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-17 04:44:43 --> Helper loaded: url_helper
INFO - 2018-07-17 04:44:43 --> Helper loaded: form_helper
INFO - 2018-07-17 04:44:43 --> Helper loaded: date_helper
INFO - 2018-07-17 04:44:43 --> Helper loaded: util_helper
INFO - 2018-07-17 04:44:43 --> Helper loaded: text_helper
INFO - 2018-07-17 04:44:43 --> Helper loaded: string_helper
INFO - 2018-07-17 04:44:43 --> Database Driver Class Initialized
DEBUG - 2018-07-17 04:44:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-17 04:44:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-17 04:44:43 --> Email Class Initialized
INFO - 2018-07-17 04:44:43 --> Controller Class Initialized
DEBUG - 2018-07-17 04:44:43 --> Login MX_Controller Initialized
INFO - 2018-07-17 04:44:43 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-17 04:44:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-17 04:44:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-17 04:44:43 --> Email starts for admin@colin.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-07-17 04:44:43 --> User session created for 1
INFO - 2018-07-17 04:44:43 --> Login status admin@colin.com - success
INFO - 2018-07-17 04:44:43 --> Final output sent to browser
DEBUG - 2018-07-17 04:44:43 --> Total execution time: 0.3763
INFO - 2018-07-17 04:44:43 --> Config Class Initialized
INFO - 2018-07-17 04:44:43 --> Hooks Class Initialized
DEBUG - 2018-07-17 04:44:43 --> UTF-8 Support Enabled
INFO - 2018-07-17 04:44:43 --> Utf8 Class Initialized
INFO - 2018-07-17 04:44:43 --> URI Class Initialized
INFO - 2018-07-17 04:44:43 --> Router Class Initialized
INFO - 2018-07-17 04:44:43 --> Output Class Initialized
INFO - 2018-07-17 04:44:43 --> Security Class Initialized
DEBUG - 2018-07-17 04:44:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 04:44:43 --> Input Class Initialized
INFO - 2018-07-17 04:44:43 --> Language Class Initialized
INFO - 2018-07-17 04:44:43 --> Language Class Initialized
INFO - 2018-07-17 04:44:43 --> Config Class Initialized
INFO - 2018-07-17 04:44:43 --> Loader Class Initialized
DEBUG - 2018-07-17 04:44:43 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-17 04:44:43 --> Helper loaded: url_helper
INFO - 2018-07-17 04:44:43 --> Helper loaded: form_helper
INFO - 2018-07-17 04:44:43 --> Helper loaded: date_helper
INFO - 2018-07-17 04:44:43 --> Helper loaded: util_helper
INFO - 2018-07-17 04:44:43 --> Helper loaded: text_helper
INFO - 2018-07-17 04:44:43 --> Helper loaded: string_helper
INFO - 2018-07-17 04:44:43 --> Database Driver Class Initialized
DEBUG - 2018-07-17 04:44:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-17 04:44:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-17 04:44:43 --> Email Class Initialized
INFO - 2018-07-17 04:44:43 --> Controller Class Initialized
DEBUG - 2018-07-17 04:44:43 --> Admin MX_Controller Initialized
INFO - 2018-07-17 04:44:43 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-17 04:44:43 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-17 04:44:43 --> Login MX_Controller Initialized
DEBUG - 2018-07-17 04:44:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-17 04:44:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-17 04:44:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-17 04:44:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-17 04:44:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-17 04:44:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-17 04:44:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-17 04:44:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/dashboard.php
INFO - 2018-07-17 04:44:43 --> Final output sent to browser
DEBUG - 2018-07-17 04:44:43 --> Total execution time: 0.4110
INFO - 2018-07-17 04:44:44 --> Config Class Initialized
INFO - 2018-07-17 04:44:44 --> Config Class Initialized
INFO - 2018-07-17 04:44:44 --> Hooks Class Initialized
INFO - 2018-07-17 04:44:44 --> Hooks Class Initialized
DEBUG - 2018-07-17 04:44:44 --> UTF-8 Support Enabled
DEBUG - 2018-07-17 04:44:44 --> UTF-8 Support Enabled
INFO - 2018-07-17 04:44:44 --> Utf8 Class Initialized
INFO - 2018-07-17 04:44:44 --> Utf8 Class Initialized
INFO - 2018-07-17 04:44:44 --> URI Class Initialized
INFO - 2018-07-17 04:44:44 --> URI Class Initialized
INFO - 2018-07-17 04:44:44 --> Router Class Initialized
INFO - 2018-07-17 04:44:44 --> Router Class Initialized
INFO - 2018-07-17 04:44:44 --> Output Class Initialized
INFO - 2018-07-17 04:44:44 --> Output Class Initialized
INFO - 2018-07-17 04:44:44 --> Security Class Initialized
INFO - 2018-07-17 04:44:44 --> Security Class Initialized
DEBUG - 2018-07-17 04:44:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-07-17 04:44:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 04:44:44 --> Input Class Initialized
INFO - 2018-07-17 04:44:44 --> Input Class Initialized
INFO - 2018-07-17 04:44:44 --> Language Class Initialized
INFO - 2018-07-17 04:44:44 --> Language Class Initialized
ERROR - 2018-07-17 04:44:44 --> 404 Page Not Found: /index
ERROR - 2018-07-17 04:44:44 --> 404 Page Not Found: /index
INFO - 2018-07-17 04:44:44 --> Config Class Initialized
INFO - 2018-07-17 04:44:44 --> Hooks Class Initialized
DEBUG - 2018-07-17 04:44:44 --> UTF-8 Support Enabled
INFO - 2018-07-17 04:44:44 --> Utf8 Class Initialized
INFO - 2018-07-17 04:44:44 --> URI Class Initialized
INFO - 2018-07-17 04:44:44 --> Router Class Initialized
INFO - 2018-07-17 04:44:44 --> Output Class Initialized
INFO - 2018-07-17 04:44:44 --> Security Class Initialized
DEBUG - 2018-07-17 04:44:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 04:44:44 --> Input Class Initialized
INFO - 2018-07-17 04:44:44 --> Language Class Initialized
ERROR - 2018-07-17 04:44:44 --> 404 Page Not Found: /index
INFO - 2018-07-17 04:44:47 --> Config Class Initialized
INFO - 2018-07-17 04:44:47 --> Hooks Class Initialized
DEBUG - 2018-07-17 04:44:47 --> UTF-8 Support Enabled
INFO - 2018-07-17 04:44:47 --> Utf8 Class Initialized
INFO - 2018-07-17 04:44:47 --> URI Class Initialized
INFO - 2018-07-17 04:44:47 --> Router Class Initialized
INFO - 2018-07-17 04:44:47 --> Output Class Initialized
INFO - 2018-07-17 04:44:47 --> Security Class Initialized
DEBUG - 2018-07-17 04:44:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 04:44:47 --> Input Class Initialized
INFO - 2018-07-17 04:44:47 --> Language Class Initialized
INFO - 2018-07-17 04:44:47 --> Language Class Initialized
INFO - 2018-07-17 04:44:47 --> Config Class Initialized
INFO - 2018-07-17 04:44:47 --> Loader Class Initialized
DEBUG - 2018-07-17 04:44:47 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-17 04:44:47 --> Helper loaded: url_helper
INFO - 2018-07-17 04:44:47 --> Helper loaded: form_helper
INFO - 2018-07-17 04:44:47 --> Helper loaded: date_helper
INFO - 2018-07-17 04:44:47 --> Helper loaded: util_helper
INFO - 2018-07-17 04:44:47 --> Helper loaded: text_helper
INFO - 2018-07-17 04:44:47 --> Helper loaded: string_helper
INFO - 2018-07-17 04:44:47 --> Database Driver Class Initialized
DEBUG - 2018-07-17 04:44:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-17 04:44:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-17 04:44:47 --> Email Class Initialized
INFO - 2018-07-17 04:44:47 --> Controller Class Initialized
DEBUG - 2018-07-17 04:44:47 --> Profile MX_Controller Initialized
INFO - 2018-07-17 04:44:47 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-17 04:44:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-17 04:44:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Profile_model.php
DEBUG - 2018-07-17 04:44:47 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-17 04:44:47 --> Login MX_Controller Initialized
DEBUG - 2018-07-17 04:44:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-17 04:44:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-17 04:44:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-17 04:44:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-17 04:44:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-17 04:44:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-17 04:44:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/profile.php
INFO - 2018-07-17 04:44:47 --> Final output sent to browser
DEBUG - 2018-07-17 04:44:47 --> Total execution time: 0.4273
INFO - 2018-07-17 04:46:50 --> Config Class Initialized
INFO - 2018-07-17 04:46:50 --> Hooks Class Initialized
DEBUG - 2018-07-17 04:46:50 --> UTF-8 Support Enabled
INFO - 2018-07-17 04:46:50 --> Utf8 Class Initialized
INFO - 2018-07-17 04:46:50 --> URI Class Initialized
INFO - 2018-07-17 04:46:50 --> Router Class Initialized
INFO - 2018-07-17 04:46:50 --> Output Class Initialized
INFO - 2018-07-17 04:46:50 --> Security Class Initialized
DEBUG - 2018-07-17 04:46:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 04:46:50 --> Input Class Initialized
INFO - 2018-07-17 04:46:50 --> Language Class Initialized
INFO - 2018-07-17 04:46:50 --> Language Class Initialized
INFO - 2018-07-17 04:46:50 --> Config Class Initialized
INFO - 2018-07-17 04:46:50 --> Loader Class Initialized
DEBUG - 2018-07-17 04:46:50 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-17 04:46:50 --> Helper loaded: url_helper
INFO - 2018-07-17 04:46:50 --> Helper loaded: form_helper
INFO - 2018-07-17 04:46:50 --> Helper loaded: date_helper
INFO - 2018-07-17 04:46:50 --> Helper loaded: util_helper
INFO - 2018-07-17 04:46:50 --> Helper loaded: text_helper
INFO - 2018-07-17 04:46:50 --> Helper loaded: string_helper
INFO - 2018-07-17 04:46:50 --> Database Driver Class Initialized
DEBUG - 2018-07-17 04:46:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-17 04:46:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-17 04:46:50 --> Email Class Initialized
INFO - 2018-07-17 04:46:50 --> Controller Class Initialized
DEBUG - 2018-07-17 04:46:50 --> Login MX_Controller Initialized
INFO - 2018-07-17 04:46:50 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-17 04:46:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-17 04:46:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-17 04:46:50 --> 1 Loggedout
INFO - 2018-07-17 04:46:50 --> Config Class Initialized
INFO - 2018-07-17 04:46:50 --> Hooks Class Initialized
DEBUG - 2018-07-17 04:46:50 --> UTF-8 Support Enabled
INFO - 2018-07-17 04:46:50 --> Utf8 Class Initialized
INFO - 2018-07-17 04:46:50 --> URI Class Initialized
INFO - 2018-07-17 04:46:50 --> Router Class Initialized
INFO - 2018-07-17 04:46:50 --> Output Class Initialized
INFO - 2018-07-17 04:46:50 --> Security Class Initialized
DEBUG - 2018-07-17 04:46:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 04:46:50 --> Input Class Initialized
INFO - 2018-07-17 04:46:50 --> Language Class Initialized
INFO - 2018-07-17 04:46:50 --> Language Class Initialized
INFO - 2018-07-17 04:46:50 --> Config Class Initialized
INFO - 2018-07-17 04:46:50 --> Loader Class Initialized
DEBUG - 2018-07-17 04:46:51 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-17 04:46:51 --> Helper loaded: url_helper
INFO - 2018-07-17 04:46:51 --> Helper loaded: form_helper
INFO - 2018-07-17 04:46:51 --> Helper loaded: date_helper
INFO - 2018-07-17 04:46:51 --> Helper loaded: util_helper
INFO - 2018-07-17 04:46:51 --> Helper loaded: text_helper
INFO - 2018-07-17 04:46:51 --> Helper loaded: string_helper
INFO - 2018-07-17 04:46:51 --> Database Driver Class Initialized
DEBUG - 2018-07-17 04:46:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-17 04:46:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-17 04:46:51 --> Email Class Initialized
INFO - 2018-07-17 04:46:51 --> Controller Class Initialized
DEBUG - 2018-07-17 04:46:51 --> Admin MX_Controller Initialized
INFO - 2018-07-17 04:46:51 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-17 04:46:51 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-17 04:46:51 --> Login MX_Controller Initialized
DEBUG - 2018-07-17 04:46:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-17 04:46:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-17 04:46:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
INFO - 2018-07-17 04:46:51 --> Config Class Initialized
INFO - 2018-07-17 04:46:51 --> Hooks Class Initialized
DEBUG - 2018-07-17 04:46:51 --> UTF-8 Support Enabled
INFO - 2018-07-17 04:46:51 --> Utf8 Class Initialized
INFO - 2018-07-17 04:46:51 --> URI Class Initialized
INFO - 2018-07-17 04:46:51 --> Router Class Initialized
INFO - 2018-07-17 04:46:51 --> Output Class Initialized
INFO - 2018-07-17 04:46:51 --> Security Class Initialized
DEBUG - 2018-07-17 04:46:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 04:46:51 --> Input Class Initialized
INFO - 2018-07-17 04:46:51 --> Language Class Initialized
ERROR - 2018-07-17 04:46:51 --> 404 Page Not Found: /index
INFO - 2018-07-17 04:46:55 --> Config Class Initialized
INFO - 2018-07-17 04:46:55 --> Hooks Class Initialized
DEBUG - 2018-07-17 04:46:55 --> UTF-8 Support Enabled
INFO - 2018-07-17 04:46:55 --> Utf8 Class Initialized
INFO - 2018-07-17 04:46:55 --> URI Class Initialized
INFO - 2018-07-17 04:46:55 --> Router Class Initialized
INFO - 2018-07-17 04:46:55 --> Output Class Initialized
INFO - 2018-07-17 04:46:55 --> Security Class Initialized
DEBUG - 2018-07-17 04:46:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 04:46:55 --> Input Class Initialized
INFO - 2018-07-17 04:46:55 --> Language Class Initialized
INFO - 2018-07-17 04:46:55 --> Language Class Initialized
INFO - 2018-07-17 04:46:55 --> Config Class Initialized
INFO - 2018-07-17 04:46:55 --> Loader Class Initialized
DEBUG - 2018-07-17 04:46:55 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-17 04:46:55 --> Helper loaded: url_helper
INFO - 2018-07-17 04:46:55 --> Helper loaded: form_helper
INFO - 2018-07-17 04:46:55 --> Helper loaded: date_helper
INFO - 2018-07-17 04:46:55 --> Helper loaded: util_helper
INFO - 2018-07-17 04:46:55 --> Helper loaded: text_helper
INFO - 2018-07-17 04:46:55 --> Helper loaded: string_helper
INFO - 2018-07-17 04:46:55 --> Database Driver Class Initialized
DEBUG - 2018-07-17 04:46:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-17 04:46:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-17 04:46:55 --> Email Class Initialized
INFO - 2018-07-17 04:46:55 --> Controller Class Initialized
DEBUG - 2018-07-17 04:46:55 --> Login MX_Controller Initialized
INFO - 2018-07-17 04:46:55 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-17 04:46:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-17 04:46:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-17 04:46:55 --> Email starts for admin@colin.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-07-17 04:46:55 --> User session created for 1
INFO - 2018-07-17 04:46:55 --> Login status admin@colin.com - success
INFO - 2018-07-17 04:46:55 --> Final output sent to browser
DEBUG - 2018-07-17 04:46:55 --> Total execution time: 0.5128
INFO - 2018-07-17 04:46:55 --> Config Class Initialized
INFO - 2018-07-17 04:46:55 --> Hooks Class Initialized
DEBUG - 2018-07-17 04:46:55 --> UTF-8 Support Enabled
INFO - 2018-07-17 04:46:55 --> Utf8 Class Initialized
INFO - 2018-07-17 04:46:55 --> URI Class Initialized
INFO - 2018-07-17 04:46:55 --> Router Class Initialized
INFO - 2018-07-17 04:46:55 --> Output Class Initialized
INFO - 2018-07-17 04:46:56 --> Security Class Initialized
DEBUG - 2018-07-17 04:46:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 04:46:56 --> Input Class Initialized
INFO - 2018-07-17 04:46:56 --> Language Class Initialized
INFO - 2018-07-17 04:46:56 --> Language Class Initialized
INFO - 2018-07-17 04:46:56 --> Config Class Initialized
INFO - 2018-07-17 04:46:56 --> Loader Class Initialized
DEBUG - 2018-07-17 04:46:56 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-17 04:46:56 --> Helper loaded: url_helper
INFO - 2018-07-17 04:46:56 --> Helper loaded: form_helper
INFO - 2018-07-17 04:46:56 --> Helper loaded: date_helper
INFO - 2018-07-17 04:46:56 --> Helper loaded: util_helper
INFO - 2018-07-17 04:46:56 --> Helper loaded: text_helper
INFO - 2018-07-17 04:46:56 --> Helper loaded: string_helper
INFO - 2018-07-17 04:46:56 --> Database Driver Class Initialized
DEBUG - 2018-07-17 04:46:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-17 04:46:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-17 04:46:56 --> Email Class Initialized
INFO - 2018-07-17 04:46:56 --> Controller Class Initialized
DEBUG - 2018-07-17 04:46:56 --> Admin MX_Controller Initialized
INFO - 2018-07-17 04:46:56 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-17 04:46:56 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-17 04:46:56 --> Login MX_Controller Initialized
DEBUG - 2018-07-17 04:46:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-17 04:46:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-17 04:46:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-17 04:46:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-17 04:46:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-17 04:46:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-17 04:46:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-17 04:46:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/dashboard.php
INFO - 2018-07-17 04:46:56 --> Final output sent to browser
INFO - 2018-07-17 04:46:56 --> Config Class Initialized
INFO - 2018-07-17 04:46:56 --> Hooks Class Initialized
DEBUG - 2018-07-17 04:46:56 --> Total execution time: 0.4553
DEBUG - 2018-07-17 04:46:56 --> UTF-8 Support Enabled
INFO - 2018-07-17 04:46:56 --> Config Class Initialized
INFO - 2018-07-17 04:46:56 --> Hooks Class Initialized
INFO - 2018-07-17 04:46:56 --> Utf8 Class Initialized
DEBUG - 2018-07-17 04:46:56 --> UTF-8 Support Enabled
INFO - 2018-07-17 04:46:56 --> URI Class Initialized
INFO - 2018-07-17 04:46:56 --> Utf8 Class Initialized
INFO - 2018-07-17 04:46:56 --> Router Class Initialized
INFO - 2018-07-17 04:46:56 --> URI Class Initialized
INFO - 2018-07-17 04:46:56 --> Output Class Initialized
INFO - 2018-07-17 04:46:56 --> Security Class Initialized
INFO - 2018-07-17 04:46:56 --> Router Class Initialized
DEBUG - 2018-07-17 04:46:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 04:46:56 --> Output Class Initialized
INFO - 2018-07-17 04:46:56 --> Input Class Initialized
INFO - 2018-07-17 04:46:56 --> Security Class Initialized
INFO - 2018-07-17 04:46:56 --> Language Class Initialized
DEBUG - 2018-07-17 04:46:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-07-17 04:46:56 --> 404 Page Not Found: /index
INFO - 2018-07-17 04:46:56 --> Input Class Initialized
INFO - 2018-07-17 04:46:56 --> Language Class Initialized
ERROR - 2018-07-17 04:46:56 --> 404 Page Not Found: /index
INFO - 2018-07-17 04:47:01 --> Config Class Initialized
INFO - 2018-07-17 04:47:01 --> Hooks Class Initialized
DEBUG - 2018-07-17 04:47:01 --> UTF-8 Support Enabled
INFO - 2018-07-17 04:47:01 --> Utf8 Class Initialized
INFO - 2018-07-17 04:47:01 --> URI Class Initialized
INFO - 2018-07-17 04:47:01 --> Router Class Initialized
INFO - 2018-07-17 04:47:01 --> Output Class Initialized
INFO - 2018-07-17 04:47:01 --> Security Class Initialized
DEBUG - 2018-07-17 04:47:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 04:47:02 --> Input Class Initialized
INFO - 2018-07-17 04:47:02 --> Language Class Initialized
INFO - 2018-07-17 04:47:02 --> Language Class Initialized
INFO - 2018-07-17 04:47:02 --> Config Class Initialized
INFO - 2018-07-17 04:47:02 --> Loader Class Initialized
DEBUG - 2018-07-17 04:47:02 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-17 04:47:02 --> Helper loaded: url_helper
INFO - 2018-07-17 04:47:02 --> Helper loaded: form_helper
INFO - 2018-07-17 04:47:02 --> Helper loaded: date_helper
INFO - 2018-07-17 04:47:02 --> Helper loaded: util_helper
INFO - 2018-07-17 04:47:02 --> Helper loaded: text_helper
INFO - 2018-07-17 04:47:02 --> Helper loaded: string_helper
INFO - 2018-07-17 04:47:02 --> Database Driver Class Initialized
DEBUG - 2018-07-17 04:47:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-17 04:47:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-17 04:47:02 --> Email Class Initialized
INFO - 2018-07-17 04:47:02 --> Controller Class Initialized
DEBUG - 2018-07-17 04:47:02 --> Profile MX_Controller Initialized
INFO - 2018-07-17 04:47:02 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-17 04:47:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-17 04:47:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Profile_model.php
DEBUG - 2018-07-17 04:47:02 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-17 04:47:02 --> Login MX_Controller Initialized
DEBUG - 2018-07-17 04:47:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-17 04:47:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-17 04:47:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-17 04:47:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-17 04:47:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-17 04:47:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-17 04:47:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/profile.php
INFO - 2018-07-17 04:47:02 --> Final output sent to browser
DEBUG - 2018-07-17 04:47:02 --> Total execution time: 0.4451
INFO - 2018-07-17 04:54:29 --> Config Class Initialized
INFO - 2018-07-17 04:54:29 --> Hooks Class Initialized
DEBUG - 2018-07-17 04:54:29 --> UTF-8 Support Enabled
INFO - 2018-07-17 04:54:29 --> Utf8 Class Initialized
INFO - 2018-07-17 04:54:29 --> URI Class Initialized
INFO - 2018-07-17 04:54:29 --> Router Class Initialized
INFO - 2018-07-17 04:54:29 --> Output Class Initialized
INFO - 2018-07-17 04:54:29 --> Security Class Initialized
DEBUG - 2018-07-17 04:54:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 04:54:29 --> Input Class Initialized
INFO - 2018-07-17 04:54:29 --> Language Class Initialized
INFO - 2018-07-17 04:54:29 --> Language Class Initialized
INFO - 2018-07-17 04:54:29 --> Config Class Initialized
INFO - 2018-07-17 04:54:29 --> Loader Class Initialized
DEBUG - 2018-07-17 04:54:29 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-17 04:54:29 --> Helper loaded: url_helper
INFO - 2018-07-17 04:54:29 --> Helper loaded: form_helper
INFO - 2018-07-17 04:54:29 --> Helper loaded: date_helper
INFO - 2018-07-17 04:54:29 --> Helper loaded: util_helper
INFO - 2018-07-17 04:54:29 --> Helper loaded: text_helper
INFO - 2018-07-17 04:54:29 --> Helper loaded: string_helper
INFO - 2018-07-17 04:54:29 --> Database Driver Class Initialized
DEBUG - 2018-07-17 04:54:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-17 04:54:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-17 04:54:30 --> Email Class Initialized
INFO - 2018-07-17 04:54:30 --> Controller Class Initialized
DEBUG - 2018-07-17 04:54:30 --> Profile MX_Controller Initialized
INFO - 2018-07-17 04:54:30 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-17 04:54:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-17 04:54:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Profile_model.php
DEBUG - 2018-07-17 04:54:30 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-17 04:54:30 --> Login MX_Controller Initialized
DEBUG - 2018-07-17 04:54:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-17 04:54:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
INFO - 2018-07-17 04:54:30 --> Config Class Initialized
INFO - 2018-07-17 04:54:30 --> Hooks Class Initialized
DEBUG - 2018-07-17 04:54:30 --> UTF-8 Support Enabled
INFO - 2018-07-17 04:54:30 --> Utf8 Class Initialized
INFO - 2018-07-17 04:54:30 --> URI Class Initialized
INFO - 2018-07-17 04:54:30 --> Router Class Initialized
INFO - 2018-07-17 04:54:30 --> Output Class Initialized
INFO - 2018-07-17 04:54:30 --> Security Class Initialized
DEBUG - 2018-07-17 04:54:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 04:54:30 --> Input Class Initialized
INFO - 2018-07-17 04:54:30 --> Language Class Initialized
ERROR - 2018-07-17 04:54:30 --> 404 Page Not Found: /index
INFO - 2018-07-17 04:54:32 --> Config Class Initialized
INFO - 2018-07-17 04:54:32 --> Hooks Class Initialized
DEBUG - 2018-07-17 04:54:32 --> UTF-8 Support Enabled
INFO - 2018-07-17 04:54:32 --> Utf8 Class Initialized
INFO - 2018-07-17 04:54:32 --> URI Class Initialized
INFO - 2018-07-17 04:54:32 --> Router Class Initialized
INFO - 2018-07-17 04:54:32 --> Output Class Initialized
INFO - 2018-07-17 04:54:32 --> Security Class Initialized
DEBUG - 2018-07-17 04:54:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 04:54:32 --> Input Class Initialized
INFO - 2018-07-17 04:54:32 --> Language Class Initialized
ERROR - 2018-07-17 04:54:32 --> 404 Page Not Found: /index
INFO - 2018-07-17 04:54:36 --> Config Class Initialized
INFO - 2018-07-17 04:54:36 --> Hooks Class Initialized
DEBUG - 2018-07-17 04:54:36 --> UTF-8 Support Enabled
INFO - 2018-07-17 04:54:36 --> Utf8 Class Initialized
INFO - 2018-07-17 04:54:36 --> URI Class Initialized
INFO - 2018-07-17 04:54:36 --> Router Class Initialized
INFO - 2018-07-17 04:54:36 --> Output Class Initialized
INFO - 2018-07-17 04:54:36 --> Security Class Initialized
DEBUG - 2018-07-17 04:54:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 04:54:36 --> Input Class Initialized
INFO - 2018-07-17 04:54:36 --> Language Class Initialized
INFO - 2018-07-17 04:54:36 --> Language Class Initialized
INFO - 2018-07-17 04:54:36 --> Config Class Initialized
INFO - 2018-07-17 04:54:36 --> Loader Class Initialized
DEBUG - 2018-07-17 04:54:36 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-17 04:54:36 --> Helper loaded: url_helper
INFO - 2018-07-17 04:54:36 --> Helper loaded: form_helper
INFO - 2018-07-17 04:54:36 --> Helper loaded: date_helper
INFO - 2018-07-17 04:54:36 --> Helper loaded: util_helper
INFO - 2018-07-17 04:54:36 --> Helper loaded: text_helper
INFO - 2018-07-17 04:54:36 --> Helper loaded: string_helper
INFO - 2018-07-17 04:54:36 --> Database Driver Class Initialized
DEBUG - 2018-07-17 04:54:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-17 04:54:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-17 04:54:36 --> Email Class Initialized
INFO - 2018-07-17 04:54:36 --> Controller Class Initialized
DEBUG - 2018-07-17 04:54:36 --> Login MX_Controller Initialized
INFO - 2018-07-17 04:54:36 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-17 04:54:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-17 04:54:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-17 04:54:36 --> Email starts for admin@colin.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-07-17 04:54:36 --> User session created for 1
INFO - 2018-07-17 04:54:36 --> Login status admin@colin.com - success
INFO - 2018-07-17 04:54:36 --> Final output sent to browser
DEBUG - 2018-07-17 04:54:36 --> Total execution time: 0.3930
INFO - 2018-07-17 04:54:36 --> Config Class Initialized
INFO - 2018-07-17 04:54:36 --> Hooks Class Initialized
DEBUG - 2018-07-17 04:54:36 --> UTF-8 Support Enabled
INFO - 2018-07-17 04:54:36 --> Utf8 Class Initialized
INFO - 2018-07-17 04:54:36 --> URI Class Initialized
INFO - 2018-07-17 04:54:36 --> Router Class Initialized
INFO - 2018-07-17 04:54:36 --> Output Class Initialized
INFO - 2018-07-17 04:54:36 --> Security Class Initialized
DEBUG - 2018-07-17 04:54:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 04:54:36 --> Input Class Initialized
INFO - 2018-07-17 04:54:36 --> Language Class Initialized
INFO - 2018-07-17 04:54:36 --> Language Class Initialized
INFO - 2018-07-17 04:54:36 --> Config Class Initialized
INFO - 2018-07-17 04:54:36 --> Loader Class Initialized
DEBUG - 2018-07-17 04:54:36 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-17 04:54:36 --> Helper loaded: url_helper
INFO - 2018-07-17 04:54:36 --> Helper loaded: form_helper
INFO - 2018-07-17 04:54:36 --> Helper loaded: date_helper
INFO - 2018-07-17 04:54:36 --> Helper loaded: util_helper
INFO - 2018-07-17 04:54:36 --> Helper loaded: text_helper
INFO - 2018-07-17 04:54:36 --> Helper loaded: string_helper
INFO - 2018-07-17 04:54:36 --> Database Driver Class Initialized
DEBUG - 2018-07-17 04:54:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-17 04:54:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-17 04:54:37 --> Email Class Initialized
INFO - 2018-07-17 04:54:37 --> Controller Class Initialized
DEBUG - 2018-07-17 04:54:37 --> Profile MX_Controller Initialized
INFO - 2018-07-17 04:54:37 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-17 04:54:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-17 04:54:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Profile_model.php
DEBUG - 2018-07-17 04:54:37 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-17 04:54:37 --> Login MX_Controller Initialized
DEBUG - 2018-07-17 04:54:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-17 04:54:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-17 04:54:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-17 04:54:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-17 04:54:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-17 04:54:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-17 04:54:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/profile.php
INFO - 2018-07-17 04:54:37 --> Final output sent to browser
DEBUG - 2018-07-17 04:54:37 --> Total execution time: 0.4377
INFO - 2018-07-17 04:54:50 --> Config Class Initialized
INFO - 2018-07-17 04:54:50 --> Hooks Class Initialized
DEBUG - 2018-07-17 04:54:51 --> UTF-8 Support Enabled
INFO - 2018-07-17 04:54:51 --> Utf8 Class Initialized
INFO - 2018-07-17 04:54:51 --> URI Class Initialized
INFO - 2018-07-17 04:54:51 --> Router Class Initialized
INFO - 2018-07-17 04:54:51 --> Output Class Initialized
INFO - 2018-07-17 04:54:51 --> Security Class Initialized
DEBUG - 2018-07-17 04:54:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 04:54:51 --> Input Class Initialized
INFO - 2018-07-17 04:54:51 --> Language Class Initialized
INFO - 2018-07-17 04:54:51 --> Language Class Initialized
INFO - 2018-07-17 04:54:51 --> Config Class Initialized
INFO - 2018-07-17 04:54:51 --> Loader Class Initialized
DEBUG - 2018-07-17 04:54:51 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-17 04:54:51 --> Helper loaded: url_helper
INFO - 2018-07-17 04:54:51 --> Helper loaded: form_helper
INFO - 2018-07-17 04:54:51 --> Helper loaded: date_helper
INFO - 2018-07-17 04:54:51 --> Helper loaded: util_helper
INFO - 2018-07-17 04:54:51 --> Helper loaded: text_helper
INFO - 2018-07-17 04:54:51 --> Helper loaded: string_helper
INFO - 2018-07-17 04:54:51 --> Database Driver Class Initialized
DEBUG - 2018-07-17 04:54:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-17 04:54:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-17 04:54:51 --> Email Class Initialized
INFO - 2018-07-17 04:54:51 --> Controller Class Initialized
DEBUG - 2018-07-17 04:54:51 --> Profile MX_Controller Initialized
INFO - 2018-07-17 04:54:51 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-17 04:54:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-17 04:54:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Profile_model.php
DEBUG - 2018-07-17 04:54:51 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-17 04:54:51 --> Login MX_Controller Initialized
DEBUG - 2018-07-17 04:54:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-17 04:54:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-17 04:54:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-17 04:54:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-17 04:54:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-17 04:54:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-17 04:54:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/profile.php
INFO - 2018-07-17 04:54:51 --> Final output sent to browser
DEBUG - 2018-07-17 04:54:51 --> Total execution time: 0.4405
INFO - 2018-07-17 04:59:54 --> Config Class Initialized
INFO - 2018-07-17 04:59:54 --> Hooks Class Initialized
DEBUG - 2018-07-17 04:59:54 --> UTF-8 Support Enabled
INFO - 2018-07-17 04:59:54 --> Utf8 Class Initialized
INFO - 2018-07-17 04:59:54 --> URI Class Initialized
INFO - 2018-07-17 04:59:54 --> Router Class Initialized
INFO - 2018-07-17 04:59:54 --> Output Class Initialized
INFO - 2018-07-17 04:59:54 --> Security Class Initialized
DEBUG - 2018-07-17 04:59:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 04:59:54 --> Input Class Initialized
INFO - 2018-07-17 04:59:54 --> Language Class Initialized
INFO - 2018-07-17 04:59:54 --> Language Class Initialized
INFO - 2018-07-17 04:59:54 --> Config Class Initialized
INFO - 2018-07-17 04:59:54 --> Loader Class Initialized
DEBUG - 2018-07-17 04:59:54 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-17 04:59:54 --> Helper loaded: url_helper
INFO - 2018-07-17 04:59:54 --> Helper loaded: form_helper
INFO - 2018-07-17 04:59:54 --> Helper loaded: date_helper
INFO - 2018-07-17 04:59:54 --> Helper loaded: util_helper
INFO - 2018-07-17 04:59:54 --> Helper loaded: text_helper
INFO - 2018-07-17 04:59:54 --> Helper loaded: string_helper
INFO - 2018-07-17 04:59:54 --> Database Driver Class Initialized
DEBUG - 2018-07-17 04:59:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-17 04:59:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-17 04:59:54 --> Email Class Initialized
INFO - 2018-07-17 04:59:54 --> Controller Class Initialized
DEBUG - 2018-07-17 04:59:54 --> Profile MX_Controller Initialized
INFO - 2018-07-17 04:59:54 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-17 04:59:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-17 04:59:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Profile_model.php
DEBUG - 2018-07-17 04:59:54 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-17 04:59:54 --> Login MX_Controller Initialized
DEBUG - 2018-07-17 04:59:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-17 04:59:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-17 04:59:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-17 04:59:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-17 04:59:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-17 04:59:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-17 04:59:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/profile.php
INFO - 2018-07-17 04:59:54 --> Final output sent to browser
DEBUG - 2018-07-17 04:59:54 --> Total execution time: 0.4612
INFO - 2018-07-17 05:00:22 --> Config Class Initialized
INFO - 2018-07-17 05:00:22 --> Hooks Class Initialized
DEBUG - 2018-07-17 05:00:22 --> UTF-8 Support Enabled
INFO - 2018-07-17 05:00:22 --> Utf8 Class Initialized
INFO - 2018-07-17 05:00:22 --> URI Class Initialized
INFO - 2018-07-17 05:00:22 --> Router Class Initialized
INFO - 2018-07-17 05:00:22 --> Output Class Initialized
INFO - 2018-07-17 05:00:22 --> Security Class Initialized
DEBUG - 2018-07-17 05:00:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 05:00:22 --> Input Class Initialized
INFO - 2018-07-17 05:00:22 --> Language Class Initialized
INFO - 2018-07-17 05:00:22 --> Language Class Initialized
INFO - 2018-07-17 05:00:22 --> Config Class Initialized
INFO - 2018-07-17 05:00:22 --> Loader Class Initialized
DEBUG - 2018-07-17 05:00:22 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-17 05:00:22 --> Helper loaded: url_helper
INFO - 2018-07-17 05:00:22 --> Helper loaded: form_helper
INFO - 2018-07-17 05:00:22 --> Helper loaded: date_helper
INFO - 2018-07-17 05:00:22 --> Helper loaded: util_helper
INFO - 2018-07-17 05:00:22 --> Helper loaded: text_helper
INFO - 2018-07-17 05:00:22 --> Helper loaded: string_helper
INFO - 2018-07-17 05:00:22 --> Database Driver Class Initialized
DEBUG - 2018-07-17 05:00:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-17 05:00:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-17 05:00:22 --> Email Class Initialized
INFO - 2018-07-17 05:00:22 --> Controller Class Initialized
DEBUG - 2018-07-17 05:00:22 --> Profile MX_Controller Initialized
INFO - 2018-07-17 05:00:22 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-17 05:00:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-17 05:00:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Profile_model.php
DEBUG - 2018-07-17 05:00:22 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-17 05:00:22 --> Login MX_Controller Initialized
DEBUG - 2018-07-17 05:00:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-17 05:00:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-17 05:00:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-17 05:00:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-17 05:00:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-17 05:00:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-17 05:00:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/profile.php
INFO - 2018-07-17 05:00:22 --> Final output sent to browser
DEBUG - 2018-07-17 05:00:22 --> Total execution time: 0.4658
INFO - 2018-07-17 05:12:27 --> Config Class Initialized
INFO - 2018-07-17 05:12:27 --> Hooks Class Initialized
DEBUG - 2018-07-17 05:12:27 --> UTF-8 Support Enabled
INFO - 2018-07-17 05:12:27 --> Utf8 Class Initialized
INFO - 2018-07-17 05:12:27 --> URI Class Initialized
INFO - 2018-07-17 05:12:27 --> Router Class Initialized
INFO - 2018-07-17 05:12:27 --> Output Class Initialized
INFO - 2018-07-17 05:12:27 --> Security Class Initialized
DEBUG - 2018-07-17 05:12:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 05:12:27 --> Input Class Initialized
INFO - 2018-07-17 05:12:27 --> Language Class Initialized
INFO - 2018-07-17 05:12:27 --> Language Class Initialized
INFO - 2018-07-17 05:12:27 --> Config Class Initialized
INFO - 2018-07-17 05:12:27 --> Loader Class Initialized
DEBUG - 2018-07-17 05:12:27 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-17 05:12:27 --> Helper loaded: url_helper
INFO - 2018-07-17 05:12:27 --> Helper loaded: form_helper
INFO - 2018-07-17 05:12:27 --> Helper loaded: date_helper
INFO - 2018-07-17 05:12:27 --> Helper loaded: util_helper
INFO - 2018-07-17 05:12:27 --> Helper loaded: text_helper
INFO - 2018-07-17 05:12:27 --> Helper loaded: string_helper
INFO - 2018-07-17 05:12:27 --> Database Driver Class Initialized
DEBUG - 2018-07-17 05:12:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-17 05:12:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-17 05:12:27 --> Email Class Initialized
INFO - 2018-07-17 05:12:27 --> Controller Class Initialized
DEBUG - 2018-07-17 05:12:27 --> Users MX_Controller Initialized
DEBUG - 2018-07-17 05:12:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-17 05:12:27 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-17 05:12:27 --> Login MX_Controller Initialized
INFO - 2018-07-17 05:12:27 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-17 05:12:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-17 05:12:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-17 05:12:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-17 05:12:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-17 05:12:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-17 05:12:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-17 05:12:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-07-17 05:12:27 --> Final output sent to browser
DEBUG - 2018-07-17 05:12:27 --> Total execution time: 0.4523
INFO - 2018-07-17 05:12:27 --> Config Class Initialized
INFO - 2018-07-17 05:12:28 --> Hooks Class Initialized
DEBUG - 2018-07-17 05:12:28 --> UTF-8 Support Enabled
INFO - 2018-07-17 05:12:28 --> Utf8 Class Initialized
INFO - 2018-07-17 05:12:28 --> URI Class Initialized
INFO - 2018-07-17 05:12:28 --> Router Class Initialized
INFO - 2018-07-17 05:12:28 --> Output Class Initialized
INFO - 2018-07-17 05:12:28 --> Security Class Initialized
DEBUG - 2018-07-17 05:12:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 05:12:28 --> Input Class Initialized
INFO - 2018-07-17 05:12:28 --> Language Class Initialized
INFO - 2018-07-17 05:12:28 --> Language Class Initialized
INFO - 2018-07-17 05:12:28 --> Config Class Initialized
INFO - 2018-07-17 05:12:28 --> Loader Class Initialized
DEBUG - 2018-07-17 05:12:28 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-17 05:12:28 --> Helper loaded: url_helper
INFO - 2018-07-17 05:12:28 --> Helper loaded: form_helper
INFO - 2018-07-17 05:12:28 --> Helper loaded: date_helper
INFO - 2018-07-17 05:12:28 --> Helper loaded: util_helper
INFO - 2018-07-17 05:12:28 --> Helper loaded: text_helper
INFO - 2018-07-17 05:12:28 --> Helper loaded: string_helper
INFO - 2018-07-17 05:12:28 --> Database Driver Class Initialized
DEBUG - 2018-07-17 05:12:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-17 05:12:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-17 05:12:28 --> Email Class Initialized
INFO - 2018-07-17 05:12:28 --> Controller Class Initialized
DEBUG - 2018-07-17 05:12:28 --> Users MX_Controller Initialized
DEBUG - 2018-07-17 05:12:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-17 05:12:28 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-17 05:12:28 --> Login MX_Controller Initialized
INFO - 2018-07-17 05:12:28 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-17 05:12:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-17 05:12:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-17 05:12:28 --> Final output sent to browser
DEBUG - 2018-07-17 05:12:28 --> Total execution time: 0.5332
INFO - 2018-07-17 05:12:29 --> Config Class Initialized
INFO - 2018-07-17 05:12:29 --> Hooks Class Initialized
DEBUG - 2018-07-17 05:12:29 --> UTF-8 Support Enabled
INFO - 2018-07-17 05:12:29 --> Utf8 Class Initialized
INFO - 2018-07-17 05:12:29 --> URI Class Initialized
INFO - 2018-07-17 05:12:29 --> Router Class Initialized
INFO - 2018-07-17 05:12:29 --> Output Class Initialized
INFO - 2018-07-17 05:12:29 --> Security Class Initialized
DEBUG - 2018-07-17 05:12:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 05:12:29 --> Input Class Initialized
INFO - 2018-07-17 05:12:29 --> Language Class Initialized
INFO - 2018-07-17 05:12:29 --> Language Class Initialized
INFO - 2018-07-17 05:12:29 --> Config Class Initialized
INFO - 2018-07-17 05:12:29 --> Loader Class Initialized
DEBUG - 2018-07-17 05:12:29 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-17 05:12:29 --> Helper loaded: url_helper
INFO - 2018-07-17 05:12:29 --> Helper loaded: form_helper
INFO - 2018-07-17 05:12:29 --> Helper loaded: date_helper
INFO - 2018-07-17 05:12:29 --> Helper loaded: util_helper
INFO - 2018-07-17 05:12:29 --> Helper loaded: text_helper
INFO - 2018-07-17 05:12:29 --> Helper loaded: string_helper
INFO - 2018-07-17 05:12:29 --> Database Driver Class Initialized
DEBUG - 2018-07-17 05:12:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-17 05:12:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-17 05:12:29 --> Email Class Initialized
INFO - 2018-07-17 05:12:29 --> Controller Class Initialized
DEBUG - 2018-07-17 05:12:29 --> Users MX_Controller Initialized
DEBUG - 2018-07-17 05:12:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-17 05:12:29 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-17 05:12:29 --> Login MX_Controller Initialized
INFO - 2018-07-17 05:12:29 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-17 05:12:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-17 05:12:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-07-17 05:12:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-17 05:12:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-17 05:12:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-17 05:12:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-17 05:12:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-17 05:12:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-07-17 05:12:29 --> Final output sent to browser
DEBUG - 2018-07-17 05:12:30 --> Total execution time: 0.4588
INFO - 2018-07-17 05:50:36 --> Config Class Initialized
INFO - 2018-07-17 05:50:36 --> Hooks Class Initialized
DEBUG - 2018-07-17 05:50:36 --> UTF-8 Support Enabled
INFO - 2018-07-17 05:50:36 --> Utf8 Class Initialized
INFO - 2018-07-17 05:50:36 --> URI Class Initialized
INFO - 2018-07-17 05:50:36 --> Router Class Initialized
INFO - 2018-07-17 05:50:36 --> Output Class Initialized
INFO - 2018-07-17 05:50:36 --> Security Class Initialized
DEBUG - 2018-07-17 05:50:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 05:50:36 --> Input Class Initialized
INFO - 2018-07-17 05:50:36 --> Language Class Initialized
INFO - 2018-07-17 05:50:36 --> Language Class Initialized
INFO - 2018-07-17 05:50:36 --> Config Class Initialized
INFO - 2018-07-17 05:50:36 --> Loader Class Initialized
DEBUG - 2018-07-17 05:50:36 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-17 05:50:36 --> Helper loaded: url_helper
INFO - 2018-07-17 05:50:36 --> Helper loaded: form_helper
INFO - 2018-07-17 05:50:36 --> Helper loaded: date_helper
INFO - 2018-07-17 05:50:36 --> Helper loaded: util_helper
INFO - 2018-07-17 05:50:36 --> Helper loaded: text_helper
INFO - 2018-07-17 05:50:36 --> Helper loaded: string_helper
INFO - 2018-07-17 05:50:36 --> Database Driver Class Initialized
DEBUG - 2018-07-17 05:50:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-17 05:50:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-17 05:50:36 --> Email Class Initialized
INFO - 2018-07-17 05:50:36 --> Controller Class Initialized
DEBUG - 2018-07-17 05:50:36 --> Admin MX_Controller Initialized
INFO - 2018-07-17 05:50:36 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-17 05:50:36 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-17 05:50:36 --> Login MX_Controller Initialized
DEBUG - 2018-07-17 05:50:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-17 05:50:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-17 05:50:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-17 05:50:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-17 05:50:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-17 05:50:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-17 05:50:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-17 05:50:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/dashboard.php
INFO - 2018-07-17 05:50:36 --> Final output sent to browser
DEBUG - 2018-07-17 05:50:36 --> Total execution time: 0.4385
INFO - 2018-07-17 05:50:36 --> Config Class Initialized
INFO - 2018-07-17 05:50:36 --> Hooks Class Initialized
DEBUG - 2018-07-17 05:50:36 --> UTF-8 Support Enabled
INFO - 2018-07-17 05:50:36 --> Utf8 Class Initialized
INFO - 2018-07-17 05:50:36 --> URI Class Initialized
INFO - 2018-07-17 05:50:36 --> Router Class Initialized
INFO - 2018-07-17 05:50:36 --> Output Class Initialized
INFO - 2018-07-17 05:50:36 --> Security Class Initialized
DEBUG - 2018-07-17 05:50:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 05:50:36 --> Config Class Initialized
INFO - 2018-07-17 05:50:36 --> Hooks Class Initialized
INFO - 2018-07-17 05:50:36 --> Input Class Initialized
INFO - 2018-07-17 05:50:36 --> Language Class Initialized
DEBUG - 2018-07-17 05:50:36 --> UTF-8 Support Enabled
INFO - 2018-07-17 05:50:36 --> Utf8 Class Initialized
ERROR - 2018-07-17 05:50:36 --> 404 Page Not Found: /index
INFO - 2018-07-17 05:50:36 --> URI Class Initialized
INFO - 2018-07-17 05:50:36 --> Router Class Initialized
INFO - 2018-07-17 05:50:36 --> Output Class Initialized
INFO - 2018-07-17 05:50:36 --> Security Class Initialized
DEBUG - 2018-07-17 05:50:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 05:50:36 --> Input Class Initialized
INFO - 2018-07-17 05:50:36 --> Language Class Initialized
ERROR - 2018-07-17 05:50:36 --> 404 Page Not Found: /index
INFO - 2018-07-17 05:50:56 --> Config Class Initialized
INFO - 2018-07-17 05:50:56 --> Hooks Class Initialized
DEBUG - 2018-07-17 05:50:56 --> UTF-8 Support Enabled
INFO - 2018-07-17 05:50:56 --> Utf8 Class Initialized
INFO - 2018-07-17 05:50:56 --> URI Class Initialized
INFO - 2018-07-17 05:50:56 --> Router Class Initialized
INFO - 2018-07-17 05:50:56 --> Output Class Initialized
INFO - 2018-07-17 05:50:56 --> Security Class Initialized
DEBUG - 2018-07-17 05:50:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 05:50:56 --> Input Class Initialized
INFO - 2018-07-17 05:50:56 --> Language Class Initialized
INFO - 2018-07-17 05:50:56 --> Language Class Initialized
INFO - 2018-07-17 05:50:56 --> Config Class Initialized
INFO - 2018-07-17 05:50:56 --> Loader Class Initialized
DEBUG - 2018-07-17 05:50:56 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-17 05:50:56 --> Helper loaded: url_helper
INFO - 2018-07-17 05:50:56 --> Helper loaded: form_helper
INFO - 2018-07-17 05:50:56 --> Helper loaded: date_helper
INFO - 2018-07-17 05:50:56 --> Helper loaded: util_helper
INFO - 2018-07-17 05:50:56 --> Helper loaded: text_helper
INFO - 2018-07-17 05:50:56 --> Helper loaded: string_helper
INFO - 2018-07-17 05:50:56 --> Database Driver Class Initialized
DEBUG - 2018-07-17 05:50:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-17 05:50:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-17 05:50:56 --> Email Class Initialized
INFO - 2018-07-17 05:50:56 --> Controller Class Initialized
DEBUG - 2018-07-17 05:50:56 --> Users MX_Controller Initialized
DEBUG - 2018-07-17 05:50:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-17 05:50:56 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-17 05:50:56 --> Login MX_Controller Initialized
INFO - 2018-07-17 05:50:56 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-17 05:50:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-17 05:50:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-17 05:50:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-17 05:50:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-17 05:50:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-17 05:50:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-17 05:50:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-07-17 05:50:56 --> Final output sent to browser
DEBUG - 2018-07-17 05:50:56 --> Total execution time: 0.4376
INFO - 2018-07-17 05:50:57 --> Config Class Initialized
INFO - 2018-07-17 05:50:57 --> Hooks Class Initialized
DEBUG - 2018-07-17 05:50:57 --> UTF-8 Support Enabled
INFO - 2018-07-17 05:50:57 --> Utf8 Class Initialized
INFO - 2018-07-17 05:50:57 --> URI Class Initialized
INFO - 2018-07-17 05:50:57 --> Router Class Initialized
INFO - 2018-07-17 05:50:57 --> Output Class Initialized
INFO - 2018-07-17 05:50:57 --> Security Class Initialized
DEBUG - 2018-07-17 05:50:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 05:50:57 --> Input Class Initialized
INFO - 2018-07-17 05:50:57 --> Language Class Initialized
INFO - 2018-07-17 05:50:57 --> Language Class Initialized
INFO - 2018-07-17 05:50:57 --> Config Class Initialized
INFO - 2018-07-17 05:50:57 --> Loader Class Initialized
DEBUG - 2018-07-17 05:50:57 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-17 05:50:57 --> Helper loaded: url_helper
INFO - 2018-07-17 05:50:57 --> Helper loaded: form_helper
INFO - 2018-07-17 05:50:57 --> Helper loaded: date_helper
INFO - 2018-07-17 05:50:57 --> Helper loaded: util_helper
INFO - 2018-07-17 05:50:57 --> Helper loaded: text_helper
INFO - 2018-07-17 05:50:57 --> Helper loaded: string_helper
INFO - 2018-07-17 05:50:57 --> Database Driver Class Initialized
DEBUG - 2018-07-17 05:50:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-17 05:50:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-17 05:50:57 --> Email Class Initialized
INFO - 2018-07-17 05:50:57 --> Controller Class Initialized
DEBUG - 2018-07-17 05:50:57 --> Users MX_Controller Initialized
DEBUG - 2018-07-17 05:50:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-17 05:50:57 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-17 05:50:57 --> Login MX_Controller Initialized
INFO - 2018-07-17 05:50:57 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-17 05:50:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-17 05:50:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-17 05:50:57 --> Final output sent to browser
DEBUG - 2018-07-17 05:50:57 --> Total execution time: 0.4974
INFO - 2018-07-17 05:51:58 --> Config Class Initialized
INFO - 2018-07-17 05:51:58 --> Hooks Class Initialized
DEBUG - 2018-07-17 05:51:58 --> UTF-8 Support Enabled
INFO - 2018-07-17 05:51:58 --> Utf8 Class Initialized
INFO - 2018-07-17 05:51:58 --> URI Class Initialized
INFO - 2018-07-17 05:51:58 --> Router Class Initialized
INFO - 2018-07-17 05:51:58 --> Output Class Initialized
INFO - 2018-07-17 05:51:58 --> Security Class Initialized
DEBUG - 2018-07-17 05:51:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 05:51:58 --> Input Class Initialized
INFO - 2018-07-17 05:51:58 --> Language Class Initialized
INFO - 2018-07-17 05:51:58 --> Language Class Initialized
INFO - 2018-07-17 05:51:58 --> Config Class Initialized
INFO - 2018-07-17 05:51:58 --> Loader Class Initialized
DEBUG - 2018-07-17 05:51:58 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-17 05:51:58 --> Helper loaded: url_helper
INFO - 2018-07-17 05:51:58 --> Helper loaded: form_helper
INFO - 2018-07-17 05:51:58 --> Helper loaded: date_helper
INFO - 2018-07-17 05:51:58 --> Helper loaded: util_helper
INFO - 2018-07-17 05:51:58 --> Helper loaded: text_helper
INFO - 2018-07-17 05:51:58 --> Helper loaded: string_helper
INFO - 2018-07-17 05:51:58 --> Database Driver Class Initialized
DEBUG - 2018-07-17 05:51:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-17 05:51:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-17 05:51:58 --> Email Class Initialized
INFO - 2018-07-17 05:51:58 --> Controller Class Initialized
DEBUG - 2018-07-17 05:51:58 --> Admin MX_Controller Initialized
INFO - 2018-07-17 05:51:58 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-17 05:51:58 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-17 05:51:58 --> Login MX_Controller Initialized
DEBUG - 2018-07-17 05:51:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-17 05:51:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-17 05:51:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-17 05:51:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-17 05:51:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-17 05:51:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-17 05:51:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-17 05:51:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/dashboard.php
INFO - 2018-07-17 05:51:58 --> Final output sent to browser
INFO - 2018-07-17 05:51:58 --> Config Class Initialized
DEBUG - 2018-07-17 05:51:58 --> Total execution time: 0.4335
INFO - 2018-07-17 05:51:58 --> Hooks Class Initialized
DEBUG - 2018-07-17 05:51:58 --> UTF-8 Support Enabled
INFO - 2018-07-17 05:51:58 --> Utf8 Class Initialized
INFO - 2018-07-17 05:51:58 --> URI Class Initialized
INFO - 2018-07-17 05:51:58 --> Router Class Initialized
INFO - 2018-07-17 05:51:58 --> Output Class Initialized
INFO - 2018-07-17 05:51:58 --> Config Class Initialized
INFO - 2018-07-17 05:51:58 --> Hooks Class Initialized
INFO - 2018-07-17 05:51:58 --> Security Class Initialized
DEBUG - 2018-07-17 05:51:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-07-17 05:51:58 --> UTF-8 Support Enabled
INFO - 2018-07-17 05:51:58 --> Utf8 Class Initialized
INFO - 2018-07-17 05:51:58 --> Input Class Initialized
INFO - 2018-07-17 05:51:58 --> Language Class Initialized
INFO - 2018-07-17 05:51:58 --> URI Class Initialized
ERROR - 2018-07-17 05:51:58 --> 404 Page Not Found: /index
INFO - 2018-07-17 05:51:58 --> Router Class Initialized
INFO - 2018-07-17 05:51:58 --> Output Class Initialized
INFO - 2018-07-17 05:51:58 --> Security Class Initialized
DEBUG - 2018-07-17 05:51:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 05:51:58 --> Input Class Initialized
INFO - 2018-07-17 05:51:58 --> Language Class Initialized
ERROR - 2018-07-17 05:51:59 --> 404 Page Not Found: /index
INFO - 2018-07-17 21:31:50 --> Config Class Initialized
INFO - 2018-07-17 21:31:50 --> Hooks Class Initialized
DEBUG - 2018-07-17 21:31:50 --> UTF-8 Support Enabled
INFO - 2018-07-17 21:31:50 --> Utf8 Class Initialized
INFO - 2018-07-17 21:31:50 --> URI Class Initialized
INFO - 2018-07-17 21:31:50 --> Router Class Initialized
INFO - 2018-07-17 21:31:50 --> Output Class Initialized
INFO - 2018-07-17 21:31:50 --> Security Class Initialized
DEBUG - 2018-07-17 21:31:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 21:31:50 --> Input Class Initialized
INFO - 2018-07-17 21:31:50 --> Language Class Initialized
INFO - 2018-07-17 21:31:50 --> Language Class Initialized
INFO - 2018-07-17 21:31:50 --> Config Class Initialized
INFO - 2018-07-17 21:31:50 --> Loader Class Initialized
DEBUG - 2018-07-17 21:31:50 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-17 21:31:50 --> Helper loaded: url_helper
INFO - 2018-07-17 21:31:50 --> Helper loaded: form_helper
INFO - 2018-07-17 21:31:50 --> Helper loaded: date_helper
INFO - 2018-07-17 21:31:50 --> Helper loaded: util_helper
INFO - 2018-07-17 21:31:50 --> Helper loaded: text_helper
INFO - 2018-07-17 21:31:50 --> Helper loaded: string_helper
INFO - 2018-07-17 21:31:50 --> Database Driver Class Initialized
DEBUG - 2018-07-17 21:31:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-17 21:31:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-17 21:31:50 --> Email Class Initialized
INFO - 2018-07-17 21:31:50 --> Controller Class Initialized
DEBUG - 2018-07-17 21:31:50 --> Home MX_Controller Initialized
DEBUG - 2018-07-17 21:31:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-17 21:31:50 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-17 21:31:50 --> Login MX_Controller Initialized
INFO - 2018-07-17 21:31:50 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-17 21:31:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-17 21:31:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-17 21:31:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-07-17 21:31:53 --> Config Class Initialized
INFO - 2018-07-17 21:31:53 --> Hooks Class Initialized
DEBUG - 2018-07-17 21:31:53 --> UTF-8 Support Enabled
INFO - 2018-07-17 21:31:53 --> Utf8 Class Initialized
INFO - 2018-07-17 21:31:53 --> URI Class Initialized
INFO - 2018-07-17 21:31:53 --> Router Class Initialized
INFO - 2018-07-17 21:31:53 --> Output Class Initialized
INFO - 2018-07-17 21:31:53 --> Security Class Initialized
DEBUG - 2018-07-17 21:31:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 21:31:53 --> Input Class Initialized
INFO - 2018-07-17 21:31:53 --> Language Class Initialized
INFO - 2018-07-17 21:31:53 --> Language Class Initialized
INFO - 2018-07-17 21:31:53 --> Config Class Initialized
INFO - 2018-07-17 21:31:53 --> Loader Class Initialized
DEBUG - 2018-07-17 21:31:53 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-17 21:31:53 --> Helper loaded: url_helper
INFO - 2018-07-17 21:31:53 --> Helper loaded: form_helper
INFO - 2018-07-17 21:31:53 --> Helper loaded: date_helper
INFO - 2018-07-17 21:31:53 --> Helper loaded: util_helper
INFO - 2018-07-17 21:31:53 --> Helper loaded: text_helper
INFO - 2018-07-17 21:31:53 --> Helper loaded: string_helper
INFO - 2018-07-17 21:31:53 --> Database Driver Class Initialized
DEBUG - 2018-07-17 21:31:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-17 21:31:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-17 21:31:53 --> Email Class Initialized
INFO - 2018-07-17 21:31:53 --> Controller Class Initialized
DEBUG - 2018-07-17 21:31:53 --> Login MX_Controller Initialized
INFO - 2018-07-17 21:31:53 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-17 21:31:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-17 21:31:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-17 21:31:54 --> Email starts for gopipanguluri123@gmail.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-07-17 21:31:54 --> Login status gopipanguluri123@gmail.com - failure
INFO - 2018-07-17 21:31:54 --> Final output sent to browser
DEBUG - 2018-07-17 21:31:54 --> Total execution time: 0.4026
INFO - 2018-07-17 21:31:58 --> Config Class Initialized
INFO - 2018-07-17 21:31:58 --> Hooks Class Initialized
DEBUG - 2018-07-17 21:31:58 --> UTF-8 Support Enabled
INFO - 2018-07-17 21:31:58 --> Utf8 Class Initialized
INFO - 2018-07-17 21:31:58 --> URI Class Initialized
INFO - 2018-07-17 21:31:58 --> Router Class Initialized
INFO - 2018-07-17 21:31:58 --> Output Class Initialized
INFO - 2018-07-17 21:31:58 --> Security Class Initialized
DEBUG - 2018-07-17 21:31:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 21:31:59 --> Input Class Initialized
INFO - 2018-07-17 21:31:59 --> Language Class Initialized
INFO - 2018-07-17 21:31:59 --> Language Class Initialized
INFO - 2018-07-17 21:31:59 --> Config Class Initialized
INFO - 2018-07-17 21:31:59 --> Loader Class Initialized
DEBUG - 2018-07-17 21:31:59 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-17 21:31:59 --> Helper loaded: url_helper
INFO - 2018-07-17 21:31:59 --> Helper loaded: form_helper
INFO - 2018-07-17 21:31:59 --> Helper loaded: date_helper
INFO - 2018-07-17 21:31:59 --> Helper loaded: util_helper
INFO - 2018-07-17 21:31:59 --> Helper loaded: text_helper
INFO - 2018-07-17 21:31:59 --> Helper loaded: string_helper
INFO - 2018-07-17 21:31:59 --> Database Driver Class Initialized
DEBUG - 2018-07-17 21:31:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-17 21:31:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-17 21:31:59 --> Email Class Initialized
INFO - 2018-07-17 21:31:59 --> Controller Class Initialized
DEBUG - 2018-07-17 21:31:59 --> Login MX_Controller Initialized
INFO - 2018-07-17 21:31:59 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-17 21:31:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-17 21:31:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-17 21:31:59 --> Email starts for user@colin.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-07-17 21:31:59 --> User session created for 4
INFO - 2018-07-17 21:31:59 --> Login status user@colin.com - success
INFO - 2018-07-17 21:31:59 --> Final output sent to browser
DEBUG - 2018-07-17 21:31:59 --> Total execution time: 0.4144
INFO - 2018-07-17 21:31:59 --> Config Class Initialized
INFO - 2018-07-17 21:31:59 --> Hooks Class Initialized
DEBUG - 2018-07-17 21:31:59 --> UTF-8 Support Enabled
INFO - 2018-07-17 21:31:59 --> Utf8 Class Initialized
INFO - 2018-07-17 21:31:59 --> URI Class Initialized
INFO - 2018-07-17 21:31:59 --> Router Class Initialized
INFO - 2018-07-17 21:31:59 --> Output Class Initialized
INFO - 2018-07-17 21:31:59 --> Security Class Initialized
DEBUG - 2018-07-17 21:31:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 21:31:59 --> Input Class Initialized
INFO - 2018-07-17 21:31:59 --> Language Class Initialized
INFO - 2018-07-17 21:31:59 --> Language Class Initialized
INFO - 2018-07-17 21:31:59 --> Config Class Initialized
INFO - 2018-07-17 21:31:59 --> Loader Class Initialized
DEBUG - 2018-07-17 21:31:59 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-17 21:31:59 --> Helper loaded: url_helper
INFO - 2018-07-17 21:31:59 --> Helper loaded: form_helper
INFO - 2018-07-17 21:31:59 --> Helper loaded: date_helper
INFO - 2018-07-17 21:31:59 --> Helper loaded: util_helper
INFO - 2018-07-17 21:31:59 --> Helper loaded: text_helper
INFO - 2018-07-17 21:31:59 --> Helper loaded: string_helper
INFO - 2018-07-17 21:31:59 --> Database Driver Class Initialized
DEBUG - 2018-07-17 21:31:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-17 21:31:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-17 21:31:59 --> Email Class Initialized
INFO - 2018-07-17 21:31:59 --> Controller Class Initialized
DEBUG - 2018-07-17 21:31:59 --> Home MX_Controller Initialized
DEBUG - 2018-07-17 21:31:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-17 21:31:59 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-17 21:31:59 --> Login MX_Controller Initialized
INFO - 2018-07-17 21:31:59 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-17 21:31:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-17 21:31:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-17 21:32:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-17 21:32:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-17 21:32:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-17 21:32:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-17 21:32:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-17 21:32:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-07-17 21:32:00 --> Final output sent to browser
DEBUG - 2018-07-17 21:32:00 --> Total execution time: 0.7931
INFO - 2018-07-17 21:32:01 --> Config Class Initialized
INFO - 2018-07-17 21:32:01 --> Hooks Class Initialized
INFO - 2018-07-17 21:32:01 --> Config Class Initialized
INFO - 2018-07-17 21:32:01 --> Hooks Class Initialized
DEBUG - 2018-07-17 21:32:01 --> UTF-8 Support Enabled
INFO - 2018-07-17 21:32:01 --> Utf8 Class Initialized
DEBUG - 2018-07-17 21:32:01 --> UTF-8 Support Enabled
INFO - 2018-07-17 21:32:01 --> Utf8 Class Initialized
INFO - 2018-07-17 21:32:01 --> URI Class Initialized
INFO - 2018-07-17 21:32:01 --> URI Class Initialized
INFO - 2018-07-17 21:32:01 --> Router Class Initialized
INFO - 2018-07-17 21:32:01 --> Output Class Initialized
INFO - 2018-07-17 21:32:01 --> Router Class Initialized
INFO - 2018-07-17 21:32:01 --> Output Class Initialized
INFO - 2018-07-17 21:32:01 --> Security Class Initialized
INFO - 2018-07-17 21:32:01 --> Security Class Initialized
DEBUG - 2018-07-17 21:32:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 21:32:01 --> Input Class Initialized
INFO - 2018-07-17 21:32:01 --> Language Class Initialized
DEBUG - 2018-07-17 21:32:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 21:32:01 --> Input Class Initialized
ERROR - 2018-07-17 21:32:01 --> 404 Page Not Found: /index
INFO - 2018-07-17 21:32:01 --> Language Class Initialized
ERROR - 2018-07-17 21:32:01 --> 404 Page Not Found: /index
INFO - 2018-07-17 21:32:01 --> Config Class Initialized
INFO - 2018-07-17 21:32:01 --> Hooks Class Initialized
DEBUG - 2018-07-17 21:32:01 --> UTF-8 Support Enabled
INFO - 2018-07-17 21:32:01 --> Utf8 Class Initialized
INFO - 2018-07-17 21:32:01 --> URI Class Initialized
INFO - 2018-07-17 21:32:01 --> Router Class Initialized
INFO - 2018-07-17 21:32:01 --> Output Class Initialized
INFO - 2018-07-17 21:32:01 --> Security Class Initialized
DEBUG - 2018-07-17 21:32:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 21:32:01 --> Input Class Initialized
INFO - 2018-07-17 21:32:01 --> Language Class Initialized
ERROR - 2018-07-17 21:32:01 --> 404 Page Not Found: /index
INFO - 2018-07-17 21:32:01 --> Config Class Initialized
INFO - 2018-07-17 21:32:02 --> Hooks Class Initialized
DEBUG - 2018-07-17 21:32:02 --> UTF-8 Support Enabled
INFO - 2018-07-17 21:32:02 --> Utf8 Class Initialized
INFO - 2018-07-17 21:32:02 --> URI Class Initialized
INFO - 2018-07-17 21:32:02 --> Router Class Initialized
INFO - 2018-07-17 21:32:02 --> Output Class Initialized
INFO - 2018-07-17 21:32:02 --> Security Class Initialized
DEBUG - 2018-07-17 21:32:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 21:32:02 --> Input Class Initialized
INFO - 2018-07-17 21:32:02 --> Language Class Initialized
ERROR - 2018-07-17 21:32:02 --> 404 Page Not Found: /index
INFO - 2018-07-17 21:32:02 --> Config Class Initialized
INFO - 2018-07-17 21:32:02 --> Hooks Class Initialized
DEBUG - 2018-07-17 21:32:02 --> UTF-8 Support Enabled
INFO - 2018-07-17 21:32:02 --> Utf8 Class Initialized
INFO - 2018-07-17 21:32:02 --> URI Class Initialized
INFO - 2018-07-17 21:32:02 --> Router Class Initialized
INFO - 2018-07-17 21:32:02 --> Output Class Initialized
INFO - 2018-07-17 21:32:02 --> Security Class Initialized
DEBUG - 2018-07-17 21:32:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 21:32:02 --> Input Class Initialized
INFO - 2018-07-17 21:32:02 --> Language Class Initialized
ERROR - 2018-07-17 21:32:02 --> 404 Page Not Found: /index
INFO - 2018-07-17 21:32:02 --> Config Class Initialized
INFO - 2018-07-17 21:32:02 --> Hooks Class Initialized
DEBUG - 2018-07-17 21:32:02 --> UTF-8 Support Enabled
INFO - 2018-07-17 21:32:02 --> Utf8 Class Initialized
INFO - 2018-07-17 21:32:02 --> URI Class Initialized
INFO - 2018-07-17 21:32:02 --> Router Class Initialized
INFO - 2018-07-17 21:32:02 --> Output Class Initialized
INFO - 2018-07-17 21:32:02 --> Security Class Initialized
DEBUG - 2018-07-17 21:32:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 21:32:02 --> Input Class Initialized
INFO - 2018-07-17 21:32:02 --> Language Class Initialized
ERROR - 2018-07-17 21:32:02 --> 404 Page Not Found: /index
INFO - 2018-07-17 21:32:02 --> Config Class Initialized
INFO - 2018-07-17 21:32:02 --> Hooks Class Initialized
DEBUG - 2018-07-17 21:32:02 --> UTF-8 Support Enabled
INFO - 2018-07-17 21:32:02 --> Utf8 Class Initialized
INFO - 2018-07-17 21:32:02 --> URI Class Initialized
INFO - 2018-07-17 21:32:02 --> Router Class Initialized
INFO - 2018-07-17 21:32:02 --> Output Class Initialized
INFO - 2018-07-17 21:32:02 --> Security Class Initialized
DEBUG - 2018-07-17 21:32:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 21:32:02 --> Input Class Initialized
INFO - 2018-07-17 21:32:02 --> Language Class Initialized
ERROR - 2018-07-17 21:32:02 --> 404 Page Not Found: /index
INFO - 2018-07-17 21:32:13 --> Config Class Initialized
INFO - 2018-07-17 21:32:13 --> Hooks Class Initialized
DEBUG - 2018-07-17 21:32:13 --> UTF-8 Support Enabled
INFO - 2018-07-17 21:32:13 --> Utf8 Class Initialized
INFO - 2018-07-17 21:32:13 --> URI Class Initialized
INFO - 2018-07-17 21:32:13 --> Router Class Initialized
INFO - 2018-07-17 21:32:13 --> Output Class Initialized
INFO - 2018-07-17 21:32:13 --> Security Class Initialized
DEBUG - 2018-07-17 21:32:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 21:32:13 --> Input Class Initialized
INFO - 2018-07-17 21:32:13 --> Language Class Initialized
INFO - 2018-07-17 21:32:13 --> Language Class Initialized
INFO - 2018-07-17 21:32:13 --> Config Class Initialized
INFO - 2018-07-17 21:32:13 --> Loader Class Initialized
DEBUG - 2018-07-17 21:32:13 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-17 21:32:13 --> Helper loaded: url_helper
INFO - 2018-07-17 21:32:13 --> Helper loaded: form_helper
INFO - 2018-07-17 21:32:13 --> Helper loaded: date_helper
INFO - 2018-07-17 21:32:13 --> Helper loaded: util_helper
INFO - 2018-07-17 21:32:14 --> Helper loaded: text_helper
INFO - 2018-07-17 21:32:14 --> Helper loaded: string_helper
INFO - 2018-07-17 21:32:14 --> Database Driver Class Initialized
DEBUG - 2018-07-17 21:32:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-17 21:32:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-17 21:32:14 --> Email Class Initialized
INFO - 2018-07-17 21:32:14 --> Controller Class Initialized
DEBUG - 2018-07-17 21:32:14 --> Home MX_Controller Initialized
DEBUG - 2018-07-17 21:32:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-17 21:32:14 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-17 21:32:14 --> Login MX_Controller Initialized
INFO - 2018-07-17 21:32:14 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-17 21:32:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-17 21:32:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-17 21:32:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-17 21:32:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-17 21:32:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-17 21:32:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-17 21:32:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-17 21:32:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-07-17 21:32:14 --> Final output sent to browser
DEBUG - 2018-07-17 21:32:14 --> Total execution time: 0.4429
INFO - 2018-07-17 21:32:14 --> Config Class Initialized
INFO - 2018-07-17 21:32:14 --> Config Class Initialized
INFO - 2018-07-17 21:32:14 --> Hooks Class Initialized
INFO - 2018-07-17 21:32:14 --> Hooks Class Initialized
DEBUG - 2018-07-17 21:32:14 --> UTF-8 Support Enabled
INFO - 2018-07-17 21:32:14 --> Utf8 Class Initialized
INFO - 2018-07-17 21:32:14 --> URI Class Initialized
DEBUG - 2018-07-17 21:32:14 --> UTF-8 Support Enabled
INFO - 2018-07-17 21:32:14 --> Utf8 Class Initialized
INFO - 2018-07-17 21:32:14 --> Router Class Initialized
INFO - 2018-07-17 21:32:14 --> URI Class Initialized
INFO - 2018-07-17 21:32:14 --> Output Class Initialized
INFO - 2018-07-17 21:32:14 --> Security Class Initialized
INFO - 2018-07-17 21:32:14 --> Router Class Initialized
DEBUG - 2018-07-17 21:32:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 21:32:14 --> Output Class Initialized
INFO - 2018-07-17 21:32:14 --> Input Class Initialized
INFO - 2018-07-17 21:32:15 --> Language Class Initialized
INFO - 2018-07-17 21:32:15 --> Security Class Initialized
ERROR - 2018-07-17 21:32:15 --> 404 Page Not Found: /index
DEBUG - 2018-07-17 21:32:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 21:32:15 --> Input Class Initialized
INFO - 2018-07-17 21:32:15 --> Config Class Initialized
INFO - 2018-07-17 21:32:15 --> Hooks Class Initialized
INFO - 2018-07-17 21:32:15 --> Language Class Initialized
ERROR - 2018-07-17 21:32:15 --> 404 Page Not Found: /index
DEBUG - 2018-07-17 21:32:15 --> UTF-8 Support Enabled
INFO - 2018-07-17 21:32:15 --> Utf8 Class Initialized
INFO - 2018-07-17 21:32:15 --> URI Class Initialized
INFO - 2018-07-17 21:32:15 --> Router Class Initialized
INFO - 2018-07-17 21:32:15 --> Output Class Initialized
INFO - 2018-07-17 21:32:15 --> Security Class Initialized
DEBUG - 2018-07-17 21:32:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 21:32:15 --> Input Class Initialized
INFO - 2018-07-17 21:32:15 --> Language Class Initialized
ERROR - 2018-07-17 21:32:15 --> 404 Page Not Found: /index
INFO - 2018-07-17 21:32:15 --> Config Class Initialized
INFO - 2018-07-17 21:32:15 --> Hooks Class Initialized
DEBUG - 2018-07-17 21:32:15 --> UTF-8 Support Enabled
INFO - 2018-07-17 21:32:15 --> Utf8 Class Initialized
INFO - 2018-07-17 21:32:15 --> URI Class Initialized
INFO - 2018-07-17 21:32:15 --> Router Class Initialized
INFO - 2018-07-17 21:32:15 --> Output Class Initialized
INFO - 2018-07-17 21:32:15 --> Security Class Initialized
DEBUG - 2018-07-17 21:32:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 21:32:15 --> Input Class Initialized
INFO - 2018-07-17 21:32:15 --> Language Class Initialized
ERROR - 2018-07-17 21:32:15 --> 404 Page Not Found: /index
INFO - 2018-07-17 21:32:18 --> Config Class Initialized
INFO - 2018-07-17 21:32:18 --> Hooks Class Initialized
DEBUG - 2018-07-17 21:32:18 --> UTF-8 Support Enabled
INFO - 2018-07-17 21:32:18 --> Utf8 Class Initialized
INFO - 2018-07-17 21:32:18 --> URI Class Initialized
INFO - 2018-07-17 21:32:18 --> Router Class Initialized
INFO - 2018-07-17 21:32:19 --> Output Class Initialized
INFO - 2018-07-17 21:32:19 --> Security Class Initialized
DEBUG - 2018-07-17 21:32:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 21:32:19 --> Input Class Initialized
INFO - 2018-07-17 21:32:19 --> Language Class Initialized
INFO - 2018-07-17 21:32:19 --> Language Class Initialized
INFO - 2018-07-17 21:32:19 --> Config Class Initialized
INFO - 2018-07-17 21:32:19 --> Loader Class Initialized
DEBUG - 2018-07-17 21:32:19 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-17 21:32:19 --> Helper loaded: url_helper
INFO - 2018-07-17 21:32:19 --> Helper loaded: form_helper
INFO - 2018-07-17 21:32:19 --> Helper loaded: date_helper
INFO - 2018-07-17 21:32:19 --> Helper loaded: util_helper
INFO - 2018-07-17 21:32:19 --> Helper loaded: text_helper
INFO - 2018-07-17 21:32:19 --> Helper loaded: string_helper
INFO - 2018-07-17 21:32:19 --> Database Driver Class Initialized
DEBUG - 2018-07-17 21:32:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-17 21:32:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-17 21:32:19 --> Email Class Initialized
INFO - 2018-07-17 21:32:19 --> Controller Class Initialized
DEBUG - 2018-07-17 21:32:19 --> Home MX_Controller Initialized
DEBUG - 2018-07-17 21:32:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-17 21:32:19 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-17 21:32:19 --> Login MX_Controller Initialized
INFO - 2018-07-17 21:32:19 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-17 21:32:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-17 21:32:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-17 21:32:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-17 21:32:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-17 21:32:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-17 21:32:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-17 21:32:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-17 21:32:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-07-17 21:32:19 --> Final output sent to browser
DEBUG - 2018-07-17 21:32:19 --> Total execution time: 0.4632
INFO - 2018-07-17 21:32:19 --> Config Class Initialized
INFO - 2018-07-17 21:32:19 --> Config Class Initialized
INFO - 2018-07-17 21:32:19 --> Hooks Class Initialized
INFO - 2018-07-17 21:32:19 --> Hooks Class Initialized
DEBUG - 2018-07-17 21:32:19 --> UTF-8 Support Enabled
DEBUG - 2018-07-17 21:32:19 --> UTF-8 Support Enabled
INFO - 2018-07-17 21:32:19 --> Utf8 Class Initialized
INFO - 2018-07-17 21:32:19 --> URI Class Initialized
INFO - 2018-07-17 21:32:19 --> Router Class Initialized
INFO - 2018-07-17 21:32:20 --> Output Class Initialized
INFO - 2018-07-17 21:32:20 --> Utf8 Class Initialized
INFO - 2018-07-17 21:32:20 --> Security Class Initialized
DEBUG - 2018-07-17 21:32:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 21:32:20 --> URI Class Initialized
INFO - 2018-07-17 21:32:20 --> Input Class Initialized
INFO - 2018-07-17 21:32:20 --> Language Class Initialized
ERROR - 2018-07-17 21:32:20 --> 404 Page Not Found: /index
INFO - 2018-07-17 21:32:20 --> Router Class Initialized
INFO - 2018-07-17 21:32:20 --> Output Class Initialized
INFO - 2018-07-17 21:32:20 --> Config Class Initialized
INFO - 2018-07-17 21:32:20 --> Hooks Class Initialized
INFO - 2018-07-17 21:32:20 --> Security Class Initialized
DEBUG - 2018-07-17 21:32:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-07-17 21:32:20 --> UTF-8 Support Enabled
INFO - 2018-07-17 21:32:20 --> Utf8 Class Initialized
INFO - 2018-07-17 21:32:20 --> Input Class Initialized
INFO - 2018-07-17 21:32:20 --> URI Class Initialized
INFO - 2018-07-17 21:32:20 --> Language Class Initialized
INFO - 2018-07-17 21:32:20 --> Router Class Initialized
ERROR - 2018-07-17 21:32:20 --> 404 Page Not Found: /index
INFO - 2018-07-17 21:32:20 --> Output Class Initialized
INFO - 2018-07-17 21:32:20 --> Security Class Initialized
DEBUG - 2018-07-17 21:32:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 21:32:20 --> Input Class Initialized
INFO - 2018-07-17 21:32:20 --> Language Class Initialized
ERROR - 2018-07-17 21:32:20 --> 404 Page Not Found: /index
INFO - 2018-07-17 21:32:20 --> Config Class Initialized
INFO - 2018-07-17 21:32:20 --> Hooks Class Initialized
DEBUG - 2018-07-17 21:32:20 --> UTF-8 Support Enabled
INFO - 2018-07-17 21:32:20 --> Utf8 Class Initialized
INFO - 2018-07-17 21:32:20 --> URI Class Initialized
INFO - 2018-07-17 21:32:20 --> Router Class Initialized
INFO - 2018-07-17 21:32:20 --> Output Class Initialized
INFO - 2018-07-17 21:32:20 --> Security Class Initialized
DEBUG - 2018-07-17 21:32:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 21:32:20 --> Input Class Initialized
INFO - 2018-07-17 21:32:20 --> Language Class Initialized
ERROR - 2018-07-17 21:32:20 --> 404 Page Not Found: /index
INFO - 2018-07-17 21:37:25 --> Config Class Initialized
INFO - 2018-07-17 21:37:25 --> Hooks Class Initialized
DEBUG - 2018-07-17 21:37:25 --> UTF-8 Support Enabled
INFO - 2018-07-17 21:37:25 --> Utf8 Class Initialized
INFO - 2018-07-17 21:37:25 --> URI Class Initialized
INFO - 2018-07-17 21:37:25 --> Router Class Initialized
INFO - 2018-07-17 21:37:25 --> Output Class Initialized
INFO - 2018-07-17 21:37:25 --> Security Class Initialized
DEBUG - 2018-07-17 21:37:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 21:37:25 --> Input Class Initialized
INFO - 2018-07-17 21:37:25 --> Language Class Initialized
INFO - 2018-07-17 21:37:25 --> Language Class Initialized
INFO - 2018-07-17 21:37:25 --> Config Class Initialized
INFO - 2018-07-17 21:37:25 --> Loader Class Initialized
DEBUG - 2018-07-17 21:37:25 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-17 21:37:25 --> Helper loaded: url_helper
INFO - 2018-07-17 21:37:25 --> Helper loaded: form_helper
INFO - 2018-07-17 21:37:25 --> Helper loaded: date_helper
INFO - 2018-07-17 21:37:25 --> Helper loaded: util_helper
INFO - 2018-07-17 21:37:25 --> Helper loaded: text_helper
INFO - 2018-07-17 21:37:25 --> Helper loaded: string_helper
INFO - 2018-07-17 21:37:25 --> Database Driver Class Initialized
DEBUG - 2018-07-17 21:37:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-17 21:37:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-17 21:37:25 --> Email Class Initialized
INFO - 2018-07-17 21:37:25 --> Controller Class Initialized
DEBUG - 2018-07-17 21:37:25 --> Home MX_Controller Initialized
DEBUG - 2018-07-17 21:37:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-17 21:37:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-17 21:37:25 --> Final output sent to browser
DEBUG - 2018-07-17 21:37:25 --> Total execution time: 0.3700
INFO - 2018-07-17 21:37:25 --> Config Class Initialized
INFO - 2018-07-17 21:37:25 --> Hooks Class Initialized
DEBUG - 2018-07-17 21:37:25 --> UTF-8 Support Enabled
INFO - 2018-07-17 21:37:25 --> Utf8 Class Initialized
INFO - 2018-07-17 21:37:25 --> URI Class Initialized
INFO - 2018-07-17 21:37:25 --> Router Class Initialized
INFO - 2018-07-17 21:37:25 --> Output Class Initialized
INFO - 2018-07-17 21:37:25 --> Security Class Initialized
DEBUG - 2018-07-17 21:37:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 21:37:25 --> Input Class Initialized
INFO - 2018-07-17 21:37:25 --> Language Class Initialized
INFO - 2018-07-17 21:37:25 --> Language Class Initialized
INFO - 2018-07-17 21:37:26 --> Config Class Initialized
INFO - 2018-07-17 21:37:26 --> Loader Class Initialized
DEBUG - 2018-07-17 21:37:26 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-17 21:37:26 --> Helper loaded: url_helper
INFO - 2018-07-17 21:37:26 --> Helper loaded: form_helper
INFO - 2018-07-17 21:37:26 --> Helper loaded: date_helper
INFO - 2018-07-17 21:37:26 --> Helper loaded: util_helper
INFO - 2018-07-17 21:37:26 --> Helper loaded: text_helper
INFO - 2018-07-17 21:37:26 --> Helper loaded: string_helper
INFO - 2018-07-17 21:37:26 --> Database Driver Class Initialized
DEBUG - 2018-07-17 21:37:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-17 21:37:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-17 21:37:26 --> Email Class Initialized
INFO - 2018-07-17 21:37:26 --> Controller Class Initialized
DEBUG - 2018-07-17 21:37:26 --> Home MX_Controller Initialized
DEBUG - 2018-07-17 21:37:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-07-17 21:38:11 --> Config Class Initialized
INFO - 2018-07-17 21:38:11 --> Hooks Class Initialized
DEBUG - 2018-07-17 21:38:11 --> UTF-8 Support Enabled
INFO - 2018-07-17 21:38:11 --> Utf8 Class Initialized
INFO - 2018-07-17 21:38:11 --> URI Class Initialized
INFO - 2018-07-17 21:38:11 --> Router Class Initialized
INFO - 2018-07-17 21:38:11 --> Output Class Initialized
INFO - 2018-07-17 21:38:11 --> Security Class Initialized
DEBUG - 2018-07-17 21:38:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 21:38:12 --> Input Class Initialized
INFO - 2018-07-17 21:38:12 --> Language Class Initialized
INFO - 2018-07-17 21:38:12 --> Language Class Initialized
INFO - 2018-07-17 21:38:12 --> Config Class Initialized
INFO - 2018-07-17 21:38:12 --> Loader Class Initialized
DEBUG - 2018-07-17 21:38:12 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-17 21:38:12 --> Helper loaded: url_helper
INFO - 2018-07-17 21:38:12 --> Helper loaded: form_helper
INFO - 2018-07-17 21:38:12 --> Helper loaded: date_helper
INFO - 2018-07-17 21:38:12 --> Helper loaded: util_helper
INFO - 2018-07-17 21:38:12 --> Helper loaded: text_helper
INFO - 2018-07-17 21:38:12 --> Helper loaded: string_helper
INFO - 2018-07-17 21:38:12 --> Database Driver Class Initialized
DEBUG - 2018-07-17 21:38:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-17 21:38:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-17 21:38:12 --> Email Class Initialized
INFO - 2018-07-17 21:38:12 --> Controller Class Initialized
DEBUG - 2018-07-17 21:38:12 --> Home MX_Controller Initialized
DEBUG - 2018-07-17 21:38:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-17 21:38:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-17 21:38:12 --> Final output sent to browser
DEBUG - 2018-07-17 21:38:12 --> Total execution time: 0.3841
INFO - 2018-07-17 21:38:12 --> Config Class Initialized
INFO - 2018-07-17 21:38:12 --> Hooks Class Initialized
DEBUG - 2018-07-17 21:38:12 --> UTF-8 Support Enabled
INFO - 2018-07-17 21:38:12 --> Utf8 Class Initialized
INFO - 2018-07-17 21:38:12 --> URI Class Initialized
INFO - 2018-07-17 21:38:12 --> Router Class Initialized
INFO - 2018-07-17 21:38:12 --> Output Class Initialized
INFO - 2018-07-17 21:38:12 --> Security Class Initialized
DEBUG - 2018-07-17 21:38:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 21:38:12 --> Input Class Initialized
INFO - 2018-07-17 21:38:12 --> Language Class Initialized
INFO - 2018-07-17 21:38:12 --> Language Class Initialized
INFO - 2018-07-17 21:38:12 --> Config Class Initialized
INFO - 2018-07-17 21:38:12 --> Loader Class Initialized
DEBUG - 2018-07-17 21:38:12 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-17 21:38:12 --> Helper loaded: url_helper
INFO - 2018-07-17 21:38:12 --> Helper loaded: form_helper
INFO - 2018-07-17 21:38:12 --> Helper loaded: date_helper
INFO - 2018-07-17 21:38:12 --> Helper loaded: util_helper
INFO - 2018-07-17 21:38:12 --> Helper loaded: text_helper
INFO - 2018-07-17 21:38:12 --> Helper loaded: string_helper
INFO - 2018-07-17 21:38:12 --> Database Driver Class Initialized
DEBUG - 2018-07-17 21:38:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-17 21:38:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-17 21:38:12 --> Email Class Initialized
INFO - 2018-07-17 21:38:12 --> Controller Class Initialized
DEBUG - 2018-07-17 21:38:12 --> Home MX_Controller Initialized
DEBUG - 2018-07-17 21:38:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-07-17 21:38:14 --> Config Class Initialized
INFO - 2018-07-17 21:38:14 --> Hooks Class Initialized
DEBUG - 2018-07-17 21:38:14 --> UTF-8 Support Enabled
INFO - 2018-07-17 21:38:14 --> Utf8 Class Initialized
INFO - 2018-07-17 21:38:14 --> URI Class Initialized
INFO - 2018-07-17 21:38:14 --> Router Class Initialized
INFO - 2018-07-17 21:38:14 --> Output Class Initialized
INFO - 2018-07-17 21:38:14 --> Security Class Initialized
DEBUG - 2018-07-17 21:38:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 21:38:14 --> Input Class Initialized
INFO - 2018-07-17 21:38:14 --> Language Class Initialized
INFO - 2018-07-17 21:38:14 --> Language Class Initialized
INFO - 2018-07-17 21:38:14 --> Config Class Initialized
INFO - 2018-07-17 21:38:14 --> Loader Class Initialized
DEBUG - 2018-07-17 21:38:14 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-17 21:38:14 --> Helper loaded: url_helper
INFO - 2018-07-17 21:38:14 --> Helper loaded: form_helper
INFO - 2018-07-17 21:38:14 --> Helper loaded: date_helper
INFO - 2018-07-17 21:38:14 --> Helper loaded: util_helper
INFO - 2018-07-17 21:38:14 --> Helper loaded: text_helper
INFO - 2018-07-17 21:38:14 --> Helper loaded: string_helper
INFO - 2018-07-17 21:38:14 --> Database Driver Class Initialized
DEBUG - 2018-07-17 21:38:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-17 21:38:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-17 21:38:14 --> Email Class Initialized
INFO - 2018-07-17 21:38:14 --> Controller Class Initialized
DEBUG - 2018-07-17 21:38:14 --> Home MX_Controller Initialized
DEBUG - 2018-07-17 21:38:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-17 21:38:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-17 21:38:14 --> Final output sent to browser
DEBUG - 2018-07-17 21:38:14 --> Total execution time: 0.3673
INFO - 2018-07-17 21:38:14 --> Config Class Initialized
INFO - 2018-07-17 21:38:14 --> Hooks Class Initialized
DEBUG - 2018-07-17 21:38:14 --> UTF-8 Support Enabled
INFO - 2018-07-17 21:38:14 --> Utf8 Class Initialized
INFO - 2018-07-17 21:38:14 --> URI Class Initialized
INFO - 2018-07-17 21:38:14 --> Router Class Initialized
INFO - 2018-07-17 21:38:14 --> Output Class Initialized
INFO - 2018-07-17 21:38:14 --> Security Class Initialized
DEBUG - 2018-07-17 21:38:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 21:38:14 --> Input Class Initialized
INFO - 2018-07-17 21:38:14 --> Language Class Initialized
INFO - 2018-07-17 21:38:14 --> Language Class Initialized
INFO - 2018-07-17 21:38:14 --> Config Class Initialized
INFO - 2018-07-17 21:38:14 --> Loader Class Initialized
DEBUG - 2018-07-17 21:38:14 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-17 21:38:15 --> Helper loaded: url_helper
INFO - 2018-07-17 21:38:15 --> Helper loaded: form_helper
INFO - 2018-07-17 21:38:15 --> Helper loaded: date_helper
INFO - 2018-07-17 21:38:15 --> Helper loaded: util_helper
INFO - 2018-07-17 21:38:15 --> Helper loaded: text_helper
INFO - 2018-07-17 21:38:15 --> Helper loaded: string_helper
INFO - 2018-07-17 21:38:15 --> Database Driver Class Initialized
DEBUG - 2018-07-17 21:38:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-17 21:38:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-17 21:38:15 --> Email Class Initialized
INFO - 2018-07-17 21:38:15 --> Controller Class Initialized
DEBUG - 2018-07-17 21:38:15 --> Home MX_Controller Initialized
DEBUG - 2018-07-17 21:38:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-07-17 21:39:48 --> Config Class Initialized
INFO - 2018-07-17 21:39:48 --> Hooks Class Initialized
DEBUG - 2018-07-17 21:39:48 --> UTF-8 Support Enabled
INFO - 2018-07-17 21:39:48 --> Utf8 Class Initialized
INFO - 2018-07-17 21:39:48 --> URI Class Initialized
INFO - 2018-07-17 21:39:48 --> Router Class Initialized
INFO - 2018-07-17 21:39:48 --> Output Class Initialized
INFO - 2018-07-17 21:39:48 --> Security Class Initialized
DEBUG - 2018-07-17 21:39:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 21:39:48 --> Input Class Initialized
INFO - 2018-07-17 21:39:49 --> Language Class Initialized
INFO - 2018-07-17 21:39:49 --> Language Class Initialized
INFO - 2018-07-17 21:39:49 --> Config Class Initialized
INFO - 2018-07-17 21:39:49 --> Loader Class Initialized
DEBUG - 2018-07-17 21:39:49 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-17 21:39:49 --> Helper loaded: url_helper
INFO - 2018-07-17 21:39:49 --> Helper loaded: form_helper
INFO - 2018-07-17 21:39:49 --> Helper loaded: date_helper
INFO - 2018-07-17 21:39:49 --> Helper loaded: util_helper
INFO - 2018-07-17 21:39:49 --> Helper loaded: text_helper
INFO - 2018-07-17 21:39:49 --> Helper loaded: string_helper
INFO - 2018-07-17 21:39:49 --> Database Driver Class Initialized
DEBUG - 2018-07-17 21:39:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-17 21:39:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-17 21:39:49 --> Email Class Initialized
INFO - 2018-07-17 21:39:49 --> Controller Class Initialized
DEBUG - 2018-07-17 21:39:49 --> Admin MX_Controller Initialized
INFO - 2018-07-17 21:39:49 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-17 21:39:49 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-17 21:39:49 --> Login MX_Controller Initialized
DEBUG - 2018-07-17 21:39:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-17 21:39:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-17 21:39:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
INFO - 2018-07-17 21:39:49 --> Config Class Initialized
INFO - 2018-07-17 21:39:49 --> Hooks Class Initialized
DEBUG - 2018-07-17 21:39:49 --> UTF-8 Support Enabled
INFO - 2018-07-17 21:39:49 --> Utf8 Class Initialized
INFO - 2018-07-17 21:39:49 --> URI Class Initialized
INFO - 2018-07-17 21:39:49 --> Router Class Initialized
INFO - 2018-07-17 21:39:49 --> Output Class Initialized
INFO - 2018-07-17 21:39:49 --> Security Class Initialized
DEBUG - 2018-07-17 21:39:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 21:39:49 --> Input Class Initialized
INFO - 2018-07-17 21:39:49 --> Language Class Initialized
ERROR - 2018-07-17 21:39:49 --> 404 Page Not Found: /index
INFO - 2018-07-17 21:39:51 --> Config Class Initialized
INFO - 2018-07-17 21:39:51 --> Hooks Class Initialized
DEBUG - 2018-07-17 21:39:51 --> UTF-8 Support Enabled
INFO - 2018-07-17 21:39:51 --> Utf8 Class Initialized
INFO - 2018-07-17 21:39:51 --> URI Class Initialized
INFO - 2018-07-17 21:39:51 --> Router Class Initialized
INFO - 2018-07-17 21:39:51 --> Output Class Initialized
INFO - 2018-07-17 21:39:51 --> Security Class Initialized
DEBUG - 2018-07-17 21:39:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 21:39:51 --> Input Class Initialized
INFO - 2018-07-17 21:39:51 --> Language Class Initialized
ERROR - 2018-07-17 21:39:51 --> 404 Page Not Found: /index
INFO - 2018-07-17 21:39:56 --> Config Class Initialized
INFO - 2018-07-17 21:39:56 --> Hooks Class Initialized
DEBUG - 2018-07-17 21:39:56 --> UTF-8 Support Enabled
INFO - 2018-07-17 21:39:56 --> Utf8 Class Initialized
INFO - 2018-07-17 21:39:56 --> URI Class Initialized
INFO - 2018-07-17 21:39:56 --> Router Class Initialized
INFO - 2018-07-17 21:39:56 --> Output Class Initialized
INFO - 2018-07-17 21:39:56 --> Security Class Initialized
DEBUG - 2018-07-17 21:39:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 21:39:56 --> Input Class Initialized
INFO - 2018-07-17 21:39:56 --> Language Class Initialized
INFO - 2018-07-17 21:39:56 --> Language Class Initialized
INFO - 2018-07-17 21:39:56 --> Config Class Initialized
INFO - 2018-07-17 21:39:56 --> Loader Class Initialized
DEBUG - 2018-07-17 21:39:56 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-17 21:39:56 --> Helper loaded: url_helper
INFO - 2018-07-17 21:39:56 --> Helper loaded: form_helper
INFO - 2018-07-17 21:39:56 --> Helper loaded: date_helper
INFO - 2018-07-17 21:39:56 --> Helper loaded: util_helper
INFO - 2018-07-17 21:39:56 --> Helper loaded: text_helper
INFO - 2018-07-17 21:39:56 --> Helper loaded: string_helper
INFO - 2018-07-17 21:39:56 --> Database Driver Class Initialized
DEBUG - 2018-07-17 21:39:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-17 21:39:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-17 21:39:56 --> Email Class Initialized
INFO - 2018-07-17 21:39:56 --> Controller Class Initialized
DEBUG - 2018-07-17 21:39:56 --> Login MX_Controller Initialized
INFO - 2018-07-17 21:39:56 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-17 21:39:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-17 21:39:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-17 21:39:56 --> Email starts for admin@colin.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-07-17 21:39:56 --> User session created for 1
INFO - 2018-07-17 21:39:56 --> Login status admin@colin.com - success
INFO - 2018-07-17 21:39:56 --> Final output sent to browser
DEBUG - 2018-07-17 21:39:56 --> Total execution time: 0.3889
INFO - 2018-07-17 21:39:56 --> Config Class Initialized
INFO - 2018-07-17 21:39:56 --> Hooks Class Initialized
DEBUG - 2018-07-17 21:39:56 --> UTF-8 Support Enabled
INFO - 2018-07-17 21:39:56 --> Utf8 Class Initialized
INFO - 2018-07-17 21:39:56 --> URI Class Initialized
INFO - 2018-07-17 21:39:56 --> Router Class Initialized
INFO - 2018-07-17 21:39:56 --> Output Class Initialized
INFO - 2018-07-17 21:39:56 --> Security Class Initialized
DEBUG - 2018-07-17 21:39:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 21:39:57 --> Input Class Initialized
INFO - 2018-07-17 21:39:57 --> Language Class Initialized
INFO - 2018-07-17 21:39:57 --> Language Class Initialized
INFO - 2018-07-17 21:39:57 --> Config Class Initialized
INFO - 2018-07-17 21:39:57 --> Loader Class Initialized
DEBUG - 2018-07-17 21:39:57 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-17 21:39:57 --> Helper loaded: url_helper
INFO - 2018-07-17 21:39:57 --> Helper loaded: form_helper
INFO - 2018-07-17 21:39:57 --> Helper loaded: date_helper
INFO - 2018-07-17 21:39:57 --> Helper loaded: util_helper
INFO - 2018-07-17 21:39:57 --> Helper loaded: text_helper
INFO - 2018-07-17 21:39:57 --> Helper loaded: string_helper
INFO - 2018-07-17 21:39:57 --> Database Driver Class Initialized
DEBUG - 2018-07-17 21:39:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-17 21:39:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-17 21:39:57 --> Email Class Initialized
INFO - 2018-07-17 21:39:57 --> Controller Class Initialized
DEBUG - 2018-07-17 21:39:57 --> Admin MX_Controller Initialized
INFO - 2018-07-17 21:39:57 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-17 21:39:57 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-17 21:39:57 --> Login MX_Controller Initialized
DEBUG - 2018-07-17 21:39:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-17 21:39:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-17 21:39:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-17 21:39:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-17 21:39:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-17 21:39:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-17 21:39:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-17 21:39:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/dashboard.php
INFO - 2018-07-17 21:39:57 --> Final output sent to browser
INFO - 2018-07-17 21:39:57 --> Config Class Initialized
INFO - 2018-07-17 21:39:57 --> Hooks Class Initialized
DEBUG - 2018-07-17 21:39:57 --> Total execution time: 0.4498
INFO - 2018-07-17 21:39:57 --> Config Class Initialized
INFO - 2018-07-17 21:39:57 --> Hooks Class Initialized
DEBUG - 2018-07-17 21:39:57 --> UTF-8 Support Enabled
INFO - 2018-07-17 21:39:57 --> Utf8 Class Initialized
DEBUG - 2018-07-17 21:39:57 --> UTF-8 Support Enabled
INFO - 2018-07-17 21:39:57 --> Utf8 Class Initialized
INFO - 2018-07-17 21:39:57 --> URI Class Initialized
INFO - 2018-07-17 21:39:57 --> URI Class Initialized
INFO - 2018-07-17 21:39:57 --> Router Class Initialized
INFO - 2018-07-17 21:39:57 --> Output Class Initialized
INFO - 2018-07-17 21:39:57 --> Router Class Initialized
INFO - 2018-07-17 21:39:57 --> Output Class Initialized
INFO - 2018-07-17 21:39:57 --> Security Class Initialized
INFO - 2018-07-17 21:39:57 --> Security Class Initialized
DEBUG - 2018-07-17 21:39:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 21:39:57 --> Input Class Initialized
DEBUG - 2018-07-17 21:39:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 21:39:57 --> Input Class Initialized
INFO - 2018-07-17 21:39:57 --> Language Class Initialized
INFO - 2018-07-17 21:39:57 --> Language Class Initialized
ERROR - 2018-07-17 21:39:57 --> 404 Page Not Found: /index
ERROR - 2018-07-17 21:39:57 --> 404 Page Not Found: /index
INFO - 2018-07-17 21:43:55 --> Config Class Initialized
INFO - 2018-07-17 21:43:55 --> Hooks Class Initialized
DEBUG - 2018-07-17 21:43:55 --> UTF-8 Support Enabled
INFO - 2018-07-17 21:43:55 --> Utf8 Class Initialized
INFO - 2018-07-17 21:43:55 --> URI Class Initialized
INFO - 2018-07-17 21:43:55 --> Router Class Initialized
INFO - 2018-07-17 21:43:55 --> Output Class Initialized
INFO - 2018-07-17 21:43:55 --> Security Class Initialized
DEBUG - 2018-07-17 21:43:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 21:43:55 --> Input Class Initialized
INFO - 2018-07-17 21:43:55 --> Language Class Initialized
INFO - 2018-07-17 21:43:55 --> Language Class Initialized
INFO - 2018-07-17 21:43:55 --> Config Class Initialized
INFO - 2018-07-17 21:43:55 --> Loader Class Initialized
DEBUG - 2018-07-17 21:43:55 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-17 21:43:55 --> Helper loaded: url_helper
INFO - 2018-07-17 21:43:55 --> Helper loaded: form_helper
INFO - 2018-07-17 21:43:55 --> Helper loaded: date_helper
INFO - 2018-07-17 21:43:55 --> Helper loaded: util_helper
INFO - 2018-07-17 21:43:55 --> Helper loaded: text_helper
INFO - 2018-07-17 21:43:55 --> Helper loaded: string_helper
INFO - 2018-07-17 21:43:55 --> Database Driver Class Initialized
DEBUG - 2018-07-17 21:43:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-17 21:43:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-17 21:43:55 --> Email Class Initialized
INFO - 2018-07-17 21:43:55 --> Controller Class Initialized
DEBUG - 2018-07-17 21:43:55 --> videos MX_Controller Initialized
INFO - 2018-07-17 21:43:55 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-17 21:43:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-07-17 21:43:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-17 21:43:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-07-17 21:43:55 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-17 21:43:55 --> Login MX_Controller Initialized
DEBUG - 2018-07-17 21:43:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-17 21:43:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-17 21:43:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-17 21:43:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-17 21:43:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-17 21:43:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-17 21:43:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/videos/videos.php
INFO - 2018-07-17 21:43:55 --> Final output sent to browser
DEBUG - 2018-07-17 21:43:55 --> Total execution time: 0.4711
INFO - 2018-07-17 21:43:56 --> Config Class Initialized
INFO - 2018-07-17 21:43:56 --> Hooks Class Initialized
DEBUG - 2018-07-17 21:43:56 --> UTF-8 Support Enabled
INFO - 2018-07-17 21:43:56 --> Utf8 Class Initialized
INFO - 2018-07-17 21:43:56 --> URI Class Initialized
INFO - 2018-07-17 21:43:56 --> Router Class Initialized
INFO - 2018-07-17 21:43:56 --> Output Class Initialized
INFO - 2018-07-17 21:43:56 --> Security Class Initialized
DEBUG - 2018-07-17 21:43:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 21:43:56 --> Input Class Initialized
INFO - 2018-07-17 21:43:56 --> Language Class Initialized
INFO - 2018-07-17 21:43:56 --> Language Class Initialized
INFO - 2018-07-17 21:43:56 --> Config Class Initialized
INFO - 2018-07-17 21:43:56 --> Loader Class Initialized
DEBUG - 2018-07-17 21:43:56 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-17 21:43:56 --> Helper loaded: url_helper
INFO - 2018-07-17 21:43:56 --> Helper loaded: form_helper
INFO - 2018-07-17 21:43:56 --> Helper loaded: date_helper
INFO - 2018-07-17 21:43:56 --> Helper loaded: util_helper
INFO - 2018-07-17 21:43:56 --> Helper loaded: text_helper
INFO - 2018-07-17 21:43:56 --> Helper loaded: string_helper
INFO - 2018-07-17 21:43:56 --> Database Driver Class Initialized
DEBUG - 2018-07-17 21:43:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-17 21:43:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-17 21:43:56 --> Email Class Initialized
INFO - 2018-07-17 21:43:56 --> Controller Class Initialized
DEBUG - 2018-07-17 21:43:56 --> videos MX_Controller Initialized
INFO - 2018-07-17 21:43:56 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-17 21:43:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Videos_model.php
DEBUG - 2018-07-17 21:43:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-17 21:43:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-07-17 21:43:56 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-17 21:43:56 --> Login MX_Controller Initialized
DEBUG - 2018-07-17 21:43:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-17 21:43:56 --> Final output sent to browser
DEBUG - 2018-07-17 21:43:56 --> Total execution time: 0.4902
INFO - 2018-07-17 21:47:44 --> Config Class Initialized
INFO - 2018-07-17 21:47:44 --> Hooks Class Initialized
DEBUG - 2018-07-17 21:47:44 --> UTF-8 Support Enabled
INFO - 2018-07-17 21:47:44 --> Utf8 Class Initialized
INFO - 2018-07-17 21:47:44 --> URI Class Initialized
DEBUG - 2018-07-17 21:47:44 --> No URI present. Default controller set.
INFO - 2018-07-17 21:47:44 --> Router Class Initialized
INFO - 2018-07-17 21:47:44 --> Output Class Initialized
INFO - 2018-07-17 21:47:44 --> Security Class Initialized
DEBUG - 2018-07-17 21:47:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 21:47:44 --> Input Class Initialized
INFO - 2018-07-17 21:47:44 --> Language Class Initialized
INFO - 2018-07-17 21:47:44 --> Language Class Initialized
INFO - 2018-07-17 21:47:44 --> Config Class Initialized
INFO - 2018-07-17 21:47:44 --> Loader Class Initialized
DEBUG - 2018-07-17 21:47:44 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-17 21:47:44 --> Helper loaded: url_helper
INFO - 2018-07-17 21:47:44 --> Helper loaded: form_helper
INFO - 2018-07-17 21:47:44 --> Helper loaded: date_helper
INFO - 2018-07-17 21:47:44 --> Helper loaded: util_helper
INFO - 2018-07-17 21:47:44 --> Helper loaded: text_helper
INFO - 2018-07-17 21:47:44 --> Helper loaded: string_helper
INFO - 2018-07-17 21:47:44 --> Database Driver Class Initialized
DEBUG - 2018-07-17 21:47:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-17 21:47:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-17 21:47:44 --> Email Class Initialized
INFO - 2018-07-17 21:47:44 --> Controller Class Initialized
DEBUG - 2018-07-17 21:47:44 --> Home MX_Controller Initialized
DEBUG - 2018-07-17 21:47:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-17 21:47:44 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-17 21:47:45 --> Login MX_Controller Initialized
INFO - 2018-07-17 21:47:45 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-17 21:47:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-17 21:47:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-17 21:47:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-07-17 21:48:42 --> Config Class Initialized
INFO - 2018-07-17 21:48:42 --> Hooks Class Initialized
DEBUG - 2018-07-17 21:48:42 --> UTF-8 Support Enabled
INFO - 2018-07-17 21:48:42 --> Utf8 Class Initialized
INFO - 2018-07-17 21:48:42 --> URI Class Initialized
INFO - 2018-07-17 21:48:42 --> Router Class Initialized
INFO - 2018-07-17 21:48:42 --> Output Class Initialized
INFO - 2018-07-17 21:48:42 --> Security Class Initialized
DEBUG - 2018-07-17 21:48:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 21:48:42 --> Input Class Initialized
INFO - 2018-07-17 21:48:42 --> Language Class Initialized
INFO - 2018-07-17 21:48:42 --> Language Class Initialized
INFO - 2018-07-17 21:48:42 --> Config Class Initialized
INFO - 2018-07-17 21:48:42 --> Loader Class Initialized
DEBUG - 2018-07-17 21:48:42 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-17 21:48:42 --> Helper loaded: url_helper
INFO - 2018-07-17 21:48:42 --> Helper loaded: form_helper
INFO - 2018-07-17 21:48:42 --> Helper loaded: date_helper
INFO - 2018-07-17 21:48:42 --> Helper loaded: util_helper
INFO - 2018-07-17 21:48:42 --> Helper loaded: text_helper
INFO - 2018-07-17 21:48:42 --> Helper loaded: string_helper
INFO - 2018-07-17 21:48:42 --> Database Driver Class Initialized
DEBUG - 2018-07-17 21:48:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-17 21:48:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-17 21:48:42 --> Email Class Initialized
INFO - 2018-07-17 21:48:42 --> Controller Class Initialized
DEBUG - 2018-07-17 21:48:42 --> Profile MX_Controller Initialized
INFO - 2018-07-17 21:48:42 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-17 21:48:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-17 21:48:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Profile_model.php
DEBUG - 2018-07-17 21:48:42 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-17 21:48:42 --> Login MX_Controller Initialized
DEBUG - 2018-07-17 21:48:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-17 21:48:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-17 21:48:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-17 21:48:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-17 21:48:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-17 21:48:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-17 21:48:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/profile.php
INFO - 2018-07-17 21:48:42 --> Final output sent to browser
DEBUG - 2018-07-17 21:48:42 --> Total execution time: 0.4634
INFO - 2018-07-17 22:04:36 --> Config Class Initialized
INFO - 2018-07-17 22:04:36 --> Hooks Class Initialized
DEBUG - 2018-07-17 22:04:36 --> UTF-8 Support Enabled
INFO - 2018-07-17 22:04:36 --> Utf8 Class Initialized
INFO - 2018-07-17 22:04:36 --> URI Class Initialized
INFO - 2018-07-17 22:04:36 --> Router Class Initialized
INFO - 2018-07-17 22:04:36 --> Output Class Initialized
INFO - 2018-07-17 22:04:36 --> Security Class Initialized
DEBUG - 2018-07-17 22:04:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 22:04:36 --> Input Class Initialized
INFO - 2018-07-17 22:04:36 --> Language Class Initialized
ERROR - 2018-07-17 22:04:36 --> 404 Page Not Found: /index
INFO - 2018-07-17 22:04:38 --> Config Class Initialized
INFO - 2018-07-17 22:04:38 --> Hooks Class Initialized
DEBUG - 2018-07-17 22:04:38 --> UTF-8 Support Enabled
INFO - 2018-07-17 22:04:38 --> Utf8 Class Initialized
INFO - 2018-07-17 22:04:38 --> URI Class Initialized
INFO - 2018-07-17 22:04:38 --> Router Class Initialized
INFO - 2018-07-17 22:04:38 --> Output Class Initialized
INFO - 2018-07-17 22:04:38 --> Security Class Initialized
DEBUG - 2018-07-17 22:04:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 22:04:38 --> Input Class Initialized
INFO - 2018-07-17 22:04:38 --> Language Class Initialized
ERROR - 2018-07-17 22:04:38 --> 404 Page Not Found: /index
INFO - 2018-07-17 22:04:39 --> Config Class Initialized
INFO - 2018-07-17 22:04:39 --> Hooks Class Initialized
DEBUG - 2018-07-17 22:04:39 --> UTF-8 Support Enabled
INFO - 2018-07-17 22:04:39 --> Utf8 Class Initialized
INFO - 2018-07-17 22:04:39 --> URI Class Initialized
INFO - 2018-07-17 22:04:39 --> Router Class Initialized
INFO - 2018-07-17 22:04:40 --> Output Class Initialized
INFO - 2018-07-17 22:04:40 --> Security Class Initialized
DEBUG - 2018-07-17 22:04:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 22:04:40 --> Input Class Initialized
INFO - 2018-07-17 22:04:40 --> Language Class Initialized
ERROR - 2018-07-17 22:04:40 --> 404 Page Not Found: /index
INFO - 2018-07-17 22:04:40 --> Config Class Initialized
INFO - 2018-07-17 22:04:40 --> Hooks Class Initialized
DEBUG - 2018-07-17 22:04:40 --> UTF-8 Support Enabled
INFO - 2018-07-17 22:04:40 --> Utf8 Class Initialized
INFO - 2018-07-17 22:04:40 --> URI Class Initialized
INFO - 2018-07-17 22:04:40 --> Router Class Initialized
INFO - 2018-07-17 22:04:40 --> Output Class Initialized
INFO - 2018-07-17 22:04:40 --> Security Class Initialized
DEBUG - 2018-07-17 22:04:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 22:04:40 --> Input Class Initialized
INFO - 2018-07-17 22:04:40 --> Language Class Initialized
ERROR - 2018-07-17 22:04:40 --> 404 Page Not Found: /index
INFO - 2018-07-17 22:04:40 --> Config Class Initialized
INFO - 2018-07-17 22:04:40 --> Hooks Class Initialized
DEBUG - 2018-07-17 22:04:40 --> UTF-8 Support Enabled
INFO - 2018-07-17 22:04:40 --> Utf8 Class Initialized
INFO - 2018-07-17 22:04:40 --> URI Class Initialized
INFO - 2018-07-17 22:04:40 --> Router Class Initialized
INFO - 2018-07-17 22:04:40 --> Output Class Initialized
INFO - 2018-07-17 22:04:40 --> Security Class Initialized
DEBUG - 2018-07-17 22:04:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 22:04:40 --> Input Class Initialized
INFO - 2018-07-17 22:04:40 --> Language Class Initialized
ERROR - 2018-07-17 22:04:40 --> 404 Page Not Found: /index
