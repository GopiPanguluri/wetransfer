<?php header('Access-Control-Allow-Origin: *'); ?>
<?php
require_once base_path('public/l2/resources/konnektiveSDK.php');
$pageType = "checkoutPage"; //choose from: catalogPage, checkoutPage, upsellPage1, upsellPage2, upsellPage3, upsellPage4, thankyouPage
$deviceType = "ALL"; //choose from: DESKTOP, MOBILE, ALL
$ksdk = new KonnektiveSDK($pageType,$deviceType);

$productId = $ksdk->page->productId;
$offer = $ksdk->getProduct((int) $productId);

if(isset($_GET['c1'])) $c1=$_GET['c1']; else  $c1=''; 
if(isset($_GET['c2'])) $c2=$_GET['c2']; else  $c2='';
if(isset($_GET['c3'])) $c3=$_GET['c3']; else  $c3='';
if(isset($_GET['affId'])) $affId=$_GET['affId']; else $affId='';
//dd($c1);


if(request('c2')){
    session(['c2' => request('c2')]);
}
if(request('c3')){
    session(['c3' => request('c3')]);
}
$ip= \Request::ip();
$data = \Location::get($ip);

$country=$data->countryCode;
$state1=$data->regionName;

$city=$data->cityName;
$zipcode=$data->zipCode;
?>
@extends('layout2')

@section('content')


    <style>body {background:url(/landing1/img/bionuvo-checkout-1.jpg) center top no-repeat;}
    .cta-btn {
        width: 50%;
    }
    .info_msg,.error_msg,.hide_this_div{
      display: none;
    }
    .error,.error_msg{
        color: red !important;
        font-weight: bold !important;
    }
    .info_msg{
        color: green !important;
        font-weight: bold !important;
    }
    .check-bt1{
        position: absolute;
        left: -148px;
        top: 0;
        width: 72%;
    }
    .bootbox-alert{
        margin-top: 100px !important;
    }
    .btn-primary{
        background-color: #854aa8 !important;
        border-color: #854aa8 !important;
    }

    </style>
     <script>
        //$(function() {setTimeout(function(){ $("#dispalyState").append('<option value="<?php //echo $state1;?>" selected><?php //echo $state1;?></option>'); }, 5000);});          
     </script>
               <!-- start Mixpanel -->
    <script src="{{ asset('genealabs-laravel-mixpanel/js/mixpanel.js') }}"></script>
    
    <script type="text/javascript">(function(e,a){if(!a.__SV){var b=window;try{var c,l,i,j=b.location,g=j.hash;c=function(a,b){return(l=a.match(RegExp(b+"=([^&]*)")))?l[1]:null};g&&c(g,"state")&&(i=JSON.parse(decodeURIComponent(c(g,"state"))),"mpeditor"===i.action&&(b.sessionStorage.setItem("_mpcehash",g),history.replaceState(i.desiredHash||"",e.title,j.pathname+j.search)))}catch(m){}var k,h;window.mixpanel=a;a._i=[];a.init=function(b,c,f){function e(b,a){var c=a.split(".");2==c.length&&(b=b[c[0]],a=c[1]);b[a]=function(){b.push([a].concat(Array.prototype.slice.call(arguments,
0)))}}var d=a;"undefined"!==typeof f?d=a[f]=[]:f="mixpanel";d.people=d.people||[];d.toString=function(b){var a="mixpanel";"mixpanel"!==f&&(a+="."+f);b||(a+=" (stub)");return a};d.people.toString=function(){return d.toString(1)+".people (stub)"};k="disable time_event track track_pageview track_links track_forms register register_once alias unregister identify name_tag set_config reset people.set people.set_once people.unset people.increment people.append people.union people.track_charge people.clear_charges people.delete_user".split(" ");
for(h=0;h<k.length;h++)e(d,k[h]);a._i.push([b,c,f])};a.__SV=1.2;b=e.createElement("script");b.type="text/javascript";b.async=!0;b.src="undefined"!==typeof MIXPANEL_CUSTOM_LIB_URL?MIXPANEL_CUSTOM_LIB_URL:"file:"===e.location.protocol&&"//cdn.mxpnl.com/libs/mixpanel-2-latest.min.js".match(/^\/\//)?"https://cdn.mxpnl.com/libs/mixpanel-2-latest.min.js":"//cdn.mxpnl.com/libs/mixpanel-2-latest.min.js";c=e.getElementsByTagName("script")[0];c.parentNode.insertBefore(b,c)}})(document,window.mixpanel||[]);
mixpanel.init("41cf7c2d566d7da988dd6869a193595e");</script>

    <div class="container">
    <div class="image_loading" style="margin-top: -4px;background-color: rgba(255,255,255,0.7);position: absolute;z-index: +100 !important;width: 99.8%;height: 238%;left: 2px;display: none;">
      <img src="/uploads/loading_over.gif" class="img-responsive" style="position: relative;top: 26%;left: 34%;"/>
    </div>
        <div class="row">
            <div class="col-sm-4">
                <img src="/landing1/img/logo.png" class="img-responsive hidden-xs" alt="bionuvo logo" />
                <div class="col-md-8 col-md-offset-4 pricing pre_active_26 hide_this_div">
                    <div class="check-bt1">
                        <img src="/uploads/bio-btl.png" class="img-responsive" alt="bionuvo bottle" />
                    </div>
                    <h4 class="text-center nuvo">Double Play</h4>
                    <div class="main-item">
                        <span class="bio">bio<span class="nuvo">nuvo</span></span> <span style="padding-top:8px;" class="pull-right">$99.95</span>
                    </div>
                    <div class="line-item">
                        Subtotal <span class="pull-right kcartSubTotal">$99.95</span>
                    </div>
                    <div class="line-item">
                        Shipping <span class="pull-right kcartShipTotal">$3.95</span>
                    </div>
                    <div class="line-item">
                        Sales Tax <span class="pull-right kcartSalesTax">$0.00</span>
                    </div>
                    @if(session('landing') == 'shipping')
                        <div class="line-item">
                            Discounts <span class="pull-right kcartDiscount"> </span>
                        </div>
                    @endif
                    <div class="grand-item">
                        Grand Total <span class="pull-right kcartGrandTotal">$103.9 </span>
                    </div>
                </div>



                 <div class="col-md-8 col-md-offset-4 pricing pre_active_27 hide_this_div">
                    <div class="check-btl">
                        <img style="margin-top: 20%;" src="/uploads/bio-btl.png" class="img-responsive" alt="bionuvo bottle" />
                    </div>
                    <h4 class="text-center nuvo">Standard Subscription</h4>
                    <div class="main-item">
                        <span class="bio">bio<span class="nuvo">nuvo</span></span> <span style="padding-top:8px;" class="pull-right">$59.95</span>
                    </div>
                    <div class="line-item">
                        Subtotal <span class="pull-right kcartSubTotal">$59.95</span>
                    </div>
                    <div class="line-item">
                        Shipping <span class="pull-right kcartShipTotal">$3.95</span>
                    </div>
                    <div class="line-item">
                        Sales Tax <span class="pull-right kcartSalesTax">$0.00</span>
                    </div>
                    @if(session('landing') == 'shipping')
                        <div class="line-item">
                            Discounts <span class="pull-right kcartDiscount"> </span>
                        </div>
                    @endif
                    <div class="grand-item">
                        Grand Total <span class="pull-right kcartGrandTotal">$63.9</span>
                    </div>
                </div>



                 <div class="col-md-8 col-md-offset-4 pricing pre_active_28 hide_this_div">
                    <div class="check-btl">
                        <img style="margin-top: 10%;" src="/uploads/bio-btl.png" class="img-responsive" alt="bionuvo bottle" />

                    </div>
                    <h4 class="text-center nuvo">Trial Pack</h4>
                    <div class="main-item">
                        <span class="bio">bio<span class="nuvo">nuvo</span></span> <span style="padding-top:8px;" class="pull-right">$74.95</span>
                    </div>
                    <div class="line-item">
                        Subtotal <span class="pull-right kcartSubTotal">$74.95</span>
                    </div>
                    <div class="line-item">
                        Shipping <span class="pull-right kcartShipTotal">$3.95</span>
                    </div>
                    <div class="line-item">
                        Sales Tax <span class="pull-right kcartSalesTax">$0.00</span>
                    </div>
                    @if(session('landing') == 'shipping')
                        <div class="line-item">
                            Discounts <span class="pull-right kcartDiscount"> </span>
                        </div>
                    @endif
                    <div class="grand-item">
                        Grand Total <span class="pull-right kcartGrandTotal">$78.9</span>
                    </div>
                </div>
                <div class="col-md-8 col-md-offset-4 pricing pre_active_29 hide_this_div">
                    <div class="check-btl">
                        <img src="/uploads/bio-btl.png" class="img-responsive" alt="bionuvo bottle" />
                    </div>
                    <h4 class="text-center nuvo">14 Day Trial</h4>
                    <div class="main-item">
                        <span class="bio">bio<span class="nuvo">nuvo</span></span> <span style="padding-top:8px;" class="pull-right">$0.00</span>
                    </div>
                    <div class="line-item">
                        Subtotal <span class="pull-right kcartSubTotal">$0.00</span>
                    </div>
                    <div class="line-item">
                        Shipping <span class="pull-right kcartShipTotal">$3.95</span>
                    </div>
                    <div class="line-item">
                        Sales Tax <span class="pull-right kcartSalesTax">$0.00</span>
                    </div>
                    @if(session('landing') == 'shipping')
                        <div class="line-item">
                            Discounts <span class="pull-right kcartDiscount"> </span>
                        </div>
                    @endif
                    <div class="grand-item">
                        Grand Total <span class="pull-right kcartGrandTotal">$3.95</span>
                    </div>
                </div>
                <div class="clearfix"></div>
                @if(session('landing') == 3 || session('landing') == 1)
                    <div class="check-disclaimer" style="font-size:12px;padding-bottom:20px">
                        <strong>Offer Terms:</strong> Unless you cancel within 14 days, you'll be charged $29 for the remainder of bottle - money back guarantee applies! After your first 30 days, you'll be sent a 30 day supply of Bionuvo every 30 days thereafter and be charged recurring monthly payments of $59.95 unless you contact Customer Service and return as instructed. Credit Card Descriptor: BIONUVO (844)383-4637
                    </div>
                    <div id="offer-terms" style="background:#fff;padding:20px;" class="lity-hide">
                        <strong>Offer Terms:</strong> Unless you cancel within 14 days, you'll be charged $29 for the remainder of bottle - money back guarantee applies! After your first 30 days, you'll be sent a 30 day supply of Bionuvo every 30 days thereafter and be charged recurring monthly payments of $59.95 unless you contact Customer Service and return as instructed.
                    </div>
                @endif
            </div>
            <div id="checkout" class="col-sm-8">
                <form id="kform2" class="kform2" method="post" action="{{url('l2/payment')}}" enctype="multipart/form-data">
                    {{ csrf_field() }}
                    <img src="/uploads/shipping_1_bar.png" class="img-responsive ch-trk" alt="checkout progress" />
                    <input type="hidden" name="pro_id" id="pro_id" value="{{$pro_id}}">
                    <input type="hidden" name="c1" id="c1" value="{{$c1}}">
                    <input type="hidden" name="c2" id="c2" value="{{$c2}}">
                    <input type="hidden" name="c3" id="c3" value="{{$c3}}">
                    <input type="hidden" name="affId" id="affId" value="{{$affId}}">
                    <div class="col-sm-6">

                        <div class="form-line">
                            <label>First Name:</label>
                            <input type="text" name="firstName" isRequired {!! request('firstName') ? 'value="'.request('firstName').'"' :''  !!}>
                        </div>

                    </div>
                    <div class="col-sm-6">

                        <div class="form-line">
                            <label>Last Name:</label>
                            <input type="text" name="lastName" isRequired {!! request('lastName') ? 'value="'.request('lastName').'"' :''  !!}>
                        </div>

                    </div>
                    <div class="col-sm-6">
                        <div class="form-line">
                            <label>Email:</label>
                            <input type="text" name="emailAddress" isRequired {!! request('emailAddress') ? 'value="'.request('emailAddress').'"' :''  !!}>
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class="form-line">
                            <label>Phone Number:</label>
                            <input type="text" name="phoneNumber" isRequired>
                        </div>
                    </div>

                    <!-- BILLING SECTION -->
                    <div class="clearfix"></div>
                    <div>
                        <h4 class="text-center">Billing Address</h4>
                        <div class="col-sm-6">
                            <div class="form-line">
                                <label>Billing Address Line 1:</label>
                                <input type="text" name="address1" isRequired>
                            </div>
                            <div class="form-line">
                                <label>Billing Address Line 2:</label>
                                <input type="text" name="address2">
                            </div>
                        </div>
                        <div class="col-sm-6">

                            <div class="form-line">
                                <label>City:</label>
                                <input type="text" name="city" value=""  isRequired>
                            </div>
                            <div class="col-sm-6 split-l">
                                <div class="form-line">
                                    <label>State:</label>
                                    <select name="state" id="dispalyState" isRequired>
                                        <option value="">Select State</option>
                                        <?php foreach($ksdk->config->states->US as $sts_key=>$sts_val){ ?>
                                            <option value="{{ $sts_key }}">{{ $sts_val }}</option>
                                        <?php } ?>
                                    </select>
                                </div>
                            </div>
                            <div class="col-sm-6 split-r">
                                <div class="form-line">
                                    <label>Zipcode:</label>
                                    <input type="text" name="postalCode" value="<?php echo $zipcode;?>" isRequired>
                                </div>
                            </div>

                            <div class="form-line">
                                <select name="country">
                                <?php foreach($ksdk->config->countries as $cntr_key=>$cntr_val){ ?>
                                    <option value="{{ $cntr_key }}">{{ $cntr_val }}</option>
                                <?php } ?>
                                </select>
                            </div>
                        </div>
                    </div>
                    <!-- BILLING SECTION -->


                    <!-- SHIPPING SECTION HIDDEN -->
                    <div class="clearfix"></div>
                    <div id="kform_hiddenAddress" style="display: none;">
                        <h4 class="text-center">Shipping Address</h4>
                        <div class="col-sm-6">
                            <div class="form-line">
                                <label>Shipping Address Line 1:</label>
                                <input type="text" name="shipAddress1" isRequired>
                            </div>
                            <div class="form-line">
                                <label>Shipping Address Line 2:</label>
                                <input type="text" name="shipAddress2">
                            </div>
                        </div>
                        <div class="col-sm-6">

                            <div class="form-line">
                                <label>City:</label>
                                <input type="text" name="shipCity" isRequired>
                            </div>
                            <div class="col-sm-6 split-l">
                                <div class="form-line">
                                    <label>State:</label>
                                   <select class="form-control" name="shipState" isRequired>
                                <option value="">Select State</option>
                                <?php foreach($ksdk->config->states->US as $sts_key=>$sts_val){ ?>
                                    <option value="{{ $sts_key }}">{{ $sts_val }}</option>
                                <?php } ?>
                                </select>
                                </div>
                            </div>
                            <div class="col-sm-6 split-r">
                                <div class="form-line">
                                    <label>Zipcode:</label>
                                    <input type="text" name="shipPostalCode" isRequired>
                                </div>
                            </div>

                            <div class="form-line">
                                <select class="form-control" name="shipCountry">
                                <option value="">Select Country</option>
                                <?php foreach($ksdk->config->countries as $cntr_key=>$cntr_val){ ?>
                                    <option value="{{ $cntr_key }}">{{ $cntr_val }}</option>
                                <?php } ?>
                                </select>
                            </div>
                        </div>
                    </div>
                    <!-- SHIPPING SECTION HIDDEN -->

                    <div class="clearfix"></div>
                    <div class="cc-section">
                        <div class="col-sm-6 col-lg-5 col-sm-offset-0 col-lg-offset-1 chk-ship">
                            <label onclick="check()">
                                <input name="billShipSame" type="CHECKBOX" id="check" placeholder="Billing Same as Shipping Address" checked> Shipping Address same as Billing
                            </label>
                        </div>
                        
                    </div>
                    </br>
                    <center>
                    <div class="info_msg"></div>
                    <div class="error_msg"></div>
                    <button type="submit" class="check_out_validate btn btn-primary btn-large btn-block cta-btn">Continue Checkout</button>
                    </center>
                </form>
            </div>
        </div>
    </div>
<script>
$("#check").click(function() {
    //alert("test");
    if($("#check").is(":checked")) {
        $("#kform_hiddenAddress").hide(200);
    } else {
       
        $("#kform_hiddenAddress").show(300);
    }
});
</script>
    <script>
        $(document).ready(function(){
            $('#country, #shipCountry').val('US');
        });
    </script>

    <script>
        fbq('track', 'AddToCart');
    </script>
    <script>
        //setTimeout(function(){ $("#dispalyState").append('<option value="<?php //echo $state1;?>" selected><?php //echo $state1;?></option>'); }, 1000);        
    </script>
    <script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.17.0/dist/jquery.validate.min.js"></script>
    <script>
        function getUrlVars() {
            var vars = {};
            var parts = window.location.href.replace(/[?&]+([^=&]+)=([^&]*)/gi, function(m,key,value) {
            vars[key] = value;
            });
            return vars;
        }

        $(document).ready(function() {
        $.validator.setDefaults({
                ignore: []
        });
        $(".kform2").validate({
            rules: {
            firstName: {
                required: true
            },
            lastName: {
                required: true
            },
            emailAddress: {
                required: true,
                email:true
            },
            phoneNumber: {
                required: true,
                number: true
            },
            address1: {
                required: true
            },
            city: {
                required: true
            },
            dispalyState: {
                required: true
            },
            postalCode: {
                required: true
            },
            country: {
                required: true
            }
            },
            messages: {             
                firstName: {                    
                    required: "Please your enter first name."
                },
                lastName: {                 
                    required: "Please your enter last name.",
                },
                emailAddress: {                 
                    required: "Please your enter email address.",
                },
                phoneNumber: {                 
                    required: "Please your enter phone number.",
                },
                address1: {                 
                    required: "Please your enter address one.",
                },
                city: {                 
                    required: "Please enter city.",
                },
                dispalyState: {                 
                    required: "Please enter state.",
                },
                postalCode: {                 
                    required: "Please enter postal code.",
                },
                country: {                 
                    required: "Please your enter country.",
                }
            },
            submitHandler: function(form,event){
            event.preventDefault();// using this page stop being refreshing
            var firstName = $('[name=firstName]').val();
            var lastName = $('[name=lastName]').val();
            var emailAddress = $('[name=emailAddress]').val();
            var phoneNumber = $('[name=phoneNumber]').val();
            var address1 = $('[name=address1]').val();
            var city = $('[name=city]').val();
            var address2 = $('[name=address2]').val();
            var state = $('select[name=state]').val();
            var postalCode = $('[name=postalCode]').val();
            var country = $('select[name=country]').val();
            var ship = $('[name=billShipSame]').is(":checked");
            var pro_id=$('[name=pro_id]').val();
            var c1=$('[name=c1]').val();
            var c2=$('[name=c2]').val();
            var c3=$('[name=c3]').val();
            var affId=$('[name=affId]').val();
            if(ship){
                var shipAddress1 = address1;
                var shipAddress2 = address2;
                var shipCity = city;
                var shipState = state;
                var shipPostalCode = postalCode;
                var shipCountry = country;
            }else{
                var shipAddress1 = $('[name=shipAddress1]').val();
                var shipAddress2 = $('[name=shipAddress2]').val();
                var shipCity = $('[name=shipCity]').val();
                var shipState = $('select[name=shipState]').val();
                var shipPostalCode = $('[name=shipPostalCode]').val();
                var shipCountry = $('select[name=shipCountry]').val();
            }
            //alert(shipAddress1);
            var pre_url = "https://api.konnektive.com/leads/import/?loginId=bionuvoteam&password=fissionthetech1&emailAddress="+emailAddress+"&phoneNumber="+phoneNumber+"&";
pre_url +="firstName="+firstName+"&lastName="+lastName+"&address1="+address1+"&address2="+address2+"&";
pre_url += "city="+city+"&state="+state+"&country="+country+"&postalCode="+postalCode+"&shipFirstName="+firstName+"&";
pre_url += "shipLastName="+lastName+"&shipAddress1="+shipAddress1+"&shipAddress2="+shipAddress2+"&";
pre_url += "&shipCity="+shipCity+"&shipState="+shipState;
pre_url += "&shipCountry="+shipCountry+"&shipPostalCode="+shipPostalCode+"&campaignId=12";
pre_url += "&sourceValue1="+c1+"&sourceValue2="+c2+"&sourceValue3="+c3+"&affId="+affId;
            // alert(pre_url);
            // console.log(pre_url);
            // return false;
            $.ajax({
                url: pre_url,
                type: 'GET',
                dataType: "json",
                //data: $(form).serialize(),
                beforeSend: function(){
                    $('.image_loading').show();
                },
                complete: function(){
                    $('.image_loading').hide();
                },
                success: function(res) {
                    if(res.result=="SUCCESS"){
                      //alert(res.message.orderId)
                      $('.error_msg').hide();
                      $('.info_msg').show();
                      $('.info_msg').html("Redirecting to Payment");
                      var red_url = form.action+"/"+pro_id+"/"+res.message.orderId;
                      var pre_url_ano = 'https://a.klaviyo.com/api/v1/list/MDQi4x/members';
                      //var pre_url_ano_get = 'https://a.klaviyo.com/api/v1/segment/HAZFtp/members';
                      var api_key = 'pk_cb67e83ec235a7a75c3f801b0f4d0369b1';
                      var email = emailAddress;
                      var properties = {first_name:firstName};
                      var confirm_optin = true;
                       //$.ajax({
//                            url: pre_url_ano_get,
//                            type: 'GET',
//                            dataType: "json",
//                            data: {api_key:api_key,email:email},
//                            success: function(res) {
//                                alert(res);
//                                console.log(res);
//                                return false;
//                            }            
//                      });
                      //return false;
                      $.ajax({
                            url: pre_url_ano,
                            type: 'POST',
                            dataType: "json",
                            crossDomain : true,
                            data: {api_key:api_key,email:email,properties:properties,confirm_optin:confirm_optin},
                            success: function(res) {
                                
                            }            
                     });
                     window.location.href = red_url;
                    }else{
                      // $('.error_msg').show();
                      // $('.info_msg').hide();
                      // $('.error_msg').html("Something went Wrong Please try again!.");
                      alert("Something went Wrong Please try again!.");
                    }
                }            
            });
        }
        });
        });
        $( document ).ready(function() {
            var pre_active_id=$('[name=pro_id]').val();
            $('.pre_active_'+pre_active_id).show();
        });
    </script>

@endsection