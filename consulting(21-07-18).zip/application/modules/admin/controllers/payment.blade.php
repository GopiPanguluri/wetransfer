<?php
require_once base_path('public/l2/resources/konnektiveSDK.php');
$pageType = "checkoutPage"; //choose from: catalogPage, checkoutPage, upsellPage1, upsellPage2, upsellPage3, upsellPage4, thankyouPage
$deviceType = "ALL"; //choose from: DESKTOP, MOBILE, ALL
$ksdk = new KonnektiveSDK($pageType,$deviceType);

$productId = $ksdk->page->productId;
$offer = $ksdk->getProduct((int) $productId);



if(request('c2')){
    session(['c2' => request('c2')]);
}
if(request('c3')){
    session(['c3' => request('c3')]);
}
$ip= \Request::ip();
$data = \Location::get($ip);

$country=$data->countryCode;
$state1=$data->regionName;

$city=$data->cityName;
$zipcode=$data->zipCode;

//dd($u_data);
?>
@extends('layout2')

@section('content')

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous"/>
    <style>body {background:url(/landing1/img/bionuvo-checkout-1.jpg) center top no-repeat;}
    .info_msg,.error_msg{
      display: none;
    }
    .error,.error_msg{
        color: red !important;
        font-weight: bold !important;
    }
    .info_msg{
        color: green !important;
        font-weight: bold !important;
    }
    .bootbox-alert{
        margin-top: 100px !important;
    }
    .btn-primary{
        background-color: #854aa8 !important;
        border-color: #854aa8 !important;
    }
    </style>
     <script>
       $(function() {
          
        setTimeout(function(){ $("#dispalyState").append('<option value="<?php echo $state1;?>" selected><?php echo $state1;?></option>'); }, 5000);
         
          }); 
         
         </script>
               <!-- start Mixpanel -->
    <script src="{{ asset('genealabs-laravel-mixpanel/js/mixpanel.js') }}"></script>
    
    <script type="text/javascript">(function(e,a){if(!a.__SV){var b=window;try{var c,l,i,j=b.location,g=j.hash;c=function(a,b){return(l=a.match(RegExp(b+"=([^&]*)")))?l[1]:null};g&&c(g,"state")&&(i=JSON.parse(decodeURIComponent(c(g,"state"))),"mpeditor"===i.action&&(b.sessionStorage.setItem("_mpcehash",g),history.replaceState(i.desiredHash||"",e.title,j.pathname+j.search)))}catch(m){}var k,h;window.mixpanel=a;a._i=[];a.init=function(b,c,f){function e(b,a){var c=a.split(".");2==c.length&&(b=b[c[0]],a=c[1]);b[a]=function(){b.push([a].concat(Array.prototype.slice.call(arguments,
0)))}}var d=a;"undefined"!==typeof f?d=a[f]=[]:f="mixpanel";d.people=d.people||[];d.toString=function(b){var a="mixpanel";"mixpanel"!==f&&(a+="."+f);b||(a+=" (stub)");return a};d.people.toString=function(){return d.toString(1)+".people (stub)"};k="disable time_event track track_pageview track_links track_forms register register_once alias unregister identify name_tag set_config reset people.set people.set_once people.unset people.increment people.append people.union people.track_charge people.clear_charges people.delete_user".split(" ");
for(h=0;h<k.length;h++)e(d,k[h]);a._i.push([b,c,f])};a.__SV=1.2;b=e.createElement("script");b.type="text/javascript";b.async=!0;b.src="undefined"!==typeof MIXPANEL_CUSTOM_LIB_URL?MIXPANEL_CUSTOM_LIB_URL:"file:"===e.location.protocol&&"//cdn.mxpnl.com/libs/mixpanel-2-latest.min.js".match(/^\/\//)?"https://cdn.mxpnl.com/libs/mixpanel-2-latest.min.js":"//cdn.mxpnl.com/libs/mixpanel-2-latest.min.js";c=e.getElementsByTagName("script")[0];c.parentNode.insertBefore(b,c)}})(document,window.mixpanel||[]);
mixpanel.init("41cf7c2d566d7da988dd6869a193595e");</script>

    <div class="container">
        <div class="row col-sm-12">
           <div class="col-sm-2"></div>
            <div id="checkout" class="col-sm-8">
                <form id="kform23" class="kform23" action="{{url('l2/thanksyou')}}">
                    <img src="/uploads/payment_2_bar.png" class="img-responsive ch-trk" alt="checkout progress" />
                    <div class="col-sm-6" style="width:100%;">
                      <input type="hidden" name="pro_id" value="{{$u_data['pro_id']}}" >
                      <input type="hidden" name="orderId" value="{{$u_data['orderId']}}" >
                    <div class="clearfix"></div>
                    <div class="cc-section col-md-12">
                        <div class="col-sm-6 col-lg-5 col-sm-offset-6 col-lg-offset-6 cardholder">
                            <img src="/landing1/img/c-cards.png" class="img-responsive" alt="we accept visa, mastercard, discover, and american express" />
                        </div>

                        <input type="hidden" name="paySource" value="CREDITCARD">
                        <div style="display: none;">
                            <select id="shipProfileId" name="shipProfileId">
                                <option value=""> Select Shipping Method</option>
                                <option value="2" selected>Standard Shipping</option>
                            </select>
                            <div id="kformPaySourceWrap" inputType="radio"></div>
                            <div class="form-group" id="kformNewPaymentType">
                                <input type="checkbox" name="newPaymentType"><span>New Credit Card</span>
                            </div>
                        </div>

                        @if(session('landing') == 'shipping')
                            <div class="col-lg-10 col-lg-offset-1">
                                <div class="form-line">
                                    <label>Coupon Code:</label>
                                    <input type="text" name="couponCode">
                                </div>
                            </div>
                        @endif

                        <div class="col-lg-10 col-lg-offset-1">
                            <div class="form-line">
                                <label style="font-weight: normal;">Card #:</label>
                                <input type="text" name="cardNumber" maxlength=16 isRequired>
                            </div>
                        </div>
                        <div class="col-lg-5 col-lg-offset-1">
                            <div class="form-line">
                                <label style="font-weight: normal;">Expiration (mo / yr):</label>
                                <div class="clearfix"></div>
                                <div style="margin-left: -5%;" class="col-xs-6 split-l text-center">
                                    <select placeholder="mo" name="cardMonth" isRequired>
                                        <option value="01">01</option>
                                        <option value="02">02</option>
                                        <option value="03">03</option>
                                        <option value="04">04</option>
                                        <option value="05">05</option>
                                        <option value="06">06</option>
                                        <option value="07">07</option>
                                        <option value="08">08</option>
                                        <option value="09">09</option>
                                        <option value="10">10</option>
                                        <option value="11">11</option>
                                        <option value="12">12</option>
                                    </select>
                                </div>
                                <div class="col-xs-6 split-r text-center">
                                    <select placeholder="yr" name="cardYear" isRequired>
                                        <option value="2017">2017</option>
                                        <option value="2018">2018</option>
                                        <option value="2019">2019</option>
                                        <option value="2020">2020</option>
                                        <option value="2021">2021</option>
                                        <option value="2022">2022</option>
                                        <option value="2023">2023</option>
                                        <option value="2024">2024</option>
                                        <option value="2025">2025</option>
                                        <option value="2026">2026</option>
                                        <option value="2027">2027</option>
                                        <option value="2028">2028</option>
                                        <option value="2029">2029</option>
                                        <option value="2030">2030</option>
                                        <option value="2031">2031</option>
                                        <option value="2032">2032</option>
                                        <option value="2033">2033</option>
                                        <option value="2034">2034</option>
                                        <option value="2035">2035</option>
                                        <option value="2036">2036</option>
                                        <option value="2037">2037</option>
                                    </select>
                                </div>
                                <div class="clearfix"></div>
                            </div>
                        </div>
                        <div class="col-lg-5">
                            <div class="form-line">
                                <label style="font-weight: normal;">CVV:</label>
                                <input type="text" name="cardSecurityCode" maxlength=4>
                            </div>
                        </div>


                        <div class="col-lg-10 col-lg-offset-1">
                            <div class="terms">
                                @if(session('landing') == 3)
                                    <div class="chk-tos">
                                        <label>
                                            <input type="checkbox" name="confirmTOS" isRequired>
                                            I agree to the <a href="#offer-terms" data-lity>Offer Terms</a>, <a href="/pages/terms-and-conditions" data-lity>Terms and Conditions</a> and <a href="/pages/privacy-policy" data-lity>Privacy Policy</a>.
                                        </label>

                                    </div>
                                @elseif(session('landing') == 1)
                                    <div class="chk-tos">
                                        <label>
                                            <input type="checkbox" name="confirmTOS" isRequired style="margin-bottom:0;">
                                            I agree to the <a href="/pages/terms-and-conditions" data-lity>Terms and Conditions</a> and <a href="/pages/privacy-policy" data-lity>Privacy Policy</a> explaining that I will be billed $3.95 for the S&H and if I don't cancel within 14 days (10 days + 4 days) Shipping trial period, I will be billed $29. I will be enrolled in a monthly subscription and receive a new 30-days supply each month for $59.99 (free shipping) until I call (844) 383-4637 to cancel my subscription.
                                        </label>

                                    </div>
                                @else
                                    <input type="hidden" name="confirmTOS" value="1">
                                    By clicking below you agree to the <a href="/pages/terms-and-conditions" data-lity>Terms and Conditions</a> and <a href="/pages/privacy-policy" data-lity>Privacy Policy</a>
                                @endif
                            </div>
                            <div class="cta">
                                <div class="info_msg"></div>
                                <div class="error_msg"></div>
                                <button style="font-size: 30px;" type="submit" value="" class="cta-btn" alt="Send My Trial Now!"  id="kformSubmit">Complete Checkout </button>

                                <input type="hidden" name="orderItems" value="">

                                @if(session('landing') == 3 || session('landing') == 1)
                                    <div class="security2">
                                        <a href="https://www.mcafeesecure.com/verify?host=bionuvo.com" data-lity><img src="/landing1/img/security2.png" alt="McAfee Secure"></a>
                                    </div>
                                @else
                                    <div class="security"></div>
                                @endif
                            </div>
                        </div>
                    </div>

                </form>
            </div>
          
          <div class="col-sm-2">
          </div>
        </div>
    </div>
    <div class="image_loading" style="background-color: rgba(255,255,255,0.7);position: absolute;z-index: +100 !important;width: 90%;height: 100%;display: none;">
      <img src="/uploads/loading_over.gif" class="img-responsive" style="position: relative;top: 26%;left: 34%;"/>
    </div>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
    <script src="/js/bootbox.min.js"></script>
    <script>
        $(document).ready(function(){
            $('#country, #shipCountry').val('US');
        });
    </script>

    <script>
        fbq('track', 'AddToCart');
    </script>
    <script>
        setTimeout(function(){ $("#dispalyState").append('<option value="<?php echo $state1;?>" selected><?php echo $state1;?></option>'); }, 1000);
  </script>
  <script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.17.0/dist/jquery.validate.min.js"></script>
    <script>
        function getUrlVars() {
            var vars = {};
            var parts = window.location.href.replace(/[?&]+([^=&]+)=([^&]*)/gi, function(m,key,value) {
            vars[key] = value;
            });
            return vars;
        }

        $(document).ready(function() {
        $.validator.setDefaults({
                ignore: []
        });
        $(".kform23").validate({
            rules: {
            cardNumber: {
                required: true,
                number: true
            },
            cardMonth: {
                required: true
            },
            cardYear: {
                required: true
            },
            cardSecurityCode: {
                required: true,
                number: true
            }
            },
            messages: {             
                cardNumber: {                    
                    required: "Please your enter Card Number."
                },
                cardMonth: {                 
                    required: "Please your enter Card Month.",
                },
                cardYear: {                 
                    required: "Please your enter Card Year.",
                },
                cardSecurityCode: {                 
                    required: "Please your enter Card Security Code.",
                }
            },
            submitHandler: function(form,event){
            event.preventDefault();// using this page stop being refreshing
            var cardNumber = $('[name=cardNumber]').val();
            var cardSecurityCode = $('[name=cardSecurityCode]').val();
            var cardMonth = $('select[name=cardMonth]').val();
            var cardYear = $('select[name=cardYear]').val();
            var pro_id = $('[name=pro_id]').val();
            var orderId = $('[name=orderId]').val();
            //console.log(orderId);
            //return false;
            var pre_url = "https://api.konnektive.com/order/import/?loginId=bionuvoteam&password=fissionthetech1&orderId="+orderId+"&paySource=CREDITCARD&";
pre_url += "cardNumber="+cardNumber+"&cardSecurityCode="+cardSecurityCode+"&cardYear="+cardYear+"&cardMonth="+cardMonth+"&campaignId=12&product1_id="+pro_id+"&product1_qty=1";
            //alert(pre_url);
            //console.log(pre_url);
            //return false;
            $.ajax({
                url: pre_url,
                type: 'GET',
                dataType: "json",
                //data: $(form).serialize(),
                beforeSend: function(){
                    $('.image_loading').show();
                },
                complete: function(){
                    $('.image_loading').hide();
                },
                success: function(res) {
                    //console.log(res)
                    //return false;
                    if(res.result=="SUCCESS"){
                      $('.error_msg').hide();
                      $('.info_msg').show();
                      var red_url = form.action+"/"+pro_id+"/"+res.message.orderId;
                      //alert(pro_id);
                      //return false;
                      window.location.href = red_url;
                    }else{
                      //$('.error_msg').show();
                      //$('.info_msg').hide();
                      //$('.error_msg').html(res.message);
                      bootbox.alert(res.message);
                    }
                }            
            });
        }
        });
        });
    </script>
@endsection