<?php
class Buyer_model extends CI_Model
{

    function __construct()
    {
        parent::__construct();
    }
    
    /**
     * get_buyers_list()
     * Get Buyers List
     * @author GOPI PANGULURI<gopi.panguluri@mindtechlabs.com>
     */
    public function get_buyers_list($date='') {
        $tableName = 'users';
        $columns   = array("$tableName.user_id",
                           "$tableName.name",
                           "$tableName.mobile",
                           "$tableName.email",
                           "$tableName.created_on",
                           "$tableName.status",
                           "$tableName.user_id"
                          );
        $indexId     = '$tableName.user_id';
        $columnOrder = "$tableName.user_id";
        $orderby     = "";
        $joinMe      = "";
        if($_SESSION['admin_role_id']!==4||$_SESSION['admin_role_id']==5){
            $condition   = " WHERE $tableName.type= '2' ";            
        }else{
            $condition   = " WHERE $tableName.teacher_id!= '' ";
        }
        //$condition   = " WHERE $tableName.teacher_id!= '' AND $tableName.sc_id= '".$_SESSION['admin_user_id']."' ";
        return $this->db->drawdatatable($tableName, $columns, $indexId, $joinMe, $condition, $orderby);
    }
}