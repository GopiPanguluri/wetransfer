<?php
class Franchise_model extends CI_Model
{

    function __construct()
    {
        parent::__construct();
    }
    
    /**
     * get_franchises_list()
     * Get franchises List
     * @author GOPI PANGULURI<gopi.panguluri@mindtechlabs.com>
     */
    public function get_franchise_list($date='') {
        $tableName = 'users';
        $columns   = array("$tableName.user_id",
                           "$tableName.name",
                           "$tableName.mobile",
                           "$tableName.email",
                           "$tableName.created_on",
                           "$tableName.status",
                           "$tableName.user_id"
                          );
        $indexId     = '$tableName.user_id';
        $columnOrder = "$tableName.user_id";
        $orderby     = "";
        $joinMe      = "";
        $condition   = " WHERE $tableName.type= '4' ";
        //$condition   = " WHERE $tableName.teacher_id!= '' AND $tableName.sc_id= '".$_SESSION['admin_user_id']."' ";
        return $this->db->drawdatatable($tableName, $columns, $indexId, $joinMe, $condition, $orderby);
    }
}