<?php

class Packages_model extends CI_Model {
        
    /**
     * get_reg_users()
     * get the registered users list
     * @author GOPI PANGULURI<gopi.panguluri@mindtechlabs.com>
     */
    public function get_packages_list() {
        $tableName = 'packages';
        $columns   = array("$tableName.p_id",
                           "$tableName.p_feature_name",
                           "$tableName.added_date",
                           "$tableName.status",
                           "$tableName.p_id"
                          );
        $indexId     = '$tableName.p_id';
        $columnOrder = "$tableName.p_id";
        $orderby     = "";
        $joinMe      = "";
        $condition   = "";
        $condition   = " WHERE $tableName.p_id!= '' ";
        //$condition   = " WHERE $tableName.c_id!= '' AND $tableName.sc_id= '".$_SESSION['admin_user_id']."' ";
        return $this->db->drawdatatable($tableName, $columns, $indexId, $joinMe, $condition, $orderby);
    }
    
    /**
     * get_parents_list()
     * get Parents List
     * @author GOPI PANGULURI<gopi.panguluri@mindtechlabs.com>
     */
    public function get_user_types(){
        $this->db->select('*');
        $this->db->from('user_types');
        $this->db->order_by('ut_name','DESC');
        $res = $this->db->get()->result_array();
        $country_list = array(''=>'Select One');
        foreach($res as $country):
            $country_list[$country['ut_id']] = $country['ut_name'];
        endforeach;
        //echo '<pre>'; print_r($country_list);exit;
        return $country_list;
    }
    
    /**
     * get_schools_list()
     * get Schools List
     * @author GOPI PANGULURI<gopi.panguluri@mindtechlabs.com>
     */
    public function get_schools_list($id='') {
        $this->db->select('*');
        $this->db->from('schools');
        if($id!=''){
            $this->db->where('sc_id',$id);
        }
        $this->db->order_by('name','ASC');
        $res = $this->db->get()->result_array();
        $school_list = array(''=>'Select One');
        foreach($res as $school):
            $school_list[$school['sc_id']] = $school['name'];
        endforeach;
        //echo '<pre>'; print_r($school_list);exit;
        return $school_list;
    }
    
    /**
     * get_subjects_list()
     * get Subjects List
     * @author GOPI PANGULURI<gopi.panguluri@mindtechlabs.com>
     */
    public function get_subjects_list($id='') {
        $this->db->select('*');
        $this->db->from('subjects');
        if($id!=''){
            $this->db->where('sub_id',$id);
        }
        $this->db->order_by('sub_name','ASC');
        $this->db->join('classes', 'subjects.cl_id = classes.cl_id');
        $res = $this->db->get()->result_array();
        //echo '<pre>'; print_r($res);exit;
        $school_list = array(''=>'Select One');
        foreach($res as $school):
            $school_list[$school['sub_id']] = $school['cl_name'].'-'.$school['sub_name'];
        endforeach;
        //echo '<pre>'; print_r($school_list);exit;
        return $school_list;
    }
    
    /**
     * get_classes_list()
     * get Classes List
     * @author GOPI PANGULURI<gopi.panguluri@mindtechlabs.com>
     */
    public function get_classes_list($id='') {
        $this->db->select('*');
        $this->db->from('sections');
        if($id!=''){
            $this->db->where('sec_id',$id);
        }
        $this->db->order_by('cl_name','ASC');
        $this->db->join('classes', 'sections.cl_id = classes.cl_id');
        $res = $this->db->get()->result_array();
        //echo '<pre>'; print_r($res);exit;
        $school_list = array(''=>'Select One');
        foreach($res as $school):
            $school_list[$school['sec_id']] = $school['cl_name'].'-'.$school['sec_name'];
        endforeach;
        //echo '<pre>'; print_r($school_list);exit;
        return $school_list;
    }
    
    /**
     * insert_id_details
     * Insert Id Details
     * @author GOPI PANGULURI<gopi.panguluri@mindtechlabs.com>
     * @param type $data
     */
    public function insert_id_details($table_name, $data) {
        $result = $this->db->insert($table_name, $data);
        return $this->db->insert_id();
    }
	
	/**
     * update_techer_details
     * @param type $data
     * @author GOPI PANGULURI<gopi.panguluri@mindtechlabs.com>
     * @return type
     */
    public function update_techer_details($data) {		
        $this->db->where($data['where']);
        $result = $this->db->update($data['tablename'], $data['data']);		
        return $this->db->insert_id();
    }
    
}

?>