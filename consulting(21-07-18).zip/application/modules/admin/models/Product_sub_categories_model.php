<?php

class Product_sub_categories_model extends CI_Model {
        
    /**
     * get_reg_users()
     * get the registered users list
     * @author GOPI PANGULURI<gopi.panguluri@mindtechlabs.com>
     */
    public function get_product_sub_categories_list(){
        $tableName = 'product_categories';
        $tableName1 = 'pro_service_types';
        $columns   = array("$tableName.pro_cat_id",
                           "$tableName.pro_cat_name",
                           "$tableName.parent_id",
                           "$tableName.added_date",
                           "$tableName.status",
                           "$tableName.pro_cat_id"
                          );
        $indexId     = '$tableName.pro_cat_id';
        $columnOrder = "$tableName.pro_cat_id";
        $orderby     = "";
        $joinMe      = " ";
        //$condition   = " join $tableName1 on $tableName.pro_cat_id = $tableName1.pro_cat_id ";
        //$condition   = " ";
        $condition   = " WHERE $tableName.parent_id!= '0' ";
        //$condition   = " WHERE $tableName.pro_sub_cat_id!= '' AND $tableName.spro_sub_cat_id= '".$_SESSION['admin_user_id']."' ";
        return $this->db->drawdatatable($tableName, $columns, $indexId, $joinMe, $condition, $orderby);
    }
    
    /**
     * insert_id_details
     * Insert Id Details
     * @author GOPI PANGULURI<gopi.panguluri@mindtechlabs.com>
     * @param type $data
     */
    public function insert_id_details($table_name, $data){
        $result = $this->db->insert($table_name, $data);
        return $this->db->insert_id();
    }
	
	/**
     * update_techer_details
     * @param type $data
     * @author GOPI PANGULURI<gopi.panguluri@mindtechlabs.com>
     * @return type
     */
    public function update_techer_details($data){		
        $this->db->where($data['where']);
        $result = $this->db->update($data['tablename'], $data['data']);		
        return $this->db->insert_id();
    }
    
    
}

?>