Dear <?php echo $name; ?>,
Please confirm your email address by clicking the link below.
We may need to send you critical information about our service and it is important that we have an accurate email address.
<?php echo $conflink."<br/>"; ?>
<?php echo $this->config->item('site_title'); ?>
<?php //exit;  ?>