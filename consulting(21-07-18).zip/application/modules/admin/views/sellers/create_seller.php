<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <?php $this->load->view('common/common/css') ?>
</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">
  <?php $this->load->view('common/admin-top_nav') ?>
  <?php $this->load->view('common/admin-left_nav') ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>Seller Details
        </h1>
        <ol class="breadcrumb">
            <li><a href="<?php echo site_url('admin'); ?>"><i class="fa fa-dashboard"></i> Home </a></li>
            <li><a href="<?php echo site_url('admin/classes'); ?>"><i class="fa fa-classes"></i> Sellers </a></li>
            <li class="active"> Seller Details </li>
        </ol>
      </section>

    <!-- Main content -->
    <input type="hidden" id="page" value="nav-sellers"/>    
    <section class="content">
        <div class="box box-primary">
          <div class="panel-body">
            <?php
                $success_message = $this->session->flashdata('insert_record');
                if ($success_message['status'] == "success") {
                    echo '<p class="alert alert-success sas-succcess-message">' . $success_message['message'] . '</p><div class="clearfix"></div>';
                } else if ($success_message['status'] == "fail") {
                    echo '<p class="alert alert-danger sas-succcess-message">' . $success_message['message'] . '</p><div class="clearfix"></div>';
                }
                echo '<div class="response_alert"></div>';
            ?>  
                <div class="form-group">
                    <div class="col-md-12">
                        <a href="<?php echo site_url('admin/seller') ?>" class="btn btn-info">Back</a>
                    </div>
                </div><br /><br />            
                <div class="form-group">
                    <label class="col-md-2"> Full Name </label>
                    <div class="col-md-4">
                        <?php echo $item_details['name']; ?>
                    </div>
                    <label class="col-md-2"> User Name </label>
                    <div class="col-md-4">
                        <?php echo $item_details['username']; ?>
                    </div>
                </div><br />
                <div class="form-group">
                    <label class="col-md-2"> Email </label>
                    <div class="col-md-4">
                        <?php echo $item_details['email']; ?>
                    </div>
                    <label class="col-md-2"> Mobile </label>
                    <div class="col-md-4">
                        <?php echo $item_details['mobile']; ?>
                    </div>
                </div><br />
                <div class="form-group">
                    <label class="col-md-2"> Category </label>
                    <div class="col-md-4">
                        <?php if($item_details['c_id']!=0){ echo $categories[$item_details['c_id']]; }else{ echo 'Not Mentioned'; } ?>
                    </div>
                </div><br />
                <div class="form-group">
                    <label class="col-md-2"> Gender </label>
                    <div class="col-md-4">
                        <?php if($item_details['gender']==0){ echo 'Male'; }else{ echo 'Female'; } ?>
                    </div>
                    <label class="col-md-2"> Created On </label>
                    <div class="col-md-4">
                        <?php echo $item_details['created_on']; ?>
                    </div>
                </div><br />
                <div class="form-group">
                    <label class="col-md-2"> Last Login </label>
                    <div class="col-md-4">
                        <?php echo $item_details['last_login']; ?>
                    </div>
                    <label class="col-md-2"> Status </label>
                    <div class="col-md-4">
                        <?php if($item_details['status']==0){ echo '<span class="label bg-green">Active</span>'; }elseif($item_details['status']==1){ echo '<span class="label bg-red">Blocked</span>'; }elseif($item_details['status']==2){ echo '<span class="label bg-yellow">Account not activated</span>'; }else{ echo '<span class="label bg-red">Deleted</span>'; }?>
                    </div>
                </div><br />
            </div>            
        </div>
      </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <!-- Control Sidebar -->
  <?php $this->load->view('common/common/footer'); ?>
  <!-- Add the sidebar's background. This div must be placed
       immediately after the control sidebar -->
  <div class="control-sidebar-bg"></div>
</div>
<!-- ./wrapper -->

<?php $this->load->view('common/common/js') ?>
<script src="<?php echo config_item('ui_base_path') ?>custom/js/jquery.validate.min.js"></script>
<script type="">
    $(document).ready(function() {
        <?php if ($mode == 'create') { ?>
        $.validator.setDefaults({
                ignore: []
        });
            $("#customer_form").validate({
                rules: {
                cl_name: {
                    required: true,
                    remote:BASE_URL+"admin/classes/check_cl_name"
                }
                },
                
                messages: {				
                    cl_name: {					
                            required: "Class Name should not leave empty.",
                            remote:"Class Name is already taken please enter another"
                        }
                }
            });
        <?php }else{ ?>
            $("#customer_form").validate({
                    rules: {
                    cl_name: {
                        required: true
                    }
                    },
                    
                    messages: {				
                        cl_name: {					
                                required: "Class Name should not leave empty."
                            }
                    }
                });
    <?php } ?>
    });
</script>
</body>
</html>