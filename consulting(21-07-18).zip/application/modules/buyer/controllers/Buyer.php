<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Buyer extends MX_Controller{
    function __construct()
    {
        parent::__construct();
        $this->lang->load('data');
        modules::run('admin/login/is_buyer_logged_in');
    }

    // Login from search login page
    /**
	 * index()
	 * Login from search login page
	 * @author GOPI PANGULURI<gopi.panguluri@mindtechlabs.com>
	 */
    public function index()
    {
        //$this->dashboard();
        //$info = array(
//            'select_fields' => '',
//            'where' => array(
//            ),
//            'where_in' => array(
//                'ut_id' => '2,3'
//            ),
//            'tablename' => 'categories'
//        );
        $this->load->model('common_model');
        $ids = "2,3";
        $category = $this->common_model->get_cat_list($ids);
        $data['category'] = array(''=>'Select one');
        foreach($category as $row):
            $data['category'][$row['c_id']] = $row['c_name'];
        endforeach;
        
        $info_com = array(
            'select_fields' => '',
            'where' => array(
            ),
            'where_in' => array(
            ),
            'tablename' => 'company_types'
        );
        $this->load->model('seller/seller_model');
        $com_types = $this->seller_model->get_tz_list($info_com);
        $data['com_types'] = array(''=>'Select one');
        foreach($com_types as $row):
            $data['com_types'][$row['ct_id']] = $row['ct_name'];
        endforeach;
        
        $info_tz = array(
            'select_fields' => '',
            'where' => array(
            ),
            'where_in' => array(
            ),
            'tablename' => 'timezones'
        );
        $this->load->model('common_model');
        $info_tz = $this->common_model->get_list_where_in($info_tz);
        $data['tz_list'] = array(''=>'Select one');
        foreach($info_tz as $row):
            $data['tz_list'][$row['tz_id']] = $row['timezone'].' (GMT'.$row['utc_offset'].')';
        endforeach;
        $this->load->view('buyer_details',$data);
    }


    public function dashboard()
    {
        $this->load->view('buyer_dashboard');
    }
    
    public function banners()
    {
        $this->load->view('banners/banners');
    }
    
    public function get_banners_list()
    {
        $this->load->model('buyer_model');
        $result = $this->buyer_model->get_banners_list();
        $aaData = array();
        foreach($result['aaData'] as $row){
            $row[0] = '<input type="checkbox" id="checkbox-1-' . intval($row[0]) . '" class="checkbox1 regular-checkbox" name="regular-checkbox"
                                value="' . $row[0] . '"/><label for="checkbox-1-' . intval($row[0]) . '"></label>';
            $row[2] = '<img src="'. base_url('assets/images/banners/'.$row[2]).'" height="120" width="150"/>';
            if($row[4]==1){
                $row[4] = '<div id="status' . $row[5] . '">
                        <a href="javascript:void(0);" class="show-tooltip" title="Change Status" onclick="changestatus(' . $row[5] . ', ' . $row[4] . ')" >
                                <i class="glyphicon glyphicon-remove"></i>
                        </a></div> ';   
            }else{
                $row[4] = '<div id="status' . $row[5] . '">
                        <a href="javascript:void(0);" class="show-tooltip" title="Change Status" onclick="changestatus(' . $row[5] . ', ' . $row[4] . ')" >
                                <i class="glyphicon glyphicon-ok"></i>
                        </a></div> ';
            }
            $row[5] = '<a href="'.base_url('admin/create_banner/')  ."/". $row[5] . '" title="Edit Record" data-toggle="tooltip">
                                <i class="fa_size fa fa-pencil" ></i></a>
                         <a href="javascript:void(0)" data-toggle="tooltip" id="' . $row[5] . '" class="deleteme show-tooltip deleteitem_' . $row[5] . '"" title="Delete Record" data-tablename="banners" data-fieldname="banner_id" url="'. site_url('admin/admin/delete_all_record') .'">
                                <i class="fa_size fa fa-trash-o "></i></a>';
            $aaData[] = $row;
        }
        $result['aaData'] = $aaData;
        //echo '<pre>'; print_r($result);exit;
        print_r(json_encode($result));
    }
    
    /**
    * addto_negotiation
    * Add To Negotiation
    * @author GOPI PANGULURI<gopi.panguluri@mindtechlabs.com>
    * @param type $data
    */
    public function addto_negotiation() {
        //echo '<pre>'; print_r($_POST);exit;
        //echo '<pre>'; print_r($_SESSION);exit;
        $this->load->model('common_model');
        $user = $_SESSION['buyer_type'].'-'.$_SESSION['buyer_user_id'];
        $info = array(
                'select_fields' => '',
                'where' => array(
                    $_POST['field_name'] => $_POST['row_id']
                ),
                'tablename' => $_POST['table_name']
        );
        //echo '<pre>'; print_r($info);exit;
        $item_details = $this->common_model->get_individual_details($info);
        //echo '<pre>'; print_r($item_details);exit;
        if ($_POST['status'] == "0") {
        
            if(count($item_details)==0){
                $info_in = array(
                    $_POST['field_name'] => $_POST['row_id'],
                    'users' => $user,
                );
                //echo '<pre>insert'; print_r($info_in);exit;
                $result = $this->common_model->insert_details($_POST['table_name'], $info_in);
            }else{
                $info_up = array(
                    'where' => array(
                        $_POST['field_name'] => $_POST['row_id']
                    ),
                    'data' => array(
                        'users' => $item_details['users'].','.$user,
                    ),
                    'tablename' => $_POST['table_name']
                );
                //echo '<pre>update'; print_r($info_up);exit;
                $result = $this->common_model->update_details($info_up);
            }
        } else {
            $users = explode(',',$item_details['users']);
            //echo '<pre>'; print_r($users);exit;
            if (in_array($user, $users)) {
                $users = array_flip($users);
                unset($users[ $user ]);
                $users = array_flip($users);
            }
            $users = implode(',',$users);
            //echo '<pre>'; print_r($users);exit;
            $info_up = array(
                'where' => array(
                    $_POST['field_name'] => $_POST['row_id']
                ),
                'data' => array(
                    'users' => $users,
                ),
                'tablename' => $_POST['table_name']
            );
            $result = $this->common_model->update_details($info_up);            
        }
        //echo $this->db->last_query();
        //echo '<pre>'; print_r($result);exit;
        if($result){
            echo "1";
        }else{
            echo "0";
        }
    }
    
    /**
    * get_states_list
    * Get States List
    * @author GOPI PANGULURI<gopi.panguluri@mindtechlabs.com>
    * @param type $data
    */
    public function get_states_list(){
        //echo '<pre>'; print_r($_POST);exit;
        $this->load->model('address_model');
        $id = $this->input->post('id');
        $data['states'] = $this->address_model->get_states_list($id);
        if($data['states']){
            $data['status'] = 0;
        }else{
            $data['status'] = 1;
        }
        //echo '<pre>'; print_r($states);exit;
        echo json_encode($data);
    }
    
    /**
    * get_states_list
    * Get States List
    * @author GOPI PANGULURI<gopi.panguluri@mindtechlabs.com>
    * @param type $data
    */
    public function get_cities_list(){
        $this->load->model('address_model');
        $id = $this->input->post('id');
        $data['states'] = $this->address_model->get_cities_list($id);
        if($data['states']){
            $data['status'] = 0;
        }else{
            $data['status'] = 1;
        }
        //echo '<pre>'; print_r($states);exit;
        echo json_encode($data);
    }
    
    /**
    * changestatus
    * Change Status
    * @author GOPI PANGULURI<gopi.panguluri@mindtechlabs.com>
    * @param type $data
    */
    public function changestatus() {
        //echo '<pre>'; print_r($_POST);
        $this->load->model('common/common_model');
        if ($_POST['status'] == "1") {
            $status = "0";
        } else {
            $status = "1";
        }
        $info = array(
            'where' => array(
                $_POST['field_name'] => $_POST['row_id']
            ),
            'data' => array(
                'status' => $status,
            ),
            'tablename' => $_POST['table_name']
        );
        //echo '<pre>'; print_r($info);exit;
        $result = $this->common_model->update_details($info);
        //echo $this->db->last_query();exit;
        if ($result) {
            echo "1";
        } else {
            echo "0";
        }
    }
    
    
    /**
    * delete_all_record
    * Delete All Record
    * @author GOPI PANGULURI<gopi.panguluri@mindtechlabs.com>
    * @param type $data
    */
    public function delete_all_record() {
        //print_r($_POST); exit;
        $this->load->model('common_model');
        $info = array(
            'where' => array(
                $_POST['field_name'] => $_POST['deleteme']
            ),
            'tablename' => $_POST['table_name']
        );
        $result = $this->common_model->delete_all_record($_POST['table_name'], $_POST['field_name'], $_POST['deleteme']);
        if ($result) {
            echo "1";
        } else {
            echo "0";
        }
    }
    
    function page_not_found()
    {
        //$this->output->cache(360);
        log_message("INFO", '404:' . $this->uri->uri_string());
        $this->load->view('page_not_found');
    }	
}
