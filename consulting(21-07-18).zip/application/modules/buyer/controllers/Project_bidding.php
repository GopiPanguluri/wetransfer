<?php if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Project_bidding extends MX_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->lang->load('data');
        $this->load->model('common/upload_model');
        $this->load->model('common/common_model');
        $this->load->model('common/common_functions_model');
        $this->load->model('project_bidding_model');
        modules::run('admin/login/is_buyer_logged_in');
    }
    
    public function index()
    {
        $this->load->view('project_bidding/project_bidding');
    }
    
    /**
    * get_project_bidding_list
    * Get Project bidding List
    * @author GOPI PANGULURI<gopi.panguluri@mindtechlabs.com>
    * @param type $data
    */
    public function get_project_bidding_list()
    {
        $result = $this->project_bidding_model->get_project_bidding_list();
        //echo $this->db->last_query();
        //echo '<pre>'; print_r($result);exit;
        $aaData = array();
        foreach($result['aaData'] as $row){
                $row[0] = '<input type="checkbox" id="checkbox-1-' . intval($row[0]) . '" class="checkbox1 regular-checkbox" name="regular-checkbox"
                                    value="' . $row[0] . '"/><label for="checkbox-1-' . intval($row[0]) . '"></label>';
                $row[3] = date('Y-M-d h:i:s a',strtotime($row[3]));
                $row[4] = date('Y-M-d h:i:s a',strtotime($row[4]));
                    $row[5] = '<a href="'.base_url('buyer/project_bidding/project_bidding_details/'). $row[5] . '/details" title="Go to Project Bidding" data-toggle="tooltip">
                                <i class="fa_size fa fa-eye"></i></a>';
            $aaData[] = $row;
        }
        $result['aaData'] = $aaData;
        //echo '<pre>'; print_r($result);exit;
        print_r(json_encode($result));
    }
    
   /**
    * create_news
    * Create News
    * @author GOPI PANGULURI<gopi.panguluri@mindtechlabs.com>
    * @param type $data
    */
    public function project_bidding_details($id) {
        //echo '<pre>';print_r($_FILES);
        //echo '<pre>';print_r($_POST);exit;
        $data['addresses'] = $this->project_bidding_model->get_address_list($_SESSION['buyer_user_id']);
        $data['product_cat'] = $this->common_functions_model->get_product_or_service_list('1');
        $data['service_cat'] = $this->common_functions_model->get_product_or_service_list('2');
        $data['currency_types'] = $this->config->item('currency_types');
        $data['payment_terms'] = $this->config->item('payment_terms');
        $data['messures'] = $this->config->item('messures');
        if ($id != ''){
            $data['msg'] = '';
            $info = array(
                'select_fields' => '',
                'where' => array(
                    'r_id' => $id
                ),
                'tablename' => 'requirements'
            );
            $data['item_details'] = $this->common_model->get_individual_details($info);
            $info = array(
            'select_fields' => 'negotiation_round',
            'where' => array(
                'r_id' => $id
            ),
            'tablename' => 'project_bidding'
            );
            $item_details = $this->common_model->get_list($info);
            $row_pro_list = array();
            foreach($item_details as $row_pb_list){
                $row_pro_list[$row_pb_list['negotiation_round']] = 'Negotiation round '.$row_pb_list['negotiation_round'];
                $list_pb[] = $row_pro_list;
            }
            //echo '<pre>';print_r($row_pro_list);exit;
            $data['ngo_count'] = count($row_pro_list);
            $data['negotiations'] = array_reverse($row_pro_list,true);
            //$data['negotiations'] = $row_pro_list;
            //$selected_srt = $this->project_bidding_model->get_short_sellers_list(explode(',',$data['item_details']['selected_negotiation']));
            //foreach(explode(',',$data['item_details']['selected_negotiation']) as $row_srt){
//                echo '<pre>';print_r($row_srt);exit;
//            }
            
            $shortlist_users_list = $this->project_bidding_model->get_shortlist_list($data['item_details']['selected_negotiation']);
            $st_list = array('0'=>'Select One');
            foreach($shortlist_users_list as $stls):
                $st_list[$stls['user_id']] = $stls['name'];
            endforeach;
            $data['shortlist_list'] = $st_list;
                                    
            $info_items = array(
                'select_fields' => '',
                'where' => array(
                    'r_id' => $id
                ),
                'tablename' => 'req_items'
            );
            $data['req_items'] = $this->common_model->get_list($info_items);
            
            $info_catelog = array(
                'select_fields' => '',
                'where' => array(
                    'r_id' => $id
                ),
                'tablename' => 'requirement_files'
            );
            $data['requirement_files'] = $this->common_model->get_list($info_catelog);
            $project_biddings = $this->project_bidding_model->get_project_bids_list($id);
            //echo '<pre>';print_r($project_biddings);exit;
            $project_biddings_ls = array();
            foreach($project_biddings as $rw_pb){
                //echo '<pre>';print_r($rw_pb);exit;
                $project_bidding_files = $this->project_bidding_model->get_project_bidding_files_list($rw_pb['pb_id']);
                $project_bidding_items = $this->project_bidding_model->get_project_bidding_items_list($rw_pb['pb_id']);
                $project_bidding_taxes = $this->project_bidding_model->get_project_bidding_taxes_list($rw_pb['pb_id']);
                $rw_pb['bidding_files'] = $project_bidding_files;
                $rw_pb['bidding_items'] = $project_bidding_items;
                $rw_pb['bidding_taxes'] = $project_bidding_taxes;
                $project_biddings_ls[] = $rw_pb;
            }
            $data['project_biddings'] = $project_biddings_ls;
            $info = array(
                'select_fields' => '',
                'where' => array(
                    'r_id' => $id,
                    'selected' => 'Y',
                    'negotiation_acceptance' => 'Y',
                    'negotiation' => 'Y'
                ),
                'tablename' => 'project_bidding'
            );
            $data['bid_selected'] = $this->common_model->get_individual_details($info);
            //echo '<pre>';print_r($data['bid_selected']);exit;
            $this->load->view('project_bidding/biding_details', $data);
        }
    }
    
    /**
    * requirement_details
    * requirement Details
    * @author GOPI PANGULURI<gopi.panguluri@mindtechlabs.com>
    * @param type $data
    */
    public function requirement_details($id){
        $data['service_cat'] = array(''=>'Select one','1'=>'Electrician','2'=>'Painter','4'=>'AC Repair','5'=>'Carpenter','6'=>'Full home cleaning','7'=>'Plumber');
        $data['requirement_cat'] = array(''=>'Select one','1'=>'TMT Steels','2'=>'Cement','3'=>'Agri Commodities','4'=>'Gold','5'=>'Sugar Domestic');
        $data['mode'] = 'details';
        $data['msg'] = '';
        $info = array(
            'select_fields' => '',
            'where' => array(
                'r_id' => $id
            ),
            'tablename' => 'project_bidding'
        );
        $data['item_details'] = $this->common_model->get_individual_details($info);
        //echo '<pre>';print_r($data);exit;
        $this->load->view('Project_bidding/create_requirement', $data);
    }
    
    /**
    * create_negotiation_proc
    * Create Negotiation Process
    * @author GOPI PANGULURI<gopi.panguluri@mindtechlabs.com>
    * @param type $data
    */
    public function create_negotiation_proc(){
        //echo '<pre>'; print_r($_POST);exit;
        //echo '<pre>'; print_r($item_details);exit;
        foreach(explode(',',$_POST['change_status']) as $row_sel_sellers){
            //echo $row_sel_sellers;exit;
            $info = array(
            'select_fields' => 'negotiation_round',
            'where' => array(
                'user_id' => $row_sel_sellers,
                'r_id' => $_POST['r_id']
            ),
            'tablename' => 'project_bidding'
            );
            $item_details = $this->common_model->get_list($info);
            $neg_count = count($item_details);
            //echo '<pre>'; print_r($neg_count);exit;
            $info_bid = array(
                    'user_id' => $row_sel_sellers,
                    'negotiation' => 'N',
                    'selected' => 'N',
                    'negotiation_round' => $neg_count, 
                    'r_id' => $_POST['r_id']
                   );
            //echo '<pre>'; print_r($info_bid);exit;
            $result = $this->common_model->insert_details('project_bidding', $info_bid);
            $info_msg = array(
                    'user_id' => $row_sel_sellers,
                    'r_id' => $_POST['r_id'],
                    'notification_text' => 'You have been shortlisted and invited for negotiation round '.$neg_count, 
                    'notification_type' => 'N'
            );
            //echo '<pre>'; print_r($info_msg);exit;
            $result_nft = $this->common_model->insert_details('notifications', $info_msg);
        }
        //echo '<pre>'; print_r($result);exit;
        //echo $this->db->last_query();exit;
        if($result&&$result_nft){
            echo "1";
        }else{
            echo "0";
        }
    }
    
    
    
    /**
    * create_negotiation_proc
    * Create Negotiation Process
    * @author GOPI PANGULURI<gopi.panguluri@mindtechlabs.com>
    * @param type $data
    */
    public function select_seller_bid(){
        //echo '<pre>'; print_r($_POST);exit;
        $row_sel_sellers = explode(',',$_POST['data']);
        $row_sel_sellers = $row_sel_sellers[0];
        //echo $row_sel_sellers;exit;
            $info = array(
            'select_fields' => 'negotiation_round',
            'where' => array(
                'user_id' => $row_sel_sellers,
                'r_id' => $_POST['r_id']
            ),
            'tablename' => 'project_bidding'
            );
            $item_details = $this->common_model->get_list($info);
            $neg_count = count($item_details)-1;
            //echo '<pre>'; print_r($neg_count);exit;
            $info_items_up = array(
                'where' => array(
                    'user_id' => $row_sel_sellers,
                    'negotiation_round' => $neg_count, 
                    'r_id' => $_POST['r_id']
                ),
                'data' => array(
                    'selected' => 'Y'
                ),
                'tablename' => 'project_bidding'
            );
            //echo "<pre>";print_r($info_items_up);exit;
            $result = $this->common_model->update_details($info_items_up);
            //echo '<pre>'; print_r($info_bid);exit;
            $info_msg = array(
                    'user_id' => $row_sel_sellers,
                    'r_id' => $_POST['r_id'],
                    'notification_text' => 'Congratulations! Your bid has been selected at negotiation round '.$neg_count, 
                    'notification_type' => 'N'
            );
            //echo '<pre>'; print_r($info_msg);exit;
            $result_nft = $this->common_model->insert_details('notifications', $info_msg);
            $info_negoti = array(
                    'buyer_user_id' => $_SESSION['buyer_user_id'],
                    'seller_user_id' => $row_sel_sellers,
                    'r_id' => $_POST['r_id'], 
                    'negotiation_accept' => 'Not'
            );
            //echo '<pre>'; print_r($info_msg);exit;
            $result_nft = $this->common_model->insert_details('negotiation_members', $info_negoti);
        //echo '<pre>'; print_r($result);exit;
        //echo $this->db->last_query();exit;
        if($result&&$result_nft){
            echo "1";
        }else{
            echo "0";
        }
    } 
    
}