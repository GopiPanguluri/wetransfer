<?php

class Address_model extends CI_Model {
        
    /**
     * get_reg_users()
     * get the registered users list
     * @author GOPI PANGULURI<gopi.panguluri@mindtechlabs.com>
     */
    public function get_address_list() {
        $tableName = 'address';
        $tableName1 = 'countries';
        $tableName2 = 'address_types';
        $columns   = array("$tableName.a_id",
                           "$tableName2.at_name",
                           "$tableName.a_address_line",
                           "$tableName1.name",
                           "$tableName.added_date",
                           "$tableName.status",
                           "$tableName.a_id"
                          );
        $indexId     = '$tableName.a_id';
        $columnOrder = "$tableName.a_id";
        $orderby     = "";
        $joinMe      = "left join $tableName1 on $tableName1.id=$tableName.a_country left join $tableName2 on $tableName.at_id=$tableName2.at_id";
        $condition   = " WHERE $tableName.user_id= '".$_SESSION['seller_user_id']."' ";
        //$condition   = " WHERE $tableName.a_id!= '' AND $tableName.sc_id= '".$_SESSION['admin_user_id']."' ";
        return $this->db->drawdatatable($tableName, $columns, $indexId, $joinMe, $condition, $orderby);
    }
    
    /**
     * get_countries_list()
     * get Countries List
     * @author GOPI PANGULURI<gopi.panguluri@mindtechlabs.com>
     */
    public function get_countries_list(){
        $this->db->select('*');
        $this->db->from('countries');
        $this->db->order_by('name','ASC');
        $res = $this->db->get()->result_array();
        foreach($res as $country):
            $country_list[$country['id']] = $country['name'].' => '.$country['sortname'];
        endforeach;
        //echo '<pre>'; print_r($country_list);exit;
        return $country_list;
    }
    
    /**
     * get_countries_list()
     * get Countries List
     * @author GOPI PANGULURI<gopi.panguluri@mindtechlabs.com>
     */
    public function get_states_list($id='') {
        $this->db->select('*');
        $this->db->from('states');
        if($id!=''){
            $this->db->where('country_id',$id);
        }
        $this->db->order_by('state_name','ASC');
        $res = $this->db->get()->result_array();
        //foreach($res as $country):
//            $country_list[$country['id']] = $country['name'];
//        endforeach;
        //echo '<pre>'; print_r($country_list);exit;
        return $res;
    }
    
    /**
     * get_countries_list()
     * get Countries List
     * @author GOPI PANGULURI<gopi.panguluri@mindtechlabs.com>
     */
    public function get_cities_list($id='') {
        $this->db->select('*');
        $this->db->from('cities');
        if($id!=''){
            $this->db->where('state_id',$id);
        }
        $this->db->order_by('city_name','ASC');
        $res = $this->db->get()->result_array();
        //foreach($res as $country):
//            $country_list[$country['id']] = $country['name'].' => '.$country['sortname'];
//        endforeach;
        //echo '<pre>'; print_r($res);exit;
        return $res;
    }
    
    /**
     * get_address_types_list()
     * get Address Types List
     * @author GOPI PANGULURI<gopi.panguluri@mindtechlabs.com>
     */
    public function get_address_types_list(){
        $this->db->select('*');
        $this->db->from('address_types');
        $this->db->order_by('at_name','ASC');
        $res = $this->db->get()->result_array();
        foreach($res as $a_types):
            $a_types_list[$a_types['at_id']] = $a_types['at_name'];
        endforeach;
        //echo '<pre>'; print_r($a_types_list);exit;
        return $a_types_list;
    }
    
    /**
     * insert_id_details
     * Insert Id Details
     * @author GOPI PANGULURI<gopi.panguluri@mindtechlabs.com>
     * @param type $data
     */
    public function insert_id_details($tabla_name, $data) {
        $result = $this->db->insert($tabla_name, $data);
        return $this->db->insert_id();
    }
	
	/**
     * update_techer_details
     * @param type $data
     * @author GOPI PANGULURI<gopi.panguluri@mindtechlabs.com>
     * @return type
     */
    public function update_techer_details($data) {		
        $this->db->where($data['where']);
        $result = $this->db->update($data['tablename'], $data['data']);		
        return $this->db->insert_id();
    }
    
}

?>