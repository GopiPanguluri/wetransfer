<?php

class Products_model extends CI_Model {
        
    /**
     * get_reg_users()
     * get the registered users list
     * @author GOPI PANGULURI<gopi.panguluri@mindtechlabs.com>
     */
    public function get_products_list() {
        $tableName = 'products';
        $tableName1 = 'pro_service_types';
        $tableName2 = 'users';
        $columns   = array("$tableName.product_id",
                           "$tableName.product_image",
                           "$tableName.product_name",
                           "$tableName.product_price",
                           "$tableName1.pst_name",
                           "$tableName.added_date",
                           "$tableName.status",
                           "$tableName.product_id"
                          );
        $indexId     = '$tableName.product_id';
        $columnOrder = "$tableName.product_id";
        $orderby     = "";
        $joinMe      = "left join $tableName1 on $tableName1.pst_id=$tableName.type";
        $condition   = " WHERE $tableName.product_id!= '' ";        
        //$condition   = " WHERE $tableName.product_id!= '' AND $tableName.sc_id= '".$_SESSION['admin_user_id']."' ";
        return $this->db->drawdatatable($tableName, $columns, $indexId, $joinMe, $condition, $orderby);
    }
    
    /**
     * get_parents_list()
     * get Parents List
     * @author GOPI PANGULURI<gopi.panguluri@mindtechlabs.com>
     */
    public function get_parents_list() {
        $this->db->select('*');
        $this->db->from('parents');
        $this->db->order_by('parent_name','ASC');
        $res = $this->db->get()->result_array();
        $country_list = array(''=>'Select One');
        foreach($res as $country):
            $country_list[$country['parent_id']] = $country['parent_name'];
        endforeach;
        //echo '<pre>'; print_r($country_list);exit;
        return $country_list;
    }
    
    /**
     * get_schools_list()
     * get Schools List
     * @author GOPI PANGULURI<gopi.panguluri@mindtechlabs.com>
     */
    public function get_schools_list($id='') {
        $this->db->select('*');
        $this->db->from('schools');
        if($id!=''){
            $this->db->where('sc_id',$id);
        }
        $this->db->order_by('name','ASC');
        $res = $this->db->get()->result_array();
        $school_list = array(''=>'Select One');
        foreach($res as $school):
            $school_list[$school['sc_id']] = $school['name'];
        endforeach;
        //echo '<pre>'; print_r($school_list);exit;
        return $school_list;
    }
    
    /**
     * get_subjects_list()
     * get Subjects List
     * @author GOPI PANGULURI<gopi.panguluri@mindtechlabs.com>
     */
    public function get_subjects_list($id='') {
        $this->db->select('*');
        $this->db->from('subjects');
        if($id!=''){
            $this->db->where('sub_id',$id);
        }
        $this->db->order_by('sub_name','ASC');
        $this->db->join('classes', 'subjects.cl_id = classes.cl_id');
        $res = $this->db->get()->result_array();
        //echo '<pre>'; print_r($res);exit;
        $school_list = array(''=>'Select One');
        foreach($res as $school):
            $school_list[$school['sub_id']] = $school['cl_name'].'-'.$school['sub_name'];
        endforeach;
        //echo '<pre>'; print_r($school_list);exit;
        return $school_list;
    }
    
    /**
     * get_classes_list()
     * get Classes List
     * @author GOPI PANGULURI<gopi.panguluri@mindtechlabs.com>
     */
    public function get_classes_list($id='') {
        $this->db->select('*');
        $this->db->from('sections');
        if($id!=''){
            $this->db->where('sec_id',$id);
        }
        $this->db->order_by('cl_name','ASC');
        $this->db->join('classes', 'sections.cl_id = classes.cl_id');
        $res = $this->db->get()->result_array();
        //echo '<pre>'; print_r($res);exit;
        $school_list = array(''=>'Select One');
        foreach($res as $school):
            $school_list[$school['sec_id']] = $school['cl_name'].'-'.$school['sec_name'];
        endforeach;
        //echo '<pre>'; print_r($school_list);exit;
        return $school_list;
    }
    
    /**
     * insert_id_details
     * Insert Id Details
     * @author GOPI PANGULURI<gopi.panguluri@mindtechlabs.com>
     * @param type $data
     */
    public function insert_id_details($table_name, $data) {
        $result = $this->db->insert($table_name, $data);
        return $this->db->insert_id();
    }
	
	/**
     * update_techer_details
     * @param type $data
     * @author GOPI PANGULURI<gopi.panguluri@mindtechlabs.com>
     * @return type
     */
    public function update_techer_details($data) {		
        $this->db->where($data['where']);
        $result = $this->db->update($data['tablename'], $data['data']);		
        return $this->db->insert_id();
    }
	
	/**
     * get_product_or_service_list
     * @param type $data
     * @author GOPI PANGULURI<gopi.panguluri@mindtechlabs.com>
     * @return type
     */
    public function get_product_or_service_list($id){
        $this->db->select('*');
        $this->db->from('product_categories');
        $this->db->where('pro_type',$id);
        $this->db->order_by('pro_cat_name','DESC');
        $res = $this->db->get()->result_array();
        $country_list = array(''=>'Select One');
        foreach($res as $country):
            $country_list[$country['pro_cat_id']] = $country['pro_cat_name'];
        endforeach;
        //echo '<pre>'; print_r($country_list);exit;
        return $country_list;
    }
    
}

?>