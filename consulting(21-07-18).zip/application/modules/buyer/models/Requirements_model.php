<?php

class Requirements_model extends CI_Model {
        
    /**
     * get_reg_users()
     * get the registered users list
     * @author GOPI PANGULURI<gopi.panguluri@mindtechlabs.com>
     */
    public function get_requirements_list() {
        $tableName = 'requirements';
        $tableName1 = 'pro_service_types';
        $tableName2 = 'users';
        $columns   = array("$tableName.r_id",
                           "$tableName.enquire_time_from",
                           "$tableName.enquire_time_to",
                           "$tableName.description",
                           "$tableName.added_date",
                           "$tableName.status",
                           "$tableName.r_id"
                          );
        $indexId     = '$tableName.r_id';
        $columnOrder = "$tableName.r_id";
        $orderby     = "";
        $joinMe      = "";
        $condition   = " WHERE $tableName.user_id= '".$_SESSION['buyer_user_id']."' ";        
        //$condition   = " WHERE $tableName.r_id!= '' AND $tableName.sc_id= '".$_SESSION['admin_user_id']."' ";
        return $this->db->drawdatatable($tableName, $columns, $indexId, $joinMe, $condition, $orderby);
    }
    
    /**
     * get_parents_list()
     * get Parents List
     * @author GOPI PANGULURI<gopi.panguluri@mindtechlabs.com>
     */
    public function get_parents_list() {
        $this->db->select('*');
        $this->db->from('parents');
        $this->db->order_by('parent_name','ASC');
        $res = $this->db->get()->result_array();
        $country_list = array(''=>'Select One');
        foreach($res as $country):
            $country_list[$country['parent_id']] = $country['parent_name'];
        endforeach;
        //echo '<pre>'; print_r($country_list);exit;
        return $country_list;
    }
    
    /**
     * get_shortlist_list()
     * get shortlist List
     * @author GOPI PANGULURI<gopi.panguluri@mindtechlabs.com>
     */
    public function get_shortlist_list($id=''){
        $this->db->select('negotiation_list.*,products.product_name,users.user_id,users.name');
        $this->db->from('negotiation_list');
        if($id!=''){
            $this->db->where('sub_id',$id);
        }
        //$this->db->order_by('sub_name','ASC');
        $this->db->join('products', 'negotiation_list.product_id = products.product_id');
        $this->db->join('users', 'users.user_id = products.user_id');
        $res = $this->db->get()->result_array();
        //echo '<pre>'; print_r($res);exit;
        //$school_list = array(''=>'Select One');
//        foreach($res as $school):
//            $school_list[$school['sub_id']] = $school['cl_name'].'-'.$school['sub_name'];
//        endforeach;
        //echo '<pre>'; print_r($res);exit;
        return $res;
    }
    
    /**
     * get_subjects_list()
     * get Subjects List
     * @author GOPI PANGULURI<gopi.panguluri@mindtechlabs.com>
     */
    public function get_subjects_list($id='') {
        $this->db->select('*');
        $this->db->from('subjects');
        if($id!=''){
            $this->db->where('sub_id',$id);
        }
        $this->db->order_by('sub_name','ASC');
        $this->db->join('classes', 'subjects.cl_id = classes.cl_id');
        $res = $this->db->get()->result_array();
        //echo '<pre>'; print_r($res);exit;
        $school_list = array(''=>'Select One');
        foreach($res as $school):
            $school_list[$school['sub_id']] = $school['cl_name'].'-'.$school['sub_name'];
        endforeach;
        //echo '<pre>'; print_r($school_list);exit;
        return $school_list;
    }
    
    /**
     * get_classes_list()
     * get Classes List
     * @author GOPI PANGULURI<gopi.panguluri@mindtechlabs.com>
     */
    public function get_classes_list($id='') {
        $this->db->select('*');
        $this->db->from('sections');
        if($id!=''){
            $this->db->where('sec_id',$id);
        }
        $this->db->order_by('cl_name','ASC');
        $this->db->join('classes', 'sections.cl_id = classes.cl_id');
        $res = $this->db->get()->result_array();
        //echo '<pre>'; print_r($res);exit;
        $school_list = array(''=>'Select One');
        foreach($res as $school):
            $school_list[$school['sec_id']] = $school['cl_name'].'-'.$school['sec_name'];
        endforeach;
        //echo '<pre>'; print_r($school_list);exit;
        return $school_list;
    }
    
    /**
     * get_address_list()
     * get Address List
     * @author GOPI PANGULURI<gopi.panguluri@mindtechlabs.com>
     */
    public function get_address_list($id='',$type='') {
        $this->db->select('address.*,countries.name as c_name,states.state_name,cities.city_name');
        $this->db->from('address');
        if($id!=''){
            $this->db->where('user_id',$id);
        }
        if($type!=''){
            $this->db->where('at_id',$type);
        }
        $this->db->order_by('a_name','ASC');
        $this->db->join('countries', 'address.a_country = countries.id');
        $this->db->join('states', 'address.a_state = states.state_id');
        $this->db->join('cities', 'address.a_city = cities.city_id');
        $res = $this->db->get()->result_array();
        //echo '<pre>'; print_r($res);exit;
        $address_list = array(''=>'Select One');
        foreach($res as $address):
            $address_list[$address['a_id']] = $address['a_name'].'-'.$address['a_address_line'].'-'.$address['a_pincode'].'-'.$address['city_name'].'-'.$address['state_name'].'-'.$address['c_name'];
        endforeach;
        //echo '<pre>'; print_r($address_list);exit;
        return $address_list;
    }
    
    /**
     * insert_id_details
     * Insert Id Details
     * @author GOPI PANGULURI<gopi.panguluri@mindtechlabs.com>
     * @param type $data
     */
    public function insert_id_details($table_name, $data) {
        $result = $this->db->insert($table_name, $data);
        return $this->db->insert_id();
    }
	
	/**
     * update_techer_details
     * @param type $data
     * @author GOPI PANGULURI<gopi.panguluri@mindtechlabs.com>
     * @return type
     */
    public function update_techer_details($data) {		
        $this->db->where($data['where']);
        $result = $this->db->update($data['tablename'], $data['data']);		
        return $this->db->insert_id();
    }
    
}

?>