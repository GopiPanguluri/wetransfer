<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <?php $this->load->view('common/common/css') ?>
  <link rel="stylesheet" href="<?php echo config_item('ui_base_path') ?>plugins/bootstrap-select/bootstrap-select.min.css"/>
  <style>
    
  </style>
</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">
  <?php $this->load->view('common/buyer-top_nav') ?>
  <?php $this->load->view('common/buyer-left_nav') ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1><?php if ($mode == 'edit') {
                echo "Edit";
            }  else if($mode == 'details'){
                echo "Details of";
            }else {
                echo "Add";
            } ?> Address
        </h1>
        <ol class="breadcrumb">
            <li><a href="<?php echo site_url('school'); ?>"><i class="fa fa-dashboard"></i> Home </a></li>
            <li><a href="<?php echo site_url('buyer/address'); ?>"><i class="fa fa-map-marker"></i> address </a></li>
            <li class="active"> <?php if ($mode == 'edit') {echo "<i class='fa fa-pencil'></i>&nbsp;&nbsp;Edit";}  else if($mode == 'details'){ echo "<i class='fa fa-eye'></i>&nbsp;&nbsp;Details of"; } else {echo "<i class='fa fa-plus'></i>&nbsp;&nbsp;Add";} ?> address </li>
        </ol>
      </section>

    <!-- Main content -->
    <input type="hidden" id="page" value="nav-address"/>    
    <section class="content">
        <div class="box box-primary">
          <div class="panel-body">
            <?php
                $success_message = $this->session->flashdata('insert_record');
                if ($success_message['status'] == "success") {
                    echo '<p class="alert alert-success sas-succcess-message">' . $success_message['message'] . '</p><div class="clearfix"></div>';
                } else if ($success_message['status'] == "fail") {
                    echo '<p class="alert alert-danger sas-succcess-message">' . $success_message['message'] . '</p><div class="clearfix"></div>';
                }
            ?>
            <div class="error_msg alert alert-danger alert-dismissible"></div>
            <div class="info_msg alert alert-success alert-dismissible"></div>
            <?php
                echo form_open_multipart('buyer/address/create_address', array('id' => 'customer_form', 'class' => 'form-horizontal'));
                if ($mode == 'edit') {
            ?>  
                <div class="form-group">
                    <label class="col-md-2"> Name </label>
                    <div class="col-md-4">
                        <input name="a_name" id="a_name" type="text" class="form-control" value="<?php echo $item_details['a_name']; ?>"/>
                    </div>
                    <label class="col-md-2"> Country </label>
                    <div class="col-md-4">
                        <?php echo form_dropdown('a_country',$country,$item_details['a_country'],' id="a_country" class="form-control"') ?>
                    </div>
                </div>                
                <div class="form-group">
                    <label class="col-md-2"> State </label>
                    <div class="col-md-4">
                        <?php echo form_dropdown('a_state',$states,$item_details['a_state'],' id="a_state" class="form-control"') ?>
                    </div>
                    <label class="col-md-2"> City </label>
                    <div class="col-md-4">
                        <?php echo form_dropdown('a_city',$cities,$item_details['a_city'],' id="a_city" class="form-control"') ?>
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-md-2"> Address type </label>
                    <div class="col-md-4">
                        <?php echo form_dropdown('at_id',$address_types,$item_details['at_id'],' id="at_id" class="form-control"') ?>
                    </div>
                </div>                
                <div class="form-group">
                    <label class="col-md-2"> Zip/Postal code </label>
                    <div class="col-md-4">
                        <input name="a_pincode" id="a_pincode" type="text" class="form-control" value="<?php echo $item_details['a_pincode']; ?>"/>
                    </div>
                    <label class="col-md-2"> Port Of Discharge </label>
                    <div class="col-md-4">
                        <input name="a_port_of_discharge" id="a_port_of_discharge" type="text" class="form-control" value="<?php echo $item_details['a_port_of_discharge']; ?>"/>
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-md-2"> Mobile </label>
                    <div class="col-md-4">
                        <input name="a_mobile" id="a_mobile" type="text" class="form-control" value="<?php echo $item_details['a_mobile']; ?>"/>
                    </div>
                    <label class="col-md-2"> Bussiness Phone </label>
                    <div class="col-md-4">
                        <input name="a_bussiness_ph" id="a_bussiness_ph" type="text" class="form-control" value="<?php echo $item_details['a_bussiness_ph']; ?>"/>
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-md-2"> TIN/CST No. if applicable </label>
                    <div class="col-md-4">
                        <input name="a_trstn_or_cst_no" id="a_trstn_or_cst_no" type="text" class="form-control" value="<?php echo $item_details['a_trstn_or_cst_no']; ?>"/>
                    </div>
                    <label class="col-md-2"> ECC code(Excise No). if applicable </label>
                    <div class="col-md-4">
                        <input name="a_ecc_code" id="a_ecc_code" type="text" class="form-control" value="<?php echo $item_details['a_ecc_code']; ?>"/>
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-md-2"> Receiver Name </label>
                    <div class="col-md-4">
                        <input name="a_receiver_name" id="a_receiver_name" type="text" class="form-control" value="<?php echo $item_details['a_receiver_name']; ?>"/>
                    </div>
                    <label class="col-md-2"> Receiver Mobile </label>
                    <div class="col-md-4">
                        <input name="a_receiver_mobile" id="a_receiver_mobile" type="text" class="form-control" value="<?php echo $item_details['a_receiver_mobile']; ?>"/>
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-md-2"> Receiver id type </label>
                    <div class="col-md-4">
                        <?php echo form_dropdown('a_receiver_id',$id_types,$item_details['a_receiver_id'],' id="a_receiver_id" class="form-control"') ?>
                    </div>
                    <label class="col-md-2"> Receiver id no </label>
                    <div class="col-md-4">
                        <input name="a_id_no" id="a_id_no" type="text" class="form-control" value="<?php echo $item_details['a_id_no']; ?>"/>
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-md-2"> Address Description </label>
                    <div class="col-md-4">
                        <textarea name="a_address_line" id="a_address_line" class="form-control"><?php echo $item_details['a_address_line']; ?></textarea>
                    </div>
                </div>
                
                <div class="col-md-9 col-md-offset-2">
                    <input type="hidden" name="id" id="id" value="<?php echo $item_details['a_id']; ?>" />
                    <button type="submit" name="submit" id="submit" val="update" class="btn btn-success">Update </button>
                    <a href="<?php echo site_url('buyer/address') ?>" class="btn btn-default">Cancel</a>
                </div>
                
            <?php } else if($mode == 'details'){ ?> 
                
                <div class="form-group">
                    <label class="col-md-2"> Name </label>
                    <div class="col-md-4">
                        <?php echo $item_details['a_name']; ?>
                    </div>
                    <label class="col-md-2"> Country </label>
                    <div class="col-md-4">
                        <?php echo $country[$item_details['a_country']]; ?>
                    </div>
                </div>                
                <div class="form-group">
                    <label class="col-md-2"> State </label>
                    <div class="col-md-4">
                        <?php echo $states[$item_details['a_state']]; ?>
                    </div>
                    <label class="col-md-2"> City </label>
                    <div class="col-md-4">
                        <?php echo $cities[$item_details['a_city']]; ?>
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-md-2"> Address type </label>
                    <div class="col-md-4">
                        <?php echo $address_types[$item_details['at_id']]; ?>
                    </div>
                </div>                
                <div class="form-group">
                    <label class="col-md-2"> Zip/Postal code </label>
                    <div class="col-md-4">
                        <?php echo $item_details['a_pincode']; ?>
                    </div>
                    <label class="col-md-2"> Port Of Discharge </label>
                    <div class="col-md-4">
                        <?php echo $item_details['a_port_of_discharge']; ?>
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-md-2"> Mobile </label>
                    <div class="col-md-4">
                        <?php echo $item_details['a_mobile']; ?>
                    </div>
                    <label class="col-md-2"> Bussiness Phone </label>
                    <div class="col-md-4">
                        <?php echo $item_details['a_bussiness_ph']; ?>
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-md-2"> TIN/CST No. if applicable </label>
                    <div class="col-md-4">
                        <?php echo $item_details['a_trstn_or_cst_no']; ?>
                    </div>
                    <label class="col-md-2"> ECC code(Excise No). if applicable </label>
                    <div class="col-md-4">
                        <?php echo $item_details['a_ecc_code']; ?>
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-md-2"> Receiver Name </label>
                    <div class="col-md-4">
                        <?php echo $item_details['a_receiver_name']; ?>
                    </div>
                    <label class="col-md-2"> Receiver Mobile </label>
                    <div class="col-md-4">
                        <?php echo $item_details['a_receiver_mobile']; ?>
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-md-2"> Receiver id type </label>
                    <div class="col-md-4">
                        <?php echo $id_types[$item_details['a_receiver_id']]; ?>
                    </div>
                    <label class="col-md-2"> Receiver id no </label>
                    <div class="col-md-4">
                        <?php echo $item_details['a_id_no']; ?>
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-md-2"> Address Description </label>
                    <div class="col-md-4">
                        <?php echo $item_details['a_address_line']; ?>
                    </div>
                </div>
                <div class="col-md-9">
                    <a href="<?php echo site_url('buyer/address') ?>" class="btn btn-default">Back</a>
                </div>
                
            <?php } else { ?>
            
                <div class="form-group">
                    <label class="col-md-2"> Name </label>
                    <div class="col-md-4">
                        <input name="a_name" id="a_name" type="text" class="form-control" value=""/>
                    </div>
                    <label class="col-md-2"> Country </label>
                    <div class="col-md-4">
                        <?php echo form_dropdown('a_country',$country,'',' id="a_country" class="form-control"') ?>
                    </div>
                </div>                
                <div class="form-group">
                    <label class="col-md-2"> State </label>
                    <div class="col-md-4">
                        <?php echo form_dropdown('a_state',$states,'',' id="a_state" class="form-control"') ?>
                    </div>
                    <label class="col-md-2"> City </label>
                    <div class="col-md-4">
                        <?php echo form_dropdown('a_city',$cities,'',' id="a_city" class="form-control"') ?>
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-md-2"> Address type </label>
                    <div class="col-md-4">
                        <?php echo form_dropdown('at_id',$address_types,'','id="at_id" class="form-control"') ?>
                    </div>
                </div>                
                <div class="form-group">
                    <label class="col-md-2"> Zip/Postal code </label>
                    <div class="col-md-4">
                        <input name="a_pincode" id="a_pincode" type="text" class="form-control" value=""/>
                    </div>
                    <label class="col-md-2"> Port Of Discharge </label>
                    <div class="col-md-4">
                        <input name="a_port_of_discharge" id="a_port_of_discharge" type="text" class="form-control" value=""/>
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-md-2"> Mobile </label>
                    <div class="col-md-4">
                        <input name="a_mobile" id="a_mobile" type="text" class="form-control" value=""/>
                    </div>
                    <label class="col-md-2"> Bussiness Phone </label>
                    <div class="col-md-4">
                        <input name="a_bussiness_ph" id="a_bussiness_ph" type="text" class="form-control" value=""/>
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-md-2"> TIN/CST No. if applicable </label>
                    <div class="col-md-4">
                        <input name="a_trstn_or_cst_no" id="a_trstn_or_cst_no" type="text" class="form-control" value=""/>
                    </div>
                    <label class="col-md-2"> ECC code(Excise No). if applicable </label>
                    <div class="col-md-4">
                        <input name="a_ecc_code" id="a_ecc_code" type="text" class="form-control" value=""/>
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-md-2"> Receiver Name </label>
                    <div class="col-md-4">
                        <input name="a_receiver_name" id="a_receiver_name" type="text" class="form-control" value=""/>
                    </div>
                    <label class="col-md-2"> Receiver Mobile </label>
                    <div class="col-md-4">
                        <input name="a_receiver_mobile" id="a_receiver_mobile" type="text" class="form-control" value=""/>
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-md-2"> Receiver id type </label>
                    <div class="col-md-4">
                        <?php echo form_dropdown('a_receiver_id',$id_types,'',' id="a_receiver_id" class="form-control"') ?>
                    </div>
                    <label class="col-md-2"> Receiver id no </label>
                    <div class="col-md-4">
                        <input name="a_id_no" id="a_id_no" type="text" class="form-control" value=""/>
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-md-2"> Address Description </label>
                    <div class="col-md-4">
                        <textarea name="a_address_line" id="a_address_line" class="form-control"></textarea>
                    </div>
                </div>
                <div class="col-md-9 col-md-offset-2">
                    <button type="submit" name="submit" class="btn btn-success" id="submit" val="insert">Save </button>
                    <a href="<?php echo site_url('buyer/address') ?>" class="btn btn-default">Cancel</a>
                </div>
            <?php } echo form_close(); ?>
            </div>            
        </div>
      </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <!-- Control Sidebar -->
  <?php $this->load->view('common/common/footer'); ?>
  <!-- Add the sidebar's background. This div must be placed
       immediately after the control sidebar -->
  <div class="control-sidebar-bg"></div>
</div>
<!-- ./wrapper -->

<?php $this->load->view('common/common/js') ?>
<script src="<?php echo config_item('ui_base_path') ?>custom/js/jquery.validate.min.js"></script>
<script src="<?php echo config_item('ui_base_path') ?>custom/js/additional-methods.js"></script>
<script src="<?php echo config_item('ui_base_path') ?>plugins/bootstrap-select/bootstrap-select.min.js"></script>
<script type="">
    $(document).ready(function() {
    $("#a_country").change(function(){
        var selectedValue = this.value;
        $.ajax({
        url: BASE_URL + 'buyer/get_states_list',
        method: 'POST',
        dataType: 'json',
        data: {id : selectedValue},
        success: function(data) {
            if(data.status==0){
                var content = '';
                content = '<option value="">Select One</option>';
                $.each(data.states, function(i, post) {
                 content += '<option value="'+post.state_id+'">'  + post.state_name + '</option>';
                });
                $('#a_state').empty();                
                $('#a_state').append(content);
            }else{
                alert('There is a problem with states');
            }
        }
    });
    });
    $("#a_state").change(function(){
        var selectedValue = this.value;
        $.ajax({
        url: BASE_URL + 'buyer/get_cities_list',
        method: 'POST',
        dataType: 'json',
        data: {id : selectedValue},
        success: function(data) {
            if(data.status==0){
                var content = '';
                content = '<option value="">Select One</option>';
                $.each(data.states, function(i, post) {
                 content += '<option value="'+post.city_id+'">'  + post.city_name + '</option>';
                });
                $('#a_city').empty();                
                $('#a_city').append(content);
            }else{
                alert('There is a problem with cities');
            }
        }
    });
    });
    $.validator.setDefaults({
            ignore: []
    });
    $("#customer_form").validate({
    <?php if ($mode == 'create') { ?>
        rules: {
        a_name: {
            required: true,
            letterswithbasicpunc: true,
            minlength:3,
            maxlength:35
        },
        a_address_line: {
            required: true,
            minlength:10
        },
        at_id: {
            required: true
        },
        a_country: {
            required: true
        },
        a_state: {
            required: true
        },
        a_city: {
            required: true
        },
        a_pincode: {
            required: true,
            number: true,
            minlength:6,
            maxlength:6
        },
        a_port_of_discharge: {
            required: true
        },
        a_mobile: {
            required: true,
            number: true,
            minlength:10,
            maxlength:10
        },
        a_bussiness_ph: {
            number: true,
            minlength:10,
            maxlength:10
        },
        a_trstn_or_cst_no: {
            required: true
        },
        a_ecc_code: {
            required: true
        },
        a_receiver_name: {
            letterswithbasicpunc: true,
            required: true
        },
        a_receiver_mobile: {
            required: true,
            number: true,
            minlength:10,
            maxlength:10
        },
        a_receiver_id: {
            required: true
        },
        a_id_no: {
            required: true,
            minlength:10,
            maxlength:16
        }
        },
        
        messages: {				
            //address_email: {					
//                required: "Email should not leave empty.",
//                remote:"email id is already taken please enter anoter"
//                }
        },
    <?php }else{ ?>
        rules: {
        a_name: {
            required: true,
            letterswithbasicpunc: true,
            minlength:3,
            maxlength:35
        },
        a_address_line: {
            required: true,
            minlength:10
        },
        at_id: {
            required: true
        },
        a_country: {
            required: true
        },
        a_state: {
            required: true
        },
        a_city: {
            required: true
        },
        a_pincode: {
            required: true,
            number: true,
            minlength:6,
            maxlength:6
        },
        a_port_of_discharge: {
            required: true
        },
        a_mobile: {
            required: true,
            number: true,
            minlength:10,
            maxlength:10
        },
        a_bussiness_ph: {
            number: true,
            minlength:10,
            maxlength:10
        },
        a_trstn_or_cst_no: {
            required: true
        },
        a_ecc_code: {
            required: true
        },
        a_receiver_name: {
            letterswithbasicpunc: true,
            required: true
        },
        a_receiver_mobile: {
            required: true,
            number: true,
            minlength:10,
            maxlength:10
        },
        a_receiver_id: {
            required: true
        },
        a_id_no: {
            required: true,
            minlength:10,
            maxlength:16
        }
        },
        
        messages: {				
            //address_email: {					
//                required: "Email should not leave empty."
//                }
        },
    <?php } ?>
        submitHandler: function(form,event){
        event.preventDefault();// using this page stop being refreshing
        var formData = new FormData();
        formData.append('a_name', $('#a_name').val());
        formData.append('a_address_line', $('#a_address_line').val());
        formData.append('a_country', $('#a_country').val());
        formData.append('a_state', $('#a_state').val());
        formData.append('a_city', $('#a_city').val());
        formData.append('a_pincode', $('#a_pincode').val());
        formData.append('a_port_of_discharge', $('#a_port_of_discharge').val());
        formData.append('a_mobile', $('#a_mobile').val());
        formData.append('a_bussiness_ph', $('#a_bussiness_ph').val());
        formData.append('a_trstn_or_cst_no', $('#a_trstn_or_cst_no').val());
        formData.append('a_ecc_code', $('#a_ecc_code').val());
        formData.append('a_receiver_name', $('#a_receiver_name').val());
        formData.append('a_receiver_mobile', $('#a_receiver_mobile').val());
        formData.append('a_receiver_id', $('#a_receiver_id').val());
        formData.append('a_id_no', $('#a_id_no').val());
        formData.append('at_id', $('#at_id').val());        
        <?php if($mode=='edit'){ ?>
        formData.append('id', $('#id').val());
        <?php } ?>
        formData.append('submit', $("#submit").attr('val'));
        $.ajax({
            url: form.action,
            type: form.method,
            async: false,
            cache: false,
            contentType: false,
            enctype: 'multipart/form-data',
            processData: false,
            dataType: "json",
            //data: $(form).serialize(),
            data: formData,
            success: function(res) {
                if(res.status=='success'){
                    $('.error_msg').hide();
                    $('.info_msg').show();
                    $('.info_msg').html(res.message);
                    $(location).attr('href', BASE_URL + res.go_to)
                    redirect(res.go_to);
                }else{
                    $('.info_msg').hide();
                    $('.error_msg').show();
                    $('.error_msg').html(res.message);
                }
            }            
        });
    }
    });
    });
    
    
    //Date picker
    //$('#a_country').datepicker({
//      autoclose: true,
//      startDate: new Date()
//    });
    
    //$(function () {
//    //Add text editor
//    $("#a_address_line").wysihtml5();
//    });
    
</script>
</body>
</html>