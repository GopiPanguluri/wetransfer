<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <?php $this->load->view('common/common/css') ?>
  <style>
  .content-wrapper, .right-side, .main-footer{
    margin-left: 0px;
  }
  /*.disabled{
    display: none !important;
  }*/
  </style>
  
  <!-- Include SmartWizard CSS -->
  <link href="<?php echo config_item('ui_base_path') ?>plugins/smartwizard/css/smart_wizard.css" rel="stylesheet" type="text/css"/>
  <!-- Optional SmartWizard theme -->
  <link href="<?php echo config_item('ui_base_path') ?>plugins/smartwizard/css/smart_wizard_theme_arrows.css" rel="stylesheet" type="text/css"/>
</head>
<body class="hold-transition skin-blue sidebar-mini">
    <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header text-center">
      <h1>
        Please fill these fields
        <!--small>advanced tables</small-->
      </h1>
      </ol>
    </section>
    <!-- Main content -->
    <input type="hidden" id="page" value="nav-university"/>    
    <section class="content">
        <div class="box box-primary">
          <div class="panel-body">
            <?php
                $success_message = $this->session->flashdata('insert_record');
                if ($success_message['status'] == "success") {
                    echo '<p class="alert alert-success sas-succcess-message">' . $success_message['message'] . '</p><div class="clearfix"></div>';
                } else if ($success_message['status'] == "fail") {
                    echo '<p class="alert alert-danger sas-succcess-message">' . $success_message['message'] . '</p><div class="clearfix"></div>';
                }
            ?>
            <div class="error_msg alert alert-danger alert-dismissible"></div>
            <div class="info_msg alert alert-success alert-dismissible"></div>      
            <?php
                echo form_open_multipart('seller/save_profile_data', array('id' => 'customer_form', 'class' => 'form-horizontal'));
            ?>    
            <div id="smartwizard">
                <ul>
                <li><a href="#step-1">Step 1<br /><small>Profile Information</small></a></li>
                <li><a href="#step-2">Step 2<br /><small>Company details</small></a></li>
                <!--li><a href="#step-3">Step 3<br /><small>This is step description</small></a></li>
                <li><a href="#step-4">Step 4<br /><small>This is step description</small></a></li-->
                </ul>
                <div>
                    <div id="step-1" class="">
                        <h2>Profile Details</h2>
                        <div class="form-group">
                            <label class="col-md-2"> Image </label>
                            <div class="col-md-4">
                                <input name="image" id="image" type="file" class="form-control" value=""/>
                            </div>
                            <label class="col-md-2"> Category </label>
                            <div class="col-md-4">
                                <?php echo form_dropdown('c_id',$category,'','id="c_id" class="form-control"'); ?>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-md-2"> Address </label>
                            <div class="col-md-4">
                                <textarea name="address" id="address" class="form-control"></textarea>
                            </div>
                            <label class="col-md-2"> Gender </label>
                            <div class="col-md-4">
                                <label>
                                  <input type="radio" id="gender" name="gender" class="minimal" value="0"/>
                                  Male &nbsp;&nbsp;&nbsp;&nbsp;
                                </label>
                                <label>
                                  <input type="radio" id="gender" name="gender" class="minimal" value="1"/>
                                  Female
                                </label>
                            </div>
                        </div>
                    </div>
                    <div id="step-2" class="">
                        <h2>Company Details</h2>
                        <div class="form-group">
                            <label class="col-md-2"> Company Name </label>
                            <div class="col-md-4">
                                <input name="com_name" id="com_name" type="text" class="form-control" value=""/>
                            </div>
                            <label class="col-md-2"> Contact name </label>
                            <div class="col-md-4">
                                <input name="com_contact_name" id="com_contact_name" type="text" class="form-control" value=""/>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-md-2"> Company number </label>
                            <div class="col-md-4">
                                <input name="com_contact_number" id="com_contact_number" type="number" class="form-control" value=""/>
                            </div>
                            <label class="col-md-2"> Company email </label>
                            <div class="col-md-4">
                                <input name="com_contact_email" id="com_contact_email" type="email" class="form-control" value=""/>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-md-2"> Company Address </label>
                            <div class="col-md-4">
                                <textarea name="com_address" id="com_address" class="form-control"></textarea>
                            </div>
                            <label class="col-md-2"> Company Type </label>
                            <div class="col-md-4">
                                <?php echo form_dropdown('ct_id',$com_types,'','class="form-control" id="ct_id"'); ?>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-md-2"> Company Exporter No </label>
                            <div class="col-md-4">
                                <input name="cd_exporter_no" id="cd_exporter_no" type="number" class="form-control" value=""/>
                            </div>
                            <label class="col-md-2"> Company Registration No </label>
                            <div class="col-md-4">
                                <input name="cd_reg_no" id="cd_reg_no" type="number" class="form-control" value=""/>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-md-2"> Incorporation Date </label>
                            <div class="col-md-4">
                                <div class="input-group date">
                                    <div class="input-group-addon">
                                        <i class="fa fa-calendar"></i>
                                    </div>
                                    <input name="cd_incorp_date" type="text" class="form-control pull-right" class="form-control" id="cd_incorp_date"/>
                                </div>
                            </div>
                            <label class="col-md-2"> Time Zone </label>
                            <div class="col-md-4">
                                <?php echo form_dropdown('tz_id',$tz_list,'','id="tz_id" class="form-control"'); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php echo form_close(); ?>
            </div>            
        </div>
        <?php $this->load->view('common/common/footer'); ?>
      </section>
    <!-- /.content -->
    </div>
  <!-- Control Sidebar -->
  
  <!-- Add the sidebar's background. This div must be placed
       immediately after the control sidebar -->
  <div class="control-sidebar-bg"></div>
<!-- ./wrapper -->

<?php $this->load->view('common/common/js'); ?>
<script src="<?php echo config_item('ui_base_path') ?>custom/js/jquery.validate.min.js"></script>
<script type="text/javascript" src="<?php echo config_item('ui_base_path') ?>plugins/smartwizard/js/validator.min.js"></script>
<script type="text/javascript" src="<?php echo config_item('ui_base_path') ?>plugins/smartwizard/js/jquery.smartWizard.js"></script>
<script type="text/javascript">
        $(document).ready(function(){
        
        //Date picker
        $('#cd_incorp_date').datepicker({
          autoclose: true
        });
    
        //iCheck for checkbox and radio inputs
        $('input[type="checkbox"].minimal, input[type="radio"].minimal').iCheck({
          checkboxClass: 'icheckbox_minimal-blue',
          radioClass: 'iradio_minimal-blue'
        });
            //form validation        
    var $validator = $("#customer_form").validate({
        rules: {
                //name: {
//                    required: true
//                },
                //contact_number: {
//                    required: true,
//                    number: true,
//                    minlength:'10'
//                },
                c_id: {
                    required: true
                },
                image: {
                    required: true,
                },
                address: {
                    required: true,
                },
                gender: {
                    required: true,
                },
                com_name: {
                    required: true,
                },
                com_contact_name: {
                    required: true,
                },
                com_contact_number: {
                    required: true,
                    number:true
                },
                com_contact_email: {
                    required: true,
                    email:true
                },
                com_address: {
                    required: true
                },
                ct_id: {
                    required: true
                },
                cd_exporter_no: {
                    required: true
                },
                cd_reg_no: {
                    required: true
                },
                cd_incorp_date: {
                    required: true
                },
                tz_id: {
                    required: true
                }
            },
            submitHandler: function(form){
            event.preventDefault();// using this page stop being refreshing
            var formData = new FormData();
            if($('#image')[0].files[0]!==''){
                formData.append('image', $('#image')[0].files[0]);
            }
            formData.append('c_id', $('#c_id').val());
            formData.append('address', $('#address').val());
            formData.append('com_name', $('#com_name').val());
            formData.append('com_contact_name', $('#com_contact_name').val());
            formData.append('com_contact_number', $('#com_contact_number').val());
            formData.append('com_contact_email', $("#com_contact_email").val());
            formData.append('com_address', $("#com_address").val());
            formData.append('ct_id', $("#ct_id").val());
            formData.append('cd_exporter_no', $("#cd_exporter_no").val());
            formData.append('cd_reg_no', $("#cd_reg_no").val());
            formData.append('cd_incorp_date', $("#cd_incorp_date").val());
            formData.append('tz_id', $("#tz_id").val());
            formData.append('gender', $('input[name="gender"]:checked').val());
            //alert($('input[name="gender"]:checked').val());
            $.ajax({
                url: form.action,
                type: form.method,
                async: false,
                cache: false,
                contentType: false,
                enctype: 'multipart/form-data',
                processData: false,
                dataType: "json",
                data: formData,
                success: function(res) {
                    if(res.status==0){
                        $('.error_msg').hide();
                        $('.info_msg').show();
                        $('.info_msg').html(res.message);
                        $(location).attr('href', BASE_URL + res.go_to)
                        redirect(res.go_to);
                    }else{
                        $('.error_msg').show();
                        $('.error_msg').html(res.message);
                    }
                }            
            });
        } 
        });
            // Step show event 
            $("#smartwizard").on("showStep", function(e, anchorObject, stepNumber, stepDirection, stepPosition) {
               //alert("You are on step "+stepNumber+" now");
               if(stepPosition === 'first'){
                   $("#prev-btn").addClass('disabled');
                   $("#prev-btn").addClass('disabled');
                   $("#finish").addClass('disabled');
                   //$("#finish").removeAttr('type', 'submit');
                   $("#finish").removeClass('submit_details');
                   $("#finish").css('display', 'none');
               }else if(stepPosition === 'final'){
                   $("#next-btn").addClass('disabled');
                   $("#finish").addClass('submit_details');
                   $("#finish").removeClass('disabled');
                   $("#finish").attr('type', 'submit');
                   $("#finish").css('display', 'block');
               }else{
                   $("#prev-btn").removeClass('disabled');
                   $("#next-btn").removeClass('disabled');
                   $("#finish").addClass('disabled');
                   $("#finish").removeAttr('type', 'submit');
                   $("#finish").removeClass('submit_details');
                   $("#finish").css('display', 'none');
               }
            });
            
            // Toolbar extra buttons
            var btnFinish = $('<button></button>').text('Save')
                                             .addClass('btn btn-info disabled')
                                             .attr('id', 'finish')
                                             .attr('type', 'button');
                                             
            var btnCancel = $('<button></button>').text('Cancel')
                                             .addClass('btn btn-danger')
                                             .on('click', function(){ $('#smartwizard').smartWizard("reset"); });
                                             
            var btnSkip = $('<button></button>').text('Skip')
                                             .addClass('btn btn-default')
                                             .on('click', function(){ var url = 'seller/dashboard'; window.location.href = BASE_URL + url; });                         
            
            
            // Smart Wizard
            $('#smartwizard').smartWizard({ 
                    selected: 0, 
                    theme: 'arrows',
                    transitionEffect:'fade',
                    showStepURLhash: true,
                    toolbarSettings: {toolbarPosition: 'down',
                                      toolbarExtraButtons: [btnSkip, btnFinish, btnCancel]
                                    }
            });
            
            $("#smartwizard").on("leaveStep", function(e, anchorObject, stepNumber, stepDirection) {
                var elmForm = $("#form-step-" + stepNumber);
                // stepDirection === 'forward' :- this condition allows to do the form validation 
                // only on forward navigation, that makes easy navigation on backwards still do the validation when going next
                if(stepDirection === 'forward' && elmForm){
                    var $valid = $("#customer_form").valid();
                    if(!$valid) {
                        $validator.focusInvalid();
                        return false;
                    }
                }
                return true;
            });
                                         
            
            // External Button Events
            $("#reset-btn").on("click", function() {
                // Reset wizard
                $('#smartwizard').smartWizard("reset");
                return true;
            });
            
            $("#prev-btn").on("click", function() {
                // Navigate previous
                $('#smartwizard').smartWizard("prev");
                return true;
            });
            
            $("#next-btn").on("click", function() {
                // Navigate next
                $('#smartwizard').smartWizard("next");
                return true;
            });
            
            //$("#theme_selector").on("change", function() {
//                // Change theme
//                $('#smartwizard').smartWizard("theme", $(this).val());
//                return true;
//            });
            
            // Set selected theme on page refresh
            //$("#theme_selector").change();
            $('#smartwizard').smartWizard("reset");
        });   
</script>
</body>
</html>