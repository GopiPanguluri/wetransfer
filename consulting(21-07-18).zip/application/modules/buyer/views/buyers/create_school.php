<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <?php $this->load->view('admin/common/css') ?>
</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">
  <?php $this->load->view('admin/common/top_nav') ?>
  <?php $this->load->view('admin/common/left_nav') ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1><?php if ($mode == 'edit') {
                echo "Edit";
            }  else if($mode == 'details'){
                echo "Details of";
            }else {
                echo "Add";
            } ?> School
        </h1>
        <ol class="breadcrumb">
            <li><a href="<?php echo site_url('admin'); ?>"><i class="fa fa-dashboard"></i> Home </a></li>
            <li><a href="<?php echo site_url('admin/schools'); ?>"><i class="fa fa-university"></i> Schools </a></li>
            <li class="active"> <?php if ($mode == 'edit') {echo "<i class='fa fa-pencil'></i>&nbsp;&nbsp;Edit";}  else if($mode == 'details'){ echo "<i class='fa fa-eye'></i>&nbsp;&nbsp;Details of"; } else {echo "<i class='fa fa-plus'></i>&nbsp;&nbsp;Add";} ?> School </li>
        </ol>
      </section>

    <!-- Main content -->
    <input type="hidden" id="page" value="nav-university"/>    
    <section class="content">
        <div class="box box-primary">
          <div class="panel-body">
            <?php
                $success_message = $this->session->flashdata('insert_record');
                if ($success_message['status'] == "success") {
                    echo '<p class="alert alert-success sas-succcess-message">' . $success_message['message'] . '</p><div class="clearfix"></div>';
                } else if ($success_message['status'] == "fail") {
                    echo '<p class="alert alert-danger sas-succcess-message">' . $success_message['message'] . '</p><div class="clearfix"></div>';
                }
            ?>
            <?php
                echo form_open_multipart('admin/schools/create_school', array('id' => 'customer_form', 'class' => 'form-horizontal'));
                if ($mode == 'edit') {
            ?>  
                <div class="form-group">
                    <label class="col-md-2"> Schools name </label>
                    <div class="col-md-4">
                        <input name="name" id="name" type="text" class="form-control" value="<?php echo $item_details['name']; ?>"/>
                    </div>
                    <label class="col-md-2"> Schools Type </label>
                    <div class="col-md-4">
                        <?php echo form_dropdown('sc_type',$sc_types,$item_details['sc_type'],'class="form-control" id="sc_type"'); ?>
                    </div>                    
                </div>
                <div class="form-group">
                    <label class="col-md-2"> Image </label>
                    <div class="col-md-4">
                        <input name="image" id="image" type="file" class="form-control" value=""/>
                    </div>
                    <label class="col-md-2"> Contact Type </label>
                    <div class="col-md-4">
                        <?php echo form_dropdown('con_type',$con_types,$item_details['con_type'],'class="form-control" id="sc_type"'); ?>
                    </div>
                </div>
                <div class="form-group">
                    
                    <label class="col-md-2"> Contact name </label>
                    <div class="col-md-4">
                        <input name="sc_contact_name" id="sc_contact_name" type="text" class="form-control" value="<?php echo $item_details['sc_contact_name']; ?>"/>
                    </div>
                    <label class="col-md-2"> Contact number </label>
                    <div class="col-md-4">
                        <input name="sc_contact_number" id="sc_contact_number" type="number" class="form-control" value="<?php echo $item_details['sc_contact_number']; ?>"/>
                    </div>
                    
                </div>
                <div class="form-group">
                    <label class="col-md-2"> Contact email </label>
                    <div class="col-md-4">
                        <input name="sc_contact_email" id="sc_contact_email" type="email" class="form-control" value="<?php echo $item_details['sc_contact_email']; ?>"/>
                    </div>
                    <label class="col-md-2"> Schools email </label>
                    <div class="col-md-4">
                        <input name="sc_email" id="sc_email" type="email" class="form-control" value="<?php echo $item_details['sc_email']; ?>"/>
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-md-2"> Schools number </label>
                    <div class="col-md-4">
                        <input name="sc_number" id="sc_number" type="number" class="form-control" value="<?php echo $item_details['sc_number']; ?>"/>
                    </div>
                    <label class="col-md-2"> Schools address </label>
                    <div class="col-md-4">
                        <textarea name="sc_address" id="sc_address" class="form-control"><?php echo $item_details['sc_address']; ?></textarea>
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-md-2"> Country </label>
                    <div class="col-md-4">
                        <?php echo form_dropdown('country_id',$countries,$item_details['country_id'],'class="form-control" id="country_id"'); ?>
                    </div>
                    <label class="col-md-2"> State </label>
                    <div class="col-md-4">
                        <?php echo form_dropdown('state_id',$states,$item_details['state_id'],'class="form-control" id="state_id"'); ?>
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-md-2"> City </label>
                    <div class="col-md-4">
                        <?php echo form_dropdown('city_id',$cities,$item_details['city_id'],'class="form-control" id="city_id"'); ?>
                    </div>
                    <label class="col-md-2"> Password </label>
                    <div class="col-md-4">
                        <input name="password" id="password" type="text" class="form-control" value=""/>
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-md-2"> Confirm Password </label>
                    <div class="col-md-4">
                        <input name="con_password" id="con_password" type="text" class="form-control" value=""/>
                    </div>
                    <label class="col-md-2"> Image </label>
                    <div class="col-md-4">
                        <img src="<?php echo config_item('root_dir')."assets/images/users/".$item_details['image']; ?>" alt="" height="200" width="200"/>
                    </div>
                </div>
                
                
                <div class="col-md-9 col-md-offset-2">
                    <input type="hidden" name="old_image" id="old_image" value="<?php echo $item_details['image']; ?>" />
                    <input type="hidden" name="id" id="id" value="<?php echo $item_details['sc_id']; ?>" />
                    <button type="submit" name="update" class="btn btn-success">Update </button>
                    <a href="<?php echo site_url('admin/schools') ?>" class="btn btn-default">Cancel</a>
                </div>
                
            <?php } else if($mode == 'details'){ ?> 
                <div class="form-group">
                    <label class="col-md-2"> Schools name </label>
                    <div class="col-md-4">
                        <?php echo $item_details['name']; ?>
                    </div>
                    <label class="col-md-2"> Schools Type </label>
                    <div class="col-md-4">
                        <?php echo $sc_types[$item_details['sc_type']]; ?>
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-md-2"> Image </label>
                    <div class="col-md-4">
                        <img src="<?php echo config_item('root_dir')."assets/images/users/".$item_details['image']; ?>" alt="" height="200" width="200"/>
                    </div>
                    <label class="col-md-2"> Contact Type </label>
                    <div class="col-md-4">
                        <?php echo $con_types[$item_details['con_type']]; ?>
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-md-2"> Contact name </label>
                    <div class="col-md-4">
                        <?php echo $item_details['sc_contact_name']; ?>
                    </div>
                    <label class="col-md-2"> Contact number </label>
                    <div class="col-md-4">
                        <?php echo $item_details['sc_contact_number']; ?>
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-md-2"> Contact email </label>
                    <div class="col-md-4">
                        <?php echo $item_details['sc_contact_email']; ?>
                    </div>
                    <label class="col-md-2"> Schools email </label>
                    <div class="col-md-4">
                        <?php echo $item_details['sc_email']; ?>
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-md-2"> Schools number </label>
                    <div class="col-md-4">
                        <?php echo $item_details['sc_number']; ?>
                    </div>
                    <label class="col-md-2"> Schools address </label>
                    <div class="col-md-4">
                        <?php echo $item_details['sc_address']; ?>
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-md-2"> Country </label>
                    <div class="col-md-4">
                        <?php echo $countries[$item_details['country_id']]; ?>
                    </div>
                    <label class="col-md-2"> State </label>
                    <div class="col-md-4">
                        <?php echo $states[$item_details['state_id']]; ?>
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-md-2"> City </label>
                    <div class="col-md-4">
                        <?php echo $cities[$item_details['city_id']]; ?>
                    </div>
                </div>
                
                <div class="col-md-9">
                    <a href="<?php echo site_url('admin/schools') ?>" class="btn btn-default">Back</a>
                </div>
                
            <?php } else { ?>
            
                <div class="form-group">
                    <label class="col-md-2"> Schools name </label>
                    <div class="col-md-4">
                        <input name="name" id="name" type="text" class="form-control" value=""/>
                    </div>
                    <label class="col-md-2"> Schools Type </label>
                    <div class="col-md-4">
                        <?php echo form_dropdown('sc_type',$sc_types,'','class="form-control" id="sc_type"'); ?>
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-md-2"> Image </label>
                    <div class="col-md-4">
                        <input name="image" id="image" type="file" class="form-control" value=""/>
                    </div>
                    <label class="col-md-2"> Contact Type </label>
                    <div class="col-md-4">
                        <?php echo form_dropdown('con_type',$con_types,'','class="form-control" id="sc_type"'); ?>
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-md-2"> Contact name </label>
                    <div class="col-md-4">
                        <input name="sc_contact_name" id="sc_contact_name" type="text" class="form-control" value=""/>
                    </div>
                    <label class="col-md-2"> Contact number </label>
                    <div class="col-md-4">
                        <input name="sc_contact_number" id="sc_contact_number" type="number" class="form-control" value=""/>
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-md-2"> Contact email </label>
                    <div class="col-md-4">
                        <input name="sc_contact_email" id="sc_contact_email" type="email" class="form-control" value=""/>
                    </div>
                    <label class="col-md-2"> Schools email </label>
                    <div class="col-md-4">
                        <input name="sc_email" id="sc_email" type="email" class="form-control" value=""/>
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-md-2"> Schools number </label>
                    <div class="col-md-4">
                        <input name="sc_number" id="sc_number" type="number" class="form-control" value=""/>
                    </div>
                    <label class="col-md-2"> School address </label>
                    <div class="col-md-4">
                        <textarea name="sc_address" id="sc_address" class="form-control"></textarea>
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-md-2"> Country </label>
                    <div class="col-md-4">
                        <?php echo form_dropdown('country_id',$countries,'','class="form-control" id="country_id" onch'); ?>
                    </div>
                    <label class="col-md-2"> State </label>
                    <div class="col-md-4">
                        <?php $states = array(); echo form_dropdown('state_id',$states,'','class="form-control" id="state_id"'); ?>
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-md-2"> City </label>
                    <div class="col-md-4">
                        <?php $cities = array(); echo form_dropdown('city_id',$cities,'','class="form-control" id="city_id"'); ?>
                    </div>
                    <label class="col-md-2"> Password </label>
                    <div class="col-md-4">
                        <input name="password" id="password" type="password" class="form-control" value=""/>
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-md-2"> Confirm Password </label>
                    <div class="col-md-4">
                        <input name="con_password" id="con_password" type="password" class="form-control" value=""/>
                    </div>
                </div>
                
                <div class="col-md-9 col-md-offset-2">
                    <button type="submit" name="insert" class="btn btn-success">Save </button>
                    <a href="<?php echo site_url('admin/schools') ?>" class="btn btn-default">Cancel</a>
                </div>
                
            <?php } echo form_close(); ?>
            </div>            
        </div>
      </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <!-- Control Sidebar -->
  <?php $this->load->view('admin/common/footer'); ?>
  <!-- Add the sidebar's background. This div must be placed
       immediately after the control sidebar -->
  <div class="control-sidebar-bg"></div>
</div>
<!-- ./wrapper -->

<?php $this->load->view('admin/common/js') ?>
<script src="<?php echo config_item('ui_base_path') ?>custom/js/jquery.validate.min.js"></script>
<script type="">
    $(document).ready(function() {
    $("#country_id").change(function(){
        var selectedValue = this.value;
        $.ajax({
        url: BASE_URL + 'admin/schools/get_states_list',
        method: 'POST',
        dataType: 'json',
        data: {id : selectedValue},
        success: function(data) {
            if(data.status==0){
                var content = '';
                content = '<option value="">Select One</option>';
                $.each(data.states, function(i, post) {
                 content += '<option value="'+post.state_id+'">'  + post.state_name + '</option>';
                });
                $('#state_id').empty();                
                $('#state_id').append(content);
            }else{
                alert('There is a problem with states');
            }
        }
    });
    });
    $("#state_id").change(function(){
        var selectedValue = this.value;
        $.ajax({
        url: BASE_URL + 'admin/schools/get_cities_list',
        method: 'POST',
        dataType: 'json',
        data: {id : selectedValue},
        success: function(data) {
            if(data.status==0){
                var content = '';
                content = '<option value="">Select One</option>';
                $.each(data.states, function(i, post) {
                 content += '<option value="'+post.city_id+'">'  + post.city_name + '</option>';
                });
                $('#city_id').empty();                
                $('#city_id').append(content);
            }else{
                alert('There is a problem with cities');
            }
        }
    });
    });
    <?php if ($mode == 'create') { ?>
    $.validator.setDefaults({
            ignore: []
    });
    $("#customer_form").validate({
        rules: {
        sc_name: {
            required: true,
            minlength:3,
            maxlength:35
        },
        sc_contact_name: {
            required: true,
            minlength:3,
            maxlength:35
        },
        sc_type: {
            required: true
        },
        sc_contact_email: {
            required: true,
            email: true
        },
        sc_contact_number: {
            required: true,
            minlength:10,
            maxlength:12
        },
        sc_email: {
            required: true,
            email: true,
            remote:BASE_URL+"admin/schools/check_email_id"
        },
        sc_number: {
            required: true,
            minlength:10,
            maxlength:12
        },
        con_type: {
            required: true
        }
        ,
        image: {
            required: true
        },
        sc_address: {
            required: true
        },
        city_id: {
            required: true
        },
        state_id: {
            required: true
        },
        country_id: {
            required: true
        },
        password: {
            required: true,
            minlength:5
        },
        con_password: {
            required: true,
            minlength:5,
            equalTo:"#password"
        }
        },
        
        messages: {				
            sc_email: {					
                required: "Email should not leave empty.",
                remote:"email id is already taken please enter anoter"
                }
        }
    });
    <?php }else{ ?>
    $.validator.setDefaults({
            ignore: []
    });
    $("#customer_form").validate({
        rules: {
        sc_name: {
            required: true,
            minlength:3,
            maxlength:35
        },
        sc_contact_name: {
            required: true,
            minlength:3,
            maxlength:35
        },
        sc_type: {
            required: true
        },
        sc_contact_email: {
            required: true,
            email: true
        },
        sc_contact_number: {
            required: true,
            minlength:10,
            maxlength:12
        },
        sc_email: {
            required: true,
            email: true
        },
        sc_number: {
            required: true,
            minlength:10,
            maxlength:12
        },
        sc_address: {
            required: true
        },
        city_id: {
            required: true
        },
        state_id: {
            required: true
        },
        country_id: {
            required: true
        },
        password: {
            minlength:5
        },
        con_password: {
            minlength:5,
            equalTo:"#password"
        }
        },
        
        messages: {				
            sc_email: {					
                required: "Email should not leave empty.",
                remote:"email id is already taken please enter anoter"
                }
        }
    });
    <?php } ?>
    });
    
</script>
</body>
</html>