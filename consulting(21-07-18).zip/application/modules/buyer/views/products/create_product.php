<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <?php $this->load->view('common/common/css'); ?>
  <link rel="stylesheet" href="<?php echo config_item('ui_base_path') ?>plugins/bootstrap-select/bootstrap-select.min.css"/>
  <style>
    .no_display_col{
        display: none;
    }
  </style>
</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">
  <?php $this->load->view('common/buyer-top_nav') ?>
  <?php $this->load->view('common/buyer-left_nav') ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1><?php if ($mode == 'edit') {
                echo "Edit";
            }  else if($mode == 'details'){
                echo "Details of";
            }else {
                echo "Add";
            } ?> product
        </h1>
        <ol class="breadcrumb">
            <li><a href="<?php echo site_url('admin'); ?>"><i class="fa fa-dashboard"></i> Home </a></li>
            <li><a href="<?php echo site_url('admin/products'); ?>"><i class="fa fa-university"></i> Products </a></li>
            <li class="active"> <?php if ($mode == 'edit') {echo "<i class='fa fa-pencil'></i>&nbsp;&nbsp;Edit";}  else if($mode == 'details'){ echo "<i class='fa fa-eye'></i>&nbsp;&nbsp;Details of"; } else {echo "<i class='fa fa-plus'></i>&nbsp;&nbsp;Add";} ?> product </li>
        </ol>
      </section>

    <!-- Main content -->
    <input type="hidden" id="page" value="nav-search"/>    
    <section class="content">
        <div class="box box-primary">
          <div class="panel-body">
            <?php
                $success_message = $this->session->flashdata('insert_record');
                if ($success_message['status'] == "success") {
                    echo '<p class="alert alert-success sas-succcess-message">' . $success_message['message'] . '</p><div class="clearfix"></div>';
                } else if ($success_message['status'] == "fail") {
                    echo '<p class="alert alert-danger sas-succcess-message">' . $success_message['message'] . '</p><div class="clearfix"></div>';
                }
            ?>
            <div class="error_msg alert alert-danger alert-dismissible"></div>
            <div class="info_msg alert alert-success alert-dismissible"></div>
            <?php
                echo form_open_multipart('seller/products/create_product', array('id' => 'customer_form', 'class' => 'form-horizontal'));
                if ($mode == 'edit') {
            ?>  
                
                <div class="form-group">
                    <label class="col-md-2"> Name </label>
                    <div class="col-md-4">
                        <input name="product_name" id="product_name" type="text" class="form-control" value="<?php echo $item_details['product_name']; ?>"/>
                    </div>
                    <label class="col-md-2"> Price </label>
                    <div class="col-md-4">
                        <input name="product_price" id="product_price" type="number" class="form-control" value="<?php echo $item_details['product_price']; ?>"/>
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-md-2"> Type </label>
                    <div class="col-md-4">
                        <div class="form-group">
                        <label>
                            <input type="radio" id="type" name="type" value="1" <?php if($item_details['type']==1){ echo 'checked'; } ?> onclick="open_box_display(0)"/>
                            Product
                        </label>
                        <label>
                            <input type="radio" id="type" name="type" value="2" <?php if($item_details['type']==2){ echo 'checked'; } ?> onclick="open_box_display(1)"/>
                            Service
                        </label>
                        <label id="type-error" class="error" for="type"></label>
                        </div>
                    </div>
                    <label class="col-md-2"> Image </label>
                    <div class="col-md-4">
                           <input name="product_image" id="product_image" type="file" class="form-control"/>
                           <img src="<?php echo config_item('root_dir').'assets/images/catelogues/'.$item_details['product_image']; ?>" height="200" width="200" alt="Image"/>
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-md-2"> Catelogue </label>
                    <div class="col-md-10">
                           <input name="catelogue[]" id="catelogue" type="file" class="form-control" multiple=""/>
                           <?php if(count($catelogues)!=0){ $sno=1; foreach($catelogues as $row):?>
                                <div class="border_files col-md-4 text-center" style="margin: 10px;"> 
                                  <span class=""> <a target="_blank" href="<?php echo config_item('root_dir').'assets/images/catelogues/'.$row['catlogues_name']; ?>"> <i>Click here to see</i> Catelogue - <?php echo $sno; ?> </a> <a href="javascript:void(0)" data-toggle="tooltip" id="<?php echo $row['catlogues_id']; ?>" class="deleteme show-tooltip deleteitem_<?php echo $row['catlogues_id']; ?>" title="Delete Record" data-tablename="catelogues" data-fieldname="catlogues_id" url="<?php echo base_url('seller/delete_all_record'); ?>"><i class="fa_size fa fa-trash-o "></i></a> </span> 
                                </div>
                            <?php $sno++; endforeach; }else{ ?>
                                <a class="" href="javascript:void(0)"> No Certificates </a>
                            <?php } ?>
                    </div>
                </div>
                <div class="product_col <?php if($item_details['type']!=1){ echo 'no_display_col'; } ?>">
                    <div class="form-group">
                        <label class="col-md-2"> Category </label>
                        <div class="col-md-4">
                            <?php echo form_dropdown('c_id',$product_cat,$item_details['c_id'],'id="c_id" class="form-control"'); ?>
                        </div>
                        
                    </div>
                </div>
                <div class="service_col <?php if($item_details['type']!=2){ echo 'no_display_col'; } ?>">
                    <div class="form-group">
                        <label class="col-md-2"> Service type </label>
                        <div class="col-md-4">
                            <?php echo form_dropdown('service_type',$service_cat,$item_details['service_type'],'id="service_type" class="form-control"'); ?>
                        </div>
                        <label class="col-md-2"> Man power </label>
                        <div class="col-md-4">
                            <input name="man_power" id="man_power" type="number" class="form-control" value="<?php echo $item_details['man_power']; ?>"/>
                        </div>
                    </div>
                </div>
                <!--div>
                    <label class="col-md-2"> Image </label>
                    <div class="col-md-4">
                        <img src="<?php //echo config_item('root_dir').'assets/images/users/'.$item_details['image']; ?>" alt="image" height="200" width="200"/>
                    </div>
                </div-->
                
                <div class="col-md-9 col-md-offset-2">
                    <input type="hidden" name="product_old_image" id="product_old_image" value="<?php echo $item_details['product_image']; ?>" />
                    <input type="hidden" name="id" id="id" value="<?php echo $item_details['product_id']; ?>" />
                    <button type="submit" name="submit" id="submit" val="update" class="btn btn-success">Update </button>
                    <a href="<?php echo site_url('seller/products') ?>" class="btn btn-default">Cancel</a>
                </div>
                
            <?php } else if($mode == 'details'){ ?> 
                
                <div class="form-group">
                    <label class="col-md-2"> Name </label>
                    <div class="col-md-4">
                        <?php echo $item_details['product_name']; ?>
                    </div>
                    <label class="col-md-2"> Price </label>
                    <div class="col-md-4">
                        <?php echo $item_details['product_price'].'/-'; ?>
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-md-2"> Type </label>
                    <div class="col-md-4">
                        <?php if($item_details['type']==1){ echo 'Product';}else{ echo 'Service';} ?>
                    </div>
                    <label class="col-md-2"> Image </label>
                    <div class="col-md-4">
                           <img src="<?php echo config_item('root_dir').'assets/images/catelogues/'.$item_details['product_image']; ?>" height="200" width="200" alt="Image"/>
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-md-2"> Catelogue </label>
                    <div class="col-md-10">
                           <?php if(count($catelogues)!=0){ $sno=1; foreach($catelogues as $row):?>
                                <div class="border_files col-md-4 text-center" style="margin: 10px;"> 
                                  <span class=""> <a target="_blank" href="<?php echo config_item('root_dir').'assets/images/catelogues/'.$row['catlogues_name']; ?>"> <i>Click here to see</i> Catelogue - <?php echo $sno; ?> </a> <a href="javascript:void(0)" data-toggle="tooltip" id="<?php echo $row['catlogues_id']; ?>" class="deleteme show-tooltip deleteitem_<?php echo $row['catlogues_id']; ?>" title="Delete Record" data-tablename="catelogues" data-fieldname="catlogues_id" url="<?php echo base_url('seller/delete_all_record'); ?>"><i class="fa_size fa fa-trash-o "></i></a> </span> 
                                </div>
                            <?php $sno++; endforeach; }else{ ?>
                                <a class="" href="javascript:void(0)"> No Certificates </a>
                            <?php } ?>
                    </div>
                </div>
                <div class="product_col <?php if($item_details['type']!=1){ echo 'no_display_col'; } ?>">
                    <div class="form-group">
                        <label class="col-md-2"> Category </label>
                        <div class="col-md-4">
                            <?php echo $product_cat[$item_details['c_id']]; ?>
                        </div>
                        
                    </div>
                </div>
                <div class="service_col <?php if($item_details['type']!=2){ echo 'no_display_col'; } ?>">
                    <div class="form-group">
                        <label class="col-md-2"> Service type </label>
                        <div class="col-md-4">
                            <?php echo $service_cat[$item_details['type']]; ?>
                        </div>
                        <label class="col-md-2"> Man power </label>
                        <div class="col-md-4">
                            <?php echo $item_details['man_power'].' members'; ?>
                        </div>
                    </div>
                </div>
                <div class="col-md-9">
                    <a href="<?php echo site_url('buyer/products') ?>" class="btn btn-default">Back</a>
                </div>
                
            <?php } else { ?>
            
                <div class="form-group">
                    <label class="col-md-2"> Name </label>
                    <div class="col-md-4">
                        <input name="product_name" id="product_name" type="text" class="form-control" value=""/>
                    </div>
                    <label class="col-md-2"> Price </label>
                    <div class="col-md-4">
                        <input name="product_price" id="product_price" type="number" class="form-control" value=""/>
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-md-2"> Type </label>
                    <div class="col-md-4">
                        <div class="form-group">
                        <label>
                            <input type="radio" id="type" name="type" value="1" onclick="open_box_display(0)"/>
                            Product
                        </label>
                        <label>
                            <input type="radio" id="type" name="type" value="2" onclick="open_box_display(1)"/>
                            Service
                        </label>
                        <label id="type-error" class="error" for="type"></label>
                        </div>
                    </div>
                    <label class="col-md-2"> Image </label>
                    <div class="col-md-4">
                           <input name="product_image" id="product_image" type="file" class="form-control"/>
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-md-2"> Catelogue </label>
                    <div class="col-md-10">
                           <input name="catelogue[]" id="catelogue" type="file" class="form-control" multiple=""/>
                    </div>
                </div>
                <div class="product_col no_display_col">
                    <div class="form-group">
                        <label class="col-md-2"> Category </label>
                        <div class="col-md-4">
                            <?php echo form_dropdown('c_id',$product_cat,'','id="c_id" class="form-control"'); ?>
                        </div>
                        
                    </div>
                </div>
                <div class="service_col no_display_col">
                    <div class="form-group">
                        <label class="col-md-2"> Service type </label>
                        <div class="col-md-4">
                            <?php echo form_dropdown('service_type',$service_cat,'','id="service_type" class="form-control"'); ?>
                        </div>
                        <label class="col-md-2"> Man power </label>
                        <div class="col-md-4">
                            <input name="man_power" id="man_power" type="number" class="form-control" value=""/>
                        </div>
                    </div>
                </div>
                <div class="col-md-9 col-md-offset-2">
                    <button type="submit" name="submit" class="btn btn-success" id="submit" val="insert">Save </button>
                    <a href="<?php echo site_url('seller/products') ?>" class="btn btn-default">Cancel</a>
                </div>
            <?php } echo form_close(); ?>
            </div>            
        </div>
      </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <!-- Control Sidebar -->
  <?php $this->load->view('common/common/footer'); ?>
  <!-- Add the sidebar's background. This div must be placed
       immediately after the control sidebar -->
  <div class="control-sidebar-bg"></div>
</div>
<!-- ./wrapper -->

<?php $this->load->view('common/common/js') ?>
<script src="<?php echo config_item('ui_base_path') ?>custom/js/jquery.validate.min.js"></script>
<script src="<?php echo config_item('ui_base_path') ?>plugins/bootstrap-select/bootstrap-select.min.js"></script>
<script type="">
    $(document).ready(function() {
    $.validator.setDefaults({
            //ignore: []
    });
    $("#customer_form").validate({
    <?php if ($mode == 'create') { ?>
        rules: {
            product_name: {
                required: true,
                minlength:3,
                maxlength:35
            },
            product_price: {
                required: true
            },
            type: {
                required: true
            },
            c_id: {
                required: true
            },
            catelogue: {
                required: true
            },
            service_type: {
                required: true
            },
            man_power: {
                required: true
            }
        },
        
        messages: {				
            //product_email: {					
//                required: "Email should not leave empty.",
//                remote:"email id is already taken please enter anoter"
//                }
        },
    <?php }else{ ?>
        rules: {
            product_name: {
                required: true,
                minlength:3,
                maxlength:35
            },
            product_price: {
                required: true
            },
            type: {
                required: true
            },
            c_id: {
                required: true
            },
            catelogue: {
                required: true
            },
            service_type: {
                required: true
            },
            man_power: {
                required: true
            }
        },
        
        messages: {				
            product_email: {					
                required: "Email should not leave empty."
                }
        },
    <?php } ?>
        submitHandler: function(form){
        event.preventDefault();// using this page stop being refreshing
        var formData = new FormData();
        if($('#catelogue')[0].files!==''){
            jQuery.each(jQuery('#catelogue')[0].files, function(i, file) {
                formData.append('catelogue[]', file);
            });
        }
        
        if($('#product_image')[0].files[0]!==''){
            formData.append('product_image', $('#product_image')[0].files[0]);
        }
        //alert($('#type:checked').val());
        //return false;
        formData.append('product_name', $('#product_name').val());
        formData.append('type', $('#type:checked').val());
        formData.append('product_price', $('#product_price').val());
        formData.append('c_id', $('#c_id').val());
        formData.append('service_type', $('#service_type').val());
        formData.append('man_power', $('#man_power').val());
        <?php if ($mode == 'edit') { ?>
        formData.append('product_old_image', $('#product_old_image').val());
        formData.append('id', $('#id').val());
        <?php } ?>
        formData.append('submit', $("#submit").attr('val'));
        $.ajax({
            url: form.action,
            type: form.method,
            async: false,
            cache: false,
            contentType: false,
            enctype: 'multipart/form-data',
            processData: false,
            dataType: "json",
            //data: $(form).serialize(),
            data: formData,
            success: function(res) {
                if(res.status=='success'){
                    $('.error_msg').hide();
                    $('.info_msg').show();
                    $('.info_msg').html(res.message);
                    $(location).attr('href', BASE_URL + res.go_to)
                    redirect(res.go_to);
                }else{
                    $('.info_msg').hide();
                    $('.error_msg').show();
                    $('.error_msg').html(res.message);
                }
            }            
        });
    }
    });
    });
     
      
    function open_box_display(id){
        //alert(id)
      if(id==0){
        $(".service_col").hide();
        $(".product_col").show();
      }else if(id==1){
        $(".product_col").hide();
        $(".service_col").show();
      }
    }
         
  </script>
</body>
</html>