<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <?php $this->load->view('common/common/css'); ?>
  <!-- DataTables -->
  <link rel="stylesheet" href="<?php echo config_item('ui_base_path'); ?>plugins/datatables/dataTables.bootstrap.css">
  
  <style>
        .profile_seta{
            width: 200px !important;
            height: 200px !important;
        }      
  </style>
  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->
</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">
  <?php $this->load->view('common/buyer-top_nav') ?>
  <?php $this->load->view('common/buyer-left_nav') ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Edit Profile
        <!--small>advanced tables</small-->
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo site_url('admin'); ?>"><i class="fa fa-dashboard"></i> Home </a></li>
        <li class="active"> Edit Profile </li>
      </ol>
    </section>

    <!-- Main content -->
    <input type="hidden" id="page" value="nav-profile"/>
    <section class="content">
        <div class="box box-primary">
          <div class="panel-body">
            <?php
                $success_message = $this->session->flashdata('insert_record');
                if ($success_message['status'] == "success") {
                    echo '<p class="alert alert-success sas-succcess-message">' . $success_message['message'] . '</p><div class="clearfix"></div>';
                } else if ($success_message['status'] == "fail") {
                    echo '<p class="alert alert-danger sas-succcess-message">' . $success_message['message'] . '</p><div class="clearfix"></div>';
                }
            ?>
            <div class="error_msg alert alert-danger alert-dismissible"></div>
            <div class="info_msg alert alert-success alert-dismissible"></div>      
            <?php
                echo form_open_multipart('buyer/buyer_profile/save_buyer_profile_edit', array('id' => 'customer_form', 'class' => 'form-horizontal'));
            ?>
                    <h2>Profile Details</h2>
                    <div class="form-group">
                        <label class="col-md-2"> Name </label>
                        <div class="col-md-4">
                            <input name="name" id="name" type="text" class="form-control" value="<?php echo $item_details['name']; ?>"/>
                        </div>
                        <label class="col-md-2"> User Name </label>
                        <div class="col-md-4">
                            <input name="username" id="username" type="text" class="form-control" value="<?php echo $item_details['username']; ?>"/>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-md-2"> Email </label>
                        <div class="col-md-4">
                            <input name="email" id="email" type="email" class="form-control" value="<?php echo $item_details['email']; ?>"  readonly=""/>
                        </div>
                        <label class="col-md-2"> Mobile </label>
                        <div class="col-md-4">
                            <input name="mobile" id="mobile" type="number" class="form-control" value="<?php echo $item_details['mobile']; ?>"/>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-md-2"> Image </label>
                        <div class="col-md-4">
                            <input name="image" id="image" type="file" class="form-control" value=""/>
                            <img src="<?php echo config_item('root_dir')."assets/images/users/".$item_details['image']; ?>" alt="Image" height="150" width="250"/>
                        </div>
                        <label class="col-md-2"> Category </label>
                        <div class="col-md-4">
                            <?php echo form_dropdown('c_id',$category,$item_details['c_id'],'id="c_id" class="form-control"'); ?>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-md-2"> Address </label>
                        <div class="col-md-4">
                            <textarea name="address" id="address" class="form-control"><?php echo $item_details['address']; ?></textarea>
                        </div>
                        <label class="col-md-2"> Gender </label>
                        <div class="col-md-4">
                            <label>
                              <input type="radio" id="gender" name="gender" class="minimal" value="0" <?php if($item_details['address']==0){ echo 'checked'; } ?>/>
                              Male &nbsp;&nbsp;&nbsp;&nbsp;
                            </label>
                            <label>
                              <input type="radio" id="gender" name="gender" class="minimal" value="1" <?php if($item_details['address']==1){ echo 'checked'; } ?>/>
                              Female
                            </label>
                            <label id="gender-error" class="error" for="gender"></label>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-md-2"> Company Name </label>
                        <div class="col-md-4">
                            <input name="cd_name" id="cd_name" type="text" class="form-control" value="<?php echo $com_details['cd_name']; ?>"/>
                        </div>
                        <label class="col-md-2"> PAN No/Company Registration No </label>
                        <div class="col-md-4">
                            <input name="cd_reg_no" id="cd_reg_no" type="text" class="form-control" value="<?php echo $com_details['cd_reg_no']; ?>"/>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-md-2"> Company Exporter No </label>
                        <div class="col-md-4">
                            <input name="cd_exporter_no" id="cd_exporter_no" type="text" class="form-control" value="<?php echo $com_details['cd_exporter_no']; ?>"/>
                        </div>
                    </div>
                    <div class="col-md-9 col-md-offset-2">
                        <button type="submit" name="update" class="btn btn-success"> Update </button>
                        <a href="<?php echo site_url('admin/schools') ?>" class="btn btn-default">Cancel</a>
                    </div>
            <?php echo form_close(); ?>
            </div>            
        </div>
      </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <?php $this->load->view('common/common/footer') ?>
  <!-- Add the sidebar's background. This div must be placed
       immediately after the control sidebar -->
  <div class="control-sidebar-bg"></div>
</div>
<!-- ./wrapper -->
<?php $this->load->view('common/common/js') ?>
<script src="<?php echo config_item('ui_base_path') ?>custom/js/jquery.validate.min.js"></script>
<script type="text/javascript" src="<?php echo config_item('ui_base_path') ?>plugins/smartwizard/js/validator.min.js"></script>
<script type="text/javascript" src="<?php echo config_item('ui_base_path') ?>plugins/smartwizard/js/jquery.smartWizard.js"></script>
<!-- page script -->
<script type="text/javascript">
        $(document).ready(function(){
    
        //iCheck for checkbox and radio inputs
        $('input[type="checkbox"].minimal, input[type="radio"].minimal').iCheck({
          checkboxClass: 'icheckbox_minimal-blue',
          radioClass: 'iradio_minimal-blue'
        });
            //form validation        
    $("#customer_form").validate({
        rules: {
                name: {
                    required: true
                },
                username: {
                    required: true,
                    minlength:3
                },
                email: {
                    required: true,
                    minlength:3
                },
                mobile: {
                    required: true,
                    minlength:3
                },
                c_id: {
                    required: true
                },
                address: {
                    required: true,
                },
                gender: {
                    required: true,
                },
                cd_name: {
                    required: true,
                },
                cd_exporter_no: {
                    required: true
                },
                cd_reg_no: {
                    required: true
                }
            },
            submitHandler: function(form){
            event.preventDefault();// using this page stop being refreshing
            var formData = new FormData();
            if($('#image')[0].files[0]!==''){
                formData.append('image', $('#image')[0].files[0]);
            }
            formData.append('name', $('#name').val());
            formData.append('username', $('#username').val());
            formData.append('email', $('#email').val());
            formData.append('mobile', $('#mobile').val());
            formData.append('c_id', $('#c_id').val());
            formData.append('address', $('#address').val());
            formData.append('gender', $('input[name="gender"]:checked').val());
            formData.append('cd_name', $('#cd_name').val());
            formData.append('cd_exporter_no', $("#cd_exporter_no").val());
            formData.append('cd_reg_no', $("#cd_reg_no").val());
            $.ajax({
                url: form.action,
                type: form.method,
                async: false,
                cache: false,
                contentType: false,
                enctype: 'multipart/form-data',
                processData: false,
                dataType: "json",
                data: formData,
                success: function(res) {
                    if(res.status=='success'){
                        $('.error_msg').hide();
                        $('.info_msg').hide();
                        $('.info_msg').show();
                        $('.info_msg').html(res.message);
                        $('.info_msg').fadeOut(4000);
                    }else{
                        $('.error_msg').hide();
                        $('.error_msg').show();
                        $('.error_msg').html(res.message);
                        $('.error_msg').fadeOut(4000);
                    }
                }            
            });
        } 
        });
        });   
</script>
</body>
</html>