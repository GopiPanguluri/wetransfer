Dear <?php echo $name; ?>,<br /><br />
Please use below are the WE Transfer Credentials for your account please find the details below.<br />
<b>Website: </b> <?php echo base_url(); ?>.<br />
<b>Username: </b> <?php echo $username; ?>.<br />
<b>Password: </b> <?php echo $Password; ?>.<br />
<i>Regards,</i><br />
<?php echo 'WE Transfer team.'; ?>
<?php //exit;  ?>