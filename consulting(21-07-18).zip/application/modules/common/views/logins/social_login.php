<!DOCTYPE html>
<html lang="en">
<head>

	<title><?php echo $this->lang->line('title_default'); ?></title>

	<!-- Required meta tags always come first -->
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta http-equiv="x-ua-compatible" content="ie=edge">

	<!-- Main Font -->
	<script src="<?php echo $this->config->item('social_aassets');?>js/webfontloader.min.js"></script>

	<script>
		WebFont.load({
			google: {
				families: ['Roboto:300,400,500,700:latin']
			}
		});
	</script>

	<!-- Bootstrap CSS -->
	<link rel="stylesheet" type="text/css" href="<?php echo $this->config->item('social_assets');?>Bootstrap/dist/css/bootstrap-reboot.css">
	<link rel="stylesheet" type="text/css" href="<?php echo $this->config->item('social_assets');?>Bootstrap/dist/css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="<?php echo $this->config->item('social_assets');?>Bootstrap/dist/css/bootstrap-grid.css">

	<!-- Theme Styles CSS -->
	<link rel="stylesheet" type="text/css" href="<?php echo $this->config->item('social_assets');?>css/theme-styles.css">
	<link rel="stylesheet" type="text/css" href="<?php echo $this->config->item('social_assets');?>css/blocks.css">
	<link rel="stylesheet" type="text/css" href="<?php echo $this->config->item('social_assets');?>css/fonts.css">

	<!-- Styles for plugins -->
	<link rel="stylesheet" type="text/css" href="<?php echo $this->config->item('social_assets');?>css/jquery.mCustomScrollbar.min.css">
	<link rel="stylesheet" type="text/css" href="<?php echo $this->config->item('social_assets');?>css/daterangepicker.css">
	<link rel="stylesheet" type="text/css" href="<?php echo $this->config->item('social_assets');?>css/bootstrap-select.css">
    <style>
        .error{
            color: red;
            display: block;
        }
        .error_msg,.info_msg{
            display: none;
        }
        .buttons_row button{
            padding: 10px;
            margin-left: 5px;
            margin-right: 5px;
        }
    </style>
</head>

<body class="landing-page">

<div class="content-bg-wrap">
	<div class="content-bg"></div>
</div>


<!-- Landing Header -->

<div class="container">
	<div class="row">
		<div class="col-xl-12 col-lg-12 col-md-12">
			<div id="site-header-landing" class="header-landing">
				<a href="<?php echo config_item('root_dir'); ?>" class="logo">
					<img src="<?php echo config_item('frontend_assets');?>images/logo.png" height="150" width="150" alt="Construction Bay"/>
					<!--h5 class="logo-title">olympus</h5-->
				</a>
				<ul class="profile-menu">
					<li>
						<a href="#">About Us</a>
					</li>
					<li>
						<a href="#">Careers</a>
					</li>
					<li>
						<a href="#">FAQS</a>
					</li>
					<li>
						<a href="#">Help & Support</a>
					</li>
					<li>
						<a href="#" class="js-expanded-menu">
							<svg class="olymp-menu-icon"><use xlink:href="icons/icons.svg#olymp-menu-icon"></use></svg>
							<svg class="olymp-close-icon"><use xlink:href="icons/icons.svg#olymp-close-icon"></use></svg>
						</a>
					</li>
				</ul>
			</div>
		</div>
	</div>
</div>

<!-- ... end Landing Header -->

<!-- Login-Registration Form  -->

<div class="container">
	<div class="row display-flex">
		<div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-xs-12">
			<div class="landing-content">
				<h1>Welcome to the Biggest Social Network in the World</h1>
				<p>We are the best and biggest social network with 5 billion active users all around the world. Share you
					thoughts, write blog posts, show your favourite music via Stopify, earn badges and much more!
				</p>
				<a href="<?php echo base_url('admin/login/social_register'); ?>" class="btn btn-md btn-border c-white">Register Now!</a>
			</div>
		</div>

		<div class="col-xl-5 col-lg-6 col-md-12 col-sm-12 col-xs-12">
			<div class="registration-login-form">
				<!-- Nav tabs -->
				<ul class="nav nav-tabs" role="tablist">
					<li class="nav-item">
						<a class="nav-link active" data-toggle="tab" href="#home" role="tab">
							<svg class="olymp-login-icon"><use xlink:href="icons/icons.svg#olymp-login-icon"></use></svg>
						</a>
					</li>
					<li class="nav-item">
						<a class="nav-link" data-toggle="tab" href="#profile" role="tab">
							<svg class="olymp-register-icon"><use xlink:href="icons/icons.svg#olymp-register-icon"></use></svg>
						</a>
					</li>
				</ul>

				<!-- Tab panes -->
				<div class="tab-content">
					<div class="tab-pane active" id="profile" role="tabpanel" data-mh="log-tab">
						<div class="title h6">Login to your Account</div>
						<form class="content" method="post" action="<?php echo base_url('admin/login/login_status'); ?>" id="login_form">
                        <div class="error_msg alert alert-danger alert-dismissible"></div>
                        <div class="info_msg alert alert-success alert-dismissible"></div>
							<div class="row">
								<div class="col-xl-12 col-lg-12 col-md-12">
									<div class="form-group label-floating is-empty">
										<label class="control-label">Your Email</label>
										<input class="form-control" placeholder="" type="email" name="email" id="email"/>
                                        <input name="type" type="hidden" value="social"/>
									</div>
									<div class="form-group label-floating is-empty">
										<label class="control-label">Your Password</label>
										<input name="password" class="form-control" placeholder="" type="password" id="password"/>
									</div>

									<div class="remember">

										<div class="checkbox">
											<label>
												<input name="optionsCheckboxes" type="checkbox">
												Remember Me
											</label>
										</div>
										<a href="#" class="forgot">Forgot my Password</a>
									</div>

									<button type="submit" class="btn btn-lg btn-primary full-width">Login</button>

									<div class="or"></div>

									<a href="#" class="btn btn-lg bg-facebook full-width btn-icon-left"><i class="fa fa-facebook" aria-hidden="true"></i>Login with Facebook</a>

									<a href="#" class="btn btn-lg bg-twitter full-width btn-icon-left"><i class="fa fa-twitter" aria-hidden="true"></i>Login with Twitter</a>


									<p>Don't you have an account? <a href="<?php echo base_url('admin/login/social_register'); ?>">Register Now!</a> it's really simple and you can start enjoing all the benefits!</p>
								</div>
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

<!-- ... end Login-Registration Form  -->





<!-- jQuery first, then Other JS. -->
<script src="<?php echo $this->config->item('social_assets');?>js/jquery-3.2.0.min.js"></script>
<!-- Js effects for material design. + Tooltips -->
<script src="<?php echo $this->config->item('social_assets');?>js/material.min.js"></script>
<!-- Helper scripts (Tabs, Equal height, Scrollbar, etc) -->
<script src="<?php echo $this->config->item('social_assets');?>js/theme-plugins.js"></script>
<!-- Init functions -->
<script src="<?php echo $this->config->item('social_assets');?>js/main.js"></script>

<!-- Select / Sorting script -->
<script src="<?php echo $this->config->item('social_assets');?>js/selectize.min.js"></script>

<!-- Swiper / Sliders -->
<script src="<?php echo $this->config->item('social_assets');?>js/swiper.jquery.min.js"></script>

<!-- Datepicker input field script-->
<script src="<?php echo $this->config->item('social_assets');?>js/moment.min.js"></script>
<script src="<?php echo $this->config->item('social_assets');?>js/daterangepicker.min.js"></script>

<script src="<?php echo $this->config->item('social_assets');?>js/mediaelement-and-player.min.js"></script>
<script src="<?php echo $this->config->item('social_assets');?>js/mediaelement-playlist-plugin.min.js"></script>
<script src="<?php echo config_item('ui_base_path') ?>custom/js/jquery.validate.min.js"></script>
<script>
    var BASE_URL = '<?php echo base_url(); ?>';
    $(document).ready(function(event) {
    $.validator.setDefaults({
            ignore: []
    });
    $("#login_form").validate({
        rules: {
        email: {
            required: true,
            email: true
        },
        password: {
            required: true,
            minlength:5
        }
        },
        messages: {				
            email: {					
                required: "Email should not leave empty.",
                email: "Please enter valid email id."
                },
            password: {					
                required: "Password is required.",
                minlength: "Please enter the password of minimum 5 characters"
                }
        },
        submitHandler: function(form,event){
        event.preventDefault();// using this page stop being refreshing
        $.ajax({
            url: form.action,
            type: form.method,
            dataType: "json",
            data: $(form).serialize(),
            success: function(res) {
                if(res.status==0){
                    $('.error_msg').hide();
                    $('.info_msg').show();
                    $('.info_msg').html(res.message);
                    $(location).attr('href', BASE_URL + res.go_to)
                    redirect(res.go_to);
                }else{
                    $('.error_msg').show();
                    $('.error_msg').html(res.message);
                }
            }            
        });
    }
    });
    });
    
</script>
</body>
</html>