<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends MX_Controller  {

	function __construct(){
        parent::__construct();
        $this->load->model('home_model');
    }
    
	public function index(){
        modules::run('admin/login/is_home_logged_in');
        $programs = $this->home_model->get_programs_list();
        foreach($programs as $rw_programs){
            $rw_programs['get_pro'] = $this->home_model->get_progress_status($rw_programs['program_id'],$_SESSION['home_user_id']);
            $rw_programs['get_pro'] = round($rw_programs['get_pro']); 
            $pr_ls[] = $rw_programs;
        }
        $data['programs'] = $pr_ls; 
        $this->load->view('home',$data);
	}
    
	public function products($prgm_id='',$chaptr_id='',$lession_id='',$video_id=''){
        modules::run('admin/login/is_home_logged_in');
        $data['chapters'] = $this->home_model->get_chapters_list($prgm_id);
        if(count($data['chapters'])==0){
            redirect('home');
        }
        //echo '<pre>'; print_r($data['chapters']);exit;
        if($chaptr_id==''){
          if(isset($data['chapters'][0]['chapter_id'])){
            $chaptr_id = $data['chapters'][0]['chapter_id'];
          }else{
            $chaptr_id = '';
          }
        }
        
        //$chapters_ls = array(''=>'Select');
        foreach($data['chapters'] as $rw_chapters){
            $chapters_ls[base_url('home/products/'.$prgm_id.'/'.$rw_chapters['chapter_id'])] = $rw_chapters['chapter_name'];
        }
        $programs = $this->home_model->get_programs_list();
        foreach($programs as $rw_programs){
            $programs_ls[base_url('home/products/'.str_replace(' ', '-', $rw_programs['program_name']))] = $rw_programs['program_name'];
        }
        $lessions = $this->home_model->get_lessions_list($chaptr_id);
        $lessions_ls = array();
        foreach($lessions as $rw_lessions){
            $lessions_ls[base_url('home/products/'.$prgm_id.'/'.$rw_lessions['chapter_id'].'/'.$rw_lessions['lession_id'])] = $rw_lessions['lession_name'];
        }
        
        //echo '<pre>'; print_r($lessions);exit;
        if($lession_id==''){
          if(isset($lessions[0]['lession_id'])){
            $lession_id = $lessions[0]['lession_id'];
          }else{
            $lession_id = '';
          }
        }
        //echo '<pre>'; print_r($lessions_ls);exit;
        $data['videos'] = $this->home_model->get_videos_list($lession_id);
        if($video_id==''){
          if(isset($data['videos'][0]['video_id'])){
            $video_id = $data['videos'][0]['video_id'];
          }else{
            $video_id = '';
          }
        }
        //echo '<pre>'; print_r($lession_id);exit;        
        $data['pre_video'] = $this->home_model->get_pre_video($lession_id,$video_id);
        //echo $this->db->last_query();
        //echo '<pre>'; print_r($data['pre_video']);exit;
        if(isset($data['pre_video'])&&count($data['pre_video'])!==0){
            $data_check_sts = array(
                    'select_fields' => '',
                    'where' => array(
                        'video_id' => $data['pre_video']['video_id'],
                    ),
                    'tablename' => 'course_seen'
            );
            $data['vid_sts'] = $this->common_model->get_individual_details($data_check_sts);   
        }else{
            $data['vid_sts'] = '';
        }
        //echo '<pre>'; print_r($check_vid_sts);exit;
        $data['chapters_ls'] = $chapters_ls;
        $data['programs'] = $programs_ls;
        $data['lessions_ls'] = $lessions_ls;
        $data['prgm_id'] = $prgm_id;
        $data['chaptr_id'] = $chaptr_id;
        $data['prgm_sel_id'] = base_url('home/products/'.$prgm_id);
        $data['chaptr_sel_id'] = base_url('home/products/'.$prgm_id.'/'.$chaptr_id);
        $data['lession_id'] = $lession_id;
        $data['less_sel_id'] = base_url('home/products/'.$prgm_id.'/'.$chaptr_id.'/'.$lession_id);
        $data['video_id'] = $video_id;
        $data['program'] = $this->home_model->get_program($prgm_id);
        $data['get_pro'] = $this->home_model->get_progress_status($data['program']['program_id'],$_SESSION['home_user_id']);
        $data['get_pro'] = round($data['get_pro']);
        //echo '<pre>'; print_r($data['videos']);exit;
        $this->load->view('course',$data);
	}
    
	public function progress(){
      modules::run('admin/login/is_home_logged_in');
      $programs = $this->home_model->get_programs_list();
        foreach($programs as $rw_programs){
            $rw_programs['get_pro'] = $this->home_model->get_progress_status($rw_programs['program_id'],$_SESSION['home_user_id']);
            $rw_programs['get_pro'] = round($rw_programs['get_pro']); 
            $pr_ls[] = $rw_programs;
        }
        $data['programs'] = $pr_ls;
      //echo '<pre>'; print_r($data);exit;
      $this->load->view('progress',$data);
	}
    
	public function progress_product(){
      modules::run('admin/login/is_home_logged_in');
      $programs = $this->home_model->get_programs_list();
        foreach($programs as $rw_programs){
            $rw_programs['get_pro'] = $this->home_model->get_progress_status($rw_programs['program_id'],$_SESSION['home_user_id']);
            $rw_programs['get_pro'] = round($rw_programs['get_pro']); 
            $pr_ls[] = $rw_programs;
        }
        $data['programs'] = $pr_ls;
      $data['chapters'] = $this->home_model->get_chapters_list($data['programs']['0']['program_name']);
      //$programs['0']['program_name']
      //echo '<pre>'; print_r($data['chapters']);exit;
      $this->load->view('progress_product',$data);
	}
    
	//public function profile(){
//      modules::run('admin/login/is_home_logged_in');
//      $this->load->view('progress_product');
//	}

	public function how_to_get_help(){
        modules::run('admin/login/is_home_logged_in');
        $this->load->view('how_to_get_help');
	}
    
	public function qa_calls(){
        modules::run('admin/login/is_home_logged_in');
        $this->load->view('qa_calls');
	}
    
	public function qa_callsas(){
        modules::run('admin/login/is_home_logged_in');
        $this->load->view('qa_calls');
	}
    
	public function refer_a_friend(){
        modules::run('admin/login/is_home_logged_in');
        $this->load->view('refer_a_friend');
	}
    
	public function register(){
        $this->load->view('register');
	}
    
    public function change_status_course(){
        //echo '<pre>';print_r($_POST);exit;
        $this->load->model('common/common_model');
        $data = array(
                'select_fields' => '',
                'where' => array(
                    'video_id' => $_POST['video_id'],
                    'user_id' => $_SESSION['home_user_id'],
                ),
                'tablename' => 'course_seen'
        );
        $check_unique = $this->common_model->get_list($data);
        //echo '<pre>';print_r($check_unique);exit;
        if(count($check_unique)==0){
            $info = array(
                'video_id' => $_POST['video_id'],
                'seen_status' => $_POST['seen_status'],
                'user_id' => $_SESSION['home_user_id']
            );
            $result = $this->common_model->insert_details('course_seen', $info);
        }else{
            $info = array(
                'where' => array(
                    'video_id' => $_POST['video_id'],
                ),
                'data' => array(
                    'seen_status' => $_POST['seen_status'],
                    'user_id' => $_SESSION['home_user_id']
                ),
                'tablename' => 'course_seen'
            );
            //echo '<pre>';print_r($info);exit;
            $result = $this->common_model->update_details($info);
        }
        //echo $this->db->last_query();exit;
        if($result){
            echo "1";
        }else{
            echo "0";
        }
    }
    
    function get_progress_status(){
        //echo '<pre>';print_r($_POST);exit;
        $get_pro = $this->home_model->get_progress_status($_POST['program_id'],$_SESSION['home_user_id']);
        //echo $this->db->last_query();
        //echo '<pre>';print_r($get_pro);exit;
        $status = array(
            'status' => '1',
            'percentage' => round($get_pro)
        );
        echo json_encode($status);exit;
    }
    
    
	public function search(){
	    modules::run('admin/login/is_home_logged_in');
        $item = $this->input->get('search_term');
        $get_pro = $this->home_model->get_search_status($item);
        //echo $this->db->last_query();
        //echo '<pre>';print_r($get_pro);exit;
        $data['items'] = $get_pro;
        $data['items_count'] = count($get_pro);
        $this->load->view('search_page',$data);
	}
}
?>