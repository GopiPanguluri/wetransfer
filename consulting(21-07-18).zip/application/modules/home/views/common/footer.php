<section class="site-search-overlay">
  <button class="search-close show-for-large">&#10005;</button>
  <div class="search-container">
    <header class="search-header">
      <div class="page-icon show-for-large">
        <div class="image-icon"></div>
      </div>
      <h2>Search the WE Tranformation </h2>
    </header>
    <div class="block search-form-container">
      <form action="<?php echo base_url('home/search'); ?>" method="get" id="site-search">
        <input type="text" id="search_term" required="" name="search_term" value="" placeholder="Search keywords..." autofocus=""/>
        <ul class="no-bullet search-filters"> 
          <li class="form-field">
            <div class="checkbox-container">
              <input type="checkbox" id="consulting-accelerator" name='products[]' value='1' checked=""/>
              <label class="" for="consulting-accelerator">WE Transformation<sup>TH</sup></label>
            </div>
          </li>
          <li class="form-field">
            <div class="checkbox-container">
              <input type="checkbox" id="uplevel-consulting" name='products[]' value='2' disabled=""/>
              <label class="" for="uplevel-consulting">WE Accelerator<sup>TH</sup></label>
            </div>
          </li>
          <li class="form-field">
            <div class="checkbox-container">
              <input type="checkbox" id="quantum-mastermind" name='products[]' value='3' disabled=""/>
              <label class="" for="quantum-mastermind">WE Retreats<sup>TH</sup></label>
            </div>
          </li>
        </ul>
        <button class="button primary hide-for-large">Show Results</button>
      </form>
    </div>
    <!-- /.search-form-container -->
  </div>
</section>
<div class="reveal program" id="program-type-for-calls" data-reveal>
  <div class="row reveal-inner">
    <header class="reveal-header columns small-12">
      <div class="sub-heading">Weekly Q&A Calls</div>
      <h1 class="text-center">Please select the program</h1>
    </header>
    <div class="reveal-content">
      <div class="columns small-12">
        <ul class="no-bullet text-center programs-list">
          <li>
            <a href="#">Consulting Accelerator<sup>TH</sup></a>
          </li>              
        </ul>
      </div>
    </div>
    <!-- /.reveal-content -->
  </div>
  <!-- /.reveal-inner -->
  <button class="close-button" data-close aria-label="Close modal" type="button">
    <span aria-hidden="true">&#10005;</span>
  </button>
</div>
<div class="reveal program" id="program-type-for-community" data-reveal>
  <div class="row reveal-inner">
    <header class="reveal-header columns small-12">
      <div class="sub-heading">Facebook Group</div>
      <h1 class="text-center">Please select the program</h1>
    </header>
    <div class="reveal-content">
      <div class="columns small-12">
        <ul class="no-bullet text-center programs-list">
          <li>
            <a target="_blank" href="#">Consulting Accelerator<sup>TH</sup></a>
          </li>
        </ul>
      </div>
    </div>
    <!-- /.reveal-content -->
  </div>
  <!-- /.reveal-inner -->
  <button class="close-button" data-close aria-label="Close modal" type="button">
    <span aria-hidden="true">&#10005;</span>
  </button>
</div>