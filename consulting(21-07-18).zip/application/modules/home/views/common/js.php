<!--script data-cfasync="false" src="<?php //echo config_item('site_base_path'); ?>js/email-decode.min.js"></script-->
<script src="<?php echo config_item('site_base_path'); ?>js/app.js"></script>
<script>
    //var billingIssues = $('.has-billing-issue').length > 0
//    var isSuspended = $('.is-suspended').length > 0
//    if(billingIssues) {
//        var billignReveal = new Foundation.Reveal($('#billing-issue'))
//        billignReveal.open()
//    } else if (isSuspended){
//        var name = $('.is-suspended').data('name');
//        var messageHtml = 'Unfortunately your access to the ' + name + ' content has been suspended.<br>' +
//        'If you have any questions please email us to <a href="#">support@consulting.com</a>';
//        $('#suspend-modal-message').html(messageHtml);
//        var accountSuspended = new Foundation.Reveal($('#account-suspended'))
//        accountSuspended.open()
//    }
//    $('.continue-link').each(function(index, value) {
//    var link = localStorage.getItem('product-last-location-' + $(value).data().id)
//    if(link)
//    $(this).attr('href', link)
//    })
</script>