<?php

$lang['company'] = "Consulting";
$lang['title_default_mini']		= "Consulting";
$lang['title_default']		= "Consulting";
$lang['copy_r']			= "Copyright &copy; 2018";
$lang['copy_right']			= "consulting.com";

/*
$lang['copy_right']			= "Copyright &copy; Spriha BioSciences 2013-14";
$lang['title_default']		= "Spriha BioSciences Daily Report";
$lang['company'] = "SPRIHA BIOSCIENCES";
*/

/* End of file site_lang.php */
/* Location: ./application/language/english/site_lang.php */