<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-07-20 00:21:10 --> Config Class Initialized
INFO - 2018-07-20 00:21:10 --> Hooks Class Initialized
DEBUG - 2018-07-20 00:21:10 --> UTF-8 Support Enabled
INFO - 2018-07-20 00:21:10 --> Utf8 Class Initialized
INFO - 2018-07-20 00:21:10 --> URI Class Initialized
INFO - 2018-07-20 00:21:10 --> Router Class Initialized
INFO - 2018-07-20 00:21:10 --> Output Class Initialized
INFO - 2018-07-20 00:21:10 --> Security Class Initialized
DEBUG - 2018-07-20 00:21:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 00:21:10 --> Input Class Initialized
INFO - 2018-07-20 00:21:10 --> Language Class Initialized
INFO - 2018-07-20 00:21:10 --> Language Class Initialized
INFO - 2018-07-20 00:21:10 --> Config Class Initialized
INFO - 2018-07-20 00:21:10 --> Loader Class Initialized
DEBUG - 2018-07-20 00:21:10 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-20 00:21:10 --> Helper loaded: url_helper
INFO - 2018-07-20 00:21:10 --> Helper loaded: form_helper
INFO - 2018-07-20 00:21:10 --> Helper loaded: date_helper
INFO - 2018-07-20 00:21:10 --> Helper loaded: util_helper
INFO - 2018-07-20 00:21:10 --> Helper loaded: text_helper
INFO - 2018-07-20 00:21:10 --> Helper loaded: string_helper
INFO - 2018-07-20 00:21:10 --> Database Driver Class Initialized
DEBUG - 2018-07-20 00:21:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-20 00:21:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-20 00:21:10 --> Email Class Initialized
INFO - 2018-07-20 00:21:10 --> Controller Class Initialized
DEBUG - 2018-07-20 00:21:10 --> Users MX_Controller Initialized
DEBUG - 2018-07-20 00:21:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-20 00:21:10 --> Helper loaded: file_helper
DEBUG - 2018-07-20 00:21:10 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-20 00:21:10 --> Login MX_Controller Initialized
INFO - 2018-07-20 00:21:10 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-20 00:21:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-20 00:21:10 --> Final output sent to browser
DEBUG - 2018-07-20 00:21:10 --> Total execution time: 0.2949
INFO - 2018-07-20 00:21:10 --> Config Class Initialized
INFO - 2018-07-20 00:21:10 --> Hooks Class Initialized
DEBUG - 2018-07-20 00:21:10 --> UTF-8 Support Enabled
INFO - 2018-07-20 00:21:10 --> Utf8 Class Initialized
INFO - 2018-07-20 00:21:10 --> URI Class Initialized
INFO - 2018-07-20 00:21:10 --> Router Class Initialized
INFO - 2018-07-20 00:21:10 --> Output Class Initialized
INFO - 2018-07-20 00:21:10 --> Security Class Initialized
DEBUG - 2018-07-20 00:21:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 00:21:10 --> Input Class Initialized
INFO - 2018-07-20 00:21:10 --> Language Class Initialized
INFO - 2018-07-20 00:21:10 --> Language Class Initialized
INFO - 2018-07-20 00:21:10 --> Config Class Initialized
INFO - 2018-07-20 00:21:10 --> Loader Class Initialized
DEBUG - 2018-07-20 00:21:10 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-20 00:21:10 --> Helper loaded: url_helper
INFO - 2018-07-20 00:21:10 --> Helper loaded: form_helper
INFO - 2018-07-20 00:21:10 --> Helper loaded: date_helper
INFO - 2018-07-20 00:21:10 --> Helper loaded: util_helper
INFO - 2018-07-20 00:21:10 --> Helper loaded: text_helper
INFO - 2018-07-20 00:21:10 --> Helper loaded: string_helper
INFO - 2018-07-20 00:21:10 --> Database Driver Class Initialized
DEBUG - 2018-07-20 00:21:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-20 00:21:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-20 00:21:10 --> Email Class Initialized
INFO - 2018-07-20 00:21:10 --> Controller Class Initialized
DEBUG - 2018-07-20 00:21:10 --> Users MX_Controller Initialized
DEBUG - 2018-07-20 00:21:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-20 00:21:10 --> Helper loaded: file_helper
DEBUG - 2018-07-20 00:21:10 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-20 00:21:10 --> Login MX_Controller Initialized
INFO - 2018-07-20 00:21:10 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-20 00:21:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-20 00:21:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-07-20 00:21:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-20 00:21:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-20 00:21:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-20 00:21:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-20 00:21:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-20 00:21:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-07-20 00:21:10 --> Final output sent to browser
DEBUG - 2018-07-20 00:21:10 --> Total execution time: 0.3765
INFO - 2018-07-20 00:23:39 --> Config Class Initialized
INFO - 2018-07-20 00:23:39 --> Hooks Class Initialized
DEBUG - 2018-07-20 00:23:39 --> UTF-8 Support Enabled
INFO - 2018-07-20 00:23:39 --> Utf8 Class Initialized
INFO - 2018-07-20 00:23:39 --> URI Class Initialized
INFO - 2018-07-20 00:23:39 --> Router Class Initialized
INFO - 2018-07-20 00:23:39 --> Output Class Initialized
INFO - 2018-07-20 00:23:39 --> Security Class Initialized
DEBUG - 2018-07-20 00:23:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 00:23:39 --> Input Class Initialized
INFO - 2018-07-20 00:23:39 --> Language Class Initialized
INFO - 2018-07-20 00:23:39 --> Language Class Initialized
INFO - 2018-07-20 00:23:39 --> Config Class Initialized
INFO - 2018-07-20 00:23:39 --> Loader Class Initialized
DEBUG - 2018-07-20 00:23:39 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-20 00:23:39 --> Helper loaded: url_helper
INFO - 2018-07-20 00:23:39 --> Helper loaded: form_helper
INFO - 2018-07-20 00:23:39 --> Helper loaded: date_helper
INFO - 2018-07-20 00:23:39 --> Helper loaded: util_helper
INFO - 2018-07-20 00:23:39 --> Helper loaded: text_helper
INFO - 2018-07-20 00:23:39 --> Helper loaded: string_helper
INFO - 2018-07-20 00:23:39 --> Database Driver Class Initialized
DEBUG - 2018-07-20 00:23:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-20 00:23:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-20 00:23:39 --> Email Class Initialized
INFO - 2018-07-20 00:23:39 --> Controller Class Initialized
DEBUG - 2018-07-20 00:23:39 --> Users MX_Controller Initialized
DEBUG - 2018-07-20 00:23:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-20 00:23:39 --> Helper loaded: file_helper
DEBUG - 2018-07-20 00:23:39 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-20 00:23:39 --> Login MX_Controller Initialized
INFO - 2018-07-20 00:23:39 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-20 00:23:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-20 00:23:39 --> Final output sent to browser
DEBUG - 2018-07-20 00:23:39 --> Total execution time: 0.3610
INFO - 2018-07-20 00:23:49 --> Config Class Initialized
INFO - 2018-07-20 00:23:49 --> Hooks Class Initialized
DEBUG - 2018-07-20 00:23:49 --> UTF-8 Support Enabled
INFO - 2018-07-20 00:23:49 --> Utf8 Class Initialized
INFO - 2018-07-20 00:23:49 --> URI Class Initialized
INFO - 2018-07-20 00:23:49 --> Router Class Initialized
INFO - 2018-07-20 00:23:49 --> Output Class Initialized
INFO - 2018-07-20 00:23:49 --> Security Class Initialized
DEBUG - 2018-07-20 00:23:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 00:23:49 --> Input Class Initialized
INFO - 2018-07-20 00:23:49 --> Language Class Initialized
INFO - 2018-07-20 00:23:49 --> Language Class Initialized
INFO - 2018-07-20 00:23:49 --> Config Class Initialized
INFO - 2018-07-20 00:23:49 --> Loader Class Initialized
DEBUG - 2018-07-20 00:23:49 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-20 00:23:49 --> Helper loaded: url_helper
INFO - 2018-07-20 00:23:49 --> Helper loaded: form_helper
INFO - 2018-07-20 00:23:49 --> Helper loaded: date_helper
INFO - 2018-07-20 00:23:49 --> Helper loaded: util_helper
INFO - 2018-07-20 00:23:49 --> Helper loaded: text_helper
INFO - 2018-07-20 00:23:49 --> Helper loaded: string_helper
INFO - 2018-07-20 00:23:49 --> Database Driver Class Initialized
DEBUG - 2018-07-20 00:23:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-20 00:23:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-20 00:23:49 --> Email Class Initialized
INFO - 2018-07-20 00:23:49 --> Controller Class Initialized
DEBUG - 2018-07-20 00:23:49 --> Users MX_Controller Initialized
DEBUG - 2018-07-20 00:23:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-20 00:23:49 --> Helper loaded: file_helper
DEBUG - 2018-07-20 00:23:49 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-20 00:23:49 --> Login MX_Controller Initialized
INFO - 2018-07-20 00:23:49 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-20 00:23:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-20 00:23:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-20 00:23:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-20 00:23:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-20 00:23:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-20 00:23:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-20 00:23:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-07-20 00:23:49 --> Final output sent to browser
DEBUG - 2018-07-20 00:23:49 --> Total execution time: 0.4867
INFO - 2018-07-20 00:23:50 --> Config Class Initialized
INFO - 2018-07-20 00:23:50 --> Hooks Class Initialized
DEBUG - 2018-07-20 00:23:50 --> UTF-8 Support Enabled
INFO - 2018-07-20 00:23:50 --> Utf8 Class Initialized
INFO - 2018-07-20 00:23:50 --> URI Class Initialized
INFO - 2018-07-20 00:23:50 --> Router Class Initialized
INFO - 2018-07-20 00:23:50 --> Output Class Initialized
INFO - 2018-07-20 00:23:50 --> Security Class Initialized
DEBUG - 2018-07-20 00:23:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 00:23:50 --> Input Class Initialized
INFO - 2018-07-20 00:23:50 --> Language Class Initialized
INFO - 2018-07-20 00:23:50 --> Language Class Initialized
INFO - 2018-07-20 00:23:50 --> Config Class Initialized
INFO - 2018-07-20 00:23:50 --> Loader Class Initialized
DEBUG - 2018-07-20 00:23:50 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-20 00:23:50 --> Helper loaded: url_helper
INFO - 2018-07-20 00:23:50 --> Helper loaded: form_helper
INFO - 2018-07-20 00:23:50 --> Helper loaded: date_helper
INFO - 2018-07-20 00:23:50 --> Helper loaded: util_helper
INFO - 2018-07-20 00:23:50 --> Helper loaded: text_helper
INFO - 2018-07-20 00:23:50 --> Helper loaded: string_helper
INFO - 2018-07-20 00:23:50 --> Database Driver Class Initialized
DEBUG - 2018-07-20 00:23:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-20 00:23:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-20 00:23:50 --> Email Class Initialized
INFO - 2018-07-20 00:23:50 --> Controller Class Initialized
DEBUG - 2018-07-20 00:23:50 --> Users MX_Controller Initialized
DEBUG - 2018-07-20 00:23:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-20 00:23:50 --> Helper loaded: file_helper
DEBUG - 2018-07-20 00:23:50 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-20 00:23:50 --> Login MX_Controller Initialized
INFO - 2018-07-20 00:23:50 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-20 00:23:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-20 00:23:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-20 00:23:50 --> Final output sent to browser
DEBUG - 2018-07-20 00:23:50 --> Total execution time: 0.4745
INFO - 2018-07-20 00:24:04 --> Config Class Initialized
INFO - 2018-07-20 00:24:04 --> Hooks Class Initialized
DEBUG - 2018-07-20 00:24:04 --> UTF-8 Support Enabled
INFO - 2018-07-20 00:24:04 --> Utf8 Class Initialized
INFO - 2018-07-20 00:24:04 --> URI Class Initialized
INFO - 2018-07-20 00:24:04 --> Router Class Initialized
INFO - 2018-07-20 00:24:04 --> Output Class Initialized
INFO - 2018-07-20 00:24:04 --> Security Class Initialized
DEBUG - 2018-07-20 00:24:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 00:24:05 --> Input Class Initialized
INFO - 2018-07-20 00:24:05 --> Language Class Initialized
INFO - 2018-07-20 00:24:05 --> Language Class Initialized
INFO - 2018-07-20 00:24:05 --> Config Class Initialized
INFO - 2018-07-20 00:24:05 --> Loader Class Initialized
DEBUG - 2018-07-20 00:24:05 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-20 00:24:05 --> Helper loaded: url_helper
INFO - 2018-07-20 00:24:05 --> Helper loaded: form_helper
INFO - 2018-07-20 00:24:05 --> Helper loaded: date_helper
INFO - 2018-07-20 00:24:05 --> Helper loaded: util_helper
INFO - 2018-07-20 00:24:05 --> Helper loaded: text_helper
INFO - 2018-07-20 00:24:05 --> Helper loaded: string_helper
INFO - 2018-07-20 00:24:05 --> Database Driver Class Initialized
DEBUG - 2018-07-20 00:24:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-20 00:24:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-20 00:24:05 --> Email Class Initialized
INFO - 2018-07-20 00:24:05 --> Controller Class Initialized
DEBUG - 2018-07-20 00:24:05 --> Users MX_Controller Initialized
DEBUG - 2018-07-20 00:24:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-20 00:24:05 --> Helper loaded: file_helper
DEBUG - 2018-07-20 00:24:05 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-20 00:24:05 --> Login MX_Controller Initialized
INFO - 2018-07-20 00:24:05 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-20 00:24:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-20 00:24:05 --> Final output sent to browser
DEBUG - 2018-07-20 00:24:05 --> Total execution time: 0.3639
INFO - 2018-07-20 00:24:10 --> Config Class Initialized
INFO - 2018-07-20 00:24:10 --> Hooks Class Initialized
DEBUG - 2018-07-20 00:24:10 --> UTF-8 Support Enabled
INFO - 2018-07-20 00:24:10 --> Utf8 Class Initialized
INFO - 2018-07-20 00:24:10 --> URI Class Initialized
INFO - 2018-07-20 00:24:10 --> Router Class Initialized
INFO - 2018-07-20 00:24:10 --> Output Class Initialized
INFO - 2018-07-20 00:24:10 --> Security Class Initialized
DEBUG - 2018-07-20 00:24:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 00:24:10 --> Input Class Initialized
INFO - 2018-07-20 00:24:10 --> Language Class Initialized
INFO - 2018-07-20 00:24:10 --> Language Class Initialized
INFO - 2018-07-20 00:24:10 --> Config Class Initialized
INFO - 2018-07-20 00:24:10 --> Loader Class Initialized
DEBUG - 2018-07-20 00:24:10 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-20 00:24:10 --> Helper loaded: url_helper
INFO - 2018-07-20 00:24:10 --> Helper loaded: form_helper
INFO - 2018-07-20 00:24:10 --> Helper loaded: date_helper
INFO - 2018-07-20 00:24:10 --> Helper loaded: util_helper
INFO - 2018-07-20 00:24:10 --> Helper loaded: text_helper
INFO - 2018-07-20 00:24:10 --> Helper loaded: string_helper
INFO - 2018-07-20 00:24:10 --> Database Driver Class Initialized
DEBUG - 2018-07-20 00:24:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-20 00:24:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-20 00:24:10 --> Email Class Initialized
INFO - 2018-07-20 00:24:10 --> Controller Class Initialized
DEBUG - 2018-07-20 00:24:10 --> Users MX_Controller Initialized
DEBUG - 2018-07-20 00:24:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-20 00:24:10 --> Helper loaded: file_helper
DEBUG - 2018-07-20 00:24:10 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-20 00:24:10 --> Login MX_Controller Initialized
INFO - 2018-07-20 00:24:10 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-20 00:24:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-20 00:24:10 --> Final output sent to browser
DEBUG - 2018-07-20 00:24:10 --> Total execution time: 0.3924
INFO - 2018-07-20 00:24:54 --> Config Class Initialized
INFO - 2018-07-20 00:24:54 --> Hooks Class Initialized
DEBUG - 2018-07-20 00:24:54 --> UTF-8 Support Enabled
INFO - 2018-07-20 00:24:54 --> Utf8 Class Initialized
INFO - 2018-07-20 00:24:54 --> URI Class Initialized
INFO - 2018-07-20 00:24:54 --> Router Class Initialized
INFO - 2018-07-20 00:24:54 --> Output Class Initialized
INFO - 2018-07-20 00:24:54 --> Security Class Initialized
DEBUG - 2018-07-20 00:24:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 00:24:54 --> Input Class Initialized
INFO - 2018-07-20 00:24:54 --> Language Class Initialized
INFO - 2018-07-20 00:24:54 --> Language Class Initialized
INFO - 2018-07-20 00:24:54 --> Config Class Initialized
INFO - 2018-07-20 00:24:54 --> Loader Class Initialized
DEBUG - 2018-07-20 00:24:54 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-20 00:24:54 --> Helper loaded: url_helper
INFO - 2018-07-20 00:24:54 --> Helper loaded: form_helper
INFO - 2018-07-20 00:24:54 --> Helper loaded: date_helper
INFO - 2018-07-20 00:24:54 --> Helper loaded: util_helper
INFO - 2018-07-20 00:24:54 --> Helper loaded: text_helper
INFO - 2018-07-20 00:24:54 --> Helper loaded: string_helper
INFO - 2018-07-20 00:24:54 --> Database Driver Class Initialized
DEBUG - 2018-07-20 00:24:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-20 00:24:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-20 00:24:54 --> Email Class Initialized
INFO - 2018-07-20 00:24:54 --> Controller Class Initialized
DEBUG - 2018-07-20 00:24:54 --> Users MX_Controller Initialized
DEBUG - 2018-07-20 00:24:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-20 00:24:54 --> Helper loaded: file_helper
DEBUG - 2018-07-20 00:24:54 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-20 00:24:54 --> Login MX_Controller Initialized
INFO - 2018-07-20 00:24:54 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-20 00:24:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
ERROR - 2018-07-20 00:24:54 --> Severity: Notice --> Undefined variable: info E:\xampp\htdocs\consulting\application\modules\admin\controllers\Users.php 440
INFO - 2018-07-20 00:25:14 --> Config Class Initialized
INFO - 2018-07-20 00:25:14 --> Hooks Class Initialized
DEBUG - 2018-07-20 00:25:14 --> UTF-8 Support Enabled
INFO - 2018-07-20 00:25:14 --> Utf8 Class Initialized
INFO - 2018-07-20 00:25:14 --> URI Class Initialized
INFO - 2018-07-20 00:25:14 --> Router Class Initialized
INFO - 2018-07-20 00:25:14 --> Output Class Initialized
INFO - 2018-07-20 00:25:15 --> Security Class Initialized
DEBUG - 2018-07-20 00:25:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 00:25:15 --> Input Class Initialized
INFO - 2018-07-20 00:25:15 --> Language Class Initialized
INFO - 2018-07-20 00:25:15 --> Language Class Initialized
INFO - 2018-07-20 00:25:15 --> Config Class Initialized
INFO - 2018-07-20 00:25:15 --> Loader Class Initialized
DEBUG - 2018-07-20 00:25:15 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-20 00:25:15 --> Helper loaded: url_helper
INFO - 2018-07-20 00:25:15 --> Helper loaded: form_helper
INFO - 2018-07-20 00:25:15 --> Helper loaded: date_helper
INFO - 2018-07-20 00:25:15 --> Helper loaded: util_helper
INFO - 2018-07-20 00:25:15 --> Helper loaded: text_helper
INFO - 2018-07-20 00:25:15 --> Helper loaded: string_helper
INFO - 2018-07-20 00:25:15 --> Database Driver Class Initialized
DEBUG - 2018-07-20 00:25:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-20 00:25:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-20 00:25:15 --> Email Class Initialized
INFO - 2018-07-20 00:25:15 --> Controller Class Initialized
DEBUG - 2018-07-20 00:25:15 --> Users MX_Controller Initialized
DEBUG - 2018-07-20 00:25:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-20 00:25:15 --> Helper loaded: file_helper
DEBUG - 2018-07-20 00:25:15 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-20 00:25:15 --> Login MX_Controller Initialized
INFO - 2018-07-20 00:25:15 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-20 00:25:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-20 00:27:14 --> Config Class Initialized
INFO - 2018-07-20 00:27:14 --> Hooks Class Initialized
DEBUG - 2018-07-20 00:27:14 --> UTF-8 Support Enabled
INFO - 2018-07-20 00:27:14 --> Utf8 Class Initialized
INFO - 2018-07-20 00:27:14 --> URI Class Initialized
INFO - 2018-07-20 00:27:14 --> Router Class Initialized
INFO - 2018-07-20 00:27:14 --> Output Class Initialized
INFO - 2018-07-20 00:27:14 --> Security Class Initialized
DEBUG - 2018-07-20 00:27:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 00:27:14 --> Input Class Initialized
INFO - 2018-07-20 00:27:14 --> Language Class Initialized
INFO - 2018-07-20 00:27:14 --> Language Class Initialized
INFO - 2018-07-20 00:27:14 --> Config Class Initialized
INFO - 2018-07-20 00:27:14 --> Loader Class Initialized
DEBUG - 2018-07-20 00:27:14 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-20 00:27:14 --> Helper loaded: url_helper
INFO - 2018-07-20 00:27:14 --> Helper loaded: form_helper
INFO - 2018-07-20 00:27:14 --> Helper loaded: date_helper
INFO - 2018-07-20 00:27:14 --> Helper loaded: util_helper
INFO - 2018-07-20 00:27:14 --> Helper loaded: text_helper
INFO - 2018-07-20 00:27:14 --> Helper loaded: string_helper
INFO - 2018-07-20 00:27:14 --> Database Driver Class Initialized
DEBUG - 2018-07-20 00:27:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-20 00:27:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-20 00:27:14 --> Email Class Initialized
INFO - 2018-07-20 00:27:14 --> Controller Class Initialized
DEBUG - 2018-07-20 00:27:14 --> Users MX_Controller Initialized
DEBUG - 2018-07-20 00:27:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-20 00:27:14 --> Helper loaded: file_helper
DEBUG - 2018-07-20 00:27:14 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-20 00:27:14 --> Login MX_Controller Initialized
INFO - 2018-07-20 00:27:14 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-20 00:27:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-20 00:27:44 --> Config Class Initialized
INFO - 2018-07-20 00:27:44 --> Hooks Class Initialized
DEBUG - 2018-07-20 00:27:44 --> UTF-8 Support Enabled
INFO - 2018-07-20 00:27:44 --> Utf8 Class Initialized
INFO - 2018-07-20 00:27:44 --> URI Class Initialized
INFO - 2018-07-20 00:27:44 --> Router Class Initialized
INFO - 2018-07-20 00:27:44 --> Output Class Initialized
INFO - 2018-07-20 00:27:44 --> Security Class Initialized
DEBUG - 2018-07-20 00:27:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 00:27:44 --> Input Class Initialized
INFO - 2018-07-20 00:27:44 --> Language Class Initialized
INFO - 2018-07-20 00:27:44 --> Language Class Initialized
INFO - 2018-07-20 00:27:44 --> Config Class Initialized
INFO - 2018-07-20 00:27:44 --> Loader Class Initialized
DEBUG - 2018-07-20 00:27:44 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-20 00:27:44 --> Helper loaded: url_helper
INFO - 2018-07-20 00:27:44 --> Helper loaded: form_helper
INFO - 2018-07-20 00:27:44 --> Helper loaded: date_helper
INFO - 2018-07-20 00:27:44 --> Helper loaded: util_helper
INFO - 2018-07-20 00:27:44 --> Helper loaded: text_helper
INFO - 2018-07-20 00:27:45 --> Helper loaded: string_helper
INFO - 2018-07-20 00:27:45 --> Database Driver Class Initialized
DEBUG - 2018-07-20 00:27:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-20 00:27:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-20 00:27:45 --> Email Class Initialized
INFO - 2018-07-20 00:27:45 --> Controller Class Initialized
DEBUG - 2018-07-20 00:27:45 --> Users MX_Controller Initialized
DEBUG - 2018-07-20 00:27:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-20 00:27:45 --> Helper loaded: file_helper
DEBUG - 2018-07-20 00:27:45 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-20 00:27:45 --> Login MX_Controller Initialized
INFO - 2018-07-20 00:27:45 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-20 00:27:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-20 00:28:16 --> Config Class Initialized
INFO - 2018-07-20 00:28:16 --> Hooks Class Initialized
DEBUG - 2018-07-20 00:28:16 --> UTF-8 Support Enabled
INFO - 2018-07-20 00:28:16 --> Utf8 Class Initialized
INFO - 2018-07-20 00:28:16 --> URI Class Initialized
INFO - 2018-07-20 00:28:16 --> Router Class Initialized
INFO - 2018-07-20 00:28:16 --> Output Class Initialized
INFO - 2018-07-20 00:28:16 --> Security Class Initialized
DEBUG - 2018-07-20 00:28:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 00:28:16 --> Input Class Initialized
INFO - 2018-07-20 00:28:16 --> Language Class Initialized
INFO - 2018-07-20 00:28:16 --> Language Class Initialized
INFO - 2018-07-20 00:28:16 --> Config Class Initialized
INFO - 2018-07-20 00:28:16 --> Loader Class Initialized
DEBUG - 2018-07-20 00:28:16 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-20 00:28:16 --> Helper loaded: url_helper
INFO - 2018-07-20 00:28:16 --> Helper loaded: form_helper
INFO - 2018-07-20 00:28:16 --> Helper loaded: date_helper
INFO - 2018-07-20 00:28:16 --> Helper loaded: util_helper
INFO - 2018-07-20 00:28:16 --> Helper loaded: text_helper
INFO - 2018-07-20 00:28:16 --> Helper loaded: string_helper
INFO - 2018-07-20 00:28:16 --> Database Driver Class Initialized
DEBUG - 2018-07-20 00:28:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-20 00:28:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-20 00:28:16 --> Email Class Initialized
INFO - 2018-07-20 00:28:17 --> Controller Class Initialized
DEBUG - 2018-07-20 00:28:17 --> Users MX_Controller Initialized
DEBUG - 2018-07-20 00:28:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-20 00:28:17 --> Helper loaded: file_helper
DEBUG - 2018-07-20 00:28:17 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-20 00:28:17 --> Login MX_Controller Initialized
INFO - 2018-07-20 00:28:17 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-20 00:28:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-20 00:28:37 --> Config Class Initialized
INFO - 2018-07-20 00:28:37 --> Hooks Class Initialized
DEBUG - 2018-07-20 00:28:37 --> UTF-8 Support Enabled
INFO - 2018-07-20 00:28:37 --> Utf8 Class Initialized
INFO - 2018-07-20 00:28:37 --> URI Class Initialized
INFO - 2018-07-20 00:28:37 --> Router Class Initialized
INFO - 2018-07-20 00:28:37 --> Output Class Initialized
INFO - 2018-07-20 00:28:37 --> Security Class Initialized
DEBUG - 2018-07-20 00:28:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 00:28:37 --> Input Class Initialized
INFO - 2018-07-20 00:28:37 --> Language Class Initialized
INFO - 2018-07-20 00:28:37 --> Language Class Initialized
INFO - 2018-07-20 00:28:37 --> Config Class Initialized
INFO - 2018-07-20 00:28:37 --> Loader Class Initialized
DEBUG - 2018-07-20 00:28:37 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-20 00:28:37 --> Helper loaded: url_helper
INFO - 2018-07-20 00:28:37 --> Helper loaded: form_helper
INFO - 2018-07-20 00:28:37 --> Helper loaded: date_helper
INFO - 2018-07-20 00:28:37 --> Helper loaded: util_helper
INFO - 2018-07-20 00:28:37 --> Helper loaded: text_helper
INFO - 2018-07-20 00:28:37 --> Helper loaded: string_helper
INFO - 2018-07-20 00:28:37 --> Database Driver Class Initialized
DEBUG - 2018-07-20 00:28:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-20 00:28:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-20 00:28:37 --> Email Class Initialized
INFO - 2018-07-20 00:28:37 --> Controller Class Initialized
DEBUG - 2018-07-20 00:28:37 --> Users MX_Controller Initialized
DEBUG - 2018-07-20 00:28:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-20 00:28:37 --> Helper loaded: file_helper
DEBUG - 2018-07-20 00:28:37 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-20 00:28:37 --> Login MX_Controller Initialized
INFO - 2018-07-20 00:28:37 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-20 00:28:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-20 00:29:02 --> Config Class Initialized
INFO - 2018-07-20 00:29:02 --> Hooks Class Initialized
DEBUG - 2018-07-20 00:29:02 --> UTF-8 Support Enabled
INFO - 2018-07-20 00:29:02 --> Utf8 Class Initialized
INFO - 2018-07-20 00:29:02 --> URI Class Initialized
INFO - 2018-07-20 00:29:02 --> Router Class Initialized
INFO - 2018-07-20 00:29:02 --> Output Class Initialized
INFO - 2018-07-20 00:29:02 --> Security Class Initialized
DEBUG - 2018-07-20 00:29:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 00:29:02 --> Input Class Initialized
INFO - 2018-07-20 00:29:02 --> Language Class Initialized
INFO - 2018-07-20 00:29:02 --> Language Class Initialized
INFO - 2018-07-20 00:29:02 --> Config Class Initialized
INFO - 2018-07-20 00:29:02 --> Loader Class Initialized
DEBUG - 2018-07-20 00:29:02 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-20 00:29:02 --> Helper loaded: url_helper
INFO - 2018-07-20 00:29:02 --> Helper loaded: form_helper
INFO - 2018-07-20 00:29:02 --> Helper loaded: date_helper
INFO - 2018-07-20 00:29:02 --> Helper loaded: util_helper
INFO - 2018-07-20 00:29:02 --> Helper loaded: text_helper
INFO - 2018-07-20 00:29:02 --> Helper loaded: string_helper
INFO - 2018-07-20 00:29:02 --> Database Driver Class Initialized
DEBUG - 2018-07-20 00:29:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-20 00:29:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-20 00:29:02 --> Email Class Initialized
INFO - 2018-07-20 00:29:02 --> Controller Class Initialized
DEBUG - 2018-07-20 00:29:02 --> Users MX_Controller Initialized
DEBUG - 2018-07-20 00:29:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-20 00:29:02 --> Helper loaded: file_helper
DEBUG - 2018-07-20 00:29:02 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-20 00:29:02 --> Login MX_Controller Initialized
INFO - 2018-07-20 00:29:02 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-20 00:29:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
ERROR - 2018-07-20 00:29:02 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable E:\xampp\htdocs\consulting\application\modules\admin\controllers\Users.php 442
INFO - 2018-07-20 00:29:02 --> Final output sent to browser
DEBUG - 2018-07-20 00:29:02 --> Total execution time: 0.3654
INFO - 2018-07-20 00:29:30 --> Config Class Initialized
INFO - 2018-07-20 00:29:30 --> Hooks Class Initialized
DEBUG - 2018-07-20 00:29:30 --> UTF-8 Support Enabled
INFO - 2018-07-20 00:29:30 --> Utf8 Class Initialized
INFO - 2018-07-20 00:29:30 --> URI Class Initialized
INFO - 2018-07-20 00:29:30 --> Router Class Initialized
INFO - 2018-07-20 00:29:30 --> Output Class Initialized
INFO - 2018-07-20 00:29:30 --> Security Class Initialized
DEBUG - 2018-07-20 00:29:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 00:29:30 --> Input Class Initialized
INFO - 2018-07-20 00:29:30 --> Language Class Initialized
INFO - 2018-07-20 00:29:30 --> Language Class Initialized
INFO - 2018-07-20 00:29:30 --> Config Class Initialized
INFO - 2018-07-20 00:29:30 --> Loader Class Initialized
DEBUG - 2018-07-20 00:29:30 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-20 00:29:30 --> Helper loaded: url_helper
INFO - 2018-07-20 00:29:30 --> Helper loaded: form_helper
INFO - 2018-07-20 00:29:30 --> Helper loaded: date_helper
INFO - 2018-07-20 00:29:30 --> Helper loaded: util_helper
INFO - 2018-07-20 00:29:30 --> Helper loaded: text_helper
INFO - 2018-07-20 00:29:30 --> Helper loaded: string_helper
INFO - 2018-07-20 00:29:30 --> Database Driver Class Initialized
DEBUG - 2018-07-20 00:29:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-20 00:29:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-20 00:29:30 --> Email Class Initialized
INFO - 2018-07-20 00:29:30 --> Controller Class Initialized
DEBUG - 2018-07-20 00:29:30 --> Users MX_Controller Initialized
DEBUG - 2018-07-20 00:29:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-20 00:29:30 --> Helper loaded: file_helper
DEBUG - 2018-07-20 00:29:30 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-20 00:29:30 --> Login MX_Controller Initialized
INFO - 2018-07-20 00:29:30 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-20 00:29:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
ERROR - 2018-07-20 00:29:30 --> Severity: error --> Exception: Call to undefined method Common_model::get__list() E:\xampp\htdocs\consulting\application\modules\admin\controllers\Users.php 440
INFO - 2018-07-20 00:29:44 --> Config Class Initialized
INFO - 2018-07-20 00:29:44 --> Hooks Class Initialized
DEBUG - 2018-07-20 00:29:44 --> UTF-8 Support Enabled
INFO - 2018-07-20 00:29:44 --> Utf8 Class Initialized
INFO - 2018-07-20 00:29:44 --> URI Class Initialized
INFO - 2018-07-20 00:29:44 --> Router Class Initialized
INFO - 2018-07-20 00:29:44 --> Output Class Initialized
INFO - 2018-07-20 00:29:44 --> Security Class Initialized
DEBUG - 2018-07-20 00:29:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 00:29:44 --> Input Class Initialized
INFO - 2018-07-20 00:29:44 --> Language Class Initialized
INFO - 2018-07-20 00:29:44 --> Language Class Initialized
INFO - 2018-07-20 00:29:44 --> Config Class Initialized
INFO - 2018-07-20 00:29:44 --> Loader Class Initialized
DEBUG - 2018-07-20 00:29:44 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-20 00:29:44 --> Helper loaded: url_helper
INFO - 2018-07-20 00:29:44 --> Helper loaded: form_helper
INFO - 2018-07-20 00:29:44 --> Helper loaded: date_helper
INFO - 2018-07-20 00:29:44 --> Helper loaded: util_helper
INFO - 2018-07-20 00:29:44 --> Helper loaded: text_helper
INFO - 2018-07-20 00:29:44 --> Helper loaded: string_helper
INFO - 2018-07-20 00:29:44 --> Database Driver Class Initialized
DEBUG - 2018-07-20 00:29:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-20 00:29:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-20 00:29:44 --> Email Class Initialized
INFO - 2018-07-20 00:29:44 --> Controller Class Initialized
DEBUG - 2018-07-20 00:29:44 --> Users MX_Controller Initialized
DEBUG - 2018-07-20 00:29:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-20 00:29:44 --> Helper loaded: file_helper
DEBUG - 2018-07-20 00:29:44 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-20 00:29:44 --> Login MX_Controller Initialized
INFO - 2018-07-20 00:29:44 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-20 00:29:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-20 00:29:44 --> Final output sent to browser
DEBUG - 2018-07-20 00:29:44 --> Total execution time: 0.3542
INFO - 2018-07-20 00:29:48 --> Config Class Initialized
INFO - 2018-07-20 00:29:48 --> Hooks Class Initialized
DEBUG - 2018-07-20 00:29:48 --> UTF-8 Support Enabled
INFO - 2018-07-20 00:29:48 --> Utf8 Class Initialized
INFO - 2018-07-20 00:29:48 --> URI Class Initialized
INFO - 2018-07-20 00:29:48 --> Router Class Initialized
INFO - 2018-07-20 00:29:48 --> Output Class Initialized
INFO - 2018-07-20 00:29:48 --> Security Class Initialized
DEBUG - 2018-07-20 00:29:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 00:29:48 --> Input Class Initialized
INFO - 2018-07-20 00:29:48 --> Language Class Initialized
INFO - 2018-07-20 00:29:48 --> Language Class Initialized
INFO - 2018-07-20 00:29:48 --> Config Class Initialized
INFO - 2018-07-20 00:29:48 --> Loader Class Initialized
DEBUG - 2018-07-20 00:29:48 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-20 00:29:48 --> Helper loaded: url_helper
INFO - 2018-07-20 00:29:48 --> Helper loaded: form_helper
INFO - 2018-07-20 00:29:48 --> Helper loaded: date_helper
INFO - 2018-07-20 00:29:48 --> Helper loaded: util_helper
INFO - 2018-07-20 00:29:48 --> Helper loaded: text_helper
INFO - 2018-07-20 00:29:48 --> Helper loaded: string_helper
INFO - 2018-07-20 00:29:48 --> Database Driver Class Initialized
DEBUG - 2018-07-20 00:29:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-20 00:29:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-20 00:29:48 --> Email Class Initialized
INFO - 2018-07-20 00:29:48 --> Controller Class Initialized
DEBUG - 2018-07-20 00:29:48 --> Users MX_Controller Initialized
DEBUG - 2018-07-20 00:29:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-20 00:29:48 --> Helper loaded: file_helper
DEBUG - 2018-07-20 00:29:48 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-20 00:29:48 --> Login MX_Controller Initialized
INFO - 2018-07-20 00:29:48 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-20 00:29:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-20 00:29:48 --> Final output sent to browser
DEBUG - 2018-07-20 00:29:48 --> Total execution time: 0.3584
INFO - 2018-07-20 02:49:35 --> Config Class Initialized
INFO - 2018-07-20 02:49:35 --> Hooks Class Initialized
DEBUG - 2018-07-20 02:49:35 --> UTF-8 Support Enabled
INFO - 2018-07-20 02:49:35 --> Utf8 Class Initialized
INFO - 2018-07-20 02:49:35 --> URI Class Initialized
INFO - 2018-07-20 02:49:35 --> Router Class Initialized
INFO - 2018-07-20 02:49:35 --> Output Class Initialized
INFO - 2018-07-20 02:49:35 --> Security Class Initialized
DEBUG - 2018-07-20 02:49:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 02:49:35 --> Input Class Initialized
INFO - 2018-07-20 02:49:35 --> Language Class Initialized
INFO - 2018-07-20 02:49:35 --> Language Class Initialized
INFO - 2018-07-20 02:49:35 --> Config Class Initialized
INFO - 2018-07-20 02:49:35 --> Loader Class Initialized
DEBUG - 2018-07-20 02:49:35 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-20 02:49:35 --> Helper loaded: url_helper
INFO - 2018-07-20 02:49:35 --> Helper loaded: form_helper
INFO - 2018-07-20 02:49:35 --> Helper loaded: date_helper
INFO - 2018-07-20 02:49:35 --> Helper loaded: util_helper
INFO - 2018-07-20 02:49:35 --> Helper loaded: text_helper
INFO - 2018-07-20 02:49:36 --> Helper loaded: string_helper
INFO - 2018-07-20 02:49:36 --> Database Driver Class Initialized
DEBUG - 2018-07-20 02:49:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-20 02:49:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-20 02:49:36 --> Email Class Initialized
INFO - 2018-07-20 02:49:36 --> Controller Class Initialized
DEBUG - 2018-07-20 02:49:36 --> Users MX_Controller Initialized
DEBUG - 2018-07-20 02:49:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-20 02:49:36 --> Helper loaded: file_helper
DEBUG - 2018-07-20 02:49:36 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-20 02:49:36 --> Login MX_Controller Initialized
INFO - 2018-07-20 02:49:36 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-20 02:49:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-20 02:49:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
INFO - 2018-07-20 02:49:36 --> Config Class Initialized
INFO - 2018-07-20 02:49:36 --> Hooks Class Initialized
DEBUG - 2018-07-20 02:49:36 --> UTF-8 Support Enabled
INFO - 2018-07-20 02:49:36 --> Utf8 Class Initialized
INFO - 2018-07-20 02:49:36 --> URI Class Initialized
INFO - 2018-07-20 02:49:36 --> Router Class Initialized
INFO - 2018-07-20 02:49:36 --> Output Class Initialized
INFO - 2018-07-20 02:49:36 --> Security Class Initialized
DEBUG - 2018-07-20 02:49:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 02:49:36 --> Input Class Initialized
INFO - 2018-07-20 02:49:36 --> Language Class Initialized
ERROR - 2018-07-20 02:49:36 --> 404 Page Not Found: /index
INFO - 2018-07-20 02:49:39 --> Config Class Initialized
INFO - 2018-07-20 02:49:39 --> Hooks Class Initialized
DEBUG - 2018-07-20 02:49:39 --> UTF-8 Support Enabled
INFO - 2018-07-20 02:49:39 --> Utf8 Class Initialized
INFO - 2018-07-20 02:49:39 --> URI Class Initialized
INFO - 2018-07-20 02:49:39 --> Router Class Initialized
INFO - 2018-07-20 02:49:39 --> Output Class Initialized
INFO - 2018-07-20 02:49:39 --> Security Class Initialized
DEBUG - 2018-07-20 02:49:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 02:49:39 --> Input Class Initialized
INFO - 2018-07-20 02:49:39 --> Language Class Initialized
ERROR - 2018-07-20 02:49:39 --> 404 Page Not Found: /index
INFO - 2018-07-20 02:49:47 --> Config Class Initialized
INFO - 2018-07-20 02:49:47 --> Hooks Class Initialized
DEBUG - 2018-07-20 02:49:47 --> UTF-8 Support Enabled
INFO - 2018-07-20 02:49:47 --> Utf8 Class Initialized
INFO - 2018-07-20 02:49:47 --> URI Class Initialized
INFO - 2018-07-20 02:49:47 --> Router Class Initialized
INFO - 2018-07-20 02:49:47 --> Output Class Initialized
INFO - 2018-07-20 02:49:47 --> Security Class Initialized
DEBUG - 2018-07-20 02:49:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 02:49:47 --> Input Class Initialized
INFO - 2018-07-20 02:49:47 --> Language Class Initialized
INFO - 2018-07-20 02:49:47 --> Language Class Initialized
INFO - 2018-07-20 02:49:47 --> Config Class Initialized
INFO - 2018-07-20 02:49:47 --> Loader Class Initialized
DEBUG - 2018-07-20 02:49:47 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-20 02:49:47 --> Helper loaded: url_helper
INFO - 2018-07-20 02:49:47 --> Helper loaded: form_helper
INFO - 2018-07-20 02:49:47 --> Helper loaded: date_helper
INFO - 2018-07-20 02:49:47 --> Helper loaded: util_helper
INFO - 2018-07-20 02:49:47 --> Helper loaded: text_helper
INFO - 2018-07-20 02:49:47 --> Helper loaded: string_helper
INFO - 2018-07-20 02:49:47 --> Database Driver Class Initialized
DEBUG - 2018-07-20 02:49:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-20 02:49:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-20 02:49:47 --> Email Class Initialized
INFO - 2018-07-20 02:49:47 --> Controller Class Initialized
DEBUG - 2018-07-20 02:49:47 --> Users MX_Controller Initialized
DEBUG - 2018-07-20 02:49:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-20 02:49:47 --> Helper loaded: file_helper
DEBUG - 2018-07-20 02:49:47 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-20 02:49:47 --> Login MX_Controller Initialized
INFO - 2018-07-20 02:49:47 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-20 02:49:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-20 02:49:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
INFO - 2018-07-20 02:49:47 --> Config Class Initialized
INFO - 2018-07-20 02:49:47 --> Hooks Class Initialized
DEBUG - 2018-07-20 02:49:47 --> UTF-8 Support Enabled
INFO - 2018-07-20 02:49:47 --> Utf8 Class Initialized
INFO - 2018-07-20 02:49:47 --> URI Class Initialized
INFO - 2018-07-20 02:49:47 --> Router Class Initialized
INFO - 2018-07-20 02:49:47 --> Output Class Initialized
INFO - 2018-07-20 02:49:47 --> Security Class Initialized
DEBUG - 2018-07-20 02:49:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 02:49:47 --> Input Class Initialized
INFO - 2018-07-20 02:49:47 --> Language Class Initialized
ERROR - 2018-07-20 02:49:47 --> 404 Page Not Found: /index
INFO - 2018-07-20 02:49:53 --> Config Class Initialized
INFO - 2018-07-20 02:49:53 --> Hooks Class Initialized
DEBUG - 2018-07-20 02:49:53 --> UTF-8 Support Enabled
INFO - 2018-07-20 02:49:53 --> Utf8 Class Initialized
INFO - 2018-07-20 02:49:53 --> URI Class Initialized
INFO - 2018-07-20 02:49:53 --> Router Class Initialized
INFO - 2018-07-20 02:49:53 --> Output Class Initialized
INFO - 2018-07-20 02:49:53 --> Security Class Initialized
DEBUG - 2018-07-20 02:49:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 02:49:53 --> Input Class Initialized
INFO - 2018-07-20 02:49:53 --> Language Class Initialized
INFO - 2018-07-20 02:49:53 --> Language Class Initialized
INFO - 2018-07-20 02:49:53 --> Config Class Initialized
INFO - 2018-07-20 02:49:53 --> Loader Class Initialized
DEBUG - 2018-07-20 02:49:53 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-20 02:49:53 --> Helper loaded: url_helper
INFO - 2018-07-20 02:49:53 --> Helper loaded: form_helper
INFO - 2018-07-20 02:49:53 --> Helper loaded: date_helper
INFO - 2018-07-20 02:49:53 --> Helper loaded: util_helper
INFO - 2018-07-20 02:49:53 --> Helper loaded: text_helper
INFO - 2018-07-20 02:49:53 --> Helper loaded: string_helper
INFO - 2018-07-20 02:49:53 --> Database Driver Class Initialized
DEBUG - 2018-07-20 02:49:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-20 02:49:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-20 02:49:53 --> Email Class Initialized
INFO - 2018-07-20 02:49:53 --> Controller Class Initialized
DEBUG - 2018-07-20 02:49:53 --> Login MX_Controller Initialized
INFO - 2018-07-20 02:49:53 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-20 02:49:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-20 02:49:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-20 02:49:54 --> Email starts for admin@colin.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-07-20 02:49:54 --> User session created for 1
INFO - 2018-07-20 02:49:54 --> Login status admin@colin.com - success
INFO - 2018-07-20 02:49:54 --> Final output sent to browser
DEBUG - 2018-07-20 02:49:54 --> Total execution time: 0.3496
INFO - 2018-07-20 02:49:54 --> Config Class Initialized
INFO - 2018-07-20 02:49:54 --> Hooks Class Initialized
DEBUG - 2018-07-20 02:49:54 --> UTF-8 Support Enabled
INFO - 2018-07-20 02:49:54 --> Utf8 Class Initialized
INFO - 2018-07-20 02:49:54 --> URI Class Initialized
INFO - 2018-07-20 02:49:54 --> Router Class Initialized
INFO - 2018-07-20 02:49:54 --> Output Class Initialized
INFO - 2018-07-20 02:49:54 --> Security Class Initialized
DEBUG - 2018-07-20 02:49:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 02:49:54 --> Input Class Initialized
INFO - 2018-07-20 02:49:54 --> Language Class Initialized
INFO - 2018-07-20 02:49:54 --> Language Class Initialized
INFO - 2018-07-20 02:49:54 --> Config Class Initialized
INFO - 2018-07-20 02:49:54 --> Loader Class Initialized
DEBUG - 2018-07-20 02:49:54 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-20 02:49:54 --> Helper loaded: url_helper
INFO - 2018-07-20 02:49:54 --> Helper loaded: form_helper
INFO - 2018-07-20 02:49:54 --> Helper loaded: date_helper
INFO - 2018-07-20 02:49:54 --> Helper loaded: util_helper
INFO - 2018-07-20 02:49:54 --> Helper loaded: text_helper
INFO - 2018-07-20 02:49:54 --> Helper loaded: string_helper
INFO - 2018-07-20 02:49:54 --> Database Driver Class Initialized
DEBUG - 2018-07-20 02:49:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-20 02:49:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-20 02:49:54 --> Email Class Initialized
INFO - 2018-07-20 02:49:54 --> Controller Class Initialized
DEBUG - 2018-07-20 02:49:54 --> Users MX_Controller Initialized
DEBUG - 2018-07-20 02:49:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-20 02:49:54 --> Helper loaded: file_helper
DEBUG - 2018-07-20 02:49:54 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-20 02:49:54 --> Login MX_Controller Initialized
INFO - 2018-07-20 02:49:54 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-20 02:49:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-20 02:49:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-07-20 02:49:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-20 02:49:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-20 02:49:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-20 02:49:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-20 02:49:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-20 02:49:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-07-20 02:49:54 --> Final output sent to browser
DEBUG - 2018-07-20 02:49:54 --> Total execution time: 0.4056
INFO - 2018-07-20 02:49:57 --> Config Class Initialized
INFO - 2018-07-20 02:49:57 --> Hooks Class Initialized
DEBUG - 2018-07-20 02:49:57 --> UTF-8 Support Enabled
INFO - 2018-07-20 02:49:57 --> Utf8 Class Initialized
INFO - 2018-07-20 02:49:57 --> URI Class Initialized
INFO - 2018-07-20 02:49:57 --> Router Class Initialized
INFO - 2018-07-20 02:49:57 --> Output Class Initialized
INFO - 2018-07-20 02:49:57 --> Security Class Initialized
DEBUG - 2018-07-20 02:49:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 02:49:57 --> Input Class Initialized
INFO - 2018-07-20 02:49:57 --> Language Class Initialized
INFO - 2018-07-20 02:49:57 --> Language Class Initialized
INFO - 2018-07-20 02:49:57 --> Config Class Initialized
INFO - 2018-07-20 02:49:57 --> Loader Class Initialized
DEBUG - 2018-07-20 02:49:57 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-20 02:49:57 --> Helper loaded: url_helper
INFO - 2018-07-20 02:49:57 --> Helper loaded: form_helper
INFO - 2018-07-20 02:49:57 --> Helper loaded: date_helper
INFO - 2018-07-20 02:49:57 --> Helper loaded: util_helper
INFO - 2018-07-20 02:49:57 --> Helper loaded: text_helper
INFO - 2018-07-20 02:49:57 --> Helper loaded: string_helper
INFO - 2018-07-20 02:49:57 --> Database Driver Class Initialized
DEBUG - 2018-07-20 02:49:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-20 02:49:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-20 02:49:57 --> Email Class Initialized
INFO - 2018-07-20 02:49:57 --> Controller Class Initialized
DEBUG - 2018-07-20 02:49:57 --> Users MX_Controller Initialized
DEBUG - 2018-07-20 02:49:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-20 02:49:57 --> Helper loaded: file_helper
DEBUG - 2018-07-20 02:49:57 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-20 02:49:57 --> Login MX_Controller Initialized
INFO - 2018-07-20 02:49:57 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-20 02:49:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-20 02:49:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-20 02:49:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-20 02:49:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-20 02:49:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-20 02:49:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-20 02:49:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-07-20 02:49:57 --> Final output sent to browser
DEBUG - 2018-07-20 02:49:57 --> Total execution time: 0.3917
INFO - 2018-07-20 02:49:58 --> Config Class Initialized
INFO - 2018-07-20 02:49:58 --> Hooks Class Initialized
DEBUG - 2018-07-20 02:49:58 --> UTF-8 Support Enabled
INFO - 2018-07-20 02:49:58 --> Utf8 Class Initialized
INFO - 2018-07-20 02:49:58 --> URI Class Initialized
INFO - 2018-07-20 02:49:58 --> Router Class Initialized
INFO - 2018-07-20 02:49:58 --> Output Class Initialized
INFO - 2018-07-20 02:49:58 --> Security Class Initialized
DEBUG - 2018-07-20 02:49:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 02:49:58 --> Input Class Initialized
INFO - 2018-07-20 02:49:58 --> Language Class Initialized
INFO - 2018-07-20 02:49:58 --> Language Class Initialized
INFO - 2018-07-20 02:49:58 --> Config Class Initialized
INFO - 2018-07-20 02:49:58 --> Loader Class Initialized
DEBUG - 2018-07-20 02:49:58 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-20 02:49:58 --> Helper loaded: url_helper
INFO - 2018-07-20 02:49:58 --> Helper loaded: form_helper
INFO - 2018-07-20 02:49:58 --> Helper loaded: date_helper
INFO - 2018-07-20 02:49:58 --> Helper loaded: util_helper
INFO - 2018-07-20 02:49:58 --> Helper loaded: text_helper
INFO - 2018-07-20 02:49:58 --> Helper loaded: string_helper
INFO - 2018-07-20 02:49:58 --> Database Driver Class Initialized
DEBUG - 2018-07-20 02:49:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-20 02:49:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-20 02:49:58 --> Email Class Initialized
INFO - 2018-07-20 02:49:58 --> Controller Class Initialized
DEBUG - 2018-07-20 02:49:58 --> Users MX_Controller Initialized
DEBUG - 2018-07-20 02:49:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-20 02:49:58 --> Helper loaded: file_helper
DEBUG - 2018-07-20 02:49:58 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-20 02:49:58 --> Login MX_Controller Initialized
INFO - 2018-07-20 02:49:58 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-20 02:49:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-20 02:49:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-20 02:49:58 --> Final output sent to browser
DEBUG - 2018-07-20 02:49:58 --> Total execution time: 0.4674
INFO - 2018-07-20 02:50:01 --> Config Class Initialized
INFO - 2018-07-20 02:50:01 --> Hooks Class Initialized
DEBUG - 2018-07-20 02:50:01 --> UTF-8 Support Enabled
INFO - 2018-07-20 02:50:01 --> Utf8 Class Initialized
INFO - 2018-07-20 02:50:01 --> URI Class Initialized
INFO - 2018-07-20 02:50:01 --> Router Class Initialized
INFO - 2018-07-20 02:50:01 --> Output Class Initialized
INFO - 2018-07-20 02:50:01 --> Security Class Initialized
DEBUG - 2018-07-20 02:50:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 02:50:01 --> Input Class Initialized
INFO - 2018-07-20 02:50:01 --> Language Class Initialized
INFO - 2018-07-20 02:50:01 --> Language Class Initialized
INFO - 2018-07-20 02:50:01 --> Config Class Initialized
INFO - 2018-07-20 02:50:01 --> Loader Class Initialized
DEBUG - 2018-07-20 02:50:01 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-20 02:50:01 --> Helper loaded: url_helper
INFO - 2018-07-20 02:50:01 --> Helper loaded: form_helper
INFO - 2018-07-20 02:50:01 --> Helper loaded: date_helper
INFO - 2018-07-20 02:50:01 --> Helper loaded: util_helper
INFO - 2018-07-20 02:50:01 --> Helper loaded: text_helper
INFO - 2018-07-20 02:50:01 --> Helper loaded: string_helper
INFO - 2018-07-20 02:50:01 --> Database Driver Class Initialized
DEBUG - 2018-07-20 02:50:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-20 02:50:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-20 02:50:01 --> Email Class Initialized
INFO - 2018-07-20 02:50:01 --> Controller Class Initialized
DEBUG - 2018-07-20 02:50:01 --> Users MX_Controller Initialized
DEBUG - 2018-07-20 02:50:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-20 02:50:02 --> Helper loaded: file_helper
DEBUG - 2018-07-20 02:50:02 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-20 02:50:02 --> Login MX_Controller Initialized
INFO - 2018-07-20 02:50:02 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-20 02:50:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-20 02:50:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-07-20 02:50:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-20 02:50:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-20 02:50:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-20 02:50:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-20 02:50:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-20 02:50:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-07-20 02:50:02 --> Final output sent to browser
DEBUG - 2018-07-20 02:50:02 --> Total execution time: 0.4247
INFO - 2018-07-20 04:04:20 --> Config Class Initialized
INFO - 2018-07-20 04:04:20 --> Hooks Class Initialized
DEBUG - 2018-07-20 04:04:20 --> UTF-8 Support Enabled
INFO - 2018-07-20 04:04:21 --> Utf8 Class Initialized
INFO - 2018-07-20 04:04:21 --> URI Class Initialized
INFO - 2018-07-20 04:04:21 --> Router Class Initialized
INFO - 2018-07-20 04:04:21 --> Output Class Initialized
INFO - 2018-07-20 04:04:21 --> Security Class Initialized
DEBUG - 2018-07-20 04:04:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 04:04:21 --> Input Class Initialized
INFO - 2018-07-20 04:04:21 --> Language Class Initialized
INFO - 2018-07-20 04:04:21 --> Language Class Initialized
INFO - 2018-07-20 04:04:21 --> Config Class Initialized
INFO - 2018-07-20 04:04:21 --> Loader Class Initialized
DEBUG - 2018-07-20 04:04:21 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-20 04:04:21 --> Helper loaded: url_helper
INFO - 2018-07-20 04:04:21 --> Helper loaded: form_helper
INFO - 2018-07-20 04:04:21 --> Helper loaded: date_helper
INFO - 2018-07-20 04:04:21 --> Helper loaded: util_helper
INFO - 2018-07-20 04:04:21 --> Helper loaded: text_helper
INFO - 2018-07-20 04:04:21 --> Helper loaded: string_helper
INFO - 2018-07-20 04:04:21 --> Database Driver Class Initialized
DEBUG - 2018-07-20 04:04:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-20 04:04:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-20 04:04:21 --> Email Class Initialized
INFO - 2018-07-20 04:04:21 --> Controller Class Initialized
DEBUG - 2018-07-20 04:04:21 --> Users MX_Controller Initialized
DEBUG - 2018-07-20 04:04:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-20 04:04:21 --> Helper loaded: file_helper
DEBUG - 2018-07-20 04:04:21 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-20 04:04:21 --> Login MX_Controller Initialized
INFO - 2018-07-20 04:04:21 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-20 04:04:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-20 04:04:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-07-20 04:04:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-20 04:04:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-20 04:04:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-20 04:04:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-20 04:04:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-20 04:04:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-07-20 04:04:21 --> Final output sent to browser
DEBUG - 2018-07-20 04:04:21 --> Total execution time: 0.4094
INFO - 2018-07-20 04:05:30 --> Config Class Initialized
INFO - 2018-07-20 04:05:30 --> Hooks Class Initialized
DEBUG - 2018-07-20 04:05:30 --> UTF-8 Support Enabled
INFO - 2018-07-20 04:05:30 --> Utf8 Class Initialized
INFO - 2018-07-20 04:05:30 --> URI Class Initialized
INFO - 2018-07-20 04:05:30 --> Router Class Initialized
INFO - 2018-07-20 04:05:30 --> Output Class Initialized
INFO - 2018-07-20 04:05:30 --> Security Class Initialized
DEBUG - 2018-07-20 04:05:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 04:05:30 --> Input Class Initialized
INFO - 2018-07-20 04:05:30 --> Language Class Initialized
INFO - 2018-07-20 04:05:30 --> Language Class Initialized
INFO - 2018-07-20 04:05:30 --> Config Class Initialized
INFO - 2018-07-20 04:05:30 --> Loader Class Initialized
DEBUG - 2018-07-20 04:05:30 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-20 04:05:30 --> Helper loaded: url_helper
INFO - 2018-07-20 04:05:30 --> Helper loaded: form_helper
INFO - 2018-07-20 04:05:30 --> Helper loaded: date_helper
INFO - 2018-07-20 04:05:30 --> Helper loaded: util_helper
INFO - 2018-07-20 04:05:30 --> Helper loaded: text_helper
INFO - 2018-07-20 04:05:30 --> Helper loaded: string_helper
INFO - 2018-07-20 04:05:30 --> Database Driver Class Initialized
DEBUG - 2018-07-20 04:05:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-20 04:05:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-20 04:05:30 --> Email Class Initialized
INFO - 2018-07-20 04:05:30 --> Controller Class Initialized
DEBUG - 2018-07-20 04:05:30 --> Programs MX_Controller Initialized
INFO - 2018-07-20 04:05:30 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-20 04:05:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-20 04:05:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-20 04:05:30 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-20 04:05:30 --> Login MX_Controller Initialized
DEBUG - 2018-07-20 04:05:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-20 04:05:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-20 04:05:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-20 04:05:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-20 04:05:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-20 04:05:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-20 04:05:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/programs.php
INFO - 2018-07-20 04:05:30 --> Final output sent to browser
DEBUG - 2018-07-20 04:05:30 --> Total execution time: 0.4898
INFO - 2018-07-20 04:05:31 --> Config Class Initialized
INFO - 2018-07-20 04:05:31 --> Hooks Class Initialized
DEBUG - 2018-07-20 04:05:31 --> UTF-8 Support Enabled
INFO - 2018-07-20 04:05:31 --> Utf8 Class Initialized
INFO - 2018-07-20 04:05:31 --> URI Class Initialized
INFO - 2018-07-20 04:05:31 --> Router Class Initialized
INFO - 2018-07-20 04:05:31 --> Output Class Initialized
INFO - 2018-07-20 04:05:31 --> Security Class Initialized
DEBUG - 2018-07-20 04:05:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 04:05:31 --> Input Class Initialized
INFO - 2018-07-20 04:05:31 --> Language Class Initialized
INFO - 2018-07-20 04:05:31 --> Language Class Initialized
INFO - 2018-07-20 04:05:31 --> Config Class Initialized
INFO - 2018-07-20 04:05:31 --> Loader Class Initialized
DEBUG - 2018-07-20 04:05:31 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-20 04:05:31 --> Helper loaded: url_helper
INFO - 2018-07-20 04:05:31 --> Helper loaded: form_helper
INFO - 2018-07-20 04:05:31 --> Helper loaded: date_helper
INFO - 2018-07-20 04:05:31 --> Helper loaded: util_helper
INFO - 2018-07-20 04:05:31 --> Helper loaded: text_helper
INFO - 2018-07-20 04:05:31 --> Helper loaded: string_helper
INFO - 2018-07-20 04:05:31 --> Database Driver Class Initialized
DEBUG - 2018-07-20 04:05:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-20 04:05:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-20 04:05:31 --> Email Class Initialized
INFO - 2018-07-20 04:05:31 --> Controller Class Initialized
DEBUG - 2018-07-20 04:05:31 --> Programs MX_Controller Initialized
INFO - 2018-07-20 04:05:31 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-20 04:05:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-20 04:05:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-20 04:05:31 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-20 04:05:31 --> Login MX_Controller Initialized
DEBUG - 2018-07-20 04:05:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-20 04:05:31 --> Final output sent to browser
DEBUG - 2018-07-20 04:05:31 --> Total execution time: 0.4821
INFO - 2018-07-20 04:12:49 --> Config Class Initialized
INFO - 2018-07-20 04:12:49 --> Hooks Class Initialized
DEBUG - 2018-07-20 04:12:49 --> UTF-8 Support Enabled
INFO - 2018-07-20 04:12:49 --> Utf8 Class Initialized
INFO - 2018-07-20 04:12:49 --> URI Class Initialized
INFO - 2018-07-20 04:12:49 --> Router Class Initialized
INFO - 2018-07-20 04:12:49 --> Output Class Initialized
INFO - 2018-07-20 04:12:49 --> Security Class Initialized
DEBUG - 2018-07-20 04:12:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 04:12:49 --> Input Class Initialized
INFO - 2018-07-20 04:12:49 --> Language Class Initialized
INFO - 2018-07-20 04:12:49 --> Language Class Initialized
INFO - 2018-07-20 04:12:49 --> Config Class Initialized
INFO - 2018-07-20 04:12:49 --> Loader Class Initialized
DEBUG - 2018-07-20 04:12:49 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-20 04:12:49 --> Helper loaded: url_helper
INFO - 2018-07-20 04:12:49 --> Helper loaded: form_helper
INFO - 2018-07-20 04:12:49 --> Helper loaded: date_helper
INFO - 2018-07-20 04:12:49 --> Helper loaded: util_helper
INFO - 2018-07-20 04:12:49 --> Helper loaded: text_helper
INFO - 2018-07-20 04:12:49 --> Helper loaded: string_helper
INFO - 2018-07-20 04:12:49 --> Database Driver Class Initialized
DEBUG - 2018-07-20 04:12:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-20 04:12:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-20 04:12:49 --> Email Class Initialized
INFO - 2018-07-20 04:12:49 --> Controller Class Initialized
DEBUG - 2018-07-20 04:12:49 --> Users MX_Controller Initialized
DEBUG - 2018-07-20 04:12:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-20 04:12:49 --> Helper loaded: file_helper
DEBUG - 2018-07-20 04:12:49 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-20 04:12:49 --> Login MX_Controller Initialized
INFO - 2018-07-20 04:12:49 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-20 04:12:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-20 04:12:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-07-20 04:12:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-20 04:12:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-20 04:12:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-20 04:12:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-20 04:12:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-20 04:12:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-07-20 04:12:49 --> Final output sent to browser
DEBUG - 2018-07-20 04:12:49 --> Total execution time: 0.5008
INFO - 2018-07-20 04:40:30 --> Config Class Initialized
INFO - 2018-07-20 04:40:30 --> Hooks Class Initialized
DEBUG - 2018-07-20 04:40:30 --> UTF-8 Support Enabled
INFO - 2018-07-20 04:40:30 --> Utf8 Class Initialized
INFO - 2018-07-20 04:40:30 --> URI Class Initialized
INFO - 2018-07-20 04:40:30 --> Router Class Initialized
INFO - 2018-07-20 04:40:30 --> Output Class Initialized
INFO - 2018-07-20 04:40:30 --> Security Class Initialized
DEBUG - 2018-07-20 04:40:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 04:40:30 --> Input Class Initialized
INFO - 2018-07-20 04:40:30 --> Language Class Initialized
INFO - 2018-07-20 04:40:30 --> Language Class Initialized
INFO - 2018-07-20 04:40:30 --> Config Class Initialized
INFO - 2018-07-20 04:40:30 --> Loader Class Initialized
DEBUG - 2018-07-20 04:40:30 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-20 04:40:30 --> Helper loaded: url_helper
INFO - 2018-07-20 04:40:30 --> Helper loaded: form_helper
INFO - 2018-07-20 04:40:30 --> Helper loaded: date_helper
INFO - 2018-07-20 04:40:30 --> Helper loaded: util_helper
INFO - 2018-07-20 04:40:30 --> Helper loaded: text_helper
INFO - 2018-07-20 04:40:30 --> Helper loaded: string_helper
INFO - 2018-07-20 04:40:30 --> Database Driver Class Initialized
DEBUG - 2018-07-20 04:40:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-20 04:40:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-20 04:40:30 --> Email Class Initialized
INFO - 2018-07-20 04:40:30 --> Controller Class Initialized
DEBUG - 2018-07-20 04:40:30 --> Users MX_Controller Initialized
DEBUG - 2018-07-20 04:40:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-20 04:40:30 --> Helper loaded: file_helper
DEBUG - 2018-07-20 04:40:31 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-20 04:40:31 --> Login MX_Controller Initialized
INFO - 2018-07-20 04:40:31 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-20 04:40:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-20 04:40:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-07-20 04:40:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-20 04:40:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-20 04:40:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-20 04:40:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-20 04:40:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-20 04:40:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-07-20 04:40:31 --> Final output sent to browser
DEBUG - 2018-07-20 04:40:31 --> Total execution time: 0.4215
INFO - 2018-07-20 04:40:41 --> Config Class Initialized
INFO - 2018-07-20 04:40:41 --> Hooks Class Initialized
DEBUG - 2018-07-20 04:40:41 --> UTF-8 Support Enabled
INFO - 2018-07-20 04:40:41 --> Utf8 Class Initialized
INFO - 2018-07-20 04:40:42 --> URI Class Initialized
INFO - 2018-07-20 04:40:42 --> Router Class Initialized
INFO - 2018-07-20 04:40:42 --> Output Class Initialized
INFO - 2018-07-20 04:40:42 --> Security Class Initialized
DEBUG - 2018-07-20 04:40:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 04:40:42 --> Input Class Initialized
INFO - 2018-07-20 04:40:42 --> Language Class Initialized
INFO - 2018-07-20 04:40:42 --> Language Class Initialized
INFO - 2018-07-20 04:40:42 --> Config Class Initialized
INFO - 2018-07-20 04:40:42 --> Loader Class Initialized
DEBUG - 2018-07-20 04:40:42 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-20 04:40:42 --> Helper loaded: url_helper
INFO - 2018-07-20 04:40:42 --> Helper loaded: form_helper
INFO - 2018-07-20 04:40:42 --> Helper loaded: date_helper
INFO - 2018-07-20 04:40:42 --> Helper loaded: util_helper
INFO - 2018-07-20 04:40:42 --> Helper loaded: text_helper
INFO - 2018-07-20 04:40:42 --> Helper loaded: string_helper
INFO - 2018-07-20 04:40:42 --> Database Driver Class Initialized
DEBUG - 2018-07-20 04:40:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-20 04:40:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-20 04:40:42 --> Email Class Initialized
INFO - 2018-07-20 04:40:42 --> Controller Class Initialized
DEBUG - 2018-07-20 04:40:42 --> Users MX_Controller Initialized
DEBUG - 2018-07-20 04:40:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-20 04:40:42 --> Helper loaded: file_helper
DEBUG - 2018-07-20 04:40:42 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-20 04:40:42 --> Login MX_Controller Initialized
INFO - 2018-07-20 04:40:42 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-20 04:40:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-20 04:40:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-07-20 04:40:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-20 04:40:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-20 04:40:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-20 04:40:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-20 04:40:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-20 04:40:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-07-20 04:40:42 --> Final output sent to browser
DEBUG - 2018-07-20 04:40:42 --> Total execution time: 0.4169
INFO - 2018-07-20 04:40:56 --> Config Class Initialized
INFO - 2018-07-20 04:40:56 --> Hooks Class Initialized
DEBUG - 2018-07-20 04:40:56 --> UTF-8 Support Enabled
INFO - 2018-07-20 04:40:56 --> Utf8 Class Initialized
INFO - 2018-07-20 04:40:56 --> URI Class Initialized
INFO - 2018-07-20 04:40:56 --> Router Class Initialized
INFO - 2018-07-20 04:40:56 --> Output Class Initialized
INFO - 2018-07-20 04:40:56 --> Security Class Initialized
DEBUG - 2018-07-20 04:40:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 04:40:56 --> Input Class Initialized
INFO - 2018-07-20 04:40:56 --> Language Class Initialized
INFO - 2018-07-20 04:40:56 --> Language Class Initialized
INFO - 2018-07-20 04:40:56 --> Config Class Initialized
INFO - 2018-07-20 04:40:56 --> Loader Class Initialized
DEBUG - 2018-07-20 04:40:56 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-20 04:40:56 --> Helper loaded: url_helper
INFO - 2018-07-20 04:40:56 --> Helper loaded: form_helper
INFO - 2018-07-20 04:40:56 --> Helper loaded: date_helper
INFO - 2018-07-20 04:40:56 --> Helper loaded: util_helper
INFO - 2018-07-20 04:40:56 --> Helper loaded: text_helper
INFO - 2018-07-20 04:40:56 --> Helper loaded: string_helper
INFO - 2018-07-20 04:40:56 --> Database Driver Class Initialized
DEBUG - 2018-07-20 04:40:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-20 04:40:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-20 04:40:56 --> Email Class Initialized
INFO - 2018-07-20 04:40:56 --> Controller Class Initialized
DEBUG - 2018-07-20 04:40:56 --> Users MX_Controller Initialized
DEBUG - 2018-07-20 04:40:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-20 04:40:56 --> Helper loaded: file_helper
DEBUG - 2018-07-20 04:40:56 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-20 04:40:56 --> Login MX_Controller Initialized
INFO - 2018-07-20 04:40:56 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-20 04:40:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-20 04:40:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-07-20 04:40:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-20 04:40:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-20 04:40:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-20 04:40:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-20 04:40:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-20 04:40:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-07-20 04:40:56 --> Final output sent to browser
DEBUG - 2018-07-20 04:40:56 --> Total execution time: 0.4323
INFO - 2018-07-20 04:41:13 --> Config Class Initialized
INFO - 2018-07-20 04:41:13 --> Hooks Class Initialized
DEBUG - 2018-07-20 04:41:13 --> UTF-8 Support Enabled
INFO - 2018-07-20 04:41:13 --> Utf8 Class Initialized
INFO - 2018-07-20 04:41:13 --> URI Class Initialized
INFO - 2018-07-20 04:41:13 --> Router Class Initialized
INFO - 2018-07-20 04:41:13 --> Output Class Initialized
INFO - 2018-07-20 04:41:13 --> Security Class Initialized
DEBUG - 2018-07-20 04:41:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 04:41:14 --> Input Class Initialized
INFO - 2018-07-20 04:41:14 --> Language Class Initialized
INFO - 2018-07-20 04:41:14 --> Language Class Initialized
INFO - 2018-07-20 04:41:14 --> Config Class Initialized
INFO - 2018-07-20 04:41:14 --> Loader Class Initialized
DEBUG - 2018-07-20 04:41:14 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-20 04:41:14 --> Helper loaded: url_helper
INFO - 2018-07-20 04:41:14 --> Helper loaded: form_helper
INFO - 2018-07-20 04:41:14 --> Helper loaded: date_helper
INFO - 2018-07-20 04:41:14 --> Helper loaded: util_helper
INFO - 2018-07-20 04:41:14 --> Helper loaded: text_helper
INFO - 2018-07-20 04:41:14 --> Helper loaded: string_helper
INFO - 2018-07-20 04:41:14 --> Database Driver Class Initialized
DEBUG - 2018-07-20 04:41:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-20 04:41:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-20 04:41:14 --> Email Class Initialized
INFO - 2018-07-20 04:41:14 --> Controller Class Initialized
DEBUG - 2018-07-20 04:41:14 --> Users MX_Controller Initialized
DEBUG - 2018-07-20 04:41:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-20 04:41:14 --> Helper loaded: file_helper
DEBUG - 2018-07-20 04:41:14 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-20 04:41:14 --> Login MX_Controller Initialized
INFO - 2018-07-20 04:41:14 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-20 04:41:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-20 04:41:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-07-20 04:41:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-20 04:41:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-20 04:41:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-20 04:41:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-20 04:41:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-20 04:41:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-07-20 04:41:14 --> Final output sent to browser
DEBUG - 2018-07-20 04:41:14 --> Total execution time: 0.4253
INFO - 2018-07-20 04:42:35 --> Config Class Initialized
INFO - 2018-07-20 04:42:35 --> Hooks Class Initialized
DEBUG - 2018-07-20 04:42:35 --> UTF-8 Support Enabled
INFO - 2018-07-20 04:42:35 --> Utf8 Class Initialized
INFO - 2018-07-20 04:42:35 --> URI Class Initialized
INFO - 2018-07-20 04:42:35 --> Router Class Initialized
INFO - 2018-07-20 04:42:36 --> Output Class Initialized
INFO - 2018-07-20 04:42:36 --> Security Class Initialized
DEBUG - 2018-07-20 04:42:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 04:42:36 --> Input Class Initialized
INFO - 2018-07-20 04:42:36 --> Language Class Initialized
INFO - 2018-07-20 04:42:36 --> Language Class Initialized
INFO - 2018-07-20 04:42:36 --> Config Class Initialized
INFO - 2018-07-20 04:42:36 --> Loader Class Initialized
DEBUG - 2018-07-20 04:42:36 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-20 04:42:36 --> Helper loaded: url_helper
INFO - 2018-07-20 04:42:36 --> Helper loaded: form_helper
INFO - 2018-07-20 04:42:36 --> Helper loaded: date_helper
INFO - 2018-07-20 04:42:36 --> Helper loaded: util_helper
INFO - 2018-07-20 04:42:36 --> Helper loaded: text_helper
INFO - 2018-07-20 04:42:36 --> Helper loaded: string_helper
INFO - 2018-07-20 04:42:36 --> Database Driver Class Initialized
DEBUG - 2018-07-20 04:42:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-20 04:42:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-20 04:42:36 --> Email Class Initialized
INFO - 2018-07-20 04:42:36 --> Controller Class Initialized
DEBUG - 2018-07-20 04:42:36 --> Users MX_Controller Initialized
DEBUG - 2018-07-20 04:42:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-20 04:42:36 --> Helper loaded: file_helper
DEBUG - 2018-07-20 04:42:36 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-20 04:42:36 --> Login MX_Controller Initialized
INFO - 2018-07-20 04:42:36 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-20 04:42:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-20 04:42:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-07-20 04:42:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-20 04:42:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-20 04:42:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-20 04:42:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-20 04:42:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-20 04:42:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-07-20 04:42:36 --> Final output sent to browser
DEBUG - 2018-07-20 04:42:36 --> Total execution time: 0.5254
INFO - 2018-07-20 04:42:39 --> Config Class Initialized
INFO - 2018-07-20 04:42:39 --> Hooks Class Initialized
DEBUG - 2018-07-20 04:42:39 --> UTF-8 Support Enabled
INFO - 2018-07-20 04:42:40 --> Utf8 Class Initialized
INFO - 2018-07-20 04:42:40 --> URI Class Initialized
INFO - 2018-07-20 04:42:40 --> Router Class Initialized
INFO - 2018-07-20 04:42:40 --> Output Class Initialized
INFO - 2018-07-20 04:42:40 --> Security Class Initialized
DEBUG - 2018-07-20 04:42:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 04:42:40 --> Input Class Initialized
INFO - 2018-07-20 04:42:40 --> Language Class Initialized
ERROR - 2018-07-20 04:42:40 --> 404 Page Not Found: /index
INFO - 2018-07-20 04:44:58 --> Config Class Initialized
INFO - 2018-07-20 04:44:58 --> Hooks Class Initialized
DEBUG - 2018-07-20 04:44:58 --> UTF-8 Support Enabled
INFO - 2018-07-20 04:44:58 --> Utf8 Class Initialized
INFO - 2018-07-20 04:44:58 --> URI Class Initialized
INFO - 2018-07-20 04:44:58 --> Router Class Initialized
INFO - 2018-07-20 04:44:58 --> Output Class Initialized
INFO - 2018-07-20 04:44:58 --> Security Class Initialized
DEBUG - 2018-07-20 04:44:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 04:44:58 --> Input Class Initialized
INFO - 2018-07-20 04:44:58 --> Language Class Initialized
INFO - 2018-07-20 04:44:58 --> Language Class Initialized
INFO - 2018-07-20 04:44:58 --> Config Class Initialized
INFO - 2018-07-20 04:44:58 --> Loader Class Initialized
DEBUG - 2018-07-20 04:44:58 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-20 04:44:58 --> Helper loaded: url_helper
INFO - 2018-07-20 04:44:58 --> Helper loaded: form_helper
INFO - 2018-07-20 04:44:58 --> Helper loaded: date_helper
INFO - 2018-07-20 04:44:58 --> Helper loaded: util_helper
INFO - 2018-07-20 04:44:58 --> Helper loaded: text_helper
INFO - 2018-07-20 04:44:58 --> Helper loaded: string_helper
INFO - 2018-07-20 04:44:58 --> Database Driver Class Initialized
DEBUG - 2018-07-20 04:44:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-20 04:44:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-20 04:44:58 --> Email Class Initialized
INFO - 2018-07-20 04:44:58 --> Controller Class Initialized
DEBUG - 2018-07-20 04:44:58 --> Users MX_Controller Initialized
DEBUG - 2018-07-20 04:44:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-20 04:44:58 --> Helper loaded: file_helper
DEBUG - 2018-07-20 04:44:58 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-20 04:44:58 --> Login MX_Controller Initialized
INFO - 2018-07-20 04:44:58 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-20 04:44:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-20 04:44:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-07-20 04:44:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-20 04:44:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-20 04:44:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-20 04:44:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-20 04:44:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-20 04:44:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-07-20 04:44:59 --> Final output sent to browser
DEBUG - 2018-07-20 04:44:59 --> Total execution time: 0.4249
INFO - 2018-07-20 04:45:28 --> Config Class Initialized
INFO - 2018-07-20 04:45:28 --> Hooks Class Initialized
DEBUG - 2018-07-20 04:45:28 --> UTF-8 Support Enabled
INFO - 2018-07-20 04:45:28 --> Utf8 Class Initialized
INFO - 2018-07-20 04:45:28 --> URI Class Initialized
INFO - 2018-07-20 04:45:28 --> Router Class Initialized
INFO - 2018-07-20 04:45:28 --> Output Class Initialized
INFO - 2018-07-20 04:45:28 --> Security Class Initialized
DEBUG - 2018-07-20 04:45:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 04:45:28 --> Input Class Initialized
INFO - 2018-07-20 04:45:28 --> Language Class Initialized
INFO - 2018-07-20 04:45:28 --> Language Class Initialized
INFO - 2018-07-20 04:45:28 --> Config Class Initialized
INFO - 2018-07-20 04:45:28 --> Loader Class Initialized
DEBUG - 2018-07-20 04:45:28 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-20 04:45:28 --> Helper loaded: url_helper
INFO - 2018-07-20 04:45:28 --> Helper loaded: form_helper
INFO - 2018-07-20 04:45:28 --> Helper loaded: date_helper
INFO - 2018-07-20 04:45:28 --> Helper loaded: util_helper
INFO - 2018-07-20 04:45:28 --> Helper loaded: text_helper
INFO - 2018-07-20 04:45:28 --> Helper loaded: string_helper
INFO - 2018-07-20 04:45:28 --> Database Driver Class Initialized
DEBUG - 2018-07-20 04:45:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-20 04:45:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-20 04:45:28 --> Email Class Initialized
INFO - 2018-07-20 04:45:28 --> Controller Class Initialized
DEBUG - 2018-07-20 04:45:28 --> Users MX_Controller Initialized
DEBUG - 2018-07-20 04:45:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-20 04:45:28 --> Helper loaded: file_helper
DEBUG - 2018-07-20 04:45:28 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-20 04:45:28 --> Login MX_Controller Initialized
INFO - 2018-07-20 04:45:28 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-20 04:45:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-20 04:45:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-07-20 04:45:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-20 04:45:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-20 04:45:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-20 04:45:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-20 04:45:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-20 04:45:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-07-20 04:45:28 --> Final output sent to browser
DEBUG - 2018-07-20 04:45:28 --> Total execution time: 0.4274
INFO - 2018-07-20 04:45:54 --> Config Class Initialized
INFO - 2018-07-20 04:45:54 --> Hooks Class Initialized
DEBUG - 2018-07-20 04:45:54 --> UTF-8 Support Enabled
INFO - 2018-07-20 04:45:54 --> Utf8 Class Initialized
INFO - 2018-07-20 04:45:54 --> URI Class Initialized
INFO - 2018-07-20 04:45:54 --> Router Class Initialized
INFO - 2018-07-20 04:45:54 --> Output Class Initialized
INFO - 2018-07-20 04:45:54 --> Security Class Initialized
DEBUG - 2018-07-20 04:45:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 04:45:54 --> Input Class Initialized
INFO - 2018-07-20 04:45:54 --> Language Class Initialized
INFO - 2018-07-20 04:45:54 --> Language Class Initialized
INFO - 2018-07-20 04:45:54 --> Config Class Initialized
INFO - 2018-07-20 04:45:54 --> Loader Class Initialized
DEBUG - 2018-07-20 04:45:54 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-20 04:45:54 --> Helper loaded: url_helper
INFO - 2018-07-20 04:45:55 --> Helper loaded: form_helper
INFO - 2018-07-20 04:45:55 --> Helper loaded: date_helper
INFO - 2018-07-20 04:45:55 --> Helper loaded: util_helper
INFO - 2018-07-20 04:45:55 --> Helper loaded: text_helper
INFO - 2018-07-20 04:45:55 --> Helper loaded: string_helper
INFO - 2018-07-20 04:45:55 --> Database Driver Class Initialized
DEBUG - 2018-07-20 04:45:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-20 04:45:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-20 04:45:55 --> Email Class Initialized
INFO - 2018-07-20 04:45:55 --> Controller Class Initialized
DEBUG - 2018-07-20 04:45:55 --> Users MX_Controller Initialized
DEBUG - 2018-07-20 04:45:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-20 04:45:55 --> Helper loaded: file_helper
DEBUG - 2018-07-20 04:45:55 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-20 04:45:55 --> Login MX_Controller Initialized
INFO - 2018-07-20 04:45:55 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-20 04:45:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-20 04:45:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-07-20 04:45:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-20 04:45:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-20 04:45:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-20 04:45:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-20 04:45:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-20 04:45:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-07-20 04:45:55 --> Final output sent to browser
DEBUG - 2018-07-20 04:45:55 --> Total execution time: 0.4309
INFO - 2018-07-20 04:46:22 --> Config Class Initialized
INFO - 2018-07-20 04:46:22 --> Hooks Class Initialized
DEBUG - 2018-07-20 04:46:22 --> UTF-8 Support Enabled
INFO - 2018-07-20 04:46:22 --> Utf8 Class Initialized
INFO - 2018-07-20 04:46:22 --> URI Class Initialized
INFO - 2018-07-20 04:46:22 --> Router Class Initialized
INFO - 2018-07-20 04:46:22 --> Output Class Initialized
INFO - 2018-07-20 04:46:22 --> Security Class Initialized
DEBUG - 2018-07-20 04:46:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 04:46:22 --> Input Class Initialized
INFO - 2018-07-20 04:46:22 --> Language Class Initialized
INFO - 2018-07-20 04:46:22 --> Language Class Initialized
INFO - 2018-07-20 04:46:22 --> Config Class Initialized
INFO - 2018-07-20 04:46:22 --> Loader Class Initialized
DEBUG - 2018-07-20 04:46:22 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-20 04:46:22 --> Helper loaded: url_helper
INFO - 2018-07-20 04:46:22 --> Helper loaded: form_helper
INFO - 2018-07-20 04:46:22 --> Helper loaded: date_helper
INFO - 2018-07-20 04:46:23 --> Helper loaded: util_helper
INFO - 2018-07-20 04:46:23 --> Helper loaded: text_helper
INFO - 2018-07-20 04:46:23 --> Helper loaded: string_helper
INFO - 2018-07-20 04:46:23 --> Database Driver Class Initialized
DEBUG - 2018-07-20 04:46:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-20 04:46:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-20 04:46:23 --> Email Class Initialized
INFO - 2018-07-20 04:46:23 --> Controller Class Initialized
DEBUG - 2018-07-20 04:46:23 --> Users MX_Controller Initialized
DEBUG - 2018-07-20 04:46:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-20 04:46:23 --> Helper loaded: file_helper
DEBUG - 2018-07-20 04:46:23 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-20 04:46:23 --> Login MX_Controller Initialized
INFO - 2018-07-20 04:46:23 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-20 04:46:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-20 04:46:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-07-20 04:46:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-20 04:46:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-20 04:46:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-20 04:46:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-20 04:46:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-20 04:46:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-07-20 04:46:23 --> Final output sent to browser
DEBUG - 2018-07-20 04:46:23 --> Total execution time: 0.4433
INFO - 2018-07-20 05:48:38 --> Config Class Initialized
INFO - 2018-07-20 05:48:38 --> Hooks Class Initialized
DEBUG - 2018-07-20 05:48:38 --> UTF-8 Support Enabled
INFO - 2018-07-20 05:48:38 --> Utf8 Class Initialized
INFO - 2018-07-20 05:48:38 --> URI Class Initialized
INFO - 2018-07-20 05:48:38 --> Router Class Initialized
INFO - 2018-07-20 05:48:38 --> Output Class Initialized
INFO - 2018-07-20 05:48:38 --> Security Class Initialized
DEBUG - 2018-07-20 05:48:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 05:48:38 --> Input Class Initialized
INFO - 2018-07-20 05:48:38 --> Language Class Initialized
ERROR - 2018-07-20 05:48:38 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ',' or ')' E:\xampp\htdocs\consulting\application\modules\admin\controllers\Users.php 93
INFO - 2018-07-20 05:49:01 --> Config Class Initialized
INFO - 2018-07-20 05:49:01 --> Hooks Class Initialized
DEBUG - 2018-07-20 05:49:01 --> UTF-8 Support Enabled
INFO - 2018-07-20 05:49:02 --> Utf8 Class Initialized
INFO - 2018-07-20 05:49:02 --> URI Class Initialized
INFO - 2018-07-20 05:49:02 --> Router Class Initialized
INFO - 2018-07-20 05:49:02 --> Output Class Initialized
INFO - 2018-07-20 05:49:02 --> Security Class Initialized
DEBUG - 2018-07-20 05:49:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 05:49:02 --> Input Class Initialized
INFO - 2018-07-20 05:49:02 --> Language Class Initialized
INFO - 2018-07-20 05:49:02 --> Language Class Initialized
INFO - 2018-07-20 05:49:02 --> Config Class Initialized
INFO - 2018-07-20 05:49:02 --> Loader Class Initialized
DEBUG - 2018-07-20 05:49:02 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-20 05:49:02 --> Helper loaded: url_helper
INFO - 2018-07-20 05:49:02 --> Helper loaded: form_helper
INFO - 2018-07-20 05:49:02 --> Helper loaded: date_helper
INFO - 2018-07-20 05:49:02 --> Helper loaded: util_helper
INFO - 2018-07-20 05:49:02 --> Helper loaded: text_helper
INFO - 2018-07-20 05:49:02 --> Helper loaded: string_helper
INFO - 2018-07-20 05:49:02 --> Database Driver Class Initialized
DEBUG - 2018-07-20 05:49:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-20 05:49:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-20 05:49:02 --> Email Class Initialized
INFO - 2018-07-20 05:49:02 --> Controller Class Initialized
DEBUG - 2018-07-20 05:49:02 --> Users MX_Controller Initialized
DEBUG - 2018-07-20 05:49:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-20 05:49:02 --> Helper loaded: file_helper
DEBUG - 2018-07-20 05:49:02 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-20 05:49:02 --> Login MX_Controller Initialized
INFO - 2018-07-20 05:49:02 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-20 05:49:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-20 05:49:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-07-20 05:49:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-20 05:49:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-20 05:49:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-20 05:49:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-20 05:49:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-20 05:49:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-20 05:49:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-07-20 05:49:02 --> Final output sent to browser
DEBUG - 2018-07-20 05:49:02 --> Total execution time: 0.5148
INFO - 2018-07-20 05:49:24 --> Config Class Initialized
INFO - 2018-07-20 05:49:24 --> Hooks Class Initialized
DEBUG - 2018-07-20 05:49:24 --> UTF-8 Support Enabled
INFO - 2018-07-20 05:49:24 --> Utf8 Class Initialized
INFO - 2018-07-20 05:49:24 --> URI Class Initialized
INFO - 2018-07-20 05:49:24 --> Router Class Initialized
INFO - 2018-07-20 05:49:24 --> Output Class Initialized
INFO - 2018-07-20 05:49:24 --> Security Class Initialized
DEBUG - 2018-07-20 05:49:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 05:49:24 --> Input Class Initialized
INFO - 2018-07-20 05:49:24 --> Language Class Initialized
INFO - 2018-07-20 05:49:24 --> Language Class Initialized
INFO - 2018-07-20 05:49:24 --> Config Class Initialized
INFO - 2018-07-20 05:49:24 --> Loader Class Initialized
DEBUG - 2018-07-20 05:49:24 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-20 05:49:24 --> Helper loaded: url_helper
INFO - 2018-07-20 05:49:24 --> Helper loaded: form_helper
INFO - 2018-07-20 05:49:24 --> Helper loaded: date_helper
INFO - 2018-07-20 05:49:24 --> Helper loaded: util_helper
INFO - 2018-07-20 05:49:24 --> Helper loaded: text_helper
INFO - 2018-07-20 05:49:24 --> Helper loaded: string_helper
INFO - 2018-07-20 05:49:24 --> Database Driver Class Initialized
DEBUG - 2018-07-20 05:49:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-20 05:49:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-20 05:49:24 --> Email Class Initialized
INFO - 2018-07-20 05:49:24 --> Controller Class Initialized
DEBUG - 2018-07-20 05:49:24 --> Users MX_Controller Initialized
DEBUG - 2018-07-20 05:49:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-20 05:49:24 --> Helper loaded: file_helper
DEBUG - 2018-07-20 05:49:24 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-20 05:49:24 --> Login MX_Controller Initialized
INFO - 2018-07-20 05:49:24 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-20 05:49:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-20 05:49:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-07-20 05:49:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-07-20 05:50:40 --> Config Class Initialized
INFO - 2018-07-20 05:50:40 --> Hooks Class Initialized
DEBUG - 2018-07-20 05:50:40 --> UTF-8 Support Enabled
INFO - 2018-07-20 05:50:40 --> Utf8 Class Initialized
INFO - 2018-07-20 05:50:40 --> URI Class Initialized
INFO - 2018-07-20 05:50:40 --> Router Class Initialized
INFO - 2018-07-20 05:50:40 --> Output Class Initialized
INFO - 2018-07-20 05:50:40 --> Security Class Initialized
DEBUG - 2018-07-20 05:50:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 05:50:40 --> Input Class Initialized
INFO - 2018-07-20 05:50:40 --> Language Class Initialized
INFO - 2018-07-20 05:50:40 --> Language Class Initialized
INFO - 2018-07-20 05:50:40 --> Config Class Initialized
INFO - 2018-07-20 05:50:40 --> Loader Class Initialized
DEBUG - 2018-07-20 05:50:40 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-20 05:50:40 --> Helper loaded: url_helper
INFO - 2018-07-20 05:50:40 --> Helper loaded: form_helper
INFO - 2018-07-20 05:50:40 --> Helper loaded: date_helper
INFO - 2018-07-20 05:50:40 --> Helper loaded: util_helper
INFO - 2018-07-20 05:50:40 --> Helper loaded: text_helper
INFO - 2018-07-20 05:50:40 --> Helper loaded: string_helper
INFO - 2018-07-20 05:50:40 --> Database Driver Class Initialized
DEBUG - 2018-07-20 05:50:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-20 05:50:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-20 05:50:40 --> Email Class Initialized
INFO - 2018-07-20 05:50:40 --> Controller Class Initialized
DEBUG - 2018-07-20 05:50:40 --> Users MX_Controller Initialized
DEBUG - 2018-07-20 05:50:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-20 05:50:40 --> Helper loaded: file_helper
DEBUG - 2018-07-20 05:50:40 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-20 05:50:40 --> Login MX_Controller Initialized
INFO - 2018-07-20 05:50:40 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-20 05:50:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-20 05:50:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-07-20 05:50:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-07-20 05:51:02 --> Config Class Initialized
INFO - 2018-07-20 05:51:02 --> Hooks Class Initialized
DEBUG - 2018-07-20 05:51:02 --> UTF-8 Support Enabled
INFO - 2018-07-20 05:51:02 --> Utf8 Class Initialized
INFO - 2018-07-20 05:51:02 --> URI Class Initialized
INFO - 2018-07-20 05:51:02 --> Router Class Initialized
INFO - 2018-07-20 05:51:02 --> Output Class Initialized
INFO - 2018-07-20 05:51:02 --> Security Class Initialized
DEBUG - 2018-07-20 05:51:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 05:51:02 --> Input Class Initialized
INFO - 2018-07-20 05:51:02 --> Language Class Initialized
INFO - 2018-07-20 05:51:02 --> Language Class Initialized
INFO - 2018-07-20 05:51:02 --> Config Class Initialized
INFO - 2018-07-20 05:51:02 --> Loader Class Initialized
DEBUG - 2018-07-20 05:51:02 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-20 05:51:02 --> Helper loaded: url_helper
INFO - 2018-07-20 05:51:02 --> Helper loaded: form_helper
INFO - 2018-07-20 05:51:02 --> Helper loaded: date_helper
INFO - 2018-07-20 05:51:02 --> Helper loaded: util_helper
INFO - 2018-07-20 05:51:02 --> Helper loaded: text_helper
INFO - 2018-07-20 05:51:02 --> Helper loaded: string_helper
INFO - 2018-07-20 05:51:02 --> Database Driver Class Initialized
DEBUG - 2018-07-20 05:51:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-20 05:51:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-20 05:51:02 --> Email Class Initialized
INFO - 2018-07-20 05:51:02 --> Controller Class Initialized
DEBUG - 2018-07-20 05:51:02 --> Users MX_Controller Initialized
DEBUG - 2018-07-20 05:51:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-20 05:51:02 --> Helper loaded: file_helper
DEBUG - 2018-07-20 05:51:02 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-20 05:51:02 --> Login MX_Controller Initialized
INFO - 2018-07-20 05:51:02 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-20 05:51:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-20 05:51:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-07-20 05:51:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-07-20 05:52:16 --> Config Class Initialized
INFO - 2018-07-20 05:52:16 --> Hooks Class Initialized
DEBUG - 2018-07-20 05:52:16 --> UTF-8 Support Enabled
INFO - 2018-07-20 05:52:16 --> Utf8 Class Initialized
INFO - 2018-07-20 05:52:16 --> URI Class Initialized
INFO - 2018-07-20 05:52:16 --> Router Class Initialized
INFO - 2018-07-20 05:52:16 --> Output Class Initialized
INFO - 2018-07-20 05:52:16 --> Security Class Initialized
DEBUG - 2018-07-20 05:52:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 05:52:16 --> Input Class Initialized
INFO - 2018-07-20 05:52:16 --> Language Class Initialized
INFO - 2018-07-20 05:52:16 --> Language Class Initialized
INFO - 2018-07-20 05:52:16 --> Config Class Initialized
INFO - 2018-07-20 05:52:16 --> Loader Class Initialized
DEBUG - 2018-07-20 05:52:16 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-20 05:52:16 --> Helper loaded: url_helper
INFO - 2018-07-20 05:52:16 --> Helper loaded: form_helper
INFO - 2018-07-20 05:52:16 --> Helper loaded: date_helper
INFO - 2018-07-20 05:52:16 --> Helper loaded: util_helper
INFO - 2018-07-20 05:52:16 --> Helper loaded: text_helper
INFO - 2018-07-20 05:52:16 --> Helper loaded: string_helper
INFO - 2018-07-20 05:52:16 --> Database Driver Class Initialized
DEBUG - 2018-07-20 05:52:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-20 05:52:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-20 05:52:16 --> Email Class Initialized
INFO - 2018-07-20 05:52:16 --> Controller Class Initialized
DEBUG - 2018-07-20 05:52:16 --> Users MX_Controller Initialized
DEBUG - 2018-07-20 05:52:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-20 05:52:16 --> Helper loaded: file_helper
DEBUG - 2018-07-20 05:52:16 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-20 05:52:16 --> Login MX_Controller Initialized
INFO - 2018-07-20 05:52:16 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-20 05:52:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-20 05:52:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-07-20 05:52:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-20 05:52:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-20 05:52:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-20 05:52:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-20 05:52:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-20 05:52:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-20 05:52:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-07-20 05:52:16 --> Final output sent to browser
DEBUG - 2018-07-20 05:52:16 --> Total execution time: 0.4600
INFO - 2018-07-20 05:52:58 --> Config Class Initialized
INFO - 2018-07-20 05:52:58 --> Hooks Class Initialized
DEBUG - 2018-07-20 05:52:58 --> UTF-8 Support Enabled
INFO - 2018-07-20 05:52:58 --> Utf8 Class Initialized
INFO - 2018-07-20 05:52:58 --> URI Class Initialized
INFO - 2018-07-20 05:52:58 --> Router Class Initialized
INFO - 2018-07-20 05:52:58 --> Output Class Initialized
INFO - 2018-07-20 05:52:58 --> Security Class Initialized
DEBUG - 2018-07-20 05:52:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 05:52:58 --> Input Class Initialized
INFO - 2018-07-20 05:52:58 --> Language Class Initialized
INFO - 2018-07-20 05:52:58 --> Language Class Initialized
INFO - 2018-07-20 05:52:58 --> Config Class Initialized
INFO - 2018-07-20 05:52:58 --> Loader Class Initialized
DEBUG - 2018-07-20 05:52:58 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-20 05:52:58 --> Helper loaded: url_helper
INFO - 2018-07-20 05:52:58 --> Helper loaded: form_helper
INFO - 2018-07-20 05:52:58 --> Helper loaded: date_helper
INFO - 2018-07-20 05:52:58 --> Helper loaded: util_helper
INFO - 2018-07-20 05:52:58 --> Helper loaded: text_helper
INFO - 2018-07-20 05:52:58 --> Helper loaded: string_helper
INFO - 2018-07-20 05:52:58 --> Database Driver Class Initialized
DEBUG - 2018-07-20 05:52:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-20 05:52:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-20 05:52:58 --> Email Class Initialized
INFO - 2018-07-20 05:52:58 --> Controller Class Initialized
DEBUG - 2018-07-20 05:52:58 --> Users MX_Controller Initialized
DEBUG - 2018-07-20 05:52:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-20 05:52:58 --> Helper loaded: file_helper
DEBUG - 2018-07-20 05:52:58 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-20 05:52:58 --> Login MX_Controller Initialized
INFO - 2018-07-20 05:52:58 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-20 05:52:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-20 05:52:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-07-20 05:52:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-20 05:52:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-20 05:52:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-20 05:52:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-20 05:52:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-20 05:52:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-20 05:52:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-07-20 05:52:58 --> Final output sent to browser
DEBUG - 2018-07-20 05:52:58 --> Total execution time: 0.4771
INFO - 2018-07-20 05:53:17 --> Config Class Initialized
INFO - 2018-07-20 05:53:17 --> Hooks Class Initialized
DEBUG - 2018-07-20 05:53:17 --> UTF-8 Support Enabled
INFO - 2018-07-20 05:53:17 --> Utf8 Class Initialized
INFO - 2018-07-20 05:53:17 --> URI Class Initialized
INFO - 2018-07-20 05:53:17 --> Router Class Initialized
INFO - 2018-07-20 05:53:17 --> Output Class Initialized
INFO - 2018-07-20 05:53:17 --> Security Class Initialized
DEBUG - 2018-07-20 05:53:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 05:53:17 --> Input Class Initialized
INFO - 2018-07-20 05:53:17 --> Language Class Initialized
INFO - 2018-07-20 05:53:17 --> Language Class Initialized
INFO - 2018-07-20 05:53:17 --> Config Class Initialized
INFO - 2018-07-20 05:53:17 --> Loader Class Initialized
DEBUG - 2018-07-20 05:53:17 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-20 05:53:17 --> Helper loaded: url_helper
INFO - 2018-07-20 05:53:17 --> Helper loaded: form_helper
INFO - 2018-07-20 05:53:17 --> Helper loaded: date_helper
INFO - 2018-07-20 05:53:17 --> Helper loaded: util_helper
INFO - 2018-07-20 05:53:17 --> Helper loaded: text_helper
INFO - 2018-07-20 05:53:17 --> Helper loaded: string_helper
INFO - 2018-07-20 05:53:17 --> Database Driver Class Initialized
DEBUG - 2018-07-20 05:53:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-20 05:53:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-20 05:53:18 --> Email Class Initialized
INFO - 2018-07-20 05:53:18 --> Controller Class Initialized
DEBUG - 2018-07-20 05:53:18 --> Users MX_Controller Initialized
DEBUG - 2018-07-20 05:53:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-20 05:53:18 --> Helper loaded: file_helper
DEBUG - 2018-07-20 05:53:18 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-20 05:53:18 --> Login MX_Controller Initialized
INFO - 2018-07-20 05:53:18 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-20 05:53:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-20 05:53:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-07-20 05:53:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-20 05:53:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-20 05:53:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-20 05:53:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-20 05:53:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-20 05:53:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-20 05:53:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-07-20 05:53:18 --> Final output sent to browser
DEBUG - 2018-07-20 05:53:18 --> Total execution time: 0.5169
INFO - 2018-07-20 05:53:30 --> Config Class Initialized
INFO - 2018-07-20 05:53:30 --> Hooks Class Initialized
DEBUG - 2018-07-20 05:53:30 --> UTF-8 Support Enabled
INFO - 2018-07-20 05:53:30 --> Utf8 Class Initialized
INFO - 2018-07-20 05:53:30 --> URI Class Initialized
INFO - 2018-07-20 05:53:30 --> Router Class Initialized
INFO - 2018-07-20 05:53:30 --> Output Class Initialized
INFO - 2018-07-20 05:53:30 --> Security Class Initialized
DEBUG - 2018-07-20 05:53:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 05:53:30 --> Input Class Initialized
INFO - 2018-07-20 05:53:30 --> Language Class Initialized
ERROR - 2018-07-20 05:53:30 --> 404 Page Not Found: /index
INFO - 2018-07-20 05:53:31 --> Config Class Initialized
INFO - 2018-07-20 05:53:31 --> Hooks Class Initialized
DEBUG - 2018-07-20 05:53:31 --> UTF-8 Support Enabled
INFO - 2018-07-20 05:53:31 --> Utf8 Class Initialized
INFO - 2018-07-20 05:53:31 --> URI Class Initialized
INFO - 2018-07-20 05:53:31 --> Router Class Initialized
INFO - 2018-07-20 05:53:31 --> Output Class Initialized
INFO - 2018-07-20 05:53:31 --> Security Class Initialized
DEBUG - 2018-07-20 05:53:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 05:53:31 --> Input Class Initialized
INFO - 2018-07-20 05:53:31 --> Language Class Initialized
ERROR - 2018-07-20 05:53:31 --> 404 Page Not Found: /index
INFO - 2018-07-20 05:53:31 --> Config Class Initialized
INFO - 2018-07-20 05:53:31 --> Hooks Class Initialized
DEBUG - 2018-07-20 05:53:31 --> UTF-8 Support Enabled
INFO - 2018-07-20 05:53:31 --> Utf8 Class Initialized
INFO - 2018-07-20 05:53:31 --> URI Class Initialized
INFO - 2018-07-20 05:53:31 --> Router Class Initialized
INFO - 2018-07-20 05:53:31 --> Output Class Initialized
INFO - 2018-07-20 05:53:31 --> Security Class Initialized
DEBUG - 2018-07-20 05:53:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 05:53:31 --> Input Class Initialized
INFO - 2018-07-20 05:53:31 --> Language Class Initialized
ERROR - 2018-07-20 05:53:31 --> 404 Page Not Found: /index
INFO - 2018-07-20 05:53:31 --> Config Class Initialized
INFO - 2018-07-20 05:53:31 --> Hooks Class Initialized
DEBUG - 2018-07-20 05:53:31 --> UTF-8 Support Enabled
INFO - 2018-07-20 05:53:31 --> Utf8 Class Initialized
INFO - 2018-07-20 05:53:31 --> URI Class Initialized
INFO - 2018-07-20 05:53:31 --> Router Class Initialized
INFO - 2018-07-20 05:53:31 --> Output Class Initialized
INFO - 2018-07-20 05:53:31 --> Security Class Initialized
DEBUG - 2018-07-20 05:53:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 05:53:31 --> Input Class Initialized
INFO - 2018-07-20 05:53:31 --> Language Class Initialized
ERROR - 2018-07-20 05:53:32 --> 404 Page Not Found: /index
INFO - 2018-07-20 05:53:36 --> Config Class Initialized
INFO - 2018-07-20 05:53:36 --> Hooks Class Initialized
DEBUG - 2018-07-20 05:53:36 --> UTF-8 Support Enabled
INFO - 2018-07-20 05:53:36 --> Utf8 Class Initialized
INFO - 2018-07-20 05:53:36 --> URI Class Initialized
INFO - 2018-07-20 05:53:36 --> Router Class Initialized
INFO - 2018-07-20 05:53:36 --> Output Class Initialized
INFO - 2018-07-20 05:53:36 --> Security Class Initialized
DEBUG - 2018-07-20 05:53:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 05:53:36 --> Input Class Initialized
INFO - 2018-07-20 05:53:36 --> Language Class Initialized
ERROR - 2018-07-20 05:53:36 --> 404 Page Not Found: /index
INFO - 2018-07-20 05:54:49 --> Config Class Initialized
INFO - 2018-07-20 05:54:49 --> Hooks Class Initialized
DEBUG - 2018-07-20 05:54:50 --> UTF-8 Support Enabled
INFO - 2018-07-20 05:54:50 --> Utf8 Class Initialized
INFO - 2018-07-20 05:54:50 --> URI Class Initialized
INFO - 2018-07-20 05:54:50 --> Router Class Initialized
INFO - 2018-07-20 05:54:50 --> Output Class Initialized
INFO - 2018-07-20 05:54:50 --> Security Class Initialized
DEBUG - 2018-07-20 05:54:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 05:54:50 --> Input Class Initialized
INFO - 2018-07-20 05:54:50 --> Language Class Initialized
INFO - 2018-07-20 05:54:50 --> Language Class Initialized
INFO - 2018-07-20 05:54:50 --> Config Class Initialized
INFO - 2018-07-20 05:54:50 --> Loader Class Initialized
DEBUG - 2018-07-20 05:54:50 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-20 05:54:50 --> Helper loaded: url_helper
INFO - 2018-07-20 05:54:50 --> Helper loaded: form_helper
INFO - 2018-07-20 05:54:50 --> Helper loaded: date_helper
INFO - 2018-07-20 05:54:50 --> Helper loaded: util_helper
INFO - 2018-07-20 05:54:50 --> Helper loaded: text_helper
INFO - 2018-07-20 05:54:50 --> Helper loaded: string_helper
INFO - 2018-07-20 05:54:50 --> Database Driver Class Initialized
DEBUG - 2018-07-20 05:54:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-20 05:54:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-20 05:54:50 --> Email Class Initialized
INFO - 2018-07-20 05:54:50 --> Controller Class Initialized
DEBUG - 2018-07-20 05:54:50 --> Users MX_Controller Initialized
DEBUG - 2018-07-20 05:54:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-20 05:54:50 --> Helper loaded: file_helper
DEBUG - 2018-07-20 05:54:50 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-20 05:54:50 --> Login MX_Controller Initialized
INFO - 2018-07-20 05:54:50 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-20 05:54:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-20 05:54:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-07-20 05:54:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-20 05:54:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-20 05:54:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-20 05:54:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-20 05:54:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-20 05:54:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-20 05:54:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-07-20 05:54:50 --> Final output sent to browser
DEBUG - 2018-07-20 05:54:50 --> Total execution time: 0.4951
INFO - 2018-07-20 05:55:01 --> Config Class Initialized
INFO - 2018-07-20 05:55:01 --> Hooks Class Initialized
DEBUG - 2018-07-20 05:55:01 --> UTF-8 Support Enabled
INFO - 2018-07-20 05:55:01 --> Utf8 Class Initialized
INFO - 2018-07-20 05:55:01 --> URI Class Initialized
INFO - 2018-07-20 05:55:01 --> Router Class Initialized
INFO - 2018-07-20 05:55:01 --> Output Class Initialized
INFO - 2018-07-20 05:55:01 --> Security Class Initialized
DEBUG - 2018-07-20 05:55:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 05:55:01 --> Input Class Initialized
INFO - 2018-07-20 05:55:01 --> Language Class Initialized
INFO - 2018-07-20 05:55:01 --> Language Class Initialized
INFO - 2018-07-20 05:55:01 --> Config Class Initialized
INFO - 2018-07-20 05:55:01 --> Loader Class Initialized
DEBUG - 2018-07-20 05:55:01 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-20 05:55:01 --> Helper loaded: url_helper
INFO - 2018-07-20 05:55:01 --> Helper loaded: form_helper
INFO - 2018-07-20 05:55:01 --> Helper loaded: date_helper
INFO - 2018-07-20 05:55:01 --> Helper loaded: util_helper
INFO - 2018-07-20 05:55:01 --> Helper loaded: text_helper
INFO - 2018-07-20 05:55:01 --> Helper loaded: string_helper
INFO - 2018-07-20 05:55:01 --> Database Driver Class Initialized
DEBUG - 2018-07-20 05:55:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-20 05:55:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-20 05:55:01 --> Email Class Initialized
INFO - 2018-07-20 05:55:01 --> Controller Class Initialized
DEBUG - 2018-07-20 05:55:01 --> Users MX_Controller Initialized
DEBUG - 2018-07-20 05:55:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-20 05:55:01 --> Helper loaded: file_helper
DEBUG - 2018-07-20 05:55:01 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-20 05:55:01 --> Login MX_Controller Initialized
INFO - 2018-07-20 05:55:01 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-20 05:55:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-20 05:55:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-07-20 05:55:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-20 05:55:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-20 05:55:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-20 05:55:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-20 05:55:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-20 05:55:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-20 05:55:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-07-20 05:55:01 --> Final output sent to browser
DEBUG - 2018-07-20 05:55:02 --> Total execution time: 0.4677
INFO - 2018-07-20 05:55:49 --> Config Class Initialized
INFO - 2018-07-20 05:55:49 --> Hooks Class Initialized
DEBUG - 2018-07-20 05:55:49 --> UTF-8 Support Enabled
INFO - 2018-07-20 05:55:49 --> Utf8 Class Initialized
INFO - 2018-07-20 05:55:49 --> URI Class Initialized
INFO - 2018-07-20 05:55:49 --> Router Class Initialized
INFO - 2018-07-20 05:55:49 --> Output Class Initialized
INFO - 2018-07-20 05:55:49 --> Security Class Initialized
DEBUG - 2018-07-20 05:55:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 05:55:49 --> Input Class Initialized
INFO - 2018-07-20 05:55:49 --> Language Class Initialized
INFO - 2018-07-20 05:55:49 --> Language Class Initialized
INFO - 2018-07-20 05:55:49 --> Config Class Initialized
INFO - 2018-07-20 05:55:49 --> Loader Class Initialized
DEBUG - 2018-07-20 05:55:49 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-20 05:55:49 --> Helper loaded: url_helper
INFO - 2018-07-20 05:55:49 --> Helper loaded: form_helper
INFO - 2018-07-20 05:55:49 --> Helper loaded: date_helper
INFO - 2018-07-20 05:55:49 --> Helper loaded: util_helper
INFO - 2018-07-20 05:55:49 --> Helper loaded: text_helper
INFO - 2018-07-20 05:55:49 --> Helper loaded: string_helper
INFO - 2018-07-20 05:55:49 --> Database Driver Class Initialized
DEBUG - 2018-07-20 05:55:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-20 05:55:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-20 05:55:49 --> Email Class Initialized
INFO - 2018-07-20 05:55:49 --> Controller Class Initialized
DEBUG - 2018-07-20 05:55:49 --> Users MX_Controller Initialized
DEBUG - 2018-07-20 05:55:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-20 05:55:49 --> Helper loaded: file_helper
DEBUG - 2018-07-20 05:55:49 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-20 05:55:49 --> Login MX_Controller Initialized
INFO - 2018-07-20 05:55:49 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-20 05:55:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-20 05:55:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-07-20 05:55:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-20 05:55:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-20 05:55:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-20 05:55:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-20 05:55:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-20 05:55:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-20 05:55:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-07-20 05:55:50 --> Final output sent to browser
DEBUG - 2018-07-20 05:55:50 --> Total execution time: 0.4842
INFO - 2018-07-20 05:59:09 --> Config Class Initialized
INFO - 2018-07-20 05:59:09 --> Hooks Class Initialized
DEBUG - 2018-07-20 05:59:09 --> UTF-8 Support Enabled
INFO - 2018-07-20 05:59:09 --> Utf8 Class Initialized
INFO - 2018-07-20 05:59:09 --> URI Class Initialized
INFO - 2018-07-20 05:59:09 --> Router Class Initialized
INFO - 2018-07-20 05:59:09 --> Output Class Initialized
INFO - 2018-07-20 05:59:09 --> Security Class Initialized
DEBUG - 2018-07-20 05:59:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 05:59:09 --> Input Class Initialized
INFO - 2018-07-20 05:59:09 --> Language Class Initialized
INFO - 2018-07-20 05:59:09 --> Language Class Initialized
INFO - 2018-07-20 05:59:09 --> Config Class Initialized
INFO - 2018-07-20 05:59:09 --> Loader Class Initialized
DEBUG - 2018-07-20 05:59:09 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-20 05:59:09 --> Helper loaded: url_helper
INFO - 2018-07-20 05:59:09 --> Helper loaded: form_helper
INFO - 2018-07-20 05:59:09 --> Helper loaded: date_helper
INFO - 2018-07-20 05:59:09 --> Helper loaded: util_helper
INFO - 2018-07-20 05:59:09 --> Helper loaded: text_helper
INFO - 2018-07-20 05:59:09 --> Helper loaded: string_helper
INFO - 2018-07-20 05:59:09 --> Database Driver Class Initialized
DEBUG - 2018-07-20 05:59:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-20 05:59:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-20 05:59:09 --> Email Class Initialized
INFO - 2018-07-20 05:59:09 --> Controller Class Initialized
DEBUG - 2018-07-20 05:59:09 --> Users MX_Controller Initialized
DEBUG - 2018-07-20 05:59:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-20 05:59:09 --> Helper loaded: file_helper
DEBUG - 2018-07-20 05:59:09 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-20 05:59:10 --> Login MX_Controller Initialized
INFO - 2018-07-20 05:59:10 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-20 05:59:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-20 05:59:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-07-20 05:59:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-20 05:59:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-20 05:59:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-20 05:59:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-20 05:59:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-20 05:59:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-20 05:59:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-07-20 05:59:10 --> Final output sent to browser
DEBUG - 2018-07-20 05:59:10 --> Total execution time: 0.5246
INFO - 2018-07-20 05:59:18 --> Config Class Initialized
INFO - 2018-07-20 05:59:18 --> Hooks Class Initialized
DEBUG - 2018-07-20 05:59:18 --> UTF-8 Support Enabled
INFO - 2018-07-20 05:59:18 --> Utf8 Class Initialized
INFO - 2018-07-20 05:59:18 --> URI Class Initialized
INFO - 2018-07-20 05:59:18 --> Router Class Initialized
INFO - 2018-07-20 05:59:19 --> Output Class Initialized
INFO - 2018-07-20 05:59:19 --> Security Class Initialized
DEBUG - 2018-07-20 05:59:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 05:59:19 --> Input Class Initialized
INFO - 2018-07-20 05:59:19 --> Language Class Initialized
INFO - 2018-07-20 05:59:19 --> Language Class Initialized
INFO - 2018-07-20 05:59:19 --> Config Class Initialized
INFO - 2018-07-20 05:59:19 --> Loader Class Initialized
DEBUG - 2018-07-20 05:59:19 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-20 05:59:19 --> Helper loaded: url_helper
INFO - 2018-07-20 05:59:19 --> Helper loaded: form_helper
INFO - 2018-07-20 05:59:19 --> Helper loaded: date_helper
INFO - 2018-07-20 05:59:19 --> Config Class Initialized
INFO - 2018-07-20 05:59:19 --> Hooks Class Initialized
INFO - 2018-07-20 05:59:19 --> Helper loaded: util_helper
DEBUG - 2018-07-20 05:59:19 --> UTF-8 Support Enabled
INFO - 2018-07-20 05:59:19 --> Helper loaded: text_helper
INFO - 2018-07-20 05:59:19 --> Utf8 Class Initialized
INFO - 2018-07-20 05:59:19 --> URI Class Initialized
INFO - 2018-07-20 05:59:19 --> Router Class Initialized
INFO - 2018-07-20 05:59:19 --> Helper loaded: string_helper
INFO - 2018-07-20 05:59:19 --> Output Class Initialized
INFO - 2018-07-20 05:59:19 --> Security Class Initialized
DEBUG - 2018-07-20 05:59:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 05:59:19 --> Input Class Initialized
INFO - 2018-07-20 05:59:19 --> Language Class Initialized
INFO - 2018-07-20 05:59:19 --> Language Class Initialized
INFO - 2018-07-20 05:59:19 --> Database Driver Class Initialized
INFO - 2018-07-20 05:59:19 --> Config Class Initialized
INFO - 2018-07-20 05:59:19 --> Loader Class Initialized
DEBUG - 2018-07-20 05:59:19 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
DEBUG - 2018-07-20 05:59:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-20 05:59:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-20 05:59:19 --> Helper loaded: url_helper
INFO - 2018-07-20 05:59:19 --> Email Class Initialized
INFO - 2018-07-20 05:59:19 --> Helper loaded: form_helper
INFO - 2018-07-20 05:59:19 --> Controller Class Initialized
DEBUG - 2018-07-20 05:59:19 --> Users MX_Controller Initialized
DEBUG - 2018-07-20 05:59:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-20 05:59:19 --> Helper loaded: file_helper
DEBUG - 2018-07-20 05:59:19 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-20 05:59:19 --> Login MX_Controller Initialized
INFO - 2018-07-20 05:59:19 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-20 05:59:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-20 05:59:19 --> Helper loaded: date_helper
DEBUG - 2018-07-20 05:59:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-07-20 05:59:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-07-20 05:59:19 --> Helper loaded: util_helper
INFO - 2018-07-20 05:59:19 --> Helper loaded: text_helper
DEBUG - 2018-07-20 05:59:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-20 05:59:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
INFO - 2018-07-20 05:59:19 --> Helper loaded: string_helper
DEBUG - 2018-07-20 05:59:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-20 05:59:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-20 05:59:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-20 05:59:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-07-20 05:59:19 --> Final output sent to browser
DEBUG - 2018-07-20 05:59:19 --> Total execution time: 0.6114
INFO - 2018-07-20 05:59:19 --> Database Driver Class Initialized
DEBUG - 2018-07-20 05:59:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-20 05:59:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-20 05:59:19 --> Email Class Initialized
INFO - 2018-07-20 05:59:19 --> Controller Class Initialized
DEBUG - 2018-07-20 05:59:19 --> Users MX_Controller Initialized
DEBUG - 2018-07-20 05:59:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-20 05:59:19 --> Helper loaded: file_helper
DEBUG - 2018-07-20 05:59:19 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-20 05:59:19 --> Login MX_Controller Initialized
INFO - 2018-07-20 05:59:19 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-20 05:59:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-20 05:59:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-07-20 05:59:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-20 05:59:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
INFO - 2018-07-20 05:59:19 --> Upload Class Initialized
INFO - 2018-07-20 05:59:19 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2018-07-20 05:59:19 --> You did not select a file to upload.
INFO - 2018-07-20 05:59:19 --> Config Class Initialized
INFO - 2018-07-20 05:59:19 --> Hooks Class Initialized
DEBUG - 2018-07-20 05:59:19 --> UTF-8 Support Enabled
INFO - 2018-07-20 05:59:19 --> Utf8 Class Initialized
INFO - 2018-07-20 05:59:19 --> URI Class Initialized
INFO - 2018-07-20 05:59:19 --> Router Class Initialized
INFO - 2018-07-20 05:59:19 --> Output Class Initialized
INFO - 2018-07-20 05:59:19 --> Security Class Initialized
DEBUG - 2018-07-20 05:59:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 05:59:19 --> Input Class Initialized
INFO - 2018-07-20 05:59:19 --> Language Class Initialized
INFO - 2018-07-20 05:59:19 --> Language Class Initialized
INFO - 2018-07-20 05:59:19 --> Config Class Initialized
INFO - 2018-07-20 05:59:20 --> Loader Class Initialized
DEBUG - 2018-07-20 05:59:20 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-20 05:59:20 --> Helper loaded: url_helper
INFO - 2018-07-20 05:59:20 --> Helper loaded: form_helper
INFO - 2018-07-20 05:59:20 --> Helper loaded: date_helper
INFO - 2018-07-20 05:59:20 --> Helper loaded: util_helper
INFO - 2018-07-20 05:59:20 --> Helper loaded: text_helper
INFO - 2018-07-20 05:59:20 --> Helper loaded: string_helper
INFO - 2018-07-20 05:59:20 --> Database Driver Class Initialized
DEBUG - 2018-07-20 05:59:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-20 05:59:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-20 05:59:20 --> Email Class Initialized
INFO - 2018-07-20 05:59:20 --> Controller Class Initialized
DEBUG - 2018-07-20 05:59:20 --> Users MX_Controller Initialized
DEBUG - 2018-07-20 05:59:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-20 05:59:20 --> Helper loaded: file_helper
DEBUG - 2018-07-20 05:59:20 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-20 05:59:20 --> Login MX_Controller Initialized
INFO - 2018-07-20 05:59:20 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-20 05:59:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-20 05:59:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-07-20 05:59:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-20 05:59:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-20 05:59:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-20 05:59:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-20 05:59:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-20 05:59:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-20 05:59:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-07-20 05:59:20 --> Final output sent to browser
DEBUG - 2018-07-20 05:59:20 --> Total execution time: 0.4623
INFO - 2018-07-20 05:59:24 --> Config Class Initialized
INFO - 2018-07-20 05:59:24 --> Hooks Class Initialized
DEBUG - 2018-07-20 05:59:24 --> UTF-8 Support Enabled
INFO - 2018-07-20 05:59:24 --> Utf8 Class Initialized
INFO - 2018-07-20 05:59:24 --> URI Class Initialized
INFO - 2018-07-20 05:59:24 --> Router Class Initialized
INFO - 2018-07-20 05:59:24 --> Output Class Initialized
INFO - 2018-07-20 05:59:24 --> Security Class Initialized
DEBUG - 2018-07-20 05:59:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 05:59:24 --> Input Class Initialized
INFO - 2018-07-20 05:59:24 --> Language Class Initialized
INFO - 2018-07-20 05:59:24 --> Language Class Initialized
INFO - 2018-07-20 05:59:24 --> Config Class Initialized
INFO - 2018-07-20 05:59:24 --> Loader Class Initialized
DEBUG - 2018-07-20 05:59:24 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-20 05:59:24 --> Helper loaded: url_helper
INFO - 2018-07-20 05:59:24 --> Helper loaded: form_helper
INFO - 2018-07-20 05:59:24 --> Helper loaded: date_helper
INFO - 2018-07-20 05:59:24 --> Helper loaded: util_helper
INFO - 2018-07-20 05:59:24 --> Helper loaded: text_helper
INFO - 2018-07-20 05:59:24 --> Helper loaded: string_helper
INFO - 2018-07-20 05:59:25 --> Database Driver Class Initialized
DEBUG - 2018-07-20 05:59:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-20 05:59:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-20 05:59:25 --> Email Class Initialized
INFO - 2018-07-20 05:59:25 --> Controller Class Initialized
DEBUG - 2018-07-20 05:59:25 --> Users MX_Controller Initialized
DEBUG - 2018-07-20 05:59:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-20 05:59:25 --> Helper loaded: file_helper
DEBUG - 2018-07-20 05:59:25 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-20 05:59:25 --> Login MX_Controller Initialized
INFO - 2018-07-20 05:59:25 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-20 05:59:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-20 05:59:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-07-20 05:59:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-20 05:59:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-20 05:59:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-20 05:59:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-20 05:59:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-20 05:59:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-20 05:59:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-07-20 05:59:25 --> Final output sent to browser
DEBUG - 2018-07-20 05:59:25 --> Total execution time: 0.4781
INFO - 2018-07-20 05:59:53 --> Config Class Initialized
INFO - 2018-07-20 05:59:53 --> Hooks Class Initialized
DEBUG - 2018-07-20 05:59:53 --> UTF-8 Support Enabled
INFO - 2018-07-20 05:59:53 --> Utf8 Class Initialized
INFO - 2018-07-20 05:59:53 --> URI Class Initialized
INFO - 2018-07-20 05:59:53 --> Router Class Initialized
INFO - 2018-07-20 05:59:53 --> Output Class Initialized
INFO - 2018-07-20 05:59:53 --> Security Class Initialized
DEBUG - 2018-07-20 05:59:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 05:59:53 --> Input Class Initialized
INFO - 2018-07-20 05:59:53 --> Language Class Initialized
INFO - 2018-07-20 05:59:53 --> Language Class Initialized
INFO - 2018-07-20 05:59:53 --> Config Class Initialized
INFO - 2018-07-20 05:59:53 --> Loader Class Initialized
DEBUG - 2018-07-20 05:59:53 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-20 05:59:53 --> Helper loaded: url_helper
INFO - 2018-07-20 05:59:54 --> Helper loaded: form_helper
INFO - 2018-07-20 05:59:54 --> Helper loaded: date_helper
INFO - 2018-07-20 05:59:54 --> Helper loaded: util_helper
INFO - 2018-07-20 05:59:54 --> Helper loaded: text_helper
INFO - 2018-07-20 05:59:54 --> Helper loaded: string_helper
INFO - 2018-07-20 05:59:54 --> Database Driver Class Initialized
DEBUG - 2018-07-20 05:59:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-20 05:59:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-20 05:59:54 --> Email Class Initialized
INFO - 2018-07-20 05:59:54 --> Controller Class Initialized
DEBUG - 2018-07-20 05:59:54 --> Users MX_Controller Initialized
DEBUG - 2018-07-20 05:59:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-20 05:59:54 --> Helper loaded: file_helper
DEBUG - 2018-07-20 05:59:54 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-20 05:59:54 --> Login MX_Controller Initialized
INFO - 2018-07-20 05:59:54 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-20 05:59:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-20 05:59:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-07-20 05:59:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-20 05:59:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-20 05:59:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-20 05:59:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-20 05:59:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-20 05:59:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-20 05:59:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-07-20 05:59:54 --> Final output sent to browser
DEBUG - 2018-07-20 05:59:54 --> Total execution time: 0.5117
INFO - 2018-07-20 05:59:55 --> Config Class Initialized
INFO - 2018-07-20 05:59:55 --> Hooks Class Initialized
DEBUG - 2018-07-20 05:59:55 --> UTF-8 Support Enabled
INFO - 2018-07-20 05:59:55 --> Utf8 Class Initialized
INFO - 2018-07-20 05:59:55 --> URI Class Initialized
INFO - 2018-07-20 05:59:55 --> Router Class Initialized
INFO - 2018-07-20 05:59:55 --> Output Class Initialized
INFO - 2018-07-20 05:59:55 --> Security Class Initialized
DEBUG - 2018-07-20 05:59:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 05:59:55 --> Input Class Initialized
INFO - 2018-07-20 05:59:55 --> Language Class Initialized
INFO - 2018-07-20 05:59:55 --> Language Class Initialized
INFO - 2018-07-20 05:59:55 --> Config Class Initialized
INFO - 2018-07-20 05:59:55 --> Loader Class Initialized
DEBUG - 2018-07-20 05:59:55 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-20 05:59:55 --> Helper loaded: url_helper
INFO - 2018-07-20 05:59:55 --> Helper loaded: form_helper
INFO - 2018-07-20 05:59:55 --> Helper loaded: date_helper
INFO - 2018-07-20 05:59:55 --> Helper loaded: util_helper
INFO - 2018-07-20 05:59:55 --> Helper loaded: text_helper
INFO - 2018-07-20 05:59:55 --> Helper loaded: string_helper
INFO - 2018-07-20 05:59:55 --> Database Driver Class Initialized
DEBUG - 2018-07-20 05:59:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-20 05:59:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-20 05:59:55 --> Email Class Initialized
INFO - 2018-07-20 05:59:55 --> Controller Class Initialized
DEBUG - 2018-07-20 05:59:55 --> Users MX_Controller Initialized
DEBUG - 2018-07-20 05:59:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-20 05:59:55 --> Helper loaded: file_helper
DEBUG - 2018-07-20 05:59:55 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-20 05:59:55 --> Login MX_Controller Initialized
INFO - 2018-07-20 05:59:55 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-20 05:59:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-20 05:59:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-07-20 05:59:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-20 05:59:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-20 05:59:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-20 05:59:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-20 05:59:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-20 05:59:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-20 05:59:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-07-20 05:59:55 --> Final output sent to browser
DEBUG - 2018-07-20 05:59:56 --> Total execution time: 0.5005
INFO - 2018-07-20 06:01:27 --> Config Class Initialized
INFO - 2018-07-20 06:01:27 --> Hooks Class Initialized
DEBUG - 2018-07-20 06:01:27 --> UTF-8 Support Enabled
INFO - 2018-07-20 06:01:27 --> Utf8 Class Initialized
INFO - 2018-07-20 06:01:27 --> URI Class Initialized
INFO - 2018-07-20 06:01:27 --> Router Class Initialized
INFO - 2018-07-20 06:01:27 --> Output Class Initialized
INFO - 2018-07-20 06:01:27 --> Security Class Initialized
DEBUG - 2018-07-20 06:01:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 06:01:27 --> Input Class Initialized
INFO - 2018-07-20 06:01:27 --> Language Class Initialized
INFO - 2018-07-20 06:01:27 --> Language Class Initialized
INFO - 2018-07-20 06:01:27 --> Config Class Initialized
INFO - 2018-07-20 06:01:27 --> Loader Class Initialized
DEBUG - 2018-07-20 06:01:27 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-20 06:01:27 --> Helper loaded: url_helper
INFO - 2018-07-20 06:01:27 --> Helper loaded: form_helper
INFO - 2018-07-20 06:01:27 --> Helper loaded: date_helper
INFO - 2018-07-20 06:01:27 --> Helper loaded: util_helper
INFO - 2018-07-20 06:01:27 --> Helper loaded: text_helper
INFO - 2018-07-20 06:01:27 --> Helper loaded: string_helper
INFO - 2018-07-20 06:01:27 --> Database Driver Class Initialized
DEBUG - 2018-07-20 06:01:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-20 06:01:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-20 06:01:27 --> Email Class Initialized
INFO - 2018-07-20 06:01:27 --> Controller Class Initialized
DEBUG - 2018-07-20 06:01:27 --> Users MX_Controller Initialized
DEBUG - 2018-07-20 06:01:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-20 06:01:27 --> Helper loaded: file_helper
DEBUG - 2018-07-20 06:01:27 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-20 06:01:27 --> Login MX_Controller Initialized
INFO - 2018-07-20 06:01:27 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-20 06:01:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-20 06:01:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-07-20 06:01:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-20 06:01:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-20 06:01:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-20 06:01:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-20 06:01:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-20 06:01:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-20 06:01:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-07-20 06:01:27 --> Final output sent to browser
DEBUG - 2018-07-20 06:01:27 --> Total execution time: 0.4873
INFO - 2018-07-20 21:48:50 --> Config Class Initialized
INFO - 2018-07-20 21:48:50 --> Config Class Initialized
INFO - 2018-07-20 21:48:50 --> Hooks Class Initialized
INFO - 2018-07-20 21:48:50 --> Hooks Class Initialized
DEBUG - 2018-07-20 21:48:50 --> UTF-8 Support Enabled
DEBUG - 2018-07-20 21:48:50 --> UTF-8 Support Enabled
INFO - 2018-07-20 21:48:50 --> Utf8 Class Initialized
INFO - 2018-07-20 21:48:50 --> Utf8 Class Initialized
INFO - 2018-07-20 21:48:50 --> URI Class Initialized
INFO - 2018-07-20 21:48:50 --> URI Class Initialized
INFO - 2018-07-20 21:48:50 --> Router Class Initialized
INFO - 2018-07-20 21:48:50 --> Router Class Initialized
INFO - 2018-07-20 21:48:51 --> Output Class Initialized
INFO - 2018-07-20 21:48:51 --> Output Class Initialized
INFO - 2018-07-20 21:48:51 --> Security Class Initialized
INFO - 2018-07-20 21:48:51 --> Security Class Initialized
DEBUG - 2018-07-20 21:48:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-07-20 21:48:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 21:48:51 --> Input Class Initialized
INFO - 2018-07-20 21:48:51 --> Input Class Initialized
INFO - 2018-07-20 21:48:51 --> Language Class Initialized
INFO - 2018-07-20 21:48:51 --> Language Class Initialized
INFO - 2018-07-20 21:48:51 --> Language Class Initialized
INFO - 2018-07-20 21:48:51 --> Language Class Initialized
INFO - 2018-07-20 21:48:51 --> Config Class Initialized
INFO - 2018-07-20 21:48:51 --> Config Class Initialized
INFO - 2018-07-20 21:48:51 --> Loader Class Initialized
INFO - 2018-07-20 21:48:51 --> Loader Class Initialized
DEBUG - 2018-07-20 21:48:51 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
DEBUG - 2018-07-20 21:48:51 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-20 21:48:51 --> Helper loaded: url_helper
INFO - 2018-07-20 21:48:51 --> Helper loaded: url_helper
INFO - 2018-07-20 21:48:51 --> Helper loaded: form_helper
INFO - 2018-07-20 21:48:51 --> Helper loaded: form_helper
INFO - 2018-07-20 21:48:51 --> Helper loaded: date_helper
INFO - 2018-07-20 21:48:51 --> Helper loaded: date_helper
INFO - 2018-07-20 21:48:51 --> Helper loaded: util_helper
INFO - 2018-07-20 21:48:51 --> Helper loaded: util_helper
INFO - 2018-07-20 21:48:51 --> Helper loaded: text_helper
INFO - 2018-07-20 21:48:51 --> Helper loaded: text_helper
INFO - 2018-07-20 21:48:51 --> Helper loaded: string_helper
INFO - 2018-07-20 21:48:51 --> Helper loaded: string_helper
INFO - 2018-07-20 21:48:52 --> Database Driver Class Initialized
INFO - 2018-07-20 21:48:52 --> Database Driver Class Initialized
DEBUG - 2018-07-20 21:48:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-07-20 21:48:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-20 21:48:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-20 21:48:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-20 21:48:52 --> Email Class Initialized
INFO - 2018-07-20 21:48:52 --> Email Class Initialized
INFO - 2018-07-20 21:48:52 --> Controller Class Initialized
INFO - 2018-07-20 21:48:52 --> Controller Class Initialized
DEBUG - 2018-07-20 21:48:52 --> Home MX_Controller Initialized
DEBUG - 2018-07-20 21:48:52 --> Home MX_Controller Initialized
DEBUG - 2018-07-20 21:48:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-20 21:48:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-20 21:48:53 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-20 21:48:53 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-20 21:48:53 --> Login MX_Controller Initialized
DEBUG - 2018-07-20 21:48:53 --> Login MX_Controller Initialized
INFO - 2018-07-20 21:48:53 --> Language file loaded: language/english/data_lang.php
INFO - 2018-07-20 21:48:53 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-20 21:48:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-20 21:48:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-20 21:48:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-20 21:48:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-20 21:48:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
DEBUG - 2018-07-20 21:48:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-07-20 21:49:02 --> Config Class Initialized
INFO - 2018-07-20 21:49:02 --> Hooks Class Initialized
DEBUG - 2018-07-20 21:49:02 --> UTF-8 Support Enabled
INFO - 2018-07-20 21:49:02 --> Utf8 Class Initialized
INFO - 2018-07-20 21:49:02 --> URI Class Initialized
INFO - 2018-07-20 21:49:02 --> Router Class Initialized
INFO - 2018-07-20 21:49:02 --> Output Class Initialized
INFO - 2018-07-20 21:49:02 --> Security Class Initialized
DEBUG - 2018-07-20 21:49:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 21:49:02 --> Input Class Initialized
INFO - 2018-07-20 21:49:02 --> Language Class Initialized
INFO - 2018-07-20 21:49:02 --> Language Class Initialized
INFO - 2018-07-20 21:49:02 --> Config Class Initialized
INFO - 2018-07-20 21:49:02 --> Loader Class Initialized
DEBUG - 2018-07-20 21:49:02 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-20 21:49:02 --> Helper loaded: url_helper
INFO - 2018-07-20 21:49:02 --> Helper loaded: form_helper
INFO - 2018-07-20 21:49:02 --> Helper loaded: date_helper
INFO - 2018-07-20 21:49:02 --> Helper loaded: util_helper
INFO - 2018-07-20 21:49:02 --> Helper loaded: text_helper
INFO - 2018-07-20 21:49:02 --> Helper loaded: string_helper
INFO - 2018-07-20 21:49:02 --> Database Driver Class Initialized
DEBUG - 2018-07-20 21:49:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-20 21:49:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-20 21:49:02 --> Email Class Initialized
INFO - 2018-07-20 21:49:02 --> Controller Class Initialized
DEBUG - 2018-07-20 21:49:02 --> Admin MX_Controller Initialized
INFO - 2018-07-20 21:49:02 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-20 21:49:02 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-20 21:49:02 --> Login MX_Controller Initialized
DEBUG - 2018-07-20 21:49:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-20 21:49:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-20 21:49:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
INFO - 2018-07-20 21:49:03 --> Config Class Initialized
INFO - 2018-07-20 21:49:03 --> Hooks Class Initialized
DEBUG - 2018-07-20 21:49:03 --> UTF-8 Support Enabled
INFO - 2018-07-20 21:49:03 --> Utf8 Class Initialized
INFO - 2018-07-20 21:49:03 --> URI Class Initialized
INFO - 2018-07-20 21:49:03 --> Router Class Initialized
INFO - 2018-07-20 21:49:03 --> Output Class Initialized
INFO - 2018-07-20 21:49:03 --> Security Class Initialized
DEBUG - 2018-07-20 21:49:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 21:49:03 --> Input Class Initialized
INFO - 2018-07-20 21:49:03 --> Language Class Initialized
ERROR - 2018-07-20 21:49:03 --> 404 Page Not Found: /index
INFO - 2018-07-20 21:49:04 --> Config Class Initialized
INFO - 2018-07-20 21:49:04 --> Hooks Class Initialized
DEBUG - 2018-07-20 21:49:04 --> UTF-8 Support Enabled
INFO - 2018-07-20 21:49:04 --> Utf8 Class Initialized
INFO - 2018-07-20 21:49:04 --> URI Class Initialized
INFO - 2018-07-20 21:49:04 --> Router Class Initialized
INFO - 2018-07-20 21:49:04 --> Output Class Initialized
INFO - 2018-07-20 21:49:04 --> Security Class Initialized
DEBUG - 2018-07-20 21:49:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 21:49:04 --> Input Class Initialized
INFO - 2018-07-20 21:49:04 --> Language Class Initialized
ERROR - 2018-07-20 21:49:04 --> 404 Page Not Found: /index
INFO - 2018-07-20 21:49:15 --> Config Class Initialized
INFO - 2018-07-20 21:49:15 --> Hooks Class Initialized
DEBUG - 2018-07-20 21:49:15 --> UTF-8 Support Enabled
INFO - 2018-07-20 21:49:15 --> Utf8 Class Initialized
INFO - 2018-07-20 21:49:15 --> URI Class Initialized
INFO - 2018-07-20 21:49:15 --> Router Class Initialized
INFO - 2018-07-20 21:49:15 --> Output Class Initialized
INFO - 2018-07-20 21:49:15 --> Security Class Initialized
DEBUG - 2018-07-20 21:49:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 21:49:15 --> Input Class Initialized
INFO - 2018-07-20 21:49:15 --> Language Class Initialized
INFO - 2018-07-20 21:49:15 --> Language Class Initialized
INFO - 2018-07-20 21:49:15 --> Config Class Initialized
INFO - 2018-07-20 21:49:16 --> Loader Class Initialized
DEBUG - 2018-07-20 21:49:16 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-20 21:49:16 --> Helper loaded: url_helper
INFO - 2018-07-20 21:49:16 --> Helper loaded: form_helper
INFO - 2018-07-20 21:49:16 --> Helper loaded: date_helper
INFO - 2018-07-20 21:49:16 --> Helper loaded: util_helper
INFO - 2018-07-20 21:49:16 --> Helper loaded: text_helper
INFO - 2018-07-20 21:49:16 --> Helper loaded: string_helper
INFO - 2018-07-20 21:49:16 --> Database Driver Class Initialized
DEBUG - 2018-07-20 21:49:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-20 21:49:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-20 21:49:16 --> Email Class Initialized
INFO - 2018-07-20 21:49:16 --> Controller Class Initialized
DEBUG - 2018-07-20 21:49:16 --> Login MX_Controller Initialized
INFO - 2018-07-20 21:49:16 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-20 21:49:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-20 21:49:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-20 21:49:16 --> Email starts for admin@colin.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-07-20 21:49:16 --> User session created for 1
INFO - 2018-07-20 21:49:16 --> Login status admin@colin.com - success
INFO - 2018-07-20 21:49:16 --> Final output sent to browser
DEBUG - 2018-07-20 21:49:16 --> Total execution time: 0.4728
INFO - 2018-07-20 21:49:16 --> Config Class Initialized
INFO - 2018-07-20 21:49:16 --> Hooks Class Initialized
DEBUG - 2018-07-20 21:49:16 --> UTF-8 Support Enabled
INFO - 2018-07-20 21:49:16 --> Utf8 Class Initialized
INFO - 2018-07-20 21:49:16 --> URI Class Initialized
INFO - 2018-07-20 21:49:16 --> Router Class Initialized
INFO - 2018-07-20 21:49:16 --> Output Class Initialized
INFO - 2018-07-20 21:49:16 --> Security Class Initialized
DEBUG - 2018-07-20 21:49:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 21:49:16 --> Input Class Initialized
INFO - 2018-07-20 21:49:16 --> Language Class Initialized
INFO - 2018-07-20 21:49:16 --> Language Class Initialized
INFO - 2018-07-20 21:49:16 --> Config Class Initialized
INFO - 2018-07-20 21:49:16 --> Loader Class Initialized
DEBUG - 2018-07-20 21:49:16 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-20 21:49:16 --> Helper loaded: url_helper
INFO - 2018-07-20 21:49:16 --> Helper loaded: form_helper
INFO - 2018-07-20 21:49:16 --> Helper loaded: date_helper
INFO - 2018-07-20 21:49:16 --> Helper loaded: util_helper
INFO - 2018-07-20 21:49:16 --> Helper loaded: text_helper
INFO - 2018-07-20 21:49:16 --> Helper loaded: string_helper
INFO - 2018-07-20 21:49:16 --> Database Driver Class Initialized
DEBUG - 2018-07-20 21:49:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-20 21:49:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-20 21:49:16 --> Email Class Initialized
INFO - 2018-07-20 21:49:16 --> Controller Class Initialized
DEBUG - 2018-07-20 21:49:16 --> Admin MX_Controller Initialized
INFO - 2018-07-20 21:49:16 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-20 21:49:16 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-20 21:49:16 --> Login MX_Controller Initialized
DEBUG - 2018-07-20 21:49:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-20 21:49:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-20 21:49:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-20 21:49:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-20 21:49:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-20 21:49:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-20 21:49:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-20 21:49:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/dashboard.php
INFO - 2018-07-20 21:49:17 --> Final output sent to browser
DEBUG - 2018-07-20 21:49:17 --> Total execution time: 0.8592
INFO - 2018-07-20 21:49:17 --> Config Class Initialized
INFO - 2018-07-20 21:49:17 --> Hooks Class Initialized
DEBUG - 2018-07-20 21:49:17 --> UTF-8 Support Enabled
INFO - 2018-07-20 21:49:17 --> Utf8 Class Initialized
INFO - 2018-07-20 21:49:17 --> URI Class Initialized
INFO - 2018-07-20 21:49:17 --> Router Class Initialized
INFO - 2018-07-20 21:49:17 --> Output Class Initialized
INFO - 2018-07-20 21:49:17 --> Security Class Initialized
DEBUG - 2018-07-20 21:49:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 21:49:17 --> Input Class Initialized
INFO - 2018-07-20 21:49:17 --> Language Class Initialized
ERROR - 2018-07-20 21:49:17 --> 404 Page Not Found: /index
INFO - 2018-07-20 21:49:18 --> Config Class Initialized
INFO - 2018-07-20 21:49:18 --> Hooks Class Initialized
DEBUG - 2018-07-20 21:49:18 --> UTF-8 Support Enabled
INFO - 2018-07-20 21:49:18 --> Utf8 Class Initialized
INFO - 2018-07-20 21:49:18 --> URI Class Initialized
INFO - 2018-07-20 21:49:18 --> Router Class Initialized
INFO - 2018-07-20 21:49:18 --> Output Class Initialized
INFO - 2018-07-20 21:49:18 --> Security Class Initialized
DEBUG - 2018-07-20 21:49:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 21:49:18 --> Input Class Initialized
INFO - 2018-07-20 21:49:18 --> Language Class Initialized
ERROR - 2018-07-20 21:49:18 --> 404 Page Not Found: /index
INFO - 2018-07-20 21:52:11 --> Config Class Initialized
INFO - 2018-07-20 21:52:11 --> Hooks Class Initialized
DEBUG - 2018-07-20 21:52:12 --> UTF-8 Support Enabled
INFO - 2018-07-20 21:52:12 --> Utf8 Class Initialized
INFO - 2018-07-20 21:52:12 --> URI Class Initialized
INFO - 2018-07-20 21:52:12 --> Router Class Initialized
INFO - 2018-07-20 21:52:12 --> Output Class Initialized
INFO - 2018-07-20 21:52:12 --> Security Class Initialized
DEBUG - 2018-07-20 21:52:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 21:52:12 --> Input Class Initialized
INFO - 2018-07-20 21:52:12 --> Language Class Initialized
INFO - 2018-07-20 21:52:12 --> Language Class Initialized
INFO - 2018-07-20 21:52:12 --> Config Class Initialized
INFO - 2018-07-20 21:52:12 --> Loader Class Initialized
DEBUG - 2018-07-20 21:52:12 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-20 21:52:12 --> Helper loaded: url_helper
INFO - 2018-07-20 21:52:12 --> Helper loaded: form_helper
INFO - 2018-07-20 21:52:12 --> Helper loaded: date_helper
INFO - 2018-07-20 21:52:12 --> Helper loaded: util_helper
INFO - 2018-07-20 21:52:12 --> Helper loaded: text_helper
INFO - 2018-07-20 21:52:12 --> Helper loaded: string_helper
INFO - 2018-07-20 21:52:12 --> Database Driver Class Initialized
DEBUG - 2018-07-20 21:52:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-20 21:52:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-20 21:52:12 --> Email Class Initialized
INFO - 2018-07-20 21:52:12 --> Controller Class Initialized
DEBUG - 2018-07-20 21:52:12 --> Users MX_Controller Initialized
DEBUG - 2018-07-20 21:52:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-20 21:52:12 --> Helper loaded: file_helper
DEBUG - 2018-07-20 21:52:12 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-20 21:52:12 --> Login MX_Controller Initialized
INFO - 2018-07-20 21:52:12 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-20 21:52:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-20 21:52:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-20 21:52:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-20 21:52:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-20 21:52:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-20 21:52:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-20 21:52:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-07-20 21:52:13 --> Final output sent to browser
DEBUG - 2018-07-20 21:52:13 --> Total execution time: 1.2523
INFO - 2018-07-20 21:52:13 --> Config Class Initialized
INFO - 2018-07-20 21:52:13 --> Hooks Class Initialized
DEBUG - 2018-07-20 21:52:13 --> UTF-8 Support Enabled
INFO - 2018-07-20 21:52:13 --> Utf8 Class Initialized
INFO - 2018-07-20 21:52:13 --> URI Class Initialized
INFO - 2018-07-20 21:52:13 --> Router Class Initialized
INFO - 2018-07-20 21:52:13 --> Output Class Initialized
INFO - 2018-07-20 21:52:13 --> Security Class Initialized
DEBUG - 2018-07-20 21:52:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 21:52:13 --> Input Class Initialized
INFO - 2018-07-20 21:52:13 --> Language Class Initialized
INFO - 2018-07-20 21:52:13 --> Language Class Initialized
INFO - 2018-07-20 21:52:13 --> Config Class Initialized
INFO - 2018-07-20 21:52:13 --> Loader Class Initialized
DEBUG - 2018-07-20 21:52:13 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-20 21:52:13 --> Helper loaded: url_helper
INFO - 2018-07-20 21:52:13 --> Helper loaded: form_helper
INFO - 2018-07-20 21:52:13 --> Helper loaded: date_helper
INFO - 2018-07-20 21:52:13 --> Helper loaded: util_helper
INFO - 2018-07-20 21:52:13 --> Helper loaded: text_helper
INFO - 2018-07-20 21:52:13 --> Helper loaded: string_helper
INFO - 2018-07-20 21:52:13 --> Database Driver Class Initialized
DEBUG - 2018-07-20 21:52:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-20 21:52:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-20 21:52:13 --> Email Class Initialized
INFO - 2018-07-20 21:52:13 --> Controller Class Initialized
DEBUG - 2018-07-20 21:52:13 --> Users MX_Controller Initialized
DEBUG - 2018-07-20 21:52:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-20 21:52:13 --> Helper loaded: file_helper
DEBUG - 2018-07-20 21:52:13 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-20 21:52:13 --> Login MX_Controller Initialized
INFO - 2018-07-20 21:52:13 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-20 21:52:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-20 21:52:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-20 21:52:14 --> Final output sent to browser
DEBUG - 2018-07-20 21:52:14 --> Total execution time: 0.5098
INFO - 2018-07-20 21:52:17 --> Config Class Initialized
INFO - 2018-07-20 21:52:17 --> Hooks Class Initialized
DEBUG - 2018-07-20 21:52:17 --> UTF-8 Support Enabled
INFO - 2018-07-20 21:52:17 --> Utf8 Class Initialized
INFO - 2018-07-20 21:52:18 --> URI Class Initialized
INFO - 2018-07-20 21:52:18 --> Router Class Initialized
INFO - 2018-07-20 21:52:18 --> Output Class Initialized
INFO - 2018-07-20 21:52:18 --> Security Class Initialized
DEBUG - 2018-07-20 21:52:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 21:52:18 --> Input Class Initialized
INFO - 2018-07-20 21:52:18 --> Language Class Initialized
INFO - 2018-07-20 21:52:18 --> Language Class Initialized
INFO - 2018-07-20 21:52:18 --> Config Class Initialized
INFO - 2018-07-20 21:52:18 --> Loader Class Initialized
DEBUG - 2018-07-20 21:52:18 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-20 21:52:18 --> Helper loaded: url_helper
INFO - 2018-07-20 21:52:18 --> Helper loaded: form_helper
INFO - 2018-07-20 21:52:18 --> Helper loaded: date_helper
INFO - 2018-07-20 21:52:18 --> Helper loaded: util_helper
INFO - 2018-07-20 21:52:18 --> Helper loaded: text_helper
INFO - 2018-07-20 21:52:18 --> Helper loaded: string_helper
INFO - 2018-07-20 21:52:18 --> Database Driver Class Initialized
DEBUG - 2018-07-20 21:52:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-20 21:52:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-20 21:52:18 --> Email Class Initialized
INFO - 2018-07-20 21:52:18 --> Controller Class Initialized
DEBUG - 2018-07-20 21:52:18 --> Users MX_Controller Initialized
DEBUG - 2018-07-20 21:52:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-20 21:52:18 --> Helper loaded: file_helper
DEBUG - 2018-07-20 21:52:18 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-20 21:52:18 --> Login MX_Controller Initialized
INFO - 2018-07-20 21:52:18 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-20 21:52:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-20 21:52:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
DEBUG - 2018-07-20 21:52:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-20 21:52:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-20 21:52:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-20 21:52:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-20 21:52:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-20 21:52:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-20 21:52:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-07-20 21:52:18 --> Final output sent to browser
DEBUG - 2018-07-20 21:52:18 --> Total execution time: 0.5412
