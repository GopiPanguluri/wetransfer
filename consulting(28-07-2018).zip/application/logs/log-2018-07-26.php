<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-07-26 02:57:56 --> Config Class Initialized
INFO - 2018-07-26 02:57:56 --> Hooks Class Initialized
DEBUG - 2018-07-26 02:57:56 --> UTF-8 Support Enabled
INFO - 2018-07-26 02:57:56 --> Utf8 Class Initialized
INFO - 2018-07-26 02:57:56 --> URI Class Initialized
INFO - 2018-07-26 02:57:56 --> Router Class Initialized
INFO - 2018-07-26 02:57:56 --> Output Class Initialized
INFO - 2018-07-26 02:57:56 --> Security Class Initialized
DEBUG - 2018-07-26 02:57:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 02:57:56 --> Input Class Initialized
INFO - 2018-07-26 02:57:56 --> Language Class Initialized
INFO - 2018-07-26 02:57:56 --> Language Class Initialized
INFO - 2018-07-26 02:57:56 --> Config Class Initialized
INFO - 2018-07-26 02:57:56 --> Loader Class Initialized
DEBUG - 2018-07-26 02:57:56 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-26 02:57:56 --> Helper loaded: url_helper
INFO - 2018-07-26 02:57:56 --> Helper loaded: form_helper
INFO - 2018-07-26 02:57:56 --> Helper loaded: date_helper
INFO - 2018-07-26 02:57:56 --> Helper loaded: util_helper
INFO - 2018-07-26 02:57:56 --> Helper loaded: text_helper
INFO - 2018-07-26 02:57:56 --> Helper loaded: string_helper
INFO - 2018-07-26 02:57:56 --> Database Driver Class Initialized
DEBUG - 2018-07-26 02:57:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 02:57:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 02:57:56 --> Email Class Initialized
INFO - 2018-07-26 02:57:56 --> Controller Class Initialized
DEBUG - 2018-07-26 02:57:56 --> Users MX_Controller Initialized
DEBUG - 2018-07-26 02:57:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-26 02:57:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-26 02:57:56 --> Helper loaded: file_helper
DEBUG - 2018-07-26 02:57:56 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-26 02:57:56 --> Login MX_Controller Initialized
INFO - 2018-07-26 02:57:56 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-26 02:57:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-26 02:57:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
INFO - 2018-07-26 02:57:57 --> Config Class Initialized
INFO - 2018-07-26 02:57:57 --> Hooks Class Initialized
DEBUG - 2018-07-26 02:57:57 --> UTF-8 Support Enabled
INFO - 2018-07-26 02:57:57 --> Utf8 Class Initialized
INFO - 2018-07-26 02:57:57 --> URI Class Initialized
INFO - 2018-07-26 02:57:57 --> Router Class Initialized
INFO - 2018-07-26 02:57:57 --> Output Class Initialized
INFO - 2018-07-26 02:57:57 --> Security Class Initialized
DEBUG - 2018-07-26 02:57:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 02:57:57 --> Input Class Initialized
INFO - 2018-07-26 02:57:57 --> Language Class Initialized
ERROR - 2018-07-26 02:57:57 --> 404 Page Not Found: /index
INFO - 2018-07-26 02:57:57 --> Config Class Initialized
INFO - 2018-07-26 02:57:57 --> Hooks Class Initialized
DEBUG - 2018-07-26 02:57:57 --> UTF-8 Support Enabled
INFO - 2018-07-26 02:57:57 --> Utf8 Class Initialized
INFO - 2018-07-26 02:57:57 --> URI Class Initialized
INFO - 2018-07-26 02:57:57 --> Router Class Initialized
INFO - 2018-07-26 02:57:57 --> Output Class Initialized
INFO - 2018-07-26 02:57:57 --> Security Class Initialized
DEBUG - 2018-07-26 02:57:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 02:57:57 --> Input Class Initialized
INFO - 2018-07-26 02:57:57 --> Language Class Initialized
ERROR - 2018-07-26 02:57:57 --> 404 Page Not Found: /index
INFO - 2018-07-26 02:58:01 --> Config Class Initialized
INFO - 2018-07-26 02:58:01 --> Hooks Class Initialized
DEBUG - 2018-07-26 02:58:01 --> UTF-8 Support Enabled
INFO - 2018-07-26 02:58:01 --> Utf8 Class Initialized
INFO - 2018-07-26 02:58:01 --> URI Class Initialized
INFO - 2018-07-26 02:58:01 --> Router Class Initialized
INFO - 2018-07-26 02:58:01 --> Output Class Initialized
INFO - 2018-07-26 02:58:01 --> Security Class Initialized
DEBUG - 2018-07-26 02:58:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 02:58:01 --> Input Class Initialized
INFO - 2018-07-26 02:58:01 --> Language Class Initialized
INFO - 2018-07-26 02:58:02 --> Language Class Initialized
INFO - 2018-07-26 02:58:02 --> Config Class Initialized
INFO - 2018-07-26 02:58:02 --> Loader Class Initialized
DEBUG - 2018-07-26 02:58:02 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-26 02:58:02 --> Helper loaded: url_helper
INFO - 2018-07-26 02:58:02 --> Helper loaded: form_helper
INFO - 2018-07-26 02:58:02 --> Helper loaded: date_helper
INFO - 2018-07-26 02:58:02 --> Helper loaded: util_helper
INFO - 2018-07-26 02:58:02 --> Helper loaded: text_helper
INFO - 2018-07-26 02:58:02 --> Helper loaded: string_helper
INFO - 2018-07-26 02:58:02 --> Database Driver Class Initialized
DEBUG - 2018-07-26 02:58:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 02:58:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 02:58:02 --> Email Class Initialized
INFO - 2018-07-26 02:58:02 --> Controller Class Initialized
DEBUG - 2018-07-26 02:58:02 --> Login MX_Controller Initialized
INFO - 2018-07-26 02:58:02 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-26 02:58:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-26 02:58:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-26 02:58:02 --> Email starts for admin@colin.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-07-26 02:58:02 --> User session created for 1
INFO - 2018-07-26 02:58:02 --> Login status admin@colin.com - success
INFO - 2018-07-26 02:58:02 --> Final output sent to browser
DEBUG - 2018-07-26 02:58:02 --> Total execution time: 0.5665
INFO - 2018-07-26 02:58:02 --> Config Class Initialized
INFO - 2018-07-26 02:58:02 --> Hooks Class Initialized
DEBUG - 2018-07-26 02:58:02 --> UTF-8 Support Enabled
INFO - 2018-07-26 02:58:02 --> Utf8 Class Initialized
INFO - 2018-07-26 02:58:02 --> URI Class Initialized
INFO - 2018-07-26 02:58:02 --> Router Class Initialized
INFO - 2018-07-26 02:58:02 --> Output Class Initialized
INFO - 2018-07-26 02:58:02 --> Security Class Initialized
DEBUG - 2018-07-26 02:58:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 02:58:02 --> Input Class Initialized
INFO - 2018-07-26 02:58:02 --> Language Class Initialized
INFO - 2018-07-26 02:58:02 --> Language Class Initialized
INFO - 2018-07-26 02:58:02 --> Config Class Initialized
INFO - 2018-07-26 02:58:02 --> Loader Class Initialized
DEBUG - 2018-07-26 02:58:02 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-26 02:58:02 --> Helper loaded: url_helper
INFO - 2018-07-26 02:58:02 --> Helper loaded: form_helper
INFO - 2018-07-26 02:58:02 --> Helper loaded: date_helper
INFO - 2018-07-26 02:58:02 --> Helper loaded: util_helper
INFO - 2018-07-26 02:58:02 --> Helper loaded: text_helper
INFO - 2018-07-26 02:58:02 --> Helper loaded: string_helper
INFO - 2018-07-26 02:58:02 --> Database Driver Class Initialized
DEBUG - 2018-07-26 02:58:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 02:58:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 02:58:02 --> Email Class Initialized
INFO - 2018-07-26 02:58:02 --> Controller Class Initialized
DEBUG - 2018-07-26 02:58:02 --> Users MX_Controller Initialized
DEBUG - 2018-07-26 02:58:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-26 02:58:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-26 02:58:02 --> Helper loaded: file_helper
DEBUG - 2018-07-26 02:58:02 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-26 02:58:02 --> Login MX_Controller Initialized
INFO - 2018-07-26 02:58:03 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-26 02:58:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-26 02:58:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-26 02:58:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-26 02:58:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-26 02:58:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-26 02:58:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-26 02:58:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-07-26 02:58:03 --> Final output sent to browser
DEBUG - 2018-07-26 02:58:03 --> Total execution time: 0.6036
INFO - 2018-07-26 02:58:05 --> Config Class Initialized
INFO - 2018-07-26 02:58:05 --> Hooks Class Initialized
DEBUG - 2018-07-26 02:58:05 --> UTF-8 Support Enabled
INFO - 2018-07-26 02:58:05 --> Utf8 Class Initialized
INFO - 2018-07-26 02:58:05 --> URI Class Initialized
INFO - 2018-07-26 02:58:05 --> Router Class Initialized
INFO - 2018-07-26 02:58:05 --> Output Class Initialized
INFO - 2018-07-26 02:58:05 --> Security Class Initialized
DEBUG - 2018-07-26 02:58:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 02:58:05 --> Input Class Initialized
INFO - 2018-07-26 02:58:05 --> Language Class Initialized
INFO - 2018-07-26 02:58:05 --> Language Class Initialized
INFO - 2018-07-26 02:58:05 --> Config Class Initialized
INFO - 2018-07-26 02:58:05 --> Loader Class Initialized
DEBUG - 2018-07-26 02:58:05 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-26 02:58:05 --> Helper loaded: url_helper
INFO - 2018-07-26 02:58:05 --> Helper loaded: form_helper
INFO - 2018-07-26 02:58:05 --> Helper loaded: date_helper
INFO - 2018-07-26 02:58:05 --> Helper loaded: util_helper
INFO - 2018-07-26 02:58:05 --> Helper loaded: text_helper
INFO - 2018-07-26 02:58:05 --> Helper loaded: string_helper
INFO - 2018-07-26 02:58:05 --> Database Driver Class Initialized
DEBUG - 2018-07-26 02:58:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 02:58:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 02:58:05 --> Email Class Initialized
INFO - 2018-07-26 02:58:05 --> Controller Class Initialized
DEBUG - 2018-07-26 02:58:05 --> Users MX_Controller Initialized
DEBUG - 2018-07-26 02:58:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-26 02:58:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-26 02:58:05 --> Helper loaded: file_helper
DEBUG - 2018-07-26 02:58:05 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-26 02:58:05 --> Login MX_Controller Initialized
INFO - 2018-07-26 02:58:05 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-26 02:58:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-26 02:58:05 --> Final output sent to browser
DEBUG - 2018-07-26 02:58:06 --> Total execution time: 0.9422
INFO - 2018-07-26 02:58:36 --> Config Class Initialized
INFO - 2018-07-26 02:58:36 --> Hooks Class Initialized
DEBUG - 2018-07-26 02:58:36 --> UTF-8 Support Enabled
INFO - 2018-07-26 02:58:36 --> Utf8 Class Initialized
INFO - 2018-07-26 02:58:36 --> URI Class Initialized
INFO - 2018-07-26 02:58:36 --> Router Class Initialized
INFO - 2018-07-26 02:58:36 --> Output Class Initialized
INFO - 2018-07-26 02:58:36 --> Security Class Initialized
DEBUG - 2018-07-26 02:58:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 02:58:36 --> Input Class Initialized
INFO - 2018-07-26 02:58:36 --> Language Class Initialized
INFO - 2018-07-26 02:58:36 --> Language Class Initialized
INFO - 2018-07-26 02:58:36 --> Config Class Initialized
INFO - 2018-07-26 02:58:36 --> Loader Class Initialized
DEBUG - 2018-07-26 02:58:36 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-26 02:58:36 --> Helper loaded: url_helper
INFO - 2018-07-26 02:58:36 --> Helper loaded: form_helper
INFO - 2018-07-26 02:58:36 --> Helper loaded: date_helper
INFO - 2018-07-26 02:58:36 --> Helper loaded: util_helper
INFO - 2018-07-26 02:58:36 --> Helper loaded: text_helper
INFO - 2018-07-26 02:58:36 --> Helper loaded: string_helper
INFO - 2018-07-26 02:58:36 --> Database Driver Class Initialized
DEBUG - 2018-07-26 02:58:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 02:58:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 02:58:36 --> Email Class Initialized
INFO - 2018-07-26 02:58:36 --> Controller Class Initialized
DEBUG - 2018-07-26 02:58:36 --> Users MX_Controller Initialized
DEBUG - 2018-07-26 02:58:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-26 02:58:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-26 02:58:36 --> Helper loaded: file_helper
DEBUG - 2018-07-26 02:58:36 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-26 02:58:36 --> Login MX_Controller Initialized
INFO - 2018-07-26 02:58:36 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-26 02:58:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-26 02:58:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-26 02:58:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-26 02:58:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-26 02:58:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-26 02:58:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-26 02:58:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-07-26 02:58:36 --> Final output sent to browser
DEBUG - 2018-07-26 02:58:36 --> Total execution time: 0.3920
INFO - 2018-07-26 02:58:37 --> Config Class Initialized
INFO - 2018-07-26 02:58:37 --> Hooks Class Initialized
DEBUG - 2018-07-26 02:58:37 --> UTF-8 Support Enabled
INFO - 2018-07-26 02:58:37 --> Utf8 Class Initialized
INFO - 2018-07-26 02:58:37 --> URI Class Initialized
INFO - 2018-07-26 02:58:37 --> Router Class Initialized
INFO - 2018-07-26 02:58:37 --> Output Class Initialized
INFO - 2018-07-26 02:58:37 --> Security Class Initialized
DEBUG - 2018-07-26 02:58:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 02:58:37 --> Input Class Initialized
INFO - 2018-07-26 02:58:37 --> Language Class Initialized
INFO - 2018-07-26 02:58:37 --> Language Class Initialized
INFO - 2018-07-26 02:58:37 --> Config Class Initialized
INFO - 2018-07-26 02:58:37 --> Loader Class Initialized
DEBUG - 2018-07-26 02:58:37 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-26 02:58:37 --> Helper loaded: url_helper
INFO - 2018-07-26 02:58:37 --> Helper loaded: form_helper
INFO - 2018-07-26 02:58:37 --> Helper loaded: date_helper
INFO - 2018-07-26 02:58:37 --> Helper loaded: util_helper
INFO - 2018-07-26 02:58:37 --> Helper loaded: text_helper
INFO - 2018-07-26 02:58:37 --> Helper loaded: string_helper
INFO - 2018-07-26 02:58:37 --> Database Driver Class Initialized
DEBUG - 2018-07-26 02:58:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 02:58:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 02:58:37 --> Email Class Initialized
INFO - 2018-07-26 02:58:37 --> Controller Class Initialized
DEBUG - 2018-07-26 02:58:37 --> Users MX_Controller Initialized
DEBUG - 2018-07-26 02:58:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-26 02:58:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-26 02:58:37 --> Helper loaded: file_helper
DEBUG - 2018-07-26 02:58:37 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-26 02:58:37 --> Login MX_Controller Initialized
INFO - 2018-07-26 02:58:37 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-26 02:58:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-26 02:58:37 --> Final output sent to browser
DEBUG - 2018-07-26 02:58:37 --> Total execution time: 0.4894
INFO - 2018-07-26 02:58:43 --> Config Class Initialized
INFO - 2018-07-26 02:58:43 --> Hooks Class Initialized
DEBUG - 2018-07-26 02:58:43 --> UTF-8 Support Enabled
INFO - 2018-07-26 02:58:43 --> Utf8 Class Initialized
INFO - 2018-07-26 02:58:43 --> URI Class Initialized
INFO - 2018-07-26 02:58:43 --> Router Class Initialized
INFO - 2018-07-26 02:58:43 --> Output Class Initialized
INFO - 2018-07-26 02:58:43 --> Security Class Initialized
DEBUG - 2018-07-26 02:58:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 02:58:43 --> Input Class Initialized
INFO - 2018-07-26 02:58:43 --> Language Class Initialized
INFO - 2018-07-26 02:58:43 --> Language Class Initialized
INFO - 2018-07-26 02:58:43 --> Config Class Initialized
INFO - 2018-07-26 02:58:43 --> Loader Class Initialized
DEBUG - 2018-07-26 02:58:43 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-26 02:58:43 --> Helper loaded: url_helper
INFO - 2018-07-26 02:58:43 --> Helper loaded: form_helper
INFO - 2018-07-26 02:58:43 --> Helper loaded: date_helper
INFO - 2018-07-26 02:58:43 --> Helper loaded: util_helper
INFO - 2018-07-26 02:58:43 --> Helper loaded: text_helper
INFO - 2018-07-26 02:58:43 --> Helper loaded: string_helper
INFO - 2018-07-26 02:58:43 --> Database Driver Class Initialized
DEBUG - 2018-07-26 02:58:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 02:58:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 02:58:43 --> Email Class Initialized
INFO - 2018-07-26 02:58:43 --> Controller Class Initialized
DEBUG - 2018-07-26 02:58:43 --> Login MX_Controller Initialized
INFO - 2018-07-26 02:58:43 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-26 02:58:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-26 02:58:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-26 02:58:44 --> 1 Loggedout
INFO - 2018-07-26 02:58:44 --> Config Class Initialized
INFO - 2018-07-26 02:58:44 --> Hooks Class Initialized
DEBUG - 2018-07-26 02:58:44 --> UTF-8 Support Enabled
INFO - 2018-07-26 02:58:44 --> Utf8 Class Initialized
INFO - 2018-07-26 02:58:44 --> URI Class Initialized
INFO - 2018-07-26 02:58:44 --> Router Class Initialized
INFO - 2018-07-26 02:58:44 --> Output Class Initialized
INFO - 2018-07-26 02:58:44 --> Security Class Initialized
DEBUG - 2018-07-26 02:58:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 02:58:44 --> Input Class Initialized
INFO - 2018-07-26 02:58:44 --> Language Class Initialized
INFO - 2018-07-26 02:58:44 --> Language Class Initialized
INFO - 2018-07-26 02:58:44 --> Config Class Initialized
INFO - 2018-07-26 02:58:44 --> Loader Class Initialized
DEBUG - 2018-07-26 02:58:44 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-26 02:58:44 --> Helper loaded: url_helper
INFO - 2018-07-26 02:58:44 --> Helper loaded: form_helper
INFO - 2018-07-26 02:58:44 --> Helper loaded: date_helper
INFO - 2018-07-26 02:58:44 --> Helper loaded: util_helper
INFO - 2018-07-26 02:58:44 --> Helper loaded: text_helper
INFO - 2018-07-26 02:58:44 --> Helper loaded: string_helper
INFO - 2018-07-26 02:58:44 --> Database Driver Class Initialized
DEBUG - 2018-07-26 02:58:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 02:58:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 02:58:44 --> Email Class Initialized
INFO - 2018-07-26 02:58:44 --> Controller Class Initialized
DEBUG - 2018-07-26 02:58:44 --> Admin MX_Controller Initialized
INFO - 2018-07-26 02:58:44 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-26 02:58:44 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-26 02:58:44 --> Login MX_Controller Initialized
DEBUG - 2018-07-26 02:58:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-26 02:58:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-26 02:58:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
INFO - 2018-07-26 02:58:44 --> Config Class Initialized
INFO - 2018-07-26 02:58:44 --> Hooks Class Initialized
DEBUG - 2018-07-26 02:58:44 --> UTF-8 Support Enabled
INFO - 2018-07-26 02:58:44 --> Utf8 Class Initialized
INFO - 2018-07-26 02:58:44 --> URI Class Initialized
INFO - 2018-07-26 02:58:44 --> Router Class Initialized
INFO - 2018-07-26 02:58:44 --> Output Class Initialized
INFO - 2018-07-26 02:58:44 --> Security Class Initialized
DEBUG - 2018-07-26 02:58:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 02:58:44 --> Input Class Initialized
INFO - 2018-07-26 02:58:44 --> Language Class Initialized
ERROR - 2018-07-26 02:58:44 --> 404 Page Not Found: /index
INFO - 2018-07-26 02:58:48 --> Config Class Initialized
INFO - 2018-07-26 02:58:48 --> Hooks Class Initialized
DEBUG - 2018-07-26 02:58:48 --> UTF-8 Support Enabled
INFO - 2018-07-26 02:58:48 --> Utf8 Class Initialized
INFO - 2018-07-26 02:58:48 --> URI Class Initialized
INFO - 2018-07-26 02:58:48 --> Router Class Initialized
INFO - 2018-07-26 02:58:48 --> Output Class Initialized
INFO - 2018-07-26 02:58:48 --> Security Class Initialized
DEBUG - 2018-07-26 02:58:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 02:58:48 --> Input Class Initialized
INFO - 2018-07-26 02:58:48 --> Language Class Initialized
INFO - 2018-07-26 02:58:48 --> Language Class Initialized
INFO - 2018-07-26 02:58:48 --> Config Class Initialized
INFO - 2018-07-26 02:58:48 --> Loader Class Initialized
DEBUG - 2018-07-26 02:58:48 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-26 02:58:48 --> Helper loaded: url_helper
INFO - 2018-07-26 02:58:48 --> Helper loaded: form_helper
INFO - 2018-07-26 02:58:48 --> Helper loaded: date_helper
INFO - 2018-07-26 02:58:48 --> Helper loaded: util_helper
INFO - 2018-07-26 02:58:48 --> Helper loaded: text_helper
INFO - 2018-07-26 02:58:48 --> Helper loaded: string_helper
INFO - 2018-07-26 02:58:48 --> Database Driver Class Initialized
DEBUG - 2018-07-26 02:58:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 02:58:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 02:58:48 --> Email Class Initialized
INFO - 2018-07-26 02:58:48 --> Controller Class Initialized
DEBUG - 2018-07-26 02:58:48 --> Login MX_Controller Initialized
INFO - 2018-07-26 02:58:48 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-26 02:58:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-26 02:58:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-26 02:58:48 --> Email starts for gopi.lion123@gmail.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-07-26 02:58:48 --> User session created for 6
INFO - 2018-07-26 02:58:48 --> Login status gopi.lion123@gmail.com - success
INFO - 2018-07-26 02:58:48 --> Final output sent to browser
DEBUG - 2018-07-26 02:58:48 --> Total execution time: 0.3403
INFO - 2018-07-26 02:58:48 --> Config Class Initialized
INFO - 2018-07-26 02:58:48 --> Hooks Class Initialized
DEBUG - 2018-07-26 02:58:48 --> UTF-8 Support Enabled
INFO - 2018-07-26 02:58:48 --> Utf8 Class Initialized
INFO - 2018-07-26 02:58:48 --> URI Class Initialized
INFO - 2018-07-26 02:58:48 --> Router Class Initialized
INFO - 2018-07-26 02:58:48 --> Output Class Initialized
INFO - 2018-07-26 02:58:48 --> Security Class Initialized
DEBUG - 2018-07-26 02:58:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 02:58:48 --> Input Class Initialized
INFO - 2018-07-26 02:58:48 --> Language Class Initialized
INFO - 2018-07-26 02:58:48 --> Language Class Initialized
INFO - 2018-07-26 02:58:48 --> Config Class Initialized
INFO - 2018-07-26 02:58:48 --> Loader Class Initialized
DEBUG - 2018-07-26 02:58:48 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-26 02:58:48 --> Helper loaded: url_helper
INFO - 2018-07-26 02:58:48 --> Helper loaded: form_helper
INFO - 2018-07-26 02:58:48 --> Helper loaded: date_helper
INFO - 2018-07-26 02:58:48 --> Helper loaded: util_helper
INFO - 2018-07-26 02:58:48 --> Helper loaded: text_helper
INFO - 2018-07-26 02:58:48 --> Helper loaded: string_helper
INFO - 2018-07-26 02:58:48 --> Database Driver Class Initialized
DEBUG - 2018-07-26 02:58:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 02:58:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 02:58:48 --> Email Class Initialized
INFO - 2018-07-26 02:58:48 --> Controller Class Initialized
DEBUG - 2018-07-26 02:58:48 --> Admin MX_Controller Initialized
INFO - 2018-07-26 02:58:48 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-26 02:58:48 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-26 02:58:48 --> Login MX_Controller Initialized
DEBUG - 2018-07-26 02:58:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-26 02:58:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-26 02:58:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-26 02:58:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-26 02:58:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-26 02:58:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-26 02:58:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-26 02:58:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/dashboard.php
INFO - 2018-07-26 02:58:48 --> Final output sent to browser
DEBUG - 2018-07-26 02:58:48 --> Total execution time: 0.3939
INFO - 2018-07-26 02:58:49 --> Config Class Initialized
INFO - 2018-07-26 02:58:49 --> Hooks Class Initialized
DEBUG - 2018-07-26 02:58:49 --> UTF-8 Support Enabled
INFO - 2018-07-26 02:58:49 --> Utf8 Class Initialized
INFO - 2018-07-26 02:58:49 --> URI Class Initialized
INFO - 2018-07-26 02:58:49 --> Router Class Initialized
INFO - 2018-07-26 02:58:49 --> Config Class Initialized
INFO - 2018-07-26 02:58:49 --> Hooks Class Initialized
INFO - 2018-07-26 02:58:49 --> Output Class Initialized
INFO - 2018-07-26 02:58:49 --> Security Class Initialized
DEBUG - 2018-07-26 02:58:49 --> UTF-8 Support Enabled
DEBUG - 2018-07-26 02:58:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 02:58:49 --> Input Class Initialized
INFO - 2018-07-26 02:58:49 --> Utf8 Class Initialized
INFO - 2018-07-26 02:58:49 --> Language Class Initialized
INFO - 2018-07-26 02:58:49 --> URI Class Initialized
ERROR - 2018-07-26 02:58:49 --> 404 Page Not Found: /index
INFO - 2018-07-26 02:58:49 --> Router Class Initialized
INFO - 2018-07-26 02:58:49 --> Output Class Initialized
INFO - 2018-07-26 02:58:49 --> Security Class Initialized
DEBUG - 2018-07-26 02:58:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 02:58:49 --> Input Class Initialized
INFO - 2018-07-26 02:58:49 --> Language Class Initialized
ERROR - 2018-07-26 02:58:49 --> 404 Page Not Found: /index
INFO - 2018-07-26 02:58:51 --> Config Class Initialized
INFO - 2018-07-26 02:58:51 --> Hooks Class Initialized
DEBUG - 2018-07-26 02:58:51 --> UTF-8 Support Enabled
INFO - 2018-07-26 02:58:51 --> Utf8 Class Initialized
INFO - 2018-07-26 02:58:51 --> URI Class Initialized
INFO - 2018-07-26 02:58:51 --> Router Class Initialized
INFO - 2018-07-26 02:58:51 --> Output Class Initialized
INFO - 2018-07-26 02:58:51 --> Security Class Initialized
DEBUG - 2018-07-26 02:58:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 02:58:51 --> Input Class Initialized
INFO - 2018-07-26 02:58:51 --> Language Class Initialized
INFO - 2018-07-26 02:58:51 --> Language Class Initialized
INFO - 2018-07-26 02:58:51 --> Config Class Initialized
INFO - 2018-07-26 02:58:51 --> Loader Class Initialized
DEBUG - 2018-07-26 02:58:51 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-26 02:58:51 --> Helper loaded: url_helper
INFO - 2018-07-26 02:58:51 --> Helper loaded: form_helper
INFO - 2018-07-26 02:58:51 --> Helper loaded: date_helper
INFO - 2018-07-26 02:58:51 --> Helper loaded: util_helper
INFO - 2018-07-26 02:58:51 --> Helper loaded: text_helper
INFO - 2018-07-26 02:58:51 --> Config Class Initialized
INFO - 2018-07-26 02:58:51 --> Hooks Class Initialized
INFO - 2018-07-26 02:58:51 --> Helper loaded: string_helper
DEBUG - 2018-07-26 02:58:51 --> UTF-8 Support Enabled
INFO - 2018-07-26 02:58:51 --> Database Driver Class Initialized
INFO - 2018-07-26 02:58:51 --> Utf8 Class Initialized
DEBUG - 2018-07-26 02:58:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 02:58:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 02:58:51 --> URI Class Initialized
INFO - 2018-07-26 02:58:51 --> Router Class Initialized
INFO - 2018-07-26 02:58:51 --> Email Class Initialized
INFO - 2018-07-26 02:58:51 --> Controller Class Initialized
INFO - 2018-07-26 02:58:51 --> Output Class Initialized
DEBUG - 2018-07-26 02:58:51 --> Users MX_Controller Initialized
INFO - 2018-07-26 02:58:51 --> Security Class Initialized
DEBUG - 2018-07-26 02:58:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-26 02:58:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 02:58:51 --> Input Class Initialized
DEBUG - 2018-07-26 02:58:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-26 02:58:51 --> Language Class Initialized
INFO - 2018-07-26 02:58:51 --> Helper loaded: file_helper
DEBUG - 2018-07-26 02:58:51 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
INFO - 2018-07-26 02:58:51 --> Language Class Initialized
INFO - 2018-07-26 02:58:51 --> Config Class Initialized
DEBUG - 2018-07-26 02:58:51 --> Login MX_Controller Initialized
INFO - 2018-07-26 02:58:51 --> Language file loaded: language/english/data_lang.php
INFO - 2018-07-26 02:58:51 --> Loader Class Initialized
DEBUG - 2018-07-26 02:58:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-26 02:58:51 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
DEBUG - 2018-07-26 02:58:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
INFO - 2018-07-26 02:58:51 --> Helper loaded: url_helper
INFO - 2018-07-26 02:58:51 --> Helper loaded: form_helper
DEBUG - 2018-07-26 02:58:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-26 02:58:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
INFO - 2018-07-26 02:58:51 --> Helper loaded: date_helper
INFO - 2018-07-26 02:58:51 --> Helper loaded: util_helper
DEBUG - 2018-07-26 02:58:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-26 02:58:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
INFO - 2018-07-26 02:58:51 --> Helper loaded: text_helper
DEBUG - 2018-07-26 02:58:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-07-26 02:58:51 --> Helper loaded: string_helper
INFO - 2018-07-26 02:58:51 --> Final output sent to browser
INFO - 2018-07-26 02:58:51 --> Database Driver Class Initialized
DEBUG - 2018-07-26 02:58:51 --> Total execution time: 0.4127
DEBUG - 2018-07-26 02:58:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 02:58:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 02:58:51 --> Email Class Initialized
INFO - 2018-07-26 02:58:51 --> Controller Class Initialized
DEBUG - 2018-07-26 02:58:51 --> Users MX_Controller Initialized
DEBUG - 2018-07-26 02:58:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-26 02:58:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-26 02:58:51 --> Helper loaded: file_helper
DEBUG - 2018-07-26 02:58:51 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-26 02:58:51 --> Login MX_Controller Initialized
INFO - 2018-07-26 02:58:51 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-26 02:58:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-26 02:58:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-26 02:58:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-26 02:58:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-26 02:58:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-26 02:58:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-26 02:58:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-07-26 02:58:51 --> Final output sent to browser
DEBUG - 2018-07-26 02:58:51 --> Total execution time: 0.4154
INFO - 2018-07-26 02:58:52 --> Config Class Initialized
INFO - 2018-07-26 02:58:52 --> Config Class Initialized
INFO - 2018-07-26 02:58:52 --> Hooks Class Initialized
INFO - 2018-07-26 02:58:52 --> Hooks Class Initialized
DEBUG - 2018-07-26 02:58:52 --> UTF-8 Support Enabled
DEBUG - 2018-07-26 02:58:52 --> UTF-8 Support Enabled
INFO - 2018-07-26 02:58:52 --> Utf8 Class Initialized
INFO - 2018-07-26 02:58:52 --> Utf8 Class Initialized
INFO - 2018-07-26 02:58:52 --> URI Class Initialized
INFO - 2018-07-26 02:58:52 --> URI Class Initialized
INFO - 2018-07-26 02:58:52 --> Router Class Initialized
INFO - 2018-07-26 02:58:52 --> Output Class Initialized
INFO - 2018-07-26 02:58:52 --> Router Class Initialized
INFO - 2018-07-26 02:58:52 --> Output Class Initialized
INFO - 2018-07-26 02:58:52 --> Security Class Initialized
INFO - 2018-07-26 02:58:52 --> Security Class Initialized
DEBUG - 2018-07-26 02:58:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-07-26 02:58:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 02:58:52 --> Input Class Initialized
INFO - 2018-07-26 02:58:52 --> Input Class Initialized
INFO - 2018-07-26 02:58:52 --> Language Class Initialized
INFO - 2018-07-26 02:58:52 --> Language Class Initialized
INFO - 2018-07-26 02:58:52 --> Language Class Initialized
INFO - 2018-07-26 02:58:52 --> Config Class Initialized
INFO - 2018-07-26 02:58:52 --> Language Class Initialized
INFO - 2018-07-26 02:58:52 --> Config Class Initialized
INFO - 2018-07-26 02:58:52 --> Loader Class Initialized
DEBUG - 2018-07-26 02:58:52 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-26 02:58:52 --> Loader Class Initialized
DEBUG - 2018-07-26 02:58:52 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-26 02:58:52 --> Helper loaded: url_helper
INFO - 2018-07-26 02:58:52 --> Helper loaded: url_helper
INFO - 2018-07-26 02:58:52 --> Helper loaded: form_helper
INFO - 2018-07-26 02:58:52 --> Helper loaded: date_helper
INFO - 2018-07-26 02:58:52 --> Helper loaded: form_helper
INFO - 2018-07-26 02:58:52 --> Helper loaded: date_helper
INFO - 2018-07-26 02:58:52 --> Helper loaded: util_helper
INFO - 2018-07-26 02:58:52 --> Helper loaded: text_helper
INFO - 2018-07-26 02:58:52 --> Helper loaded: util_helper
INFO - 2018-07-26 02:58:52 --> Helper loaded: text_helper
INFO - 2018-07-26 02:58:52 --> Helper loaded: string_helper
INFO - 2018-07-26 02:58:52 --> Helper loaded: string_helper
INFO - 2018-07-26 02:58:52 --> Database Driver Class Initialized
INFO - 2018-07-26 02:58:52 --> Database Driver Class Initialized
DEBUG - 2018-07-26 02:58:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 02:58:52 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-07-26 02:58:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 02:58:52 --> Email Class Initialized
INFO - 2018-07-26 02:58:52 --> Controller Class Initialized
DEBUG - 2018-07-26 02:58:52 --> Users MX_Controller Initialized
DEBUG - 2018-07-26 02:58:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-26 02:58:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-26 02:58:52 --> Helper loaded: file_helper
DEBUG - 2018-07-26 02:58:52 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-26 02:58:52 --> Login MX_Controller Initialized
INFO - 2018-07-26 02:58:52 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-26 02:58:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-26 02:58:52 --> Final output sent to browser
DEBUG - 2018-07-26 02:58:52 --> Total execution time: 0.5227
INFO - 2018-07-26 02:58:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 02:58:52 --> Email Class Initialized
INFO - 2018-07-26 02:58:52 --> Controller Class Initialized
DEBUG - 2018-07-26 02:58:52 --> Users MX_Controller Initialized
DEBUG - 2018-07-26 02:58:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-26 02:58:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-26 02:58:52 --> Helper loaded: file_helper
DEBUG - 2018-07-26 02:58:52 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-26 02:58:52 --> Login MX_Controller Initialized
INFO - 2018-07-26 02:58:52 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-26 02:58:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-26 02:58:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-26 02:58:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-26 02:58:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-26 02:58:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-26 02:58:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-26 02:58:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-07-26 02:58:52 --> Final output sent to browser
DEBUG - 2018-07-26 02:58:52 --> Total execution time: 0.7388
INFO - 2018-07-26 02:58:53 --> Config Class Initialized
INFO - 2018-07-26 02:58:53 --> Hooks Class Initialized
DEBUG - 2018-07-26 02:58:53 --> UTF-8 Support Enabled
INFO - 2018-07-26 02:58:53 --> Utf8 Class Initialized
INFO - 2018-07-26 02:58:53 --> URI Class Initialized
INFO - 2018-07-26 02:58:53 --> Router Class Initialized
INFO - 2018-07-26 02:58:53 --> Output Class Initialized
INFO - 2018-07-26 02:58:53 --> Security Class Initialized
DEBUG - 2018-07-26 02:58:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 02:58:53 --> Input Class Initialized
INFO - 2018-07-26 02:58:53 --> Language Class Initialized
INFO - 2018-07-26 02:58:53 --> Language Class Initialized
INFO - 2018-07-26 02:58:53 --> Config Class Initialized
INFO - 2018-07-26 02:58:53 --> Loader Class Initialized
DEBUG - 2018-07-26 02:58:53 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-26 02:58:53 --> Helper loaded: url_helper
INFO - 2018-07-26 02:58:53 --> Helper loaded: form_helper
INFO - 2018-07-26 02:58:53 --> Helper loaded: date_helper
INFO - 2018-07-26 02:58:53 --> Helper loaded: util_helper
INFO - 2018-07-26 02:58:53 --> Helper loaded: text_helper
INFO - 2018-07-26 02:58:53 --> Helper loaded: string_helper
INFO - 2018-07-26 02:58:53 --> Database Driver Class Initialized
DEBUG - 2018-07-26 02:58:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 02:58:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 02:58:53 --> Email Class Initialized
INFO - 2018-07-26 02:58:53 --> Controller Class Initialized
DEBUG - 2018-07-26 02:58:53 --> Users MX_Controller Initialized
DEBUG - 2018-07-26 02:58:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-26 02:58:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-26 02:58:53 --> Helper loaded: file_helper
DEBUG - 2018-07-26 02:58:53 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-26 02:58:53 --> Login MX_Controller Initialized
INFO - 2018-07-26 02:58:53 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-26 02:58:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-26 02:58:53 --> Final output sent to browser
DEBUG - 2018-07-26 02:58:54 --> Total execution time: 0.8567
INFO - 2018-07-26 02:59:04 --> Config Class Initialized
INFO - 2018-07-26 02:59:04 --> Hooks Class Initialized
DEBUG - 2018-07-26 02:59:04 --> UTF-8 Support Enabled
INFO - 2018-07-26 02:59:04 --> Utf8 Class Initialized
INFO - 2018-07-26 02:59:04 --> URI Class Initialized
INFO - 2018-07-26 02:59:04 --> Router Class Initialized
INFO - 2018-07-26 02:59:04 --> Output Class Initialized
INFO - 2018-07-26 02:59:04 --> Security Class Initialized
DEBUG - 2018-07-26 02:59:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 02:59:04 --> Input Class Initialized
INFO - 2018-07-26 02:59:04 --> Language Class Initialized
INFO - 2018-07-26 02:59:04 --> Language Class Initialized
INFO - 2018-07-26 02:59:04 --> Config Class Initialized
INFO - 2018-07-26 02:59:04 --> Loader Class Initialized
DEBUG - 2018-07-26 02:59:04 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-26 02:59:04 --> Helper loaded: url_helper
INFO - 2018-07-26 02:59:04 --> Helper loaded: form_helper
INFO - 2018-07-26 02:59:04 --> Helper loaded: date_helper
INFO - 2018-07-26 02:59:04 --> Helper loaded: util_helper
INFO - 2018-07-26 02:59:04 --> Helper loaded: text_helper
INFO - 2018-07-26 02:59:04 --> Helper loaded: string_helper
INFO - 2018-07-26 02:59:04 --> Database Driver Class Initialized
DEBUG - 2018-07-26 02:59:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 02:59:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 02:59:04 --> Email Class Initialized
INFO - 2018-07-26 02:59:04 --> Controller Class Initialized
DEBUG - 2018-07-26 02:59:04 --> Admin MX_Controller Initialized
INFO - 2018-07-26 02:59:04 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-26 02:59:04 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-26 02:59:04 --> Login MX_Controller Initialized
DEBUG - 2018-07-26 02:59:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-26 02:59:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-26 02:59:04 --> Final output sent to browser
DEBUG - 2018-07-26 02:59:04 --> Total execution time: 0.4049
INFO - 2018-07-26 02:59:05 --> Config Class Initialized
INFO - 2018-07-26 02:59:05 --> Hooks Class Initialized
DEBUG - 2018-07-26 02:59:05 --> UTF-8 Support Enabled
INFO - 2018-07-26 02:59:05 --> Utf8 Class Initialized
INFO - 2018-07-26 02:59:05 --> URI Class Initialized
INFO - 2018-07-26 02:59:05 --> Router Class Initialized
INFO - 2018-07-26 02:59:05 --> Output Class Initialized
INFO - 2018-07-26 02:59:05 --> Security Class Initialized
DEBUG - 2018-07-26 02:59:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 02:59:05 --> Input Class Initialized
INFO - 2018-07-26 02:59:05 --> Language Class Initialized
INFO - 2018-07-26 02:59:05 --> Language Class Initialized
INFO - 2018-07-26 02:59:05 --> Config Class Initialized
INFO - 2018-07-26 02:59:05 --> Loader Class Initialized
DEBUG - 2018-07-26 02:59:05 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-26 02:59:05 --> Helper loaded: url_helper
INFO - 2018-07-26 02:59:05 --> Helper loaded: form_helper
INFO - 2018-07-26 02:59:05 --> Helper loaded: date_helper
INFO - 2018-07-26 02:59:05 --> Helper loaded: util_helper
INFO - 2018-07-26 02:59:05 --> Helper loaded: text_helper
INFO - 2018-07-26 02:59:05 --> Helper loaded: string_helper
INFO - 2018-07-26 02:59:05 --> Database Driver Class Initialized
DEBUG - 2018-07-26 02:59:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 02:59:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 02:59:05 --> Email Class Initialized
INFO - 2018-07-26 02:59:05 --> Controller Class Initialized
DEBUG - 2018-07-26 02:59:05 --> Admin MX_Controller Initialized
INFO - 2018-07-26 02:59:05 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-26 02:59:05 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-26 02:59:05 --> Login MX_Controller Initialized
DEBUG - 2018-07-26 02:59:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-26 02:59:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-26 02:59:05 --> Final output sent to browser
DEBUG - 2018-07-26 02:59:06 --> Total execution time: 0.5678
INFO - 2018-07-26 02:59:14 --> Config Class Initialized
INFO - 2018-07-26 02:59:14 --> Hooks Class Initialized
DEBUG - 2018-07-26 02:59:14 --> UTF-8 Support Enabled
INFO - 2018-07-26 02:59:14 --> Utf8 Class Initialized
INFO - 2018-07-26 02:59:14 --> URI Class Initialized
INFO - 2018-07-26 02:59:14 --> Router Class Initialized
INFO - 2018-07-26 02:59:14 --> Output Class Initialized
INFO - 2018-07-26 02:59:14 --> Security Class Initialized
DEBUG - 2018-07-26 02:59:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 02:59:14 --> Input Class Initialized
INFO - 2018-07-26 02:59:14 --> Language Class Initialized
INFO - 2018-07-26 02:59:14 --> Language Class Initialized
INFO - 2018-07-26 02:59:14 --> Config Class Initialized
INFO - 2018-07-26 02:59:14 --> Loader Class Initialized
DEBUG - 2018-07-26 02:59:14 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-26 02:59:14 --> Helper loaded: url_helper
INFO - 2018-07-26 02:59:14 --> Helper loaded: form_helper
INFO - 2018-07-26 02:59:14 --> Helper loaded: date_helper
INFO - 2018-07-26 02:59:14 --> Helper loaded: util_helper
INFO - 2018-07-26 02:59:14 --> Helper loaded: text_helper
INFO - 2018-07-26 02:59:14 --> Helper loaded: string_helper
INFO - 2018-07-26 02:59:14 --> Database Driver Class Initialized
DEBUG - 2018-07-26 02:59:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 02:59:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 02:59:14 --> Email Class Initialized
INFO - 2018-07-26 02:59:14 --> Controller Class Initialized
DEBUG - 2018-07-26 02:59:14 --> Login MX_Controller Initialized
INFO - 2018-07-26 02:59:14 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-26 02:59:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-26 02:59:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-26 02:59:14 --> 6 Loggedout
INFO - 2018-07-26 02:59:14 --> Config Class Initialized
INFO - 2018-07-26 02:59:14 --> Hooks Class Initialized
DEBUG - 2018-07-26 02:59:14 --> UTF-8 Support Enabled
INFO - 2018-07-26 02:59:14 --> Utf8 Class Initialized
INFO - 2018-07-26 02:59:14 --> URI Class Initialized
INFO - 2018-07-26 02:59:14 --> Router Class Initialized
INFO - 2018-07-26 02:59:14 --> Output Class Initialized
INFO - 2018-07-26 02:59:14 --> Security Class Initialized
DEBUG - 2018-07-26 02:59:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 02:59:14 --> Input Class Initialized
INFO - 2018-07-26 02:59:14 --> Language Class Initialized
INFO - 2018-07-26 02:59:14 --> Language Class Initialized
INFO - 2018-07-26 02:59:14 --> Config Class Initialized
INFO - 2018-07-26 02:59:14 --> Loader Class Initialized
DEBUG - 2018-07-26 02:59:14 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-26 02:59:14 --> Helper loaded: url_helper
INFO - 2018-07-26 02:59:14 --> Helper loaded: form_helper
INFO - 2018-07-26 02:59:14 --> Helper loaded: date_helper
INFO - 2018-07-26 02:59:15 --> Helper loaded: util_helper
INFO - 2018-07-26 02:59:15 --> Helper loaded: text_helper
INFO - 2018-07-26 02:59:15 --> Helper loaded: string_helper
INFO - 2018-07-26 02:59:15 --> Database Driver Class Initialized
DEBUG - 2018-07-26 02:59:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 02:59:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 02:59:15 --> Email Class Initialized
INFO - 2018-07-26 02:59:15 --> Controller Class Initialized
DEBUG - 2018-07-26 02:59:15 --> Admin MX_Controller Initialized
INFO - 2018-07-26 02:59:15 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-26 02:59:15 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-26 02:59:15 --> Login MX_Controller Initialized
DEBUG - 2018-07-26 02:59:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-26 02:59:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-26 02:59:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
INFO - 2018-07-26 02:59:15 --> Config Class Initialized
INFO - 2018-07-26 02:59:15 --> Hooks Class Initialized
DEBUG - 2018-07-26 02:59:15 --> UTF-8 Support Enabled
INFO - 2018-07-26 02:59:15 --> Utf8 Class Initialized
INFO - 2018-07-26 02:59:15 --> URI Class Initialized
INFO - 2018-07-26 02:59:15 --> Router Class Initialized
INFO - 2018-07-26 02:59:15 --> Output Class Initialized
INFO - 2018-07-26 02:59:15 --> Security Class Initialized
DEBUG - 2018-07-26 02:59:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 02:59:15 --> Input Class Initialized
INFO - 2018-07-26 02:59:15 --> Language Class Initialized
ERROR - 2018-07-26 02:59:15 --> 404 Page Not Found: /index
INFO - 2018-07-26 02:59:19 --> Config Class Initialized
INFO - 2018-07-26 02:59:19 --> Hooks Class Initialized
DEBUG - 2018-07-26 02:59:19 --> UTF-8 Support Enabled
INFO - 2018-07-26 02:59:19 --> Utf8 Class Initialized
INFO - 2018-07-26 02:59:19 --> URI Class Initialized
INFO - 2018-07-26 02:59:19 --> Router Class Initialized
INFO - 2018-07-26 02:59:19 --> Output Class Initialized
INFO - 2018-07-26 02:59:19 --> Security Class Initialized
DEBUG - 2018-07-26 02:59:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 02:59:19 --> Input Class Initialized
INFO - 2018-07-26 02:59:19 --> Language Class Initialized
INFO - 2018-07-26 02:59:19 --> Language Class Initialized
INFO - 2018-07-26 02:59:19 --> Config Class Initialized
INFO - 2018-07-26 02:59:19 --> Loader Class Initialized
DEBUG - 2018-07-26 02:59:19 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-26 02:59:19 --> Helper loaded: url_helper
INFO - 2018-07-26 02:59:19 --> Helper loaded: form_helper
INFO - 2018-07-26 02:59:19 --> Helper loaded: date_helper
INFO - 2018-07-26 02:59:20 --> Helper loaded: util_helper
INFO - 2018-07-26 02:59:20 --> Helper loaded: text_helper
INFO - 2018-07-26 02:59:20 --> Helper loaded: string_helper
INFO - 2018-07-26 02:59:20 --> Database Driver Class Initialized
DEBUG - 2018-07-26 02:59:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 02:59:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 02:59:20 --> Email Class Initialized
INFO - 2018-07-26 02:59:20 --> Controller Class Initialized
DEBUG - 2018-07-26 02:59:20 --> Login MX_Controller Initialized
INFO - 2018-07-26 02:59:20 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-26 02:59:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-26 02:59:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-26 02:59:20 --> Email starts for gopi.lion123@gmail.com fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-07-26 02:59:20 --> User session created for 6
INFO - 2018-07-26 02:59:20 --> Login status gopi.lion123@gmail.com - success
INFO - 2018-07-26 02:59:20 --> Final output sent to browser
DEBUG - 2018-07-26 02:59:20 --> Total execution time: 0.3763
INFO - 2018-07-26 02:59:20 --> Config Class Initialized
INFO - 2018-07-26 02:59:20 --> Hooks Class Initialized
DEBUG - 2018-07-26 02:59:20 --> UTF-8 Support Enabled
INFO - 2018-07-26 02:59:20 --> Utf8 Class Initialized
INFO - 2018-07-26 02:59:20 --> URI Class Initialized
INFO - 2018-07-26 02:59:20 --> Router Class Initialized
INFO - 2018-07-26 02:59:20 --> Output Class Initialized
INFO - 2018-07-26 02:59:20 --> Security Class Initialized
DEBUG - 2018-07-26 02:59:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 02:59:20 --> Input Class Initialized
INFO - 2018-07-26 02:59:20 --> Language Class Initialized
INFO - 2018-07-26 02:59:20 --> Language Class Initialized
INFO - 2018-07-26 02:59:20 --> Config Class Initialized
INFO - 2018-07-26 02:59:20 --> Loader Class Initialized
DEBUG - 2018-07-26 02:59:20 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-26 02:59:20 --> Helper loaded: url_helper
INFO - 2018-07-26 02:59:20 --> Helper loaded: form_helper
INFO - 2018-07-26 02:59:20 --> Helper loaded: date_helper
INFO - 2018-07-26 02:59:20 --> Helper loaded: util_helper
INFO - 2018-07-26 02:59:20 --> Helper loaded: text_helper
INFO - 2018-07-26 02:59:20 --> Helper loaded: string_helper
INFO - 2018-07-26 02:59:20 --> Database Driver Class Initialized
DEBUG - 2018-07-26 02:59:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 02:59:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 02:59:20 --> Email Class Initialized
INFO - 2018-07-26 02:59:20 --> Controller Class Initialized
DEBUG - 2018-07-26 02:59:20 --> Admin MX_Controller Initialized
INFO - 2018-07-26 02:59:20 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-26 02:59:20 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-26 02:59:20 --> Login MX_Controller Initialized
DEBUG - 2018-07-26 02:59:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-26 02:59:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-26 02:59:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-26 02:59:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-26 02:59:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-26 02:59:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-26 02:59:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-26 02:59:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/dashboard.php
INFO - 2018-07-26 02:59:20 --> Final output sent to browser
DEBUG - 2018-07-26 02:59:20 --> Total execution time: 0.4080
INFO - 2018-07-26 02:59:20 --> Config Class Initialized
INFO - 2018-07-26 02:59:20 --> Hooks Class Initialized
DEBUG - 2018-07-26 02:59:20 --> UTF-8 Support Enabled
INFO - 2018-07-26 02:59:20 --> Utf8 Class Initialized
INFO - 2018-07-26 02:59:20 --> URI Class Initialized
INFO - 2018-07-26 02:59:20 --> Router Class Initialized
INFO - 2018-07-26 02:59:21 --> Output Class Initialized
INFO - 2018-07-26 02:59:21 --> Config Class Initialized
INFO - 2018-07-26 02:59:21 --> Security Class Initialized
INFO - 2018-07-26 02:59:21 --> Hooks Class Initialized
DEBUG - 2018-07-26 02:59:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-07-26 02:59:21 --> UTF-8 Support Enabled
INFO - 2018-07-26 02:59:21 --> Input Class Initialized
INFO - 2018-07-26 02:59:21 --> Utf8 Class Initialized
INFO - 2018-07-26 02:59:21 --> Language Class Initialized
ERROR - 2018-07-26 02:59:21 --> 404 Page Not Found: /index
INFO - 2018-07-26 02:59:21 --> URI Class Initialized
INFO - 2018-07-26 02:59:21 --> Router Class Initialized
INFO - 2018-07-26 02:59:21 --> Output Class Initialized
INFO - 2018-07-26 02:59:21 --> Security Class Initialized
DEBUG - 2018-07-26 02:59:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 02:59:21 --> Input Class Initialized
INFO - 2018-07-26 02:59:21 --> Language Class Initialized
ERROR - 2018-07-26 02:59:21 --> 404 Page Not Found: /index
INFO - 2018-07-26 03:47:20 --> Config Class Initialized
INFO - 2018-07-26 03:47:20 --> Hooks Class Initialized
DEBUG - 2018-07-26 03:47:20 --> UTF-8 Support Enabled
INFO - 2018-07-26 03:47:20 --> Utf8 Class Initialized
INFO - 2018-07-26 03:47:20 --> URI Class Initialized
INFO - 2018-07-26 03:47:20 --> Router Class Initialized
INFO - 2018-07-26 03:47:20 --> Output Class Initialized
INFO - 2018-07-26 03:47:20 --> Security Class Initialized
DEBUG - 2018-07-26 03:47:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 03:47:20 --> Input Class Initialized
INFO - 2018-07-26 03:47:20 --> Language Class Initialized
INFO - 2018-07-26 03:47:20 --> Language Class Initialized
INFO - 2018-07-26 03:47:20 --> Config Class Initialized
INFO - 2018-07-26 03:47:20 --> Loader Class Initialized
DEBUG - 2018-07-26 03:47:20 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-26 03:47:20 --> Helper loaded: url_helper
INFO - 2018-07-26 03:47:20 --> Helper loaded: form_helper
INFO - 2018-07-26 03:47:20 --> Helper loaded: date_helper
INFO - 2018-07-26 03:47:20 --> Helper loaded: util_helper
INFO - 2018-07-26 03:47:20 --> Helper loaded: text_helper
INFO - 2018-07-26 03:47:20 --> Helper loaded: string_helper
INFO - 2018-07-26 03:47:20 --> Database Driver Class Initialized
DEBUG - 2018-07-26 03:47:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 03:47:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 03:47:20 --> Email Class Initialized
INFO - 2018-07-26 03:47:20 --> Controller Class Initialized
DEBUG - 2018-07-26 03:47:20 --> Login MX_Controller Initialized
INFO - 2018-07-26 03:47:20 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-26 03:47:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-26 03:47:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-26 03:47:20 --> 6 Loggedout
INFO - 2018-07-26 03:47:20 --> Config Class Initialized
INFO - 2018-07-26 03:47:20 --> Hooks Class Initialized
DEBUG - 2018-07-26 03:47:20 --> UTF-8 Support Enabled
INFO - 2018-07-26 03:47:20 --> Utf8 Class Initialized
INFO - 2018-07-26 03:47:20 --> URI Class Initialized
INFO - 2018-07-26 03:47:20 --> Router Class Initialized
INFO - 2018-07-26 03:47:20 --> Output Class Initialized
INFO - 2018-07-26 03:47:20 --> Security Class Initialized
DEBUG - 2018-07-26 03:47:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 03:47:20 --> Input Class Initialized
INFO - 2018-07-26 03:47:20 --> Language Class Initialized
INFO - 2018-07-26 03:47:20 --> Language Class Initialized
INFO - 2018-07-26 03:47:21 --> Config Class Initialized
INFO - 2018-07-26 03:47:21 --> Loader Class Initialized
DEBUG - 2018-07-26 03:47:21 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-26 03:47:21 --> Helper loaded: url_helper
INFO - 2018-07-26 03:47:21 --> Helper loaded: form_helper
INFO - 2018-07-26 03:47:21 --> Helper loaded: date_helper
INFO - 2018-07-26 03:47:21 --> Helper loaded: util_helper
INFO - 2018-07-26 03:47:21 --> Helper loaded: text_helper
INFO - 2018-07-26 03:47:21 --> Helper loaded: string_helper
INFO - 2018-07-26 03:47:21 --> Database Driver Class Initialized
DEBUG - 2018-07-26 03:47:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 03:47:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 03:47:21 --> Email Class Initialized
INFO - 2018-07-26 03:47:21 --> Controller Class Initialized
DEBUG - 2018-07-26 03:47:21 --> Admin MX_Controller Initialized
INFO - 2018-07-26 03:47:21 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-26 03:47:21 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-26 03:47:21 --> Login MX_Controller Initialized
DEBUG - 2018-07-26 03:47:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-26 03:47:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-26 03:47:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
INFO - 2018-07-26 03:47:21 --> Config Class Initialized
INFO - 2018-07-26 03:47:21 --> Hooks Class Initialized
DEBUG - 2018-07-26 03:47:21 --> UTF-8 Support Enabled
INFO - 2018-07-26 03:47:21 --> Utf8 Class Initialized
INFO - 2018-07-26 03:47:21 --> URI Class Initialized
INFO - 2018-07-26 03:47:21 --> Router Class Initialized
INFO - 2018-07-26 03:47:21 --> Output Class Initialized
INFO - 2018-07-26 03:47:21 --> Security Class Initialized
DEBUG - 2018-07-26 03:47:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 03:47:21 --> Input Class Initialized
INFO - 2018-07-26 03:47:21 --> Language Class Initialized
ERROR - 2018-07-26 03:47:21 --> 404 Page Not Found: /index
INFO - 2018-07-26 03:48:03 --> Config Class Initialized
INFO - 2018-07-26 03:48:03 --> Hooks Class Initialized
DEBUG - 2018-07-26 03:48:03 --> UTF-8 Support Enabled
INFO - 2018-07-26 03:48:03 --> Utf8 Class Initialized
INFO - 2018-07-26 03:48:03 --> URI Class Initialized
INFO - 2018-07-26 03:48:03 --> Router Class Initialized
INFO - 2018-07-26 03:48:03 --> Output Class Initialized
INFO - 2018-07-26 03:48:03 --> Security Class Initialized
DEBUG - 2018-07-26 03:48:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 03:48:03 --> Input Class Initialized
INFO - 2018-07-26 03:48:03 --> Language Class Initialized
INFO - 2018-07-26 03:48:03 --> Language Class Initialized
INFO - 2018-07-26 03:48:03 --> Config Class Initialized
INFO - 2018-07-26 03:48:03 --> Loader Class Initialized
DEBUG - 2018-07-26 03:48:03 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-26 03:48:03 --> Helper loaded: url_helper
INFO - 2018-07-26 03:48:03 --> Helper loaded: form_helper
INFO - 2018-07-26 03:48:03 --> Helper loaded: date_helper
INFO - 2018-07-26 03:48:03 --> Helper loaded: util_helper
INFO - 2018-07-26 03:48:03 --> Helper loaded: text_helper
INFO - 2018-07-26 03:48:03 --> Helper loaded: string_helper
INFO - 2018-07-26 03:48:03 --> Database Driver Class Initialized
DEBUG - 2018-07-26 03:48:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 03:48:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 03:48:03 --> Email Class Initialized
INFO - 2018-07-26 03:48:03 --> Controller Class Initialized
DEBUG - 2018-07-26 03:48:03 --> Admin MX_Controller Initialized
INFO - 2018-07-26 03:48:03 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-26 03:48:03 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-26 03:48:03 --> Login MX_Controller Initialized
DEBUG - 2018-07-26 03:48:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-26 03:48:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-26 03:48:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
INFO - 2018-07-26 03:48:03 --> Config Class Initialized
INFO - 2018-07-26 03:48:03 --> Hooks Class Initialized
DEBUG - 2018-07-26 03:48:03 --> UTF-8 Support Enabled
INFO - 2018-07-26 03:48:03 --> Utf8 Class Initialized
INFO - 2018-07-26 03:48:03 --> URI Class Initialized
INFO - 2018-07-26 03:48:03 --> Router Class Initialized
INFO - 2018-07-26 03:48:03 --> Output Class Initialized
INFO - 2018-07-26 03:48:03 --> Security Class Initialized
DEBUG - 2018-07-26 03:48:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 03:48:03 --> Input Class Initialized
INFO - 2018-07-26 03:48:03 --> Language Class Initialized
ERROR - 2018-07-26 03:48:03 --> 404 Page Not Found: /index
INFO - 2018-07-26 03:48:12 --> Config Class Initialized
INFO - 2018-07-26 03:48:12 --> Hooks Class Initialized
DEBUG - 2018-07-26 03:48:12 --> UTF-8 Support Enabled
INFO - 2018-07-26 03:48:12 --> Utf8 Class Initialized
INFO - 2018-07-26 03:48:12 --> URI Class Initialized
INFO - 2018-07-26 03:48:12 --> Router Class Initialized
INFO - 2018-07-26 03:48:12 --> Output Class Initialized
INFO - 2018-07-26 03:48:12 --> Security Class Initialized
DEBUG - 2018-07-26 03:48:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 03:48:12 --> Input Class Initialized
INFO - 2018-07-26 03:48:12 --> Language Class Initialized
INFO - 2018-07-26 03:48:12 --> Language Class Initialized
INFO - 2018-07-26 03:48:12 --> Config Class Initialized
INFO - 2018-07-26 03:48:12 --> Loader Class Initialized
DEBUG - 2018-07-26 03:48:12 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-26 03:48:12 --> Helper loaded: url_helper
INFO - 2018-07-26 03:48:12 --> Helper loaded: form_helper
INFO - 2018-07-26 03:48:12 --> Helper loaded: date_helper
INFO - 2018-07-26 03:48:12 --> Helper loaded: util_helper
INFO - 2018-07-26 03:48:12 --> Helper loaded: text_helper
INFO - 2018-07-26 03:48:12 --> Helper loaded: string_helper
INFO - 2018-07-26 03:48:12 --> Database Driver Class Initialized
DEBUG - 2018-07-26 03:48:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 03:48:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 03:48:12 --> Email Class Initialized
INFO - 2018-07-26 03:48:12 --> Controller Class Initialized
DEBUG - 2018-07-26 03:48:12 --> Admin MX_Controller Initialized
INFO - 2018-07-26 03:48:12 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-26 03:48:12 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-26 03:48:12 --> Login MX_Controller Initialized
DEBUG - 2018-07-26 03:48:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-26 03:48:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-26 03:48:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
INFO - 2018-07-26 03:48:19 --> Config Class Initialized
INFO - 2018-07-26 03:48:19 --> Hooks Class Initialized
DEBUG - 2018-07-26 03:48:19 --> UTF-8 Support Enabled
INFO - 2018-07-26 03:48:19 --> Utf8 Class Initialized
INFO - 2018-07-26 03:48:19 --> URI Class Initialized
INFO - 2018-07-26 03:48:19 --> Router Class Initialized
INFO - 2018-07-26 03:48:19 --> Output Class Initialized
INFO - 2018-07-26 03:48:19 --> Security Class Initialized
DEBUG - 2018-07-26 03:48:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 03:48:19 --> Input Class Initialized
INFO - 2018-07-26 03:48:19 --> Language Class Initialized
INFO - 2018-07-26 03:48:19 --> Language Class Initialized
INFO - 2018-07-26 03:48:19 --> Config Class Initialized
INFO - 2018-07-26 03:48:19 --> Loader Class Initialized
DEBUG - 2018-07-26 03:48:19 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-26 03:48:19 --> Helper loaded: url_helper
INFO - 2018-07-26 03:48:19 --> Helper loaded: form_helper
INFO - 2018-07-26 03:48:19 --> Helper loaded: date_helper
INFO - 2018-07-26 03:48:19 --> Helper loaded: util_helper
INFO - 2018-07-26 03:48:19 --> Helper loaded: text_helper
INFO - 2018-07-26 03:48:19 --> Helper loaded: string_helper
INFO - 2018-07-26 03:48:19 --> Database Driver Class Initialized
DEBUG - 2018-07-26 03:48:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 03:48:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 03:48:19 --> Email Class Initialized
INFO - 2018-07-26 03:48:19 --> Controller Class Initialized
DEBUG - 2018-07-26 03:48:19 --> Admin MX_Controller Initialized
INFO - 2018-07-26 03:48:19 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-26 03:48:19 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-26 03:48:19 --> Login MX_Controller Initialized
DEBUG - 2018-07-26 03:48:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-26 03:48:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-26 03:48:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
INFO - 2018-07-26 03:48:20 --> Config Class Initialized
INFO - 2018-07-26 03:48:20 --> Hooks Class Initialized
DEBUG - 2018-07-26 03:48:20 --> UTF-8 Support Enabled
INFO - 2018-07-26 03:48:20 --> Utf8 Class Initialized
INFO - 2018-07-26 03:48:20 --> URI Class Initialized
INFO - 2018-07-26 03:48:20 --> Router Class Initialized
INFO - 2018-07-26 03:48:20 --> Output Class Initialized
INFO - 2018-07-26 03:48:20 --> Security Class Initialized
DEBUG - 2018-07-26 03:48:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 03:48:20 --> Input Class Initialized
INFO - 2018-07-26 03:48:20 --> Language Class Initialized
ERROR - 2018-07-26 03:48:20 --> 404 Page Not Found: /index
INFO - 2018-07-26 03:49:34 --> Config Class Initialized
INFO - 2018-07-26 03:49:34 --> Hooks Class Initialized
DEBUG - 2018-07-26 03:49:34 --> UTF-8 Support Enabled
INFO - 2018-07-26 03:49:34 --> Utf8 Class Initialized
INFO - 2018-07-26 03:49:34 --> URI Class Initialized
INFO - 2018-07-26 03:49:34 --> Router Class Initialized
INFO - 2018-07-26 03:49:34 --> Output Class Initialized
INFO - 2018-07-26 03:49:34 --> Security Class Initialized
DEBUG - 2018-07-26 03:49:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 03:49:34 --> Input Class Initialized
INFO - 2018-07-26 03:49:34 --> Language Class Initialized
INFO - 2018-07-26 03:49:34 --> Language Class Initialized
INFO - 2018-07-26 03:49:34 --> Config Class Initialized
INFO - 2018-07-26 03:49:34 --> Loader Class Initialized
DEBUG - 2018-07-26 03:49:34 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-26 03:49:34 --> Helper loaded: url_helper
INFO - 2018-07-26 03:49:34 --> Helper loaded: form_helper
INFO - 2018-07-26 03:49:34 --> Helper loaded: date_helper
INFO - 2018-07-26 03:49:34 --> Helper loaded: util_helper
INFO - 2018-07-26 03:49:34 --> Helper loaded: text_helper
INFO - 2018-07-26 03:49:34 --> Helper loaded: string_helper
INFO - 2018-07-26 03:49:34 --> Database Driver Class Initialized
DEBUG - 2018-07-26 03:49:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 03:49:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 03:49:34 --> Email Class Initialized
INFO - 2018-07-26 03:49:34 --> Controller Class Initialized
DEBUG - 2018-07-26 03:49:34 --> Admin MX_Controller Initialized
INFO - 2018-07-26 03:49:34 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-26 03:49:34 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-26 03:49:34 --> Login MX_Controller Initialized
DEBUG - 2018-07-26 03:49:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-26 03:49:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-26 03:49:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
INFO - 2018-07-26 03:49:34 --> Config Class Initialized
INFO - 2018-07-26 03:49:34 --> Hooks Class Initialized
DEBUG - 2018-07-26 03:49:34 --> UTF-8 Support Enabled
INFO - 2018-07-26 03:49:34 --> Utf8 Class Initialized
INFO - 2018-07-26 03:49:34 --> URI Class Initialized
INFO - 2018-07-26 03:49:35 --> Router Class Initialized
INFO - 2018-07-26 03:49:35 --> Output Class Initialized
INFO - 2018-07-26 03:49:35 --> Security Class Initialized
DEBUG - 2018-07-26 03:49:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 03:49:35 --> Input Class Initialized
INFO - 2018-07-26 03:49:35 --> Language Class Initialized
ERROR - 2018-07-26 03:49:35 --> 404 Page Not Found: /index
INFO - 2018-07-26 03:52:50 --> Config Class Initialized
INFO - 2018-07-26 03:52:50 --> Hooks Class Initialized
DEBUG - 2018-07-26 03:52:50 --> UTF-8 Support Enabled
INFO - 2018-07-26 03:52:50 --> Utf8 Class Initialized
INFO - 2018-07-26 03:52:50 --> URI Class Initialized
INFO - 2018-07-26 03:52:50 --> Router Class Initialized
INFO - 2018-07-26 03:52:50 --> Output Class Initialized
INFO - 2018-07-26 03:52:50 --> Security Class Initialized
DEBUG - 2018-07-26 03:52:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 03:52:50 --> Input Class Initialized
INFO - 2018-07-26 03:52:50 --> Language Class Initialized
INFO - 2018-07-26 03:52:50 --> Language Class Initialized
INFO - 2018-07-26 03:52:50 --> Config Class Initialized
INFO - 2018-07-26 03:52:50 --> Loader Class Initialized
DEBUG - 2018-07-26 03:52:50 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-26 03:52:50 --> Helper loaded: url_helper
INFO - 2018-07-26 03:52:50 --> Helper loaded: form_helper
INFO - 2018-07-26 03:52:50 --> Helper loaded: date_helper
INFO - 2018-07-26 03:52:50 --> Helper loaded: util_helper
INFO - 2018-07-26 03:52:50 --> Helper loaded: text_helper
INFO - 2018-07-26 03:52:50 --> Helper loaded: string_helper
INFO - 2018-07-26 03:52:50 --> Database Driver Class Initialized
DEBUG - 2018-07-26 03:52:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 03:52:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 03:52:50 --> Email Class Initialized
INFO - 2018-07-26 03:52:50 --> Controller Class Initialized
DEBUG - 2018-07-26 03:52:50 --> Admin MX_Controller Initialized
INFO - 2018-07-26 03:52:50 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-26 03:52:50 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-26 03:52:50 --> Login MX_Controller Initialized
DEBUG - 2018-07-26 03:52:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-26 03:52:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-26 03:52:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
INFO - 2018-07-26 03:52:50 --> Config Class Initialized
INFO - 2018-07-26 03:52:50 --> Hooks Class Initialized
DEBUG - 2018-07-26 03:52:50 --> UTF-8 Support Enabled
INFO - 2018-07-26 03:52:50 --> Utf8 Class Initialized
INFO - 2018-07-26 03:52:50 --> URI Class Initialized
INFO - 2018-07-26 03:52:50 --> Router Class Initialized
INFO - 2018-07-26 03:52:50 --> Output Class Initialized
INFO - 2018-07-26 03:52:50 --> Security Class Initialized
DEBUG - 2018-07-26 03:52:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 03:52:50 --> Input Class Initialized
INFO - 2018-07-26 03:52:50 --> Language Class Initialized
ERROR - 2018-07-26 03:52:50 --> 404 Page Not Found: /index
INFO - 2018-07-26 03:53:24 --> Config Class Initialized
INFO - 2018-07-26 03:53:24 --> Hooks Class Initialized
DEBUG - 2018-07-26 03:53:24 --> UTF-8 Support Enabled
INFO - 2018-07-26 03:53:24 --> Utf8 Class Initialized
INFO - 2018-07-26 03:53:24 --> URI Class Initialized
INFO - 2018-07-26 03:53:24 --> Router Class Initialized
INFO - 2018-07-26 03:53:24 --> Output Class Initialized
INFO - 2018-07-26 03:53:24 --> Security Class Initialized
DEBUG - 2018-07-26 03:53:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 03:53:24 --> Input Class Initialized
INFO - 2018-07-26 03:53:24 --> Language Class Initialized
INFO - 2018-07-26 03:53:24 --> Language Class Initialized
INFO - 2018-07-26 03:53:24 --> Config Class Initialized
INFO - 2018-07-26 03:53:24 --> Loader Class Initialized
DEBUG - 2018-07-26 03:53:24 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-26 03:53:24 --> Helper loaded: url_helper
INFO - 2018-07-26 03:53:24 --> Helper loaded: form_helper
INFO - 2018-07-26 03:53:25 --> Helper loaded: date_helper
INFO - 2018-07-26 03:53:25 --> Helper loaded: util_helper
INFO - 2018-07-26 03:53:25 --> Helper loaded: text_helper
INFO - 2018-07-26 03:53:25 --> Helper loaded: string_helper
INFO - 2018-07-26 03:53:25 --> Database Driver Class Initialized
DEBUG - 2018-07-26 03:53:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 03:53:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 03:53:25 --> Email Class Initialized
INFO - 2018-07-26 03:53:25 --> Controller Class Initialized
DEBUG - 2018-07-26 03:53:25 --> Admin MX_Controller Initialized
INFO - 2018-07-26 03:53:25 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-26 03:53:25 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-26 03:53:25 --> Login MX_Controller Initialized
DEBUG - 2018-07-26 03:53:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-26 03:53:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-26 03:53:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
INFO - 2018-07-26 03:53:25 --> Config Class Initialized
INFO - 2018-07-26 03:53:25 --> Hooks Class Initialized
DEBUG - 2018-07-26 03:53:25 --> UTF-8 Support Enabled
INFO - 2018-07-26 03:53:25 --> Utf8 Class Initialized
INFO - 2018-07-26 03:53:25 --> URI Class Initialized
INFO - 2018-07-26 03:53:25 --> Router Class Initialized
INFO - 2018-07-26 03:53:25 --> Output Class Initialized
INFO - 2018-07-26 03:53:25 --> Security Class Initialized
DEBUG - 2018-07-26 03:53:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 03:53:25 --> Input Class Initialized
INFO - 2018-07-26 03:53:25 --> Language Class Initialized
ERROR - 2018-07-26 03:53:25 --> 404 Page Not Found: /index
INFO - 2018-07-26 03:53:28 --> Config Class Initialized
INFO - 2018-07-26 03:53:28 --> Hooks Class Initialized
DEBUG - 2018-07-26 03:53:28 --> UTF-8 Support Enabled
INFO - 2018-07-26 03:53:28 --> Utf8 Class Initialized
INFO - 2018-07-26 03:53:28 --> URI Class Initialized
INFO - 2018-07-26 03:53:28 --> Router Class Initialized
INFO - 2018-07-26 03:53:28 --> Output Class Initialized
INFO - 2018-07-26 03:53:28 --> Security Class Initialized
DEBUG - 2018-07-26 03:53:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 03:53:28 --> Input Class Initialized
INFO - 2018-07-26 03:53:28 --> Language Class Initialized
INFO - 2018-07-26 03:53:28 --> Language Class Initialized
INFO - 2018-07-26 03:53:28 --> Config Class Initialized
INFO - 2018-07-26 03:53:28 --> Loader Class Initialized
DEBUG - 2018-07-26 03:53:28 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-26 03:53:28 --> Helper loaded: url_helper
INFO - 2018-07-26 03:53:28 --> Helper loaded: form_helper
INFO - 2018-07-26 03:53:28 --> Helper loaded: date_helper
INFO - 2018-07-26 03:53:28 --> Helper loaded: util_helper
INFO - 2018-07-26 03:53:28 --> Helper loaded: text_helper
INFO - 2018-07-26 03:53:28 --> Helper loaded: string_helper
INFO - 2018-07-26 03:53:28 --> Database Driver Class Initialized
DEBUG - 2018-07-26 03:53:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 03:53:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 03:53:28 --> Email Class Initialized
INFO - 2018-07-26 03:53:28 --> Controller Class Initialized
DEBUG - 2018-07-26 03:53:28 --> Login MX_Controller Initialized
INFO - 2018-07-26 03:53:28 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-26 03:53:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-26 03:53:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-26 03:53:28 --> Email starts for Colin-admin fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-07-26 03:53:28 --> User session created for 1
INFO - 2018-07-26 03:53:28 --> Login status Colin-admin - success
INFO - 2018-07-26 03:53:28 --> Final output sent to browser
DEBUG - 2018-07-26 03:53:28 --> Total execution time: 0.3732
INFO - 2018-07-26 03:53:28 --> Config Class Initialized
INFO - 2018-07-26 03:53:28 --> Hooks Class Initialized
DEBUG - 2018-07-26 03:53:28 --> UTF-8 Support Enabled
INFO - 2018-07-26 03:53:28 --> Utf8 Class Initialized
INFO - 2018-07-26 03:53:28 --> URI Class Initialized
INFO - 2018-07-26 03:53:28 --> Router Class Initialized
INFO - 2018-07-26 03:53:28 --> Output Class Initialized
INFO - 2018-07-26 03:53:28 --> Security Class Initialized
DEBUG - 2018-07-26 03:53:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 03:53:28 --> Input Class Initialized
INFO - 2018-07-26 03:53:28 --> Language Class Initialized
INFO - 2018-07-26 03:53:28 --> Language Class Initialized
INFO - 2018-07-26 03:53:28 --> Config Class Initialized
INFO - 2018-07-26 03:53:28 --> Loader Class Initialized
DEBUG - 2018-07-26 03:53:28 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-26 03:53:28 --> Helper loaded: url_helper
INFO - 2018-07-26 03:53:28 --> Helper loaded: form_helper
INFO - 2018-07-26 03:53:28 --> Helper loaded: date_helper
INFO - 2018-07-26 03:53:28 --> Helper loaded: util_helper
INFO - 2018-07-26 03:53:28 --> Helper loaded: text_helper
INFO - 2018-07-26 03:53:28 --> Helper loaded: string_helper
INFO - 2018-07-26 03:53:28 --> Database Driver Class Initialized
DEBUG - 2018-07-26 03:53:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 03:53:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 03:53:29 --> Email Class Initialized
INFO - 2018-07-26 03:53:29 --> Controller Class Initialized
DEBUG - 2018-07-26 03:53:29 --> Admin MX_Controller Initialized
INFO - 2018-07-26 03:53:29 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-26 03:53:29 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-26 03:53:29 --> Login MX_Controller Initialized
DEBUG - 2018-07-26 03:53:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-26 03:53:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-26 03:53:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-26 03:53:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-26 03:53:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-26 03:53:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-26 03:53:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-26 03:53:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/dashboard.php
INFO - 2018-07-26 03:53:29 --> Final output sent to browser
DEBUG - 2018-07-26 03:53:29 --> Total execution time: 0.4201
INFO - 2018-07-26 03:53:29 --> Config Class Initialized
INFO - 2018-07-26 03:53:29 --> Hooks Class Initialized
DEBUG - 2018-07-26 03:53:29 --> UTF-8 Support Enabled
INFO - 2018-07-26 03:53:29 --> Utf8 Class Initialized
INFO - 2018-07-26 03:53:29 --> URI Class Initialized
INFO - 2018-07-26 03:53:29 --> Config Class Initialized
INFO - 2018-07-26 03:53:29 --> Router Class Initialized
INFO - 2018-07-26 03:53:29 --> Hooks Class Initialized
INFO - 2018-07-26 03:53:29 --> Output Class Initialized
INFO - 2018-07-26 03:53:29 --> Security Class Initialized
DEBUG - 2018-07-26 03:53:29 --> UTF-8 Support Enabled
DEBUG - 2018-07-26 03:53:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 03:53:29 --> Utf8 Class Initialized
INFO - 2018-07-26 03:53:29 --> Input Class Initialized
INFO - 2018-07-26 03:53:29 --> URI Class Initialized
INFO - 2018-07-26 03:53:29 --> Language Class Initialized
INFO - 2018-07-26 03:53:29 --> Router Class Initialized
ERROR - 2018-07-26 03:53:29 --> 404 Page Not Found: /index
INFO - 2018-07-26 03:53:29 --> Output Class Initialized
INFO - 2018-07-26 03:53:29 --> Security Class Initialized
DEBUG - 2018-07-26 03:53:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 03:53:29 --> Input Class Initialized
INFO - 2018-07-26 03:53:29 --> Language Class Initialized
ERROR - 2018-07-26 03:53:29 --> 404 Page Not Found: /index
INFO - 2018-07-26 03:53:34 --> Config Class Initialized
INFO - 2018-07-26 03:53:34 --> Hooks Class Initialized
DEBUG - 2018-07-26 03:53:34 --> UTF-8 Support Enabled
INFO - 2018-07-26 03:53:34 --> Utf8 Class Initialized
INFO - 2018-07-26 03:53:34 --> URI Class Initialized
INFO - 2018-07-26 03:53:34 --> Router Class Initialized
INFO - 2018-07-26 03:53:34 --> Output Class Initialized
INFO - 2018-07-26 03:53:34 --> Security Class Initialized
DEBUG - 2018-07-26 03:53:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 03:53:34 --> Input Class Initialized
INFO - 2018-07-26 03:53:34 --> Language Class Initialized
INFO - 2018-07-26 03:53:34 --> Language Class Initialized
INFO - 2018-07-26 03:53:34 --> Config Class Initialized
INFO - 2018-07-26 03:53:34 --> Loader Class Initialized
DEBUG - 2018-07-26 03:53:34 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-26 03:53:34 --> Helper loaded: url_helper
INFO - 2018-07-26 03:53:34 --> Helper loaded: form_helper
INFO - 2018-07-26 03:53:34 --> Helper loaded: date_helper
INFO - 2018-07-26 03:53:34 --> Helper loaded: util_helper
INFO - 2018-07-26 03:53:34 --> Helper loaded: text_helper
INFO - 2018-07-26 03:53:34 --> Helper loaded: string_helper
INFO - 2018-07-26 03:53:34 --> Database Driver Class Initialized
DEBUG - 2018-07-26 03:53:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 03:53:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 03:53:34 --> Email Class Initialized
INFO - 2018-07-26 03:53:34 --> Controller Class Initialized
DEBUG - 2018-07-26 03:53:34 --> Login MX_Controller Initialized
INFO - 2018-07-26 03:53:34 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-26 03:53:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-26 03:53:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-26 03:53:34 --> 1 Loggedout
INFO - 2018-07-26 03:53:34 --> Config Class Initialized
INFO - 2018-07-26 03:53:34 --> Hooks Class Initialized
DEBUG - 2018-07-26 03:53:34 --> UTF-8 Support Enabled
INFO - 2018-07-26 03:53:34 --> Utf8 Class Initialized
INFO - 2018-07-26 03:53:34 --> URI Class Initialized
INFO - 2018-07-26 03:53:34 --> Router Class Initialized
INFO - 2018-07-26 03:53:34 --> Output Class Initialized
INFO - 2018-07-26 03:53:34 --> Security Class Initialized
DEBUG - 2018-07-26 03:53:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 03:53:34 --> Input Class Initialized
INFO - 2018-07-26 03:53:34 --> Language Class Initialized
INFO - 2018-07-26 03:53:34 --> Language Class Initialized
INFO - 2018-07-26 03:53:34 --> Config Class Initialized
INFO - 2018-07-26 03:53:34 --> Loader Class Initialized
DEBUG - 2018-07-26 03:53:34 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-26 03:53:34 --> Helper loaded: url_helper
INFO - 2018-07-26 03:53:34 --> Helper loaded: form_helper
INFO - 2018-07-26 03:53:34 --> Helper loaded: date_helper
INFO - 2018-07-26 03:53:34 --> Helper loaded: util_helper
INFO - 2018-07-26 03:53:34 --> Helper loaded: text_helper
INFO - 2018-07-26 03:53:34 --> Helper loaded: string_helper
INFO - 2018-07-26 03:53:34 --> Database Driver Class Initialized
DEBUG - 2018-07-26 03:53:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 03:53:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 03:53:34 --> Email Class Initialized
INFO - 2018-07-26 03:53:34 --> Controller Class Initialized
DEBUG - 2018-07-26 03:53:34 --> Admin MX_Controller Initialized
INFO - 2018-07-26 03:53:34 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-26 03:53:34 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-26 03:53:34 --> Login MX_Controller Initialized
DEBUG - 2018-07-26 03:53:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-26 03:53:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-26 03:53:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
INFO - 2018-07-26 03:53:34 --> Config Class Initialized
INFO - 2018-07-26 03:53:34 --> Hooks Class Initialized
DEBUG - 2018-07-26 03:53:34 --> UTF-8 Support Enabled
INFO - 2018-07-26 03:53:34 --> Utf8 Class Initialized
INFO - 2018-07-26 03:53:34 --> URI Class Initialized
INFO - 2018-07-26 03:53:34 --> Router Class Initialized
INFO - 2018-07-26 03:53:34 --> Output Class Initialized
INFO - 2018-07-26 03:53:34 --> Security Class Initialized
DEBUG - 2018-07-26 03:53:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 03:53:34 --> Input Class Initialized
INFO - 2018-07-26 03:53:34 --> Language Class Initialized
ERROR - 2018-07-26 03:53:34 --> 404 Page Not Found: /index
INFO - 2018-07-26 03:53:41 --> Config Class Initialized
INFO - 2018-07-26 03:53:41 --> Hooks Class Initialized
DEBUG - 2018-07-26 03:53:41 --> UTF-8 Support Enabled
INFO - 2018-07-26 03:53:41 --> Utf8 Class Initialized
INFO - 2018-07-26 03:53:41 --> URI Class Initialized
INFO - 2018-07-26 03:53:41 --> Router Class Initialized
INFO - 2018-07-26 03:53:41 --> Output Class Initialized
INFO - 2018-07-26 03:53:41 --> Security Class Initialized
DEBUG - 2018-07-26 03:53:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 03:53:41 --> Input Class Initialized
INFO - 2018-07-26 03:53:41 --> Language Class Initialized
INFO - 2018-07-26 03:53:41 --> Language Class Initialized
INFO - 2018-07-26 03:53:41 --> Config Class Initialized
INFO - 2018-07-26 03:53:41 --> Loader Class Initialized
DEBUG - 2018-07-26 03:53:41 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-26 03:53:41 --> Helper loaded: url_helper
INFO - 2018-07-26 03:53:41 --> Helper loaded: form_helper
INFO - 2018-07-26 03:53:41 --> Helper loaded: date_helper
INFO - 2018-07-26 03:53:41 --> Helper loaded: util_helper
INFO - 2018-07-26 03:53:41 --> Helper loaded: text_helper
INFO - 2018-07-26 03:53:41 --> Helper loaded: string_helper
INFO - 2018-07-26 03:53:41 --> Database Driver Class Initialized
DEBUG - 2018-07-26 03:53:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 03:53:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 03:53:41 --> Email Class Initialized
INFO - 2018-07-26 03:53:41 --> Controller Class Initialized
DEBUG - 2018-07-26 03:53:41 --> Users MX_Controller Initialized
DEBUG - 2018-07-26 03:53:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-26 03:53:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-26 03:53:41 --> Helper loaded: file_helper
DEBUG - 2018-07-26 03:53:41 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-26 03:53:41 --> Login MX_Controller Initialized
INFO - 2018-07-26 03:53:41 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-26 03:53:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-26 03:53:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
INFO - 2018-07-26 03:53:41 --> Config Class Initialized
INFO - 2018-07-26 03:53:41 --> Hooks Class Initialized
DEBUG - 2018-07-26 03:53:41 --> UTF-8 Support Enabled
INFO - 2018-07-26 03:53:41 --> Utf8 Class Initialized
INFO - 2018-07-26 03:53:41 --> URI Class Initialized
INFO - 2018-07-26 03:53:41 --> Router Class Initialized
INFO - 2018-07-26 03:53:41 --> Output Class Initialized
INFO - 2018-07-26 03:53:41 --> Security Class Initialized
DEBUG - 2018-07-26 03:53:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 03:53:41 --> Input Class Initialized
INFO - 2018-07-26 03:53:42 --> Language Class Initialized
ERROR - 2018-07-26 03:53:42 --> 404 Page Not Found: /index
INFO - 2018-07-26 04:34:25 --> Config Class Initialized
INFO - 2018-07-26 04:34:25 --> Hooks Class Initialized
DEBUG - 2018-07-26 04:34:25 --> UTF-8 Support Enabled
INFO - 2018-07-26 04:34:25 --> Utf8 Class Initialized
INFO - 2018-07-26 04:34:25 --> URI Class Initialized
INFO - 2018-07-26 04:34:25 --> Router Class Initialized
INFO - 2018-07-26 04:34:25 --> Output Class Initialized
INFO - 2018-07-26 04:34:25 --> Security Class Initialized
DEBUG - 2018-07-26 04:34:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 04:34:25 --> Input Class Initialized
INFO - 2018-07-26 04:34:25 --> Language Class Initialized
INFO - 2018-07-26 04:34:25 --> Language Class Initialized
INFO - 2018-07-26 04:34:25 --> Config Class Initialized
INFO - 2018-07-26 04:34:25 --> Loader Class Initialized
DEBUG - 2018-07-26 04:34:25 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-26 04:34:25 --> Helper loaded: url_helper
INFO - 2018-07-26 04:34:25 --> Helper loaded: form_helper
INFO - 2018-07-26 04:34:25 --> Helper loaded: date_helper
INFO - 2018-07-26 04:34:25 --> Helper loaded: util_helper
INFO - 2018-07-26 04:34:25 --> Helper loaded: text_helper
INFO - 2018-07-26 04:34:25 --> Helper loaded: string_helper
INFO - 2018-07-26 04:34:25 --> Database Driver Class Initialized
DEBUG - 2018-07-26 04:34:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 04:34:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 04:34:25 --> Email Class Initialized
INFO - 2018-07-26 04:34:25 --> Controller Class Initialized
DEBUG - 2018-07-26 04:34:25 --> Login MX_Controller Initialized
INFO - 2018-07-26 04:34:25 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-26 04:34:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-26 04:34:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-26 04:34:25 --> Email starts for colin-admin fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-07-26 04:34:25 --> User session created for 1
INFO - 2018-07-26 04:34:25 --> Login status colin-admin - success
INFO - 2018-07-26 04:34:25 --> Final output sent to browser
DEBUG - 2018-07-26 04:34:25 --> Total execution time: 0.3813
INFO - 2018-07-26 04:34:25 --> Config Class Initialized
INFO - 2018-07-26 04:34:25 --> Hooks Class Initialized
DEBUG - 2018-07-26 04:34:25 --> UTF-8 Support Enabled
INFO - 2018-07-26 04:34:25 --> Utf8 Class Initialized
INFO - 2018-07-26 04:34:25 --> URI Class Initialized
INFO - 2018-07-26 04:34:25 --> Router Class Initialized
INFO - 2018-07-26 04:34:25 --> Output Class Initialized
INFO - 2018-07-26 04:34:25 --> Security Class Initialized
DEBUG - 2018-07-26 04:34:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 04:34:25 --> Input Class Initialized
INFO - 2018-07-26 04:34:25 --> Language Class Initialized
INFO - 2018-07-26 04:34:26 --> Language Class Initialized
INFO - 2018-07-26 04:34:26 --> Config Class Initialized
INFO - 2018-07-26 04:34:26 --> Loader Class Initialized
DEBUG - 2018-07-26 04:34:26 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-26 04:34:26 --> Helper loaded: url_helper
INFO - 2018-07-26 04:34:26 --> Helper loaded: form_helper
INFO - 2018-07-26 04:34:26 --> Helper loaded: date_helper
INFO - 2018-07-26 04:34:26 --> Helper loaded: util_helper
INFO - 2018-07-26 04:34:26 --> Helper loaded: text_helper
INFO - 2018-07-26 04:34:26 --> Helper loaded: string_helper
INFO - 2018-07-26 04:34:26 --> Database Driver Class Initialized
DEBUG - 2018-07-26 04:34:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 04:34:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 04:34:26 --> Email Class Initialized
INFO - 2018-07-26 04:34:26 --> Controller Class Initialized
DEBUG - 2018-07-26 04:34:26 --> Admin MX_Controller Initialized
INFO - 2018-07-26 04:34:26 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-26 04:34:26 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-26 04:34:26 --> Login MX_Controller Initialized
DEBUG - 2018-07-26 04:34:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-26 04:34:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-26 04:34:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-26 04:34:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-26 04:34:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-26 04:34:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-26 04:34:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-26 04:34:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/dashboard.php
INFO - 2018-07-26 04:34:26 --> Final output sent to browser
DEBUG - 2018-07-26 04:34:26 --> Total execution time: 0.4550
INFO - 2018-07-26 04:34:26 --> Config Class Initialized
INFO - 2018-07-26 04:34:26 --> Hooks Class Initialized
DEBUG - 2018-07-26 04:34:26 --> UTF-8 Support Enabled
INFO - 2018-07-26 04:34:26 --> Utf8 Class Initialized
INFO - 2018-07-26 04:34:26 --> URI Class Initialized
INFO - 2018-07-26 04:34:26 --> Router Class Initialized
INFO - 2018-07-26 04:34:26 --> Output Class Initialized
INFO - 2018-07-26 04:34:26 --> Security Class Initialized
DEBUG - 2018-07-26 04:34:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 04:34:26 --> Input Class Initialized
INFO - 2018-07-26 04:34:26 --> Config Class Initialized
INFO - 2018-07-26 04:34:26 --> Language Class Initialized
INFO - 2018-07-26 04:34:26 --> Hooks Class Initialized
DEBUG - 2018-07-26 04:34:26 --> UTF-8 Support Enabled
ERROR - 2018-07-26 04:34:26 --> 404 Page Not Found: /index
INFO - 2018-07-26 04:34:26 --> Utf8 Class Initialized
INFO - 2018-07-26 04:34:26 --> URI Class Initialized
INFO - 2018-07-26 04:34:26 --> Router Class Initialized
INFO - 2018-07-26 04:34:26 --> Output Class Initialized
INFO - 2018-07-26 04:34:26 --> Security Class Initialized
DEBUG - 2018-07-26 04:34:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 04:34:26 --> Input Class Initialized
INFO - 2018-07-26 04:34:26 --> Language Class Initialized
ERROR - 2018-07-26 04:34:26 --> 404 Page Not Found: /index
INFO - 2018-07-26 04:34:31 --> Config Class Initialized
INFO - 2018-07-26 04:34:31 --> Hooks Class Initialized
DEBUG - 2018-07-26 04:34:31 --> UTF-8 Support Enabled
INFO - 2018-07-26 04:34:31 --> Utf8 Class Initialized
INFO - 2018-07-26 04:34:31 --> URI Class Initialized
INFO - 2018-07-26 04:34:31 --> Router Class Initialized
INFO - 2018-07-26 04:34:31 --> Output Class Initialized
INFO - 2018-07-26 04:34:31 --> Security Class Initialized
DEBUG - 2018-07-26 04:34:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 04:34:31 --> Input Class Initialized
INFO - 2018-07-26 04:34:31 --> Language Class Initialized
INFO - 2018-07-26 04:34:31 --> Language Class Initialized
INFO - 2018-07-26 04:34:31 --> Config Class Initialized
INFO - 2018-07-26 04:34:31 --> Loader Class Initialized
DEBUG - 2018-07-26 04:34:31 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-26 04:34:31 --> Helper loaded: url_helper
INFO - 2018-07-26 04:34:31 --> Helper loaded: form_helper
INFO - 2018-07-26 04:34:31 --> Helper loaded: date_helper
INFO - 2018-07-26 04:34:31 --> Helper loaded: util_helper
INFO - 2018-07-26 04:34:31 --> Helper loaded: text_helper
INFO - 2018-07-26 04:34:31 --> Helper loaded: string_helper
INFO - 2018-07-26 04:34:31 --> Database Driver Class Initialized
DEBUG - 2018-07-26 04:34:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 04:34:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 04:34:31 --> Email Class Initialized
INFO - 2018-07-26 04:34:31 --> Controller Class Initialized
DEBUG - 2018-07-26 04:34:31 --> Users MX_Controller Initialized
DEBUG - 2018-07-26 04:34:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-26 04:34:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-26 04:34:31 --> Helper loaded: file_helper
DEBUG - 2018-07-26 04:34:31 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-26 04:34:31 --> Login MX_Controller Initialized
INFO - 2018-07-26 04:34:31 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-26 04:34:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-26 04:34:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-26 04:34:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-26 04:34:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-26 04:34:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-26 04:34:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-26 04:34:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-07-26 04:34:32 --> Final output sent to browser
DEBUG - 2018-07-26 04:34:32 --> Total execution time: 0.4646
INFO - 2018-07-26 04:34:32 --> Config Class Initialized
INFO - 2018-07-26 04:34:32 --> Hooks Class Initialized
DEBUG - 2018-07-26 04:34:32 --> UTF-8 Support Enabled
INFO - 2018-07-26 04:34:32 --> Utf8 Class Initialized
INFO - 2018-07-26 04:34:32 --> URI Class Initialized
INFO - 2018-07-26 04:34:32 --> Router Class Initialized
INFO - 2018-07-26 04:34:32 --> Output Class Initialized
INFO - 2018-07-26 04:34:32 --> Security Class Initialized
DEBUG - 2018-07-26 04:34:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 04:34:32 --> Input Class Initialized
INFO - 2018-07-26 04:34:32 --> Language Class Initialized
INFO - 2018-07-26 04:34:32 --> Language Class Initialized
INFO - 2018-07-26 04:34:32 --> Config Class Initialized
INFO - 2018-07-26 04:34:32 --> Loader Class Initialized
DEBUG - 2018-07-26 04:34:32 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-26 04:34:32 --> Helper loaded: url_helper
INFO - 2018-07-26 04:34:32 --> Helper loaded: form_helper
INFO - 2018-07-26 04:34:32 --> Helper loaded: date_helper
INFO - 2018-07-26 04:34:32 --> Helper loaded: util_helper
INFO - 2018-07-26 04:34:32 --> Helper loaded: text_helper
INFO - 2018-07-26 04:34:32 --> Helper loaded: string_helper
INFO - 2018-07-26 04:34:32 --> Database Driver Class Initialized
DEBUG - 2018-07-26 04:34:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 04:34:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 04:34:32 --> Email Class Initialized
INFO - 2018-07-26 04:34:32 --> Controller Class Initialized
DEBUG - 2018-07-26 04:34:32 --> Users MX_Controller Initialized
DEBUG - 2018-07-26 04:34:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-26 04:34:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-26 04:34:32 --> Helper loaded: file_helper
DEBUG - 2018-07-26 04:34:32 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-26 04:34:32 --> Login MX_Controller Initialized
INFO - 2018-07-26 04:34:32 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-26 04:34:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-26 04:34:32 --> Final output sent to browser
DEBUG - 2018-07-26 04:34:32 --> Total execution time: 0.5737
INFO - 2018-07-26 04:35:03 --> Config Class Initialized
INFO - 2018-07-26 04:35:03 --> Hooks Class Initialized
DEBUG - 2018-07-26 04:35:03 --> UTF-8 Support Enabled
INFO - 2018-07-26 04:35:03 --> Utf8 Class Initialized
INFO - 2018-07-26 04:35:03 --> URI Class Initialized
INFO - 2018-07-26 04:35:03 --> Router Class Initialized
INFO - 2018-07-26 04:35:03 --> Output Class Initialized
INFO - 2018-07-26 04:35:03 --> Security Class Initialized
DEBUG - 2018-07-26 04:35:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 04:35:03 --> Input Class Initialized
INFO - 2018-07-26 04:35:03 --> Language Class Initialized
INFO - 2018-07-26 04:35:03 --> Language Class Initialized
INFO - 2018-07-26 04:35:03 --> Config Class Initialized
INFO - 2018-07-26 04:35:03 --> Loader Class Initialized
DEBUG - 2018-07-26 04:35:03 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-26 04:35:03 --> Helper loaded: url_helper
INFO - 2018-07-26 04:35:03 --> Helper loaded: form_helper
INFO - 2018-07-26 04:35:03 --> Helper loaded: date_helper
INFO - 2018-07-26 04:35:03 --> Helper loaded: util_helper
INFO - 2018-07-26 04:35:03 --> Helper loaded: text_helper
INFO - 2018-07-26 04:35:03 --> Helper loaded: string_helper
INFO - 2018-07-26 04:35:03 --> Database Driver Class Initialized
DEBUG - 2018-07-26 04:35:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 04:35:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 04:35:03 --> Email Class Initialized
INFO - 2018-07-26 04:35:03 --> Controller Class Initialized
DEBUG - 2018-07-26 04:35:03 --> Profile MX_Controller Initialized
INFO - 2018-07-26 04:35:03 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-26 04:35:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-26 04:35:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Profile_model.php
DEBUG - 2018-07-26 04:35:03 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-26 04:35:03 --> Login MX_Controller Initialized
DEBUG - 2018-07-26 04:35:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-26 04:35:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-26 04:35:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-26 04:35:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-26 04:35:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-26 04:35:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-26 04:35:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/profile.php
INFO - 2018-07-26 04:35:03 --> Final output sent to browser
DEBUG - 2018-07-26 04:35:03 --> Total execution time: 0.4778
INFO - 2018-07-26 04:35:29 --> Config Class Initialized
INFO - 2018-07-26 04:35:29 --> Hooks Class Initialized
DEBUG - 2018-07-26 04:35:29 --> UTF-8 Support Enabled
INFO - 2018-07-26 04:35:29 --> Utf8 Class Initialized
INFO - 2018-07-26 04:35:29 --> URI Class Initialized
INFO - 2018-07-26 04:35:29 --> Router Class Initialized
INFO - 2018-07-26 04:35:29 --> Output Class Initialized
INFO - 2018-07-26 04:35:29 --> Security Class Initialized
DEBUG - 2018-07-26 04:35:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 04:35:29 --> Input Class Initialized
INFO - 2018-07-26 04:35:29 --> Language Class Initialized
INFO - 2018-07-26 04:35:29 --> Language Class Initialized
INFO - 2018-07-26 04:35:29 --> Config Class Initialized
INFO - 2018-07-26 04:35:29 --> Loader Class Initialized
DEBUG - 2018-07-26 04:35:29 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-26 04:35:29 --> Helper loaded: url_helper
INFO - 2018-07-26 04:35:29 --> Helper loaded: form_helper
INFO - 2018-07-26 04:35:29 --> Helper loaded: date_helper
INFO - 2018-07-26 04:35:29 --> Helper loaded: util_helper
INFO - 2018-07-26 04:35:29 --> Helper loaded: text_helper
INFO - 2018-07-26 04:35:29 --> Helper loaded: string_helper
INFO - 2018-07-26 04:35:29 --> Database Driver Class Initialized
DEBUG - 2018-07-26 04:35:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 04:35:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 04:35:29 --> Email Class Initialized
INFO - 2018-07-26 04:35:29 --> Controller Class Initialized
DEBUG - 2018-07-26 04:35:29 --> Users MX_Controller Initialized
DEBUG - 2018-07-26 04:35:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-26 04:35:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-26 04:35:29 --> Helper loaded: file_helper
DEBUG - 2018-07-26 04:35:29 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-26 04:35:29 --> Login MX_Controller Initialized
INFO - 2018-07-26 04:35:29 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-26 04:35:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-26 04:35:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-26 04:35:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-26 04:35:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-26 04:35:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-26 04:35:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-26 04:35:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-07-26 04:35:30 --> Final output sent to browser
DEBUG - 2018-07-26 04:35:30 --> Total execution time: 0.4650
INFO - 2018-07-26 04:35:30 --> Config Class Initialized
INFO - 2018-07-26 04:35:30 --> Hooks Class Initialized
DEBUG - 2018-07-26 04:35:30 --> UTF-8 Support Enabled
INFO - 2018-07-26 04:35:30 --> Utf8 Class Initialized
INFO - 2018-07-26 04:35:30 --> URI Class Initialized
INFO - 2018-07-26 04:35:30 --> Router Class Initialized
INFO - 2018-07-26 04:35:30 --> Output Class Initialized
INFO - 2018-07-26 04:35:30 --> Security Class Initialized
DEBUG - 2018-07-26 04:35:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 04:35:30 --> Input Class Initialized
INFO - 2018-07-26 04:35:30 --> Language Class Initialized
INFO - 2018-07-26 04:35:30 --> Language Class Initialized
INFO - 2018-07-26 04:35:30 --> Config Class Initialized
INFO - 2018-07-26 04:35:30 --> Loader Class Initialized
DEBUG - 2018-07-26 04:35:30 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-26 04:35:30 --> Helper loaded: url_helper
INFO - 2018-07-26 04:35:30 --> Helper loaded: form_helper
INFO - 2018-07-26 04:35:30 --> Helper loaded: date_helper
INFO - 2018-07-26 04:35:30 --> Helper loaded: util_helper
INFO - 2018-07-26 04:35:30 --> Helper loaded: text_helper
INFO - 2018-07-26 04:35:30 --> Helper loaded: string_helper
INFO - 2018-07-26 04:35:30 --> Database Driver Class Initialized
DEBUG - 2018-07-26 04:35:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 04:35:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 04:35:30 --> Email Class Initialized
INFO - 2018-07-26 04:35:30 --> Controller Class Initialized
DEBUG - 2018-07-26 04:35:30 --> Users MX_Controller Initialized
DEBUG - 2018-07-26 04:35:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-26 04:35:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-26 04:35:30 --> Helper loaded: file_helper
DEBUG - 2018-07-26 04:35:30 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-26 04:35:30 --> Login MX_Controller Initialized
INFO - 2018-07-26 04:35:30 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-26 04:35:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-26 04:35:31 --> Final output sent to browser
DEBUG - 2018-07-26 04:35:31 --> Total execution time: 0.5942
INFO - 2018-07-26 04:38:34 --> Config Class Initialized
INFO - 2018-07-26 04:38:34 --> Hooks Class Initialized
DEBUG - 2018-07-26 04:38:34 --> UTF-8 Support Enabled
INFO - 2018-07-26 04:38:34 --> Utf8 Class Initialized
INFO - 2018-07-26 04:38:34 --> URI Class Initialized
INFO - 2018-07-26 04:38:34 --> Router Class Initialized
INFO - 2018-07-26 04:38:34 --> Output Class Initialized
INFO - 2018-07-26 04:38:34 --> Security Class Initialized
DEBUG - 2018-07-26 04:38:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 04:38:34 --> Input Class Initialized
INFO - 2018-07-26 04:38:34 --> Language Class Initialized
INFO - 2018-07-26 04:38:34 --> Language Class Initialized
INFO - 2018-07-26 04:38:34 --> Config Class Initialized
INFO - 2018-07-26 04:38:34 --> Loader Class Initialized
DEBUG - 2018-07-26 04:38:34 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-26 04:38:35 --> Helper loaded: url_helper
INFO - 2018-07-26 04:38:35 --> Helper loaded: form_helper
INFO - 2018-07-26 04:38:35 --> Helper loaded: date_helper
INFO - 2018-07-26 04:38:35 --> Helper loaded: util_helper
INFO - 2018-07-26 04:38:35 --> Helper loaded: text_helper
INFO - 2018-07-26 04:38:35 --> Helper loaded: string_helper
INFO - 2018-07-26 04:38:35 --> Database Driver Class Initialized
DEBUG - 2018-07-26 04:38:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 04:38:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 04:38:35 --> Email Class Initialized
INFO - 2018-07-26 04:38:35 --> Controller Class Initialized
DEBUG - 2018-07-26 04:38:35 --> Users MX_Controller Initialized
DEBUG - 2018-07-26 04:38:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-26 04:38:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-26 04:38:35 --> Helper loaded: file_helper
DEBUG - 2018-07-26 04:38:35 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-26 04:38:35 --> Login MX_Controller Initialized
INFO - 2018-07-26 04:38:35 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-26 04:38:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-26 04:38:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-26 04:38:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-26 04:38:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-26 04:38:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-26 04:38:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-26 04:38:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-07-26 04:38:35 --> Final output sent to browser
DEBUG - 2018-07-26 04:38:35 --> Total execution time: 0.4718
INFO - 2018-07-26 04:38:35 --> Config Class Initialized
INFO - 2018-07-26 04:38:35 --> Hooks Class Initialized
DEBUG - 2018-07-26 04:38:35 --> UTF-8 Support Enabled
INFO - 2018-07-26 04:38:35 --> Utf8 Class Initialized
INFO - 2018-07-26 04:38:35 --> URI Class Initialized
INFO - 2018-07-26 04:38:35 --> Router Class Initialized
INFO - 2018-07-26 04:38:35 --> Output Class Initialized
INFO - 2018-07-26 04:38:35 --> Security Class Initialized
DEBUG - 2018-07-26 04:38:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 04:38:35 --> Input Class Initialized
INFO - 2018-07-26 04:38:35 --> Language Class Initialized
INFO - 2018-07-26 04:38:35 --> Language Class Initialized
INFO - 2018-07-26 04:38:35 --> Config Class Initialized
INFO - 2018-07-26 04:38:35 --> Loader Class Initialized
DEBUG - 2018-07-26 04:38:35 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-26 04:38:35 --> Helper loaded: url_helper
INFO - 2018-07-26 04:38:35 --> Helper loaded: form_helper
INFO - 2018-07-26 04:38:35 --> Helper loaded: date_helper
INFO - 2018-07-26 04:38:36 --> Helper loaded: util_helper
INFO - 2018-07-26 04:38:36 --> Helper loaded: text_helper
INFO - 2018-07-26 04:38:36 --> Helper loaded: string_helper
INFO - 2018-07-26 04:38:36 --> Database Driver Class Initialized
DEBUG - 2018-07-26 04:38:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 04:38:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 04:38:36 --> Email Class Initialized
INFO - 2018-07-26 04:38:36 --> Controller Class Initialized
DEBUG - 2018-07-26 04:38:36 --> Users MX_Controller Initialized
DEBUG - 2018-07-26 04:38:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-26 04:38:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-26 04:38:36 --> Helper loaded: file_helper
DEBUG - 2018-07-26 04:38:36 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-26 04:38:36 --> Login MX_Controller Initialized
INFO - 2018-07-26 04:38:36 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-26 04:38:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-26 04:38:36 --> Final output sent to browser
DEBUG - 2018-07-26 04:38:36 --> Total execution time: 0.5734
INFO - 2018-07-26 04:40:25 --> Config Class Initialized
INFO - 2018-07-26 04:40:25 --> Hooks Class Initialized
DEBUG - 2018-07-26 04:40:25 --> UTF-8 Support Enabled
INFO - 2018-07-26 04:40:25 --> Utf8 Class Initialized
INFO - 2018-07-26 04:40:25 --> URI Class Initialized
INFO - 2018-07-26 04:40:25 --> Router Class Initialized
INFO - 2018-07-26 04:40:25 --> Output Class Initialized
INFO - 2018-07-26 04:40:25 --> Security Class Initialized
DEBUG - 2018-07-26 04:40:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 04:40:25 --> Input Class Initialized
INFO - 2018-07-26 04:40:25 --> Language Class Initialized
INFO - 2018-07-26 04:40:25 --> Language Class Initialized
INFO - 2018-07-26 04:40:25 --> Config Class Initialized
INFO - 2018-07-26 04:40:25 --> Loader Class Initialized
DEBUG - 2018-07-26 04:40:25 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-26 04:40:25 --> Helper loaded: url_helper
INFO - 2018-07-26 04:40:25 --> Helper loaded: form_helper
INFO - 2018-07-26 04:40:25 --> Helper loaded: date_helper
INFO - 2018-07-26 04:40:25 --> Helper loaded: util_helper
INFO - 2018-07-26 04:40:25 --> Helper loaded: text_helper
INFO - 2018-07-26 04:40:25 --> Helper loaded: string_helper
INFO - 2018-07-26 04:40:25 --> Database Driver Class Initialized
DEBUG - 2018-07-26 04:40:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 04:40:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 04:40:25 --> Email Class Initialized
INFO - 2018-07-26 04:40:25 --> Controller Class Initialized
DEBUG - 2018-07-26 04:40:25 --> Login MX_Controller Initialized
INFO - 2018-07-26 04:40:25 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-26 04:40:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-26 04:40:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-26 04:40:25 --> 1 Loggedout
INFO - 2018-07-26 04:40:25 --> Config Class Initialized
INFO - 2018-07-26 04:40:25 --> Hooks Class Initialized
DEBUG - 2018-07-26 04:40:25 --> UTF-8 Support Enabled
INFO - 2018-07-26 04:40:25 --> Utf8 Class Initialized
INFO - 2018-07-26 04:40:25 --> URI Class Initialized
INFO - 2018-07-26 04:40:25 --> Router Class Initialized
INFO - 2018-07-26 04:40:25 --> Output Class Initialized
INFO - 2018-07-26 04:40:25 --> Security Class Initialized
DEBUG - 2018-07-26 04:40:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 04:40:25 --> Input Class Initialized
INFO - 2018-07-26 04:40:25 --> Language Class Initialized
INFO - 2018-07-26 04:40:25 --> Language Class Initialized
INFO - 2018-07-26 04:40:25 --> Config Class Initialized
INFO - 2018-07-26 04:40:25 --> Loader Class Initialized
DEBUG - 2018-07-26 04:40:25 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-26 04:40:25 --> Helper loaded: url_helper
INFO - 2018-07-26 04:40:25 --> Helper loaded: form_helper
INFO - 2018-07-26 04:40:25 --> Helper loaded: date_helper
INFO - 2018-07-26 04:40:25 --> Helper loaded: util_helper
INFO - 2018-07-26 04:40:25 --> Helper loaded: text_helper
INFO - 2018-07-26 04:40:25 --> Helper loaded: string_helper
INFO - 2018-07-26 04:40:25 --> Database Driver Class Initialized
DEBUG - 2018-07-26 04:40:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 04:40:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 04:40:25 --> Email Class Initialized
INFO - 2018-07-26 04:40:25 --> Controller Class Initialized
DEBUG - 2018-07-26 04:40:25 --> Admin MX_Controller Initialized
INFO - 2018-07-26 04:40:25 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-26 04:40:25 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-26 04:40:26 --> Login MX_Controller Initialized
DEBUG - 2018-07-26 04:40:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-26 04:40:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-26 04:40:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
INFO - 2018-07-26 04:40:26 --> Config Class Initialized
INFO - 2018-07-26 04:40:26 --> Hooks Class Initialized
DEBUG - 2018-07-26 04:40:26 --> UTF-8 Support Enabled
INFO - 2018-07-26 04:40:26 --> Utf8 Class Initialized
INFO - 2018-07-26 04:40:26 --> URI Class Initialized
INFO - 2018-07-26 04:40:26 --> Router Class Initialized
INFO - 2018-07-26 04:40:26 --> Output Class Initialized
INFO - 2018-07-26 04:40:26 --> Security Class Initialized
DEBUG - 2018-07-26 04:40:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 04:40:26 --> Input Class Initialized
INFO - 2018-07-26 04:40:26 --> Language Class Initialized
ERROR - 2018-07-26 04:40:26 --> 404 Page Not Found: /index
INFO - 2018-07-26 04:40:29 --> Config Class Initialized
INFO - 2018-07-26 04:40:29 --> Hooks Class Initialized
DEBUG - 2018-07-26 04:40:29 --> UTF-8 Support Enabled
INFO - 2018-07-26 04:40:29 --> Utf8 Class Initialized
INFO - 2018-07-26 04:40:29 --> URI Class Initialized
INFO - 2018-07-26 04:40:29 --> Router Class Initialized
INFO - 2018-07-26 04:40:29 --> Output Class Initialized
INFO - 2018-07-26 04:40:29 --> Security Class Initialized
DEBUG - 2018-07-26 04:40:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 04:40:29 --> Input Class Initialized
INFO - 2018-07-26 04:40:29 --> Language Class Initialized
INFO - 2018-07-26 04:40:29 --> Language Class Initialized
INFO - 2018-07-26 04:40:29 --> Config Class Initialized
INFO - 2018-07-26 04:40:29 --> Loader Class Initialized
DEBUG - 2018-07-26 04:40:29 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-26 04:40:29 --> Helper loaded: url_helper
INFO - 2018-07-26 04:40:29 --> Helper loaded: form_helper
INFO - 2018-07-26 04:40:29 --> Helper loaded: date_helper
INFO - 2018-07-26 04:40:29 --> Helper loaded: util_helper
INFO - 2018-07-26 04:40:29 --> Helper loaded: text_helper
INFO - 2018-07-26 04:40:29 --> Helper loaded: string_helper
INFO - 2018-07-26 04:40:29 --> Database Driver Class Initialized
DEBUG - 2018-07-26 04:40:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 04:40:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 04:40:29 --> Email Class Initialized
INFO - 2018-07-26 04:40:29 --> Controller Class Initialized
DEBUG - 2018-07-26 04:40:29 --> Login MX_Controller Initialized
INFO - 2018-07-26 04:40:29 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-26 04:40:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-26 04:40:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-26 04:40:29 --> Email starts for colin-admin fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-07-26 04:40:29 --> User session created for 1
INFO - 2018-07-26 04:40:29 --> Login status colin-admin - success
INFO - 2018-07-26 04:40:29 --> Final output sent to browser
DEBUG - 2018-07-26 04:40:29 --> Total execution time: 0.4319
INFO - 2018-07-26 04:40:29 --> Config Class Initialized
INFO - 2018-07-26 04:40:29 --> Hooks Class Initialized
DEBUG - 2018-07-26 04:40:29 --> UTF-8 Support Enabled
INFO - 2018-07-26 04:40:29 --> Utf8 Class Initialized
INFO - 2018-07-26 04:40:30 --> URI Class Initialized
INFO - 2018-07-26 04:40:30 --> Router Class Initialized
INFO - 2018-07-26 04:40:30 --> Output Class Initialized
INFO - 2018-07-26 04:40:30 --> Security Class Initialized
DEBUG - 2018-07-26 04:40:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 04:40:30 --> Input Class Initialized
INFO - 2018-07-26 04:40:30 --> Language Class Initialized
INFO - 2018-07-26 04:40:30 --> Language Class Initialized
INFO - 2018-07-26 04:40:30 --> Config Class Initialized
INFO - 2018-07-26 04:40:30 --> Loader Class Initialized
DEBUG - 2018-07-26 04:40:30 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-26 04:40:30 --> Helper loaded: url_helper
INFO - 2018-07-26 04:40:30 --> Helper loaded: form_helper
INFO - 2018-07-26 04:40:30 --> Helper loaded: date_helper
INFO - 2018-07-26 04:40:30 --> Helper loaded: util_helper
INFO - 2018-07-26 04:40:30 --> Helper loaded: text_helper
INFO - 2018-07-26 04:40:30 --> Helper loaded: string_helper
INFO - 2018-07-26 04:40:30 --> Database Driver Class Initialized
DEBUG - 2018-07-26 04:40:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 04:40:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 04:40:30 --> Email Class Initialized
INFO - 2018-07-26 04:40:30 --> Controller Class Initialized
DEBUG - 2018-07-26 04:40:30 --> Admin MX_Controller Initialized
INFO - 2018-07-26 04:40:30 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-26 04:40:30 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-26 04:40:30 --> Login MX_Controller Initialized
DEBUG - 2018-07-26 04:40:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-26 04:40:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-26 04:40:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-26 04:40:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-26 04:40:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-26 04:40:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-26 04:40:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-26 04:40:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/dashboard.php
INFO - 2018-07-26 04:40:30 --> Final output sent to browser
DEBUG - 2018-07-26 04:40:30 --> Total execution time: 0.7155
INFO - 2018-07-26 04:40:30 --> Config Class Initialized
INFO - 2018-07-26 04:40:30 --> Hooks Class Initialized
DEBUG - 2018-07-26 04:40:30 --> UTF-8 Support Enabled
INFO - 2018-07-26 04:40:30 --> Utf8 Class Initialized
INFO - 2018-07-26 04:40:31 --> URI Class Initialized
INFO - 2018-07-26 04:40:31 --> Router Class Initialized
INFO - 2018-07-26 04:40:31 --> Output Class Initialized
INFO - 2018-07-26 04:40:31 --> Security Class Initialized
DEBUG - 2018-07-26 04:40:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 04:40:31 --> Input Class Initialized
INFO - 2018-07-26 04:40:31 --> Language Class Initialized
ERROR - 2018-07-26 04:40:31 --> 404 Page Not Found: /index
INFO - 2018-07-26 04:40:31 --> Config Class Initialized
INFO - 2018-07-26 04:40:31 --> Hooks Class Initialized
DEBUG - 2018-07-26 04:40:31 --> UTF-8 Support Enabled
INFO - 2018-07-26 04:40:31 --> Utf8 Class Initialized
INFO - 2018-07-26 04:40:31 --> URI Class Initialized
INFO - 2018-07-26 04:40:31 --> Router Class Initialized
INFO - 2018-07-26 04:40:31 --> Output Class Initialized
INFO - 2018-07-26 04:40:31 --> Security Class Initialized
DEBUG - 2018-07-26 04:40:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 04:40:31 --> Input Class Initialized
INFO - 2018-07-26 04:40:31 --> Language Class Initialized
ERROR - 2018-07-26 04:40:31 --> 404 Page Not Found: /index
INFO - 2018-07-26 04:40:35 --> Config Class Initialized
INFO - 2018-07-26 04:40:35 --> Hooks Class Initialized
DEBUG - 2018-07-26 04:40:35 --> UTF-8 Support Enabled
INFO - 2018-07-26 04:40:35 --> Utf8 Class Initialized
INFO - 2018-07-26 04:40:35 --> URI Class Initialized
INFO - 2018-07-26 04:40:35 --> Router Class Initialized
INFO - 2018-07-26 04:40:35 --> Output Class Initialized
INFO - 2018-07-26 04:40:35 --> Security Class Initialized
DEBUG - 2018-07-26 04:40:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 04:40:36 --> Input Class Initialized
INFO - 2018-07-26 04:40:36 --> Language Class Initialized
INFO - 2018-07-26 04:40:36 --> Language Class Initialized
INFO - 2018-07-26 04:40:36 --> Config Class Initialized
INFO - 2018-07-26 04:40:36 --> Loader Class Initialized
DEBUG - 2018-07-26 04:40:36 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-26 04:40:36 --> Helper loaded: url_helper
INFO - 2018-07-26 04:40:36 --> Helper loaded: form_helper
INFO - 2018-07-26 04:40:36 --> Helper loaded: date_helper
INFO - 2018-07-26 04:40:36 --> Helper loaded: util_helper
INFO - 2018-07-26 04:40:36 --> Helper loaded: text_helper
INFO - 2018-07-26 04:40:36 --> Helper loaded: string_helper
INFO - 2018-07-26 04:40:36 --> Database Driver Class Initialized
DEBUG - 2018-07-26 04:40:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 04:40:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 04:40:36 --> Email Class Initialized
INFO - 2018-07-26 04:40:36 --> Controller Class Initialized
DEBUG - 2018-07-26 04:40:36 --> Users MX_Controller Initialized
DEBUG - 2018-07-26 04:40:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-26 04:40:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-26 04:40:36 --> Helper loaded: file_helper
DEBUG - 2018-07-26 04:40:36 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-26 04:40:36 --> Login MX_Controller Initialized
INFO - 2018-07-26 04:40:36 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-26 04:40:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-26 04:40:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-26 04:40:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-26 04:40:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-26 04:40:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-26 04:40:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-26 04:40:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-07-26 04:40:36 --> Final output sent to browser
DEBUG - 2018-07-26 04:40:36 --> Total execution time: 0.4784
INFO - 2018-07-26 04:40:36 --> Config Class Initialized
INFO - 2018-07-26 04:40:36 --> Hooks Class Initialized
DEBUG - 2018-07-26 04:40:36 --> UTF-8 Support Enabled
INFO - 2018-07-26 04:40:36 --> Utf8 Class Initialized
INFO - 2018-07-26 04:40:36 --> URI Class Initialized
INFO - 2018-07-26 04:40:36 --> Router Class Initialized
INFO - 2018-07-26 04:40:36 --> Output Class Initialized
INFO - 2018-07-26 04:40:36 --> Security Class Initialized
DEBUG - 2018-07-26 04:40:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 04:40:36 --> Input Class Initialized
INFO - 2018-07-26 04:40:36 --> Language Class Initialized
INFO - 2018-07-26 04:40:36 --> Language Class Initialized
INFO - 2018-07-26 04:40:36 --> Config Class Initialized
INFO - 2018-07-26 04:40:36 --> Loader Class Initialized
DEBUG - 2018-07-26 04:40:36 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-26 04:40:36 --> Helper loaded: url_helper
INFO - 2018-07-26 04:40:36 --> Helper loaded: form_helper
INFO - 2018-07-26 04:40:36 --> Helper loaded: date_helper
INFO - 2018-07-26 04:40:37 --> Helper loaded: util_helper
INFO - 2018-07-26 04:40:37 --> Helper loaded: text_helper
INFO - 2018-07-26 04:40:37 --> Helper loaded: string_helper
INFO - 2018-07-26 04:40:37 --> Database Driver Class Initialized
DEBUG - 2018-07-26 04:40:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 04:40:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 04:40:37 --> Email Class Initialized
INFO - 2018-07-26 04:40:37 --> Controller Class Initialized
DEBUG - 2018-07-26 04:40:37 --> Users MX_Controller Initialized
DEBUG - 2018-07-26 04:40:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-26 04:40:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-26 04:40:37 --> Helper loaded: file_helper
DEBUG - 2018-07-26 04:40:37 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-26 04:40:37 --> Login MX_Controller Initialized
INFO - 2018-07-26 04:40:37 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-26 04:40:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-26 04:40:37 --> Final output sent to browser
DEBUG - 2018-07-26 04:40:37 --> Total execution time: 0.6381
INFO - 2018-07-26 04:40:38 --> Config Class Initialized
INFO - 2018-07-26 04:40:38 --> Hooks Class Initialized
DEBUG - 2018-07-26 04:40:38 --> UTF-8 Support Enabled
INFO - 2018-07-26 04:40:38 --> Utf8 Class Initialized
INFO - 2018-07-26 04:40:38 --> URI Class Initialized
INFO - 2018-07-26 04:40:38 --> Router Class Initialized
INFO - 2018-07-26 04:40:38 --> Output Class Initialized
INFO - 2018-07-26 04:40:38 --> Security Class Initialized
DEBUG - 2018-07-26 04:40:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 04:40:38 --> Input Class Initialized
INFO - 2018-07-26 04:40:38 --> Language Class Initialized
INFO - 2018-07-26 04:40:38 --> Language Class Initialized
INFO - 2018-07-26 04:40:38 --> Config Class Initialized
INFO - 2018-07-26 04:40:39 --> Loader Class Initialized
DEBUG - 2018-07-26 04:40:39 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-26 04:40:39 --> Helper loaded: url_helper
INFO - 2018-07-26 04:40:39 --> Helper loaded: form_helper
INFO - 2018-07-26 04:40:39 --> Helper loaded: date_helper
INFO - 2018-07-26 04:40:39 --> Helper loaded: util_helper
INFO - 2018-07-26 04:40:39 --> Helper loaded: text_helper
INFO - 2018-07-26 04:40:39 --> Helper loaded: string_helper
INFO - 2018-07-26 04:40:39 --> Database Driver Class Initialized
DEBUG - 2018-07-26 04:40:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 04:40:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 04:40:39 --> Email Class Initialized
INFO - 2018-07-26 04:40:39 --> Controller Class Initialized
DEBUG - 2018-07-26 04:40:39 --> Users MX_Controller Initialized
DEBUG - 2018-07-26 04:40:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-26 04:40:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-26 04:40:39 --> Helper loaded: file_helper
DEBUG - 2018-07-26 04:40:39 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-26 04:40:39 --> Login MX_Controller Initialized
INFO - 2018-07-26 04:40:39 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-26 04:40:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-26 04:40:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-26 04:40:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-26 04:40:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-26 04:40:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-26 04:40:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-26 04:40:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-26 04:40:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-07-26 04:40:39 --> Final output sent to browser
DEBUG - 2018-07-26 04:40:39 --> Total execution time: 0.5423
INFO - 2018-07-26 04:40:42 --> Config Class Initialized
INFO - 2018-07-26 04:40:42 --> Hooks Class Initialized
DEBUG - 2018-07-26 04:40:42 --> UTF-8 Support Enabled
INFO - 2018-07-26 04:40:42 --> Utf8 Class Initialized
INFO - 2018-07-26 04:40:42 --> URI Class Initialized
INFO - 2018-07-26 04:40:42 --> Router Class Initialized
INFO - 2018-07-26 04:40:42 --> Output Class Initialized
INFO - 2018-07-26 04:40:42 --> Security Class Initialized
DEBUG - 2018-07-26 04:40:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 04:40:42 --> Input Class Initialized
INFO - 2018-07-26 04:40:42 --> Language Class Initialized
INFO - 2018-07-26 04:40:42 --> Language Class Initialized
INFO - 2018-07-26 04:40:42 --> Config Class Initialized
INFO - 2018-07-26 04:40:42 --> Loader Class Initialized
DEBUG - 2018-07-26 04:40:42 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-26 04:40:42 --> Helper loaded: url_helper
INFO - 2018-07-26 04:40:42 --> Helper loaded: form_helper
INFO - 2018-07-26 04:40:42 --> Helper loaded: date_helper
INFO - 2018-07-26 04:40:42 --> Helper loaded: util_helper
INFO - 2018-07-26 04:40:42 --> Helper loaded: text_helper
INFO - 2018-07-26 04:40:42 --> Helper loaded: string_helper
INFO - 2018-07-26 04:40:42 --> Database Driver Class Initialized
DEBUG - 2018-07-26 04:40:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 04:40:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 04:40:42 --> Email Class Initialized
INFO - 2018-07-26 04:40:42 --> Controller Class Initialized
DEBUG - 2018-07-26 04:40:42 --> Users MX_Controller Initialized
DEBUG - 2018-07-26 04:40:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-26 04:40:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-26 04:40:42 --> Helper loaded: file_helper
DEBUG - 2018-07-26 04:40:42 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-26 04:40:42 --> Login MX_Controller Initialized
INFO - 2018-07-26 04:40:42 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-26 04:40:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-26 04:40:42 --> Final output sent to browser
DEBUG - 2018-07-26 04:40:42 --> Total execution time: 0.4531
INFO - 2018-07-26 04:41:23 --> Config Class Initialized
INFO - 2018-07-26 04:41:23 --> Hooks Class Initialized
DEBUG - 2018-07-26 04:41:23 --> UTF-8 Support Enabled
INFO - 2018-07-26 04:41:23 --> Utf8 Class Initialized
INFO - 2018-07-26 04:41:23 --> URI Class Initialized
INFO - 2018-07-26 04:41:23 --> Router Class Initialized
INFO - 2018-07-26 04:41:23 --> Output Class Initialized
INFO - 2018-07-26 04:41:23 --> Security Class Initialized
DEBUG - 2018-07-26 04:41:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 04:41:23 --> Input Class Initialized
INFO - 2018-07-26 04:41:24 --> Language Class Initialized
INFO - 2018-07-26 04:41:24 --> Language Class Initialized
INFO - 2018-07-26 04:41:24 --> Config Class Initialized
INFO - 2018-07-26 04:41:24 --> Loader Class Initialized
DEBUG - 2018-07-26 04:41:24 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-26 04:41:24 --> Helper loaded: url_helper
INFO - 2018-07-26 04:41:24 --> Helper loaded: form_helper
INFO - 2018-07-26 04:41:24 --> Helper loaded: date_helper
INFO - 2018-07-26 04:41:24 --> Helper loaded: util_helper
INFO - 2018-07-26 04:41:24 --> Helper loaded: text_helper
INFO - 2018-07-26 04:41:24 --> Helper loaded: string_helper
INFO - 2018-07-26 04:41:24 --> Database Driver Class Initialized
DEBUG - 2018-07-26 04:41:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 04:41:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 04:41:24 --> Email Class Initialized
INFO - 2018-07-26 04:41:24 --> Controller Class Initialized
DEBUG - 2018-07-26 04:41:24 --> Users MX_Controller Initialized
DEBUG - 2018-07-26 04:41:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-26 04:41:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-26 04:41:24 --> Helper loaded: file_helper
DEBUG - 2018-07-26 04:41:24 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-26 04:41:24 --> Login MX_Controller Initialized
INFO - 2018-07-26 04:41:24 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-26 04:41:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-26 04:41:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-26 04:41:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
INFO - 2018-07-26 04:41:24 --> Upload Class Initialized
INFO - 2018-07-26 05:16:28 --> Config Class Initialized
INFO - 2018-07-26 05:16:28 --> Hooks Class Initialized
DEBUG - 2018-07-26 05:16:28 --> UTF-8 Support Enabled
INFO - 2018-07-26 05:16:29 --> Utf8 Class Initialized
INFO - 2018-07-26 05:16:29 --> URI Class Initialized
INFO - 2018-07-26 05:16:29 --> Router Class Initialized
INFO - 2018-07-26 05:16:29 --> Output Class Initialized
INFO - 2018-07-26 05:16:29 --> Security Class Initialized
DEBUG - 2018-07-26 05:16:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 05:16:29 --> Input Class Initialized
INFO - 2018-07-26 05:16:29 --> Language Class Initialized
INFO - 2018-07-26 05:16:29 --> Language Class Initialized
INFO - 2018-07-26 05:16:29 --> Config Class Initialized
INFO - 2018-07-26 05:16:29 --> Loader Class Initialized
DEBUG - 2018-07-26 05:16:29 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-26 05:16:29 --> Helper loaded: url_helper
INFO - 2018-07-26 05:16:29 --> Helper loaded: form_helper
INFO - 2018-07-26 05:16:29 --> Helper loaded: date_helper
INFO - 2018-07-26 05:16:29 --> Helper loaded: util_helper
INFO - 2018-07-26 05:16:29 --> Helper loaded: text_helper
INFO - 2018-07-26 05:16:29 --> Helper loaded: string_helper
INFO - 2018-07-26 05:16:29 --> Database Driver Class Initialized
DEBUG - 2018-07-26 05:16:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 05:16:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 05:16:29 --> Email Class Initialized
INFO - 2018-07-26 05:16:29 --> Controller Class Initialized
DEBUG - 2018-07-26 05:16:29 --> Users MX_Controller Initialized
DEBUG - 2018-07-26 05:16:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-26 05:16:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-26 05:16:29 --> Helper loaded: file_helper
DEBUG - 2018-07-26 05:16:29 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-26 05:16:29 --> Login MX_Controller Initialized
INFO - 2018-07-26 05:16:29 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-26 05:16:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-26 05:16:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-26 05:16:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
INFO - 2018-07-26 05:16:29 --> Upload Class Initialized
INFO - 2018-07-26 06:00:56 --> Config Class Initialized
INFO - 2018-07-26 06:00:56 --> Hooks Class Initialized
DEBUG - 2018-07-26 06:00:56 --> UTF-8 Support Enabled
INFO - 2018-07-26 06:00:56 --> Utf8 Class Initialized
INFO - 2018-07-26 06:00:56 --> URI Class Initialized
INFO - 2018-07-26 06:00:56 --> Router Class Initialized
INFO - 2018-07-26 06:00:56 --> Output Class Initialized
INFO - 2018-07-26 06:00:56 --> Security Class Initialized
DEBUG - 2018-07-26 06:00:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 06:00:56 --> Input Class Initialized
INFO - 2018-07-26 06:00:56 --> Language Class Initialized
INFO - 2018-07-26 06:00:56 --> Language Class Initialized
INFO - 2018-07-26 06:00:56 --> Config Class Initialized
INFO - 2018-07-26 06:00:56 --> Loader Class Initialized
DEBUG - 2018-07-26 06:00:56 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-26 06:00:56 --> Helper loaded: url_helper
INFO - 2018-07-26 06:00:56 --> Helper loaded: form_helper
INFO - 2018-07-26 06:00:56 --> Helper loaded: date_helper
INFO - 2018-07-26 06:00:56 --> Helper loaded: util_helper
INFO - 2018-07-26 06:00:56 --> Helper loaded: text_helper
INFO - 2018-07-26 06:00:56 --> Helper loaded: string_helper
INFO - 2018-07-26 06:00:56 --> Database Driver Class Initialized
DEBUG - 2018-07-26 06:00:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 06:00:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 06:00:56 --> Email Class Initialized
INFO - 2018-07-26 06:00:56 --> Controller Class Initialized
DEBUG - 2018-07-26 06:00:56 --> Users MX_Controller Initialized
DEBUG - 2018-07-26 06:00:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-26 06:00:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-26 06:00:56 --> Helper loaded: file_helper
DEBUG - 2018-07-26 06:00:56 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-26 06:00:56 --> Login MX_Controller Initialized
INFO - 2018-07-26 06:00:56 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-26 06:00:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-26 06:00:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-26 06:00:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-26 06:00:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-26 06:00:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-26 06:00:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-26 06:00:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-26 06:00:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-07-26 06:00:56 --> Final output sent to browser
DEBUG - 2018-07-26 06:00:56 --> Total execution time: 0.7378
INFO - 2018-07-26 22:13:24 --> Config Class Initialized
INFO - 2018-07-26 22:13:24 --> Hooks Class Initialized
DEBUG - 2018-07-26 22:13:24 --> UTF-8 Support Enabled
INFO - 2018-07-26 22:13:24 --> Utf8 Class Initialized
INFO - 2018-07-26 22:13:24 --> URI Class Initialized
INFO - 2018-07-26 22:13:24 --> Router Class Initialized
INFO - 2018-07-26 22:13:25 --> Output Class Initialized
INFO - 2018-07-26 22:13:25 --> Security Class Initialized
DEBUG - 2018-07-26 22:13:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 22:13:25 --> Input Class Initialized
INFO - 2018-07-26 22:13:25 --> Language Class Initialized
INFO - 2018-07-26 22:13:25 --> Language Class Initialized
INFO - 2018-07-26 22:13:25 --> Config Class Initialized
INFO - 2018-07-26 22:13:25 --> Loader Class Initialized
DEBUG - 2018-07-26 22:13:25 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-26 22:13:25 --> Helper loaded: url_helper
INFO - 2018-07-26 22:13:25 --> Helper loaded: form_helper
INFO - 2018-07-26 22:13:25 --> Helper loaded: date_helper
INFO - 2018-07-26 22:13:25 --> Helper loaded: util_helper
INFO - 2018-07-26 22:13:25 --> Helper loaded: text_helper
INFO - 2018-07-26 22:13:25 --> Helper loaded: string_helper
INFO - 2018-07-26 22:13:25 --> Database Driver Class Initialized
DEBUG - 2018-07-26 22:13:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 22:13:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 22:13:25 --> Email Class Initialized
INFO - 2018-07-26 22:13:25 --> Controller Class Initialized
DEBUG - 2018-07-26 22:13:25 --> Users MX_Controller Initialized
DEBUG - 2018-07-26 22:13:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-26 22:13:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-26 22:13:25 --> Helper loaded: file_helper
DEBUG - 2018-07-26 22:13:25 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-26 22:13:25 --> Login MX_Controller Initialized
INFO - 2018-07-26 22:13:26 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-26 22:13:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-26 22:13:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
INFO - 2018-07-26 22:13:26 --> Config Class Initialized
INFO - 2018-07-26 22:13:26 --> Hooks Class Initialized
DEBUG - 2018-07-26 22:13:26 --> UTF-8 Support Enabled
INFO - 2018-07-26 22:13:26 --> Utf8 Class Initialized
INFO - 2018-07-26 22:13:26 --> URI Class Initialized
INFO - 2018-07-26 22:13:26 --> Router Class Initialized
INFO - 2018-07-26 22:13:26 --> Output Class Initialized
INFO - 2018-07-26 22:13:26 --> Security Class Initialized
DEBUG - 2018-07-26 22:13:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 22:13:26 --> Input Class Initialized
INFO - 2018-07-26 22:13:26 --> Language Class Initialized
INFO - 2018-07-26 22:13:26 --> Language Class Initialized
INFO - 2018-07-26 22:13:26 --> Config Class Initialized
INFO - 2018-07-26 22:13:26 --> Loader Class Initialized
DEBUG - 2018-07-26 22:13:26 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-26 22:13:26 --> Helper loaded: url_helper
INFO - 2018-07-26 22:13:26 --> Helper loaded: form_helper
INFO - 2018-07-26 22:13:26 --> Helper loaded: date_helper
INFO - 2018-07-26 22:13:26 --> Helper loaded: util_helper
INFO - 2018-07-26 22:13:26 --> Helper loaded: text_helper
INFO - 2018-07-26 22:13:26 --> Helper loaded: string_helper
INFO - 2018-07-26 22:13:26 --> Database Driver Class Initialized
DEBUG - 2018-07-26 22:13:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 22:13:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 22:13:26 --> Email Class Initialized
INFO - 2018-07-26 22:13:26 --> Controller Class Initialized
DEBUG - 2018-07-26 22:13:26 --> Users MX_Controller Initialized
DEBUG - 2018-07-26 22:13:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-26 22:13:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-26 22:13:26 --> Helper loaded: file_helper
DEBUG - 2018-07-26 22:13:26 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-26 22:13:26 --> Login MX_Controller Initialized
INFO - 2018-07-26 22:13:26 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-26 22:13:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-26 22:13:26 --> Config Class Initialized
INFO - 2018-07-26 22:13:26 --> Hooks Class Initialized
DEBUG - 2018-07-26 22:13:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
DEBUG - 2018-07-26 22:13:26 --> UTF-8 Support Enabled
INFO - 2018-07-26 22:13:26 --> Utf8 Class Initialized
INFO - 2018-07-26 22:13:26 --> URI Class Initialized
INFO - 2018-07-26 22:13:26 --> Router Class Initialized
INFO - 2018-07-26 22:13:26 --> Output Class Initialized
INFO - 2018-07-26 22:13:26 --> Security Class Initialized
DEBUG - 2018-07-26 22:13:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 22:13:27 --> Input Class Initialized
INFO - 2018-07-26 22:13:27 --> Language Class Initialized
ERROR - 2018-07-26 22:13:27 --> 404 Page Not Found: /index
INFO - 2018-07-26 22:13:27 --> Config Class Initialized
INFO - 2018-07-26 22:13:27 --> Hooks Class Initialized
DEBUG - 2018-07-26 22:13:27 --> UTF-8 Support Enabled
INFO - 2018-07-26 22:13:27 --> Utf8 Class Initialized
INFO - 2018-07-26 22:13:27 --> URI Class Initialized
INFO - 2018-07-26 22:13:27 --> Router Class Initialized
INFO - 2018-07-26 22:13:27 --> Output Class Initialized
INFO - 2018-07-26 22:13:27 --> Security Class Initialized
DEBUG - 2018-07-26 22:13:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 22:13:27 --> Input Class Initialized
INFO - 2018-07-26 22:13:27 --> Language Class Initialized
ERROR - 2018-07-26 22:13:27 --> 404 Page Not Found: /index
INFO - 2018-07-26 22:13:27 --> Config Class Initialized
INFO - 2018-07-26 22:13:27 --> Hooks Class Initialized
DEBUG - 2018-07-26 22:13:28 --> UTF-8 Support Enabled
INFO - 2018-07-26 22:13:28 --> Utf8 Class Initialized
INFO - 2018-07-26 22:13:28 --> URI Class Initialized
INFO - 2018-07-26 22:13:28 --> Router Class Initialized
INFO - 2018-07-26 22:13:28 --> Output Class Initialized
INFO - 2018-07-26 22:13:28 --> Security Class Initialized
DEBUG - 2018-07-26 22:13:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 22:13:28 --> Input Class Initialized
INFO - 2018-07-26 22:13:28 --> Language Class Initialized
ERROR - 2018-07-26 22:13:28 --> 404 Page Not Found: /index
INFO - 2018-07-26 22:24:18 --> Config Class Initialized
INFO - 2018-07-26 22:24:18 --> Hooks Class Initialized
DEBUG - 2018-07-26 22:24:18 --> UTF-8 Support Enabled
INFO - 2018-07-26 22:24:18 --> Utf8 Class Initialized
INFO - 2018-07-26 22:24:18 --> URI Class Initialized
INFO - 2018-07-26 22:24:19 --> Router Class Initialized
INFO - 2018-07-26 22:24:19 --> Output Class Initialized
INFO - 2018-07-26 22:24:19 --> Security Class Initialized
DEBUG - 2018-07-26 22:24:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 22:24:19 --> Input Class Initialized
INFO - 2018-07-26 22:24:19 --> Language Class Initialized
INFO - 2018-07-26 22:24:19 --> Language Class Initialized
INFO - 2018-07-26 22:24:19 --> Config Class Initialized
INFO - 2018-07-26 22:24:19 --> Loader Class Initialized
DEBUG - 2018-07-26 22:24:19 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-26 22:24:19 --> Helper loaded: url_helper
INFO - 2018-07-26 22:24:19 --> Helper loaded: form_helper
INFO - 2018-07-26 22:24:19 --> Helper loaded: date_helper
INFO - 2018-07-26 22:24:19 --> Helper loaded: util_helper
INFO - 2018-07-26 22:24:19 --> Helper loaded: text_helper
INFO - 2018-07-26 22:24:19 --> Helper loaded: string_helper
INFO - 2018-07-26 22:24:19 --> Database Driver Class Initialized
DEBUG - 2018-07-26 22:24:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 22:24:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 22:24:19 --> Email Class Initialized
INFO - 2018-07-26 22:24:19 --> Controller Class Initialized
DEBUG - 2018-07-26 22:24:19 --> Login MX_Controller Initialized
INFO - 2018-07-26 22:24:19 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-26 22:24:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-26 22:24:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-26 22:24:19 --> Email starts for colin-admin fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-07-26 22:24:19 --> User session created for 1
INFO - 2018-07-26 22:24:19 --> Login status colin-admin - success
INFO - 2018-07-26 22:24:19 --> Final output sent to browser
DEBUG - 2018-07-26 22:24:19 --> Total execution time: 1.1156
INFO - 2018-07-26 22:24:19 --> Config Class Initialized
INFO - 2018-07-26 22:24:19 --> Hooks Class Initialized
DEBUG - 2018-07-26 22:24:19 --> UTF-8 Support Enabled
INFO - 2018-07-26 22:24:19 --> Utf8 Class Initialized
INFO - 2018-07-26 22:24:19 --> URI Class Initialized
INFO - 2018-07-26 22:24:20 --> Router Class Initialized
INFO - 2018-07-26 22:24:20 --> Output Class Initialized
INFO - 2018-07-26 22:24:20 --> Security Class Initialized
DEBUG - 2018-07-26 22:24:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 22:24:20 --> Input Class Initialized
INFO - 2018-07-26 22:24:20 --> Language Class Initialized
INFO - 2018-07-26 22:24:20 --> Language Class Initialized
INFO - 2018-07-26 22:24:20 --> Config Class Initialized
INFO - 2018-07-26 22:24:20 --> Loader Class Initialized
DEBUG - 2018-07-26 22:24:20 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-26 22:24:20 --> Helper loaded: url_helper
INFO - 2018-07-26 22:24:20 --> Helper loaded: form_helper
INFO - 2018-07-26 22:24:20 --> Helper loaded: date_helper
INFO - 2018-07-26 22:24:20 --> Helper loaded: util_helper
INFO - 2018-07-26 22:24:20 --> Helper loaded: text_helper
INFO - 2018-07-26 22:24:20 --> Helper loaded: string_helper
INFO - 2018-07-26 22:24:20 --> Database Driver Class Initialized
DEBUG - 2018-07-26 22:24:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 22:24:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 22:24:20 --> Email Class Initialized
INFO - 2018-07-26 22:24:20 --> Controller Class Initialized
DEBUG - 2018-07-26 22:24:20 --> Users MX_Controller Initialized
DEBUG - 2018-07-26 22:24:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-26 22:24:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-26 22:24:20 --> Helper loaded: file_helper
DEBUG - 2018-07-26 22:24:20 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-26 22:24:20 --> Login MX_Controller Initialized
INFO - 2018-07-26 22:24:20 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-26 22:24:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-26 22:24:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-26 22:24:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-26 22:24:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-26 22:24:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-26 22:24:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-26 22:24:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-26 22:24:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-07-26 22:24:20 --> Final output sent to browser
DEBUG - 2018-07-26 22:24:20 --> Total execution time: 0.7997
INFO - 2018-07-26 22:56:35 --> Config Class Initialized
INFO - 2018-07-26 22:56:35 --> Hooks Class Initialized
DEBUG - 2018-07-26 22:56:35 --> UTF-8 Support Enabled
INFO - 2018-07-26 22:56:35 --> Utf8 Class Initialized
INFO - 2018-07-26 22:56:35 --> URI Class Initialized
DEBUG - 2018-07-26 22:56:35 --> No URI present. Default controller set.
INFO - 2018-07-26 22:56:35 --> Router Class Initialized
INFO - 2018-07-26 22:56:35 --> Output Class Initialized
INFO - 2018-07-26 22:56:35 --> Security Class Initialized
DEBUG - 2018-07-26 22:56:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 22:56:35 --> Input Class Initialized
INFO - 2018-07-26 22:56:35 --> Language Class Initialized
INFO - 2018-07-26 22:56:35 --> Language Class Initialized
INFO - 2018-07-26 22:56:35 --> Config Class Initialized
INFO - 2018-07-26 22:56:35 --> Loader Class Initialized
DEBUG - 2018-07-26 22:56:35 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-26 22:56:35 --> Helper loaded: url_helper
INFO - 2018-07-26 22:56:35 --> Helper loaded: form_helper
INFO - 2018-07-26 22:56:35 --> Helper loaded: date_helper
INFO - 2018-07-26 22:56:35 --> Helper loaded: util_helper
INFO - 2018-07-26 22:56:35 --> Helper loaded: text_helper
INFO - 2018-07-26 22:56:35 --> Helper loaded: string_helper
INFO - 2018-07-26 22:56:35 --> Database Driver Class Initialized
DEBUG - 2018-07-26 22:56:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 22:56:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 22:56:36 --> Email Class Initialized
INFO - 2018-07-26 22:56:36 --> Controller Class Initialized
DEBUG - 2018-07-26 22:56:36 --> Home MX_Controller Initialized
DEBUG - 2018-07-26 22:56:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-26 22:56:36 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-26 22:56:36 --> Login MX_Controller Initialized
INFO - 2018-07-26 22:56:36 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-26 22:56:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-26 22:56:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-26 22:56:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-07-26 22:56:52 --> Config Class Initialized
INFO - 2018-07-26 22:56:52 --> Hooks Class Initialized
DEBUG - 2018-07-26 22:56:52 --> UTF-8 Support Enabled
INFO - 2018-07-26 22:56:52 --> Utf8 Class Initialized
INFO - 2018-07-26 22:56:52 --> URI Class Initialized
INFO - 2018-07-26 22:56:52 --> Router Class Initialized
INFO - 2018-07-26 22:56:52 --> Output Class Initialized
INFO - 2018-07-26 22:56:52 --> Security Class Initialized
DEBUG - 2018-07-26 22:56:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 22:56:52 --> Input Class Initialized
INFO - 2018-07-26 22:56:52 --> Language Class Initialized
INFO - 2018-07-26 22:56:52 --> Language Class Initialized
INFO - 2018-07-26 22:56:52 --> Config Class Initialized
INFO - 2018-07-26 22:56:52 --> Loader Class Initialized
DEBUG - 2018-07-26 22:56:52 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-26 22:56:52 --> Helper loaded: url_helper
INFO - 2018-07-26 22:56:52 --> Helper loaded: form_helper
INFO - 2018-07-26 22:56:52 --> Helper loaded: date_helper
INFO - 2018-07-26 22:56:52 --> Helper loaded: util_helper
INFO - 2018-07-26 22:56:52 --> Helper loaded: text_helper
INFO - 2018-07-26 22:56:52 --> Helper loaded: string_helper
INFO - 2018-07-26 22:56:52 --> Database Driver Class Initialized
DEBUG - 2018-07-26 22:56:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 22:56:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 22:56:52 --> Email Class Initialized
INFO - 2018-07-26 22:56:52 --> Controller Class Initialized
DEBUG - 2018-07-26 22:56:52 --> Login MX_Controller Initialized
INFO - 2018-07-26 22:56:52 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-26 22:56:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-26 22:56:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-26 22:56:52 --> Email starts for colinuser fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-07-26 22:56:52 --> Login status colinuser - failure
INFO - 2018-07-26 22:56:52 --> Final output sent to browser
DEBUG - 2018-07-26 22:56:52 --> Total execution time: 0.3622
INFO - 2018-07-26 22:57:05 --> Config Class Initialized
INFO - 2018-07-26 22:57:05 --> Hooks Class Initialized
DEBUG - 2018-07-26 22:57:05 --> UTF-8 Support Enabled
INFO - 2018-07-26 22:57:05 --> Utf8 Class Initialized
INFO - 2018-07-26 22:57:05 --> URI Class Initialized
INFO - 2018-07-26 22:57:05 --> Router Class Initialized
INFO - 2018-07-26 22:57:05 --> Output Class Initialized
INFO - 2018-07-26 22:57:05 --> Security Class Initialized
DEBUG - 2018-07-26 22:57:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 22:57:05 --> Input Class Initialized
INFO - 2018-07-26 22:57:05 --> Language Class Initialized
INFO - 2018-07-26 22:57:05 --> Language Class Initialized
INFO - 2018-07-26 22:57:05 --> Config Class Initialized
INFO - 2018-07-26 22:57:05 --> Loader Class Initialized
DEBUG - 2018-07-26 22:57:05 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-26 22:57:05 --> Helper loaded: url_helper
INFO - 2018-07-26 22:57:05 --> Helper loaded: form_helper
INFO - 2018-07-26 22:57:05 --> Helper loaded: date_helper
INFO - 2018-07-26 22:57:05 --> Helper loaded: util_helper
INFO - 2018-07-26 22:57:05 --> Helper loaded: text_helper
INFO - 2018-07-26 22:57:05 --> Helper loaded: string_helper
INFO - 2018-07-26 22:57:05 --> Database Driver Class Initialized
DEBUG - 2018-07-26 22:57:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 22:57:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 22:57:05 --> Email Class Initialized
INFO - 2018-07-26 22:57:05 --> Controller Class Initialized
DEBUG - 2018-07-26 22:57:05 --> Login MX_Controller Initialized
INFO - 2018-07-26 22:57:05 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-26 22:57:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-26 22:57:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-26 22:57:05 --> Email starts for colin fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-07-26 22:57:05 --> User session created for 4
INFO - 2018-07-26 22:57:05 --> Login status colin - success
INFO - 2018-07-26 22:57:05 --> Final output sent to browser
DEBUG - 2018-07-26 22:57:05 --> Total execution time: 0.4061
INFO - 2018-07-26 22:57:05 --> Config Class Initialized
INFO - 2018-07-26 22:57:05 --> Hooks Class Initialized
DEBUG - 2018-07-26 22:57:05 --> UTF-8 Support Enabled
INFO - 2018-07-26 22:57:05 --> Utf8 Class Initialized
INFO - 2018-07-26 22:57:05 --> URI Class Initialized
DEBUG - 2018-07-26 22:57:05 --> No URI present. Default controller set.
INFO - 2018-07-26 22:57:05 --> Router Class Initialized
INFO - 2018-07-26 22:57:05 --> Output Class Initialized
INFO - 2018-07-26 22:57:05 --> Security Class Initialized
DEBUG - 2018-07-26 22:57:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 22:57:05 --> Input Class Initialized
INFO - 2018-07-26 22:57:05 --> Language Class Initialized
INFO - 2018-07-26 22:57:05 --> Language Class Initialized
INFO - 2018-07-26 22:57:05 --> Config Class Initialized
INFO - 2018-07-26 22:57:06 --> Loader Class Initialized
DEBUG - 2018-07-26 22:57:06 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-26 22:57:06 --> Helper loaded: url_helper
INFO - 2018-07-26 22:57:06 --> Helper loaded: form_helper
INFO - 2018-07-26 22:57:06 --> Helper loaded: date_helper
INFO - 2018-07-26 22:57:06 --> Helper loaded: util_helper
INFO - 2018-07-26 22:57:06 --> Helper loaded: text_helper
INFO - 2018-07-26 22:57:06 --> Helper loaded: string_helper
INFO - 2018-07-26 22:57:06 --> Database Driver Class Initialized
DEBUG - 2018-07-26 22:57:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 22:57:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 22:57:06 --> Email Class Initialized
INFO - 2018-07-26 22:57:06 --> Controller Class Initialized
DEBUG - 2018-07-26 22:57:06 --> Home MX_Controller Initialized
DEBUG - 2018-07-26 22:57:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-26 22:57:06 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-26 22:57:06 --> Login MX_Controller Initialized
INFO - 2018-07-26 22:57:06 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-26 22:57:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-26 22:57:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-26 22:57:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-26 22:57:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
ERROR - 2018-07-26 22:57:06 --> Severity: Notice --> Undefined variable: user_details E:\xampp\htdocs\consulting\application\modules\home\views\common\header.php 43
DEBUG - 2018-07-26 22:57:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-26 22:57:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-26 22:57:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-26 22:57:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-26 22:57:06 --> Final output sent to browser
DEBUG - 2018-07-26 22:57:06 --> Total execution time: 0.5642
INFO - 2018-07-26 22:57:07 --> Config Class Initialized
INFO - 2018-07-26 22:57:07 --> Hooks Class Initialized
DEBUG - 2018-07-26 22:57:07 --> UTF-8 Support Enabled
INFO - 2018-07-26 22:57:07 --> Utf8 Class Initialized
INFO - 2018-07-26 22:57:07 --> URI Class Initialized
INFO - 2018-07-26 22:57:07 --> Router Class Initialized
INFO - 2018-07-26 22:57:07 --> Output Class Initialized
INFO - 2018-07-26 22:57:07 --> Security Class Initialized
DEBUG - 2018-07-26 22:57:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 22:57:08 --> Input Class Initialized
INFO - 2018-07-26 22:57:08 --> Language Class Initialized
ERROR - 2018-07-26 22:57:08 --> 404 Page Not Found: /index
INFO - 2018-07-26 22:57:08 --> Config Class Initialized
INFO - 2018-07-26 22:57:08 --> Hooks Class Initialized
DEBUG - 2018-07-26 22:57:08 --> UTF-8 Support Enabled
INFO - 2018-07-26 22:57:08 --> Utf8 Class Initialized
INFO - 2018-07-26 22:57:08 --> URI Class Initialized
INFO - 2018-07-26 22:57:08 --> Router Class Initialized
INFO - 2018-07-26 22:57:08 --> Output Class Initialized
INFO - 2018-07-26 22:57:08 --> Security Class Initialized
DEBUG - 2018-07-26 22:57:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 22:57:08 --> Input Class Initialized
INFO - 2018-07-26 22:57:08 --> Language Class Initialized
ERROR - 2018-07-26 22:57:08 --> 404 Page Not Found: /index
INFO - 2018-07-26 22:57:08 --> Config Class Initialized
INFO - 2018-07-26 22:57:08 --> Hooks Class Initialized
DEBUG - 2018-07-26 22:57:08 --> UTF-8 Support Enabled
INFO - 2018-07-26 22:57:08 --> Config Class Initialized
INFO - 2018-07-26 22:57:08 --> Hooks Class Initialized
INFO - 2018-07-26 22:57:08 --> Utf8 Class Initialized
DEBUG - 2018-07-26 22:57:08 --> UTF-8 Support Enabled
INFO - 2018-07-26 22:57:08 --> URI Class Initialized
INFO - 2018-07-26 22:57:08 --> Utf8 Class Initialized
INFO - 2018-07-26 22:57:08 --> Router Class Initialized
INFO - 2018-07-26 22:57:08 --> URI Class Initialized
INFO - 2018-07-26 22:57:08 --> Output Class Initialized
INFO - 2018-07-26 22:57:08 --> Router Class Initialized
INFO - 2018-07-26 22:57:08 --> Security Class Initialized
INFO - 2018-07-26 22:57:08 --> Output Class Initialized
DEBUG - 2018-07-26 22:57:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 22:57:08 --> Input Class Initialized
INFO - 2018-07-26 22:57:08 --> Security Class Initialized
INFO - 2018-07-26 22:57:08 --> Language Class Initialized
DEBUG - 2018-07-26 22:57:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 22:57:08 --> Input Class Initialized
INFO - 2018-07-26 22:57:08 --> Language Class Initialized
ERROR - 2018-07-26 22:57:08 --> 404 Page Not Found: /index
ERROR - 2018-07-26 22:57:08 --> 404 Page Not Found: /index
INFO - 2018-07-26 22:57:08 --> Config Class Initialized
INFO - 2018-07-26 22:57:08 --> Hooks Class Initialized
DEBUG - 2018-07-26 22:57:08 --> UTF-8 Support Enabled
INFO - 2018-07-26 22:57:08 --> Utf8 Class Initialized
INFO - 2018-07-26 22:57:08 --> URI Class Initialized
INFO - 2018-07-26 22:57:08 --> Router Class Initialized
INFO - 2018-07-26 22:57:08 --> Output Class Initialized
INFO - 2018-07-26 22:57:08 --> Security Class Initialized
DEBUG - 2018-07-26 22:57:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 22:57:09 --> Input Class Initialized
INFO - 2018-07-26 22:57:09 --> Language Class Initialized
ERROR - 2018-07-26 22:57:09 --> 404 Page Not Found: /index
INFO - 2018-07-26 22:57:09 --> Config Class Initialized
INFO - 2018-07-26 22:57:09 --> Hooks Class Initialized
DEBUG - 2018-07-26 22:57:09 --> UTF-8 Support Enabled
INFO - 2018-07-26 22:57:09 --> Utf8 Class Initialized
INFO - 2018-07-26 22:57:09 --> URI Class Initialized
INFO - 2018-07-26 22:57:09 --> Router Class Initialized
INFO - 2018-07-26 22:57:09 --> Output Class Initialized
INFO - 2018-07-26 22:57:09 --> Security Class Initialized
DEBUG - 2018-07-26 22:57:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 22:57:09 --> Input Class Initialized
INFO - 2018-07-26 22:57:09 --> Language Class Initialized
ERROR - 2018-07-26 22:57:09 --> 404 Page Not Found: /index
INFO - 2018-07-26 22:57:09 --> Config Class Initialized
INFO - 2018-07-26 22:57:09 --> Hooks Class Initialized
DEBUG - 2018-07-26 22:57:09 --> UTF-8 Support Enabled
INFO - 2018-07-26 22:57:09 --> Utf8 Class Initialized
INFO - 2018-07-26 22:57:09 --> URI Class Initialized
INFO - 2018-07-26 22:57:09 --> Router Class Initialized
INFO - 2018-07-26 22:57:09 --> Output Class Initialized
INFO - 2018-07-26 22:57:09 --> Security Class Initialized
DEBUG - 2018-07-26 22:57:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 22:57:09 --> Input Class Initialized
INFO - 2018-07-26 22:57:09 --> Language Class Initialized
ERROR - 2018-07-26 22:57:09 --> 404 Page Not Found: /index
INFO - 2018-07-26 22:57:09 --> Config Class Initialized
INFO - 2018-07-26 22:57:09 --> Hooks Class Initialized
DEBUG - 2018-07-26 22:57:09 --> UTF-8 Support Enabled
INFO - 2018-07-26 22:57:09 --> Utf8 Class Initialized
INFO - 2018-07-26 22:57:09 --> URI Class Initialized
INFO - 2018-07-26 22:57:09 --> Router Class Initialized
INFO - 2018-07-26 22:57:09 --> Output Class Initialized
INFO - 2018-07-26 22:57:09 --> Security Class Initialized
DEBUG - 2018-07-26 22:57:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 22:57:09 --> Input Class Initialized
INFO - 2018-07-26 22:57:09 --> Language Class Initialized
ERROR - 2018-07-26 22:57:09 --> 404 Page Not Found: /index
INFO - 2018-07-26 22:57:09 --> Config Class Initialized
INFO - 2018-07-26 22:57:09 --> Hooks Class Initialized
DEBUG - 2018-07-26 22:57:09 --> UTF-8 Support Enabled
INFO - 2018-07-26 22:57:09 --> Utf8 Class Initialized
INFO - 2018-07-26 22:57:09 --> URI Class Initialized
INFO - 2018-07-26 22:57:09 --> Router Class Initialized
INFO - 2018-07-26 22:57:09 --> Output Class Initialized
INFO - 2018-07-26 22:57:09 --> Security Class Initialized
DEBUG - 2018-07-26 22:57:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 22:57:09 --> Input Class Initialized
INFO - 2018-07-26 22:57:09 --> Language Class Initialized
ERROR - 2018-07-26 22:57:09 --> 404 Page Not Found: /index
INFO - 2018-07-26 22:57:09 --> Config Class Initialized
INFO - 2018-07-26 22:57:09 --> Hooks Class Initialized
DEBUG - 2018-07-26 22:57:09 --> UTF-8 Support Enabled
INFO - 2018-07-26 22:57:09 --> Utf8 Class Initialized
INFO - 2018-07-26 22:57:09 --> URI Class Initialized
INFO - 2018-07-26 22:57:09 --> Router Class Initialized
INFO - 2018-07-26 22:57:09 --> Output Class Initialized
INFO - 2018-07-26 22:57:09 --> Security Class Initialized
DEBUG - 2018-07-26 22:57:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 22:57:10 --> Input Class Initialized
INFO - 2018-07-26 22:57:10 --> Language Class Initialized
ERROR - 2018-07-26 22:57:10 --> 404 Page Not Found: /index
INFO - 2018-07-26 22:57:36 --> Config Class Initialized
INFO - 2018-07-26 22:57:36 --> Hooks Class Initialized
DEBUG - 2018-07-26 22:57:36 --> UTF-8 Support Enabled
INFO - 2018-07-26 22:57:36 --> Utf8 Class Initialized
INFO - 2018-07-26 22:57:36 --> URI Class Initialized
INFO - 2018-07-26 22:57:36 --> Router Class Initialized
INFO - 2018-07-26 22:57:36 --> Output Class Initialized
INFO - 2018-07-26 22:57:36 --> Security Class Initialized
DEBUG - 2018-07-26 22:57:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 22:57:36 --> Input Class Initialized
INFO - 2018-07-26 22:57:36 --> Language Class Initialized
ERROR - 2018-07-26 22:57:36 --> 404 Page Not Found: /index
INFO - 2018-07-26 22:57:36 --> Config Class Initialized
INFO - 2018-07-26 22:57:37 --> Hooks Class Initialized
DEBUG - 2018-07-26 22:57:37 --> UTF-8 Support Enabled
INFO - 2018-07-26 22:57:37 --> Utf8 Class Initialized
INFO - 2018-07-26 22:57:37 --> URI Class Initialized
INFO - 2018-07-26 22:57:37 --> Router Class Initialized
INFO - 2018-07-26 22:57:37 --> Output Class Initialized
INFO - 2018-07-26 22:57:37 --> Security Class Initialized
DEBUG - 2018-07-26 22:57:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 22:57:37 --> Input Class Initialized
INFO - 2018-07-26 22:57:37 --> Language Class Initialized
ERROR - 2018-07-26 22:57:37 --> 404 Page Not Found: /index
INFO - 2018-07-26 22:57:37 --> Config Class Initialized
INFO - 2018-07-26 22:57:37 --> Hooks Class Initialized
DEBUG - 2018-07-26 22:57:37 --> UTF-8 Support Enabled
INFO - 2018-07-26 22:57:37 --> Utf8 Class Initialized
INFO - 2018-07-26 22:57:37 --> URI Class Initialized
INFO - 2018-07-26 22:57:37 --> Router Class Initialized
INFO - 2018-07-26 22:57:37 --> Output Class Initialized
INFO - 2018-07-26 22:57:37 --> Security Class Initialized
DEBUG - 2018-07-26 22:57:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 22:57:37 --> Input Class Initialized
INFO - 2018-07-26 22:57:37 --> Language Class Initialized
ERROR - 2018-07-26 22:57:37 --> 404 Page Not Found: /index
INFO - 2018-07-26 22:57:39 --> Config Class Initialized
INFO - 2018-07-26 22:57:39 --> Hooks Class Initialized
DEBUG - 2018-07-26 22:57:39 --> UTF-8 Support Enabled
INFO - 2018-07-26 22:57:39 --> Utf8 Class Initialized
INFO - 2018-07-26 22:57:39 --> URI Class Initialized
INFO - 2018-07-26 22:57:39 --> Router Class Initialized
INFO - 2018-07-26 22:57:39 --> Output Class Initialized
INFO - 2018-07-26 22:57:39 --> Security Class Initialized
DEBUG - 2018-07-26 22:57:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 22:57:39 --> Input Class Initialized
INFO - 2018-07-26 22:57:39 --> Language Class Initialized
INFO - 2018-07-26 22:57:39 --> Language Class Initialized
INFO - 2018-07-26 22:57:39 --> Config Class Initialized
INFO - 2018-07-26 22:57:39 --> Loader Class Initialized
DEBUG - 2018-07-26 22:57:39 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-26 22:57:39 --> Helper loaded: url_helper
INFO - 2018-07-26 22:57:39 --> Helper loaded: form_helper
INFO - 2018-07-26 22:57:39 --> Helper loaded: date_helper
INFO - 2018-07-26 22:57:39 --> Helper loaded: util_helper
INFO - 2018-07-26 22:57:39 --> Helper loaded: text_helper
INFO - 2018-07-26 22:57:39 --> Helper loaded: string_helper
INFO - 2018-07-26 22:57:39 --> Database Driver Class Initialized
DEBUG - 2018-07-26 22:57:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 22:57:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 22:57:39 --> Email Class Initialized
INFO - 2018-07-26 22:57:39 --> Controller Class Initialized
DEBUG - 2018-07-26 22:57:39 --> Home MX_Controller Initialized
DEBUG - 2018-07-26 22:57:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-26 22:57:39 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-26 22:57:39 --> Login MX_Controller Initialized
INFO - 2018-07-26 22:57:39 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-26 22:57:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-26 22:57:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-26 22:57:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-26 22:57:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
ERROR - 2018-07-26 22:57:39 --> Severity: Notice --> Undefined variable: user_details E:\xampp\htdocs\consulting\application\modules\home\views\common\header.php 43
DEBUG - 2018-07-26 22:57:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-26 22:57:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-26 22:57:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-26 22:57:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-26 22:57:39 --> Final output sent to browser
DEBUG - 2018-07-26 22:57:39 --> Total execution time: 0.6110
INFO - 2018-07-26 22:57:40 --> Config Class Initialized
INFO - 2018-07-26 22:57:40 --> Hooks Class Initialized
DEBUG - 2018-07-26 22:57:40 --> UTF-8 Support Enabled
INFO - 2018-07-26 22:57:40 --> Utf8 Class Initialized
INFO - 2018-07-26 22:57:40 --> URI Class Initialized
INFO - 2018-07-26 22:57:40 --> Router Class Initialized
INFO - 2018-07-26 22:57:40 --> Output Class Initialized
INFO - 2018-07-26 22:57:40 --> Security Class Initialized
DEBUG - 2018-07-26 22:57:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 22:57:40 --> Input Class Initialized
INFO - 2018-07-26 22:57:40 --> Language Class Initialized
ERROR - 2018-07-26 22:57:40 --> 404 Page Not Found: /index
INFO - 2018-07-26 22:57:40 --> Config Class Initialized
INFO - 2018-07-26 22:57:40 --> Hooks Class Initialized
DEBUG - 2018-07-26 22:57:40 --> UTF-8 Support Enabled
INFO - 2018-07-26 22:57:40 --> Utf8 Class Initialized
INFO - 2018-07-26 22:57:40 --> URI Class Initialized
INFO - 2018-07-26 22:57:40 --> Router Class Initialized
INFO - 2018-07-26 22:57:40 --> Output Class Initialized
INFO - 2018-07-26 22:57:40 --> Security Class Initialized
DEBUG - 2018-07-26 22:57:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 22:57:40 --> Input Class Initialized
INFO - 2018-07-26 22:57:40 --> Language Class Initialized
ERROR - 2018-07-26 22:57:40 --> 404 Page Not Found: /index
INFO - 2018-07-26 22:57:40 --> Config Class Initialized
INFO - 2018-07-26 22:57:40 --> Hooks Class Initialized
DEBUG - 2018-07-26 22:57:40 --> UTF-8 Support Enabled
INFO - 2018-07-26 22:57:40 --> Utf8 Class Initialized
INFO - 2018-07-26 22:57:40 --> URI Class Initialized
INFO - 2018-07-26 22:57:40 --> Router Class Initialized
INFO - 2018-07-26 22:57:40 --> Output Class Initialized
INFO - 2018-07-26 22:57:40 --> Security Class Initialized
DEBUG - 2018-07-26 22:57:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 22:57:40 --> Input Class Initialized
INFO - 2018-07-26 22:57:40 --> Language Class Initialized
ERROR - 2018-07-26 22:57:40 --> 404 Page Not Found: /index
INFO - 2018-07-26 22:58:24 --> Config Class Initialized
INFO - 2018-07-26 22:58:24 --> Hooks Class Initialized
DEBUG - 2018-07-26 22:58:24 --> UTF-8 Support Enabled
INFO - 2018-07-26 22:58:24 --> Utf8 Class Initialized
INFO - 2018-07-26 22:58:24 --> URI Class Initialized
INFO - 2018-07-26 22:58:24 --> Router Class Initialized
INFO - 2018-07-26 22:58:24 --> Output Class Initialized
INFO - 2018-07-26 22:58:24 --> Security Class Initialized
DEBUG - 2018-07-26 22:58:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 22:58:24 --> Input Class Initialized
INFO - 2018-07-26 22:58:25 --> Language Class Initialized
INFO - 2018-07-26 22:58:25 --> Language Class Initialized
INFO - 2018-07-26 22:58:25 --> Config Class Initialized
INFO - 2018-07-26 22:58:25 --> Loader Class Initialized
DEBUG - 2018-07-26 22:58:25 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-26 22:58:25 --> Helper loaded: url_helper
INFO - 2018-07-26 22:58:25 --> Helper loaded: form_helper
INFO - 2018-07-26 22:58:25 --> Helper loaded: date_helper
INFO - 2018-07-26 22:58:25 --> Helper loaded: util_helper
INFO - 2018-07-26 22:58:25 --> Helper loaded: text_helper
INFO - 2018-07-26 22:58:25 --> Helper loaded: string_helper
INFO - 2018-07-26 22:58:25 --> Database Driver Class Initialized
DEBUG - 2018-07-26 22:58:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 22:58:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 22:58:25 --> Email Class Initialized
INFO - 2018-07-26 22:58:25 --> Controller Class Initialized
DEBUG - 2018-07-26 22:58:25 --> Home MX_Controller Initialized
DEBUG - 2018-07-26 22:58:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-26 22:58:25 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-26 22:58:25 --> Login MX_Controller Initialized
INFO - 2018-07-26 22:58:25 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-26 22:58:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-26 22:58:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-26 22:58:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-26 22:58:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
INFO - 2018-07-26 22:58:27 --> Config Class Initialized
INFO - 2018-07-26 22:58:27 --> Hooks Class Initialized
DEBUG - 2018-07-26 22:58:27 --> UTF-8 Support Enabled
INFO - 2018-07-26 22:58:27 --> Utf8 Class Initialized
INFO - 2018-07-26 22:58:27 --> URI Class Initialized
INFO - 2018-07-26 22:58:27 --> Router Class Initialized
INFO - 2018-07-26 22:58:27 --> Output Class Initialized
INFO - 2018-07-26 22:58:27 --> Security Class Initialized
DEBUG - 2018-07-26 22:58:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 22:58:27 --> Input Class Initialized
INFO - 2018-07-26 22:58:27 --> Language Class Initialized
ERROR - 2018-07-26 22:58:27 --> 404 Page Not Found: /index
INFO - 2018-07-26 22:58:27 --> Config Class Initialized
INFO - 2018-07-26 22:58:27 --> Hooks Class Initialized
DEBUG - 2018-07-26 22:58:27 --> UTF-8 Support Enabled
INFO - 2018-07-26 22:58:27 --> Utf8 Class Initialized
INFO - 2018-07-26 22:58:27 --> URI Class Initialized
INFO - 2018-07-26 22:58:27 --> Router Class Initialized
INFO - 2018-07-26 22:58:27 --> Output Class Initialized
INFO - 2018-07-26 22:58:27 --> Security Class Initialized
DEBUG - 2018-07-26 22:58:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 22:58:27 --> Input Class Initialized
INFO - 2018-07-26 22:58:27 --> Language Class Initialized
ERROR - 2018-07-26 22:58:27 --> 404 Page Not Found: /index
INFO - 2018-07-26 22:58:27 --> Config Class Initialized
INFO - 2018-07-26 22:58:27 --> Hooks Class Initialized
DEBUG - 2018-07-26 22:58:27 --> UTF-8 Support Enabled
INFO - 2018-07-26 22:58:27 --> Utf8 Class Initialized
INFO - 2018-07-26 22:58:27 --> URI Class Initialized
INFO - 2018-07-26 22:58:27 --> Router Class Initialized
INFO - 2018-07-26 22:58:27 --> Output Class Initialized
INFO - 2018-07-26 22:58:27 --> Security Class Initialized
DEBUG - 2018-07-26 22:58:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 22:58:27 --> Input Class Initialized
INFO - 2018-07-26 22:58:27 --> Language Class Initialized
ERROR - 2018-07-26 22:58:27 --> 404 Page Not Found: /index
INFO - 2018-07-26 22:58:29 --> Config Class Initialized
INFO - 2018-07-26 22:58:29 --> Hooks Class Initialized
DEBUG - 2018-07-26 22:58:29 --> UTF-8 Support Enabled
INFO - 2018-07-26 22:58:29 --> Utf8 Class Initialized
INFO - 2018-07-26 22:58:29 --> URI Class Initialized
INFO - 2018-07-26 22:58:29 --> Router Class Initialized
INFO - 2018-07-26 22:58:29 --> Output Class Initialized
INFO - 2018-07-26 22:58:29 --> Security Class Initialized
DEBUG - 2018-07-26 22:58:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 22:58:29 --> Input Class Initialized
INFO - 2018-07-26 22:58:29 --> Language Class Initialized
INFO - 2018-07-26 22:58:29 --> Language Class Initialized
INFO - 2018-07-26 22:58:29 --> Config Class Initialized
INFO - 2018-07-26 22:58:29 --> Loader Class Initialized
DEBUG - 2018-07-26 22:58:29 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-26 22:58:29 --> Helper loaded: url_helper
INFO - 2018-07-26 22:58:29 --> Helper loaded: form_helper
INFO - 2018-07-26 22:58:29 --> Helper loaded: date_helper
INFO - 2018-07-26 22:58:29 --> Helper loaded: util_helper
INFO - 2018-07-26 22:58:29 --> Helper loaded: text_helper
INFO - 2018-07-26 22:58:29 --> Helper loaded: string_helper
INFO - 2018-07-26 22:58:29 --> Database Driver Class Initialized
DEBUG - 2018-07-26 22:58:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 22:58:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 22:58:29 --> Email Class Initialized
INFO - 2018-07-26 22:58:29 --> Controller Class Initialized
DEBUG - 2018-07-26 22:58:29 --> Home MX_Controller Initialized
DEBUG - 2018-07-26 22:58:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-26 22:58:29 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-26 22:58:29 --> Login MX_Controller Initialized
INFO - 2018-07-26 22:58:29 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-26 22:58:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-26 22:58:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-26 22:58:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-26 22:58:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
INFO - 2018-07-26 22:59:23 --> Config Class Initialized
INFO - 2018-07-26 22:59:23 --> Hooks Class Initialized
DEBUG - 2018-07-26 22:59:23 --> UTF-8 Support Enabled
INFO - 2018-07-26 22:59:23 --> Utf8 Class Initialized
INFO - 2018-07-26 22:59:23 --> URI Class Initialized
INFO - 2018-07-26 22:59:23 --> Router Class Initialized
INFO - 2018-07-26 22:59:23 --> Output Class Initialized
INFO - 2018-07-26 22:59:23 --> Security Class Initialized
DEBUG - 2018-07-26 22:59:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 22:59:23 --> Input Class Initialized
INFO - 2018-07-26 22:59:24 --> Language Class Initialized
INFO - 2018-07-26 22:59:24 --> Language Class Initialized
INFO - 2018-07-26 22:59:24 --> Config Class Initialized
INFO - 2018-07-26 22:59:24 --> Loader Class Initialized
DEBUG - 2018-07-26 22:59:24 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-26 22:59:24 --> Helper loaded: url_helper
INFO - 2018-07-26 22:59:24 --> Helper loaded: form_helper
INFO - 2018-07-26 22:59:24 --> Helper loaded: date_helper
INFO - 2018-07-26 22:59:24 --> Helper loaded: util_helper
INFO - 2018-07-26 22:59:24 --> Helper loaded: text_helper
INFO - 2018-07-26 22:59:24 --> Helper loaded: string_helper
INFO - 2018-07-26 22:59:24 --> Database Driver Class Initialized
DEBUG - 2018-07-26 22:59:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 22:59:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 22:59:24 --> Email Class Initialized
INFO - 2018-07-26 22:59:24 --> Controller Class Initialized
DEBUG - 2018-07-26 22:59:24 --> Home MX_Controller Initialized
DEBUG - 2018-07-26 22:59:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-26 22:59:24 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-26 22:59:24 --> Login MX_Controller Initialized
INFO - 2018-07-26 22:59:24 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-26 22:59:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-26 22:59:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-26 22:59:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-26 22:59:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-26 22:59:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-26 22:59:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-26 22:59:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-26 22:59:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-26 22:59:24 --> Final output sent to browser
DEBUG - 2018-07-26 22:59:24 --> Total execution time: 0.5400
INFO - 2018-07-26 22:59:27 --> Config Class Initialized
INFO - 2018-07-26 22:59:27 --> Hooks Class Initialized
DEBUG - 2018-07-26 22:59:27 --> UTF-8 Support Enabled
INFO - 2018-07-26 22:59:27 --> Utf8 Class Initialized
INFO - 2018-07-26 22:59:27 --> URI Class Initialized
INFO - 2018-07-26 22:59:27 --> Router Class Initialized
INFO - 2018-07-26 22:59:27 --> Output Class Initialized
INFO - 2018-07-26 22:59:27 --> Security Class Initialized
DEBUG - 2018-07-26 22:59:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 22:59:27 --> Input Class Initialized
INFO - 2018-07-26 22:59:27 --> Language Class Initialized
INFO - 2018-07-26 22:59:27 --> Language Class Initialized
INFO - 2018-07-26 22:59:27 --> Config Class Initialized
INFO - 2018-07-26 22:59:27 --> Loader Class Initialized
DEBUG - 2018-07-26 22:59:27 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-26 22:59:27 --> Helper loaded: url_helper
INFO - 2018-07-26 22:59:27 --> Helper loaded: form_helper
INFO - 2018-07-26 22:59:27 --> Helper loaded: date_helper
INFO - 2018-07-26 22:59:27 --> Helper loaded: util_helper
INFO - 2018-07-26 22:59:27 --> Helper loaded: text_helper
INFO - 2018-07-26 22:59:27 --> Helper loaded: string_helper
INFO - 2018-07-26 22:59:27 --> Database Driver Class Initialized
DEBUG - 2018-07-26 22:59:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 22:59:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 22:59:27 --> Email Class Initialized
INFO - 2018-07-26 22:59:27 --> Controller Class Initialized
DEBUG - 2018-07-26 22:59:27 --> Home MX_Controller Initialized
DEBUG - 2018-07-26 22:59:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-26 22:59:27 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-26 22:59:27 --> Login MX_Controller Initialized
INFO - 2018-07-26 22:59:27 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-26 22:59:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-26 22:59:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-26 22:59:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-26 22:59:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-26 22:59:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-26 22:59:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-26 22:59:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-26 22:59:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-26 22:59:27 --> Final output sent to browser
DEBUG - 2018-07-26 22:59:28 --> Total execution time: 0.4966
INFO - 2018-07-26 22:59:28 --> Config Class Initialized
INFO - 2018-07-26 22:59:28 --> Hooks Class Initialized
DEBUG - 2018-07-26 22:59:28 --> UTF-8 Support Enabled
INFO - 2018-07-26 22:59:28 --> Utf8 Class Initialized
INFO - 2018-07-26 22:59:28 --> URI Class Initialized
INFO - 2018-07-26 22:59:28 --> Router Class Initialized
INFO - 2018-07-26 22:59:28 --> Output Class Initialized
INFO - 2018-07-26 22:59:28 --> Security Class Initialized
DEBUG - 2018-07-26 22:59:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 22:59:28 --> Input Class Initialized
INFO - 2018-07-26 22:59:28 --> Language Class Initialized
ERROR - 2018-07-26 22:59:28 --> 404 Page Not Found: /index
INFO - 2018-07-26 22:59:28 --> Config Class Initialized
INFO - 2018-07-26 22:59:29 --> Hooks Class Initialized
DEBUG - 2018-07-26 22:59:29 --> UTF-8 Support Enabled
INFO - 2018-07-26 22:59:29 --> Utf8 Class Initialized
INFO - 2018-07-26 22:59:29 --> URI Class Initialized
INFO - 2018-07-26 22:59:29 --> Router Class Initialized
INFO - 2018-07-26 22:59:29 --> Output Class Initialized
INFO - 2018-07-26 22:59:29 --> Security Class Initialized
DEBUG - 2018-07-26 22:59:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 22:59:29 --> Input Class Initialized
INFO - 2018-07-26 22:59:29 --> Language Class Initialized
ERROR - 2018-07-26 22:59:29 --> 404 Page Not Found: /index
INFO - 2018-07-26 22:59:29 --> Config Class Initialized
INFO - 2018-07-26 22:59:29 --> Hooks Class Initialized
DEBUG - 2018-07-26 22:59:29 --> UTF-8 Support Enabled
INFO - 2018-07-26 22:59:29 --> Utf8 Class Initialized
INFO - 2018-07-26 22:59:29 --> URI Class Initialized
INFO - 2018-07-26 22:59:29 --> Router Class Initialized
INFO - 2018-07-26 22:59:29 --> Output Class Initialized
INFO - 2018-07-26 22:59:29 --> Security Class Initialized
DEBUG - 2018-07-26 22:59:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 22:59:29 --> Input Class Initialized
INFO - 2018-07-26 22:59:29 --> Language Class Initialized
ERROR - 2018-07-26 22:59:29 --> 404 Page Not Found: /index
INFO - 2018-07-26 22:59:29 --> Config Class Initialized
INFO - 2018-07-26 22:59:29 --> Hooks Class Initialized
DEBUG - 2018-07-26 22:59:29 --> UTF-8 Support Enabled
INFO - 2018-07-26 22:59:29 --> Utf8 Class Initialized
INFO - 2018-07-26 22:59:29 --> URI Class Initialized
INFO - 2018-07-26 22:59:29 --> Router Class Initialized
INFO - 2018-07-26 22:59:29 --> Output Class Initialized
INFO - 2018-07-26 22:59:29 --> Security Class Initialized
DEBUG - 2018-07-26 22:59:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 22:59:29 --> Input Class Initialized
INFO - 2018-07-26 22:59:29 --> Language Class Initialized
ERROR - 2018-07-26 22:59:29 --> 404 Page Not Found: /index
INFO - 2018-07-26 22:59:29 --> Config Class Initialized
INFO - 2018-07-26 22:59:29 --> Hooks Class Initialized
DEBUG - 2018-07-26 22:59:29 --> UTF-8 Support Enabled
INFO - 2018-07-26 22:59:29 --> Utf8 Class Initialized
INFO - 2018-07-26 22:59:29 --> URI Class Initialized
INFO - 2018-07-26 22:59:29 --> Router Class Initialized
INFO - 2018-07-26 22:59:29 --> Output Class Initialized
INFO - 2018-07-26 22:59:29 --> Security Class Initialized
DEBUG - 2018-07-26 22:59:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 22:59:29 --> Input Class Initialized
INFO - 2018-07-26 22:59:29 --> Language Class Initialized
ERROR - 2018-07-26 22:59:29 --> 404 Page Not Found: /index
INFO - 2018-07-26 22:59:29 --> Config Class Initialized
INFO - 2018-07-26 22:59:29 --> Hooks Class Initialized
DEBUG - 2018-07-26 22:59:30 --> UTF-8 Support Enabled
INFO - 2018-07-26 22:59:30 --> Utf8 Class Initialized
INFO - 2018-07-26 22:59:30 --> URI Class Initialized
INFO - 2018-07-26 22:59:30 --> Router Class Initialized
INFO - 2018-07-26 22:59:30 --> Output Class Initialized
INFO - 2018-07-26 22:59:30 --> Security Class Initialized
DEBUG - 2018-07-26 22:59:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 22:59:30 --> Input Class Initialized
INFO - 2018-07-26 22:59:30 --> Language Class Initialized
ERROR - 2018-07-26 22:59:30 --> 404 Page Not Found: /index
INFO - 2018-07-26 22:59:49 --> Config Class Initialized
INFO - 2018-07-26 22:59:49 --> Hooks Class Initialized
DEBUG - 2018-07-26 22:59:49 --> UTF-8 Support Enabled
INFO - 2018-07-26 22:59:49 --> Utf8 Class Initialized
INFO - 2018-07-26 22:59:50 --> URI Class Initialized
INFO - 2018-07-26 22:59:50 --> Router Class Initialized
INFO - 2018-07-26 22:59:50 --> Output Class Initialized
INFO - 2018-07-26 22:59:50 --> Security Class Initialized
DEBUG - 2018-07-26 22:59:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 22:59:50 --> Input Class Initialized
INFO - 2018-07-26 22:59:50 --> Language Class Initialized
INFO - 2018-07-26 22:59:50 --> Language Class Initialized
INFO - 2018-07-26 22:59:50 --> Config Class Initialized
INFO - 2018-07-26 22:59:50 --> Loader Class Initialized
DEBUG - 2018-07-26 22:59:50 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-26 22:59:50 --> Helper loaded: url_helper
INFO - 2018-07-26 22:59:50 --> Helper loaded: form_helper
INFO - 2018-07-26 22:59:50 --> Helper loaded: date_helper
INFO - 2018-07-26 22:59:50 --> Helper loaded: util_helper
INFO - 2018-07-26 22:59:50 --> Helper loaded: text_helper
INFO - 2018-07-26 22:59:50 --> Helper loaded: string_helper
INFO - 2018-07-26 22:59:50 --> Database Driver Class Initialized
DEBUG - 2018-07-26 22:59:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 22:59:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 22:59:50 --> Email Class Initialized
INFO - 2018-07-26 22:59:50 --> Controller Class Initialized
DEBUG - 2018-07-26 22:59:50 --> Home MX_Controller Initialized
DEBUG - 2018-07-26 22:59:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-26 22:59:50 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-26 22:59:50 --> Login MX_Controller Initialized
INFO - 2018-07-26 22:59:50 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-26 22:59:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-26 22:59:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-26 22:59:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-26 22:59:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-26 22:59:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-26 22:59:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-26 22:59:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-26 22:59:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-26 22:59:50 --> Final output sent to browser
DEBUG - 2018-07-26 22:59:50 --> Total execution time: 0.4948
INFO - 2018-07-26 22:59:51 --> Config Class Initialized
INFO - 2018-07-26 22:59:51 --> Hooks Class Initialized
DEBUG - 2018-07-26 22:59:51 --> UTF-8 Support Enabled
INFO - 2018-07-26 22:59:51 --> Utf8 Class Initialized
INFO - 2018-07-26 22:59:51 --> URI Class Initialized
INFO - 2018-07-26 22:59:51 --> Router Class Initialized
INFO - 2018-07-26 22:59:51 --> Output Class Initialized
INFO - 2018-07-26 22:59:51 --> Security Class Initialized
DEBUG - 2018-07-26 22:59:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 22:59:51 --> Input Class Initialized
INFO - 2018-07-26 22:59:51 --> Language Class Initialized
ERROR - 2018-07-26 22:59:51 --> 404 Page Not Found: /index
INFO - 2018-07-26 22:59:51 --> Config Class Initialized
INFO - 2018-07-26 22:59:51 --> Hooks Class Initialized
DEBUG - 2018-07-26 22:59:51 --> UTF-8 Support Enabled
INFO - 2018-07-26 22:59:51 --> Utf8 Class Initialized
INFO - 2018-07-26 22:59:51 --> URI Class Initialized
INFO - 2018-07-26 22:59:51 --> Router Class Initialized
INFO - 2018-07-26 22:59:51 --> Output Class Initialized
INFO - 2018-07-26 22:59:51 --> Security Class Initialized
DEBUG - 2018-07-26 22:59:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 22:59:51 --> Input Class Initialized
INFO - 2018-07-26 22:59:51 --> Language Class Initialized
ERROR - 2018-07-26 22:59:51 --> 404 Page Not Found: /index
INFO - 2018-07-26 22:59:51 --> Config Class Initialized
INFO - 2018-07-26 22:59:51 --> Hooks Class Initialized
DEBUG - 2018-07-26 22:59:51 --> UTF-8 Support Enabled
INFO - 2018-07-26 22:59:51 --> Utf8 Class Initialized
INFO - 2018-07-26 22:59:51 --> URI Class Initialized
INFO - 2018-07-26 22:59:51 --> Router Class Initialized
INFO - 2018-07-26 22:59:51 --> Output Class Initialized
INFO - 2018-07-26 22:59:51 --> Security Class Initialized
DEBUG - 2018-07-26 22:59:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 22:59:51 --> Input Class Initialized
INFO - 2018-07-26 22:59:51 --> Language Class Initialized
ERROR - 2018-07-26 22:59:51 --> 404 Page Not Found: /index
INFO - 2018-07-26 22:59:51 --> Config Class Initialized
INFO - 2018-07-26 22:59:51 --> Hooks Class Initialized
DEBUG - 2018-07-26 22:59:51 --> UTF-8 Support Enabled
INFO - 2018-07-26 22:59:51 --> Utf8 Class Initialized
INFO - 2018-07-26 22:59:51 --> URI Class Initialized
INFO - 2018-07-26 22:59:51 --> Router Class Initialized
INFO - 2018-07-26 22:59:51 --> Output Class Initialized
INFO - 2018-07-26 22:59:51 --> Security Class Initialized
DEBUG - 2018-07-26 22:59:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 22:59:51 --> Input Class Initialized
INFO - 2018-07-26 22:59:51 --> Language Class Initialized
ERROR - 2018-07-26 22:59:51 --> 404 Page Not Found: /index
INFO - 2018-07-26 22:59:51 --> Config Class Initialized
INFO - 2018-07-26 22:59:51 --> Hooks Class Initialized
DEBUG - 2018-07-26 22:59:51 --> UTF-8 Support Enabled
INFO - 2018-07-26 22:59:51 --> Utf8 Class Initialized
INFO - 2018-07-26 22:59:51 --> URI Class Initialized
INFO - 2018-07-26 22:59:51 --> Router Class Initialized
INFO - 2018-07-26 22:59:51 --> Output Class Initialized
INFO - 2018-07-26 22:59:51 --> Security Class Initialized
DEBUG - 2018-07-26 22:59:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 22:59:51 --> Input Class Initialized
INFO - 2018-07-26 22:59:51 --> Language Class Initialized
ERROR - 2018-07-26 22:59:51 --> 404 Page Not Found: /index
INFO - 2018-07-26 22:59:52 --> Config Class Initialized
INFO - 2018-07-26 22:59:52 --> Hooks Class Initialized
DEBUG - 2018-07-26 22:59:52 --> UTF-8 Support Enabled
INFO - 2018-07-26 22:59:52 --> Utf8 Class Initialized
INFO - 2018-07-26 22:59:52 --> URI Class Initialized
INFO - 2018-07-26 22:59:52 --> Router Class Initialized
INFO - 2018-07-26 22:59:52 --> Output Class Initialized
INFO - 2018-07-26 22:59:52 --> Security Class Initialized
DEBUG - 2018-07-26 22:59:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 22:59:52 --> Input Class Initialized
INFO - 2018-07-26 22:59:52 --> Language Class Initialized
ERROR - 2018-07-26 22:59:52 --> 404 Page Not Found: /index
INFO - 2018-07-26 23:00:02 --> Config Class Initialized
INFO - 2018-07-26 23:00:02 --> Hooks Class Initialized
DEBUG - 2018-07-26 23:00:02 --> UTF-8 Support Enabled
INFO - 2018-07-26 23:00:02 --> Utf8 Class Initialized
INFO - 2018-07-26 23:00:03 --> URI Class Initialized
INFO - 2018-07-26 23:00:03 --> Router Class Initialized
INFO - 2018-07-26 23:00:03 --> Output Class Initialized
INFO - 2018-07-26 23:00:03 --> Security Class Initialized
DEBUG - 2018-07-26 23:00:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 23:00:03 --> Input Class Initialized
INFO - 2018-07-26 23:00:03 --> Language Class Initialized
INFO - 2018-07-26 23:00:03 --> Language Class Initialized
INFO - 2018-07-26 23:00:03 --> Config Class Initialized
INFO - 2018-07-26 23:00:03 --> Loader Class Initialized
DEBUG - 2018-07-26 23:00:03 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-26 23:00:03 --> Helper loaded: url_helper
INFO - 2018-07-26 23:00:03 --> Helper loaded: form_helper
INFO - 2018-07-26 23:00:03 --> Helper loaded: date_helper
INFO - 2018-07-26 23:00:03 --> Helper loaded: util_helper
INFO - 2018-07-26 23:00:03 --> Helper loaded: text_helper
INFO - 2018-07-26 23:00:03 --> Helper loaded: string_helper
INFO - 2018-07-26 23:00:03 --> Database Driver Class Initialized
DEBUG - 2018-07-26 23:00:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 23:00:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 23:00:03 --> Email Class Initialized
INFO - 2018-07-26 23:00:03 --> Controller Class Initialized
DEBUG - 2018-07-26 23:00:03 --> Home MX_Controller Initialized
DEBUG - 2018-07-26 23:00:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-26 23:00:03 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-26 23:00:03 --> Login MX_Controller Initialized
INFO - 2018-07-26 23:00:03 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-26 23:00:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-26 23:00:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-26 23:00:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-26 23:00:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-26 23:00:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-26 23:00:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-26 23:00:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-26 23:00:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-26 23:00:03 --> Final output sent to browser
DEBUG - 2018-07-26 23:00:03 --> Total execution time: 0.5116
INFO - 2018-07-26 23:00:04 --> Config Class Initialized
INFO - 2018-07-26 23:00:04 --> Hooks Class Initialized
DEBUG - 2018-07-26 23:00:04 --> UTF-8 Support Enabled
INFO - 2018-07-26 23:00:04 --> Utf8 Class Initialized
INFO - 2018-07-26 23:00:04 --> URI Class Initialized
INFO - 2018-07-26 23:00:04 --> Router Class Initialized
INFO - 2018-07-26 23:00:04 --> Output Class Initialized
INFO - 2018-07-26 23:00:04 --> Security Class Initialized
DEBUG - 2018-07-26 23:00:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 23:00:04 --> Input Class Initialized
INFO - 2018-07-26 23:00:04 --> Language Class Initialized
ERROR - 2018-07-26 23:00:04 --> 404 Page Not Found: /index
INFO - 2018-07-26 23:00:04 --> Config Class Initialized
INFO - 2018-07-26 23:00:04 --> Hooks Class Initialized
DEBUG - 2018-07-26 23:00:04 --> UTF-8 Support Enabled
INFO - 2018-07-26 23:00:04 --> Utf8 Class Initialized
INFO - 2018-07-26 23:00:04 --> URI Class Initialized
INFO - 2018-07-26 23:00:04 --> Router Class Initialized
INFO - 2018-07-26 23:00:04 --> Output Class Initialized
INFO - 2018-07-26 23:00:04 --> Security Class Initialized
DEBUG - 2018-07-26 23:00:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 23:00:04 --> Input Class Initialized
INFO - 2018-07-26 23:00:04 --> Language Class Initialized
ERROR - 2018-07-26 23:00:04 --> 404 Page Not Found: /index
INFO - 2018-07-26 23:00:04 --> Config Class Initialized
INFO - 2018-07-26 23:00:04 --> Hooks Class Initialized
DEBUG - 2018-07-26 23:00:04 --> UTF-8 Support Enabled
INFO - 2018-07-26 23:00:04 --> Utf8 Class Initialized
INFO - 2018-07-26 23:00:04 --> URI Class Initialized
INFO - 2018-07-26 23:00:04 --> Router Class Initialized
INFO - 2018-07-26 23:00:04 --> Output Class Initialized
INFO - 2018-07-26 23:00:04 --> Security Class Initialized
DEBUG - 2018-07-26 23:00:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 23:00:04 --> Input Class Initialized
INFO - 2018-07-26 23:00:04 --> Language Class Initialized
ERROR - 2018-07-26 23:00:04 --> 404 Page Not Found: /index
INFO - 2018-07-26 23:00:04 --> Config Class Initialized
INFO - 2018-07-26 23:00:04 --> Hooks Class Initialized
DEBUG - 2018-07-26 23:00:04 --> UTF-8 Support Enabled
INFO - 2018-07-26 23:00:04 --> Utf8 Class Initialized
INFO - 2018-07-26 23:00:05 --> URI Class Initialized
INFO - 2018-07-26 23:00:05 --> Router Class Initialized
INFO - 2018-07-26 23:00:05 --> Output Class Initialized
INFO - 2018-07-26 23:00:05 --> Security Class Initialized
DEBUG - 2018-07-26 23:00:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 23:00:05 --> Input Class Initialized
INFO - 2018-07-26 23:00:05 --> Language Class Initialized
ERROR - 2018-07-26 23:00:05 --> 404 Page Not Found: /index
INFO - 2018-07-26 23:00:05 --> Config Class Initialized
INFO - 2018-07-26 23:00:05 --> Hooks Class Initialized
DEBUG - 2018-07-26 23:00:05 --> UTF-8 Support Enabled
INFO - 2018-07-26 23:00:05 --> Utf8 Class Initialized
INFO - 2018-07-26 23:00:05 --> URI Class Initialized
INFO - 2018-07-26 23:00:05 --> Router Class Initialized
INFO - 2018-07-26 23:00:05 --> Output Class Initialized
INFO - 2018-07-26 23:00:05 --> Security Class Initialized
DEBUG - 2018-07-26 23:00:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 23:00:05 --> Input Class Initialized
INFO - 2018-07-26 23:00:05 --> Language Class Initialized
ERROR - 2018-07-26 23:00:05 --> 404 Page Not Found: /index
INFO - 2018-07-26 23:00:05 --> Config Class Initialized
INFO - 2018-07-26 23:00:05 --> Hooks Class Initialized
DEBUG - 2018-07-26 23:00:05 --> UTF-8 Support Enabled
INFO - 2018-07-26 23:00:05 --> Utf8 Class Initialized
INFO - 2018-07-26 23:00:05 --> URI Class Initialized
INFO - 2018-07-26 23:00:05 --> Router Class Initialized
INFO - 2018-07-26 23:00:05 --> Output Class Initialized
INFO - 2018-07-26 23:00:05 --> Security Class Initialized
DEBUG - 2018-07-26 23:00:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 23:00:05 --> Input Class Initialized
INFO - 2018-07-26 23:00:05 --> Language Class Initialized
ERROR - 2018-07-26 23:00:05 --> 404 Page Not Found: /index
INFO - 2018-07-26 23:00:10 --> Config Class Initialized
INFO - 2018-07-26 23:00:10 --> Hooks Class Initialized
DEBUG - 2018-07-26 23:00:10 --> UTF-8 Support Enabled
INFO - 2018-07-26 23:00:10 --> Utf8 Class Initialized
INFO - 2018-07-26 23:00:10 --> URI Class Initialized
INFO - 2018-07-26 23:00:10 --> Router Class Initialized
INFO - 2018-07-26 23:00:10 --> Output Class Initialized
INFO - 2018-07-26 23:00:10 --> Security Class Initialized
DEBUG - 2018-07-26 23:00:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 23:00:10 --> Input Class Initialized
INFO - 2018-07-26 23:00:10 --> Language Class Initialized
ERROR - 2018-07-26 23:00:10 --> 404 Page Not Found: /index
INFO - 2018-07-26 23:00:10 --> Config Class Initialized
INFO - 2018-07-26 23:00:10 --> Hooks Class Initialized
DEBUG - 2018-07-26 23:00:10 --> UTF-8 Support Enabled
INFO - 2018-07-26 23:00:10 --> Utf8 Class Initialized
INFO - 2018-07-26 23:00:10 --> URI Class Initialized
INFO - 2018-07-26 23:00:10 --> Router Class Initialized
INFO - 2018-07-26 23:00:10 --> Output Class Initialized
INFO - 2018-07-26 23:00:10 --> Security Class Initialized
DEBUG - 2018-07-26 23:00:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 23:00:10 --> Input Class Initialized
INFO - 2018-07-26 23:00:10 --> Language Class Initialized
ERROR - 2018-07-26 23:00:10 --> 404 Page Not Found: /index
INFO - 2018-07-26 23:00:10 --> Config Class Initialized
INFO - 2018-07-26 23:00:10 --> Hooks Class Initialized
DEBUG - 2018-07-26 23:00:10 --> UTF-8 Support Enabled
INFO - 2018-07-26 23:00:10 --> Utf8 Class Initialized
INFO - 2018-07-26 23:00:10 --> URI Class Initialized
INFO - 2018-07-26 23:00:10 --> Router Class Initialized
INFO - 2018-07-26 23:00:10 --> Output Class Initialized
INFO - 2018-07-26 23:00:10 --> Security Class Initialized
DEBUG - 2018-07-26 23:00:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 23:00:10 --> Input Class Initialized
INFO - 2018-07-26 23:00:10 --> Language Class Initialized
ERROR - 2018-07-26 23:00:10 --> 404 Page Not Found: /index
INFO - 2018-07-26 23:00:57 --> Config Class Initialized
INFO - 2018-07-26 23:00:57 --> Hooks Class Initialized
DEBUG - 2018-07-26 23:00:57 --> UTF-8 Support Enabled
INFO - 2018-07-26 23:00:57 --> Utf8 Class Initialized
INFO - 2018-07-26 23:00:57 --> URI Class Initialized
INFO - 2018-07-26 23:00:57 --> Router Class Initialized
INFO - 2018-07-26 23:00:57 --> Output Class Initialized
INFO - 2018-07-26 23:00:57 --> Security Class Initialized
DEBUG - 2018-07-26 23:00:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 23:00:57 --> Input Class Initialized
INFO - 2018-07-26 23:00:57 --> Language Class Initialized
INFO - 2018-07-26 23:00:57 --> Language Class Initialized
INFO - 2018-07-26 23:00:57 --> Config Class Initialized
INFO - 2018-07-26 23:00:57 --> Loader Class Initialized
DEBUG - 2018-07-26 23:00:57 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-26 23:00:57 --> Helper loaded: url_helper
INFO - 2018-07-26 23:00:57 --> Helper loaded: form_helper
INFO - 2018-07-26 23:00:57 --> Helper loaded: date_helper
INFO - 2018-07-26 23:00:57 --> Helper loaded: util_helper
INFO - 2018-07-26 23:00:57 --> Helper loaded: text_helper
INFO - 2018-07-26 23:00:57 --> Helper loaded: string_helper
INFO - 2018-07-26 23:00:57 --> Database Driver Class Initialized
DEBUG - 2018-07-26 23:00:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 23:00:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 23:00:57 --> Email Class Initialized
INFO - 2018-07-26 23:00:57 --> Controller Class Initialized
DEBUG - 2018-07-26 23:00:57 --> Home MX_Controller Initialized
DEBUG - 2018-07-26 23:00:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-26 23:00:57 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-26 23:00:57 --> Login MX_Controller Initialized
INFO - 2018-07-26 23:00:57 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-26 23:00:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-26 23:00:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-26 23:00:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-26 23:00:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-26 23:00:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-26 23:00:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-26 23:00:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-26 23:00:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-26 23:00:57 --> Final output sent to browser
DEBUG - 2018-07-26 23:00:58 --> Total execution time: 0.5345
INFO - 2018-07-26 23:00:58 --> Config Class Initialized
INFO - 2018-07-26 23:00:58 --> Hooks Class Initialized
DEBUG - 2018-07-26 23:00:58 --> UTF-8 Support Enabled
INFO - 2018-07-26 23:00:58 --> Utf8 Class Initialized
INFO - 2018-07-26 23:00:58 --> URI Class Initialized
INFO - 2018-07-26 23:00:58 --> Router Class Initialized
INFO - 2018-07-26 23:00:58 --> Output Class Initialized
INFO - 2018-07-26 23:00:58 --> Security Class Initialized
DEBUG - 2018-07-26 23:00:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 23:00:58 --> Input Class Initialized
INFO - 2018-07-26 23:00:58 --> Language Class Initialized
ERROR - 2018-07-26 23:00:58 --> 404 Page Not Found: /index
INFO - 2018-07-26 23:00:58 --> Config Class Initialized
INFO - 2018-07-26 23:00:58 --> Hooks Class Initialized
DEBUG - 2018-07-26 23:00:58 --> UTF-8 Support Enabled
INFO - 2018-07-26 23:00:59 --> Utf8 Class Initialized
INFO - 2018-07-26 23:00:59 --> URI Class Initialized
INFO - 2018-07-26 23:00:59 --> Router Class Initialized
INFO - 2018-07-26 23:00:59 --> Output Class Initialized
INFO - 2018-07-26 23:00:59 --> Security Class Initialized
DEBUG - 2018-07-26 23:00:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 23:00:59 --> Input Class Initialized
INFO - 2018-07-26 23:00:59 --> Language Class Initialized
ERROR - 2018-07-26 23:00:59 --> 404 Page Not Found: /index
INFO - 2018-07-26 23:00:59 --> Config Class Initialized
INFO - 2018-07-26 23:00:59 --> Hooks Class Initialized
DEBUG - 2018-07-26 23:00:59 --> UTF-8 Support Enabled
INFO - 2018-07-26 23:00:59 --> Utf8 Class Initialized
INFO - 2018-07-26 23:00:59 --> URI Class Initialized
INFO - 2018-07-26 23:00:59 --> Router Class Initialized
INFO - 2018-07-26 23:00:59 --> Output Class Initialized
INFO - 2018-07-26 23:00:59 --> Security Class Initialized
DEBUG - 2018-07-26 23:00:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 23:00:59 --> Input Class Initialized
INFO - 2018-07-26 23:00:59 --> Language Class Initialized
ERROR - 2018-07-26 23:00:59 --> 404 Page Not Found: /index
INFO - 2018-07-26 23:00:59 --> Config Class Initialized
INFO - 2018-07-26 23:00:59 --> Hooks Class Initialized
DEBUG - 2018-07-26 23:00:59 --> UTF-8 Support Enabled
INFO - 2018-07-26 23:00:59 --> Utf8 Class Initialized
INFO - 2018-07-26 23:00:59 --> URI Class Initialized
INFO - 2018-07-26 23:00:59 --> Router Class Initialized
INFO - 2018-07-26 23:00:59 --> Output Class Initialized
INFO - 2018-07-26 23:00:59 --> Security Class Initialized
DEBUG - 2018-07-26 23:00:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 23:00:59 --> Input Class Initialized
INFO - 2018-07-26 23:00:59 --> Language Class Initialized
ERROR - 2018-07-26 23:00:59 --> 404 Page Not Found: /index
INFO - 2018-07-26 23:00:59 --> Config Class Initialized
INFO - 2018-07-26 23:00:59 --> Hooks Class Initialized
DEBUG - 2018-07-26 23:00:59 --> UTF-8 Support Enabled
INFO - 2018-07-26 23:00:59 --> Utf8 Class Initialized
INFO - 2018-07-26 23:00:59 --> URI Class Initialized
INFO - 2018-07-26 23:00:59 --> Router Class Initialized
INFO - 2018-07-26 23:00:59 --> Output Class Initialized
INFO - 2018-07-26 23:00:59 --> Security Class Initialized
DEBUG - 2018-07-26 23:00:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 23:00:59 --> Input Class Initialized
INFO - 2018-07-26 23:00:59 --> Language Class Initialized
ERROR - 2018-07-26 23:00:59 --> 404 Page Not Found: /index
INFO - 2018-07-26 23:00:59 --> Config Class Initialized
INFO - 2018-07-26 23:00:59 --> Hooks Class Initialized
DEBUG - 2018-07-26 23:00:59 --> UTF-8 Support Enabled
INFO - 2018-07-26 23:00:59 --> Utf8 Class Initialized
INFO - 2018-07-26 23:00:59 --> URI Class Initialized
INFO - 2018-07-26 23:00:59 --> Router Class Initialized
INFO - 2018-07-26 23:00:59 --> Output Class Initialized
INFO - 2018-07-26 23:00:59 --> Security Class Initialized
DEBUG - 2018-07-26 23:00:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 23:00:59 --> Input Class Initialized
INFO - 2018-07-26 23:00:59 --> Language Class Initialized
ERROR - 2018-07-26 23:00:59 --> 404 Page Not Found: /index
INFO - 2018-07-26 23:01:20 --> Config Class Initialized
INFO - 2018-07-26 23:01:20 --> Hooks Class Initialized
DEBUG - 2018-07-26 23:01:20 --> UTF-8 Support Enabled
INFO - 2018-07-26 23:01:20 --> Utf8 Class Initialized
INFO - 2018-07-26 23:01:20 --> URI Class Initialized
INFO - 2018-07-26 23:01:20 --> Router Class Initialized
INFO - 2018-07-26 23:01:20 --> Output Class Initialized
INFO - 2018-07-26 23:01:20 --> Security Class Initialized
DEBUG - 2018-07-26 23:01:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 23:01:20 --> Input Class Initialized
INFO - 2018-07-26 23:01:20 --> Language Class Initialized
ERROR - 2018-07-26 23:01:21 --> 404 Page Not Found: /index
INFO - 2018-07-26 23:01:21 --> Config Class Initialized
INFO - 2018-07-26 23:01:21 --> Hooks Class Initialized
DEBUG - 2018-07-26 23:01:21 --> UTF-8 Support Enabled
INFO - 2018-07-26 23:01:21 --> Utf8 Class Initialized
INFO - 2018-07-26 23:01:21 --> URI Class Initialized
INFO - 2018-07-26 23:01:21 --> Router Class Initialized
INFO - 2018-07-26 23:01:21 --> Output Class Initialized
INFO - 2018-07-26 23:01:21 --> Security Class Initialized
DEBUG - 2018-07-26 23:01:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 23:01:21 --> Input Class Initialized
INFO - 2018-07-26 23:01:21 --> Language Class Initialized
ERROR - 2018-07-26 23:01:21 --> 404 Page Not Found: /index
INFO - 2018-07-26 23:01:21 --> Config Class Initialized
INFO - 2018-07-26 23:01:21 --> Hooks Class Initialized
DEBUG - 2018-07-26 23:01:21 --> UTF-8 Support Enabled
INFO - 2018-07-26 23:01:21 --> Utf8 Class Initialized
INFO - 2018-07-26 23:01:21 --> URI Class Initialized
INFO - 2018-07-26 23:01:21 --> Router Class Initialized
INFO - 2018-07-26 23:01:21 --> Output Class Initialized
INFO - 2018-07-26 23:01:21 --> Security Class Initialized
DEBUG - 2018-07-26 23:01:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 23:01:21 --> Input Class Initialized
INFO - 2018-07-26 23:01:21 --> Language Class Initialized
ERROR - 2018-07-26 23:01:21 --> 404 Page Not Found: /index
INFO - 2018-07-26 23:01:21 --> Config Class Initialized
INFO - 2018-07-26 23:01:21 --> Hooks Class Initialized
DEBUG - 2018-07-26 23:01:21 --> UTF-8 Support Enabled
INFO - 2018-07-26 23:01:21 --> Utf8 Class Initialized
INFO - 2018-07-26 23:01:21 --> URI Class Initialized
INFO - 2018-07-26 23:01:21 --> Router Class Initialized
INFO - 2018-07-26 23:01:21 --> Output Class Initialized
INFO - 2018-07-26 23:01:21 --> Security Class Initialized
DEBUG - 2018-07-26 23:01:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 23:01:21 --> Input Class Initialized
INFO - 2018-07-26 23:01:21 --> Language Class Initialized
ERROR - 2018-07-26 23:01:21 --> 404 Page Not Found: /index
INFO - 2018-07-26 23:01:21 --> Config Class Initialized
INFO - 2018-07-26 23:01:21 --> Hooks Class Initialized
DEBUG - 2018-07-26 23:01:21 --> UTF-8 Support Enabled
INFO - 2018-07-26 23:01:21 --> Utf8 Class Initialized
INFO - 2018-07-26 23:01:21 --> URI Class Initialized
INFO - 2018-07-26 23:01:21 --> Router Class Initialized
INFO - 2018-07-26 23:01:21 --> Output Class Initialized
INFO - 2018-07-26 23:01:21 --> Security Class Initialized
DEBUG - 2018-07-26 23:01:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 23:01:21 --> Input Class Initialized
INFO - 2018-07-26 23:01:21 --> Language Class Initialized
ERROR - 2018-07-26 23:01:21 --> 404 Page Not Found: /index
INFO - 2018-07-26 23:01:21 --> Config Class Initialized
INFO - 2018-07-26 23:01:21 --> Hooks Class Initialized
DEBUG - 2018-07-26 23:01:21 --> UTF-8 Support Enabled
INFO - 2018-07-26 23:01:21 --> Utf8 Class Initialized
INFO - 2018-07-26 23:01:21 --> URI Class Initialized
INFO - 2018-07-26 23:01:21 --> Router Class Initialized
INFO - 2018-07-26 23:01:21 --> Output Class Initialized
INFO - 2018-07-26 23:01:21 --> Security Class Initialized
DEBUG - 2018-07-26 23:01:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 23:01:21 --> Input Class Initialized
INFO - 2018-07-26 23:01:21 --> Language Class Initialized
ERROR - 2018-07-26 23:01:21 --> 404 Page Not Found: /index
INFO - 2018-07-26 23:04:36 --> Config Class Initialized
INFO - 2018-07-26 23:04:36 --> Hooks Class Initialized
DEBUG - 2018-07-26 23:04:36 --> UTF-8 Support Enabled
INFO - 2018-07-26 23:04:36 --> Utf8 Class Initialized
INFO - 2018-07-26 23:04:36 --> URI Class Initialized
INFO - 2018-07-26 23:04:36 --> Router Class Initialized
INFO - 2018-07-26 23:04:36 --> Output Class Initialized
INFO - 2018-07-26 23:04:36 --> Security Class Initialized
DEBUG - 2018-07-26 23:04:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 23:04:36 --> Input Class Initialized
INFO - 2018-07-26 23:04:36 --> Language Class Initialized
INFO - 2018-07-26 23:04:36 --> Language Class Initialized
INFO - 2018-07-26 23:04:36 --> Config Class Initialized
INFO - 2018-07-26 23:04:36 --> Loader Class Initialized
DEBUG - 2018-07-26 23:04:36 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-26 23:04:36 --> Helper loaded: url_helper
INFO - 2018-07-26 23:04:36 --> Helper loaded: form_helper
INFO - 2018-07-26 23:04:36 --> Helper loaded: date_helper
INFO - 2018-07-26 23:04:36 --> Helper loaded: util_helper
INFO - 2018-07-26 23:04:36 --> Helper loaded: text_helper
INFO - 2018-07-26 23:04:36 --> Helper loaded: string_helper
INFO - 2018-07-26 23:04:36 --> Database Driver Class Initialized
DEBUG - 2018-07-26 23:04:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 23:04:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 23:04:36 --> Email Class Initialized
INFO - 2018-07-26 23:04:36 --> Controller Class Initialized
DEBUG - 2018-07-26 23:04:36 --> Home MX_Controller Initialized
DEBUG - 2018-07-26 23:04:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-26 23:04:36 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-26 23:04:36 --> Login MX_Controller Initialized
INFO - 2018-07-26 23:04:36 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-26 23:04:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-26 23:04:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-26 23:04:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-26 23:04:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-26 23:04:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-26 23:04:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-26 23:04:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-26 23:04:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-26 23:04:36 --> Final output sent to browser
DEBUG - 2018-07-26 23:04:36 --> Total execution time: 0.5241
INFO - 2018-07-26 23:04:37 --> Config Class Initialized
INFO - 2018-07-26 23:04:37 --> Hooks Class Initialized
DEBUG - 2018-07-26 23:04:37 --> UTF-8 Support Enabled
INFO - 2018-07-26 23:04:37 --> Utf8 Class Initialized
INFO - 2018-07-26 23:04:37 --> URI Class Initialized
INFO - 2018-07-26 23:04:37 --> Router Class Initialized
INFO - 2018-07-26 23:04:37 --> Output Class Initialized
INFO - 2018-07-26 23:04:37 --> Security Class Initialized
DEBUG - 2018-07-26 23:04:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 23:04:37 --> Input Class Initialized
INFO - 2018-07-26 23:04:37 --> Language Class Initialized
ERROR - 2018-07-26 23:04:37 --> 404 Page Not Found: /index
INFO - 2018-07-26 23:04:37 --> Config Class Initialized
INFO - 2018-07-26 23:04:37 --> Hooks Class Initialized
DEBUG - 2018-07-26 23:04:37 --> UTF-8 Support Enabled
INFO - 2018-07-26 23:04:37 --> Utf8 Class Initialized
INFO - 2018-07-26 23:04:37 --> URI Class Initialized
INFO - 2018-07-26 23:04:37 --> Router Class Initialized
INFO - 2018-07-26 23:04:37 --> Output Class Initialized
INFO - 2018-07-26 23:04:37 --> Security Class Initialized
DEBUG - 2018-07-26 23:04:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 23:04:37 --> Input Class Initialized
INFO - 2018-07-26 23:04:37 --> Language Class Initialized
ERROR - 2018-07-26 23:04:37 --> 404 Page Not Found: /index
INFO - 2018-07-26 23:04:37 --> Config Class Initialized
INFO - 2018-07-26 23:04:37 --> Hooks Class Initialized
DEBUG - 2018-07-26 23:04:37 --> UTF-8 Support Enabled
INFO - 2018-07-26 23:04:37 --> Utf8 Class Initialized
INFO - 2018-07-26 23:04:37 --> URI Class Initialized
INFO - 2018-07-26 23:04:37 --> Router Class Initialized
INFO - 2018-07-26 23:04:37 --> Output Class Initialized
INFO - 2018-07-26 23:04:37 --> Security Class Initialized
DEBUG - 2018-07-26 23:04:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 23:04:38 --> Input Class Initialized
INFO - 2018-07-26 23:04:38 --> Language Class Initialized
ERROR - 2018-07-26 23:04:38 --> 404 Page Not Found: /index
INFO - 2018-07-26 23:05:21 --> Config Class Initialized
INFO - 2018-07-26 23:05:21 --> Hooks Class Initialized
DEBUG - 2018-07-26 23:05:21 --> UTF-8 Support Enabled
INFO - 2018-07-26 23:05:21 --> Utf8 Class Initialized
INFO - 2018-07-26 23:05:21 --> URI Class Initialized
INFO - 2018-07-26 23:05:21 --> Router Class Initialized
INFO - 2018-07-26 23:05:21 --> Output Class Initialized
INFO - 2018-07-26 23:05:21 --> Security Class Initialized
DEBUG - 2018-07-26 23:05:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 23:05:21 --> Input Class Initialized
INFO - 2018-07-26 23:05:21 --> Language Class Initialized
INFO - 2018-07-26 23:05:21 --> Language Class Initialized
INFO - 2018-07-26 23:05:21 --> Config Class Initialized
INFO - 2018-07-26 23:05:21 --> Loader Class Initialized
DEBUG - 2018-07-26 23:05:21 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-26 23:05:21 --> Helper loaded: url_helper
INFO - 2018-07-26 23:05:21 --> Helper loaded: form_helper
INFO - 2018-07-26 23:05:21 --> Helper loaded: date_helper
INFO - 2018-07-26 23:05:21 --> Helper loaded: util_helper
INFO - 2018-07-26 23:05:21 --> Helper loaded: text_helper
INFO - 2018-07-26 23:05:21 --> Helper loaded: string_helper
INFO - 2018-07-26 23:05:21 --> Database Driver Class Initialized
DEBUG - 2018-07-26 23:05:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 23:05:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 23:05:21 --> Email Class Initialized
INFO - 2018-07-26 23:05:21 --> Controller Class Initialized
DEBUG - 2018-07-26 23:05:21 --> Home MX_Controller Initialized
DEBUG - 2018-07-26 23:05:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-26 23:05:21 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-26 23:05:21 --> Login MX_Controller Initialized
INFO - 2018-07-26 23:05:21 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-26 23:05:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-26 23:05:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-26 23:05:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-26 23:05:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-26 23:05:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-26 23:05:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-26 23:05:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-26 23:05:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-26 23:05:22 --> Final output sent to browser
DEBUG - 2018-07-26 23:05:22 --> Total execution time: 0.5365
INFO - 2018-07-26 23:05:22 --> Config Class Initialized
INFO - 2018-07-26 23:05:22 --> Hooks Class Initialized
DEBUG - 2018-07-26 23:05:22 --> UTF-8 Support Enabled
INFO - 2018-07-26 23:05:22 --> Utf8 Class Initialized
INFO - 2018-07-26 23:05:22 --> URI Class Initialized
INFO - 2018-07-26 23:05:22 --> Router Class Initialized
INFO - 2018-07-26 23:05:22 --> Output Class Initialized
INFO - 2018-07-26 23:05:23 --> Security Class Initialized
DEBUG - 2018-07-26 23:05:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 23:05:23 --> Input Class Initialized
INFO - 2018-07-26 23:05:23 --> Language Class Initialized
ERROR - 2018-07-26 23:05:23 --> 404 Page Not Found: /index
INFO - 2018-07-26 23:05:23 --> Config Class Initialized
INFO - 2018-07-26 23:05:23 --> Hooks Class Initialized
DEBUG - 2018-07-26 23:05:23 --> UTF-8 Support Enabled
INFO - 2018-07-26 23:05:23 --> Utf8 Class Initialized
INFO - 2018-07-26 23:05:23 --> URI Class Initialized
INFO - 2018-07-26 23:05:23 --> Router Class Initialized
INFO - 2018-07-26 23:05:23 --> Output Class Initialized
INFO - 2018-07-26 23:05:23 --> Security Class Initialized
DEBUG - 2018-07-26 23:05:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 23:05:23 --> Input Class Initialized
INFO - 2018-07-26 23:05:23 --> Language Class Initialized
ERROR - 2018-07-26 23:05:23 --> 404 Page Not Found: /index
INFO - 2018-07-26 23:05:23 --> Config Class Initialized
INFO - 2018-07-26 23:05:23 --> Hooks Class Initialized
DEBUG - 2018-07-26 23:05:23 --> UTF-8 Support Enabled
INFO - 2018-07-26 23:05:23 --> Utf8 Class Initialized
INFO - 2018-07-26 23:05:23 --> URI Class Initialized
INFO - 2018-07-26 23:05:23 --> Router Class Initialized
INFO - 2018-07-26 23:05:23 --> Output Class Initialized
INFO - 2018-07-26 23:05:23 --> Security Class Initialized
DEBUG - 2018-07-26 23:05:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 23:05:23 --> Input Class Initialized
INFO - 2018-07-26 23:05:23 --> Language Class Initialized
ERROR - 2018-07-26 23:05:23 --> 404 Page Not Found: /index
INFO - 2018-07-26 23:05:38 --> Config Class Initialized
INFO - 2018-07-26 23:05:38 --> Hooks Class Initialized
DEBUG - 2018-07-26 23:05:38 --> UTF-8 Support Enabled
INFO - 2018-07-26 23:05:38 --> Utf8 Class Initialized
INFO - 2018-07-26 23:05:38 --> URI Class Initialized
INFO - 2018-07-26 23:05:39 --> Router Class Initialized
INFO - 2018-07-26 23:05:39 --> Output Class Initialized
INFO - 2018-07-26 23:05:39 --> Security Class Initialized
DEBUG - 2018-07-26 23:05:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 23:05:39 --> Input Class Initialized
INFO - 2018-07-26 23:05:39 --> Language Class Initialized
INFO - 2018-07-26 23:05:39 --> Language Class Initialized
INFO - 2018-07-26 23:05:39 --> Config Class Initialized
INFO - 2018-07-26 23:05:39 --> Loader Class Initialized
DEBUG - 2018-07-26 23:05:39 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-26 23:05:39 --> Helper loaded: url_helper
INFO - 2018-07-26 23:05:39 --> Helper loaded: form_helper
INFO - 2018-07-26 23:05:39 --> Helper loaded: date_helper
INFO - 2018-07-26 23:05:39 --> Helper loaded: util_helper
INFO - 2018-07-26 23:05:39 --> Helper loaded: text_helper
INFO - 2018-07-26 23:05:39 --> Helper loaded: string_helper
INFO - 2018-07-26 23:05:39 --> Database Driver Class Initialized
DEBUG - 2018-07-26 23:05:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 23:05:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 23:05:39 --> Email Class Initialized
INFO - 2018-07-26 23:05:39 --> Controller Class Initialized
DEBUG - 2018-07-26 23:05:39 --> Programs MX_Controller Initialized
INFO - 2018-07-26 23:05:39 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-26 23:05:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-26 23:05:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-26 23:05:39 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-26 23:05:39 --> Login MX_Controller Initialized
DEBUG - 2018-07-26 23:05:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-26 23:05:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-26 23:05:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-26 23:05:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-26 23:05:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-26 23:05:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-26 23:05:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/programs.php
INFO - 2018-07-26 23:05:39 --> Final output sent to browser
DEBUG - 2018-07-26 23:05:39 --> Total execution time: 0.5635
INFO - 2018-07-26 23:05:40 --> Config Class Initialized
INFO - 2018-07-26 23:05:40 --> Hooks Class Initialized
DEBUG - 2018-07-26 23:05:40 --> UTF-8 Support Enabled
INFO - 2018-07-26 23:05:40 --> Utf8 Class Initialized
INFO - 2018-07-26 23:05:40 --> URI Class Initialized
INFO - 2018-07-26 23:05:40 --> Router Class Initialized
INFO - 2018-07-26 23:05:40 --> Output Class Initialized
INFO - 2018-07-26 23:05:40 --> Security Class Initialized
DEBUG - 2018-07-26 23:05:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 23:05:40 --> Input Class Initialized
INFO - 2018-07-26 23:05:40 --> Language Class Initialized
INFO - 2018-07-26 23:05:40 --> Language Class Initialized
INFO - 2018-07-26 23:05:40 --> Config Class Initialized
INFO - 2018-07-26 23:05:40 --> Loader Class Initialized
DEBUG - 2018-07-26 23:05:40 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-26 23:05:40 --> Helper loaded: url_helper
INFO - 2018-07-26 23:05:40 --> Helper loaded: form_helper
INFO - 2018-07-26 23:05:40 --> Helper loaded: date_helper
INFO - 2018-07-26 23:05:40 --> Helper loaded: util_helper
INFO - 2018-07-26 23:05:40 --> Helper loaded: text_helper
INFO - 2018-07-26 23:05:40 --> Helper loaded: string_helper
INFO - 2018-07-26 23:05:40 --> Database Driver Class Initialized
DEBUG - 2018-07-26 23:05:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 23:05:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 23:05:40 --> Email Class Initialized
INFO - 2018-07-26 23:05:40 --> Controller Class Initialized
DEBUG - 2018-07-26 23:05:40 --> Programs MX_Controller Initialized
INFO - 2018-07-26 23:05:40 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-26 23:05:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-26 23:05:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-26 23:05:40 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-26 23:05:40 --> Login MX_Controller Initialized
DEBUG - 2018-07-26 23:05:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-26 23:05:40 --> Final output sent to browser
DEBUG - 2018-07-26 23:05:40 --> Total execution time: 0.6294
INFO - 2018-07-26 23:05:42 --> Config Class Initialized
INFO - 2018-07-26 23:05:42 --> Hooks Class Initialized
DEBUG - 2018-07-26 23:05:42 --> UTF-8 Support Enabled
INFO - 2018-07-26 23:05:42 --> Utf8 Class Initialized
INFO - 2018-07-26 23:05:42 --> URI Class Initialized
INFO - 2018-07-26 23:05:42 --> Router Class Initialized
INFO - 2018-07-26 23:05:42 --> Output Class Initialized
INFO - 2018-07-26 23:05:42 --> Security Class Initialized
DEBUG - 2018-07-26 23:05:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 23:05:42 --> Input Class Initialized
INFO - 2018-07-26 23:05:42 --> Language Class Initialized
INFO - 2018-07-26 23:05:42 --> Language Class Initialized
INFO - 2018-07-26 23:05:42 --> Config Class Initialized
INFO - 2018-07-26 23:05:42 --> Loader Class Initialized
DEBUG - 2018-07-26 23:05:42 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-26 23:05:42 --> Helper loaded: url_helper
INFO - 2018-07-26 23:05:42 --> Helper loaded: form_helper
INFO - 2018-07-26 23:05:42 --> Helper loaded: date_helper
INFO - 2018-07-26 23:05:42 --> Helper loaded: util_helper
INFO - 2018-07-26 23:05:42 --> Helper loaded: text_helper
INFO - 2018-07-26 23:05:42 --> Helper loaded: string_helper
INFO - 2018-07-26 23:05:42 --> Database Driver Class Initialized
DEBUG - 2018-07-26 23:05:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 23:05:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 23:05:42 --> Email Class Initialized
INFO - 2018-07-26 23:05:42 --> Controller Class Initialized
DEBUG - 2018-07-26 23:05:42 --> Programs MX_Controller Initialized
INFO - 2018-07-26 23:05:42 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-26 23:05:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-26 23:05:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-26 23:05:42 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-26 23:05:42 --> Login MX_Controller Initialized
DEBUG - 2018-07-26 23:05:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-26 23:05:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-26 23:05:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-26 23:05:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-26 23:05:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-26 23:05:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-26 23:05:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/create_program.php
INFO - 2018-07-26 23:05:42 --> Final output sent to browser
DEBUG - 2018-07-26 23:05:42 --> Total execution time: 0.5243
INFO - 2018-07-26 23:05:51 --> Config Class Initialized
INFO - 2018-07-26 23:05:51 --> Hooks Class Initialized
DEBUG - 2018-07-26 23:05:51 --> UTF-8 Support Enabled
INFO - 2018-07-26 23:05:51 --> Utf8 Class Initialized
INFO - 2018-07-26 23:05:51 --> URI Class Initialized
INFO - 2018-07-26 23:05:51 --> Router Class Initialized
INFO - 2018-07-26 23:05:51 --> Output Class Initialized
INFO - 2018-07-26 23:05:51 --> Security Class Initialized
DEBUG - 2018-07-26 23:05:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 23:05:51 --> Input Class Initialized
INFO - 2018-07-26 23:05:51 --> Language Class Initialized
INFO - 2018-07-26 23:05:51 --> Language Class Initialized
INFO - 2018-07-26 23:05:51 --> Config Class Initialized
INFO - 2018-07-26 23:05:51 --> Loader Class Initialized
DEBUG - 2018-07-26 23:05:51 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-26 23:05:51 --> Helper loaded: url_helper
INFO - 2018-07-26 23:05:51 --> Helper loaded: form_helper
INFO - 2018-07-26 23:05:51 --> Helper loaded: date_helper
INFO - 2018-07-26 23:05:51 --> Helper loaded: util_helper
INFO - 2018-07-26 23:05:51 --> Helper loaded: text_helper
INFO - 2018-07-26 23:05:51 --> Helper loaded: string_helper
INFO - 2018-07-26 23:05:51 --> Database Driver Class Initialized
DEBUG - 2018-07-26 23:05:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 23:05:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 23:05:52 --> Email Class Initialized
INFO - 2018-07-26 23:05:52 --> Controller Class Initialized
DEBUG - 2018-07-26 23:05:52 --> Programs MX_Controller Initialized
INFO - 2018-07-26 23:05:52 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-26 23:05:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-26 23:05:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-26 23:05:52 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-26 23:05:52 --> Login MX_Controller Initialized
DEBUG - 2018-07-26 23:05:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-26 23:05:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-26 23:05:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-26 23:05:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-26 23:05:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-26 23:05:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-26 23:05:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/programs.php
INFO - 2018-07-26 23:05:52 --> Final output sent to browser
DEBUG - 2018-07-26 23:05:52 --> Total execution time: 0.5344
INFO - 2018-07-26 23:05:52 --> Config Class Initialized
INFO - 2018-07-26 23:05:52 --> Hooks Class Initialized
DEBUG - 2018-07-26 23:05:52 --> UTF-8 Support Enabled
INFO - 2018-07-26 23:05:52 --> Utf8 Class Initialized
INFO - 2018-07-26 23:05:52 --> URI Class Initialized
INFO - 2018-07-26 23:05:52 --> Router Class Initialized
INFO - 2018-07-26 23:05:52 --> Output Class Initialized
INFO - 2018-07-26 23:05:52 --> Security Class Initialized
DEBUG - 2018-07-26 23:05:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 23:05:52 --> Input Class Initialized
INFO - 2018-07-26 23:05:52 --> Language Class Initialized
INFO - 2018-07-26 23:05:52 --> Language Class Initialized
INFO - 2018-07-26 23:05:52 --> Config Class Initialized
INFO - 2018-07-26 23:05:52 --> Loader Class Initialized
DEBUG - 2018-07-26 23:05:53 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-26 23:05:53 --> Helper loaded: url_helper
INFO - 2018-07-26 23:05:53 --> Helper loaded: form_helper
INFO - 2018-07-26 23:05:53 --> Helper loaded: date_helper
INFO - 2018-07-26 23:05:53 --> Helper loaded: util_helper
INFO - 2018-07-26 23:05:53 --> Helper loaded: text_helper
INFO - 2018-07-26 23:05:53 --> Helper loaded: string_helper
INFO - 2018-07-26 23:05:53 --> Database Driver Class Initialized
DEBUG - 2018-07-26 23:05:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 23:05:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 23:05:53 --> Email Class Initialized
INFO - 2018-07-26 23:05:53 --> Controller Class Initialized
DEBUG - 2018-07-26 23:05:53 --> Programs MX_Controller Initialized
INFO - 2018-07-26 23:05:53 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-26 23:05:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-26 23:05:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-26 23:05:53 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-26 23:05:53 --> Login MX_Controller Initialized
DEBUG - 2018-07-26 23:05:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-26 23:05:53 --> Final output sent to browser
DEBUG - 2018-07-26 23:05:53 --> Total execution time: 0.6000
INFO - 2018-07-26 23:07:10 --> Config Class Initialized
INFO - 2018-07-26 23:07:10 --> Hooks Class Initialized
DEBUG - 2018-07-26 23:07:10 --> UTF-8 Support Enabled
INFO - 2018-07-26 23:07:10 --> Utf8 Class Initialized
INFO - 2018-07-26 23:07:10 --> URI Class Initialized
INFO - 2018-07-26 23:07:10 --> Router Class Initialized
INFO - 2018-07-26 23:07:10 --> Output Class Initialized
INFO - 2018-07-26 23:07:10 --> Security Class Initialized
DEBUG - 2018-07-26 23:07:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 23:07:10 --> Input Class Initialized
INFO - 2018-07-26 23:07:10 --> Language Class Initialized
INFO - 2018-07-26 23:07:10 --> Language Class Initialized
INFO - 2018-07-26 23:07:10 --> Config Class Initialized
INFO - 2018-07-26 23:07:10 --> Loader Class Initialized
DEBUG - 2018-07-26 23:07:10 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-26 23:07:10 --> Helper loaded: url_helper
INFO - 2018-07-26 23:07:10 --> Helper loaded: form_helper
INFO - 2018-07-26 23:07:10 --> Helper loaded: date_helper
INFO - 2018-07-26 23:07:10 --> Helper loaded: util_helper
INFO - 2018-07-26 23:07:10 --> Helper loaded: text_helper
INFO - 2018-07-26 23:07:10 --> Helper loaded: string_helper
INFO - 2018-07-26 23:07:10 --> Database Driver Class Initialized
DEBUG - 2018-07-26 23:07:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 23:07:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 23:07:10 --> Email Class Initialized
INFO - 2018-07-26 23:07:10 --> Controller Class Initialized
DEBUG - 2018-07-26 23:07:10 --> Home MX_Controller Initialized
DEBUG - 2018-07-26 23:07:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-26 23:07:10 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-26 23:07:10 --> Login MX_Controller Initialized
INFO - 2018-07-26 23:07:10 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-26 23:07:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-26 23:07:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-26 23:07:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-26 23:07:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-26 23:07:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-26 23:07:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-26 23:07:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-26 23:07:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-26 23:07:10 --> Final output sent to browser
DEBUG - 2018-07-26 23:07:10 --> Total execution time: 0.5479
INFO - 2018-07-26 23:07:11 --> Config Class Initialized
INFO - 2018-07-26 23:07:11 --> Hooks Class Initialized
DEBUG - 2018-07-26 23:07:11 --> UTF-8 Support Enabled
INFO - 2018-07-26 23:07:11 --> Utf8 Class Initialized
INFO - 2018-07-26 23:07:11 --> URI Class Initialized
INFO - 2018-07-26 23:07:11 --> Router Class Initialized
INFO - 2018-07-26 23:07:11 --> Output Class Initialized
INFO - 2018-07-26 23:07:11 --> Security Class Initialized
DEBUG - 2018-07-26 23:07:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 23:07:11 --> Input Class Initialized
INFO - 2018-07-26 23:07:11 --> Language Class Initialized
ERROR - 2018-07-26 23:07:11 --> 404 Page Not Found: /index
INFO - 2018-07-26 23:07:11 --> Config Class Initialized
INFO - 2018-07-26 23:07:11 --> Hooks Class Initialized
DEBUG - 2018-07-26 23:07:11 --> UTF-8 Support Enabled
INFO - 2018-07-26 23:07:11 --> Utf8 Class Initialized
INFO - 2018-07-26 23:07:11 --> URI Class Initialized
INFO - 2018-07-26 23:07:11 --> Router Class Initialized
INFO - 2018-07-26 23:07:11 --> Output Class Initialized
INFO - 2018-07-26 23:07:11 --> Security Class Initialized
DEBUG - 2018-07-26 23:07:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 23:07:11 --> Input Class Initialized
INFO - 2018-07-26 23:07:11 --> Language Class Initialized
ERROR - 2018-07-26 23:07:11 --> 404 Page Not Found: /index
INFO - 2018-07-26 23:07:11 --> Config Class Initialized
INFO - 2018-07-26 23:07:11 --> Hooks Class Initialized
DEBUG - 2018-07-26 23:07:11 --> UTF-8 Support Enabled
INFO - 2018-07-26 23:07:11 --> Utf8 Class Initialized
INFO - 2018-07-26 23:07:11 --> URI Class Initialized
INFO - 2018-07-26 23:07:12 --> Router Class Initialized
INFO - 2018-07-26 23:07:12 --> Output Class Initialized
INFO - 2018-07-26 23:07:12 --> Security Class Initialized
DEBUG - 2018-07-26 23:07:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 23:07:12 --> Input Class Initialized
INFO - 2018-07-26 23:07:12 --> Language Class Initialized
ERROR - 2018-07-26 23:07:12 --> 404 Page Not Found: /index
INFO - 2018-07-26 23:07:41 --> Config Class Initialized
INFO - 2018-07-26 23:07:41 --> Hooks Class Initialized
DEBUG - 2018-07-26 23:07:41 --> UTF-8 Support Enabled
INFO - 2018-07-26 23:07:41 --> Utf8 Class Initialized
INFO - 2018-07-26 23:07:41 --> URI Class Initialized
INFO - 2018-07-26 23:07:41 --> Router Class Initialized
INFO - 2018-07-26 23:07:41 --> Output Class Initialized
INFO - 2018-07-26 23:07:41 --> Security Class Initialized
DEBUG - 2018-07-26 23:07:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 23:07:41 --> Input Class Initialized
INFO - 2018-07-26 23:07:41 --> Language Class Initialized
INFO - 2018-07-26 23:07:41 --> Language Class Initialized
INFO - 2018-07-26 23:07:41 --> Config Class Initialized
INFO - 2018-07-26 23:07:41 --> Loader Class Initialized
DEBUG - 2018-07-26 23:07:41 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-26 23:07:41 --> Helper loaded: url_helper
INFO - 2018-07-26 23:07:41 --> Helper loaded: form_helper
INFO - 2018-07-26 23:07:41 --> Helper loaded: date_helper
INFO - 2018-07-26 23:07:41 --> Helper loaded: util_helper
INFO - 2018-07-26 23:07:41 --> Helper loaded: text_helper
INFO - 2018-07-26 23:07:41 --> Helper loaded: string_helper
INFO - 2018-07-26 23:07:41 --> Database Driver Class Initialized
DEBUG - 2018-07-26 23:07:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 23:07:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 23:07:41 --> Email Class Initialized
INFO - 2018-07-26 23:07:41 --> Controller Class Initialized
DEBUG - 2018-07-26 23:07:41 --> Home MX_Controller Initialized
DEBUG - 2018-07-26 23:07:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-26 23:07:41 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-26 23:07:41 --> Login MX_Controller Initialized
INFO - 2018-07-26 23:07:42 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-26 23:07:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-26 23:07:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-26 23:07:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-26 23:07:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-26 23:07:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-26 23:07:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-26 23:07:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-26 23:07:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-26 23:07:42 --> Final output sent to browser
DEBUG - 2018-07-26 23:07:42 --> Total execution time: 0.6022
INFO - 2018-07-26 23:07:42 --> Config Class Initialized
INFO - 2018-07-26 23:07:42 --> Hooks Class Initialized
DEBUG - 2018-07-26 23:07:42 --> UTF-8 Support Enabled
INFO - 2018-07-26 23:07:42 --> Utf8 Class Initialized
INFO - 2018-07-26 23:07:42 --> URI Class Initialized
INFO - 2018-07-26 23:07:42 --> Router Class Initialized
INFO - 2018-07-26 23:07:42 --> Output Class Initialized
INFO - 2018-07-26 23:07:42 --> Security Class Initialized
DEBUG - 2018-07-26 23:07:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 23:07:42 --> Input Class Initialized
INFO - 2018-07-26 23:07:42 --> Language Class Initialized
ERROR - 2018-07-26 23:07:42 --> 404 Page Not Found: /index
INFO - 2018-07-26 23:07:42 --> Config Class Initialized
INFO - 2018-07-26 23:07:42 --> Hooks Class Initialized
DEBUG - 2018-07-26 23:07:42 --> UTF-8 Support Enabled
INFO - 2018-07-26 23:07:42 --> Utf8 Class Initialized
INFO - 2018-07-26 23:07:43 --> URI Class Initialized
INFO - 2018-07-26 23:07:43 --> Router Class Initialized
INFO - 2018-07-26 23:07:43 --> Output Class Initialized
INFO - 2018-07-26 23:07:43 --> Security Class Initialized
DEBUG - 2018-07-26 23:07:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 23:07:43 --> Input Class Initialized
INFO - 2018-07-26 23:07:43 --> Language Class Initialized
ERROR - 2018-07-26 23:07:43 --> 404 Page Not Found: /index
INFO - 2018-07-26 23:07:43 --> Config Class Initialized
INFO - 2018-07-26 23:07:43 --> Hooks Class Initialized
DEBUG - 2018-07-26 23:07:43 --> UTF-8 Support Enabled
INFO - 2018-07-26 23:07:43 --> Utf8 Class Initialized
INFO - 2018-07-26 23:07:43 --> URI Class Initialized
INFO - 2018-07-26 23:07:43 --> Router Class Initialized
INFO - 2018-07-26 23:07:43 --> Output Class Initialized
INFO - 2018-07-26 23:07:43 --> Security Class Initialized
DEBUG - 2018-07-26 23:07:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 23:07:43 --> Input Class Initialized
INFO - 2018-07-26 23:07:43 --> Language Class Initialized
ERROR - 2018-07-26 23:07:43 --> 404 Page Not Found: /index
INFO - 2018-07-26 23:07:44 --> Config Class Initialized
INFO - 2018-07-26 23:07:44 --> Hooks Class Initialized
DEBUG - 2018-07-26 23:07:44 --> UTF-8 Support Enabled
INFO - 2018-07-26 23:07:44 --> Utf8 Class Initialized
INFO - 2018-07-26 23:07:44 --> URI Class Initialized
INFO - 2018-07-26 23:07:45 --> Router Class Initialized
INFO - 2018-07-26 23:07:45 --> Output Class Initialized
INFO - 2018-07-26 23:07:45 --> Security Class Initialized
DEBUG - 2018-07-26 23:07:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 23:07:45 --> Input Class Initialized
INFO - 2018-07-26 23:07:45 --> Language Class Initialized
INFO - 2018-07-26 23:07:45 --> Language Class Initialized
INFO - 2018-07-26 23:07:45 --> Config Class Initialized
INFO - 2018-07-26 23:07:45 --> Loader Class Initialized
DEBUG - 2018-07-26 23:07:45 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-26 23:07:45 --> Helper loaded: url_helper
INFO - 2018-07-26 23:07:45 --> Helper loaded: form_helper
INFO - 2018-07-26 23:07:45 --> Helper loaded: date_helper
INFO - 2018-07-26 23:07:45 --> Helper loaded: util_helper
INFO - 2018-07-26 23:07:45 --> Helper loaded: text_helper
INFO - 2018-07-26 23:07:45 --> Helper loaded: string_helper
INFO - 2018-07-26 23:07:45 --> Database Driver Class Initialized
DEBUG - 2018-07-26 23:07:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 23:07:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 23:07:45 --> Email Class Initialized
INFO - 2018-07-26 23:07:45 --> Controller Class Initialized
DEBUG - 2018-07-26 23:07:45 --> Admin MX_Controller Initialized
INFO - 2018-07-26 23:07:45 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-26 23:07:45 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-26 23:07:45 --> Login MX_Controller Initialized
DEBUG - 2018-07-26 23:07:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-26 23:07:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-26 23:07:45 --> Config Class Initialized
INFO - 2018-07-26 23:07:45 --> Final output sent to browser
INFO - 2018-07-26 23:07:45 --> Hooks Class Initialized
DEBUG - 2018-07-26 23:07:45 --> Total execution time: 0.5892
DEBUG - 2018-07-26 23:07:45 --> UTF-8 Support Enabled
INFO - 2018-07-26 23:07:45 --> Utf8 Class Initialized
INFO - 2018-07-26 23:07:45 --> URI Class Initialized
INFO - 2018-07-26 23:07:45 --> Router Class Initialized
INFO - 2018-07-26 23:07:45 --> Output Class Initialized
INFO - 2018-07-26 23:07:45 --> Security Class Initialized
DEBUG - 2018-07-26 23:07:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 23:07:45 --> Input Class Initialized
INFO - 2018-07-26 23:07:45 --> Language Class Initialized
INFO - 2018-07-26 23:07:45 --> Language Class Initialized
INFO - 2018-07-26 23:07:45 --> Config Class Initialized
INFO - 2018-07-26 23:07:45 --> Loader Class Initialized
DEBUG - 2018-07-26 23:07:45 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-26 23:07:45 --> Helper loaded: url_helper
INFO - 2018-07-26 23:07:45 --> Helper loaded: form_helper
INFO - 2018-07-26 23:07:45 --> Helper loaded: date_helper
INFO - 2018-07-26 23:07:45 --> Helper loaded: util_helper
INFO - 2018-07-26 23:07:45 --> Helper loaded: text_helper
INFO - 2018-07-26 23:07:45 --> Helper loaded: string_helper
INFO - 2018-07-26 23:07:45 --> Database Driver Class Initialized
DEBUG - 2018-07-26 23:07:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 23:07:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 23:07:45 --> Email Class Initialized
INFO - 2018-07-26 23:07:45 --> Controller Class Initialized
DEBUG - 2018-07-26 23:07:45 --> Admin MX_Controller Initialized
INFO - 2018-07-26 23:07:45 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-26 23:07:45 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-26 23:07:45 --> Login MX_Controller Initialized
DEBUG - 2018-07-26 23:07:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-26 23:07:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-26 23:07:46 --> Final output sent to browser
DEBUG - 2018-07-26 23:07:46 --> Total execution time: 0.5199
INFO - 2018-07-26 23:07:50 --> Config Class Initialized
INFO - 2018-07-26 23:07:50 --> Hooks Class Initialized
DEBUG - 2018-07-26 23:07:50 --> UTF-8 Support Enabled
INFO - 2018-07-26 23:07:50 --> Utf8 Class Initialized
INFO - 2018-07-26 23:07:50 --> URI Class Initialized
INFO - 2018-07-26 23:07:50 --> Router Class Initialized
INFO - 2018-07-26 23:07:50 --> Output Class Initialized
INFO - 2018-07-26 23:07:50 --> Security Class Initialized
DEBUG - 2018-07-26 23:07:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 23:07:50 --> Input Class Initialized
INFO - 2018-07-26 23:07:50 --> Language Class Initialized
INFO - 2018-07-26 23:07:50 --> Language Class Initialized
INFO - 2018-07-26 23:07:50 --> Config Class Initialized
INFO - 2018-07-26 23:07:50 --> Loader Class Initialized
DEBUG - 2018-07-26 23:07:50 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-26 23:07:50 --> Helper loaded: url_helper
INFO - 2018-07-26 23:07:50 --> Helper loaded: form_helper
INFO - 2018-07-26 23:07:50 --> Helper loaded: date_helper
INFO - 2018-07-26 23:07:50 --> Helper loaded: util_helper
INFO - 2018-07-26 23:07:50 --> Helper loaded: text_helper
INFO - 2018-07-26 23:07:50 --> Helper loaded: string_helper
INFO - 2018-07-26 23:07:50 --> Database Driver Class Initialized
DEBUG - 2018-07-26 23:07:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 23:07:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 23:07:50 --> Email Class Initialized
INFO - 2018-07-26 23:07:50 --> Controller Class Initialized
DEBUG - 2018-07-26 23:07:50 --> Home MX_Controller Initialized
DEBUG - 2018-07-26 23:07:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-26 23:07:50 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-26 23:07:50 --> Login MX_Controller Initialized
INFO - 2018-07-26 23:07:50 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-26 23:07:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-26 23:07:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-26 23:07:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-26 23:07:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-26 23:07:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-26 23:07:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-26 23:07:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-26 23:07:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-26 23:07:50 --> Final output sent to browser
DEBUG - 2018-07-26 23:07:50 --> Total execution time: 0.5556
INFO - 2018-07-26 23:07:51 --> Config Class Initialized
INFO - 2018-07-26 23:07:51 --> Hooks Class Initialized
DEBUG - 2018-07-26 23:07:51 --> UTF-8 Support Enabled
INFO - 2018-07-26 23:07:51 --> Utf8 Class Initialized
INFO - 2018-07-26 23:07:51 --> URI Class Initialized
INFO - 2018-07-26 23:07:51 --> Router Class Initialized
INFO - 2018-07-26 23:07:51 --> Output Class Initialized
INFO - 2018-07-26 23:07:51 --> Security Class Initialized
DEBUG - 2018-07-26 23:07:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 23:07:51 --> Input Class Initialized
INFO - 2018-07-26 23:07:51 --> Language Class Initialized
ERROR - 2018-07-26 23:07:51 --> 404 Page Not Found: /index
INFO - 2018-07-26 23:07:51 --> Config Class Initialized
INFO - 2018-07-26 23:07:51 --> Hooks Class Initialized
DEBUG - 2018-07-26 23:07:51 --> UTF-8 Support Enabled
INFO - 2018-07-26 23:07:51 --> Utf8 Class Initialized
INFO - 2018-07-26 23:07:51 --> URI Class Initialized
INFO - 2018-07-26 23:07:51 --> Router Class Initialized
INFO - 2018-07-26 23:07:51 --> Output Class Initialized
INFO - 2018-07-26 23:07:51 --> Security Class Initialized
DEBUG - 2018-07-26 23:07:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 23:07:51 --> Input Class Initialized
INFO - 2018-07-26 23:07:51 --> Language Class Initialized
ERROR - 2018-07-26 23:07:51 --> 404 Page Not Found: /index
INFO - 2018-07-26 23:07:51 --> Config Class Initialized
INFO - 2018-07-26 23:07:51 --> Hooks Class Initialized
DEBUG - 2018-07-26 23:07:51 --> UTF-8 Support Enabled
INFO - 2018-07-26 23:07:51 --> Utf8 Class Initialized
INFO - 2018-07-26 23:07:51 --> URI Class Initialized
INFO - 2018-07-26 23:07:51 --> Router Class Initialized
INFO - 2018-07-26 23:07:51 --> Output Class Initialized
INFO - 2018-07-26 23:07:51 --> Security Class Initialized
DEBUG - 2018-07-26 23:07:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 23:07:51 --> Input Class Initialized
INFO - 2018-07-26 23:07:51 --> Language Class Initialized
ERROR - 2018-07-26 23:07:51 --> 404 Page Not Found: /index
INFO - 2018-07-26 23:08:46 --> Config Class Initialized
INFO - 2018-07-26 23:08:46 --> Hooks Class Initialized
DEBUG - 2018-07-26 23:08:46 --> UTF-8 Support Enabled
INFO - 2018-07-26 23:08:46 --> Utf8 Class Initialized
INFO - 2018-07-26 23:08:46 --> URI Class Initialized
INFO - 2018-07-26 23:08:46 --> Router Class Initialized
INFO - 2018-07-26 23:08:46 --> Output Class Initialized
INFO - 2018-07-26 23:08:46 --> Security Class Initialized
DEBUG - 2018-07-26 23:08:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 23:08:47 --> Input Class Initialized
INFO - 2018-07-26 23:08:47 --> Language Class Initialized
INFO - 2018-07-26 23:08:47 --> Language Class Initialized
INFO - 2018-07-26 23:08:47 --> Config Class Initialized
INFO - 2018-07-26 23:08:47 --> Loader Class Initialized
DEBUG - 2018-07-26 23:08:47 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-26 23:08:47 --> Helper loaded: url_helper
INFO - 2018-07-26 23:08:47 --> Helper loaded: form_helper
INFO - 2018-07-26 23:08:47 --> Helper loaded: date_helper
INFO - 2018-07-26 23:08:47 --> Helper loaded: util_helper
INFO - 2018-07-26 23:08:47 --> Helper loaded: text_helper
INFO - 2018-07-26 23:08:47 --> Helper loaded: string_helper
INFO - 2018-07-26 23:08:47 --> Database Driver Class Initialized
DEBUG - 2018-07-26 23:08:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 23:08:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 23:08:47 --> Email Class Initialized
INFO - 2018-07-26 23:08:47 --> Controller Class Initialized
DEBUG - 2018-07-26 23:08:47 --> Home MX_Controller Initialized
DEBUG - 2018-07-26 23:08:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-26 23:08:47 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-26 23:08:47 --> Login MX_Controller Initialized
INFO - 2018-07-26 23:08:47 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-26 23:08:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-26 23:08:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-26 23:08:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-26 23:08:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-26 23:08:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-26 23:08:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-26 23:08:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-26 23:08:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-26 23:08:47 --> Final output sent to browser
DEBUG - 2018-07-26 23:08:47 --> Total execution time: 0.5874
INFO - 2018-07-26 23:08:47 --> Config Class Initialized
INFO - 2018-07-26 23:08:48 --> Hooks Class Initialized
DEBUG - 2018-07-26 23:08:48 --> UTF-8 Support Enabled
INFO - 2018-07-26 23:08:48 --> Utf8 Class Initialized
INFO - 2018-07-26 23:08:48 --> URI Class Initialized
INFO - 2018-07-26 23:08:48 --> Router Class Initialized
INFO - 2018-07-26 23:08:48 --> Output Class Initialized
INFO - 2018-07-26 23:08:48 --> Security Class Initialized
DEBUG - 2018-07-26 23:08:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 23:08:48 --> Input Class Initialized
INFO - 2018-07-26 23:08:48 --> Language Class Initialized
ERROR - 2018-07-26 23:08:48 --> 404 Page Not Found: /index
INFO - 2018-07-26 23:08:48 --> Config Class Initialized
INFO - 2018-07-26 23:08:48 --> Hooks Class Initialized
DEBUG - 2018-07-26 23:08:48 --> UTF-8 Support Enabled
INFO - 2018-07-26 23:08:48 --> Utf8 Class Initialized
INFO - 2018-07-26 23:08:48 --> URI Class Initialized
INFO - 2018-07-26 23:08:48 --> Router Class Initialized
INFO - 2018-07-26 23:08:48 --> Output Class Initialized
INFO - 2018-07-26 23:08:48 --> Security Class Initialized
DEBUG - 2018-07-26 23:08:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 23:08:48 --> Input Class Initialized
INFO - 2018-07-26 23:08:48 --> Language Class Initialized
ERROR - 2018-07-26 23:08:48 --> 404 Page Not Found: /index
INFO - 2018-07-26 23:08:48 --> Config Class Initialized
INFO - 2018-07-26 23:08:48 --> Hooks Class Initialized
DEBUG - 2018-07-26 23:08:48 --> UTF-8 Support Enabled
INFO - 2018-07-26 23:08:48 --> Utf8 Class Initialized
INFO - 2018-07-26 23:08:48 --> URI Class Initialized
INFO - 2018-07-26 23:08:48 --> Router Class Initialized
INFO - 2018-07-26 23:08:48 --> Output Class Initialized
INFO - 2018-07-26 23:08:48 --> Security Class Initialized
DEBUG - 2018-07-26 23:08:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 23:08:48 --> Input Class Initialized
INFO - 2018-07-26 23:08:48 --> Language Class Initialized
ERROR - 2018-07-26 23:08:48 --> 404 Page Not Found: /index
INFO - 2018-07-26 23:09:12 --> Config Class Initialized
INFO - 2018-07-26 23:09:12 --> Hooks Class Initialized
DEBUG - 2018-07-26 23:09:12 --> UTF-8 Support Enabled
INFO - 2018-07-26 23:09:12 --> Utf8 Class Initialized
INFO - 2018-07-26 23:09:12 --> URI Class Initialized
INFO - 2018-07-26 23:09:12 --> Router Class Initialized
INFO - 2018-07-26 23:09:12 --> Output Class Initialized
INFO - 2018-07-26 23:09:12 --> Security Class Initialized
DEBUG - 2018-07-26 23:09:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 23:09:12 --> Input Class Initialized
INFO - 2018-07-26 23:09:12 --> Language Class Initialized
ERROR - 2018-07-26 23:09:12 --> 404 Page Not Found: /index
INFO - 2018-07-26 23:09:12 --> Config Class Initialized
INFO - 2018-07-26 23:09:12 --> Hooks Class Initialized
DEBUG - 2018-07-26 23:09:12 --> UTF-8 Support Enabled
INFO - 2018-07-26 23:09:12 --> Utf8 Class Initialized
INFO - 2018-07-26 23:09:12 --> URI Class Initialized
INFO - 2018-07-26 23:09:12 --> Router Class Initialized
INFO - 2018-07-26 23:09:12 --> Output Class Initialized
INFO - 2018-07-26 23:09:12 --> Security Class Initialized
DEBUG - 2018-07-26 23:09:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 23:09:12 --> Input Class Initialized
INFO - 2018-07-26 23:09:13 --> Language Class Initialized
ERROR - 2018-07-26 23:09:13 --> 404 Page Not Found: /index
INFO - 2018-07-26 23:09:13 --> Config Class Initialized
INFO - 2018-07-26 23:09:13 --> Hooks Class Initialized
DEBUG - 2018-07-26 23:09:13 --> UTF-8 Support Enabled
INFO - 2018-07-26 23:09:13 --> Utf8 Class Initialized
INFO - 2018-07-26 23:09:13 --> URI Class Initialized
INFO - 2018-07-26 23:09:13 --> Router Class Initialized
INFO - 2018-07-26 23:09:13 --> Output Class Initialized
INFO - 2018-07-26 23:09:13 --> Security Class Initialized
DEBUG - 2018-07-26 23:09:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 23:09:13 --> Input Class Initialized
INFO - 2018-07-26 23:09:13 --> Language Class Initialized
ERROR - 2018-07-26 23:09:13 --> 404 Page Not Found: /index
INFO - 2018-07-26 23:09:15 --> Config Class Initialized
INFO - 2018-07-26 23:09:15 --> Hooks Class Initialized
DEBUG - 2018-07-26 23:09:15 --> UTF-8 Support Enabled
INFO - 2018-07-26 23:09:15 --> Utf8 Class Initialized
INFO - 2018-07-26 23:09:15 --> URI Class Initialized
INFO - 2018-07-26 23:09:15 --> Router Class Initialized
INFO - 2018-07-26 23:09:15 --> Output Class Initialized
INFO - 2018-07-26 23:09:15 --> Security Class Initialized
DEBUG - 2018-07-26 23:09:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 23:09:15 --> Input Class Initialized
INFO - 2018-07-26 23:09:15 --> Language Class Initialized
ERROR - 2018-07-26 23:09:15 --> 404 Page Not Found: /index
INFO - 2018-07-26 23:09:15 --> Config Class Initialized
INFO - 2018-07-26 23:09:15 --> Hooks Class Initialized
DEBUG - 2018-07-26 23:09:15 --> UTF-8 Support Enabled
INFO - 2018-07-26 23:09:15 --> Utf8 Class Initialized
INFO - 2018-07-26 23:09:15 --> URI Class Initialized
INFO - 2018-07-26 23:09:15 --> Router Class Initialized
INFO - 2018-07-26 23:09:15 --> Output Class Initialized
INFO - 2018-07-26 23:09:15 --> Security Class Initialized
DEBUG - 2018-07-26 23:09:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 23:09:15 --> Input Class Initialized
INFO - 2018-07-26 23:09:15 --> Language Class Initialized
ERROR - 2018-07-26 23:09:15 --> 404 Page Not Found: /index
INFO - 2018-07-26 23:09:15 --> Config Class Initialized
INFO - 2018-07-26 23:09:15 --> Hooks Class Initialized
DEBUG - 2018-07-26 23:09:15 --> UTF-8 Support Enabled
INFO - 2018-07-26 23:09:15 --> Utf8 Class Initialized
INFO - 2018-07-26 23:09:15 --> URI Class Initialized
INFO - 2018-07-26 23:09:15 --> Router Class Initialized
INFO - 2018-07-26 23:09:15 --> Output Class Initialized
INFO - 2018-07-26 23:09:15 --> Security Class Initialized
DEBUG - 2018-07-26 23:09:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 23:09:15 --> Input Class Initialized
INFO - 2018-07-26 23:09:15 --> Language Class Initialized
ERROR - 2018-07-26 23:09:15 --> 404 Page Not Found: /index
INFO - 2018-07-26 23:17:38 --> Config Class Initialized
INFO - 2018-07-26 23:17:38 --> Hooks Class Initialized
DEBUG - 2018-07-26 23:17:38 --> UTF-8 Support Enabled
INFO - 2018-07-26 23:17:38 --> Utf8 Class Initialized
INFO - 2018-07-26 23:17:38 --> URI Class Initialized
INFO - 2018-07-26 23:17:38 --> Router Class Initialized
INFO - 2018-07-26 23:17:38 --> Output Class Initialized
INFO - 2018-07-26 23:17:38 --> Security Class Initialized
DEBUG - 2018-07-26 23:17:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 23:17:38 --> Input Class Initialized
INFO - 2018-07-26 23:17:38 --> Language Class Initialized
INFO - 2018-07-26 23:17:38 --> Language Class Initialized
INFO - 2018-07-26 23:17:38 --> Config Class Initialized
INFO - 2018-07-26 23:17:38 --> Loader Class Initialized
DEBUG - 2018-07-26 23:17:38 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-26 23:17:38 --> Helper loaded: url_helper
INFO - 2018-07-26 23:17:38 --> Helper loaded: form_helper
INFO - 2018-07-26 23:17:38 --> Helper loaded: date_helper
INFO - 2018-07-26 23:17:38 --> Helper loaded: util_helper
INFO - 2018-07-26 23:17:38 --> Helper loaded: text_helper
INFO - 2018-07-26 23:17:38 --> Helper loaded: string_helper
INFO - 2018-07-26 23:17:38 --> Database Driver Class Initialized
DEBUG - 2018-07-26 23:17:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 23:17:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 23:17:38 --> Email Class Initialized
INFO - 2018-07-26 23:17:38 --> Controller Class Initialized
DEBUG - 2018-07-26 23:17:38 --> Home MX_Controller Initialized
DEBUG - 2018-07-26 23:17:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-26 23:17:38 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-26 23:17:38 --> Login MX_Controller Initialized
INFO - 2018-07-26 23:17:38 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-26 23:17:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-26 23:17:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-26 23:17:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-26 23:17:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-26 23:17:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-26 23:17:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-26 23:17:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-26 23:17:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-26 23:17:38 --> Final output sent to browser
DEBUG - 2018-07-26 23:17:39 --> Total execution time: 0.5853
INFO - 2018-07-26 23:17:39 --> Config Class Initialized
INFO - 2018-07-26 23:17:39 --> Hooks Class Initialized
DEBUG - 2018-07-26 23:17:39 --> UTF-8 Support Enabled
INFO - 2018-07-26 23:17:39 --> Utf8 Class Initialized
INFO - 2018-07-26 23:17:40 --> URI Class Initialized
INFO - 2018-07-26 23:17:40 --> Router Class Initialized
INFO - 2018-07-26 23:17:40 --> Output Class Initialized
INFO - 2018-07-26 23:17:40 --> Security Class Initialized
DEBUG - 2018-07-26 23:17:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 23:17:40 --> Input Class Initialized
INFO - 2018-07-26 23:17:40 --> Language Class Initialized
ERROR - 2018-07-26 23:17:40 --> 404 Page Not Found: /index
INFO - 2018-07-26 23:17:40 --> Config Class Initialized
INFO - 2018-07-26 23:17:40 --> Hooks Class Initialized
DEBUG - 2018-07-26 23:17:40 --> UTF-8 Support Enabled
INFO - 2018-07-26 23:17:40 --> Utf8 Class Initialized
INFO - 2018-07-26 23:17:40 --> URI Class Initialized
INFO - 2018-07-26 23:17:40 --> Router Class Initialized
INFO - 2018-07-26 23:17:40 --> Output Class Initialized
INFO - 2018-07-26 23:17:40 --> Security Class Initialized
DEBUG - 2018-07-26 23:17:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 23:17:40 --> Input Class Initialized
INFO - 2018-07-26 23:17:40 --> Language Class Initialized
ERROR - 2018-07-26 23:17:40 --> 404 Page Not Found: /index
INFO - 2018-07-26 23:17:40 --> Config Class Initialized
INFO - 2018-07-26 23:17:40 --> Hooks Class Initialized
DEBUG - 2018-07-26 23:17:40 --> UTF-8 Support Enabled
INFO - 2018-07-26 23:17:40 --> Utf8 Class Initialized
INFO - 2018-07-26 23:17:40 --> URI Class Initialized
INFO - 2018-07-26 23:17:40 --> Router Class Initialized
INFO - 2018-07-26 23:17:40 --> Output Class Initialized
INFO - 2018-07-26 23:17:40 --> Security Class Initialized
DEBUG - 2018-07-26 23:17:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 23:17:40 --> Input Class Initialized
INFO - 2018-07-26 23:17:40 --> Language Class Initialized
ERROR - 2018-07-26 23:17:40 --> 404 Page Not Found: /index
INFO - 2018-07-26 23:18:06 --> Config Class Initialized
INFO - 2018-07-26 23:18:06 --> Hooks Class Initialized
DEBUG - 2018-07-26 23:18:06 --> UTF-8 Support Enabled
INFO - 2018-07-26 23:18:07 --> Utf8 Class Initialized
INFO - 2018-07-26 23:18:07 --> URI Class Initialized
INFO - 2018-07-26 23:18:07 --> Router Class Initialized
INFO - 2018-07-26 23:18:07 --> Output Class Initialized
INFO - 2018-07-26 23:18:07 --> Security Class Initialized
DEBUG - 2018-07-26 23:18:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 23:18:07 --> Input Class Initialized
INFO - 2018-07-26 23:18:07 --> Language Class Initialized
INFO - 2018-07-26 23:18:07 --> Language Class Initialized
INFO - 2018-07-26 23:18:07 --> Config Class Initialized
INFO - 2018-07-26 23:18:07 --> Loader Class Initialized
DEBUG - 2018-07-26 23:18:07 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-26 23:18:07 --> Helper loaded: url_helper
INFO - 2018-07-26 23:18:07 --> Helper loaded: form_helper
INFO - 2018-07-26 23:18:07 --> Helper loaded: date_helper
INFO - 2018-07-26 23:18:07 --> Helper loaded: util_helper
INFO - 2018-07-26 23:18:07 --> Helper loaded: text_helper
INFO - 2018-07-26 23:18:07 --> Helper loaded: string_helper
INFO - 2018-07-26 23:18:07 --> Database Driver Class Initialized
DEBUG - 2018-07-26 23:18:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 23:18:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 23:18:07 --> Email Class Initialized
INFO - 2018-07-26 23:18:07 --> Controller Class Initialized
DEBUG - 2018-07-26 23:18:07 --> Home MX_Controller Initialized
DEBUG - 2018-07-26 23:18:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-26 23:18:07 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-26 23:18:07 --> Login MX_Controller Initialized
INFO - 2018-07-26 23:18:07 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-26 23:18:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-26 23:18:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-26 23:18:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-26 23:18:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-26 23:18:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-26 23:18:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-26 23:18:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-26 23:18:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-26 23:18:07 --> Final output sent to browser
DEBUG - 2018-07-26 23:18:07 --> Total execution time: 0.5578
INFO - 2018-07-26 23:18:08 --> Config Class Initialized
INFO - 2018-07-26 23:18:08 --> Hooks Class Initialized
DEBUG - 2018-07-26 23:18:08 --> UTF-8 Support Enabled
INFO - 2018-07-26 23:18:08 --> Utf8 Class Initialized
INFO - 2018-07-26 23:18:08 --> URI Class Initialized
INFO - 2018-07-26 23:18:08 --> Router Class Initialized
INFO - 2018-07-26 23:18:08 --> Output Class Initialized
INFO - 2018-07-26 23:18:08 --> Security Class Initialized
DEBUG - 2018-07-26 23:18:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 23:18:08 --> Input Class Initialized
INFO - 2018-07-26 23:18:08 --> Language Class Initialized
ERROR - 2018-07-26 23:18:08 --> 404 Page Not Found: /index
INFO - 2018-07-26 23:18:08 --> Config Class Initialized
INFO - 2018-07-26 23:18:08 --> Hooks Class Initialized
DEBUG - 2018-07-26 23:18:08 --> UTF-8 Support Enabled
INFO - 2018-07-26 23:18:08 --> Utf8 Class Initialized
INFO - 2018-07-26 23:18:08 --> URI Class Initialized
INFO - 2018-07-26 23:18:08 --> Router Class Initialized
INFO - 2018-07-26 23:18:08 --> Output Class Initialized
INFO - 2018-07-26 23:18:08 --> Security Class Initialized
DEBUG - 2018-07-26 23:18:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 23:18:08 --> Input Class Initialized
INFO - 2018-07-26 23:18:08 --> Language Class Initialized
ERROR - 2018-07-26 23:18:08 --> 404 Page Not Found: /index
INFO - 2018-07-26 23:18:08 --> Config Class Initialized
INFO - 2018-07-26 23:18:08 --> Hooks Class Initialized
DEBUG - 2018-07-26 23:18:08 --> UTF-8 Support Enabled
INFO - 2018-07-26 23:18:08 --> Utf8 Class Initialized
INFO - 2018-07-26 23:18:08 --> URI Class Initialized
INFO - 2018-07-26 23:18:08 --> Router Class Initialized
INFO - 2018-07-26 23:18:08 --> Output Class Initialized
INFO - 2018-07-26 23:18:08 --> Security Class Initialized
DEBUG - 2018-07-26 23:18:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 23:18:08 --> Input Class Initialized
INFO - 2018-07-26 23:18:08 --> Language Class Initialized
ERROR - 2018-07-26 23:18:08 --> 404 Page Not Found: /index
INFO - 2018-07-26 23:18:12 --> Config Class Initialized
INFO - 2018-07-26 23:18:12 --> Hooks Class Initialized
DEBUG - 2018-07-26 23:18:12 --> UTF-8 Support Enabled
INFO - 2018-07-26 23:18:12 --> Utf8 Class Initialized
INFO - 2018-07-26 23:18:12 --> URI Class Initialized
INFO - 2018-07-26 23:18:12 --> Router Class Initialized
INFO - 2018-07-26 23:18:12 --> Output Class Initialized
INFO - 2018-07-26 23:18:12 --> Security Class Initialized
DEBUG - 2018-07-26 23:18:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 23:18:12 --> Input Class Initialized
INFO - 2018-07-26 23:18:12 --> Language Class Initialized
INFO - 2018-07-26 23:18:12 --> Language Class Initialized
INFO - 2018-07-26 23:18:12 --> Config Class Initialized
INFO - 2018-07-26 23:18:12 --> Loader Class Initialized
DEBUG - 2018-07-26 23:18:12 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-26 23:18:12 --> Helper loaded: url_helper
INFO - 2018-07-26 23:18:12 --> Helper loaded: form_helper
INFO - 2018-07-26 23:18:12 --> Helper loaded: date_helper
INFO - 2018-07-26 23:18:12 --> Helper loaded: util_helper
INFO - 2018-07-26 23:18:12 --> Helper loaded: text_helper
INFO - 2018-07-26 23:18:12 --> Helper loaded: string_helper
INFO - 2018-07-26 23:18:12 --> Database Driver Class Initialized
DEBUG - 2018-07-26 23:18:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 23:18:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 23:18:13 --> Email Class Initialized
INFO - 2018-07-26 23:18:13 --> Controller Class Initialized
DEBUG - 2018-07-26 23:18:13 --> Home MX_Controller Initialized
DEBUG - 2018-07-26 23:18:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-26 23:18:13 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-26 23:18:13 --> Login MX_Controller Initialized
INFO - 2018-07-26 23:18:13 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-26 23:18:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-26 23:18:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-26 23:18:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-26 23:18:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-26 23:18:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-26 23:18:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-26 23:18:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-26 23:18:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-26 23:18:13 --> Final output sent to browser
DEBUG - 2018-07-26 23:18:13 --> Total execution time: 0.5615
INFO - 2018-07-26 23:18:13 --> Config Class Initialized
INFO - 2018-07-26 23:18:13 --> Hooks Class Initialized
DEBUG - 2018-07-26 23:18:13 --> UTF-8 Support Enabled
INFO - 2018-07-26 23:18:13 --> Utf8 Class Initialized
INFO - 2018-07-26 23:18:13 --> URI Class Initialized
INFO - 2018-07-26 23:18:13 --> Router Class Initialized
INFO - 2018-07-26 23:18:13 --> Output Class Initialized
INFO - 2018-07-26 23:18:13 --> Security Class Initialized
DEBUG - 2018-07-26 23:18:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 23:18:14 --> Input Class Initialized
INFO - 2018-07-26 23:18:14 --> Language Class Initialized
ERROR - 2018-07-26 23:18:14 --> 404 Page Not Found: /index
INFO - 2018-07-26 23:18:14 --> Config Class Initialized
INFO - 2018-07-26 23:18:14 --> Hooks Class Initialized
DEBUG - 2018-07-26 23:18:14 --> UTF-8 Support Enabled
INFO - 2018-07-26 23:18:14 --> Utf8 Class Initialized
INFO - 2018-07-26 23:18:14 --> URI Class Initialized
INFO - 2018-07-26 23:18:14 --> Router Class Initialized
INFO - 2018-07-26 23:18:14 --> Output Class Initialized
INFO - 2018-07-26 23:18:14 --> Security Class Initialized
DEBUG - 2018-07-26 23:18:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 23:18:14 --> Input Class Initialized
INFO - 2018-07-26 23:18:14 --> Language Class Initialized
ERROR - 2018-07-26 23:18:14 --> 404 Page Not Found: /index
INFO - 2018-07-26 23:18:14 --> Config Class Initialized
INFO - 2018-07-26 23:18:14 --> Hooks Class Initialized
DEBUG - 2018-07-26 23:18:14 --> UTF-8 Support Enabled
INFO - 2018-07-26 23:18:14 --> Utf8 Class Initialized
INFO - 2018-07-26 23:18:14 --> URI Class Initialized
INFO - 2018-07-26 23:18:14 --> Router Class Initialized
INFO - 2018-07-26 23:18:14 --> Output Class Initialized
INFO - 2018-07-26 23:18:14 --> Security Class Initialized
DEBUG - 2018-07-26 23:18:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 23:18:14 --> Input Class Initialized
INFO - 2018-07-26 23:18:14 --> Language Class Initialized
ERROR - 2018-07-26 23:18:14 --> 404 Page Not Found: /index
INFO - 2018-07-26 23:19:28 --> Config Class Initialized
INFO - 2018-07-26 23:19:28 --> Hooks Class Initialized
DEBUG - 2018-07-26 23:19:28 --> UTF-8 Support Enabled
INFO - 2018-07-26 23:19:28 --> Utf8 Class Initialized
INFO - 2018-07-26 23:19:28 --> URI Class Initialized
INFO - 2018-07-26 23:19:28 --> Router Class Initialized
INFO - 2018-07-26 23:19:28 --> Output Class Initialized
INFO - 2018-07-26 23:19:28 --> Security Class Initialized
DEBUG - 2018-07-26 23:19:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 23:19:28 --> Input Class Initialized
INFO - 2018-07-26 23:19:28 --> Language Class Initialized
INFO - 2018-07-26 23:19:28 --> Language Class Initialized
INFO - 2018-07-26 23:19:28 --> Config Class Initialized
INFO - 2018-07-26 23:19:28 --> Loader Class Initialized
DEBUG - 2018-07-26 23:19:28 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-26 23:19:28 --> Helper loaded: url_helper
INFO - 2018-07-26 23:19:28 --> Helper loaded: form_helper
INFO - 2018-07-26 23:19:28 --> Helper loaded: date_helper
INFO - 2018-07-26 23:19:28 --> Helper loaded: util_helper
INFO - 2018-07-26 23:19:28 --> Helper loaded: text_helper
INFO - 2018-07-26 23:19:28 --> Helper loaded: string_helper
INFO - 2018-07-26 23:19:28 --> Database Driver Class Initialized
DEBUG - 2018-07-26 23:19:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 23:19:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 23:19:28 --> Email Class Initialized
INFO - 2018-07-26 23:19:28 --> Controller Class Initialized
DEBUG - 2018-07-26 23:19:28 --> Home MX_Controller Initialized
DEBUG - 2018-07-26 23:19:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-26 23:19:28 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-26 23:19:28 --> Login MX_Controller Initialized
INFO - 2018-07-26 23:19:28 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-26 23:19:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-26 23:19:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-26 23:19:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-26 23:19:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-26 23:19:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-26 23:19:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-26 23:19:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-26 23:19:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-26 23:19:28 --> Final output sent to browser
DEBUG - 2018-07-26 23:19:28 --> Total execution time: 0.5878
INFO - 2018-07-26 23:19:29 --> Config Class Initialized
INFO - 2018-07-26 23:19:29 --> Hooks Class Initialized
DEBUG - 2018-07-26 23:19:29 --> UTF-8 Support Enabled
INFO - 2018-07-26 23:19:29 --> Utf8 Class Initialized
INFO - 2018-07-26 23:19:29 --> URI Class Initialized
INFO - 2018-07-26 23:19:29 --> Router Class Initialized
INFO - 2018-07-26 23:19:29 --> Output Class Initialized
INFO - 2018-07-26 23:19:29 --> Security Class Initialized
DEBUG - 2018-07-26 23:19:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 23:19:29 --> Input Class Initialized
INFO - 2018-07-26 23:19:29 --> Language Class Initialized
ERROR - 2018-07-26 23:19:29 --> 404 Page Not Found: /index
INFO - 2018-07-26 23:19:29 --> Config Class Initialized
INFO - 2018-07-26 23:19:29 --> Hooks Class Initialized
DEBUG - 2018-07-26 23:19:29 --> UTF-8 Support Enabled
INFO - 2018-07-26 23:19:29 --> Utf8 Class Initialized
INFO - 2018-07-26 23:19:29 --> URI Class Initialized
INFO - 2018-07-26 23:19:29 --> Router Class Initialized
INFO - 2018-07-26 23:19:29 --> Output Class Initialized
INFO - 2018-07-26 23:19:29 --> Security Class Initialized
DEBUG - 2018-07-26 23:19:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 23:19:29 --> Input Class Initialized
INFO - 2018-07-26 23:19:29 --> Language Class Initialized
ERROR - 2018-07-26 23:19:29 --> 404 Page Not Found: /index
INFO - 2018-07-26 23:19:30 --> Config Class Initialized
INFO - 2018-07-26 23:19:30 --> Hooks Class Initialized
DEBUG - 2018-07-26 23:19:30 --> UTF-8 Support Enabled
INFO - 2018-07-26 23:19:30 --> Utf8 Class Initialized
INFO - 2018-07-26 23:19:30 --> URI Class Initialized
INFO - 2018-07-26 23:19:30 --> Router Class Initialized
INFO - 2018-07-26 23:19:30 --> Output Class Initialized
INFO - 2018-07-26 23:19:30 --> Security Class Initialized
DEBUG - 2018-07-26 23:19:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 23:19:30 --> Input Class Initialized
INFO - 2018-07-26 23:19:30 --> Language Class Initialized
ERROR - 2018-07-26 23:19:30 --> 404 Page Not Found: /index
INFO - 2018-07-26 23:19:30 --> Config Class Initialized
INFO - 2018-07-26 23:19:30 --> Hooks Class Initialized
DEBUG - 2018-07-26 23:19:30 --> UTF-8 Support Enabled
INFO - 2018-07-26 23:19:30 --> Utf8 Class Initialized
INFO - 2018-07-26 23:19:30 --> URI Class Initialized
INFO - 2018-07-26 23:19:30 --> Router Class Initialized
INFO - 2018-07-26 23:19:30 --> Output Class Initialized
INFO - 2018-07-26 23:19:30 --> Security Class Initialized
DEBUG - 2018-07-26 23:19:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 23:19:30 --> Input Class Initialized
INFO - 2018-07-26 23:19:30 --> Language Class Initialized
ERROR - 2018-07-26 23:19:30 --> 404 Page Not Found: /index
INFO - 2018-07-26 23:19:30 --> Config Class Initialized
INFO - 2018-07-26 23:19:30 --> Hooks Class Initialized
DEBUG - 2018-07-26 23:19:30 --> UTF-8 Support Enabled
INFO - 2018-07-26 23:19:30 --> Utf8 Class Initialized
INFO - 2018-07-26 23:19:30 --> URI Class Initialized
INFO - 2018-07-26 23:19:30 --> Router Class Initialized
INFO - 2018-07-26 23:19:30 --> Output Class Initialized
INFO - 2018-07-26 23:19:30 --> Security Class Initialized
DEBUG - 2018-07-26 23:19:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 23:19:30 --> Input Class Initialized
INFO - 2018-07-26 23:19:30 --> Language Class Initialized
ERROR - 2018-07-26 23:19:30 --> 404 Page Not Found: /index
INFO - 2018-07-26 23:19:30 --> Config Class Initialized
INFO - 2018-07-26 23:19:30 --> Hooks Class Initialized
DEBUG - 2018-07-26 23:19:30 --> UTF-8 Support Enabled
INFO - 2018-07-26 23:19:30 --> Utf8 Class Initialized
INFO - 2018-07-26 23:19:30 --> URI Class Initialized
INFO - 2018-07-26 23:19:30 --> Router Class Initialized
INFO - 2018-07-26 23:19:30 --> Output Class Initialized
INFO - 2018-07-26 23:19:30 --> Security Class Initialized
DEBUG - 2018-07-26 23:19:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 23:19:30 --> Input Class Initialized
INFO - 2018-07-26 23:19:30 --> Language Class Initialized
ERROR - 2018-07-26 23:19:30 --> 404 Page Not Found: /index
INFO - 2018-07-26 23:20:10 --> Config Class Initialized
INFO - 2018-07-26 23:20:10 --> Hooks Class Initialized
DEBUG - 2018-07-26 23:20:10 --> UTF-8 Support Enabled
INFO - 2018-07-26 23:20:10 --> Utf8 Class Initialized
INFO - 2018-07-26 23:20:10 --> URI Class Initialized
INFO - 2018-07-26 23:20:11 --> Router Class Initialized
INFO - 2018-07-26 23:20:11 --> Output Class Initialized
INFO - 2018-07-26 23:20:11 --> Security Class Initialized
DEBUG - 2018-07-26 23:20:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 23:20:11 --> Input Class Initialized
INFO - 2018-07-26 23:20:11 --> Language Class Initialized
INFO - 2018-07-26 23:20:11 --> Language Class Initialized
INFO - 2018-07-26 23:20:11 --> Config Class Initialized
INFO - 2018-07-26 23:20:11 --> Loader Class Initialized
DEBUG - 2018-07-26 23:20:11 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-26 23:20:11 --> Helper loaded: url_helper
INFO - 2018-07-26 23:20:11 --> Helper loaded: form_helper
INFO - 2018-07-26 23:20:11 --> Helper loaded: date_helper
INFO - 2018-07-26 23:20:11 --> Helper loaded: util_helper
INFO - 2018-07-26 23:20:11 --> Helper loaded: text_helper
INFO - 2018-07-26 23:20:11 --> Helper loaded: string_helper
INFO - 2018-07-26 23:20:11 --> Database Driver Class Initialized
DEBUG - 2018-07-26 23:20:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 23:20:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 23:20:11 --> Email Class Initialized
INFO - 2018-07-26 23:20:11 --> Controller Class Initialized
DEBUG - 2018-07-26 23:20:11 --> Home MX_Controller Initialized
DEBUG - 2018-07-26 23:20:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-26 23:20:11 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-26 23:20:11 --> Login MX_Controller Initialized
INFO - 2018-07-26 23:20:11 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-26 23:20:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-26 23:20:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-26 23:20:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-26 23:20:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-26 23:20:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-26 23:20:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-26 23:20:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-26 23:20:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-26 23:20:11 --> Final output sent to browser
DEBUG - 2018-07-26 23:20:11 --> Total execution time: 0.5573
INFO - 2018-07-26 23:20:12 --> Config Class Initialized
INFO - 2018-07-26 23:20:12 --> Hooks Class Initialized
DEBUG - 2018-07-26 23:20:12 --> UTF-8 Support Enabled
INFO - 2018-07-26 23:20:12 --> Utf8 Class Initialized
INFO - 2018-07-26 23:20:12 --> URI Class Initialized
INFO - 2018-07-26 23:20:12 --> Router Class Initialized
INFO - 2018-07-26 23:20:12 --> Output Class Initialized
INFO - 2018-07-26 23:20:12 --> Security Class Initialized
DEBUG - 2018-07-26 23:20:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 23:20:12 --> Input Class Initialized
INFO - 2018-07-26 23:20:12 --> Language Class Initialized
ERROR - 2018-07-26 23:20:12 --> 404 Page Not Found: /index
INFO - 2018-07-26 23:20:12 --> Config Class Initialized
INFO - 2018-07-26 23:20:12 --> Hooks Class Initialized
DEBUG - 2018-07-26 23:20:12 --> UTF-8 Support Enabled
INFO - 2018-07-26 23:20:12 --> Utf8 Class Initialized
INFO - 2018-07-26 23:20:12 --> URI Class Initialized
INFO - 2018-07-26 23:20:12 --> Router Class Initialized
INFO - 2018-07-26 23:20:12 --> Output Class Initialized
INFO - 2018-07-26 23:20:12 --> Security Class Initialized
DEBUG - 2018-07-26 23:20:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 23:20:12 --> Input Class Initialized
INFO - 2018-07-26 23:20:12 --> Language Class Initialized
ERROR - 2018-07-26 23:20:12 --> 404 Page Not Found: /index
INFO - 2018-07-26 23:20:12 --> Config Class Initialized
INFO - 2018-07-26 23:20:12 --> Hooks Class Initialized
DEBUG - 2018-07-26 23:20:12 --> UTF-8 Support Enabled
INFO - 2018-07-26 23:20:12 --> Utf8 Class Initialized
INFO - 2018-07-26 23:20:12 --> URI Class Initialized
INFO - 2018-07-26 23:20:12 --> Router Class Initialized
INFO - 2018-07-26 23:20:12 --> Output Class Initialized
INFO - 2018-07-26 23:20:12 --> Security Class Initialized
DEBUG - 2018-07-26 23:20:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 23:20:12 --> Input Class Initialized
INFO - 2018-07-26 23:20:12 --> Language Class Initialized
ERROR - 2018-07-26 23:20:12 --> 404 Page Not Found: /index
INFO - 2018-07-26 23:20:12 --> Config Class Initialized
INFO - 2018-07-26 23:20:13 --> Hooks Class Initialized
DEBUG - 2018-07-26 23:20:13 --> UTF-8 Support Enabled
INFO - 2018-07-26 23:20:13 --> Utf8 Class Initialized
INFO - 2018-07-26 23:20:13 --> URI Class Initialized
INFO - 2018-07-26 23:20:13 --> Router Class Initialized
INFO - 2018-07-26 23:20:13 --> Output Class Initialized
INFO - 2018-07-26 23:20:13 --> Security Class Initialized
DEBUG - 2018-07-26 23:20:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 23:20:13 --> Input Class Initialized
INFO - 2018-07-26 23:20:13 --> Language Class Initialized
ERROR - 2018-07-26 23:20:13 --> 404 Page Not Found: /index
INFO - 2018-07-26 23:20:13 --> Config Class Initialized
INFO - 2018-07-26 23:20:13 --> Hooks Class Initialized
DEBUG - 2018-07-26 23:20:13 --> UTF-8 Support Enabled
INFO - 2018-07-26 23:20:13 --> Utf8 Class Initialized
INFO - 2018-07-26 23:20:13 --> URI Class Initialized
INFO - 2018-07-26 23:20:13 --> Router Class Initialized
INFO - 2018-07-26 23:20:13 --> Output Class Initialized
INFO - 2018-07-26 23:20:13 --> Security Class Initialized
DEBUG - 2018-07-26 23:20:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 23:20:13 --> Input Class Initialized
INFO - 2018-07-26 23:20:13 --> Language Class Initialized
ERROR - 2018-07-26 23:20:13 --> 404 Page Not Found: /index
INFO - 2018-07-26 23:20:13 --> Config Class Initialized
INFO - 2018-07-26 23:20:13 --> Hooks Class Initialized
DEBUG - 2018-07-26 23:20:13 --> UTF-8 Support Enabled
INFO - 2018-07-26 23:20:13 --> Utf8 Class Initialized
INFO - 2018-07-26 23:20:13 --> URI Class Initialized
INFO - 2018-07-26 23:20:13 --> Router Class Initialized
INFO - 2018-07-26 23:20:13 --> Output Class Initialized
INFO - 2018-07-26 23:20:13 --> Security Class Initialized
DEBUG - 2018-07-26 23:20:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 23:20:13 --> Input Class Initialized
INFO - 2018-07-26 23:20:13 --> Language Class Initialized
ERROR - 2018-07-26 23:20:13 --> 404 Page Not Found: /index
INFO - 2018-07-26 23:27:29 --> Config Class Initialized
INFO - 2018-07-26 23:27:29 --> Hooks Class Initialized
DEBUG - 2018-07-26 23:27:29 --> UTF-8 Support Enabled
INFO - 2018-07-26 23:27:30 --> Utf8 Class Initialized
INFO - 2018-07-26 23:27:30 --> URI Class Initialized
INFO - 2018-07-26 23:27:30 --> Router Class Initialized
INFO - 2018-07-26 23:27:30 --> Output Class Initialized
INFO - 2018-07-26 23:27:30 --> Security Class Initialized
DEBUG - 2018-07-26 23:27:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 23:27:30 --> Input Class Initialized
INFO - 2018-07-26 23:27:30 --> Language Class Initialized
INFO - 2018-07-26 23:27:30 --> Language Class Initialized
INFO - 2018-07-26 23:27:30 --> Config Class Initialized
INFO - 2018-07-26 23:27:30 --> Loader Class Initialized
DEBUG - 2018-07-26 23:27:30 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-26 23:27:30 --> Helper loaded: url_helper
INFO - 2018-07-26 23:27:30 --> Helper loaded: form_helper
INFO - 2018-07-26 23:27:30 --> Helper loaded: date_helper
INFO - 2018-07-26 23:27:30 --> Helper loaded: util_helper
INFO - 2018-07-26 23:27:30 --> Helper loaded: text_helper
INFO - 2018-07-26 23:27:30 --> Helper loaded: string_helper
INFO - 2018-07-26 23:27:30 --> Database Driver Class Initialized
DEBUG - 2018-07-26 23:27:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 23:27:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 23:27:30 --> Email Class Initialized
INFO - 2018-07-26 23:27:30 --> Controller Class Initialized
DEBUG - 2018-07-26 23:27:30 --> Home MX_Controller Initialized
DEBUG - 2018-07-26 23:27:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-26 23:27:30 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-26 23:27:30 --> Login MX_Controller Initialized
INFO - 2018-07-26 23:27:30 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-26 23:27:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-26 23:27:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-26 23:27:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-26 23:27:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-26 23:27:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-26 23:27:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-26 23:27:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-26 23:27:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-26 23:27:30 --> Final output sent to browser
DEBUG - 2018-07-26 23:27:30 --> Total execution time: 0.5854
INFO - 2018-07-26 23:27:31 --> Config Class Initialized
INFO - 2018-07-26 23:27:31 --> Hooks Class Initialized
DEBUG - 2018-07-26 23:27:31 --> UTF-8 Support Enabled
INFO - 2018-07-26 23:27:31 --> Utf8 Class Initialized
INFO - 2018-07-26 23:27:31 --> URI Class Initialized
INFO - 2018-07-26 23:27:32 --> Router Class Initialized
INFO - 2018-07-26 23:27:32 --> Output Class Initialized
INFO - 2018-07-26 23:27:32 --> Security Class Initialized
DEBUG - 2018-07-26 23:27:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 23:27:32 --> Input Class Initialized
INFO - 2018-07-26 23:27:32 --> Language Class Initialized
ERROR - 2018-07-26 23:27:32 --> 404 Page Not Found: /index
INFO - 2018-07-26 23:27:32 --> Config Class Initialized
INFO - 2018-07-26 23:27:32 --> Hooks Class Initialized
DEBUG - 2018-07-26 23:27:32 --> UTF-8 Support Enabled
INFO - 2018-07-26 23:27:32 --> Utf8 Class Initialized
INFO - 2018-07-26 23:27:32 --> URI Class Initialized
INFO - 2018-07-26 23:27:32 --> Router Class Initialized
INFO - 2018-07-26 23:27:32 --> Output Class Initialized
INFO - 2018-07-26 23:27:32 --> Security Class Initialized
DEBUG - 2018-07-26 23:27:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 23:27:32 --> Input Class Initialized
INFO - 2018-07-26 23:27:32 --> Language Class Initialized
ERROR - 2018-07-26 23:27:32 --> 404 Page Not Found: /index
INFO - 2018-07-26 23:27:32 --> Config Class Initialized
INFO - 2018-07-26 23:27:32 --> Hooks Class Initialized
DEBUG - 2018-07-26 23:27:32 --> UTF-8 Support Enabled
INFO - 2018-07-26 23:27:32 --> Utf8 Class Initialized
INFO - 2018-07-26 23:27:32 --> URI Class Initialized
INFO - 2018-07-26 23:27:32 --> Router Class Initialized
INFO - 2018-07-26 23:27:32 --> Output Class Initialized
INFO - 2018-07-26 23:27:32 --> Security Class Initialized
DEBUG - 2018-07-26 23:27:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 23:27:33 --> Input Class Initialized
INFO - 2018-07-26 23:27:33 --> Language Class Initialized
ERROR - 2018-07-26 23:27:33 --> 404 Page Not Found: /index
INFO - 2018-07-26 23:40:41 --> Config Class Initialized
INFO - 2018-07-26 23:40:41 --> Hooks Class Initialized
DEBUG - 2018-07-26 23:40:41 --> UTF-8 Support Enabled
INFO - 2018-07-26 23:40:41 --> Utf8 Class Initialized
INFO - 2018-07-26 23:40:41 --> URI Class Initialized
INFO - 2018-07-26 23:40:42 --> Router Class Initialized
INFO - 2018-07-26 23:40:42 --> Output Class Initialized
INFO - 2018-07-26 23:40:42 --> Security Class Initialized
DEBUG - 2018-07-26 23:40:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 23:40:42 --> Input Class Initialized
INFO - 2018-07-26 23:40:42 --> Language Class Initialized
INFO - 2018-07-26 23:40:42 --> Language Class Initialized
INFO - 2018-07-26 23:40:42 --> Config Class Initialized
INFO - 2018-07-26 23:40:42 --> Loader Class Initialized
DEBUG - 2018-07-26 23:40:42 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-26 23:40:42 --> Helper loaded: url_helper
INFO - 2018-07-26 23:40:42 --> Helper loaded: form_helper
INFO - 2018-07-26 23:40:42 --> Helper loaded: date_helper
INFO - 2018-07-26 23:40:42 --> Helper loaded: util_helper
INFO - 2018-07-26 23:40:42 --> Helper loaded: text_helper
INFO - 2018-07-26 23:40:42 --> Helper loaded: string_helper
INFO - 2018-07-26 23:40:42 --> Database Driver Class Initialized
DEBUG - 2018-07-26 23:40:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 23:40:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 23:40:42 --> Email Class Initialized
INFO - 2018-07-26 23:40:42 --> Controller Class Initialized
DEBUG - 2018-07-26 23:40:42 --> Home MX_Controller Initialized
DEBUG - 2018-07-26 23:40:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-26 23:40:42 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-26 23:40:42 --> Login MX_Controller Initialized
INFO - 2018-07-26 23:40:42 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-26 23:40:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-26 23:40:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-26 23:40:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-26 23:40:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-26 23:40:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-26 23:40:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-26 23:40:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-26 23:40:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-26 23:40:42 --> Final output sent to browser
DEBUG - 2018-07-26 23:40:42 --> Total execution time: 0.5939
INFO - 2018-07-26 23:40:43 --> Config Class Initialized
INFO - 2018-07-26 23:40:43 --> Hooks Class Initialized
DEBUG - 2018-07-26 23:40:43 --> UTF-8 Support Enabled
INFO - 2018-07-26 23:40:44 --> Utf8 Class Initialized
INFO - 2018-07-26 23:40:44 --> URI Class Initialized
INFO - 2018-07-26 23:40:44 --> Router Class Initialized
INFO - 2018-07-26 23:40:44 --> Output Class Initialized
INFO - 2018-07-26 23:40:44 --> Security Class Initialized
DEBUG - 2018-07-26 23:40:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 23:40:44 --> Input Class Initialized
INFO - 2018-07-26 23:40:44 --> Language Class Initialized
ERROR - 2018-07-26 23:40:44 --> 404 Page Not Found: /index
INFO - 2018-07-26 23:40:44 --> Config Class Initialized
INFO - 2018-07-26 23:40:44 --> Hooks Class Initialized
DEBUG - 2018-07-26 23:40:44 --> UTF-8 Support Enabled
INFO - 2018-07-26 23:40:44 --> Utf8 Class Initialized
INFO - 2018-07-26 23:40:44 --> URI Class Initialized
INFO - 2018-07-26 23:40:44 --> Router Class Initialized
INFO - 2018-07-26 23:40:44 --> Output Class Initialized
INFO - 2018-07-26 23:40:44 --> Security Class Initialized
DEBUG - 2018-07-26 23:40:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 23:40:44 --> Input Class Initialized
INFO - 2018-07-26 23:40:44 --> Language Class Initialized
ERROR - 2018-07-26 23:40:44 --> 404 Page Not Found: /index
INFO - 2018-07-26 23:40:44 --> Config Class Initialized
INFO - 2018-07-26 23:40:44 --> Hooks Class Initialized
DEBUG - 2018-07-26 23:40:44 --> UTF-8 Support Enabled
INFO - 2018-07-26 23:40:44 --> Utf8 Class Initialized
INFO - 2018-07-26 23:40:44 --> URI Class Initialized
INFO - 2018-07-26 23:40:44 --> Router Class Initialized
INFO - 2018-07-26 23:40:44 --> Output Class Initialized
INFO - 2018-07-26 23:40:45 --> Security Class Initialized
DEBUG - 2018-07-26 23:40:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 23:40:45 --> Input Class Initialized
INFO - 2018-07-26 23:40:45 --> Language Class Initialized
ERROR - 2018-07-26 23:40:45 --> 404 Page Not Found: /index
INFO - 2018-07-26 23:42:05 --> Config Class Initialized
INFO - 2018-07-26 23:42:05 --> Hooks Class Initialized
DEBUG - 2018-07-26 23:42:05 --> UTF-8 Support Enabled
INFO - 2018-07-26 23:42:05 --> Utf8 Class Initialized
INFO - 2018-07-26 23:42:05 --> URI Class Initialized
INFO - 2018-07-26 23:42:05 --> Router Class Initialized
INFO - 2018-07-26 23:42:05 --> Output Class Initialized
INFO - 2018-07-26 23:42:05 --> Security Class Initialized
DEBUG - 2018-07-26 23:42:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 23:42:05 --> Input Class Initialized
INFO - 2018-07-26 23:42:05 --> Language Class Initialized
INFO - 2018-07-26 23:42:05 --> Language Class Initialized
INFO - 2018-07-26 23:42:05 --> Config Class Initialized
INFO - 2018-07-26 23:42:05 --> Loader Class Initialized
DEBUG - 2018-07-26 23:42:05 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-26 23:42:05 --> Helper loaded: url_helper
INFO - 2018-07-26 23:42:05 --> Helper loaded: form_helper
INFO - 2018-07-26 23:42:05 --> Helper loaded: date_helper
INFO - 2018-07-26 23:42:05 --> Helper loaded: util_helper
INFO - 2018-07-26 23:42:05 --> Helper loaded: text_helper
INFO - 2018-07-26 23:42:05 --> Helper loaded: string_helper
INFO - 2018-07-26 23:42:05 --> Database Driver Class Initialized
DEBUG - 2018-07-26 23:42:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 23:42:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 23:42:05 --> Email Class Initialized
INFO - 2018-07-26 23:42:05 --> Controller Class Initialized
DEBUG - 2018-07-26 23:42:05 --> Home MX_Controller Initialized
DEBUG - 2018-07-26 23:42:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-26 23:42:05 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-26 23:42:05 --> Login MX_Controller Initialized
INFO - 2018-07-26 23:42:05 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-26 23:42:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-26 23:42:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-26 23:42:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-26 23:42:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-26 23:42:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-26 23:42:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-26 23:42:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-26 23:42:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-26 23:42:05 --> Final output sent to browser
DEBUG - 2018-07-26 23:42:05 --> Total execution time: 0.5793
INFO - 2018-07-26 23:42:06 --> Config Class Initialized
INFO - 2018-07-26 23:42:06 --> Hooks Class Initialized
DEBUG - 2018-07-26 23:42:06 --> UTF-8 Support Enabled
INFO - 2018-07-26 23:42:06 --> Utf8 Class Initialized
INFO - 2018-07-26 23:42:06 --> URI Class Initialized
INFO - 2018-07-26 23:42:06 --> Router Class Initialized
INFO - 2018-07-26 23:42:06 --> Output Class Initialized
INFO - 2018-07-26 23:42:06 --> Security Class Initialized
DEBUG - 2018-07-26 23:42:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 23:42:06 --> Input Class Initialized
INFO - 2018-07-26 23:42:06 --> Language Class Initialized
ERROR - 2018-07-26 23:42:06 --> 404 Page Not Found: /index
INFO - 2018-07-26 23:42:07 --> Config Class Initialized
INFO - 2018-07-26 23:42:07 --> Hooks Class Initialized
DEBUG - 2018-07-26 23:42:07 --> UTF-8 Support Enabled
INFO - 2018-07-26 23:42:07 --> Utf8 Class Initialized
INFO - 2018-07-26 23:42:07 --> URI Class Initialized
INFO - 2018-07-26 23:42:07 --> Router Class Initialized
INFO - 2018-07-26 23:42:07 --> Output Class Initialized
INFO - 2018-07-26 23:42:07 --> Security Class Initialized
DEBUG - 2018-07-26 23:42:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 23:42:07 --> Input Class Initialized
INFO - 2018-07-26 23:42:07 --> Language Class Initialized
ERROR - 2018-07-26 23:42:07 --> 404 Page Not Found: /index
INFO - 2018-07-26 23:42:07 --> Config Class Initialized
INFO - 2018-07-26 23:42:07 --> Hooks Class Initialized
DEBUG - 2018-07-26 23:42:07 --> UTF-8 Support Enabled
INFO - 2018-07-26 23:42:07 --> Utf8 Class Initialized
INFO - 2018-07-26 23:42:07 --> URI Class Initialized
INFO - 2018-07-26 23:42:07 --> Router Class Initialized
INFO - 2018-07-26 23:42:07 --> Output Class Initialized
INFO - 2018-07-26 23:42:07 --> Security Class Initialized
DEBUG - 2018-07-26 23:42:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 23:42:07 --> Input Class Initialized
INFO - 2018-07-26 23:42:07 --> Language Class Initialized
ERROR - 2018-07-26 23:42:07 --> 404 Page Not Found: /index
INFO - 2018-07-26 23:42:26 --> Config Class Initialized
INFO - 2018-07-26 23:42:26 --> Hooks Class Initialized
DEBUG - 2018-07-26 23:42:26 --> UTF-8 Support Enabled
INFO - 2018-07-26 23:42:26 --> Utf8 Class Initialized
INFO - 2018-07-26 23:42:26 --> URI Class Initialized
INFO - 2018-07-26 23:42:26 --> Router Class Initialized
INFO - 2018-07-26 23:42:26 --> Output Class Initialized
INFO - 2018-07-26 23:42:26 --> Security Class Initialized
DEBUG - 2018-07-26 23:42:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 23:42:26 --> Input Class Initialized
INFO - 2018-07-26 23:42:26 --> Language Class Initialized
INFO - 2018-07-26 23:42:26 --> Language Class Initialized
INFO - 2018-07-26 23:42:26 --> Config Class Initialized
INFO - 2018-07-26 23:42:26 --> Loader Class Initialized
DEBUG - 2018-07-26 23:42:26 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-26 23:42:26 --> Helper loaded: url_helper
INFO - 2018-07-26 23:42:26 --> Helper loaded: form_helper
INFO - 2018-07-26 23:42:26 --> Helper loaded: date_helper
INFO - 2018-07-26 23:42:26 --> Helper loaded: util_helper
INFO - 2018-07-26 23:42:26 --> Helper loaded: text_helper
INFO - 2018-07-26 23:42:26 --> Helper loaded: string_helper
INFO - 2018-07-26 23:42:26 --> Database Driver Class Initialized
DEBUG - 2018-07-26 23:42:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-26 23:42:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-26 23:42:26 --> Email Class Initialized
INFO - 2018-07-26 23:42:26 --> Controller Class Initialized
DEBUG - 2018-07-26 23:42:26 --> Home MX_Controller Initialized
DEBUG - 2018-07-26 23:42:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-26 23:42:26 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-26 23:42:26 --> Login MX_Controller Initialized
INFO - 2018-07-26 23:42:26 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-26 23:42:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-26 23:42:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-26 23:42:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-26 23:42:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-26 23:42:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-26 23:42:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-26 23:42:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-26 23:42:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-26 23:42:27 --> Final output sent to browser
DEBUG - 2018-07-26 23:42:27 --> Total execution time: 0.5740
INFO - 2018-07-26 23:42:27 --> Config Class Initialized
INFO - 2018-07-26 23:42:27 --> Hooks Class Initialized
DEBUG - 2018-07-26 23:42:27 --> UTF-8 Support Enabled
INFO - 2018-07-26 23:42:27 --> Utf8 Class Initialized
INFO - 2018-07-26 23:42:27 --> URI Class Initialized
INFO - 2018-07-26 23:42:27 --> Router Class Initialized
INFO - 2018-07-26 23:42:27 --> Output Class Initialized
INFO - 2018-07-26 23:42:28 --> Security Class Initialized
DEBUG - 2018-07-26 23:42:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 23:42:28 --> Input Class Initialized
INFO - 2018-07-26 23:42:28 --> Language Class Initialized
ERROR - 2018-07-26 23:42:28 --> 404 Page Not Found: /index
INFO - 2018-07-26 23:42:28 --> Config Class Initialized
INFO - 2018-07-26 23:42:28 --> Hooks Class Initialized
DEBUG - 2018-07-26 23:42:28 --> UTF-8 Support Enabled
INFO - 2018-07-26 23:42:28 --> Utf8 Class Initialized
INFO - 2018-07-26 23:42:28 --> URI Class Initialized
INFO - 2018-07-26 23:42:28 --> Router Class Initialized
INFO - 2018-07-26 23:42:28 --> Output Class Initialized
INFO - 2018-07-26 23:42:28 --> Security Class Initialized
DEBUG - 2018-07-26 23:42:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 23:42:28 --> Input Class Initialized
INFO - 2018-07-26 23:42:28 --> Language Class Initialized
ERROR - 2018-07-26 23:42:28 --> 404 Page Not Found: /index
INFO - 2018-07-26 23:42:28 --> Config Class Initialized
INFO - 2018-07-26 23:42:28 --> Hooks Class Initialized
DEBUG - 2018-07-26 23:42:28 --> UTF-8 Support Enabled
INFO - 2018-07-26 23:42:28 --> Utf8 Class Initialized
INFO - 2018-07-26 23:42:28 --> URI Class Initialized
INFO - 2018-07-26 23:42:28 --> Router Class Initialized
INFO - 2018-07-26 23:42:28 --> Output Class Initialized
INFO - 2018-07-26 23:42:28 --> Security Class Initialized
DEBUG - 2018-07-26 23:42:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-26 23:42:28 --> Input Class Initialized
INFO - 2018-07-26 23:42:29 --> Language Class Initialized
ERROR - 2018-07-26 23:42:29 --> 404 Page Not Found: /index
