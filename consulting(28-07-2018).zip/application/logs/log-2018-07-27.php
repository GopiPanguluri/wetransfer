<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-07-27 00:34:54 --> Config Class Initialized
INFO - 2018-07-27 00:34:54 --> Hooks Class Initialized
DEBUG - 2018-07-27 00:34:54 --> UTF-8 Support Enabled
INFO - 2018-07-27 00:34:54 --> Utf8 Class Initialized
INFO - 2018-07-27 00:34:54 --> URI Class Initialized
INFO - 2018-07-27 00:34:54 --> Router Class Initialized
INFO - 2018-07-27 00:34:54 --> Output Class Initialized
INFO - 2018-07-27 00:34:54 --> Security Class Initialized
DEBUG - 2018-07-27 00:34:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 00:34:54 --> Input Class Initialized
INFO - 2018-07-27 00:34:54 --> Language Class Initialized
INFO - 2018-07-27 00:34:54 --> Language Class Initialized
INFO - 2018-07-27 00:34:54 --> Config Class Initialized
INFO - 2018-07-27 00:34:54 --> Loader Class Initialized
DEBUG - 2018-07-27 00:34:54 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-27 00:34:54 --> Helper loaded: url_helper
INFO - 2018-07-27 00:34:54 --> Helper loaded: form_helper
INFO - 2018-07-27 00:34:54 --> Helper loaded: date_helper
INFO - 2018-07-27 00:34:54 --> Helper loaded: util_helper
INFO - 2018-07-27 00:34:54 --> Helper loaded: text_helper
INFO - 2018-07-27 00:34:54 --> Helper loaded: string_helper
INFO - 2018-07-27 00:34:54 --> Database Driver Class Initialized
DEBUG - 2018-07-27 00:34:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 00:34:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 00:34:54 --> Email Class Initialized
INFO - 2018-07-27 00:34:54 --> Controller Class Initialized
DEBUG - 2018-07-27 00:34:54 --> Home MX_Controller Initialized
DEBUG - 2018-07-27 00:34:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-27 00:34:54 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-27 00:34:54 --> Login MX_Controller Initialized
INFO - 2018-07-27 00:34:54 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-27 00:34:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-27 00:34:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-27 00:34:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-27 00:34:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-27 00:34:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-27 00:34:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-27 00:34:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-27 00:34:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-27 00:34:54 --> Final output sent to browser
DEBUG - 2018-07-27 00:34:54 --> Total execution time: 0.4386
INFO - 2018-07-27 00:34:55 --> Config Class Initialized
INFO - 2018-07-27 00:34:55 --> Hooks Class Initialized
DEBUG - 2018-07-27 00:34:55 --> UTF-8 Support Enabled
INFO - 2018-07-27 00:34:55 --> Utf8 Class Initialized
INFO - 2018-07-27 00:34:55 --> URI Class Initialized
INFO - 2018-07-27 00:34:55 --> Router Class Initialized
INFO - 2018-07-27 00:34:55 --> Output Class Initialized
INFO - 2018-07-27 00:34:55 --> Security Class Initialized
DEBUG - 2018-07-27 00:34:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 00:34:55 --> Input Class Initialized
INFO - 2018-07-27 00:34:55 --> Language Class Initialized
ERROR - 2018-07-27 00:34:55 --> 404 Page Not Found: /index
INFO - 2018-07-27 00:34:55 --> Config Class Initialized
INFO - 2018-07-27 00:34:55 --> Hooks Class Initialized
DEBUG - 2018-07-27 00:34:55 --> UTF-8 Support Enabled
INFO - 2018-07-27 00:34:55 --> Config Class Initialized
INFO - 2018-07-27 00:34:55 --> Hooks Class Initialized
INFO - 2018-07-27 00:34:55 --> Utf8 Class Initialized
DEBUG - 2018-07-27 00:34:56 --> UTF-8 Support Enabled
INFO - 2018-07-27 00:34:56 --> Utf8 Class Initialized
INFO - 2018-07-27 00:34:56 --> URI Class Initialized
INFO - 2018-07-27 00:34:56 --> URI Class Initialized
INFO - 2018-07-27 00:34:56 --> Router Class Initialized
INFO - 2018-07-27 00:34:56 --> Output Class Initialized
INFO - 2018-07-27 00:34:56 --> Router Class Initialized
INFO - 2018-07-27 00:34:56 --> Output Class Initialized
INFO - 2018-07-27 00:34:56 --> Security Class Initialized
DEBUG - 2018-07-27 00:34:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 00:34:56 --> Security Class Initialized
INFO - 2018-07-27 00:34:56 --> Input Class Initialized
DEBUG - 2018-07-27 00:34:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 00:34:56 --> Language Class Initialized
INFO - 2018-07-27 00:34:56 --> Input Class Initialized
INFO - 2018-07-27 00:34:56 --> Language Class Initialized
ERROR - 2018-07-27 00:34:56 --> 404 Page Not Found: /index
ERROR - 2018-07-27 00:34:56 --> 404 Page Not Found: /index
INFO - 2018-07-27 00:34:56 --> Config Class Initialized
INFO - 2018-07-27 00:34:56 --> Hooks Class Initialized
DEBUG - 2018-07-27 00:34:56 --> UTF-8 Support Enabled
INFO - 2018-07-27 00:34:56 --> Utf8 Class Initialized
INFO - 2018-07-27 00:34:56 --> URI Class Initialized
INFO - 2018-07-27 00:34:56 --> Router Class Initialized
INFO - 2018-07-27 00:34:56 --> Output Class Initialized
INFO - 2018-07-27 00:34:56 --> Security Class Initialized
DEBUG - 2018-07-27 00:34:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 00:34:56 --> Input Class Initialized
INFO - 2018-07-27 00:34:56 --> Language Class Initialized
ERROR - 2018-07-27 00:34:56 --> 404 Page Not Found: /index
INFO - 2018-07-27 01:40:57 --> Config Class Initialized
INFO - 2018-07-27 01:40:57 --> Hooks Class Initialized
DEBUG - 2018-07-27 01:40:57 --> UTF-8 Support Enabled
INFO - 2018-07-27 01:40:57 --> Utf8 Class Initialized
INFO - 2018-07-27 01:40:57 --> URI Class Initialized
INFO - 2018-07-27 01:40:57 --> Router Class Initialized
INFO - 2018-07-27 01:40:57 --> Output Class Initialized
INFO - 2018-07-27 01:40:57 --> Security Class Initialized
DEBUG - 2018-07-27 01:40:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 01:40:57 --> Input Class Initialized
INFO - 2018-07-27 01:40:57 --> Language Class Initialized
INFO - 2018-07-27 01:40:58 --> Language Class Initialized
INFO - 2018-07-27 01:40:58 --> Config Class Initialized
INFO - 2018-07-27 01:40:58 --> Loader Class Initialized
DEBUG - 2018-07-27 01:40:58 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-27 01:40:58 --> Helper loaded: url_helper
INFO - 2018-07-27 01:40:58 --> Helper loaded: form_helper
INFO - 2018-07-27 01:40:58 --> Helper loaded: date_helper
INFO - 2018-07-27 01:40:58 --> Helper loaded: util_helper
INFO - 2018-07-27 01:40:58 --> Helper loaded: text_helper
INFO - 2018-07-27 01:40:58 --> Helper loaded: string_helper
INFO - 2018-07-27 01:40:58 --> Database Driver Class Initialized
DEBUG - 2018-07-27 01:40:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 01:40:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 01:40:58 --> Email Class Initialized
INFO - 2018-07-27 01:40:58 --> Controller Class Initialized
DEBUG - 2018-07-27 01:40:58 --> Profile MX_Controller Initialized
DEBUG - 2018-07-27 01:40:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-27 01:40:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-27 01:40:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-07-27 01:40:58 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-27 01:40:58 --> Login MX_Controller Initialized
INFO - 2018-07-27 01:40:58 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-27 01:40:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-27 01:40:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-27 01:40:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-27 01:40:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-27 01:40:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-07-27 01:40:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-27 01:40:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-27 01:40:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/profile.php
INFO - 2018-07-27 01:40:58 --> Final output sent to browser
DEBUG - 2018-07-27 01:40:58 --> Total execution time: 0.3825
INFO - 2018-07-27 01:40:58 --> Config Class Initialized
INFO - 2018-07-27 01:40:58 --> Hooks Class Initialized
DEBUG - 2018-07-27 01:40:58 --> UTF-8 Support Enabled
INFO - 2018-07-27 01:40:58 --> Utf8 Class Initialized
INFO - 2018-07-27 01:40:58 --> URI Class Initialized
INFO - 2018-07-27 01:40:58 --> Router Class Initialized
INFO - 2018-07-27 01:40:59 --> Output Class Initialized
INFO - 2018-07-27 01:40:59 --> Security Class Initialized
DEBUG - 2018-07-27 01:40:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 01:40:59 --> Input Class Initialized
INFO - 2018-07-27 01:40:59 --> Language Class Initialized
ERROR - 2018-07-27 01:40:59 --> 404 Page Not Found: /index
INFO - 2018-07-27 01:40:59 --> Config Class Initialized
INFO - 2018-07-27 01:40:59 --> Hooks Class Initialized
DEBUG - 2018-07-27 01:40:59 --> UTF-8 Support Enabled
INFO - 2018-07-27 01:40:59 --> Utf8 Class Initialized
INFO - 2018-07-27 01:40:59 --> URI Class Initialized
INFO - 2018-07-27 01:40:59 --> Router Class Initialized
INFO - 2018-07-27 01:40:59 --> Output Class Initialized
INFO - 2018-07-27 01:40:59 --> Security Class Initialized
DEBUG - 2018-07-27 01:40:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 01:40:59 --> Input Class Initialized
INFO - 2018-07-27 01:40:59 --> Language Class Initialized
ERROR - 2018-07-27 01:40:59 --> 404 Page Not Found: /index
INFO - 2018-07-27 01:40:59 --> Config Class Initialized
INFO - 2018-07-27 01:40:59 --> Hooks Class Initialized
DEBUG - 2018-07-27 01:40:59 --> UTF-8 Support Enabled
INFO - 2018-07-27 01:40:59 --> Utf8 Class Initialized
INFO - 2018-07-27 01:40:59 --> URI Class Initialized
INFO - 2018-07-27 01:40:59 --> Router Class Initialized
INFO - 2018-07-27 01:40:59 --> Output Class Initialized
INFO - 2018-07-27 01:40:59 --> Security Class Initialized
DEBUG - 2018-07-27 01:40:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 01:40:59 --> Input Class Initialized
INFO - 2018-07-27 01:40:59 --> Language Class Initialized
ERROR - 2018-07-27 01:40:59 --> 404 Page Not Found: /index
INFO - 2018-07-27 01:41:07 --> Config Class Initialized
INFO - 2018-07-27 01:41:07 --> Hooks Class Initialized
DEBUG - 2018-07-27 01:41:07 --> UTF-8 Support Enabled
INFO - 2018-07-27 01:41:07 --> Utf8 Class Initialized
INFO - 2018-07-27 01:41:07 --> URI Class Initialized
INFO - 2018-07-27 01:41:07 --> Router Class Initialized
INFO - 2018-07-27 01:41:07 --> Output Class Initialized
INFO - 2018-07-27 01:41:07 --> Security Class Initialized
DEBUG - 2018-07-27 01:41:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 01:41:07 --> Input Class Initialized
INFO - 2018-07-27 01:41:07 --> Language Class Initialized
INFO - 2018-07-27 01:41:07 --> Language Class Initialized
INFO - 2018-07-27 01:41:07 --> Config Class Initialized
INFO - 2018-07-27 01:41:07 --> Loader Class Initialized
DEBUG - 2018-07-27 01:41:07 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-27 01:41:07 --> Helper loaded: url_helper
INFO - 2018-07-27 01:41:07 --> Helper loaded: form_helper
INFO - 2018-07-27 01:41:07 --> Helper loaded: date_helper
INFO - 2018-07-27 01:41:07 --> Helper loaded: util_helper
INFO - 2018-07-27 01:41:07 --> Helper loaded: text_helper
INFO - 2018-07-27 01:41:07 --> Helper loaded: string_helper
INFO - 2018-07-27 01:41:07 --> Database Driver Class Initialized
DEBUG - 2018-07-27 01:41:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 01:41:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 01:41:07 --> Email Class Initialized
INFO - 2018-07-27 01:41:07 --> Controller Class Initialized
DEBUG - 2018-07-27 01:41:07 --> Profile MX_Controller Initialized
DEBUG - 2018-07-27 01:41:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-27 01:41:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-27 01:41:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-07-27 01:41:07 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-27 01:41:07 --> Login MX_Controller Initialized
INFO - 2018-07-27 01:41:07 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-27 01:41:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-27 01:41:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-27 01:41:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-27 01:41:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-27 01:41:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-07-27 01:41:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-27 01:41:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-27 01:41:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/profile.php
INFO - 2018-07-27 01:41:07 --> Final output sent to browser
DEBUG - 2018-07-27 01:41:07 --> Total execution time: 0.3870
INFO - 2018-07-27 01:41:08 --> Config Class Initialized
INFO - 2018-07-27 01:41:08 --> Hooks Class Initialized
DEBUG - 2018-07-27 01:41:08 --> UTF-8 Support Enabled
INFO - 2018-07-27 01:41:08 --> Utf8 Class Initialized
INFO - 2018-07-27 01:41:08 --> URI Class Initialized
INFO - 2018-07-27 01:41:08 --> Router Class Initialized
INFO - 2018-07-27 01:41:08 --> Output Class Initialized
INFO - 2018-07-27 01:41:08 --> Security Class Initialized
DEBUG - 2018-07-27 01:41:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 01:41:08 --> Input Class Initialized
INFO - 2018-07-27 01:41:08 --> Language Class Initialized
ERROR - 2018-07-27 01:41:08 --> 404 Page Not Found: /index
INFO - 2018-07-27 01:41:08 --> Config Class Initialized
INFO - 2018-07-27 01:41:08 --> Hooks Class Initialized
DEBUG - 2018-07-27 01:41:08 --> UTF-8 Support Enabled
INFO - 2018-07-27 01:41:08 --> Utf8 Class Initialized
INFO - 2018-07-27 01:41:08 --> URI Class Initialized
INFO - 2018-07-27 01:41:08 --> Router Class Initialized
INFO - 2018-07-27 01:41:08 --> Output Class Initialized
INFO - 2018-07-27 01:41:08 --> Security Class Initialized
DEBUG - 2018-07-27 01:41:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 01:41:08 --> Input Class Initialized
INFO - 2018-07-27 01:41:08 --> Language Class Initialized
ERROR - 2018-07-27 01:41:08 --> 404 Page Not Found: /index
INFO - 2018-07-27 01:41:08 --> Config Class Initialized
INFO - 2018-07-27 01:41:08 --> Config Class Initialized
INFO - 2018-07-27 01:41:08 --> Hooks Class Initialized
INFO - 2018-07-27 01:41:08 --> Hooks Class Initialized
DEBUG - 2018-07-27 01:41:08 --> UTF-8 Support Enabled
INFO - 2018-07-27 01:41:08 --> Utf8 Class Initialized
INFO - 2018-07-27 01:41:08 --> URI Class Initialized
INFO - 2018-07-27 01:41:08 --> Router Class Initialized
DEBUG - 2018-07-27 01:41:08 --> UTF-8 Support Enabled
INFO - 2018-07-27 01:41:09 --> Output Class Initialized
INFO - 2018-07-27 01:41:09 --> Security Class Initialized
DEBUG - 2018-07-27 01:41:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 01:41:09 --> Utf8 Class Initialized
INFO - 2018-07-27 01:41:09 --> Input Class Initialized
INFO - 2018-07-27 01:41:09 --> URI Class Initialized
INFO - 2018-07-27 01:41:09 --> Language Class Initialized
INFO - 2018-07-27 01:41:09 --> Router Class Initialized
INFO - 2018-07-27 01:41:09 --> Output Class Initialized
ERROR - 2018-07-27 01:41:09 --> 404 Page Not Found: /index
INFO - 2018-07-27 01:41:09 --> Security Class Initialized
DEBUG - 2018-07-27 01:41:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 01:41:09 --> Input Class Initialized
INFO - 2018-07-27 01:41:09 --> Language Class Initialized
ERROR - 2018-07-27 01:41:09 --> 404 Page Not Found: /index
INFO - 2018-07-27 01:41:22 --> Config Class Initialized
INFO - 2018-07-27 01:41:22 --> Hooks Class Initialized
DEBUG - 2018-07-27 01:41:22 --> UTF-8 Support Enabled
INFO - 2018-07-27 01:41:22 --> Utf8 Class Initialized
INFO - 2018-07-27 01:41:22 --> URI Class Initialized
INFO - 2018-07-27 01:41:22 --> Router Class Initialized
INFO - 2018-07-27 01:41:22 --> Output Class Initialized
INFO - 2018-07-27 01:41:22 --> Security Class Initialized
DEBUG - 2018-07-27 01:41:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 01:41:22 --> Input Class Initialized
INFO - 2018-07-27 01:41:22 --> Language Class Initialized
INFO - 2018-07-27 01:41:22 --> Language Class Initialized
INFO - 2018-07-27 01:41:22 --> Config Class Initialized
INFO - 2018-07-27 01:41:22 --> Loader Class Initialized
DEBUG - 2018-07-27 01:41:22 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-27 01:41:22 --> Helper loaded: url_helper
INFO - 2018-07-27 01:41:22 --> Helper loaded: form_helper
INFO - 2018-07-27 01:41:22 --> Helper loaded: date_helper
INFO - 2018-07-27 01:41:22 --> Helper loaded: util_helper
INFO - 2018-07-27 01:41:22 --> Helper loaded: text_helper
INFO - 2018-07-27 01:41:22 --> Helper loaded: string_helper
INFO - 2018-07-27 01:41:22 --> Database Driver Class Initialized
DEBUG - 2018-07-27 01:41:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 01:41:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 01:41:22 --> Email Class Initialized
INFO - 2018-07-27 01:41:22 --> Controller Class Initialized
DEBUG - 2018-07-27 01:41:22 --> Profile MX_Controller Initialized
DEBUG - 2018-07-27 01:41:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-27 01:41:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-27 01:41:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-07-27 01:41:22 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-27 01:41:22 --> Login MX_Controller Initialized
INFO - 2018-07-27 01:41:22 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-27 01:41:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-27 01:41:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-27 01:41:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-27 01:41:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-27 01:41:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-07-27 01:41:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-27 01:41:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-27 01:41:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/profile.php
INFO - 2018-07-27 01:41:22 --> Final output sent to browser
DEBUG - 2018-07-27 01:41:22 --> Total execution time: 0.3910
INFO - 2018-07-27 01:41:22 --> Config Class Initialized
INFO - 2018-07-27 01:41:22 --> Hooks Class Initialized
DEBUG - 2018-07-27 01:41:22 --> UTF-8 Support Enabled
INFO - 2018-07-27 01:41:22 --> Utf8 Class Initialized
INFO - 2018-07-27 01:41:22 --> URI Class Initialized
INFO - 2018-07-27 01:41:22 --> Router Class Initialized
INFO - 2018-07-27 01:41:22 --> Output Class Initialized
INFO - 2018-07-27 01:41:22 --> Security Class Initialized
DEBUG - 2018-07-27 01:41:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 01:41:23 --> Input Class Initialized
INFO - 2018-07-27 01:41:23 --> Language Class Initialized
ERROR - 2018-07-27 01:41:23 --> 404 Page Not Found: /index
INFO - 2018-07-27 01:41:23 --> Config Class Initialized
INFO - 2018-07-27 01:41:23 --> Hooks Class Initialized
DEBUG - 2018-07-27 01:41:23 --> UTF-8 Support Enabled
INFO - 2018-07-27 01:41:23 --> Utf8 Class Initialized
INFO - 2018-07-27 01:41:23 --> URI Class Initialized
INFO - 2018-07-27 01:41:23 --> Router Class Initialized
INFO - 2018-07-27 01:41:23 --> Output Class Initialized
INFO - 2018-07-27 01:41:23 --> Security Class Initialized
INFO - 2018-07-27 01:41:23 --> Config Class Initialized
INFO - 2018-07-27 01:41:23 --> Hooks Class Initialized
DEBUG - 2018-07-27 01:41:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 01:41:23 --> Input Class Initialized
DEBUG - 2018-07-27 01:41:23 --> UTF-8 Support Enabled
INFO - 2018-07-27 01:41:23 --> Utf8 Class Initialized
INFO - 2018-07-27 01:41:23 --> Language Class Initialized
INFO - 2018-07-27 01:41:23 --> URI Class Initialized
ERROR - 2018-07-27 01:41:23 --> 404 Page Not Found: /index
INFO - 2018-07-27 01:41:23 --> Router Class Initialized
INFO - 2018-07-27 01:41:23 --> Output Class Initialized
INFO - 2018-07-27 01:41:23 --> Config Class Initialized
INFO - 2018-07-27 01:41:23 --> Hooks Class Initialized
INFO - 2018-07-27 01:41:23 --> Security Class Initialized
DEBUG - 2018-07-27 01:41:23 --> UTF-8 Support Enabled
INFO - 2018-07-27 01:41:23 --> Utf8 Class Initialized
INFO - 2018-07-27 01:41:23 --> URI Class Initialized
DEBUG - 2018-07-27 01:41:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 01:41:23 --> Router Class Initialized
INFO - 2018-07-27 01:41:23 --> Input Class Initialized
INFO - 2018-07-27 01:41:23 --> Output Class Initialized
INFO - 2018-07-27 01:41:23 --> Security Class Initialized
INFO - 2018-07-27 01:41:23 --> Language Class Initialized
DEBUG - 2018-07-27 01:41:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-07-27 01:41:23 --> 404 Page Not Found: /index
INFO - 2018-07-27 01:41:23 --> Input Class Initialized
INFO - 2018-07-27 01:41:23 --> Language Class Initialized
ERROR - 2018-07-27 01:41:23 --> 404 Page Not Found: /index
INFO - 2018-07-27 01:43:00 --> Config Class Initialized
INFO - 2018-07-27 01:43:00 --> Hooks Class Initialized
DEBUG - 2018-07-27 01:43:00 --> UTF-8 Support Enabled
INFO - 2018-07-27 01:43:00 --> Utf8 Class Initialized
INFO - 2018-07-27 01:43:00 --> URI Class Initialized
INFO - 2018-07-27 01:43:00 --> Router Class Initialized
INFO - 2018-07-27 01:43:01 --> Output Class Initialized
INFO - 2018-07-27 01:43:01 --> Security Class Initialized
DEBUG - 2018-07-27 01:43:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 01:43:01 --> Input Class Initialized
INFO - 2018-07-27 01:43:01 --> Language Class Initialized
INFO - 2018-07-27 01:43:01 --> Language Class Initialized
INFO - 2018-07-27 01:43:01 --> Config Class Initialized
INFO - 2018-07-27 01:43:01 --> Loader Class Initialized
DEBUG - 2018-07-27 01:43:01 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-27 01:43:01 --> Helper loaded: url_helper
INFO - 2018-07-27 01:43:01 --> Helper loaded: form_helper
INFO - 2018-07-27 01:43:01 --> Helper loaded: date_helper
INFO - 2018-07-27 01:43:01 --> Helper loaded: util_helper
INFO - 2018-07-27 01:43:01 --> Helper loaded: text_helper
INFO - 2018-07-27 01:43:01 --> Helper loaded: string_helper
INFO - 2018-07-27 01:43:01 --> Database Driver Class Initialized
DEBUG - 2018-07-27 01:43:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 01:43:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 01:43:01 --> Email Class Initialized
INFO - 2018-07-27 01:43:01 --> Controller Class Initialized
DEBUG - 2018-07-27 01:43:01 --> Profile MX_Controller Initialized
DEBUG - 2018-07-27 01:43:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-27 01:43:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-27 01:43:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-07-27 01:43:01 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-27 01:43:01 --> Login MX_Controller Initialized
INFO - 2018-07-27 01:43:01 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-27 01:43:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-27 01:43:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-27 01:43:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-27 01:43:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-27 01:43:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-07-27 01:43:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-27 01:43:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-27 01:43:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/profile.php
INFO - 2018-07-27 01:43:01 --> Final output sent to browser
DEBUG - 2018-07-27 01:43:01 --> Total execution time: 0.4616
INFO - 2018-07-27 01:43:01 --> Config Class Initialized
INFO - 2018-07-27 01:43:01 --> Hooks Class Initialized
DEBUG - 2018-07-27 01:43:01 --> UTF-8 Support Enabled
INFO - 2018-07-27 01:43:01 --> Utf8 Class Initialized
INFO - 2018-07-27 01:43:01 --> URI Class Initialized
INFO - 2018-07-27 01:43:01 --> Router Class Initialized
INFO - 2018-07-27 01:43:01 --> Output Class Initialized
INFO - 2018-07-27 01:43:01 --> Security Class Initialized
DEBUG - 2018-07-27 01:43:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 01:43:01 --> Input Class Initialized
INFO - 2018-07-27 01:43:01 --> Language Class Initialized
ERROR - 2018-07-27 01:43:01 --> 404 Page Not Found: /index
INFO - 2018-07-27 01:43:02 --> Config Class Initialized
INFO - 2018-07-27 01:43:02 --> Hooks Class Initialized
DEBUG - 2018-07-27 01:43:02 --> UTF-8 Support Enabled
INFO - 2018-07-27 01:43:02 --> Utf8 Class Initialized
INFO - 2018-07-27 01:43:02 --> URI Class Initialized
INFO - 2018-07-27 01:43:02 --> Router Class Initialized
INFO - 2018-07-27 01:43:02 --> Output Class Initialized
INFO - 2018-07-27 01:43:02 --> Security Class Initialized
DEBUG - 2018-07-27 01:43:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 01:43:02 --> Input Class Initialized
INFO - 2018-07-27 01:43:02 --> Language Class Initialized
ERROR - 2018-07-27 01:43:02 --> 404 Page Not Found: /index
INFO - 2018-07-27 01:43:02 --> Config Class Initialized
INFO - 2018-07-27 01:43:02 --> Hooks Class Initialized
DEBUG - 2018-07-27 01:43:02 --> UTF-8 Support Enabled
INFO - 2018-07-27 01:43:02 --> Utf8 Class Initialized
INFO - 2018-07-27 01:43:02 --> URI Class Initialized
INFO - 2018-07-27 01:43:02 --> Router Class Initialized
INFO - 2018-07-27 01:43:02 --> Output Class Initialized
INFO - 2018-07-27 01:43:02 --> Security Class Initialized
DEBUG - 2018-07-27 01:43:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 01:43:02 --> Input Class Initialized
INFO - 2018-07-27 01:43:02 --> Language Class Initialized
ERROR - 2018-07-27 01:43:02 --> 404 Page Not Found: /index
INFO - 2018-07-27 01:43:44 --> Config Class Initialized
INFO - 2018-07-27 01:43:44 --> Hooks Class Initialized
DEBUG - 2018-07-27 01:43:44 --> UTF-8 Support Enabled
INFO - 2018-07-27 01:43:44 --> Utf8 Class Initialized
INFO - 2018-07-27 01:43:44 --> URI Class Initialized
INFO - 2018-07-27 01:43:44 --> Router Class Initialized
INFO - 2018-07-27 01:43:44 --> Output Class Initialized
INFO - 2018-07-27 01:43:44 --> Security Class Initialized
DEBUG - 2018-07-27 01:43:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 01:43:44 --> Input Class Initialized
INFO - 2018-07-27 01:43:44 --> Language Class Initialized
INFO - 2018-07-27 01:43:44 --> Language Class Initialized
INFO - 2018-07-27 01:43:44 --> Config Class Initialized
INFO - 2018-07-27 01:43:44 --> Loader Class Initialized
DEBUG - 2018-07-27 01:43:44 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-27 01:43:44 --> Helper loaded: url_helper
INFO - 2018-07-27 01:43:44 --> Helper loaded: form_helper
INFO - 2018-07-27 01:43:44 --> Helper loaded: date_helper
INFO - 2018-07-27 01:43:44 --> Helper loaded: util_helper
INFO - 2018-07-27 01:43:44 --> Helper loaded: text_helper
INFO - 2018-07-27 01:43:44 --> Helper loaded: string_helper
INFO - 2018-07-27 01:43:44 --> Database Driver Class Initialized
DEBUG - 2018-07-27 01:43:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 01:43:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 01:43:44 --> Email Class Initialized
INFO - 2018-07-27 01:43:44 --> Controller Class Initialized
DEBUG - 2018-07-27 01:43:44 --> Profile MX_Controller Initialized
DEBUG - 2018-07-27 01:43:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-27 01:43:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-27 01:43:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-07-27 01:43:44 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-27 01:43:44 --> Login MX_Controller Initialized
INFO - 2018-07-27 01:43:44 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-27 01:43:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-27 01:43:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-27 01:43:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-27 01:43:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-27 01:43:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-07-27 01:43:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-27 01:43:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-27 01:43:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/profile.php
INFO - 2018-07-27 01:43:44 --> Final output sent to browser
DEBUG - 2018-07-27 01:43:44 --> Total execution time: 0.4063
INFO - 2018-07-27 01:43:45 --> Config Class Initialized
INFO - 2018-07-27 01:43:45 --> Hooks Class Initialized
DEBUG - 2018-07-27 01:43:45 --> UTF-8 Support Enabled
INFO - 2018-07-27 01:43:45 --> Utf8 Class Initialized
INFO - 2018-07-27 01:43:45 --> URI Class Initialized
INFO - 2018-07-27 01:43:45 --> Router Class Initialized
INFO - 2018-07-27 01:43:45 --> Output Class Initialized
INFO - 2018-07-27 01:43:45 --> Security Class Initialized
DEBUG - 2018-07-27 01:43:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 01:43:45 --> Input Class Initialized
INFO - 2018-07-27 01:43:45 --> Language Class Initialized
ERROR - 2018-07-27 01:43:45 --> 404 Page Not Found: /index
INFO - 2018-07-27 01:43:45 --> Config Class Initialized
INFO - 2018-07-27 01:43:45 --> Hooks Class Initialized
DEBUG - 2018-07-27 01:43:45 --> UTF-8 Support Enabled
INFO - 2018-07-27 01:43:45 --> Config Class Initialized
INFO - 2018-07-27 01:43:45 --> Hooks Class Initialized
INFO - 2018-07-27 01:43:45 --> Utf8 Class Initialized
DEBUG - 2018-07-27 01:43:45 --> UTF-8 Support Enabled
INFO - 2018-07-27 01:43:45 --> URI Class Initialized
INFO - 2018-07-27 01:43:45 --> Utf8 Class Initialized
INFO - 2018-07-27 01:43:45 --> Router Class Initialized
INFO - 2018-07-27 01:43:45 --> Output Class Initialized
INFO - 2018-07-27 01:43:45 --> Security Class Initialized
DEBUG - 2018-07-27 01:43:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 01:43:45 --> Input Class Initialized
INFO - 2018-07-27 01:43:45 --> Language Class Initialized
INFO - 2018-07-27 01:43:45 --> URI Class Initialized
ERROR - 2018-07-27 01:43:45 --> 404 Page Not Found: /index
INFO - 2018-07-27 01:43:45 --> Router Class Initialized
INFO - 2018-07-27 01:43:45 --> Output Class Initialized
INFO - 2018-07-27 01:43:45 --> Security Class Initialized
DEBUG - 2018-07-27 01:43:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 01:43:46 --> Input Class Initialized
INFO - 2018-07-27 01:43:46 --> Language Class Initialized
INFO - 2018-07-27 01:43:46 --> Config Class Initialized
INFO - 2018-07-27 01:43:46 --> Hooks Class Initialized
ERROR - 2018-07-27 01:43:46 --> 404 Page Not Found: /index
DEBUG - 2018-07-27 01:43:46 --> UTF-8 Support Enabled
INFO - 2018-07-27 01:43:46 --> Utf8 Class Initialized
INFO - 2018-07-27 01:43:46 --> URI Class Initialized
INFO - 2018-07-27 01:43:46 --> Router Class Initialized
INFO - 2018-07-27 01:43:46 --> Output Class Initialized
INFO - 2018-07-27 01:43:46 --> Security Class Initialized
DEBUG - 2018-07-27 01:43:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 01:43:46 --> Input Class Initialized
INFO - 2018-07-27 01:43:46 --> Language Class Initialized
ERROR - 2018-07-27 01:43:46 --> 404 Page Not Found: /index
INFO - 2018-07-27 01:45:15 --> Config Class Initialized
INFO - 2018-07-27 01:45:15 --> Hooks Class Initialized
DEBUG - 2018-07-27 01:45:15 --> UTF-8 Support Enabled
INFO - 2018-07-27 01:45:15 --> Utf8 Class Initialized
INFO - 2018-07-27 01:45:15 --> URI Class Initialized
INFO - 2018-07-27 01:45:15 --> Router Class Initialized
INFO - 2018-07-27 01:45:15 --> Output Class Initialized
INFO - 2018-07-27 01:45:15 --> Security Class Initialized
DEBUG - 2018-07-27 01:45:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 01:45:15 --> Input Class Initialized
INFO - 2018-07-27 01:45:15 --> Language Class Initialized
INFO - 2018-07-27 01:45:15 --> Language Class Initialized
INFO - 2018-07-27 01:45:15 --> Config Class Initialized
INFO - 2018-07-27 01:45:15 --> Loader Class Initialized
DEBUG - 2018-07-27 01:45:15 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-27 01:45:15 --> Helper loaded: url_helper
INFO - 2018-07-27 01:45:15 --> Helper loaded: form_helper
INFO - 2018-07-27 01:45:15 --> Helper loaded: date_helper
INFO - 2018-07-27 01:45:15 --> Helper loaded: util_helper
INFO - 2018-07-27 01:45:15 --> Helper loaded: text_helper
INFO - 2018-07-27 01:45:15 --> Helper loaded: string_helper
INFO - 2018-07-27 01:45:15 --> Database Driver Class Initialized
DEBUG - 2018-07-27 01:45:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 01:45:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 01:45:15 --> Email Class Initialized
INFO - 2018-07-27 01:45:15 --> Controller Class Initialized
DEBUG - 2018-07-27 01:45:15 --> Profile MX_Controller Initialized
DEBUG - 2018-07-27 01:45:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-27 01:45:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-27 01:45:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-07-27 01:45:15 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-27 01:45:15 --> Login MX_Controller Initialized
INFO - 2018-07-27 01:45:15 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-27 01:45:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-27 01:45:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-27 01:45:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-27 01:45:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-27 01:45:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-07-27 01:45:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-27 01:45:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-27 01:45:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/reset_password.php
INFO - 2018-07-27 01:45:15 --> Final output sent to browser
DEBUG - 2018-07-27 01:45:15 --> Total execution time: 0.4078
INFO - 2018-07-27 01:45:15 --> Config Class Initialized
INFO - 2018-07-27 01:45:16 --> Hooks Class Initialized
DEBUG - 2018-07-27 01:45:16 --> UTF-8 Support Enabled
INFO - 2018-07-27 01:45:16 --> Utf8 Class Initialized
INFO - 2018-07-27 01:45:16 --> URI Class Initialized
INFO - 2018-07-27 01:45:16 --> Router Class Initialized
INFO - 2018-07-27 01:45:16 --> Output Class Initialized
INFO - 2018-07-27 01:45:16 --> Security Class Initialized
DEBUG - 2018-07-27 01:45:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 01:45:16 --> Input Class Initialized
INFO - 2018-07-27 01:45:16 --> Language Class Initialized
ERROR - 2018-07-27 01:45:16 --> 404 Page Not Found: /index
INFO - 2018-07-27 01:45:16 --> Config Class Initialized
INFO - 2018-07-27 01:45:16 --> Config Class Initialized
INFO - 2018-07-27 01:45:16 --> Hooks Class Initialized
INFO - 2018-07-27 01:45:16 --> Hooks Class Initialized
DEBUG - 2018-07-27 01:45:16 --> UTF-8 Support Enabled
INFO - 2018-07-27 01:45:16 --> Utf8 Class Initialized
INFO - 2018-07-27 01:45:16 --> URI Class Initialized
DEBUG - 2018-07-27 01:45:16 --> UTF-8 Support Enabled
INFO - 2018-07-27 01:45:16 --> Router Class Initialized
INFO - 2018-07-27 01:45:16 --> Utf8 Class Initialized
INFO - 2018-07-27 01:45:16 --> Output Class Initialized
INFO - 2018-07-27 01:45:16 --> URI Class Initialized
INFO - 2018-07-27 01:45:16 --> Security Class Initialized
DEBUG - 2018-07-27 01:45:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 01:45:16 --> Router Class Initialized
INFO - 2018-07-27 01:45:16 --> Input Class Initialized
INFO - 2018-07-27 01:45:16 --> Output Class Initialized
INFO - 2018-07-27 01:45:16 --> Language Class Initialized
INFO - 2018-07-27 01:45:16 --> Security Class Initialized
ERROR - 2018-07-27 01:45:16 --> 404 Page Not Found: /index
DEBUG - 2018-07-27 01:45:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 01:45:16 --> Input Class Initialized
INFO - 2018-07-27 01:45:16 --> Language Class Initialized
ERROR - 2018-07-27 01:45:16 --> 404 Page Not Found: /index
INFO - 2018-07-27 01:45:16 --> Config Class Initialized
INFO - 2018-07-27 01:45:16 --> Hooks Class Initialized
DEBUG - 2018-07-27 01:45:16 --> UTF-8 Support Enabled
INFO - 2018-07-27 01:45:16 --> Utf8 Class Initialized
INFO - 2018-07-27 01:45:16 --> URI Class Initialized
INFO - 2018-07-27 01:45:16 --> Router Class Initialized
INFO - 2018-07-27 01:45:16 --> Output Class Initialized
INFO - 2018-07-27 01:45:16 --> Security Class Initialized
DEBUG - 2018-07-27 01:45:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 01:45:16 --> Input Class Initialized
INFO - 2018-07-27 01:45:16 --> Language Class Initialized
ERROR - 2018-07-27 01:45:16 --> 404 Page Not Found: /index
INFO - 2018-07-27 01:53:41 --> Config Class Initialized
INFO - 2018-07-27 01:53:41 --> Hooks Class Initialized
DEBUG - 2018-07-27 01:53:41 --> UTF-8 Support Enabled
INFO - 2018-07-27 01:53:41 --> Utf8 Class Initialized
INFO - 2018-07-27 01:53:41 --> URI Class Initialized
INFO - 2018-07-27 01:53:41 --> Router Class Initialized
INFO - 2018-07-27 01:53:41 --> Output Class Initialized
INFO - 2018-07-27 01:53:41 --> Security Class Initialized
DEBUG - 2018-07-27 01:53:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 01:53:41 --> Input Class Initialized
INFO - 2018-07-27 01:53:41 --> Language Class Initialized
INFO - 2018-07-27 01:53:41 --> Language Class Initialized
INFO - 2018-07-27 01:53:41 --> Config Class Initialized
INFO - 2018-07-27 01:53:41 --> Loader Class Initialized
DEBUG - 2018-07-27 01:53:41 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-27 01:53:41 --> Helper loaded: url_helper
INFO - 2018-07-27 01:53:41 --> Helper loaded: form_helper
INFO - 2018-07-27 01:53:41 --> Helper loaded: date_helper
INFO - 2018-07-27 01:53:41 --> Helper loaded: util_helper
INFO - 2018-07-27 01:53:41 --> Helper loaded: text_helper
INFO - 2018-07-27 01:53:41 --> Helper loaded: string_helper
INFO - 2018-07-27 01:53:41 --> Database Driver Class Initialized
DEBUG - 2018-07-27 01:53:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 01:53:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 01:53:41 --> Email Class Initialized
INFO - 2018-07-27 01:53:41 --> Controller Class Initialized
DEBUG - 2018-07-27 01:53:41 --> Profile MX_Controller Initialized
DEBUG - 2018-07-27 01:53:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-27 01:53:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-27 01:53:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-07-27 01:53:41 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-27 01:53:41 --> Login MX_Controller Initialized
INFO - 2018-07-27 01:53:41 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-27 01:53:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-27 01:53:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-27 01:53:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-27 01:53:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-27 01:53:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-07-27 01:53:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-27 01:53:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-27 01:53:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/reset_password.php
INFO - 2018-07-27 01:53:41 --> Final output sent to browser
DEBUG - 2018-07-27 01:53:41 --> Total execution time: 0.4179
INFO - 2018-07-27 01:53:42 --> Config Class Initialized
INFO - 2018-07-27 01:53:42 --> Hooks Class Initialized
DEBUG - 2018-07-27 01:53:42 --> UTF-8 Support Enabled
INFO - 2018-07-27 01:53:42 --> Utf8 Class Initialized
INFO - 2018-07-27 01:53:42 --> URI Class Initialized
INFO - 2018-07-27 01:53:42 --> Router Class Initialized
INFO - 2018-07-27 01:53:42 --> Output Class Initialized
INFO - 2018-07-27 01:53:42 --> Config Class Initialized
INFO - 2018-07-27 01:53:42 --> Hooks Class Initialized
INFO - 2018-07-27 01:53:42 --> Security Class Initialized
DEBUG - 2018-07-27 01:53:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-07-27 01:53:42 --> UTF-8 Support Enabled
INFO - 2018-07-27 01:53:42 --> Input Class Initialized
INFO - 2018-07-27 01:53:42 --> Utf8 Class Initialized
INFO - 2018-07-27 01:53:42 --> Language Class Initialized
ERROR - 2018-07-27 01:53:42 --> 404 Page Not Found: /index
INFO - 2018-07-27 01:53:42 --> URI Class Initialized
INFO - 2018-07-27 01:53:42 --> Router Class Initialized
INFO - 2018-07-27 01:53:42 --> Output Class Initialized
INFO - 2018-07-27 01:53:42 --> Security Class Initialized
DEBUG - 2018-07-27 01:53:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 01:53:42 --> Input Class Initialized
INFO - 2018-07-27 01:53:42 --> Language Class Initialized
INFO - 2018-07-27 01:53:42 --> Language Class Initialized
INFO - 2018-07-27 01:53:42 --> Config Class Initialized
INFO - 2018-07-27 01:53:42 --> Config Class Initialized
INFO - 2018-07-27 01:53:42 --> Hooks Class Initialized
INFO - 2018-07-27 01:53:42 --> Loader Class Initialized
DEBUG - 2018-07-27 01:53:42 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
DEBUG - 2018-07-27 01:53:42 --> UTF-8 Support Enabled
INFO - 2018-07-27 01:53:42 --> Utf8 Class Initialized
INFO - 2018-07-27 01:53:42 --> Helper loaded: url_helper
INFO - 2018-07-27 01:53:42 --> URI Class Initialized
INFO - 2018-07-27 01:53:42 --> Helper loaded: form_helper
INFO - 2018-07-27 01:53:42 --> Helper loaded: date_helper
INFO - 2018-07-27 01:53:42 --> Router Class Initialized
INFO - 2018-07-27 01:53:43 --> Output Class Initialized
INFO - 2018-07-27 01:53:43 --> Helper loaded: util_helper
INFO - 2018-07-27 01:53:43 --> Security Class Initialized
DEBUG - 2018-07-27 01:53:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 01:53:43 --> Input Class Initialized
INFO - 2018-07-27 01:53:43 --> Language Class Initialized
ERROR - 2018-07-27 01:53:43 --> 404 Page Not Found: /index
INFO - 2018-07-27 01:53:43 --> Helper loaded: text_helper
INFO - 2018-07-27 01:53:43 --> Config Class Initialized
INFO - 2018-07-27 01:53:43 --> Hooks Class Initialized
INFO - 2018-07-27 01:53:43 --> Helper loaded: string_helper
DEBUG - 2018-07-27 01:53:43 --> UTF-8 Support Enabled
INFO - 2018-07-27 01:53:43 --> Database Driver Class Initialized
INFO - 2018-07-27 01:53:43 --> Utf8 Class Initialized
INFO - 2018-07-27 01:53:43 --> URI Class Initialized
DEBUG - 2018-07-27 01:53:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 01:53:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 01:53:43 --> Router Class Initialized
INFO - 2018-07-27 01:53:43 --> Output Class Initialized
INFO - 2018-07-27 01:53:43 --> Email Class Initialized
INFO - 2018-07-27 01:53:43 --> Controller Class Initialized
INFO - 2018-07-27 01:53:43 --> Security Class Initialized
DEBUG - 2018-07-27 01:53:43 --> Home MX_Controller Initialized
DEBUG - 2018-07-27 01:53:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-07-27 01:53:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-07-27 01:53:43 --> Input Class Initialized
INFO - 2018-07-27 01:53:43 --> Language Class Initialized
ERROR - 2018-07-27 01:53:43 --> 404 Page Not Found: /index
INFO - 2018-07-27 01:54:04 --> Config Class Initialized
INFO - 2018-07-27 01:54:04 --> Hooks Class Initialized
DEBUG - 2018-07-27 01:54:04 --> UTF-8 Support Enabled
INFO - 2018-07-27 01:54:04 --> Utf8 Class Initialized
INFO - 2018-07-27 01:54:04 --> URI Class Initialized
INFO - 2018-07-27 01:54:04 --> Router Class Initialized
INFO - 2018-07-27 01:54:04 --> Output Class Initialized
INFO - 2018-07-27 01:54:04 --> Security Class Initialized
DEBUG - 2018-07-27 01:54:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 01:54:04 --> Input Class Initialized
INFO - 2018-07-27 01:54:04 --> Language Class Initialized
INFO - 2018-07-27 01:54:04 --> Language Class Initialized
INFO - 2018-07-27 01:54:04 --> Config Class Initialized
INFO - 2018-07-27 01:54:04 --> Loader Class Initialized
DEBUG - 2018-07-27 01:54:04 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-27 01:54:04 --> Helper loaded: url_helper
INFO - 2018-07-27 01:54:04 --> Helper loaded: form_helper
INFO - 2018-07-27 01:54:04 --> Helper loaded: date_helper
INFO - 2018-07-27 01:54:04 --> Helper loaded: util_helper
INFO - 2018-07-27 01:54:04 --> Helper loaded: text_helper
INFO - 2018-07-27 01:54:04 --> Helper loaded: string_helper
INFO - 2018-07-27 01:54:04 --> Database Driver Class Initialized
DEBUG - 2018-07-27 01:54:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 01:54:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 01:54:04 --> Email Class Initialized
INFO - 2018-07-27 01:54:04 --> Controller Class Initialized
DEBUG - 2018-07-27 01:54:04 --> Home MX_Controller Initialized
DEBUG - 2018-07-27 01:54:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-07-27 01:54:05 --> Config Class Initialized
INFO - 2018-07-27 01:54:05 --> Hooks Class Initialized
DEBUG - 2018-07-27 01:54:05 --> UTF-8 Support Enabled
INFO - 2018-07-27 01:54:05 --> Utf8 Class Initialized
INFO - 2018-07-27 01:54:05 --> URI Class Initialized
INFO - 2018-07-27 01:54:05 --> Router Class Initialized
INFO - 2018-07-27 01:54:05 --> Output Class Initialized
INFO - 2018-07-27 01:54:05 --> Security Class Initialized
DEBUG - 2018-07-27 01:54:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 01:54:05 --> Input Class Initialized
INFO - 2018-07-27 01:54:05 --> Language Class Initialized
ERROR - 2018-07-27 01:54:05 --> 404 Page Not Found: /index
INFO - 2018-07-27 01:54:05 --> Config Class Initialized
INFO - 2018-07-27 01:54:05 --> Hooks Class Initialized
DEBUG - 2018-07-27 01:54:05 --> UTF-8 Support Enabled
INFO - 2018-07-27 01:54:05 --> Utf8 Class Initialized
INFO - 2018-07-27 01:54:05 --> URI Class Initialized
INFO - 2018-07-27 01:54:05 --> Router Class Initialized
INFO - 2018-07-27 01:54:05 --> Output Class Initialized
INFO - 2018-07-27 01:54:05 --> Security Class Initialized
DEBUG - 2018-07-27 01:54:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 01:54:05 --> Input Class Initialized
INFO - 2018-07-27 01:54:05 --> Language Class Initialized
ERROR - 2018-07-27 01:54:05 --> 404 Page Not Found: /index
INFO - 2018-07-27 01:54:05 --> Config Class Initialized
INFO - 2018-07-27 01:54:05 --> Hooks Class Initialized
DEBUG - 2018-07-27 01:54:05 --> UTF-8 Support Enabled
INFO - 2018-07-27 01:54:05 --> Utf8 Class Initialized
INFO - 2018-07-27 01:54:05 --> URI Class Initialized
INFO - 2018-07-27 01:54:05 --> Router Class Initialized
INFO - 2018-07-27 01:54:05 --> Output Class Initialized
INFO - 2018-07-27 01:54:05 --> Security Class Initialized
DEBUG - 2018-07-27 01:54:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 01:54:05 --> Input Class Initialized
INFO - 2018-07-27 01:54:05 --> Language Class Initialized
ERROR - 2018-07-27 01:54:05 --> 404 Page Not Found: /index
INFO - 2018-07-27 01:54:42 --> Config Class Initialized
INFO - 2018-07-27 01:54:42 --> Hooks Class Initialized
DEBUG - 2018-07-27 01:54:42 --> UTF-8 Support Enabled
INFO - 2018-07-27 01:54:42 --> Utf8 Class Initialized
INFO - 2018-07-27 01:54:42 --> URI Class Initialized
INFO - 2018-07-27 01:54:42 --> Router Class Initialized
INFO - 2018-07-27 01:54:42 --> Output Class Initialized
INFO - 2018-07-27 01:54:43 --> Security Class Initialized
DEBUG - 2018-07-27 01:54:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 01:54:43 --> Input Class Initialized
INFO - 2018-07-27 01:54:43 --> Language Class Initialized
INFO - 2018-07-27 01:54:43 --> Language Class Initialized
INFO - 2018-07-27 01:54:43 --> Config Class Initialized
INFO - 2018-07-27 01:54:43 --> Loader Class Initialized
DEBUG - 2018-07-27 01:54:43 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-27 01:54:43 --> Helper loaded: url_helper
INFO - 2018-07-27 01:54:43 --> Helper loaded: form_helper
INFO - 2018-07-27 01:54:43 --> Helper loaded: date_helper
INFO - 2018-07-27 01:54:43 --> Helper loaded: util_helper
INFO - 2018-07-27 01:54:43 --> Helper loaded: text_helper
INFO - 2018-07-27 01:54:43 --> Helper loaded: string_helper
INFO - 2018-07-27 01:54:43 --> Database Driver Class Initialized
DEBUG - 2018-07-27 01:54:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 01:54:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 01:54:43 --> Email Class Initialized
INFO - 2018-07-27 01:54:43 --> Controller Class Initialized
DEBUG - 2018-07-27 01:54:43 --> Home MX_Controller Initialized
DEBUG - 2018-07-27 01:54:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-07-27 02:16:33 --> Config Class Initialized
INFO - 2018-07-27 02:16:33 --> Hooks Class Initialized
DEBUG - 2018-07-27 02:16:33 --> UTF-8 Support Enabled
INFO - 2018-07-27 02:16:33 --> Utf8 Class Initialized
INFO - 2018-07-27 02:16:33 --> URI Class Initialized
INFO - 2018-07-27 02:16:33 --> Router Class Initialized
INFO - 2018-07-27 02:16:33 --> Output Class Initialized
INFO - 2018-07-27 02:16:33 --> Security Class Initialized
DEBUG - 2018-07-27 02:16:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 02:16:33 --> Input Class Initialized
INFO - 2018-07-27 02:16:33 --> Language Class Initialized
INFO - 2018-07-27 02:16:33 --> Language Class Initialized
INFO - 2018-07-27 02:16:33 --> Config Class Initialized
INFO - 2018-07-27 02:16:33 --> Loader Class Initialized
DEBUG - 2018-07-27 02:16:33 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-27 02:16:33 --> Helper loaded: url_helper
INFO - 2018-07-27 02:16:33 --> Helper loaded: form_helper
INFO - 2018-07-27 02:16:33 --> Helper loaded: date_helper
INFO - 2018-07-27 02:16:33 --> Helper loaded: util_helper
INFO - 2018-07-27 02:16:33 --> Helper loaded: text_helper
INFO - 2018-07-27 02:16:33 --> Helper loaded: string_helper
INFO - 2018-07-27 02:16:33 --> Database Driver Class Initialized
DEBUG - 2018-07-27 02:16:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 02:16:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 02:16:33 --> Email Class Initialized
INFO - 2018-07-27 02:16:33 --> Controller Class Initialized
DEBUG - 2018-07-27 02:16:33 --> Home MX_Controller Initialized
DEBUG - 2018-07-27 02:16:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-27 02:16:33 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-27 02:16:33 --> Login MX_Controller Initialized
INFO - 2018-07-27 02:16:33 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-27 02:16:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-27 02:16:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-27 02:16:45 --> Config Class Initialized
INFO - 2018-07-27 02:16:45 --> Hooks Class Initialized
DEBUG - 2018-07-27 02:16:45 --> UTF-8 Support Enabled
INFO - 2018-07-27 02:16:45 --> Utf8 Class Initialized
INFO - 2018-07-27 02:16:45 --> URI Class Initialized
INFO - 2018-07-27 02:16:45 --> Router Class Initialized
INFO - 2018-07-27 02:16:45 --> Output Class Initialized
INFO - 2018-07-27 02:16:45 --> Config Class Initialized
INFO - 2018-07-27 02:16:45 --> Security Class Initialized
INFO - 2018-07-27 02:16:45 --> Hooks Class Initialized
DEBUG - 2018-07-27 02:16:45 --> UTF-8 Support Enabled
INFO - 2018-07-27 02:16:45 --> Utf8 Class Initialized
INFO - 2018-07-27 02:16:45 --> URI Class Initialized
INFO - 2018-07-27 02:16:45 --> Router Class Initialized
DEBUG - 2018-07-27 02:16:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 02:16:45 --> Output Class Initialized
INFO - 2018-07-27 02:16:45 --> Security Class Initialized
DEBUG - 2018-07-27 02:16:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 02:16:45 --> Input Class Initialized
INFO - 2018-07-27 02:16:45 --> Language Class Initialized
ERROR - 2018-07-27 02:16:45 --> 404 Page Not Found: /index
INFO - 2018-07-27 02:16:45 --> Config Class Initialized
INFO - 2018-07-27 02:16:45 --> Hooks Class Initialized
INFO - 2018-07-27 02:16:45 --> Input Class Initialized
DEBUG - 2018-07-27 02:16:45 --> UTF-8 Support Enabled
INFO - 2018-07-27 02:16:45 --> Utf8 Class Initialized
INFO - 2018-07-27 02:16:45 --> Language Class Initialized
INFO - 2018-07-27 02:16:45 --> URI Class Initialized
INFO - 2018-07-27 02:16:45 --> Router Class Initialized
INFO - 2018-07-27 02:16:45 --> Language Class Initialized
INFO - 2018-07-27 02:16:45 --> Output Class Initialized
INFO - 2018-07-27 02:16:45 --> Security Class Initialized
INFO - 2018-07-27 02:16:45 --> Config Class Initialized
DEBUG - 2018-07-27 02:16:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 02:16:45 --> Input Class Initialized
INFO - 2018-07-27 02:16:45 --> Language Class Initialized
ERROR - 2018-07-27 02:16:45 --> 404 Page Not Found: /index
INFO - 2018-07-27 02:16:45 --> Config Class Initialized
INFO - 2018-07-27 02:16:45 --> Hooks Class Initialized
DEBUG - 2018-07-27 02:16:45 --> UTF-8 Support Enabled
INFO - 2018-07-27 02:16:45 --> Loader Class Initialized
INFO - 2018-07-27 02:16:45 --> Utf8 Class Initialized
INFO - 2018-07-27 02:16:45 --> URI Class Initialized
DEBUG - 2018-07-27 02:16:45 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-27 02:16:45 --> Router Class Initialized
INFO - 2018-07-27 02:16:45 --> Output Class Initialized
INFO - 2018-07-27 02:16:45 --> Helper loaded: url_helper
INFO - 2018-07-27 02:16:45 --> Helper loaded: form_helper
INFO - 2018-07-27 02:16:45 --> Security Class Initialized
INFO - 2018-07-27 02:16:45 --> Helper loaded: date_helper
DEBUG - 2018-07-27 02:16:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 02:16:45 --> Helper loaded: util_helper
INFO - 2018-07-27 02:16:45 --> Input Class Initialized
INFO - 2018-07-27 02:16:45 --> Helper loaded: text_helper
INFO - 2018-07-27 02:16:45 --> Helper loaded: string_helper
INFO - 2018-07-27 02:16:45 --> Language Class Initialized
ERROR - 2018-07-27 02:16:45 --> 404 Page Not Found: /index
INFO - 2018-07-27 02:16:45 --> Database Driver Class Initialized
DEBUG - 2018-07-27 02:16:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 02:16:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 02:16:45 --> Email Class Initialized
INFO - 2018-07-27 02:16:45 --> Controller Class Initialized
DEBUG - 2018-07-27 02:16:45 --> Home MX_Controller Initialized
DEBUG - 2018-07-27 02:16:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-27 02:16:45 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-27 02:16:45 --> Login MX_Controller Initialized
INFO - 2018-07-27 02:16:45 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-27 02:16:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-27 02:16:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-27 02:18:58 --> Config Class Initialized
INFO - 2018-07-27 02:18:58 --> Hooks Class Initialized
DEBUG - 2018-07-27 02:18:58 --> UTF-8 Support Enabled
INFO - 2018-07-27 02:18:58 --> Utf8 Class Initialized
INFO - 2018-07-27 02:18:58 --> URI Class Initialized
INFO - 2018-07-27 02:18:58 --> Router Class Initialized
INFO - 2018-07-27 02:18:58 --> Output Class Initialized
INFO - 2018-07-27 02:18:58 --> Security Class Initialized
DEBUG - 2018-07-27 02:18:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 02:18:58 --> Input Class Initialized
INFO - 2018-07-27 02:18:58 --> Language Class Initialized
INFO - 2018-07-27 02:18:58 --> Language Class Initialized
INFO - 2018-07-27 02:18:58 --> Config Class Initialized
INFO - 2018-07-27 02:18:58 --> Loader Class Initialized
DEBUG - 2018-07-27 02:18:58 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-27 02:18:58 --> Helper loaded: url_helper
INFO - 2018-07-27 02:18:58 --> Helper loaded: form_helper
INFO - 2018-07-27 02:18:58 --> Helper loaded: date_helper
INFO - 2018-07-27 02:18:58 --> Helper loaded: util_helper
INFO - 2018-07-27 02:18:58 --> Helper loaded: text_helper
INFO - 2018-07-27 02:18:58 --> Helper loaded: string_helper
INFO - 2018-07-27 02:18:58 --> Database Driver Class Initialized
DEBUG - 2018-07-27 02:18:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 02:18:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 02:18:59 --> Email Class Initialized
INFO - 2018-07-27 02:18:59 --> Controller Class Initialized
DEBUG - 2018-07-27 02:18:59 --> Profile MX_Controller Initialized
DEBUG - 2018-07-27 02:18:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-27 02:18:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-27 02:18:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-07-27 02:18:59 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-27 02:18:59 --> Login MX_Controller Initialized
INFO - 2018-07-27 02:18:59 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-27 02:18:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-27 02:18:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-27 02:18:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-27 02:18:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-27 02:18:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-07-27 02:18:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-27 02:18:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-27 02:18:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/reset_password.php
INFO - 2018-07-27 02:18:59 --> Final output sent to browser
DEBUG - 2018-07-27 02:18:59 --> Total execution time: 0.4534
INFO - 2018-07-27 02:18:59 --> Config Class Initialized
INFO - 2018-07-27 02:18:59 --> Hooks Class Initialized
DEBUG - 2018-07-27 02:18:59 --> UTF-8 Support Enabled
INFO - 2018-07-27 02:18:59 --> Utf8 Class Initialized
INFO - 2018-07-27 02:18:59 --> URI Class Initialized
INFO - 2018-07-27 02:18:59 --> Router Class Initialized
INFO - 2018-07-27 02:18:59 --> Output Class Initialized
INFO - 2018-07-27 02:18:59 --> Config Class Initialized
INFO - 2018-07-27 02:18:59 --> Hooks Class Initialized
INFO - 2018-07-27 02:18:59 --> Security Class Initialized
DEBUG - 2018-07-27 02:18:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-07-27 02:18:59 --> UTF-8 Support Enabled
INFO - 2018-07-27 02:19:00 --> Utf8 Class Initialized
INFO - 2018-07-27 02:19:00 --> Input Class Initialized
INFO - 2018-07-27 02:19:00 --> URI Class Initialized
INFO - 2018-07-27 02:19:00 --> Language Class Initialized
INFO - 2018-07-27 02:19:00 --> Router Class Initialized
ERROR - 2018-07-27 02:19:00 --> 404 Page Not Found: /index
INFO - 2018-07-27 02:19:00 --> Output Class Initialized
INFO - 2018-07-27 02:19:00 --> Security Class Initialized
DEBUG - 2018-07-27 02:19:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 02:19:00 --> Input Class Initialized
INFO - 2018-07-27 02:19:00 --> Language Class Initialized
INFO - 2018-07-27 02:19:00 --> Language Class Initialized
INFO - 2018-07-27 02:19:00 --> Config Class Initialized
INFO - 2018-07-27 02:19:00 --> Loader Class Initialized
INFO - 2018-07-27 02:19:00 --> Config Class Initialized
INFO - 2018-07-27 02:19:00 --> Hooks Class Initialized
DEBUG - 2018-07-27 02:19:00 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
DEBUG - 2018-07-27 02:19:00 --> UTF-8 Support Enabled
INFO - 2018-07-27 02:19:00 --> Utf8 Class Initialized
INFO - 2018-07-27 02:19:00 --> URI Class Initialized
INFO - 2018-07-27 02:19:00 --> Router Class Initialized
INFO - 2018-07-27 02:19:00 --> Helper loaded: url_helper
INFO - 2018-07-27 02:19:00 --> Output Class Initialized
INFO - 2018-07-27 02:19:00 --> Security Class Initialized
INFO - 2018-07-27 02:19:00 --> Helper loaded: form_helper
INFO - 2018-07-27 02:19:00 --> Helper loaded: date_helper
DEBUG - 2018-07-27 02:19:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 02:19:00 --> Helper loaded: util_helper
INFO - 2018-07-27 02:19:00 --> Input Class Initialized
INFO - 2018-07-27 02:19:00 --> Language Class Initialized
INFO - 2018-07-27 02:19:00 --> Helper loaded: text_helper
INFO - 2018-07-27 02:19:00 --> Helper loaded: string_helper
ERROR - 2018-07-27 02:19:00 --> 404 Page Not Found: /index
INFO - 2018-07-27 02:19:00 --> Database Driver Class Initialized
INFO - 2018-07-27 02:19:00 --> Config Class Initialized
INFO - 2018-07-27 02:19:00 --> Hooks Class Initialized
DEBUG - 2018-07-27 02:19:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 02:19:00 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-07-27 02:19:00 --> UTF-8 Support Enabled
INFO - 2018-07-27 02:19:00 --> Utf8 Class Initialized
INFO - 2018-07-27 02:19:00 --> Email Class Initialized
INFO - 2018-07-27 02:19:00 --> Controller Class Initialized
INFO - 2018-07-27 02:19:00 --> URI Class Initialized
DEBUG - 2018-07-27 02:19:00 --> Home MX_Controller Initialized
INFO - 2018-07-27 02:19:00 --> Router Class Initialized
DEBUG - 2018-07-27 02:19:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-07-27 02:19:00 --> Output Class Initialized
INFO - 2018-07-27 02:19:00 --> Security Class Initialized
DEBUG - 2018-07-27 02:19:00 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-27 02:19:00 --> Login MX_Controller Initialized
DEBUG - 2018-07-27 02:19:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 02:19:00 --> Language file loaded: language/english/data_lang.php
INFO - 2018-07-27 02:19:00 --> Input Class Initialized
INFO - 2018-07-27 02:19:00 --> Language Class Initialized
DEBUG - 2018-07-27 02:19:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
ERROR - 2018-07-27 02:19:00 --> 404 Page Not Found: /index
DEBUG - 2018-07-27 02:19:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-27 02:19:05 --> Config Class Initialized
INFO - 2018-07-27 02:19:05 --> Hooks Class Initialized
DEBUG - 2018-07-27 02:19:05 --> UTF-8 Support Enabled
INFO - 2018-07-27 02:19:05 --> Utf8 Class Initialized
INFO - 2018-07-27 02:19:05 --> URI Class Initialized
INFO - 2018-07-27 02:19:05 --> Router Class Initialized
INFO - 2018-07-27 02:19:05 --> Output Class Initialized
INFO - 2018-07-27 02:19:05 --> Security Class Initialized
DEBUG - 2018-07-27 02:19:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 02:19:05 --> Input Class Initialized
INFO - 2018-07-27 02:19:05 --> Language Class Initialized
INFO - 2018-07-27 02:19:05 --> Language Class Initialized
INFO - 2018-07-27 02:19:05 --> Config Class Initialized
INFO - 2018-07-27 02:19:05 --> Loader Class Initialized
DEBUG - 2018-07-27 02:19:05 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-27 02:19:05 --> Helper loaded: url_helper
INFO - 2018-07-27 02:19:05 --> Helper loaded: form_helper
INFO - 2018-07-27 02:19:05 --> Helper loaded: date_helper
INFO - 2018-07-27 02:19:05 --> Helper loaded: util_helper
INFO - 2018-07-27 02:19:05 --> Helper loaded: text_helper
INFO - 2018-07-27 02:19:05 --> Helper loaded: string_helper
INFO - 2018-07-27 02:19:05 --> Database Driver Class Initialized
DEBUG - 2018-07-27 02:19:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 02:19:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 02:19:05 --> Email Class Initialized
INFO - 2018-07-27 02:19:05 --> Controller Class Initialized
DEBUG - 2018-07-27 02:19:05 --> Home MX_Controller Initialized
DEBUG - 2018-07-27 02:19:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-27 02:19:05 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-27 02:19:05 --> Login MX_Controller Initialized
INFO - 2018-07-27 02:19:06 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-27 02:19:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-27 02:19:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-27 02:20:10 --> Config Class Initialized
INFO - 2018-07-27 02:20:10 --> Hooks Class Initialized
DEBUG - 2018-07-27 02:20:10 --> UTF-8 Support Enabled
INFO - 2018-07-27 02:20:10 --> Utf8 Class Initialized
INFO - 2018-07-27 02:20:10 --> URI Class Initialized
INFO - 2018-07-27 02:20:10 --> Router Class Initialized
INFO - 2018-07-27 02:20:10 --> Output Class Initialized
INFO - 2018-07-27 02:20:10 --> Security Class Initialized
DEBUG - 2018-07-27 02:20:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 02:20:10 --> Input Class Initialized
INFO - 2018-07-27 02:20:10 --> Language Class Initialized
INFO - 2018-07-27 02:20:10 --> Language Class Initialized
INFO - 2018-07-27 02:20:10 --> Config Class Initialized
INFO - 2018-07-27 02:20:10 --> Loader Class Initialized
DEBUG - 2018-07-27 02:20:10 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-27 02:20:10 --> Helper loaded: url_helper
INFO - 2018-07-27 02:20:10 --> Helper loaded: form_helper
INFO - 2018-07-27 02:20:10 --> Helper loaded: date_helper
INFO - 2018-07-27 02:20:10 --> Helper loaded: util_helper
INFO - 2018-07-27 02:20:10 --> Helper loaded: text_helper
INFO - 2018-07-27 02:20:10 --> Helper loaded: string_helper
INFO - 2018-07-27 02:20:10 --> Database Driver Class Initialized
DEBUG - 2018-07-27 02:20:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 02:20:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 02:20:10 --> Email Class Initialized
INFO - 2018-07-27 02:20:10 --> Controller Class Initialized
DEBUG - 2018-07-27 02:20:10 --> Profile MX_Controller Initialized
DEBUG - 2018-07-27 02:20:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-27 02:20:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-27 02:20:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-07-27 02:20:10 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-27 02:20:10 --> Login MX_Controller Initialized
INFO - 2018-07-27 02:20:10 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-27 02:20:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-27 02:20:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-27 02:20:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-27 02:20:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-27 02:20:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-07-27 02:20:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-27 02:20:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-27 02:20:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/reset_password.php
INFO - 2018-07-27 02:20:10 --> Final output sent to browser
DEBUG - 2018-07-27 02:20:10 --> Total execution time: 0.4568
INFO - 2018-07-27 02:20:10 --> Config Class Initialized
INFO - 2018-07-27 02:20:10 --> Hooks Class Initialized
DEBUG - 2018-07-27 02:20:10 --> UTF-8 Support Enabled
INFO - 2018-07-27 02:20:10 --> Utf8 Class Initialized
INFO - 2018-07-27 02:20:10 --> URI Class Initialized
INFO - 2018-07-27 02:20:11 --> Router Class Initialized
INFO - 2018-07-27 02:20:11 --> Config Class Initialized
INFO - 2018-07-27 02:20:11 --> Hooks Class Initialized
INFO - 2018-07-27 02:20:11 --> Output Class Initialized
DEBUG - 2018-07-27 02:20:11 --> UTF-8 Support Enabled
INFO - 2018-07-27 02:20:11 --> Security Class Initialized
INFO - 2018-07-27 02:20:11 --> Utf8 Class Initialized
DEBUG - 2018-07-27 02:20:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 02:20:11 --> Input Class Initialized
INFO - 2018-07-27 02:20:11 --> URI Class Initialized
INFO - 2018-07-27 02:20:11 --> Language Class Initialized
INFO - 2018-07-27 02:20:11 --> Router Class Initialized
INFO - 2018-07-27 02:20:11 --> Output Class Initialized
ERROR - 2018-07-27 02:20:11 --> 404 Page Not Found: /index
INFO - 2018-07-27 02:20:11 --> Security Class Initialized
DEBUG - 2018-07-27 02:20:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 02:20:11 --> Config Class Initialized
INFO - 2018-07-27 02:20:11 --> Hooks Class Initialized
INFO - 2018-07-27 02:20:11 --> Input Class Initialized
DEBUG - 2018-07-27 02:20:11 --> UTF-8 Support Enabled
INFO - 2018-07-27 02:20:11 --> Utf8 Class Initialized
INFO - 2018-07-27 02:20:11 --> URI Class Initialized
INFO - 2018-07-27 02:20:11 --> Router Class Initialized
INFO - 2018-07-27 02:20:11 --> Output Class Initialized
INFO - 2018-07-27 02:20:11 --> Security Class Initialized
DEBUG - 2018-07-27 02:20:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 02:20:11 --> Input Class Initialized
INFO - 2018-07-27 02:20:11 --> Language Class Initialized
INFO - 2018-07-27 02:20:11 --> Language Class Initialized
INFO - 2018-07-27 02:20:11 --> Language Class Initialized
INFO - 2018-07-27 02:20:11 --> Config Class Initialized
ERROR - 2018-07-27 02:20:11 --> 404 Page Not Found: /index
INFO - 2018-07-27 02:20:11 --> Loader Class Initialized
INFO - 2018-07-27 02:20:11 --> Config Class Initialized
DEBUG - 2018-07-27 02:20:11 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-27 02:20:11 --> Hooks Class Initialized
DEBUG - 2018-07-27 02:20:11 --> UTF-8 Support Enabled
INFO - 2018-07-27 02:20:11 --> Helper loaded: url_helper
INFO - 2018-07-27 02:20:11 --> Utf8 Class Initialized
INFO - 2018-07-27 02:20:11 --> URI Class Initialized
INFO - 2018-07-27 02:20:11 --> Helper loaded: form_helper
INFO - 2018-07-27 02:20:11 --> Helper loaded: date_helper
INFO - 2018-07-27 02:20:11 --> Router Class Initialized
INFO - 2018-07-27 02:20:11 --> Output Class Initialized
INFO - 2018-07-27 02:20:11 --> Helper loaded: util_helper
INFO - 2018-07-27 02:20:11 --> Security Class Initialized
INFO - 2018-07-27 02:20:11 --> Helper loaded: text_helper
INFO - 2018-07-27 02:20:11 --> Helper loaded: string_helper
DEBUG - 2018-07-27 02:20:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 02:20:11 --> Input Class Initialized
INFO - 2018-07-27 02:20:11 --> Database Driver Class Initialized
INFO - 2018-07-27 02:20:11 --> Language Class Initialized
DEBUG - 2018-07-27 02:20:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 02:20:11 --> Session: Class initialized using 'files' driver.
ERROR - 2018-07-27 02:20:11 --> 404 Page Not Found: /index
INFO - 2018-07-27 02:20:11 --> Email Class Initialized
INFO - 2018-07-27 02:20:11 --> Controller Class Initialized
DEBUG - 2018-07-27 02:20:11 --> Home MX_Controller Initialized
DEBUG - 2018-07-27 02:20:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-27 02:20:11 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-27 02:20:11 --> Login MX_Controller Initialized
INFO - 2018-07-27 02:20:11 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-27 02:20:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-27 02:20:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-27 02:20:15 --> Config Class Initialized
INFO - 2018-07-27 02:20:15 --> Hooks Class Initialized
DEBUG - 2018-07-27 02:20:15 --> UTF-8 Support Enabled
INFO - 2018-07-27 02:20:15 --> Utf8 Class Initialized
INFO - 2018-07-27 02:20:15 --> URI Class Initialized
INFO - 2018-07-27 02:20:15 --> Router Class Initialized
INFO - 2018-07-27 02:20:15 --> Output Class Initialized
INFO - 2018-07-27 02:20:15 --> Security Class Initialized
DEBUG - 2018-07-27 02:20:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 02:20:15 --> Input Class Initialized
INFO - 2018-07-27 02:20:15 --> Language Class Initialized
INFO - 2018-07-27 02:20:15 --> Language Class Initialized
INFO - 2018-07-27 02:20:15 --> Config Class Initialized
INFO - 2018-07-27 02:20:15 --> Loader Class Initialized
DEBUG - 2018-07-27 02:20:15 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-27 02:20:15 --> Helper loaded: url_helper
INFO - 2018-07-27 02:20:15 --> Helper loaded: form_helper
INFO - 2018-07-27 02:20:15 --> Helper loaded: date_helper
INFO - 2018-07-27 02:20:15 --> Helper loaded: util_helper
INFO - 2018-07-27 02:20:15 --> Helper loaded: text_helper
INFO - 2018-07-27 02:20:15 --> Helper loaded: string_helper
INFO - 2018-07-27 02:20:15 --> Database Driver Class Initialized
DEBUG - 2018-07-27 02:20:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 02:20:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 02:20:15 --> Email Class Initialized
INFO - 2018-07-27 02:20:15 --> Controller Class Initialized
DEBUG - 2018-07-27 02:20:15 --> Profile MX_Controller Initialized
DEBUG - 2018-07-27 02:20:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-27 02:20:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-27 02:20:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-07-27 02:20:15 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-27 02:20:15 --> Login MX_Controller Initialized
INFO - 2018-07-27 02:20:15 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-27 02:20:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-27 02:20:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-27 02:20:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-27 02:20:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-27 02:20:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-07-27 02:20:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-27 02:20:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-27 02:20:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/reset_password.php
INFO - 2018-07-27 02:20:15 --> Final output sent to browser
DEBUG - 2018-07-27 02:20:15 --> Total execution time: 0.4701
INFO - 2018-07-27 02:20:16 --> Config Class Initialized
INFO - 2018-07-27 02:20:16 --> Hooks Class Initialized
DEBUG - 2018-07-27 02:20:16 --> UTF-8 Support Enabled
INFO - 2018-07-27 02:20:16 --> Config Class Initialized
INFO - 2018-07-27 02:20:16 --> Hooks Class Initialized
INFO - 2018-07-27 02:20:16 --> Utf8 Class Initialized
DEBUG - 2018-07-27 02:20:16 --> UTF-8 Support Enabled
INFO - 2018-07-27 02:20:16 --> Utf8 Class Initialized
INFO - 2018-07-27 02:20:16 --> URI Class Initialized
INFO - 2018-07-27 02:20:16 --> Router Class Initialized
INFO - 2018-07-27 02:20:16 --> Output Class Initialized
INFO - 2018-07-27 02:20:16 --> Security Class Initialized
INFO - 2018-07-27 02:20:16 --> URI Class Initialized
DEBUG - 2018-07-27 02:20:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 02:20:16 --> Router Class Initialized
INFO - 2018-07-27 02:20:16 --> Output Class Initialized
INFO - 2018-07-27 02:20:16 --> Security Class Initialized
DEBUG - 2018-07-27 02:20:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 02:20:16 --> Input Class Initialized
INFO - 2018-07-27 02:20:16 --> Language Class Initialized
ERROR - 2018-07-27 02:20:16 --> 404 Page Not Found: /index
INFO - 2018-07-27 02:20:16 --> Input Class Initialized
INFO - 2018-07-27 02:20:16 --> Config Class Initialized
INFO - 2018-07-27 02:20:16 --> Hooks Class Initialized
INFO - 2018-07-27 02:20:16 --> Language Class Initialized
DEBUG - 2018-07-27 02:20:16 --> UTF-8 Support Enabled
INFO - 2018-07-27 02:20:16 --> Language Class Initialized
INFO - 2018-07-27 02:20:16 --> Utf8 Class Initialized
INFO - 2018-07-27 02:20:16 --> Config Class Initialized
INFO - 2018-07-27 02:20:16 --> URI Class Initialized
INFO - 2018-07-27 02:20:16 --> Loader Class Initialized
DEBUG - 2018-07-27 02:20:16 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-27 02:20:16 --> Router Class Initialized
INFO - 2018-07-27 02:20:16 --> Helper loaded: url_helper
INFO - 2018-07-27 02:20:16 --> Output Class Initialized
INFO - 2018-07-27 02:20:16 --> Security Class Initialized
INFO - 2018-07-27 02:20:16 --> Helper loaded: form_helper
DEBUG - 2018-07-27 02:20:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 02:20:16 --> Helper loaded: date_helper
INFO - 2018-07-27 02:20:16 --> Helper loaded: util_helper
INFO - 2018-07-27 02:20:16 --> Input Class Initialized
INFO - 2018-07-27 02:20:16 --> Language Class Initialized
INFO - 2018-07-27 02:20:16 --> Helper loaded: text_helper
ERROR - 2018-07-27 02:20:16 --> 404 Page Not Found: /index
INFO - 2018-07-27 02:20:16 --> Helper loaded: string_helper
INFO - 2018-07-27 02:20:17 --> Database Driver Class Initialized
INFO - 2018-07-27 02:20:17 --> Config Class Initialized
INFO - 2018-07-27 02:20:17 --> Hooks Class Initialized
DEBUG - 2018-07-27 02:20:17 --> UTF-8 Support Enabled
INFO - 2018-07-27 02:20:17 --> Utf8 Class Initialized
INFO - 2018-07-27 02:20:17 --> URI Class Initialized
DEBUG - 2018-07-27 02:20:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 02:20:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 02:20:17 --> Router Class Initialized
INFO - 2018-07-27 02:20:17 --> Output Class Initialized
INFO - 2018-07-27 02:20:17 --> Email Class Initialized
INFO - 2018-07-27 02:20:17 --> Controller Class Initialized
INFO - 2018-07-27 02:20:17 --> Security Class Initialized
DEBUG - 2018-07-27 02:20:17 --> Home MX_Controller Initialized
DEBUG - 2018-07-27 02:20:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 02:20:17 --> Input Class Initialized
DEBUG - 2018-07-27 02:20:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-07-27 02:20:17 --> Language Class Initialized
DEBUG - 2018-07-27 02:20:17 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-27 02:20:17 --> Login MX_Controller Initialized
ERROR - 2018-07-27 02:20:17 --> 404 Page Not Found: /index
INFO - 2018-07-27 02:20:17 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-27 02:20:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-27 02:20:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-27 02:25:15 --> Config Class Initialized
INFO - 2018-07-27 02:25:15 --> Hooks Class Initialized
DEBUG - 2018-07-27 02:25:15 --> UTF-8 Support Enabled
INFO - 2018-07-27 02:25:15 --> Utf8 Class Initialized
INFO - 2018-07-27 02:25:15 --> URI Class Initialized
INFO - 2018-07-27 02:25:15 --> Router Class Initialized
INFO - 2018-07-27 02:25:15 --> Output Class Initialized
INFO - 2018-07-27 02:25:15 --> Security Class Initialized
DEBUG - 2018-07-27 02:25:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 02:25:15 --> Input Class Initialized
INFO - 2018-07-27 02:25:15 --> Language Class Initialized
INFO - 2018-07-27 02:25:15 --> Language Class Initialized
INFO - 2018-07-27 02:25:15 --> Config Class Initialized
INFO - 2018-07-27 02:25:15 --> Loader Class Initialized
DEBUG - 2018-07-27 02:25:15 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-27 02:25:15 --> Helper loaded: url_helper
INFO - 2018-07-27 02:25:15 --> Helper loaded: form_helper
INFO - 2018-07-27 02:25:15 --> Helper loaded: date_helper
INFO - 2018-07-27 02:25:15 --> Helper loaded: util_helper
INFO - 2018-07-27 02:25:15 --> Helper loaded: text_helper
INFO - 2018-07-27 02:25:15 --> Helper loaded: string_helper
INFO - 2018-07-27 02:25:15 --> Database Driver Class Initialized
DEBUG - 2018-07-27 02:25:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 02:25:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 02:25:15 --> Email Class Initialized
INFO - 2018-07-27 02:25:15 --> Controller Class Initialized
DEBUG - 2018-07-27 02:25:15 --> Profile MX_Controller Initialized
DEBUG - 2018-07-27 02:25:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-27 02:25:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-27 02:25:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-07-27 02:25:15 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-27 02:25:15 --> Login MX_Controller Initialized
INFO - 2018-07-27 02:25:15 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-27 02:25:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-27 02:25:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-27 02:25:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-27 02:25:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-27 02:25:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-07-27 02:25:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-27 02:25:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-27 02:25:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/reset_password.php
INFO - 2018-07-27 02:25:15 --> Final output sent to browser
DEBUG - 2018-07-27 02:25:15 --> Total execution time: 0.4669
INFO - 2018-07-27 02:25:16 --> Config Class Initialized
INFO - 2018-07-27 02:25:16 --> Hooks Class Initialized
DEBUG - 2018-07-27 02:25:16 --> UTF-8 Support Enabled
INFO - 2018-07-27 02:25:16 --> Utf8 Class Initialized
INFO - 2018-07-27 02:25:16 --> URI Class Initialized
INFO - 2018-07-27 02:25:16 --> Router Class Initialized
INFO - 2018-07-27 02:25:16 --> Output Class Initialized
INFO - 2018-07-27 02:25:16 --> Config Class Initialized
INFO - 2018-07-27 02:25:16 --> Hooks Class Initialized
INFO - 2018-07-27 02:25:16 --> Security Class Initialized
DEBUG - 2018-07-27 02:25:16 --> UTF-8 Support Enabled
DEBUG - 2018-07-27 02:25:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 02:25:16 --> Utf8 Class Initialized
INFO - 2018-07-27 02:25:16 --> URI Class Initialized
INFO - 2018-07-27 02:25:16 --> Router Class Initialized
INFO - 2018-07-27 02:25:16 --> Output Class Initialized
INFO - 2018-07-27 02:25:16 --> Security Class Initialized
DEBUG - 2018-07-27 02:25:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 02:25:16 --> Input Class Initialized
INFO - 2018-07-27 02:25:16 --> Input Class Initialized
INFO - 2018-07-27 02:25:16 --> Language Class Initialized
INFO - 2018-07-27 02:25:16 --> Language Class Initialized
ERROR - 2018-07-27 02:25:16 --> 404 Page Not Found: /index
INFO - 2018-07-27 02:25:16 --> Language Class Initialized
INFO - 2018-07-27 02:25:16 --> Config Class Initialized
INFO - 2018-07-27 02:25:16 --> Loader Class Initialized
DEBUG - 2018-07-27 02:25:16 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-27 02:25:16 --> Config Class Initialized
INFO - 2018-07-27 02:25:16 --> Hooks Class Initialized
INFO - 2018-07-27 02:25:16 --> Helper loaded: url_helper
DEBUG - 2018-07-27 02:25:16 --> UTF-8 Support Enabled
INFO - 2018-07-27 02:25:16 --> Helper loaded: form_helper
INFO - 2018-07-27 02:25:16 --> Utf8 Class Initialized
INFO - 2018-07-27 02:25:16 --> URI Class Initialized
INFO - 2018-07-27 02:25:16 --> Router Class Initialized
INFO - 2018-07-27 02:25:16 --> Output Class Initialized
INFO - 2018-07-27 02:25:16 --> Security Class Initialized
DEBUG - 2018-07-27 02:25:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 02:25:16 --> Input Class Initialized
INFO - 2018-07-27 02:25:16 --> Language Class Initialized
INFO - 2018-07-27 02:25:16 --> Helper loaded: date_helper
ERROR - 2018-07-27 02:25:16 --> 404 Page Not Found: /index
INFO - 2018-07-27 02:25:16 --> Helper loaded: util_helper
INFO - 2018-07-27 02:25:16 --> Helper loaded: text_helper
INFO - 2018-07-27 02:25:16 --> Config Class Initialized
INFO - 2018-07-27 02:25:16 --> Hooks Class Initialized
INFO - 2018-07-27 02:25:16 --> Helper loaded: string_helper
DEBUG - 2018-07-27 02:25:16 --> UTF-8 Support Enabled
INFO - 2018-07-27 02:25:16 --> Utf8 Class Initialized
INFO - 2018-07-27 02:25:16 --> URI Class Initialized
INFO - 2018-07-27 02:25:16 --> Router Class Initialized
INFO - 2018-07-27 02:25:16 --> Database Driver Class Initialized
INFO - 2018-07-27 02:25:16 --> Output Class Initialized
INFO - 2018-07-27 02:25:16 --> Security Class Initialized
DEBUG - 2018-07-27 02:25:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 02:25:16 --> Input Class Initialized
INFO - 2018-07-27 02:25:16 --> Language Class Initialized
ERROR - 2018-07-27 02:25:16 --> 404 Page Not Found: /index
DEBUG - 2018-07-27 02:25:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 02:25:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 02:25:17 --> Email Class Initialized
INFO - 2018-07-27 02:25:17 --> Controller Class Initialized
DEBUG - 2018-07-27 02:25:17 --> Home MX_Controller Initialized
DEBUG - 2018-07-27 02:25:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-27 02:25:17 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-27 02:25:17 --> Login MX_Controller Initialized
INFO - 2018-07-27 02:25:17 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-27 02:25:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-27 02:25:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-27 02:25:19 --> Config Class Initialized
INFO - 2018-07-27 02:25:19 --> Hooks Class Initialized
DEBUG - 2018-07-27 02:25:19 --> UTF-8 Support Enabled
INFO - 2018-07-27 02:25:19 --> Utf8 Class Initialized
INFO - 2018-07-27 02:25:19 --> URI Class Initialized
INFO - 2018-07-27 02:25:19 --> Router Class Initialized
INFO - 2018-07-27 02:25:19 --> Output Class Initialized
INFO - 2018-07-27 02:25:19 --> Security Class Initialized
DEBUG - 2018-07-27 02:25:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 02:25:19 --> Input Class Initialized
INFO - 2018-07-27 02:25:19 --> Language Class Initialized
INFO - 2018-07-27 02:25:19 --> Language Class Initialized
INFO - 2018-07-27 02:25:19 --> Config Class Initialized
INFO - 2018-07-27 02:25:19 --> Loader Class Initialized
DEBUG - 2018-07-27 02:25:19 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-27 02:25:19 --> Helper loaded: url_helper
INFO - 2018-07-27 02:25:19 --> Helper loaded: form_helper
INFO - 2018-07-27 02:25:19 --> Helper loaded: date_helper
INFO - 2018-07-27 02:25:19 --> Helper loaded: util_helper
INFO - 2018-07-27 02:25:19 --> Helper loaded: text_helper
INFO - 2018-07-27 02:25:19 --> Helper loaded: string_helper
INFO - 2018-07-27 02:25:20 --> Database Driver Class Initialized
DEBUG - 2018-07-27 02:25:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 02:25:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 02:25:20 --> Email Class Initialized
INFO - 2018-07-27 02:25:20 --> Controller Class Initialized
DEBUG - 2018-07-27 02:25:20 --> Login MX_Controller Initialized
INFO - 2018-07-27 02:25:20 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-27 02:25:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-27 02:25:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-27 02:25:20 --> 4 Loggedout
INFO - 2018-07-27 02:25:20 --> Config Class Initialized
INFO - 2018-07-27 02:25:20 --> Hooks Class Initialized
DEBUG - 2018-07-27 02:25:20 --> UTF-8 Support Enabled
INFO - 2018-07-27 02:25:20 --> Utf8 Class Initialized
INFO - 2018-07-27 02:25:20 --> URI Class Initialized
INFO - 2018-07-27 02:25:20 --> Router Class Initialized
INFO - 2018-07-27 02:25:20 --> Output Class Initialized
INFO - 2018-07-27 02:25:20 --> Security Class Initialized
DEBUG - 2018-07-27 02:25:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 02:25:20 --> Input Class Initialized
INFO - 2018-07-27 02:25:20 --> Language Class Initialized
INFO - 2018-07-27 02:25:20 --> Language Class Initialized
INFO - 2018-07-27 02:25:20 --> Config Class Initialized
INFO - 2018-07-27 02:25:20 --> Loader Class Initialized
DEBUG - 2018-07-27 02:25:20 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-27 02:25:20 --> Helper loaded: url_helper
INFO - 2018-07-27 02:25:20 --> Helper loaded: form_helper
INFO - 2018-07-27 02:25:20 --> Helper loaded: date_helper
INFO - 2018-07-27 02:25:20 --> Helper loaded: util_helper
INFO - 2018-07-27 02:25:20 --> Helper loaded: text_helper
INFO - 2018-07-27 02:25:20 --> Helper loaded: string_helper
INFO - 2018-07-27 02:25:20 --> Database Driver Class Initialized
DEBUG - 2018-07-27 02:25:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 02:25:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 02:25:20 --> Email Class Initialized
INFO - 2018-07-27 02:25:20 --> Controller Class Initialized
DEBUG - 2018-07-27 02:25:20 --> Home MX_Controller Initialized
DEBUG - 2018-07-27 02:25:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-27 02:25:20 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-27 02:25:20 --> Login MX_Controller Initialized
INFO - 2018-07-27 02:25:20 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-27 02:25:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-27 02:25:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-27 02:25:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-07-27 02:25:25 --> Config Class Initialized
INFO - 2018-07-27 02:25:25 --> Hooks Class Initialized
DEBUG - 2018-07-27 02:25:25 --> UTF-8 Support Enabled
INFO - 2018-07-27 02:25:25 --> Utf8 Class Initialized
INFO - 2018-07-27 02:25:25 --> URI Class Initialized
INFO - 2018-07-27 02:25:25 --> Router Class Initialized
INFO - 2018-07-27 02:25:25 --> Output Class Initialized
INFO - 2018-07-27 02:25:26 --> Security Class Initialized
DEBUG - 2018-07-27 02:25:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 02:25:26 --> Input Class Initialized
INFO - 2018-07-27 02:25:26 --> Language Class Initialized
INFO - 2018-07-27 02:25:26 --> Language Class Initialized
INFO - 2018-07-27 02:25:26 --> Config Class Initialized
INFO - 2018-07-27 02:25:26 --> Loader Class Initialized
DEBUG - 2018-07-27 02:25:26 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-27 02:25:26 --> Helper loaded: url_helper
INFO - 2018-07-27 02:25:26 --> Helper loaded: form_helper
INFO - 2018-07-27 02:25:26 --> Helper loaded: date_helper
INFO - 2018-07-27 02:25:26 --> Helper loaded: util_helper
INFO - 2018-07-27 02:25:26 --> Helper loaded: text_helper
INFO - 2018-07-27 02:25:26 --> Helper loaded: string_helper
INFO - 2018-07-27 02:25:26 --> Database Driver Class Initialized
DEBUG - 2018-07-27 02:25:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 02:25:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 02:25:26 --> Email Class Initialized
INFO - 2018-07-27 02:25:26 --> Controller Class Initialized
DEBUG - 2018-07-27 02:25:26 --> Login MX_Controller Initialized
INFO - 2018-07-27 02:25:26 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-27 02:25:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-27 02:25:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-27 02:25:26 --> Email starts for colin fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-07-27 02:25:26 --> User session created for 4
INFO - 2018-07-27 02:25:26 --> Login status colin - success
INFO - 2018-07-27 02:25:26 --> Final output sent to browser
DEBUG - 2018-07-27 02:25:26 --> Total execution time: 0.3897
INFO - 2018-07-27 02:25:26 --> Config Class Initialized
INFO - 2018-07-27 02:25:26 --> Hooks Class Initialized
DEBUG - 2018-07-27 02:25:26 --> UTF-8 Support Enabled
INFO - 2018-07-27 02:25:26 --> Utf8 Class Initialized
INFO - 2018-07-27 02:25:26 --> URI Class Initialized
INFO - 2018-07-27 02:25:26 --> Router Class Initialized
INFO - 2018-07-27 02:25:26 --> Output Class Initialized
INFO - 2018-07-27 02:25:26 --> Security Class Initialized
DEBUG - 2018-07-27 02:25:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 02:25:26 --> Input Class Initialized
INFO - 2018-07-27 02:25:26 --> Language Class Initialized
INFO - 2018-07-27 02:25:26 --> Language Class Initialized
INFO - 2018-07-27 02:25:26 --> Config Class Initialized
INFO - 2018-07-27 02:25:26 --> Loader Class Initialized
DEBUG - 2018-07-27 02:25:26 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-27 02:25:26 --> Helper loaded: url_helper
INFO - 2018-07-27 02:25:26 --> Helper loaded: form_helper
INFO - 2018-07-27 02:25:26 --> Helper loaded: date_helper
INFO - 2018-07-27 02:25:26 --> Helper loaded: util_helper
INFO - 2018-07-27 02:25:26 --> Helper loaded: text_helper
INFO - 2018-07-27 02:25:26 --> Helper loaded: string_helper
INFO - 2018-07-27 02:25:26 --> Database Driver Class Initialized
DEBUG - 2018-07-27 02:25:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 02:25:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 02:25:26 --> Email Class Initialized
INFO - 2018-07-27 02:25:26 --> Controller Class Initialized
DEBUG - 2018-07-27 02:25:26 --> Home MX_Controller Initialized
DEBUG - 2018-07-27 02:25:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-27 02:25:26 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-27 02:25:26 --> Login MX_Controller Initialized
INFO - 2018-07-27 02:25:26 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-27 02:25:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-27 02:25:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-27 02:25:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-27 02:25:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-27 02:25:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-27 02:25:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-27 02:25:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-27 02:25:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-27 02:25:26 --> Final output sent to browser
DEBUG - 2018-07-27 02:25:26 --> Total execution time: 0.4461
INFO - 2018-07-27 02:25:27 --> Config Class Initialized
INFO - 2018-07-27 02:25:27 --> Hooks Class Initialized
DEBUG - 2018-07-27 02:25:27 --> UTF-8 Support Enabled
INFO - 2018-07-27 02:25:27 --> Utf8 Class Initialized
INFO - 2018-07-27 02:25:27 --> URI Class Initialized
INFO - 2018-07-27 02:25:27 --> Router Class Initialized
INFO - 2018-07-27 02:25:27 --> Config Class Initialized
INFO - 2018-07-27 02:25:27 --> Hooks Class Initialized
INFO - 2018-07-27 02:25:27 --> Output Class Initialized
DEBUG - 2018-07-27 02:25:27 --> UTF-8 Support Enabled
INFO - 2018-07-27 02:25:27 --> Security Class Initialized
INFO - 2018-07-27 02:25:27 --> Utf8 Class Initialized
DEBUG - 2018-07-27 02:25:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 02:25:27 --> Input Class Initialized
INFO - 2018-07-27 02:25:27 --> URI Class Initialized
INFO - 2018-07-27 02:25:27 --> Router Class Initialized
INFO - 2018-07-27 02:25:27 --> Language Class Initialized
INFO - 2018-07-27 02:25:27 --> Output Class Initialized
ERROR - 2018-07-27 02:25:27 --> 404 Page Not Found: /index
INFO - 2018-07-27 02:25:27 --> Security Class Initialized
INFO - 2018-07-27 02:25:27 --> Config Class Initialized
INFO - 2018-07-27 02:25:27 --> Hooks Class Initialized
DEBUG - 2018-07-27 02:25:27 --> UTF-8 Support Enabled
INFO - 2018-07-27 02:25:27 --> Utf8 Class Initialized
INFO - 2018-07-27 02:25:27 --> URI Class Initialized
DEBUG - 2018-07-27 02:25:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 02:25:27 --> Router Class Initialized
INFO - 2018-07-27 02:25:27 --> Input Class Initialized
INFO - 2018-07-27 02:25:27 --> Language Class Initialized
INFO - 2018-07-27 02:25:27 --> Output Class Initialized
INFO - 2018-07-27 02:25:27 --> Security Class Initialized
INFO - 2018-07-27 02:25:27 --> Language Class Initialized
DEBUG - 2018-07-27 02:25:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 02:25:27 --> Config Class Initialized
INFO - 2018-07-27 02:25:27 --> Input Class Initialized
INFO - 2018-07-27 02:25:27 --> Language Class Initialized
INFO - 2018-07-27 02:25:27 --> Loader Class Initialized
INFO - 2018-07-27 02:25:27 --> Config Class Initialized
ERROR - 2018-07-27 02:25:28 --> 404 Page Not Found: /index
INFO - 2018-07-27 02:25:28 --> Hooks Class Initialized
DEBUG - 2018-07-27 02:25:28 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-27 02:25:28 --> Config Class Initialized
INFO - 2018-07-27 02:25:28 --> Hooks Class Initialized
DEBUG - 2018-07-27 02:25:28 --> UTF-8 Support Enabled
INFO - 2018-07-27 02:25:28 --> Utf8 Class Initialized
DEBUG - 2018-07-27 02:25:28 --> UTF-8 Support Enabled
INFO - 2018-07-27 02:25:28 --> Helper loaded: url_helper
INFO - 2018-07-27 02:25:28 --> Utf8 Class Initialized
INFO - 2018-07-27 02:25:28 --> URI Class Initialized
INFO - 2018-07-27 02:25:28 --> URI Class Initialized
INFO - 2018-07-27 02:25:28 --> Helper loaded: form_helper
INFO - 2018-07-27 02:25:28 --> Router Class Initialized
INFO - 2018-07-27 02:25:28 --> Helper loaded: date_helper
INFO - 2018-07-27 02:25:28 --> Output Class Initialized
INFO - 2018-07-27 02:25:28 --> Router Class Initialized
INFO - 2018-07-27 02:25:28 --> Output Class Initialized
INFO - 2018-07-27 02:25:28 --> Security Class Initialized
INFO - 2018-07-27 02:25:28 --> Helper loaded: util_helper
DEBUG - 2018-07-27 02:25:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 02:25:28 --> Helper loaded: text_helper
INFO - 2018-07-27 02:25:28 --> Security Class Initialized
INFO - 2018-07-27 02:25:28 --> Input Class Initialized
INFO - 2018-07-27 02:25:28 --> Helper loaded: string_helper
DEBUG - 2018-07-27 02:25:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 02:25:28 --> Input Class Initialized
INFO - 2018-07-27 02:25:28 --> Language Class Initialized
INFO - 2018-07-27 02:25:28 --> Database Driver Class Initialized
ERROR - 2018-07-27 02:25:28 --> 404 Page Not Found: /index
INFO - 2018-07-27 02:25:28 --> Language Class Initialized
DEBUG - 2018-07-27 02:25:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 02:25:28 --> Session: Class initialized using 'files' driver.
ERROR - 2018-07-27 02:25:28 --> 404 Page Not Found: /index
INFO - 2018-07-27 02:25:28 --> Config Class Initialized
INFO - 2018-07-27 02:25:28 --> Hooks Class Initialized
INFO - 2018-07-27 02:25:28 --> Email Class Initialized
INFO - 2018-07-27 02:25:28 --> Controller Class Initialized
DEBUG - 2018-07-27 02:25:28 --> UTF-8 Support Enabled
DEBUG - 2018-07-27 02:25:28 --> Home MX_Controller Initialized
INFO - 2018-07-27 02:25:28 --> Utf8 Class Initialized
DEBUG - 2018-07-27 02:25:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-07-27 02:25:28 --> URI Class Initialized
INFO - 2018-07-27 02:25:28 --> Router Class Initialized
DEBUG - 2018-07-27 02:25:28 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-27 02:25:28 --> Login MX_Controller Initialized
INFO - 2018-07-27 02:25:28 --> Output Class Initialized
INFO - 2018-07-27 02:25:28 --> Language file loaded: language/english/data_lang.php
INFO - 2018-07-27 02:25:28 --> Security Class Initialized
DEBUG - 2018-07-27 02:25:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-27 02:25:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 02:25:28 --> Input Class Initialized
DEBUG - 2018-07-27 02:25:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-27 02:25:28 --> Language Class Initialized
ERROR - 2018-07-27 02:25:28 --> 404 Page Not Found: /index
INFO - 2018-07-27 02:25:28 --> Config Class Initialized
INFO - 2018-07-27 02:25:28 --> Hooks Class Initialized
DEBUG - 2018-07-27 02:25:28 --> UTF-8 Support Enabled
INFO - 2018-07-27 02:25:28 --> Utf8 Class Initialized
INFO - 2018-07-27 02:25:28 --> URI Class Initialized
INFO - 2018-07-27 02:25:28 --> Router Class Initialized
INFO - 2018-07-27 02:25:28 --> Output Class Initialized
INFO - 2018-07-27 02:25:28 --> Security Class Initialized
DEBUG - 2018-07-27 02:25:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 02:25:28 --> Input Class Initialized
INFO - 2018-07-27 02:25:28 --> Language Class Initialized
ERROR - 2018-07-27 02:25:28 --> 404 Page Not Found: /index
INFO - 2018-07-27 02:25:28 --> Config Class Initialized
INFO - 2018-07-27 02:25:28 --> Hooks Class Initialized
DEBUG - 2018-07-27 02:25:28 --> UTF-8 Support Enabled
INFO - 2018-07-27 02:25:28 --> Utf8 Class Initialized
INFO - 2018-07-27 02:25:28 --> URI Class Initialized
INFO - 2018-07-27 02:25:28 --> Router Class Initialized
INFO - 2018-07-27 02:25:28 --> Output Class Initialized
INFO - 2018-07-27 02:25:28 --> Security Class Initialized
DEBUG - 2018-07-27 02:25:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 02:25:28 --> Input Class Initialized
INFO - 2018-07-27 02:25:28 --> Language Class Initialized
ERROR - 2018-07-27 02:25:28 --> 404 Page Not Found: /index
INFO - 2018-07-27 02:25:30 --> Config Class Initialized
INFO - 2018-07-27 02:25:30 --> Hooks Class Initialized
DEBUG - 2018-07-27 02:25:30 --> UTF-8 Support Enabled
INFO - 2018-07-27 02:25:30 --> Utf8 Class Initialized
INFO - 2018-07-27 02:25:30 --> URI Class Initialized
INFO - 2018-07-27 02:25:30 --> Router Class Initialized
INFO - 2018-07-27 02:25:30 --> Output Class Initialized
INFO - 2018-07-27 02:25:30 --> Security Class Initialized
DEBUG - 2018-07-27 02:25:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 02:25:30 --> Input Class Initialized
INFO - 2018-07-27 02:25:30 --> Language Class Initialized
INFO - 2018-07-27 02:25:30 --> Language Class Initialized
INFO - 2018-07-27 02:25:30 --> Config Class Initialized
INFO - 2018-07-27 02:25:30 --> Loader Class Initialized
DEBUG - 2018-07-27 02:25:30 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-27 02:25:30 --> Helper loaded: url_helper
INFO - 2018-07-27 02:25:30 --> Helper loaded: form_helper
INFO - 2018-07-27 02:25:31 --> Helper loaded: date_helper
INFO - 2018-07-27 02:25:31 --> Helper loaded: util_helper
INFO - 2018-07-27 02:25:31 --> Helper loaded: text_helper
INFO - 2018-07-27 02:25:31 --> Helper loaded: string_helper
INFO - 2018-07-27 02:25:31 --> Database Driver Class Initialized
DEBUG - 2018-07-27 02:25:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 02:25:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 02:25:31 --> Email Class Initialized
INFO - 2018-07-27 02:25:31 --> Controller Class Initialized
DEBUG - 2018-07-27 02:25:31 --> Profile MX_Controller Initialized
DEBUG - 2018-07-27 02:25:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-27 02:25:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-27 02:25:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-07-27 02:25:31 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-27 02:25:31 --> Login MX_Controller Initialized
INFO - 2018-07-27 02:25:31 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-27 02:25:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-27 02:25:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-27 02:25:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-27 02:25:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-27 02:25:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-07-27 02:25:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-27 02:25:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-27 02:25:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/reset_password.php
INFO - 2018-07-27 02:25:31 --> Final output sent to browser
DEBUG - 2018-07-27 02:25:31 --> Total execution time: 0.6520
INFO - 2018-07-27 02:25:31 --> Config Class Initialized
INFO - 2018-07-27 02:25:31 --> Hooks Class Initialized
DEBUG - 2018-07-27 02:25:31 --> UTF-8 Support Enabled
INFO - 2018-07-27 02:25:31 --> Utf8 Class Initialized
INFO - 2018-07-27 02:25:31 --> URI Class Initialized
INFO - 2018-07-27 02:25:32 --> Router Class Initialized
INFO - 2018-07-27 02:25:32 --> Config Class Initialized
INFO - 2018-07-27 02:25:32 --> Hooks Class Initialized
INFO - 2018-07-27 02:25:32 --> Output Class Initialized
DEBUG - 2018-07-27 02:25:32 --> UTF-8 Support Enabled
INFO - 2018-07-27 02:25:32 --> Utf8 Class Initialized
INFO - 2018-07-27 02:25:32 --> URI Class Initialized
INFO - 2018-07-27 02:25:32 --> Router Class Initialized
INFO - 2018-07-27 02:25:32 --> Output Class Initialized
INFO - 2018-07-27 02:25:32 --> Security Class Initialized
DEBUG - 2018-07-27 02:25:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 02:25:32 --> Input Class Initialized
INFO - 2018-07-27 02:25:32 --> Security Class Initialized
DEBUG - 2018-07-27 02:25:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 02:25:32 --> Input Class Initialized
INFO - 2018-07-27 02:25:32 --> Language Class Initialized
ERROR - 2018-07-27 02:25:32 --> 404 Page Not Found: /index
INFO - 2018-07-27 02:25:32 --> Language Class Initialized
INFO - 2018-07-27 02:25:32 --> Config Class Initialized
INFO - 2018-07-27 02:25:32 --> Hooks Class Initialized
INFO - 2018-07-27 02:25:32 --> Language Class Initialized
DEBUG - 2018-07-27 02:25:32 --> UTF-8 Support Enabled
INFO - 2018-07-27 02:25:32 --> Utf8 Class Initialized
INFO - 2018-07-27 02:25:32 --> URI Class Initialized
INFO - 2018-07-27 02:25:32 --> Config Class Initialized
INFO - 2018-07-27 02:25:32 --> Router Class Initialized
INFO - 2018-07-27 02:25:32 --> Loader Class Initialized
INFO - 2018-07-27 02:25:32 --> Output Class Initialized
DEBUG - 2018-07-27 02:25:32 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-27 02:25:32 --> Security Class Initialized
INFO - 2018-07-27 02:25:32 --> Helper loaded: url_helper
DEBUG - 2018-07-27 02:25:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 02:25:32 --> Helper loaded: form_helper
INFO - 2018-07-27 02:25:32 --> Input Class Initialized
INFO - 2018-07-27 02:25:32 --> Language Class Initialized
INFO - 2018-07-27 02:25:32 --> Helper loaded: date_helper
ERROR - 2018-07-27 02:25:32 --> 404 Page Not Found: /index
INFO - 2018-07-27 02:25:32 --> Helper loaded: util_helper
INFO - 2018-07-27 02:25:32 --> Helper loaded: text_helper
INFO - 2018-07-27 02:25:32 --> Config Class Initialized
INFO - 2018-07-27 02:25:32 --> Hooks Class Initialized
INFO - 2018-07-27 02:25:32 --> Helper loaded: string_helper
DEBUG - 2018-07-27 02:25:32 --> UTF-8 Support Enabled
INFO - 2018-07-27 02:25:32 --> Database Driver Class Initialized
INFO - 2018-07-27 02:25:32 --> Utf8 Class Initialized
INFO - 2018-07-27 02:25:32 --> URI Class Initialized
INFO - 2018-07-27 02:25:32 --> Router Class Initialized
DEBUG - 2018-07-27 02:25:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 02:25:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 02:25:32 --> Output Class Initialized
INFO - 2018-07-27 02:25:32 --> Security Class Initialized
INFO - 2018-07-27 02:25:32 --> Email Class Initialized
INFO - 2018-07-27 02:25:32 --> Controller Class Initialized
DEBUG - 2018-07-27 02:25:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-07-27 02:25:32 --> Home MX_Controller Initialized
INFO - 2018-07-27 02:25:32 --> Input Class Initialized
DEBUG - 2018-07-27 02:25:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-07-27 02:25:32 --> Language Class Initialized
DEBUG - 2018-07-27 02:25:32 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-27 02:25:32 --> Login MX_Controller Initialized
ERROR - 2018-07-27 02:25:32 --> 404 Page Not Found: /index
INFO - 2018-07-27 02:25:32 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-27 02:25:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-27 02:25:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-27 02:26:26 --> Config Class Initialized
INFO - 2018-07-27 02:26:26 --> Hooks Class Initialized
DEBUG - 2018-07-27 02:26:26 --> UTF-8 Support Enabled
INFO - 2018-07-27 02:26:26 --> Utf8 Class Initialized
INFO - 2018-07-27 02:26:26 --> URI Class Initialized
INFO - 2018-07-27 02:26:26 --> Router Class Initialized
INFO - 2018-07-27 02:26:26 --> Output Class Initialized
INFO - 2018-07-27 02:26:26 --> Security Class Initialized
DEBUG - 2018-07-27 02:26:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 02:26:26 --> Input Class Initialized
INFO - 2018-07-27 02:26:26 --> Language Class Initialized
INFO - 2018-07-27 02:26:26 --> Language Class Initialized
INFO - 2018-07-27 02:26:26 --> Config Class Initialized
INFO - 2018-07-27 02:26:26 --> Loader Class Initialized
DEBUG - 2018-07-27 02:26:26 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-27 02:26:26 --> Helper loaded: url_helper
INFO - 2018-07-27 02:26:26 --> Helper loaded: form_helper
INFO - 2018-07-27 02:26:26 --> Helper loaded: date_helper
INFO - 2018-07-27 02:26:26 --> Helper loaded: util_helper
INFO - 2018-07-27 02:26:26 --> Helper loaded: text_helper
INFO - 2018-07-27 02:26:26 --> Helper loaded: string_helper
INFO - 2018-07-27 02:26:26 --> Database Driver Class Initialized
DEBUG - 2018-07-27 02:26:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 02:26:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 02:26:26 --> Email Class Initialized
INFO - 2018-07-27 02:26:26 --> Controller Class Initialized
DEBUG - 2018-07-27 02:26:26 --> Profile MX_Controller Initialized
DEBUG - 2018-07-27 02:26:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-27 02:26:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-27 02:26:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-07-27 02:26:26 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-27 02:26:26 --> Login MX_Controller Initialized
INFO - 2018-07-27 02:26:26 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-27 02:26:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-27 02:26:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-27 02:26:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-27 02:26:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-27 02:26:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-07-27 02:26:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-27 02:26:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-27 02:26:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/reset_password.php
INFO - 2018-07-27 02:26:26 --> Final output sent to browser
DEBUG - 2018-07-27 02:26:26 --> Total execution time: 0.4881
INFO - 2018-07-27 02:26:27 --> Config Class Initialized
INFO - 2018-07-27 02:26:27 --> Hooks Class Initialized
DEBUG - 2018-07-27 02:26:27 --> UTF-8 Support Enabled
INFO - 2018-07-27 02:26:27 --> Utf8 Class Initialized
INFO - 2018-07-27 02:26:27 --> Config Class Initialized
INFO - 2018-07-27 02:26:27 --> Hooks Class Initialized
INFO - 2018-07-27 02:26:27 --> URI Class Initialized
DEBUG - 2018-07-27 02:26:27 --> UTF-8 Support Enabled
INFO - 2018-07-27 02:26:27 --> Utf8 Class Initialized
INFO - 2018-07-27 02:26:27 --> URI Class Initialized
INFO - 2018-07-27 02:26:27 --> Router Class Initialized
INFO - 2018-07-27 02:26:27 --> Output Class Initialized
INFO - 2018-07-27 02:26:27 --> Router Class Initialized
INFO - 2018-07-27 02:26:27 --> Output Class Initialized
INFO - 2018-07-27 02:26:27 --> Security Class Initialized
INFO - 2018-07-27 02:26:27 --> Security Class Initialized
DEBUG - 2018-07-27 02:26:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 02:26:27 --> Input Class Initialized
INFO - 2018-07-27 02:26:27 --> Language Class Initialized
ERROR - 2018-07-27 02:26:27 --> 404 Page Not Found: /index
DEBUG - 2018-07-27 02:26:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 02:26:27 --> Input Class Initialized
INFO - 2018-07-27 02:26:27 --> Language Class Initialized
INFO - 2018-07-27 02:26:27 --> Config Class Initialized
INFO - 2018-07-27 02:26:27 --> Hooks Class Initialized
INFO - 2018-07-27 02:26:27 --> Language Class Initialized
DEBUG - 2018-07-27 02:26:27 --> UTF-8 Support Enabled
INFO - 2018-07-27 02:26:27 --> Utf8 Class Initialized
INFO - 2018-07-27 02:26:27 --> URI Class Initialized
INFO - 2018-07-27 02:26:27 --> Config Class Initialized
INFO - 2018-07-27 02:26:27 --> Router Class Initialized
INFO - 2018-07-27 02:26:27 --> Loader Class Initialized
DEBUG - 2018-07-27 02:26:27 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-27 02:26:27 --> Output Class Initialized
INFO - 2018-07-27 02:26:27 --> Helper loaded: url_helper
INFO - 2018-07-27 02:26:27 --> Security Class Initialized
INFO - 2018-07-27 02:26:27 --> Helper loaded: form_helper
DEBUG - 2018-07-27 02:26:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 02:26:27 --> Input Class Initialized
INFO - 2018-07-27 02:26:27 --> Helper loaded: date_helper
INFO - 2018-07-27 02:26:27 --> Helper loaded: util_helper
INFO - 2018-07-27 02:26:27 --> Language Class Initialized
INFO - 2018-07-27 02:26:27 --> Helper loaded: text_helper
ERROR - 2018-07-27 02:26:27 --> 404 Page Not Found: /index
INFO - 2018-07-27 02:26:27 --> Helper loaded: string_helper
INFO - 2018-07-27 02:26:27 --> Config Class Initialized
INFO - 2018-07-27 02:26:28 --> Hooks Class Initialized
INFO - 2018-07-27 02:26:28 --> Database Driver Class Initialized
DEBUG - 2018-07-27 02:26:28 --> UTF-8 Support Enabled
DEBUG - 2018-07-27 02:26:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 02:26:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 02:26:28 --> Utf8 Class Initialized
INFO - 2018-07-27 02:26:28 --> URI Class Initialized
INFO - 2018-07-27 02:26:28 --> Email Class Initialized
INFO - 2018-07-27 02:26:28 --> Controller Class Initialized
INFO - 2018-07-27 02:26:28 --> Router Class Initialized
DEBUG - 2018-07-27 02:26:28 --> Home MX_Controller Initialized
INFO - 2018-07-27 02:26:28 --> Output Class Initialized
DEBUG - 2018-07-27 02:26:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-07-27 02:26:28 --> Security Class Initialized
DEBUG - 2018-07-27 02:26:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-07-27 02:26:28 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-27 02:26:28 --> Login MX_Controller Initialized
INFO - 2018-07-27 02:26:28 --> Input Class Initialized
INFO - 2018-07-27 02:26:28 --> Language file loaded: language/english/data_lang.php
INFO - 2018-07-27 02:26:28 --> Language Class Initialized
DEBUG - 2018-07-27 02:26:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
ERROR - 2018-07-27 02:26:28 --> 404 Page Not Found: /index
DEBUG - 2018-07-27 02:26:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-27 02:26:50 --> Config Class Initialized
INFO - 2018-07-27 02:26:50 --> Hooks Class Initialized
DEBUG - 2018-07-27 02:26:50 --> UTF-8 Support Enabled
INFO - 2018-07-27 02:26:50 --> Utf8 Class Initialized
INFO - 2018-07-27 02:26:50 --> URI Class Initialized
INFO - 2018-07-27 02:26:50 --> Router Class Initialized
INFO - 2018-07-27 02:26:50 --> Output Class Initialized
INFO - 2018-07-27 02:26:50 --> Security Class Initialized
DEBUG - 2018-07-27 02:26:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 02:26:50 --> Input Class Initialized
INFO - 2018-07-27 02:26:50 --> Language Class Initialized
INFO - 2018-07-27 02:26:50 --> Language Class Initialized
INFO - 2018-07-27 02:26:50 --> Config Class Initialized
INFO - 2018-07-27 02:26:50 --> Loader Class Initialized
DEBUG - 2018-07-27 02:26:50 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-27 02:26:50 --> Helper loaded: url_helper
INFO - 2018-07-27 02:26:50 --> Helper loaded: form_helper
INFO - 2018-07-27 02:26:50 --> Helper loaded: date_helper
INFO - 2018-07-27 02:26:50 --> Helper loaded: util_helper
INFO - 2018-07-27 02:26:50 --> Helper loaded: text_helper
INFO - 2018-07-27 02:26:50 --> Helper loaded: string_helper
INFO - 2018-07-27 02:26:50 --> Database Driver Class Initialized
DEBUG - 2018-07-27 02:26:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 02:26:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 02:26:50 --> Email Class Initialized
INFO - 2018-07-27 02:26:50 --> Controller Class Initialized
DEBUG - 2018-07-27 02:26:50 --> Profile MX_Controller Initialized
DEBUG - 2018-07-27 02:26:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-27 02:26:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-27 02:26:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-07-27 02:26:50 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-27 02:26:50 --> Login MX_Controller Initialized
INFO - 2018-07-27 02:26:50 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-27 02:26:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-27 02:26:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-27 02:26:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
INFO - 2018-07-27 02:28:04 --> Config Class Initialized
INFO - 2018-07-27 02:28:04 --> Hooks Class Initialized
DEBUG - 2018-07-27 02:28:04 --> UTF-8 Support Enabled
INFO - 2018-07-27 02:28:04 --> Utf8 Class Initialized
INFO - 2018-07-27 02:28:04 --> URI Class Initialized
INFO - 2018-07-27 02:28:04 --> Router Class Initialized
INFO - 2018-07-27 02:28:04 --> Output Class Initialized
INFO - 2018-07-27 02:28:04 --> Security Class Initialized
DEBUG - 2018-07-27 02:28:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 02:28:04 --> Input Class Initialized
INFO - 2018-07-27 02:28:04 --> Language Class Initialized
INFO - 2018-07-27 02:28:04 --> Language Class Initialized
INFO - 2018-07-27 02:28:04 --> Config Class Initialized
INFO - 2018-07-27 02:28:04 --> Loader Class Initialized
DEBUG - 2018-07-27 02:28:04 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-27 02:28:04 --> Helper loaded: url_helper
INFO - 2018-07-27 02:28:04 --> Helper loaded: form_helper
INFO - 2018-07-27 02:28:04 --> Helper loaded: date_helper
INFO - 2018-07-27 02:28:04 --> Helper loaded: util_helper
INFO - 2018-07-27 02:28:04 --> Helper loaded: text_helper
INFO - 2018-07-27 02:28:05 --> Helper loaded: string_helper
INFO - 2018-07-27 02:28:05 --> Database Driver Class Initialized
DEBUG - 2018-07-27 02:28:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 02:28:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 02:28:05 --> Email Class Initialized
INFO - 2018-07-27 02:28:05 --> Controller Class Initialized
DEBUG - 2018-07-27 02:28:05 --> Profile MX_Controller Initialized
DEBUG - 2018-07-27 02:28:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-27 02:28:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-27 02:28:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-07-27 02:28:05 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-27 02:28:05 --> Login MX_Controller Initialized
INFO - 2018-07-27 02:28:05 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-27 02:28:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-27 02:28:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-27 02:28:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
INFO - 2018-07-27 02:28:14 --> Config Class Initialized
INFO - 2018-07-27 02:28:14 --> Hooks Class Initialized
DEBUG - 2018-07-27 02:28:14 --> UTF-8 Support Enabled
INFO - 2018-07-27 02:28:14 --> Utf8 Class Initialized
INFO - 2018-07-27 02:28:14 --> URI Class Initialized
INFO - 2018-07-27 02:28:14 --> Router Class Initialized
INFO - 2018-07-27 02:28:14 --> Output Class Initialized
INFO - 2018-07-27 02:28:14 --> Security Class Initialized
DEBUG - 2018-07-27 02:28:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 02:28:14 --> Input Class Initialized
INFO - 2018-07-27 02:28:14 --> Language Class Initialized
INFO - 2018-07-27 02:28:14 --> Language Class Initialized
INFO - 2018-07-27 02:28:14 --> Config Class Initialized
INFO - 2018-07-27 02:28:14 --> Loader Class Initialized
DEBUG - 2018-07-27 02:28:14 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-27 02:28:14 --> Helper loaded: url_helper
INFO - 2018-07-27 02:28:14 --> Helper loaded: form_helper
INFO - 2018-07-27 02:28:14 --> Helper loaded: date_helper
INFO - 2018-07-27 02:28:14 --> Helper loaded: util_helper
INFO - 2018-07-27 02:28:14 --> Helper loaded: text_helper
INFO - 2018-07-27 02:28:14 --> Helper loaded: string_helper
INFO - 2018-07-27 02:28:15 --> Database Driver Class Initialized
DEBUG - 2018-07-27 02:28:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 02:28:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 02:28:15 --> Email Class Initialized
INFO - 2018-07-27 02:28:15 --> Controller Class Initialized
DEBUG - 2018-07-27 02:28:15 --> Profile MX_Controller Initialized
DEBUG - 2018-07-27 02:28:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-27 02:28:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-27 02:28:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-07-27 02:28:15 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-27 02:28:15 --> Login MX_Controller Initialized
INFO - 2018-07-27 02:28:15 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-27 02:28:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-27 02:28:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-27 02:28:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-27 02:28:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-27 02:28:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-07-27 02:28:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-27 02:28:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-27 02:28:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/reset_password.php
INFO - 2018-07-27 02:28:15 --> Final output sent to browser
DEBUG - 2018-07-27 02:28:15 --> Total execution time: 0.4899
INFO - 2018-07-27 02:28:18 --> Config Class Initialized
INFO - 2018-07-27 02:28:18 --> Hooks Class Initialized
DEBUG - 2018-07-27 02:28:18 --> UTF-8 Support Enabled
INFO - 2018-07-27 02:28:18 --> Utf8 Class Initialized
INFO - 2018-07-27 02:28:18 --> URI Class Initialized
INFO - 2018-07-27 02:28:18 --> Router Class Initialized
INFO - 2018-07-27 02:28:18 --> Output Class Initialized
INFO - 2018-07-27 02:28:18 --> Security Class Initialized
DEBUG - 2018-07-27 02:28:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 02:28:18 --> Input Class Initialized
INFO - 2018-07-27 02:28:18 --> Language Class Initialized
INFO - 2018-07-27 02:28:18 --> Language Class Initialized
INFO - 2018-07-27 02:28:18 --> Config Class Initialized
INFO - 2018-07-27 02:28:18 --> Loader Class Initialized
DEBUG - 2018-07-27 02:28:18 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-27 02:28:18 --> Helper loaded: url_helper
INFO - 2018-07-27 02:28:18 --> Helper loaded: form_helper
INFO - 2018-07-27 02:28:18 --> Helper loaded: date_helper
INFO - 2018-07-27 02:28:18 --> Helper loaded: util_helper
INFO - 2018-07-27 02:28:18 --> Helper loaded: text_helper
INFO - 2018-07-27 02:28:18 --> Helper loaded: string_helper
INFO - 2018-07-27 02:28:18 --> Database Driver Class Initialized
DEBUG - 2018-07-27 02:28:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 02:28:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 02:28:18 --> Email Class Initialized
INFO - 2018-07-27 02:28:18 --> Controller Class Initialized
DEBUG - 2018-07-27 02:28:18 --> Profile MX_Controller Initialized
DEBUG - 2018-07-27 02:28:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-27 02:28:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-27 02:28:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-07-27 02:28:18 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-27 02:28:18 --> Login MX_Controller Initialized
INFO - 2018-07-27 02:28:18 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-27 02:28:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-27 02:28:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-27 02:28:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-27 02:28:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-27 02:28:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-07-27 02:28:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-27 02:28:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-27 02:28:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/reset_password.php
INFO - 2018-07-27 02:28:19 --> Final output sent to browser
DEBUG - 2018-07-27 02:28:19 --> Total execution time: 0.5048
INFO - 2018-07-27 02:28:19 --> Config Class Initialized
INFO - 2018-07-27 02:28:19 --> Hooks Class Initialized
DEBUG - 2018-07-27 02:28:19 --> UTF-8 Support Enabled
INFO - 2018-07-27 02:28:19 --> Utf8 Class Initialized
INFO - 2018-07-27 02:28:19 --> URI Class Initialized
INFO - 2018-07-27 02:28:19 --> Router Class Initialized
INFO - 2018-07-27 02:28:19 --> Config Class Initialized
INFO - 2018-07-27 02:28:19 --> Output Class Initialized
INFO - 2018-07-27 02:28:19 --> Hooks Class Initialized
INFO - 2018-07-27 02:28:19 --> Security Class Initialized
DEBUG - 2018-07-27 02:28:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-07-27 02:28:19 --> UTF-8 Support Enabled
INFO - 2018-07-27 02:28:19 --> Input Class Initialized
INFO - 2018-07-27 02:28:19 --> Utf8 Class Initialized
INFO - 2018-07-27 02:28:19 --> Language Class Initialized
INFO - 2018-07-27 02:28:19 --> URI Class Initialized
ERROR - 2018-07-27 02:28:19 --> 404 Page Not Found: /index
INFO - 2018-07-27 02:28:19 --> Router Class Initialized
INFO - 2018-07-27 02:28:19 --> Output Class Initialized
INFO - 2018-07-27 02:28:19 --> Security Class Initialized
DEBUG - 2018-07-27 02:28:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 02:28:19 --> Input Class Initialized
INFO - 2018-07-27 02:28:19 --> Language Class Initialized
INFO - 2018-07-27 02:28:19 --> Config Class Initialized
INFO - 2018-07-27 02:28:19 --> Language Class Initialized
INFO - 2018-07-27 02:28:20 --> Hooks Class Initialized
DEBUG - 2018-07-27 02:28:20 --> UTF-8 Support Enabled
INFO - 2018-07-27 02:28:20 --> Utf8 Class Initialized
INFO - 2018-07-27 02:28:20 --> URI Class Initialized
INFO - 2018-07-27 02:28:20 --> Router Class Initialized
INFO - 2018-07-27 02:28:20 --> Config Class Initialized
INFO - 2018-07-27 02:28:20 --> Output Class Initialized
INFO - 2018-07-27 02:28:20 --> Loader Class Initialized
INFO - 2018-07-27 02:28:20 --> Security Class Initialized
DEBUG - 2018-07-27 02:28:20 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
DEBUG - 2018-07-27 02:28:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 02:28:20 --> Helper loaded: url_helper
INFO - 2018-07-27 02:28:20 --> Input Class Initialized
INFO - 2018-07-27 02:28:20 --> Helper loaded: form_helper
INFO - 2018-07-27 02:28:20 --> Language Class Initialized
INFO - 2018-07-27 02:28:20 --> Helper loaded: date_helper
INFO - 2018-07-27 02:28:20 --> Helper loaded: util_helper
ERROR - 2018-07-27 02:28:20 --> 404 Page Not Found: /index
INFO - 2018-07-27 02:28:20 --> Helper loaded: text_helper
INFO - 2018-07-27 02:28:20 --> Config Class Initialized
INFO - 2018-07-27 02:28:20 --> Hooks Class Initialized
INFO - 2018-07-27 02:28:20 --> Helper loaded: string_helper
DEBUG - 2018-07-27 02:28:20 --> UTF-8 Support Enabled
INFO - 2018-07-27 02:28:20 --> Database Driver Class Initialized
INFO - 2018-07-27 02:28:20 --> Utf8 Class Initialized
DEBUG - 2018-07-27 02:28:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 02:28:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 02:28:20 --> URI Class Initialized
INFO - 2018-07-27 02:28:20 --> Email Class Initialized
INFO - 2018-07-27 02:28:20 --> Router Class Initialized
INFO - 2018-07-27 02:28:20 --> Controller Class Initialized
INFO - 2018-07-27 02:28:20 --> Output Class Initialized
DEBUG - 2018-07-27 02:28:20 --> Home MX_Controller Initialized
INFO - 2018-07-27 02:28:20 --> Security Class Initialized
DEBUG - 2018-07-27 02:28:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-27 02:28:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 02:28:20 --> Input Class Initialized
DEBUG - 2018-07-27 02:28:20 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-27 02:28:20 --> Login MX_Controller Initialized
INFO - 2018-07-27 02:28:20 --> Language Class Initialized
INFO - 2018-07-27 02:28:20 --> Language file loaded: language/english/data_lang.php
ERROR - 2018-07-27 02:28:20 --> 404 Page Not Found: /index
DEBUG - 2018-07-27 02:28:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-27 02:28:20 --> Config Class Initialized
INFO - 2018-07-27 02:28:20 --> Hooks Class Initialized
DEBUG - 2018-07-27 02:28:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-27 02:28:20 --> UTF-8 Support Enabled
INFO - 2018-07-27 02:28:20 --> Utf8 Class Initialized
INFO - 2018-07-27 02:28:20 --> URI Class Initialized
INFO - 2018-07-27 02:28:20 --> Router Class Initialized
INFO - 2018-07-27 02:28:20 --> Output Class Initialized
INFO - 2018-07-27 02:28:20 --> Security Class Initialized
DEBUG - 2018-07-27 02:28:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 02:28:20 --> Input Class Initialized
INFO - 2018-07-27 02:28:20 --> Language Class Initialized
ERROR - 2018-07-27 02:28:20 --> 404 Page Not Found: /index
INFO - 2018-07-27 02:28:20 --> Config Class Initialized
INFO - 2018-07-27 02:28:20 --> Hooks Class Initialized
DEBUG - 2018-07-27 02:28:20 --> UTF-8 Support Enabled
INFO - 2018-07-27 02:28:20 --> Utf8 Class Initialized
INFO - 2018-07-27 02:28:20 --> URI Class Initialized
INFO - 2018-07-27 02:28:20 --> Router Class Initialized
INFO - 2018-07-27 02:28:20 --> Output Class Initialized
INFO - 2018-07-27 02:28:20 --> Security Class Initialized
DEBUG - 2018-07-27 02:28:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 02:28:20 --> Input Class Initialized
INFO - 2018-07-27 02:28:20 --> Language Class Initialized
ERROR - 2018-07-27 02:28:20 --> 404 Page Not Found: /index
INFO - 2018-07-27 02:28:20 --> Config Class Initialized
INFO - 2018-07-27 02:28:20 --> Hooks Class Initialized
DEBUG - 2018-07-27 02:28:20 --> UTF-8 Support Enabled
INFO - 2018-07-27 02:28:20 --> Utf8 Class Initialized
INFO - 2018-07-27 02:28:20 --> URI Class Initialized
INFO - 2018-07-27 02:28:20 --> Router Class Initialized
INFO - 2018-07-27 02:28:20 --> Output Class Initialized
INFO - 2018-07-27 02:28:20 --> Security Class Initialized
DEBUG - 2018-07-27 02:28:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 02:28:20 --> Input Class Initialized
INFO - 2018-07-27 02:28:20 --> Language Class Initialized
ERROR - 2018-07-27 02:28:20 --> 404 Page Not Found: /index
INFO - 2018-07-27 02:30:36 --> Config Class Initialized
INFO - 2018-07-27 02:30:36 --> Hooks Class Initialized
DEBUG - 2018-07-27 02:30:36 --> UTF-8 Support Enabled
INFO - 2018-07-27 02:30:36 --> Utf8 Class Initialized
INFO - 2018-07-27 02:30:36 --> URI Class Initialized
INFO - 2018-07-27 02:30:36 --> Router Class Initialized
INFO - 2018-07-27 02:30:36 --> Output Class Initialized
INFO - 2018-07-27 02:30:36 --> Security Class Initialized
DEBUG - 2018-07-27 02:30:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 02:30:36 --> Input Class Initialized
INFO - 2018-07-27 02:30:36 --> Language Class Initialized
INFO - 2018-07-27 02:30:36 --> Language Class Initialized
INFO - 2018-07-27 02:30:36 --> Config Class Initialized
INFO - 2018-07-27 02:30:36 --> Loader Class Initialized
DEBUG - 2018-07-27 02:30:36 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-27 02:30:36 --> Helper loaded: url_helper
INFO - 2018-07-27 02:30:36 --> Helper loaded: form_helper
INFO - 2018-07-27 02:30:36 --> Helper loaded: date_helper
INFO - 2018-07-27 02:30:36 --> Helper loaded: util_helper
INFO - 2018-07-27 02:30:36 --> Helper loaded: text_helper
INFO - 2018-07-27 02:30:36 --> Helper loaded: string_helper
INFO - 2018-07-27 02:30:36 --> Database Driver Class Initialized
DEBUG - 2018-07-27 02:30:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 02:30:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 02:30:36 --> Email Class Initialized
INFO - 2018-07-27 02:30:36 --> Controller Class Initialized
DEBUG - 2018-07-27 02:30:36 --> Profile MX_Controller Initialized
DEBUG - 2018-07-27 02:30:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-27 02:30:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-27 02:30:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-07-27 02:30:36 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-27 02:30:36 --> Login MX_Controller Initialized
INFO - 2018-07-27 02:30:36 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-27 02:30:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-27 02:30:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-27 02:30:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-27 02:30:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-27 02:30:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-07-27 02:30:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-27 02:30:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-27 02:30:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/reset_password.php
INFO - 2018-07-27 02:30:36 --> Final output sent to browser
DEBUG - 2018-07-27 02:30:36 --> Total execution time: 0.5071
INFO - 2018-07-27 02:30:37 --> Config Class Initialized
INFO - 2018-07-27 02:30:37 --> Hooks Class Initialized
DEBUG - 2018-07-27 02:30:37 --> UTF-8 Support Enabled
INFO - 2018-07-27 02:30:37 --> Utf8 Class Initialized
INFO - 2018-07-27 02:30:37 --> URI Class Initialized
INFO - 2018-07-27 02:30:37 --> Router Class Initialized
INFO - 2018-07-27 02:30:37 --> Config Class Initialized
INFO - 2018-07-27 02:30:37 --> Hooks Class Initialized
INFO - 2018-07-27 02:30:37 --> Output Class Initialized
INFO - 2018-07-27 02:30:37 --> Security Class Initialized
DEBUG - 2018-07-27 02:30:37 --> UTF-8 Support Enabled
INFO - 2018-07-27 02:30:37 --> Utf8 Class Initialized
DEBUG - 2018-07-27 02:30:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 02:30:37 --> Input Class Initialized
INFO - 2018-07-27 02:30:37 --> URI Class Initialized
INFO - 2018-07-27 02:30:37 --> Router Class Initialized
INFO - 2018-07-27 02:30:37 --> Language Class Initialized
INFO - 2018-07-27 02:30:37 --> Output Class Initialized
INFO - 2018-07-27 02:30:37 --> Security Class Initialized
DEBUG - 2018-07-27 02:30:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 02:30:37 --> Input Class Initialized
INFO - 2018-07-27 02:30:37 --> Language Class Initialized
INFO - 2018-07-27 02:30:37 --> Language Class Initialized
INFO - 2018-07-27 02:30:37 --> Config Class Initialized
INFO - 2018-07-27 02:30:37 --> Loader Class Initialized
DEBUG - 2018-07-27 02:30:37 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
ERROR - 2018-07-27 02:30:37 --> 404 Page Not Found: /index
INFO - 2018-07-27 02:30:37 --> Helper loaded: url_helper
INFO - 2018-07-27 02:30:37 --> Helper loaded: form_helper
INFO - 2018-07-27 02:30:37 --> Helper loaded: date_helper
INFO - 2018-07-27 02:30:37 --> Config Class Initialized
INFO - 2018-07-27 02:30:37 --> Helper loaded: util_helper
INFO - 2018-07-27 02:30:37 --> Hooks Class Initialized
DEBUG - 2018-07-27 02:30:37 --> UTF-8 Support Enabled
INFO - 2018-07-27 02:30:37 --> Utf8 Class Initialized
INFO - 2018-07-27 02:30:37 --> URI Class Initialized
INFO - 2018-07-27 02:30:37 --> Router Class Initialized
INFO - 2018-07-27 02:30:37 --> Output Class Initialized
INFO - 2018-07-27 02:30:37 --> Security Class Initialized
DEBUG - 2018-07-27 02:30:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 02:30:37 --> Input Class Initialized
INFO - 2018-07-27 02:30:37 --> Language Class Initialized
ERROR - 2018-07-27 02:30:38 --> 404 Page Not Found: /index
INFO - 2018-07-27 02:30:38 --> Config Class Initialized
INFO - 2018-07-27 02:30:38 --> Helper loaded: text_helper
INFO - 2018-07-27 02:30:38 --> Hooks Class Initialized
INFO - 2018-07-27 02:30:38 --> Helper loaded: string_helper
DEBUG - 2018-07-27 02:30:38 --> UTF-8 Support Enabled
INFO - 2018-07-27 02:30:38 --> Database Driver Class Initialized
INFO - 2018-07-27 02:30:38 --> Utf8 Class Initialized
INFO - 2018-07-27 02:30:38 --> URI Class Initialized
INFO - 2018-07-27 02:30:38 --> Router Class Initialized
DEBUG - 2018-07-27 02:30:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 02:30:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 02:30:38 --> Output Class Initialized
INFO - 2018-07-27 02:30:38 --> Email Class Initialized
INFO - 2018-07-27 02:30:38 --> Security Class Initialized
INFO - 2018-07-27 02:30:38 --> Controller Class Initialized
DEBUG - 2018-07-27 02:30:38 --> Home MX_Controller Initialized
DEBUG - 2018-07-27 02:30:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-27 02:30:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-07-27 02:30:38 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-27 02:30:38 --> Login MX_Controller Initialized
INFO - 2018-07-27 02:30:38 --> Input Class Initialized
INFO - 2018-07-27 02:30:38 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-27 02:30:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-27 02:30:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-27 02:30:38 --> Language Class Initialized
ERROR - 2018-07-27 02:30:38 --> 404 Page Not Found: /index
INFO - 2018-07-27 02:34:08 --> Config Class Initialized
INFO - 2018-07-27 02:34:08 --> Hooks Class Initialized
DEBUG - 2018-07-27 02:34:08 --> UTF-8 Support Enabled
INFO - 2018-07-27 02:34:08 --> Utf8 Class Initialized
INFO - 2018-07-27 02:34:08 --> URI Class Initialized
INFO - 2018-07-27 02:34:08 --> Router Class Initialized
INFO - 2018-07-27 02:34:08 --> Output Class Initialized
INFO - 2018-07-27 02:34:08 --> Security Class Initialized
DEBUG - 2018-07-27 02:34:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 02:34:08 --> Input Class Initialized
INFO - 2018-07-27 02:34:08 --> Language Class Initialized
INFO - 2018-07-27 02:34:08 --> Language Class Initialized
INFO - 2018-07-27 02:34:08 --> Config Class Initialized
INFO - 2018-07-27 02:34:08 --> Loader Class Initialized
DEBUG - 2018-07-27 02:34:08 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-27 02:34:08 --> Helper loaded: url_helper
INFO - 2018-07-27 02:34:08 --> Helper loaded: form_helper
INFO - 2018-07-27 02:34:08 --> Helper loaded: date_helper
INFO - 2018-07-27 02:34:08 --> Helper loaded: util_helper
INFO - 2018-07-27 02:34:08 --> Helper loaded: text_helper
INFO - 2018-07-27 02:34:08 --> Helper loaded: string_helper
INFO - 2018-07-27 02:34:08 --> Database Driver Class Initialized
DEBUG - 2018-07-27 02:34:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 02:34:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 02:34:08 --> Email Class Initialized
INFO - 2018-07-27 02:34:08 --> Controller Class Initialized
DEBUG - 2018-07-27 02:34:08 --> Profile MX_Controller Initialized
DEBUG - 2018-07-27 02:34:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-27 02:34:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-27 02:34:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-07-27 02:34:08 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-27 02:34:08 --> Login MX_Controller Initialized
INFO - 2018-07-27 02:34:08 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-27 02:34:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-27 02:34:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-27 02:34:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-27 02:34:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-27 02:34:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-07-27 02:34:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-27 02:34:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-27 02:34:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/reset_password.php
INFO - 2018-07-27 02:34:08 --> Final output sent to browser
DEBUG - 2018-07-27 02:34:08 --> Total execution time: 0.5008
INFO - 2018-07-27 02:34:09 --> Config Class Initialized
INFO - 2018-07-27 02:34:09 --> Hooks Class Initialized
DEBUG - 2018-07-27 02:34:09 --> UTF-8 Support Enabled
INFO - 2018-07-27 02:34:09 --> Utf8 Class Initialized
INFO - 2018-07-27 02:34:09 --> URI Class Initialized
INFO - 2018-07-27 02:34:09 --> Config Class Initialized
INFO - 2018-07-27 02:34:09 --> Hooks Class Initialized
INFO - 2018-07-27 02:34:09 --> Router Class Initialized
DEBUG - 2018-07-27 02:34:09 --> UTF-8 Support Enabled
INFO - 2018-07-27 02:34:09 --> Output Class Initialized
INFO - 2018-07-27 02:34:09 --> Utf8 Class Initialized
INFO - 2018-07-27 02:34:09 --> URI Class Initialized
INFO - 2018-07-27 02:34:09 --> Security Class Initialized
INFO - 2018-07-27 02:34:09 --> Router Class Initialized
DEBUG - 2018-07-27 02:34:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 02:34:09 --> Output Class Initialized
INFO - 2018-07-27 02:34:09 --> Security Class Initialized
INFO - 2018-07-27 02:34:09 --> Input Class Initialized
INFO - 2018-07-27 02:34:09 --> Language Class Initialized
DEBUG - 2018-07-27 02:34:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-07-27 02:34:09 --> 404 Page Not Found: /index
INFO - 2018-07-27 02:34:09 --> Input Class Initialized
INFO - 2018-07-27 02:34:09 --> Config Class Initialized
INFO - 2018-07-27 02:34:09 --> Language Class Initialized
INFO - 2018-07-27 02:34:09 --> Hooks Class Initialized
INFO - 2018-07-27 02:34:09 --> Language Class Initialized
INFO - 2018-07-27 02:34:09 --> Config Class Initialized
DEBUG - 2018-07-27 02:34:09 --> UTF-8 Support Enabled
INFO - 2018-07-27 02:34:09 --> Utf8 Class Initialized
INFO - 2018-07-27 02:34:09 --> Loader Class Initialized
INFO - 2018-07-27 02:34:09 --> URI Class Initialized
INFO - 2018-07-27 02:34:09 --> Router Class Initialized
INFO - 2018-07-27 02:34:09 --> Output Class Initialized
INFO - 2018-07-27 02:34:09 --> Security Class Initialized
DEBUG - 2018-07-27 02:34:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 02:34:09 --> Input Class Initialized
INFO - 2018-07-27 02:34:09 --> Language Class Initialized
ERROR - 2018-07-27 02:34:09 --> 404 Page Not Found: /index
DEBUG - 2018-07-27 02:34:09 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-27 02:34:09 --> Helper loaded: url_helper
INFO - 2018-07-27 02:34:09 --> Helper loaded: form_helper
INFO - 2018-07-27 02:34:09 --> Config Class Initialized
INFO - 2018-07-27 02:34:09 --> Hooks Class Initialized
INFO - 2018-07-27 02:34:09 --> Helper loaded: date_helper
DEBUG - 2018-07-27 02:34:10 --> UTF-8 Support Enabled
INFO - 2018-07-27 02:34:10 --> Utf8 Class Initialized
INFO - 2018-07-27 02:34:10 --> URI Class Initialized
INFO - 2018-07-27 02:34:10 --> Router Class Initialized
INFO - 2018-07-27 02:34:10 --> Output Class Initialized
INFO - 2018-07-27 02:34:10 --> Security Class Initialized
DEBUG - 2018-07-27 02:34:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 02:34:10 --> Input Class Initialized
INFO - 2018-07-27 02:34:10 --> Helper loaded: util_helper
INFO - 2018-07-27 02:34:10 --> Language Class Initialized
INFO - 2018-07-27 02:34:10 --> Helper loaded: text_helper
INFO - 2018-07-27 02:34:10 --> Helper loaded: string_helper
ERROR - 2018-07-27 02:34:10 --> 404 Page Not Found: /index
INFO - 2018-07-27 02:34:10 --> Database Driver Class Initialized
DEBUG - 2018-07-27 02:34:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 02:34:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 02:34:10 --> Email Class Initialized
INFO - 2018-07-27 02:34:10 --> Controller Class Initialized
DEBUG - 2018-07-27 02:34:10 --> Home MX_Controller Initialized
DEBUG - 2018-07-27 02:34:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-27 02:34:10 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-27 02:34:10 --> Login MX_Controller Initialized
INFO - 2018-07-27 02:34:10 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-27 02:34:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-27 02:34:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-27 02:35:01 --> Config Class Initialized
INFO - 2018-07-27 02:35:01 --> Hooks Class Initialized
DEBUG - 2018-07-27 02:35:01 --> UTF-8 Support Enabled
INFO - 2018-07-27 02:35:01 --> Utf8 Class Initialized
INFO - 2018-07-27 02:35:01 --> URI Class Initialized
INFO - 2018-07-27 02:35:01 --> Router Class Initialized
INFO - 2018-07-27 02:35:01 --> Output Class Initialized
INFO - 2018-07-27 02:35:01 --> Security Class Initialized
DEBUG - 2018-07-27 02:35:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 02:35:01 --> Input Class Initialized
INFO - 2018-07-27 02:35:01 --> Language Class Initialized
INFO - 2018-07-27 02:35:01 --> Language Class Initialized
INFO - 2018-07-27 02:35:01 --> Config Class Initialized
INFO - 2018-07-27 02:35:01 --> Loader Class Initialized
DEBUG - 2018-07-27 02:35:01 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-27 02:35:01 --> Helper loaded: url_helper
INFO - 2018-07-27 02:35:01 --> Helper loaded: form_helper
INFO - 2018-07-27 02:35:01 --> Helper loaded: date_helper
INFO - 2018-07-27 02:35:01 --> Helper loaded: util_helper
INFO - 2018-07-27 02:35:01 --> Helper loaded: text_helper
INFO - 2018-07-27 02:35:01 --> Helper loaded: string_helper
INFO - 2018-07-27 02:35:01 --> Database Driver Class Initialized
DEBUG - 2018-07-27 02:35:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 02:35:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 02:35:01 --> Email Class Initialized
INFO - 2018-07-27 02:35:01 --> Controller Class Initialized
DEBUG - 2018-07-27 02:35:01 --> Profile MX_Controller Initialized
DEBUG - 2018-07-27 02:35:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-27 02:35:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-27 02:35:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-07-27 02:35:01 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-27 02:35:01 --> Login MX_Controller Initialized
INFO - 2018-07-27 02:35:01 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-27 02:35:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-27 02:35:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-27 02:35:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-27 02:35:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-27 02:35:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-07-27 02:35:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-27 02:35:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-27 02:35:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/reset_password.php
INFO - 2018-07-27 02:35:01 --> Final output sent to browser
DEBUG - 2018-07-27 02:35:01 --> Total execution time: 0.4998
INFO - 2018-07-27 02:35:02 --> Config Class Initialized
INFO - 2018-07-27 02:35:02 --> Hooks Class Initialized
DEBUG - 2018-07-27 02:35:02 --> UTF-8 Support Enabled
INFO - 2018-07-27 02:35:02 --> Utf8 Class Initialized
INFO - 2018-07-27 02:35:02 --> URI Class Initialized
INFO - 2018-07-27 02:35:02 --> Config Class Initialized
INFO - 2018-07-27 02:35:02 --> Hooks Class Initialized
INFO - 2018-07-27 02:35:02 --> Router Class Initialized
INFO - 2018-07-27 02:35:02 --> Output Class Initialized
DEBUG - 2018-07-27 02:35:02 --> UTF-8 Support Enabled
INFO - 2018-07-27 02:35:02 --> Utf8 Class Initialized
INFO - 2018-07-27 02:35:02 --> Security Class Initialized
DEBUG - 2018-07-27 02:35:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 02:35:02 --> URI Class Initialized
INFO - 2018-07-27 02:35:02 --> Input Class Initialized
INFO - 2018-07-27 02:35:02 --> Router Class Initialized
INFO - 2018-07-27 02:35:02 --> Language Class Initialized
ERROR - 2018-07-27 02:35:02 --> 404 Page Not Found: /index
INFO - 2018-07-27 02:35:02 --> Output Class Initialized
INFO - 2018-07-27 02:35:02 --> Security Class Initialized
DEBUG - 2018-07-27 02:35:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 02:35:02 --> Input Class Initialized
INFO - 2018-07-27 02:35:02 --> Config Class Initialized
INFO - 2018-07-27 02:35:02 --> Hooks Class Initialized
INFO - 2018-07-27 02:35:02 --> Language Class Initialized
DEBUG - 2018-07-27 02:35:02 --> UTF-8 Support Enabled
INFO - 2018-07-27 02:35:02 --> Utf8 Class Initialized
INFO - 2018-07-27 02:35:02 --> URI Class Initialized
INFO - 2018-07-27 02:35:02 --> Router Class Initialized
INFO - 2018-07-27 02:35:02 --> Output Class Initialized
INFO - 2018-07-27 02:35:02 --> Language Class Initialized
INFO - 2018-07-27 02:35:02 --> Security Class Initialized
DEBUG - 2018-07-27 02:35:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 02:35:02 --> Input Class Initialized
INFO - 2018-07-27 02:35:02 --> Language Class Initialized
ERROR - 2018-07-27 02:35:02 --> 404 Page Not Found: /index
INFO - 2018-07-27 02:35:02 --> Config Class Initialized
INFO - 2018-07-27 02:35:02 --> Loader Class Initialized
DEBUG - 2018-07-27 02:35:02 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-27 02:35:02 --> Helper loaded: url_helper
INFO - 2018-07-27 02:35:02 --> Config Class Initialized
INFO - 2018-07-27 02:35:03 --> Hooks Class Initialized
INFO - 2018-07-27 02:35:03 --> Helper loaded: form_helper
DEBUG - 2018-07-27 02:35:03 --> UTF-8 Support Enabled
INFO - 2018-07-27 02:35:03 --> Utf8 Class Initialized
INFO - 2018-07-27 02:35:03 --> URI Class Initialized
INFO - 2018-07-27 02:35:03 --> Router Class Initialized
INFO - 2018-07-27 02:35:03 --> Output Class Initialized
INFO - 2018-07-27 02:35:03 --> Security Class Initialized
DEBUG - 2018-07-27 02:35:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 02:35:03 --> Input Class Initialized
INFO - 2018-07-27 02:35:03 --> Language Class Initialized
ERROR - 2018-07-27 02:35:03 --> 404 Page Not Found: /index
INFO - 2018-07-27 02:35:03 --> Helper loaded: date_helper
INFO - 2018-07-27 02:35:03 --> Helper loaded: util_helper
INFO - 2018-07-27 02:35:03 --> Helper loaded: text_helper
INFO - 2018-07-27 02:35:03 --> Helper loaded: string_helper
INFO - 2018-07-27 02:35:03 --> Database Driver Class Initialized
DEBUG - 2018-07-27 02:35:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 02:35:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 02:35:03 --> Email Class Initialized
INFO - 2018-07-27 02:35:03 --> Controller Class Initialized
DEBUG - 2018-07-27 02:35:03 --> Home MX_Controller Initialized
DEBUG - 2018-07-27 02:35:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-27 02:35:03 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-27 02:35:03 --> Login MX_Controller Initialized
INFO - 2018-07-27 02:35:03 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-27 02:35:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-27 02:35:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-27 02:37:27 --> Config Class Initialized
INFO - 2018-07-27 02:37:27 --> Hooks Class Initialized
DEBUG - 2018-07-27 02:37:27 --> UTF-8 Support Enabled
INFO - 2018-07-27 02:37:27 --> Utf8 Class Initialized
INFO - 2018-07-27 02:37:27 --> URI Class Initialized
INFO - 2018-07-27 02:37:27 --> Router Class Initialized
INFO - 2018-07-27 02:37:27 --> Output Class Initialized
INFO - 2018-07-27 02:37:27 --> Security Class Initialized
DEBUG - 2018-07-27 02:37:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 02:37:27 --> Input Class Initialized
INFO - 2018-07-27 02:37:27 --> Language Class Initialized
INFO - 2018-07-27 02:37:27 --> Language Class Initialized
INFO - 2018-07-27 02:37:27 --> Config Class Initialized
INFO - 2018-07-27 02:37:27 --> Loader Class Initialized
DEBUG - 2018-07-27 02:37:27 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-27 02:37:27 --> Helper loaded: url_helper
INFO - 2018-07-27 02:37:27 --> Helper loaded: form_helper
INFO - 2018-07-27 02:37:27 --> Helper loaded: date_helper
INFO - 2018-07-27 02:37:27 --> Helper loaded: util_helper
INFO - 2018-07-27 02:37:27 --> Helper loaded: text_helper
INFO - 2018-07-27 02:37:27 --> Helper loaded: string_helper
INFO - 2018-07-27 02:37:27 --> Database Driver Class Initialized
DEBUG - 2018-07-27 02:37:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 02:37:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 02:37:27 --> Email Class Initialized
INFO - 2018-07-27 02:37:27 --> Controller Class Initialized
DEBUG - 2018-07-27 02:37:27 --> Profile MX_Controller Initialized
DEBUG - 2018-07-27 02:37:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-27 02:37:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-27 02:37:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-07-27 02:37:27 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-27 02:37:27 --> Login MX_Controller Initialized
INFO - 2018-07-27 02:37:27 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-27 02:37:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-27 02:37:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-27 02:37:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-27 02:37:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-27 02:37:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-07-27 02:37:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-27 02:37:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-27 02:37:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/reset_password.php
INFO - 2018-07-27 02:37:27 --> Final output sent to browser
DEBUG - 2018-07-27 02:37:27 --> Total execution time: 0.5113
INFO - 2018-07-27 02:37:28 --> Config Class Initialized
INFO - 2018-07-27 02:37:28 --> Hooks Class Initialized
DEBUG - 2018-07-27 02:37:28 --> UTF-8 Support Enabled
INFO - 2018-07-27 02:37:28 --> Utf8 Class Initialized
INFO - 2018-07-27 02:37:28 --> URI Class Initialized
INFO - 2018-07-27 02:37:28 --> Config Class Initialized
INFO - 2018-07-27 02:37:28 --> Hooks Class Initialized
INFO - 2018-07-27 02:37:28 --> Router Class Initialized
DEBUG - 2018-07-27 02:37:28 --> UTF-8 Support Enabled
INFO - 2018-07-27 02:37:28 --> Output Class Initialized
INFO - 2018-07-27 02:37:28 --> Utf8 Class Initialized
INFO - 2018-07-27 02:37:28 --> URI Class Initialized
INFO - 2018-07-27 02:37:28 --> Router Class Initialized
INFO - 2018-07-27 02:37:28 --> Output Class Initialized
INFO - 2018-07-27 02:37:28 --> Security Class Initialized
INFO - 2018-07-27 02:37:28 --> Security Class Initialized
DEBUG - 2018-07-27 02:37:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 02:37:28 --> Input Class Initialized
INFO - 2018-07-27 02:37:28 --> Language Class Initialized
INFO - 2018-07-27 02:37:28 --> Language Class Initialized
INFO - 2018-07-27 02:37:28 --> Config Class Initialized
DEBUG - 2018-07-27 02:37:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 02:37:28 --> Loader Class Initialized
INFO - 2018-07-27 02:37:28 --> Input Class Initialized
INFO - 2018-07-27 02:37:28 --> Language Class Initialized
DEBUG - 2018-07-27 02:37:28 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
ERROR - 2018-07-27 02:37:28 --> 404 Page Not Found: /index
INFO - 2018-07-27 02:37:28 --> Helper loaded: url_helper
INFO - 2018-07-27 02:37:28 --> Helper loaded: form_helper
INFO - 2018-07-27 02:37:28 --> Helper loaded: date_helper
INFO - 2018-07-27 02:37:28 --> Helper loaded: util_helper
INFO - 2018-07-27 02:37:28 --> Helper loaded: text_helper
INFO - 2018-07-27 02:37:28 --> Helper loaded: string_helper
INFO - 2018-07-27 02:37:28 --> Database Driver Class Initialized
DEBUG - 2018-07-27 02:37:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 02:37:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 02:37:29 --> Email Class Initialized
INFO - 2018-07-27 02:37:29 --> Controller Class Initialized
DEBUG - 2018-07-27 02:37:29 --> Home MX_Controller Initialized
DEBUG - 2018-07-27 02:37:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-07-27 02:37:29 --> Config Class Initialized
INFO - 2018-07-27 02:37:29 --> Hooks Class Initialized
DEBUG - 2018-07-27 02:37:29 --> UTF-8 Support Enabled
DEBUG - 2018-07-27 02:37:29 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-27 02:37:29 --> Login MX_Controller Initialized
INFO - 2018-07-27 02:37:29 --> Utf8 Class Initialized
INFO - 2018-07-27 02:37:29 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-27 02:37:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-27 02:37:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-27 02:37:29 --> URI Class Initialized
INFO - 2018-07-27 02:37:29 --> Router Class Initialized
INFO - 2018-07-27 02:37:29 --> Output Class Initialized
INFO - 2018-07-27 02:37:29 --> Security Class Initialized
DEBUG - 2018-07-27 02:37:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 02:37:29 --> Input Class Initialized
INFO - 2018-07-27 02:37:29 --> Language Class Initialized
ERROR - 2018-07-27 02:37:29 --> 404 Page Not Found: /index
INFO - 2018-07-27 02:37:29 --> Config Class Initialized
INFO - 2018-07-27 02:37:29 --> Hooks Class Initialized
DEBUG - 2018-07-27 02:37:29 --> UTF-8 Support Enabled
INFO - 2018-07-27 02:37:29 --> Utf8 Class Initialized
INFO - 2018-07-27 02:37:29 --> URI Class Initialized
INFO - 2018-07-27 02:37:29 --> Router Class Initialized
INFO - 2018-07-27 02:37:29 --> Output Class Initialized
INFO - 2018-07-27 02:37:29 --> Security Class Initialized
DEBUG - 2018-07-27 02:37:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 02:37:29 --> Input Class Initialized
INFO - 2018-07-27 02:37:29 --> Language Class Initialized
ERROR - 2018-07-27 02:37:29 --> 404 Page Not Found: /index
INFO - 2018-07-27 02:38:12 --> Config Class Initialized
INFO - 2018-07-27 02:38:12 --> Hooks Class Initialized
DEBUG - 2018-07-27 02:38:12 --> UTF-8 Support Enabled
INFO - 2018-07-27 02:38:12 --> Utf8 Class Initialized
INFO - 2018-07-27 02:38:12 --> URI Class Initialized
INFO - 2018-07-27 02:38:12 --> Router Class Initialized
INFO - 2018-07-27 02:38:12 --> Output Class Initialized
INFO - 2018-07-27 02:38:12 --> Security Class Initialized
DEBUG - 2018-07-27 02:38:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 02:38:12 --> Input Class Initialized
INFO - 2018-07-27 02:38:12 --> Language Class Initialized
INFO - 2018-07-27 02:38:12 --> Language Class Initialized
INFO - 2018-07-27 02:38:12 --> Config Class Initialized
INFO - 2018-07-27 02:38:12 --> Loader Class Initialized
DEBUG - 2018-07-27 02:38:12 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-27 02:38:12 --> Helper loaded: url_helper
INFO - 2018-07-27 02:38:12 --> Helper loaded: form_helper
INFO - 2018-07-27 02:38:12 --> Helper loaded: date_helper
INFO - 2018-07-27 02:38:12 --> Helper loaded: util_helper
INFO - 2018-07-27 02:38:12 --> Helper loaded: text_helper
INFO - 2018-07-27 02:38:12 --> Helper loaded: string_helper
INFO - 2018-07-27 02:38:12 --> Database Driver Class Initialized
DEBUG - 2018-07-27 02:38:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 02:38:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 02:38:12 --> Email Class Initialized
INFO - 2018-07-27 02:38:12 --> Controller Class Initialized
DEBUG - 2018-07-27 02:38:12 --> Profile MX_Controller Initialized
DEBUG - 2018-07-27 02:38:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-27 02:38:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-27 02:38:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-07-27 02:38:12 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-27 02:38:12 --> Login MX_Controller Initialized
INFO - 2018-07-27 02:38:12 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-27 02:38:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-27 02:38:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-27 02:38:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-27 02:38:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-27 02:38:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-07-27 02:38:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-27 02:38:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-27 02:38:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/reset_password.php
INFO - 2018-07-27 02:38:12 --> Final output sent to browser
DEBUG - 2018-07-27 02:38:12 --> Total execution time: 0.5104
INFO - 2018-07-27 02:38:13 --> Config Class Initialized
INFO - 2018-07-27 02:38:13 --> Hooks Class Initialized
DEBUG - 2018-07-27 02:38:13 --> UTF-8 Support Enabled
INFO - 2018-07-27 02:38:13 --> Utf8 Class Initialized
INFO - 2018-07-27 02:38:13 --> URI Class Initialized
INFO - 2018-07-27 02:38:13 --> Router Class Initialized
INFO - 2018-07-27 02:38:13 --> Config Class Initialized
INFO - 2018-07-27 02:38:13 --> Hooks Class Initialized
INFO - 2018-07-27 02:38:13 --> Output Class Initialized
INFO - 2018-07-27 02:38:13 --> Security Class Initialized
DEBUG - 2018-07-27 02:38:13 --> UTF-8 Support Enabled
INFO - 2018-07-27 02:38:13 --> Utf8 Class Initialized
DEBUG - 2018-07-27 02:38:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 02:38:13 --> URI Class Initialized
INFO - 2018-07-27 02:38:13 --> Input Class Initialized
INFO - 2018-07-27 02:38:13 --> Router Class Initialized
INFO - 2018-07-27 02:38:13 --> Language Class Initialized
ERROR - 2018-07-27 02:38:13 --> 404 Page Not Found: /index
INFO - 2018-07-27 02:38:13 --> Output Class Initialized
INFO - 2018-07-27 02:38:13 --> Security Class Initialized
DEBUG - 2018-07-27 02:38:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 02:38:13 --> Input Class Initialized
INFO - 2018-07-27 02:38:13 --> Language Class Initialized
INFO - 2018-07-27 02:38:13 --> Language Class Initialized
INFO - 2018-07-27 02:38:13 --> Config Class Initialized
INFO - 2018-07-27 02:38:13 --> Config Class Initialized
INFO - 2018-07-27 02:38:13 --> Loader Class Initialized
INFO - 2018-07-27 02:38:13 --> Hooks Class Initialized
DEBUG - 2018-07-27 02:38:13 --> UTF-8 Support Enabled
INFO - 2018-07-27 02:38:13 --> Utf8 Class Initialized
INFO - 2018-07-27 02:38:13 --> URI Class Initialized
DEBUG - 2018-07-27 02:38:13 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-27 02:38:13 --> Router Class Initialized
INFO - 2018-07-27 02:38:13 --> Helper loaded: url_helper
INFO - 2018-07-27 02:38:13 --> Helper loaded: form_helper
INFO - 2018-07-27 02:38:13 --> Helper loaded: date_helper
INFO - 2018-07-27 02:38:13 --> Helper loaded: util_helper
INFO - 2018-07-27 02:38:13 --> Helper loaded: text_helper
INFO - 2018-07-27 02:38:13 --> Helper loaded: string_helper
INFO - 2018-07-27 02:38:13 --> Database Driver Class Initialized
INFO - 2018-07-27 02:38:13 --> Output Class Initialized
INFO - 2018-07-27 02:38:13 --> Security Class Initialized
DEBUG - 2018-07-27 02:38:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 02:38:13 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-07-27 02:38:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 02:38:13 --> Email Class Initialized
INFO - 2018-07-27 02:38:13 --> Controller Class Initialized
DEBUG - 2018-07-27 02:38:13 --> Home MX_Controller Initialized
DEBUG - 2018-07-27 02:38:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-07-27 02:38:13 --> Input Class Initialized
INFO - 2018-07-27 02:38:13 --> Language Class Initialized
DEBUG - 2018-07-27 02:38:13 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-27 02:38:13 --> Login MX_Controller Initialized
ERROR - 2018-07-27 02:38:13 --> 404 Page Not Found: /index
INFO - 2018-07-27 02:38:13 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-27 02:38:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-27 02:38:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-27 02:38:14 --> Config Class Initialized
INFO - 2018-07-27 02:38:14 --> Hooks Class Initialized
DEBUG - 2018-07-27 02:38:14 --> UTF-8 Support Enabled
INFO - 2018-07-27 02:38:14 --> Utf8 Class Initialized
INFO - 2018-07-27 02:38:14 --> URI Class Initialized
INFO - 2018-07-27 02:38:14 --> Router Class Initialized
INFO - 2018-07-27 02:38:14 --> Output Class Initialized
INFO - 2018-07-27 02:38:14 --> Security Class Initialized
DEBUG - 2018-07-27 02:38:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 02:38:14 --> Input Class Initialized
INFO - 2018-07-27 02:38:14 --> Language Class Initialized
ERROR - 2018-07-27 02:38:14 --> 404 Page Not Found: /index
INFO - 2018-07-27 02:38:36 --> Config Class Initialized
INFO - 2018-07-27 02:38:36 --> Hooks Class Initialized
DEBUG - 2018-07-27 02:38:36 --> UTF-8 Support Enabled
INFO - 2018-07-27 02:38:36 --> Utf8 Class Initialized
INFO - 2018-07-27 02:38:36 --> URI Class Initialized
INFO - 2018-07-27 02:38:36 --> Router Class Initialized
INFO - 2018-07-27 02:38:36 --> Output Class Initialized
INFO - 2018-07-27 02:38:36 --> Security Class Initialized
DEBUG - 2018-07-27 02:38:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 02:38:36 --> Input Class Initialized
INFO - 2018-07-27 02:38:36 --> Language Class Initialized
INFO - 2018-07-27 02:38:36 --> Language Class Initialized
INFO - 2018-07-27 02:38:36 --> Config Class Initialized
INFO - 2018-07-27 02:38:36 --> Loader Class Initialized
DEBUG - 2018-07-27 02:38:36 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-27 02:38:36 --> Helper loaded: url_helper
INFO - 2018-07-27 02:38:36 --> Helper loaded: form_helper
INFO - 2018-07-27 02:38:36 --> Helper loaded: date_helper
INFO - 2018-07-27 02:38:36 --> Helper loaded: util_helper
INFO - 2018-07-27 02:38:36 --> Helper loaded: text_helper
INFO - 2018-07-27 02:38:36 --> Helper loaded: string_helper
INFO - 2018-07-27 02:38:36 --> Database Driver Class Initialized
DEBUG - 2018-07-27 02:38:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 02:38:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 02:38:36 --> Email Class Initialized
INFO - 2018-07-27 02:38:36 --> Controller Class Initialized
DEBUG - 2018-07-27 02:38:36 --> Profile MX_Controller Initialized
DEBUG - 2018-07-27 02:38:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-27 02:38:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-27 02:38:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-07-27 02:38:36 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-27 02:38:36 --> Login MX_Controller Initialized
INFO - 2018-07-27 02:38:36 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-27 02:38:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-27 02:38:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-27 02:38:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-27 02:38:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-27 02:38:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-07-27 02:38:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-27 02:38:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-27 02:38:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/reset_password.php
INFO - 2018-07-27 02:38:36 --> Final output sent to browser
DEBUG - 2018-07-27 02:38:36 --> Total execution time: 0.5207
INFO - 2018-07-27 02:38:37 --> Config Class Initialized
INFO - 2018-07-27 02:38:37 --> Hooks Class Initialized
DEBUG - 2018-07-27 02:38:37 --> UTF-8 Support Enabled
INFO - 2018-07-27 02:38:37 --> Utf8 Class Initialized
INFO - 2018-07-27 02:38:37 --> URI Class Initialized
INFO - 2018-07-27 02:38:37 --> Router Class Initialized
INFO - 2018-07-27 02:38:37 --> Config Class Initialized
INFO - 2018-07-27 02:38:37 --> Hooks Class Initialized
INFO - 2018-07-27 02:38:37 --> Output Class Initialized
DEBUG - 2018-07-27 02:38:37 --> UTF-8 Support Enabled
INFO - 2018-07-27 02:38:37 --> Utf8 Class Initialized
INFO - 2018-07-27 02:38:37 --> Security Class Initialized
INFO - 2018-07-27 02:38:37 --> URI Class Initialized
INFO - 2018-07-27 02:38:37 --> Router Class Initialized
INFO - 2018-07-27 02:38:37 --> Output Class Initialized
INFO - 2018-07-27 02:38:37 --> Security Class Initialized
DEBUG - 2018-07-27 02:38:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 02:38:37 --> Input Class Initialized
DEBUG - 2018-07-27 02:38:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 02:38:37 --> Language Class Initialized
INFO - 2018-07-27 02:38:37 --> Input Class Initialized
INFO - 2018-07-27 02:38:37 --> Language Class Initialized
ERROR - 2018-07-27 02:38:37 --> 404 Page Not Found: /index
INFO - 2018-07-27 02:38:37 --> Language Class Initialized
INFO - 2018-07-27 02:38:37 --> Config Class Initialized
INFO - 2018-07-27 02:38:37 --> Loader Class Initialized
DEBUG - 2018-07-27 02:38:37 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-27 02:38:37 --> Helper loaded: url_helper
INFO - 2018-07-27 02:38:37 --> Helper loaded: form_helper
INFO - 2018-07-27 02:38:37 --> Helper loaded: date_helper
INFO - 2018-07-27 02:38:38 --> Helper loaded: util_helper
INFO - 2018-07-27 02:38:38 --> Config Class Initialized
INFO - 2018-07-27 02:38:38 --> Hooks Class Initialized
INFO - 2018-07-27 02:38:38 --> Helper loaded: text_helper
DEBUG - 2018-07-27 02:38:38 --> UTF-8 Support Enabled
INFO - 2018-07-27 02:38:38 --> Utf8 Class Initialized
INFO - 2018-07-27 02:38:38 --> URI Class Initialized
INFO - 2018-07-27 02:38:38 --> Router Class Initialized
INFO - 2018-07-27 02:38:38 --> Output Class Initialized
INFO - 2018-07-27 02:38:38 --> Security Class Initialized
DEBUG - 2018-07-27 02:38:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 02:38:38 --> Input Class Initialized
INFO - 2018-07-27 02:38:38 --> Language Class Initialized
ERROR - 2018-07-27 02:38:38 --> 404 Page Not Found: /index
INFO - 2018-07-27 02:38:38 --> Config Class Initialized
INFO - 2018-07-27 02:38:38 --> Helper loaded: string_helper
INFO - 2018-07-27 02:38:38 --> Hooks Class Initialized
DEBUG - 2018-07-27 02:38:38 --> UTF-8 Support Enabled
INFO - 2018-07-27 02:38:38 --> Utf8 Class Initialized
INFO - 2018-07-27 02:38:38 --> URI Class Initialized
INFO - 2018-07-27 02:38:38 --> Router Class Initialized
INFO - 2018-07-27 02:38:38 --> Database Driver Class Initialized
INFO - 2018-07-27 02:38:38 --> Output Class Initialized
INFO - 2018-07-27 02:38:38 --> Security Class Initialized
DEBUG - 2018-07-27 02:38:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-07-27 02:38:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 02:38:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 02:38:38 --> Input Class Initialized
INFO - 2018-07-27 02:38:38 --> Language Class Initialized
INFO - 2018-07-27 02:38:38 --> Email Class Initialized
INFO - 2018-07-27 02:38:38 --> Controller Class Initialized
ERROR - 2018-07-27 02:38:38 --> 404 Page Not Found: /index
DEBUG - 2018-07-27 02:38:38 --> Home MX_Controller Initialized
DEBUG - 2018-07-27 02:38:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-27 02:38:38 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-27 02:38:38 --> Login MX_Controller Initialized
INFO - 2018-07-27 02:38:38 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-27 02:38:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-27 02:38:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-27 02:38:41 --> Config Class Initialized
INFO - 2018-07-27 02:38:41 --> Hooks Class Initialized
DEBUG - 2018-07-27 02:38:41 --> UTF-8 Support Enabled
INFO - 2018-07-27 02:38:41 --> Config Class Initialized
INFO - 2018-07-27 02:38:41 --> Hooks Class Initialized
INFO - 2018-07-27 02:38:41 --> Utf8 Class Initialized
DEBUG - 2018-07-27 02:38:41 --> UTF-8 Support Enabled
INFO - 2018-07-27 02:38:41 --> Utf8 Class Initialized
INFO - 2018-07-27 02:38:41 --> URI Class Initialized
INFO - 2018-07-27 02:38:41 --> URI Class Initialized
INFO - 2018-07-27 02:38:41 --> Router Class Initialized
INFO - 2018-07-27 02:38:41 --> Router Class Initialized
INFO - 2018-07-27 02:38:41 --> Output Class Initialized
INFO - 2018-07-27 02:38:41 --> Output Class Initialized
INFO - 2018-07-27 02:38:41 --> Security Class Initialized
INFO - 2018-07-27 02:38:41 --> Security Class Initialized
DEBUG - 2018-07-27 02:38:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-07-27 02:38:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 02:38:42 --> Input Class Initialized
INFO - 2018-07-27 02:38:42 --> Language Class Initialized
ERROR - 2018-07-27 02:38:42 --> 404 Page Not Found: /index
INFO - 2018-07-27 02:38:42 --> Config Class Initialized
INFO - 2018-07-27 02:38:42 --> Hooks Class Initialized
DEBUG - 2018-07-27 02:38:42 --> UTF-8 Support Enabled
INFO - 2018-07-27 02:38:42 --> Utf8 Class Initialized
INFO - 2018-07-27 02:38:42 --> URI Class Initialized
INFO - 2018-07-27 02:38:42 --> Router Class Initialized
INFO - 2018-07-27 02:38:42 --> Output Class Initialized
INFO - 2018-07-27 02:38:42 --> Security Class Initialized
INFO - 2018-07-27 02:38:42 --> Input Class Initialized
DEBUG - 2018-07-27 02:38:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 02:38:42 --> Input Class Initialized
INFO - 2018-07-27 02:38:42 --> Language Class Initialized
ERROR - 2018-07-27 02:38:42 --> 404 Page Not Found: /index
INFO - 2018-07-27 02:38:42 --> Config Class Initialized
INFO - 2018-07-27 02:38:42 --> Hooks Class Initialized
DEBUG - 2018-07-27 02:38:42 --> UTF-8 Support Enabled
INFO - 2018-07-27 02:38:42 --> Utf8 Class Initialized
INFO - 2018-07-27 02:38:42 --> URI Class Initialized
INFO - 2018-07-27 02:38:42 --> Router Class Initialized
INFO - 2018-07-27 02:38:42 --> Language Class Initialized
INFO - 2018-07-27 02:38:42 --> Output Class Initialized
INFO - 2018-07-27 02:38:42 --> Security Class Initialized
DEBUG - 2018-07-27 02:38:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 02:38:42 --> Input Class Initialized
INFO - 2018-07-27 02:38:42 --> Language Class Initialized
ERROR - 2018-07-27 02:38:42 --> 404 Page Not Found: /index
INFO - 2018-07-27 02:38:42 --> Language Class Initialized
INFO - 2018-07-27 02:38:42 --> Config Class Initialized
INFO - 2018-07-27 02:38:42 --> Loader Class Initialized
DEBUG - 2018-07-27 02:38:42 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-27 02:38:42 --> Helper loaded: url_helper
INFO - 2018-07-27 02:38:42 --> Helper loaded: form_helper
INFO - 2018-07-27 02:38:42 --> Helper loaded: date_helper
INFO - 2018-07-27 02:38:42 --> Helper loaded: util_helper
INFO - 2018-07-27 02:38:42 --> Helper loaded: text_helper
INFO - 2018-07-27 02:38:42 --> Helper loaded: string_helper
INFO - 2018-07-27 02:38:42 --> Database Driver Class Initialized
DEBUG - 2018-07-27 02:38:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 02:38:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 02:38:42 --> Email Class Initialized
INFO - 2018-07-27 02:38:42 --> Controller Class Initialized
DEBUG - 2018-07-27 02:38:42 --> Home MX_Controller Initialized
DEBUG - 2018-07-27 02:38:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-27 02:38:42 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-27 02:38:42 --> Login MX_Controller Initialized
INFO - 2018-07-27 02:38:42 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-27 02:38:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-27 02:38:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-27 02:38:44 --> Config Class Initialized
INFO - 2018-07-27 02:38:44 --> Hooks Class Initialized
DEBUG - 2018-07-27 02:38:44 --> UTF-8 Support Enabled
INFO - 2018-07-27 02:38:44 --> Utf8 Class Initialized
INFO - 2018-07-27 02:38:44 --> URI Class Initialized
INFO - 2018-07-27 02:38:44 --> Router Class Initialized
INFO - 2018-07-27 02:38:44 --> Output Class Initialized
INFO - 2018-07-27 02:38:44 --> Security Class Initialized
DEBUG - 2018-07-27 02:38:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 02:38:44 --> Input Class Initialized
INFO - 2018-07-27 02:38:44 --> Language Class Initialized
INFO - 2018-07-27 02:38:44 --> Language Class Initialized
INFO - 2018-07-27 02:38:44 --> Config Class Initialized
INFO - 2018-07-27 02:38:44 --> Loader Class Initialized
DEBUG - 2018-07-27 02:38:44 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-27 02:38:44 --> Helper loaded: url_helper
INFO - 2018-07-27 02:38:44 --> Helper loaded: form_helper
INFO - 2018-07-27 02:38:44 --> Helper loaded: date_helper
INFO - 2018-07-27 02:38:44 --> Helper loaded: util_helper
INFO - 2018-07-27 02:38:44 --> Helper loaded: text_helper
INFO - 2018-07-27 02:38:44 --> Helper loaded: string_helper
INFO - 2018-07-27 02:38:44 --> Database Driver Class Initialized
DEBUG - 2018-07-27 02:38:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 02:38:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 02:38:44 --> Email Class Initialized
INFO - 2018-07-27 02:38:44 --> Controller Class Initialized
DEBUG - 2018-07-27 02:38:44 --> Profile MX_Controller Initialized
DEBUG - 2018-07-27 02:38:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-27 02:38:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-27 02:38:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-07-27 02:38:44 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-27 02:38:44 --> Login MX_Controller Initialized
INFO - 2018-07-27 02:38:44 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-27 02:38:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-27 02:38:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-27 02:38:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-27 02:38:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-27 02:38:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-07-27 02:38:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-27 02:38:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-27 02:38:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/reset_password.php
INFO - 2018-07-27 02:38:44 --> Final output sent to browser
DEBUG - 2018-07-27 02:38:44 --> Total execution time: 0.5259
INFO - 2018-07-27 02:38:45 --> Config Class Initialized
INFO - 2018-07-27 02:38:45 --> Hooks Class Initialized
DEBUG - 2018-07-27 02:38:45 --> UTF-8 Support Enabled
INFO - 2018-07-27 02:38:45 --> Utf8 Class Initialized
INFO - 2018-07-27 02:38:45 --> URI Class Initialized
INFO - 2018-07-27 02:38:45 --> Router Class Initialized
INFO - 2018-07-27 02:38:45 --> Config Class Initialized
INFO - 2018-07-27 02:38:45 --> Hooks Class Initialized
INFO - 2018-07-27 02:38:45 --> Output Class Initialized
DEBUG - 2018-07-27 02:38:45 --> UTF-8 Support Enabled
INFO - 2018-07-27 02:38:45 --> Utf8 Class Initialized
INFO - 2018-07-27 02:38:45 --> Security Class Initialized
INFO - 2018-07-27 02:38:45 --> URI Class Initialized
INFO - 2018-07-27 02:38:45 --> Router Class Initialized
INFO - 2018-07-27 02:38:45 --> Output Class Initialized
DEBUG - 2018-07-27 02:38:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 02:38:45 --> Security Class Initialized
INFO - 2018-07-27 02:38:45 --> Input Class Initialized
DEBUG - 2018-07-27 02:38:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 02:38:45 --> Language Class Initialized
INFO - 2018-07-27 02:38:45 --> Input Class Initialized
INFO - 2018-07-27 02:38:45 --> Language Class Initialized
ERROR - 2018-07-27 02:38:45 --> 404 Page Not Found: /index
INFO - 2018-07-27 02:38:45 --> Language Class Initialized
INFO - 2018-07-27 02:38:45 --> Config Class Initialized
INFO - 2018-07-27 02:38:45 --> Loader Class Initialized
DEBUG - 2018-07-27 02:38:45 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-27 02:38:45 --> Helper loaded: url_helper
INFO - 2018-07-27 02:38:45 --> Helper loaded: form_helper
INFO - 2018-07-27 02:38:45 --> Helper loaded: date_helper
INFO - 2018-07-27 02:38:45 --> Helper loaded: util_helper
INFO - 2018-07-27 02:38:45 --> Helper loaded: text_helper
INFO - 2018-07-27 02:38:45 --> Helper loaded: string_helper
INFO - 2018-07-27 02:38:45 --> Database Driver Class Initialized
DEBUG - 2018-07-27 02:38:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 02:38:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 02:38:45 --> Email Class Initialized
INFO - 2018-07-27 02:38:45 --> Controller Class Initialized
DEBUG - 2018-07-27 02:38:46 --> Home MX_Controller Initialized
DEBUG - 2018-07-27 02:38:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-27 02:38:46 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
INFO - 2018-07-27 02:38:46 --> Config Class Initialized
DEBUG - 2018-07-27 02:38:46 --> Login MX_Controller Initialized
INFO - 2018-07-27 02:38:46 --> Hooks Class Initialized
INFO - 2018-07-27 02:38:46 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-27 02:38:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-27 02:38:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-27 02:38:46 --> UTF-8 Support Enabled
INFO - 2018-07-27 02:38:46 --> Utf8 Class Initialized
INFO - 2018-07-27 02:38:46 --> URI Class Initialized
INFO - 2018-07-27 02:38:46 --> Router Class Initialized
INFO - 2018-07-27 02:38:46 --> Output Class Initialized
INFO - 2018-07-27 02:38:46 --> Security Class Initialized
DEBUG - 2018-07-27 02:38:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 02:38:46 --> Input Class Initialized
INFO - 2018-07-27 02:38:46 --> Language Class Initialized
ERROR - 2018-07-27 02:38:46 --> 404 Page Not Found: /index
INFO - 2018-07-27 02:38:46 --> Config Class Initialized
INFO - 2018-07-27 02:38:46 --> Hooks Class Initialized
DEBUG - 2018-07-27 02:38:46 --> UTF-8 Support Enabled
INFO - 2018-07-27 02:38:46 --> Utf8 Class Initialized
INFO - 2018-07-27 02:38:46 --> URI Class Initialized
INFO - 2018-07-27 02:38:46 --> Router Class Initialized
INFO - 2018-07-27 02:38:46 --> Output Class Initialized
INFO - 2018-07-27 02:38:46 --> Security Class Initialized
DEBUG - 2018-07-27 02:38:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 02:38:46 --> Input Class Initialized
INFO - 2018-07-27 02:38:46 --> Language Class Initialized
ERROR - 2018-07-27 02:38:46 --> 404 Page Not Found: /index
INFO - 2018-07-27 02:39:15 --> Config Class Initialized
INFO - 2018-07-27 02:39:15 --> Hooks Class Initialized
DEBUG - 2018-07-27 02:39:15 --> UTF-8 Support Enabled
INFO - 2018-07-27 02:39:15 --> Utf8 Class Initialized
INFO - 2018-07-27 02:39:15 --> URI Class Initialized
INFO - 2018-07-27 02:39:15 --> Router Class Initialized
INFO - 2018-07-27 02:39:15 --> Output Class Initialized
INFO - 2018-07-27 02:39:15 --> Security Class Initialized
DEBUG - 2018-07-27 02:39:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 02:39:15 --> Input Class Initialized
INFO - 2018-07-27 02:39:15 --> Language Class Initialized
INFO - 2018-07-27 02:39:15 --> Language Class Initialized
INFO - 2018-07-27 02:39:15 --> Config Class Initialized
INFO - 2018-07-27 02:39:15 --> Loader Class Initialized
DEBUG - 2018-07-27 02:39:15 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-27 02:39:15 --> Helper loaded: url_helper
INFO - 2018-07-27 02:39:15 --> Helper loaded: form_helper
INFO - 2018-07-27 02:39:15 --> Helper loaded: date_helper
INFO - 2018-07-27 02:39:15 --> Helper loaded: util_helper
INFO - 2018-07-27 02:39:15 --> Helper loaded: text_helper
INFO - 2018-07-27 02:39:15 --> Helper loaded: string_helper
INFO - 2018-07-27 02:39:15 --> Database Driver Class Initialized
DEBUG - 2018-07-27 02:39:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 02:39:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 02:39:15 --> Email Class Initialized
INFO - 2018-07-27 02:39:15 --> Controller Class Initialized
DEBUG - 2018-07-27 02:39:15 --> Home MX_Controller Initialized
DEBUG - 2018-07-27 02:39:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-27 02:39:15 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-27 02:39:15 --> Login MX_Controller Initialized
INFO - 2018-07-27 02:39:15 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-27 02:39:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-27 02:39:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-27 02:39:19 --> Config Class Initialized
INFO - 2018-07-27 02:39:19 --> Hooks Class Initialized
DEBUG - 2018-07-27 02:39:19 --> UTF-8 Support Enabled
INFO - 2018-07-27 02:39:19 --> Utf8 Class Initialized
INFO - 2018-07-27 02:39:19 --> URI Class Initialized
INFO - 2018-07-27 02:39:19 --> Router Class Initialized
INFO - 2018-07-27 02:39:19 --> Output Class Initialized
INFO - 2018-07-27 02:39:19 --> Security Class Initialized
DEBUG - 2018-07-27 02:39:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 02:39:19 --> Input Class Initialized
INFO - 2018-07-27 02:39:19 --> Language Class Initialized
INFO - 2018-07-27 02:39:19 --> Language Class Initialized
INFO - 2018-07-27 02:39:19 --> Config Class Initialized
INFO - 2018-07-27 02:39:19 --> Loader Class Initialized
DEBUG - 2018-07-27 02:39:19 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-27 02:39:19 --> Helper loaded: url_helper
INFO - 2018-07-27 02:39:19 --> Helper loaded: form_helper
INFO - 2018-07-27 02:39:19 --> Helper loaded: date_helper
INFO - 2018-07-27 02:39:19 --> Helper loaded: util_helper
INFO - 2018-07-27 02:39:19 --> Helper loaded: text_helper
INFO - 2018-07-27 02:39:20 --> Helper loaded: string_helper
INFO - 2018-07-27 02:39:20 --> Database Driver Class Initialized
DEBUG - 2018-07-27 02:39:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 02:39:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 02:39:20 --> Email Class Initialized
INFO - 2018-07-27 02:39:20 --> Controller Class Initialized
DEBUG - 2018-07-27 02:39:20 --> Profile MX_Controller Initialized
DEBUG - 2018-07-27 02:39:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-27 02:39:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-27 02:39:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-07-27 02:39:20 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-27 02:39:20 --> Login MX_Controller Initialized
INFO - 2018-07-27 02:39:20 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-27 02:39:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-27 02:39:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-27 02:39:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-27 02:39:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-27 02:39:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-07-27 02:39:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-27 02:39:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-27 02:39:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/reset_password.php
INFO - 2018-07-27 02:39:20 --> Final output sent to browser
DEBUG - 2018-07-27 02:39:20 --> Total execution time: 0.5362
INFO - 2018-07-27 02:39:20 --> Config Class Initialized
INFO - 2018-07-27 02:39:20 --> Hooks Class Initialized
DEBUG - 2018-07-27 02:39:20 --> UTF-8 Support Enabled
INFO - 2018-07-27 02:39:20 --> Utf8 Class Initialized
INFO - 2018-07-27 02:39:20 --> URI Class Initialized
INFO - 2018-07-27 02:39:20 --> Config Class Initialized
INFO - 2018-07-27 02:39:20 --> Hooks Class Initialized
INFO - 2018-07-27 02:39:20 --> Router Class Initialized
INFO - 2018-07-27 02:39:20 --> Output Class Initialized
DEBUG - 2018-07-27 02:39:20 --> UTF-8 Support Enabled
INFO - 2018-07-27 02:39:20 --> Security Class Initialized
DEBUG - 2018-07-27 02:39:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 02:39:20 --> Input Class Initialized
INFO - 2018-07-27 02:39:20 --> Utf8 Class Initialized
INFO - 2018-07-27 02:39:20 --> Language Class Initialized
INFO - 2018-07-27 02:39:20 --> URI Class Initialized
INFO - 2018-07-27 02:39:21 --> Router Class Initialized
INFO - 2018-07-27 02:39:21 --> Output Class Initialized
ERROR - 2018-07-27 02:39:21 --> 404 Page Not Found: /index
INFO - 2018-07-27 02:39:21 --> Security Class Initialized
DEBUG - 2018-07-27 02:39:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 02:39:21 --> Input Class Initialized
INFO - 2018-07-27 02:39:21 --> Config Class Initialized
INFO - 2018-07-27 02:39:21 --> Hooks Class Initialized
INFO - 2018-07-27 02:39:21 --> Language Class Initialized
DEBUG - 2018-07-27 02:39:21 --> UTF-8 Support Enabled
INFO - 2018-07-27 02:39:21 --> Utf8 Class Initialized
INFO - 2018-07-27 02:39:21 --> URI Class Initialized
INFO - 2018-07-27 02:39:21 --> Router Class Initialized
INFO - 2018-07-27 02:39:21 --> Language Class Initialized
INFO - 2018-07-27 02:39:21 --> Config Class Initialized
INFO - 2018-07-27 02:39:21 --> Output Class Initialized
INFO - 2018-07-27 02:39:21 --> Loader Class Initialized
INFO - 2018-07-27 02:39:21 --> Security Class Initialized
DEBUG - 2018-07-27 02:39:21 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
DEBUG - 2018-07-27 02:39:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 02:39:21 --> Helper loaded: url_helper
INFO - 2018-07-27 02:39:21 --> Input Class Initialized
INFO - 2018-07-27 02:39:21 --> Language Class Initialized
INFO - 2018-07-27 02:39:21 --> Helper loaded: form_helper
ERROR - 2018-07-27 02:39:21 --> 404 Page Not Found: /index
INFO - 2018-07-27 02:39:21 --> Helper loaded: date_helper
INFO - 2018-07-27 02:39:21 --> Helper loaded: util_helper
INFO - 2018-07-27 02:39:21 --> Config Class Initialized
INFO - 2018-07-27 02:39:21 --> Helper loaded: text_helper
INFO - 2018-07-27 02:39:21 --> Hooks Class Initialized
INFO - 2018-07-27 02:39:21 --> Helper loaded: string_helper
DEBUG - 2018-07-27 02:39:21 --> UTF-8 Support Enabled
INFO - 2018-07-27 02:39:21 --> Utf8 Class Initialized
INFO - 2018-07-27 02:39:21 --> Database Driver Class Initialized
INFO - 2018-07-27 02:39:21 --> URI Class Initialized
DEBUG - 2018-07-27 02:39:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 02:39:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 02:39:21 --> Router Class Initialized
INFO - 2018-07-27 02:39:21 --> Email Class Initialized
INFO - 2018-07-27 02:39:21 --> Output Class Initialized
INFO - 2018-07-27 02:39:21 --> Controller Class Initialized
INFO - 2018-07-27 02:39:21 --> Security Class Initialized
DEBUG - 2018-07-27 02:39:21 --> Home MX_Controller Initialized
DEBUG - 2018-07-27 02:39:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 02:39:21 --> Input Class Initialized
DEBUG - 2018-07-27 02:39:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-07-27 02:39:21 --> Language Class Initialized
DEBUG - 2018-07-27 02:39:21 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-27 02:39:21 --> Login MX_Controller Initialized
ERROR - 2018-07-27 02:39:21 --> 404 Page Not Found: /index
INFO - 2018-07-27 02:39:21 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-27 02:39:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-27 02:39:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-27 02:39:23 --> Config Class Initialized
INFO - 2018-07-27 02:39:23 --> Hooks Class Initialized
DEBUG - 2018-07-27 02:39:23 --> UTF-8 Support Enabled
INFO - 2018-07-27 02:39:23 --> Utf8 Class Initialized
INFO - 2018-07-27 02:39:23 --> URI Class Initialized
INFO - 2018-07-27 02:39:23 --> Config Class Initialized
INFO - 2018-07-27 02:39:23 --> Hooks Class Initialized
INFO - 2018-07-27 02:39:23 --> Router Class Initialized
DEBUG - 2018-07-27 02:39:23 --> UTF-8 Support Enabled
INFO - 2018-07-27 02:39:23 --> Output Class Initialized
INFO - 2018-07-27 02:39:23 --> Utf8 Class Initialized
INFO - 2018-07-27 02:39:23 --> URI Class Initialized
INFO - 2018-07-27 02:39:23 --> Router Class Initialized
INFO - 2018-07-27 02:39:23 --> Security Class Initialized
INFO - 2018-07-27 02:39:23 --> Output Class Initialized
INFO - 2018-07-27 02:39:23 --> Security Class Initialized
DEBUG - 2018-07-27 02:39:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 02:39:23 --> Input Class Initialized
INFO - 2018-07-27 02:39:23 --> Language Class Initialized
ERROR - 2018-07-27 02:39:23 --> 404 Page Not Found: /index
INFO - 2018-07-27 02:39:23 --> Config Class Initialized
INFO - 2018-07-27 02:39:23 --> Hooks Class Initialized
DEBUG - 2018-07-27 02:39:23 --> UTF-8 Support Enabled
DEBUG - 2018-07-27 02:39:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 02:39:23 --> Utf8 Class Initialized
INFO - 2018-07-27 02:39:23 --> URI Class Initialized
INFO - 2018-07-27 02:39:23 --> Input Class Initialized
INFO - 2018-07-27 02:39:23 --> Router Class Initialized
INFO - 2018-07-27 02:39:23 --> Output Class Initialized
INFO - 2018-07-27 02:39:23 --> Language Class Initialized
INFO - 2018-07-27 02:39:23 --> Security Class Initialized
DEBUG - 2018-07-27 02:39:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 02:39:23 --> Input Class Initialized
INFO - 2018-07-27 02:39:23 --> Language Class Initialized
ERROR - 2018-07-27 02:39:23 --> 404 Page Not Found: /index
INFO - 2018-07-27 02:39:23 --> Config Class Initialized
INFO - 2018-07-27 02:39:23 --> Hooks Class Initialized
DEBUG - 2018-07-27 02:39:23 --> UTF-8 Support Enabled
INFO - 2018-07-27 02:39:23 --> Language Class Initialized
INFO - 2018-07-27 02:39:23 --> Utf8 Class Initialized
INFO - 2018-07-27 02:39:23 --> URI Class Initialized
INFO - 2018-07-27 02:39:23 --> Config Class Initialized
INFO - 2018-07-27 02:39:23 --> Router Class Initialized
INFO - 2018-07-27 02:39:23 --> Output Class Initialized
INFO - 2018-07-27 02:39:23 --> Loader Class Initialized
INFO - 2018-07-27 02:39:23 --> Security Class Initialized
DEBUG - 2018-07-27 02:39:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 02:39:23 --> Input Class Initialized
INFO - 2018-07-27 02:39:23 --> Language Class Initialized
ERROR - 2018-07-27 02:39:23 --> 404 Page Not Found: /index
DEBUG - 2018-07-27 02:39:23 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-27 02:39:23 --> Helper loaded: url_helper
INFO - 2018-07-27 02:39:23 --> Helper loaded: form_helper
INFO - 2018-07-27 02:39:23 --> Helper loaded: date_helper
INFO - 2018-07-27 02:39:23 --> Helper loaded: util_helper
INFO - 2018-07-27 02:39:23 --> Helper loaded: text_helper
INFO - 2018-07-27 02:39:23 --> Helper loaded: string_helper
INFO - 2018-07-27 02:39:24 --> Database Driver Class Initialized
DEBUG - 2018-07-27 02:39:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 02:39:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 02:39:24 --> Email Class Initialized
INFO - 2018-07-27 02:39:24 --> Controller Class Initialized
DEBUG - 2018-07-27 02:39:24 --> Home MX_Controller Initialized
DEBUG - 2018-07-27 02:39:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-27 02:39:24 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-27 02:39:24 --> Login MX_Controller Initialized
INFO - 2018-07-27 02:39:24 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-27 02:39:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-27 02:39:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-27 02:39:26 --> Config Class Initialized
INFO - 2018-07-27 02:39:26 --> Hooks Class Initialized
DEBUG - 2018-07-27 02:39:26 --> UTF-8 Support Enabled
INFO - 2018-07-27 02:39:26 --> Utf8 Class Initialized
INFO - 2018-07-27 02:39:26 --> URI Class Initialized
INFO - 2018-07-27 02:39:26 --> Router Class Initialized
INFO - 2018-07-27 02:39:26 --> Output Class Initialized
INFO - 2018-07-27 02:39:26 --> Security Class Initialized
DEBUG - 2018-07-27 02:39:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 02:39:26 --> Input Class Initialized
INFO - 2018-07-27 02:39:26 --> Language Class Initialized
INFO - 2018-07-27 02:39:26 --> Language Class Initialized
INFO - 2018-07-27 02:39:26 --> Config Class Initialized
INFO - 2018-07-27 02:39:26 --> Loader Class Initialized
DEBUG - 2018-07-27 02:39:26 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-27 02:39:26 --> Helper loaded: url_helper
INFO - 2018-07-27 02:39:26 --> Helper loaded: form_helper
INFO - 2018-07-27 02:39:26 --> Helper loaded: date_helper
INFO - 2018-07-27 02:39:26 --> Helper loaded: util_helper
INFO - 2018-07-27 02:39:26 --> Helper loaded: text_helper
INFO - 2018-07-27 02:39:26 --> Helper loaded: string_helper
INFO - 2018-07-27 02:39:26 --> Database Driver Class Initialized
DEBUG - 2018-07-27 02:39:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 02:39:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 02:39:26 --> Email Class Initialized
INFO - 2018-07-27 02:39:26 --> Controller Class Initialized
DEBUG - 2018-07-27 02:39:26 --> Profile MX_Controller Initialized
DEBUG - 2018-07-27 02:39:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-27 02:39:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-27 02:39:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-07-27 02:39:26 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-27 02:39:26 --> Login MX_Controller Initialized
INFO - 2018-07-27 02:39:26 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-27 02:39:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-27 02:39:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-27 02:39:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-27 02:39:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-27 02:39:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-07-27 02:39:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-27 02:39:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-27 02:39:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/reset_password.php
INFO - 2018-07-27 02:39:26 --> Final output sent to browser
DEBUG - 2018-07-27 02:39:26 --> Total execution time: 0.5562
INFO - 2018-07-27 02:39:27 --> Config Class Initialized
INFO - 2018-07-27 02:39:27 --> Hooks Class Initialized
DEBUG - 2018-07-27 02:39:27 --> UTF-8 Support Enabled
INFO - 2018-07-27 02:39:27 --> Utf8 Class Initialized
INFO - 2018-07-27 02:39:27 --> Config Class Initialized
INFO - 2018-07-27 02:39:27 --> URI Class Initialized
INFO - 2018-07-27 02:39:27 --> Hooks Class Initialized
DEBUG - 2018-07-27 02:39:27 --> UTF-8 Support Enabled
INFO - 2018-07-27 02:39:27 --> Router Class Initialized
INFO - 2018-07-27 02:39:27 --> Utf8 Class Initialized
INFO - 2018-07-27 02:39:27 --> Output Class Initialized
INFO - 2018-07-27 02:39:27 --> URI Class Initialized
INFO - 2018-07-27 02:39:27 --> Security Class Initialized
DEBUG - 2018-07-27 02:39:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 02:39:27 --> Router Class Initialized
INFO - 2018-07-27 02:39:27 --> Input Class Initialized
INFO - 2018-07-27 02:39:27 --> Output Class Initialized
INFO - 2018-07-27 02:39:27 --> Language Class Initialized
ERROR - 2018-07-27 02:39:27 --> 404 Page Not Found: /index
INFO - 2018-07-27 02:39:27 --> Security Class Initialized
DEBUG - 2018-07-27 02:39:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 02:39:27 --> Input Class Initialized
INFO - 2018-07-27 02:39:27 --> Language Class Initialized
INFO - 2018-07-27 02:39:27 --> Config Class Initialized
INFO - 2018-07-27 02:39:27 --> Hooks Class Initialized
INFO - 2018-07-27 02:39:27 --> Language Class Initialized
DEBUG - 2018-07-27 02:39:27 --> UTF-8 Support Enabled
INFO - 2018-07-27 02:39:27 --> Utf8 Class Initialized
INFO - 2018-07-27 02:39:27 --> URI Class Initialized
INFO - 2018-07-27 02:39:27 --> Config Class Initialized
INFO - 2018-07-27 02:39:27 --> Router Class Initialized
INFO - 2018-07-27 02:39:27 --> Output Class Initialized
INFO - 2018-07-27 02:39:27 --> Loader Class Initialized
INFO - 2018-07-27 02:39:27 --> Security Class Initialized
DEBUG - 2018-07-27 02:39:27 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
DEBUG - 2018-07-27 02:39:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 02:39:27 --> Helper loaded: url_helper
INFO - 2018-07-27 02:39:27 --> Input Class Initialized
INFO - 2018-07-27 02:39:27 --> Helper loaded: form_helper
INFO - 2018-07-27 02:39:27 --> Language Class Initialized
INFO - 2018-07-27 02:39:27 --> Helper loaded: date_helper
ERROR - 2018-07-27 02:39:27 --> 404 Page Not Found: /index
INFO - 2018-07-27 02:39:27 --> Config Class Initialized
INFO - 2018-07-27 02:39:27 --> Hooks Class Initialized
INFO - 2018-07-27 02:39:27 --> Helper loaded: util_helper
INFO - 2018-07-27 02:39:27 --> Helper loaded: text_helper
DEBUG - 2018-07-27 02:39:27 --> UTF-8 Support Enabled
INFO - 2018-07-27 02:39:27 --> Utf8 Class Initialized
INFO - 2018-07-27 02:39:27 --> Helper loaded: string_helper
INFO - 2018-07-27 02:39:27 --> URI Class Initialized
INFO - 2018-07-27 02:39:27 --> Database Driver Class Initialized
INFO - 2018-07-27 02:39:27 --> Router Class Initialized
DEBUG - 2018-07-27 02:39:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 02:39:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 02:39:27 --> Output Class Initialized
INFO - 2018-07-27 02:39:27 --> Security Class Initialized
INFO - 2018-07-27 02:39:27 --> Email Class Initialized
INFO - 2018-07-27 02:39:27 --> Controller Class Initialized
DEBUG - 2018-07-27 02:39:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-07-27 02:39:27 --> Home MX_Controller Initialized
INFO - 2018-07-27 02:39:27 --> Input Class Initialized
INFO - 2018-07-27 02:39:27 --> Language Class Initialized
DEBUG - 2018-07-27 02:39:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
ERROR - 2018-07-27 02:39:27 --> 404 Page Not Found: /index
DEBUG - 2018-07-27 02:39:27 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-27 02:39:27 --> Login MX_Controller Initialized
INFO - 2018-07-27 02:39:27 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-27 02:39:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-27 02:39:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-27 02:40:55 --> Config Class Initialized
INFO - 2018-07-27 02:40:55 --> Hooks Class Initialized
DEBUG - 2018-07-27 02:40:55 --> UTF-8 Support Enabled
INFO - 2018-07-27 02:40:55 --> Utf8 Class Initialized
INFO - 2018-07-27 02:40:55 --> URI Class Initialized
INFO - 2018-07-27 02:40:55 --> Router Class Initialized
INFO - 2018-07-27 02:40:55 --> Output Class Initialized
INFO - 2018-07-27 02:40:55 --> Security Class Initialized
DEBUG - 2018-07-27 02:40:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 02:40:55 --> Input Class Initialized
INFO - 2018-07-27 02:40:55 --> Language Class Initialized
INFO - 2018-07-27 02:40:55 --> Language Class Initialized
INFO - 2018-07-27 02:40:55 --> Config Class Initialized
INFO - 2018-07-27 02:40:55 --> Loader Class Initialized
DEBUG - 2018-07-27 02:40:55 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-27 02:40:55 --> Helper loaded: url_helper
INFO - 2018-07-27 02:40:55 --> Helper loaded: form_helper
INFO - 2018-07-27 02:40:55 --> Helper loaded: date_helper
INFO - 2018-07-27 02:40:55 --> Helper loaded: util_helper
INFO - 2018-07-27 02:40:55 --> Helper loaded: text_helper
INFO - 2018-07-27 02:40:55 --> Helper loaded: string_helper
INFO - 2018-07-27 02:40:55 --> Database Driver Class Initialized
DEBUG - 2018-07-27 02:40:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 02:40:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 02:40:55 --> Email Class Initialized
INFO - 2018-07-27 02:40:55 --> Controller Class Initialized
DEBUG - 2018-07-27 02:40:55 --> Profile MX_Controller Initialized
DEBUG - 2018-07-27 02:40:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-27 02:40:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-27 02:40:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-07-27 02:40:55 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-27 02:40:55 --> Login MX_Controller Initialized
INFO - 2018-07-27 02:40:55 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-27 02:40:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-27 02:40:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-27 02:40:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-27 02:40:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-27 02:40:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-07-27 02:40:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-27 02:40:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-27 02:40:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/reset_password.php
INFO - 2018-07-27 02:40:55 --> Final output sent to browser
DEBUG - 2018-07-27 02:40:55 --> Total execution time: 0.5658
INFO - 2018-07-27 02:40:56 --> Config Class Initialized
INFO - 2018-07-27 02:40:56 --> Hooks Class Initialized
DEBUG - 2018-07-27 02:40:56 --> UTF-8 Support Enabled
INFO - 2018-07-27 02:40:56 --> Utf8 Class Initialized
INFO - 2018-07-27 02:40:56 --> URI Class Initialized
INFO - 2018-07-27 02:40:56 --> Router Class Initialized
INFO - 2018-07-27 02:40:56 --> Config Class Initialized
INFO - 2018-07-27 02:40:56 --> Hooks Class Initialized
INFO - 2018-07-27 02:40:56 --> Output Class Initialized
DEBUG - 2018-07-27 02:40:56 --> UTF-8 Support Enabled
INFO - 2018-07-27 02:40:56 --> Security Class Initialized
INFO - 2018-07-27 02:40:56 --> Utf8 Class Initialized
DEBUG - 2018-07-27 02:40:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 02:40:56 --> URI Class Initialized
INFO - 2018-07-27 02:40:56 --> Input Class Initialized
INFO - 2018-07-27 02:40:56 --> Router Class Initialized
INFO - 2018-07-27 02:40:56 --> Language Class Initialized
INFO - 2018-07-27 02:40:56 --> Output Class Initialized
ERROR - 2018-07-27 02:40:56 --> 404 Page Not Found: /index
INFO - 2018-07-27 02:40:56 --> Security Class Initialized
INFO - 2018-07-27 02:40:56 --> Config Class Initialized
DEBUG - 2018-07-27 02:40:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 02:40:56 --> Hooks Class Initialized
DEBUG - 2018-07-27 02:40:56 --> UTF-8 Support Enabled
INFO - 2018-07-27 02:40:56 --> Utf8 Class Initialized
INFO - 2018-07-27 02:40:56 --> URI Class Initialized
INFO - 2018-07-27 02:40:56 --> Router Class Initialized
INFO - 2018-07-27 02:40:56 --> Output Class Initialized
INFO - 2018-07-27 02:40:56 --> Security Class Initialized
DEBUG - 2018-07-27 02:40:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 02:40:56 --> Input Class Initialized
INFO - 2018-07-27 02:40:56 --> Language Class Initialized
INFO - 2018-07-27 02:40:56 --> Input Class Initialized
ERROR - 2018-07-27 02:40:56 --> 404 Page Not Found: /index
INFO - 2018-07-27 02:40:56 --> Config Class Initialized
INFO - 2018-07-27 02:40:56 --> Hooks Class Initialized
DEBUG - 2018-07-27 02:40:56 --> UTF-8 Support Enabled
INFO - 2018-07-27 02:40:56 --> Language Class Initialized
INFO - 2018-07-27 02:40:56 --> Utf8 Class Initialized
INFO - 2018-07-27 02:40:56 --> URI Class Initialized
INFO - 2018-07-27 02:40:56 --> Router Class Initialized
INFO - 2018-07-27 02:40:56 --> Language Class Initialized
INFO - 2018-07-27 02:40:56 --> Output Class Initialized
INFO - 2018-07-27 02:40:56 --> Security Class Initialized
DEBUG - 2018-07-27 02:40:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 02:40:57 --> Input Class Initialized
INFO - 2018-07-27 02:40:57 --> Language Class Initialized
ERROR - 2018-07-27 02:40:57 --> 404 Page Not Found: /index
INFO - 2018-07-27 02:40:57 --> Config Class Initialized
INFO - 2018-07-27 02:40:57 --> Loader Class Initialized
DEBUG - 2018-07-27 02:40:57 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-27 02:40:57 --> Helper loaded: url_helper
INFO - 2018-07-27 02:40:57 --> Helper loaded: form_helper
INFO - 2018-07-27 02:40:57 --> Helper loaded: date_helper
INFO - 2018-07-27 02:40:57 --> Helper loaded: util_helper
INFO - 2018-07-27 02:40:57 --> Helper loaded: text_helper
INFO - 2018-07-27 02:40:57 --> Helper loaded: string_helper
INFO - 2018-07-27 02:40:57 --> Database Driver Class Initialized
DEBUG - 2018-07-27 02:40:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 02:40:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 02:40:57 --> Email Class Initialized
INFO - 2018-07-27 02:40:57 --> Controller Class Initialized
DEBUG - 2018-07-27 02:40:57 --> Home MX_Controller Initialized
DEBUG - 2018-07-27 02:40:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-27 02:40:57 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-27 02:40:57 --> Login MX_Controller Initialized
INFO - 2018-07-27 02:40:57 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-27 02:40:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-27 02:40:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-27 02:41:02 --> Config Class Initialized
INFO - 2018-07-27 02:41:02 --> Hooks Class Initialized
DEBUG - 2018-07-27 02:41:02 --> UTF-8 Support Enabled
INFO - 2018-07-27 02:41:02 --> Utf8 Class Initialized
INFO - 2018-07-27 02:41:02 --> Config Class Initialized
INFO - 2018-07-27 02:41:02 --> Hooks Class Initialized
INFO - 2018-07-27 02:41:02 --> URI Class Initialized
DEBUG - 2018-07-27 02:41:02 --> UTF-8 Support Enabled
INFO - 2018-07-27 02:41:02 --> Router Class Initialized
INFO - 2018-07-27 02:41:02 --> Utf8 Class Initialized
INFO - 2018-07-27 02:41:02 --> Output Class Initialized
INFO - 2018-07-27 02:41:03 --> URI Class Initialized
INFO - 2018-07-27 02:41:03 --> Security Class Initialized
INFO - 2018-07-27 02:41:03 --> Router Class Initialized
DEBUG - 2018-07-27 02:41:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 02:41:03 --> Output Class Initialized
INFO - 2018-07-27 02:41:03 --> Input Class Initialized
INFO - 2018-07-27 02:41:03 --> Security Class Initialized
DEBUG - 2018-07-27 02:41:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 02:41:03 --> Input Class Initialized
INFO - 2018-07-27 02:41:03 --> Language Class Initialized
ERROR - 2018-07-27 02:41:03 --> 404 Page Not Found: /index
INFO - 2018-07-27 02:41:03 --> Config Class Initialized
INFO - 2018-07-27 02:41:03 --> Hooks Class Initialized
INFO - 2018-07-27 02:41:03 --> Language Class Initialized
DEBUG - 2018-07-27 02:41:03 --> UTF-8 Support Enabled
INFO - 2018-07-27 02:41:03 --> Language Class Initialized
INFO - 2018-07-27 02:41:03 --> Config Class Initialized
INFO - 2018-07-27 02:41:03 --> Utf8 Class Initialized
INFO - 2018-07-27 02:41:03 --> Loader Class Initialized
DEBUG - 2018-07-27 02:41:03 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-27 02:41:03 --> URI Class Initialized
INFO - 2018-07-27 02:41:03 --> Router Class Initialized
INFO - 2018-07-27 02:41:03 --> Helper loaded: url_helper
INFO - 2018-07-27 02:41:03 --> Output Class Initialized
INFO - 2018-07-27 02:41:03 --> Helper loaded: form_helper
INFO - 2018-07-27 02:41:03 --> Helper loaded: date_helper
INFO - 2018-07-27 02:41:03 --> Security Class Initialized
INFO - 2018-07-27 02:41:03 --> Helper loaded: util_helper
DEBUG - 2018-07-27 02:41:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 02:41:03 --> Helper loaded: text_helper
INFO - 2018-07-27 02:41:03 --> Input Class Initialized
INFO - 2018-07-27 02:41:03 --> Helper loaded: string_helper
INFO - 2018-07-27 02:41:03 --> Language Class Initialized
ERROR - 2018-07-27 02:41:03 --> 404 Page Not Found: /index
INFO - 2018-07-27 02:41:03 --> Database Driver Class Initialized
INFO - 2018-07-27 02:41:03 --> Config Class Initialized
DEBUG - 2018-07-27 02:41:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 02:41:03 --> Hooks Class Initialized
INFO - 2018-07-27 02:41:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 02:41:03 --> Email Class Initialized
DEBUG - 2018-07-27 02:41:03 --> UTF-8 Support Enabled
INFO - 2018-07-27 02:41:03 --> Controller Class Initialized
INFO - 2018-07-27 02:41:03 --> Utf8 Class Initialized
DEBUG - 2018-07-27 02:41:03 --> Home MX_Controller Initialized
INFO - 2018-07-27 02:41:03 --> URI Class Initialized
INFO - 2018-07-27 02:41:03 --> Router Class Initialized
DEBUG - 2018-07-27 02:41:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-07-27 02:41:03 --> Output Class Initialized
DEBUG - 2018-07-27 02:41:03 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-27 02:41:03 --> Login MX_Controller Initialized
INFO - 2018-07-27 02:41:03 --> Security Class Initialized
INFO - 2018-07-27 02:41:03 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-27 02:41:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-07-27 02:41:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-27 02:41:03 --> Input Class Initialized
DEBUG - 2018-07-27 02:41:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-27 02:41:03 --> Language Class Initialized
ERROR - 2018-07-27 02:41:03 --> 404 Page Not Found: /index
INFO - 2018-07-27 02:41:04 --> Config Class Initialized
INFO - 2018-07-27 02:41:04 --> Hooks Class Initialized
DEBUG - 2018-07-27 02:41:04 --> UTF-8 Support Enabled
INFO - 2018-07-27 02:41:04 --> Utf8 Class Initialized
INFO - 2018-07-27 02:41:04 --> URI Class Initialized
INFO - 2018-07-27 02:41:04 --> Router Class Initialized
INFO - 2018-07-27 02:41:04 --> Output Class Initialized
INFO - 2018-07-27 02:41:04 --> Security Class Initialized
DEBUG - 2018-07-27 02:41:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 02:41:04 --> Input Class Initialized
INFO - 2018-07-27 02:41:04 --> Language Class Initialized
INFO - 2018-07-27 02:41:04 --> Language Class Initialized
INFO - 2018-07-27 02:41:04 --> Config Class Initialized
INFO - 2018-07-27 02:41:04 --> Loader Class Initialized
DEBUG - 2018-07-27 02:41:04 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-27 02:41:04 --> Helper loaded: url_helper
INFO - 2018-07-27 02:41:04 --> Helper loaded: form_helper
INFO - 2018-07-27 02:41:04 --> Helper loaded: date_helper
INFO - 2018-07-27 02:41:04 --> Helper loaded: util_helper
INFO - 2018-07-27 02:41:04 --> Helper loaded: text_helper
INFO - 2018-07-27 02:41:04 --> Helper loaded: string_helper
INFO - 2018-07-27 02:41:04 --> Database Driver Class Initialized
DEBUG - 2018-07-27 02:41:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 02:41:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 02:41:04 --> Email Class Initialized
INFO - 2018-07-27 02:41:04 --> Controller Class Initialized
DEBUG - 2018-07-27 02:41:04 --> Profile MX_Controller Initialized
DEBUG - 2018-07-27 02:41:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-27 02:41:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-27 02:41:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-07-27 02:41:05 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-27 02:41:05 --> Login MX_Controller Initialized
INFO - 2018-07-27 02:41:05 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-27 02:41:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-27 02:41:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-27 02:41:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-27 02:41:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-27 02:41:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-07-27 02:41:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-27 02:41:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-27 02:41:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/reset_password.php
INFO - 2018-07-27 02:41:05 --> Final output sent to browser
DEBUG - 2018-07-27 02:41:05 --> Total execution time: 0.5649
INFO - 2018-07-27 02:41:05 --> Config Class Initialized
INFO - 2018-07-27 02:41:05 --> Hooks Class Initialized
DEBUG - 2018-07-27 02:41:05 --> UTF-8 Support Enabled
INFO - 2018-07-27 02:41:05 --> Utf8 Class Initialized
INFO - 2018-07-27 02:41:05 --> URI Class Initialized
INFO - 2018-07-27 02:41:05 --> Router Class Initialized
INFO - 2018-07-27 02:41:05 --> Config Class Initialized
INFO - 2018-07-27 02:41:05 --> Hooks Class Initialized
INFO - 2018-07-27 02:41:05 --> Output Class Initialized
DEBUG - 2018-07-27 02:41:05 --> UTF-8 Support Enabled
INFO - 2018-07-27 02:41:05 --> Security Class Initialized
INFO - 2018-07-27 02:41:05 --> Utf8 Class Initialized
INFO - 2018-07-27 02:41:05 --> URI Class Initialized
DEBUG - 2018-07-27 02:41:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 02:41:05 --> Router Class Initialized
INFO - 2018-07-27 02:41:05 --> Output Class Initialized
INFO - 2018-07-27 02:41:05 --> Security Class Initialized
DEBUG - 2018-07-27 02:41:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 02:41:06 --> Input Class Initialized
INFO - 2018-07-27 02:41:06 --> Input Class Initialized
INFO - 2018-07-27 02:41:06 --> Language Class Initialized
INFO - 2018-07-27 02:41:06 --> Language Class Initialized
ERROR - 2018-07-27 02:41:06 --> 404 Page Not Found: /index
INFO - 2018-07-27 02:41:06 --> Language Class Initialized
INFO - 2018-07-27 02:41:06 --> Config Class Initialized
INFO - 2018-07-27 02:41:06 --> Loader Class Initialized
DEBUG - 2018-07-27 02:41:06 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-27 02:41:06 --> Config Class Initialized
INFO - 2018-07-27 02:41:06 --> Hooks Class Initialized
INFO - 2018-07-27 02:41:06 --> Helper loaded: url_helper
DEBUG - 2018-07-27 02:41:06 --> UTF-8 Support Enabled
INFO - 2018-07-27 02:41:06 --> Utf8 Class Initialized
INFO - 2018-07-27 02:41:06 --> URI Class Initialized
INFO - 2018-07-27 02:41:06 --> Helper loaded: form_helper
INFO - 2018-07-27 02:41:06 --> Helper loaded: date_helper
INFO - 2018-07-27 02:41:06 --> Router Class Initialized
INFO - 2018-07-27 02:41:06 --> Output Class Initialized
INFO - 2018-07-27 02:41:06 --> Helper loaded: util_helper
INFO - 2018-07-27 02:41:06 --> Security Class Initialized
INFO - 2018-07-27 02:41:06 --> Helper loaded: text_helper
DEBUG - 2018-07-27 02:41:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 02:41:06 --> Helper loaded: string_helper
INFO - 2018-07-27 02:41:06 --> Input Class Initialized
INFO - 2018-07-27 02:41:06 --> Database Driver Class Initialized
INFO - 2018-07-27 02:41:06 --> Language Class Initialized
DEBUG - 2018-07-27 02:41:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 02:41:06 --> Session: Class initialized using 'files' driver.
ERROR - 2018-07-27 02:41:06 --> 404 Page Not Found: /index
INFO - 2018-07-27 02:41:06 --> Email Class Initialized
INFO - 2018-07-27 02:41:06 --> Config Class Initialized
INFO - 2018-07-27 02:41:06 --> Hooks Class Initialized
INFO - 2018-07-27 02:41:06 --> Controller Class Initialized
DEBUG - 2018-07-27 02:41:06 --> UTF-8 Support Enabled
DEBUG - 2018-07-27 02:41:06 --> Home MX_Controller Initialized
INFO - 2018-07-27 02:41:06 --> Utf8 Class Initialized
DEBUG - 2018-07-27 02:41:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-07-27 02:41:06 --> URI Class Initialized
DEBUG - 2018-07-27 02:41:06 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-27 02:41:06 --> Login MX_Controller Initialized
INFO - 2018-07-27 02:41:06 --> Router Class Initialized
INFO - 2018-07-27 02:41:06 --> Language file loaded: language/english/data_lang.php
INFO - 2018-07-27 02:41:06 --> Output Class Initialized
DEBUG - 2018-07-27 02:41:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-27 02:41:06 --> Security Class Initialized
DEBUG - 2018-07-27 02:41:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-27 02:41:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 02:41:06 --> Input Class Initialized
INFO - 2018-07-27 02:41:06 --> Language Class Initialized
ERROR - 2018-07-27 02:41:06 --> 404 Page Not Found: /index
INFO - 2018-07-27 02:41:10 --> Config Class Initialized
INFO - 2018-07-27 02:41:10 --> Hooks Class Initialized
DEBUG - 2018-07-27 02:41:10 --> UTF-8 Support Enabled
INFO - 2018-07-27 02:41:10 --> Utf8 Class Initialized
INFO - 2018-07-27 02:41:10 --> URI Class Initialized
INFO - 2018-07-27 02:41:10 --> Router Class Initialized
INFO - 2018-07-27 02:41:10 --> Output Class Initialized
INFO - 2018-07-27 02:41:10 --> Security Class Initialized
DEBUG - 2018-07-27 02:41:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 02:41:10 --> Input Class Initialized
INFO - 2018-07-27 02:41:10 --> Language Class Initialized
INFO - 2018-07-27 02:41:10 --> Language Class Initialized
INFO - 2018-07-27 02:41:10 --> Config Class Initialized
INFO - 2018-07-27 02:41:10 --> Loader Class Initialized
DEBUG - 2018-07-27 02:41:10 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-27 02:41:10 --> Helper loaded: url_helper
INFO - 2018-07-27 02:41:10 --> Helper loaded: form_helper
INFO - 2018-07-27 02:41:10 --> Helper loaded: date_helper
INFO - 2018-07-27 02:41:10 --> Helper loaded: util_helper
INFO - 2018-07-27 02:41:10 --> Helper loaded: text_helper
INFO - 2018-07-27 02:41:10 --> Helper loaded: string_helper
INFO - 2018-07-27 02:41:10 --> Database Driver Class Initialized
DEBUG - 2018-07-27 02:41:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 02:41:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 02:41:10 --> Email Class Initialized
INFO - 2018-07-27 02:41:10 --> Controller Class Initialized
DEBUG - 2018-07-27 02:41:10 --> Profile MX_Controller Initialized
DEBUG - 2018-07-27 02:41:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-27 02:41:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-27 02:41:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-07-27 02:41:10 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-27 02:41:10 --> Login MX_Controller Initialized
INFO - 2018-07-27 02:41:10 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-27 02:41:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-27 02:41:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-07-27 02:41:14 --> Config Class Initialized
INFO - 2018-07-27 02:41:14 --> Hooks Class Initialized
DEBUG - 2018-07-27 02:41:14 --> UTF-8 Support Enabled
INFO - 2018-07-27 02:41:14 --> Utf8 Class Initialized
INFO - 2018-07-27 02:41:14 --> URI Class Initialized
INFO - 2018-07-27 02:41:14 --> Router Class Initialized
INFO - 2018-07-27 02:41:14 --> Output Class Initialized
INFO - 2018-07-27 02:41:14 --> Security Class Initialized
DEBUG - 2018-07-27 02:41:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 02:41:15 --> Input Class Initialized
INFO - 2018-07-27 02:41:15 --> Language Class Initialized
INFO - 2018-07-27 02:41:15 --> Language Class Initialized
INFO - 2018-07-27 02:41:15 --> Config Class Initialized
INFO - 2018-07-27 02:41:15 --> Loader Class Initialized
DEBUG - 2018-07-27 02:41:15 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-27 02:41:15 --> Helper loaded: url_helper
INFO - 2018-07-27 02:41:15 --> Helper loaded: form_helper
INFO - 2018-07-27 02:41:15 --> Helper loaded: date_helper
INFO - 2018-07-27 02:41:15 --> Helper loaded: util_helper
INFO - 2018-07-27 02:41:15 --> Helper loaded: text_helper
INFO - 2018-07-27 02:41:15 --> Helper loaded: string_helper
INFO - 2018-07-27 02:41:15 --> Database Driver Class Initialized
DEBUG - 2018-07-27 02:41:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 02:41:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 02:41:15 --> Email Class Initialized
INFO - 2018-07-27 02:41:15 --> Controller Class Initialized
DEBUG - 2018-07-27 02:41:15 --> Login MX_Controller Initialized
INFO - 2018-07-27 02:41:15 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-27 02:41:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-27 02:41:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-27 02:41:15 --> Email starts for colin fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-07-27 02:41:15 --> User session created for 4
INFO - 2018-07-27 02:41:15 --> Login status colin - success
INFO - 2018-07-27 02:41:15 --> Final output sent to browser
DEBUG - 2018-07-27 02:41:15 --> Total execution time: 0.5677
INFO - 2018-07-27 02:41:15 --> Config Class Initialized
INFO - 2018-07-27 02:41:15 --> Hooks Class Initialized
DEBUG - 2018-07-27 02:41:15 --> UTF-8 Support Enabled
INFO - 2018-07-27 02:41:15 --> Utf8 Class Initialized
INFO - 2018-07-27 02:41:15 --> URI Class Initialized
INFO - 2018-07-27 02:41:15 --> Router Class Initialized
INFO - 2018-07-27 02:41:15 --> Output Class Initialized
INFO - 2018-07-27 02:41:15 --> Security Class Initialized
DEBUG - 2018-07-27 02:41:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 02:41:15 --> Input Class Initialized
INFO - 2018-07-27 02:41:15 --> Language Class Initialized
INFO - 2018-07-27 02:41:15 --> Language Class Initialized
INFO - 2018-07-27 02:41:15 --> Config Class Initialized
INFO - 2018-07-27 02:41:15 --> Loader Class Initialized
DEBUG - 2018-07-27 02:41:15 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-27 02:41:15 --> Helper loaded: url_helper
INFO - 2018-07-27 02:41:15 --> Helper loaded: form_helper
INFO - 2018-07-27 02:41:15 --> Helper loaded: date_helper
INFO - 2018-07-27 02:41:15 --> Helper loaded: util_helper
INFO - 2018-07-27 02:41:15 --> Helper loaded: text_helper
INFO - 2018-07-27 02:41:15 --> Helper loaded: string_helper
INFO - 2018-07-27 02:41:15 --> Database Driver Class Initialized
DEBUG - 2018-07-27 02:41:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 02:41:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 02:41:15 --> Email Class Initialized
INFO - 2018-07-27 02:41:15 --> Controller Class Initialized
DEBUG - 2018-07-27 02:41:15 --> Profile MX_Controller Initialized
DEBUG - 2018-07-27 02:41:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-27 02:41:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-27 02:41:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
DEBUG - 2018-07-27 02:41:15 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-27 02:41:16 --> Login MX_Controller Initialized
INFO - 2018-07-27 02:41:16 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-27 02:41:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-27 02:41:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-27 02:41:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-27 02:41:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-27 02:41:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/profile_left_nav.php
DEBUG - 2018-07-27 02:41:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-27 02:41:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-27 02:41:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/reset_password.php
INFO - 2018-07-27 02:41:16 --> Final output sent to browser
DEBUG - 2018-07-27 02:41:16 --> Total execution time: 0.6282
INFO - 2018-07-27 02:41:16 --> Config Class Initialized
INFO - 2018-07-27 02:41:16 --> Hooks Class Initialized
DEBUG - 2018-07-27 02:41:16 --> UTF-8 Support Enabled
INFO - 2018-07-27 02:41:16 --> Utf8 Class Initialized
INFO - 2018-07-27 02:41:16 --> Config Class Initialized
INFO - 2018-07-27 02:41:16 --> Hooks Class Initialized
INFO - 2018-07-27 02:41:16 --> URI Class Initialized
DEBUG - 2018-07-27 02:41:16 --> UTF-8 Support Enabled
INFO - 2018-07-27 02:41:16 --> Utf8 Class Initialized
INFO - 2018-07-27 02:41:16 --> Router Class Initialized
INFO - 2018-07-27 02:41:16 --> URI Class Initialized
INFO - 2018-07-27 02:41:16 --> Output Class Initialized
INFO - 2018-07-27 02:41:16 --> Router Class Initialized
INFO - 2018-07-27 02:41:16 --> Security Class Initialized
DEBUG - 2018-07-27 02:41:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 02:41:16 --> Output Class Initialized
INFO - 2018-07-27 02:41:16 --> Input Class Initialized
INFO - 2018-07-27 02:41:16 --> Security Class Initialized
INFO - 2018-07-27 02:41:16 --> Language Class Initialized
DEBUG - 2018-07-27 02:41:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 02:41:16 --> Input Class Initialized
ERROR - 2018-07-27 02:41:16 --> 404 Page Not Found: /index
INFO - 2018-07-27 02:41:16 --> Language Class Initialized
INFO - 2018-07-27 02:41:16 --> Config Class Initialized
INFO - 2018-07-27 02:41:16 --> Hooks Class Initialized
INFO - 2018-07-27 02:41:16 --> Language Class Initialized
INFO - 2018-07-27 02:41:16 --> Config Class Initialized
DEBUG - 2018-07-27 02:41:16 --> UTF-8 Support Enabled
INFO - 2018-07-27 02:41:16 --> Utf8 Class Initialized
INFO - 2018-07-27 02:41:16 --> Loader Class Initialized
DEBUG - 2018-07-27 02:41:16 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-27 02:41:16 --> URI Class Initialized
INFO - 2018-07-27 02:41:16 --> Helper loaded: url_helper
INFO - 2018-07-27 02:41:16 --> Router Class Initialized
INFO - 2018-07-27 02:41:16 --> Output Class Initialized
INFO - 2018-07-27 02:41:16 --> Helper loaded: form_helper
INFO - 2018-07-27 02:41:16 --> Security Class Initialized
DEBUG - 2018-07-27 02:41:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 02:41:16 --> Helper loaded: date_helper
INFO - 2018-07-27 02:41:16 --> Input Class Initialized
INFO - 2018-07-27 02:41:16 --> Helper loaded: util_helper
INFO - 2018-07-27 02:41:16 --> Helper loaded: text_helper
INFO - 2018-07-27 02:41:16 --> Language Class Initialized
INFO - 2018-07-27 02:41:16 --> Helper loaded: string_helper
ERROR - 2018-07-27 02:41:16 --> 404 Page Not Found: /index
INFO - 2018-07-27 02:41:17 --> Database Driver Class Initialized
INFO - 2018-07-27 02:41:17 --> Config Class Initialized
INFO - 2018-07-27 02:41:17 --> Hooks Class Initialized
DEBUG - 2018-07-27 02:41:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 02:41:17 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-07-27 02:41:17 --> UTF-8 Support Enabled
INFO - 2018-07-27 02:41:17 --> Utf8 Class Initialized
INFO - 2018-07-27 02:41:17 --> Email Class Initialized
INFO - 2018-07-27 02:41:17 --> Controller Class Initialized
INFO - 2018-07-27 02:41:17 --> URI Class Initialized
DEBUG - 2018-07-27 02:41:17 --> Home MX_Controller Initialized
INFO - 2018-07-27 02:41:17 --> Router Class Initialized
DEBUG - 2018-07-27 02:41:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-07-27 02:41:17 --> Output Class Initialized
INFO - 2018-07-27 02:41:17 --> Security Class Initialized
DEBUG - 2018-07-27 02:41:17 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-27 02:41:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-07-27 02:41:17 --> Login MX_Controller Initialized
INFO - 2018-07-27 02:41:17 --> Input Class Initialized
INFO - 2018-07-27 02:41:17 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-27 02:41:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-27 02:41:17 --> Language Class Initialized
DEBUG - 2018-07-27 02:41:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
ERROR - 2018-07-27 02:41:17 --> 404 Page Not Found: /index
INFO - 2018-07-27 03:12:32 --> Config Class Initialized
INFO - 2018-07-27 03:12:32 --> Hooks Class Initialized
DEBUG - 2018-07-27 03:12:32 --> UTF-8 Support Enabled
INFO - 2018-07-27 03:12:32 --> Utf8 Class Initialized
INFO - 2018-07-27 03:12:32 --> URI Class Initialized
DEBUG - 2018-07-27 03:12:32 --> No URI present. Default controller set.
INFO - 2018-07-27 03:12:32 --> Router Class Initialized
INFO - 2018-07-27 03:12:32 --> Output Class Initialized
INFO - 2018-07-27 03:12:32 --> Security Class Initialized
DEBUG - 2018-07-27 03:12:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 03:12:32 --> Input Class Initialized
INFO - 2018-07-27 03:12:32 --> Language Class Initialized
INFO - 2018-07-27 03:12:32 --> Language Class Initialized
INFO - 2018-07-27 03:12:32 --> Config Class Initialized
INFO - 2018-07-27 03:12:32 --> Loader Class Initialized
DEBUG - 2018-07-27 03:12:32 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-27 03:12:32 --> Helper loaded: url_helper
INFO - 2018-07-27 03:12:32 --> Helper loaded: form_helper
INFO - 2018-07-27 03:12:32 --> Helper loaded: date_helper
INFO - 2018-07-27 03:12:32 --> Helper loaded: util_helper
INFO - 2018-07-27 03:12:32 --> Helper loaded: text_helper
INFO - 2018-07-27 03:12:32 --> Helper loaded: string_helper
INFO - 2018-07-27 03:12:32 --> Database Driver Class Initialized
DEBUG - 2018-07-27 03:12:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 03:12:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 03:12:32 --> Email Class Initialized
INFO - 2018-07-27 03:12:32 --> Controller Class Initialized
DEBUG - 2018-07-27 03:12:32 --> Home MX_Controller Initialized
DEBUG - 2018-07-27 03:12:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-27 03:12:32 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-27 03:12:32 --> Login MX_Controller Initialized
INFO - 2018-07-27 03:12:32 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-27 03:12:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-27 03:12:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-27 03:12:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-27 03:12:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-27 03:12:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-27 03:12:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-27 03:12:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-27 03:12:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-27 03:12:33 --> Final output sent to browser
DEBUG - 2018-07-27 03:12:33 --> Total execution time: 0.6308
INFO - 2018-07-27 03:12:34 --> Config Class Initialized
INFO - 2018-07-27 03:12:34 --> Hooks Class Initialized
DEBUG - 2018-07-27 03:12:34 --> UTF-8 Support Enabled
INFO - 2018-07-27 03:12:34 --> Utf8 Class Initialized
INFO - 2018-07-27 03:12:34 --> URI Class Initialized
INFO - 2018-07-27 03:12:34 --> Config Class Initialized
INFO - 2018-07-27 03:12:34 --> Hooks Class Initialized
INFO - 2018-07-27 03:12:34 --> Router Class Initialized
INFO - 2018-07-27 03:12:34 --> Output Class Initialized
DEBUG - 2018-07-27 03:12:34 --> UTF-8 Support Enabled
INFO - 2018-07-27 03:12:34 --> Security Class Initialized
INFO - 2018-07-27 03:12:34 --> Utf8 Class Initialized
DEBUG - 2018-07-27 03:12:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 03:12:34 --> URI Class Initialized
INFO - 2018-07-27 03:12:34 --> Input Class Initialized
INFO - 2018-07-27 03:12:34 --> Language Class Initialized
ERROR - 2018-07-27 03:12:34 --> 404 Page Not Found: /index
INFO - 2018-07-27 03:12:34 --> Router Class Initialized
INFO - 2018-07-27 03:12:34 --> Output Class Initialized
INFO - 2018-07-27 03:12:34 --> Security Class Initialized
DEBUG - 2018-07-27 03:12:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 03:12:34 --> Input Class Initialized
INFO - 2018-07-27 03:12:34 --> Config Class Initialized
INFO - 2018-07-27 03:12:34 --> Hooks Class Initialized
INFO - 2018-07-27 03:12:34 --> Language Class Initialized
DEBUG - 2018-07-27 03:12:34 --> UTF-8 Support Enabled
INFO - 2018-07-27 03:12:34 --> Utf8 Class Initialized
INFO - 2018-07-27 03:12:34 --> URI Class Initialized
INFO - 2018-07-27 03:12:34 --> Router Class Initialized
INFO - 2018-07-27 03:12:34 --> Language Class Initialized
INFO - 2018-07-27 03:12:34 --> Output Class Initialized
INFO - 2018-07-27 03:12:34 --> Security Class Initialized
DEBUG - 2018-07-27 03:12:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 03:12:34 --> Input Class Initialized
INFO - 2018-07-27 03:12:34 --> Language Class Initialized
ERROR - 2018-07-27 03:12:34 --> 404 Page Not Found: /index
INFO - 2018-07-27 03:12:34 --> Config Class Initialized
INFO - 2018-07-27 03:12:34 --> Hooks Class Initialized
DEBUG - 2018-07-27 03:12:34 --> UTF-8 Support Enabled
INFO - 2018-07-27 03:12:34 --> Config Class Initialized
INFO - 2018-07-27 03:12:34 --> Utf8 Class Initialized
INFO - 2018-07-27 03:12:34 --> URI Class Initialized
INFO - 2018-07-27 03:12:34 --> Router Class Initialized
INFO - 2018-07-27 03:12:34 --> Output Class Initialized
INFO - 2018-07-27 03:12:34 --> Security Class Initialized
DEBUG - 2018-07-27 03:12:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 03:12:34 --> Input Class Initialized
INFO - 2018-07-27 03:12:34 --> Loader Class Initialized
INFO - 2018-07-27 03:12:35 --> Language Class Initialized
DEBUG - 2018-07-27 03:12:35 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
ERROR - 2018-07-27 03:12:35 --> 404 Page Not Found: /index
INFO - 2018-07-27 03:12:35 --> Helper loaded: url_helper
INFO - 2018-07-27 03:12:35 --> Helper loaded: form_helper
INFO - 2018-07-27 03:12:35 --> Helper loaded: date_helper
INFO - 2018-07-27 03:12:35 --> Helper loaded: util_helper
INFO - 2018-07-27 03:12:35 --> Helper loaded: text_helper
INFO - 2018-07-27 03:12:35 --> Helper loaded: string_helper
INFO - 2018-07-27 03:12:35 --> Database Driver Class Initialized
DEBUG - 2018-07-27 03:12:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 03:12:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 03:12:35 --> Email Class Initialized
INFO - 2018-07-27 03:12:35 --> Controller Class Initialized
DEBUG - 2018-07-27 03:12:35 --> Home MX_Controller Initialized
DEBUG - 2018-07-27 03:12:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-27 03:12:35 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-27 03:12:35 --> Login MX_Controller Initialized
INFO - 2018-07-27 03:12:35 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-27 03:12:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-27 03:12:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-27 03:12:37 --> Config Class Initialized
INFO - 2018-07-27 03:12:37 --> Hooks Class Initialized
DEBUG - 2018-07-27 03:12:37 --> UTF-8 Support Enabled
INFO - 2018-07-27 03:12:37 --> Utf8 Class Initialized
INFO - 2018-07-27 03:12:37 --> Config Class Initialized
INFO - 2018-07-27 03:12:37 --> Hooks Class Initialized
INFO - 2018-07-27 03:12:37 --> URI Class Initialized
DEBUG - 2018-07-27 03:12:37 --> UTF-8 Support Enabled
INFO - 2018-07-27 03:12:37 --> Router Class Initialized
INFO - 2018-07-27 03:12:37 --> Utf8 Class Initialized
INFO - 2018-07-27 03:12:37 --> Output Class Initialized
INFO - 2018-07-27 03:12:37 --> Security Class Initialized
INFO - 2018-07-27 03:12:37 --> URI Class Initialized
DEBUG - 2018-07-27 03:12:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 03:12:37 --> Router Class Initialized
INFO - 2018-07-27 03:12:37 --> Input Class Initialized
INFO - 2018-07-27 03:12:37 --> Output Class Initialized
INFO - 2018-07-27 03:12:38 --> Security Class Initialized
INFO - 2018-07-27 03:12:38 --> Language Class Initialized
DEBUG - 2018-07-27 03:12:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 03:12:38 --> Language Class Initialized
INFO - 2018-07-27 03:12:38 --> Input Class Initialized
INFO - 2018-07-27 03:12:38 --> Config Class Initialized
INFO - 2018-07-27 03:12:38 --> Language Class Initialized
INFO - 2018-07-27 03:12:38 --> Loader Class Initialized
ERROR - 2018-07-27 03:12:38 --> 404 Page Not Found: /index
DEBUG - 2018-07-27 03:12:38 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-27 03:12:38 --> Helper loaded: url_helper
INFO - 2018-07-27 03:12:38 --> Config Class Initialized
INFO - 2018-07-27 03:12:38 --> Hooks Class Initialized
INFO - 2018-07-27 03:12:38 --> Helper loaded: form_helper
DEBUG - 2018-07-27 03:12:38 --> UTF-8 Support Enabled
INFO - 2018-07-27 03:12:38 --> Helper loaded: date_helper
INFO - 2018-07-27 03:12:38 --> Utf8 Class Initialized
INFO - 2018-07-27 03:12:38 --> URI Class Initialized
INFO - 2018-07-27 03:12:38 --> Helper loaded: util_helper
INFO - 2018-07-27 03:12:38 --> Router Class Initialized
INFO - 2018-07-27 03:12:38 --> Output Class Initialized
INFO - 2018-07-27 03:12:38 --> Helper loaded: text_helper
INFO - 2018-07-27 03:12:38 --> Security Class Initialized
INFO - 2018-07-27 03:12:38 --> Helper loaded: string_helper
DEBUG - 2018-07-27 03:12:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 03:12:38 --> Database Driver Class Initialized
INFO - 2018-07-27 03:12:38 --> Input Class Initialized
INFO - 2018-07-27 03:12:38 --> Language Class Initialized
DEBUG - 2018-07-27 03:12:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 03:12:38 --> Session: Class initialized using 'files' driver.
ERROR - 2018-07-27 03:12:38 --> 404 Page Not Found: /index
INFO - 2018-07-27 03:12:38 --> Email Class Initialized
INFO - 2018-07-27 03:12:38 --> Config Class Initialized
INFO - 2018-07-27 03:12:38 --> Hooks Class Initialized
INFO - 2018-07-27 03:12:38 --> Controller Class Initialized
DEBUG - 2018-07-27 03:12:38 --> Home MX_Controller Initialized
DEBUG - 2018-07-27 03:12:38 --> UTF-8 Support Enabled
INFO - 2018-07-27 03:12:38 --> Utf8 Class Initialized
DEBUG - 2018-07-27 03:12:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-07-27 03:12:38 --> URI Class Initialized
INFO - 2018-07-27 03:12:38 --> Router Class Initialized
INFO - 2018-07-27 03:12:38 --> Output Class Initialized
INFO - 2018-07-27 03:12:38 --> Security Class Initialized
DEBUG - 2018-07-27 03:12:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 03:12:38 --> Input Class Initialized
INFO - 2018-07-27 03:12:38 --> Language Class Initialized
ERROR - 2018-07-27 03:12:38 --> 404 Page Not Found: /index
DEBUG - 2018-07-27 03:12:38 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-27 03:12:38 --> Login MX_Controller Initialized
INFO - 2018-07-27 03:12:38 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-27 03:12:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-27 03:12:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-27 03:12:40 --> Config Class Initialized
INFO - 2018-07-27 03:12:40 --> Hooks Class Initialized
DEBUG - 2018-07-27 03:12:40 --> UTF-8 Support Enabled
INFO - 2018-07-27 03:12:40 --> Utf8 Class Initialized
INFO - 2018-07-27 03:12:40 --> Config Class Initialized
INFO - 2018-07-27 03:12:40 --> Hooks Class Initialized
INFO - 2018-07-27 03:12:40 --> URI Class Initialized
DEBUG - 2018-07-27 03:12:40 --> UTF-8 Support Enabled
INFO - 2018-07-27 03:12:40 --> Router Class Initialized
INFO - 2018-07-27 03:12:40 --> Utf8 Class Initialized
INFO - 2018-07-27 03:12:40 --> Output Class Initialized
INFO - 2018-07-27 03:12:40 --> URI Class Initialized
INFO - 2018-07-27 03:12:40 --> Security Class Initialized
INFO - 2018-07-27 03:12:40 --> Router Class Initialized
DEBUG - 2018-07-27 03:12:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 03:12:40 --> Input Class Initialized
INFO - 2018-07-27 03:12:40 --> Output Class Initialized
INFO - 2018-07-27 03:12:40 --> Security Class Initialized
INFO - 2018-07-27 03:12:40 --> Language Class Initialized
DEBUG - 2018-07-27 03:12:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 03:12:40 --> Language Class Initialized
INFO - 2018-07-27 03:12:40 --> Input Class Initialized
INFO - 2018-07-27 03:12:40 --> Config Class Initialized
INFO - 2018-07-27 03:12:40 --> Language Class Initialized
ERROR - 2018-07-27 03:12:40 --> 404 Page Not Found: /index
INFO - 2018-07-27 03:12:40 --> Loader Class Initialized
DEBUG - 2018-07-27 03:12:40 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-27 03:12:40 --> Config Class Initialized
INFO - 2018-07-27 03:12:40 --> Helper loaded: url_helper
INFO - 2018-07-27 03:12:40 --> Helper loaded: form_helper
INFO - 2018-07-27 03:12:40 --> Helper loaded: date_helper
INFO - 2018-07-27 03:12:40 --> Helper loaded: util_helper
INFO - 2018-07-27 03:12:40 --> Hooks Class Initialized
INFO - 2018-07-27 03:12:40 --> Helper loaded: text_helper
DEBUG - 2018-07-27 03:12:40 --> UTF-8 Support Enabled
INFO - 2018-07-27 03:12:40 --> Utf8 Class Initialized
INFO - 2018-07-27 03:12:40 --> URI Class Initialized
INFO - 2018-07-27 03:12:40 --> Router Class Initialized
INFO - 2018-07-27 03:12:40 --> Helper loaded: string_helper
INFO - 2018-07-27 03:12:40 --> Output Class Initialized
INFO - 2018-07-27 03:12:40 --> Database Driver Class Initialized
INFO - 2018-07-27 03:12:40 --> Security Class Initialized
DEBUG - 2018-07-27 03:12:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 03:12:40 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-07-27 03:12:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 03:12:40 --> Input Class Initialized
INFO - 2018-07-27 03:12:40 --> Email Class Initialized
INFO - 2018-07-27 03:12:40 --> Controller Class Initialized
INFO - 2018-07-27 03:12:40 --> Language Class Initialized
DEBUG - 2018-07-27 03:12:40 --> Home MX_Controller Initialized
ERROR - 2018-07-27 03:12:40 --> 404 Page Not Found: /index
DEBUG - 2018-07-27 03:12:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-07-27 03:12:41 --> Config Class Initialized
INFO - 2018-07-27 03:12:41 --> Hooks Class Initialized
DEBUG - 2018-07-27 03:12:41 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-27 03:12:41 --> Login MX_Controller Initialized
DEBUG - 2018-07-27 03:12:41 --> UTF-8 Support Enabled
INFO - 2018-07-27 03:12:41 --> Language file loaded: language/english/data_lang.php
INFO - 2018-07-27 03:12:41 --> Utf8 Class Initialized
DEBUG - 2018-07-27 03:12:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-27 03:12:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-27 03:12:41 --> URI Class Initialized
INFO - 2018-07-27 03:12:41 --> Router Class Initialized
INFO - 2018-07-27 03:12:41 --> Output Class Initialized
INFO - 2018-07-27 03:12:41 --> Security Class Initialized
DEBUG - 2018-07-27 03:12:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 03:12:41 --> Input Class Initialized
INFO - 2018-07-27 03:12:41 --> Language Class Initialized
ERROR - 2018-07-27 03:12:41 --> 404 Page Not Found: /index
INFO - 2018-07-27 03:12:46 --> Config Class Initialized
INFO - 2018-07-27 03:12:46 --> Hooks Class Initialized
DEBUG - 2018-07-27 03:12:46 --> UTF-8 Support Enabled
INFO - 2018-07-27 03:12:46 --> Utf8 Class Initialized
INFO - 2018-07-27 03:12:46 --> URI Class Initialized
DEBUG - 2018-07-27 03:12:46 --> No URI present. Default controller set.
INFO - 2018-07-27 03:12:46 --> Router Class Initialized
INFO - 2018-07-27 03:12:46 --> Output Class Initialized
INFO - 2018-07-27 03:12:46 --> Security Class Initialized
DEBUG - 2018-07-27 03:12:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 03:12:47 --> Input Class Initialized
INFO - 2018-07-27 03:12:47 --> Language Class Initialized
INFO - 2018-07-27 03:12:47 --> Language Class Initialized
INFO - 2018-07-27 03:12:47 --> Config Class Initialized
INFO - 2018-07-27 03:12:47 --> Loader Class Initialized
DEBUG - 2018-07-27 03:12:47 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-27 03:12:47 --> Helper loaded: url_helper
INFO - 2018-07-27 03:12:47 --> Helper loaded: form_helper
INFO - 2018-07-27 03:12:47 --> Helper loaded: date_helper
INFO - 2018-07-27 03:12:47 --> Helper loaded: util_helper
INFO - 2018-07-27 03:12:47 --> Helper loaded: text_helper
INFO - 2018-07-27 03:12:47 --> Helper loaded: string_helper
INFO - 2018-07-27 03:12:47 --> Database Driver Class Initialized
DEBUG - 2018-07-27 03:12:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 03:12:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 03:12:47 --> Email Class Initialized
INFO - 2018-07-27 03:12:47 --> Controller Class Initialized
DEBUG - 2018-07-27 03:12:47 --> Home MX_Controller Initialized
DEBUG - 2018-07-27 03:12:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-27 03:12:47 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-27 03:12:47 --> Login MX_Controller Initialized
INFO - 2018-07-27 03:12:47 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-27 03:12:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-27 03:12:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-27 03:12:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-27 03:12:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-27 03:12:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-27 03:12:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-27 03:12:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-27 03:12:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-27 03:12:47 --> Final output sent to browser
DEBUG - 2018-07-27 03:12:47 --> Total execution time: 0.6288
INFO - 2018-07-27 03:12:48 --> Config Class Initialized
INFO - 2018-07-27 03:12:48 --> Hooks Class Initialized
DEBUG - 2018-07-27 03:12:48 --> UTF-8 Support Enabled
INFO - 2018-07-27 03:12:48 --> Utf8 Class Initialized
INFO - 2018-07-27 03:12:48 --> URI Class Initialized
INFO - 2018-07-27 03:12:48 --> Config Class Initialized
INFO - 2018-07-27 03:12:48 --> Hooks Class Initialized
INFO - 2018-07-27 03:12:48 --> Router Class Initialized
DEBUG - 2018-07-27 03:12:48 --> UTF-8 Support Enabled
INFO - 2018-07-27 03:12:48 --> Utf8 Class Initialized
INFO - 2018-07-27 03:12:48 --> URI Class Initialized
INFO - 2018-07-27 03:12:48 --> Output Class Initialized
INFO - 2018-07-27 03:12:48 --> Router Class Initialized
INFO - 2018-07-27 03:12:48 --> Security Class Initialized
DEBUG - 2018-07-27 03:12:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 03:12:48 --> Input Class Initialized
INFO - 2018-07-27 03:12:48 --> Output Class Initialized
INFO - 2018-07-27 03:12:48 --> Language Class Initialized
INFO - 2018-07-27 03:12:48 --> Security Class Initialized
DEBUG - 2018-07-27 03:12:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 03:12:48 --> Input Class Initialized
INFO - 2018-07-27 03:12:48 --> Language Class Initialized
ERROR - 2018-07-27 03:12:48 --> 404 Page Not Found: /index
INFO - 2018-07-27 03:12:48 --> Language Class Initialized
INFO - 2018-07-27 03:12:48 --> Config Class Initialized
INFO - 2018-07-27 03:12:48 --> Config Class Initialized
INFO - 2018-07-27 03:12:48 --> Hooks Class Initialized
INFO - 2018-07-27 03:12:48 --> Loader Class Initialized
DEBUG - 2018-07-27 03:12:48 --> UTF-8 Support Enabled
INFO - 2018-07-27 03:12:48 --> Utf8 Class Initialized
INFO - 2018-07-27 03:12:48 --> URI Class Initialized
DEBUG - 2018-07-27 03:12:48 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-27 03:12:48 --> Router Class Initialized
INFO - 2018-07-27 03:12:48 --> Helper loaded: url_helper
INFO - 2018-07-27 03:12:48 --> Helper loaded: form_helper
INFO - 2018-07-27 03:12:48 --> Helper loaded: date_helper
INFO - 2018-07-27 03:12:48 --> Helper loaded: util_helper
INFO - 2018-07-27 03:12:48 --> Helper loaded: text_helper
INFO - 2018-07-27 03:12:48 --> Helper loaded: string_helper
INFO - 2018-07-27 03:12:48 --> Output Class Initialized
INFO - 2018-07-27 03:12:48 --> Security Class Initialized
DEBUG - 2018-07-27 03:12:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 03:12:49 --> Database Driver Class Initialized
INFO - 2018-07-27 03:12:49 --> Input Class Initialized
DEBUG - 2018-07-27 03:12:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 03:12:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 03:12:49 --> Language Class Initialized
ERROR - 2018-07-27 03:12:49 --> 404 Page Not Found: /index
INFO - 2018-07-27 03:12:49 --> Email Class Initialized
INFO - 2018-07-27 03:12:49 --> Controller Class Initialized
INFO - 2018-07-27 03:12:49 --> Config Class Initialized
DEBUG - 2018-07-27 03:12:49 --> Home MX_Controller Initialized
INFO - 2018-07-27 03:12:49 --> Hooks Class Initialized
DEBUG - 2018-07-27 03:12:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-27 03:12:49 --> UTF-8 Support Enabled
INFO - 2018-07-27 03:12:49 --> Utf8 Class Initialized
DEBUG - 2018-07-27 03:12:49 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-27 03:12:49 --> Login MX_Controller Initialized
INFO - 2018-07-27 03:12:49 --> URI Class Initialized
INFO - 2018-07-27 03:12:49 --> Language file loaded: language/english/data_lang.php
INFO - 2018-07-27 03:12:49 --> Router Class Initialized
DEBUG - 2018-07-27 03:12:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-27 03:12:49 --> Output Class Initialized
DEBUG - 2018-07-27 03:12:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-27 03:12:49 --> Security Class Initialized
DEBUG - 2018-07-27 03:12:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 03:12:49 --> Input Class Initialized
INFO - 2018-07-27 03:12:49 --> Language Class Initialized
ERROR - 2018-07-27 03:12:49 --> 404 Page Not Found: /index
INFO - 2018-07-27 03:12:54 --> Config Class Initialized
INFO - 2018-07-27 03:12:54 --> Hooks Class Initialized
DEBUG - 2018-07-27 03:12:54 --> UTF-8 Support Enabled
INFO - 2018-07-27 03:12:54 --> Utf8 Class Initialized
INFO - 2018-07-27 03:12:54 --> URI Class Initialized
DEBUG - 2018-07-27 03:12:54 --> No URI present. Default controller set.
INFO - 2018-07-27 03:12:54 --> Router Class Initialized
INFO - 2018-07-27 03:12:54 --> Output Class Initialized
INFO - 2018-07-27 03:12:54 --> Security Class Initialized
DEBUG - 2018-07-27 03:12:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 03:12:54 --> Input Class Initialized
INFO - 2018-07-27 03:12:54 --> Language Class Initialized
INFO - 2018-07-27 03:12:54 --> Language Class Initialized
INFO - 2018-07-27 03:12:54 --> Config Class Initialized
INFO - 2018-07-27 03:12:54 --> Loader Class Initialized
DEBUG - 2018-07-27 03:12:54 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-27 03:12:54 --> Helper loaded: url_helper
INFO - 2018-07-27 03:12:54 --> Helper loaded: form_helper
INFO - 2018-07-27 03:12:54 --> Helper loaded: date_helper
INFO - 2018-07-27 03:12:54 --> Helper loaded: util_helper
INFO - 2018-07-27 03:12:54 --> Helper loaded: text_helper
INFO - 2018-07-27 03:12:54 --> Helper loaded: string_helper
INFO - 2018-07-27 03:12:54 --> Database Driver Class Initialized
DEBUG - 2018-07-27 03:12:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 03:12:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 03:12:54 --> Email Class Initialized
INFO - 2018-07-27 03:12:54 --> Controller Class Initialized
DEBUG - 2018-07-27 03:12:54 --> Home MX_Controller Initialized
DEBUG - 2018-07-27 03:12:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-27 03:12:54 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-27 03:12:54 --> Login MX_Controller Initialized
INFO - 2018-07-27 03:12:54 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-27 03:12:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-27 03:12:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-27 03:12:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-07-27 03:13:17 --> Config Class Initialized
INFO - 2018-07-27 03:13:17 --> Hooks Class Initialized
DEBUG - 2018-07-27 03:13:17 --> UTF-8 Support Enabled
INFO - 2018-07-27 03:13:17 --> Utf8 Class Initialized
INFO - 2018-07-27 03:13:17 --> URI Class Initialized
DEBUG - 2018-07-27 03:13:17 --> No URI present. Default controller set.
INFO - 2018-07-27 03:13:17 --> Router Class Initialized
INFO - 2018-07-27 03:13:17 --> Output Class Initialized
INFO - 2018-07-27 03:13:17 --> Security Class Initialized
DEBUG - 2018-07-27 03:13:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 03:13:17 --> Input Class Initialized
INFO - 2018-07-27 03:13:17 --> Language Class Initialized
INFO - 2018-07-27 03:13:17 --> Language Class Initialized
INFO - 2018-07-27 03:13:17 --> Config Class Initialized
INFO - 2018-07-27 03:13:17 --> Loader Class Initialized
DEBUG - 2018-07-27 03:13:17 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-27 03:13:17 --> Helper loaded: url_helper
INFO - 2018-07-27 03:13:17 --> Helper loaded: form_helper
INFO - 2018-07-27 03:13:17 --> Helper loaded: date_helper
INFO - 2018-07-27 03:13:17 --> Helper loaded: util_helper
INFO - 2018-07-27 03:13:17 --> Helper loaded: text_helper
INFO - 2018-07-27 03:13:17 --> Helper loaded: string_helper
INFO - 2018-07-27 03:13:17 --> Database Driver Class Initialized
DEBUG - 2018-07-27 03:13:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 03:13:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 03:13:17 --> Email Class Initialized
INFO - 2018-07-27 03:13:17 --> Controller Class Initialized
DEBUG - 2018-07-27 03:13:17 --> Home MX_Controller Initialized
DEBUG - 2018-07-27 03:13:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-27 03:13:17 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-27 03:13:17 --> Login MX_Controller Initialized
INFO - 2018-07-27 03:13:17 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-27 03:13:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-27 03:13:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-27 03:13:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-07-27 03:14:07 --> Config Class Initialized
INFO - 2018-07-27 03:14:07 --> Hooks Class Initialized
DEBUG - 2018-07-27 03:14:07 --> UTF-8 Support Enabled
INFO - 2018-07-27 03:14:07 --> Utf8 Class Initialized
INFO - 2018-07-27 03:14:07 --> URI Class Initialized
INFO - 2018-07-27 03:14:07 --> Router Class Initialized
INFO - 2018-07-27 03:14:07 --> Output Class Initialized
INFO - 2018-07-27 03:14:07 --> Security Class Initialized
DEBUG - 2018-07-27 03:14:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 03:14:07 --> Input Class Initialized
INFO - 2018-07-27 03:14:07 --> Language Class Initialized
INFO - 2018-07-27 03:14:07 --> Language Class Initialized
INFO - 2018-07-27 03:14:07 --> Config Class Initialized
INFO - 2018-07-27 03:14:07 --> Loader Class Initialized
DEBUG - 2018-07-27 03:14:07 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-27 03:14:07 --> Helper loaded: url_helper
INFO - 2018-07-27 03:14:07 --> Helper loaded: form_helper
INFO - 2018-07-27 03:14:07 --> Helper loaded: date_helper
INFO - 2018-07-27 03:14:07 --> Helper loaded: util_helper
INFO - 2018-07-27 03:14:07 --> Helper loaded: text_helper
INFO - 2018-07-27 03:14:07 --> Helper loaded: string_helper
INFO - 2018-07-27 03:14:07 --> Database Driver Class Initialized
DEBUG - 2018-07-27 03:14:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 03:14:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 03:14:07 --> Email Class Initialized
INFO - 2018-07-27 03:14:07 --> Controller Class Initialized
DEBUG - 2018-07-27 03:14:07 --> Login MX_Controller Initialized
INFO - 2018-07-27 03:14:07 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-27 03:14:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-27 03:14:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-27 03:14:07 --> Email starts for colin fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-07-27 03:14:07 --> User session created for 4
INFO - 2018-07-27 03:14:07 --> Login status colin - success
INFO - 2018-07-27 03:14:07 --> Final output sent to browser
DEBUG - 2018-07-27 03:14:07 --> Total execution time: 0.5332
INFO - 2018-07-27 03:14:07 --> Config Class Initialized
INFO - 2018-07-27 03:14:07 --> Hooks Class Initialized
DEBUG - 2018-07-27 03:14:07 --> UTF-8 Support Enabled
INFO - 2018-07-27 03:14:07 --> Utf8 Class Initialized
INFO - 2018-07-27 03:14:07 --> URI Class Initialized
DEBUG - 2018-07-27 03:14:07 --> No URI present. Default controller set.
INFO - 2018-07-27 03:14:07 --> Router Class Initialized
INFO - 2018-07-27 03:14:07 --> Output Class Initialized
INFO - 2018-07-27 03:14:07 --> Security Class Initialized
DEBUG - 2018-07-27 03:14:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 03:14:07 --> Input Class Initialized
INFO - 2018-07-27 03:14:07 --> Language Class Initialized
INFO - 2018-07-27 03:14:07 --> Language Class Initialized
INFO - 2018-07-27 03:14:07 --> Config Class Initialized
INFO - 2018-07-27 03:14:07 --> Loader Class Initialized
DEBUG - 2018-07-27 03:14:07 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-27 03:14:07 --> Helper loaded: url_helper
INFO - 2018-07-27 03:14:07 --> Helper loaded: form_helper
INFO - 2018-07-27 03:14:07 --> Helper loaded: date_helper
INFO - 2018-07-27 03:14:07 --> Helper loaded: util_helper
INFO - 2018-07-27 03:14:07 --> Helper loaded: text_helper
INFO - 2018-07-27 03:14:08 --> Helper loaded: string_helper
INFO - 2018-07-27 03:14:08 --> Database Driver Class Initialized
DEBUG - 2018-07-27 03:14:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 03:14:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 03:14:08 --> Email Class Initialized
INFO - 2018-07-27 03:14:08 --> Controller Class Initialized
DEBUG - 2018-07-27 03:14:08 --> Home MX_Controller Initialized
DEBUG - 2018-07-27 03:14:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-27 03:14:08 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-27 03:14:08 --> Login MX_Controller Initialized
INFO - 2018-07-27 03:14:08 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-27 03:14:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-27 03:14:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-27 03:14:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-27 03:14:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-27 03:14:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-27 03:14:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-27 03:14:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-27 03:14:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-27 03:14:08 --> Final output sent to browser
DEBUG - 2018-07-27 03:14:08 --> Total execution time: 0.6473
INFO - 2018-07-27 03:14:10 --> Config Class Initialized
INFO - 2018-07-27 03:14:10 --> Hooks Class Initialized
DEBUG - 2018-07-27 03:14:10 --> UTF-8 Support Enabled
INFO - 2018-07-27 03:14:10 --> Utf8 Class Initialized
INFO - 2018-07-27 03:14:10 --> URI Class Initialized
INFO - 2018-07-27 03:14:10 --> Config Class Initialized
INFO - 2018-07-27 03:14:10 --> Hooks Class Initialized
INFO - 2018-07-27 03:14:10 --> Router Class Initialized
DEBUG - 2018-07-27 03:14:10 --> UTF-8 Support Enabled
INFO - 2018-07-27 03:14:10 --> Utf8 Class Initialized
INFO - 2018-07-27 03:14:10 --> URI Class Initialized
INFO - 2018-07-27 03:14:10 --> Output Class Initialized
INFO - 2018-07-27 03:14:10 --> Router Class Initialized
INFO - 2018-07-27 03:14:10 --> Security Class Initialized
DEBUG - 2018-07-27 03:14:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 03:14:10 --> Output Class Initialized
INFO - 2018-07-27 03:14:10 --> Input Class Initialized
INFO - 2018-07-27 03:14:10 --> Security Class Initialized
DEBUG - 2018-07-27 03:14:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 03:14:10 --> Language Class Initialized
ERROR - 2018-07-27 03:14:10 --> 404 Page Not Found: /index
INFO - 2018-07-27 03:14:10 --> Input Class Initialized
INFO - 2018-07-27 03:14:10 --> Config Class Initialized
INFO - 2018-07-27 03:14:10 --> Hooks Class Initialized
DEBUG - 2018-07-27 03:14:10 --> UTF-8 Support Enabled
INFO - 2018-07-27 03:14:10 --> Language Class Initialized
INFO - 2018-07-27 03:14:10 --> Utf8 Class Initialized
INFO - 2018-07-27 03:14:10 --> Language Class Initialized
INFO - 2018-07-27 03:14:10 --> URI Class Initialized
INFO - 2018-07-27 03:14:10 --> Config Class Initialized
INFO - 2018-07-27 03:14:10 --> Router Class Initialized
INFO - 2018-07-27 03:14:10 --> Output Class Initialized
INFO - 2018-07-27 03:14:10 --> Loader Class Initialized
INFO - 2018-07-27 03:14:10 --> Security Class Initialized
DEBUG - 2018-07-27 03:14:10 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-27 03:14:10 --> Helper loaded: url_helper
DEBUG - 2018-07-27 03:14:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 03:14:10 --> Helper loaded: form_helper
INFO - 2018-07-27 03:14:10 --> Helper loaded: date_helper
INFO - 2018-07-27 03:14:11 --> Input Class Initialized
INFO - 2018-07-27 03:14:11 --> Language Class Initialized
INFO - 2018-07-27 03:14:11 --> Helper loaded: util_helper
ERROR - 2018-07-27 03:14:11 --> 404 Page Not Found: /index
INFO - 2018-07-27 03:14:11 --> Helper loaded: text_helper
INFO - 2018-07-27 03:14:11 --> Helper loaded: string_helper
INFO - 2018-07-27 03:14:11 --> Config Class Initialized
INFO - 2018-07-27 03:14:11 --> Hooks Class Initialized
INFO - 2018-07-27 03:14:11 --> Database Driver Class Initialized
DEBUG - 2018-07-27 03:14:11 --> UTF-8 Support Enabled
INFO - 2018-07-27 03:14:11 --> Config Class Initialized
INFO - 2018-07-27 03:14:11 --> Hooks Class Initialized
INFO - 2018-07-27 03:14:11 --> Utf8 Class Initialized
DEBUG - 2018-07-27 03:14:11 --> UTF-8 Support Enabled
DEBUG - 2018-07-27 03:14:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 03:14:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 03:14:11 --> Utf8 Class Initialized
INFO - 2018-07-27 03:14:11 --> URI Class Initialized
INFO - 2018-07-27 03:14:11 --> Email Class Initialized
INFO - 2018-07-27 03:14:11 --> Router Class Initialized
INFO - 2018-07-27 03:14:11 --> Controller Class Initialized
DEBUG - 2018-07-27 03:14:11 --> Home MX_Controller Initialized
DEBUG - 2018-07-27 03:14:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-07-27 03:14:11 --> URI Class Initialized
INFO - 2018-07-27 03:14:11 --> Output Class Initialized
DEBUG - 2018-07-27 03:14:11 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-27 03:14:11 --> Login MX_Controller Initialized
INFO - 2018-07-27 03:14:11 --> Router Class Initialized
INFO - 2018-07-27 03:14:11 --> Language file loaded: language/english/data_lang.php
INFO - 2018-07-27 03:14:11 --> Output Class Initialized
INFO - 2018-07-27 03:14:11 --> Security Class Initialized
DEBUG - 2018-07-27 03:14:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-27 03:14:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-27 03:14:11 --> Security Class Initialized
DEBUG - 2018-07-27 03:14:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 03:14:11 --> Input Class Initialized
INFO - 2018-07-27 03:14:11 --> Language Class Initialized
ERROR - 2018-07-27 03:14:11 --> 404 Page Not Found: /index
DEBUG - 2018-07-27 03:14:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 03:14:11 --> Config Class Initialized
INFO - 2018-07-27 03:14:11 --> Hooks Class Initialized
INFO - 2018-07-27 03:14:11 --> Input Class Initialized
INFO - 2018-07-27 03:14:11 --> Language Class Initialized
DEBUG - 2018-07-27 03:14:11 --> UTF-8 Support Enabled
ERROR - 2018-07-27 03:14:11 --> 404 Page Not Found: /index
INFO - 2018-07-27 03:14:11 --> Utf8 Class Initialized
INFO - 2018-07-27 03:14:11 --> URI Class Initialized
INFO - 2018-07-27 03:14:11 --> Router Class Initialized
INFO - 2018-07-27 03:14:11 --> Output Class Initialized
INFO - 2018-07-27 03:14:11 --> Security Class Initialized
DEBUG - 2018-07-27 03:14:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 03:14:11 --> Input Class Initialized
INFO - 2018-07-27 03:14:11 --> Language Class Initialized
ERROR - 2018-07-27 03:14:11 --> 404 Page Not Found: /index
INFO - 2018-07-27 03:14:11 --> Config Class Initialized
INFO - 2018-07-27 03:14:11 --> Hooks Class Initialized
DEBUG - 2018-07-27 03:14:11 --> UTF-8 Support Enabled
INFO - 2018-07-27 03:14:11 --> Utf8 Class Initialized
INFO - 2018-07-27 03:14:11 --> URI Class Initialized
INFO - 2018-07-27 03:14:11 --> Router Class Initialized
INFO - 2018-07-27 03:14:11 --> Output Class Initialized
INFO - 2018-07-27 03:14:11 --> Security Class Initialized
DEBUG - 2018-07-27 03:14:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 03:14:11 --> Input Class Initialized
INFO - 2018-07-27 03:14:11 --> Language Class Initialized
ERROR - 2018-07-27 03:14:11 --> 404 Page Not Found: /index
INFO - 2018-07-27 03:14:11 --> Config Class Initialized
INFO - 2018-07-27 03:14:12 --> Hooks Class Initialized
DEBUG - 2018-07-27 03:14:12 --> UTF-8 Support Enabled
INFO - 2018-07-27 03:14:12 --> Utf8 Class Initialized
INFO - 2018-07-27 03:14:12 --> URI Class Initialized
INFO - 2018-07-27 03:14:12 --> Router Class Initialized
INFO - 2018-07-27 03:14:12 --> Output Class Initialized
INFO - 2018-07-27 03:14:12 --> Security Class Initialized
DEBUG - 2018-07-27 03:14:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 03:14:12 --> Input Class Initialized
INFO - 2018-07-27 03:14:12 --> Language Class Initialized
ERROR - 2018-07-27 03:14:12 --> 404 Page Not Found: /index
INFO - 2018-07-27 03:14:18 --> Config Class Initialized
INFO - 2018-07-27 03:14:18 --> Hooks Class Initialized
DEBUG - 2018-07-27 03:14:18 --> UTF-8 Support Enabled
INFO - 2018-07-27 03:14:18 --> Utf8 Class Initialized
INFO - 2018-07-27 03:14:18 --> URI Class Initialized
INFO - 2018-07-27 03:14:18 --> Config Class Initialized
INFO - 2018-07-27 03:14:18 --> Hooks Class Initialized
INFO - 2018-07-27 03:14:18 --> Router Class Initialized
INFO - 2018-07-27 03:14:18 --> Output Class Initialized
DEBUG - 2018-07-27 03:14:18 --> UTF-8 Support Enabled
INFO - 2018-07-27 03:14:18 --> Security Class Initialized
INFO - 2018-07-27 03:14:18 --> Utf8 Class Initialized
DEBUG - 2018-07-27 03:14:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 03:14:18 --> URI Class Initialized
INFO - 2018-07-27 03:14:18 --> Input Class Initialized
INFO - 2018-07-27 03:14:18 --> Language Class Initialized
INFO - 2018-07-27 03:14:18 --> Router Class Initialized
INFO - 2018-07-27 03:14:18 --> Language Class Initialized
INFO - 2018-07-27 03:14:18 --> Output Class Initialized
INFO - 2018-07-27 03:14:18 --> Config Class Initialized
INFO - 2018-07-27 03:14:18 --> Security Class Initialized
INFO - 2018-07-27 03:14:18 --> Loader Class Initialized
DEBUG - 2018-07-27 03:14:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 03:14:18 --> Input Class Initialized
DEBUG - 2018-07-27 03:14:18 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-27 03:14:18 --> Helper loaded: url_helper
INFO - 2018-07-27 03:14:18 --> Language Class Initialized
ERROR - 2018-07-27 03:14:18 --> 404 Page Not Found: /index
INFO - 2018-07-27 03:14:18 --> Helper loaded: form_helper
INFO - 2018-07-27 03:14:18 --> Helper loaded: date_helper
INFO - 2018-07-27 03:14:18 --> Config Class Initialized
INFO - 2018-07-27 03:14:18 --> Hooks Class Initialized
INFO - 2018-07-27 03:14:18 --> Helper loaded: util_helper
INFO - 2018-07-27 03:14:18 --> Helper loaded: text_helper
DEBUG - 2018-07-27 03:14:18 --> UTF-8 Support Enabled
INFO - 2018-07-27 03:14:18 --> Helper loaded: string_helper
INFO - 2018-07-27 03:14:18 --> Utf8 Class Initialized
INFO - 2018-07-27 03:14:18 --> URI Class Initialized
INFO - 2018-07-27 03:14:18 --> Database Driver Class Initialized
INFO - 2018-07-27 03:14:18 --> Router Class Initialized
DEBUG - 2018-07-27 03:14:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 03:14:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 03:14:18 --> Output Class Initialized
INFO - 2018-07-27 03:14:18 --> Security Class Initialized
INFO - 2018-07-27 03:14:18 --> Email Class Initialized
INFO - 2018-07-27 03:14:18 --> Controller Class Initialized
DEBUG - 2018-07-27 03:14:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-07-27 03:14:18 --> Home MX_Controller Initialized
INFO - 2018-07-27 03:14:18 --> Input Class Initialized
INFO - 2018-07-27 03:14:18 --> Language Class Initialized
DEBUG - 2018-07-27 03:14:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
ERROR - 2018-07-27 03:14:18 --> 404 Page Not Found: /index
DEBUG - 2018-07-27 03:14:18 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-27 03:14:18 --> Login MX_Controller Initialized
INFO - 2018-07-27 03:14:18 --> Config Class Initialized
INFO - 2018-07-27 03:14:18 --> Language file loaded: language/english/data_lang.php
INFO - 2018-07-27 03:14:18 --> Hooks Class Initialized
DEBUG - 2018-07-27 03:14:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-27 03:14:18 --> UTF-8 Support Enabled
DEBUG - 2018-07-27 03:14:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-27 03:14:18 --> Utf8 Class Initialized
INFO - 2018-07-27 03:14:18 --> URI Class Initialized
INFO - 2018-07-27 03:14:18 --> Router Class Initialized
INFO - 2018-07-27 03:14:18 --> Output Class Initialized
INFO - 2018-07-27 03:14:18 --> Security Class Initialized
DEBUG - 2018-07-27 03:14:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 03:14:18 --> Input Class Initialized
INFO - 2018-07-27 03:14:18 --> Language Class Initialized
ERROR - 2018-07-27 03:14:18 --> 404 Page Not Found: /index
INFO - 2018-07-27 03:14:18 --> Config Class Initialized
INFO - 2018-07-27 03:14:18 --> Hooks Class Initialized
DEBUG - 2018-07-27 03:14:18 --> UTF-8 Support Enabled
INFO - 2018-07-27 03:14:18 --> Utf8 Class Initialized
INFO - 2018-07-27 03:14:18 --> URI Class Initialized
INFO - 2018-07-27 03:14:18 --> Router Class Initialized
INFO - 2018-07-27 03:14:18 --> Output Class Initialized
INFO - 2018-07-27 03:14:18 --> Security Class Initialized
DEBUG - 2018-07-27 03:14:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 03:14:18 --> Input Class Initialized
INFO - 2018-07-27 03:14:18 --> Language Class Initialized
ERROR - 2018-07-27 03:14:18 --> 404 Page Not Found: /index
INFO - 2018-07-27 03:14:19 --> Config Class Initialized
INFO - 2018-07-27 03:14:19 --> Hooks Class Initialized
DEBUG - 2018-07-27 03:14:19 --> UTF-8 Support Enabled
INFO - 2018-07-27 03:14:19 --> Utf8 Class Initialized
INFO - 2018-07-27 03:14:19 --> URI Class Initialized
INFO - 2018-07-27 03:14:19 --> Router Class Initialized
INFO - 2018-07-27 03:14:19 --> Output Class Initialized
INFO - 2018-07-27 03:14:19 --> Security Class Initialized
DEBUG - 2018-07-27 03:14:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 03:14:19 --> Input Class Initialized
INFO - 2018-07-27 03:14:19 --> Language Class Initialized
ERROR - 2018-07-27 03:14:19 --> 404 Page Not Found: /index
INFO - 2018-07-27 03:14:19 --> Config Class Initialized
INFO - 2018-07-27 03:14:19 --> Hooks Class Initialized
DEBUG - 2018-07-27 03:14:19 --> UTF-8 Support Enabled
INFO - 2018-07-27 03:14:19 --> Utf8 Class Initialized
INFO - 2018-07-27 03:14:19 --> URI Class Initialized
INFO - 2018-07-27 03:14:19 --> Router Class Initialized
INFO - 2018-07-27 03:14:19 --> Output Class Initialized
INFO - 2018-07-27 03:14:19 --> Security Class Initialized
DEBUG - 2018-07-27 03:14:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 03:14:19 --> Input Class Initialized
INFO - 2018-07-27 03:14:19 --> Language Class Initialized
ERROR - 2018-07-27 03:14:19 --> 404 Page Not Found: /index
INFO - 2018-07-27 03:14:34 --> Config Class Initialized
INFO - 2018-07-27 03:14:34 --> Hooks Class Initialized
DEBUG - 2018-07-27 03:14:34 --> UTF-8 Support Enabled
INFO - 2018-07-27 03:14:34 --> Utf8 Class Initialized
INFO - 2018-07-27 03:14:34 --> URI Class Initialized
INFO - 2018-07-27 03:14:34 --> Router Class Initialized
INFO - 2018-07-27 03:14:34 --> Output Class Initialized
INFO - 2018-07-27 03:14:34 --> Security Class Initialized
DEBUG - 2018-07-27 03:14:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 03:14:34 --> Input Class Initialized
INFO - 2018-07-27 03:14:34 --> Language Class Initialized
INFO - 2018-07-27 03:14:34 --> Language Class Initialized
INFO - 2018-07-27 03:14:34 --> Config Class Initialized
INFO - 2018-07-27 03:14:34 --> Loader Class Initialized
DEBUG - 2018-07-27 03:14:34 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-27 03:14:34 --> Helper loaded: url_helper
INFO - 2018-07-27 03:14:34 --> Helper loaded: form_helper
INFO - 2018-07-27 03:14:34 --> Helper loaded: date_helper
INFO - 2018-07-27 03:14:34 --> Helper loaded: util_helper
INFO - 2018-07-27 03:14:34 --> Helper loaded: text_helper
INFO - 2018-07-27 03:14:35 --> Helper loaded: string_helper
INFO - 2018-07-27 03:14:35 --> Database Driver Class Initialized
DEBUG - 2018-07-27 03:14:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 03:14:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 03:14:35 --> Email Class Initialized
INFO - 2018-07-27 03:14:35 --> Controller Class Initialized
DEBUG - 2018-07-27 03:14:35 --> Login MX_Controller Initialized
INFO - 2018-07-27 03:14:35 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-27 03:14:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-27 03:14:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-27 03:14:35 --> 4 Loggedout
INFO - 2018-07-27 03:14:35 --> Config Class Initialized
INFO - 2018-07-27 03:14:35 --> Hooks Class Initialized
DEBUG - 2018-07-27 03:14:35 --> UTF-8 Support Enabled
INFO - 2018-07-27 03:14:35 --> Utf8 Class Initialized
INFO - 2018-07-27 03:14:35 --> URI Class Initialized
INFO - 2018-07-27 03:14:35 --> Router Class Initialized
INFO - 2018-07-27 03:14:35 --> Output Class Initialized
INFO - 2018-07-27 03:14:35 --> Security Class Initialized
DEBUG - 2018-07-27 03:14:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 03:14:35 --> Input Class Initialized
INFO - 2018-07-27 03:14:35 --> Language Class Initialized
INFO - 2018-07-27 03:14:35 --> Language Class Initialized
INFO - 2018-07-27 03:14:35 --> Config Class Initialized
INFO - 2018-07-27 03:14:35 --> Loader Class Initialized
DEBUG - 2018-07-27 03:14:35 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-27 03:14:35 --> Helper loaded: url_helper
INFO - 2018-07-27 03:14:35 --> Helper loaded: form_helper
INFO - 2018-07-27 03:14:35 --> Helper loaded: date_helper
INFO - 2018-07-27 03:14:35 --> Helper loaded: util_helper
INFO - 2018-07-27 03:14:35 --> Helper loaded: text_helper
INFO - 2018-07-27 03:14:35 --> Helper loaded: string_helper
INFO - 2018-07-27 03:14:35 --> Database Driver Class Initialized
DEBUG - 2018-07-27 03:14:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 03:14:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 03:14:35 --> Email Class Initialized
INFO - 2018-07-27 03:14:35 --> Controller Class Initialized
DEBUG - 2018-07-27 03:14:35 --> Home MX_Controller Initialized
DEBUG - 2018-07-27 03:14:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-27 03:14:35 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-27 03:14:35 --> Login MX_Controller Initialized
INFO - 2018-07-27 03:14:35 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-27 03:14:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-27 03:14:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-27 03:14:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-07-27 03:14:40 --> Config Class Initialized
INFO - 2018-07-27 03:14:40 --> Hooks Class Initialized
DEBUG - 2018-07-27 03:14:40 --> UTF-8 Support Enabled
INFO - 2018-07-27 03:14:40 --> Utf8 Class Initialized
INFO - 2018-07-27 03:14:40 --> URI Class Initialized
INFO - 2018-07-27 03:14:40 --> Router Class Initialized
INFO - 2018-07-27 03:14:40 --> Output Class Initialized
INFO - 2018-07-27 03:14:40 --> Security Class Initialized
DEBUG - 2018-07-27 03:14:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 03:14:41 --> Input Class Initialized
INFO - 2018-07-27 03:14:41 --> Language Class Initialized
INFO - 2018-07-27 03:14:41 --> Language Class Initialized
INFO - 2018-07-27 03:14:41 --> Config Class Initialized
INFO - 2018-07-27 03:14:41 --> Loader Class Initialized
DEBUG - 2018-07-27 03:14:41 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-27 03:14:41 --> Helper loaded: url_helper
INFO - 2018-07-27 03:14:41 --> Helper loaded: form_helper
INFO - 2018-07-27 03:14:41 --> Helper loaded: date_helper
INFO - 2018-07-27 03:14:41 --> Helper loaded: util_helper
INFO - 2018-07-27 03:14:41 --> Helper loaded: text_helper
INFO - 2018-07-27 03:14:41 --> Helper loaded: string_helper
INFO - 2018-07-27 03:14:41 --> Database Driver Class Initialized
DEBUG - 2018-07-27 03:14:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 03:14:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 03:14:41 --> Email Class Initialized
INFO - 2018-07-27 03:14:41 --> Controller Class Initialized
DEBUG - 2018-07-27 03:14:41 --> Login MX_Controller Initialized
INFO - 2018-07-27 03:14:41 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-27 03:14:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-27 03:14:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-27 03:14:41 --> Email starts for colin fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-07-27 03:14:41 --> User session created for 4
INFO - 2018-07-27 03:14:41 --> Login status colin - success
INFO - 2018-07-27 03:14:41 --> Final output sent to browser
DEBUG - 2018-07-27 03:14:41 --> Total execution time: 0.4787
INFO - 2018-07-27 03:14:41 --> Config Class Initialized
INFO - 2018-07-27 03:14:41 --> Hooks Class Initialized
DEBUG - 2018-07-27 03:14:41 --> UTF-8 Support Enabled
INFO - 2018-07-27 03:14:41 --> Utf8 Class Initialized
INFO - 2018-07-27 03:14:41 --> URI Class Initialized
INFO - 2018-07-27 03:14:41 --> Router Class Initialized
INFO - 2018-07-27 03:14:41 --> Output Class Initialized
INFO - 2018-07-27 03:14:41 --> Security Class Initialized
DEBUG - 2018-07-27 03:14:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 03:14:41 --> Input Class Initialized
INFO - 2018-07-27 03:14:41 --> Language Class Initialized
INFO - 2018-07-27 03:14:41 --> Language Class Initialized
INFO - 2018-07-27 03:14:41 --> Config Class Initialized
INFO - 2018-07-27 03:14:41 --> Loader Class Initialized
DEBUG - 2018-07-27 03:14:41 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-27 03:14:41 --> Helper loaded: url_helper
INFO - 2018-07-27 03:14:41 --> Helper loaded: form_helper
INFO - 2018-07-27 03:14:41 --> Helper loaded: date_helper
INFO - 2018-07-27 03:14:41 --> Helper loaded: util_helper
INFO - 2018-07-27 03:14:41 --> Helper loaded: text_helper
INFO - 2018-07-27 03:14:41 --> Helper loaded: string_helper
INFO - 2018-07-27 03:14:41 --> Database Driver Class Initialized
DEBUG - 2018-07-27 03:14:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 03:14:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 03:14:41 --> Email Class Initialized
INFO - 2018-07-27 03:14:41 --> Controller Class Initialized
DEBUG - 2018-07-27 03:14:41 --> Home MX_Controller Initialized
DEBUG - 2018-07-27 03:14:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-27 03:14:41 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-27 03:14:41 --> Login MX_Controller Initialized
INFO - 2018-07-27 03:14:41 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-27 03:14:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-27 03:14:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-27 03:14:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-27 03:14:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-27 03:14:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-27 03:14:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-27 03:14:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-27 03:14:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-27 03:14:42 --> Final output sent to browser
DEBUG - 2018-07-27 03:14:42 --> Total execution time: 0.6033
INFO - 2018-07-27 03:14:42 --> Config Class Initialized
INFO - 2018-07-27 03:14:42 --> Hooks Class Initialized
DEBUG - 2018-07-27 03:14:42 --> UTF-8 Support Enabled
INFO - 2018-07-27 03:14:42 --> Config Class Initialized
INFO - 2018-07-27 03:14:42 --> Hooks Class Initialized
INFO - 2018-07-27 03:14:42 --> Utf8 Class Initialized
DEBUG - 2018-07-27 03:14:42 --> UTF-8 Support Enabled
INFO - 2018-07-27 03:14:42 --> Utf8 Class Initialized
INFO - 2018-07-27 03:14:42 --> URI Class Initialized
INFO - 2018-07-27 03:14:42 --> URI Class Initialized
INFO - 2018-07-27 03:14:42 --> Router Class Initialized
INFO - 2018-07-27 03:14:42 --> Output Class Initialized
INFO - 2018-07-27 03:14:42 --> Router Class Initialized
INFO - 2018-07-27 03:14:42 --> Security Class Initialized
DEBUG - 2018-07-27 03:14:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 03:14:42 --> Input Class Initialized
INFO - 2018-07-27 03:14:42 --> Output Class Initialized
INFO - 2018-07-27 03:14:42 --> Language Class Initialized
INFO - 2018-07-27 03:14:42 --> Security Class Initialized
ERROR - 2018-07-27 03:14:42 --> 404 Page Not Found: /index
INFO - 2018-07-27 03:14:42 --> Config Class Initialized
INFO - 2018-07-27 03:14:42 --> Hooks Class Initialized
DEBUG - 2018-07-27 03:14:42 --> UTF-8 Support Enabled
DEBUG - 2018-07-27 03:14:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 03:14:42 --> Utf8 Class Initialized
INFO - 2018-07-27 03:14:42 --> URI Class Initialized
INFO - 2018-07-27 03:14:42 --> Input Class Initialized
INFO - 2018-07-27 03:14:42 --> Router Class Initialized
INFO - 2018-07-27 03:14:42 --> Language Class Initialized
INFO - 2018-07-27 03:14:42 --> Output Class Initialized
INFO - 2018-07-27 03:14:42 --> Language Class Initialized
INFO - 2018-07-27 03:14:43 --> Config Class Initialized
INFO - 2018-07-27 03:14:43 --> Loader Class Initialized
DEBUG - 2018-07-27 03:14:43 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-27 03:14:43 --> Security Class Initialized
INFO - 2018-07-27 03:14:43 --> Helper loaded: url_helper
DEBUG - 2018-07-27 03:14:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 03:14:43 --> Input Class Initialized
INFO - 2018-07-27 03:14:43 --> Helper loaded: form_helper
INFO - 2018-07-27 03:14:43 --> Language Class Initialized
ERROR - 2018-07-27 03:14:43 --> 404 Page Not Found: /index
INFO - 2018-07-27 03:14:43 --> Helper loaded: date_helper
INFO - 2018-07-27 03:14:43 --> Config Class Initialized
INFO - 2018-07-27 03:14:43 --> Hooks Class Initialized
INFO - 2018-07-27 03:14:43 --> Config Class Initialized
INFO - 2018-07-27 03:14:43 --> Hooks Class Initialized
DEBUG - 2018-07-27 03:14:43 --> UTF-8 Support Enabled
INFO - 2018-07-27 03:14:43 --> Helper loaded: util_helper
INFO - 2018-07-27 03:14:43 --> Utf8 Class Initialized
INFO - 2018-07-27 03:14:43 --> Helper loaded: text_helper
DEBUG - 2018-07-27 03:14:43 --> UTF-8 Support Enabled
INFO - 2018-07-27 03:14:43 --> URI Class Initialized
INFO - 2018-07-27 03:14:43 --> Helper loaded: string_helper
INFO - 2018-07-27 03:14:43 --> Router Class Initialized
INFO - 2018-07-27 03:14:43 --> Utf8 Class Initialized
INFO - 2018-07-27 03:14:43 --> Output Class Initialized
INFO - 2018-07-27 03:14:43 --> Database Driver Class Initialized
INFO - 2018-07-27 03:14:43 --> Security Class Initialized
DEBUG - 2018-07-27 03:14:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-07-27 03:14:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 03:14:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 03:14:43 --> URI Class Initialized
INFO - 2018-07-27 03:14:43 --> Input Class Initialized
INFO - 2018-07-27 03:14:43 --> Email Class Initialized
INFO - 2018-07-27 03:14:43 --> Controller Class Initialized
INFO - 2018-07-27 03:14:43 --> Language Class Initialized
INFO - 2018-07-27 03:14:43 --> Router Class Initialized
DEBUG - 2018-07-27 03:14:43 --> Home MX_Controller Initialized
ERROR - 2018-07-27 03:14:43 --> 404 Page Not Found: /index
INFO - 2018-07-27 03:14:43 --> Output Class Initialized
DEBUG - 2018-07-27 03:14:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-07-27 03:14:43 --> Security Class Initialized
DEBUG - 2018-07-27 03:14:43 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-27 03:14:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-07-27 03:14:43 --> Login MX_Controller Initialized
INFO - 2018-07-27 03:14:43 --> Input Class Initialized
INFO - 2018-07-27 03:14:43 --> Language file loaded: language/english/data_lang.php
INFO - 2018-07-27 03:14:43 --> Language Class Initialized
DEBUG - 2018-07-27 03:14:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
ERROR - 2018-07-27 03:14:43 --> 404 Page Not Found: /index
DEBUG - 2018-07-27 03:14:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-27 03:14:43 --> Config Class Initialized
INFO - 2018-07-27 03:14:43 --> Hooks Class Initialized
DEBUG - 2018-07-27 03:14:43 --> UTF-8 Support Enabled
INFO - 2018-07-27 03:14:43 --> Utf8 Class Initialized
INFO - 2018-07-27 03:14:43 --> URI Class Initialized
INFO - 2018-07-27 03:14:43 --> Router Class Initialized
INFO - 2018-07-27 03:14:43 --> Output Class Initialized
INFO - 2018-07-27 03:14:43 --> Security Class Initialized
DEBUG - 2018-07-27 03:14:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 03:14:43 --> Input Class Initialized
INFO - 2018-07-27 03:14:43 --> Language Class Initialized
ERROR - 2018-07-27 03:14:43 --> 404 Page Not Found: /index
INFO - 2018-07-27 03:14:43 --> Config Class Initialized
INFO - 2018-07-27 03:14:43 --> Hooks Class Initialized
DEBUG - 2018-07-27 03:14:43 --> UTF-8 Support Enabled
INFO - 2018-07-27 03:14:43 --> Utf8 Class Initialized
INFO - 2018-07-27 03:14:43 --> URI Class Initialized
INFO - 2018-07-27 03:14:43 --> Router Class Initialized
INFO - 2018-07-27 03:14:43 --> Output Class Initialized
INFO - 2018-07-27 03:14:43 --> Security Class Initialized
DEBUG - 2018-07-27 03:14:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 03:14:44 --> Input Class Initialized
INFO - 2018-07-27 03:14:44 --> Language Class Initialized
ERROR - 2018-07-27 03:14:44 --> 404 Page Not Found: /index
INFO - 2018-07-27 03:14:44 --> Config Class Initialized
INFO - 2018-07-27 03:14:44 --> Hooks Class Initialized
DEBUG - 2018-07-27 03:14:44 --> UTF-8 Support Enabled
INFO - 2018-07-27 03:14:44 --> Utf8 Class Initialized
INFO - 2018-07-27 03:14:44 --> URI Class Initialized
INFO - 2018-07-27 03:14:44 --> Router Class Initialized
INFO - 2018-07-27 03:14:44 --> Output Class Initialized
INFO - 2018-07-27 03:14:44 --> Security Class Initialized
DEBUG - 2018-07-27 03:14:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 03:14:44 --> Input Class Initialized
INFO - 2018-07-27 03:14:44 --> Language Class Initialized
ERROR - 2018-07-27 03:14:44 --> 404 Page Not Found: /index
INFO - 2018-07-27 03:14:50 --> Config Class Initialized
INFO - 2018-07-27 03:14:50 --> Hooks Class Initialized
DEBUG - 2018-07-27 03:14:50 --> UTF-8 Support Enabled
INFO - 2018-07-27 03:14:50 --> Utf8 Class Initialized
INFO - 2018-07-27 03:14:51 --> URI Class Initialized
INFO - 2018-07-27 03:14:51 --> Router Class Initialized
INFO - 2018-07-27 03:14:51 --> Output Class Initialized
INFO - 2018-07-27 03:14:51 --> Security Class Initialized
DEBUG - 2018-07-27 03:14:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 03:14:51 --> Input Class Initialized
INFO - 2018-07-27 03:14:51 --> Language Class Initialized
INFO - 2018-07-27 03:14:51 --> Language Class Initialized
INFO - 2018-07-27 03:14:51 --> Config Class Initialized
INFO - 2018-07-27 03:14:51 --> Loader Class Initialized
DEBUG - 2018-07-27 03:14:51 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-27 03:14:51 --> Helper loaded: url_helper
INFO - 2018-07-27 03:14:51 --> Helper loaded: form_helper
INFO - 2018-07-27 03:14:51 --> Helper loaded: date_helper
INFO - 2018-07-27 03:14:51 --> Helper loaded: util_helper
INFO - 2018-07-27 03:14:51 --> Helper loaded: text_helper
INFO - 2018-07-27 03:14:51 --> Helper loaded: string_helper
INFO - 2018-07-27 03:14:51 --> Database Driver Class Initialized
DEBUG - 2018-07-27 03:14:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 03:14:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 03:14:51 --> Email Class Initialized
INFO - 2018-07-27 03:14:51 --> Controller Class Initialized
DEBUG - 2018-07-27 03:14:51 --> Home MX_Controller Initialized
DEBUG - 2018-07-27 03:14:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-27 03:14:51 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-27 03:14:51 --> Login MX_Controller Initialized
INFO - 2018-07-27 03:14:51 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-27 03:14:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-27 03:14:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-27 03:15:05 --> Config Class Initialized
INFO - 2018-07-27 03:15:05 --> Hooks Class Initialized
DEBUG - 2018-07-27 03:15:05 --> UTF-8 Support Enabled
INFO - 2018-07-27 03:15:05 --> Utf8 Class Initialized
INFO - 2018-07-27 03:15:05 --> URI Class Initialized
INFO - 2018-07-27 03:15:05 --> Router Class Initialized
INFO - 2018-07-27 03:15:05 --> Output Class Initialized
INFO - 2018-07-27 03:15:05 --> Security Class Initialized
DEBUG - 2018-07-27 03:15:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 03:15:05 --> Input Class Initialized
INFO - 2018-07-27 03:15:05 --> Language Class Initialized
INFO - 2018-07-27 03:15:05 --> Language Class Initialized
INFO - 2018-07-27 03:15:05 --> Config Class Initialized
INFO - 2018-07-27 03:15:05 --> Loader Class Initialized
DEBUG - 2018-07-27 03:15:05 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-27 03:15:05 --> Helper loaded: url_helper
INFO - 2018-07-27 03:15:05 --> Helper loaded: form_helper
INFO - 2018-07-27 03:15:05 --> Helper loaded: date_helper
INFO - 2018-07-27 03:15:05 --> Helper loaded: util_helper
INFO - 2018-07-27 03:15:05 --> Helper loaded: text_helper
INFO - 2018-07-27 03:15:05 --> Helper loaded: string_helper
INFO - 2018-07-27 03:15:05 --> Database Driver Class Initialized
DEBUG - 2018-07-27 03:15:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 03:15:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 03:15:05 --> Email Class Initialized
INFO - 2018-07-27 03:15:05 --> Controller Class Initialized
DEBUG - 2018-07-27 03:15:05 --> Login MX_Controller Initialized
INFO - 2018-07-27 03:15:05 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-27 03:15:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-27 03:15:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-27 03:15:05 --> 4 Loggedout
INFO - 2018-07-27 03:15:06 --> Config Class Initialized
INFO - 2018-07-27 03:15:06 --> Hooks Class Initialized
DEBUG - 2018-07-27 03:15:06 --> UTF-8 Support Enabled
INFO - 2018-07-27 03:15:06 --> Utf8 Class Initialized
INFO - 2018-07-27 03:15:06 --> URI Class Initialized
INFO - 2018-07-27 03:15:06 --> Router Class Initialized
INFO - 2018-07-27 03:15:06 --> Output Class Initialized
INFO - 2018-07-27 03:15:06 --> Security Class Initialized
DEBUG - 2018-07-27 03:15:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 03:15:06 --> Input Class Initialized
INFO - 2018-07-27 03:15:06 --> Language Class Initialized
INFO - 2018-07-27 03:15:06 --> Language Class Initialized
INFO - 2018-07-27 03:15:06 --> Config Class Initialized
INFO - 2018-07-27 03:15:06 --> Loader Class Initialized
DEBUG - 2018-07-27 03:15:06 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-27 03:15:06 --> Helper loaded: url_helper
INFO - 2018-07-27 03:15:06 --> Helper loaded: form_helper
INFO - 2018-07-27 03:15:06 --> Helper loaded: date_helper
INFO - 2018-07-27 03:15:06 --> Helper loaded: util_helper
INFO - 2018-07-27 03:15:06 --> Helper loaded: text_helper
INFO - 2018-07-27 03:15:06 --> Helper loaded: string_helper
INFO - 2018-07-27 03:15:06 --> Database Driver Class Initialized
DEBUG - 2018-07-27 03:15:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 03:15:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 03:15:06 --> Email Class Initialized
INFO - 2018-07-27 03:15:06 --> Controller Class Initialized
DEBUG - 2018-07-27 03:15:06 --> Home MX_Controller Initialized
DEBUG - 2018-07-27 03:15:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-27 03:15:06 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-27 03:15:06 --> Login MX_Controller Initialized
INFO - 2018-07-27 03:15:06 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-27 03:15:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-27 03:15:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-27 03:15:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-07-27 03:15:21 --> Config Class Initialized
INFO - 2018-07-27 03:15:21 --> Hooks Class Initialized
DEBUG - 2018-07-27 03:15:21 --> UTF-8 Support Enabled
INFO - 2018-07-27 03:15:21 --> Utf8 Class Initialized
INFO - 2018-07-27 03:15:21 --> URI Class Initialized
INFO - 2018-07-27 03:15:21 --> Router Class Initialized
INFO - 2018-07-27 03:15:21 --> Output Class Initialized
INFO - 2018-07-27 03:15:21 --> Security Class Initialized
DEBUG - 2018-07-27 03:15:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 03:15:21 --> Input Class Initialized
INFO - 2018-07-27 03:15:21 --> Language Class Initialized
INFO - 2018-07-27 03:15:21 --> Language Class Initialized
INFO - 2018-07-27 03:15:21 --> Config Class Initialized
INFO - 2018-07-27 03:15:21 --> Loader Class Initialized
DEBUG - 2018-07-27 03:15:21 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-27 03:15:21 --> Helper loaded: url_helper
INFO - 2018-07-27 03:15:21 --> Helper loaded: form_helper
INFO - 2018-07-27 03:15:21 --> Helper loaded: date_helper
INFO - 2018-07-27 03:15:21 --> Helper loaded: util_helper
INFO - 2018-07-27 03:15:21 --> Helper loaded: text_helper
INFO - 2018-07-27 03:15:21 --> Helper loaded: string_helper
INFO - 2018-07-27 03:15:21 --> Database Driver Class Initialized
DEBUG - 2018-07-27 03:15:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 03:15:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 03:15:21 --> Email Class Initialized
INFO - 2018-07-27 03:15:21 --> Controller Class Initialized
DEBUG - 2018-07-27 03:15:21 --> Login MX_Controller Initialized
INFO - 2018-07-27 03:15:21 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-27 03:15:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-27 03:15:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-27 03:15:21 --> Email starts for colin fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-07-27 03:15:21 --> User session created for 4
INFO - 2018-07-27 03:15:21 --> Login status colin - success
INFO - 2018-07-27 03:15:21 --> Final output sent to browser
DEBUG - 2018-07-27 03:15:21 --> Total execution time: 0.5057
INFO - 2018-07-27 03:15:21 --> Config Class Initialized
INFO - 2018-07-27 03:15:21 --> Hooks Class Initialized
DEBUG - 2018-07-27 03:15:21 --> UTF-8 Support Enabled
INFO - 2018-07-27 03:15:21 --> Utf8 Class Initialized
INFO - 2018-07-27 03:15:21 --> URI Class Initialized
INFO - 2018-07-27 03:15:21 --> Router Class Initialized
INFO - 2018-07-27 03:15:21 --> Output Class Initialized
INFO - 2018-07-27 03:15:21 --> Security Class Initialized
DEBUG - 2018-07-27 03:15:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 03:15:22 --> Input Class Initialized
INFO - 2018-07-27 03:15:22 --> Language Class Initialized
INFO - 2018-07-27 03:15:22 --> Language Class Initialized
INFO - 2018-07-27 03:15:22 --> Config Class Initialized
INFO - 2018-07-27 03:15:22 --> Loader Class Initialized
DEBUG - 2018-07-27 03:15:22 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-27 03:15:22 --> Helper loaded: url_helper
INFO - 2018-07-27 03:15:22 --> Helper loaded: form_helper
INFO - 2018-07-27 03:15:22 --> Helper loaded: date_helper
INFO - 2018-07-27 03:15:22 --> Helper loaded: util_helper
INFO - 2018-07-27 03:15:22 --> Helper loaded: text_helper
INFO - 2018-07-27 03:15:22 --> Helper loaded: string_helper
INFO - 2018-07-27 03:15:22 --> Database Driver Class Initialized
DEBUG - 2018-07-27 03:15:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 03:15:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 03:15:22 --> Email Class Initialized
INFO - 2018-07-27 03:15:22 --> Controller Class Initialized
DEBUG - 2018-07-27 03:15:22 --> Home MX_Controller Initialized
DEBUG - 2018-07-27 03:15:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-27 03:15:22 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-27 03:15:22 --> Login MX_Controller Initialized
INFO - 2018-07-27 03:15:22 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-27 03:15:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-27 03:15:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-27 03:15:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-27 03:15:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-27 03:15:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-27 03:15:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-27 03:15:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-27 03:15:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-27 03:15:22 --> Final output sent to browser
DEBUG - 2018-07-27 03:15:22 --> Total execution time: 0.5990
INFO - 2018-07-27 03:15:22 --> Config Class Initialized
INFO - 2018-07-27 03:15:22 --> Hooks Class Initialized
INFO - 2018-07-27 03:15:22 --> Config Class Initialized
INFO - 2018-07-27 03:15:22 --> Hooks Class Initialized
DEBUG - 2018-07-27 03:15:22 --> UTF-8 Support Enabled
DEBUG - 2018-07-27 03:15:22 --> UTF-8 Support Enabled
INFO - 2018-07-27 03:15:22 --> Utf8 Class Initialized
INFO - 2018-07-27 03:15:22 --> URI Class Initialized
INFO - 2018-07-27 03:15:22 --> Utf8 Class Initialized
INFO - 2018-07-27 03:15:22 --> Router Class Initialized
INFO - 2018-07-27 03:15:22 --> URI Class Initialized
INFO - 2018-07-27 03:15:22 --> Output Class Initialized
INFO - 2018-07-27 03:15:23 --> Router Class Initialized
INFO - 2018-07-27 03:15:23 --> Output Class Initialized
INFO - 2018-07-27 03:15:23 --> Security Class Initialized
INFO - 2018-07-27 03:15:23 --> Security Class Initialized
DEBUG - 2018-07-27 03:15:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-07-27 03:15:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 03:15:23 --> Input Class Initialized
INFO - 2018-07-27 03:15:23 --> Language Class Initialized
INFO - 2018-07-27 03:15:23 --> Input Class Initialized
ERROR - 2018-07-27 03:15:23 --> 404 Page Not Found: /index
INFO - 2018-07-27 03:15:23 --> Language Class Initialized
INFO - 2018-07-27 03:15:23 --> Config Class Initialized
INFO - 2018-07-27 03:15:23 --> Hooks Class Initialized
INFO - 2018-07-27 03:15:23 --> Language Class Initialized
DEBUG - 2018-07-27 03:15:23 --> UTF-8 Support Enabled
INFO - 2018-07-27 03:15:23 --> Utf8 Class Initialized
INFO - 2018-07-27 03:15:23 --> Config Class Initialized
INFO - 2018-07-27 03:15:23 --> URI Class Initialized
INFO - 2018-07-27 03:15:23 --> Router Class Initialized
INFO - 2018-07-27 03:15:23 --> Loader Class Initialized
DEBUG - 2018-07-27 03:15:23 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-27 03:15:23 --> Output Class Initialized
INFO - 2018-07-27 03:15:23 --> Security Class Initialized
INFO - 2018-07-27 03:15:23 --> Helper loaded: url_helper
DEBUG - 2018-07-27 03:15:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 03:15:23 --> Helper loaded: form_helper
INFO - 2018-07-27 03:15:23 --> Helper loaded: date_helper
INFO - 2018-07-27 03:15:23 --> Input Class Initialized
INFO - 2018-07-27 03:15:23 --> Helper loaded: util_helper
INFO - 2018-07-27 03:15:23 --> Helper loaded: text_helper
INFO - 2018-07-27 03:15:23 --> Helper loaded: string_helper
INFO - 2018-07-27 03:15:23 --> Database Driver Class Initialized
INFO - 2018-07-27 03:15:23 --> Language Class Initialized
ERROR - 2018-07-27 03:15:23 --> 404 Page Not Found: /index
INFO - 2018-07-27 03:15:23 --> Config Class Initialized
DEBUG - 2018-07-27 03:15:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 03:15:23 --> Hooks Class Initialized
INFO - 2018-07-27 03:15:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 03:15:23 --> Config Class Initialized
DEBUG - 2018-07-27 03:15:23 --> UTF-8 Support Enabled
INFO - 2018-07-27 03:15:23 --> Email Class Initialized
INFO - 2018-07-27 03:15:23 --> Utf8 Class Initialized
INFO - 2018-07-27 03:15:23 --> Controller Class Initialized
INFO - 2018-07-27 03:15:23 --> Hooks Class Initialized
DEBUG - 2018-07-27 03:15:23 --> Home MX_Controller Initialized
INFO - 2018-07-27 03:15:23 --> URI Class Initialized
DEBUG - 2018-07-27 03:15:23 --> UTF-8 Support Enabled
INFO - 2018-07-27 03:15:23 --> Router Class Initialized
DEBUG - 2018-07-27 03:15:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-07-27 03:15:23 --> Utf8 Class Initialized
INFO - 2018-07-27 03:15:23 --> Output Class Initialized
DEBUG - 2018-07-27 03:15:23 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
INFO - 2018-07-27 03:15:23 --> URI Class Initialized
DEBUG - 2018-07-27 03:15:23 --> Login MX_Controller Initialized
INFO - 2018-07-27 03:15:23 --> Security Class Initialized
INFO - 2018-07-27 03:15:23 --> Router Class Initialized
INFO - 2018-07-27 03:15:23 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-27 03:15:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 03:15:23 --> Output Class Initialized
DEBUG - 2018-07-27 03:15:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-27 03:15:23 --> Input Class Initialized
INFO - 2018-07-27 03:15:23 --> Security Class Initialized
DEBUG - 2018-07-27 03:15:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-27 03:15:23 --> Language Class Initialized
ERROR - 2018-07-27 03:15:23 --> 404 Page Not Found: /index
DEBUG - 2018-07-27 03:15:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 03:15:23 --> Config Class Initialized
INFO - 2018-07-27 03:15:24 --> Hooks Class Initialized
INFO - 2018-07-27 03:15:24 --> Input Class Initialized
INFO - 2018-07-27 03:15:24 --> Language Class Initialized
DEBUG - 2018-07-27 03:15:24 --> UTF-8 Support Enabled
INFO - 2018-07-27 03:15:24 --> Utf8 Class Initialized
ERROR - 2018-07-27 03:15:24 --> 404 Page Not Found: /index
INFO - 2018-07-27 03:15:24 --> URI Class Initialized
INFO - 2018-07-27 03:15:24 --> Router Class Initialized
INFO - 2018-07-27 03:15:24 --> Output Class Initialized
INFO - 2018-07-27 03:15:24 --> Security Class Initialized
DEBUG - 2018-07-27 03:15:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 03:15:24 --> Input Class Initialized
INFO - 2018-07-27 03:15:24 --> Language Class Initialized
ERROR - 2018-07-27 03:15:24 --> 404 Page Not Found: /index
INFO - 2018-07-27 03:15:24 --> Config Class Initialized
INFO - 2018-07-27 03:15:24 --> Hooks Class Initialized
DEBUG - 2018-07-27 03:15:24 --> UTF-8 Support Enabled
INFO - 2018-07-27 03:15:24 --> Utf8 Class Initialized
INFO - 2018-07-27 03:15:24 --> URI Class Initialized
INFO - 2018-07-27 03:15:24 --> Router Class Initialized
INFO - 2018-07-27 03:15:24 --> Output Class Initialized
INFO - 2018-07-27 03:15:24 --> Security Class Initialized
DEBUG - 2018-07-27 03:15:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 03:15:24 --> Input Class Initialized
INFO - 2018-07-27 03:15:24 --> Language Class Initialized
ERROR - 2018-07-27 03:15:24 --> 404 Page Not Found: /index
INFO - 2018-07-27 03:15:24 --> Config Class Initialized
INFO - 2018-07-27 03:15:24 --> Hooks Class Initialized
DEBUG - 2018-07-27 03:15:24 --> UTF-8 Support Enabled
INFO - 2018-07-27 03:15:24 --> Utf8 Class Initialized
INFO - 2018-07-27 03:15:24 --> URI Class Initialized
INFO - 2018-07-27 03:15:24 --> Router Class Initialized
INFO - 2018-07-27 03:15:24 --> Output Class Initialized
INFO - 2018-07-27 03:15:24 --> Security Class Initialized
DEBUG - 2018-07-27 03:15:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 03:15:24 --> Input Class Initialized
INFO - 2018-07-27 03:15:24 --> Language Class Initialized
ERROR - 2018-07-27 03:15:24 --> 404 Page Not Found: /index
INFO - 2018-07-27 03:15:29 --> Config Class Initialized
INFO - 2018-07-27 03:15:29 --> Hooks Class Initialized
DEBUG - 2018-07-27 03:15:29 --> UTF-8 Support Enabled
INFO - 2018-07-27 03:15:29 --> Utf8 Class Initialized
INFO - 2018-07-27 03:15:29 --> URI Class Initialized
INFO - 2018-07-27 03:15:29 --> Router Class Initialized
INFO - 2018-07-27 03:15:29 --> Output Class Initialized
INFO - 2018-07-27 03:15:29 --> Security Class Initialized
DEBUG - 2018-07-27 03:15:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 03:15:29 --> Input Class Initialized
INFO - 2018-07-27 03:15:29 --> Language Class Initialized
INFO - 2018-07-27 03:15:29 --> Language Class Initialized
INFO - 2018-07-27 03:15:29 --> Config Class Initialized
INFO - 2018-07-27 03:15:29 --> Loader Class Initialized
DEBUG - 2018-07-27 03:15:29 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-27 03:15:29 --> Helper loaded: url_helper
INFO - 2018-07-27 03:15:29 --> Helper loaded: form_helper
INFO - 2018-07-27 03:15:29 --> Helper loaded: date_helper
INFO - 2018-07-27 03:15:29 --> Helper loaded: util_helper
INFO - 2018-07-27 03:15:29 --> Helper loaded: text_helper
INFO - 2018-07-27 03:15:29 --> Helper loaded: string_helper
INFO - 2018-07-27 03:15:29 --> Database Driver Class Initialized
DEBUG - 2018-07-27 03:15:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 03:15:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 03:15:29 --> Email Class Initialized
INFO - 2018-07-27 03:15:29 --> Controller Class Initialized
DEBUG - 2018-07-27 03:15:29 --> Login MX_Controller Initialized
INFO - 2018-07-27 03:15:29 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-27 03:15:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-27 03:15:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-27 03:15:29 --> 4 Loggedout
INFO - 2018-07-27 03:15:29 --> Config Class Initialized
INFO - 2018-07-27 03:15:29 --> Hooks Class Initialized
DEBUG - 2018-07-27 03:15:29 --> UTF-8 Support Enabled
INFO - 2018-07-27 03:15:29 --> Utf8 Class Initialized
INFO - 2018-07-27 03:15:29 --> URI Class Initialized
INFO - 2018-07-27 03:15:29 --> Router Class Initialized
INFO - 2018-07-27 03:15:29 --> Output Class Initialized
INFO - 2018-07-27 03:15:29 --> Security Class Initialized
DEBUG - 2018-07-27 03:15:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 03:15:29 --> Input Class Initialized
INFO - 2018-07-27 03:15:29 --> Language Class Initialized
INFO - 2018-07-27 03:15:29 --> Language Class Initialized
INFO - 2018-07-27 03:15:29 --> Config Class Initialized
INFO - 2018-07-27 03:15:29 --> Loader Class Initialized
DEBUG - 2018-07-27 03:15:29 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-27 03:15:29 --> Helper loaded: url_helper
INFO - 2018-07-27 03:15:29 --> Helper loaded: form_helper
INFO - 2018-07-27 03:15:30 --> Helper loaded: date_helper
INFO - 2018-07-27 03:15:30 --> Helper loaded: util_helper
INFO - 2018-07-27 03:15:30 --> Helper loaded: text_helper
INFO - 2018-07-27 03:15:30 --> Helper loaded: string_helper
INFO - 2018-07-27 03:15:30 --> Database Driver Class Initialized
DEBUG - 2018-07-27 03:15:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 03:15:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 03:15:30 --> Email Class Initialized
INFO - 2018-07-27 03:15:30 --> Controller Class Initialized
DEBUG - 2018-07-27 03:15:30 --> Home MX_Controller Initialized
DEBUG - 2018-07-27 03:15:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-27 03:15:30 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-27 03:15:30 --> Login MX_Controller Initialized
INFO - 2018-07-27 03:15:30 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-27 03:15:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-27 03:15:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-27 03:15:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-07-27 04:50:19 --> Config Class Initialized
INFO - 2018-07-27 04:50:19 --> Hooks Class Initialized
DEBUG - 2018-07-27 04:50:19 --> UTF-8 Support Enabled
INFO - 2018-07-27 04:50:19 --> Utf8 Class Initialized
INFO - 2018-07-27 04:50:19 --> URI Class Initialized
INFO - 2018-07-27 04:50:19 --> Router Class Initialized
INFO - 2018-07-27 04:50:19 --> Output Class Initialized
INFO - 2018-07-27 04:50:19 --> Security Class Initialized
DEBUG - 2018-07-27 04:50:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 04:50:19 --> Input Class Initialized
INFO - 2018-07-27 04:50:19 --> Language Class Initialized
INFO - 2018-07-27 04:50:19 --> Language Class Initialized
INFO - 2018-07-27 04:50:19 --> Config Class Initialized
INFO - 2018-07-27 04:50:19 --> Loader Class Initialized
DEBUG - 2018-07-27 04:50:19 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-27 04:50:19 --> Helper loaded: url_helper
INFO - 2018-07-27 04:50:19 --> Helper loaded: form_helper
INFO - 2018-07-27 04:50:19 --> Helper loaded: date_helper
INFO - 2018-07-27 04:50:19 --> Helper loaded: util_helper
INFO - 2018-07-27 04:50:19 --> Helper loaded: text_helper
INFO - 2018-07-27 04:50:19 --> Helper loaded: string_helper
INFO - 2018-07-27 04:50:20 --> Database Driver Class Initialized
DEBUG - 2018-07-27 04:50:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 04:50:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 04:50:20 --> Email Class Initialized
INFO - 2018-07-27 04:50:20 --> Controller Class Initialized
DEBUG - 2018-07-27 04:50:20 --> Home MX_Controller Initialized
DEBUG - 2018-07-27 04:50:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-27 04:50:20 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-27 04:50:20 --> Login MX_Controller Initialized
INFO - 2018-07-27 04:50:20 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-27 04:50:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-27 04:50:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-27 04:50:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-27 04:50:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-27 04:50:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-27 04:50:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-27 04:50:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-27 04:50:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-27 04:50:20 --> Final output sent to browser
DEBUG - 2018-07-27 04:50:20 --> Total execution time: 0.7110
INFO - 2018-07-27 04:50:21 --> Config Class Initialized
INFO - 2018-07-27 04:50:21 --> Hooks Class Initialized
DEBUG - 2018-07-27 04:50:21 --> UTF-8 Support Enabled
INFO - 2018-07-27 04:50:21 --> Config Class Initialized
INFO - 2018-07-27 04:50:21 --> Utf8 Class Initialized
INFO - 2018-07-27 04:50:21 --> Hooks Class Initialized
INFO - 2018-07-27 04:50:21 --> URI Class Initialized
INFO - 2018-07-27 04:50:21 --> Router Class Initialized
DEBUG - 2018-07-27 04:50:21 --> UTF-8 Support Enabled
INFO - 2018-07-27 04:50:21 --> Output Class Initialized
INFO - 2018-07-27 04:50:21 --> Security Class Initialized
DEBUG - 2018-07-27 04:50:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 04:50:21 --> Input Class Initialized
INFO - 2018-07-27 04:50:21 --> Language Class Initialized
ERROR - 2018-07-27 04:50:21 --> 404 Page Not Found: /index
INFO - 2018-07-27 04:50:21 --> Utf8 Class Initialized
INFO - 2018-07-27 04:50:21 --> Config Class Initialized
INFO - 2018-07-27 04:50:21 --> Hooks Class Initialized
INFO - 2018-07-27 04:50:21 --> URI Class Initialized
DEBUG - 2018-07-27 04:50:21 --> UTF-8 Support Enabled
INFO - 2018-07-27 04:50:21 --> Router Class Initialized
INFO - 2018-07-27 04:50:21 --> Utf8 Class Initialized
INFO - 2018-07-27 04:50:21 --> Output Class Initialized
INFO - 2018-07-27 04:50:21 --> Security Class Initialized
INFO - 2018-07-27 04:50:21 --> URI Class Initialized
DEBUG - 2018-07-27 04:50:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 04:50:21 --> Router Class Initialized
INFO - 2018-07-27 04:50:21 --> Input Class Initialized
INFO - 2018-07-27 04:50:21 --> Output Class Initialized
INFO - 2018-07-27 04:50:21 --> Security Class Initialized
INFO - 2018-07-27 04:50:21 --> Language Class Initialized
INFO - 2018-07-27 04:50:21 --> Language Class Initialized
DEBUG - 2018-07-27 04:50:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 04:50:21 --> Config Class Initialized
INFO - 2018-07-27 04:50:21 --> Input Class Initialized
INFO - 2018-07-27 04:50:21 --> Language Class Initialized
INFO - 2018-07-27 04:50:21 --> Loader Class Initialized
ERROR - 2018-07-27 04:50:21 --> 404 Page Not Found: /index
DEBUG - 2018-07-27 04:50:21 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-27 04:50:21 --> Helper loaded: url_helper
INFO - 2018-07-27 04:50:21 --> Config Class Initialized
INFO - 2018-07-27 04:50:21 --> Hooks Class Initialized
INFO - 2018-07-27 04:50:21 --> Helper loaded: form_helper
INFO - 2018-07-27 04:50:21 --> Helper loaded: date_helper
DEBUG - 2018-07-27 04:50:21 --> UTF-8 Support Enabled
INFO - 2018-07-27 04:50:21 --> Utf8 Class Initialized
INFO - 2018-07-27 04:50:21 --> Helper loaded: util_helper
INFO - 2018-07-27 04:50:21 --> URI Class Initialized
INFO - 2018-07-27 04:50:21 --> Helper loaded: text_helper
INFO - 2018-07-27 04:50:21 --> Helper loaded: string_helper
INFO - 2018-07-27 04:50:21 --> Router Class Initialized
INFO - 2018-07-27 04:50:21 --> Output Class Initialized
INFO - 2018-07-27 04:50:21 --> Database Driver Class Initialized
INFO - 2018-07-27 04:50:21 --> Security Class Initialized
DEBUG - 2018-07-27 04:50:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 04:50:21 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-07-27 04:50:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 04:50:21 --> Input Class Initialized
INFO - 2018-07-27 04:50:21 --> Email Class Initialized
INFO - 2018-07-27 04:50:21 --> Controller Class Initialized
INFO - 2018-07-27 04:50:21 --> Language Class Initialized
DEBUG - 2018-07-27 04:50:21 --> Home MX_Controller Initialized
ERROR - 2018-07-27 04:50:21 --> 404 Page Not Found: /index
DEBUG - 2018-07-27 04:50:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-27 04:50:21 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-27 04:50:21 --> Login MX_Controller Initialized
INFO - 2018-07-27 04:50:21 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-27 04:50:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-27 04:50:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-27 21:26:45 --> Config Class Initialized
INFO - 2018-07-27 21:26:46 --> Hooks Class Initialized
DEBUG - 2018-07-27 21:26:46 --> UTF-8 Support Enabled
INFO - 2018-07-27 21:26:46 --> Utf8 Class Initialized
INFO - 2018-07-27 21:26:46 --> URI Class Initialized
INFO - 2018-07-27 21:26:46 --> Router Class Initialized
INFO - 2018-07-27 21:26:46 --> Output Class Initialized
INFO - 2018-07-27 21:26:46 --> Security Class Initialized
DEBUG - 2018-07-27 21:26:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 21:26:46 --> Input Class Initialized
INFO - 2018-07-27 21:26:46 --> Language Class Initialized
INFO - 2018-07-27 21:26:47 --> Language Class Initialized
INFO - 2018-07-27 21:26:47 --> Config Class Initialized
INFO - 2018-07-27 21:26:47 --> Loader Class Initialized
DEBUG - 2018-07-27 21:26:47 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-27 21:26:47 --> Helper loaded: url_helper
INFO - 2018-07-27 21:26:47 --> Helper loaded: form_helper
INFO - 2018-07-27 21:26:47 --> Helper loaded: date_helper
INFO - 2018-07-27 21:26:47 --> Helper loaded: util_helper
INFO - 2018-07-27 21:26:47 --> Helper loaded: text_helper
INFO - 2018-07-27 21:26:47 --> Helper loaded: string_helper
INFO - 2018-07-27 21:26:48 --> Database Driver Class Initialized
DEBUG - 2018-07-27 21:26:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 21:26:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 21:26:48 --> Email Class Initialized
INFO - 2018-07-27 21:26:48 --> Controller Class Initialized
DEBUG - 2018-07-27 21:26:48 --> Users MX_Controller Initialized
DEBUG - 2018-07-27 21:26:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-27 21:26:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-27 21:26:48 --> Helper loaded: file_helper
DEBUG - 2018-07-27 21:26:48 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-27 21:26:48 --> Login MX_Controller Initialized
INFO - 2018-07-27 21:26:48 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-27 21:26:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-27 21:26:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
INFO - 2018-07-27 21:26:49 --> Config Class Initialized
INFO - 2018-07-27 21:26:49 --> Hooks Class Initialized
DEBUG - 2018-07-27 21:26:49 --> UTF-8 Support Enabled
INFO - 2018-07-27 21:26:49 --> Utf8 Class Initialized
INFO - 2018-07-27 21:26:49 --> URI Class Initialized
INFO - 2018-07-27 21:26:49 --> Router Class Initialized
INFO - 2018-07-27 21:26:49 --> Output Class Initialized
INFO - 2018-07-27 21:26:49 --> Security Class Initialized
DEBUG - 2018-07-27 21:26:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 21:26:49 --> Input Class Initialized
INFO - 2018-07-27 21:26:49 --> Language Class Initialized
ERROR - 2018-07-27 21:26:49 --> 404 Page Not Found: /index
INFO - 2018-07-27 21:26:50 --> Config Class Initialized
INFO - 2018-07-27 21:26:50 --> Hooks Class Initialized
DEBUG - 2018-07-27 21:26:50 --> UTF-8 Support Enabled
INFO - 2018-07-27 21:26:50 --> Utf8 Class Initialized
INFO - 2018-07-27 21:26:50 --> URI Class Initialized
INFO - 2018-07-27 21:26:50 --> Router Class Initialized
INFO - 2018-07-27 21:26:50 --> Output Class Initialized
INFO - 2018-07-27 21:26:50 --> Security Class Initialized
DEBUG - 2018-07-27 21:26:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 21:26:50 --> Input Class Initialized
INFO - 2018-07-27 21:26:50 --> Language Class Initialized
ERROR - 2018-07-27 21:26:50 --> 404 Page Not Found: /index
INFO - 2018-07-27 21:32:59 --> Config Class Initialized
INFO - 2018-07-27 21:32:59 --> Hooks Class Initialized
DEBUG - 2018-07-27 21:32:59 --> UTF-8 Support Enabled
INFO - 2018-07-27 21:32:59 --> Utf8 Class Initialized
INFO - 2018-07-27 21:32:59 --> URI Class Initialized
INFO - 2018-07-27 21:32:59 --> Router Class Initialized
INFO - 2018-07-27 21:32:59 --> Output Class Initialized
INFO - 2018-07-27 21:32:59 --> Security Class Initialized
DEBUG - 2018-07-27 21:32:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 21:32:59 --> Input Class Initialized
INFO - 2018-07-27 21:32:59 --> Language Class Initialized
INFO - 2018-07-27 21:32:59 --> Language Class Initialized
INFO - 2018-07-27 21:32:59 --> Config Class Initialized
INFO - 2018-07-27 21:32:59 --> Loader Class Initialized
DEBUG - 2018-07-27 21:32:59 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-27 21:32:59 --> Helper loaded: url_helper
INFO - 2018-07-27 21:32:59 --> Helper loaded: form_helper
INFO - 2018-07-27 21:32:59 --> Helper loaded: date_helper
INFO - 2018-07-27 21:32:59 --> Helper loaded: util_helper
INFO - 2018-07-27 21:32:59 --> Helper loaded: text_helper
INFO - 2018-07-27 21:32:59 --> Helper loaded: string_helper
INFO - 2018-07-27 21:32:59 --> Database Driver Class Initialized
DEBUG - 2018-07-27 21:32:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 21:32:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 21:32:59 --> Email Class Initialized
INFO - 2018-07-27 21:32:59 --> Controller Class Initialized
DEBUG - 2018-07-27 21:32:59 --> Users MX_Controller Initialized
DEBUG - 2018-07-27 21:32:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-27 21:32:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-27 21:32:59 --> Helper loaded: file_helper
DEBUG - 2018-07-27 21:32:59 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-27 21:32:59 --> Login MX_Controller Initialized
INFO - 2018-07-27 21:32:59 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-27 21:32:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-27 21:32:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
INFO - 2018-07-27 21:32:59 --> Config Class Initialized
INFO - 2018-07-27 21:32:59 --> Hooks Class Initialized
DEBUG - 2018-07-27 21:33:00 --> UTF-8 Support Enabled
INFO - 2018-07-27 21:33:00 --> Utf8 Class Initialized
INFO - 2018-07-27 21:33:00 --> URI Class Initialized
INFO - 2018-07-27 21:33:00 --> Router Class Initialized
INFO - 2018-07-27 21:33:00 --> Output Class Initialized
INFO - 2018-07-27 21:33:00 --> Security Class Initialized
DEBUG - 2018-07-27 21:33:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 21:33:00 --> Input Class Initialized
INFO - 2018-07-27 21:33:00 --> Language Class Initialized
ERROR - 2018-07-27 21:33:00 --> 404 Page Not Found: /index
INFO - 2018-07-27 21:33:01 --> Config Class Initialized
INFO - 2018-07-27 21:33:01 --> Hooks Class Initialized
DEBUG - 2018-07-27 21:33:01 --> UTF-8 Support Enabled
INFO - 2018-07-27 21:33:01 --> Utf8 Class Initialized
INFO - 2018-07-27 21:33:01 --> URI Class Initialized
INFO - 2018-07-27 21:33:01 --> Router Class Initialized
INFO - 2018-07-27 21:33:01 --> Output Class Initialized
INFO - 2018-07-27 21:33:01 --> Security Class Initialized
DEBUG - 2018-07-27 21:33:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 21:33:01 --> Input Class Initialized
INFO - 2018-07-27 21:33:01 --> Language Class Initialized
INFO - 2018-07-27 21:33:01 --> Language Class Initialized
INFO - 2018-07-27 21:33:01 --> Config Class Initialized
INFO - 2018-07-27 21:33:01 --> Loader Class Initialized
DEBUG - 2018-07-27 21:33:01 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-27 21:33:01 --> Helper loaded: url_helper
INFO - 2018-07-27 21:33:01 --> Helper loaded: form_helper
INFO - 2018-07-27 21:33:01 --> Helper loaded: date_helper
INFO - 2018-07-27 21:33:01 --> Helper loaded: util_helper
INFO - 2018-07-27 21:33:01 --> Helper loaded: text_helper
INFO - 2018-07-27 21:33:01 --> Helper loaded: string_helper
INFO - 2018-07-27 21:33:01 --> Database Driver Class Initialized
DEBUG - 2018-07-27 21:33:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 21:33:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 21:33:01 --> Email Class Initialized
INFO - 2018-07-27 21:33:01 --> Controller Class Initialized
DEBUG - 2018-07-27 21:33:02 --> Users MX_Controller Initialized
DEBUG - 2018-07-27 21:33:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-27 21:33:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-27 21:33:02 --> Helper loaded: file_helper
DEBUG - 2018-07-27 21:33:02 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-27 21:33:02 --> Login MX_Controller Initialized
INFO - 2018-07-27 21:33:02 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-27 21:33:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-27 21:33:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
INFO - 2018-07-27 21:33:02 --> Config Class Initialized
INFO - 2018-07-27 21:33:02 --> Hooks Class Initialized
DEBUG - 2018-07-27 21:33:02 --> UTF-8 Support Enabled
INFO - 2018-07-27 21:33:02 --> Utf8 Class Initialized
INFO - 2018-07-27 21:33:02 --> URI Class Initialized
INFO - 2018-07-27 21:33:02 --> Router Class Initialized
INFO - 2018-07-27 21:33:02 --> Output Class Initialized
INFO - 2018-07-27 21:33:02 --> Security Class Initialized
DEBUG - 2018-07-27 21:33:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 21:33:02 --> Input Class Initialized
INFO - 2018-07-27 21:33:02 --> Language Class Initialized
ERROR - 2018-07-27 21:33:02 --> 404 Page Not Found: /index
INFO - 2018-07-27 23:34:30 --> Config Class Initialized
INFO - 2018-07-27 23:34:30 --> Hooks Class Initialized
DEBUG - 2018-07-27 23:34:30 --> UTF-8 Support Enabled
INFO - 2018-07-27 23:34:30 --> Utf8 Class Initialized
INFO - 2018-07-27 23:34:30 --> URI Class Initialized
INFO - 2018-07-27 23:34:30 --> Router Class Initialized
INFO - 2018-07-27 23:34:30 --> Output Class Initialized
INFO - 2018-07-27 23:34:30 --> Security Class Initialized
DEBUG - 2018-07-27 23:34:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 23:34:30 --> Input Class Initialized
INFO - 2018-07-27 23:34:30 --> Language Class Initialized
INFO - 2018-07-27 23:34:30 --> Language Class Initialized
INFO - 2018-07-27 23:34:30 --> Config Class Initialized
INFO - 2018-07-27 23:34:30 --> Loader Class Initialized
DEBUG - 2018-07-27 23:34:30 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-27 23:34:30 --> Helper loaded: url_helper
INFO - 2018-07-27 23:34:30 --> Helper loaded: form_helper
INFO - 2018-07-27 23:34:30 --> Helper loaded: date_helper
INFO - 2018-07-27 23:34:30 --> Helper loaded: util_helper
INFO - 2018-07-27 23:34:30 --> Helper loaded: text_helper
INFO - 2018-07-27 23:34:30 --> Helper loaded: string_helper
INFO - 2018-07-27 23:34:30 --> Database Driver Class Initialized
DEBUG - 2018-07-27 23:34:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 23:34:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 23:34:30 --> Email Class Initialized
INFO - 2018-07-27 23:34:30 --> Controller Class Initialized
DEBUG - 2018-07-27 23:34:30 --> Programs MX_Controller Initialized
INFO - 2018-07-27 23:34:30 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-27 23:34:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-27 23:34:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-27 23:34:30 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-27 23:34:30 --> Login MX_Controller Initialized
DEBUG - 2018-07-27 23:34:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-27 23:34:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
INFO - 2018-07-27 23:34:31 --> Config Class Initialized
INFO - 2018-07-27 23:34:31 --> Hooks Class Initialized
DEBUG - 2018-07-27 23:34:31 --> UTF-8 Support Enabled
INFO - 2018-07-27 23:34:31 --> Utf8 Class Initialized
INFO - 2018-07-27 23:34:31 --> URI Class Initialized
INFO - 2018-07-27 23:34:31 --> Router Class Initialized
INFO - 2018-07-27 23:34:31 --> Output Class Initialized
INFO - 2018-07-27 23:34:31 --> Security Class Initialized
DEBUG - 2018-07-27 23:34:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 23:34:31 --> Input Class Initialized
INFO - 2018-07-27 23:34:31 --> Language Class Initialized
ERROR - 2018-07-27 23:34:31 --> 404 Page Not Found: /index
INFO - 2018-07-27 23:34:31 --> Config Class Initialized
INFO - 2018-07-27 23:34:31 --> Hooks Class Initialized
DEBUG - 2018-07-27 23:34:31 --> UTF-8 Support Enabled
INFO - 2018-07-27 23:34:31 --> Utf8 Class Initialized
INFO - 2018-07-27 23:34:31 --> URI Class Initialized
INFO - 2018-07-27 23:34:31 --> Router Class Initialized
INFO - 2018-07-27 23:34:31 --> Output Class Initialized
INFO - 2018-07-27 23:34:31 --> Security Class Initialized
DEBUG - 2018-07-27 23:34:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 23:34:31 --> Input Class Initialized
INFO - 2018-07-27 23:34:31 --> Language Class Initialized
ERROR - 2018-07-27 23:34:31 --> 404 Page Not Found: /index
INFO - 2018-07-27 23:34:31 --> Config Class Initialized
INFO - 2018-07-27 23:34:31 --> Hooks Class Initialized
DEBUG - 2018-07-27 23:34:31 --> UTF-8 Support Enabled
INFO - 2018-07-27 23:34:31 --> Utf8 Class Initialized
INFO - 2018-07-27 23:34:31 --> URI Class Initialized
DEBUG - 2018-07-27 23:34:31 --> No URI present. Default controller set.
INFO - 2018-07-27 23:34:31 --> Router Class Initialized
INFO - 2018-07-27 23:34:31 --> Output Class Initialized
INFO - 2018-07-27 23:34:31 --> Security Class Initialized
DEBUG - 2018-07-27 23:34:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 23:34:31 --> Input Class Initialized
INFO - 2018-07-27 23:34:31 --> Language Class Initialized
INFO - 2018-07-27 23:34:31 --> Language Class Initialized
INFO - 2018-07-27 23:34:31 --> Config Class Initialized
INFO - 2018-07-27 23:34:31 --> Loader Class Initialized
DEBUG - 2018-07-27 23:34:31 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-27 23:34:31 --> Helper loaded: url_helper
INFO - 2018-07-27 23:34:31 --> Helper loaded: form_helper
INFO - 2018-07-27 23:34:31 --> Helper loaded: date_helper
INFO - 2018-07-27 23:34:32 --> Helper loaded: util_helper
INFO - 2018-07-27 23:34:32 --> Helper loaded: text_helper
INFO - 2018-07-27 23:34:32 --> Helper loaded: string_helper
INFO - 2018-07-27 23:34:32 --> Database Driver Class Initialized
DEBUG - 2018-07-27 23:34:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 23:34:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 23:34:32 --> Email Class Initialized
INFO - 2018-07-27 23:34:32 --> Controller Class Initialized
DEBUG - 2018-07-27 23:34:32 --> Home MX_Controller Initialized
DEBUG - 2018-07-27 23:34:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-27 23:34:32 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-27 23:34:32 --> Login MX_Controller Initialized
INFO - 2018-07-27 23:34:32 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-27 23:34:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-27 23:34:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-27 23:34:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-07-27 23:34:32 --> Config Class Initialized
INFO - 2018-07-27 23:34:32 --> Hooks Class Initialized
DEBUG - 2018-07-27 23:34:32 --> UTF-8 Support Enabled
INFO - 2018-07-27 23:34:32 --> Utf8 Class Initialized
INFO - 2018-07-27 23:34:32 --> URI Class Initialized
INFO - 2018-07-27 23:34:32 --> Router Class Initialized
INFO - 2018-07-27 23:34:32 --> Output Class Initialized
INFO - 2018-07-27 23:34:32 --> Security Class Initialized
DEBUG - 2018-07-27 23:34:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 23:34:32 --> Input Class Initialized
INFO - 2018-07-27 23:34:32 --> Language Class Initialized
INFO - 2018-07-27 23:34:32 --> Language Class Initialized
INFO - 2018-07-27 23:34:32 --> Config Class Initialized
INFO - 2018-07-27 23:34:33 --> Loader Class Initialized
DEBUG - 2018-07-27 23:34:33 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-27 23:34:33 --> Helper loaded: url_helper
INFO - 2018-07-27 23:34:33 --> Helper loaded: form_helper
INFO - 2018-07-27 23:34:33 --> Helper loaded: date_helper
INFO - 2018-07-27 23:34:33 --> Helper loaded: util_helper
INFO - 2018-07-27 23:34:33 --> Helper loaded: text_helper
INFO - 2018-07-27 23:34:33 --> Helper loaded: string_helper
INFO - 2018-07-27 23:34:33 --> Database Driver Class Initialized
DEBUG - 2018-07-27 23:34:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 23:34:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 23:34:33 --> Email Class Initialized
INFO - 2018-07-27 23:34:33 --> Controller Class Initialized
DEBUG - 2018-07-27 23:34:33 --> Home MX_Controller Initialized
DEBUG - 2018-07-27 23:34:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-27 23:34:33 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-27 23:34:33 --> Login MX_Controller Initialized
INFO - 2018-07-27 23:34:33 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-27 23:34:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-27 23:34:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-27 23:34:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-07-27 23:34:43 --> Config Class Initialized
INFO - 2018-07-27 23:34:43 --> Hooks Class Initialized
DEBUG - 2018-07-27 23:34:43 --> UTF-8 Support Enabled
INFO - 2018-07-27 23:34:43 --> Utf8 Class Initialized
INFO - 2018-07-27 23:34:43 --> URI Class Initialized
INFO - 2018-07-27 23:34:43 --> Router Class Initialized
INFO - 2018-07-27 23:34:43 --> Output Class Initialized
INFO - 2018-07-27 23:34:43 --> Security Class Initialized
DEBUG - 2018-07-27 23:34:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 23:34:43 --> Input Class Initialized
INFO - 2018-07-27 23:34:43 --> Language Class Initialized
INFO - 2018-07-27 23:34:43 --> Language Class Initialized
INFO - 2018-07-27 23:34:43 --> Config Class Initialized
INFO - 2018-07-27 23:34:43 --> Loader Class Initialized
DEBUG - 2018-07-27 23:34:43 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-27 23:34:43 --> Helper loaded: url_helper
INFO - 2018-07-27 23:34:43 --> Helper loaded: form_helper
INFO - 2018-07-27 23:34:43 --> Helper loaded: date_helper
INFO - 2018-07-27 23:34:43 --> Helper loaded: util_helper
INFO - 2018-07-27 23:34:43 --> Helper loaded: text_helper
INFO - 2018-07-27 23:34:43 --> Helper loaded: string_helper
INFO - 2018-07-27 23:34:43 --> Database Driver Class Initialized
DEBUG - 2018-07-27 23:34:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 23:34:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 23:34:43 --> Email Class Initialized
INFO - 2018-07-27 23:34:43 --> Controller Class Initialized
DEBUG - 2018-07-27 23:34:43 --> Login MX_Controller Initialized
INFO - 2018-07-27 23:34:43 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-27 23:34:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-27 23:34:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-27 23:34:44 --> Email starts for colin fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-07-27 23:34:44 --> User session created for 4
INFO - 2018-07-27 23:34:44 --> Login status colin - success
INFO - 2018-07-27 23:34:44 --> Final output sent to browser
DEBUG - 2018-07-27 23:34:44 --> Total execution time: 0.5735
INFO - 2018-07-27 23:34:44 --> Config Class Initialized
INFO - 2018-07-27 23:34:44 --> Hooks Class Initialized
DEBUG - 2018-07-27 23:34:44 --> UTF-8 Support Enabled
INFO - 2018-07-27 23:34:44 --> Utf8 Class Initialized
INFO - 2018-07-27 23:34:44 --> URI Class Initialized
INFO - 2018-07-27 23:34:44 --> Router Class Initialized
INFO - 2018-07-27 23:34:44 --> Output Class Initialized
INFO - 2018-07-27 23:34:44 --> Security Class Initialized
DEBUG - 2018-07-27 23:34:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 23:34:44 --> Input Class Initialized
INFO - 2018-07-27 23:34:44 --> Language Class Initialized
INFO - 2018-07-27 23:34:44 --> Language Class Initialized
INFO - 2018-07-27 23:34:44 --> Config Class Initialized
INFO - 2018-07-27 23:34:44 --> Loader Class Initialized
DEBUG - 2018-07-27 23:34:44 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-27 23:34:44 --> Helper loaded: url_helper
INFO - 2018-07-27 23:34:44 --> Helper loaded: form_helper
INFO - 2018-07-27 23:34:44 --> Helper loaded: date_helper
INFO - 2018-07-27 23:34:44 --> Helper loaded: util_helper
INFO - 2018-07-27 23:34:44 --> Helper loaded: text_helper
INFO - 2018-07-27 23:34:44 --> Helper loaded: string_helper
INFO - 2018-07-27 23:34:44 --> Database Driver Class Initialized
DEBUG - 2018-07-27 23:34:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 23:34:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 23:34:44 --> Email Class Initialized
INFO - 2018-07-27 23:34:44 --> Controller Class Initialized
DEBUG - 2018-07-27 23:34:44 --> Users MX_Controller Initialized
DEBUG - 2018-07-27 23:34:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-27 23:34:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-27 23:34:44 --> Helper loaded: file_helper
DEBUG - 2018-07-27 23:34:44 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-27 23:34:44 --> Login MX_Controller Initialized
INFO - 2018-07-27 23:34:44 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-27 23:34:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-27 23:34:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/logins/login.php
INFO - 2018-07-27 23:34:44 --> Config Class Initialized
INFO - 2018-07-27 23:34:44 --> Hooks Class Initialized
DEBUG - 2018-07-27 23:34:44 --> UTF-8 Support Enabled
INFO - 2018-07-27 23:34:44 --> Utf8 Class Initialized
INFO - 2018-07-27 23:34:44 --> URI Class Initialized
INFO - 2018-07-27 23:34:44 --> Router Class Initialized
INFO - 2018-07-27 23:34:44 --> Output Class Initialized
INFO - 2018-07-27 23:34:45 --> Security Class Initialized
DEBUG - 2018-07-27 23:34:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 23:34:45 --> Input Class Initialized
INFO - 2018-07-27 23:34:45 --> Language Class Initialized
ERROR - 2018-07-27 23:34:45 --> 404 Page Not Found: /index
INFO - 2018-07-27 23:34:48 --> Config Class Initialized
INFO - 2018-07-27 23:34:48 --> Hooks Class Initialized
DEBUG - 2018-07-27 23:34:48 --> UTF-8 Support Enabled
INFO - 2018-07-27 23:34:48 --> Utf8 Class Initialized
INFO - 2018-07-27 23:34:48 --> URI Class Initialized
INFO - 2018-07-27 23:34:48 --> Router Class Initialized
INFO - 2018-07-27 23:34:48 --> Output Class Initialized
INFO - 2018-07-27 23:34:48 --> Security Class Initialized
DEBUG - 2018-07-27 23:34:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 23:34:48 --> Input Class Initialized
INFO - 2018-07-27 23:34:48 --> Language Class Initialized
INFO - 2018-07-27 23:34:48 --> Language Class Initialized
INFO - 2018-07-27 23:34:48 --> Config Class Initialized
INFO - 2018-07-27 23:34:48 --> Loader Class Initialized
DEBUG - 2018-07-27 23:34:48 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-27 23:34:48 --> Helper loaded: url_helper
INFO - 2018-07-27 23:34:48 --> Helper loaded: form_helper
INFO - 2018-07-27 23:34:48 --> Helper loaded: date_helper
INFO - 2018-07-27 23:34:48 --> Helper loaded: util_helper
INFO - 2018-07-27 23:34:48 --> Helper loaded: text_helper
INFO - 2018-07-27 23:34:48 --> Helper loaded: string_helper
INFO - 2018-07-27 23:34:48 --> Database Driver Class Initialized
DEBUG - 2018-07-27 23:34:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 23:34:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 23:34:48 --> Email Class Initialized
INFO - 2018-07-27 23:34:48 --> Controller Class Initialized
DEBUG - 2018-07-27 23:34:48 --> Login MX_Controller Initialized
INFO - 2018-07-27 23:34:48 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-27 23:34:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-27 23:34:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-27 23:34:48 --> Email starts for colin-admin fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-07-27 23:34:48 --> User session created for 1
INFO - 2018-07-27 23:34:48 --> Login status colin-admin - success
INFO - 2018-07-27 23:34:48 --> Final output sent to browser
DEBUG - 2018-07-27 23:34:48 --> Total execution time: 0.5767
INFO - 2018-07-27 23:34:48 --> Config Class Initialized
INFO - 2018-07-27 23:34:48 --> Hooks Class Initialized
DEBUG - 2018-07-27 23:34:48 --> UTF-8 Support Enabled
INFO - 2018-07-27 23:34:48 --> Utf8 Class Initialized
INFO - 2018-07-27 23:34:48 --> URI Class Initialized
INFO - 2018-07-27 23:34:48 --> Router Class Initialized
INFO - 2018-07-27 23:34:48 --> Output Class Initialized
INFO - 2018-07-27 23:34:48 --> Security Class Initialized
DEBUG - 2018-07-27 23:34:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 23:34:48 --> Input Class Initialized
INFO - 2018-07-27 23:34:48 --> Language Class Initialized
INFO - 2018-07-27 23:34:48 --> Language Class Initialized
INFO - 2018-07-27 23:34:48 --> Config Class Initialized
INFO - 2018-07-27 23:34:48 --> Loader Class Initialized
DEBUG - 2018-07-27 23:34:48 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-27 23:34:48 --> Helper loaded: url_helper
INFO - 2018-07-27 23:34:48 --> Helper loaded: form_helper
INFO - 2018-07-27 23:34:48 --> Helper loaded: date_helper
INFO - 2018-07-27 23:34:48 --> Helper loaded: util_helper
INFO - 2018-07-27 23:34:48 --> Helper loaded: text_helper
INFO - 2018-07-27 23:34:48 --> Helper loaded: string_helper
INFO - 2018-07-27 23:34:49 --> Database Driver Class Initialized
DEBUG - 2018-07-27 23:34:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 23:34:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 23:34:49 --> Email Class Initialized
INFO - 2018-07-27 23:34:49 --> Controller Class Initialized
DEBUG - 2018-07-27 23:34:49 --> Users MX_Controller Initialized
DEBUG - 2018-07-27 23:34:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-27 23:34:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-27 23:34:49 --> Helper loaded: file_helper
DEBUG - 2018-07-27 23:34:49 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-27 23:34:49 --> Login MX_Controller Initialized
INFO - 2018-07-27 23:34:49 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-27 23:34:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-27 23:34:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-27 23:34:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-27 23:34:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-27 23:34:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-27 23:34:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-27 23:34:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-27 23:34:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-07-27 23:34:49 --> Final output sent to browser
DEBUG - 2018-07-27 23:34:49 --> Total execution time: 1.0730
INFO - 2018-07-27 23:34:51 --> Config Class Initialized
INFO - 2018-07-27 23:34:51 --> Hooks Class Initialized
DEBUG - 2018-07-27 23:34:51 --> UTF-8 Support Enabled
INFO - 2018-07-27 23:34:51 --> Utf8 Class Initialized
INFO - 2018-07-27 23:34:51 --> URI Class Initialized
INFO - 2018-07-27 23:34:51 --> Router Class Initialized
INFO - 2018-07-27 23:34:51 --> Output Class Initialized
INFO - 2018-07-27 23:34:51 --> Security Class Initialized
DEBUG - 2018-07-27 23:34:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 23:34:51 --> Input Class Initialized
INFO - 2018-07-27 23:34:51 --> Language Class Initialized
INFO - 2018-07-27 23:34:51 --> Language Class Initialized
INFO - 2018-07-27 23:34:51 --> Config Class Initialized
INFO - 2018-07-27 23:34:51 --> Loader Class Initialized
DEBUG - 2018-07-27 23:34:51 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-27 23:34:51 --> Helper loaded: url_helper
INFO - 2018-07-27 23:34:51 --> Helper loaded: form_helper
INFO - 2018-07-27 23:34:51 --> Helper loaded: date_helper
INFO - 2018-07-27 23:34:51 --> Helper loaded: util_helper
INFO - 2018-07-27 23:34:51 --> Helper loaded: text_helper
INFO - 2018-07-27 23:34:51 --> Helper loaded: string_helper
INFO - 2018-07-27 23:34:51 --> Database Driver Class Initialized
DEBUG - 2018-07-27 23:34:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 23:34:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 23:34:51 --> Email Class Initialized
INFO - 2018-07-27 23:34:51 --> Controller Class Initialized
DEBUG - 2018-07-27 23:34:51 --> Programs MX_Controller Initialized
INFO - 2018-07-27 23:34:51 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-27 23:34:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-27 23:34:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-27 23:34:51 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-27 23:34:52 --> Login MX_Controller Initialized
DEBUG - 2018-07-27 23:34:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-27 23:34:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-27 23:34:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-27 23:34:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-27 23:34:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-27 23:34:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-27 23:34:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/programs.php
INFO - 2018-07-27 23:34:52 --> Final output sent to browser
DEBUG - 2018-07-27 23:34:52 --> Total execution time: 0.7559
INFO - 2018-07-27 23:34:52 --> Config Class Initialized
INFO - 2018-07-27 23:34:52 --> Hooks Class Initialized
DEBUG - 2018-07-27 23:34:53 --> UTF-8 Support Enabled
INFO - 2018-07-27 23:34:53 --> Utf8 Class Initialized
INFO - 2018-07-27 23:34:53 --> URI Class Initialized
INFO - 2018-07-27 23:34:53 --> Router Class Initialized
INFO - 2018-07-27 23:34:53 --> Output Class Initialized
INFO - 2018-07-27 23:34:53 --> Security Class Initialized
DEBUG - 2018-07-27 23:34:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 23:34:53 --> Input Class Initialized
INFO - 2018-07-27 23:34:53 --> Language Class Initialized
INFO - 2018-07-27 23:34:53 --> Language Class Initialized
INFO - 2018-07-27 23:34:53 --> Config Class Initialized
INFO - 2018-07-27 23:34:53 --> Loader Class Initialized
DEBUG - 2018-07-27 23:34:53 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-27 23:34:53 --> Helper loaded: url_helper
INFO - 2018-07-27 23:34:53 --> Helper loaded: form_helper
INFO - 2018-07-27 23:34:53 --> Helper loaded: date_helper
INFO - 2018-07-27 23:34:53 --> Helper loaded: util_helper
INFO - 2018-07-27 23:34:53 --> Helper loaded: text_helper
INFO - 2018-07-27 23:34:53 --> Helper loaded: string_helper
INFO - 2018-07-27 23:34:53 --> Database Driver Class Initialized
DEBUG - 2018-07-27 23:34:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 23:34:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 23:34:53 --> Email Class Initialized
INFO - 2018-07-27 23:34:53 --> Controller Class Initialized
DEBUG - 2018-07-27 23:34:53 --> Programs MX_Controller Initialized
INFO - 2018-07-27 23:34:53 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-27 23:34:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-27 23:34:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-27 23:34:53 --> Config Class Initialized
INFO - 2018-07-27 23:34:53 --> Hooks Class Initialized
DEBUG - 2018-07-27 23:34:53 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-27 23:34:53 --> Login MX_Controller Initialized
DEBUG - 2018-07-27 23:34:53 --> UTF-8 Support Enabled
INFO - 2018-07-27 23:34:53 --> Utf8 Class Initialized
DEBUG - 2018-07-27 23:34:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-27 23:34:53 --> URI Class Initialized
INFO - 2018-07-27 23:34:53 --> Final output sent to browser
DEBUG - 2018-07-27 23:34:53 --> Total execution time: 0.5848
DEBUG - 2018-07-27 23:34:53 --> No URI present. Default controller set.
INFO - 2018-07-27 23:34:53 --> Router Class Initialized
INFO - 2018-07-27 23:34:53 --> Output Class Initialized
INFO - 2018-07-27 23:34:53 --> Security Class Initialized
DEBUG - 2018-07-27 23:34:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 23:34:53 --> Input Class Initialized
INFO - 2018-07-27 23:34:53 --> Language Class Initialized
INFO - 2018-07-27 23:34:53 --> Language Class Initialized
INFO - 2018-07-27 23:34:53 --> Config Class Initialized
INFO - 2018-07-27 23:34:53 --> Loader Class Initialized
DEBUG - 2018-07-27 23:34:53 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-27 23:34:53 --> Helper loaded: url_helper
INFO - 2018-07-27 23:34:53 --> Helper loaded: form_helper
INFO - 2018-07-27 23:34:53 --> Helper loaded: date_helper
INFO - 2018-07-27 23:34:53 --> Helper loaded: util_helper
INFO - 2018-07-27 23:34:53 --> Helper loaded: text_helper
INFO - 2018-07-27 23:34:53 --> Helper loaded: string_helper
INFO - 2018-07-27 23:34:53 --> Database Driver Class Initialized
DEBUG - 2018-07-27 23:34:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 23:34:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 23:34:53 --> Email Class Initialized
INFO - 2018-07-27 23:34:53 --> Controller Class Initialized
DEBUG - 2018-07-27 23:34:53 --> Home MX_Controller Initialized
DEBUG - 2018-07-27 23:34:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-27 23:34:54 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-27 23:34:54 --> Login MX_Controller Initialized
INFO - 2018-07-27 23:34:54 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-27 23:34:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-27 23:34:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-27 23:34:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-27 23:34:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-27 23:34:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-27 23:34:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-27 23:34:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-27 23:34:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-27 23:34:54 --> Final output sent to browser
DEBUG - 2018-07-27 23:34:54 --> Total execution time: 0.9786
INFO - 2018-07-27 23:34:55 --> Config Class Initialized
INFO - 2018-07-27 23:34:55 --> Hooks Class Initialized
DEBUG - 2018-07-27 23:34:55 --> UTF-8 Support Enabled
INFO - 2018-07-27 23:34:55 --> Utf8 Class Initialized
INFO - 2018-07-27 23:34:55 --> URI Class Initialized
INFO - 2018-07-27 23:34:56 --> Router Class Initialized
INFO - 2018-07-27 23:34:56 --> Output Class Initialized
INFO - 2018-07-27 23:34:56 --> Security Class Initialized
DEBUG - 2018-07-27 23:34:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 23:34:56 --> Input Class Initialized
INFO - 2018-07-27 23:34:56 --> Language Class Initialized
ERROR - 2018-07-27 23:34:56 --> 404 Page Not Found: /index
INFO - 2018-07-27 23:34:56 --> Config Class Initialized
INFO - 2018-07-27 23:34:56 --> Hooks Class Initialized
DEBUG - 2018-07-27 23:34:56 --> UTF-8 Support Enabled
INFO - 2018-07-27 23:34:56 --> Utf8 Class Initialized
INFO - 2018-07-27 23:34:56 --> Config Class Initialized
INFO - 2018-07-27 23:34:56 --> Hooks Class Initialized
INFO - 2018-07-27 23:34:56 --> URI Class Initialized
DEBUG - 2018-07-27 23:34:56 --> UTF-8 Support Enabled
INFO - 2018-07-27 23:34:56 --> Utf8 Class Initialized
INFO - 2018-07-27 23:34:56 --> URI Class Initialized
INFO - 2018-07-27 23:34:56 --> Router Class Initialized
INFO - 2018-07-27 23:34:56 --> Output Class Initialized
INFO - 2018-07-27 23:34:56 --> Router Class Initialized
INFO - 2018-07-27 23:34:56 --> Security Class Initialized
INFO - 2018-07-27 23:34:56 --> Output Class Initialized
DEBUG - 2018-07-27 23:34:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 23:34:56 --> Security Class Initialized
INFO - 2018-07-27 23:34:56 --> Input Class Initialized
INFO - 2018-07-27 23:34:56 --> Language Class Initialized
DEBUG - 2018-07-27 23:34:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 23:34:56 --> Input Class Initialized
INFO - 2018-07-27 23:34:56 --> Language Class Initialized
INFO - 2018-07-27 23:34:56 --> Language Class Initialized
ERROR - 2018-07-27 23:34:56 --> 404 Page Not Found: /index
INFO - 2018-07-27 23:34:56 --> Config Class Initialized
INFO - 2018-07-27 23:34:56 --> Config Class Initialized
INFO - 2018-07-27 23:34:56 --> Loader Class Initialized
INFO - 2018-07-27 23:34:56 --> Hooks Class Initialized
DEBUG - 2018-07-27 23:34:56 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-27 23:34:56 --> Helper loaded: url_helper
DEBUG - 2018-07-27 23:34:56 --> UTF-8 Support Enabled
INFO - 2018-07-27 23:34:56 --> Utf8 Class Initialized
INFO - 2018-07-27 23:34:56 --> Helper loaded: form_helper
INFO - 2018-07-27 23:34:56 --> URI Class Initialized
INFO - 2018-07-27 23:34:56 --> Helper loaded: date_helper
INFO - 2018-07-27 23:34:56 --> Helper loaded: util_helper
INFO - 2018-07-27 23:34:56 --> Router Class Initialized
INFO - 2018-07-27 23:34:56 --> Helper loaded: text_helper
INFO - 2018-07-27 23:34:56 --> Output Class Initialized
INFO - 2018-07-27 23:34:56 --> Helper loaded: string_helper
INFO - 2018-07-27 23:34:56 --> Security Class Initialized
DEBUG - 2018-07-27 23:34:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 23:34:56 --> Database Driver Class Initialized
INFO - 2018-07-27 23:34:56 --> Input Class Initialized
INFO - 2018-07-27 23:34:56 --> Language Class Initialized
DEBUG - 2018-07-27 23:34:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 23:34:56 --> Session: Class initialized using 'files' driver.
ERROR - 2018-07-27 23:34:56 --> 404 Page Not Found: /index
INFO - 2018-07-27 23:34:56 --> Email Class Initialized
INFO - 2018-07-27 23:34:56 --> Controller Class Initialized
DEBUG - 2018-07-27 23:34:56 --> Home MX_Controller Initialized
DEBUG - 2018-07-27 23:34:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-27 23:34:56 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-27 23:34:56 --> Login MX_Controller Initialized
INFO - 2018-07-27 23:34:56 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-27 23:34:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-27 23:34:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-27 23:34:57 --> Config Class Initialized
INFO - 2018-07-27 23:34:57 --> Hooks Class Initialized
DEBUG - 2018-07-27 23:34:57 --> UTF-8 Support Enabled
INFO - 2018-07-27 23:34:57 --> Utf8 Class Initialized
INFO - 2018-07-27 23:34:57 --> URI Class Initialized
INFO - 2018-07-27 23:34:57 --> Router Class Initialized
INFO - 2018-07-27 23:34:57 --> Output Class Initialized
INFO - 2018-07-27 23:34:57 --> Security Class Initialized
DEBUG - 2018-07-27 23:34:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 23:34:57 --> Input Class Initialized
INFO - 2018-07-27 23:34:57 --> Language Class Initialized
ERROR - 2018-07-27 23:34:57 --> 404 Page Not Found: /index
INFO - 2018-07-27 23:34:57 --> Config Class Initialized
INFO - 2018-07-27 23:34:57 --> Hooks Class Initialized
DEBUG - 2018-07-27 23:34:57 --> UTF-8 Support Enabled
INFO - 2018-07-27 23:34:57 --> Utf8 Class Initialized
INFO - 2018-07-27 23:34:57 --> URI Class Initialized
INFO - 2018-07-27 23:34:57 --> Router Class Initialized
INFO - 2018-07-27 23:34:57 --> Output Class Initialized
INFO - 2018-07-27 23:34:57 --> Security Class Initialized
DEBUG - 2018-07-27 23:34:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 23:34:57 --> Input Class Initialized
INFO - 2018-07-27 23:34:57 --> Language Class Initialized
ERROR - 2018-07-27 23:34:57 --> 404 Page Not Found: /index
INFO - 2018-07-27 23:34:57 --> Config Class Initialized
INFO - 2018-07-27 23:34:57 --> Hooks Class Initialized
DEBUG - 2018-07-27 23:34:57 --> UTF-8 Support Enabled
INFO - 2018-07-27 23:34:57 --> Utf8 Class Initialized
INFO - 2018-07-27 23:34:57 --> URI Class Initialized
INFO - 2018-07-27 23:34:57 --> Router Class Initialized
INFO - 2018-07-27 23:34:57 --> Output Class Initialized
INFO - 2018-07-27 23:34:57 --> Security Class Initialized
DEBUG - 2018-07-27 23:34:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 23:34:57 --> Input Class Initialized
INFO - 2018-07-27 23:34:57 --> Language Class Initialized
ERROR - 2018-07-27 23:34:57 --> 404 Page Not Found: /index
INFO - 2018-07-27 23:55:36 --> Config Class Initialized
INFO - 2018-07-27 23:55:36 --> Hooks Class Initialized
DEBUG - 2018-07-27 23:55:36 --> UTF-8 Support Enabled
INFO - 2018-07-27 23:55:36 --> Utf8 Class Initialized
INFO - 2018-07-27 23:55:36 --> URI Class Initialized
DEBUG - 2018-07-27 23:55:36 --> No URI present. Default controller set.
INFO - 2018-07-27 23:55:36 --> Router Class Initialized
INFO - 2018-07-27 23:55:36 --> Output Class Initialized
INFO - 2018-07-27 23:55:36 --> Security Class Initialized
DEBUG - 2018-07-27 23:55:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 23:55:36 --> Input Class Initialized
INFO - 2018-07-27 23:55:36 --> Language Class Initialized
INFO - 2018-07-27 23:55:36 --> Language Class Initialized
INFO - 2018-07-27 23:55:36 --> Config Class Initialized
INFO - 2018-07-27 23:55:36 --> Loader Class Initialized
DEBUG - 2018-07-27 23:55:36 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-27 23:55:36 --> Helper loaded: url_helper
INFO - 2018-07-27 23:55:36 --> Helper loaded: form_helper
INFO - 2018-07-27 23:55:36 --> Helper loaded: date_helper
INFO - 2018-07-27 23:55:36 --> Helper loaded: util_helper
INFO - 2018-07-27 23:55:36 --> Helper loaded: text_helper
INFO - 2018-07-27 23:55:36 --> Helper loaded: string_helper
INFO - 2018-07-27 23:55:36 --> Database Driver Class Initialized
DEBUG - 2018-07-27 23:55:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 23:55:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 23:55:36 --> Email Class Initialized
INFO - 2018-07-27 23:55:36 --> Controller Class Initialized
DEBUG - 2018-07-27 23:55:36 --> Home MX_Controller Initialized
DEBUG - 2018-07-27 23:55:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-27 23:55:36 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-27 23:55:36 --> Login MX_Controller Initialized
INFO - 2018-07-27 23:55:36 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-27 23:55:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-27 23:55:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-27 23:55:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-27 23:55:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-27 23:55:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-27 23:55:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-27 23:55:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-27 23:55:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-27 23:55:36 --> Final output sent to browser
DEBUG - 2018-07-27 23:55:36 --> Total execution time: 0.7848
INFO - 2018-07-27 23:55:37 --> Config Class Initialized
INFO - 2018-07-27 23:55:37 --> Config Class Initialized
INFO - 2018-07-27 23:55:37 --> Hooks Class Initialized
INFO - 2018-07-27 23:55:37 --> Hooks Class Initialized
DEBUG - 2018-07-27 23:55:37 --> UTF-8 Support Enabled
INFO - 2018-07-27 23:55:37 --> Utf8 Class Initialized
INFO - 2018-07-27 23:55:37 --> URI Class Initialized
DEBUG - 2018-07-27 23:55:37 --> UTF-8 Support Enabled
INFO - 2018-07-27 23:55:37 --> Utf8 Class Initialized
INFO - 2018-07-27 23:55:37 --> Router Class Initialized
INFO - 2018-07-27 23:55:37 --> URI Class Initialized
INFO - 2018-07-27 23:55:37 --> Router Class Initialized
INFO - 2018-07-27 23:55:37 --> Output Class Initialized
INFO - 2018-07-27 23:55:37 --> Security Class Initialized
INFO - 2018-07-27 23:55:37 --> Output Class Initialized
DEBUG - 2018-07-27 23:55:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 23:55:37 --> Security Class Initialized
INFO - 2018-07-27 23:55:37 --> Input Class Initialized
DEBUG - 2018-07-27 23:55:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 23:55:37 --> Language Class Initialized
INFO - 2018-07-27 23:55:37 --> Input Class Initialized
INFO - 2018-07-27 23:55:37 --> Language Class Initialized
INFO - 2018-07-27 23:55:37 --> Language Class Initialized
INFO - 2018-07-27 23:55:37 --> Config Class Initialized
ERROR - 2018-07-27 23:55:37 --> 404 Page Not Found: /index
INFO - 2018-07-27 23:55:37 --> Loader Class Initialized
INFO - 2018-07-27 23:55:37 --> Config Class Initialized
INFO - 2018-07-27 23:55:37 --> Hooks Class Initialized
DEBUG - 2018-07-27 23:55:37 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
DEBUG - 2018-07-27 23:55:37 --> UTF-8 Support Enabled
INFO - 2018-07-27 23:55:37 --> Helper loaded: url_helper
INFO - 2018-07-27 23:55:37 --> Utf8 Class Initialized
INFO - 2018-07-27 23:55:37 --> Helper loaded: form_helper
INFO - 2018-07-27 23:55:37 --> URI Class Initialized
INFO - 2018-07-27 23:55:37 --> Helper loaded: date_helper
INFO - 2018-07-27 23:55:37 --> Helper loaded: util_helper
INFO - 2018-07-27 23:55:37 --> Router Class Initialized
INFO - 2018-07-27 23:55:37 --> Helper loaded: text_helper
INFO - 2018-07-27 23:55:37 --> Output Class Initialized
INFO - 2018-07-27 23:55:37 --> Helper loaded: string_helper
INFO - 2018-07-27 23:55:37 --> Security Class Initialized
DEBUG - 2018-07-27 23:55:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 23:55:37 --> Database Driver Class Initialized
INFO - 2018-07-27 23:55:37 --> Input Class Initialized
DEBUG - 2018-07-27 23:55:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-27 23:55:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-27 23:55:38 --> Language Class Initialized
ERROR - 2018-07-27 23:55:38 --> 404 Page Not Found: /index
INFO - 2018-07-27 23:55:38 --> Email Class Initialized
INFO - 2018-07-27 23:55:38 --> Controller Class Initialized
INFO - 2018-07-27 23:55:38 --> Config Class Initialized
INFO - 2018-07-27 23:55:38 --> Hooks Class Initialized
DEBUG - 2018-07-27 23:55:38 --> Home MX_Controller Initialized
DEBUG - 2018-07-27 23:55:38 --> UTF-8 Support Enabled
DEBUG - 2018-07-27 23:55:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-07-27 23:55:38 --> Utf8 Class Initialized
DEBUG - 2018-07-27 23:55:38 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-27 23:55:38 --> Login MX_Controller Initialized
INFO - 2018-07-27 23:55:38 --> URI Class Initialized
INFO - 2018-07-27 23:55:38 --> Language file loaded: language/english/data_lang.php
INFO - 2018-07-27 23:55:38 --> Router Class Initialized
DEBUG - 2018-07-27 23:55:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-27 23:55:38 --> Output Class Initialized
DEBUG - 2018-07-27 23:55:38 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-27 23:55:38 --> Security Class Initialized
DEBUG - 2018-07-27 23:55:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 23:55:38 --> Input Class Initialized
INFO - 2018-07-27 23:55:38 --> Language Class Initialized
ERROR - 2018-07-27 23:55:38 --> 404 Page Not Found: /index
INFO - 2018-07-27 23:55:38 --> Config Class Initialized
INFO - 2018-07-27 23:55:38 --> Hooks Class Initialized
DEBUG - 2018-07-27 23:55:38 --> UTF-8 Support Enabled
INFO - 2018-07-27 23:55:38 --> Utf8 Class Initialized
INFO - 2018-07-27 23:55:38 --> URI Class Initialized
INFO - 2018-07-27 23:55:38 --> Router Class Initialized
INFO - 2018-07-27 23:55:38 --> Output Class Initialized
INFO - 2018-07-27 23:55:38 --> Security Class Initialized
DEBUG - 2018-07-27 23:55:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 23:55:38 --> Input Class Initialized
INFO - 2018-07-27 23:55:38 --> Language Class Initialized
ERROR - 2018-07-27 23:55:38 --> 404 Page Not Found: /index
INFO - 2018-07-27 23:55:38 --> Config Class Initialized
INFO - 2018-07-27 23:55:38 --> Hooks Class Initialized
DEBUG - 2018-07-27 23:55:38 --> UTF-8 Support Enabled
INFO - 2018-07-27 23:55:38 --> Utf8 Class Initialized
INFO - 2018-07-27 23:55:38 --> URI Class Initialized
INFO - 2018-07-27 23:55:38 --> Router Class Initialized
INFO - 2018-07-27 23:55:38 --> Output Class Initialized
INFO - 2018-07-27 23:55:38 --> Security Class Initialized
DEBUG - 2018-07-27 23:55:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 23:55:38 --> Input Class Initialized
INFO - 2018-07-27 23:55:38 --> Language Class Initialized
ERROR - 2018-07-27 23:55:38 --> 404 Page Not Found: /index
INFO - 2018-07-27 23:55:38 --> Config Class Initialized
INFO - 2018-07-27 23:55:38 --> Hooks Class Initialized
DEBUG - 2018-07-27 23:55:38 --> UTF-8 Support Enabled
INFO - 2018-07-27 23:55:38 --> Utf8 Class Initialized
INFO - 2018-07-27 23:55:38 --> URI Class Initialized
INFO - 2018-07-27 23:55:38 --> Router Class Initialized
INFO - 2018-07-27 23:55:38 --> Output Class Initialized
INFO - 2018-07-27 23:55:38 --> Security Class Initialized
DEBUG - 2018-07-27 23:55:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-27 23:55:38 --> Input Class Initialized
INFO - 2018-07-27 23:55:38 --> Language Class Initialized
ERROR - 2018-07-27 23:55:38 --> 404 Page Not Found: /index
