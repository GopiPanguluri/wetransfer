<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-07-28 00:09:47 --> Config Class Initialized
INFO - 2018-07-28 00:09:47 --> Hooks Class Initialized
DEBUG - 2018-07-28 00:09:47 --> UTF-8 Support Enabled
INFO - 2018-07-28 00:09:47 --> Utf8 Class Initialized
INFO - 2018-07-28 00:09:47 --> URI Class Initialized
INFO - 2018-07-28 00:09:47 --> Router Class Initialized
INFO - 2018-07-28 00:09:47 --> Output Class Initialized
INFO - 2018-07-28 00:09:47 --> Security Class Initialized
DEBUG - 2018-07-28 00:09:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 00:09:47 --> Input Class Initialized
INFO - 2018-07-28 00:09:47 --> Language Class Initialized
INFO - 2018-07-28 00:09:47 --> Language Class Initialized
INFO - 2018-07-28 00:09:47 --> Config Class Initialized
INFO - 2018-07-28 00:09:47 --> Hooks Class Initialized
INFO - 2018-07-28 00:09:47 --> Config Class Initialized
DEBUG - 2018-07-28 00:09:47 --> UTF-8 Support Enabled
INFO - 2018-07-28 00:09:47 --> Loader Class Initialized
INFO - 2018-07-28 00:09:47 --> Utf8 Class Initialized
INFO - 2018-07-28 00:09:47 --> URI Class Initialized
INFO - 2018-07-28 00:09:47 --> Router Class Initialized
DEBUG - 2018-07-28 00:09:47 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 00:09:47 --> Output Class Initialized
INFO - 2018-07-28 00:09:47 --> Helper loaded: url_helper
INFO - 2018-07-28 00:09:47 --> Security Class Initialized
INFO - 2018-07-28 00:09:47 --> Helper loaded: form_helper
DEBUG - 2018-07-28 00:09:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 00:09:47 --> Input Class Initialized
INFO - 2018-07-28 00:09:47 --> Language Class Initialized
INFO - 2018-07-28 00:09:47 --> Helper loaded: date_helper
INFO - 2018-07-28 00:09:47 --> Helper loaded: util_helper
ERROR - 2018-07-28 00:09:47 --> 404 Page Not Found: /index
INFO - 2018-07-28 00:09:47 --> Helper loaded: text_helper
INFO - 2018-07-28 00:09:47 --> Config Class Initialized
INFO - 2018-07-28 00:09:47 --> Hooks Class Initialized
INFO - 2018-07-28 00:09:47 --> Helper loaded: string_helper
DEBUG - 2018-07-28 00:09:47 --> UTF-8 Support Enabled
INFO - 2018-07-28 00:09:47 --> Database Driver Class Initialized
INFO - 2018-07-28 00:09:47 --> Utf8 Class Initialized
INFO - 2018-07-28 00:09:47 --> URI Class Initialized
INFO - 2018-07-28 00:09:47 --> Router Class Initialized
INFO - 2018-07-28 00:09:47 --> Output Class Initialized
DEBUG - 2018-07-28 00:09:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 00:09:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 00:09:47 --> Security Class Initialized
DEBUG - 2018-07-28 00:09:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 00:09:47 --> Email Class Initialized
INFO - 2018-07-28 00:09:47 --> Controller Class Initialized
INFO - 2018-07-28 00:09:47 --> Input Class Initialized
DEBUG - 2018-07-28 00:09:47 --> Home MX_Controller Initialized
INFO - 2018-07-28 00:09:47 --> Language Class Initialized
DEBUG - 2018-07-28 00:09:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
ERROR - 2018-07-28 00:09:47 --> 404 Page Not Found: /index
DEBUG - 2018-07-28 00:09:47 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 00:09:47 --> Login MX_Controller Initialized
INFO - 2018-07-28 00:09:47 --> Config Class Initialized
INFO - 2018-07-28 00:09:47 --> Hooks Class Initialized
INFO - 2018-07-28 00:09:47 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 00:09:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 00:09:47 --> UTF-8 Support Enabled
INFO - 2018-07-28 00:09:47 --> Utf8 Class Initialized
DEBUG - 2018-07-28 00:09:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-28 00:09:47 --> URI Class Initialized
INFO - 2018-07-28 00:09:47 --> Router Class Initialized
INFO - 2018-07-28 00:09:47 --> Output Class Initialized
INFO - 2018-07-28 00:09:47 --> Security Class Initialized
DEBUG - 2018-07-28 00:09:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 00:09:47 --> Input Class Initialized
INFO - 2018-07-28 00:09:47 --> Language Class Initialized
ERROR - 2018-07-28 00:09:47 --> 404 Page Not Found: /index
INFO - 2018-07-28 00:09:53 --> Config Class Initialized
INFO - 2018-07-28 00:09:53 --> Hooks Class Initialized
DEBUG - 2018-07-28 00:09:53 --> UTF-8 Support Enabled
INFO - 2018-07-28 00:09:53 --> Utf8 Class Initialized
INFO - 2018-07-28 00:09:53 --> URI Class Initialized
DEBUG - 2018-07-28 00:09:53 --> No URI present. Default controller set.
INFO - 2018-07-28 00:09:53 --> Router Class Initialized
INFO - 2018-07-28 00:09:53 --> Output Class Initialized
INFO - 2018-07-28 00:09:53 --> Security Class Initialized
DEBUG - 2018-07-28 00:09:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 00:09:53 --> Input Class Initialized
INFO - 2018-07-28 00:09:53 --> Language Class Initialized
INFO - 2018-07-28 00:09:53 --> Language Class Initialized
INFO - 2018-07-28 00:09:53 --> Config Class Initialized
INFO - 2018-07-28 00:09:53 --> Loader Class Initialized
DEBUG - 2018-07-28 00:09:53 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 00:09:53 --> Helper loaded: url_helper
INFO - 2018-07-28 00:09:53 --> Helper loaded: form_helper
INFO - 2018-07-28 00:09:53 --> Helper loaded: date_helper
INFO - 2018-07-28 00:09:53 --> Helper loaded: util_helper
INFO - 2018-07-28 00:09:53 --> Helper loaded: text_helper
INFO - 2018-07-28 00:09:53 --> Helper loaded: string_helper
INFO - 2018-07-28 00:09:53 --> Database Driver Class Initialized
DEBUG - 2018-07-28 00:09:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 00:09:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 00:09:53 --> Email Class Initialized
INFO - 2018-07-28 00:09:53 --> Controller Class Initialized
DEBUG - 2018-07-28 00:09:53 --> Home MX_Controller Initialized
DEBUG - 2018-07-28 00:09:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-28 00:09:53 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 00:09:53 --> Login MX_Controller Initialized
INFO - 2018-07-28 00:09:53 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 00:09:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 00:09:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-28 00:09:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-07-28 00:09:56 --> Config Class Initialized
INFO - 2018-07-28 00:09:56 --> Hooks Class Initialized
DEBUG - 2018-07-28 00:09:56 --> UTF-8 Support Enabled
INFO - 2018-07-28 00:09:56 --> Utf8 Class Initialized
INFO - 2018-07-28 00:09:56 --> URI Class Initialized
INFO - 2018-07-28 00:09:56 --> Router Class Initialized
INFO - 2018-07-28 00:09:56 --> Output Class Initialized
INFO - 2018-07-28 00:09:56 --> Security Class Initialized
DEBUG - 2018-07-28 00:09:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 00:09:56 --> Input Class Initialized
INFO - 2018-07-28 00:09:56 --> Language Class Initialized
INFO - 2018-07-28 00:09:56 --> Language Class Initialized
INFO - 2018-07-28 00:09:56 --> Config Class Initialized
INFO - 2018-07-28 00:09:56 --> Loader Class Initialized
DEBUG - 2018-07-28 00:09:56 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 00:09:56 --> Helper loaded: url_helper
INFO - 2018-07-28 00:09:56 --> Helper loaded: form_helper
INFO - 2018-07-28 00:09:56 --> Helper loaded: date_helper
INFO - 2018-07-28 00:09:56 --> Helper loaded: util_helper
INFO - 2018-07-28 00:09:56 --> Helper loaded: text_helper
INFO - 2018-07-28 00:09:56 --> Helper loaded: string_helper
INFO - 2018-07-28 00:09:56 --> Database Driver Class Initialized
DEBUG - 2018-07-28 00:09:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 00:09:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 00:09:56 --> Email Class Initialized
INFO - 2018-07-28 00:09:56 --> Controller Class Initialized
DEBUG - 2018-07-28 00:09:56 --> Login MX_Controller Initialized
INFO - 2018-07-28 00:09:56 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 00:09:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 00:09:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-28 00:09:56 --> Email starts for colin fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-07-28 00:09:56 --> User session created for 4
INFO - 2018-07-28 00:09:56 --> Login status colin - success
INFO - 2018-07-28 00:09:56 --> Final output sent to browser
DEBUG - 2018-07-28 00:09:56 --> Total execution time: 0.3492
INFO - 2018-07-28 00:09:56 --> Config Class Initialized
INFO - 2018-07-28 00:09:56 --> Hooks Class Initialized
DEBUG - 2018-07-28 00:09:56 --> UTF-8 Support Enabled
INFO - 2018-07-28 00:09:56 --> Utf8 Class Initialized
INFO - 2018-07-28 00:09:56 --> URI Class Initialized
DEBUG - 2018-07-28 00:09:56 --> No URI present. Default controller set.
INFO - 2018-07-28 00:09:56 --> Router Class Initialized
INFO - 2018-07-28 00:09:56 --> Output Class Initialized
INFO - 2018-07-28 00:09:56 --> Security Class Initialized
DEBUG - 2018-07-28 00:09:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 00:09:57 --> Input Class Initialized
INFO - 2018-07-28 00:09:57 --> Language Class Initialized
INFO - 2018-07-28 00:09:57 --> Language Class Initialized
INFO - 2018-07-28 00:09:57 --> Config Class Initialized
INFO - 2018-07-28 00:09:57 --> Loader Class Initialized
DEBUG - 2018-07-28 00:09:57 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 00:09:57 --> Helper loaded: url_helper
INFO - 2018-07-28 00:09:57 --> Helper loaded: form_helper
INFO - 2018-07-28 00:09:57 --> Helper loaded: date_helper
INFO - 2018-07-28 00:09:57 --> Helper loaded: util_helper
INFO - 2018-07-28 00:09:57 --> Helper loaded: text_helper
INFO - 2018-07-28 00:09:57 --> Helper loaded: string_helper
INFO - 2018-07-28 00:09:57 --> Database Driver Class Initialized
DEBUG - 2018-07-28 00:09:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 00:09:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 00:09:57 --> Email Class Initialized
INFO - 2018-07-28 00:09:57 --> Controller Class Initialized
DEBUG - 2018-07-28 00:09:57 --> Home MX_Controller Initialized
DEBUG - 2018-07-28 00:09:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-28 00:09:57 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 00:09:57 --> Login MX_Controller Initialized
INFO - 2018-07-28 00:09:57 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 00:09:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 00:09:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-28 00:09:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-28 00:09:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-28 00:09:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-28 00:09:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-28 00:09:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-28 00:09:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-28 00:09:57 --> Final output sent to browser
DEBUG - 2018-07-28 00:09:57 --> Total execution time: 0.3872
INFO - 2018-07-28 00:09:57 --> Config Class Initialized
INFO - 2018-07-28 00:09:57 --> Hooks Class Initialized
DEBUG - 2018-07-28 00:09:58 --> UTF-8 Support Enabled
INFO - 2018-07-28 00:09:58 --> Utf8 Class Initialized
INFO - 2018-07-28 00:09:58 --> URI Class Initialized
INFO - 2018-07-28 00:09:58 --> Router Class Initialized
INFO - 2018-07-28 00:09:58 --> Output Class Initialized
INFO - 2018-07-28 00:09:58 --> Config Class Initialized
INFO - 2018-07-28 00:09:58 --> Hooks Class Initialized
INFO - 2018-07-28 00:09:58 --> Security Class Initialized
DEBUG - 2018-07-28 00:09:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-07-28 00:09:58 --> UTF-8 Support Enabled
INFO - 2018-07-28 00:09:58 --> Input Class Initialized
INFO - 2018-07-28 00:09:58 --> Utf8 Class Initialized
INFO - 2018-07-28 00:09:58 --> Language Class Initialized
ERROR - 2018-07-28 00:09:58 --> 404 Page Not Found: /index
INFO - 2018-07-28 00:09:58 --> Config Class Initialized
INFO - 2018-07-28 00:09:58 --> Hooks Class Initialized
DEBUG - 2018-07-28 00:09:58 --> UTF-8 Support Enabled
INFO - 2018-07-28 00:09:58 --> Utf8 Class Initialized
INFO - 2018-07-28 00:09:58 --> URI Class Initialized
INFO - 2018-07-28 00:09:58 --> Router Class Initialized
INFO - 2018-07-28 00:09:58 --> Output Class Initialized
INFO - 2018-07-28 00:09:58 --> Security Class Initialized
INFO - 2018-07-28 00:09:58 --> URI Class Initialized
DEBUG - 2018-07-28 00:09:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 00:09:58 --> Input Class Initialized
INFO - 2018-07-28 00:09:58 --> Language Class Initialized
ERROR - 2018-07-28 00:09:58 --> 404 Page Not Found: /index
INFO - 2018-07-28 00:09:58 --> Config Class Initialized
INFO - 2018-07-28 00:09:58 --> Hooks Class Initialized
DEBUG - 2018-07-28 00:09:58 --> UTF-8 Support Enabled
INFO - 2018-07-28 00:09:58 --> Router Class Initialized
INFO - 2018-07-28 00:09:58 --> Utf8 Class Initialized
INFO - 2018-07-28 00:09:58 --> URI Class Initialized
INFO - 2018-07-28 00:09:58 --> Router Class Initialized
INFO - 2018-07-28 00:09:58 --> Output Class Initialized
INFO - 2018-07-28 00:09:58 --> Output Class Initialized
INFO - 2018-07-28 00:09:58 --> Security Class Initialized
DEBUG - 2018-07-28 00:09:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 00:09:58 --> Input Class Initialized
INFO - 2018-07-28 00:09:58 --> Language Class Initialized
ERROR - 2018-07-28 00:09:58 --> 404 Page Not Found: /index
INFO - 2018-07-28 00:09:58 --> Security Class Initialized
DEBUG - 2018-07-28 00:09:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 00:09:58 --> Input Class Initialized
INFO - 2018-07-28 00:09:58 --> Language Class Initialized
INFO - 2018-07-28 00:09:58 --> Language Class Initialized
INFO - 2018-07-28 00:09:58 --> Config Class Initialized
INFO - 2018-07-28 00:09:58 --> Loader Class Initialized
DEBUG - 2018-07-28 00:09:58 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 00:09:58 --> Helper loaded: url_helper
INFO - 2018-07-28 00:09:58 --> Helper loaded: form_helper
INFO - 2018-07-28 00:09:58 --> Helper loaded: date_helper
INFO - 2018-07-28 00:09:58 --> Helper loaded: util_helper
INFO - 2018-07-28 00:09:58 --> Helper loaded: text_helper
INFO - 2018-07-28 00:09:58 --> Helper loaded: string_helper
INFO - 2018-07-28 00:09:58 --> Database Driver Class Initialized
DEBUG - 2018-07-28 00:09:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 00:09:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 00:09:58 --> Email Class Initialized
INFO - 2018-07-28 00:09:58 --> Controller Class Initialized
DEBUG - 2018-07-28 00:09:58 --> Home MX_Controller Initialized
DEBUG - 2018-07-28 00:09:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-28 00:09:58 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 00:09:58 --> Login MX_Controller Initialized
INFO - 2018-07-28 00:09:58 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 00:09:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 00:09:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-28 00:10:10 --> Config Class Initialized
INFO - 2018-07-28 00:10:10 --> Hooks Class Initialized
DEBUG - 2018-07-28 00:10:10 --> UTF-8 Support Enabled
INFO - 2018-07-28 00:10:10 --> Utf8 Class Initialized
INFO - 2018-07-28 00:10:10 --> URI Class Initialized
INFO - 2018-07-28 00:10:10 --> Router Class Initialized
INFO - 2018-07-28 00:10:10 --> Output Class Initialized
INFO - 2018-07-28 00:10:10 --> Security Class Initialized
DEBUG - 2018-07-28 00:10:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 00:10:10 --> Input Class Initialized
INFO - 2018-07-28 00:10:10 --> Language Class Initialized
INFO - 2018-07-28 00:10:10 --> Language Class Initialized
INFO - 2018-07-28 00:10:10 --> Config Class Initialized
INFO - 2018-07-28 00:10:10 --> Loader Class Initialized
DEBUG - 2018-07-28 00:10:10 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 00:10:10 --> Helper loaded: url_helper
INFO - 2018-07-28 00:10:10 --> Helper loaded: form_helper
INFO - 2018-07-28 00:10:10 --> Helper loaded: date_helper
INFO - 2018-07-28 00:10:10 --> Helper loaded: util_helper
INFO - 2018-07-28 00:10:10 --> Helper loaded: text_helper
INFO - 2018-07-28 00:10:10 --> Helper loaded: string_helper
INFO - 2018-07-28 00:10:10 --> Database Driver Class Initialized
DEBUG - 2018-07-28 00:10:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 00:10:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 00:10:10 --> Email Class Initialized
INFO - 2018-07-28 00:10:10 --> Controller Class Initialized
DEBUG - 2018-07-28 00:10:10 --> Home MX_Controller Initialized
DEBUG - 2018-07-28 00:10:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-28 00:10:10 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 00:10:10 --> Login MX_Controller Initialized
INFO - 2018-07-28 00:10:10 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 00:10:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 00:10:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-28 00:10:13 --> Config Class Initialized
INFO - 2018-07-28 00:10:13 --> Hooks Class Initialized
DEBUG - 2018-07-28 00:10:13 --> UTF-8 Support Enabled
INFO - 2018-07-28 00:10:13 --> Utf8 Class Initialized
INFO - 2018-07-28 00:10:13 --> URI Class Initialized
DEBUG - 2018-07-28 00:10:13 --> No URI present. Default controller set.
INFO - 2018-07-28 00:10:13 --> Router Class Initialized
INFO - 2018-07-28 00:10:13 --> Output Class Initialized
INFO - 2018-07-28 00:10:13 --> Security Class Initialized
DEBUG - 2018-07-28 00:10:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 00:10:13 --> Input Class Initialized
INFO - 2018-07-28 00:10:13 --> Language Class Initialized
INFO - 2018-07-28 00:10:13 --> Language Class Initialized
INFO - 2018-07-28 00:10:13 --> Config Class Initialized
INFO - 2018-07-28 00:10:13 --> Loader Class Initialized
DEBUG - 2018-07-28 00:10:13 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 00:10:13 --> Helper loaded: url_helper
INFO - 2018-07-28 00:10:13 --> Helper loaded: form_helper
INFO - 2018-07-28 00:10:13 --> Helper loaded: date_helper
INFO - 2018-07-28 00:10:13 --> Helper loaded: util_helper
INFO - 2018-07-28 00:10:13 --> Helper loaded: text_helper
INFO - 2018-07-28 00:10:13 --> Helper loaded: string_helper
INFO - 2018-07-28 00:10:13 --> Database Driver Class Initialized
DEBUG - 2018-07-28 00:10:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 00:10:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 00:10:13 --> Email Class Initialized
INFO - 2018-07-28 00:10:13 --> Controller Class Initialized
DEBUG - 2018-07-28 00:10:13 --> Home MX_Controller Initialized
DEBUG - 2018-07-28 00:10:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-28 00:10:13 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 00:10:13 --> Login MX_Controller Initialized
INFO - 2018-07-28 00:10:13 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 00:10:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 00:10:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-28 00:10:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-28 00:10:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-28 00:10:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-28 00:10:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-28 00:10:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-28 00:10:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-28 00:10:14 --> Final output sent to browser
DEBUG - 2018-07-28 00:10:14 --> Total execution time: 0.4221
INFO - 2018-07-28 00:10:14 --> Config Class Initialized
INFO - 2018-07-28 00:10:14 --> Hooks Class Initialized
DEBUG - 2018-07-28 00:10:14 --> UTF-8 Support Enabled
INFO - 2018-07-28 00:10:14 --> Utf8 Class Initialized
INFO - 2018-07-28 00:10:14 --> URI Class Initialized
INFO - 2018-07-28 00:10:14 --> Router Class Initialized
INFO - 2018-07-28 00:10:14 --> Config Class Initialized
INFO - 2018-07-28 00:10:14 --> Hooks Class Initialized
INFO - 2018-07-28 00:10:14 --> Output Class Initialized
DEBUG - 2018-07-28 00:10:14 --> UTF-8 Support Enabled
INFO - 2018-07-28 00:10:14 --> Security Class Initialized
INFO - 2018-07-28 00:10:14 --> Utf8 Class Initialized
INFO - 2018-07-28 00:10:14 --> URI Class Initialized
INFO - 2018-07-28 00:10:14 --> Router Class Initialized
INFO - 2018-07-28 00:10:14 --> Output Class Initialized
INFO - 2018-07-28 00:10:14 --> Security Class Initialized
DEBUG - 2018-07-28 00:10:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 00:10:14 --> Input Class Initialized
INFO - 2018-07-28 00:10:14 --> Language Class Initialized
INFO - 2018-07-28 00:10:14 --> Language Class Initialized
DEBUG - 2018-07-28 00:10:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 00:10:14 --> Config Class Initialized
INFO - 2018-07-28 00:10:14 --> Input Class Initialized
INFO - 2018-07-28 00:10:14 --> Loader Class Initialized
INFO - 2018-07-28 00:10:14 --> Language Class Initialized
ERROR - 2018-07-28 00:10:14 --> 404 Page Not Found: /index
INFO - 2018-07-28 00:10:14 --> Config Class Initialized
DEBUG - 2018-07-28 00:10:14 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 00:10:14 --> Hooks Class Initialized
DEBUG - 2018-07-28 00:10:14 --> UTF-8 Support Enabled
INFO - 2018-07-28 00:10:14 --> Helper loaded: url_helper
INFO - 2018-07-28 00:10:14 --> Utf8 Class Initialized
INFO - 2018-07-28 00:10:14 --> URI Class Initialized
INFO - 2018-07-28 00:10:14 --> Router Class Initialized
INFO - 2018-07-28 00:10:14 --> Helper loaded: form_helper
INFO - 2018-07-28 00:10:14 --> Output Class Initialized
INFO - 2018-07-28 00:10:14 --> Security Class Initialized
INFO - 2018-07-28 00:10:14 --> Helper loaded: date_helper
DEBUG - 2018-07-28 00:10:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 00:10:14 --> Helper loaded: util_helper
INFO - 2018-07-28 00:10:14 --> Input Class Initialized
INFO - 2018-07-28 00:10:14 --> Helper loaded: text_helper
INFO - 2018-07-28 00:10:14 --> Language Class Initialized
INFO - 2018-07-28 00:10:14 --> Helper loaded: string_helper
ERROR - 2018-07-28 00:10:14 --> 404 Page Not Found: /index
INFO - 2018-07-28 00:10:14 --> Database Driver Class Initialized
INFO - 2018-07-28 00:10:14 --> Config Class Initialized
INFO - 2018-07-28 00:10:14 --> Hooks Class Initialized
DEBUG - 2018-07-28 00:10:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 00:10:14 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-07-28 00:10:14 --> UTF-8 Support Enabled
INFO - 2018-07-28 00:10:14 --> Utf8 Class Initialized
INFO - 2018-07-28 00:10:14 --> Email Class Initialized
INFO - 2018-07-28 00:10:14 --> Controller Class Initialized
INFO - 2018-07-28 00:10:14 --> URI Class Initialized
DEBUG - 2018-07-28 00:10:14 --> Home MX_Controller Initialized
INFO - 2018-07-28 00:10:14 --> Router Class Initialized
DEBUG - 2018-07-28 00:10:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-07-28 00:10:15 --> Output Class Initialized
INFO - 2018-07-28 00:10:15 --> Security Class Initialized
DEBUG - 2018-07-28 00:10:15 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 00:10:15 --> Login MX_Controller Initialized
DEBUG - 2018-07-28 00:10:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 00:10:15 --> Input Class Initialized
INFO - 2018-07-28 00:10:15 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 00:10:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-28 00:10:15 --> Language Class Initialized
DEBUG - 2018-07-28 00:10:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
ERROR - 2018-07-28 00:10:15 --> 404 Page Not Found: /index
INFO - 2018-07-28 00:10:41 --> Config Class Initialized
INFO - 2018-07-28 00:10:41 --> Hooks Class Initialized
DEBUG - 2018-07-28 00:10:41 --> UTF-8 Support Enabled
INFO - 2018-07-28 00:10:41 --> Utf8 Class Initialized
INFO - 2018-07-28 00:10:41 --> URI Class Initialized
INFO - 2018-07-28 00:10:41 --> Router Class Initialized
INFO - 2018-07-28 00:10:41 --> Output Class Initialized
INFO - 2018-07-28 00:10:41 --> Security Class Initialized
DEBUG - 2018-07-28 00:10:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 00:10:41 --> Input Class Initialized
INFO - 2018-07-28 00:10:41 --> Language Class Initialized
INFO - 2018-07-28 00:10:41 --> Language Class Initialized
INFO - 2018-07-28 00:10:41 --> Config Class Initialized
INFO - 2018-07-28 00:10:41 --> Loader Class Initialized
DEBUG - 2018-07-28 00:10:41 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 00:10:41 --> Helper loaded: url_helper
INFO - 2018-07-28 00:10:41 --> Helper loaded: form_helper
INFO - 2018-07-28 00:10:41 --> Helper loaded: date_helper
INFO - 2018-07-28 00:10:41 --> Helper loaded: util_helper
INFO - 2018-07-28 00:10:41 --> Helper loaded: text_helper
INFO - 2018-07-28 00:10:41 --> Helper loaded: string_helper
INFO - 2018-07-28 00:10:41 --> Database Driver Class Initialized
DEBUG - 2018-07-28 00:10:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 00:10:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 00:10:41 --> Email Class Initialized
INFO - 2018-07-28 00:10:41 --> Controller Class Initialized
DEBUG - 2018-07-28 00:10:41 --> Home MX_Controller Initialized
DEBUG - 2018-07-28 00:10:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-28 00:10:41 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 00:10:41 --> Login MX_Controller Initialized
INFO - 2018-07-28 00:10:41 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 00:10:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 00:10:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-28 00:10:42 --> Config Class Initialized
INFO - 2018-07-28 00:10:42 --> Hooks Class Initialized
DEBUG - 2018-07-28 00:10:42 --> UTF-8 Support Enabled
INFO - 2018-07-28 00:10:42 --> Utf8 Class Initialized
INFO - 2018-07-28 00:10:42 --> URI Class Initialized
DEBUG - 2018-07-28 00:10:42 --> No URI present. Default controller set.
INFO - 2018-07-28 00:10:42 --> Router Class Initialized
INFO - 2018-07-28 00:10:42 --> Output Class Initialized
INFO - 2018-07-28 00:10:42 --> Security Class Initialized
DEBUG - 2018-07-28 00:10:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 00:10:42 --> Input Class Initialized
INFO - 2018-07-28 00:10:42 --> Language Class Initialized
INFO - 2018-07-28 00:10:42 --> Language Class Initialized
INFO - 2018-07-28 00:10:42 --> Config Class Initialized
INFO - 2018-07-28 00:10:42 --> Loader Class Initialized
DEBUG - 2018-07-28 00:10:42 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 00:10:42 --> Helper loaded: url_helper
INFO - 2018-07-28 00:10:42 --> Helper loaded: form_helper
INFO - 2018-07-28 00:10:42 --> Helper loaded: date_helper
INFO - 2018-07-28 00:10:42 --> Helper loaded: util_helper
INFO - 2018-07-28 00:10:42 --> Helper loaded: text_helper
INFO - 2018-07-28 00:10:42 --> Helper loaded: string_helper
INFO - 2018-07-28 00:10:42 --> Database Driver Class Initialized
DEBUG - 2018-07-28 00:10:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 00:10:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 00:10:42 --> Email Class Initialized
INFO - 2018-07-28 00:10:42 --> Controller Class Initialized
DEBUG - 2018-07-28 00:10:42 --> Home MX_Controller Initialized
DEBUG - 2018-07-28 00:10:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-28 00:10:42 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 00:10:42 --> Login MX_Controller Initialized
INFO - 2018-07-28 00:10:42 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 00:10:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 00:10:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-28 00:10:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-28 00:10:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-28 00:10:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-28 00:10:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-28 00:10:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-28 00:10:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-28 00:10:42 --> Final output sent to browser
DEBUG - 2018-07-28 00:10:42 --> Total execution time: 0.4284
INFO - 2018-07-28 00:10:43 --> Config Class Initialized
INFO - 2018-07-28 00:10:43 --> Hooks Class Initialized
DEBUG - 2018-07-28 00:10:43 --> UTF-8 Support Enabled
INFO - 2018-07-28 00:10:43 --> Utf8 Class Initialized
INFO - 2018-07-28 00:10:43 --> Config Class Initialized
INFO - 2018-07-28 00:10:43 --> URI Class Initialized
INFO - 2018-07-28 00:10:43 --> Hooks Class Initialized
INFO - 2018-07-28 00:10:43 --> Router Class Initialized
INFO - 2018-07-28 00:10:43 --> Output Class Initialized
DEBUG - 2018-07-28 00:10:43 --> UTF-8 Support Enabled
INFO - 2018-07-28 00:10:43 --> Security Class Initialized
DEBUG - 2018-07-28 00:10:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 00:10:43 --> Input Class Initialized
INFO - 2018-07-28 00:10:43 --> Utf8 Class Initialized
INFO - 2018-07-28 00:10:43 --> Language Class Initialized
INFO - 2018-07-28 00:10:43 --> URI Class Initialized
ERROR - 2018-07-28 00:10:43 --> 404 Page Not Found: /index
INFO - 2018-07-28 00:10:43 --> Router Class Initialized
INFO - 2018-07-28 00:10:43 --> Output Class Initialized
INFO - 2018-07-28 00:10:43 --> Config Class Initialized
INFO - 2018-07-28 00:10:43 --> Hooks Class Initialized
INFO - 2018-07-28 00:10:43 --> Security Class Initialized
DEBUG - 2018-07-28 00:10:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-07-28 00:10:43 --> UTF-8 Support Enabled
INFO - 2018-07-28 00:10:43 --> Input Class Initialized
INFO - 2018-07-28 00:10:43 --> Utf8 Class Initialized
INFO - 2018-07-28 00:10:43 --> Language Class Initialized
INFO - 2018-07-28 00:10:43 --> URI Class Initialized
INFO - 2018-07-28 00:10:43 --> Language Class Initialized
INFO - 2018-07-28 00:10:43 --> Router Class Initialized
INFO - 2018-07-28 00:10:43 --> Config Class Initialized
INFO - 2018-07-28 00:10:43 --> Loader Class Initialized
INFO - 2018-07-28 00:10:43 --> Output Class Initialized
INFO - 2018-07-28 00:10:43 --> Security Class Initialized
DEBUG - 2018-07-28 00:10:43 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
DEBUG - 2018-07-28 00:10:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 00:10:43 --> Helper loaded: url_helper
INFO - 2018-07-28 00:10:43 --> Input Class Initialized
INFO - 2018-07-28 00:10:43 --> Helper loaded: form_helper
INFO - 2018-07-28 00:10:43 --> Language Class Initialized
INFO - 2018-07-28 00:10:43 --> Helper loaded: date_helper
ERROR - 2018-07-28 00:10:43 --> 404 Page Not Found: /index
INFO - 2018-07-28 00:10:43 --> Helper loaded: util_helper
INFO - 2018-07-28 00:10:43 --> Helper loaded: text_helper
INFO - 2018-07-28 00:10:43 --> Config Class Initialized
INFO - 2018-07-28 00:10:43 --> Hooks Class Initialized
INFO - 2018-07-28 00:10:43 --> Helper loaded: string_helper
DEBUG - 2018-07-28 00:10:43 --> UTF-8 Support Enabled
INFO - 2018-07-28 00:10:43 --> Database Driver Class Initialized
INFO - 2018-07-28 00:10:43 --> Utf8 Class Initialized
DEBUG - 2018-07-28 00:10:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 00:10:43 --> URI Class Initialized
INFO - 2018-07-28 00:10:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 00:10:43 --> Router Class Initialized
INFO - 2018-07-28 00:10:43 --> Email Class Initialized
INFO - 2018-07-28 00:10:43 --> Output Class Initialized
INFO - 2018-07-28 00:10:43 --> Controller Class Initialized
DEBUG - 2018-07-28 00:10:43 --> Home MX_Controller Initialized
DEBUG - 2018-07-28 00:10:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-07-28 00:10:43 --> Security Class Initialized
DEBUG - 2018-07-28 00:10:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-07-28 00:10:43 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 00:10:43 --> Login MX_Controller Initialized
INFO - 2018-07-28 00:10:43 --> Input Class Initialized
INFO - 2018-07-28 00:10:43 --> Language file loaded: language/english/data_lang.php
INFO - 2018-07-28 00:10:43 --> Language Class Initialized
DEBUG - 2018-07-28 00:10:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
ERROR - 2018-07-28 00:10:43 --> 404 Page Not Found: /index
DEBUG - 2018-07-28 00:10:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-28 00:11:53 --> Config Class Initialized
INFO - 2018-07-28 00:11:53 --> Hooks Class Initialized
DEBUG - 2018-07-28 00:11:53 --> UTF-8 Support Enabled
INFO - 2018-07-28 00:11:53 --> Utf8 Class Initialized
INFO - 2018-07-28 00:11:53 --> URI Class Initialized
DEBUG - 2018-07-28 00:11:53 --> No URI present. Default controller set.
INFO - 2018-07-28 00:11:53 --> Router Class Initialized
INFO - 2018-07-28 00:11:53 --> Output Class Initialized
INFO - 2018-07-28 00:11:53 --> Security Class Initialized
DEBUG - 2018-07-28 00:11:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 00:11:53 --> Input Class Initialized
INFO - 2018-07-28 00:11:53 --> Language Class Initialized
INFO - 2018-07-28 00:11:53 --> Language Class Initialized
INFO - 2018-07-28 00:11:53 --> Config Class Initialized
INFO - 2018-07-28 00:11:53 --> Loader Class Initialized
DEBUG - 2018-07-28 00:11:53 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 00:11:53 --> Helper loaded: url_helper
INFO - 2018-07-28 00:11:53 --> Helper loaded: form_helper
INFO - 2018-07-28 00:11:53 --> Helper loaded: date_helper
INFO - 2018-07-28 00:11:53 --> Helper loaded: util_helper
INFO - 2018-07-28 00:11:53 --> Helper loaded: text_helper
INFO - 2018-07-28 00:11:53 --> Helper loaded: string_helper
INFO - 2018-07-28 00:11:53 --> Database Driver Class Initialized
DEBUG - 2018-07-28 00:11:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 00:11:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 00:11:53 --> Email Class Initialized
INFO - 2018-07-28 00:11:53 --> Controller Class Initialized
DEBUG - 2018-07-28 00:11:53 --> Home MX_Controller Initialized
DEBUG - 2018-07-28 00:11:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-28 00:11:53 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 00:11:53 --> Login MX_Controller Initialized
INFO - 2018-07-28 00:11:53 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 00:11:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 00:11:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-28 00:11:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-28 00:11:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-28 00:11:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-28 00:11:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-28 00:11:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-28 00:11:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-28 00:11:53 --> Final output sent to browser
DEBUG - 2018-07-28 00:11:53 --> Total execution time: 0.6766
INFO - 2018-07-28 00:11:54 --> Config Class Initialized
INFO - 2018-07-28 00:11:54 --> Hooks Class Initialized
DEBUG - 2018-07-28 00:11:54 --> UTF-8 Support Enabled
INFO - 2018-07-28 00:11:54 --> Utf8 Class Initialized
INFO - 2018-07-28 00:11:54 --> Config Class Initialized
INFO - 2018-07-28 00:11:54 --> Hooks Class Initialized
INFO - 2018-07-28 00:11:54 --> URI Class Initialized
INFO - 2018-07-28 00:11:54 --> Router Class Initialized
DEBUG - 2018-07-28 00:11:54 --> UTF-8 Support Enabled
INFO - 2018-07-28 00:11:54 --> Output Class Initialized
INFO - 2018-07-28 00:11:54 --> Utf8 Class Initialized
INFO - 2018-07-28 00:11:54 --> Security Class Initialized
DEBUG - 2018-07-28 00:11:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 00:11:54 --> URI Class Initialized
INFO - 2018-07-28 00:11:54 --> Input Class Initialized
INFO - 2018-07-28 00:11:54 --> Router Class Initialized
INFO - 2018-07-28 00:11:54 --> Output Class Initialized
INFO - 2018-07-28 00:11:54 --> Language Class Initialized
INFO - 2018-07-28 00:11:54 --> Security Class Initialized
DEBUG - 2018-07-28 00:11:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 00:11:54 --> Input Class Initialized
INFO - 2018-07-28 00:11:54 --> Language Class Initialized
ERROR - 2018-07-28 00:11:54 --> 404 Page Not Found: /index
INFO - 2018-07-28 00:11:54 --> Language Class Initialized
INFO - 2018-07-28 00:11:54 --> Config Class Initialized
INFO - 2018-07-28 00:11:54 --> Loader Class Initialized
INFO - 2018-07-28 00:11:54 --> Config Class Initialized
INFO - 2018-07-28 00:11:54 --> Hooks Class Initialized
DEBUG - 2018-07-28 00:11:54 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 00:11:54 --> Helper loaded: url_helper
DEBUG - 2018-07-28 00:11:54 --> UTF-8 Support Enabled
INFO - 2018-07-28 00:11:54 --> Helper loaded: form_helper
INFO - 2018-07-28 00:11:54 --> Utf8 Class Initialized
INFO - 2018-07-28 00:11:54 --> Helper loaded: date_helper
INFO - 2018-07-28 00:11:54 --> URI Class Initialized
INFO - 2018-07-28 00:11:54 --> Router Class Initialized
INFO - 2018-07-28 00:11:54 --> Helper loaded: util_helper
INFO - 2018-07-28 00:11:54 --> Output Class Initialized
INFO - 2018-07-28 00:11:54 --> Helper loaded: text_helper
INFO - 2018-07-28 00:11:54 --> Security Class Initialized
INFO - 2018-07-28 00:11:54 --> Helper loaded: string_helper
DEBUG - 2018-07-28 00:11:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 00:11:54 --> Database Driver Class Initialized
INFO - 2018-07-28 00:11:54 --> Input Class Initialized
DEBUG - 2018-07-28 00:11:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 00:11:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 00:11:54 --> Language Class Initialized
ERROR - 2018-07-28 00:11:54 --> 404 Page Not Found: /index
INFO - 2018-07-28 00:11:54 --> Email Class Initialized
INFO - 2018-07-28 00:11:54 --> Controller Class Initialized
INFO - 2018-07-28 00:11:54 --> Config Class Initialized
INFO - 2018-07-28 00:11:54 --> Hooks Class Initialized
DEBUG - 2018-07-28 00:11:54 --> Home MX_Controller Initialized
DEBUG - 2018-07-28 00:11:54 --> UTF-8 Support Enabled
DEBUG - 2018-07-28 00:11:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-07-28 00:11:54 --> Utf8 Class Initialized
DEBUG - 2018-07-28 00:11:54 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 00:11:54 --> Login MX_Controller Initialized
INFO - 2018-07-28 00:11:54 --> URI Class Initialized
INFO - 2018-07-28 00:11:54 --> Language file loaded: language/english/data_lang.php
INFO - 2018-07-28 00:11:54 --> Router Class Initialized
DEBUG - 2018-07-28 00:11:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-28 00:11:54 --> Output Class Initialized
DEBUG - 2018-07-28 00:11:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-28 00:11:54 --> Security Class Initialized
DEBUG - 2018-07-28 00:11:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 00:11:54 --> Input Class Initialized
INFO - 2018-07-28 00:11:54 --> Language Class Initialized
ERROR - 2018-07-28 00:11:55 --> 404 Page Not Found: /index
INFO - 2018-07-28 00:20:02 --> Config Class Initialized
INFO - 2018-07-28 00:20:02 --> Hooks Class Initialized
DEBUG - 2018-07-28 00:20:02 --> UTF-8 Support Enabled
INFO - 2018-07-28 00:20:02 --> Utf8 Class Initialized
INFO - 2018-07-28 00:20:02 --> URI Class Initialized
INFO - 2018-07-28 00:20:02 --> Router Class Initialized
INFO - 2018-07-28 00:20:02 --> Output Class Initialized
INFO - 2018-07-28 00:20:02 --> Security Class Initialized
DEBUG - 2018-07-28 00:20:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 00:20:02 --> Input Class Initialized
INFO - 2018-07-28 00:20:02 --> Language Class Initialized
INFO - 2018-07-28 00:20:02 --> Language Class Initialized
INFO - 2018-07-28 00:20:02 --> Config Class Initialized
INFO - 2018-07-28 00:20:02 --> Loader Class Initialized
DEBUG - 2018-07-28 00:20:02 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 00:20:02 --> Helper loaded: url_helper
INFO - 2018-07-28 00:20:02 --> Helper loaded: form_helper
INFO - 2018-07-28 00:20:02 --> Helper loaded: date_helper
INFO - 2018-07-28 00:20:02 --> Helper loaded: util_helper
INFO - 2018-07-28 00:20:02 --> Helper loaded: text_helper
INFO - 2018-07-28 00:20:02 --> Helper loaded: string_helper
INFO - 2018-07-28 00:20:02 --> Database Driver Class Initialized
DEBUG - 2018-07-28 00:20:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 00:20:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 00:20:02 --> Email Class Initialized
INFO - 2018-07-28 00:20:02 --> Controller Class Initialized
DEBUG - 2018-07-28 00:20:02 --> Home MX_Controller Initialized
DEBUG - 2018-07-28 00:20:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-28 00:20:03 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 00:20:03 --> Login MX_Controller Initialized
INFO - 2018-07-28 00:20:03 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 00:20:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 00:20:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-28 00:20:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-28 00:20:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-28 00:20:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-28 00:20:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-28 00:20:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-28 00:20:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-07-28 00:20:03 --> Final output sent to browser
DEBUG - 2018-07-28 00:20:03 --> Total execution time: 0.5385
INFO - 2018-07-28 00:20:03 --> Config Class Initialized
INFO - 2018-07-28 00:20:03 --> Config Class Initialized
INFO - 2018-07-28 00:20:03 --> Hooks Class Initialized
INFO - 2018-07-28 00:20:03 --> Hooks Class Initialized
DEBUG - 2018-07-28 00:20:03 --> UTF-8 Support Enabled
INFO - 2018-07-28 00:20:03 --> Utf8 Class Initialized
DEBUG - 2018-07-28 00:20:03 --> UTF-8 Support Enabled
INFO - 2018-07-28 00:20:03 --> URI Class Initialized
INFO - 2018-07-28 00:20:03 --> Config Class Initialized
INFO - 2018-07-28 00:20:03 --> Utf8 Class Initialized
INFO - 2018-07-28 00:20:03 --> Hooks Class Initialized
INFO - 2018-07-28 00:20:03 --> Router Class Initialized
INFO - 2018-07-28 00:20:03 --> URI Class Initialized
DEBUG - 2018-07-28 00:20:03 --> UTF-8 Support Enabled
INFO - 2018-07-28 00:20:03 --> Output Class Initialized
INFO - 2018-07-28 00:20:03 --> Router Class Initialized
INFO - 2018-07-28 00:20:03 --> Utf8 Class Initialized
INFO - 2018-07-28 00:20:03 --> URI Class Initialized
INFO - 2018-07-28 00:20:03 --> Router Class Initialized
INFO - 2018-07-28 00:20:03 --> Output Class Initialized
INFO - 2018-07-28 00:20:03 --> Security Class Initialized
DEBUG - 2018-07-28 00:20:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 00:20:03 --> Output Class Initialized
INFO - 2018-07-28 00:20:03 --> Security Class Initialized
INFO - 2018-07-28 00:20:03 --> Input Class Initialized
INFO - 2018-07-28 00:20:03 --> Security Class Initialized
DEBUG - 2018-07-28 00:20:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 00:20:03 --> Input Class Initialized
INFO - 2018-07-28 00:20:04 --> Language Class Initialized
ERROR - 2018-07-28 00:20:04 --> 404 Page Not Found: /index
DEBUG - 2018-07-28 00:20:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 00:20:04 --> Config Class Initialized
INFO - 2018-07-28 00:20:04 --> Hooks Class Initialized
INFO - 2018-07-28 00:20:04 --> Input Class Initialized
INFO - 2018-07-28 00:20:04 --> Language Class Initialized
DEBUG - 2018-07-28 00:20:04 --> UTF-8 Support Enabled
INFO - 2018-07-28 00:20:04 --> Utf8 Class Initialized
INFO - 2018-07-28 00:20:04 --> URI Class Initialized
INFO - 2018-07-28 00:20:04 --> Router Class Initialized
INFO - 2018-07-28 00:20:04 --> Output Class Initialized
INFO - 2018-07-28 00:20:04 --> Security Class Initialized
DEBUG - 2018-07-28 00:20:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 00:20:04 --> Input Class Initialized
INFO - 2018-07-28 00:20:04 --> Language Class Initialized
ERROR - 2018-07-28 00:20:04 --> 404 Page Not Found: /index
INFO - 2018-07-28 00:20:04 --> Config Class Initialized
INFO - 2018-07-28 00:20:04 --> Language Class Initialized
INFO - 2018-07-28 00:20:04 --> Language Class Initialized
INFO - 2018-07-28 00:20:04 --> Hooks Class Initialized
DEBUG - 2018-07-28 00:20:04 --> UTF-8 Support Enabled
INFO - 2018-07-28 00:20:04 --> Utf8 Class Initialized
INFO - 2018-07-28 00:20:04 --> URI Class Initialized
INFO - 2018-07-28 00:20:04 --> Router Class Initialized
INFO - 2018-07-28 00:20:04 --> Output Class Initialized
INFO - 2018-07-28 00:20:04 --> Security Class Initialized
DEBUG - 2018-07-28 00:20:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 00:20:04 --> Input Class Initialized
INFO - 2018-07-28 00:20:04 --> Language Class Initialized
ERROR - 2018-07-28 00:20:04 --> 404 Page Not Found: /index
ERROR - 2018-07-28 00:20:04 --> 404 Page Not Found: /index
INFO - 2018-07-28 00:20:04 --> Config Class Initialized
INFO - 2018-07-28 00:20:04 --> Loader Class Initialized
DEBUG - 2018-07-28 00:20:04 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 00:20:04 --> Helper loaded: url_helper
INFO - 2018-07-28 00:20:04 --> Helper loaded: form_helper
INFO - 2018-07-28 00:20:04 --> Helper loaded: date_helper
INFO - 2018-07-28 00:20:04 --> Helper loaded: util_helper
INFO - 2018-07-28 00:20:04 --> Helper loaded: text_helper
INFO - 2018-07-28 00:20:04 --> Helper loaded: string_helper
INFO - 2018-07-28 00:20:04 --> Database Driver Class Initialized
DEBUG - 2018-07-28 00:20:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 00:20:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 00:20:04 --> Email Class Initialized
INFO - 2018-07-28 00:20:04 --> Controller Class Initialized
DEBUG - 2018-07-28 00:20:04 --> Home MX_Controller Initialized
DEBUG - 2018-07-28 00:20:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-28 00:20:04 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 00:20:04 --> Login MX_Controller Initialized
INFO - 2018-07-28 00:20:04 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 00:20:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 00:20:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-28 00:26:28 --> Config Class Initialized
INFO - 2018-07-28 00:26:28 --> Hooks Class Initialized
DEBUG - 2018-07-28 00:26:28 --> UTF-8 Support Enabled
INFO - 2018-07-28 00:26:28 --> Utf8 Class Initialized
INFO - 2018-07-28 00:26:28 --> URI Class Initialized
DEBUG - 2018-07-28 00:26:28 --> No URI present. Default controller set.
INFO - 2018-07-28 00:26:28 --> Router Class Initialized
INFO - 2018-07-28 00:26:28 --> Output Class Initialized
INFO - 2018-07-28 00:26:28 --> Security Class Initialized
DEBUG - 2018-07-28 00:26:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 00:26:28 --> Input Class Initialized
INFO - 2018-07-28 00:26:28 --> Language Class Initialized
INFO - 2018-07-28 00:26:28 --> Language Class Initialized
INFO - 2018-07-28 00:26:28 --> Config Class Initialized
INFO - 2018-07-28 00:26:28 --> Loader Class Initialized
DEBUG - 2018-07-28 00:26:28 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 00:26:28 --> Helper loaded: url_helper
INFO - 2018-07-28 00:26:28 --> Helper loaded: form_helper
INFO - 2018-07-28 00:26:28 --> Helper loaded: date_helper
INFO - 2018-07-28 00:26:28 --> Helper loaded: util_helper
INFO - 2018-07-28 00:26:28 --> Helper loaded: text_helper
INFO - 2018-07-28 00:26:28 --> Helper loaded: string_helper
INFO - 2018-07-28 00:26:28 --> Database Driver Class Initialized
DEBUG - 2018-07-28 00:26:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 00:26:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 00:26:28 --> Email Class Initialized
INFO - 2018-07-28 00:26:28 --> Controller Class Initialized
DEBUG - 2018-07-28 00:26:28 --> Home MX_Controller Initialized
DEBUG - 2018-07-28 00:26:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-28 00:26:28 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 00:26:28 --> Login MX_Controller Initialized
INFO - 2018-07-28 00:26:28 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 00:26:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 00:26:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-28 00:26:28 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-28 00:26:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-28 00:26:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-28 00:26:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-28 00:26:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-28 00:26:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-28 00:26:29 --> Final output sent to browser
DEBUG - 2018-07-28 00:26:29 --> Total execution time: 0.5048
INFO - 2018-07-28 00:26:29 --> Config Class Initialized
INFO - 2018-07-28 00:26:29 --> Hooks Class Initialized
INFO - 2018-07-28 00:26:29 --> Config Class Initialized
INFO - 2018-07-28 00:26:29 --> Hooks Class Initialized
DEBUG - 2018-07-28 00:26:29 --> UTF-8 Support Enabled
INFO - 2018-07-28 00:26:29 --> Utf8 Class Initialized
DEBUG - 2018-07-28 00:26:29 --> UTF-8 Support Enabled
INFO - 2018-07-28 00:26:29 --> URI Class Initialized
INFO - 2018-07-28 00:26:29 --> Utf8 Class Initialized
INFO - 2018-07-28 00:26:29 --> Router Class Initialized
INFO - 2018-07-28 00:26:29 --> Output Class Initialized
INFO - 2018-07-28 00:26:29 --> URI Class Initialized
INFO - 2018-07-28 00:26:29 --> Router Class Initialized
INFO - 2018-07-28 00:26:29 --> Security Class Initialized
DEBUG - 2018-07-28 00:26:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 00:26:29 --> Output Class Initialized
INFO - 2018-07-28 00:26:29 --> Input Class Initialized
INFO - 2018-07-28 00:26:29 --> Language Class Initialized
INFO - 2018-07-28 00:26:29 --> Security Class Initialized
ERROR - 2018-07-28 00:26:29 --> 404 Page Not Found: /index
DEBUG - 2018-07-28 00:26:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 00:26:29 --> Config Class Initialized
INFO - 2018-07-28 00:26:29 --> Hooks Class Initialized
INFO - 2018-07-28 00:26:29 --> Input Class Initialized
INFO - 2018-07-28 00:26:29 --> Language Class Initialized
DEBUG - 2018-07-28 00:26:29 --> UTF-8 Support Enabled
INFO - 2018-07-28 00:26:29 --> Utf8 Class Initialized
INFO - 2018-07-28 00:26:29 --> Language Class Initialized
INFO - 2018-07-28 00:26:29 --> URI Class Initialized
INFO - 2018-07-28 00:26:29 --> Config Class Initialized
INFO - 2018-07-28 00:26:29 --> Router Class Initialized
INFO - 2018-07-28 00:26:29 --> Loader Class Initialized
DEBUG - 2018-07-28 00:26:29 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 00:26:29 --> Output Class Initialized
INFO - 2018-07-28 00:26:29 --> Security Class Initialized
INFO - 2018-07-28 00:26:29 --> Helper loaded: url_helper
DEBUG - 2018-07-28 00:26:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 00:26:29 --> Helper loaded: form_helper
INFO - 2018-07-28 00:26:29 --> Input Class Initialized
INFO - 2018-07-28 00:26:29 --> Helper loaded: date_helper
INFO - 2018-07-28 00:26:29 --> Language Class Initialized
INFO - 2018-07-28 00:26:29 --> Helper loaded: util_helper
ERROR - 2018-07-28 00:26:29 --> 404 Page Not Found: /index
INFO - 2018-07-28 00:26:29 --> Helper loaded: text_helper
INFO - 2018-07-28 00:26:29 --> Helper loaded: string_helper
INFO - 2018-07-28 00:26:29 --> Config Class Initialized
INFO - 2018-07-28 00:26:29 --> Hooks Class Initialized
INFO - 2018-07-28 00:26:29 --> Database Driver Class Initialized
DEBUG - 2018-07-28 00:26:29 --> UTF-8 Support Enabled
DEBUG - 2018-07-28 00:26:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 00:26:30 --> Utf8 Class Initialized
INFO - 2018-07-28 00:26:30 --> URI Class Initialized
INFO - 2018-07-28 00:26:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 00:26:30 --> Email Class Initialized
INFO - 2018-07-28 00:26:30 --> Router Class Initialized
INFO - 2018-07-28 00:26:30 --> Controller Class Initialized
INFO - 2018-07-28 00:26:30 --> Output Class Initialized
DEBUG - 2018-07-28 00:26:30 --> Home MX_Controller Initialized
INFO - 2018-07-28 00:26:30 --> Security Class Initialized
DEBUG - 2018-07-28 00:26:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-07-28 00:26:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-07-28 00:26:30 --> Input Class Initialized
DEBUG - 2018-07-28 00:26:30 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 00:26:30 --> Login MX_Controller Initialized
INFO - 2018-07-28 00:26:30 --> Language Class Initialized
INFO - 2018-07-28 00:26:30 --> Language file loaded: language/english/data_lang.php
ERROR - 2018-07-28 00:26:30 --> 404 Page Not Found: /index
DEBUG - 2018-07-28 00:26:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 00:26:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-28 00:28:37 --> Config Class Initialized
INFO - 2018-07-28 00:28:37 --> Hooks Class Initialized
DEBUG - 2018-07-28 00:28:37 --> UTF-8 Support Enabled
INFO - 2018-07-28 00:28:37 --> Utf8 Class Initialized
INFO - 2018-07-28 00:28:37 --> URI Class Initialized
INFO - 2018-07-28 00:28:37 --> Router Class Initialized
INFO - 2018-07-28 00:28:37 --> Output Class Initialized
INFO - 2018-07-28 00:28:37 --> Security Class Initialized
DEBUG - 2018-07-28 00:28:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 00:28:37 --> Input Class Initialized
INFO - 2018-07-28 00:28:37 --> Language Class Initialized
INFO - 2018-07-28 00:28:37 --> Language Class Initialized
INFO - 2018-07-28 00:28:37 --> Config Class Initialized
INFO - 2018-07-28 00:28:37 --> Config Class Initialized
INFO - 2018-07-28 00:28:37 --> Hooks Class Initialized
INFO - 2018-07-28 00:28:37 --> Loader Class Initialized
DEBUG - 2018-07-28 00:28:37 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
DEBUG - 2018-07-28 00:28:37 --> UTF-8 Support Enabled
INFO - 2018-07-28 00:28:37 --> Utf8 Class Initialized
INFO - 2018-07-28 00:28:37 --> Helper loaded: url_helper
INFO - 2018-07-28 00:28:37 --> URI Class Initialized
INFO - 2018-07-28 00:28:37 --> Helper loaded: form_helper
INFO - 2018-07-28 00:28:37 --> Helper loaded: date_helper
INFO - 2018-07-28 00:28:37 --> Router Class Initialized
INFO - 2018-07-28 00:28:37 --> Output Class Initialized
INFO - 2018-07-28 00:28:37 --> Helper loaded: util_helper
INFO - 2018-07-28 00:28:37 --> Security Class Initialized
INFO - 2018-07-28 00:28:37 --> Helper loaded: text_helper
INFO - 2018-07-28 00:28:37 --> Helper loaded: string_helper
DEBUG - 2018-07-28 00:28:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 00:28:37 --> Input Class Initialized
INFO - 2018-07-28 00:28:37 --> Database Driver Class Initialized
INFO - 2018-07-28 00:28:37 --> Language Class Initialized
DEBUG - 2018-07-28 00:28:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 00:28:37 --> Session: Class initialized using 'files' driver.
ERROR - 2018-07-28 00:28:37 --> 404 Page Not Found: /index
INFO - 2018-07-28 00:28:37 --> Email Class Initialized
INFO - 2018-07-28 00:28:37 --> Config Class Initialized
INFO - 2018-07-28 00:28:37 --> Controller Class Initialized
INFO - 2018-07-28 00:28:37 --> Hooks Class Initialized
DEBUG - 2018-07-28 00:28:37 --> Home MX_Controller Initialized
DEBUG - 2018-07-28 00:28:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-28 00:28:37 --> UTF-8 Support Enabled
INFO - 2018-07-28 00:28:37 --> Utf8 Class Initialized
DEBUG - 2018-07-28 00:28:37 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 00:28:37 --> Login MX_Controller Initialized
INFO - 2018-07-28 00:28:37 --> URI Class Initialized
INFO - 2018-07-28 00:28:37 --> Language file loaded: language/english/data_lang.php
INFO - 2018-07-28 00:28:37 --> Router Class Initialized
DEBUG - 2018-07-28 00:28:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-28 00:28:37 --> Output Class Initialized
DEBUG - 2018-07-28 00:28:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-28 00:28:37 --> Security Class Initialized
DEBUG - 2018-07-28 00:28:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 00:28:38 --> Input Class Initialized
INFO - 2018-07-28 00:28:38 --> Language Class Initialized
ERROR - 2018-07-28 00:28:38 --> 404 Page Not Found: /index
INFO - 2018-07-28 00:28:38 --> Config Class Initialized
INFO - 2018-07-28 00:28:38 --> Hooks Class Initialized
DEBUG - 2018-07-28 00:28:38 --> UTF-8 Support Enabled
INFO - 2018-07-28 00:28:38 --> Utf8 Class Initialized
INFO - 2018-07-28 00:28:38 --> URI Class Initialized
INFO - 2018-07-28 00:28:38 --> Router Class Initialized
INFO - 2018-07-28 00:28:38 --> Output Class Initialized
INFO - 2018-07-28 00:28:38 --> Security Class Initialized
DEBUG - 2018-07-28 00:28:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 00:28:38 --> Input Class Initialized
INFO - 2018-07-28 00:28:38 --> Language Class Initialized
ERROR - 2018-07-28 00:28:38 --> 404 Page Not Found: /index
INFO - 2018-07-28 00:28:42 --> Config Class Initialized
INFO - 2018-07-28 00:28:42 --> Hooks Class Initialized
DEBUG - 2018-07-28 00:28:42 --> UTF-8 Support Enabled
INFO - 2018-07-28 00:28:42 --> Utf8 Class Initialized
INFO - 2018-07-28 00:28:42 --> URI Class Initialized
DEBUG - 2018-07-28 00:28:42 --> No URI present. Default controller set.
INFO - 2018-07-28 00:28:42 --> Router Class Initialized
INFO - 2018-07-28 00:28:42 --> Output Class Initialized
INFO - 2018-07-28 00:28:42 --> Security Class Initialized
DEBUG - 2018-07-28 00:28:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 00:28:42 --> Input Class Initialized
INFO - 2018-07-28 00:28:42 --> Language Class Initialized
INFO - 2018-07-28 00:28:42 --> Language Class Initialized
INFO - 2018-07-28 00:28:42 --> Config Class Initialized
INFO - 2018-07-28 00:28:42 --> Loader Class Initialized
DEBUG - 2018-07-28 00:28:42 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 00:28:42 --> Helper loaded: url_helper
INFO - 2018-07-28 00:28:42 --> Helper loaded: form_helper
INFO - 2018-07-28 00:28:42 --> Helper loaded: date_helper
INFO - 2018-07-28 00:28:42 --> Helper loaded: util_helper
INFO - 2018-07-28 00:28:42 --> Helper loaded: text_helper
INFO - 2018-07-28 00:28:42 --> Helper loaded: string_helper
INFO - 2018-07-28 00:28:42 --> Database Driver Class Initialized
DEBUG - 2018-07-28 00:28:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 00:28:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 00:28:42 --> Email Class Initialized
INFO - 2018-07-28 00:28:42 --> Controller Class Initialized
DEBUG - 2018-07-28 00:28:42 --> Home MX_Controller Initialized
DEBUG - 2018-07-28 00:28:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-28 00:28:42 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 00:28:42 --> Login MX_Controller Initialized
INFO - 2018-07-28 00:28:42 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 00:28:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 00:28:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-28 00:28:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-28 00:28:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-28 00:28:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-28 00:28:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-28 00:28:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-28 00:28:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-28 00:28:42 --> Final output sent to browser
DEBUG - 2018-07-28 00:28:42 --> Total execution time: 0.5818
INFO - 2018-07-28 00:28:43 --> Config Class Initialized
INFO - 2018-07-28 00:28:43 --> Hooks Class Initialized
DEBUG - 2018-07-28 00:28:43 --> UTF-8 Support Enabled
INFO - 2018-07-28 00:28:43 --> Config Class Initialized
INFO - 2018-07-28 00:28:43 --> Hooks Class Initialized
INFO - 2018-07-28 00:28:43 --> Utf8 Class Initialized
DEBUG - 2018-07-28 00:28:43 --> UTF-8 Support Enabled
INFO - 2018-07-28 00:28:43 --> Utf8 Class Initialized
INFO - 2018-07-28 00:28:43 --> URI Class Initialized
INFO - 2018-07-28 00:28:43 --> URI Class Initialized
INFO - 2018-07-28 00:28:43 --> Router Class Initialized
INFO - 2018-07-28 00:28:43 --> Output Class Initialized
INFO - 2018-07-28 00:28:43 --> Router Class Initialized
INFO - 2018-07-28 00:28:43 --> Security Class Initialized
DEBUG - 2018-07-28 00:28:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 00:28:43 --> Output Class Initialized
INFO - 2018-07-28 00:28:43 --> Input Class Initialized
INFO - 2018-07-28 00:28:43 --> Security Class Initialized
INFO - 2018-07-28 00:28:43 --> Language Class Initialized
DEBUG - 2018-07-28 00:28:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 00:28:43 --> Input Class Initialized
INFO - 2018-07-28 00:28:43 --> Language Class Initialized
INFO - 2018-07-28 00:28:43 --> Config Class Initialized
INFO - 2018-07-28 00:28:43 --> Language Class Initialized
ERROR - 2018-07-28 00:28:43 --> 404 Page Not Found: /index
INFO - 2018-07-28 00:28:43 --> Loader Class Initialized
INFO - 2018-07-28 00:28:43 --> Config Class Initialized
INFO - 2018-07-28 00:28:43 --> Hooks Class Initialized
DEBUG - 2018-07-28 00:28:44 --> UTF-8 Support Enabled
INFO - 2018-07-28 00:28:44 --> Utf8 Class Initialized
DEBUG - 2018-07-28 00:28:44 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 00:28:44 --> Helper loaded: url_helper
INFO - 2018-07-28 00:28:44 --> URI Class Initialized
INFO - 2018-07-28 00:28:44 --> Helper loaded: form_helper
INFO - 2018-07-28 00:28:44 --> Router Class Initialized
INFO - 2018-07-28 00:28:44 --> Helper loaded: date_helper
INFO - 2018-07-28 00:28:44 --> Output Class Initialized
INFO - 2018-07-28 00:28:44 --> Helper loaded: util_helper
INFO - 2018-07-28 00:28:44 --> Helper loaded: text_helper
INFO - 2018-07-28 00:28:44 --> Security Class Initialized
INFO - 2018-07-28 00:28:44 --> Helper loaded: string_helper
DEBUG - 2018-07-28 00:28:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 00:28:44 --> Input Class Initialized
INFO - 2018-07-28 00:28:44 --> Database Driver Class Initialized
INFO - 2018-07-28 00:28:44 --> Language Class Initialized
DEBUG - 2018-07-28 00:28:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 00:28:44 --> Session: Class initialized using 'files' driver.
ERROR - 2018-07-28 00:28:44 --> 404 Page Not Found: /index
INFO - 2018-07-28 00:28:44 --> Email Class Initialized
INFO - 2018-07-28 00:28:44 --> Config Class Initialized
INFO - 2018-07-28 00:28:44 --> Hooks Class Initialized
INFO - 2018-07-28 00:28:44 --> Controller Class Initialized
DEBUG - 2018-07-28 00:28:44 --> Home MX_Controller Initialized
DEBUG - 2018-07-28 00:28:44 --> UTF-8 Support Enabled
INFO - 2018-07-28 00:28:44 --> Utf8 Class Initialized
DEBUG - 2018-07-28 00:28:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-07-28 00:28:44 --> URI Class Initialized
DEBUG - 2018-07-28 00:28:44 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 00:28:44 --> Login MX_Controller Initialized
INFO - 2018-07-28 00:28:44 --> Router Class Initialized
INFO - 2018-07-28 00:28:44 --> Language file loaded: language/english/data_lang.php
INFO - 2018-07-28 00:28:44 --> Output Class Initialized
DEBUG - 2018-07-28 00:28:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-28 00:28:44 --> Security Class Initialized
DEBUG - 2018-07-28 00:28:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-28 00:28:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 00:28:44 --> Input Class Initialized
INFO - 2018-07-28 00:28:44 --> Language Class Initialized
ERROR - 2018-07-28 00:28:44 --> 404 Page Not Found: /index
INFO - 2018-07-28 00:28:45 --> Config Class Initialized
INFO - 2018-07-28 00:28:45 --> Hooks Class Initialized
DEBUG - 2018-07-28 00:28:45 --> UTF-8 Support Enabled
INFO - 2018-07-28 00:28:45 --> Utf8 Class Initialized
INFO - 2018-07-28 00:28:45 --> URI Class Initialized
DEBUG - 2018-07-28 00:28:45 --> No URI present. Default controller set.
INFO - 2018-07-28 00:28:45 --> Router Class Initialized
INFO - 2018-07-28 00:28:45 --> Output Class Initialized
INFO - 2018-07-28 00:28:45 --> Security Class Initialized
DEBUG - 2018-07-28 00:28:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 00:28:45 --> Input Class Initialized
INFO - 2018-07-28 00:28:45 --> Language Class Initialized
INFO - 2018-07-28 00:28:45 --> Language Class Initialized
INFO - 2018-07-28 00:28:45 --> Config Class Initialized
INFO - 2018-07-28 00:28:45 --> Loader Class Initialized
DEBUG - 2018-07-28 00:28:45 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 00:28:45 --> Helper loaded: url_helper
INFO - 2018-07-28 00:28:45 --> Helper loaded: form_helper
INFO - 2018-07-28 00:28:45 --> Helper loaded: date_helper
INFO - 2018-07-28 00:28:45 --> Helper loaded: util_helper
INFO - 2018-07-28 00:28:45 --> Helper loaded: text_helper
INFO - 2018-07-28 00:28:45 --> Helper loaded: string_helper
INFO - 2018-07-28 00:28:45 --> Database Driver Class Initialized
DEBUG - 2018-07-28 00:28:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 00:28:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 00:28:45 --> Email Class Initialized
INFO - 2018-07-28 00:28:45 --> Controller Class Initialized
DEBUG - 2018-07-28 00:28:45 --> Home MX_Controller Initialized
DEBUG - 2018-07-28 00:28:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-28 00:28:45 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 00:28:45 --> Login MX_Controller Initialized
INFO - 2018-07-28 00:28:45 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 00:28:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 00:28:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-28 00:28:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-28 00:28:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-28 00:28:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-28 00:28:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-28 00:28:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-28 00:28:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-28 00:28:46 --> Final output sent to browser
DEBUG - 2018-07-28 00:28:46 --> Total execution time: 0.5030
INFO - 2018-07-28 00:28:46 --> Config Class Initialized
INFO - 2018-07-28 00:28:46 --> Hooks Class Initialized
DEBUG - 2018-07-28 00:28:46 --> UTF-8 Support Enabled
INFO - 2018-07-28 00:28:46 --> Utf8 Class Initialized
INFO - 2018-07-28 00:28:46 --> Config Class Initialized
INFO - 2018-07-28 00:28:46 --> Hooks Class Initialized
INFO - 2018-07-28 00:28:46 --> URI Class Initialized
DEBUG - 2018-07-28 00:28:46 --> UTF-8 Support Enabled
INFO - 2018-07-28 00:28:46 --> Router Class Initialized
INFO - 2018-07-28 00:28:46 --> Utf8 Class Initialized
INFO - 2018-07-28 00:28:46 --> Output Class Initialized
INFO - 2018-07-28 00:28:46 --> Security Class Initialized
INFO - 2018-07-28 00:28:46 --> URI Class Initialized
DEBUG - 2018-07-28 00:28:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 00:28:46 --> Input Class Initialized
INFO - 2018-07-28 00:28:46 --> Language Class Initialized
ERROR - 2018-07-28 00:28:46 --> 404 Page Not Found: /index
INFO - 2018-07-28 00:28:46 --> Router Class Initialized
INFO - 2018-07-28 00:28:46 --> Output Class Initialized
INFO - 2018-07-28 00:28:46 --> Security Class Initialized
INFO - 2018-07-28 00:28:46 --> Config Class Initialized
INFO - 2018-07-28 00:28:46 --> Hooks Class Initialized
DEBUG - 2018-07-28 00:28:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 00:28:46 --> Input Class Initialized
DEBUG - 2018-07-28 00:28:46 --> UTF-8 Support Enabled
INFO - 2018-07-28 00:28:46 --> Utf8 Class Initialized
INFO - 2018-07-28 00:28:46 --> Language Class Initialized
INFO - 2018-07-28 00:28:46 --> Language Class Initialized
INFO - 2018-07-28 00:28:46 --> URI Class Initialized
INFO - 2018-07-28 00:28:46 --> Config Class Initialized
INFO - 2018-07-28 00:28:46 --> Loader Class Initialized
DEBUG - 2018-07-28 00:28:46 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 00:28:46 --> Helper loaded: url_helper
INFO - 2018-07-28 00:28:46 --> Helper loaded: form_helper
INFO - 2018-07-28 00:28:46 --> Helper loaded: date_helper
INFO - 2018-07-28 00:28:46 --> Helper loaded: util_helper
INFO - 2018-07-28 00:28:46 --> Helper loaded: text_helper
INFO - 2018-07-28 00:28:46 --> Helper loaded: string_helper
INFO - 2018-07-28 00:28:46 --> Database Driver Class Initialized
INFO - 2018-07-28 00:28:46 --> Router Class Initialized
INFO - 2018-07-28 00:28:46 --> Output Class Initialized
DEBUG - 2018-07-28 00:28:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 00:28:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 00:28:46 --> Security Class Initialized
INFO - 2018-07-28 00:28:46 --> Email Class Initialized
DEBUG - 2018-07-28 00:28:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 00:28:47 --> Controller Class Initialized
DEBUG - 2018-07-28 00:28:47 --> Home MX_Controller Initialized
DEBUG - 2018-07-28 00:28:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-07-28 00:28:47 --> Input Class Initialized
DEBUG - 2018-07-28 00:28:47 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 00:28:47 --> Login MX_Controller Initialized
INFO - 2018-07-28 00:28:47 --> Language Class Initialized
INFO - 2018-07-28 00:28:47 --> Language file loaded: language/english/data_lang.php
ERROR - 2018-07-28 00:28:47 --> 404 Page Not Found: /index
DEBUG - 2018-07-28 00:28:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 00:28:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-28 00:28:47 --> Config Class Initialized
INFO - 2018-07-28 00:28:47 --> Hooks Class Initialized
DEBUG - 2018-07-28 00:28:47 --> UTF-8 Support Enabled
INFO - 2018-07-28 00:28:47 --> Utf8 Class Initialized
INFO - 2018-07-28 00:28:47 --> URI Class Initialized
INFO - 2018-07-28 00:28:47 --> Router Class Initialized
INFO - 2018-07-28 00:28:47 --> Output Class Initialized
INFO - 2018-07-28 00:28:47 --> Security Class Initialized
DEBUG - 2018-07-28 00:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 00:28:47 --> Input Class Initialized
INFO - 2018-07-28 00:28:47 --> Language Class Initialized
ERROR - 2018-07-28 00:28:47 --> 404 Page Not Found: /index
INFO - 2018-07-28 00:28:48 --> Config Class Initialized
INFO - 2018-07-28 00:28:48 --> Hooks Class Initialized
DEBUG - 2018-07-28 00:28:48 --> UTF-8 Support Enabled
INFO - 2018-07-28 00:28:48 --> Utf8 Class Initialized
INFO - 2018-07-28 00:28:48 --> URI Class Initialized
DEBUG - 2018-07-28 00:28:48 --> No URI present. Default controller set.
INFO - 2018-07-28 00:28:48 --> Router Class Initialized
INFO - 2018-07-28 00:28:48 --> Output Class Initialized
INFO - 2018-07-28 00:28:48 --> Security Class Initialized
DEBUG - 2018-07-28 00:28:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 00:28:48 --> Input Class Initialized
INFO - 2018-07-28 00:28:48 --> Language Class Initialized
INFO - 2018-07-28 00:28:48 --> Language Class Initialized
INFO - 2018-07-28 00:28:48 --> Config Class Initialized
INFO - 2018-07-28 00:28:48 --> Loader Class Initialized
DEBUG - 2018-07-28 00:28:48 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 00:28:48 --> Helper loaded: url_helper
INFO - 2018-07-28 00:28:48 --> Helper loaded: form_helper
INFO - 2018-07-28 00:28:48 --> Helper loaded: date_helper
INFO - 2018-07-28 00:28:48 --> Helper loaded: util_helper
INFO - 2018-07-28 00:28:48 --> Helper loaded: text_helper
INFO - 2018-07-28 00:28:48 --> Helper loaded: string_helper
INFO - 2018-07-28 00:28:48 --> Database Driver Class Initialized
DEBUG - 2018-07-28 00:28:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 00:28:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 00:28:48 --> Email Class Initialized
INFO - 2018-07-28 00:28:49 --> Controller Class Initialized
DEBUG - 2018-07-28 00:28:49 --> Home MX_Controller Initialized
DEBUG - 2018-07-28 00:28:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-28 00:28:49 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 00:28:49 --> Login MX_Controller Initialized
INFO - 2018-07-28 00:28:49 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 00:28:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 00:28:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-28 00:28:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-28 00:28:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-28 00:28:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-28 00:28:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-28 00:28:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-28 00:28:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-28 00:28:49 --> Final output sent to browser
DEBUG - 2018-07-28 00:28:49 --> Total execution time: 0.4662
INFO - 2018-07-28 00:28:49 --> Config Class Initialized
INFO - 2018-07-28 00:28:49 --> Hooks Class Initialized
DEBUG - 2018-07-28 00:28:49 --> UTF-8 Support Enabled
INFO - 2018-07-28 00:28:49 --> Utf8 Class Initialized
INFO - 2018-07-28 00:28:49 --> Config Class Initialized
INFO - 2018-07-28 00:28:49 --> Hooks Class Initialized
INFO - 2018-07-28 00:28:49 --> URI Class Initialized
DEBUG - 2018-07-28 00:28:49 --> UTF-8 Support Enabled
INFO - 2018-07-28 00:28:49 --> Utf8 Class Initialized
INFO - 2018-07-28 00:28:49 --> URI Class Initialized
INFO - 2018-07-28 00:28:49 --> Router Class Initialized
INFO - 2018-07-28 00:28:49 --> Router Class Initialized
INFO - 2018-07-28 00:28:49 --> Output Class Initialized
INFO - 2018-07-28 00:28:49 --> Output Class Initialized
INFO - 2018-07-28 00:28:49 --> Security Class Initialized
INFO - 2018-07-28 00:28:49 --> Security Class Initialized
DEBUG - 2018-07-28 00:28:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 00:28:49 --> Input Class Initialized
DEBUG - 2018-07-28 00:28:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 00:28:49 --> Input Class Initialized
INFO - 2018-07-28 00:28:49 --> Language Class Initialized
INFO - 2018-07-28 00:28:49 --> Language Class Initialized
INFO - 2018-07-28 00:28:49 --> Language Class Initialized
ERROR - 2018-07-28 00:28:49 --> 404 Page Not Found: /index
INFO - 2018-07-28 00:28:49 --> Config Class Initialized
INFO - 2018-07-28 00:28:49 --> Loader Class Initialized
INFO - 2018-07-28 00:28:49 --> Config Class Initialized
INFO - 2018-07-28 00:28:49 --> Hooks Class Initialized
DEBUG - 2018-07-28 00:28:49 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 00:28:49 --> Helper loaded: url_helper
DEBUG - 2018-07-28 00:28:49 --> UTF-8 Support Enabled
INFO - 2018-07-28 00:28:49 --> Utf8 Class Initialized
INFO - 2018-07-28 00:28:49 --> Helper loaded: form_helper
INFO - 2018-07-28 00:28:49 --> URI Class Initialized
INFO - 2018-07-28 00:28:49 --> Helper loaded: date_helper
INFO - 2018-07-28 00:28:49 --> Helper loaded: util_helper
INFO - 2018-07-28 00:28:49 --> Router Class Initialized
INFO - 2018-07-28 00:28:49 --> Output Class Initialized
INFO - 2018-07-28 00:28:49 --> Helper loaded: text_helper
INFO - 2018-07-28 00:28:49 --> Security Class Initialized
INFO - 2018-07-28 00:28:49 --> Helper loaded: string_helper
DEBUG - 2018-07-28 00:28:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 00:28:49 --> Database Driver Class Initialized
INFO - 2018-07-28 00:28:49 --> Input Class Initialized
DEBUG - 2018-07-28 00:28:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 00:28:49 --> Language Class Initialized
INFO - 2018-07-28 00:28:49 --> Session: Class initialized using 'files' driver.
ERROR - 2018-07-28 00:28:49 --> 404 Page Not Found: /index
INFO - 2018-07-28 00:28:49 --> Email Class Initialized
INFO - 2018-07-28 00:28:49 --> Controller Class Initialized
INFO - 2018-07-28 00:28:49 --> Config Class Initialized
DEBUG - 2018-07-28 00:28:49 --> Home MX_Controller Initialized
INFO - 2018-07-28 00:28:49 --> Hooks Class Initialized
DEBUG - 2018-07-28 00:28:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-28 00:28:49 --> UTF-8 Support Enabled
INFO - 2018-07-28 00:28:49 --> Utf8 Class Initialized
DEBUG - 2018-07-28 00:28:49 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 00:28:49 --> Login MX_Controller Initialized
INFO - 2018-07-28 00:28:49 --> URI Class Initialized
INFO - 2018-07-28 00:28:49 --> Language file loaded: language/english/data_lang.php
INFO - 2018-07-28 00:28:49 --> Router Class Initialized
DEBUG - 2018-07-28 00:28:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-28 00:28:50 --> Output Class Initialized
DEBUG - 2018-07-28 00:28:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-28 00:28:50 --> Security Class Initialized
DEBUG - 2018-07-28 00:28:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 00:28:50 --> Input Class Initialized
INFO - 2018-07-28 00:28:50 --> Language Class Initialized
ERROR - 2018-07-28 00:28:50 --> 404 Page Not Found: /index
INFO - 2018-07-28 00:30:16 --> Config Class Initialized
INFO - 2018-07-28 00:30:16 --> Hooks Class Initialized
DEBUG - 2018-07-28 00:30:16 --> UTF-8 Support Enabled
INFO - 2018-07-28 00:30:16 --> Utf8 Class Initialized
INFO - 2018-07-28 00:30:16 --> URI Class Initialized
INFO - 2018-07-28 00:30:16 --> Router Class Initialized
INFO - 2018-07-28 00:30:16 --> Output Class Initialized
INFO - 2018-07-28 00:30:16 --> Security Class Initialized
DEBUG - 2018-07-28 00:30:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 00:30:16 --> Input Class Initialized
INFO - 2018-07-28 00:30:16 --> Language Class Initialized
INFO - 2018-07-28 00:30:16 --> Language Class Initialized
INFO - 2018-07-28 00:30:16 --> Config Class Initialized
INFO - 2018-07-28 00:30:16 --> Loader Class Initialized
DEBUG - 2018-07-28 00:30:16 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 00:30:16 --> Helper loaded: url_helper
INFO - 2018-07-28 00:30:16 --> Helper loaded: form_helper
INFO - 2018-07-28 00:30:16 --> Helper loaded: date_helper
INFO - 2018-07-28 00:30:16 --> Helper loaded: util_helper
INFO - 2018-07-28 00:30:16 --> Helper loaded: text_helper
INFO - 2018-07-28 00:30:16 --> Helper loaded: string_helper
INFO - 2018-07-28 00:30:16 --> Database Driver Class Initialized
DEBUG - 2018-07-28 00:30:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 00:30:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 00:30:16 --> Email Class Initialized
INFO - 2018-07-28 00:30:16 --> Controller Class Initialized
DEBUG - 2018-07-28 00:30:16 --> Login MX_Controller Initialized
INFO - 2018-07-28 00:30:16 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 00:30:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 00:30:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-28 00:30:16 --> 4 Loggedout
INFO - 2018-07-28 00:30:16 --> Config Class Initialized
INFO - 2018-07-28 00:30:16 --> Hooks Class Initialized
DEBUG - 2018-07-28 00:30:16 --> UTF-8 Support Enabled
INFO - 2018-07-28 00:30:17 --> Utf8 Class Initialized
INFO - 2018-07-28 00:30:17 --> URI Class Initialized
INFO - 2018-07-28 00:30:17 --> Router Class Initialized
INFO - 2018-07-28 00:30:17 --> Output Class Initialized
INFO - 2018-07-28 00:30:17 --> Security Class Initialized
DEBUG - 2018-07-28 00:30:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 00:30:17 --> Input Class Initialized
INFO - 2018-07-28 00:30:17 --> Language Class Initialized
INFO - 2018-07-28 00:30:17 --> Language Class Initialized
INFO - 2018-07-28 00:30:17 --> Config Class Initialized
INFO - 2018-07-28 00:30:17 --> Loader Class Initialized
DEBUG - 2018-07-28 00:30:17 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 00:30:17 --> Helper loaded: url_helper
INFO - 2018-07-28 00:30:17 --> Helper loaded: form_helper
INFO - 2018-07-28 00:30:17 --> Helper loaded: date_helper
INFO - 2018-07-28 00:30:17 --> Helper loaded: util_helper
INFO - 2018-07-28 00:30:17 --> Helper loaded: text_helper
INFO - 2018-07-28 00:30:17 --> Helper loaded: string_helper
INFO - 2018-07-28 00:30:17 --> Database Driver Class Initialized
DEBUG - 2018-07-28 00:30:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 00:30:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 00:30:17 --> Email Class Initialized
INFO - 2018-07-28 00:30:17 --> Controller Class Initialized
DEBUG - 2018-07-28 00:30:17 --> Home MX_Controller Initialized
DEBUG - 2018-07-28 00:30:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-28 00:30:17 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 00:30:17 --> Login MX_Controller Initialized
INFO - 2018-07-28 00:30:17 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 00:30:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 00:30:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-28 00:30:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-07-28 00:30:20 --> Config Class Initialized
INFO - 2018-07-28 00:30:20 --> Hooks Class Initialized
DEBUG - 2018-07-28 00:30:20 --> UTF-8 Support Enabled
INFO - 2018-07-28 00:30:20 --> Utf8 Class Initialized
INFO - 2018-07-28 00:30:20 --> URI Class Initialized
INFO - 2018-07-28 00:30:20 --> Router Class Initialized
INFO - 2018-07-28 00:30:20 --> Output Class Initialized
INFO - 2018-07-28 00:30:20 --> Security Class Initialized
DEBUG - 2018-07-28 00:30:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 00:30:20 --> Input Class Initialized
INFO - 2018-07-28 00:30:20 --> Language Class Initialized
INFO - 2018-07-28 00:30:20 --> Language Class Initialized
INFO - 2018-07-28 00:30:20 --> Config Class Initialized
INFO - 2018-07-28 00:30:20 --> Loader Class Initialized
DEBUG - 2018-07-28 00:30:20 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 00:30:20 --> Helper loaded: url_helper
INFO - 2018-07-28 00:30:20 --> Helper loaded: form_helper
INFO - 2018-07-28 00:30:20 --> Helper loaded: date_helper
INFO - 2018-07-28 00:30:20 --> Helper loaded: util_helper
INFO - 2018-07-28 00:30:20 --> Helper loaded: text_helper
INFO - 2018-07-28 00:30:20 --> Helper loaded: string_helper
INFO - 2018-07-28 00:30:20 --> Database Driver Class Initialized
DEBUG - 2018-07-28 00:30:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 00:30:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 00:30:20 --> Email Class Initialized
INFO - 2018-07-28 00:30:20 --> Controller Class Initialized
DEBUG - 2018-07-28 00:30:20 --> Login MX_Controller Initialized
INFO - 2018-07-28 00:30:20 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 00:30:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 00:30:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-28 00:30:20 --> Email starts for colin fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-07-28 00:30:20 --> User session created for 4
INFO - 2018-07-28 00:30:20 --> Login status colin - success
INFO - 2018-07-28 00:30:20 --> Final output sent to browser
DEBUG - 2018-07-28 00:30:20 --> Total execution time: 0.4002
INFO - 2018-07-28 00:30:20 --> Config Class Initialized
INFO - 2018-07-28 00:30:20 --> Hooks Class Initialized
DEBUG - 2018-07-28 00:30:20 --> UTF-8 Support Enabled
INFO - 2018-07-28 00:30:20 --> Utf8 Class Initialized
INFO - 2018-07-28 00:30:21 --> URI Class Initialized
INFO - 2018-07-28 00:30:21 --> Router Class Initialized
INFO - 2018-07-28 00:30:21 --> Output Class Initialized
INFO - 2018-07-28 00:30:21 --> Security Class Initialized
DEBUG - 2018-07-28 00:30:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 00:30:21 --> Input Class Initialized
INFO - 2018-07-28 00:30:21 --> Language Class Initialized
INFO - 2018-07-28 00:30:21 --> Language Class Initialized
INFO - 2018-07-28 00:30:21 --> Config Class Initialized
INFO - 2018-07-28 00:30:21 --> Loader Class Initialized
DEBUG - 2018-07-28 00:30:21 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 00:30:21 --> Helper loaded: url_helper
INFO - 2018-07-28 00:30:21 --> Helper loaded: form_helper
INFO - 2018-07-28 00:30:21 --> Helper loaded: date_helper
INFO - 2018-07-28 00:30:21 --> Helper loaded: util_helper
INFO - 2018-07-28 00:30:21 --> Helper loaded: text_helper
INFO - 2018-07-28 00:30:21 --> Helper loaded: string_helper
INFO - 2018-07-28 00:30:21 --> Database Driver Class Initialized
DEBUG - 2018-07-28 00:30:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 00:30:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 00:30:21 --> Email Class Initialized
INFO - 2018-07-28 00:30:21 --> Controller Class Initialized
DEBUG - 2018-07-28 00:30:21 --> Home MX_Controller Initialized
DEBUG - 2018-07-28 00:30:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-28 00:30:21 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 00:30:21 --> Login MX_Controller Initialized
INFO - 2018-07-28 00:30:21 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 00:30:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 00:30:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-28 00:30:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-28 00:30:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-28 00:30:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-28 00:30:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-28 00:30:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-28 00:30:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-28 00:30:21 --> Final output sent to browser
DEBUG - 2018-07-28 00:30:21 --> Total execution time: 0.4236
INFO - 2018-07-28 00:30:21 --> Config Class Initialized
INFO - 2018-07-28 00:30:21 --> Hooks Class Initialized
DEBUG - 2018-07-28 00:30:21 --> UTF-8 Support Enabled
INFO - 2018-07-28 00:30:21 --> Utf8 Class Initialized
INFO - 2018-07-28 00:30:21 --> Config Class Initialized
INFO - 2018-07-28 00:30:21 --> Hooks Class Initialized
INFO - 2018-07-28 00:30:21 --> URI Class Initialized
DEBUG - 2018-07-28 00:30:21 --> UTF-8 Support Enabled
INFO - 2018-07-28 00:30:21 --> Utf8 Class Initialized
INFO - 2018-07-28 00:30:21 --> URI Class Initialized
INFO - 2018-07-28 00:30:21 --> Router Class Initialized
INFO - 2018-07-28 00:30:21 --> Output Class Initialized
INFO - 2018-07-28 00:30:21 --> Router Class Initialized
INFO - 2018-07-28 00:30:22 --> Output Class Initialized
INFO - 2018-07-28 00:30:22 --> Security Class Initialized
DEBUG - 2018-07-28 00:30:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 00:30:22 --> Security Class Initialized
DEBUG - 2018-07-28 00:30:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 00:30:22 --> Input Class Initialized
INFO - 2018-07-28 00:30:22 --> Language Class Initialized
INFO - 2018-07-28 00:30:22 --> Input Class Initialized
INFO - 2018-07-28 00:30:22 --> Language Class Initialized
INFO - 2018-07-28 00:30:22 --> Language Class Initialized
INFO - 2018-07-28 00:30:22 --> Config Class Initialized
INFO - 2018-07-28 00:30:22 --> Loader Class Initialized
ERROR - 2018-07-28 00:30:22 --> 404 Page Not Found: /index
DEBUG - 2018-07-28 00:30:22 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 00:30:22 --> Helper loaded: url_helper
INFO - 2018-07-28 00:30:22 --> Helper loaded: form_helper
INFO - 2018-07-28 00:30:22 --> Helper loaded: date_helper
INFO - 2018-07-28 00:30:22 --> Helper loaded: util_helper
INFO - 2018-07-28 00:30:22 --> Helper loaded: text_helper
INFO - 2018-07-28 00:30:22 --> Helper loaded: string_helper
INFO - 2018-07-28 00:30:22 --> Database Driver Class Initialized
INFO - 2018-07-28 00:30:22 --> Config Class Initialized
INFO - 2018-07-28 00:30:22 --> Hooks Class Initialized
DEBUG - 2018-07-28 00:30:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 00:30:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-07-28 00:30:22 --> UTF-8 Support Enabled
INFO - 2018-07-28 00:30:22 --> Utf8 Class Initialized
INFO - 2018-07-28 00:30:22 --> Email Class Initialized
INFO - 2018-07-28 00:30:22 --> Controller Class Initialized
INFO - 2018-07-28 00:30:22 --> URI Class Initialized
DEBUG - 2018-07-28 00:30:22 --> Home MX_Controller Initialized
DEBUG - 2018-07-28 00:30:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-07-28 00:30:22 --> Router Class Initialized
DEBUG - 2018-07-28 00:30:22 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 00:30:22 --> Login MX_Controller Initialized
INFO - 2018-07-28 00:30:22 --> Output Class Initialized
INFO - 2018-07-28 00:30:22 --> Language file loaded: language/english/data_lang.php
INFO - 2018-07-28 00:30:22 --> Security Class Initialized
DEBUG - 2018-07-28 00:30:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 00:30:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 00:30:22 --> Input Class Initialized
DEBUG - 2018-07-28 00:30:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-28 00:30:22 --> Language Class Initialized
ERROR - 2018-07-28 00:30:22 --> 404 Page Not Found: /index
INFO - 2018-07-28 00:30:22 --> Config Class Initialized
INFO - 2018-07-28 00:30:22 --> Hooks Class Initialized
DEBUG - 2018-07-28 00:30:22 --> UTF-8 Support Enabled
INFO - 2018-07-28 00:30:22 --> Utf8 Class Initialized
INFO - 2018-07-28 00:30:22 --> URI Class Initialized
INFO - 2018-07-28 00:30:22 --> Router Class Initialized
INFO - 2018-07-28 00:30:22 --> Output Class Initialized
INFO - 2018-07-28 00:30:22 --> Security Class Initialized
DEBUG - 2018-07-28 00:30:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 00:30:22 --> Input Class Initialized
INFO - 2018-07-28 00:30:22 --> Language Class Initialized
ERROR - 2018-07-28 00:30:22 --> 404 Page Not Found: /index
INFO - 2018-07-28 00:30:29 --> Config Class Initialized
INFO - 2018-07-28 00:30:30 --> Hooks Class Initialized
DEBUG - 2018-07-28 00:30:30 --> UTF-8 Support Enabled
INFO - 2018-07-28 00:30:30 --> Utf8 Class Initialized
INFO - 2018-07-28 00:30:30 --> URI Class Initialized
DEBUG - 2018-07-28 00:30:30 --> No URI present. Default controller set.
INFO - 2018-07-28 00:30:30 --> Router Class Initialized
INFO - 2018-07-28 00:30:30 --> Output Class Initialized
INFO - 2018-07-28 00:30:30 --> Security Class Initialized
DEBUG - 2018-07-28 00:30:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 00:30:30 --> Input Class Initialized
INFO - 2018-07-28 00:30:30 --> Language Class Initialized
INFO - 2018-07-28 00:30:30 --> Language Class Initialized
INFO - 2018-07-28 00:30:30 --> Config Class Initialized
INFO - 2018-07-28 00:30:30 --> Loader Class Initialized
DEBUG - 2018-07-28 00:30:30 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 00:30:30 --> Helper loaded: url_helper
INFO - 2018-07-28 00:30:30 --> Helper loaded: form_helper
INFO - 2018-07-28 00:30:30 --> Helper loaded: date_helper
INFO - 2018-07-28 00:30:30 --> Helper loaded: util_helper
INFO - 2018-07-28 00:30:30 --> Helper loaded: text_helper
INFO - 2018-07-28 00:30:30 --> Helper loaded: string_helper
INFO - 2018-07-28 00:30:30 --> Database Driver Class Initialized
DEBUG - 2018-07-28 00:30:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 00:30:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 00:30:30 --> Email Class Initialized
INFO - 2018-07-28 00:30:30 --> Controller Class Initialized
DEBUG - 2018-07-28 00:30:30 --> Home MX_Controller Initialized
DEBUG - 2018-07-28 00:30:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-28 00:30:30 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 00:30:30 --> Login MX_Controller Initialized
INFO - 2018-07-28 00:30:30 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 00:30:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 00:30:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-28 00:30:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-28 00:30:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-28 00:30:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-28 00:30:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-28 00:30:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-28 00:30:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-28 00:30:30 --> Final output sent to browser
DEBUG - 2018-07-28 00:30:30 --> Total execution time: 0.4939
INFO - 2018-07-28 00:30:30 --> Config Class Initialized
INFO - 2018-07-28 00:30:30 --> Hooks Class Initialized
DEBUG - 2018-07-28 00:30:30 --> UTF-8 Support Enabled
INFO - 2018-07-28 00:30:30 --> Utf8 Class Initialized
INFO - 2018-07-28 00:30:30 --> Config Class Initialized
INFO - 2018-07-28 00:30:30 --> URI Class Initialized
INFO - 2018-07-28 00:30:31 --> Router Class Initialized
INFO - 2018-07-28 00:30:31 --> Output Class Initialized
INFO - 2018-07-28 00:30:31 --> Security Class Initialized
DEBUG - 2018-07-28 00:30:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 00:30:31 --> Input Class Initialized
INFO - 2018-07-28 00:30:31 --> Language Class Initialized
INFO - 2018-07-28 00:30:31 --> Hooks Class Initialized
ERROR - 2018-07-28 00:30:31 --> 404 Page Not Found: /index
DEBUG - 2018-07-28 00:30:31 --> UTF-8 Support Enabled
INFO - 2018-07-28 00:30:31 --> Config Class Initialized
INFO - 2018-07-28 00:30:31 --> Hooks Class Initialized
INFO - 2018-07-28 00:30:31 --> Utf8 Class Initialized
INFO - 2018-07-28 00:30:31 --> URI Class Initialized
DEBUG - 2018-07-28 00:30:31 --> UTF-8 Support Enabled
INFO - 2018-07-28 00:30:31 --> Utf8 Class Initialized
INFO - 2018-07-28 00:30:31 --> Router Class Initialized
INFO - 2018-07-28 00:30:31 --> URI Class Initialized
INFO - 2018-07-28 00:30:31 --> Output Class Initialized
INFO - 2018-07-28 00:30:31 --> Security Class Initialized
INFO - 2018-07-28 00:30:31 --> Router Class Initialized
DEBUG - 2018-07-28 00:30:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 00:30:31 --> Output Class Initialized
INFO - 2018-07-28 00:30:31 --> Input Class Initialized
INFO - 2018-07-28 00:30:31 --> Security Class Initialized
INFO - 2018-07-28 00:30:31 --> Language Class Initialized
DEBUG - 2018-07-28 00:30:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 00:30:31 --> Language Class Initialized
INFO - 2018-07-28 00:30:31 --> Input Class Initialized
INFO - 2018-07-28 00:30:31 --> Config Class Initialized
INFO - 2018-07-28 00:30:31 --> Language Class Initialized
INFO - 2018-07-28 00:30:31 --> Loader Class Initialized
ERROR - 2018-07-28 00:30:31 --> 404 Page Not Found: /index
DEBUG - 2018-07-28 00:30:31 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 00:30:31 --> Helper loaded: url_helper
INFO - 2018-07-28 00:30:31 --> Config Class Initialized
INFO - 2018-07-28 00:30:31 --> Hooks Class Initialized
INFO - 2018-07-28 00:30:31 --> Helper loaded: form_helper
INFO - 2018-07-28 00:30:31 --> Helper loaded: date_helper
DEBUG - 2018-07-28 00:30:31 --> UTF-8 Support Enabled
INFO - 2018-07-28 00:30:31 --> Utf8 Class Initialized
INFO - 2018-07-28 00:30:31 --> Helper loaded: util_helper
INFO - 2018-07-28 00:30:31 --> URI Class Initialized
INFO - 2018-07-28 00:30:31 --> Helper loaded: text_helper
INFO - 2018-07-28 00:30:31 --> Helper loaded: string_helper
INFO - 2018-07-28 00:30:31 --> Router Class Initialized
INFO - 2018-07-28 00:30:31 --> Output Class Initialized
INFO - 2018-07-28 00:30:31 --> Database Driver Class Initialized
INFO - 2018-07-28 00:30:31 --> Security Class Initialized
DEBUG - 2018-07-28 00:30:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 00:30:31 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-07-28 00:30:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 00:30:31 --> Input Class Initialized
INFO - 2018-07-28 00:30:31 --> Email Class Initialized
INFO - 2018-07-28 00:30:31 --> Controller Class Initialized
INFO - 2018-07-28 00:30:31 --> Language Class Initialized
DEBUG - 2018-07-28 00:30:31 --> Home MX_Controller Initialized
ERROR - 2018-07-28 00:30:31 --> 404 Page Not Found: /index
DEBUG - 2018-07-28 00:30:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-28 00:30:31 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 00:30:31 --> Login MX_Controller Initialized
INFO - 2018-07-28 00:30:31 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 00:30:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 00:30:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-28 00:30:35 --> Config Class Initialized
INFO - 2018-07-28 00:30:35 --> Hooks Class Initialized
DEBUG - 2018-07-28 00:30:35 --> UTF-8 Support Enabled
INFO - 2018-07-28 00:30:35 --> Utf8 Class Initialized
INFO - 2018-07-28 00:30:35 --> URI Class Initialized
INFO - 2018-07-28 00:30:35 --> Router Class Initialized
INFO - 2018-07-28 00:30:35 --> Output Class Initialized
INFO - 2018-07-28 00:30:35 --> Security Class Initialized
DEBUG - 2018-07-28 00:30:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 00:30:35 --> Input Class Initialized
INFO - 2018-07-28 00:30:35 --> Language Class Initialized
INFO - 2018-07-28 00:30:35 --> Language Class Initialized
INFO - 2018-07-28 00:30:35 --> Config Class Initialized
INFO - 2018-07-28 00:30:35 --> Loader Class Initialized
DEBUG - 2018-07-28 00:30:35 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 00:30:35 --> Helper loaded: url_helper
INFO - 2018-07-28 00:30:35 --> Helper loaded: form_helper
INFO - 2018-07-28 00:30:35 --> Helper loaded: date_helper
INFO - 2018-07-28 00:30:35 --> Helper loaded: util_helper
INFO - 2018-07-28 00:30:35 --> Helper loaded: text_helper
INFO - 2018-07-28 00:30:35 --> Helper loaded: string_helper
INFO - 2018-07-28 00:30:35 --> Database Driver Class Initialized
DEBUG - 2018-07-28 00:30:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 00:30:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 00:30:35 --> Email Class Initialized
INFO - 2018-07-28 00:30:35 --> Controller Class Initialized
DEBUG - 2018-07-28 00:30:35 --> Login MX_Controller Initialized
INFO - 2018-07-28 00:30:35 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 00:30:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 00:30:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-28 00:30:35 --> 4 Loggedout
INFO - 2018-07-28 00:30:35 --> Config Class Initialized
INFO - 2018-07-28 00:30:35 --> Hooks Class Initialized
DEBUG - 2018-07-28 00:30:35 --> UTF-8 Support Enabled
INFO - 2018-07-28 00:30:35 --> Utf8 Class Initialized
INFO - 2018-07-28 00:30:35 --> URI Class Initialized
INFO - 2018-07-28 00:30:35 --> Router Class Initialized
INFO - 2018-07-28 00:30:35 --> Output Class Initialized
INFO - 2018-07-28 00:30:35 --> Security Class Initialized
DEBUG - 2018-07-28 00:30:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 00:30:35 --> Input Class Initialized
INFO - 2018-07-28 00:30:35 --> Language Class Initialized
INFO - 2018-07-28 00:30:35 --> Language Class Initialized
INFO - 2018-07-28 00:30:35 --> Config Class Initialized
INFO - 2018-07-28 00:30:35 --> Loader Class Initialized
DEBUG - 2018-07-28 00:30:35 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 00:30:35 --> Helper loaded: url_helper
INFO - 2018-07-28 00:30:35 --> Helper loaded: form_helper
INFO - 2018-07-28 00:30:35 --> Helper loaded: date_helper
INFO - 2018-07-28 00:30:35 --> Helper loaded: util_helper
INFO - 2018-07-28 00:30:35 --> Helper loaded: text_helper
INFO - 2018-07-28 00:30:35 --> Helper loaded: string_helper
INFO - 2018-07-28 00:30:35 --> Database Driver Class Initialized
DEBUG - 2018-07-28 00:30:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 00:30:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 00:30:35 --> Email Class Initialized
INFO - 2018-07-28 00:30:35 --> Controller Class Initialized
DEBUG - 2018-07-28 00:30:35 --> Home MX_Controller Initialized
DEBUG - 2018-07-28 00:30:35 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-28 00:30:36 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 00:30:36 --> Login MX_Controller Initialized
INFO - 2018-07-28 00:30:36 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 00:30:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 00:30:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-28 00:30:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-07-28 00:30:39 --> Config Class Initialized
INFO - 2018-07-28 00:30:39 --> Hooks Class Initialized
DEBUG - 2018-07-28 00:30:39 --> UTF-8 Support Enabled
INFO - 2018-07-28 00:30:39 --> Utf8 Class Initialized
INFO - 2018-07-28 00:30:39 --> URI Class Initialized
INFO - 2018-07-28 00:30:39 --> Router Class Initialized
INFO - 2018-07-28 00:30:39 --> Output Class Initialized
INFO - 2018-07-28 00:30:39 --> Security Class Initialized
DEBUG - 2018-07-28 00:30:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 00:30:39 --> Input Class Initialized
INFO - 2018-07-28 00:30:39 --> Language Class Initialized
INFO - 2018-07-28 00:30:39 --> Language Class Initialized
INFO - 2018-07-28 00:30:39 --> Config Class Initialized
INFO - 2018-07-28 00:30:39 --> Loader Class Initialized
DEBUG - 2018-07-28 00:30:39 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 00:30:39 --> Helper loaded: url_helper
INFO - 2018-07-28 00:30:39 --> Helper loaded: form_helper
INFO - 2018-07-28 00:30:39 --> Helper loaded: date_helper
INFO - 2018-07-28 00:30:39 --> Helper loaded: util_helper
INFO - 2018-07-28 00:30:39 --> Helper loaded: text_helper
INFO - 2018-07-28 00:30:40 --> Helper loaded: string_helper
INFO - 2018-07-28 00:30:40 --> Database Driver Class Initialized
DEBUG - 2018-07-28 00:30:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 00:30:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 00:30:40 --> Email Class Initialized
INFO - 2018-07-28 00:30:40 --> Controller Class Initialized
DEBUG - 2018-07-28 00:30:40 --> Login MX_Controller Initialized
INFO - 2018-07-28 00:30:40 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 00:30:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 00:30:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-28 00:30:40 --> Email starts for colin fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-07-28 00:30:40 --> User session created for 4
INFO - 2018-07-28 00:30:40 --> Login status colin - success
INFO - 2018-07-28 00:30:40 --> Final output sent to browser
DEBUG - 2018-07-28 00:30:40 --> Total execution time: 0.3944
INFO - 2018-07-28 00:30:40 --> Config Class Initialized
INFO - 2018-07-28 00:30:40 --> Hooks Class Initialized
DEBUG - 2018-07-28 00:30:40 --> UTF-8 Support Enabled
INFO - 2018-07-28 00:30:40 --> Utf8 Class Initialized
INFO - 2018-07-28 00:30:40 --> URI Class Initialized
INFO - 2018-07-28 00:30:40 --> Router Class Initialized
INFO - 2018-07-28 00:30:40 --> Output Class Initialized
INFO - 2018-07-28 00:30:40 --> Security Class Initialized
DEBUG - 2018-07-28 00:30:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 00:30:40 --> Input Class Initialized
INFO - 2018-07-28 00:30:40 --> Language Class Initialized
INFO - 2018-07-28 00:30:40 --> Language Class Initialized
INFO - 2018-07-28 00:30:40 --> Config Class Initialized
INFO - 2018-07-28 00:30:40 --> Loader Class Initialized
DEBUG - 2018-07-28 00:30:40 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 00:30:40 --> Helper loaded: url_helper
INFO - 2018-07-28 00:30:40 --> Helper loaded: form_helper
INFO - 2018-07-28 00:30:40 --> Helper loaded: date_helper
INFO - 2018-07-28 00:30:40 --> Helper loaded: util_helper
INFO - 2018-07-28 00:30:40 --> Helper loaded: text_helper
INFO - 2018-07-28 00:30:40 --> Helper loaded: string_helper
INFO - 2018-07-28 00:30:40 --> Database Driver Class Initialized
DEBUG - 2018-07-28 00:30:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 00:30:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 00:30:40 --> Email Class Initialized
INFO - 2018-07-28 00:30:40 --> Controller Class Initialized
DEBUG - 2018-07-28 00:30:40 --> Home MX_Controller Initialized
DEBUG - 2018-07-28 00:30:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-28 00:30:40 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 00:30:40 --> Login MX_Controller Initialized
INFO - 2018-07-28 00:30:40 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 00:30:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 00:30:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-28 00:30:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-28 00:30:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-28 00:30:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-28 00:30:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-28 00:30:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-28 00:30:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-28 00:30:40 --> Final output sent to browser
DEBUG - 2018-07-28 00:30:40 --> Total execution time: 0.5345
INFO - 2018-07-28 00:30:41 --> Config Class Initialized
INFO - 2018-07-28 00:30:41 --> Hooks Class Initialized
DEBUG - 2018-07-28 00:30:41 --> UTF-8 Support Enabled
INFO - 2018-07-28 00:30:41 --> Config Class Initialized
INFO - 2018-07-28 00:30:41 --> Hooks Class Initialized
INFO - 2018-07-28 00:30:41 --> Utf8 Class Initialized
INFO - 2018-07-28 00:30:41 --> URI Class Initialized
DEBUG - 2018-07-28 00:30:41 --> UTF-8 Support Enabled
INFO - 2018-07-28 00:30:41 --> Utf8 Class Initialized
INFO - 2018-07-28 00:30:41 --> Router Class Initialized
INFO - 2018-07-28 00:30:41 --> URI Class Initialized
INFO - 2018-07-28 00:30:41 --> Router Class Initialized
INFO - 2018-07-28 00:30:41 --> Output Class Initialized
INFO - 2018-07-28 00:30:41 --> Output Class Initialized
INFO - 2018-07-28 00:30:41 --> Security Class Initialized
DEBUG - 2018-07-28 00:30:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 00:30:41 --> Security Class Initialized
INFO - 2018-07-28 00:30:41 --> Input Class Initialized
DEBUG - 2018-07-28 00:30:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 00:30:41 --> Language Class Initialized
INFO - 2018-07-28 00:30:41 --> Input Class Initialized
INFO - 2018-07-28 00:30:41 --> Language Class Initialized
INFO - 2018-07-28 00:30:41 --> Language Class Initialized
INFO - 2018-07-28 00:30:41 --> Config Class Initialized
ERROR - 2018-07-28 00:30:41 --> 404 Page Not Found: /index
INFO - 2018-07-28 00:30:41 --> Loader Class Initialized
DEBUG - 2018-07-28 00:30:41 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 00:30:41 --> Config Class Initialized
INFO - 2018-07-28 00:30:41 --> Hooks Class Initialized
INFO - 2018-07-28 00:30:41 --> Helper loaded: url_helper
INFO - 2018-07-28 00:30:41 --> Helper loaded: form_helper
DEBUG - 2018-07-28 00:30:41 --> UTF-8 Support Enabled
INFO - 2018-07-28 00:30:41 --> Utf8 Class Initialized
INFO - 2018-07-28 00:30:41 --> Helper loaded: date_helper
INFO - 2018-07-28 00:30:41 --> URI Class Initialized
INFO - 2018-07-28 00:30:41 --> Helper loaded: util_helper
INFO - 2018-07-28 00:30:41 --> Helper loaded: text_helper
INFO - 2018-07-28 00:30:41 --> Router Class Initialized
INFO - 2018-07-28 00:30:41 --> Output Class Initialized
INFO - 2018-07-28 00:30:41 --> Helper loaded: string_helper
INFO - 2018-07-28 00:30:41 --> Security Class Initialized
INFO - 2018-07-28 00:30:41 --> Database Driver Class Initialized
DEBUG - 2018-07-28 00:30:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-07-28 00:30:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 00:30:41 --> Input Class Initialized
INFO - 2018-07-28 00:30:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 00:30:41 --> Language Class Initialized
INFO - 2018-07-28 00:30:41 --> Email Class Initialized
INFO - 2018-07-28 00:30:41 --> Controller Class Initialized
ERROR - 2018-07-28 00:30:41 --> 404 Page Not Found: /index
DEBUG - 2018-07-28 00:30:41 --> Home MX_Controller Initialized
INFO - 2018-07-28 00:30:41 --> Config Class Initialized
INFO - 2018-07-28 00:30:41 --> Hooks Class Initialized
DEBUG - 2018-07-28 00:30:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-28 00:30:41 --> UTF-8 Support Enabled
DEBUG - 2018-07-28 00:30:41 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 00:30:41 --> Login MX_Controller Initialized
INFO - 2018-07-28 00:30:41 --> Utf8 Class Initialized
INFO - 2018-07-28 00:30:41 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 00:30:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-28 00:30:41 --> URI Class Initialized
DEBUG - 2018-07-28 00:30:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-28 00:30:41 --> Router Class Initialized
INFO - 2018-07-28 00:30:41 --> Output Class Initialized
INFO - 2018-07-28 00:30:41 --> Security Class Initialized
DEBUG - 2018-07-28 00:30:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 00:30:41 --> Input Class Initialized
INFO - 2018-07-28 00:30:41 --> Language Class Initialized
ERROR - 2018-07-28 00:30:41 --> 404 Page Not Found: /index
INFO - 2018-07-28 00:30:45 --> Config Class Initialized
INFO - 2018-07-28 00:30:45 --> Hooks Class Initialized
DEBUG - 2018-07-28 00:30:45 --> UTF-8 Support Enabled
INFO - 2018-07-28 00:30:45 --> Utf8 Class Initialized
INFO - 2018-07-28 00:30:45 --> URI Class Initialized
INFO - 2018-07-28 00:30:45 --> Router Class Initialized
INFO - 2018-07-28 00:30:45 --> Output Class Initialized
INFO - 2018-07-28 00:30:45 --> Security Class Initialized
DEBUG - 2018-07-28 00:30:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 00:30:46 --> Input Class Initialized
INFO - 2018-07-28 00:30:46 --> Language Class Initialized
INFO - 2018-07-28 00:30:46 --> Language Class Initialized
INFO - 2018-07-28 00:30:46 --> Config Class Initialized
INFO - 2018-07-28 00:30:46 --> Loader Class Initialized
DEBUG - 2018-07-28 00:30:46 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 00:30:46 --> Helper loaded: url_helper
INFO - 2018-07-28 00:30:46 --> Helper loaded: form_helper
INFO - 2018-07-28 00:30:46 --> Helper loaded: date_helper
INFO - 2018-07-28 00:30:46 --> Helper loaded: util_helper
INFO - 2018-07-28 00:30:46 --> Helper loaded: text_helper
INFO - 2018-07-28 00:30:46 --> Helper loaded: string_helper
INFO - 2018-07-28 00:30:46 --> Database Driver Class Initialized
DEBUG - 2018-07-28 00:30:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 00:30:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 00:30:46 --> Email Class Initialized
INFO - 2018-07-28 00:30:46 --> Controller Class Initialized
DEBUG - 2018-07-28 00:30:46 --> Login MX_Controller Initialized
INFO - 2018-07-28 00:30:46 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 00:30:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 00:30:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-28 00:30:46 --> 4 Loggedout
INFO - 2018-07-28 00:30:46 --> Config Class Initialized
INFO - 2018-07-28 00:30:46 --> Hooks Class Initialized
DEBUG - 2018-07-28 00:30:46 --> UTF-8 Support Enabled
INFO - 2018-07-28 00:30:46 --> Utf8 Class Initialized
INFO - 2018-07-28 00:30:46 --> URI Class Initialized
INFO - 2018-07-28 00:30:46 --> Router Class Initialized
INFO - 2018-07-28 00:30:46 --> Output Class Initialized
INFO - 2018-07-28 00:30:46 --> Security Class Initialized
DEBUG - 2018-07-28 00:30:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 00:30:46 --> Input Class Initialized
INFO - 2018-07-28 00:30:46 --> Language Class Initialized
INFO - 2018-07-28 00:30:46 --> Language Class Initialized
INFO - 2018-07-28 00:30:46 --> Config Class Initialized
INFO - 2018-07-28 00:30:46 --> Loader Class Initialized
DEBUG - 2018-07-28 00:30:46 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 00:30:46 --> Helper loaded: url_helper
INFO - 2018-07-28 00:30:46 --> Helper loaded: form_helper
INFO - 2018-07-28 00:30:46 --> Helper loaded: date_helper
INFO - 2018-07-28 00:30:46 --> Helper loaded: util_helper
INFO - 2018-07-28 00:30:46 --> Helper loaded: text_helper
INFO - 2018-07-28 00:30:46 --> Helper loaded: string_helper
INFO - 2018-07-28 00:30:46 --> Database Driver Class Initialized
DEBUG - 2018-07-28 00:30:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 00:30:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 00:30:46 --> Email Class Initialized
INFO - 2018-07-28 00:30:46 --> Controller Class Initialized
DEBUG - 2018-07-28 00:30:46 --> Home MX_Controller Initialized
DEBUG - 2018-07-28 00:30:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-28 00:30:46 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 00:30:46 --> Login MX_Controller Initialized
INFO - 2018-07-28 00:30:46 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 00:30:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 00:30:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-28 00:30:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-07-28 00:30:48 --> Config Class Initialized
INFO - 2018-07-28 00:30:48 --> Hooks Class Initialized
DEBUG - 2018-07-28 00:30:48 --> UTF-8 Support Enabled
INFO - 2018-07-28 00:30:48 --> Utf8 Class Initialized
INFO - 2018-07-28 00:30:48 --> URI Class Initialized
INFO - 2018-07-28 00:30:48 --> Config Class Initialized
INFO - 2018-07-28 00:30:48 --> Hooks Class Initialized
INFO - 2018-07-28 00:30:48 --> Router Class Initialized
INFO - 2018-07-28 00:30:48 --> Output Class Initialized
DEBUG - 2018-07-28 00:30:48 --> UTF-8 Support Enabled
INFO - 2018-07-28 00:30:48 --> Utf8 Class Initialized
INFO - 2018-07-28 00:30:48 --> Security Class Initialized
INFO - 2018-07-28 00:30:48 --> URI Class Initialized
DEBUG - 2018-07-28 00:30:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 00:30:48 --> Input Class Initialized
INFO - 2018-07-28 00:30:48 --> Router Class Initialized
INFO - 2018-07-28 00:30:48 --> Output Class Initialized
INFO - 2018-07-28 00:30:48 --> Language Class Initialized
INFO - 2018-07-28 00:30:48 --> Security Class Initialized
INFO - 2018-07-28 00:30:48 --> Language Class Initialized
INFO - 2018-07-28 00:30:48 --> Config Class Initialized
DEBUG - 2018-07-28 00:30:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 00:30:48 --> Input Class Initialized
INFO - 2018-07-28 00:30:48 --> Loader Class Initialized
INFO - 2018-07-28 00:30:48 --> Language Class Initialized
DEBUG - 2018-07-28 00:30:48 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
ERROR - 2018-07-28 00:30:48 --> 404 Page Not Found: /index
INFO - 2018-07-28 00:30:48 --> Helper loaded: url_helper
INFO - 2018-07-28 00:30:48 --> Config Class Initialized
INFO - 2018-07-28 00:30:48 --> Hooks Class Initialized
INFO - 2018-07-28 00:30:48 --> Helper loaded: form_helper
INFO - 2018-07-28 00:30:48 --> Helper loaded: date_helper
DEBUG - 2018-07-28 00:30:48 --> UTF-8 Support Enabled
INFO - 2018-07-28 00:30:48 --> Helper loaded: util_helper
INFO - 2018-07-28 00:30:48 --> Utf8 Class Initialized
INFO - 2018-07-28 00:30:48 --> Helper loaded: text_helper
INFO - 2018-07-28 00:30:48 --> URI Class Initialized
INFO - 2018-07-28 00:30:48 --> Helper loaded: string_helper
INFO - 2018-07-28 00:30:48 --> Router Class Initialized
INFO - 2018-07-28 00:30:48 --> Output Class Initialized
INFO - 2018-07-28 00:30:48 --> Database Driver Class Initialized
INFO - 2018-07-28 00:30:48 --> Security Class Initialized
DEBUG - 2018-07-28 00:30:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 00:30:48 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-07-28 00:30:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 00:30:48 --> Input Class Initialized
INFO - 2018-07-28 00:30:48 --> Email Class Initialized
INFO - 2018-07-28 00:30:48 --> Controller Class Initialized
INFO - 2018-07-28 00:30:48 --> Language Class Initialized
DEBUG - 2018-07-28 00:30:48 --> Home MX_Controller Initialized
ERROR - 2018-07-28 00:30:48 --> 404 Page Not Found: /index
DEBUG - 2018-07-28 00:30:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-07-28 00:30:48 --> Config Class Initialized
INFO - 2018-07-28 00:30:48 --> Hooks Class Initialized
DEBUG - 2018-07-28 00:30:48 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 00:30:48 --> Login MX_Controller Initialized
DEBUG - 2018-07-28 00:30:48 --> UTF-8 Support Enabled
INFO - 2018-07-28 00:30:48 --> Utf8 Class Initialized
INFO - 2018-07-28 00:30:48 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 00:30:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-28 00:30:48 --> URI Class Initialized
DEBUG - 2018-07-28 00:30:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-28 00:30:48 --> Router Class Initialized
INFO - 2018-07-28 00:30:48 --> Output Class Initialized
INFO - 2018-07-28 00:30:48 --> Security Class Initialized
DEBUG - 2018-07-28 00:30:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 00:30:48 --> Input Class Initialized
INFO - 2018-07-28 00:30:48 --> Language Class Initialized
ERROR - 2018-07-28 00:30:48 --> 404 Page Not Found: /index
INFO - 2018-07-28 00:30:48 --> Config Class Initialized
INFO - 2018-07-28 00:30:48 --> Hooks Class Initialized
DEBUG - 2018-07-28 00:30:48 --> UTF-8 Support Enabled
INFO - 2018-07-28 00:30:48 --> Utf8 Class Initialized
INFO - 2018-07-28 00:30:48 --> URI Class Initialized
INFO - 2018-07-28 00:30:48 --> Router Class Initialized
INFO - 2018-07-28 00:30:48 --> Output Class Initialized
INFO - 2018-07-28 00:30:48 --> Security Class Initialized
DEBUG - 2018-07-28 00:30:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 00:30:48 --> Input Class Initialized
INFO - 2018-07-28 00:30:48 --> Language Class Initialized
ERROR - 2018-07-28 00:30:49 --> 404 Page Not Found: /index
INFO - 2018-07-28 00:30:49 --> Config Class Initialized
INFO - 2018-07-28 00:30:49 --> Hooks Class Initialized
DEBUG - 2018-07-28 00:30:49 --> UTF-8 Support Enabled
INFO - 2018-07-28 00:30:49 --> Utf8 Class Initialized
INFO - 2018-07-28 00:30:49 --> URI Class Initialized
INFO - 2018-07-28 00:30:49 --> Router Class Initialized
INFO - 2018-07-28 00:30:49 --> Output Class Initialized
INFO - 2018-07-28 00:30:49 --> Security Class Initialized
DEBUG - 2018-07-28 00:30:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 00:30:49 --> Input Class Initialized
INFO - 2018-07-28 00:30:49 --> Language Class Initialized
ERROR - 2018-07-28 00:30:49 --> 404 Page Not Found: /index
INFO - 2018-07-28 00:30:49 --> Config Class Initialized
INFO - 2018-07-28 00:30:49 --> Hooks Class Initialized
DEBUG - 2018-07-28 00:30:49 --> UTF-8 Support Enabled
INFO - 2018-07-28 00:30:49 --> Utf8 Class Initialized
INFO - 2018-07-28 00:30:49 --> URI Class Initialized
INFO - 2018-07-28 00:30:49 --> Router Class Initialized
INFO - 2018-07-28 00:30:49 --> Output Class Initialized
INFO - 2018-07-28 00:30:49 --> Security Class Initialized
DEBUG - 2018-07-28 00:30:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 00:30:49 --> Input Class Initialized
INFO - 2018-07-28 00:30:49 --> Language Class Initialized
ERROR - 2018-07-28 00:30:49 --> 404 Page Not Found: /index
INFO - 2018-07-28 00:30:51 --> Config Class Initialized
INFO - 2018-07-28 00:30:51 --> Hooks Class Initialized
DEBUG - 2018-07-28 00:30:51 --> UTF-8 Support Enabled
INFO - 2018-07-28 00:30:51 --> Utf8 Class Initialized
INFO - 2018-07-28 00:30:51 --> URI Class Initialized
INFO - 2018-07-28 00:30:51 --> Router Class Initialized
INFO - 2018-07-28 00:30:51 --> Output Class Initialized
INFO - 2018-07-28 00:30:51 --> Security Class Initialized
DEBUG - 2018-07-28 00:30:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 00:30:51 --> Input Class Initialized
INFO - 2018-07-28 00:30:51 --> Language Class Initialized
INFO - 2018-07-28 00:30:51 --> Language Class Initialized
INFO - 2018-07-28 00:30:51 --> Config Class Initialized
INFO - 2018-07-28 00:30:51 --> Loader Class Initialized
DEBUG - 2018-07-28 00:30:51 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 00:30:51 --> Helper loaded: url_helper
INFO - 2018-07-28 00:30:51 --> Helper loaded: form_helper
INFO - 2018-07-28 00:30:51 --> Helper loaded: date_helper
INFO - 2018-07-28 00:30:51 --> Helper loaded: util_helper
INFO - 2018-07-28 00:30:51 --> Helper loaded: text_helper
INFO - 2018-07-28 00:30:51 --> Helper loaded: string_helper
INFO - 2018-07-28 00:30:51 --> Database Driver Class Initialized
DEBUG - 2018-07-28 00:30:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 00:30:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 00:30:51 --> Email Class Initialized
INFO - 2018-07-28 00:30:51 --> Controller Class Initialized
DEBUG - 2018-07-28 00:30:51 --> Login MX_Controller Initialized
INFO - 2018-07-28 00:30:51 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 00:30:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 00:30:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-28 00:30:51 --> Email starts for colin fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-07-28 00:30:51 --> User session created for 4
INFO - 2018-07-28 00:30:51 --> Login status colin - success
INFO - 2018-07-28 00:30:51 --> Final output sent to browser
DEBUG - 2018-07-28 00:30:51 --> Total execution time: 0.3805
INFO - 2018-07-28 00:30:51 --> Config Class Initialized
INFO - 2018-07-28 00:30:51 --> Hooks Class Initialized
DEBUG - 2018-07-28 00:30:51 --> UTF-8 Support Enabled
INFO - 2018-07-28 00:30:51 --> Utf8 Class Initialized
INFO - 2018-07-28 00:30:51 --> URI Class Initialized
INFO - 2018-07-28 00:30:51 --> Router Class Initialized
INFO - 2018-07-28 00:30:51 --> Output Class Initialized
INFO - 2018-07-28 00:30:51 --> Security Class Initialized
DEBUG - 2018-07-28 00:30:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 00:30:51 --> Input Class Initialized
INFO - 2018-07-28 00:30:51 --> Language Class Initialized
INFO - 2018-07-28 00:30:51 --> Language Class Initialized
INFO - 2018-07-28 00:30:51 --> Config Class Initialized
INFO - 2018-07-28 00:30:51 --> Loader Class Initialized
DEBUG - 2018-07-28 00:30:51 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 00:30:51 --> Helper loaded: url_helper
INFO - 2018-07-28 00:30:51 --> Helper loaded: form_helper
INFO - 2018-07-28 00:30:51 --> Helper loaded: date_helper
INFO - 2018-07-28 00:30:51 --> Helper loaded: util_helper
INFO - 2018-07-28 00:30:51 --> Helper loaded: text_helper
INFO - 2018-07-28 00:30:51 --> Helper loaded: string_helper
INFO - 2018-07-28 00:30:51 --> Database Driver Class Initialized
DEBUG - 2018-07-28 00:30:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 00:30:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 00:30:51 --> Email Class Initialized
INFO - 2018-07-28 00:30:51 --> Controller Class Initialized
DEBUG - 2018-07-28 00:30:51 --> Home MX_Controller Initialized
DEBUG - 2018-07-28 00:30:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-28 00:30:51 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 00:30:52 --> Login MX_Controller Initialized
INFO - 2018-07-28 00:30:52 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 00:30:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 00:30:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-28 00:30:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-28 00:30:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-28 00:30:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-28 00:30:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-28 00:30:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-28 00:30:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-28 00:30:52 --> Final output sent to browser
DEBUG - 2018-07-28 00:30:52 --> Total execution time: 0.4488
INFO - 2018-07-28 00:30:52 --> Config Class Initialized
INFO - 2018-07-28 00:30:52 --> Hooks Class Initialized
DEBUG - 2018-07-28 00:30:52 --> UTF-8 Support Enabled
INFO - 2018-07-28 00:30:52 --> Utf8 Class Initialized
INFO - 2018-07-28 00:30:52 --> Config Class Initialized
INFO - 2018-07-28 00:30:52 --> URI Class Initialized
INFO - 2018-07-28 00:30:52 --> Hooks Class Initialized
INFO - 2018-07-28 00:30:52 --> Router Class Initialized
DEBUG - 2018-07-28 00:30:52 --> UTF-8 Support Enabled
INFO - 2018-07-28 00:30:52 --> Utf8 Class Initialized
INFO - 2018-07-28 00:30:52 --> Output Class Initialized
INFO - 2018-07-28 00:30:52 --> URI Class Initialized
INFO - 2018-07-28 00:30:52 --> Security Class Initialized
INFO - 2018-07-28 00:30:52 --> Router Class Initialized
DEBUG - 2018-07-28 00:30:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 00:30:52 --> Output Class Initialized
INFO - 2018-07-28 00:30:52 --> Input Class Initialized
INFO - 2018-07-28 00:30:52 --> Language Class Initialized
ERROR - 2018-07-28 00:30:52 --> 404 Page Not Found: /index
INFO - 2018-07-28 00:30:52 --> Config Class Initialized
INFO - 2018-07-28 00:30:52 --> Security Class Initialized
INFO - 2018-07-28 00:30:52 --> Hooks Class Initialized
DEBUG - 2018-07-28 00:30:52 --> UTF-8 Support Enabled
DEBUG - 2018-07-28 00:30:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 00:30:52 --> Utf8 Class Initialized
INFO - 2018-07-28 00:30:52 --> URI Class Initialized
INFO - 2018-07-28 00:30:52 --> Input Class Initialized
INFO - 2018-07-28 00:30:52 --> Router Class Initialized
INFO - 2018-07-28 00:30:52 --> Output Class Initialized
INFO - 2018-07-28 00:30:52 --> Language Class Initialized
INFO - 2018-07-28 00:30:52 --> Security Class Initialized
DEBUG - 2018-07-28 00:30:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 00:30:52 --> Input Class Initialized
INFO - 2018-07-28 00:30:52 --> Language Class Initialized
ERROR - 2018-07-28 00:30:52 --> 404 Page Not Found: /index
INFO - 2018-07-28 00:30:52 --> Config Class Initialized
INFO - 2018-07-28 00:30:52 --> Hooks Class Initialized
DEBUG - 2018-07-28 00:30:52 --> UTF-8 Support Enabled
INFO - 2018-07-28 00:30:52 --> Language Class Initialized
INFO - 2018-07-28 00:30:52 --> Utf8 Class Initialized
INFO - 2018-07-28 00:30:52 --> URI Class Initialized
INFO - 2018-07-28 00:30:52 --> Config Class Initialized
INFO - 2018-07-28 00:30:52 --> Router Class Initialized
INFO - 2018-07-28 00:30:52 --> Output Class Initialized
INFO - 2018-07-28 00:30:52 --> Loader Class Initialized
DEBUG - 2018-07-28 00:30:52 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 00:30:52 --> Security Class Initialized
DEBUG - 2018-07-28 00:30:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 00:30:52 --> Helper loaded: url_helper
INFO - 2018-07-28 00:30:52 --> Helper loaded: form_helper
INFO - 2018-07-28 00:30:52 --> Input Class Initialized
INFO - 2018-07-28 00:30:52 --> Helper loaded: date_helper
INFO - 2018-07-28 00:30:52 --> Language Class Initialized
ERROR - 2018-07-28 00:30:52 --> 404 Page Not Found: /index
INFO - 2018-07-28 00:30:52 --> Helper loaded: util_helper
INFO - 2018-07-28 00:30:52 --> Helper loaded: text_helper
INFO - 2018-07-28 00:30:53 --> Helper loaded: string_helper
INFO - 2018-07-28 00:30:53 --> Database Driver Class Initialized
DEBUG - 2018-07-28 00:30:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 00:30:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 00:30:53 --> Email Class Initialized
INFO - 2018-07-28 00:30:53 --> Controller Class Initialized
DEBUG - 2018-07-28 00:30:53 --> Home MX_Controller Initialized
DEBUG - 2018-07-28 00:30:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-28 00:30:53 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 00:30:53 --> Login MX_Controller Initialized
INFO - 2018-07-28 00:30:53 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 00:30:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 00:30:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-28 00:30:55 --> Config Class Initialized
INFO - 2018-07-28 00:30:55 --> Hooks Class Initialized
DEBUG - 2018-07-28 00:30:55 --> UTF-8 Support Enabled
INFO - 2018-07-28 00:30:55 --> Utf8 Class Initialized
INFO - 2018-07-28 00:30:55 --> URI Class Initialized
INFO - 2018-07-28 00:30:55 --> Router Class Initialized
INFO - 2018-07-28 00:30:55 --> Output Class Initialized
INFO - 2018-07-28 00:30:55 --> Security Class Initialized
DEBUG - 2018-07-28 00:30:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 00:30:55 --> Input Class Initialized
INFO - 2018-07-28 00:30:55 --> Language Class Initialized
INFO - 2018-07-28 00:30:55 --> Language Class Initialized
INFO - 2018-07-28 00:30:55 --> Config Class Initialized
INFO - 2018-07-28 00:30:55 --> Loader Class Initialized
DEBUG - 2018-07-28 00:30:55 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 00:30:55 --> Helper loaded: url_helper
INFO - 2018-07-28 00:30:55 --> Helper loaded: form_helper
INFO - 2018-07-28 00:30:55 --> Helper loaded: date_helper
INFO - 2018-07-28 00:30:55 --> Helper loaded: util_helper
INFO - 2018-07-28 00:30:55 --> Helper loaded: text_helper
INFO - 2018-07-28 00:30:55 --> Helper loaded: string_helper
INFO - 2018-07-28 00:30:55 --> Database Driver Class Initialized
DEBUG - 2018-07-28 00:30:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 00:30:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 00:30:55 --> Email Class Initialized
INFO - 2018-07-28 00:30:55 --> Controller Class Initialized
DEBUG - 2018-07-28 00:30:55 --> Home MX_Controller Initialized
DEBUG - 2018-07-28 00:30:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-28 00:30:55 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 00:30:55 --> Login MX_Controller Initialized
INFO - 2018-07-28 00:30:55 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 00:30:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 00:30:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-28 00:30:55 --> Config Class Initialized
INFO - 2018-07-28 00:30:56 --> Hooks Class Initialized
DEBUG - 2018-07-28 00:30:56 --> UTF-8 Support Enabled
INFO - 2018-07-28 00:30:56 --> Utf8 Class Initialized
INFO - 2018-07-28 00:30:56 --> URI Class Initialized
INFO - 2018-07-28 00:30:56 --> Router Class Initialized
INFO - 2018-07-28 00:30:56 --> Output Class Initialized
INFO - 2018-07-28 00:30:56 --> Security Class Initialized
DEBUG - 2018-07-28 00:30:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 00:30:56 --> Input Class Initialized
INFO - 2018-07-28 00:30:56 --> Language Class Initialized
ERROR - 2018-07-28 00:30:56 --> 404 Page Not Found: /index
INFO - 2018-07-28 00:30:56 --> Config Class Initialized
INFO - 2018-07-28 00:30:56 --> Hooks Class Initialized
DEBUG - 2018-07-28 00:30:56 --> UTF-8 Support Enabled
INFO - 2018-07-28 00:30:56 --> Utf8 Class Initialized
INFO - 2018-07-28 00:30:56 --> URI Class Initialized
INFO - 2018-07-28 00:30:56 --> Router Class Initialized
INFO - 2018-07-28 00:30:56 --> Output Class Initialized
INFO - 2018-07-28 00:30:56 --> Security Class Initialized
DEBUG - 2018-07-28 00:30:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 00:30:56 --> Input Class Initialized
INFO - 2018-07-28 00:30:56 --> Language Class Initialized
ERROR - 2018-07-28 00:30:56 --> 404 Page Not Found: /index
INFO - 2018-07-28 00:30:56 --> Config Class Initialized
INFO - 2018-07-28 00:30:56 --> Hooks Class Initialized
DEBUG - 2018-07-28 00:30:56 --> UTF-8 Support Enabled
INFO - 2018-07-28 00:30:56 --> Utf8 Class Initialized
INFO - 2018-07-28 00:30:56 --> URI Class Initialized
INFO - 2018-07-28 00:30:56 --> Router Class Initialized
INFO - 2018-07-28 00:30:56 --> Output Class Initialized
INFO - 2018-07-28 00:30:56 --> Security Class Initialized
DEBUG - 2018-07-28 00:30:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 00:30:56 --> Input Class Initialized
INFO - 2018-07-28 00:30:56 --> Language Class Initialized
ERROR - 2018-07-28 00:30:56 --> 404 Page Not Found: /index
INFO - 2018-07-28 00:31:01 --> Config Class Initialized
INFO - 2018-07-28 00:31:01 --> Hooks Class Initialized
DEBUG - 2018-07-28 00:31:01 --> UTF-8 Support Enabled
INFO - 2018-07-28 00:31:01 --> Utf8 Class Initialized
INFO - 2018-07-28 00:31:01 --> URI Class Initialized
DEBUG - 2018-07-28 00:31:01 --> No URI present. Default controller set.
INFO - 2018-07-28 00:31:01 --> Router Class Initialized
INFO - 2018-07-28 00:31:01 --> Output Class Initialized
INFO - 2018-07-28 00:31:01 --> Security Class Initialized
DEBUG - 2018-07-28 00:31:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 00:31:02 --> Input Class Initialized
INFO - 2018-07-28 00:31:02 --> Language Class Initialized
INFO - 2018-07-28 00:31:02 --> Language Class Initialized
INFO - 2018-07-28 00:31:02 --> Config Class Initialized
INFO - 2018-07-28 00:31:02 --> Loader Class Initialized
DEBUG - 2018-07-28 00:31:02 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 00:31:02 --> Helper loaded: url_helper
INFO - 2018-07-28 00:31:02 --> Helper loaded: form_helper
INFO - 2018-07-28 00:31:02 --> Helper loaded: date_helper
INFO - 2018-07-28 00:31:02 --> Helper loaded: util_helper
INFO - 2018-07-28 00:31:02 --> Helper loaded: text_helper
INFO - 2018-07-28 00:31:02 --> Helper loaded: string_helper
INFO - 2018-07-28 00:31:02 --> Database Driver Class Initialized
DEBUG - 2018-07-28 00:31:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 00:31:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 00:31:02 --> Email Class Initialized
INFO - 2018-07-28 00:31:02 --> Controller Class Initialized
DEBUG - 2018-07-28 00:31:02 --> Home MX_Controller Initialized
DEBUG - 2018-07-28 00:31:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-28 00:31:02 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 00:31:02 --> Login MX_Controller Initialized
INFO - 2018-07-28 00:31:02 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 00:31:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 00:31:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-28 00:31:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-28 00:31:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-28 00:31:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-28 00:31:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-28 00:31:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-28 00:31:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-28 00:31:02 --> Final output sent to browser
DEBUG - 2018-07-28 00:31:02 --> Total execution time: 0.5397
INFO - 2018-07-28 00:31:02 --> Config Class Initialized
INFO - 2018-07-28 00:31:02 --> Hooks Class Initialized
DEBUG - 2018-07-28 00:31:02 --> UTF-8 Support Enabled
INFO - 2018-07-28 00:31:02 --> Config Class Initialized
INFO - 2018-07-28 00:31:02 --> Hooks Class Initialized
INFO - 2018-07-28 00:31:02 --> Utf8 Class Initialized
DEBUG - 2018-07-28 00:31:02 --> UTF-8 Support Enabled
INFO - 2018-07-28 00:31:02 --> Utf8 Class Initialized
INFO - 2018-07-28 00:31:02 --> URI Class Initialized
INFO - 2018-07-28 00:31:02 --> Router Class Initialized
INFO - 2018-07-28 00:31:02 --> Output Class Initialized
INFO - 2018-07-28 00:31:03 --> Security Class Initialized
DEBUG - 2018-07-28 00:31:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 00:31:03 --> Input Class Initialized
INFO - 2018-07-28 00:31:03 --> URI Class Initialized
INFO - 2018-07-28 00:31:03 --> Language Class Initialized
INFO - 2018-07-28 00:31:03 --> Language Class Initialized
INFO - 2018-07-28 00:31:03 --> Router Class Initialized
INFO - 2018-07-28 00:31:03 --> Config Class Initialized
INFO - 2018-07-28 00:31:03 --> Output Class Initialized
INFO - 2018-07-28 00:31:03 --> Loader Class Initialized
INFO - 2018-07-28 00:31:03 --> Security Class Initialized
DEBUG - 2018-07-28 00:31:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 00:31:03 --> Input Class Initialized
INFO - 2018-07-28 00:31:03 --> Language Class Initialized
ERROR - 2018-07-28 00:31:03 --> 404 Page Not Found: /index
DEBUG - 2018-07-28 00:31:03 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 00:31:03 --> Config Class Initialized
INFO - 2018-07-28 00:31:03 --> Hooks Class Initialized
INFO - 2018-07-28 00:31:03 --> Helper loaded: url_helper
DEBUG - 2018-07-28 00:31:03 --> UTF-8 Support Enabled
INFO - 2018-07-28 00:31:03 --> Helper loaded: form_helper
INFO - 2018-07-28 00:31:03 --> Utf8 Class Initialized
INFO - 2018-07-28 00:31:03 --> URI Class Initialized
INFO - 2018-07-28 00:31:03 --> Helper loaded: date_helper
INFO - 2018-07-28 00:31:03 --> Router Class Initialized
INFO - 2018-07-28 00:31:03 --> Output Class Initialized
INFO - 2018-07-28 00:31:03 --> Helper loaded: util_helper
INFO - 2018-07-28 00:31:03 --> Helper loaded: text_helper
INFO - 2018-07-28 00:31:03 --> Security Class Initialized
INFO - 2018-07-28 00:31:03 --> Helper loaded: string_helper
DEBUG - 2018-07-28 00:31:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 00:31:03 --> Input Class Initialized
INFO - 2018-07-28 00:31:03 --> Database Driver Class Initialized
INFO - 2018-07-28 00:31:03 --> Language Class Initialized
ERROR - 2018-07-28 00:31:03 --> 404 Page Not Found: /index
DEBUG - 2018-07-28 00:31:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 00:31:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 00:31:03 --> Config Class Initialized
INFO - 2018-07-28 00:31:03 --> Hooks Class Initialized
INFO - 2018-07-28 00:31:03 --> Email Class Initialized
INFO - 2018-07-28 00:31:03 --> Controller Class Initialized
DEBUG - 2018-07-28 00:31:03 --> UTF-8 Support Enabled
DEBUG - 2018-07-28 00:31:03 --> Home MX_Controller Initialized
DEBUG - 2018-07-28 00:31:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-07-28 00:31:03 --> Utf8 Class Initialized
INFO - 2018-07-28 00:31:03 --> URI Class Initialized
DEBUG - 2018-07-28 00:31:03 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 00:31:03 --> Login MX_Controller Initialized
INFO - 2018-07-28 00:31:03 --> Router Class Initialized
INFO - 2018-07-28 00:31:03 --> Language file loaded: language/english/data_lang.php
INFO - 2018-07-28 00:31:03 --> Output Class Initialized
DEBUG - 2018-07-28 00:31:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-28 00:31:03 --> Security Class Initialized
DEBUG - 2018-07-28 00:31:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-07-28 00:31:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-28 00:31:03 --> Input Class Initialized
INFO - 2018-07-28 00:31:03 --> Language Class Initialized
ERROR - 2018-07-28 00:31:03 --> 404 Page Not Found: /index
INFO - 2018-07-28 00:31:04 --> Config Class Initialized
INFO - 2018-07-28 00:31:04 --> Hooks Class Initialized
DEBUG - 2018-07-28 00:31:04 --> UTF-8 Support Enabled
INFO - 2018-07-28 00:31:04 --> Utf8 Class Initialized
INFO - 2018-07-28 00:31:04 --> URI Class Initialized
INFO - 2018-07-28 00:31:04 --> Router Class Initialized
INFO - 2018-07-28 00:31:04 --> Output Class Initialized
INFO - 2018-07-28 00:31:04 --> Security Class Initialized
DEBUG - 2018-07-28 00:31:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 00:31:04 --> Input Class Initialized
INFO - 2018-07-28 00:31:04 --> Language Class Initialized
INFO - 2018-07-28 00:31:04 --> Language Class Initialized
INFO - 2018-07-28 00:31:04 --> Config Class Initialized
INFO - 2018-07-28 00:31:04 --> Loader Class Initialized
DEBUG - 2018-07-28 00:31:04 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 00:31:04 --> Helper loaded: url_helper
INFO - 2018-07-28 00:31:05 --> Helper loaded: form_helper
INFO - 2018-07-28 00:31:05 --> Helper loaded: date_helper
INFO - 2018-07-28 00:31:05 --> Helper loaded: util_helper
INFO - 2018-07-28 00:31:05 --> Helper loaded: text_helper
INFO - 2018-07-28 00:31:05 --> Helper loaded: string_helper
INFO - 2018-07-28 00:31:05 --> Database Driver Class Initialized
DEBUG - 2018-07-28 00:31:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 00:31:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 00:31:05 --> Email Class Initialized
INFO - 2018-07-28 00:31:05 --> Controller Class Initialized
DEBUG - 2018-07-28 00:31:05 --> Login MX_Controller Initialized
INFO - 2018-07-28 00:31:05 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 00:31:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 00:31:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-28 00:31:05 --> 4 Loggedout
INFO - 2018-07-28 00:31:05 --> Config Class Initialized
INFO - 2018-07-28 00:31:05 --> Hooks Class Initialized
DEBUG - 2018-07-28 00:31:05 --> UTF-8 Support Enabled
INFO - 2018-07-28 00:31:05 --> Utf8 Class Initialized
INFO - 2018-07-28 00:31:05 --> URI Class Initialized
INFO - 2018-07-28 00:31:05 --> Router Class Initialized
INFO - 2018-07-28 00:31:05 --> Output Class Initialized
INFO - 2018-07-28 00:31:05 --> Security Class Initialized
DEBUG - 2018-07-28 00:31:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 00:31:05 --> Input Class Initialized
INFO - 2018-07-28 00:31:05 --> Language Class Initialized
INFO - 2018-07-28 00:31:05 --> Language Class Initialized
INFO - 2018-07-28 00:31:05 --> Config Class Initialized
INFO - 2018-07-28 00:31:05 --> Loader Class Initialized
DEBUG - 2018-07-28 00:31:05 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 00:31:05 --> Helper loaded: url_helper
INFO - 2018-07-28 00:31:05 --> Helper loaded: form_helper
INFO - 2018-07-28 00:31:05 --> Helper loaded: date_helper
INFO - 2018-07-28 00:31:05 --> Helper loaded: util_helper
INFO - 2018-07-28 00:31:05 --> Helper loaded: text_helper
INFO - 2018-07-28 00:31:05 --> Helper loaded: string_helper
INFO - 2018-07-28 00:31:05 --> Database Driver Class Initialized
DEBUG - 2018-07-28 00:31:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 00:31:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 00:31:05 --> Email Class Initialized
INFO - 2018-07-28 00:31:05 --> Controller Class Initialized
DEBUG - 2018-07-28 00:31:05 --> Home MX_Controller Initialized
DEBUG - 2018-07-28 00:31:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-28 00:31:05 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 00:31:05 --> Login MX_Controller Initialized
INFO - 2018-07-28 00:31:05 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 00:31:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 00:31:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-28 00:31:05 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-07-28 00:31:09 --> Config Class Initialized
INFO - 2018-07-28 00:31:09 --> Hooks Class Initialized
DEBUG - 2018-07-28 00:31:09 --> UTF-8 Support Enabled
INFO - 2018-07-28 00:31:09 --> Utf8 Class Initialized
INFO - 2018-07-28 00:31:09 --> URI Class Initialized
INFO - 2018-07-28 00:31:09 --> Router Class Initialized
INFO - 2018-07-28 00:31:09 --> Output Class Initialized
INFO - 2018-07-28 00:31:09 --> Security Class Initialized
DEBUG - 2018-07-28 00:31:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 00:31:09 --> Input Class Initialized
INFO - 2018-07-28 00:31:09 --> Language Class Initialized
INFO - 2018-07-28 00:31:09 --> Language Class Initialized
INFO - 2018-07-28 00:31:09 --> Config Class Initialized
INFO - 2018-07-28 00:31:09 --> Loader Class Initialized
DEBUG - 2018-07-28 00:31:09 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 00:31:09 --> Helper loaded: url_helper
INFO - 2018-07-28 00:31:09 --> Helper loaded: form_helper
INFO - 2018-07-28 00:31:09 --> Helper loaded: date_helper
INFO - 2018-07-28 00:31:09 --> Helper loaded: util_helper
INFO - 2018-07-28 00:31:09 --> Helper loaded: text_helper
INFO - 2018-07-28 00:31:09 --> Helper loaded: string_helper
INFO - 2018-07-28 00:31:09 --> Database Driver Class Initialized
DEBUG - 2018-07-28 00:31:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 00:31:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 00:31:09 --> Email Class Initialized
INFO - 2018-07-28 00:31:09 --> Controller Class Initialized
DEBUG - 2018-07-28 00:31:09 --> Login MX_Controller Initialized
INFO - 2018-07-28 00:31:09 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 00:31:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 00:31:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-28 00:31:09 --> 4 Loggedout
INFO - 2018-07-28 00:31:09 --> Config Class Initialized
INFO - 2018-07-28 00:31:09 --> Hooks Class Initialized
DEBUG - 2018-07-28 00:31:09 --> UTF-8 Support Enabled
INFO - 2018-07-28 00:31:09 --> Utf8 Class Initialized
INFO - 2018-07-28 00:31:09 --> URI Class Initialized
INFO - 2018-07-28 00:31:09 --> Router Class Initialized
INFO - 2018-07-28 00:31:09 --> Output Class Initialized
INFO - 2018-07-28 00:31:09 --> Security Class Initialized
DEBUG - 2018-07-28 00:31:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 00:31:09 --> Input Class Initialized
INFO - 2018-07-28 00:31:09 --> Language Class Initialized
INFO - 2018-07-28 00:31:09 --> Language Class Initialized
INFO - 2018-07-28 00:31:09 --> Config Class Initialized
INFO - 2018-07-28 00:31:09 --> Loader Class Initialized
DEBUG - 2018-07-28 00:31:09 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 00:31:09 --> Helper loaded: url_helper
INFO - 2018-07-28 00:31:09 --> Helper loaded: form_helper
INFO - 2018-07-28 00:31:09 --> Helper loaded: date_helper
INFO - 2018-07-28 00:31:09 --> Helper loaded: util_helper
INFO - 2018-07-28 00:31:09 --> Helper loaded: text_helper
INFO - 2018-07-28 00:31:09 --> Helper loaded: string_helper
INFO - 2018-07-28 00:31:10 --> Database Driver Class Initialized
DEBUG - 2018-07-28 00:31:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 00:31:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 00:31:10 --> Email Class Initialized
INFO - 2018-07-28 00:31:10 --> Controller Class Initialized
DEBUG - 2018-07-28 00:31:10 --> Home MX_Controller Initialized
DEBUG - 2018-07-28 00:31:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-28 00:31:10 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 00:31:10 --> Login MX_Controller Initialized
INFO - 2018-07-28 00:31:10 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 00:31:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 00:31:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-28 00:31:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/login.php
INFO - 2018-07-28 00:31:13 --> Config Class Initialized
INFO - 2018-07-28 00:31:13 --> Hooks Class Initialized
DEBUG - 2018-07-28 00:31:13 --> UTF-8 Support Enabled
INFO - 2018-07-28 00:31:13 --> Utf8 Class Initialized
INFO - 2018-07-28 00:31:13 --> URI Class Initialized
INFO - 2018-07-28 00:31:13 --> Router Class Initialized
INFO - 2018-07-28 00:31:13 --> Output Class Initialized
INFO - 2018-07-28 00:31:13 --> Security Class Initialized
DEBUG - 2018-07-28 00:31:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 00:31:13 --> Input Class Initialized
INFO - 2018-07-28 00:31:13 --> Language Class Initialized
INFO - 2018-07-28 00:31:13 --> Language Class Initialized
INFO - 2018-07-28 00:31:13 --> Config Class Initialized
INFO - 2018-07-28 00:31:13 --> Loader Class Initialized
DEBUG - 2018-07-28 00:31:13 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 00:31:13 --> Helper loaded: url_helper
INFO - 2018-07-28 00:31:13 --> Helper loaded: form_helper
INFO - 2018-07-28 00:31:13 --> Helper loaded: date_helper
INFO - 2018-07-28 00:31:13 --> Helper loaded: util_helper
INFO - 2018-07-28 00:31:13 --> Helper loaded: text_helper
INFO - 2018-07-28 00:31:13 --> Helper loaded: string_helper
INFO - 2018-07-28 00:31:13 --> Database Driver Class Initialized
DEBUG - 2018-07-28 00:31:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 00:31:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 00:31:13 --> Email Class Initialized
INFO - 2018-07-28 00:31:13 --> Controller Class Initialized
DEBUG - 2018-07-28 00:31:13 --> Login MX_Controller Initialized
INFO - 2018-07-28 00:31:13 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 00:31:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 00:31:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-28 00:31:13 --> Email starts for colin fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-07-28 00:31:13 --> User session created for 4
INFO - 2018-07-28 00:31:13 --> Login status colin - success
INFO - 2018-07-28 00:31:13 --> Final output sent to browser
DEBUG - 2018-07-28 00:31:13 --> Total execution time: 0.4379
INFO - 2018-07-28 00:31:13 --> Config Class Initialized
INFO - 2018-07-28 00:31:13 --> Hooks Class Initialized
DEBUG - 2018-07-28 00:31:13 --> UTF-8 Support Enabled
INFO - 2018-07-28 00:31:13 --> Utf8 Class Initialized
INFO - 2018-07-28 00:31:13 --> URI Class Initialized
INFO - 2018-07-28 00:31:13 --> Router Class Initialized
INFO - 2018-07-28 00:31:13 --> Output Class Initialized
INFO - 2018-07-28 00:31:13 --> Security Class Initialized
DEBUG - 2018-07-28 00:31:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 00:31:13 --> Input Class Initialized
INFO - 2018-07-28 00:31:13 --> Language Class Initialized
INFO - 2018-07-28 00:31:13 --> Language Class Initialized
INFO - 2018-07-28 00:31:13 --> Config Class Initialized
INFO - 2018-07-28 00:31:13 --> Loader Class Initialized
DEBUG - 2018-07-28 00:31:13 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 00:31:13 --> Helper loaded: url_helper
INFO - 2018-07-28 00:31:13 --> Helper loaded: form_helper
INFO - 2018-07-28 00:31:13 --> Helper loaded: date_helper
INFO - 2018-07-28 00:31:14 --> Helper loaded: util_helper
INFO - 2018-07-28 00:31:14 --> Helper loaded: text_helper
INFO - 2018-07-28 00:31:14 --> Helper loaded: string_helper
INFO - 2018-07-28 00:31:14 --> Database Driver Class Initialized
DEBUG - 2018-07-28 00:31:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 00:31:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 00:31:14 --> Email Class Initialized
INFO - 2018-07-28 00:31:14 --> Controller Class Initialized
DEBUG - 2018-07-28 00:31:14 --> Home MX_Controller Initialized
DEBUG - 2018-07-28 00:31:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-28 00:31:14 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 00:31:14 --> Login MX_Controller Initialized
INFO - 2018-07-28 00:31:14 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 00:31:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 00:31:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-28 00:31:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-28 00:31:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-28 00:31:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-28 00:31:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-28 00:31:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-28 00:31:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-28 00:31:14 --> Final output sent to browser
DEBUG - 2018-07-28 00:31:14 --> Total execution time: 0.5490
INFO - 2018-07-28 00:31:14 --> Config Class Initialized
INFO - 2018-07-28 00:31:14 --> Hooks Class Initialized
DEBUG - 2018-07-28 00:31:14 --> UTF-8 Support Enabled
INFO - 2018-07-28 00:31:14 --> Config Class Initialized
INFO - 2018-07-28 00:31:14 --> Hooks Class Initialized
INFO - 2018-07-28 00:31:14 --> Utf8 Class Initialized
INFO - 2018-07-28 00:31:14 --> URI Class Initialized
DEBUG - 2018-07-28 00:31:14 --> UTF-8 Support Enabled
INFO - 2018-07-28 00:31:14 --> Utf8 Class Initialized
INFO - 2018-07-28 00:31:14 --> Router Class Initialized
INFO - 2018-07-28 00:31:14 --> Output Class Initialized
INFO - 2018-07-28 00:31:14 --> URI Class Initialized
INFO - 2018-07-28 00:31:14 --> Security Class Initialized
DEBUG - 2018-07-28 00:31:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 00:31:14 --> Input Class Initialized
INFO - 2018-07-28 00:31:15 --> Language Class Initialized
INFO - 2018-07-28 00:31:15 --> Router Class Initialized
INFO - 2018-07-28 00:31:15 --> Output Class Initialized
ERROR - 2018-07-28 00:31:15 --> 404 Page Not Found: /index
INFO - 2018-07-28 00:31:15 --> Security Class Initialized
DEBUG - 2018-07-28 00:31:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 00:31:15 --> Config Class Initialized
INFO - 2018-07-28 00:31:15 --> Hooks Class Initialized
INFO - 2018-07-28 00:31:15 --> Input Class Initialized
DEBUG - 2018-07-28 00:31:15 --> UTF-8 Support Enabled
INFO - 2018-07-28 00:31:15 --> Utf8 Class Initialized
INFO - 2018-07-28 00:31:15 --> URI Class Initialized
INFO - 2018-07-28 00:31:15 --> Language Class Initialized
INFO - 2018-07-28 00:31:15 --> Router Class Initialized
INFO - 2018-07-28 00:31:15 --> Output Class Initialized
INFO - 2018-07-28 00:31:15 --> Language Class Initialized
INFO - 2018-07-28 00:31:15 --> Security Class Initialized
DEBUG - 2018-07-28 00:31:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 00:31:15 --> Input Class Initialized
INFO - 2018-07-28 00:31:15 --> Language Class Initialized
ERROR - 2018-07-28 00:31:15 --> 404 Page Not Found: /index
INFO - 2018-07-28 00:31:15 --> Config Class Initialized
INFO - 2018-07-28 00:31:15 --> Config Class Initialized
INFO - 2018-07-28 00:31:15 --> Hooks Class Initialized
INFO - 2018-07-28 00:31:15 --> Loader Class Initialized
DEBUG - 2018-07-28 00:31:15 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
DEBUG - 2018-07-28 00:31:15 --> UTF-8 Support Enabled
INFO - 2018-07-28 00:31:15 --> Utf8 Class Initialized
INFO - 2018-07-28 00:31:15 --> Helper loaded: url_helper
INFO - 2018-07-28 00:31:15 --> URI Class Initialized
INFO - 2018-07-28 00:31:15 --> Helper loaded: form_helper
INFO - 2018-07-28 00:31:15 --> Router Class Initialized
INFO - 2018-07-28 00:31:15 --> Helper loaded: date_helper
INFO - 2018-07-28 00:31:15 --> Output Class Initialized
INFO - 2018-07-28 00:31:15 --> Helper loaded: util_helper
INFO - 2018-07-28 00:31:15 --> Helper loaded: text_helper
INFO - 2018-07-28 00:31:15 --> Security Class Initialized
DEBUG - 2018-07-28 00:31:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 00:31:15 --> Helper loaded: string_helper
INFO - 2018-07-28 00:31:15 --> Input Class Initialized
INFO - 2018-07-28 00:31:15 --> Language Class Initialized
INFO - 2018-07-28 00:31:15 --> Database Driver Class Initialized
ERROR - 2018-07-28 00:31:15 --> 404 Page Not Found: /index
DEBUG - 2018-07-28 00:31:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 00:31:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 00:31:15 --> Email Class Initialized
INFO - 2018-07-28 00:31:15 --> Controller Class Initialized
DEBUG - 2018-07-28 00:31:15 --> Home MX_Controller Initialized
DEBUG - 2018-07-28 00:31:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-28 00:31:15 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 00:31:15 --> Login MX_Controller Initialized
INFO - 2018-07-28 00:31:15 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 00:31:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 00:31:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-28 00:31:19 --> Config Class Initialized
INFO - 2018-07-28 00:31:19 --> Hooks Class Initialized
DEBUG - 2018-07-28 00:31:19 --> UTF-8 Support Enabled
INFO - 2018-07-28 00:31:19 --> Utf8 Class Initialized
INFO - 2018-07-28 00:31:19 --> URI Class Initialized
INFO - 2018-07-28 00:31:19 --> Router Class Initialized
INFO - 2018-07-28 00:31:19 --> Output Class Initialized
INFO - 2018-07-28 00:31:19 --> Security Class Initialized
DEBUG - 2018-07-28 00:31:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 00:31:19 --> Input Class Initialized
INFO - 2018-07-28 00:31:19 --> Language Class Initialized
INFO - 2018-07-28 00:31:19 --> Language Class Initialized
INFO - 2018-07-28 00:31:19 --> Config Class Initialized
INFO - 2018-07-28 00:31:19 --> Loader Class Initialized
DEBUG - 2018-07-28 00:31:19 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 00:31:19 --> Helper loaded: url_helper
INFO - 2018-07-28 00:31:19 --> Helper loaded: form_helper
INFO - 2018-07-28 00:31:19 --> Helper loaded: date_helper
INFO - 2018-07-28 00:31:19 --> Helper loaded: util_helper
INFO - 2018-07-28 00:31:19 --> Helper loaded: text_helper
INFO - 2018-07-28 00:31:19 --> Helper loaded: string_helper
INFO - 2018-07-28 00:31:19 --> Database Driver Class Initialized
DEBUG - 2018-07-28 00:31:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 00:31:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 00:31:19 --> Email Class Initialized
INFO - 2018-07-28 00:31:19 --> Controller Class Initialized
DEBUG - 2018-07-28 00:31:19 --> Login MX_Controller Initialized
INFO - 2018-07-28 00:31:19 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 00:31:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 00:31:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-28 00:31:19 --> Email starts for colin fn:login_status lc:E:\xampp\htdocs\consulting\application\modules\admin\controllers\Login.php
INFO - 2018-07-28 00:31:19 --> User session created for 4
INFO - 2018-07-28 00:31:19 --> Login status colin - success
INFO - 2018-07-28 00:31:19 --> Final output sent to browser
DEBUG - 2018-07-28 00:31:19 --> Total execution time: 0.5179
INFO - 2018-07-28 00:31:19 --> Config Class Initialized
INFO - 2018-07-28 00:31:19 --> Hooks Class Initialized
DEBUG - 2018-07-28 00:31:19 --> UTF-8 Support Enabled
INFO - 2018-07-28 00:31:19 --> Utf8 Class Initialized
INFO - 2018-07-28 00:31:19 --> URI Class Initialized
INFO - 2018-07-28 00:31:19 --> Router Class Initialized
INFO - 2018-07-28 00:31:19 --> Output Class Initialized
INFO - 2018-07-28 00:31:19 --> Security Class Initialized
DEBUG - 2018-07-28 00:31:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 00:31:20 --> Input Class Initialized
INFO - 2018-07-28 00:31:20 --> Language Class Initialized
INFO - 2018-07-28 00:31:20 --> Language Class Initialized
INFO - 2018-07-28 00:31:20 --> Config Class Initialized
INFO - 2018-07-28 00:31:20 --> Loader Class Initialized
DEBUG - 2018-07-28 00:31:20 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 00:31:20 --> Helper loaded: url_helper
INFO - 2018-07-28 00:31:20 --> Helper loaded: form_helper
INFO - 2018-07-28 00:31:20 --> Helper loaded: date_helper
INFO - 2018-07-28 00:31:20 --> Helper loaded: util_helper
INFO - 2018-07-28 00:31:20 --> Helper loaded: text_helper
INFO - 2018-07-28 00:31:20 --> Helper loaded: string_helper
INFO - 2018-07-28 00:31:20 --> Database Driver Class Initialized
DEBUG - 2018-07-28 00:31:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 00:31:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 00:31:20 --> Email Class Initialized
INFO - 2018-07-28 00:31:20 --> Controller Class Initialized
DEBUG - 2018-07-28 00:31:20 --> Home MX_Controller Initialized
DEBUG - 2018-07-28 00:31:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-28 00:31:20 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 00:31:20 --> Login MX_Controller Initialized
INFO - 2018-07-28 00:31:20 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 00:31:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 00:31:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-28 00:31:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-28 00:31:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-28 00:31:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-28 00:31:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-28 00:31:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-28 00:31:20 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-28 00:31:20 --> Final output sent to browser
DEBUG - 2018-07-28 00:31:20 --> Total execution time: 0.4986
INFO - 2018-07-28 00:31:20 --> Config Class Initialized
INFO - 2018-07-28 00:31:20 --> Hooks Class Initialized
DEBUG - 2018-07-28 00:31:20 --> UTF-8 Support Enabled
INFO - 2018-07-28 00:31:20 --> Config Class Initialized
INFO - 2018-07-28 00:31:20 --> Hooks Class Initialized
INFO - 2018-07-28 00:31:20 --> Utf8 Class Initialized
INFO - 2018-07-28 00:31:20 --> URI Class Initialized
DEBUG - 2018-07-28 00:31:20 --> UTF-8 Support Enabled
INFO - 2018-07-28 00:31:20 --> Utf8 Class Initialized
INFO - 2018-07-28 00:31:20 --> Router Class Initialized
INFO - 2018-07-28 00:31:20 --> URI Class Initialized
INFO - 2018-07-28 00:31:20 --> Output Class Initialized
INFO - 2018-07-28 00:31:20 --> Router Class Initialized
INFO - 2018-07-28 00:31:20 --> Security Class Initialized
DEBUG - 2018-07-28 00:31:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 00:31:20 --> Output Class Initialized
INFO - 2018-07-28 00:31:20 --> Input Class Initialized
INFO - 2018-07-28 00:31:20 --> Security Class Initialized
INFO - 2018-07-28 00:31:21 --> Language Class Initialized
DEBUG - 2018-07-28 00:31:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 00:31:21 --> Input Class Initialized
ERROR - 2018-07-28 00:31:21 --> 404 Page Not Found: /index
INFO - 2018-07-28 00:31:21 --> Language Class Initialized
INFO - 2018-07-28 00:31:21 --> Config Class Initialized
INFO - 2018-07-28 00:31:21 --> Hooks Class Initialized
INFO - 2018-07-28 00:31:21 --> Language Class Initialized
INFO - 2018-07-28 00:31:21 --> Config Class Initialized
DEBUG - 2018-07-28 00:31:21 --> UTF-8 Support Enabled
INFO - 2018-07-28 00:31:21 --> Utf8 Class Initialized
INFO - 2018-07-28 00:31:21 --> Loader Class Initialized
INFO - 2018-07-28 00:31:21 --> URI Class Initialized
DEBUG - 2018-07-28 00:31:21 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 00:31:21 --> Router Class Initialized
INFO - 2018-07-28 00:31:21 --> Output Class Initialized
INFO - 2018-07-28 00:31:21 --> Helper loaded: url_helper
INFO - 2018-07-28 00:31:21 --> Helper loaded: form_helper
INFO - 2018-07-28 00:31:21 --> Security Class Initialized
INFO - 2018-07-28 00:31:21 --> Helper loaded: date_helper
DEBUG - 2018-07-28 00:31:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 00:31:21 --> Helper loaded: util_helper
INFO - 2018-07-28 00:31:21 --> Input Class Initialized
INFO - 2018-07-28 00:31:21 --> Helper loaded: text_helper
INFO - 2018-07-28 00:31:21 --> Language Class Initialized
ERROR - 2018-07-28 00:31:21 --> 404 Page Not Found: /index
INFO - 2018-07-28 00:31:21 --> Helper loaded: string_helper
INFO - 2018-07-28 00:31:21 --> Database Driver Class Initialized
INFO - 2018-07-28 00:31:21 --> Config Class Initialized
INFO - 2018-07-28 00:31:21 --> Hooks Class Initialized
DEBUG - 2018-07-28 00:31:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 00:31:21 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-07-28 00:31:21 --> UTF-8 Support Enabled
INFO - 2018-07-28 00:31:21 --> Utf8 Class Initialized
INFO - 2018-07-28 00:31:21 --> Email Class Initialized
INFO - 2018-07-28 00:31:21 --> Controller Class Initialized
INFO - 2018-07-28 00:31:21 --> URI Class Initialized
DEBUG - 2018-07-28 00:31:21 --> Home MX_Controller Initialized
INFO - 2018-07-28 00:31:21 --> Router Class Initialized
DEBUG - 2018-07-28 00:31:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-07-28 00:31:21 --> Output Class Initialized
INFO - 2018-07-28 00:31:21 --> Security Class Initialized
DEBUG - 2018-07-28 00:31:21 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 00:31:21 --> Login MX_Controller Initialized
DEBUG - 2018-07-28 00:31:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 00:31:21 --> Input Class Initialized
INFO - 2018-07-28 00:31:21 --> Language file loaded: language/english/data_lang.php
INFO - 2018-07-28 00:31:21 --> Language Class Initialized
DEBUG - 2018-07-28 00:31:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 00:31:21 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
ERROR - 2018-07-28 00:31:21 --> 404 Page Not Found: /index
INFO - 2018-07-28 01:21:01 --> Config Class Initialized
INFO - 2018-07-28 01:21:01 --> Config Class Initialized
INFO - 2018-07-28 01:21:01 --> Hooks Class Initialized
INFO - 2018-07-28 01:21:01 --> Hooks Class Initialized
DEBUG - 2018-07-28 01:21:01 --> UTF-8 Support Enabled
DEBUG - 2018-07-28 01:21:01 --> UTF-8 Support Enabled
INFO - 2018-07-28 01:21:01 --> Utf8 Class Initialized
INFO - 2018-07-28 01:21:01 --> Utf8 Class Initialized
INFO - 2018-07-28 01:21:01 --> URI Class Initialized
INFO - 2018-07-28 01:21:01 --> URI Class Initialized
INFO - 2018-07-28 01:21:01 --> Router Class Initialized
INFO - 2018-07-28 01:21:01 --> Router Class Initialized
INFO - 2018-07-28 01:21:01 --> Output Class Initialized
INFO - 2018-07-28 01:21:01 --> Output Class Initialized
INFO - 2018-07-28 01:21:01 --> Security Class Initialized
INFO - 2018-07-28 01:21:01 --> Security Class Initialized
DEBUG - 2018-07-28 01:21:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-07-28 01:21:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 01:21:01 --> Input Class Initialized
INFO - 2018-07-28 01:21:01 --> Input Class Initialized
INFO - 2018-07-28 01:21:01 --> Language Class Initialized
INFO - 2018-07-28 01:21:01 --> Language Class Initialized
ERROR - 2018-07-28 01:21:01 --> 404 Page Not Found: /index
INFO - 2018-07-28 01:21:01 --> Language Class Initialized
INFO - 2018-07-28 01:21:01 --> Config Class Initialized
INFO - 2018-07-28 01:21:01 --> Config Class Initialized
INFO - 2018-07-28 01:21:01 --> Hooks Class Initialized
DEBUG - 2018-07-28 01:21:01 --> UTF-8 Support Enabled
INFO - 2018-07-28 01:21:01 --> Utf8 Class Initialized
INFO - 2018-07-28 01:21:01 --> URI Class Initialized
INFO - 2018-07-28 01:21:01 --> Loader Class Initialized
INFO - 2018-07-28 01:21:01 --> Router Class Initialized
INFO - 2018-07-28 01:21:01 --> Output Class Initialized
DEBUG - 2018-07-28 01:21:01 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 01:21:01 --> Security Class Initialized
INFO - 2018-07-28 01:21:01 --> Helper loaded: url_helper
DEBUG - 2018-07-28 01:21:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 01:21:02 --> Input Class Initialized
INFO - 2018-07-28 01:21:02 --> Language Class Initialized
INFO - 2018-07-28 01:21:02 --> Helper loaded: form_helper
ERROR - 2018-07-28 01:21:02 --> 404 Page Not Found: /index
INFO - 2018-07-28 01:21:02 --> Config Class Initialized
INFO - 2018-07-28 01:21:02 --> Helper loaded: date_helper
INFO - 2018-07-28 01:21:02 --> Hooks Class Initialized
DEBUG - 2018-07-28 01:21:02 --> UTF-8 Support Enabled
INFO - 2018-07-28 01:21:02 --> Utf8 Class Initialized
INFO - 2018-07-28 01:21:02 --> Helper loaded: util_helper
INFO - 2018-07-28 01:21:02 --> URI Class Initialized
INFO - 2018-07-28 01:21:02 --> Router Class Initialized
INFO - 2018-07-28 01:21:02 --> Output Class Initialized
INFO - 2018-07-28 01:21:02 --> Helper loaded: text_helper
INFO - 2018-07-28 01:21:02 --> Security Class Initialized
DEBUG - 2018-07-28 01:21:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 01:21:02 --> Input Class Initialized
INFO - 2018-07-28 01:21:02 --> Language Class Initialized
ERROR - 2018-07-28 01:21:02 --> 404 Page Not Found: /index
INFO - 2018-07-28 01:21:02 --> Helper loaded: string_helper
INFO - 2018-07-28 01:21:02 --> Config Class Initialized
INFO - 2018-07-28 01:21:02 --> Hooks Class Initialized
DEBUG - 2018-07-28 01:21:02 --> UTF-8 Support Enabled
INFO - 2018-07-28 01:21:02 --> Utf8 Class Initialized
INFO - 2018-07-28 01:21:02 --> URI Class Initialized
INFO - 2018-07-28 01:21:02 --> Router Class Initialized
INFO - 2018-07-28 01:21:02 --> Output Class Initialized
INFO - 2018-07-28 01:21:02 --> Security Class Initialized
INFO - 2018-07-28 01:21:02 --> Database Driver Class Initialized
DEBUG - 2018-07-28 01:21:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 01:21:02 --> Input Class Initialized
INFO - 2018-07-28 01:21:02 --> Language Class Initialized
ERROR - 2018-07-28 01:21:02 --> 404 Page Not Found: /index
INFO - 2018-07-28 01:21:02 --> Config Class Initialized
INFO - 2018-07-28 01:21:02 --> Hooks Class Initialized
DEBUG - 2018-07-28 01:21:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-07-28 01:21:02 --> UTF-8 Support Enabled
INFO - 2018-07-28 01:21:02 --> Utf8 Class Initialized
INFO - 2018-07-28 01:21:02 --> URI Class Initialized
INFO - 2018-07-28 01:21:02 --> Router Class Initialized
INFO - 2018-07-28 01:21:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 01:21:02 --> Output Class Initialized
INFO - 2018-07-28 01:21:02 --> Security Class Initialized
DEBUG - 2018-07-28 01:21:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 01:21:02 --> Email Class Initialized
INFO - 2018-07-28 01:21:02 --> Input Class Initialized
INFO - 2018-07-28 01:21:02 --> Controller Class Initialized
DEBUG - 2018-07-28 01:21:02 --> Home MX_Controller Initialized
INFO - 2018-07-28 01:21:02 --> Language Class Initialized
ERROR - 2018-07-28 01:21:02 --> 404 Page Not Found: /index
INFO - 2018-07-28 01:21:02 --> Config Class Initialized
INFO - 2018-07-28 01:21:02 --> Hooks Class Initialized
DEBUG - 2018-07-28 01:21:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-28 01:21:02 --> UTF-8 Support Enabled
INFO - 2018-07-28 01:21:02 --> Utf8 Class Initialized
INFO - 2018-07-28 01:21:02 --> URI Class Initialized
INFO - 2018-07-28 01:21:02 --> Router Class Initialized
INFO - 2018-07-28 01:21:02 --> Output Class Initialized
DEBUG - 2018-07-28 01:21:02 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
INFO - 2018-07-28 01:21:02 --> Config Class Initialized
INFO - 2018-07-28 01:21:02 --> Hooks Class Initialized
DEBUG - 2018-07-28 01:21:02 --> Login MX_Controller Initialized
INFO - 2018-07-28 01:21:02 --> Security Class Initialized
DEBUG - 2018-07-28 01:21:02 --> UTF-8 Support Enabled
DEBUG - 2018-07-28 01:21:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 01:21:02 --> Language file loaded: language/english/data_lang.php
INFO - 2018-07-28 01:21:02 --> Utf8 Class Initialized
INFO - 2018-07-28 01:21:02 --> URI Class Initialized
INFO - 2018-07-28 01:21:02 --> Config Class Initialized
INFO - 2018-07-28 01:21:02 --> Input Class Initialized
DEBUG - 2018-07-28 01:21:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-28 01:21:02 --> Hooks Class Initialized
INFO - 2018-07-28 01:21:02 --> Router Class Initialized
INFO - 2018-07-28 01:21:02 --> Language Class Initialized
INFO - 2018-07-28 01:21:02 --> Output Class Initialized
DEBUG - 2018-07-28 01:21:02 --> UTF-8 Support Enabled
ERROR - 2018-07-28 01:21:02 --> 404 Page Not Found: /index
DEBUG - 2018-07-28 01:21:02 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-28 01:21:02 --> Utf8 Class Initialized
INFO - 2018-07-28 01:21:02 --> Security Class Initialized
INFO - 2018-07-28 01:21:02 --> URI Class Initialized
DEBUG - 2018-07-28 01:21:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 01:21:02 --> Input Class Initialized
INFO - 2018-07-28 01:21:02 --> Router Class Initialized
INFO - 2018-07-28 01:21:02 --> Output Class Initialized
INFO - 2018-07-28 01:21:02 --> Language Class Initialized
INFO - 2018-07-28 01:21:02 --> Security Class Initialized
INFO - 2018-07-28 01:21:02 --> Language Class Initialized
INFO - 2018-07-28 01:21:02 --> Config Class Initialized
DEBUG - 2018-07-28 01:21:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 01:21:02 --> Input Class Initialized
INFO - 2018-07-28 01:21:02 --> Loader Class Initialized
INFO - 2018-07-28 01:21:02 --> Language Class Initialized
DEBUG - 2018-07-28 01:21:02 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
ERROR - 2018-07-28 01:21:02 --> 404 Page Not Found: /index
INFO - 2018-07-28 01:21:02 --> Helper loaded: url_helper
INFO - 2018-07-28 01:21:02 --> Helper loaded: form_helper
INFO - 2018-07-28 01:21:03 --> Config Class Initialized
INFO - 2018-07-28 01:21:03 --> Helper loaded: date_helper
INFO - 2018-07-28 01:21:03 --> Hooks Class Initialized
INFO - 2018-07-28 01:21:03 --> Helper loaded: util_helper
INFO - 2018-07-28 01:21:03 --> Helper loaded: text_helper
DEBUG - 2018-07-28 01:21:03 --> UTF-8 Support Enabled
INFO - 2018-07-28 01:21:03 --> Helper loaded: string_helper
INFO - 2018-07-28 01:21:03 --> Utf8 Class Initialized
INFO - 2018-07-28 01:21:03 --> URI Class Initialized
INFO - 2018-07-28 01:21:03 --> Database Driver Class Initialized
INFO - 2018-07-28 01:21:03 --> Router Class Initialized
DEBUG - 2018-07-28 01:21:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 01:21:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 01:21:03 --> Output Class Initialized
INFO - 2018-07-28 01:21:03 --> Security Class Initialized
INFO - 2018-07-28 01:21:03 --> Email Class Initialized
INFO - 2018-07-28 01:21:03 --> Controller Class Initialized
DEBUG - 2018-07-28 01:21:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-07-28 01:21:03 --> Home MX_Controller Initialized
INFO - 2018-07-28 01:21:03 --> Input Class Initialized
INFO - 2018-07-28 01:21:03 --> Language Class Initialized
DEBUG - 2018-07-28 01:21:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
ERROR - 2018-07-28 01:21:03 --> 404 Page Not Found: /index
DEBUG - 2018-07-28 01:21:03 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 01:21:03 --> Login MX_Controller Initialized
INFO - 2018-07-28 01:21:03 --> Config Class Initialized
INFO - 2018-07-28 01:21:03 --> Hooks Class Initialized
INFO - 2018-07-28 01:21:03 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 01:21:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 01:21:03 --> UTF-8 Support Enabled
INFO - 2018-07-28 01:21:03 --> Utf8 Class Initialized
DEBUG - 2018-07-28 01:21:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-28 01:21:03 --> URI Class Initialized
INFO - 2018-07-28 01:21:03 --> Router Class Initialized
INFO - 2018-07-28 01:21:03 --> Output Class Initialized
INFO - 2018-07-28 01:21:03 --> Security Class Initialized
DEBUG - 2018-07-28 01:21:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 01:21:03 --> Input Class Initialized
INFO - 2018-07-28 01:21:03 --> Language Class Initialized
ERROR - 2018-07-28 01:21:03 --> 404 Page Not Found: /index
INFO - 2018-07-28 01:21:09 --> Config Class Initialized
INFO - 2018-07-28 01:21:09 --> Hooks Class Initialized
DEBUG - 2018-07-28 01:21:09 --> UTF-8 Support Enabled
INFO - 2018-07-28 01:21:09 --> Utf8 Class Initialized
INFO - 2018-07-28 01:21:09 --> URI Class Initialized
DEBUG - 2018-07-28 01:21:09 --> No URI present. Default controller set.
INFO - 2018-07-28 01:21:09 --> Router Class Initialized
INFO - 2018-07-28 01:21:09 --> Output Class Initialized
INFO - 2018-07-28 01:21:09 --> Security Class Initialized
DEBUG - 2018-07-28 01:21:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 01:21:09 --> Input Class Initialized
INFO - 2018-07-28 01:21:09 --> Language Class Initialized
INFO - 2018-07-28 01:21:09 --> Language Class Initialized
INFO - 2018-07-28 01:21:09 --> Config Class Initialized
INFO - 2018-07-28 01:21:09 --> Loader Class Initialized
DEBUG - 2018-07-28 01:21:09 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 01:21:09 --> Helper loaded: url_helper
INFO - 2018-07-28 01:21:09 --> Helper loaded: form_helper
INFO - 2018-07-28 01:21:09 --> Helper loaded: date_helper
INFO - 2018-07-28 01:21:09 --> Helper loaded: util_helper
INFO - 2018-07-28 01:21:09 --> Helper loaded: text_helper
INFO - 2018-07-28 01:21:09 --> Helper loaded: string_helper
INFO - 2018-07-28 01:21:09 --> Database Driver Class Initialized
DEBUG - 2018-07-28 01:21:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 01:21:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 01:21:09 --> Email Class Initialized
INFO - 2018-07-28 01:21:09 --> Controller Class Initialized
DEBUG - 2018-07-28 01:21:09 --> Home MX_Controller Initialized
DEBUG - 2018-07-28 01:21:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-28 01:21:09 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 01:21:09 --> Login MX_Controller Initialized
INFO - 2018-07-28 01:21:09 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 01:21:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 01:21:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
ERROR - 2018-07-28 01:21:09 --> Severity: Notice --> Undefined variable: name E:\xampp\htdocs\consulting\application\modules\home\models\Home_model.php 135
ERROR - 2018-07-28 01:21:09 --> Severity: Notice --> Undefined variable: name E:\xampp\htdocs\consulting\application\modules\home\models\Home_model.php 135
ERROR - 2018-07-28 01:21:09 --> Severity: Notice --> Undefined variable: name E:\xampp\htdocs\consulting\application\modules\home\models\Home_model.php 135
DEBUG - 2018-07-28 01:21:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-28 01:21:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-28 01:21:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
ERROR - 2018-07-28 01:21:10 --> Severity: Notice --> Array to string conversion E:\xampp\htdocs\consulting\application\modules\home\views\home.php 138
ERROR - 2018-07-28 01:21:10 --> Severity: Notice --> Array to string conversion E:\xampp\htdocs\consulting\application\modules\home\views\home.php 140
DEBUG - 2018-07-28 01:21:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-28 01:21:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-28 01:21:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-28 01:21:10 --> Final output sent to browser
DEBUG - 2018-07-28 01:21:10 --> Total execution time: 0.9036
INFO - 2018-07-28 01:21:10 --> Config Class Initialized
INFO - 2018-07-28 01:21:10 --> Hooks Class Initialized
DEBUG - 2018-07-28 01:21:10 --> UTF-8 Support Enabled
INFO - 2018-07-28 01:21:10 --> Utf8 Class Initialized
INFO - 2018-07-28 01:21:10 --> URI Class Initialized
INFO - 2018-07-28 01:21:10 --> Router Class Initialized
INFO - 2018-07-28 01:21:10 --> Output Class Initialized
INFO - 2018-07-28 01:21:10 --> Security Class Initialized
INFO - 2018-07-28 01:21:10 --> Config Class Initialized
INFO - 2018-07-28 01:21:10 --> Hooks Class Initialized
DEBUG - 2018-07-28 01:21:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 01:21:10 --> Input Class Initialized
DEBUG - 2018-07-28 01:21:10 --> UTF-8 Support Enabled
INFO - 2018-07-28 01:21:10 --> Utf8 Class Initialized
INFO - 2018-07-28 01:21:10 --> Language Class Initialized
INFO - 2018-07-28 01:21:10 --> URI Class Initialized
ERROR - 2018-07-28 01:21:10 --> 404 Page Not Found: /index
INFO - 2018-07-28 01:21:10 --> Router Class Initialized
INFO - 2018-07-28 01:21:10 --> Output Class Initialized
INFO - 2018-07-28 01:21:10 --> Security Class Initialized
DEBUG - 2018-07-28 01:21:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 01:21:10 --> Config Class Initialized
INFO - 2018-07-28 01:21:10 --> Hooks Class Initialized
INFO - 2018-07-28 01:21:10 --> Input Class Initialized
DEBUG - 2018-07-28 01:21:10 --> UTF-8 Support Enabled
INFO - 2018-07-28 01:21:11 --> Utf8 Class Initialized
INFO - 2018-07-28 01:21:11 --> URI Class Initialized
INFO - 2018-07-28 01:21:11 --> Language Class Initialized
INFO - 2018-07-28 01:21:11 --> Router Class Initialized
INFO - 2018-07-28 01:21:11 --> Language Class Initialized
INFO - 2018-07-28 01:21:11 --> Config Class Initialized
INFO - 2018-07-28 01:21:11 --> Loader Class Initialized
INFO - 2018-07-28 01:21:11 --> Output Class Initialized
DEBUG - 2018-07-28 01:21:11 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 01:21:11 --> Helper loaded: url_helper
INFO - 2018-07-28 01:21:11 --> Helper loaded: form_helper
INFO - 2018-07-28 01:21:11 --> Helper loaded: date_helper
INFO - 2018-07-28 01:21:11 --> Helper loaded: util_helper
INFO - 2018-07-28 01:21:11 --> Helper loaded: text_helper
INFO - 2018-07-28 01:21:11 --> Helper loaded: string_helper
INFO - 2018-07-28 01:21:11 --> Security Class Initialized
INFO - 2018-07-28 01:21:11 --> Database Driver Class Initialized
DEBUG - 2018-07-28 01:21:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-07-28 01:21:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 01:21:11 --> Input Class Initialized
INFO - 2018-07-28 01:21:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 01:21:11 --> Language Class Initialized
INFO - 2018-07-28 01:21:11 --> Email Class Initialized
ERROR - 2018-07-28 01:21:11 --> 404 Page Not Found: /index
INFO - 2018-07-28 01:21:11 --> Controller Class Initialized
DEBUG - 2018-07-28 01:21:11 --> Home MX_Controller Initialized
INFO - 2018-07-28 01:21:11 --> Config Class Initialized
INFO - 2018-07-28 01:21:11 --> Hooks Class Initialized
DEBUG - 2018-07-28 01:21:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-28 01:21:11 --> UTF-8 Support Enabled
DEBUG - 2018-07-28 01:21:11 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
INFO - 2018-07-28 01:21:11 --> Utf8 Class Initialized
INFO - 2018-07-28 01:21:11 --> URI Class Initialized
DEBUG - 2018-07-28 01:21:11 --> Login MX_Controller Initialized
INFO - 2018-07-28 01:21:11 --> Router Class Initialized
INFO - 2018-07-28 01:21:11 --> Output Class Initialized
INFO - 2018-07-28 01:21:11 --> Language file loaded: language/english/data_lang.php
INFO - 2018-07-28 01:21:11 --> Security Class Initialized
DEBUG - 2018-07-28 01:21:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 01:21:11 --> Input Class Initialized
INFO - 2018-07-28 01:21:11 --> Language Class Initialized
ERROR - 2018-07-28 01:21:11 --> 404 Page Not Found: /index
DEBUG - 2018-07-28 01:21:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 01:21:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-28 01:23:12 --> Config Class Initialized
INFO - 2018-07-28 01:23:13 --> Hooks Class Initialized
DEBUG - 2018-07-28 01:23:13 --> UTF-8 Support Enabled
INFO - 2018-07-28 01:23:13 --> Utf8 Class Initialized
INFO - 2018-07-28 01:23:13 --> URI Class Initialized
DEBUG - 2018-07-28 01:23:13 --> No URI present. Default controller set.
INFO - 2018-07-28 01:23:13 --> Router Class Initialized
INFO - 2018-07-28 01:23:13 --> Output Class Initialized
INFO - 2018-07-28 01:23:13 --> Security Class Initialized
DEBUG - 2018-07-28 01:23:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 01:23:13 --> Input Class Initialized
INFO - 2018-07-28 01:23:13 --> Language Class Initialized
INFO - 2018-07-28 01:23:13 --> Language Class Initialized
INFO - 2018-07-28 01:23:13 --> Config Class Initialized
INFO - 2018-07-28 01:23:13 --> Loader Class Initialized
DEBUG - 2018-07-28 01:23:13 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 01:23:13 --> Helper loaded: url_helper
INFO - 2018-07-28 01:23:13 --> Helper loaded: form_helper
INFO - 2018-07-28 01:23:13 --> Helper loaded: date_helper
INFO - 2018-07-28 01:23:13 --> Helper loaded: util_helper
INFO - 2018-07-28 01:23:13 --> Helper loaded: text_helper
INFO - 2018-07-28 01:23:13 --> Helper loaded: string_helper
INFO - 2018-07-28 01:23:13 --> Database Driver Class Initialized
DEBUG - 2018-07-28 01:23:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 01:23:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 01:23:13 --> Email Class Initialized
INFO - 2018-07-28 01:23:13 --> Controller Class Initialized
DEBUG - 2018-07-28 01:23:13 --> Home MX_Controller Initialized
DEBUG - 2018-07-28 01:23:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-28 01:23:13 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 01:23:13 --> Login MX_Controller Initialized
INFO - 2018-07-28 01:23:13 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 01:23:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 01:23:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-28 01:23:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-28 01:23:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-28 01:23:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
ERROR - 2018-07-28 01:23:13 --> Severity: Notice --> Array to string conversion E:\xampp\htdocs\consulting\application\modules\home\views\home.php 138
ERROR - 2018-07-28 01:23:13 --> Severity: Notice --> Array to string conversion E:\xampp\htdocs\consulting\application\modules\home\views\home.php 140
DEBUG - 2018-07-28 01:23:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-28 01:23:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-28 01:23:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-28 01:23:13 --> Final output sent to browser
DEBUG - 2018-07-28 01:23:13 --> Total execution time: 0.5719
INFO - 2018-07-28 01:23:14 --> Config Class Initialized
INFO - 2018-07-28 01:23:14 --> Config Class Initialized
INFO - 2018-07-28 01:23:14 --> Hooks Class Initialized
INFO - 2018-07-28 01:23:14 --> Hooks Class Initialized
DEBUG - 2018-07-28 01:23:14 --> UTF-8 Support Enabled
DEBUG - 2018-07-28 01:23:14 --> UTF-8 Support Enabled
INFO - 2018-07-28 01:23:14 --> Utf8 Class Initialized
INFO - 2018-07-28 01:23:14 --> URI Class Initialized
INFO - 2018-07-28 01:23:14 --> Router Class Initialized
INFO - 2018-07-28 01:23:14 --> Output Class Initialized
INFO - 2018-07-28 01:23:14 --> Security Class Initialized
DEBUG - 2018-07-28 01:23:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 01:23:14 --> Input Class Initialized
INFO - 2018-07-28 01:23:14 --> Language Class Initialized
INFO - 2018-07-28 01:23:14 --> Utf8 Class Initialized
INFO - 2018-07-28 01:23:14 --> Language Class Initialized
INFO - 2018-07-28 01:23:14 --> URI Class Initialized
INFO - 2018-07-28 01:23:14 --> Config Class Initialized
INFO - 2018-07-28 01:23:14 --> Router Class Initialized
INFO - 2018-07-28 01:23:14 --> Output Class Initialized
INFO - 2018-07-28 01:23:14 --> Loader Class Initialized
INFO - 2018-07-28 01:23:14 --> Security Class Initialized
DEBUG - 2018-07-28 01:23:14 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 01:23:14 --> Helper loaded: url_helper
DEBUG - 2018-07-28 01:23:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 01:23:14 --> Helper loaded: form_helper
INFO - 2018-07-28 01:23:14 --> Input Class Initialized
INFO - 2018-07-28 01:23:14 --> Language Class Initialized
INFO - 2018-07-28 01:23:14 --> Helper loaded: date_helper
ERROR - 2018-07-28 01:23:14 --> 404 Page Not Found: /index
INFO - 2018-07-28 01:23:14 --> Helper loaded: util_helper
INFO - 2018-07-28 01:23:14 --> Helper loaded: text_helper
INFO - 2018-07-28 01:23:14 --> Config Class Initialized
INFO - 2018-07-28 01:23:14 --> Hooks Class Initialized
INFO - 2018-07-28 01:23:14 --> Helper loaded: string_helper
DEBUG - 2018-07-28 01:23:14 --> UTF-8 Support Enabled
INFO - 2018-07-28 01:23:14 --> Database Driver Class Initialized
INFO - 2018-07-28 01:23:14 --> Utf8 Class Initialized
INFO - 2018-07-28 01:23:14 --> URI Class Initialized
INFO - 2018-07-28 01:23:14 --> Router Class Initialized
INFO - 2018-07-28 01:23:14 --> Output Class Initialized
INFO - 2018-07-28 01:23:14 --> Security Class Initialized
DEBUG - 2018-07-28 01:23:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 01:23:14 --> Input Class Initialized
INFO - 2018-07-28 01:23:14 --> Language Class Initialized
ERROR - 2018-07-28 01:23:14 --> 404 Page Not Found: /index
INFO - 2018-07-28 01:23:14 --> Config Class Initialized
DEBUG - 2018-07-28 01:23:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 01:23:14 --> Hooks Class Initialized
INFO - 2018-07-28 01:23:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 01:23:14 --> Email Class Initialized
DEBUG - 2018-07-28 01:23:14 --> UTF-8 Support Enabled
INFO - 2018-07-28 01:23:14 --> Controller Class Initialized
INFO - 2018-07-28 01:23:14 --> Utf8 Class Initialized
DEBUG - 2018-07-28 01:23:14 --> Home MX_Controller Initialized
INFO - 2018-07-28 01:23:14 --> URI Class Initialized
DEBUG - 2018-07-28 01:23:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-07-28 01:23:14 --> Router Class Initialized
INFO - 2018-07-28 01:23:14 --> Output Class Initialized
DEBUG - 2018-07-28 01:23:14 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 01:23:14 --> Login MX_Controller Initialized
INFO - 2018-07-28 01:23:14 --> Security Class Initialized
INFO - 2018-07-28 01:23:14 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 01:23:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 01:23:14 --> Input Class Initialized
DEBUG - 2018-07-28 01:23:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 01:23:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-28 01:23:14 --> Language Class Initialized
ERROR - 2018-07-28 01:23:14 --> 404 Page Not Found: /index
INFO - 2018-07-28 01:23:48 --> Config Class Initialized
INFO - 2018-07-28 01:23:48 --> Hooks Class Initialized
DEBUG - 2018-07-28 01:23:48 --> UTF-8 Support Enabled
INFO - 2018-07-28 01:23:48 --> Utf8 Class Initialized
INFO - 2018-07-28 01:23:48 --> URI Class Initialized
DEBUG - 2018-07-28 01:23:48 --> No URI present. Default controller set.
INFO - 2018-07-28 01:23:48 --> Router Class Initialized
INFO - 2018-07-28 01:23:48 --> Output Class Initialized
INFO - 2018-07-28 01:23:48 --> Security Class Initialized
DEBUG - 2018-07-28 01:23:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 01:23:48 --> Input Class Initialized
INFO - 2018-07-28 01:23:48 --> Language Class Initialized
INFO - 2018-07-28 01:23:48 --> Language Class Initialized
INFO - 2018-07-28 01:23:48 --> Config Class Initialized
INFO - 2018-07-28 01:23:48 --> Loader Class Initialized
DEBUG - 2018-07-28 01:23:48 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 01:23:48 --> Helper loaded: url_helper
INFO - 2018-07-28 01:23:48 --> Helper loaded: form_helper
INFO - 2018-07-28 01:23:48 --> Helper loaded: date_helper
INFO - 2018-07-28 01:23:48 --> Helper loaded: util_helper
INFO - 2018-07-28 01:23:48 --> Helper loaded: text_helper
INFO - 2018-07-28 01:23:48 --> Helper loaded: string_helper
INFO - 2018-07-28 01:23:48 --> Database Driver Class Initialized
DEBUG - 2018-07-28 01:23:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 01:23:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 01:23:48 --> Email Class Initialized
INFO - 2018-07-28 01:23:48 --> Controller Class Initialized
DEBUG - 2018-07-28 01:23:48 --> Home MX_Controller Initialized
DEBUG - 2018-07-28 01:23:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-28 01:23:48 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 01:23:48 --> Login MX_Controller Initialized
INFO - 2018-07-28 01:23:48 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 01:23:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 01:23:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-28 01:23:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-28 01:23:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-28 01:23:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-28 01:23:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-28 01:23:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-28 01:23:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-28 01:23:48 --> Final output sent to browser
DEBUG - 2018-07-28 01:23:48 --> Total execution time: 0.5947
INFO - 2018-07-28 01:23:49 --> Config Class Initialized
INFO - 2018-07-28 01:23:49 --> Hooks Class Initialized
DEBUG - 2018-07-28 01:23:49 --> UTF-8 Support Enabled
INFO - 2018-07-28 01:23:49 --> Utf8 Class Initialized
INFO - 2018-07-28 01:23:49 --> Config Class Initialized
INFO - 2018-07-28 01:23:49 --> Hooks Class Initialized
INFO - 2018-07-28 01:23:49 --> URI Class Initialized
DEBUG - 2018-07-28 01:23:49 --> UTF-8 Support Enabled
INFO - 2018-07-28 01:23:49 --> Router Class Initialized
INFO - 2018-07-28 01:23:49 --> Utf8 Class Initialized
INFO - 2018-07-28 01:23:49 --> Output Class Initialized
INFO - 2018-07-28 01:23:49 --> URI Class Initialized
INFO - 2018-07-28 01:23:49 --> Security Class Initialized
DEBUG - 2018-07-28 01:23:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 01:23:49 --> Input Class Initialized
INFO - 2018-07-28 01:23:49 --> Language Class Initialized
INFO - 2018-07-28 01:23:49 --> Router Class Initialized
ERROR - 2018-07-28 01:23:49 --> 404 Page Not Found: /index
INFO - 2018-07-28 01:23:49 --> Output Class Initialized
INFO - 2018-07-28 01:23:49 --> Config Class Initialized
INFO - 2018-07-28 01:23:49 --> Security Class Initialized
DEBUG - 2018-07-28 01:23:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 01:23:49 --> Input Class Initialized
INFO - 2018-07-28 01:23:49 --> Language Class Initialized
INFO - 2018-07-28 01:23:49 --> Language Class Initialized
INFO - 2018-07-28 01:23:49 --> Hooks Class Initialized
INFO - 2018-07-28 01:23:49 --> Config Class Initialized
INFO - 2018-07-28 01:23:49 --> Loader Class Initialized
DEBUG - 2018-07-28 01:23:49 --> UTF-8 Support Enabled
DEBUG - 2018-07-28 01:23:49 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 01:23:49 --> Helper loaded: url_helper
INFO - 2018-07-28 01:23:49 --> Helper loaded: form_helper
INFO - 2018-07-28 01:23:49 --> Helper loaded: date_helper
INFO - 2018-07-28 01:23:49 --> Helper loaded: util_helper
INFO - 2018-07-28 01:23:49 --> Helper loaded: text_helper
INFO - 2018-07-28 01:23:49 --> Helper loaded: string_helper
INFO - 2018-07-28 01:23:49 --> Utf8 Class Initialized
INFO - 2018-07-28 01:23:49 --> Database Driver Class Initialized
INFO - 2018-07-28 01:23:49 --> URI Class Initialized
DEBUG - 2018-07-28 01:23:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 01:23:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 01:23:49 --> Router Class Initialized
INFO - 2018-07-28 01:23:49 --> Output Class Initialized
INFO - 2018-07-28 01:23:49 --> Email Class Initialized
INFO - 2018-07-28 01:23:49 --> Controller Class Initialized
INFO - 2018-07-28 01:23:49 --> Security Class Initialized
DEBUG - 2018-07-28 01:23:49 --> Home MX_Controller Initialized
DEBUG - 2018-07-28 01:23:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-07-28 01:23:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-07-28 01:23:49 --> Input Class Initialized
INFO - 2018-07-28 01:23:49 --> Language Class Initialized
DEBUG - 2018-07-28 01:23:49 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 01:23:49 --> Login MX_Controller Initialized
ERROR - 2018-07-28 01:23:49 --> 404 Page Not Found: /index
INFO - 2018-07-28 01:23:49 --> Language file loaded: language/english/data_lang.php
INFO - 2018-07-28 01:23:49 --> Config Class Initialized
DEBUG - 2018-07-28 01:23:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 01:23:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-28 01:23:50 --> Hooks Class Initialized
DEBUG - 2018-07-28 01:23:50 --> UTF-8 Support Enabled
INFO - 2018-07-28 01:23:50 --> Utf8 Class Initialized
INFO - 2018-07-28 01:23:50 --> URI Class Initialized
INFO - 2018-07-28 01:23:50 --> Router Class Initialized
INFO - 2018-07-28 01:23:50 --> Output Class Initialized
INFO - 2018-07-28 01:23:50 --> Security Class Initialized
DEBUG - 2018-07-28 01:23:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 01:23:50 --> Input Class Initialized
INFO - 2018-07-28 01:23:50 --> Language Class Initialized
ERROR - 2018-07-28 01:23:50 --> 404 Page Not Found: /index
INFO - 2018-07-28 02:09:15 --> Config Class Initialized
INFO - 2018-07-28 02:09:15 --> Hooks Class Initialized
DEBUG - 2018-07-28 02:09:15 --> UTF-8 Support Enabled
INFO - 2018-07-28 02:09:15 --> Utf8 Class Initialized
INFO - 2018-07-28 02:09:15 --> URI Class Initialized
INFO - 2018-07-28 02:09:15 --> Router Class Initialized
INFO - 2018-07-28 02:09:15 --> Output Class Initialized
INFO - 2018-07-28 02:09:15 --> Security Class Initialized
DEBUG - 2018-07-28 02:09:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 02:09:15 --> Input Class Initialized
INFO - 2018-07-28 02:09:15 --> Language Class Initialized
INFO - 2018-07-28 02:09:15 --> Language Class Initialized
INFO - 2018-07-28 02:09:15 --> Config Class Initialized
INFO - 2018-07-28 02:09:15 --> Loader Class Initialized
DEBUG - 2018-07-28 02:09:15 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 02:09:15 --> Helper loaded: url_helper
INFO - 2018-07-28 02:09:15 --> Helper loaded: form_helper
INFO - 2018-07-28 02:09:15 --> Helper loaded: date_helper
INFO - 2018-07-28 02:09:15 --> Helper loaded: util_helper
INFO - 2018-07-28 02:09:15 --> Helper loaded: text_helper
INFO - 2018-07-28 02:09:15 --> Helper loaded: string_helper
INFO - 2018-07-28 02:09:15 --> Database Driver Class Initialized
DEBUG - 2018-07-28 02:09:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 02:09:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 02:09:15 --> Email Class Initialized
INFO - 2018-07-28 02:09:15 --> Controller Class Initialized
DEBUG - 2018-07-28 02:09:15 --> Programs MX_Controller Initialized
INFO - 2018-07-28 02:09:15 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 02:09:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-28 02:09:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 02:09:15 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 02:09:15 --> Login MX_Controller Initialized
DEBUG - 2018-07-28 02:09:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-28 02:09:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-28 02:09:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-28 02:09:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-28 02:09:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-28 02:09:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-28 02:09:15 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/programs.php
INFO - 2018-07-28 02:09:15 --> Final output sent to browser
DEBUG - 2018-07-28 02:09:15 --> Total execution time: 0.7720
INFO - 2018-07-28 02:09:16 --> Config Class Initialized
INFO - 2018-07-28 02:09:16 --> Hooks Class Initialized
DEBUG - 2018-07-28 02:09:16 --> UTF-8 Support Enabled
INFO - 2018-07-28 02:09:16 --> Utf8 Class Initialized
INFO - 2018-07-28 02:09:16 --> URI Class Initialized
INFO - 2018-07-28 02:09:16 --> Router Class Initialized
INFO - 2018-07-28 02:09:16 --> Output Class Initialized
INFO - 2018-07-28 02:09:16 --> Security Class Initialized
DEBUG - 2018-07-28 02:09:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 02:09:16 --> Input Class Initialized
INFO - 2018-07-28 02:09:16 --> Language Class Initialized
INFO - 2018-07-28 02:09:16 --> Language Class Initialized
INFO - 2018-07-28 02:09:16 --> Config Class Initialized
INFO - 2018-07-28 02:09:16 --> Loader Class Initialized
DEBUG - 2018-07-28 02:09:16 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 02:09:16 --> Helper loaded: url_helper
INFO - 2018-07-28 02:09:16 --> Helper loaded: form_helper
INFO - 2018-07-28 02:09:16 --> Helper loaded: date_helper
INFO - 2018-07-28 02:09:16 --> Helper loaded: util_helper
INFO - 2018-07-28 02:09:16 --> Helper loaded: text_helper
INFO - 2018-07-28 02:09:16 --> Helper loaded: string_helper
INFO - 2018-07-28 02:09:16 --> Database Driver Class Initialized
DEBUG - 2018-07-28 02:09:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 02:09:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 02:09:16 --> Email Class Initialized
INFO - 2018-07-28 02:09:16 --> Controller Class Initialized
DEBUG - 2018-07-28 02:09:16 --> Programs MX_Controller Initialized
INFO - 2018-07-28 02:09:16 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 02:09:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-28 02:09:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 02:09:16 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 02:09:16 --> Login MX_Controller Initialized
DEBUG - 2018-07-28 02:09:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-28 02:09:16 --> Final output sent to browser
DEBUG - 2018-07-28 02:09:16 --> Total execution time: 0.5471
INFO - 2018-07-28 02:09:18 --> Config Class Initialized
INFO - 2018-07-28 02:09:18 --> Hooks Class Initialized
DEBUG - 2018-07-28 02:09:19 --> UTF-8 Support Enabled
INFO - 2018-07-28 02:09:19 --> Utf8 Class Initialized
INFO - 2018-07-28 02:09:19 --> URI Class Initialized
INFO - 2018-07-28 02:09:19 --> Router Class Initialized
INFO - 2018-07-28 02:09:19 --> Output Class Initialized
INFO - 2018-07-28 02:09:19 --> Security Class Initialized
DEBUG - 2018-07-28 02:09:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 02:09:19 --> Input Class Initialized
INFO - 2018-07-28 02:09:19 --> Language Class Initialized
INFO - 2018-07-28 02:09:19 --> Language Class Initialized
INFO - 2018-07-28 02:09:19 --> Config Class Initialized
INFO - 2018-07-28 02:09:19 --> Loader Class Initialized
DEBUG - 2018-07-28 02:09:19 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 02:09:19 --> Helper loaded: url_helper
INFO - 2018-07-28 02:09:19 --> Helper loaded: form_helper
INFO - 2018-07-28 02:09:19 --> Helper loaded: date_helper
INFO - 2018-07-28 02:09:19 --> Helper loaded: util_helper
INFO - 2018-07-28 02:09:19 --> Helper loaded: text_helper
INFO - 2018-07-28 02:09:19 --> Helper loaded: string_helper
INFO - 2018-07-28 02:09:19 --> Database Driver Class Initialized
DEBUG - 2018-07-28 02:09:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 02:09:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 02:09:19 --> Email Class Initialized
INFO - 2018-07-28 02:09:19 --> Controller Class Initialized
DEBUG - 2018-07-28 02:09:19 --> Programs MX_Controller Initialized
INFO - 2018-07-28 02:09:19 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 02:09:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-28 02:09:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 02:09:19 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 02:09:19 --> Login MX_Controller Initialized
DEBUG - 2018-07-28 02:09:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-28 02:09:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-28 02:09:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-28 02:09:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-28 02:09:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-28 02:09:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-28 02:09:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/create_program.php
INFO - 2018-07-28 02:09:19 --> Final output sent to browser
DEBUG - 2018-07-28 02:09:19 --> Total execution time: 0.5724
INFO - 2018-07-28 02:12:26 --> Config Class Initialized
INFO - 2018-07-28 02:12:26 --> Hooks Class Initialized
DEBUG - 2018-07-28 02:12:26 --> UTF-8 Support Enabled
INFO - 2018-07-28 02:12:26 --> Utf8 Class Initialized
INFO - 2018-07-28 02:12:26 --> URI Class Initialized
INFO - 2018-07-28 02:12:26 --> Router Class Initialized
INFO - 2018-07-28 02:12:26 --> Output Class Initialized
INFO - 2018-07-28 02:12:26 --> Security Class Initialized
DEBUG - 2018-07-28 02:12:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 02:12:26 --> Input Class Initialized
INFO - 2018-07-28 02:12:26 --> Language Class Initialized
INFO - 2018-07-28 02:12:26 --> Language Class Initialized
INFO - 2018-07-28 02:12:26 --> Config Class Initialized
INFO - 2018-07-28 02:12:26 --> Loader Class Initialized
DEBUG - 2018-07-28 02:12:26 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 02:12:26 --> Helper loaded: url_helper
INFO - 2018-07-28 02:12:26 --> Helper loaded: form_helper
INFO - 2018-07-28 02:12:26 --> Helper loaded: date_helper
INFO - 2018-07-28 02:12:26 --> Helper loaded: util_helper
INFO - 2018-07-28 02:12:26 --> Helper loaded: text_helper
INFO - 2018-07-28 02:12:26 --> Helper loaded: string_helper
INFO - 2018-07-28 02:12:26 --> Database Driver Class Initialized
DEBUG - 2018-07-28 02:12:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 02:12:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 02:12:26 --> Email Class Initialized
INFO - 2018-07-28 02:12:26 --> Controller Class Initialized
DEBUG - 2018-07-28 02:12:26 --> Users MX_Controller Initialized
DEBUG - 2018-07-28 02:12:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 02:12:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-28 02:12:26 --> Helper loaded: file_helper
DEBUG - 2018-07-28 02:12:26 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 02:12:26 --> Login MX_Controller Initialized
INFO - 2018-07-28 02:12:26 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 02:12:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-28 02:12:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-28 02:12:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-28 02:12:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-28 02:12:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-28 02:12:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-28 02:12:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-07-28 02:12:27 --> Final output sent to browser
DEBUG - 2018-07-28 02:12:27 --> Total execution time: 0.6113
INFO - 2018-07-28 02:12:27 --> Config Class Initialized
INFO - 2018-07-28 02:12:27 --> Hooks Class Initialized
DEBUG - 2018-07-28 02:12:27 --> UTF-8 Support Enabled
INFO - 2018-07-28 02:12:27 --> Utf8 Class Initialized
INFO - 2018-07-28 02:12:27 --> URI Class Initialized
INFO - 2018-07-28 02:12:27 --> Router Class Initialized
INFO - 2018-07-28 02:12:27 --> Output Class Initialized
INFO - 2018-07-28 02:12:27 --> Security Class Initialized
DEBUG - 2018-07-28 02:12:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 02:12:27 --> Input Class Initialized
INFO - 2018-07-28 02:12:27 --> Language Class Initialized
INFO - 2018-07-28 02:12:27 --> Language Class Initialized
INFO - 2018-07-28 02:12:27 --> Config Class Initialized
INFO - 2018-07-28 02:12:27 --> Loader Class Initialized
DEBUG - 2018-07-28 02:12:27 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 02:12:27 --> Helper loaded: url_helper
INFO - 2018-07-28 02:12:27 --> Helper loaded: form_helper
INFO - 2018-07-28 02:12:27 --> Helper loaded: date_helper
INFO - 2018-07-28 02:12:27 --> Helper loaded: util_helper
INFO - 2018-07-28 02:12:27 --> Helper loaded: text_helper
INFO - 2018-07-28 02:12:27 --> Helper loaded: string_helper
INFO - 2018-07-28 02:12:27 --> Database Driver Class Initialized
DEBUG - 2018-07-28 02:12:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 02:12:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 02:12:27 --> Email Class Initialized
INFO - 2018-07-28 02:12:27 --> Controller Class Initialized
DEBUG - 2018-07-28 02:12:27 --> Users MX_Controller Initialized
DEBUG - 2018-07-28 02:12:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 02:12:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-28 02:12:27 --> Helper loaded: file_helper
DEBUG - 2018-07-28 02:12:27 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 02:12:27 --> Login MX_Controller Initialized
INFO - 2018-07-28 02:12:27 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 02:12:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-28 02:12:28 --> Final output sent to browser
DEBUG - 2018-07-28 02:12:28 --> Total execution time: 0.6326
INFO - 2018-07-28 02:12:31 --> Config Class Initialized
INFO - 2018-07-28 02:12:31 --> Hooks Class Initialized
DEBUG - 2018-07-28 02:12:31 --> UTF-8 Support Enabled
INFO - 2018-07-28 02:12:31 --> Utf8 Class Initialized
INFO - 2018-07-28 02:12:31 --> URI Class Initialized
INFO - 2018-07-28 02:12:31 --> Router Class Initialized
INFO - 2018-07-28 02:12:31 --> Output Class Initialized
INFO - 2018-07-28 02:12:31 --> Security Class Initialized
DEBUG - 2018-07-28 02:12:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 02:12:31 --> Input Class Initialized
INFO - 2018-07-28 02:12:31 --> Language Class Initialized
INFO - 2018-07-28 02:12:31 --> Language Class Initialized
INFO - 2018-07-28 02:12:31 --> Config Class Initialized
INFO - 2018-07-28 02:12:31 --> Loader Class Initialized
DEBUG - 2018-07-28 02:12:31 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 02:12:31 --> Helper loaded: url_helper
INFO - 2018-07-28 02:12:31 --> Helper loaded: form_helper
INFO - 2018-07-28 02:12:31 --> Helper loaded: date_helper
INFO - 2018-07-28 02:12:31 --> Helper loaded: util_helper
INFO - 2018-07-28 02:12:31 --> Helper loaded: text_helper
INFO - 2018-07-28 02:12:31 --> Helper loaded: string_helper
INFO - 2018-07-28 02:12:31 --> Database Driver Class Initialized
DEBUG - 2018-07-28 02:12:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 02:12:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 02:12:31 --> Email Class Initialized
INFO - 2018-07-28 02:12:31 --> Controller Class Initialized
DEBUG - 2018-07-28 02:12:31 --> Users MX_Controller Initialized
DEBUG - 2018-07-28 02:12:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 02:12:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-28 02:12:31 --> Helper loaded: file_helper
DEBUG - 2018-07-28 02:12:31 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 02:12:31 --> Login MX_Controller Initialized
INFO - 2018-07-28 02:12:31 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 02:12:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-28 02:12:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-28 02:12:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-28 02:12:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-28 02:12:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-28 02:12:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-28 02:12:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-28 02:12:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-07-28 02:12:31 --> Final output sent to browser
DEBUG - 2018-07-28 02:12:31 --> Total execution time: 0.6791
INFO - 2018-07-28 02:12:38 --> Config Class Initialized
INFO - 2018-07-28 02:12:39 --> Hooks Class Initialized
DEBUG - 2018-07-28 02:12:39 --> UTF-8 Support Enabled
INFO - 2018-07-28 02:12:39 --> Utf8 Class Initialized
INFO - 2018-07-28 02:12:39 --> URI Class Initialized
INFO - 2018-07-28 02:12:39 --> Router Class Initialized
INFO - 2018-07-28 02:12:39 --> Output Class Initialized
INFO - 2018-07-28 02:12:39 --> Security Class Initialized
DEBUG - 2018-07-28 02:12:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 02:12:39 --> Input Class Initialized
INFO - 2018-07-28 02:12:39 --> Language Class Initialized
INFO - 2018-07-28 02:12:39 --> Language Class Initialized
INFO - 2018-07-28 02:12:39 --> Config Class Initialized
INFO - 2018-07-28 02:12:39 --> Loader Class Initialized
DEBUG - 2018-07-28 02:12:39 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 02:12:39 --> Helper loaded: url_helper
INFO - 2018-07-28 02:12:39 --> Helper loaded: form_helper
INFO - 2018-07-28 02:12:39 --> Helper loaded: date_helper
INFO - 2018-07-28 02:12:39 --> Helper loaded: util_helper
INFO - 2018-07-28 02:12:39 --> Helper loaded: text_helper
INFO - 2018-07-28 02:12:39 --> Helper loaded: string_helper
INFO - 2018-07-28 02:12:39 --> Database Driver Class Initialized
DEBUG - 2018-07-28 02:12:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 02:12:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 02:12:39 --> Email Class Initialized
INFO - 2018-07-28 02:12:39 --> Controller Class Initialized
DEBUG - 2018-07-28 02:12:39 --> Home MX_Controller Initialized
DEBUG - 2018-07-28 02:12:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-28 02:12:39 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 02:12:39 --> Login MX_Controller Initialized
INFO - 2018-07-28 02:12:39 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 02:12:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 02:12:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
ERROR - 2018-07-28 02:12:39 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable E:\xampp\htdocs\consulting\application\modules\home\controllers\Home.php 18
ERROR - 2018-07-28 02:12:39 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable E:\xampp\htdocs\consulting\application\modules\home\controllers\Home.php 18
ERROR - 2018-07-28 02:12:39 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable E:\xampp\htdocs\consulting\application\modules\home\controllers\Home.php 18
DEBUG - 2018-07-28 02:12:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-28 02:12:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-28 02:12:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-28 02:12:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-28 02:12:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-28 02:12:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-28 02:12:39 --> Final output sent to browser
DEBUG - 2018-07-28 02:12:39 --> Total execution time: 0.5608
INFO - 2018-07-28 02:12:40 --> Config Class Initialized
INFO - 2018-07-28 02:12:40 --> Hooks Class Initialized
DEBUG - 2018-07-28 02:12:40 --> UTF-8 Support Enabled
INFO - 2018-07-28 02:12:40 --> Config Class Initialized
INFO - 2018-07-28 02:12:40 --> Hooks Class Initialized
INFO - 2018-07-28 02:12:40 --> Utf8 Class Initialized
INFO - 2018-07-28 02:12:40 --> URI Class Initialized
DEBUG - 2018-07-28 02:12:40 --> UTF-8 Support Enabled
INFO - 2018-07-28 02:12:40 --> Utf8 Class Initialized
INFO - 2018-07-28 02:12:40 --> Router Class Initialized
INFO - 2018-07-28 02:12:40 --> URI Class Initialized
INFO - 2018-07-28 02:12:40 --> Output Class Initialized
INFO - 2018-07-28 02:12:40 --> Router Class Initialized
INFO - 2018-07-28 02:12:40 --> Output Class Initialized
INFO - 2018-07-28 02:12:40 --> Security Class Initialized
INFO - 2018-07-28 02:12:40 --> Security Class Initialized
DEBUG - 2018-07-28 02:12:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 02:12:40 --> Input Class Initialized
INFO - 2018-07-28 02:12:40 --> Language Class Initialized
INFO - 2018-07-28 02:12:40 --> Language Class Initialized
INFO - 2018-07-28 02:12:40 --> Config Class Initialized
INFO - 2018-07-28 02:12:40 --> Loader Class Initialized
DEBUG - 2018-07-28 02:12:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-07-28 02:12:40 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 02:12:40 --> Helper loaded: url_helper
INFO - 2018-07-28 02:12:40 --> Input Class Initialized
INFO - 2018-07-28 02:12:40 --> Helper loaded: form_helper
INFO - 2018-07-28 02:12:40 --> Language Class Initialized
INFO - 2018-07-28 02:12:40 --> Helper loaded: date_helper
ERROR - 2018-07-28 02:12:40 --> 404 Page Not Found: /index
INFO - 2018-07-28 02:12:40 --> Helper loaded: util_helper
INFO - 2018-07-28 02:12:40 --> Config Class Initialized
INFO - 2018-07-28 02:12:40 --> Hooks Class Initialized
INFO - 2018-07-28 02:12:40 --> Helper loaded: text_helper
INFO - 2018-07-28 02:12:40 --> Helper loaded: string_helper
DEBUG - 2018-07-28 02:12:40 --> UTF-8 Support Enabled
INFO - 2018-07-28 02:12:40 --> Utf8 Class Initialized
INFO - 2018-07-28 02:12:40 --> URI Class Initialized
INFO - 2018-07-28 02:12:40 --> Database Driver Class Initialized
INFO - 2018-07-28 02:12:40 --> Router Class Initialized
DEBUG - 2018-07-28 02:12:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 02:12:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 02:12:40 --> Output Class Initialized
INFO - 2018-07-28 02:12:40 --> Security Class Initialized
INFO - 2018-07-28 02:12:40 --> Email Class Initialized
DEBUG - 2018-07-28 02:12:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 02:12:40 --> Controller Class Initialized
DEBUG - 2018-07-28 02:12:40 --> Home MX_Controller Initialized
INFO - 2018-07-28 02:12:40 --> Input Class Initialized
DEBUG - 2018-07-28 02:12:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-07-28 02:12:40 --> Language Class Initialized
ERROR - 2018-07-28 02:12:40 --> 404 Page Not Found: /index
DEBUG - 2018-07-28 02:12:40 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 02:12:40 --> Login MX_Controller Initialized
INFO - 2018-07-28 02:12:40 --> Config Class Initialized
INFO - 2018-07-28 02:12:40 --> Language file loaded: language/english/data_lang.php
INFO - 2018-07-28 02:12:40 --> Hooks Class Initialized
DEBUG - 2018-07-28 02:12:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 02:12:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-28 02:12:40 --> UTF-8 Support Enabled
INFO - 2018-07-28 02:12:40 --> Utf8 Class Initialized
INFO - 2018-07-28 02:12:41 --> URI Class Initialized
INFO - 2018-07-28 02:12:41 --> Router Class Initialized
INFO - 2018-07-28 02:12:41 --> Output Class Initialized
INFO - 2018-07-28 02:12:41 --> Security Class Initialized
DEBUG - 2018-07-28 02:12:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 02:12:41 --> Input Class Initialized
INFO - 2018-07-28 02:12:41 --> Language Class Initialized
ERROR - 2018-07-28 02:12:41 --> 404 Page Not Found: /index
INFO - 2018-07-28 02:13:31 --> Config Class Initialized
INFO - 2018-07-28 02:13:31 --> Hooks Class Initialized
DEBUG - 2018-07-28 02:13:31 --> UTF-8 Support Enabled
INFO - 2018-07-28 02:13:31 --> Utf8 Class Initialized
INFO - 2018-07-28 02:13:31 --> URI Class Initialized
INFO - 2018-07-28 02:13:31 --> Router Class Initialized
INFO - 2018-07-28 02:13:31 --> Output Class Initialized
INFO - 2018-07-28 02:13:31 --> Security Class Initialized
DEBUG - 2018-07-28 02:13:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 02:13:31 --> Input Class Initialized
INFO - 2018-07-28 02:13:31 --> Language Class Initialized
INFO - 2018-07-28 02:13:31 --> Language Class Initialized
INFO - 2018-07-28 02:13:31 --> Config Class Initialized
INFO - 2018-07-28 02:13:31 --> Loader Class Initialized
DEBUG - 2018-07-28 02:13:32 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 02:13:32 --> Helper loaded: url_helper
INFO - 2018-07-28 02:13:32 --> Helper loaded: form_helper
INFO - 2018-07-28 02:13:32 --> Helper loaded: date_helper
INFO - 2018-07-28 02:13:32 --> Helper loaded: util_helper
INFO - 2018-07-28 02:13:32 --> Helper loaded: text_helper
INFO - 2018-07-28 02:13:32 --> Helper loaded: string_helper
INFO - 2018-07-28 02:13:32 --> Database Driver Class Initialized
DEBUG - 2018-07-28 02:13:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 02:13:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 02:13:32 --> Email Class Initialized
INFO - 2018-07-28 02:13:32 --> Controller Class Initialized
DEBUG - 2018-07-28 02:13:32 --> Home MX_Controller Initialized
DEBUG - 2018-07-28 02:13:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-28 02:13:32 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 02:13:32 --> Login MX_Controller Initialized
INFO - 2018-07-28 02:13:32 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 02:13:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 02:13:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-28 02:13:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-28 02:13:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-28 02:13:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-28 02:13:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-28 02:13:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-28 02:13:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-28 02:13:32 --> Final output sent to browser
DEBUG - 2018-07-28 02:13:32 --> Total execution time: 0.5100
INFO - 2018-07-28 02:13:32 --> Config Class Initialized
INFO - 2018-07-28 02:13:32 --> Hooks Class Initialized
INFO - 2018-07-28 02:13:32 --> Config Class Initialized
INFO - 2018-07-28 02:13:32 --> Hooks Class Initialized
DEBUG - 2018-07-28 02:13:32 --> UTF-8 Support Enabled
DEBUG - 2018-07-28 02:13:32 --> UTF-8 Support Enabled
INFO - 2018-07-28 02:13:32 --> Utf8 Class Initialized
INFO - 2018-07-28 02:13:32 --> URI Class Initialized
INFO - 2018-07-28 02:13:32 --> Router Class Initialized
INFO - 2018-07-28 02:13:33 --> Output Class Initialized
INFO - 2018-07-28 02:13:33 --> Security Class Initialized
DEBUG - 2018-07-28 02:13:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 02:13:33 --> Input Class Initialized
INFO - 2018-07-28 02:13:33 --> Utf8 Class Initialized
INFO - 2018-07-28 02:13:33 --> Language Class Initialized
INFO - 2018-07-28 02:13:33 --> URI Class Initialized
INFO - 2018-07-28 02:13:33 --> Router Class Initialized
INFO - 2018-07-28 02:13:33 --> Language Class Initialized
INFO - 2018-07-28 02:13:33 --> Output Class Initialized
INFO - 2018-07-28 02:13:33 --> Config Class Initialized
INFO - 2018-07-28 02:13:33 --> Security Class Initialized
INFO - 2018-07-28 02:13:33 --> Loader Class Initialized
DEBUG - 2018-07-28 02:13:33 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
DEBUG - 2018-07-28 02:13:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 02:13:33 --> Input Class Initialized
INFO - 2018-07-28 02:13:33 --> Helper loaded: url_helper
INFO - 2018-07-28 02:13:33 --> Language Class Initialized
INFO - 2018-07-28 02:13:33 --> Helper loaded: form_helper
ERROR - 2018-07-28 02:13:33 --> 404 Page Not Found: /index
INFO - 2018-07-28 02:13:33 --> Helper loaded: date_helper
INFO - 2018-07-28 02:13:33 --> Helper loaded: util_helper
INFO - 2018-07-28 02:13:33 --> Config Class Initialized
INFO - 2018-07-28 02:13:33 --> Helper loaded: text_helper
INFO - 2018-07-28 02:13:33 --> Hooks Class Initialized
DEBUG - 2018-07-28 02:13:33 --> UTF-8 Support Enabled
INFO - 2018-07-28 02:13:33 --> Helper loaded: string_helper
INFO - 2018-07-28 02:13:33 --> Utf8 Class Initialized
INFO - 2018-07-28 02:13:33 --> Database Driver Class Initialized
INFO - 2018-07-28 02:13:33 --> URI Class Initialized
DEBUG - 2018-07-28 02:13:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 02:13:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 02:13:33 --> Router Class Initialized
INFO - 2018-07-28 02:13:33 --> Output Class Initialized
INFO - 2018-07-28 02:13:33 --> Email Class Initialized
INFO - 2018-07-28 02:13:33 --> Controller Class Initialized
INFO - 2018-07-28 02:13:33 --> Security Class Initialized
DEBUG - 2018-07-28 02:13:33 --> Home MX_Controller Initialized
DEBUG - 2018-07-28 02:13:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 02:13:33 --> Input Class Initialized
DEBUG - 2018-07-28 02:13:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-07-28 02:13:33 --> Language Class Initialized
DEBUG - 2018-07-28 02:13:33 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 02:13:33 --> Login MX_Controller Initialized
ERROR - 2018-07-28 02:13:33 --> 404 Page Not Found: /index
INFO - 2018-07-28 02:13:33 --> Language file loaded: language/english/data_lang.php
INFO - 2018-07-28 02:13:33 --> Config Class Initialized
INFO - 2018-07-28 02:13:33 --> Hooks Class Initialized
DEBUG - 2018-07-28 02:13:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 02:13:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-28 02:13:33 --> UTF-8 Support Enabled
INFO - 2018-07-28 02:13:33 --> Utf8 Class Initialized
INFO - 2018-07-28 02:13:33 --> URI Class Initialized
INFO - 2018-07-28 02:13:33 --> Router Class Initialized
INFO - 2018-07-28 02:13:33 --> Output Class Initialized
INFO - 2018-07-28 02:13:33 --> Security Class Initialized
DEBUG - 2018-07-28 02:13:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 02:13:33 --> Input Class Initialized
INFO - 2018-07-28 02:13:33 --> Language Class Initialized
ERROR - 2018-07-28 02:13:33 --> 404 Page Not Found: /index
INFO - 2018-07-28 02:13:33 --> Config Class Initialized
INFO - 2018-07-28 02:13:33 --> Hooks Class Initialized
DEBUG - 2018-07-28 02:13:33 --> UTF-8 Support Enabled
INFO - 2018-07-28 02:13:33 --> Utf8 Class Initialized
INFO - 2018-07-28 02:13:33 --> URI Class Initialized
INFO - 2018-07-28 02:13:33 --> Router Class Initialized
INFO - 2018-07-28 02:13:33 --> Output Class Initialized
INFO - 2018-07-28 02:13:33 --> Security Class Initialized
DEBUG - 2018-07-28 02:13:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 02:13:33 --> Input Class Initialized
INFO - 2018-07-28 02:13:33 --> Language Class Initialized
ERROR - 2018-07-28 02:13:33 --> 404 Page Not Found: /index
INFO - 2018-07-28 02:13:33 --> Config Class Initialized
INFO - 2018-07-28 02:13:33 --> Hooks Class Initialized
DEBUG - 2018-07-28 02:13:33 --> UTF-8 Support Enabled
INFO - 2018-07-28 02:13:33 --> Utf8 Class Initialized
INFO - 2018-07-28 02:13:33 --> URI Class Initialized
INFO - 2018-07-28 02:13:33 --> Router Class Initialized
INFO - 2018-07-28 02:13:33 --> Output Class Initialized
INFO - 2018-07-28 02:13:33 --> Security Class Initialized
DEBUG - 2018-07-28 02:13:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 02:13:33 --> Input Class Initialized
INFO - 2018-07-28 02:13:33 --> Language Class Initialized
ERROR - 2018-07-28 02:13:33 --> 404 Page Not Found: /index
INFO - 2018-07-28 02:13:33 --> Config Class Initialized
INFO - 2018-07-28 02:13:34 --> Hooks Class Initialized
DEBUG - 2018-07-28 02:13:34 --> UTF-8 Support Enabled
INFO - 2018-07-28 02:13:34 --> Utf8 Class Initialized
INFO - 2018-07-28 02:13:34 --> URI Class Initialized
INFO - 2018-07-28 02:13:34 --> Router Class Initialized
INFO - 2018-07-28 02:13:34 --> Output Class Initialized
INFO - 2018-07-28 02:13:34 --> Security Class Initialized
DEBUG - 2018-07-28 02:13:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 02:13:34 --> Input Class Initialized
INFO - 2018-07-28 02:13:34 --> Language Class Initialized
ERROR - 2018-07-28 02:13:34 --> 404 Page Not Found: /index
INFO - 2018-07-28 02:13:51 --> Config Class Initialized
INFO - 2018-07-28 02:13:51 --> Hooks Class Initialized
DEBUG - 2018-07-28 02:13:51 --> UTF-8 Support Enabled
INFO - 2018-07-28 02:13:51 --> Utf8 Class Initialized
INFO - 2018-07-28 02:13:51 --> URI Class Initialized
INFO - 2018-07-28 02:13:51 --> Router Class Initialized
INFO - 2018-07-28 02:13:51 --> Output Class Initialized
INFO - 2018-07-28 02:13:51 --> Security Class Initialized
DEBUG - 2018-07-28 02:13:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 02:13:51 --> Input Class Initialized
INFO - 2018-07-28 02:13:51 --> Language Class Initialized
INFO - 2018-07-28 02:13:51 --> Language Class Initialized
INFO - 2018-07-28 02:13:51 --> Config Class Initialized
INFO - 2018-07-28 02:13:51 --> Loader Class Initialized
DEBUG - 2018-07-28 02:13:51 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 02:13:51 --> Helper loaded: url_helper
INFO - 2018-07-28 02:13:51 --> Helper loaded: form_helper
INFO - 2018-07-28 02:13:51 --> Helper loaded: date_helper
INFO - 2018-07-28 02:13:51 --> Helper loaded: util_helper
INFO - 2018-07-28 02:13:51 --> Helper loaded: text_helper
INFO - 2018-07-28 02:13:51 --> Helper loaded: string_helper
INFO - 2018-07-28 02:13:51 --> Database Driver Class Initialized
DEBUG - 2018-07-28 02:13:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 02:13:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 02:13:51 --> Email Class Initialized
INFO - 2018-07-28 02:13:51 --> Controller Class Initialized
DEBUG - 2018-07-28 02:13:51 --> Home MX_Controller Initialized
DEBUG - 2018-07-28 02:13:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-28 02:13:51 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 02:13:51 --> Login MX_Controller Initialized
INFO - 2018-07-28 02:13:51 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 02:13:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 02:13:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-28 02:13:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-28 02:13:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-28 02:13:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-28 02:13:51 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-28 02:13:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-28 02:13:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-28 02:13:52 --> Final output sent to browser
DEBUG - 2018-07-28 02:13:52 --> Total execution time: 0.5275
INFO - 2018-07-28 02:13:52 --> Config Class Initialized
INFO - 2018-07-28 02:13:52 --> Hooks Class Initialized
DEBUG - 2018-07-28 02:13:52 --> UTF-8 Support Enabled
INFO - 2018-07-28 02:13:52 --> Config Class Initialized
INFO - 2018-07-28 02:13:52 --> Hooks Class Initialized
INFO - 2018-07-28 02:13:52 --> Utf8 Class Initialized
DEBUG - 2018-07-28 02:13:52 --> UTF-8 Support Enabled
INFO - 2018-07-28 02:13:52 --> Utf8 Class Initialized
INFO - 2018-07-28 02:13:52 --> URI Class Initialized
INFO - 2018-07-28 02:13:52 --> Router Class Initialized
INFO - 2018-07-28 02:13:52 --> Output Class Initialized
INFO - 2018-07-28 02:13:52 --> Security Class Initialized
DEBUG - 2018-07-28 02:13:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 02:13:52 --> Input Class Initialized
INFO - 2018-07-28 02:13:52 --> URI Class Initialized
INFO - 2018-07-28 02:13:52 --> Language Class Initialized
INFO - 2018-07-28 02:13:52 --> Router Class Initialized
INFO - 2018-07-28 02:13:52 --> Output Class Initialized
INFO - 2018-07-28 02:13:52 --> Language Class Initialized
INFO - 2018-07-28 02:13:52 --> Config Class Initialized
INFO - 2018-07-28 02:13:52 --> Security Class Initialized
INFO - 2018-07-28 02:13:52 --> Loader Class Initialized
DEBUG - 2018-07-28 02:13:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-07-28 02:13:52 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 02:13:52 --> Input Class Initialized
INFO - 2018-07-28 02:13:52 --> Helper loaded: url_helper
INFO - 2018-07-28 02:13:52 --> Language Class Initialized
ERROR - 2018-07-28 02:13:52 --> 404 Page Not Found: /index
INFO - 2018-07-28 02:13:52 --> Helper loaded: form_helper
INFO - 2018-07-28 02:13:52 --> Helper loaded: date_helper
INFO - 2018-07-28 02:13:52 --> Config Class Initialized
INFO - 2018-07-28 02:13:52 --> Hooks Class Initialized
INFO - 2018-07-28 02:13:52 --> Helper loaded: util_helper
DEBUG - 2018-07-28 02:13:52 --> UTF-8 Support Enabled
INFO - 2018-07-28 02:13:52 --> Helper loaded: text_helper
INFO - 2018-07-28 02:13:52 --> Utf8 Class Initialized
INFO - 2018-07-28 02:13:52 --> Helper loaded: string_helper
INFO - 2018-07-28 02:13:52 --> URI Class Initialized
INFO - 2018-07-28 02:13:53 --> Router Class Initialized
INFO - 2018-07-28 02:13:53 --> Database Driver Class Initialized
INFO - 2018-07-28 02:13:53 --> Output Class Initialized
DEBUG - 2018-07-28 02:13:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 02:13:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 02:13:53 --> Security Class Initialized
DEBUG - 2018-07-28 02:13:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 02:13:53 --> Email Class Initialized
INFO - 2018-07-28 02:13:53 --> Controller Class Initialized
INFO - 2018-07-28 02:13:53 --> Input Class Initialized
DEBUG - 2018-07-28 02:13:53 --> Home MX_Controller Initialized
INFO - 2018-07-28 02:13:53 --> Language Class Initialized
DEBUG - 2018-07-28 02:13:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
ERROR - 2018-07-28 02:13:53 --> 404 Page Not Found: /index
DEBUG - 2018-07-28 02:13:53 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
INFO - 2018-07-28 02:13:53 --> Config Class Initialized
DEBUG - 2018-07-28 02:13:53 --> Login MX_Controller Initialized
INFO - 2018-07-28 02:13:53 --> Hooks Class Initialized
INFO - 2018-07-28 02:13:53 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 02:13:53 --> UTF-8 Support Enabled
DEBUG - 2018-07-28 02:13:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-28 02:13:53 --> Utf8 Class Initialized
INFO - 2018-07-28 02:13:53 --> URI Class Initialized
DEBUG - 2018-07-28 02:13:53 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-28 02:13:53 --> Router Class Initialized
INFO - 2018-07-28 02:13:53 --> Output Class Initialized
INFO - 2018-07-28 02:13:53 --> Security Class Initialized
DEBUG - 2018-07-28 02:13:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 02:13:53 --> Input Class Initialized
INFO - 2018-07-28 02:13:53 --> Language Class Initialized
ERROR - 2018-07-28 02:13:53 --> 404 Page Not Found: /index
INFO - 2018-07-28 02:13:53 --> Config Class Initialized
INFO - 2018-07-28 02:13:53 --> Hooks Class Initialized
DEBUG - 2018-07-28 02:13:53 --> UTF-8 Support Enabled
INFO - 2018-07-28 02:13:53 --> Utf8 Class Initialized
INFO - 2018-07-28 02:13:53 --> URI Class Initialized
INFO - 2018-07-28 02:13:53 --> Router Class Initialized
INFO - 2018-07-28 02:13:53 --> Output Class Initialized
INFO - 2018-07-28 02:13:53 --> Security Class Initialized
DEBUG - 2018-07-28 02:13:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 02:13:53 --> Input Class Initialized
INFO - 2018-07-28 02:13:53 --> Language Class Initialized
ERROR - 2018-07-28 02:13:53 --> 404 Page Not Found: /index
INFO - 2018-07-28 02:13:53 --> Config Class Initialized
INFO - 2018-07-28 02:13:53 --> Hooks Class Initialized
DEBUG - 2018-07-28 02:13:53 --> UTF-8 Support Enabled
INFO - 2018-07-28 02:13:53 --> Utf8 Class Initialized
INFO - 2018-07-28 02:13:53 --> URI Class Initialized
INFO - 2018-07-28 02:13:53 --> Router Class Initialized
INFO - 2018-07-28 02:13:53 --> Output Class Initialized
INFO - 2018-07-28 02:13:53 --> Security Class Initialized
DEBUG - 2018-07-28 02:13:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 02:13:53 --> Input Class Initialized
INFO - 2018-07-28 02:13:53 --> Language Class Initialized
ERROR - 2018-07-28 02:13:53 --> 404 Page Not Found: /index
INFO - 2018-07-28 02:13:53 --> Config Class Initialized
INFO - 2018-07-28 02:13:53 --> Hooks Class Initialized
DEBUG - 2018-07-28 02:13:53 --> UTF-8 Support Enabled
INFO - 2018-07-28 02:13:53 --> Utf8 Class Initialized
INFO - 2018-07-28 02:13:53 --> URI Class Initialized
INFO - 2018-07-28 02:13:53 --> Router Class Initialized
INFO - 2018-07-28 02:13:53 --> Output Class Initialized
INFO - 2018-07-28 02:13:53 --> Security Class Initialized
DEBUG - 2018-07-28 02:13:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 02:13:53 --> Input Class Initialized
INFO - 2018-07-28 02:13:53 --> Language Class Initialized
ERROR - 2018-07-28 02:13:53 --> 404 Page Not Found: /index
INFO - 2018-07-28 02:14:40 --> Config Class Initialized
INFO - 2018-07-28 02:14:40 --> Hooks Class Initialized
DEBUG - 2018-07-28 02:14:40 --> UTF-8 Support Enabled
INFO - 2018-07-28 02:14:40 --> Utf8 Class Initialized
INFO - 2018-07-28 02:14:40 --> URI Class Initialized
INFO - 2018-07-28 02:14:40 --> Router Class Initialized
INFO - 2018-07-28 02:14:40 --> Output Class Initialized
INFO - 2018-07-28 02:14:40 --> Security Class Initialized
DEBUG - 2018-07-28 02:14:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 02:14:40 --> Input Class Initialized
INFO - 2018-07-28 02:14:40 --> Language Class Initialized
INFO - 2018-07-28 02:14:40 --> Language Class Initialized
INFO - 2018-07-28 02:14:40 --> Config Class Initialized
INFO - 2018-07-28 02:14:40 --> Loader Class Initialized
DEBUG - 2018-07-28 02:14:41 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 02:14:41 --> Helper loaded: url_helper
INFO - 2018-07-28 02:14:41 --> Helper loaded: form_helper
INFO - 2018-07-28 02:14:41 --> Helper loaded: date_helper
INFO - 2018-07-28 02:14:41 --> Helper loaded: util_helper
INFO - 2018-07-28 02:14:41 --> Helper loaded: text_helper
INFO - 2018-07-28 02:14:41 --> Helper loaded: string_helper
INFO - 2018-07-28 02:14:41 --> Database Driver Class Initialized
DEBUG - 2018-07-28 02:14:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 02:14:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 02:14:41 --> Email Class Initialized
INFO - 2018-07-28 02:14:41 --> Controller Class Initialized
DEBUG - 2018-07-28 02:14:41 --> Users MX_Controller Initialized
DEBUG - 2018-07-28 02:14:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 02:14:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-28 02:14:41 --> Helper loaded: file_helper
DEBUG - 2018-07-28 02:14:41 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 02:14:41 --> Login MX_Controller Initialized
INFO - 2018-07-28 02:14:41 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 02:14:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-28 02:14:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-28 02:14:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
ERROR - 2018-07-28 02:14:41 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable E:\xampp\htdocs\consulting\application\modules\admin\controllers\Users.php 323
INFO - 2018-07-28 02:14:41 --> Config Class Initialized
INFO - 2018-07-28 02:14:41 --> Hooks Class Initialized
DEBUG - 2018-07-28 02:14:41 --> UTF-8 Support Enabled
INFO - 2018-07-28 02:14:41 --> Utf8 Class Initialized
INFO - 2018-07-28 02:14:41 --> URI Class Initialized
INFO - 2018-07-28 02:14:41 --> Router Class Initialized
INFO - 2018-07-28 02:14:41 --> Output Class Initialized
INFO - 2018-07-28 02:14:41 --> Security Class Initialized
DEBUG - 2018-07-28 02:14:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 02:14:41 --> Input Class Initialized
INFO - 2018-07-28 02:14:41 --> Language Class Initialized
INFO - 2018-07-28 02:14:41 --> Language Class Initialized
INFO - 2018-07-28 02:14:41 --> Config Class Initialized
INFO - 2018-07-28 02:14:41 --> Loader Class Initialized
DEBUG - 2018-07-28 02:14:41 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 02:14:41 --> Helper loaded: url_helper
INFO - 2018-07-28 02:14:41 --> Helper loaded: form_helper
INFO - 2018-07-28 02:14:41 --> Helper loaded: date_helper
INFO - 2018-07-28 02:14:41 --> Helper loaded: util_helper
INFO - 2018-07-28 02:14:41 --> Helper loaded: text_helper
INFO - 2018-07-28 02:14:41 --> Helper loaded: string_helper
INFO - 2018-07-28 02:14:41 --> Database Driver Class Initialized
DEBUG - 2018-07-28 02:14:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 02:14:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 02:14:41 --> Email Class Initialized
INFO - 2018-07-28 02:14:41 --> Controller Class Initialized
DEBUG - 2018-07-28 02:14:41 --> Users MX_Controller Initialized
DEBUG - 2018-07-28 02:14:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 02:14:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-28 02:14:42 --> Helper loaded: file_helper
DEBUG - 2018-07-28 02:14:42 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 02:14:42 --> Login MX_Controller Initialized
INFO - 2018-07-28 02:14:42 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 02:14:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-28 02:14:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-28 02:14:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-28 02:14:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-28 02:14:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-28 02:14:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-28 02:14:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-07-28 02:14:42 --> Final output sent to browser
DEBUG - 2018-07-28 02:14:42 --> Total execution time: 0.6713
INFO - 2018-07-28 02:14:42 --> Config Class Initialized
INFO - 2018-07-28 02:14:42 --> Hooks Class Initialized
DEBUG - 2018-07-28 02:14:42 --> UTF-8 Support Enabled
INFO - 2018-07-28 02:14:42 --> Utf8 Class Initialized
INFO - 2018-07-28 02:14:42 --> URI Class Initialized
INFO - 2018-07-28 02:14:42 --> Config Class Initialized
INFO - 2018-07-28 02:14:42 --> Hooks Class Initialized
INFO - 2018-07-28 02:14:42 --> Router Class Initialized
INFO - 2018-07-28 02:14:42 --> Output Class Initialized
DEBUG - 2018-07-28 02:14:42 --> UTF-8 Support Enabled
INFO - 2018-07-28 02:14:42 --> Security Class Initialized
INFO - 2018-07-28 02:14:42 --> Utf8 Class Initialized
INFO - 2018-07-28 02:14:42 --> URI Class Initialized
DEBUG - 2018-07-28 02:14:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 02:14:42 --> Input Class Initialized
INFO - 2018-07-28 02:14:42 --> Router Class Initialized
INFO - 2018-07-28 02:14:42 --> Output Class Initialized
INFO - 2018-07-28 02:14:42 --> Language Class Initialized
INFO - 2018-07-28 02:14:42 --> Security Class Initialized
INFO - 2018-07-28 02:14:42 --> Language Class Initialized
DEBUG - 2018-07-28 02:14:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 02:14:42 --> Config Class Initialized
INFO - 2018-07-28 02:14:42 --> Input Class Initialized
INFO - 2018-07-28 02:14:42 --> Loader Class Initialized
INFO - 2018-07-28 02:14:42 --> Language Class Initialized
DEBUG - 2018-07-28 02:14:42 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 02:14:42 --> Language Class Initialized
INFO - 2018-07-28 02:14:42 --> Helper loaded: url_helper
INFO - 2018-07-28 02:14:42 --> Config Class Initialized
INFO - 2018-07-28 02:14:42 --> Helper loaded: form_helper
INFO - 2018-07-28 02:14:42 --> Loader Class Initialized
DEBUG - 2018-07-28 02:14:43 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 02:14:43 --> Helper loaded: date_helper
INFO - 2018-07-28 02:14:43 --> Helper loaded: url_helper
INFO - 2018-07-28 02:14:43 --> Helper loaded: util_helper
INFO - 2018-07-28 02:14:43 --> Helper loaded: text_helper
INFO - 2018-07-28 02:14:43 --> Helper loaded: form_helper
INFO - 2018-07-28 02:14:43 --> Helper loaded: date_helper
INFO - 2018-07-28 02:14:43 --> Helper loaded: string_helper
INFO - 2018-07-28 02:14:43 --> Helper loaded: util_helper
INFO - 2018-07-28 02:14:43 --> Helper loaded: text_helper
INFO - 2018-07-28 02:14:43 --> Database Driver Class Initialized
INFO - 2018-07-28 02:14:43 --> Helper loaded: string_helper
DEBUG - 2018-07-28 02:14:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 02:14:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 02:14:43 --> Database Driver Class Initialized
INFO - 2018-07-28 02:14:43 --> Email Class Initialized
DEBUG - 2018-07-28 02:14:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 02:14:43 --> Controller Class Initialized
DEBUG - 2018-07-28 02:14:43 --> Users MX_Controller Initialized
DEBUG - 2018-07-28 02:14:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 02:14:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-28 02:14:43 --> Helper loaded: file_helper
DEBUG - 2018-07-28 02:14:43 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 02:14:43 --> Login MX_Controller Initialized
INFO - 2018-07-28 02:14:43 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 02:14:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-28 02:14:43 --> Final output sent to browser
DEBUG - 2018-07-28 02:14:43 --> Total execution time: 0.5936
INFO - 2018-07-28 02:14:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 02:14:43 --> Email Class Initialized
INFO - 2018-07-28 02:14:43 --> Controller Class Initialized
DEBUG - 2018-07-28 02:14:43 --> Home MX_Controller Initialized
DEBUG - 2018-07-28 02:14:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-28 02:14:43 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 02:14:43 --> Login MX_Controller Initialized
INFO - 2018-07-28 02:14:43 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 02:14:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 02:14:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-28 02:14:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-28 02:14:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-28 02:14:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-28 02:14:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-28 02:14:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-28 02:14:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-28 02:14:43 --> Final output sent to browser
DEBUG - 2018-07-28 02:14:43 --> Total execution time: 0.7867
INFO - 2018-07-28 02:14:44 --> Config Class Initialized
INFO - 2018-07-28 02:14:44 --> Hooks Class Initialized
DEBUG - 2018-07-28 02:14:44 --> UTF-8 Support Enabled
INFO - 2018-07-28 02:14:44 --> Utf8 Class Initialized
INFO - 2018-07-28 02:14:44 --> Config Class Initialized
INFO - 2018-07-28 02:14:44 --> Hooks Class Initialized
INFO - 2018-07-28 02:14:44 --> URI Class Initialized
DEBUG - 2018-07-28 02:14:44 --> UTF-8 Support Enabled
INFO - 2018-07-28 02:14:44 --> Router Class Initialized
INFO - 2018-07-28 02:14:44 --> Utf8 Class Initialized
INFO - 2018-07-28 02:14:44 --> Output Class Initialized
INFO - 2018-07-28 02:14:44 --> URI Class Initialized
INFO - 2018-07-28 02:14:44 --> Security Class Initialized
INFO - 2018-07-28 02:14:44 --> Router Class Initialized
DEBUG - 2018-07-28 02:14:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 02:14:44 --> Output Class Initialized
INFO - 2018-07-28 02:14:44 --> Input Class Initialized
INFO - 2018-07-28 02:14:44 --> Language Class Initialized
INFO - 2018-07-28 02:14:44 --> Security Class Initialized
DEBUG - 2018-07-28 02:14:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-07-28 02:14:44 --> 404 Page Not Found: /index
INFO - 2018-07-28 02:14:44 --> Input Class Initialized
INFO - 2018-07-28 02:14:44 --> Config Class Initialized
INFO - 2018-07-28 02:14:44 --> Hooks Class Initialized
INFO - 2018-07-28 02:14:44 --> Language Class Initialized
DEBUG - 2018-07-28 02:14:44 --> UTF-8 Support Enabled
INFO - 2018-07-28 02:14:44 --> Language Class Initialized
INFO - 2018-07-28 02:14:44 --> Utf8 Class Initialized
INFO - 2018-07-28 02:14:44 --> Config Class Initialized
INFO - 2018-07-28 02:14:44 --> URI Class Initialized
INFO - 2018-07-28 02:14:44 --> Router Class Initialized
INFO - 2018-07-28 02:14:44 --> Loader Class Initialized
DEBUG - 2018-07-28 02:14:44 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 02:14:44 --> Output Class Initialized
INFO - 2018-07-28 02:14:44 --> Security Class Initialized
INFO - 2018-07-28 02:14:44 --> Helper loaded: url_helper
DEBUG - 2018-07-28 02:14:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 02:14:44 --> Helper loaded: form_helper
INFO - 2018-07-28 02:14:44 --> Input Class Initialized
INFO - 2018-07-28 02:14:44 --> Helper loaded: date_helper
INFO - 2018-07-28 02:14:44 --> Language Class Initialized
INFO - 2018-07-28 02:14:44 --> Helper loaded: util_helper
ERROR - 2018-07-28 02:14:44 --> 404 Page Not Found: /index
INFO - 2018-07-28 02:14:44 --> Helper loaded: text_helper
INFO - 2018-07-28 02:14:44 --> Helper loaded: string_helper
INFO - 2018-07-28 02:14:44 --> Config Class Initialized
INFO - 2018-07-28 02:14:44 --> Hooks Class Initialized
INFO - 2018-07-28 02:14:44 --> Database Driver Class Initialized
DEBUG - 2018-07-28 02:14:44 --> UTF-8 Support Enabled
DEBUG - 2018-07-28 02:14:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 02:14:44 --> Utf8 Class Initialized
INFO - 2018-07-28 02:14:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 02:14:44 --> URI Class Initialized
INFO - 2018-07-28 02:14:44 --> Email Class Initialized
INFO - 2018-07-28 02:14:44 --> Controller Class Initialized
INFO - 2018-07-28 02:14:44 --> Router Class Initialized
DEBUG - 2018-07-28 02:14:44 --> Home MX_Controller Initialized
DEBUG - 2018-07-28 02:14:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-07-28 02:14:44 --> Output Class Initialized
INFO - 2018-07-28 02:14:44 --> Security Class Initialized
DEBUG - 2018-07-28 02:14:44 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 02:14:44 --> Login MX_Controller Initialized
DEBUG - 2018-07-28 02:14:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 02:14:44 --> Input Class Initialized
INFO - 2018-07-28 02:14:44 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 02:14:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-28 02:14:44 --> Language Class Initialized
DEBUG - 2018-07-28 02:14:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
ERROR - 2018-07-28 02:14:44 --> 404 Page Not Found: /index
INFO - 2018-07-28 02:14:46 --> Config Class Initialized
INFO - 2018-07-28 02:14:46 --> Hooks Class Initialized
DEBUG - 2018-07-28 02:14:46 --> UTF-8 Support Enabled
INFO - 2018-07-28 02:14:46 --> Utf8 Class Initialized
INFO - 2018-07-28 02:14:46 --> URI Class Initialized
INFO - 2018-07-28 02:14:46 --> Router Class Initialized
INFO - 2018-07-28 02:14:46 --> Output Class Initialized
INFO - 2018-07-28 02:14:46 --> Security Class Initialized
DEBUG - 2018-07-28 02:14:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 02:14:46 --> Input Class Initialized
INFO - 2018-07-28 02:14:46 --> Language Class Initialized
INFO - 2018-07-28 02:14:46 --> Language Class Initialized
INFO - 2018-07-28 02:14:46 --> Config Class Initialized
INFO - 2018-07-28 02:14:46 --> Loader Class Initialized
DEBUG - 2018-07-28 02:14:46 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 02:14:46 --> Helper loaded: url_helper
INFO - 2018-07-28 02:14:46 --> Helper loaded: form_helper
INFO - 2018-07-28 02:14:46 --> Helper loaded: date_helper
INFO - 2018-07-28 02:14:46 --> Helper loaded: util_helper
INFO - 2018-07-28 02:14:46 --> Helper loaded: text_helper
INFO - 2018-07-28 02:14:46 --> Helper loaded: string_helper
INFO - 2018-07-28 02:14:47 --> Database Driver Class Initialized
DEBUG - 2018-07-28 02:14:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 02:14:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 02:14:47 --> Email Class Initialized
INFO - 2018-07-28 02:14:47 --> Controller Class Initialized
DEBUG - 2018-07-28 02:14:47 --> Home MX_Controller Initialized
DEBUG - 2018-07-28 02:14:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-28 02:14:47 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 02:14:47 --> Login MX_Controller Initialized
INFO - 2018-07-28 02:14:47 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 02:14:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 02:14:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-28 02:14:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-28 02:14:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-28 02:14:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-28 02:14:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-28 02:14:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-28 02:14:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-28 02:14:47 --> Final output sent to browser
DEBUG - 2018-07-28 02:14:47 --> Total execution time: 0.5631
INFO - 2018-07-28 02:14:47 --> Config Class Initialized
INFO - 2018-07-28 02:14:47 --> Hooks Class Initialized
DEBUG - 2018-07-28 02:14:47 --> UTF-8 Support Enabled
INFO - 2018-07-28 02:14:47 --> Config Class Initialized
INFO - 2018-07-28 02:14:47 --> Hooks Class Initialized
INFO - 2018-07-28 02:14:47 --> Utf8 Class Initialized
INFO - 2018-07-28 02:14:47 --> URI Class Initialized
DEBUG - 2018-07-28 02:14:47 --> UTF-8 Support Enabled
INFO - 2018-07-28 02:14:47 --> Utf8 Class Initialized
INFO - 2018-07-28 02:14:47 --> Router Class Initialized
INFO - 2018-07-28 02:14:47 --> URI Class Initialized
INFO - 2018-07-28 02:14:47 --> Router Class Initialized
INFO - 2018-07-28 02:14:47 --> Output Class Initialized
INFO - 2018-07-28 02:14:47 --> Output Class Initialized
INFO - 2018-07-28 02:14:47 --> Security Class Initialized
INFO - 2018-07-28 02:14:47 --> Security Class Initialized
DEBUG - 2018-07-28 02:14:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 02:14:47 --> Input Class Initialized
INFO - 2018-07-28 02:14:47 --> Language Class Initialized
ERROR - 2018-07-28 02:14:47 --> 404 Page Not Found: /index
INFO - 2018-07-28 02:14:47 --> Config Class Initialized
INFO - 2018-07-28 02:14:47 --> Hooks Class Initialized
DEBUG - 2018-07-28 02:14:47 --> UTF-8 Support Enabled
DEBUG - 2018-07-28 02:14:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 02:14:47 --> Utf8 Class Initialized
INFO - 2018-07-28 02:14:47 --> URI Class Initialized
INFO - 2018-07-28 02:14:47 --> Input Class Initialized
INFO - 2018-07-28 02:14:47 --> Router Class Initialized
INFO - 2018-07-28 02:14:47 --> Output Class Initialized
INFO - 2018-07-28 02:14:47 --> Language Class Initialized
INFO - 2018-07-28 02:14:48 --> Security Class Initialized
DEBUG - 2018-07-28 02:14:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 02:14:48 --> Input Class Initialized
INFO - 2018-07-28 02:14:48 --> Language Class Initialized
ERROR - 2018-07-28 02:14:48 --> 404 Page Not Found: /index
INFO - 2018-07-28 02:14:48 --> Config Class Initialized
INFO - 2018-07-28 02:14:48 --> Hooks Class Initialized
DEBUG - 2018-07-28 02:14:48 --> UTF-8 Support Enabled
INFO - 2018-07-28 02:14:48 --> Utf8 Class Initialized
INFO - 2018-07-28 02:14:48 --> URI Class Initialized
INFO - 2018-07-28 02:14:48 --> Language Class Initialized
INFO - 2018-07-28 02:14:48 --> Config Class Initialized
INFO - 2018-07-28 02:14:48 --> Router Class Initialized
INFO - 2018-07-28 02:14:48 --> Output Class Initialized
INFO - 2018-07-28 02:14:48 --> Loader Class Initialized
INFO - 2018-07-28 02:14:48 --> Security Class Initialized
DEBUG - 2018-07-28 02:14:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 02:14:48 --> Input Class Initialized
INFO - 2018-07-28 02:14:48 --> Language Class Initialized
ERROR - 2018-07-28 02:14:48 --> 404 Page Not Found: /index
DEBUG - 2018-07-28 02:14:48 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 02:14:48 --> Helper loaded: url_helper
INFO - 2018-07-28 02:14:48 --> Helper loaded: form_helper
INFO - 2018-07-28 02:14:48 --> Helper loaded: date_helper
INFO - 2018-07-28 02:14:48 --> Helper loaded: util_helper
INFO - 2018-07-28 02:14:48 --> Helper loaded: text_helper
INFO - 2018-07-28 02:14:48 --> Helper loaded: string_helper
INFO - 2018-07-28 02:14:48 --> Database Driver Class Initialized
DEBUG - 2018-07-28 02:14:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 02:14:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 02:14:48 --> Email Class Initialized
INFO - 2018-07-28 02:14:48 --> Controller Class Initialized
DEBUG - 2018-07-28 02:14:48 --> Home MX_Controller Initialized
DEBUG - 2018-07-28 02:14:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-28 02:14:48 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 02:14:48 --> Login MX_Controller Initialized
INFO - 2018-07-28 02:14:48 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 02:14:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 02:14:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-28 02:14:49 --> Config Class Initialized
INFO - 2018-07-28 02:14:49 --> Hooks Class Initialized
DEBUG - 2018-07-28 02:14:49 --> UTF-8 Support Enabled
INFO - 2018-07-28 02:14:49 --> Utf8 Class Initialized
INFO - 2018-07-28 02:14:49 --> URI Class Initialized
INFO - 2018-07-28 02:14:49 --> Router Class Initialized
INFO - 2018-07-28 02:14:49 --> Output Class Initialized
INFO - 2018-07-28 02:14:49 --> Security Class Initialized
DEBUG - 2018-07-28 02:14:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 02:14:49 --> Input Class Initialized
INFO - 2018-07-28 02:14:49 --> Language Class Initialized
INFO - 2018-07-28 02:14:49 --> Language Class Initialized
INFO - 2018-07-28 02:14:49 --> Config Class Initialized
INFO - 2018-07-28 02:14:49 --> Loader Class Initialized
DEBUG - 2018-07-28 02:14:49 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 02:14:49 --> Helper loaded: url_helper
INFO - 2018-07-28 02:14:49 --> Helper loaded: form_helper
INFO - 2018-07-28 02:14:49 --> Helper loaded: date_helper
INFO - 2018-07-28 02:14:49 --> Helper loaded: util_helper
INFO - 2018-07-28 02:14:49 --> Helper loaded: text_helper
INFO - 2018-07-28 02:14:49 --> Helper loaded: string_helper
INFO - 2018-07-28 02:14:49 --> Database Driver Class Initialized
DEBUG - 2018-07-28 02:14:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 02:14:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 02:14:49 --> Email Class Initialized
INFO - 2018-07-28 02:14:49 --> Controller Class Initialized
DEBUG - 2018-07-28 02:14:49 --> Users MX_Controller Initialized
DEBUG - 2018-07-28 02:14:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 02:14:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-28 02:14:49 --> Helper loaded: file_helper
DEBUG - 2018-07-28 02:14:50 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 02:14:50 --> Login MX_Controller Initialized
INFO - 2018-07-28 02:14:50 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 02:14:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-28 02:14:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-28 02:14:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-28 02:14:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-28 02:14:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-28 02:14:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-28 02:14:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-28 02:14:50 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-07-28 02:14:50 --> Final output sent to browser
DEBUG - 2018-07-28 02:14:50 --> Total execution time: 0.6253
INFO - 2018-07-28 02:14:51 --> Config Class Initialized
INFO - 2018-07-28 02:14:51 --> Hooks Class Initialized
DEBUG - 2018-07-28 02:14:51 --> UTF-8 Support Enabled
INFO - 2018-07-28 02:14:51 --> Utf8 Class Initialized
INFO - 2018-07-28 02:14:51 --> URI Class Initialized
INFO - 2018-07-28 02:14:51 --> Router Class Initialized
INFO - 2018-07-28 02:14:51 --> Output Class Initialized
INFO - 2018-07-28 02:14:51 --> Security Class Initialized
DEBUG - 2018-07-28 02:14:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 02:14:52 --> Input Class Initialized
INFO - 2018-07-28 02:14:52 --> Language Class Initialized
INFO - 2018-07-28 02:14:52 --> Language Class Initialized
INFO - 2018-07-28 02:14:52 --> Config Class Initialized
INFO - 2018-07-28 02:14:52 --> Loader Class Initialized
DEBUG - 2018-07-28 02:14:52 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 02:14:52 --> Helper loaded: url_helper
INFO - 2018-07-28 02:14:52 --> Helper loaded: form_helper
INFO - 2018-07-28 02:14:52 --> Helper loaded: date_helper
INFO - 2018-07-28 02:14:52 --> Helper loaded: util_helper
INFO - 2018-07-28 02:14:52 --> Helper loaded: text_helper
INFO - 2018-07-28 02:14:52 --> Helper loaded: string_helper
INFO - 2018-07-28 02:14:52 --> Database Driver Class Initialized
DEBUG - 2018-07-28 02:14:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 02:14:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 02:14:52 --> Email Class Initialized
INFO - 2018-07-28 02:14:52 --> Controller Class Initialized
DEBUG - 2018-07-28 02:14:52 --> Users MX_Controller Initialized
DEBUG - 2018-07-28 02:14:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 02:14:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-28 02:14:52 --> Helper loaded: file_helper
DEBUG - 2018-07-28 02:14:52 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 02:14:52 --> Login MX_Controller Initialized
INFO - 2018-07-28 02:14:52 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 02:14:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-28 02:14:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-28 02:14:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-28 02:14:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-28 02:14:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-28 02:14:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-28 02:14:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-28 02:14:52 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-07-28 02:14:52 --> Final output sent to browser
DEBUG - 2018-07-28 02:14:52 --> Total execution time: 0.6285
INFO - 2018-07-28 02:15:58 --> Config Class Initialized
INFO - 2018-07-28 02:15:58 --> Hooks Class Initialized
DEBUG - 2018-07-28 02:15:58 --> UTF-8 Support Enabled
INFO - 2018-07-28 02:15:58 --> Utf8 Class Initialized
INFO - 2018-07-28 02:15:58 --> URI Class Initialized
INFO - 2018-07-28 02:15:58 --> Router Class Initialized
INFO - 2018-07-28 02:15:58 --> Output Class Initialized
INFO - 2018-07-28 02:15:58 --> Security Class Initialized
DEBUG - 2018-07-28 02:15:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 02:15:58 --> Input Class Initialized
INFO - 2018-07-28 02:15:58 --> Language Class Initialized
INFO - 2018-07-28 02:15:58 --> Language Class Initialized
INFO - 2018-07-28 02:15:58 --> Config Class Initialized
INFO - 2018-07-28 02:15:58 --> Loader Class Initialized
DEBUG - 2018-07-28 02:15:58 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 02:15:58 --> Helper loaded: url_helper
INFO - 2018-07-28 02:15:58 --> Helper loaded: form_helper
INFO - 2018-07-28 02:15:58 --> Helper loaded: date_helper
INFO - 2018-07-28 02:15:58 --> Helper loaded: util_helper
INFO - 2018-07-28 02:15:58 --> Helper loaded: text_helper
INFO - 2018-07-28 02:15:58 --> Helper loaded: string_helper
INFO - 2018-07-28 02:15:58 --> Database Driver Class Initialized
DEBUG - 2018-07-28 02:15:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 02:15:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 02:15:58 --> Email Class Initialized
INFO - 2018-07-28 02:15:58 --> Controller Class Initialized
DEBUG - 2018-07-28 02:15:58 --> Users MX_Controller Initialized
DEBUG - 2018-07-28 02:15:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 02:15:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-28 02:15:58 --> Helper loaded: file_helper
DEBUG - 2018-07-28 02:15:58 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 02:15:58 --> Login MX_Controller Initialized
INFO - 2018-07-28 02:15:58 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 02:15:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-28 02:15:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-28 02:15:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
INFO - 2018-07-28 02:15:58 --> Config Class Initialized
INFO - 2018-07-28 02:15:58 --> Hooks Class Initialized
DEBUG - 2018-07-28 02:15:58 --> UTF-8 Support Enabled
INFO - 2018-07-28 02:15:58 --> Utf8 Class Initialized
INFO - 2018-07-28 02:15:58 --> URI Class Initialized
INFO - 2018-07-28 02:15:58 --> Router Class Initialized
INFO - 2018-07-28 02:15:58 --> Output Class Initialized
INFO - 2018-07-28 02:15:58 --> Security Class Initialized
DEBUG - 2018-07-28 02:15:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 02:15:58 --> Input Class Initialized
INFO - 2018-07-28 02:15:58 --> Language Class Initialized
INFO - 2018-07-28 02:15:58 --> Language Class Initialized
INFO - 2018-07-28 02:15:58 --> Config Class Initialized
INFO - 2018-07-28 02:15:58 --> Loader Class Initialized
DEBUG - 2018-07-28 02:15:58 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 02:15:58 --> Helper loaded: url_helper
INFO - 2018-07-28 02:15:58 --> Helper loaded: form_helper
INFO - 2018-07-28 02:15:59 --> Helper loaded: date_helper
INFO - 2018-07-28 02:15:59 --> Helper loaded: util_helper
INFO - 2018-07-28 02:15:59 --> Helper loaded: text_helper
INFO - 2018-07-28 02:15:59 --> Helper loaded: string_helper
INFO - 2018-07-28 02:15:59 --> Database Driver Class Initialized
DEBUG - 2018-07-28 02:15:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 02:15:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 02:15:59 --> Email Class Initialized
INFO - 2018-07-28 02:15:59 --> Controller Class Initialized
DEBUG - 2018-07-28 02:15:59 --> Users MX_Controller Initialized
DEBUG - 2018-07-28 02:15:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 02:15:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-28 02:15:59 --> Helper loaded: file_helper
DEBUG - 2018-07-28 02:15:59 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 02:15:59 --> Login MX_Controller Initialized
INFO - 2018-07-28 02:15:59 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 02:15:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-28 02:15:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-28 02:15:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-28 02:15:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-28 02:15:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-28 02:15:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-28 02:15:59 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-07-28 02:15:59 --> Final output sent to browser
DEBUG - 2018-07-28 02:15:59 --> Total execution time: 0.5553
INFO - 2018-07-28 02:15:59 --> Config Class Initialized
INFO - 2018-07-28 02:15:59 --> Hooks Class Initialized
DEBUG - 2018-07-28 02:15:59 --> UTF-8 Support Enabled
INFO - 2018-07-28 02:15:59 --> Utf8 Class Initialized
INFO - 2018-07-28 02:15:59 --> URI Class Initialized
INFO - 2018-07-28 02:15:59 --> Router Class Initialized
INFO - 2018-07-28 02:15:59 --> Output Class Initialized
INFO - 2018-07-28 02:15:59 --> Security Class Initialized
DEBUG - 2018-07-28 02:15:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 02:15:59 --> Input Class Initialized
INFO - 2018-07-28 02:15:59 --> Language Class Initialized
INFO - 2018-07-28 02:15:59 --> Language Class Initialized
INFO - 2018-07-28 02:15:59 --> Config Class Initialized
INFO - 2018-07-28 02:15:59 --> Loader Class Initialized
DEBUG - 2018-07-28 02:15:59 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 02:15:59 --> Helper loaded: url_helper
INFO - 2018-07-28 02:16:00 --> Helper loaded: form_helper
INFO - 2018-07-28 02:16:00 --> Helper loaded: date_helper
INFO - 2018-07-28 02:16:00 --> Helper loaded: util_helper
INFO - 2018-07-28 02:16:00 --> Helper loaded: text_helper
INFO - 2018-07-28 02:16:00 --> Helper loaded: string_helper
INFO - 2018-07-28 02:16:00 --> Database Driver Class Initialized
DEBUG - 2018-07-28 02:16:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 02:16:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 02:16:00 --> Email Class Initialized
INFO - 2018-07-28 02:16:00 --> Controller Class Initialized
DEBUG - 2018-07-28 02:16:00 --> Users MX_Controller Initialized
DEBUG - 2018-07-28 02:16:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 02:16:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-28 02:16:00 --> Helper loaded: file_helper
DEBUG - 2018-07-28 02:16:00 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 02:16:00 --> Login MX_Controller Initialized
INFO - 2018-07-28 02:16:00 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 02:16:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-28 02:16:00 --> Final output sent to browser
DEBUG - 2018-07-28 02:16:00 --> Total execution time: 0.6295
INFO - 2018-07-28 02:16:19 --> Config Class Initialized
INFO - 2018-07-28 02:16:19 --> Hooks Class Initialized
DEBUG - 2018-07-28 02:16:19 --> UTF-8 Support Enabled
INFO - 2018-07-28 02:16:19 --> Utf8 Class Initialized
INFO - 2018-07-28 02:16:19 --> URI Class Initialized
INFO - 2018-07-28 02:16:19 --> Router Class Initialized
INFO - 2018-07-28 02:16:19 --> Output Class Initialized
INFO - 2018-07-28 02:16:19 --> Security Class Initialized
DEBUG - 2018-07-28 02:16:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 02:16:19 --> Input Class Initialized
INFO - 2018-07-28 02:16:19 --> Language Class Initialized
INFO - 2018-07-28 02:16:19 --> Language Class Initialized
INFO - 2018-07-28 02:16:19 --> Config Class Initialized
INFO - 2018-07-28 02:16:19 --> Loader Class Initialized
DEBUG - 2018-07-28 02:16:19 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 02:16:19 --> Helper loaded: url_helper
INFO - 2018-07-28 02:16:19 --> Helper loaded: form_helper
INFO - 2018-07-28 02:16:19 --> Helper loaded: date_helper
INFO - 2018-07-28 02:16:19 --> Helper loaded: util_helper
INFO - 2018-07-28 02:16:19 --> Helper loaded: text_helper
INFO - 2018-07-28 02:16:19 --> Helper loaded: string_helper
INFO - 2018-07-28 02:16:19 --> Database Driver Class Initialized
DEBUG - 2018-07-28 02:16:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 02:16:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 02:16:19 --> Email Class Initialized
INFO - 2018-07-28 02:16:19 --> Controller Class Initialized
DEBUG - 2018-07-28 02:16:19 --> Users MX_Controller Initialized
DEBUG - 2018-07-28 02:16:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 02:16:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-28 02:16:19 --> Helper loaded: file_helper
DEBUG - 2018-07-28 02:16:19 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 02:16:19 --> Login MX_Controller Initialized
INFO - 2018-07-28 02:16:19 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 02:16:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-28 02:16:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-28 02:16:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-28 02:16:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-28 02:16:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-28 02:16:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-28 02:16:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-28 02:16:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-07-28 02:16:19 --> Final output sent to browser
DEBUG - 2018-07-28 02:16:19 --> Total execution time: 0.5868
INFO - 2018-07-28 02:16:21 --> Config Class Initialized
INFO - 2018-07-28 02:16:21 --> Hooks Class Initialized
DEBUG - 2018-07-28 02:16:21 --> UTF-8 Support Enabled
INFO - 2018-07-28 02:16:21 --> Utf8 Class Initialized
INFO - 2018-07-28 02:16:21 --> URI Class Initialized
INFO - 2018-07-28 02:16:21 --> Router Class Initialized
INFO - 2018-07-28 02:16:21 --> Output Class Initialized
INFO - 2018-07-28 02:16:21 --> Security Class Initialized
DEBUG - 2018-07-28 02:16:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 02:16:21 --> Input Class Initialized
INFO - 2018-07-28 02:16:21 --> Language Class Initialized
INFO - 2018-07-28 02:16:21 --> Language Class Initialized
INFO - 2018-07-28 02:16:21 --> Config Class Initialized
INFO - 2018-07-28 02:16:21 --> Loader Class Initialized
DEBUG - 2018-07-28 02:16:21 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 02:16:21 --> Helper loaded: url_helper
INFO - 2018-07-28 02:16:21 --> Helper loaded: form_helper
INFO - 2018-07-28 02:16:21 --> Helper loaded: date_helper
INFO - 2018-07-28 02:16:21 --> Helper loaded: util_helper
INFO - 2018-07-28 02:16:21 --> Helper loaded: text_helper
INFO - 2018-07-28 02:16:21 --> Helper loaded: string_helper
INFO - 2018-07-28 02:16:21 --> Database Driver Class Initialized
DEBUG - 2018-07-28 02:16:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 02:16:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 02:16:21 --> Email Class Initialized
INFO - 2018-07-28 02:16:21 --> Controller Class Initialized
DEBUG - 2018-07-28 02:16:21 --> Users MX_Controller Initialized
DEBUG - 2018-07-28 02:16:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 02:16:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-28 02:16:22 --> Helper loaded: file_helper
DEBUG - 2018-07-28 02:16:22 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 02:16:22 --> Login MX_Controller Initialized
INFO - 2018-07-28 02:16:22 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 02:16:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-28 02:16:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-28 02:16:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-28 02:16:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-28 02:16:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-28 02:16:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-28 02:16:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-28 02:16:22 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-07-28 02:16:22 --> Final output sent to browser
DEBUG - 2018-07-28 02:16:22 --> Total execution time: 0.5788
INFO - 2018-07-28 02:16:28 --> Config Class Initialized
INFO - 2018-07-28 02:16:28 --> Hooks Class Initialized
DEBUG - 2018-07-28 02:16:28 --> UTF-8 Support Enabled
INFO - 2018-07-28 02:16:28 --> Utf8 Class Initialized
INFO - 2018-07-28 02:16:28 --> URI Class Initialized
INFO - 2018-07-28 02:16:28 --> Router Class Initialized
INFO - 2018-07-28 02:16:28 --> Output Class Initialized
INFO - 2018-07-28 02:16:28 --> Security Class Initialized
DEBUG - 2018-07-28 02:16:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 02:16:28 --> Input Class Initialized
INFO - 2018-07-28 02:16:28 --> Language Class Initialized
INFO - 2018-07-28 02:16:28 --> Language Class Initialized
INFO - 2018-07-28 02:16:28 --> Config Class Initialized
INFO - 2018-07-28 02:16:28 --> Loader Class Initialized
DEBUG - 2018-07-28 02:16:28 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 02:16:28 --> Helper loaded: url_helper
INFO - 2018-07-28 02:16:28 --> Helper loaded: form_helper
INFO - 2018-07-28 02:16:29 --> Helper loaded: date_helper
INFO - 2018-07-28 02:16:29 --> Helper loaded: util_helper
INFO - 2018-07-28 02:16:29 --> Helper loaded: text_helper
INFO - 2018-07-28 02:16:29 --> Helper loaded: string_helper
INFO - 2018-07-28 02:16:29 --> Database Driver Class Initialized
DEBUG - 2018-07-28 02:16:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 02:16:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 02:16:29 --> Email Class Initialized
INFO - 2018-07-28 02:16:29 --> Controller Class Initialized
DEBUG - 2018-07-28 02:16:29 --> Home MX_Controller Initialized
DEBUG - 2018-07-28 02:16:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-28 02:16:29 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 02:16:29 --> Login MX_Controller Initialized
INFO - 2018-07-28 02:16:29 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 02:16:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 02:16:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-28 02:16:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-28 02:16:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-28 02:16:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-28 02:16:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-28 02:16:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-28 02:16:29 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-28 02:16:29 --> Final output sent to browser
DEBUG - 2018-07-28 02:16:29 --> Total execution time: 0.5873
INFO - 2018-07-28 02:16:29 --> Config Class Initialized
INFO - 2018-07-28 02:16:29 --> Hooks Class Initialized
INFO - 2018-07-28 02:16:29 --> Config Class Initialized
INFO - 2018-07-28 02:16:30 --> Hooks Class Initialized
DEBUG - 2018-07-28 02:16:30 --> UTF-8 Support Enabled
DEBUG - 2018-07-28 02:16:30 --> UTF-8 Support Enabled
INFO - 2018-07-28 02:16:30 --> Utf8 Class Initialized
INFO - 2018-07-28 02:16:30 --> URI Class Initialized
INFO - 2018-07-28 02:16:30 --> Router Class Initialized
INFO - 2018-07-28 02:16:30 --> Output Class Initialized
INFO - 2018-07-28 02:16:30 --> Security Class Initialized
DEBUG - 2018-07-28 02:16:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 02:16:30 --> Utf8 Class Initialized
INFO - 2018-07-28 02:16:30 --> URI Class Initialized
INFO - 2018-07-28 02:16:30 --> Input Class Initialized
INFO - 2018-07-28 02:16:30 --> Router Class Initialized
INFO - 2018-07-28 02:16:30 --> Output Class Initialized
INFO - 2018-07-28 02:16:30 --> Language Class Initialized
INFO - 2018-07-28 02:16:30 --> Security Class Initialized
DEBUG - 2018-07-28 02:16:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 02:16:30 --> Language Class Initialized
INFO - 2018-07-28 02:16:30 --> Input Class Initialized
INFO - 2018-07-28 02:16:30 --> Config Class Initialized
INFO - 2018-07-28 02:16:30 --> Language Class Initialized
INFO - 2018-07-28 02:16:30 --> Loader Class Initialized
ERROR - 2018-07-28 02:16:30 --> 404 Page Not Found: /index
DEBUG - 2018-07-28 02:16:30 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 02:16:30 --> Helper loaded: url_helper
INFO - 2018-07-28 02:16:30 --> Config Class Initialized
INFO - 2018-07-28 02:16:30 --> Helper loaded: form_helper
INFO - 2018-07-28 02:16:30 --> Hooks Class Initialized
INFO - 2018-07-28 02:16:30 --> Helper loaded: date_helper
DEBUG - 2018-07-28 02:16:30 --> UTF-8 Support Enabled
INFO - 2018-07-28 02:16:30 --> Helper loaded: util_helper
INFO - 2018-07-28 02:16:30 --> Utf8 Class Initialized
INFO - 2018-07-28 02:16:30 --> Helper loaded: text_helper
INFO - 2018-07-28 02:16:30 --> URI Class Initialized
INFO - 2018-07-28 02:16:30 --> Helper loaded: string_helper
INFO - 2018-07-28 02:16:30 --> Router Class Initialized
INFO - 2018-07-28 02:16:30 --> Output Class Initialized
INFO - 2018-07-28 02:16:30 --> Database Driver Class Initialized
INFO - 2018-07-28 02:16:30 --> Security Class Initialized
DEBUG - 2018-07-28 02:16:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 02:16:30 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-07-28 02:16:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 02:16:30 --> Input Class Initialized
INFO - 2018-07-28 02:16:30 --> Email Class Initialized
INFO - 2018-07-28 02:16:30 --> Controller Class Initialized
INFO - 2018-07-28 02:16:30 --> Language Class Initialized
DEBUG - 2018-07-28 02:16:30 --> Home MX_Controller Initialized
ERROR - 2018-07-28 02:16:30 --> 404 Page Not Found: /index
DEBUG - 2018-07-28 02:16:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-07-28 02:16:30 --> Config Class Initialized
INFO - 2018-07-28 02:16:30 --> Hooks Class Initialized
DEBUG - 2018-07-28 02:16:30 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 02:16:30 --> Login MX_Controller Initialized
DEBUG - 2018-07-28 02:16:30 --> UTF-8 Support Enabled
INFO - 2018-07-28 02:16:30 --> Utf8 Class Initialized
INFO - 2018-07-28 02:16:30 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 02:16:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-28 02:16:30 --> URI Class Initialized
DEBUG - 2018-07-28 02:16:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-28 02:16:30 --> Router Class Initialized
INFO - 2018-07-28 02:16:30 --> Output Class Initialized
INFO - 2018-07-28 02:16:30 --> Security Class Initialized
DEBUG - 2018-07-28 02:16:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 02:16:30 --> Input Class Initialized
INFO - 2018-07-28 02:16:30 --> Language Class Initialized
ERROR - 2018-07-28 02:16:30 --> 404 Page Not Found: /index
INFO - 2018-07-28 02:16:30 --> Config Class Initialized
INFO - 2018-07-28 02:16:30 --> Hooks Class Initialized
DEBUG - 2018-07-28 02:16:30 --> UTF-8 Support Enabled
INFO - 2018-07-28 02:16:30 --> Utf8 Class Initialized
INFO - 2018-07-28 02:16:30 --> URI Class Initialized
INFO - 2018-07-28 02:16:30 --> Router Class Initialized
INFO - 2018-07-28 02:16:30 --> Output Class Initialized
INFO - 2018-07-28 02:16:30 --> Security Class Initialized
DEBUG - 2018-07-28 02:16:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 02:16:30 --> Input Class Initialized
INFO - 2018-07-28 02:16:30 --> Language Class Initialized
ERROR - 2018-07-28 02:16:30 --> 404 Page Not Found: /index
INFO - 2018-07-28 02:16:30 --> Config Class Initialized
INFO - 2018-07-28 02:16:30 --> Hooks Class Initialized
DEBUG - 2018-07-28 02:16:31 --> UTF-8 Support Enabled
INFO - 2018-07-28 02:16:31 --> Utf8 Class Initialized
INFO - 2018-07-28 02:16:31 --> URI Class Initialized
INFO - 2018-07-28 02:16:31 --> Router Class Initialized
INFO - 2018-07-28 02:16:31 --> Output Class Initialized
INFO - 2018-07-28 02:16:31 --> Security Class Initialized
DEBUG - 2018-07-28 02:16:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 02:16:31 --> Input Class Initialized
INFO - 2018-07-28 02:16:31 --> Language Class Initialized
ERROR - 2018-07-28 02:16:31 --> 404 Page Not Found: /index
INFO - 2018-07-28 02:16:31 --> Config Class Initialized
INFO - 2018-07-28 02:16:31 --> Hooks Class Initialized
DEBUG - 2018-07-28 02:16:31 --> UTF-8 Support Enabled
INFO - 2018-07-28 02:16:31 --> Utf8 Class Initialized
INFO - 2018-07-28 02:16:31 --> URI Class Initialized
INFO - 2018-07-28 02:16:31 --> Router Class Initialized
INFO - 2018-07-28 02:16:31 --> Output Class Initialized
INFO - 2018-07-28 02:16:31 --> Security Class Initialized
DEBUG - 2018-07-28 02:16:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 02:16:31 --> Input Class Initialized
INFO - 2018-07-28 02:16:31 --> Language Class Initialized
ERROR - 2018-07-28 02:16:31 --> 404 Page Not Found: /index
INFO - 2018-07-28 02:17:08 --> Config Class Initialized
INFO - 2018-07-28 02:17:09 --> Hooks Class Initialized
DEBUG - 2018-07-28 02:17:09 --> UTF-8 Support Enabled
INFO - 2018-07-28 02:17:09 --> Utf8 Class Initialized
INFO - 2018-07-28 02:17:09 --> URI Class Initialized
INFO - 2018-07-28 02:17:09 --> Router Class Initialized
INFO - 2018-07-28 02:17:09 --> Output Class Initialized
INFO - 2018-07-28 02:17:09 --> Security Class Initialized
DEBUG - 2018-07-28 02:17:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 02:17:09 --> Input Class Initialized
INFO - 2018-07-28 02:17:09 --> Language Class Initialized
INFO - 2018-07-28 02:17:09 --> Language Class Initialized
INFO - 2018-07-28 02:17:09 --> Config Class Initialized
INFO - 2018-07-28 02:17:09 --> Loader Class Initialized
DEBUG - 2018-07-28 02:17:09 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 02:17:09 --> Helper loaded: url_helper
INFO - 2018-07-28 02:17:09 --> Helper loaded: form_helper
INFO - 2018-07-28 02:17:09 --> Helper loaded: date_helper
INFO - 2018-07-28 02:17:09 --> Helper loaded: util_helper
INFO - 2018-07-28 02:17:09 --> Helper loaded: text_helper
INFO - 2018-07-28 02:17:09 --> Helper loaded: string_helper
INFO - 2018-07-28 02:17:09 --> Database Driver Class Initialized
DEBUG - 2018-07-28 02:17:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 02:17:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 02:17:09 --> Email Class Initialized
INFO - 2018-07-28 02:17:09 --> Controller Class Initialized
DEBUG - 2018-07-28 02:17:09 --> Home MX_Controller Initialized
DEBUG - 2018-07-28 02:17:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-28 02:17:09 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 02:17:09 --> Login MX_Controller Initialized
INFO - 2018-07-28 02:17:09 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 02:17:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 02:17:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-28 02:17:31 --> Config Class Initialized
INFO - 2018-07-28 02:17:31 --> Hooks Class Initialized
DEBUG - 2018-07-28 02:17:31 --> UTF-8 Support Enabled
INFO - 2018-07-28 02:17:31 --> Utf8 Class Initialized
INFO - 2018-07-28 02:17:31 --> URI Class Initialized
INFO - 2018-07-28 02:17:31 --> Router Class Initialized
INFO - 2018-07-28 02:17:31 --> Output Class Initialized
INFO - 2018-07-28 02:17:31 --> Security Class Initialized
DEBUG - 2018-07-28 02:17:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 02:17:31 --> Input Class Initialized
INFO - 2018-07-28 02:17:31 --> Language Class Initialized
INFO - 2018-07-28 02:17:31 --> Language Class Initialized
INFO - 2018-07-28 02:17:31 --> Config Class Initialized
INFO - 2018-07-28 02:17:31 --> Loader Class Initialized
DEBUG - 2018-07-28 02:17:31 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 02:17:31 --> Helper loaded: url_helper
INFO - 2018-07-28 02:17:31 --> Helper loaded: form_helper
INFO - 2018-07-28 02:17:31 --> Helper loaded: date_helper
INFO - 2018-07-28 02:17:31 --> Helper loaded: util_helper
INFO - 2018-07-28 02:17:31 --> Helper loaded: text_helper
INFO - 2018-07-28 02:17:31 --> Helper loaded: string_helper
INFO - 2018-07-28 02:17:31 --> Database Driver Class Initialized
DEBUG - 2018-07-28 02:17:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 02:17:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 02:17:31 --> Email Class Initialized
INFO - 2018-07-28 02:17:31 --> Controller Class Initialized
DEBUG - 2018-07-28 02:17:31 --> Home MX_Controller Initialized
DEBUG - 2018-07-28 02:17:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-28 02:17:31 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 02:17:31 --> Login MX_Controller Initialized
INFO - 2018-07-28 02:17:31 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 02:17:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 02:17:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-28 02:17:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-28 02:17:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-28 02:17:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-28 02:17:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-28 02:17:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-28 02:17:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-28 02:17:31 --> Final output sent to browser
DEBUG - 2018-07-28 02:17:32 --> Total execution time: 0.5808
INFO - 2018-07-28 02:17:32 --> Config Class Initialized
INFO - 2018-07-28 02:17:32 --> Hooks Class Initialized
INFO - 2018-07-28 02:17:32 --> Config Class Initialized
INFO - 2018-07-28 02:17:32 --> Hooks Class Initialized
DEBUG - 2018-07-28 02:17:32 --> UTF-8 Support Enabled
DEBUG - 2018-07-28 02:17:32 --> UTF-8 Support Enabled
INFO - 2018-07-28 02:17:32 --> Utf8 Class Initialized
INFO - 2018-07-28 02:17:32 --> URI Class Initialized
INFO - 2018-07-28 02:17:32 --> Router Class Initialized
INFO - 2018-07-28 02:17:32 --> Output Class Initialized
INFO - 2018-07-28 02:17:32 --> Security Class Initialized
DEBUG - 2018-07-28 02:17:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 02:17:32 --> Input Class Initialized
INFO - 2018-07-28 02:17:32 --> Language Class Initialized
INFO - 2018-07-28 02:17:32 --> Utf8 Class Initialized
INFO - 2018-07-28 02:17:32 --> Language Class Initialized
INFO - 2018-07-28 02:17:32 --> URI Class Initialized
INFO - 2018-07-28 02:17:32 --> Config Class Initialized
INFO - 2018-07-28 02:17:32 --> Router Class Initialized
INFO - 2018-07-28 02:17:32 --> Output Class Initialized
INFO - 2018-07-28 02:17:32 --> Loader Class Initialized
INFO - 2018-07-28 02:17:32 --> Security Class Initialized
DEBUG - 2018-07-28 02:17:32 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 02:17:32 --> Helper loaded: url_helper
DEBUG - 2018-07-28 02:17:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 02:17:32 --> Helper loaded: form_helper
INFO - 2018-07-28 02:17:32 --> Input Class Initialized
INFO - 2018-07-28 02:17:32 --> Language Class Initialized
INFO - 2018-07-28 02:17:32 --> Helper loaded: date_helper
ERROR - 2018-07-28 02:17:33 --> 404 Page Not Found: /index
INFO - 2018-07-28 02:17:33 --> Helper loaded: util_helper
INFO - 2018-07-28 02:17:33 --> Helper loaded: text_helper
INFO - 2018-07-28 02:17:33 --> Config Class Initialized
INFO - 2018-07-28 02:17:33 --> Hooks Class Initialized
INFO - 2018-07-28 02:17:33 --> Helper loaded: string_helper
DEBUG - 2018-07-28 02:17:33 --> UTF-8 Support Enabled
INFO - 2018-07-28 02:17:33 --> Database Driver Class Initialized
INFO - 2018-07-28 02:17:33 --> Utf8 Class Initialized
INFO - 2018-07-28 02:17:33 --> URI Class Initialized
DEBUG - 2018-07-28 02:17:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 02:17:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 02:17:33 --> Router Class Initialized
INFO - 2018-07-28 02:17:33 --> Output Class Initialized
INFO - 2018-07-28 02:17:33 --> Email Class Initialized
INFO - 2018-07-28 02:17:33 --> Controller Class Initialized
INFO - 2018-07-28 02:17:33 --> Security Class Initialized
DEBUG - 2018-07-28 02:17:33 --> Home MX_Controller Initialized
DEBUG - 2018-07-28 02:17:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 02:17:33 --> Input Class Initialized
DEBUG - 2018-07-28 02:17:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-07-28 02:17:33 --> Language Class Initialized
DEBUG - 2018-07-28 02:17:33 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 02:17:33 --> Login MX_Controller Initialized
ERROR - 2018-07-28 02:17:33 --> 404 Page Not Found: /index
INFO - 2018-07-28 02:17:33 --> Language file loaded: language/english/data_lang.php
INFO - 2018-07-28 02:17:33 --> Config Class Initialized
INFO - 2018-07-28 02:17:33 --> Hooks Class Initialized
DEBUG - 2018-07-28 02:17:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 02:17:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-28 02:17:33 --> UTF-8 Support Enabled
INFO - 2018-07-28 02:17:33 --> Utf8 Class Initialized
INFO - 2018-07-28 02:17:33 --> URI Class Initialized
INFO - 2018-07-28 02:17:33 --> Router Class Initialized
INFO - 2018-07-28 02:17:33 --> Output Class Initialized
INFO - 2018-07-28 02:17:33 --> Security Class Initialized
DEBUG - 2018-07-28 02:17:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 02:17:33 --> Input Class Initialized
INFO - 2018-07-28 02:17:33 --> Language Class Initialized
ERROR - 2018-07-28 02:17:33 --> 404 Page Not Found: /index
INFO - 2018-07-28 02:17:33 --> Config Class Initialized
INFO - 2018-07-28 02:17:33 --> Hooks Class Initialized
DEBUG - 2018-07-28 02:17:33 --> UTF-8 Support Enabled
INFO - 2018-07-28 02:17:33 --> Utf8 Class Initialized
INFO - 2018-07-28 02:17:33 --> URI Class Initialized
INFO - 2018-07-28 02:17:33 --> Router Class Initialized
INFO - 2018-07-28 02:17:33 --> Output Class Initialized
INFO - 2018-07-28 02:17:33 --> Security Class Initialized
DEBUG - 2018-07-28 02:17:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 02:17:33 --> Input Class Initialized
INFO - 2018-07-28 02:17:33 --> Language Class Initialized
ERROR - 2018-07-28 02:17:33 --> 404 Page Not Found: /index
INFO - 2018-07-28 02:17:33 --> Config Class Initialized
INFO - 2018-07-28 02:17:33 --> Hooks Class Initialized
DEBUG - 2018-07-28 02:17:33 --> UTF-8 Support Enabled
INFO - 2018-07-28 02:17:33 --> Utf8 Class Initialized
INFO - 2018-07-28 02:17:33 --> URI Class Initialized
INFO - 2018-07-28 02:17:33 --> Router Class Initialized
INFO - 2018-07-28 02:17:33 --> Output Class Initialized
INFO - 2018-07-28 02:17:33 --> Security Class Initialized
DEBUG - 2018-07-28 02:17:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 02:17:33 --> Input Class Initialized
INFO - 2018-07-28 02:17:33 --> Language Class Initialized
ERROR - 2018-07-28 02:17:33 --> 404 Page Not Found: /index
INFO - 2018-07-28 02:17:36 --> Config Class Initialized
INFO - 2018-07-28 02:17:36 --> Hooks Class Initialized
DEBUG - 2018-07-28 02:17:36 --> UTF-8 Support Enabled
INFO - 2018-07-28 02:17:36 --> Utf8 Class Initialized
INFO - 2018-07-28 02:17:36 --> URI Class Initialized
INFO - 2018-07-28 02:17:36 --> Router Class Initialized
INFO - 2018-07-28 02:17:36 --> Output Class Initialized
INFO - 2018-07-28 02:17:36 --> Security Class Initialized
DEBUG - 2018-07-28 02:17:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 02:17:36 --> Input Class Initialized
INFO - 2018-07-28 02:17:36 --> Language Class Initialized
ERROR - 2018-07-28 02:17:36 --> 404 Page Not Found: /index
INFO - 2018-07-28 02:19:08 --> Config Class Initialized
INFO - 2018-07-28 02:19:08 --> Hooks Class Initialized
DEBUG - 2018-07-28 02:19:08 --> UTF-8 Support Enabled
INFO - 2018-07-28 02:19:08 --> Utf8 Class Initialized
INFO - 2018-07-28 02:19:08 --> URI Class Initialized
INFO - 2018-07-28 02:19:08 --> Router Class Initialized
INFO - 2018-07-28 02:19:08 --> Output Class Initialized
INFO - 2018-07-28 02:19:08 --> Security Class Initialized
DEBUG - 2018-07-28 02:19:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 02:19:08 --> Input Class Initialized
INFO - 2018-07-28 02:19:08 --> Language Class Initialized
INFO - 2018-07-28 02:19:08 --> Language Class Initialized
INFO - 2018-07-28 02:19:08 --> Config Class Initialized
INFO - 2018-07-28 02:19:08 --> Loader Class Initialized
DEBUG - 2018-07-28 02:19:08 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 02:19:09 --> Helper loaded: url_helper
INFO - 2018-07-28 02:19:09 --> Helper loaded: form_helper
INFO - 2018-07-28 02:19:09 --> Helper loaded: date_helper
INFO - 2018-07-28 02:19:09 --> Helper loaded: util_helper
INFO - 2018-07-28 02:19:09 --> Helper loaded: text_helper
INFO - 2018-07-28 02:19:09 --> Helper loaded: string_helper
INFO - 2018-07-28 02:19:09 --> Database Driver Class Initialized
DEBUG - 2018-07-28 02:19:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 02:19:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 02:19:09 --> Email Class Initialized
INFO - 2018-07-28 02:19:09 --> Controller Class Initialized
DEBUG - 2018-07-28 02:19:09 --> Users MX_Controller Initialized
DEBUG - 2018-07-28 02:19:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 02:19:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-28 02:19:09 --> Helper loaded: file_helper
DEBUG - 2018-07-28 02:19:09 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 02:19:09 --> Login MX_Controller Initialized
INFO - 2018-07-28 02:19:09 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 02:19:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-28 02:19:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-28 02:19:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-28 02:19:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-28 02:19:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-28 02:19:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-28 02:19:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-28 02:19:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-07-28 02:19:09 --> Final output sent to browser
DEBUG - 2018-07-28 02:19:09 --> Total execution time: 0.6080
INFO - 2018-07-28 02:19:16 --> Config Class Initialized
INFO - 2018-07-28 02:19:16 --> Hooks Class Initialized
DEBUG - 2018-07-28 02:19:16 --> UTF-8 Support Enabled
INFO - 2018-07-28 02:19:16 --> Utf8 Class Initialized
INFO - 2018-07-28 02:19:16 --> URI Class Initialized
INFO - 2018-07-28 02:19:16 --> Router Class Initialized
INFO - 2018-07-28 02:19:16 --> Output Class Initialized
INFO - 2018-07-28 02:19:16 --> Security Class Initialized
DEBUG - 2018-07-28 02:19:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 02:19:16 --> Input Class Initialized
INFO - 2018-07-28 02:19:16 --> Language Class Initialized
INFO - 2018-07-28 02:19:16 --> Language Class Initialized
INFO - 2018-07-28 02:19:16 --> Config Class Initialized
INFO - 2018-07-28 02:19:16 --> Loader Class Initialized
DEBUG - 2018-07-28 02:19:16 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 02:19:16 --> Helper loaded: url_helper
INFO - 2018-07-28 02:19:16 --> Helper loaded: form_helper
INFO - 2018-07-28 02:19:16 --> Helper loaded: date_helper
INFO - 2018-07-28 02:19:16 --> Helper loaded: util_helper
INFO - 2018-07-28 02:19:16 --> Helper loaded: text_helper
INFO - 2018-07-28 02:19:16 --> Helper loaded: string_helper
INFO - 2018-07-28 02:19:16 --> Database Driver Class Initialized
DEBUG - 2018-07-28 02:19:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 02:19:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 02:19:16 --> Email Class Initialized
INFO - 2018-07-28 02:19:16 --> Controller Class Initialized
DEBUG - 2018-07-28 02:19:16 --> Users MX_Controller Initialized
DEBUG - 2018-07-28 02:19:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 02:19:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-28 02:19:16 --> Helper loaded: file_helper
DEBUG - 2018-07-28 02:19:16 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 02:19:16 --> Login MX_Controller Initialized
INFO - 2018-07-28 02:19:16 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 02:19:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-28 02:19:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-28 02:19:16 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
ERROR - 2018-07-28 02:19:16 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable E:\xampp\htdocs\consulting\application\modules\admin\controllers\Users.php 323
INFO - 2018-07-28 02:19:16 --> Config Class Initialized
INFO - 2018-07-28 02:19:16 --> Hooks Class Initialized
DEBUG - 2018-07-28 02:19:16 --> UTF-8 Support Enabled
INFO - 2018-07-28 02:19:16 --> Utf8 Class Initialized
INFO - 2018-07-28 02:19:16 --> URI Class Initialized
INFO - 2018-07-28 02:19:16 --> Router Class Initialized
INFO - 2018-07-28 02:19:17 --> Output Class Initialized
INFO - 2018-07-28 02:19:17 --> Security Class Initialized
DEBUG - 2018-07-28 02:19:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 02:19:17 --> Input Class Initialized
INFO - 2018-07-28 02:19:17 --> Language Class Initialized
INFO - 2018-07-28 02:19:17 --> Language Class Initialized
INFO - 2018-07-28 02:19:17 --> Config Class Initialized
INFO - 2018-07-28 02:19:17 --> Loader Class Initialized
DEBUG - 2018-07-28 02:19:17 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 02:19:17 --> Helper loaded: url_helper
INFO - 2018-07-28 02:19:17 --> Helper loaded: form_helper
INFO - 2018-07-28 02:19:17 --> Helper loaded: date_helper
INFO - 2018-07-28 02:19:17 --> Helper loaded: util_helper
INFO - 2018-07-28 02:19:17 --> Helper loaded: text_helper
INFO - 2018-07-28 02:19:17 --> Helper loaded: string_helper
INFO - 2018-07-28 02:19:17 --> Database Driver Class Initialized
DEBUG - 2018-07-28 02:19:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 02:19:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 02:19:17 --> Email Class Initialized
INFO - 2018-07-28 02:19:17 --> Controller Class Initialized
DEBUG - 2018-07-28 02:19:17 --> Users MX_Controller Initialized
DEBUG - 2018-07-28 02:19:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 02:19:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-28 02:19:17 --> Helper loaded: file_helper
DEBUG - 2018-07-28 02:19:17 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 02:19:17 --> Login MX_Controller Initialized
INFO - 2018-07-28 02:19:17 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 02:19:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-28 02:19:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-28 02:19:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-28 02:19:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-28 02:19:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-28 02:19:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-28 02:19:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-07-28 02:19:17 --> Final output sent to browser
DEBUG - 2018-07-28 02:19:17 --> Total execution time: 0.5990
INFO - 2018-07-28 02:19:17 --> Config Class Initialized
INFO - 2018-07-28 02:19:17 --> Hooks Class Initialized
DEBUG - 2018-07-28 02:19:17 --> UTF-8 Support Enabled
INFO - 2018-07-28 02:19:17 --> Utf8 Class Initialized
INFO - 2018-07-28 02:19:17 --> URI Class Initialized
INFO - 2018-07-28 02:19:17 --> Router Class Initialized
INFO - 2018-07-28 02:19:17 --> Output Class Initialized
INFO - 2018-07-28 02:19:18 --> Security Class Initialized
DEBUG - 2018-07-28 02:19:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 02:19:18 --> Input Class Initialized
INFO - 2018-07-28 02:19:18 --> Language Class Initialized
INFO - 2018-07-28 02:19:18 --> Language Class Initialized
INFO - 2018-07-28 02:19:18 --> Config Class Initialized
INFO - 2018-07-28 02:19:18 --> Loader Class Initialized
DEBUG - 2018-07-28 02:19:18 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 02:19:18 --> Helper loaded: url_helper
INFO - 2018-07-28 02:19:18 --> Helper loaded: form_helper
INFO - 2018-07-28 02:19:18 --> Helper loaded: date_helper
INFO - 2018-07-28 02:19:18 --> Helper loaded: util_helper
INFO - 2018-07-28 02:19:18 --> Helper loaded: text_helper
INFO - 2018-07-28 02:19:18 --> Helper loaded: string_helper
INFO - 2018-07-28 02:19:18 --> Database Driver Class Initialized
DEBUG - 2018-07-28 02:19:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 02:19:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 02:19:18 --> Email Class Initialized
INFO - 2018-07-28 02:19:18 --> Controller Class Initialized
DEBUG - 2018-07-28 02:19:18 --> Users MX_Controller Initialized
DEBUG - 2018-07-28 02:19:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 02:19:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-28 02:19:18 --> Helper loaded: file_helper
DEBUG - 2018-07-28 02:19:18 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 02:19:18 --> Login MX_Controller Initialized
INFO - 2018-07-28 02:19:18 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 02:19:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-28 02:19:18 --> Final output sent to browser
DEBUG - 2018-07-28 02:19:18 --> Total execution time: 0.5941
INFO - 2018-07-28 02:19:19 --> Config Class Initialized
INFO - 2018-07-28 02:19:19 --> Hooks Class Initialized
DEBUG - 2018-07-28 02:19:19 --> UTF-8 Support Enabled
INFO - 2018-07-28 02:19:19 --> Utf8 Class Initialized
INFO - 2018-07-28 02:19:19 --> URI Class Initialized
INFO - 2018-07-28 02:19:19 --> Router Class Initialized
INFO - 2018-07-28 02:19:19 --> Output Class Initialized
INFO - 2018-07-28 02:19:19 --> Security Class Initialized
DEBUG - 2018-07-28 02:19:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 02:19:19 --> Input Class Initialized
INFO - 2018-07-28 02:19:19 --> Language Class Initialized
INFO - 2018-07-28 02:19:19 --> Language Class Initialized
INFO - 2018-07-28 02:19:19 --> Config Class Initialized
INFO - 2018-07-28 02:19:19 --> Loader Class Initialized
DEBUG - 2018-07-28 02:19:19 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 02:19:19 --> Helper loaded: url_helper
INFO - 2018-07-28 02:19:19 --> Helper loaded: form_helper
INFO - 2018-07-28 02:19:19 --> Helper loaded: date_helper
INFO - 2018-07-28 02:19:19 --> Helper loaded: util_helper
INFO - 2018-07-28 02:19:19 --> Helper loaded: text_helper
INFO - 2018-07-28 02:19:19 --> Helper loaded: string_helper
INFO - 2018-07-28 02:19:19 --> Database Driver Class Initialized
DEBUG - 2018-07-28 02:19:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 02:19:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 02:19:19 --> Email Class Initialized
INFO - 2018-07-28 02:19:19 --> Controller Class Initialized
DEBUG - 2018-07-28 02:19:19 --> Users MX_Controller Initialized
DEBUG - 2018-07-28 02:19:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 02:19:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-28 02:19:19 --> Helper loaded: file_helper
DEBUG - 2018-07-28 02:19:19 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 02:19:19 --> Login MX_Controller Initialized
INFO - 2018-07-28 02:19:19 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 02:19:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-28 02:19:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-28 02:19:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-28 02:19:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-28 02:19:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-28 02:19:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-28 02:19:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-28 02:19:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-07-28 02:19:19 --> Final output sent to browser
DEBUG - 2018-07-28 02:19:19 --> Total execution time: 0.5888
INFO - 2018-07-28 02:19:23 --> Config Class Initialized
INFO - 2018-07-28 02:19:23 --> Hooks Class Initialized
DEBUG - 2018-07-28 02:19:23 --> UTF-8 Support Enabled
INFO - 2018-07-28 02:19:23 --> Utf8 Class Initialized
INFO - 2018-07-28 02:19:23 --> URI Class Initialized
INFO - 2018-07-28 02:19:23 --> Router Class Initialized
INFO - 2018-07-28 02:19:23 --> Output Class Initialized
INFO - 2018-07-28 02:19:23 --> Security Class Initialized
DEBUG - 2018-07-28 02:19:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 02:19:23 --> Input Class Initialized
INFO - 2018-07-28 02:19:23 --> Language Class Initialized
INFO - 2018-07-28 02:19:23 --> Language Class Initialized
INFO - 2018-07-28 02:19:23 --> Config Class Initialized
INFO - 2018-07-28 02:19:23 --> Loader Class Initialized
DEBUG - 2018-07-28 02:19:23 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 02:19:23 --> Helper loaded: url_helper
INFO - 2018-07-28 02:19:23 --> Helper loaded: form_helper
INFO - 2018-07-28 02:19:23 --> Helper loaded: date_helper
INFO - 2018-07-28 02:19:23 --> Helper loaded: util_helper
INFO - 2018-07-28 02:19:23 --> Helper loaded: text_helper
INFO - 2018-07-28 02:19:23 --> Helper loaded: string_helper
INFO - 2018-07-28 02:19:23 --> Database Driver Class Initialized
DEBUG - 2018-07-28 02:19:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 02:19:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 02:19:23 --> Email Class Initialized
INFO - 2018-07-28 02:19:23 --> Controller Class Initialized
DEBUG - 2018-07-28 02:19:23 --> Users MX_Controller Initialized
DEBUG - 2018-07-28 02:19:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 02:19:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-28 02:19:23 --> Helper loaded: file_helper
DEBUG - 2018-07-28 02:19:23 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 02:19:23 --> Login MX_Controller Initialized
INFO - 2018-07-28 02:19:23 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 02:19:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-28 02:19:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-28 02:19:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-28 02:19:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-28 02:19:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-28 02:19:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-28 02:19:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-28 02:19:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-07-28 02:19:23 --> Final output sent to browser
DEBUG - 2018-07-28 02:19:23 --> Total execution time: 0.6045
INFO - 2018-07-28 02:20:00 --> Config Class Initialized
INFO - 2018-07-28 02:20:00 --> Hooks Class Initialized
DEBUG - 2018-07-28 02:20:00 --> UTF-8 Support Enabled
INFO - 2018-07-28 02:20:00 --> Utf8 Class Initialized
INFO - 2018-07-28 02:20:00 --> URI Class Initialized
INFO - 2018-07-28 02:20:00 --> Router Class Initialized
INFO - 2018-07-28 02:20:00 --> Output Class Initialized
INFO - 2018-07-28 02:20:00 --> Security Class Initialized
DEBUG - 2018-07-28 02:20:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 02:20:00 --> Input Class Initialized
INFO - 2018-07-28 02:20:00 --> Language Class Initialized
INFO - 2018-07-28 02:20:00 --> Language Class Initialized
INFO - 2018-07-28 02:20:00 --> Config Class Initialized
INFO - 2018-07-28 02:20:00 --> Loader Class Initialized
DEBUG - 2018-07-28 02:20:00 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 02:20:00 --> Helper loaded: url_helper
INFO - 2018-07-28 02:20:00 --> Helper loaded: form_helper
INFO - 2018-07-28 02:20:00 --> Helper loaded: date_helper
INFO - 2018-07-28 02:20:00 --> Helper loaded: util_helper
INFO - 2018-07-28 02:20:00 --> Helper loaded: text_helper
INFO - 2018-07-28 02:20:00 --> Helper loaded: string_helper
INFO - 2018-07-28 02:20:00 --> Database Driver Class Initialized
DEBUG - 2018-07-28 02:20:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 02:20:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 02:20:00 --> Email Class Initialized
INFO - 2018-07-28 02:20:00 --> Controller Class Initialized
DEBUG - 2018-07-28 02:20:00 --> Users MX_Controller Initialized
DEBUG - 2018-07-28 02:20:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 02:20:00 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-28 02:20:00 --> Helper loaded: file_helper
DEBUG - 2018-07-28 02:20:00 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 02:20:00 --> Login MX_Controller Initialized
INFO - 2018-07-28 02:20:00 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 02:20:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-28 02:20:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-28 02:20:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-28 02:20:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-28 02:20:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-28 02:20:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-28 02:20:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-28 02:20:01 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-07-28 02:20:01 --> Final output sent to browser
DEBUG - 2018-07-28 02:20:01 --> Total execution time: 0.6211
INFO - 2018-07-28 02:22:23 --> Config Class Initialized
INFO - 2018-07-28 02:22:23 --> Hooks Class Initialized
DEBUG - 2018-07-28 02:22:23 --> UTF-8 Support Enabled
INFO - 2018-07-28 02:22:23 --> Utf8 Class Initialized
INFO - 2018-07-28 02:22:23 --> URI Class Initialized
INFO - 2018-07-28 02:22:23 --> Router Class Initialized
INFO - 2018-07-28 02:22:23 --> Output Class Initialized
INFO - 2018-07-28 02:22:23 --> Security Class Initialized
DEBUG - 2018-07-28 02:22:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 02:22:24 --> Input Class Initialized
INFO - 2018-07-28 02:22:24 --> Language Class Initialized
INFO - 2018-07-28 02:22:24 --> Language Class Initialized
INFO - 2018-07-28 02:22:24 --> Config Class Initialized
INFO - 2018-07-28 02:22:24 --> Loader Class Initialized
DEBUG - 2018-07-28 02:22:24 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 02:22:24 --> Helper loaded: url_helper
INFO - 2018-07-28 02:22:24 --> Helper loaded: form_helper
INFO - 2018-07-28 02:22:24 --> Helper loaded: date_helper
INFO - 2018-07-28 02:22:24 --> Helper loaded: util_helper
INFO - 2018-07-28 02:22:24 --> Helper loaded: text_helper
INFO - 2018-07-28 02:22:24 --> Helper loaded: string_helper
INFO - 2018-07-28 02:22:24 --> Database Driver Class Initialized
DEBUG - 2018-07-28 02:22:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 02:22:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 02:22:24 --> Email Class Initialized
INFO - 2018-07-28 02:22:24 --> Controller Class Initialized
DEBUG - 2018-07-28 02:22:24 --> Users MX_Controller Initialized
DEBUG - 2018-07-28 02:22:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 02:22:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-28 02:22:24 --> Helper loaded: file_helper
DEBUG - 2018-07-28 02:22:24 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 02:22:24 --> Login MX_Controller Initialized
INFO - 2018-07-28 02:22:24 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 02:22:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-28 02:22:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-28 02:22:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-28 02:22:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-28 02:22:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-28 02:22:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-28 02:22:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-28 02:22:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-07-28 02:22:24 --> Final output sent to browser
DEBUG - 2018-07-28 02:22:24 --> Total execution time: 0.6265
INFO - 2018-07-28 02:22:42 --> Config Class Initialized
INFO - 2018-07-28 02:22:42 --> Config Class Initialized
INFO - 2018-07-28 02:22:42 --> Hooks Class Initialized
INFO - 2018-07-28 02:22:42 --> Hooks Class Initialized
DEBUG - 2018-07-28 02:22:42 --> UTF-8 Support Enabled
DEBUG - 2018-07-28 02:22:42 --> UTF-8 Support Enabled
INFO - 2018-07-28 02:22:42 --> Utf8 Class Initialized
INFO - 2018-07-28 02:22:42 --> Utf8 Class Initialized
INFO - 2018-07-28 02:22:42 --> URI Class Initialized
INFO - 2018-07-28 02:22:42 --> URI Class Initialized
INFO - 2018-07-28 02:22:42 --> Router Class Initialized
INFO - 2018-07-28 02:22:42 --> Router Class Initialized
INFO - 2018-07-28 02:22:42 --> Output Class Initialized
INFO - 2018-07-28 02:22:42 --> Output Class Initialized
INFO - 2018-07-28 02:22:42 --> Security Class Initialized
INFO - 2018-07-28 02:22:42 --> Security Class Initialized
DEBUG - 2018-07-28 02:22:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-07-28 02:22:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 02:22:42 --> Input Class Initialized
INFO - 2018-07-28 02:22:42 --> Input Class Initialized
INFO - 2018-07-28 02:22:42 --> Language Class Initialized
INFO - 2018-07-28 02:22:42 --> Language Class Initialized
INFO - 2018-07-28 02:22:42 --> Language Class Initialized
INFO - 2018-07-28 02:22:42 --> Language Class Initialized
INFO - 2018-07-28 02:22:42 --> Config Class Initialized
INFO - 2018-07-28 02:22:42 --> Loader Class Initialized
INFO - 2018-07-28 02:22:42 --> Config Class Initialized
DEBUG - 2018-07-28 02:22:42 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 02:22:42 --> Loader Class Initialized
DEBUG - 2018-07-28 02:22:42 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 02:22:42 --> Helper loaded: url_helper
INFO - 2018-07-28 02:22:42 --> Helper loaded: url_helper
INFO - 2018-07-28 02:22:42 --> Helper loaded: form_helper
INFO - 2018-07-28 02:22:42 --> Helper loaded: date_helper
INFO - 2018-07-28 02:22:42 --> Helper loaded: util_helper
INFO - 2018-07-28 02:22:42 --> Helper loaded: text_helper
INFO - 2018-07-28 02:22:42 --> Helper loaded: string_helper
INFO - 2018-07-28 02:22:42 --> Helper loaded: form_helper
INFO - 2018-07-28 02:22:42 --> Database Driver Class Initialized
INFO - 2018-07-28 02:22:42 --> Helper loaded: date_helper
DEBUG - 2018-07-28 02:22:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 02:22:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 02:22:42 --> Helper loaded: util_helper
INFO - 2018-07-28 02:22:42 --> Helper loaded: text_helper
INFO - 2018-07-28 02:22:42 --> Email Class Initialized
INFO - 2018-07-28 02:22:42 --> Controller Class Initialized
INFO - 2018-07-28 02:22:42 --> Helper loaded: string_helper
DEBUG - 2018-07-28 02:22:42 --> Users MX_Controller Initialized
DEBUG - 2018-07-28 02:22:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 02:22:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-28 02:22:42 --> Helper loaded: file_helper
INFO - 2018-07-28 02:22:42 --> Database Driver Class Initialized
DEBUG - 2018-07-28 02:22:42 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 02:22:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-07-28 02:22:42 --> Login MX_Controller Initialized
INFO - 2018-07-28 02:22:42 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 02:22:42 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-28 02:22:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-28 02:22:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-28 02:22:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-28 02:22:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-28 02:22:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-28 02:22:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-28 02:22:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-07-28 02:22:43 --> Final output sent to browser
DEBUG - 2018-07-28 02:22:43 --> Total execution time: 0.6590
INFO - 2018-07-28 02:22:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 02:22:43 --> Email Class Initialized
INFO - 2018-07-28 02:22:43 --> Controller Class Initialized
DEBUG - 2018-07-28 02:22:43 --> Users MX_Controller Initialized
DEBUG - 2018-07-28 02:22:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 02:22:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-28 02:22:43 --> Helper loaded: file_helper
DEBUG - 2018-07-28 02:22:43 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 02:22:43 --> Login MX_Controller Initialized
INFO - 2018-07-28 02:22:43 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 02:22:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-28 02:22:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-28 02:22:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-28 02:22:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-28 02:22:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-28 02:22:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-28 02:22:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-28 02:22:43 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-07-28 02:22:43 --> Final output sent to browser
DEBUG - 2018-07-28 02:22:43 --> Total execution time: 0.9417
INFO - 2018-07-28 02:23:03 --> Config Class Initialized
INFO - 2018-07-28 02:23:03 --> Hooks Class Initialized
DEBUG - 2018-07-28 02:23:03 --> UTF-8 Support Enabled
INFO - 2018-07-28 02:23:03 --> Utf8 Class Initialized
INFO - 2018-07-28 02:23:03 --> URI Class Initialized
INFO - 2018-07-28 02:23:03 --> Router Class Initialized
INFO - 2018-07-28 02:23:03 --> Output Class Initialized
INFO - 2018-07-28 02:23:03 --> Security Class Initialized
DEBUG - 2018-07-28 02:23:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 02:23:03 --> Input Class Initialized
INFO - 2018-07-28 02:23:03 --> Language Class Initialized
INFO - 2018-07-28 02:23:03 --> Language Class Initialized
INFO - 2018-07-28 02:23:03 --> Config Class Initialized
INFO - 2018-07-28 02:23:03 --> Loader Class Initialized
DEBUG - 2018-07-28 02:23:03 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 02:23:03 --> Helper loaded: url_helper
INFO - 2018-07-28 02:23:03 --> Helper loaded: form_helper
INFO - 2018-07-28 02:23:03 --> Helper loaded: date_helper
INFO - 2018-07-28 02:23:03 --> Helper loaded: util_helper
INFO - 2018-07-28 02:23:03 --> Helper loaded: text_helper
INFO - 2018-07-28 02:23:03 --> Helper loaded: string_helper
INFO - 2018-07-28 02:23:03 --> Database Driver Class Initialized
DEBUG - 2018-07-28 02:23:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 02:23:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 02:23:03 --> Email Class Initialized
INFO - 2018-07-28 02:23:03 --> Controller Class Initialized
DEBUG - 2018-07-28 02:23:03 --> Users MX_Controller Initialized
DEBUG - 2018-07-28 02:23:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 02:23:03 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-28 02:23:03 --> Helper loaded: file_helper
DEBUG - 2018-07-28 02:23:04 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 02:23:04 --> Login MX_Controller Initialized
INFO - 2018-07-28 02:23:04 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 02:23:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-28 02:23:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-28 02:23:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-28 02:23:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-28 02:23:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-28 02:23:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-28 02:23:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-28 02:23:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-07-28 02:23:04 --> Final output sent to browser
DEBUG - 2018-07-28 02:23:04 --> Total execution time: 0.6329
INFO - 2018-07-28 02:23:47 --> Config Class Initialized
INFO - 2018-07-28 02:23:47 --> Hooks Class Initialized
DEBUG - 2018-07-28 02:23:47 --> UTF-8 Support Enabled
INFO - 2018-07-28 02:23:47 --> Utf8 Class Initialized
INFO - 2018-07-28 02:23:47 --> URI Class Initialized
INFO - 2018-07-28 02:23:47 --> Router Class Initialized
INFO - 2018-07-28 02:23:47 --> Output Class Initialized
INFO - 2018-07-28 02:23:47 --> Security Class Initialized
DEBUG - 2018-07-28 02:23:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 02:23:47 --> Input Class Initialized
INFO - 2018-07-28 02:23:47 --> Language Class Initialized
INFO - 2018-07-28 02:23:47 --> Language Class Initialized
INFO - 2018-07-28 02:23:47 --> Config Class Initialized
INFO - 2018-07-28 02:23:47 --> Loader Class Initialized
DEBUG - 2018-07-28 02:23:47 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 02:23:47 --> Helper loaded: url_helper
INFO - 2018-07-28 02:23:47 --> Helper loaded: form_helper
INFO - 2018-07-28 02:23:47 --> Helper loaded: date_helper
INFO - 2018-07-28 02:23:47 --> Helper loaded: util_helper
INFO - 2018-07-28 02:23:47 --> Helper loaded: text_helper
INFO - 2018-07-28 02:23:47 --> Helper loaded: string_helper
INFO - 2018-07-28 02:23:47 --> Database Driver Class Initialized
DEBUG - 2018-07-28 02:23:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 02:23:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 02:23:48 --> Email Class Initialized
INFO - 2018-07-28 02:23:48 --> Controller Class Initialized
DEBUG - 2018-07-28 02:23:48 --> Users MX_Controller Initialized
DEBUG - 2018-07-28 02:23:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 02:23:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-28 02:23:48 --> Helper loaded: file_helper
DEBUG - 2018-07-28 02:23:48 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 02:23:48 --> Login MX_Controller Initialized
INFO - 2018-07-28 02:23:48 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 02:23:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-28 02:23:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-28 02:23:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-28 02:23:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-28 02:23:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-28 02:23:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-28 02:23:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-28 02:23:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-07-28 02:23:48 --> Final output sent to browser
DEBUG - 2018-07-28 02:23:48 --> Total execution time: 0.6370
INFO - 2018-07-28 02:24:12 --> Config Class Initialized
INFO - 2018-07-28 02:24:12 --> Hooks Class Initialized
DEBUG - 2018-07-28 02:24:12 --> UTF-8 Support Enabled
INFO - 2018-07-28 02:24:12 --> Utf8 Class Initialized
INFO - 2018-07-28 02:24:12 --> URI Class Initialized
INFO - 2018-07-28 02:24:12 --> Router Class Initialized
INFO - 2018-07-28 02:24:12 --> Output Class Initialized
INFO - 2018-07-28 02:24:12 --> Security Class Initialized
DEBUG - 2018-07-28 02:24:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 02:24:12 --> Input Class Initialized
INFO - 2018-07-28 02:24:12 --> Language Class Initialized
INFO - 2018-07-28 02:24:12 --> Language Class Initialized
INFO - 2018-07-28 02:24:12 --> Config Class Initialized
INFO - 2018-07-28 02:24:12 --> Loader Class Initialized
DEBUG - 2018-07-28 02:24:12 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 02:24:12 --> Helper loaded: url_helper
INFO - 2018-07-28 02:24:12 --> Helper loaded: form_helper
INFO - 2018-07-28 02:24:12 --> Helper loaded: date_helper
INFO - 2018-07-28 02:24:12 --> Helper loaded: util_helper
INFO - 2018-07-28 02:24:12 --> Helper loaded: text_helper
INFO - 2018-07-28 02:24:12 --> Helper loaded: string_helper
INFO - 2018-07-28 02:24:12 --> Database Driver Class Initialized
DEBUG - 2018-07-28 02:24:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 02:24:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 02:24:12 --> Email Class Initialized
INFO - 2018-07-28 02:24:12 --> Controller Class Initialized
DEBUG - 2018-07-28 02:24:12 --> Users MX_Controller Initialized
DEBUG - 2018-07-28 02:24:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 02:24:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-28 02:24:12 --> Helper loaded: file_helper
DEBUG - 2018-07-28 02:24:12 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 02:24:12 --> Login MX_Controller Initialized
INFO - 2018-07-28 02:24:12 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 02:24:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-28 02:24:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-28 02:24:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-28 02:24:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-28 02:24:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-28 02:24:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-28 02:24:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-28 02:24:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-07-28 02:24:12 --> Final output sent to browser
DEBUG - 2018-07-28 02:24:12 --> Total execution time: 0.6373
INFO - 2018-07-28 02:25:06 --> Config Class Initialized
INFO - 2018-07-28 02:25:06 --> Hooks Class Initialized
DEBUG - 2018-07-28 02:25:06 --> UTF-8 Support Enabled
INFO - 2018-07-28 02:25:06 --> Utf8 Class Initialized
INFO - 2018-07-28 02:25:06 --> URI Class Initialized
INFO - 2018-07-28 02:25:06 --> Router Class Initialized
INFO - 2018-07-28 02:25:06 --> Output Class Initialized
INFO - 2018-07-28 02:25:06 --> Security Class Initialized
DEBUG - 2018-07-28 02:25:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 02:25:06 --> Input Class Initialized
INFO - 2018-07-28 02:25:06 --> Language Class Initialized
INFO - 2018-07-28 02:25:06 --> Language Class Initialized
INFO - 2018-07-28 02:25:06 --> Config Class Initialized
INFO - 2018-07-28 02:25:06 --> Loader Class Initialized
DEBUG - 2018-07-28 02:25:07 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 02:25:07 --> Helper loaded: url_helper
INFO - 2018-07-28 02:25:07 --> Helper loaded: form_helper
INFO - 2018-07-28 02:25:07 --> Helper loaded: date_helper
INFO - 2018-07-28 02:25:07 --> Helper loaded: util_helper
INFO - 2018-07-28 02:25:07 --> Helper loaded: text_helper
INFO - 2018-07-28 02:25:07 --> Helper loaded: string_helper
INFO - 2018-07-28 02:25:07 --> Database Driver Class Initialized
DEBUG - 2018-07-28 02:25:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 02:25:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 02:25:07 --> Email Class Initialized
INFO - 2018-07-28 02:25:07 --> Controller Class Initialized
DEBUG - 2018-07-28 02:25:07 --> Users MX_Controller Initialized
DEBUG - 2018-07-28 02:25:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 02:25:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-28 02:25:07 --> Helper loaded: file_helper
DEBUG - 2018-07-28 02:25:07 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 02:25:07 --> Login MX_Controller Initialized
INFO - 2018-07-28 02:25:07 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 02:25:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-28 02:25:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-28 02:25:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-28 02:25:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-28 02:25:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-28 02:25:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-28 02:25:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-28 02:25:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-07-28 02:25:07 --> Final output sent to browser
DEBUG - 2018-07-28 02:25:07 --> Total execution time: 0.6368
INFO - 2018-07-28 02:25:40 --> Config Class Initialized
INFO - 2018-07-28 02:25:40 --> Hooks Class Initialized
DEBUG - 2018-07-28 02:25:40 --> UTF-8 Support Enabled
INFO - 2018-07-28 02:25:40 --> Utf8 Class Initialized
INFO - 2018-07-28 02:25:40 --> URI Class Initialized
INFO - 2018-07-28 02:25:40 --> Router Class Initialized
INFO - 2018-07-28 02:25:40 --> Output Class Initialized
INFO - 2018-07-28 02:25:40 --> Security Class Initialized
DEBUG - 2018-07-28 02:25:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 02:25:40 --> Input Class Initialized
INFO - 2018-07-28 02:25:40 --> Language Class Initialized
INFO - 2018-07-28 02:25:40 --> Language Class Initialized
INFO - 2018-07-28 02:25:40 --> Config Class Initialized
INFO - 2018-07-28 02:25:40 --> Loader Class Initialized
DEBUG - 2018-07-28 02:25:40 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 02:25:40 --> Helper loaded: url_helper
INFO - 2018-07-28 02:25:40 --> Helper loaded: form_helper
INFO - 2018-07-28 02:25:40 --> Helper loaded: date_helper
INFO - 2018-07-28 02:25:40 --> Helper loaded: util_helper
INFO - 2018-07-28 02:25:40 --> Helper loaded: text_helper
INFO - 2018-07-28 02:25:40 --> Helper loaded: string_helper
INFO - 2018-07-28 02:25:40 --> Database Driver Class Initialized
DEBUG - 2018-07-28 02:25:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 02:25:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 02:25:40 --> Email Class Initialized
INFO - 2018-07-28 02:25:40 --> Controller Class Initialized
DEBUG - 2018-07-28 02:25:40 --> Users MX_Controller Initialized
DEBUG - 2018-07-28 02:25:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 02:25:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-28 02:25:40 --> Helper loaded: file_helper
DEBUG - 2018-07-28 02:25:40 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 02:25:41 --> Login MX_Controller Initialized
INFO - 2018-07-28 02:25:41 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 02:25:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-28 02:25:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-28 02:25:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-28 02:25:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-28 02:25:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-28 02:25:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-28 02:25:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-28 02:25:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-07-28 02:25:41 --> Final output sent to browser
DEBUG - 2018-07-28 02:25:41 --> Total execution time: 0.6297
INFO - 2018-07-28 02:26:07 --> Config Class Initialized
INFO - 2018-07-28 02:26:07 --> Hooks Class Initialized
DEBUG - 2018-07-28 02:26:07 --> UTF-8 Support Enabled
INFO - 2018-07-28 02:26:07 --> Utf8 Class Initialized
INFO - 2018-07-28 02:26:07 --> URI Class Initialized
INFO - 2018-07-28 02:26:07 --> Router Class Initialized
INFO - 2018-07-28 02:26:07 --> Output Class Initialized
INFO - 2018-07-28 02:26:07 --> Security Class Initialized
DEBUG - 2018-07-28 02:26:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 02:26:07 --> Input Class Initialized
INFO - 2018-07-28 02:26:07 --> Language Class Initialized
INFO - 2018-07-28 02:26:07 --> Language Class Initialized
INFO - 2018-07-28 02:26:07 --> Config Class Initialized
INFO - 2018-07-28 02:26:07 --> Loader Class Initialized
DEBUG - 2018-07-28 02:26:07 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 02:26:07 --> Helper loaded: url_helper
INFO - 2018-07-28 02:26:07 --> Helper loaded: form_helper
INFO - 2018-07-28 02:26:07 --> Helper loaded: date_helper
INFO - 2018-07-28 02:26:07 --> Helper loaded: util_helper
INFO - 2018-07-28 02:26:07 --> Helper loaded: text_helper
INFO - 2018-07-28 02:26:07 --> Helper loaded: string_helper
INFO - 2018-07-28 02:26:07 --> Database Driver Class Initialized
DEBUG - 2018-07-28 02:26:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 02:26:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 02:26:07 --> Email Class Initialized
INFO - 2018-07-28 02:26:07 --> Controller Class Initialized
DEBUG - 2018-07-28 02:26:07 --> Users MX_Controller Initialized
DEBUG - 2018-07-28 02:26:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 02:26:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-28 02:26:07 --> Helper loaded: file_helper
DEBUG - 2018-07-28 02:26:07 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 02:26:07 --> Login MX_Controller Initialized
INFO - 2018-07-28 02:26:07 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 02:26:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-28 02:26:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-28 02:26:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
INFO - 2018-07-28 02:26:07 --> Config Class Initialized
INFO - 2018-07-28 02:26:07 --> Hooks Class Initialized
DEBUG - 2018-07-28 02:26:07 --> UTF-8 Support Enabled
INFO - 2018-07-28 02:26:07 --> Utf8 Class Initialized
INFO - 2018-07-28 02:26:07 --> URI Class Initialized
INFO - 2018-07-28 02:26:08 --> Router Class Initialized
INFO - 2018-07-28 02:26:08 --> Output Class Initialized
INFO - 2018-07-28 02:26:08 --> Security Class Initialized
DEBUG - 2018-07-28 02:26:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 02:26:08 --> Input Class Initialized
INFO - 2018-07-28 02:26:08 --> Language Class Initialized
INFO - 2018-07-28 02:26:08 --> Language Class Initialized
INFO - 2018-07-28 02:26:08 --> Config Class Initialized
INFO - 2018-07-28 02:26:08 --> Loader Class Initialized
DEBUG - 2018-07-28 02:26:08 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 02:26:08 --> Helper loaded: url_helper
INFO - 2018-07-28 02:26:08 --> Helper loaded: form_helper
INFO - 2018-07-28 02:26:08 --> Helper loaded: date_helper
INFO - 2018-07-28 02:26:08 --> Helper loaded: util_helper
INFO - 2018-07-28 02:26:08 --> Helper loaded: text_helper
INFO - 2018-07-28 02:26:08 --> Helper loaded: string_helper
INFO - 2018-07-28 02:26:08 --> Database Driver Class Initialized
DEBUG - 2018-07-28 02:26:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 02:26:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 02:26:08 --> Email Class Initialized
INFO - 2018-07-28 02:26:08 --> Controller Class Initialized
DEBUG - 2018-07-28 02:26:08 --> Users MX_Controller Initialized
DEBUG - 2018-07-28 02:26:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 02:26:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-28 02:26:08 --> Helper loaded: file_helper
DEBUG - 2018-07-28 02:26:08 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 02:26:08 --> Login MX_Controller Initialized
INFO - 2018-07-28 02:26:08 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 02:26:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-28 02:26:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-28 02:26:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-28 02:26:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-28 02:26:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-28 02:26:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-28 02:26:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-07-28 02:26:08 --> Final output sent to browser
DEBUG - 2018-07-28 02:26:08 --> Total execution time: 0.6160
INFO - 2018-07-28 02:26:09 --> Config Class Initialized
INFO - 2018-07-28 02:26:09 --> Hooks Class Initialized
DEBUG - 2018-07-28 02:26:09 --> UTF-8 Support Enabled
INFO - 2018-07-28 02:26:09 --> Utf8 Class Initialized
INFO - 2018-07-28 02:26:09 --> URI Class Initialized
INFO - 2018-07-28 02:26:09 --> Router Class Initialized
INFO - 2018-07-28 02:26:09 --> Output Class Initialized
INFO - 2018-07-28 02:26:09 --> Security Class Initialized
DEBUG - 2018-07-28 02:26:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 02:26:09 --> Input Class Initialized
INFO - 2018-07-28 02:26:09 --> Language Class Initialized
INFO - 2018-07-28 02:26:09 --> Language Class Initialized
INFO - 2018-07-28 02:26:09 --> Config Class Initialized
INFO - 2018-07-28 02:26:09 --> Loader Class Initialized
DEBUG - 2018-07-28 02:26:09 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 02:26:09 --> Helper loaded: url_helper
INFO - 2018-07-28 02:26:09 --> Helper loaded: form_helper
INFO - 2018-07-28 02:26:09 --> Helper loaded: date_helper
INFO - 2018-07-28 02:26:09 --> Helper loaded: util_helper
INFO - 2018-07-28 02:26:09 --> Helper loaded: text_helper
INFO - 2018-07-28 02:26:09 --> Helper loaded: string_helper
INFO - 2018-07-28 02:26:09 --> Database Driver Class Initialized
DEBUG - 2018-07-28 02:26:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 02:26:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 02:26:09 --> Email Class Initialized
INFO - 2018-07-28 02:26:09 --> Controller Class Initialized
DEBUG - 2018-07-28 02:26:09 --> Users MX_Controller Initialized
DEBUG - 2018-07-28 02:26:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 02:26:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-28 02:26:09 --> Helper loaded: file_helper
DEBUG - 2018-07-28 02:26:09 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 02:26:09 --> Login MX_Controller Initialized
INFO - 2018-07-28 02:26:09 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 02:26:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-28 02:26:09 --> Final output sent to browser
DEBUG - 2018-07-28 02:26:09 --> Total execution time: 0.6446
INFO - 2018-07-28 02:26:10 --> Config Class Initialized
INFO - 2018-07-28 02:26:10 --> Hooks Class Initialized
DEBUG - 2018-07-28 02:26:10 --> UTF-8 Support Enabled
INFO - 2018-07-28 02:26:10 --> Utf8 Class Initialized
INFO - 2018-07-28 02:26:10 --> URI Class Initialized
INFO - 2018-07-28 02:26:10 --> Router Class Initialized
INFO - 2018-07-28 02:26:10 --> Output Class Initialized
INFO - 2018-07-28 02:26:10 --> Security Class Initialized
DEBUG - 2018-07-28 02:26:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 02:26:10 --> Input Class Initialized
INFO - 2018-07-28 02:26:10 --> Language Class Initialized
INFO - 2018-07-28 02:26:10 --> Language Class Initialized
INFO - 2018-07-28 02:26:10 --> Config Class Initialized
INFO - 2018-07-28 02:26:10 --> Loader Class Initialized
DEBUG - 2018-07-28 02:26:10 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 02:26:10 --> Helper loaded: url_helper
INFO - 2018-07-28 02:26:10 --> Helper loaded: form_helper
INFO - 2018-07-28 02:26:10 --> Helper loaded: date_helper
INFO - 2018-07-28 02:26:10 --> Helper loaded: util_helper
INFO - 2018-07-28 02:26:11 --> Helper loaded: text_helper
INFO - 2018-07-28 02:26:11 --> Helper loaded: string_helper
INFO - 2018-07-28 02:26:11 --> Database Driver Class Initialized
DEBUG - 2018-07-28 02:26:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 02:26:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 02:26:11 --> Email Class Initialized
INFO - 2018-07-28 02:26:11 --> Controller Class Initialized
DEBUG - 2018-07-28 02:26:11 --> Users MX_Controller Initialized
DEBUG - 2018-07-28 02:26:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 02:26:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-28 02:26:11 --> Helper loaded: file_helper
DEBUG - 2018-07-28 02:26:11 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 02:26:11 --> Login MX_Controller Initialized
INFO - 2018-07-28 02:26:11 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 02:26:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-28 02:26:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-28 02:26:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-28 02:26:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-28 02:26:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-28 02:26:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-28 02:26:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-28 02:26:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-07-28 02:26:11 --> Final output sent to browser
DEBUG - 2018-07-28 02:26:11 --> Total execution time: 0.6399
INFO - 2018-07-28 02:26:12 --> Config Class Initialized
INFO - 2018-07-28 02:26:12 --> Hooks Class Initialized
DEBUG - 2018-07-28 02:26:12 --> UTF-8 Support Enabled
INFO - 2018-07-28 02:26:12 --> Utf8 Class Initialized
INFO - 2018-07-28 02:26:12 --> URI Class Initialized
INFO - 2018-07-28 02:26:12 --> Router Class Initialized
INFO - 2018-07-28 02:26:13 --> Output Class Initialized
INFO - 2018-07-28 02:26:13 --> Security Class Initialized
DEBUG - 2018-07-28 02:26:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 02:26:13 --> Input Class Initialized
INFO - 2018-07-28 02:26:13 --> Language Class Initialized
INFO - 2018-07-28 02:26:13 --> Language Class Initialized
INFO - 2018-07-28 02:26:13 --> Config Class Initialized
INFO - 2018-07-28 02:26:13 --> Loader Class Initialized
DEBUG - 2018-07-28 02:26:13 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 02:26:13 --> Helper loaded: url_helper
INFO - 2018-07-28 02:26:13 --> Helper loaded: form_helper
INFO - 2018-07-28 02:26:13 --> Helper loaded: date_helper
INFO - 2018-07-28 02:26:13 --> Helper loaded: util_helper
INFO - 2018-07-28 02:26:13 --> Helper loaded: text_helper
INFO - 2018-07-28 02:26:13 --> Helper loaded: string_helper
INFO - 2018-07-28 02:26:13 --> Database Driver Class Initialized
DEBUG - 2018-07-28 02:26:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 02:26:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 02:26:13 --> Email Class Initialized
INFO - 2018-07-28 02:26:13 --> Controller Class Initialized
DEBUG - 2018-07-28 02:26:13 --> Users MX_Controller Initialized
DEBUG - 2018-07-28 02:26:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 02:26:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-28 02:26:13 --> Helper loaded: file_helper
DEBUG - 2018-07-28 02:26:13 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 02:26:13 --> Login MX_Controller Initialized
INFO - 2018-07-28 02:26:13 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 02:26:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-28 02:26:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-28 02:26:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-28 02:26:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-28 02:26:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-28 02:26:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-28 02:26:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-28 02:26:13 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-07-28 02:26:13 --> Final output sent to browser
DEBUG - 2018-07-28 02:26:13 --> Total execution time: 0.6335
INFO - 2018-07-28 02:26:41 --> Config Class Initialized
INFO - 2018-07-28 02:26:41 --> Hooks Class Initialized
DEBUG - 2018-07-28 02:26:41 --> UTF-8 Support Enabled
INFO - 2018-07-28 02:26:41 --> Utf8 Class Initialized
INFO - 2018-07-28 02:26:41 --> URI Class Initialized
INFO - 2018-07-28 02:26:41 --> Router Class Initialized
INFO - 2018-07-28 02:26:41 --> Output Class Initialized
INFO - 2018-07-28 02:26:41 --> Security Class Initialized
DEBUG - 2018-07-28 02:26:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 02:26:41 --> Input Class Initialized
INFO - 2018-07-28 02:26:41 --> Language Class Initialized
INFO - 2018-07-28 02:26:41 --> Language Class Initialized
INFO - 2018-07-28 02:26:41 --> Config Class Initialized
INFO - 2018-07-28 02:26:41 --> Loader Class Initialized
DEBUG - 2018-07-28 02:26:41 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 02:26:41 --> Helper loaded: url_helper
INFO - 2018-07-28 02:26:41 --> Helper loaded: form_helper
INFO - 2018-07-28 02:26:41 --> Helper loaded: date_helper
INFO - 2018-07-28 02:26:41 --> Helper loaded: util_helper
INFO - 2018-07-28 02:26:41 --> Helper loaded: text_helper
INFO - 2018-07-28 02:26:41 --> Helper loaded: string_helper
INFO - 2018-07-28 02:26:41 --> Database Driver Class Initialized
DEBUG - 2018-07-28 02:26:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 02:26:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 02:26:41 --> Email Class Initialized
INFO - 2018-07-28 02:26:41 --> Controller Class Initialized
DEBUG - 2018-07-28 02:26:41 --> Users MX_Controller Initialized
DEBUG - 2018-07-28 02:26:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 02:26:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-28 02:26:41 --> Helper loaded: file_helper
DEBUG - 2018-07-28 02:26:41 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 02:26:41 --> Login MX_Controller Initialized
INFO - 2018-07-28 02:26:41 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 02:26:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-28 02:26:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-28 02:26:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-28 02:26:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-28 02:26:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-28 02:26:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-28 02:26:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-28 02:26:41 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-07-28 02:26:41 --> Final output sent to browser
DEBUG - 2018-07-28 02:26:41 --> Total execution time: 0.6590
INFO - 2018-07-28 02:26:44 --> Config Class Initialized
INFO - 2018-07-28 02:26:44 --> Hooks Class Initialized
DEBUG - 2018-07-28 02:26:44 --> UTF-8 Support Enabled
INFO - 2018-07-28 02:26:44 --> Utf8 Class Initialized
INFO - 2018-07-28 02:26:44 --> URI Class Initialized
INFO - 2018-07-28 02:26:44 --> Router Class Initialized
INFO - 2018-07-28 02:26:44 --> Output Class Initialized
INFO - 2018-07-28 02:26:44 --> Security Class Initialized
DEBUG - 2018-07-28 02:26:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 02:26:44 --> Input Class Initialized
INFO - 2018-07-28 02:26:45 --> Language Class Initialized
INFO - 2018-07-28 02:26:45 --> Language Class Initialized
INFO - 2018-07-28 02:26:45 --> Config Class Initialized
INFO - 2018-07-28 02:26:45 --> Loader Class Initialized
DEBUG - 2018-07-28 02:26:45 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 02:26:45 --> Helper loaded: url_helper
INFO - 2018-07-28 02:26:45 --> Helper loaded: form_helper
INFO - 2018-07-28 02:26:45 --> Helper loaded: date_helper
INFO - 2018-07-28 02:26:45 --> Helper loaded: util_helper
INFO - 2018-07-28 02:26:45 --> Helper loaded: text_helper
INFO - 2018-07-28 02:26:45 --> Helper loaded: string_helper
INFO - 2018-07-28 02:26:45 --> Database Driver Class Initialized
DEBUG - 2018-07-28 02:26:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 02:26:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 02:26:45 --> Email Class Initialized
INFO - 2018-07-28 02:26:45 --> Controller Class Initialized
DEBUG - 2018-07-28 02:26:45 --> Users MX_Controller Initialized
DEBUG - 2018-07-28 02:26:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 02:26:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-28 02:26:45 --> Helper loaded: file_helper
DEBUG - 2018-07-28 02:26:45 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 02:26:45 --> Login MX_Controller Initialized
INFO - 2018-07-28 02:26:45 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 02:26:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-28 02:26:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-28 02:26:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-28 02:26:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-28 02:26:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-28 02:26:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-28 02:26:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-07-28 02:26:45 --> Final output sent to browser
DEBUG - 2018-07-28 02:26:45 --> Total execution time: 0.8348
INFO - 2018-07-28 02:26:46 --> Config Class Initialized
INFO - 2018-07-28 02:26:46 --> Hooks Class Initialized
DEBUG - 2018-07-28 02:26:46 --> UTF-8 Support Enabled
INFO - 2018-07-28 02:26:46 --> Utf8 Class Initialized
INFO - 2018-07-28 02:26:46 --> URI Class Initialized
INFO - 2018-07-28 02:26:46 --> Router Class Initialized
INFO - 2018-07-28 02:26:46 --> Output Class Initialized
INFO - 2018-07-28 02:26:46 --> Security Class Initialized
DEBUG - 2018-07-28 02:26:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 02:26:46 --> Input Class Initialized
INFO - 2018-07-28 02:26:46 --> Language Class Initialized
INFO - 2018-07-28 02:26:46 --> Language Class Initialized
INFO - 2018-07-28 02:26:46 --> Config Class Initialized
INFO - 2018-07-28 02:26:46 --> Loader Class Initialized
DEBUG - 2018-07-28 02:26:46 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 02:26:46 --> Helper loaded: url_helper
INFO - 2018-07-28 02:26:46 --> Helper loaded: form_helper
INFO - 2018-07-28 02:26:46 --> Helper loaded: date_helper
INFO - 2018-07-28 02:26:46 --> Helper loaded: util_helper
INFO - 2018-07-28 02:26:46 --> Helper loaded: text_helper
INFO - 2018-07-28 02:26:46 --> Helper loaded: string_helper
INFO - 2018-07-28 02:26:46 --> Database Driver Class Initialized
DEBUG - 2018-07-28 02:26:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 02:26:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 02:26:46 --> Email Class Initialized
INFO - 2018-07-28 02:26:46 --> Controller Class Initialized
DEBUG - 2018-07-28 02:26:46 --> Users MX_Controller Initialized
DEBUG - 2018-07-28 02:26:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 02:26:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-28 02:26:46 --> Helper loaded: file_helper
DEBUG - 2018-07-28 02:26:46 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 02:26:46 --> Login MX_Controller Initialized
INFO - 2018-07-28 02:26:46 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 02:26:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-28 02:26:46 --> Final output sent to browser
DEBUG - 2018-07-28 02:26:46 --> Total execution time: 0.7418
INFO - 2018-07-28 02:26:48 --> Config Class Initialized
INFO - 2018-07-28 02:26:48 --> Hooks Class Initialized
DEBUG - 2018-07-28 02:26:48 --> UTF-8 Support Enabled
INFO - 2018-07-28 02:26:48 --> Utf8 Class Initialized
INFO - 2018-07-28 02:26:48 --> URI Class Initialized
INFO - 2018-07-28 02:26:48 --> Router Class Initialized
INFO - 2018-07-28 02:26:48 --> Output Class Initialized
INFO - 2018-07-28 02:26:48 --> Security Class Initialized
DEBUG - 2018-07-28 02:26:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 02:26:48 --> Input Class Initialized
INFO - 2018-07-28 02:26:48 --> Language Class Initialized
INFO - 2018-07-28 02:26:48 --> Language Class Initialized
INFO - 2018-07-28 02:26:48 --> Config Class Initialized
INFO - 2018-07-28 02:26:48 --> Loader Class Initialized
DEBUG - 2018-07-28 02:26:48 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 02:26:48 --> Helper loaded: url_helper
INFO - 2018-07-28 02:26:48 --> Helper loaded: form_helper
INFO - 2018-07-28 02:26:48 --> Helper loaded: date_helper
INFO - 2018-07-28 02:26:48 --> Helper loaded: util_helper
INFO - 2018-07-28 02:26:48 --> Helper loaded: text_helper
INFO - 2018-07-28 02:26:48 --> Helper loaded: string_helper
INFO - 2018-07-28 02:26:48 --> Database Driver Class Initialized
DEBUG - 2018-07-28 02:26:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 02:26:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 02:26:48 --> Email Class Initialized
INFO - 2018-07-28 02:26:49 --> Controller Class Initialized
DEBUG - 2018-07-28 02:26:49 --> Users MX_Controller Initialized
DEBUG - 2018-07-28 02:26:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 02:26:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-28 02:26:49 --> Helper loaded: file_helper
DEBUG - 2018-07-28 02:26:49 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 02:26:49 --> Login MX_Controller Initialized
INFO - 2018-07-28 02:26:49 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 02:26:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-28 02:26:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-28 02:26:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-28 02:26:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-28 02:26:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-28 02:26:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-28 02:26:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-28 02:26:49 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-07-28 02:26:49 --> Final output sent to browser
DEBUG - 2018-07-28 02:26:49 --> Total execution time: 0.6819
INFO - 2018-07-28 02:28:43 --> Config Class Initialized
INFO - 2018-07-28 02:28:43 --> Hooks Class Initialized
DEBUG - 2018-07-28 02:28:43 --> UTF-8 Support Enabled
INFO - 2018-07-28 02:28:43 --> Utf8 Class Initialized
INFO - 2018-07-28 02:28:43 --> URI Class Initialized
INFO - 2018-07-28 02:28:43 --> Router Class Initialized
INFO - 2018-07-28 02:28:43 --> Output Class Initialized
INFO - 2018-07-28 02:28:43 --> Security Class Initialized
DEBUG - 2018-07-28 02:28:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 02:28:43 --> Input Class Initialized
INFO - 2018-07-28 02:28:43 --> Language Class Initialized
INFO - 2018-07-28 02:28:43 --> Language Class Initialized
INFO - 2018-07-28 02:28:43 --> Config Class Initialized
INFO - 2018-07-28 02:28:43 --> Loader Class Initialized
DEBUG - 2018-07-28 02:28:43 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 02:28:43 --> Helper loaded: url_helper
INFO - 2018-07-28 02:28:43 --> Helper loaded: form_helper
INFO - 2018-07-28 02:28:43 --> Helper loaded: date_helper
INFO - 2018-07-28 02:28:43 --> Helper loaded: util_helper
INFO - 2018-07-28 02:28:43 --> Helper loaded: text_helper
INFO - 2018-07-28 02:28:43 --> Helper loaded: string_helper
INFO - 2018-07-28 02:28:43 --> Database Driver Class Initialized
DEBUG - 2018-07-28 02:28:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 02:28:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 02:28:44 --> Email Class Initialized
INFO - 2018-07-28 02:28:44 --> Controller Class Initialized
DEBUG - 2018-07-28 02:28:44 --> Users MX_Controller Initialized
DEBUG - 2018-07-28 02:28:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 02:28:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-28 02:28:44 --> Helper loaded: file_helper
DEBUG - 2018-07-28 02:28:44 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 02:28:44 --> Login MX_Controller Initialized
INFO - 2018-07-28 02:28:44 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 02:28:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-28 02:28:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-28 02:28:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-28 02:28:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-28 02:28:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-28 02:28:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-28 02:28:44 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-07-28 02:28:44 --> Final output sent to browser
DEBUG - 2018-07-28 02:28:44 --> Total execution time: 0.6679
INFO - 2018-07-28 02:28:44 --> Config Class Initialized
INFO - 2018-07-28 02:28:44 --> Hooks Class Initialized
DEBUG - 2018-07-28 02:28:45 --> UTF-8 Support Enabled
INFO - 2018-07-28 02:28:45 --> Utf8 Class Initialized
INFO - 2018-07-28 02:28:45 --> URI Class Initialized
INFO - 2018-07-28 02:28:45 --> Router Class Initialized
INFO - 2018-07-28 02:28:45 --> Output Class Initialized
INFO - 2018-07-28 02:28:45 --> Security Class Initialized
DEBUG - 2018-07-28 02:28:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 02:28:45 --> Input Class Initialized
INFO - 2018-07-28 02:28:45 --> Language Class Initialized
INFO - 2018-07-28 02:28:45 --> Language Class Initialized
INFO - 2018-07-28 02:28:45 --> Config Class Initialized
INFO - 2018-07-28 02:28:45 --> Loader Class Initialized
DEBUG - 2018-07-28 02:28:45 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 02:28:45 --> Helper loaded: url_helper
INFO - 2018-07-28 02:28:45 --> Helper loaded: form_helper
INFO - 2018-07-28 02:28:45 --> Helper loaded: date_helper
INFO - 2018-07-28 02:28:45 --> Helper loaded: util_helper
INFO - 2018-07-28 02:28:45 --> Helper loaded: text_helper
INFO - 2018-07-28 02:28:45 --> Helper loaded: string_helper
INFO - 2018-07-28 02:28:45 --> Database Driver Class Initialized
DEBUG - 2018-07-28 02:28:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 02:28:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 02:28:45 --> Email Class Initialized
INFO - 2018-07-28 02:28:45 --> Controller Class Initialized
DEBUG - 2018-07-28 02:28:45 --> Users MX_Controller Initialized
DEBUG - 2018-07-28 02:28:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 02:28:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-28 02:28:45 --> Helper loaded: file_helper
DEBUG - 2018-07-28 02:28:45 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 02:28:45 --> Login MX_Controller Initialized
INFO - 2018-07-28 02:28:45 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 02:28:45 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-28 02:28:45 --> Final output sent to browser
DEBUG - 2018-07-28 02:28:45 --> Total execution time: 0.8285
INFO - 2018-07-28 02:35:46 --> Config Class Initialized
INFO - 2018-07-28 02:35:46 --> Hooks Class Initialized
DEBUG - 2018-07-28 02:35:46 --> UTF-8 Support Enabled
INFO - 2018-07-28 02:35:46 --> Utf8 Class Initialized
INFO - 2018-07-28 02:35:46 --> URI Class Initialized
DEBUG - 2018-07-28 02:35:46 --> No URI present. Default controller set.
INFO - 2018-07-28 02:35:46 --> Router Class Initialized
INFO - 2018-07-28 02:35:46 --> Output Class Initialized
INFO - 2018-07-28 02:35:46 --> Security Class Initialized
DEBUG - 2018-07-28 02:35:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 02:35:46 --> Input Class Initialized
INFO - 2018-07-28 02:35:46 --> Language Class Initialized
INFO - 2018-07-28 02:35:46 --> Language Class Initialized
INFO - 2018-07-28 02:35:46 --> Config Class Initialized
INFO - 2018-07-28 02:35:46 --> Loader Class Initialized
DEBUG - 2018-07-28 02:35:46 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 02:35:46 --> Helper loaded: url_helper
INFO - 2018-07-28 02:35:46 --> Helper loaded: form_helper
INFO - 2018-07-28 02:35:46 --> Helper loaded: date_helper
INFO - 2018-07-28 02:35:46 --> Helper loaded: util_helper
INFO - 2018-07-28 02:35:46 --> Helper loaded: text_helper
INFO - 2018-07-28 02:35:46 --> Helper loaded: string_helper
INFO - 2018-07-28 02:35:46 --> Database Driver Class Initialized
DEBUG - 2018-07-28 02:35:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 02:35:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 02:35:47 --> Email Class Initialized
INFO - 2018-07-28 02:35:47 --> Controller Class Initialized
DEBUG - 2018-07-28 02:35:47 --> Home MX_Controller Initialized
DEBUG - 2018-07-28 02:35:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-28 02:35:47 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 02:35:47 --> Login MX_Controller Initialized
INFO - 2018-07-28 02:35:47 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 02:35:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 02:35:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-28 02:35:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-28 02:35:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-28 02:35:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-28 02:35:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-28 02:35:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-28 02:35:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-28 02:35:47 --> Final output sent to browser
DEBUG - 2018-07-28 02:35:47 --> Total execution time: 0.6905
INFO - 2018-07-28 02:35:47 --> Config Class Initialized
INFO - 2018-07-28 02:35:47 --> Hooks Class Initialized
INFO - 2018-07-28 02:35:47 --> Config Class Initialized
DEBUG - 2018-07-28 02:35:47 --> UTF-8 Support Enabled
INFO - 2018-07-28 02:35:47 --> Hooks Class Initialized
INFO - 2018-07-28 02:35:47 --> Utf8 Class Initialized
DEBUG - 2018-07-28 02:35:47 --> UTF-8 Support Enabled
INFO - 2018-07-28 02:35:47 --> Utf8 Class Initialized
INFO - 2018-07-28 02:35:48 --> URI Class Initialized
INFO - 2018-07-28 02:35:48 --> Router Class Initialized
INFO - 2018-07-28 02:35:48 --> URI Class Initialized
INFO - 2018-07-28 02:35:48 --> Output Class Initialized
INFO - 2018-07-28 02:35:48 --> Router Class Initialized
INFO - 2018-07-28 02:35:48 --> Security Class Initialized
DEBUG - 2018-07-28 02:35:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 02:35:48 --> Output Class Initialized
INFO - 2018-07-28 02:35:48 --> Input Class Initialized
INFO - 2018-07-28 02:35:48 --> Language Class Initialized
INFO - 2018-07-28 02:35:48 --> Language Class Initialized
INFO - 2018-07-28 02:35:48 --> Security Class Initialized
INFO - 2018-07-28 02:35:48 --> Config Class Initialized
INFO - 2018-07-28 02:35:48 --> Loader Class Initialized
DEBUG - 2018-07-28 02:35:48 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 02:35:48 --> Helper loaded: url_helper
INFO - 2018-07-28 02:35:48 --> Helper loaded: form_helper
INFO - 2018-07-28 02:35:48 --> Helper loaded: date_helper
INFO - 2018-07-28 02:35:48 --> Helper loaded: util_helper
INFO - 2018-07-28 02:35:48 --> Helper loaded: text_helper
INFO - 2018-07-28 02:35:48 --> Helper loaded: string_helper
DEBUG - 2018-07-28 02:35:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 02:35:48 --> Database Driver Class Initialized
INFO - 2018-07-28 02:35:48 --> Input Class Initialized
DEBUG - 2018-07-28 02:35:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 02:35:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 02:35:48 --> Language Class Initialized
ERROR - 2018-07-28 02:35:48 --> 404 Page Not Found: /index
INFO - 2018-07-28 02:35:48 --> Email Class Initialized
INFO - 2018-07-28 02:35:48 --> Controller Class Initialized
INFO - 2018-07-28 02:35:48 --> Config Class Initialized
INFO - 2018-07-28 02:35:48 --> Hooks Class Initialized
DEBUG - 2018-07-28 02:35:48 --> Home MX_Controller Initialized
DEBUG - 2018-07-28 02:35:48 --> UTF-8 Support Enabled
DEBUG - 2018-07-28 02:35:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-07-28 02:35:48 --> Utf8 Class Initialized
DEBUG - 2018-07-28 02:35:48 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 02:35:48 --> Login MX_Controller Initialized
INFO - 2018-07-28 02:35:48 --> URI Class Initialized
INFO - 2018-07-28 02:35:48 --> Language file loaded: language/english/data_lang.php
INFO - 2018-07-28 02:35:48 --> Router Class Initialized
DEBUG - 2018-07-28 02:35:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-28 02:35:48 --> Output Class Initialized
DEBUG - 2018-07-28 02:35:48 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-28 02:35:48 --> Security Class Initialized
DEBUG - 2018-07-28 02:35:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 02:35:48 --> Input Class Initialized
INFO - 2018-07-28 02:35:48 --> Language Class Initialized
ERROR - 2018-07-28 02:35:48 --> 404 Page Not Found: /index
INFO - 2018-07-28 02:35:48 --> Config Class Initialized
INFO - 2018-07-28 02:35:48 --> Hooks Class Initialized
DEBUG - 2018-07-28 02:35:48 --> UTF-8 Support Enabled
INFO - 2018-07-28 02:35:48 --> Utf8 Class Initialized
INFO - 2018-07-28 02:35:48 --> URI Class Initialized
INFO - 2018-07-28 02:35:48 --> Router Class Initialized
INFO - 2018-07-28 02:35:48 --> Output Class Initialized
INFO - 2018-07-28 02:35:48 --> Security Class Initialized
DEBUG - 2018-07-28 02:35:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 02:35:48 --> Input Class Initialized
INFO - 2018-07-28 02:35:48 --> Language Class Initialized
ERROR - 2018-07-28 02:35:48 --> 404 Page Not Found: /index
INFO - 2018-07-28 02:35:48 --> Config Class Initialized
INFO - 2018-07-28 02:35:48 --> Hooks Class Initialized
DEBUG - 2018-07-28 02:35:48 --> UTF-8 Support Enabled
INFO - 2018-07-28 02:35:48 --> Utf8 Class Initialized
INFO - 2018-07-28 02:35:48 --> URI Class Initialized
INFO - 2018-07-28 02:35:49 --> Router Class Initialized
INFO - 2018-07-28 02:35:49 --> Output Class Initialized
INFO - 2018-07-28 02:35:49 --> Security Class Initialized
DEBUG - 2018-07-28 02:35:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 02:35:49 --> Input Class Initialized
INFO - 2018-07-28 02:35:49 --> Language Class Initialized
ERROR - 2018-07-28 02:35:49 --> 404 Page Not Found: /index
INFO - 2018-07-28 02:35:49 --> Config Class Initialized
INFO - 2018-07-28 02:35:49 --> Hooks Class Initialized
DEBUG - 2018-07-28 02:35:49 --> UTF-8 Support Enabled
INFO - 2018-07-28 02:35:49 --> Utf8 Class Initialized
INFO - 2018-07-28 02:35:49 --> URI Class Initialized
INFO - 2018-07-28 02:35:49 --> Router Class Initialized
INFO - 2018-07-28 02:35:49 --> Output Class Initialized
INFO - 2018-07-28 02:35:49 --> Security Class Initialized
DEBUG - 2018-07-28 02:35:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 02:35:49 --> Input Class Initialized
INFO - 2018-07-28 02:35:49 --> Language Class Initialized
ERROR - 2018-07-28 02:35:49 --> 404 Page Not Found: /index
INFO - 2018-07-28 02:35:49 --> Config Class Initialized
INFO - 2018-07-28 02:35:49 --> Hooks Class Initialized
DEBUG - 2018-07-28 02:35:49 --> UTF-8 Support Enabled
INFO - 2018-07-28 02:35:49 --> Utf8 Class Initialized
INFO - 2018-07-28 02:35:49 --> URI Class Initialized
INFO - 2018-07-28 02:35:49 --> Router Class Initialized
INFO - 2018-07-28 02:35:49 --> Output Class Initialized
INFO - 2018-07-28 02:35:49 --> Security Class Initialized
DEBUG - 2018-07-28 02:35:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 02:35:49 --> Input Class Initialized
INFO - 2018-07-28 02:35:49 --> Language Class Initialized
ERROR - 2018-07-28 02:35:49 --> 404 Page Not Found: /index
INFO - 2018-07-28 02:36:05 --> Config Class Initialized
INFO - 2018-07-28 02:36:05 --> Hooks Class Initialized
DEBUG - 2018-07-28 02:36:05 --> UTF-8 Support Enabled
INFO - 2018-07-28 02:36:05 --> Utf8 Class Initialized
INFO - 2018-07-28 02:36:05 --> URI Class Initialized
INFO - 2018-07-28 02:36:05 --> Router Class Initialized
INFO - 2018-07-28 02:36:05 --> Output Class Initialized
INFO - 2018-07-28 02:36:05 --> Security Class Initialized
DEBUG - 2018-07-28 02:36:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 02:36:05 --> Input Class Initialized
INFO - 2018-07-28 02:36:05 --> Language Class Initialized
INFO - 2018-07-28 02:36:05 --> Language Class Initialized
INFO - 2018-07-28 02:36:05 --> Config Class Initialized
INFO - 2018-07-28 02:36:05 --> Loader Class Initialized
DEBUG - 2018-07-28 02:36:05 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 02:36:05 --> Helper loaded: url_helper
INFO - 2018-07-28 02:36:06 --> Helper loaded: form_helper
INFO - 2018-07-28 02:36:06 --> Helper loaded: date_helper
INFO - 2018-07-28 02:36:06 --> Helper loaded: util_helper
INFO - 2018-07-28 02:36:06 --> Helper loaded: text_helper
INFO - 2018-07-28 02:36:06 --> Helper loaded: string_helper
INFO - 2018-07-28 02:36:06 --> Database Driver Class Initialized
DEBUG - 2018-07-28 02:36:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 02:36:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 02:36:06 --> Email Class Initialized
INFO - 2018-07-28 02:36:06 --> Controller Class Initialized
DEBUG - 2018-07-28 02:36:06 --> Users MX_Controller Initialized
DEBUG - 2018-07-28 02:36:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 02:36:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-28 02:36:06 --> Helper loaded: file_helper
DEBUG - 2018-07-28 02:36:06 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 02:36:06 --> Login MX_Controller Initialized
INFO - 2018-07-28 02:36:06 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 02:36:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-28 02:36:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-28 02:36:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-28 02:36:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-28 02:36:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-28 02:36:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-28 02:36:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-28 02:36:06 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/create_user.php
INFO - 2018-07-28 02:36:06 --> Final output sent to browser
DEBUG - 2018-07-28 02:36:06 --> Total execution time: 0.6640
INFO - 2018-07-28 02:36:16 --> Config Class Initialized
INFO - 2018-07-28 02:36:17 --> Hooks Class Initialized
DEBUG - 2018-07-28 02:36:17 --> UTF-8 Support Enabled
INFO - 2018-07-28 02:36:17 --> Utf8 Class Initialized
INFO - 2018-07-28 02:36:17 --> URI Class Initialized
INFO - 2018-07-28 02:36:17 --> Router Class Initialized
INFO - 2018-07-28 02:36:17 --> Output Class Initialized
INFO - 2018-07-28 02:36:17 --> Security Class Initialized
DEBUG - 2018-07-28 02:36:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 02:36:17 --> Input Class Initialized
INFO - 2018-07-28 02:36:17 --> Language Class Initialized
INFO - 2018-07-28 02:36:17 --> Language Class Initialized
INFO - 2018-07-28 02:36:17 --> Config Class Initialized
INFO - 2018-07-28 02:36:17 --> Loader Class Initialized
DEBUG - 2018-07-28 02:36:17 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 02:36:17 --> Helper loaded: url_helper
INFO - 2018-07-28 02:36:17 --> Helper loaded: form_helper
INFO - 2018-07-28 02:36:17 --> Helper loaded: date_helper
INFO - 2018-07-28 02:36:17 --> Helper loaded: util_helper
INFO - 2018-07-28 02:36:17 --> Helper loaded: text_helper
INFO - 2018-07-28 02:36:17 --> Helper loaded: string_helper
INFO - 2018-07-28 02:36:17 --> Database Driver Class Initialized
DEBUG - 2018-07-28 02:36:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 02:36:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 02:36:17 --> Email Class Initialized
INFO - 2018-07-28 02:36:17 --> Controller Class Initialized
DEBUG - 2018-07-28 02:36:17 --> Users MX_Controller Initialized
DEBUG - 2018-07-28 02:36:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 02:36:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-28 02:36:17 --> Helper loaded: file_helper
DEBUG - 2018-07-28 02:36:17 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 02:36:17 --> Login MX_Controller Initialized
INFO - 2018-07-28 02:36:17 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 02:36:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-28 02:36:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-28 02:36:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
ERROR - 2018-07-28 02:36:17 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable E:\xampp\htdocs\consulting\application\modules\admin\controllers\Users.php 323
INFO - 2018-07-28 02:36:17 --> Config Class Initialized
INFO - 2018-07-28 02:36:17 --> Hooks Class Initialized
DEBUG - 2018-07-28 02:36:17 --> UTF-8 Support Enabled
INFO - 2018-07-28 02:36:17 --> Utf8 Class Initialized
INFO - 2018-07-28 02:36:17 --> URI Class Initialized
INFO - 2018-07-28 02:36:17 --> Router Class Initialized
INFO - 2018-07-28 02:36:17 --> Output Class Initialized
INFO - 2018-07-28 02:36:17 --> Security Class Initialized
DEBUG - 2018-07-28 02:36:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 02:36:17 --> Input Class Initialized
INFO - 2018-07-28 02:36:17 --> Language Class Initialized
INFO - 2018-07-28 02:36:17 --> Language Class Initialized
INFO - 2018-07-28 02:36:17 --> Config Class Initialized
INFO - 2018-07-28 02:36:17 --> Loader Class Initialized
DEBUG - 2018-07-28 02:36:17 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 02:36:18 --> Helper loaded: url_helper
INFO - 2018-07-28 02:36:18 --> Helper loaded: form_helper
INFO - 2018-07-28 02:36:18 --> Helper loaded: date_helper
INFO - 2018-07-28 02:36:18 --> Helper loaded: util_helper
INFO - 2018-07-28 02:36:18 --> Helper loaded: text_helper
INFO - 2018-07-28 02:36:18 --> Helper loaded: string_helper
INFO - 2018-07-28 02:36:18 --> Database Driver Class Initialized
DEBUG - 2018-07-28 02:36:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 02:36:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 02:36:18 --> Email Class Initialized
INFO - 2018-07-28 02:36:18 --> Controller Class Initialized
DEBUG - 2018-07-28 02:36:18 --> Users MX_Controller Initialized
DEBUG - 2018-07-28 02:36:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 02:36:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-28 02:36:18 --> Helper loaded: file_helper
DEBUG - 2018-07-28 02:36:18 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 02:36:18 --> Login MX_Controller Initialized
INFO - 2018-07-28 02:36:18 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 02:36:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-28 02:36:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-28 02:36:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-28 02:36:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-28 02:36:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-28 02:36:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-28 02:36:18 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-07-28 02:36:18 --> Final output sent to browser
DEBUG - 2018-07-28 02:36:18 --> Total execution time: 0.6617
INFO - 2018-07-28 02:36:18 --> Config Class Initialized
INFO - 2018-07-28 02:36:18 --> Hooks Class Initialized
DEBUG - 2018-07-28 02:36:18 --> UTF-8 Support Enabled
INFO - 2018-07-28 02:36:18 --> Utf8 Class Initialized
INFO - 2018-07-28 02:36:18 --> URI Class Initialized
INFO - 2018-07-28 02:36:18 --> Router Class Initialized
INFO - 2018-07-28 02:36:18 --> Output Class Initialized
INFO - 2018-07-28 02:36:18 --> Security Class Initialized
DEBUG - 2018-07-28 02:36:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 02:36:18 --> Input Class Initialized
INFO - 2018-07-28 02:36:18 --> Language Class Initialized
INFO - 2018-07-28 02:36:18 --> Language Class Initialized
INFO - 2018-07-28 02:36:19 --> Config Class Initialized
INFO - 2018-07-28 02:36:19 --> Loader Class Initialized
DEBUG - 2018-07-28 02:36:19 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 02:36:19 --> Helper loaded: url_helper
INFO - 2018-07-28 02:36:19 --> Helper loaded: form_helper
INFO - 2018-07-28 02:36:19 --> Helper loaded: date_helper
INFO - 2018-07-28 02:36:19 --> Helper loaded: util_helper
INFO - 2018-07-28 02:36:19 --> Helper loaded: text_helper
INFO - 2018-07-28 02:36:19 --> Helper loaded: string_helper
INFO - 2018-07-28 02:36:19 --> Database Driver Class Initialized
DEBUG - 2018-07-28 02:36:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 02:36:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 02:36:19 --> Email Class Initialized
INFO - 2018-07-28 02:36:19 --> Controller Class Initialized
DEBUG - 2018-07-28 02:36:19 --> Users MX_Controller Initialized
DEBUG - 2018-07-28 02:36:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 02:36:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-28 02:36:19 --> Helper loaded: file_helper
DEBUG - 2018-07-28 02:36:19 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 02:36:19 --> Login MX_Controller Initialized
INFO - 2018-07-28 02:36:19 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 02:36:19 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-28 02:36:19 --> Final output sent to browser
DEBUG - 2018-07-28 02:36:19 --> Total execution time: 0.6669
INFO - 2018-07-28 02:36:22 --> Config Class Initialized
INFO - 2018-07-28 02:36:22 --> Hooks Class Initialized
DEBUG - 2018-07-28 02:36:22 --> UTF-8 Support Enabled
INFO - 2018-07-28 02:36:22 --> Utf8 Class Initialized
INFO - 2018-07-28 02:36:22 --> URI Class Initialized
DEBUG - 2018-07-28 02:36:22 --> No URI present. Default controller set.
INFO - 2018-07-28 02:36:22 --> Router Class Initialized
INFO - 2018-07-28 02:36:22 --> Output Class Initialized
INFO - 2018-07-28 02:36:22 --> Security Class Initialized
DEBUG - 2018-07-28 02:36:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 02:36:22 --> Input Class Initialized
INFO - 2018-07-28 02:36:22 --> Language Class Initialized
INFO - 2018-07-28 02:36:22 --> Language Class Initialized
INFO - 2018-07-28 02:36:22 --> Config Class Initialized
INFO - 2018-07-28 02:36:22 --> Loader Class Initialized
DEBUG - 2018-07-28 02:36:22 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 02:36:22 --> Helper loaded: url_helper
INFO - 2018-07-28 02:36:22 --> Helper loaded: form_helper
INFO - 2018-07-28 02:36:22 --> Helper loaded: date_helper
INFO - 2018-07-28 02:36:22 --> Helper loaded: util_helper
INFO - 2018-07-28 02:36:22 --> Helper loaded: text_helper
INFO - 2018-07-28 02:36:22 --> Helper loaded: string_helper
INFO - 2018-07-28 02:36:23 --> Database Driver Class Initialized
DEBUG - 2018-07-28 02:36:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 02:36:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 02:36:23 --> Email Class Initialized
INFO - 2018-07-28 02:36:23 --> Controller Class Initialized
DEBUG - 2018-07-28 02:36:23 --> Home MX_Controller Initialized
DEBUG - 2018-07-28 02:36:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-28 02:36:23 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 02:36:23 --> Login MX_Controller Initialized
INFO - 2018-07-28 02:36:23 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 02:36:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 02:36:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-28 02:36:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-28 02:36:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-28 02:36:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-28 02:36:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-28 02:36:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-28 02:36:23 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-28 02:36:23 --> Final output sent to browser
DEBUG - 2018-07-28 02:36:23 --> Total execution time: 0.7099
INFO - 2018-07-28 02:36:23 --> Config Class Initialized
INFO - 2018-07-28 02:36:23 --> Hooks Class Initialized
INFO - 2018-07-28 02:36:23 --> Config Class Initialized
INFO - 2018-07-28 02:36:23 --> Hooks Class Initialized
DEBUG - 2018-07-28 02:36:23 --> UTF-8 Support Enabled
DEBUG - 2018-07-28 02:36:23 --> UTF-8 Support Enabled
INFO - 2018-07-28 02:36:23 --> Utf8 Class Initialized
INFO - 2018-07-28 02:36:23 --> Utf8 Class Initialized
INFO - 2018-07-28 02:36:23 --> URI Class Initialized
INFO - 2018-07-28 02:36:23 --> Router Class Initialized
INFO - 2018-07-28 02:36:23 --> URI Class Initialized
INFO - 2018-07-28 02:36:23 --> Output Class Initialized
INFO - 2018-07-28 02:36:24 --> Router Class Initialized
INFO - 2018-07-28 02:36:24 --> Security Class Initialized
INFO - 2018-07-28 02:36:24 --> Output Class Initialized
DEBUG - 2018-07-28 02:36:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 02:36:24 --> Security Class Initialized
INFO - 2018-07-28 02:36:24 --> Input Class Initialized
INFO - 2018-07-28 02:36:24 --> Language Class Initialized
INFO - 2018-07-28 02:36:24 --> Language Class Initialized
DEBUG - 2018-07-28 02:36:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 02:36:24 --> Config Class Initialized
INFO - 2018-07-28 02:36:24 --> Input Class Initialized
INFO - 2018-07-28 02:36:24 --> Loader Class Initialized
INFO - 2018-07-28 02:36:24 --> Language Class Initialized
ERROR - 2018-07-28 02:36:24 --> 404 Page Not Found: /index
INFO - 2018-07-28 02:36:24 --> Config Class Initialized
INFO - 2018-07-28 02:36:24 --> Hooks Class Initialized
DEBUG - 2018-07-28 02:36:24 --> UTF-8 Support Enabled
INFO - 2018-07-28 02:36:24 --> Utf8 Class Initialized
INFO - 2018-07-28 02:36:24 --> URI Class Initialized
INFO - 2018-07-28 02:36:24 --> Router Class Initialized
DEBUG - 2018-07-28 02:36:24 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 02:36:24 --> Helper loaded: url_helper
INFO - 2018-07-28 02:36:24 --> Output Class Initialized
INFO - 2018-07-28 02:36:24 --> Security Class Initialized
INFO - 2018-07-28 02:36:24 --> Helper loaded: form_helper
DEBUG - 2018-07-28 02:36:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 02:36:24 --> Helper loaded: date_helper
INFO - 2018-07-28 02:36:24 --> Input Class Initialized
INFO - 2018-07-28 02:36:24 --> Helper loaded: util_helper
INFO - 2018-07-28 02:36:24 --> Helper loaded: text_helper
INFO - 2018-07-28 02:36:24 --> Language Class Initialized
INFO - 2018-07-28 02:36:24 --> Helper loaded: string_helper
ERROR - 2018-07-28 02:36:24 --> 404 Page Not Found: /index
INFO - 2018-07-28 02:36:24 --> Database Driver Class Initialized
INFO - 2018-07-28 02:36:24 --> Config Class Initialized
INFO - 2018-07-28 02:36:24 --> Hooks Class Initialized
DEBUG - 2018-07-28 02:36:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 02:36:24 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-07-28 02:36:24 --> UTF-8 Support Enabled
INFO - 2018-07-28 02:36:24 --> Utf8 Class Initialized
INFO - 2018-07-28 02:36:24 --> Email Class Initialized
INFO - 2018-07-28 02:36:24 --> Controller Class Initialized
INFO - 2018-07-28 02:36:24 --> URI Class Initialized
DEBUG - 2018-07-28 02:36:24 --> Home MX_Controller Initialized
DEBUG - 2018-07-28 02:36:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
INFO - 2018-07-28 02:36:24 --> Router Class Initialized
INFO - 2018-07-28 02:36:24 --> Output Class Initialized
DEBUG - 2018-07-28 02:36:24 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 02:36:24 --> Login MX_Controller Initialized
INFO - 2018-07-28 02:36:24 --> Language file loaded: language/english/data_lang.php
INFO - 2018-07-28 02:36:24 --> Security Class Initialized
DEBUG - 2018-07-28 02:36:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 02:36:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 02:36:24 --> Input Class Initialized
DEBUG - 2018-07-28 02:36:24 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-28 02:36:24 --> Language Class Initialized
ERROR - 2018-07-28 02:36:24 --> 404 Page Not Found: /index
INFO - 2018-07-28 02:36:25 --> Config Class Initialized
INFO - 2018-07-28 02:36:25 --> Hooks Class Initialized
DEBUG - 2018-07-28 02:36:25 --> UTF-8 Support Enabled
INFO - 2018-07-28 02:36:25 --> Utf8 Class Initialized
INFO - 2018-07-28 02:36:25 --> URI Class Initialized
INFO - 2018-07-28 02:36:25 --> Router Class Initialized
INFO - 2018-07-28 02:36:25 --> Output Class Initialized
INFO - 2018-07-28 02:36:25 --> Security Class Initialized
DEBUG - 2018-07-28 02:36:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 02:36:25 --> Input Class Initialized
INFO - 2018-07-28 02:36:25 --> Language Class Initialized
INFO - 2018-07-28 02:36:25 --> Language Class Initialized
INFO - 2018-07-28 02:36:25 --> Config Class Initialized
INFO - 2018-07-28 02:36:25 --> Loader Class Initialized
DEBUG - 2018-07-28 02:36:25 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 02:36:25 --> Helper loaded: url_helper
INFO - 2018-07-28 02:36:25 --> Helper loaded: form_helper
INFO - 2018-07-28 02:36:25 --> Helper loaded: date_helper
INFO - 2018-07-28 02:36:25 --> Helper loaded: util_helper
INFO - 2018-07-28 02:36:26 --> Helper loaded: text_helper
INFO - 2018-07-28 02:36:26 --> Helper loaded: string_helper
INFO - 2018-07-28 02:36:26 --> Database Driver Class Initialized
DEBUG - 2018-07-28 02:36:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 02:36:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 02:36:26 --> Email Class Initialized
INFO - 2018-07-28 02:36:26 --> Controller Class Initialized
DEBUG - 2018-07-28 02:36:26 --> Home MX_Controller Initialized
DEBUG - 2018-07-28 02:36:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-28 02:36:26 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 02:36:26 --> Login MX_Controller Initialized
INFO - 2018-07-28 02:36:26 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 02:36:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 02:36:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-28 02:36:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-28 02:36:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-28 02:36:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-28 02:36:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-28 02:36:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-28 02:36:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/course.php
INFO - 2018-07-28 02:36:26 --> Final output sent to browser
DEBUG - 2018-07-28 02:36:26 --> Total execution time: 0.7256
INFO - 2018-07-28 02:36:26 --> Config Class Initialized
INFO - 2018-07-28 02:36:26 --> Config Class Initialized
INFO - 2018-07-28 02:36:26 --> Hooks Class Initialized
INFO - 2018-07-28 02:36:26 --> Hooks Class Initialized
DEBUG - 2018-07-28 02:36:26 --> UTF-8 Support Enabled
DEBUG - 2018-07-28 02:36:26 --> UTF-8 Support Enabled
INFO - 2018-07-28 02:36:26 --> Config Class Initialized
INFO - 2018-07-28 02:36:26 --> Hooks Class Initialized
DEBUG - 2018-07-28 02:36:26 --> UTF-8 Support Enabled
INFO - 2018-07-28 02:36:26 --> Utf8 Class Initialized
INFO - 2018-07-28 02:36:26 --> Utf8 Class Initialized
INFO - 2018-07-28 02:36:26 --> Utf8 Class Initialized
INFO - 2018-07-28 02:36:26 --> URI Class Initialized
INFO - 2018-07-28 02:36:26 --> URI Class Initialized
INFO - 2018-07-28 02:36:26 --> Router Class Initialized
INFO - 2018-07-28 02:36:26 --> URI Class Initialized
INFO - 2018-07-28 02:36:26 --> Output Class Initialized
INFO - 2018-07-28 02:36:26 --> Router Class Initialized
INFO - 2018-07-28 02:36:26 --> Router Class Initialized
INFO - 2018-07-28 02:36:26 --> Security Class Initialized
INFO - 2018-07-28 02:36:26 --> Output Class Initialized
INFO - 2018-07-28 02:36:26 --> Output Class Initialized
DEBUG - 2018-07-28 02:36:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 02:36:26 --> Security Class Initialized
DEBUG - 2018-07-28 02:36:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 02:36:26 --> Input Class Initialized
INFO - 2018-07-28 02:36:26 --> Input Class Initialized
INFO - 2018-07-28 02:36:26 --> Security Class Initialized
INFO - 2018-07-28 02:36:26 --> Language Class Initialized
INFO - 2018-07-28 02:36:26 --> Language Class Initialized
INFO - 2018-07-28 02:36:27 --> Language Class Initialized
DEBUG - 2018-07-28 02:36:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 02:36:27 --> Input Class Initialized
INFO - 2018-07-28 02:36:27 --> Config Class Initialized
ERROR - 2018-07-28 02:36:27 --> 404 Page Not Found: /index
INFO - 2018-07-28 02:36:27 --> Loader Class Initialized
INFO - 2018-07-28 02:36:27 --> Language Class Initialized
ERROR - 2018-07-28 02:36:27 --> 404 Page Not Found: /index
DEBUG - 2018-07-28 02:36:27 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 02:36:27 --> Config Class Initialized
INFO - 2018-07-28 02:36:27 --> Helper loaded: url_helper
INFO - 2018-07-28 02:36:27 --> Hooks Class Initialized
INFO - 2018-07-28 02:36:27 --> Helper loaded: form_helper
DEBUG - 2018-07-28 02:36:27 --> UTF-8 Support Enabled
INFO - 2018-07-28 02:36:27 --> Utf8 Class Initialized
INFO - 2018-07-28 02:36:27 --> Helper loaded: date_helper
INFO - 2018-07-28 02:36:27 --> URI Class Initialized
INFO - 2018-07-28 02:36:27 --> Helper loaded: util_helper
INFO - 2018-07-28 02:36:27 --> Helper loaded: text_helper
INFO - 2018-07-28 02:36:27 --> Router Class Initialized
INFO - 2018-07-28 02:36:27 --> Helper loaded: string_helper
INFO - 2018-07-28 02:36:27 --> Output Class Initialized
INFO - 2018-07-28 02:36:27 --> Security Class Initialized
INFO - 2018-07-28 02:36:27 --> Database Driver Class Initialized
DEBUG - 2018-07-28 02:36:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 02:36:27 --> Input Class Initialized
DEBUG - 2018-07-28 02:36:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 02:36:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 02:36:27 --> Language Class Initialized
INFO - 2018-07-28 02:36:27 --> Email Class Initialized
INFO - 2018-07-28 02:36:27 --> Controller Class Initialized
DEBUG - 2018-07-28 02:36:27 --> Home MX_Controller Initialized
DEBUG - 2018-07-28 02:36:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
ERROR - 2018-07-28 02:36:27 --> 404 Page Not Found: /index
INFO - 2018-07-28 02:36:27 --> Config Class Initialized
DEBUG - 2018-07-28 02:36:27 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
INFO - 2018-07-28 02:36:27 --> Hooks Class Initialized
DEBUG - 2018-07-28 02:36:27 --> Login MX_Controller Initialized
DEBUG - 2018-07-28 02:36:27 --> UTF-8 Support Enabled
INFO - 2018-07-28 02:36:27 --> Language file loaded: language/english/data_lang.php
INFO - 2018-07-28 02:36:27 --> Utf8 Class Initialized
DEBUG - 2018-07-28 02:36:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-28 02:36:27 --> URI Class Initialized
DEBUG - 2018-07-28 02:36:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-28 02:36:27 --> Router Class Initialized
INFO - 2018-07-28 02:36:27 --> Output Class Initialized
INFO - 2018-07-28 02:36:27 --> Security Class Initialized
DEBUG - 2018-07-28 02:36:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 02:36:27 --> Input Class Initialized
INFO - 2018-07-28 02:36:27 --> Language Class Initialized
ERROR - 2018-07-28 02:36:27 --> 404 Page Not Found: /index
INFO - 2018-07-28 02:36:30 --> Config Class Initialized
INFO - 2018-07-28 02:36:30 --> Hooks Class Initialized
DEBUG - 2018-07-28 02:36:30 --> UTF-8 Support Enabled
INFO - 2018-07-28 02:36:30 --> Utf8 Class Initialized
INFO - 2018-07-28 02:36:30 --> URI Class Initialized
DEBUG - 2018-07-28 02:36:30 --> No URI present. Default controller set.
INFO - 2018-07-28 02:36:30 --> Router Class Initialized
INFO - 2018-07-28 02:36:30 --> Output Class Initialized
INFO - 2018-07-28 02:36:30 --> Security Class Initialized
DEBUG - 2018-07-28 02:36:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 02:36:30 --> Input Class Initialized
INFO - 2018-07-28 02:36:30 --> Language Class Initialized
INFO - 2018-07-28 02:36:30 --> Language Class Initialized
INFO - 2018-07-28 02:36:30 --> Config Class Initialized
INFO - 2018-07-28 02:36:30 --> Loader Class Initialized
DEBUG - 2018-07-28 02:36:30 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 02:36:30 --> Helper loaded: url_helper
INFO - 2018-07-28 02:36:30 --> Helper loaded: form_helper
INFO - 2018-07-28 02:36:30 --> Helper loaded: date_helper
INFO - 2018-07-28 02:36:30 --> Helper loaded: util_helper
INFO - 2018-07-28 02:36:30 --> Helper loaded: text_helper
INFO - 2018-07-28 02:36:30 --> Helper loaded: string_helper
INFO - 2018-07-28 02:36:30 --> Database Driver Class Initialized
DEBUG - 2018-07-28 02:36:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 02:36:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 02:36:30 --> Email Class Initialized
INFO - 2018-07-28 02:36:30 --> Controller Class Initialized
DEBUG - 2018-07-28 02:36:30 --> Home MX_Controller Initialized
DEBUG - 2018-07-28 02:36:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-28 02:36:30 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 02:36:30 --> Login MX_Controller Initialized
INFO - 2018-07-28 02:36:30 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 02:36:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 02:36:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-28 02:36:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-28 02:36:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-28 02:36:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-28 02:36:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-28 02:36:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-28 02:36:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-28 02:36:31 --> Final output sent to browser
DEBUG - 2018-07-28 02:36:31 --> Total execution time: 0.6895
INFO - 2018-07-28 02:36:31 --> Config Class Initialized
INFO - 2018-07-28 02:36:31 --> Hooks Class Initialized
INFO - 2018-07-28 02:36:31 --> Config Class Initialized
INFO - 2018-07-28 02:36:31 --> Hooks Class Initialized
DEBUG - 2018-07-28 02:36:31 --> UTF-8 Support Enabled
DEBUG - 2018-07-28 02:36:31 --> UTF-8 Support Enabled
INFO - 2018-07-28 02:36:31 --> Utf8 Class Initialized
INFO - 2018-07-28 02:36:31 --> Utf8 Class Initialized
INFO - 2018-07-28 02:36:31 --> URI Class Initialized
INFO - 2018-07-28 02:36:31 --> URI Class Initialized
INFO - 2018-07-28 02:36:31 --> Router Class Initialized
INFO - 2018-07-28 02:36:31 --> Router Class Initialized
INFO - 2018-07-28 02:36:31 --> Output Class Initialized
INFO - 2018-07-28 02:36:31 --> Output Class Initialized
INFO - 2018-07-28 02:36:31 --> Security Class Initialized
DEBUG - 2018-07-28 02:36:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 02:36:31 --> Input Class Initialized
INFO - 2018-07-28 02:36:31 --> Language Class Initialized
INFO - 2018-07-28 02:36:31 --> Language Class Initialized
INFO - 2018-07-28 02:36:31 --> Security Class Initialized
INFO - 2018-07-28 02:36:31 --> Config Class Initialized
INFO - 2018-07-28 02:36:31 --> Loader Class Initialized
DEBUG - 2018-07-28 02:36:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-07-28 02:36:31 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 02:36:31 --> Input Class Initialized
INFO - 2018-07-28 02:36:31 --> Helper loaded: url_helper
INFO - 2018-07-28 02:36:31 --> Language Class Initialized
ERROR - 2018-07-28 02:36:31 --> 404 Page Not Found: /index
INFO - 2018-07-28 02:36:31 --> Helper loaded: form_helper
INFO - 2018-07-28 02:36:31 --> Helper loaded: date_helper
INFO - 2018-07-28 02:36:31 --> Config Class Initialized
INFO - 2018-07-28 02:36:31 --> Hooks Class Initialized
INFO - 2018-07-28 02:36:31 --> Helper loaded: util_helper
DEBUG - 2018-07-28 02:36:31 --> UTF-8 Support Enabled
INFO - 2018-07-28 02:36:31 --> Helper loaded: text_helper
INFO - 2018-07-28 02:36:31 --> Utf8 Class Initialized
INFO - 2018-07-28 02:36:31 --> URI Class Initialized
INFO - 2018-07-28 02:36:31 --> Router Class Initialized
INFO - 2018-07-28 02:36:31 --> Output Class Initialized
INFO - 2018-07-28 02:36:31 --> Helper loaded: string_helper
INFO - 2018-07-28 02:36:31 --> Security Class Initialized
INFO - 2018-07-28 02:36:31 --> Database Driver Class Initialized
DEBUG - 2018-07-28 02:36:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 02:36:32 --> Input Class Initialized
DEBUG - 2018-07-28 02:36:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 02:36:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 02:36:32 --> Language Class Initialized
ERROR - 2018-07-28 02:36:32 --> 404 Page Not Found: /index
INFO - 2018-07-28 02:36:32 --> Email Class Initialized
INFO - 2018-07-28 02:36:32 --> Controller Class Initialized
INFO - 2018-07-28 02:36:32 --> Config Class Initialized
DEBUG - 2018-07-28 02:36:32 --> Home MX_Controller Initialized
INFO - 2018-07-28 02:36:32 --> Hooks Class Initialized
DEBUG - 2018-07-28 02:36:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-28 02:36:32 --> UTF-8 Support Enabled
INFO - 2018-07-28 02:36:32 --> Utf8 Class Initialized
DEBUG - 2018-07-28 02:36:32 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 02:36:32 --> Login MX_Controller Initialized
INFO - 2018-07-28 02:36:32 --> URI Class Initialized
INFO - 2018-07-28 02:36:32 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 02:36:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
INFO - 2018-07-28 02:36:32 --> Router Class Initialized
DEBUG - 2018-07-28 02:36:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-28 02:36:32 --> Output Class Initialized
INFO - 2018-07-28 02:36:32 --> Security Class Initialized
DEBUG - 2018-07-28 02:36:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 02:36:32 --> Input Class Initialized
INFO - 2018-07-28 02:36:32 --> Language Class Initialized
ERROR - 2018-07-28 02:36:32 --> 404 Page Not Found: /index
INFO - 2018-07-28 02:36:35 --> Config Class Initialized
INFO - 2018-07-28 02:36:35 --> Hooks Class Initialized
DEBUG - 2018-07-28 02:36:35 --> UTF-8 Support Enabled
INFO - 2018-07-28 02:36:35 --> Utf8 Class Initialized
INFO - 2018-07-28 02:36:35 --> URI Class Initialized
INFO - 2018-07-28 02:36:35 --> Router Class Initialized
INFO - 2018-07-28 02:36:35 --> Output Class Initialized
INFO - 2018-07-28 02:36:35 --> Security Class Initialized
DEBUG - 2018-07-28 02:36:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 02:36:35 --> Input Class Initialized
INFO - 2018-07-28 02:36:36 --> Language Class Initialized
INFO - 2018-07-28 02:36:36 --> Language Class Initialized
INFO - 2018-07-28 02:36:36 --> Config Class Initialized
INFO - 2018-07-28 02:36:36 --> Loader Class Initialized
DEBUG - 2018-07-28 02:36:36 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 02:36:36 --> Helper loaded: url_helper
INFO - 2018-07-28 02:36:36 --> Helper loaded: form_helper
INFO - 2018-07-28 02:36:36 --> Helper loaded: date_helper
INFO - 2018-07-28 02:36:36 --> Helper loaded: util_helper
INFO - 2018-07-28 02:36:36 --> Helper loaded: text_helper
INFO - 2018-07-28 02:36:36 --> Helper loaded: string_helper
INFO - 2018-07-28 02:36:36 --> Database Driver Class Initialized
DEBUG - 2018-07-28 02:36:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 02:36:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 02:36:36 --> Email Class Initialized
INFO - 2018-07-28 02:36:36 --> Controller Class Initialized
DEBUG - 2018-07-28 02:36:36 --> Users MX_Controller Initialized
DEBUG - 2018-07-28 02:36:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 02:36:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-28 02:36:36 --> Helper loaded: file_helper
DEBUG - 2018-07-28 02:36:36 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 02:36:36 --> Login MX_Controller Initialized
INFO - 2018-07-28 02:36:36 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 02:36:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-28 02:36:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-28 02:36:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-28 02:36:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-28 02:36:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-28 02:36:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-28 02:36:36 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-07-28 02:36:36 --> Final output sent to browser
DEBUG - 2018-07-28 02:36:36 --> Total execution time: 0.7076
INFO - 2018-07-28 02:36:36 --> Config Class Initialized
INFO - 2018-07-28 02:36:37 --> Hooks Class Initialized
DEBUG - 2018-07-28 02:36:37 --> UTF-8 Support Enabled
INFO - 2018-07-28 02:36:37 --> Utf8 Class Initialized
INFO - 2018-07-28 02:36:37 --> URI Class Initialized
INFO - 2018-07-28 02:36:37 --> Router Class Initialized
INFO - 2018-07-28 02:36:37 --> Output Class Initialized
INFO - 2018-07-28 02:36:37 --> Security Class Initialized
DEBUG - 2018-07-28 02:36:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 02:36:37 --> Input Class Initialized
INFO - 2018-07-28 02:36:37 --> Language Class Initialized
INFO - 2018-07-28 02:36:37 --> Language Class Initialized
INFO - 2018-07-28 02:36:37 --> Config Class Initialized
INFO - 2018-07-28 02:36:37 --> Loader Class Initialized
DEBUG - 2018-07-28 02:36:37 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 02:36:37 --> Helper loaded: url_helper
INFO - 2018-07-28 02:36:37 --> Helper loaded: form_helper
INFO - 2018-07-28 02:36:37 --> Helper loaded: date_helper
INFO - 2018-07-28 02:36:37 --> Helper loaded: util_helper
INFO - 2018-07-28 02:36:37 --> Helper loaded: text_helper
INFO - 2018-07-28 02:36:37 --> Helper loaded: string_helper
INFO - 2018-07-28 02:36:37 --> Database Driver Class Initialized
DEBUG - 2018-07-28 02:36:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 02:36:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 02:36:37 --> Email Class Initialized
INFO - 2018-07-28 02:36:37 --> Controller Class Initialized
DEBUG - 2018-07-28 02:36:37 --> Users MX_Controller Initialized
DEBUG - 2018-07-28 02:36:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 02:36:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-28 02:36:37 --> Helper loaded: file_helper
DEBUG - 2018-07-28 02:36:37 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 02:36:37 --> Login MX_Controller Initialized
INFO - 2018-07-28 02:36:37 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 02:36:37 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-28 02:36:37 --> Final output sent to browser
DEBUG - 2018-07-28 02:36:37 --> Total execution time: 0.6837
INFO - 2018-07-28 02:36:38 --> Config Class Initialized
INFO - 2018-07-28 02:36:38 --> Hooks Class Initialized
DEBUG - 2018-07-28 02:36:38 --> UTF-8 Support Enabled
INFO - 2018-07-28 02:36:38 --> Utf8 Class Initialized
INFO - 2018-07-28 02:36:38 --> URI Class Initialized
INFO - 2018-07-28 02:36:38 --> Router Class Initialized
INFO - 2018-07-28 02:36:39 --> Output Class Initialized
INFO - 2018-07-28 02:36:39 --> Security Class Initialized
DEBUG - 2018-07-28 02:36:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 02:36:39 --> Input Class Initialized
INFO - 2018-07-28 02:36:39 --> Language Class Initialized
INFO - 2018-07-28 02:36:39 --> Language Class Initialized
INFO - 2018-07-28 02:36:39 --> Config Class Initialized
INFO - 2018-07-28 02:36:39 --> Loader Class Initialized
DEBUG - 2018-07-28 02:36:39 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 02:36:39 --> Helper loaded: url_helper
INFO - 2018-07-28 02:36:39 --> Helper loaded: form_helper
INFO - 2018-07-28 02:36:39 --> Helper loaded: date_helper
INFO - 2018-07-28 02:36:39 --> Helper loaded: util_helper
INFO - 2018-07-28 02:36:39 --> Helper loaded: text_helper
INFO - 2018-07-28 02:36:39 --> Helper loaded: string_helper
INFO - 2018-07-28 02:36:39 --> Database Driver Class Initialized
DEBUG - 2018-07-28 02:36:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 02:36:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 02:36:39 --> Email Class Initialized
INFO - 2018-07-28 02:36:39 --> Controller Class Initialized
DEBUG - 2018-07-28 02:36:39 --> Programs MX_Controller Initialized
INFO - 2018-07-28 02:36:39 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 02:36:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-28 02:36:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 02:36:39 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 02:36:39 --> Login MX_Controller Initialized
DEBUG - 2018-07-28 02:36:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-28 02:36:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-28 02:36:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-28 02:36:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-28 02:36:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-28 02:36:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-28 02:36:39 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/programs.php
INFO - 2018-07-28 02:36:39 --> Final output sent to browser
DEBUG - 2018-07-28 02:36:39 --> Total execution time: 0.7325
INFO - 2018-07-28 02:36:39 --> Config Class Initialized
INFO - 2018-07-28 02:36:39 --> Hooks Class Initialized
DEBUG - 2018-07-28 02:36:40 --> UTF-8 Support Enabled
INFO - 2018-07-28 02:36:40 --> Utf8 Class Initialized
INFO - 2018-07-28 02:36:40 --> URI Class Initialized
INFO - 2018-07-28 02:36:40 --> Router Class Initialized
INFO - 2018-07-28 02:36:40 --> Output Class Initialized
INFO - 2018-07-28 02:36:40 --> Security Class Initialized
DEBUG - 2018-07-28 02:36:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 02:36:40 --> Input Class Initialized
INFO - 2018-07-28 02:36:40 --> Language Class Initialized
INFO - 2018-07-28 02:36:40 --> Language Class Initialized
INFO - 2018-07-28 02:36:40 --> Config Class Initialized
INFO - 2018-07-28 02:36:40 --> Loader Class Initialized
DEBUG - 2018-07-28 02:36:40 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 02:36:40 --> Helper loaded: url_helper
INFO - 2018-07-28 02:36:40 --> Helper loaded: form_helper
INFO - 2018-07-28 02:36:40 --> Helper loaded: date_helper
INFO - 2018-07-28 02:36:40 --> Helper loaded: util_helper
INFO - 2018-07-28 02:36:40 --> Helper loaded: text_helper
INFO - 2018-07-28 02:36:40 --> Helper loaded: string_helper
INFO - 2018-07-28 02:36:40 --> Database Driver Class Initialized
DEBUG - 2018-07-28 02:36:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 02:36:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 02:36:40 --> Email Class Initialized
INFO - 2018-07-28 02:36:40 --> Controller Class Initialized
DEBUG - 2018-07-28 02:36:40 --> Programs MX_Controller Initialized
INFO - 2018-07-28 02:36:40 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 02:36:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-28 02:36:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 02:36:40 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 02:36:40 --> Login MX_Controller Initialized
DEBUG - 2018-07-28 02:36:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-28 02:36:40 --> Final output sent to browser
DEBUG - 2018-07-28 02:36:40 --> Total execution time: 0.6733
INFO - 2018-07-28 02:37:46 --> Config Class Initialized
INFO - 2018-07-28 02:37:46 --> Hooks Class Initialized
DEBUG - 2018-07-28 02:37:46 --> UTF-8 Support Enabled
INFO - 2018-07-28 02:37:46 --> Utf8 Class Initialized
INFO - 2018-07-28 02:37:46 --> URI Class Initialized
INFO - 2018-07-28 02:37:46 --> Router Class Initialized
INFO - 2018-07-28 02:37:46 --> Output Class Initialized
INFO - 2018-07-28 02:37:46 --> Security Class Initialized
DEBUG - 2018-07-28 02:37:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 02:37:46 --> Input Class Initialized
INFO - 2018-07-28 02:37:46 --> Language Class Initialized
INFO - 2018-07-28 02:37:46 --> Language Class Initialized
INFO - 2018-07-28 02:37:46 --> Config Class Initialized
INFO - 2018-07-28 02:37:46 --> Loader Class Initialized
DEBUG - 2018-07-28 02:37:46 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 02:37:46 --> Helper loaded: url_helper
INFO - 2018-07-28 02:37:46 --> Helper loaded: form_helper
INFO - 2018-07-28 02:37:46 --> Helper loaded: date_helper
INFO - 2018-07-28 02:37:46 --> Helper loaded: util_helper
INFO - 2018-07-28 02:37:46 --> Helper loaded: text_helper
INFO - 2018-07-28 02:37:46 --> Helper loaded: string_helper
INFO - 2018-07-28 02:37:46 --> Database Driver Class Initialized
DEBUG - 2018-07-28 02:37:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 02:37:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 02:37:46 --> Email Class Initialized
INFO - 2018-07-28 02:37:46 --> Controller Class Initialized
DEBUG - 2018-07-28 02:37:46 --> Programs MX_Controller Initialized
INFO - 2018-07-28 02:37:46 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 02:37:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-28 02:37:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 02:37:46 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 02:37:46 --> Login MX_Controller Initialized
DEBUG - 2018-07-28 02:37:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-28 02:37:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-28 02:37:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-28 02:37:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-28 02:37:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-28 02:37:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-28 02:37:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/create_program.php
INFO - 2018-07-28 02:37:46 --> Final output sent to browser
DEBUG - 2018-07-28 02:37:46 --> Total execution time: 0.6871
INFO - 2018-07-28 02:39:09 --> Config Class Initialized
INFO - 2018-07-28 02:39:09 --> Hooks Class Initialized
DEBUG - 2018-07-28 02:39:09 --> UTF-8 Support Enabled
INFO - 2018-07-28 02:39:09 --> Utf8 Class Initialized
INFO - 2018-07-28 02:39:09 --> URI Class Initialized
DEBUG - 2018-07-28 02:39:09 --> No URI present. Default controller set.
INFO - 2018-07-28 02:39:09 --> Router Class Initialized
INFO - 2018-07-28 02:39:09 --> Output Class Initialized
INFO - 2018-07-28 02:39:09 --> Security Class Initialized
DEBUG - 2018-07-28 02:39:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 02:39:09 --> Input Class Initialized
INFO - 2018-07-28 02:39:09 --> Language Class Initialized
INFO - 2018-07-28 02:39:10 --> Language Class Initialized
INFO - 2018-07-28 02:39:10 --> Config Class Initialized
INFO - 2018-07-28 02:39:10 --> Loader Class Initialized
DEBUG - 2018-07-28 02:39:10 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 02:39:10 --> Helper loaded: url_helper
INFO - 2018-07-28 02:39:10 --> Helper loaded: form_helper
INFO - 2018-07-28 02:39:10 --> Helper loaded: date_helper
INFO - 2018-07-28 02:39:10 --> Helper loaded: util_helper
INFO - 2018-07-28 02:39:10 --> Helper loaded: text_helper
INFO - 2018-07-28 02:39:10 --> Helper loaded: string_helper
INFO - 2018-07-28 02:39:10 --> Database Driver Class Initialized
DEBUG - 2018-07-28 02:39:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 02:39:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 02:39:10 --> Email Class Initialized
INFO - 2018-07-28 02:39:10 --> Controller Class Initialized
DEBUG - 2018-07-28 02:39:10 --> Home MX_Controller Initialized
DEBUG - 2018-07-28 02:39:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-28 02:39:10 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 02:39:10 --> Login MX_Controller Initialized
INFO - 2018-07-28 02:39:10 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 02:39:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 02:39:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-28 02:39:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/css.php
DEBUG - 2018-07-28 02:39:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/mobile_header.php
DEBUG - 2018-07-28 02:39:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/header.php
DEBUG - 2018-07-28 02:39:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/footer.php
DEBUG - 2018-07-28 02:39:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/common/js.php
DEBUG - 2018-07-28 02:39:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/views/home.php
INFO - 2018-07-28 02:39:10 --> Final output sent to browser
DEBUG - 2018-07-28 02:39:10 --> Total execution time: 0.8619
INFO - 2018-07-28 02:39:11 --> Config Class Initialized
INFO - 2018-07-28 02:39:11 --> Hooks Class Initialized
INFO - 2018-07-28 02:39:11 --> Config Class Initialized
DEBUG - 2018-07-28 02:39:11 --> UTF-8 Support Enabled
INFO - 2018-07-28 02:39:11 --> Utf8 Class Initialized
INFO - 2018-07-28 02:39:11 --> URI Class Initialized
INFO - 2018-07-28 02:39:11 --> Router Class Initialized
INFO - 2018-07-28 02:39:11 --> Output Class Initialized
INFO - 2018-07-28 02:39:11 --> Hooks Class Initialized
INFO - 2018-07-28 02:39:11 --> Security Class Initialized
DEBUG - 2018-07-28 02:39:11 --> UTF-8 Support Enabled
DEBUG - 2018-07-28 02:39:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 02:39:11 --> Utf8 Class Initialized
INFO - 2018-07-28 02:39:11 --> URI Class Initialized
INFO - 2018-07-28 02:39:11 --> Input Class Initialized
INFO - 2018-07-28 02:39:11 --> Router Class Initialized
INFO - 2018-07-28 02:39:11 --> Language Class Initialized
INFO - 2018-07-28 02:39:11 --> Output Class Initialized
ERROR - 2018-07-28 02:39:11 --> 404 Page Not Found: /index
INFO - 2018-07-28 02:39:11 --> Security Class Initialized
INFO - 2018-07-28 02:39:11 --> Config Class Initialized
INFO - 2018-07-28 02:39:11 --> Hooks Class Initialized
DEBUG - 2018-07-28 02:39:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 02:39:11 --> Input Class Initialized
DEBUG - 2018-07-28 02:39:11 --> UTF-8 Support Enabled
INFO - 2018-07-28 02:39:11 --> Utf8 Class Initialized
INFO - 2018-07-28 02:39:11 --> Language Class Initialized
INFO - 2018-07-28 02:39:11 --> URI Class Initialized
INFO - 2018-07-28 02:39:11 --> Router Class Initialized
INFO - 2018-07-28 02:39:11 --> Language Class Initialized
INFO - 2018-07-28 02:39:11 --> Output Class Initialized
INFO - 2018-07-28 02:39:11 --> Config Class Initialized
INFO - 2018-07-28 02:39:11 --> Security Class Initialized
INFO - 2018-07-28 02:39:11 --> Loader Class Initialized
DEBUG - 2018-07-28 02:39:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-07-28 02:39:11 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 02:39:11 --> Helper loaded: url_helper
INFO - 2018-07-28 02:39:11 --> Helper loaded: form_helper
INFO - 2018-07-28 02:39:11 --> Helper loaded: date_helper
INFO - 2018-07-28 02:39:11 --> Helper loaded: util_helper
INFO - 2018-07-28 02:39:11 --> Helper loaded: text_helper
INFO - 2018-07-28 02:39:11 --> Helper loaded: string_helper
INFO - 2018-07-28 02:39:11 --> Input Class Initialized
INFO - 2018-07-28 02:39:11 --> Database Driver Class Initialized
INFO - 2018-07-28 02:39:11 --> Language Class Initialized
DEBUG - 2018-07-28 02:39:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2018-07-28 02:39:11 --> 404 Page Not Found: /index
INFO - 2018-07-28 02:39:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 02:39:11 --> Email Class Initialized
INFO - 2018-07-28 02:39:11 --> Controller Class Initialized
DEBUG - 2018-07-28 02:39:11 --> Home MX_Controller Initialized
DEBUG - 2018-07-28 02:39:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/home/models/Home_model.php
DEBUG - 2018-07-28 02:39:12 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 02:39:12 --> Login MX_Controller Initialized
INFO - 2018-07-28 02:39:12 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 02:39:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 02:39:12 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-28 02:39:13 --> Config Class Initialized
INFO - 2018-07-28 02:39:14 --> Hooks Class Initialized
DEBUG - 2018-07-28 02:39:14 --> UTF-8 Support Enabled
INFO - 2018-07-28 02:39:14 --> Utf8 Class Initialized
INFO - 2018-07-28 02:39:14 --> URI Class Initialized
INFO - 2018-07-28 02:39:14 --> Router Class Initialized
INFO - 2018-07-28 02:39:14 --> Output Class Initialized
INFO - 2018-07-28 02:39:14 --> Security Class Initialized
DEBUG - 2018-07-28 02:39:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 02:39:14 --> Input Class Initialized
INFO - 2018-07-28 02:39:14 --> Language Class Initialized
ERROR - 2018-07-28 02:39:14 --> 404 Page Not Found: /index
INFO - 2018-07-28 02:45:10 --> Config Class Initialized
INFO - 2018-07-28 02:45:10 --> Hooks Class Initialized
DEBUG - 2018-07-28 02:45:10 --> UTF-8 Support Enabled
INFO - 2018-07-28 02:45:10 --> Utf8 Class Initialized
INFO - 2018-07-28 02:45:10 --> URI Class Initialized
INFO - 2018-07-28 02:45:10 --> Router Class Initialized
INFO - 2018-07-28 02:45:10 --> Output Class Initialized
INFO - 2018-07-28 02:45:10 --> Security Class Initialized
DEBUG - 2018-07-28 02:45:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 02:45:10 --> Input Class Initialized
INFO - 2018-07-28 02:45:10 --> Language Class Initialized
INFO - 2018-07-28 02:45:10 --> Language Class Initialized
INFO - 2018-07-28 02:45:10 --> Config Class Initialized
INFO - 2018-07-28 02:45:10 --> Loader Class Initialized
DEBUG - 2018-07-28 02:45:10 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 02:45:10 --> Helper loaded: url_helper
INFO - 2018-07-28 02:45:10 --> Helper loaded: form_helper
INFO - 2018-07-28 02:45:10 --> Helper loaded: date_helper
INFO - 2018-07-28 02:45:10 --> Helper loaded: util_helper
INFO - 2018-07-28 02:45:10 --> Helper loaded: text_helper
INFO - 2018-07-28 02:45:10 --> Helper loaded: string_helper
INFO - 2018-07-28 02:45:10 --> Database Driver Class Initialized
DEBUG - 2018-07-28 02:45:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 02:45:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 02:45:10 --> Email Class Initialized
INFO - 2018-07-28 02:45:10 --> Controller Class Initialized
DEBUG - 2018-07-28 02:45:10 --> Programs MX_Controller Initialized
INFO - 2018-07-28 02:45:10 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 02:45:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-28 02:45:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 02:45:10 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 02:45:10 --> Login MX_Controller Initialized
DEBUG - 2018-07-28 02:45:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-28 02:45:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-28 02:45:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-28 02:45:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-28 02:45:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-28 02:45:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-28 02:45:10 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/create_program.php
INFO - 2018-07-28 02:45:10 --> Final output sent to browser
DEBUG - 2018-07-28 02:45:10 --> Total execution time: 0.6991
INFO - 2018-07-28 03:16:27 --> Config Class Initialized
INFO - 2018-07-28 03:16:27 --> Hooks Class Initialized
DEBUG - 2018-07-28 03:16:27 --> UTF-8 Support Enabled
INFO - 2018-07-28 03:16:27 --> Utf8 Class Initialized
INFO - 2018-07-28 03:16:27 --> URI Class Initialized
INFO - 2018-07-28 03:16:27 --> Router Class Initialized
INFO - 2018-07-28 03:16:27 --> Output Class Initialized
INFO - 2018-07-28 03:16:27 --> Security Class Initialized
DEBUG - 2018-07-28 03:16:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 03:16:27 --> Input Class Initialized
INFO - 2018-07-28 03:16:27 --> Language Class Initialized
INFO - 2018-07-28 03:16:27 --> Language Class Initialized
INFO - 2018-07-28 03:16:27 --> Config Class Initialized
INFO - 2018-07-28 03:16:27 --> Loader Class Initialized
DEBUG - 2018-07-28 03:16:27 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 03:16:27 --> Helper loaded: url_helper
INFO - 2018-07-28 03:16:27 --> Helper loaded: form_helper
INFO - 2018-07-28 03:16:27 --> Helper loaded: date_helper
INFO - 2018-07-28 03:16:27 --> Helper loaded: util_helper
INFO - 2018-07-28 03:16:27 --> Helper loaded: text_helper
INFO - 2018-07-28 03:16:27 --> Helper loaded: string_helper
INFO - 2018-07-28 03:16:27 --> Database Driver Class Initialized
DEBUG - 2018-07-28 03:16:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 03:16:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 03:16:27 --> Email Class Initialized
INFO - 2018-07-28 03:16:27 --> Controller Class Initialized
DEBUG - 2018-07-28 03:16:27 --> Programs MX_Controller Initialized
INFO - 2018-07-28 03:16:27 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 03:16:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-28 03:16:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 03:16:27 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 03:16:27 --> Login MX_Controller Initialized
DEBUG - 2018-07-28 03:16:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-28 03:16:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-28 03:16:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-28 03:16:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-28 03:16:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-28 03:16:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-28 03:16:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/create_program.php
INFO - 2018-07-28 03:16:27 --> Final output sent to browser
DEBUG - 2018-07-28 03:16:27 --> Total execution time: 0.6652
INFO - 2018-07-28 03:16:46 --> Config Class Initialized
INFO - 2018-07-28 03:16:46 --> Hooks Class Initialized
DEBUG - 2018-07-28 03:16:46 --> UTF-8 Support Enabled
INFO - 2018-07-28 03:16:46 --> Utf8 Class Initialized
INFO - 2018-07-28 03:16:46 --> URI Class Initialized
INFO - 2018-07-28 03:16:46 --> Router Class Initialized
INFO - 2018-07-28 03:16:46 --> Output Class Initialized
INFO - 2018-07-28 03:16:46 --> Security Class Initialized
DEBUG - 2018-07-28 03:16:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 03:16:46 --> Input Class Initialized
INFO - 2018-07-28 03:16:46 --> Language Class Initialized
INFO - 2018-07-28 03:16:46 --> Language Class Initialized
INFO - 2018-07-28 03:16:46 --> Config Class Initialized
INFO - 2018-07-28 03:16:46 --> Loader Class Initialized
DEBUG - 2018-07-28 03:16:46 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 03:16:46 --> Helper loaded: url_helper
INFO - 2018-07-28 03:16:46 --> Helper loaded: form_helper
INFO - 2018-07-28 03:16:46 --> Helper loaded: date_helper
INFO - 2018-07-28 03:16:46 --> Helper loaded: util_helper
INFO - 2018-07-28 03:16:46 --> Helper loaded: text_helper
INFO - 2018-07-28 03:16:46 --> Helper loaded: string_helper
INFO - 2018-07-28 03:16:46 --> Database Driver Class Initialized
DEBUG - 2018-07-28 03:16:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 03:16:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 03:16:46 --> Email Class Initialized
INFO - 2018-07-28 03:16:46 --> Controller Class Initialized
DEBUG - 2018-07-28 03:16:46 --> Programs MX_Controller Initialized
INFO - 2018-07-28 03:16:46 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 03:16:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-28 03:16:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 03:16:46 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 03:16:46 --> Login MX_Controller Initialized
DEBUG - 2018-07-28 03:16:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-28 03:16:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-28 03:16:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-28 03:16:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-28 03:16:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-28 03:16:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-28 03:16:46 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/create_program.php
INFO - 2018-07-28 03:16:46 --> Final output sent to browser
DEBUG - 2018-07-28 03:16:46 --> Total execution time: 0.6464
INFO - 2018-07-28 03:18:54 --> Config Class Initialized
INFO - 2018-07-28 03:18:54 --> Hooks Class Initialized
DEBUG - 2018-07-28 03:18:54 --> UTF-8 Support Enabled
INFO - 2018-07-28 03:18:54 --> Utf8 Class Initialized
INFO - 2018-07-28 03:18:54 --> URI Class Initialized
INFO - 2018-07-28 03:18:54 --> Router Class Initialized
INFO - 2018-07-28 03:18:54 --> Output Class Initialized
INFO - 2018-07-28 03:18:54 --> Security Class Initialized
DEBUG - 2018-07-28 03:18:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 03:18:54 --> Input Class Initialized
INFO - 2018-07-28 03:18:54 --> Language Class Initialized
INFO - 2018-07-28 03:18:54 --> Language Class Initialized
INFO - 2018-07-28 03:18:54 --> Config Class Initialized
INFO - 2018-07-28 03:18:54 --> Loader Class Initialized
DEBUG - 2018-07-28 03:18:54 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 03:18:54 --> Helper loaded: url_helper
INFO - 2018-07-28 03:18:54 --> Helper loaded: form_helper
INFO - 2018-07-28 03:18:54 --> Helper loaded: date_helper
INFO - 2018-07-28 03:18:54 --> Helper loaded: util_helper
INFO - 2018-07-28 03:18:54 --> Helper loaded: text_helper
INFO - 2018-07-28 03:18:54 --> Helper loaded: string_helper
INFO - 2018-07-28 03:18:54 --> Database Driver Class Initialized
DEBUG - 2018-07-28 03:18:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 03:18:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 03:18:54 --> Email Class Initialized
INFO - 2018-07-28 03:18:54 --> Controller Class Initialized
DEBUG - 2018-07-28 03:18:54 --> Programs MX_Controller Initialized
INFO - 2018-07-28 03:18:54 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 03:18:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-28 03:18:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 03:18:54 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 03:18:54 --> Login MX_Controller Initialized
DEBUG - 2018-07-28 03:18:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-28 03:18:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-28 03:18:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-28 03:18:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-28 03:18:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-28 03:18:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-28 03:18:55 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/create_program.php
INFO - 2018-07-28 03:18:55 --> Final output sent to browser
DEBUG - 2018-07-28 03:18:55 --> Total execution time: 0.6724
INFO - 2018-07-28 03:19:11 --> Config Class Initialized
INFO - 2018-07-28 03:19:11 --> Hooks Class Initialized
DEBUG - 2018-07-28 03:19:11 --> UTF-8 Support Enabled
INFO - 2018-07-28 03:19:11 --> Utf8 Class Initialized
INFO - 2018-07-28 03:19:11 --> URI Class Initialized
INFO - 2018-07-28 03:19:11 --> Router Class Initialized
INFO - 2018-07-28 03:19:11 --> Output Class Initialized
INFO - 2018-07-28 03:19:11 --> Security Class Initialized
DEBUG - 2018-07-28 03:19:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 03:19:11 --> Input Class Initialized
INFO - 2018-07-28 03:19:11 --> Language Class Initialized
INFO - 2018-07-28 03:19:11 --> Language Class Initialized
INFO - 2018-07-28 03:19:11 --> Config Class Initialized
INFO - 2018-07-28 03:19:11 --> Loader Class Initialized
DEBUG - 2018-07-28 03:19:11 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 03:19:11 --> Helper loaded: url_helper
INFO - 2018-07-28 03:19:11 --> Helper loaded: form_helper
INFO - 2018-07-28 03:19:11 --> Helper loaded: date_helper
INFO - 2018-07-28 03:19:11 --> Helper loaded: util_helper
INFO - 2018-07-28 03:19:11 --> Helper loaded: text_helper
INFO - 2018-07-28 03:19:11 --> Helper loaded: string_helper
INFO - 2018-07-28 03:19:11 --> Database Driver Class Initialized
DEBUG - 2018-07-28 03:19:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 03:19:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 03:19:11 --> Email Class Initialized
INFO - 2018-07-28 03:19:11 --> Controller Class Initialized
DEBUG - 2018-07-28 03:19:11 --> Programs MX_Controller Initialized
INFO - 2018-07-28 03:19:11 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 03:19:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-28 03:19:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 03:19:11 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 03:19:11 --> Login MX_Controller Initialized
DEBUG - 2018-07-28 03:19:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-28 03:19:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-28 03:19:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-28 03:19:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-28 03:19:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-28 03:19:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-28 03:19:11 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/create_program.php
INFO - 2018-07-28 03:19:11 --> Final output sent to browser
DEBUG - 2018-07-28 03:19:11 --> Total execution time: 0.6866
INFO - 2018-07-28 03:19:25 --> Config Class Initialized
INFO - 2018-07-28 03:19:25 --> Hooks Class Initialized
DEBUG - 2018-07-28 03:19:25 --> UTF-8 Support Enabled
INFO - 2018-07-28 03:19:25 --> Utf8 Class Initialized
INFO - 2018-07-28 03:19:25 --> URI Class Initialized
INFO - 2018-07-28 03:19:25 --> Router Class Initialized
INFO - 2018-07-28 03:19:26 --> Output Class Initialized
INFO - 2018-07-28 03:19:26 --> Security Class Initialized
DEBUG - 2018-07-28 03:19:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 03:19:26 --> Input Class Initialized
INFO - 2018-07-28 03:19:26 --> Language Class Initialized
INFO - 2018-07-28 03:19:26 --> Language Class Initialized
INFO - 2018-07-28 03:19:26 --> Config Class Initialized
INFO - 2018-07-28 03:19:26 --> Loader Class Initialized
DEBUG - 2018-07-28 03:19:26 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 03:19:26 --> Helper loaded: url_helper
INFO - 2018-07-28 03:19:26 --> Helper loaded: form_helper
INFO - 2018-07-28 03:19:26 --> Helper loaded: date_helper
INFO - 2018-07-28 03:19:26 --> Helper loaded: util_helper
INFO - 2018-07-28 03:19:26 --> Helper loaded: text_helper
INFO - 2018-07-28 03:19:26 --> Helper loaded: string_helper
INFO - 2018-07-28 03:19:26 --> Database Driver Class Initialized
DEBUG - 2018-07-28 03:19:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 03:19:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 03:19:26 --> Email Class Initialized
INFO - 2018-07-28 03:19:26 --> Controller Class Initialized
DEBUG - 2018-07-28 03:19:26 --> Programs MX_Controller Initialized
INFO - 2018-07-28 03:19:26 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 03:19:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-28 03:19:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 03:19:26 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 03:19:26 --> Login MX_Controller Initialized
DEBUG - 2018-07-28 03:19:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-28 03:19:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-28 03:19:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-28 03:19:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-28 03:19:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-28 03:19:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-28 03:19:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/create_program.php
INFO - 2018-07-28 03:19:26 --> Final output sent to browser
DEBUG - 2018-07-28 03:19:26 --> Total execution time: 0.7472
INFO - 2018-07-28 03:21:08 --> Config Class Initialized
INFO - 2018-07-28 03:21:08 --> Hooks Class Initialized
DEBUG - 2018-07-28 03:21:08 --> UTF-8 Support Enabled
INFO - 2018-07-28 03:21:08 --> Utf8 Class Initialized
INFO - 2018-07-28 03:21:08 --> URI Class Initialized
INFO - 2018-07-28 03:21:08 --> Router Class Initialized
INFO - 2018-07-28 03:21:08 --> Output Class Initialized
INFO - 2018-07-28 03:21:08 --> Security Class Initialized
DEBUG - 2018-07-28 03:21:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 03:21:08 --> Input Class Initialized
INFO - 2018-07-28 03:21:08 --> Language Class Initialized
INFO - 2018-07-28 03:21:08 --> Language Class Initialized
INFO - 2018-07-28 03:21:08 --> Config Class Initialized
INFO - 2018-07-28 03:21:08 --> Loader Class Initialized
DEBUG - 2018-07-28 03:21:08 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 03:21:08 --> Helper loaded: url_helper
INFO - 2018-07-28 03:21:08 --> Helper loaded: form_helper
INFO - 2018-07-28 03:21:08 --> Helper loaded: date_helper
INFO - 2018-07-28 03:21:08 --> Helper loaded: util_helper
INFO - 2018-07-28 03:21:08 --> Helper loaded: text_helper
INFO - 2018-07-28 03:21:08 --> Helper loaded: string_helper
INFO - 2018-07-28 03:21:08 --> Database Driver Class Initialized
DEBUG - 2018-07-28 03:21:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 03:21:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 03:21:08 --> Email Class Initialized
INFO - 2018-07-28 03:21:08 --> Controller Class Initialized
DEBUG - 2018-07-28 03:21:08 --> Programs MX_Controller Initialized
INFO - 2018-07-28 03:21:08 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 03:21:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-28 03:21:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 03:21:08 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 03:21:08 --> Login MX_Controller Initialized
DEBUG - 2018-07-28 03:21:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-28 03:21:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-28 03:21:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-28 03:21:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-28 03:21:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-28 03:21:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-28 03:21:08 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/create_program.php
INFO - 2018-07-28 03:21:08 --> Final output sent to browser
DEBUG - 2018-07-28 03:21:08 --> Total execution time: 0.7006
INFO - 2018-07-28 03:25:14 --> Config Class Initialized
INFO - 2018-07-28 03:25:14 --> Hooks Class Initialized
DEBUG - 2018-07-28 03:25:14 --> UTF-8 Support Enabled
INFO - 2018-07-28 03:25:14 --> Utf8 Class Initialized
INFO - 2018-07-28 03:25:14 --> URI Class Initialized
INFO - 2018-07-28 03:25:14 --> Router Class Initialized
INFO - 2018-07-28 03:25:14 --> Output Class Initialized
INFO - 2018-07-28 03:25:14 --> Security Class Initialized
DEBUG - 2018-07-28 03:25:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 03:25:14 --> Input Class Initialized
INFO - 2018-07-28 03:25:14 --> Language Class Initialized
INFO - 2018-07-28 03:25:14 --> Language Class Initialized
INFO - 2018-07-28 03:25:14 --> Config Class Initialized
INFO - 2018-07-28 03:25:14 --> Loader Class Initialized
DEBUG - 2018-07-28 03:25:14 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 03:25:14 --> Helper loaded: url_helper
INFO - 2018-07-28 03:25:14 --> Helper loaded: form_helper
INFO - 2018-07-28 03:25:14 --> Helper loaded: date_helper
INFO - 2018-07-28 03:25:14 --> Helper loaded: util_helper
INFO - 2018-07-28 03:25:14 --> Helper loaded: text_helper
INFO - 2018-07-28 03:25:14 --> Helper loaded: string_helper
INFO - 2018-07-28 03:25:14 --> Database Driver Class Initialized
DEBUG - 2018-07-28 03:25:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 03:25:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 03:25:14 --> Email Class Initialized
INFO - 2018-07-28 03:25:14 --> Controller Class Initialized
DEBUG - 2018-07-28 03:25:14 --> Programs MX_Controller Initialized
INFO - 2018-07-28 03:25:14 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 03:25:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-28 03:25:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 03:25:14 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 03:25:14 --> Login MX_Controller Initialized
DEBUG - 2018-07-28 03:25:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-28 03:25:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-28 03:25:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-28 03:25:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-28 03:25:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-28 03:25:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-28 03:25:14 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/create_program.php
INFO - 2018-07-28 03:25:14 --> Final output sent to browser
DEBUG - 2018-07-28 03:25:14 --> Total execution time: 0.6832
INFO - 2018-07-28 03:26:55 --> Config Class Initialized
INFO - 2018-07-28 03:26:56 --> Hooks Class Initialized
DEBUG - 2018-07-28 03:26:56 --> UTF-8 Support Enabled
INFO - 2018-07-28 03:26:56 --> Utf8 Class Initialized
INFO - 2018-07-28 03:26:56 --> URI Class Initialized
INFO - 2018-07-28 03:26:56 --> Router Class Initialized
INFO - 2018-07-28 03:26:56 --> Output Class Initialized
INFO - 2018-07-28 03:26:56 --> Security Class Initialized
DEBUG - 2018-07-28 03:26:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 03:26:56 --> Input Class Initialized
INFO - 2018-07-28 03:26:56 --> Language Class Initialized
INFO - 2018-07-28 03:26:56 --> Language Class Initialized
INFO - 2018-07-28 03:26:56 --> Config Class Initialized
INFO - 2018-07-28 03:26:56 --> Loader Class Initialized
DEBUG - 2018-07-28 03:26:56 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 03:26:56 --> Helper loaded: url_helper
INFO - 2018-07-28 03:26:56 --> Helper loaded: form_helper
INFO - 2018-07-28 03:26:56 --> Helper loaded: date_helper
INFO - 2018-07-28 03:26:56 --> Helper loaded: util_helper
INFO - 2018-07-28 03:26:56 --> Helper loaded: text_helper
INFO - 2018-07-28 03:26:56 --> Helper loaded: string_helper
INFO - 2018-07-28 03:26:56 --> Database Driver Class Initialized
DEBUG - 2018-07-28 03:26:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 03:26:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 03:26:56 --> Email Class Initialized
INFO - 2018-07-28 03:26:56 --> Controller Class Initialized
DEBUG - 2018-07-28 03:26:56 --> Users MX_Controller Initialized
DEBUG - 2018-07-28 03:26:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 03:26:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-28 03:26:56 --> Helper loaded: file_helper
DEBUG - 2018-07-28 03:26:56 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 03:26:56 --> Login MX_Controller Initialized
INFO - 2018-07-28 03:26:56 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 03:26:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-28 03:26:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-28 03:26:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-28 03:26:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-28 03:26:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-28 03:26:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-28 03:26:56 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/users/users.php
INFO - 2018-07-28 03:26:56 --> Final output sent to browser
DEBUG - 2018-07-28 03:26:56 --> Total execution time: 0.7554
INFO - 2018-07-28 03:26:57 --> Config Class Initialized
INFO - 2018-07-28 03:26:57 --> Hooks Class Initialized
DEBUG - 2018-07-28 03:26:57 --> UTF-8 Support Enabled
INFO - 2018-07-28 03:26:57 --> Utf8 Class Initialized
INFO - 2018-07-28 03:26:57 --> URI Class Initialized
INFO - 2018-07-28 03:26:57 --> Router Class Initialized
INFO - 2018-07-28 03:26:57 --> Output Class Initialized
INFO - 2018-07-28 03:26:57 --> Security Class Initialized
DEBUG - 2018-07-28 03:26:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 03:26:57 --> Input Class Initialized
INFO - 2018-07-28 03:26:57 --> Language Class Initialized
INFO - 2018-07-28 03:26:57 --> Language Class Initialized
INFO - 2018-07-28 03:26:57 --> Config Class Initialized
INFO - 2018-07-28 03:26:57 --> Loader Class Initialized
DEBUG - 2018-07-28 03:26:57 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 03:26:57 --> Helper loaded: url_helper
INFO - 2018-07-28 03:26:57 --> Helper loaded: form_helper
INFO - 2018-07-28 03:26:57 --> Helper loaded: date_helper
INFO - 2018-07-28 03:26:57 --> Helper loaded: util_helper
INFO - 2018-07-28 03:26:57 --> Helper loaded: text_helper
INFO - 2018-07-28 03:26:57 --> Helper loaded: string_helper
INFO - 2018-07-28 03:26:57 --> Database Driver Class Initialized
DEBUG - 2018-07-28 03:26:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 03:26:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 03:26:57 --> Email Class Initialized
INFO - 2018-07-28 03:26:57 --> Controller Class Initialized
DEBUG - 2018-07-28 03:26:57 --> Users MX_Controller Initialized
DEBUG - 2018-07-28 03:26:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 03:26:57 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Users_model.php
INFO - 2018-07-28 03:26:57 --> Helper loaded: file_helper
DEBUG - 2018-07-28 03:26:58 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 03:26:58 --> Login MX_Controller Initialized
INFO - 2018-07-28 03:26:58 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 03:26:58 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-28 03:26:58 --> Final output sent to browser
DEBUG - 2018-07-28 03:26:58 --> Total execution time: 0.7112
INFO - 2018-07-28 03:55:16 --> Config Class Initialized
INFO - 2018-07-28 03:55:16 --> Hooks Class Initialized
DEBUG - 2018-07-28 03:55:16 --> UTF-8 Support Enabled
INFO - 2018-07-28 03:55:16 --> Utf8 Class Initialized
INFO - 2018-07-28 03:55:16 --> URI Class Initialized
INFO - 2018-07-28 03:55:16 --> Router Class Initialized
INFO - 2018-07-28 03:55:16 --> Output Class Initialized
INFO - 2018-07-28 03:55:16 --> Security Class Initialized
DEBUG - 2018-07-28 03:55:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 03:55:16 --> Input Class Initialized
INFO - 2018-07-28 03:55:16 --> Language Class Initialized
INFO - 2018-07-28 03:55:16 --> Language Class Initialized
INFO - 2018-07-28 03:55:16 --> Config Class Initialized
INFO - 2018-07-28 03:55:16 --> Loader Class Initialized
DEBUG - 2018-07-28 03:55:16 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 03:55:16 --> Helper loaded: url_helper
INFO - 2018-07-28 03:55:16 --> Helper loaded: form_helper
INFO - 2018-07-28 03:55:16 --> Helper loaded: date_helper
INFO - 2018-07-28 03:55:16 --> Helper loaded: util_helper
INFO - 2018-07-28 03:55:16 --> Helper loaded: text_helper
INFO - 2018-07-28 03:55:16 --> Helper loaded: string_helper
INFO - 2018-07-28 03:55:16 --> Database Driver Class Initialized
DEBUG - 2018-07-28 03:55:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 03:55:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 03:55:17 --> Email Class Initialized
INFO - 2018-07-28 03:55:17 --> Controller Class Initialized
DEBUG - 2018-07-28 03:55:17 --> Programs MX_Controller Initialized
INFO - 2018-07-28 03:55:17 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 03:55:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-28 03:55:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 03:55:17 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 03:55:17 --> Login MX_Controller Initialized
DEBUG - 2018-07-28 03:55:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-28 03:55:17 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
ERROR - 2018-07-28 03:55:17 --> Severity: Notice --> Undefined index: prg_img_vid_name E:\xampp\htdocs\consulting\application\modules\admin\controllers\Programs.php 106
INFO - 2018-07-28 03:55:17 --> Upload Class Initialized
ERROR - 2018-07-28 03:55:17 --> Severity: Notice --> Undefined index: tmp_name E:\xampp\htdocs\consulting\system\libraries\Upload.php 412
INFO - 2018-07-28 03:55:17 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2018-07-28 03:55:17 --> You did not select a file to upload.
INFO - 2018-07-28 03:55:25 --> Config Class Initialized
INFO - 2018-07-28 03:55:25 --> Hooks Class Initialized
DEBUG - 2018-07-28 03:55:25 --> UTF-8 Support Enabled
INFO - 2018-07-28 03:55:25 --> Utf8 Class Initialized
INFO - 2018-07-28 03:55:25 --> URI Class Initialized
INFO - 2018-07-28 03:55:25 --> Router Class Initialized
INFO - 2018-07-28 03:55:25 --> Output Class Initialized
INFO - 2018-07-28 03:55:25 --> Security Class Initialized
DEBUG - 2018-07-28 03:55:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 03:55:25 --> Input Class Initialized
INFO - 2018-07-28 03:55:25 --> Language Class Initialized
INFO - 2018-07-28 03:55:25 --> Language Class Initialized
INFO - 2018-07-28 03:55:25 --> Config Class Initialized
INFO - 2018-07-28 03:55:25 --> Loader Class Initialized
DEBUG - 2018-07-28 03:55:25 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 03:55:25 --> Helper loaded: url_helper
INFO - 2018-07-28 03:55:25 --> Helper loaded: form_helper
INFO - 2018-07-28 03:55:25 --> Helper loaded: date_helper
INFO - 2018-07-28 03:55:25 --> Helper loaded: util_helper
INFO - 2018-07-28 03:55:25 --> Helper loaded: text_helper
INFO - 2018-07-28 03:55:25 --> Helper loaded: string_helper
INFO - 2018-07-28 03:55:25 --> Database Driver Class Initialized
DEBUG - 2018-07-28 03:55:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 03:55:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 03:55:25 --> Email Class Initialized
INFO - 2018-07-28 03:55:25 --> Controller Class Initialized
DEBUG - 2018-07-28 03:55:25 --> Programs MX_Controller Initialized
INFO - 2018-07-28 03:55:25 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 03:55:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-28 03:55:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 03:55:25 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 03:55:25 --> Login MX_Controller Initialized
DEBUG - 2018-07-28 03:55:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-28 03:55:25 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
ERROR - 2018-07-28 03:55:25 --> Severity: Notice --> Undefined index: prg_img_vid_name E:\xampp\htdocs\consulting\application\modules\admin\controllers\Programs.php 106
INFO - 2018-07-28 03:55:25 --> Upload Class Initialized
ERROR - 2018-07-28 03:55:25 --> Severity: Notice --> Undefined index: tmp_name E:\xampp\htdocs\consulting\system\libraries\Upload.php 412
INFO - 2018-07-28 03:55:25 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2018-07-28 03:55:25 --> You did not select a file to upload.
INFO - 2018-07-28 03:55:25 --> Config Class Initialized
INFO - 2018-07-28 03:55:25 --> Hooks Class Initialized
DEBUG - 2018-07-28 03:55:25 --> UTF-8 Support Enabled
INFO - 2018-07-28 03:55:25 --> Utf8 Class Initialized
INFO - 2018-07-28 03:55:25 --> URI Class Initialized
INFO - 2018-07-28 03:55:25 --> Router Class Initialized
INFO - 2018-07-28 03:55:25 --> Output Class Initialized
INFO - 2018-07-28 03:55:25 --> Security Class Initialized
DEBUG - 2018-07-28 03:55:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 03:55:26 --> Input Class Initialized
INFO - 2018-07-28 03:55:26 --> Language Class Initialized
INFO - 2018-07-28 03:55:26 --> Language Class Initialized
INFO - 2018-07-28 03:55:26 --> Config Class Initialized
INFO - 2018-07-28 03:55:26 --> Loader Class Initialized
DEBUG - 2018-07-28 03:55:26 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 03:55:26 --> Helper loaded: url_helper
INFO - 2018-07-28 03:55:26 --> Helper loaded: form_helper
INFO - 2018-07-28 03:55:26 --> Helper loaded: date_helper
INFO - 2018-07-28 03:55:26 --> Helper loaded: util_helper
INFO - 2018-07-28 03:55:26 --> Helper loaded: text_helper
INFO - 2018-07-28 03:55:26 --> Helper loaded: string_helper
INFO - 2018-07-28 03:55:26 --> Database Driver Class Initialized
DEBUG - 2018-07-28 03:55:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 03:55:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 03:55:26 --> Email Class Initialized
INFO - 2018-07-28 03:55:26 --> Controller Class Initialized
DEBUG - 2018-07-28 03:55:26 --> Programs MX_Controller Initialized
INFO - 2018-07-28 03:55:26 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 03:55:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-28 03:55:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 03:55:26 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 03:55:26 --> Login MX_Controller Initialized
DEBUG - 2018-07-28 03:55:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-28 03:55:26 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
ERROR - 2018-07-28 03:55:26 --> Severity: Notice --> Undefined index: prg_img_vid_name E:\xampp\htdocs\consulting\application\modules\admin\controllers\Programs.php 106
INFO - 2018-07-28 03:55:26 --> Upload Class Initialized
ERROR - 2018-07-28 03:55:26 --> Severity: Notice --> Undefined index: tmp_name E:\xampp\htdocs\consulting\system\libraries\Upload.php 412
INFO - 2018-07-28 03:55:26 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2018-07-28 03:55:26 --> You did not select a file to upload.
INFO - 2018-07-28 03:55:26 --> Config Class Initialized
INFO - 2018-07-28 03:55:26 --> Hooks Class Initialized
DEBUG - 2018-07-28 03:55:26 --> UTF-8 Support Enabled
INFO - 2018-07-28 03:55:26 --> Utf8 Class Initialized
INFO - 2018-07-28 03:55:26 --> URI Class Initialized
INFO - 2018-07-28 03:55:26 --> Router Class Initialized
INFO - 2018-07-28 03:55:26 --> Output Class Initialized
INFO - 2018-07-28 03:55:26 --> Security Class Initialized
DEBUG - 2018-07-28 03:55:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 03:55:26 --> Input Class Initialized
INFO - 2018-07-28 03:55:26 --> Language Class Initialized
INFO - 2018-07-28 03:55:26 --> Language Class Initialized
INFO - 2018-07-28 03:55:26 --> Config Class Initialized
INFO - 2018-07-28 03:55:26 --> Loader Class Initialized
DEBUG - 2018-07-28 03:55:26 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 03:55:26 --> Helper loaded: url_helper
INFO - 2018-07-28 03:55:26 --> Helper loaded: form_helper
INFO - 2018-07-28 03:55:26 --> Helper loaded: date_helper
INFO - 2018-07-28 03:55:26 --> Helper loaded: util_helper
INFO - 2018-07-28 03:55:26 --> Helper loaded: text_helper
INFO - 2018-07-28 03:55:26 --> Helper loaded: string_helper
INFO - 2018-07-28 03:55:26 --> Database Driver Class Initialized
DEBUG - 2018-07-28 03:55:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 03:55:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 03:55:27 --> Email Class Initialized
INFO - 2018-07-28 03:55:27 --> Controller Class Initialized
DEBUG - 2018-07-28 03:55:27 --> Programs MX_Controller Initialized
INFO - 2018-07-28 03:55:27 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 03:55:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-28 03:55:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 03:55:27 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 03:55:27 --> Login MX_Controller Initialized
DEBUG - 2018-07-28 03:55:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-28 03:55:27 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
ERROR - 2018-07-28 03:55:27 --> Severity: Notice --> Undefined index: prg_img_vid_name E:\xampp\htdocs\consulting\application\modules\admin\controllers\Programs.php 106
INFO - 2018-07-28 03:55:27 --> Upload Class Initialized
ERROR - 2018-07-28 03:55:27 --> Severity: Notice --> Undefined index: tmp_name E:\xampp\htdocs\consulting\system\libraries\Upload.php 412
INFO - 2018-07-28 03:55:27 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2018-07-28 03:55:27 --> You did not select a file to upload.
INFO - 2018-07-28 03:55:29 --> Config Class Initialized
INFO - 2018-07-28 03:55:29 --> Hooks Class Initialized
DEBUG - 2018-07-28 03:55:29 --> UTF-8 Support Enabled
INFO - 2018-07-28 03:55:29 --> Utf8 Class Initialized
INFO - 2018-07-28 03:55:29 --> URI Class Initialized
INFO - 2018-07-28 03:55:29 --> Router Class Initialized
INFO - 2018-07-28 03:55:29 --> Output Class Initialized
INFO - 2018-07-28 03:55:29 --> Security Class Initialized
DEBUG - 2018-07-28 03:55:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 03:55:29 --> Input Class Initialized
INFO - 2018-07-28 03:55:29 --> Language Class Initialized
ERROR - 2018-07-28 03:55:29 --> 404 Page Not Found: /index
INFO - 2018-07-28 03:55:32 --> Config Class Initialized
INFO - 2018-07-28 03:55:32 --> Hooks Class Initialized
DEBUG - 2018-07-28 03:55:32 --> UTF-8 Support Enabled
INFO - 2018-07-28 03:55:32 --> Utf8 Class Initialized
INFO - 2018-07-28 03:55:32 --> URI Class Initialized
INFO - 2018-07-28 03:55:32 --> Router Class Initialized
INFO - 2018-07-28 03:55:32 --> Output Class Initialized
INFO - 2018-07-28 03:55:32 --> Security Class Initialized
DEBUG - 2018-07-28 03:55:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 03:55:32 --> Input Class Initialized
INFO - 2018-07-28 03:55:32 --> Language Class Initialized
INFO - 2018-07-28 03:55:32 --> Language Class Initialized
INFO - 2018-07-28 03:55:32 --> Config Class Initialized
INFO - 2018-07-28 03:55:32 --> Loader Class Initialized
DEBUG - 2018-07-28 03:55:32 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 03:55:32 --> Helper loaded: url_helper
INFO - 2018-07-28 03:55:32 --> Helper loaded: form_helper
INFO - 2018-07-28 03:55:32 --> Helper loaded: date_helper
INFO - 2018-07-28 03:55:32 --> Helper loaded: util_helper
INFO - 2018-07-28 03:55:32 --> Helper loaded: text_helper
INFO - 2018-07-28 03:55:32 --> Helper loaded: string_helper
INFO - 2018-07-28 03:55:32 --> Database Driver Class Initialized
DEBUG - 2018-07-28 03:55:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 03:55:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 03:55:32 --> Email Class Initialized
INFO - 2018-07-28 03:55:32 --> Controller Class Initialized
DEBUG - 2018-07-28 03:55:32 --> Programs MX_Controller Initialized
INFO - 2018-07-28 03:55:32 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 03:55:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-28 03:55:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 03:55:33 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 03:55:33 --> Login MX_Controller Initialized
DEBUG - 2018-07-28 03:55:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-28 03:55:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
ERROR - 2018-07-28 03:55:33 --> Severity: Notice --> Undefined index: prg_img_vid_name E:\xampp\htdocs\consulting\application\modules\admin\controllers\Programs.php 106
INFO - 2018-07-28 03:55:33 --> Upload Class Initialized
ERROR - 2018-07-28 03:55:33 --> Severity: Notice --> Undefined index: tmp_name E:\xampp\htdocs\consulting\system\libraries\Upload.php 412
INFO - 2018-07-28 03:55:33 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2018-07-28 03:55:33 --> You did not select a file to upload.
INFO - 2018-07-28 03:56:06 --> Config Class Initialized
INFO - 2018-07-28 03:56:06 --> Hooks Class Initialized
DEBUG - 2018-07-28 03:56:06 --> UTF-8 Support Enabled
INFO - 2018-07-28 03:56:06 --> Utf8 Class Initialized
INFO - 2018-07-28 03:56:06 --> URI Class Initialized
INFO - 2018-07-28 03:56:06 --> Router Class Initialized
INFO - 2018-07-28 03:56:06 --> Output Class Initialized
INFO - 2018-07-28 03:56:06 --> Security Class Initialized
DEBUG - 2018-07-28 03:56:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 03:56:06 --> Input Class Initialized
INFO - 2018-07-28 03:56:06 --> Language Class Initialized
INFO - 2018-07-28 03:56:06 --> Language Class Initialized
INFO - 2018-07-28 03:56:06 --> Config Class Initialized
INFO - 2018-07-28 03:56:06 --> Loader Class Initialized
DEBUG - 2018-07-28 03:56:06 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 03:56:06 --> Helper loaded: url_helper
INFO - 2018-07-28 03:56:06 --> Helper loaded: form_helper
INFO - 2018-07-28 03:56:06 --> Helper loaded: date_helper
INFO - 2018-07-28 03:56:06 --> Helper loaded: util_helper
INFO - 2018-07-28 03:56:06 --> Helper loaded: text_helper
INFO - 2018-07-28 03:56:06 --> Helper loaded: string_helper
INFO - 2018-07-28 03:56:06 --> Database Driver Class Initialized
DEBUG - 2018-07-28 03:56:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 03:56:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 03:56:06 --> Email Class Initialized
INFO - 2018-07-28 03:56:07 --> Controller Class Initialized
DEBUG - 2018-07-28 03:56:07 --> Programs MX_Controller Initialized
INFO - 2018-07-28 03:56:07 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 03:56:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-28 03:56:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 03:56:07 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 03:56:07 --> Login MX_Controller Initialized
DEBUG - 2018-07-28 03:56:07 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-28 03:56:33 --> Config Class Initialized
INFO - 2018-07-28 03:56:33 --> Hooks Class Initialized
DEBUG - 2018-07-28 03:56:33 --> UTF-8 Support Enabled
INFO - 2018-07-28 03:56:33 --> Utf8 Class Initialized
INFO - 2018-07-28 03:56:33 --> URI Class Initialized
INFO - 2018-07-28 03:56:33 --> Router Class Initialized
INFO - 2018-07-28 03:56:33 --> Output Class Initialized
INFO - 2018-07-28 03:56:33 --> Security Class Initialized
DEBUG - 2018-07-28 03:56:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 03:56:33 --> Input Class Initialized
INFO - 2018-07-28 03:56:33 --> Language Class Initialized
INFO - 2018-07-28 03:56:33 --> Language Class Initialized
INFO - 2018-07-28 03:56:33 --> Config Class Initialized
INFO - 2018-07-28 03:56:33 --> Loader Class Initialized
DEBUG - 2018-07-28 03:56:33 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 03:56:33 --> Helper loaded: url_helper
INFO - 2018-07-28 03:56:33 --> Helper loaded: form_helper
INFO - 2018-07-28 03:56:33 --> Helper loaded: date_helper
INFO - 2018-07-28 03:56:33 --> Helper loaded: util_helper
INFO - 2018-07-28 03:56:33 --> Helper loaded: text_helper
INFO - 2018-07-28 03:56:33 --> Helper loaded: string_helper
INFO - 2018-07-28 03:56:33 --> Database Driver Class Initialized
DEBUG - 2018-07-28 03:56:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 03:56:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 03:56:33 --> Email Class Initialized
INFO - 2018-07-28 03:56:33 --> Controller Class Initialized
DEBUG - 2018-07-28 03:56:33 --> Programs MX_Controller Initialized
INFO - 2018-07-28 03:56:33 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 03:56:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-28 03:56:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 03:56:33 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 03:56:33 --> Login MX_Controller Initialized
DEBUG - 2018-07-28 03:56:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-28 03:56:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-28 03:56:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-28 03:56:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-28 03:56:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-28 03:56:33 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-28 03:56:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/create_program.php
INFO - 2018-07-28 03:56:34 --> Final output sent to browser
DEBUG - 2018-07-28 03:56:34 --> Total execution time: 0.7003
INFO - 2018-07-28 03:56:35 --> Config Class Initialized
INFO - 2018-07-28 03:56:35 --> Hooks Class Initialized
DEBUG - 2018-07-28 03:56:35 --> UTF-8 Support Enabled
INFO - 2018-07-28 03:56:35 --> Utf8 Class Initialized
INFO - 2018-07-28 03:56:35 --> URI Class Initialized
INFO - 2018-07-28 03:56:35 --> Router Class Initialized
INFO - 2018-07-28 03:56:35 --> Output Class Initialized
INFO - 2018-07-28 03:56:35 --> Security Class Initialized
DEBUG - 2018-07-28 03:56:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 03:56:35 --> Input Class Initialized
INFO - 2018-07-28 03:56:35 --> Language Class Initialized
ERROR - 2018-07-28 03:56:35 --> 404 Page Not Found: /index
INFO - 2018-07-28 03:56:47 --> Config Class Initialized
INFO - 2018-07-28 03:56:47 --> Hooks Class Initialized
DEBUG - 2018-07-28 03:56:47 --> UTF-8 Support Enabled
INFO - 2018-07-28 03:56:47 --> Utf8 Class Initialized
INFO - 2018-07-28 03:56:47 --> URI Class Initialized
INFO - 2018-07-28 03:56:47 --> Router Class Initialized
INFO - 2018-07-28 03:56:47 --> Output Class Initialized
INFO - 2018-07-28 03:56:47 --> Security Class Initialized
DEBUG - 2018-07-28 03:56:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 03:56:47 --> Input Class Initialized
INFO - 2018-07-28 03:56:47 --> Language Class Initialized
INFO - 2018-07-28 03:56:47 --> Language Class Initialized
INFO - 2018-07-28 03:56:47 --> Config Class Initialized
INFO - 2018-07-28 03:56:47 --> Loader Class Initialized
DEBUG - 2018-07-28 03:56:47 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 03:56:47 --> Helper loaded: url_helper
INFO - 2018-07-28 03:56:47 --> Helper loaded: form_helper
INFO - 2018-07-28 03:56:47 --> Helper loaded: date_helper
INFO - 2018-07-28 03:56:47 --> Helper loaded: util_helper
INFO - 2018-07-28 03:56:47 --> Helper loaded: text_helper
INFO - 2018-07-28 03:56:47 --> Helper loaded: string_helper
INFO - 2018-07-28 03:56:47 --> Database Driver Class Initialized
DEBUG - 2018-07-28 03:56:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 03:56:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 03:56:47 --> Email Class Initialized
INFO - 2018-07-28 03:56:47 --> Controller Class Initialized
DEBUG - 2018-07-28 03:56:47 --> Programs MX_Controller Initialized
INFO - 2018-07-28 03:56:47 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 03:56:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-28 03:56:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 03:56:47 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 03:56:47 --> Login MX_Controller Initialized
DEBUG - 2018-07-28 03:56:47 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-28 03:58:53 --> Config Class Initialized
INFO - 2018-07-28 03:58:53 --> Hooks Class Initialized
DEBUG - 2018-07-28 03:58:53 --> UTF-8 Support Enabled
INFO - 2018-07-28 03:58:53 --> Utf8 Class Initialized
INFO - 2018-07-28 03:58:53 --> URI Class Initialized
INFO - 2018-07-28 03:58:53 --> Router Class Initialized
INFO - 2018-07-28 03:58:53 --> Output Class Initialized
INFO - 2018-07-28 03:58:53 --> Security Class Initialized
DEBUG - 2018-07-28 03:58:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 03:58:53 --> Input Class Initialized
INFO - 2018-07-28 03:58:53 --> Language Class Initialized
INFO - 2018-07-28 03:58:53 --> Language Class Initialized
INFO - 2018-07-28 03:58:53 --> Config Class Initialized
INFO - 2018-07-28 03:58:53 --> Loader Class Initialized
DEBUG - 2018-07-28 03:58:53 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 03:58:53 --> Helper loaded: url_helper
INFO - 2018-07-28 03:58:53 --> Helper loaded: form_helper
INFO - 2018-07-28 03:58:54 --> Helper loaded: date_helper
INFO - 2018-07-28 03:58:54 --> Helper loaded: util_helper
INFO - 2018-07-28 03:58:54 --> Helper loaded: text_helper
INFO - 2018-07-28 03:58:54 --> Helper loaded: string_helper
INFO - 2018-07-28 03:58:54 --> Database Driver Class Initialized
DEBUG - 2018-07-28 03:58:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 03:58:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 03:58:54 --> Email Class Initialized
INFO - 2018-07-28 03:58:54 --> Controller Class Initialized
DEBUG - 2018-07-28 03:58:54 --> Programs MX_Controller Initialized
INFO - 2018-07-28 03:58:54 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 03:58:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-28 03:58:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 03:58:54 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 03:58:54 --> Login MX_Controller Initialized
DEBUG - 2018-07-28 03:58:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-28 03:58:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-28 03:58:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-28 03:58:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-28 03:58:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-28 03:58:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-28 03:58:54 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/create_program.php
INFO - 2018-07-28 03:58:54 --> Final output sent to browser
DEBUG - 2018-07-28 03:58:54 --> Total execution time: 0.7123
INFO - 2018-07-28 03:58:55 --> Config Class Initialized
INFO - 2018-07-28 03:58:55 --> Hooks Class Initialized
DEBUG - 2018-07-28 03:58:55 --> UTF-8 Support Enabled
INFO - 2018-07-28 03:58:55 --> Utf8 Class Initialized
INFO - 2018-07-28 03:58:55 --> URI Class Initialized
INFO - 2018-07-28 03:58:55 --> Router Class Initialized
INFO - 2018-07-28 03:58:55 --> Output Class Initialized
INFO - 2018-07-28 03:58:55 --> Security Class Initialized
DEBUG - 2018-07-28 03:58:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 03:58:55 --> Input Class Initialized
INFO - 2018-07-28 03:58:55 --> Language Class Initialized
ERROR - 2018-07-28 03:58:55 --> 404 Page Not Found: /index
INFO - 2018-07-28 03:59:03 --> Config Class Initialized
INFO - 2018-07-28 03:59:03 --> Hooks Class Initialized
DEBUG - 2018-07-28 03:59:03 --> UTF-8 Support Enabled
INFO - 2018-07-28 03:59:03 --> Utf8 Class Initialized
INFO - 2018-07-28 03:59:03 --> URI Class Initialized
INFO - 2018-07-28 03:59:03 --> Router Class Initialized
INFO - 2018-07-28 03:59:03 --> Output Class Initialized
INFO - 2018-07-28 03:59:03 --> Security Class Initialized
DEBUG - 2018-07-28 03:59:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 03:59:04 --> Input Class Initialized
INFO - 2018-07-28 03:59:04 --> Language Class Initialized
INFO - 2018-07-28 03:59:04 --> Language Class Initialized
INFO - 2018-07-28 03:59:04 --> Config Class Initialized
INFO - 2018-07-28 03:59:04 --> Loader Class Initialized
DEBUG - 2018-07-28 03:59:04 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 03:59:04 --> Helper loaded: url_helper
INFO - 2018-07-28 03:59:04 --> Helper loaded: form_helper
INFO - 2018-07-28 03:59:04 --> Helper loaded: date_helper
INFO - 2018-07-28 03:59:04 --> Helper loaded: util_helper
INFO - 2018-07-28 03:59:04 --> Helper loaded: text_helper
INFO - 2018-07-28 03:59:04 --> Helper loaded: string_helper
INFO - 2018-07-28 03:59:04 --> Database Driver Class Initialized
DEBUG - 2018-07-28 03:59:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 03:59:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 03:59:04 --> Email Class Initialized
INFO - 2018-07-28 03:59:04 --> Controller Class Initialized
DEBUG - 2018-07-28 03:59:04 --> Programs MX_Controller Initialized
INFO - 2018-07-28 03:59:04 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 03:59:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-28 03:59:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 03:59:04 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 03:59:04 --> Login MX_Controller Initialized
DEBUG - 2018-07-28 03:59:04 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-28 03:59:34 --> Config Class Initialized
INFO - 2018-07-28 03:59:34 --> Hooks Class Initialized
DEBUG - 2018-07-28 03:59:34 --> UTF-8 Support Enabled
INFO - 2018-07-28 03:59:34 --> Utf8 Class Initialized
INFO - 2018-07-28 03:59:34 --> URI Class Initialized
INFO - 2018-07-28 03:59:34 --> Router Class Initialized
INFO - 2018-07-28 03:59:34 --> Output Class Initialized
INFO - 2018-07-28 03:59:34 --> Security Class Initialized
DEBUG - 2018-07-28 03:59:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 03:59:34 --> Input Class Initialized
INFO - 2018-07-28 03:59:34 --> Language Class Initialized
INFO - 2018-07-28 03:59:34 --> Language Class Initialized
INFO - 2018-07-28 03:59:34 --> Config Class Initialized
INFO - 2018-07-28 03:59:34 --> Loader Class Initialized
DEBUG - 2018-07-28 03:59:34 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 03:59:34 --> Helper loaded: url_helper
INFO - 2018-07-28 03:59:34 --> Helper loaded: form_helper
INFO - 2018-07-28 03:59:34 --> Helper loaded: date_helper
INFO - 2018-07-28 03:59:34 --> Helper loaded: util_helper
INFO - 2018-07-28 03:59:34 --> Helper loaded: text_helper
INFO - 2018-07-28 03:59:34 --> Helper loaded: string_helper
INFO - 2018-07-28 03:59:34 --> Database Driver Class Initialized
DEBUG - 2018-07-28 03:59:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 03:59:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 03:59:34 --> Email Class Initialized
INFO - 2018-07-28 03:59:34 --> Controller Class Initialized
DEBUG - 2018-07-28 03:59:34 --> Programs MX_Controller Initialized
INFO - 2018-07-28 03:59:34 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 03:59:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-28 03:59:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 03:59:34 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 03:59:34 --> Login MX_Controller Initialized
DEBUG - 2018-07-28 03:59:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-28 03:59:34 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
INFO - 2018-07-28 03:59:34 --> Upload Class Initialized
INFO - 2018-07-28 04:29:08 --> Config Class Initialized
INFO - 2018-07-28 04:29:08 --> Hooks Class Initialized
DEBUG - 2018-07-28 04:29:08 --> UTF-8 Support Enabled
INFO - 2018-07-28 04:29:08 --> Utf8 Class Initialized
INFO - 2018-07-28 04:29:08 --> URI Class Initialized
INFO - 2018-07-28 04:29:08 --> Router Class Initialized
INFO - 2018-07-28 04:29:08 --> Output Class Initialized
INFO - 2018-07-28 04:29:08 --> Security Class Initialized
DEBUG - 2018-07-28 04:29:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 04:29:08 --> Input Class Initialized
INFO - 2018-07-28 04:29:08 --> Language Class Initialized
INFO - 2018-07-28 04:29:08 --> Language Class Initialized
INFO - 2018-07-28 04:29:08 --> Config Class Initialized
INFO - 2018-07-28 04:29:08 --> Loader Class Initialized
DEBUG - 2018-07-28 04:29:08 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 04:29:08 --> Helper loaded: url_helper
INFO - 2018-07-28 04:29:08 --> Helper loaded: form_helper
INFO - 2018-07-28 04:29:08 --> Helper loaded: date_helper
INFO - 2018-07-28 04:29:08 --> Helper loaded: util_helper
INFO - 2018-07-28 04:29:09 --> Helper loaded: text_helper
INFO - 2018-07-28 04:29:09 --> Helper loaded: string_helper
INFO - 2018-07-28 04:29:09 --> Database Driver Class Initialized
DEBUG - 2018-07-28 04:29:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 04:29:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 04:29:09 --> Email Class Initialized
INFO - 2018-07-28 04:29:09 --> Controller Class Initialized
DEBUG - 2018-07-28 04:29:09 --> Programs MX_Controller Initialized
INFO - 2018-07-28 04:29:09 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 04:29:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-28 04:29:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 04:29:09 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 04:29:09 --> Login MX_Controller Initialized
DEBUG - 2018-07-28 04:29:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-28 04:29:09 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
INFO - 2018-07-28 04:29:09 --> Upload Class Initialized
INFO - 2018-07-28 04:29:29 --> Config Class Initialized
INFO - 2018-07-28 04:29:29 --> Hooks Class Initialized
DEBUG - 2018-07-28 04:29:29 --> UTF-8 Support Enabled
INFO - 2018-07-28 04:29:29 --> Utf8 Class Initialized
INFO - 2018-07-28 04:29:29 --> URI Class Initialized
INFO - 2018-07-28 04:29:30 --> Router Class Initialized
INFO - 2018-07-28 04:29:30 --> Output Class Initialized
INFO - 2018-07-28 04:29:30 --> Security Class Initialized
DEBUG - 2018-07-28 04:29:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 04:29:30 --> Input Class Initialized
INFO - 2018-07-28 04:29:30 --> Language Class Initialized
INFO - 2018-07-28 04:29:30 --> Language Class Initialized
INFO - 2018-07-28 04:29:30 --> Config Class Initialized
INFO - 2018-07-28 04:29:30 --> Loader Class Initialized
DEBUG - 2018-07-28 04:29:30 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 04:29:30 --> Helper loaded: url_helper
INFO - 2018-07-28 04:29:30 --> Helper loaded: form_helper
INFO - 2018-07-28 04:29:30 --> Helper loaded: date_helper
INFO - 2018-07-28 04:29:30 --> Helper loaded: util_helper
INFO - 2018-07-28 04:29:30 --> Helper loaded: text_helper
INFO - 2018-07-28 04:29:30 --> Helper loaded: string_helper
INFO - 2018-07-28 04:29:30 --> Database Driver Class Initialized
DEBUG - 2018-07-28 04:29:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 04:29:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 04:29:30 --> Email Class Initialized
INFO - 2018-07-28 04:29:30 --> Controller Class Initialized
DEBUG - 2018-07-28 04:29:30 --> Programs MX_Controller Initialized
INFO - 2018-07-28 04:29:30 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 04:29:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-28 04:29:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 04:29:30 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 04:29:30 --> Login MX_Controller Initialized
DEBUG - 2018-07-28 04:29:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-28 04:29:30 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Upload_model.php
INFO - 2018-07-28 04:29:30 --> Upload Class Initialized
INFO - 2018-07-28 04:29:30 --> Config Class Initialized
INFO - 2018-07-28 04:29:30 --> Hooks Class Initialized
DEBUG - 2018-07-28 04:29:30 --> UTF-8 Support Enabled
INFO - 2018-07-28 04:29:30 --> Utf8 Class Initialized
INFO - 2018-07-28 04:29:30 --> URI Class Initialized
INFO - 2018-07-28 04:29:30 --> Router Class Initialized
INFO - 2018-07-28 04:29:30 --> Output Class Initialized
INFO - 2018-07-28 04:29:30 --> Security Class Initialized
DEBUG - 2018-07-28 04:29:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 04:29:30 --> Input Class Initialized
INFO - 2018-07-28 04:29:30 --> Language Class Initialized
INFO - 2018-07-28 04:29:30 --> Language Class Initialized
INFO - 2018-07-28 04:29:30 --> Config Class Initialized
INFO - 2018-07-28 04:29:30 --> Loader Class Initialized
DEBUG - 2018-07-28 04:29:30 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 04:29:30 --> Helper loaded: url_helper
INFO - 2018-07-28 04:29:30 --> Helper loaded: form_helper
INFO - 2018-07-28 04:29:30 --> Helper loaded: date_helper
INFO - 2018-07-28 04:29:30 --> Helper loaded: util_helper
INFO - 2018-07-28 04:29:30 --> Helper loaded: text_helper
INFO - 2018-07-28 04:29:30 --> Helper loaded: string_helper
INFO - 2018-07-28 04:29:31 --> Database Driver Class Initialized
DEBUG - 2018-07-28 04:29:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 04:29:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 04:29:31 --> Email Class Initialized
INFO - 2018-07-28 04:29:31 --> Controller Class Initialized
DEBUG - 2018-07-28 04:29:31 --> Programs MX_Controller Initialized
INFO - 2018-07-28 04:29:31 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 04:29:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-28 04:29:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 04:29:31 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 04:29:31 --> Login MX_Controller Initialized
DEBUG - 2018-07-28 04:29:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-28 04:29:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-28 04:29:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-28 04:29:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-28 04:29:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-28 04:29:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-28 04:29:31 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/programs.php
INFO - 2018-07-28 04:29:31 --> Final output sent to browser
DEBUG - 2018-07-28 04:29:31 --> Total execution time: 0.7583
INFO - 2018-07-28 04:29:31 --> Config Class Initialized
INFO - 2018-07-28 04:29:31 --> Hooks Class Initialized
DEBUG - 2018-07-28 04:29:31 --> UTF-8 Support Enabled
INFO - 2018-07-28 04:29:31 --> Utf8 Class Initialized
INFO - 2018-07-28 04:29:31 --> URI Class Initialized
INFO - 2018-07-28 04:29:31 --> Router Class Initialized
INFO - 2018-07-28 04:29:31 --> Output Class Initialized
INFO - 2018-07-28 04:29:31 --> Security Class Initialized
DEBUG - 2018-07-28 04:29:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 04:29:31 --> Input Class Initialized
INFO - 2018-07-28 04:29:32 --> Language Class Initialized
INFO - 2018-07-28 04:29:32 --> Language Class Initialized
INFO - 2018-07-28 04:29:32 --> Config Class Initialized
INFO - 2018-07-28 04:29:32 --> Loader Class Initialized
DEBUG - 2018-07-28 04:29:32 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 04:29:32 --> Helper loaded: url_helper
INFO - 2018-07-28 04:29:32 --> Helper loaded: form_helper
INFO - 2018-07-28 04:29:32 --> Helper loaded: date_helper
INFO - 2018-07-28 04:29:32 --> Helper loaded: util_helper
INFO - 2018-07-28 04:29:32 --> Helper loaded: text_helper
INFO - 2018-07-28 04:29:32 --> Helper loaded: string_helper
INFO - 2018-07-28 04:29:32 --> Database Driver Class Initialized
DEBUG - 2018-07-28 04:29:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 04:29:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 04:29:32 --> Email Class Initialized
INFO - 2018-07-28 04:29:32 --> Controller Class Initialized
DEBUG - 2018-07-28 04:29:32 --> Programs MX_Controller Initialized
INFO - 2018-07-28 04:29:32 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 04:29:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-28 04:29:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 04:29:32 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 04:29:32 --> Login MX_Controller Initialized
DEBUG - 2018-07-28 04:29:32 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
INFO - 2018-07-28 04:29:32 --> Final output sent to browser
DEBUG - 2018-07-28 04:29:32 --> Total execution time: 0.7005
INFO - 2018-07-28 04:29:39 --> Config Class Initialized
INFO - 2018-07-28 04:29:39 --> Hooks Class Initialized
DEBUG - 2018-07-28 04:29:39 --> UTF-8 Support Enabled
INFO - 2018-07-28 04:29:39 --> Utf8 Class Initialized
INFO - 2018-07-28 04:29:39 --> URI Class Initialized
INFO - 2018-07-28 04:29:39 --> Router Class Initialized
INFO - 2018-07-28 04:29:39 --> Output Class Initialized
INFO - 2018-07-28 04:29:39 --> Security Class Initialized
DEBUG - 2018-07-28 04:29:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-28 04:29:39 --> Input Class Initialized
INFO - 2018-07-28 04:29:39 --> Language Class Initialized
INFO - 2018-07-28 04:29:39 --> Language Class Initialized
INFO - 2018-07-28 04:29:39 --> Config Class Initialized
INFO - 2018-07-28 04:29:39 --> Loader Class Initialized
DEBUG - 2018-07-28 04:29:39 --> Config file loaded: E:\xampp\htdocs\consulting\application\config/construct-data.php
INFO - 2018-07-28 04:29:39 --> Helper loaded: url_helper
INFO - 2018-07-28 04:29:39 --> Helper loaded: form_helper
INFO - 2018-07-28 04:29:39 --> Helper loaded: date_helper
INFO - 2018-07-28 04:29:39 --> Helper loaded: util_helper
INFO - 2018-07-28 04:29:39 --> Helper loaded: text_helper
INFO - 2018-07-28 04:29:39 --> Helper loaded: string_helper
INFO - 2018-07-28 04:29:40 --> Database Driver Class Initialized
DEBUG - 2018-07-28 04:29:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-28 04:29:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-28 04:29:40 --> Email Class Initialized
INFO - 2018-07-28 04:29:40 --> Controller Class Initialized
DEBUG - 2018-07-28 04:29:40 --> Programs MX_Controller Initialized
INFO - 2018-07-28 04:29:40 --> Language file loaded: language/english/data_lang.php
DEBUG - 2018-07-28 04:29:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Programs_model.php
DEBUG - 2018-07-28 04:29:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/models/Common_model.php
DEBUG - 2018-07-28 04:29:40 --> File loaded: E:\xampp\htdocs\consulting\application\controllers/../modules/admin/controllers/Login.php
DEBUG - 2018-07-28 04:29:40 --> Login MX_Controller Initialized
DEBUG - 2018-07-28 04:29:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/models/Loginmdl.php
DEBUG - 2018-07-28 04:29:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/css.php
DEBUG - 2018-07-28 04:29:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-top_nav.php
DEBUG - 2018-07-28 04:29:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/common/admin-left_nav.php
DEBUG - 2018-07-28 04:29:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/footer.php
DEBUG - 2018-07-28 04:29:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/common/views/common/js.php
DEBUG - 2018-07-28 04:29:40 --> File loaded: E:\xampp\htdocs\consulting\application\modules/admin/views/programs/create_program.php
INFO - 2018-07-28 04:29:40 --> Final output sent to browser
DEBUG - 2018-07-28 04:29:40 --> Total execution time: 0.7048
