<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <?php $this->load->view('common/common/css') ?>
  <link rel="stylesheet" href="<?php echo config_item('ui_base_path'); ?>/plugins/progressbar/jQuery-plugin-progressbar.css"/>
  <style>
    /*.fix_heig{
        height: 350px;
    }
    .fix_scroll{
        overflow: auto;
        height: 250px;
    }*/
    .progress-bar{
        box-shadow: inset 0 0px 0 rgba(0,0,0,.15);
        background-color: #ffffff;
        color: #0e0e0e;
    }
  </style>
</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">
  <?php $this->load->view('common/admin-top_nav') ?>
  <?php $this->load->view('common/admin-left_nav') ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Admin Dashboard
        <small>Control panel</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo site_url('admin') ?>"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Admin Dashboard</li>
      </ol>
    </section>

    <!-- Main content -->
    <input type="hidden" id="page" value="nav-dashbooard"/>
    <section class="content">
      
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <!-- Control Sidebar -->
  <?php $this->load->view('common/common/footer'); ?>
  <!-- Add the sidebar's background. This div must be placed
       immediately after the control sidebar -->
  <div class="control-sidebar-bg"></div>
</div>
<!-- ./wrapper -->

<?php $this->load->view('common/common/js') ?>
<!-- AdminLTE dashboard demo (This is only for demo purposes) -->
<script src="<?php echo config_item('ui_base_path'); ?>dist/js/pages/dashboard2.js"></script>
<!-- ChartJS 1.0.1 -->
<script src="<?php echo config_item('ui_base_path'); ?>plugins/chartjs/Chart.min.js"></script>
<!-- DOC -->
<script src="<?php echo config_item('ui_base_path'); ?>documentation/docs.js"></script>
<script src="<?php echo config_item('ui_base_path'); ?>/plugins/progressbar/jQuery-plugin-progressbar.js"></script>
<script>
    $(".progress-bar").loading();
    $('.product-list-in-box1').slimScroll({
      //color: '#fff',
      //railVisible: true,
      size: '10px',
      height: '350px'
  });	
</script>
</body>
</html>
