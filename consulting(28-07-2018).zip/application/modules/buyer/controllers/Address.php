<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Address extends MX_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->lang->load('data');
        $this->load->model('common/upload_model');
        $this->load->model('common/common_model');
        $this->load->model('address_model');
        modules::run('admin/login/is_buyer_logged_in');
    }
    
    public function index()
    {
        $this->load->view('address/address');
    }
    
    /**
    * get_address_list
    * Get Photo event List
    * @author GOPI PANGULURI<gopi.panguluri@mindtechlabs.com>
    * @param type $data
    */
    public function get_address_list()
    {
        $result = $this->address_model->get_address_list();
        //echo '<pre>'; print_r($result);exit;
        $aaData = array();
        foreach($result['aaData'] as $row){
            $row[0] = '<input type="checkbox" id="checkbox-1-' . intval($row[0]) . '" class="checkbox1 regular-checkbox" name="regular-checkbox"
                                value="' . $row[0] . '"/><label for="checkbox-1-' . intval($row[0]) . '"></label>';
            //$row[2] = '<a href="'. base_url('assets/images/address/'.$row[2]).'" target="_blank"> View File </a>';
            //$row[3] = word_limiter($row[3], 30);
            //$row[3] = date('Y-M-d',strtotime($row[3]));
            //$row[4] = date('Y-M-d',strtotime($row[4]));
            if($row[5]==1){
            $row[5] = '<div id="status' . $row[6] . '">
                    <a href="javascript:void(0);" class="show-tooltip" title="Change Status" onclick="changestatus(' . $row[6] . ', ' . $row[5] . ')" >
                            <i class="glyphicon glyphicon-remove"></i>
                    </a></div> ';   
            }else{
                $row[5] = '<div id="status' . $row[6] . '">
                        <a href="javascript:void(0);" class="show-tooltip" title="Change Status" onclick="changestatus(' . $row[6] . ', ' . $row[5] . ')" >
                                <i class="glyphicon glyphicon-ok"></i>
                        </a></div> ';
            }
                $row[6] = '<a href="'.base_url('buyer/address/address_details/'). $row[6] . '" title="View Record" data-toggle="tooltip">
                            <i class="fa_size fa fa-eye"></i></a>
                <a href="'.base_url('buyer/address/create_address/'). $row[6] . '" title="Edit Record" data-toggle="tooltip">
                                    <i class="fa_size fa fa-pencil" ></i></a>
                           <a href="javascript:void(0)" data-toggle="tooltip" id="' . $row[6] . '" class="deleteme show-tooltip deleteitem_' . $row[6] . '"" title="Delete Record" data-tablename="address" data-fieldname="a_id" url="'. site_url('buyer/delete_all_record') .'">
                                    <i class="fa_size fa fa-trash-o "></i></a>';
            $aaData[] = $row;
        }
        $result['aaData'] = $aaData;
        //echo '<pre>'; print_r($result);exit;
        print_r(json_encode($result));
    }
    
   /**
    * create_news
    * Create News
    * @author GOPI PANGULURI<gopi.panguluri@mindtechlabs.com>
    * @param type $data
    */
    public function create_address($id = ''){
        //echo '<pre>';print_r($_FILES);
        //echo '<pre>';print_r($_POST);exit;
        $data['country'] = array(''=>'Select one') + $this->address_model->get_countries_list();
        $data['address_types'] = array(''=>'Select one') + $this->address_model->get_address_types_list();
        $data['states'] = array();
        $data['cities'] = array();
        $data['id_types'] = $this->config->item('address_receiver_id');
        if ($id != '') {
            $data['mode'] = 'edit';
            $data['msg'] = '';
            $info = array(
                'select_fields' => '',
                'where' => array(
                    'a_id' => $id
                ),
                'tablename' => 'address'
            );
            $data['item_details'] = $this->common_model->get_individual_details($info);
            $states = $this->address_model->get_states_list($data['item_details']['a_country']);
            $cities = $this->address_model->get_cities_list($data['item_details']['a_state']);
            foreach($states as $st_row){
                $data['states'][$st_row['state_id']] = $st_row['state_name'];
            }
            foreach($cities as $ct_row){
                $data['cities'][$ct_row['city_id']] = $ct_row['city_name'];
            }
            //echo '<pre>';print_r($data);exit;
            $this->load->view('address/create_address', $data);
        } else {
            if(isset($_POST['submit'])&&$_POST['submit']=='insert'){
            //echo '<pre>insert';print_r($_FILES);
            //echo '<pre>';print_r($_POST);exit;
            $ch_ed_data = array(
                    'select_fields' => '',
                    'where' => array(
                        'a_name' => $this->input->post('a_name'),
                        'a_country' => $this->input->post('a_country'),
                        'a_state' => $this->input->post('a_state'),
                        'a_city' => $this->input->post('a_city'),
                        'at_id' => $this->input->post('at_id'),
                        'user_id' => $_SESSION['buyer_user_id']
                    ),
                    'tablename' => 'address'
            );
            //echo '<pre>';print_r($ch_ed_data);exit;
            $check_unique = $this->common_model->get_list($ch_ed_data);
            //echo '<pre>';print_r($check_unique);exit;
            if(count($check_unique)!=0){
                $status = array(
                    'status' => 'fail',
                    'message' => 'Entered name & Location is already taken please enter another name & location'
                );
                $this->session->set_flashdata('insert_record', $status);
                echo json_encode($status);exit;
            }
            /* roles:-1= super admin,2= admin,3= user,4= School admin,5= event,6= parent,7= vendor */
             $info = array(
                'a_name' => $this->input->post('a_name'),
                'at_id' => $this->input->post('at_id'),
                'a_address_line' => $this->input->post('a_address_line'),
                'a_country' => $this->input->post('a_country'),
                'a_state' => $this->input->post('a_state'),
                'a_city' => $this->input->post('a_city'),
                'a_pincode' => $this->input->post('a_pincode'),
                'a_port_of_discharge' => $this->input->post('a_port_of_discharge'),
                'a_mobile' => $this->input->post('a_mobile'),
                'a_bussiness_ph' => $this->input->post('a_bussiness_ph'),
                'a_trstn_or_cst_no' => $this->input->post('a_trstn_or_cst_no'),
                'a_ecc_code' => $this->input->post('a_ecc_code'),
                'a_receiver_name' => $this->input->post('a_receiver_name'),
                'a_receiver_mobile' => $this->input->post('a_receiver_mobile'),
                'a_receiver_id' => $this->input->post('a_receiver_id'),
                'a_id_no' => $this->input->post('a_id_no'),
                'user_id' => $_SESSION['buyer_user_id']
              );
              //echo "<pre>";print_r($info);exit;
              $result_id = $this->address_model->insert_id_details('address', $info);
              //echo "<pre>";print_r($result);exit;
              if($result_id!=''){
                    $status = array(
                        'status' => 'success',
                        'go_to' => 'buyer/address',
                        'message' => 'Address added successfully'
                    );
                    echo json_encode($status);exit;
               }else{
                    $status = array(
                        'status' => 'fail',
                        'message' => 'Error while adding event details...'
                    );
                    echo json_encode($status);exit;
               }
            } if(isset($_POST['submit'])&&$_POST['submit']=='update') {
                //echo '<pre>';print_r($_FILES);
                //echo '<pre>';print_r($_POST);exit;
                $ch_ed_data = array(
                    'select_fields' => '',
                    'where' => array(
                        'a_name' => $this->input->post('a_name'),
                        'a_country' => $this->input->post('a_country'),
                        'a_state' => $this->input->post('a_state'),
                        'a_city' => $this->input->post('a_city'),
                        'at_id' => $this->input->post('at_id'),
                        'user_id' => $_SESSION['buyer_user_id'],
                        'a_id !=' => $this->input->post('id')
                    ),
                    'tablename' => 'address'
                );
                $check_unique = $this->common_model->get_list($ch_ed_data);
                if(count($check_unique)!=0){
                    $status = array(
                        'status' => 'fail',
                        'message' => 'Entered event name on the date is already taken please enter another email'
                    );
                    echo json_encode($status);exit;
                }
                
                $info = array(
                    'where' => array(
                        'a_id' => $this->input->post('id')
                    ),
                    'data' => array(
                        'a_name' => $this->input->post('a_name'),
                        'at_id' => $this->input->post('at_id'),
                        'a_address_line' => $this->input->post('a_address_line'),
                        'a_country' => $this->input->post('a_country'),
                        'a_state' => $this->input->post('a_state'),
                        'a_city' => $this->input->post('a_city'),
                        'a_pincode' => $this->input->post('a_pincode'),
                        'a_port_of_discharge' => $this->input->post('a_port_of_discharge'),
                        'a_mobile' => $this->input->post('a_mobile'),
                        'a_bussiness_ph' => $this->input->post('a_bussiness_ph'),
                        'a_trstn_or_cst_no' => $this->input->post('a_trstn_or_cst_no'),
                        'a_ecc_code' => $this->input->post('a_ecc_code'),
                        'a_receiver_name' => $this->input->post('a_receiver_name'),
                        'a_receiver_mobile' => $this->input->post('a_receiver_mobile'),
                        'a_receiver_id' => $this->input->post('a_receiver_id'),
                        'a_id_no' => $this->input->post('a_id_no')
                    ),
                    'tablename' => 'address'
                );
                //echo '<pre>';print_r($info);exit;
                $result = $this->common_model->update_details($info);
                if($result){
                  $status = array(
                        'status' => 'success',
                        'go_to' => 'buyer/address',
                        'message' => 'Address updated successfully'
                  );
                  $this->session->set_flashdata('insert_record', $status);
                  echo json_encode($status);exit;
               }else{
                //echo '<pre>not ok';print_r($_FILES);exit;
                $status = array(
                    'status' => 'fail',
                    'message' => 'Error while adding event details...'
                );
                echo json_encode($status);exit;
               }
            } else {
                $data['mode'] = 'create';
                $data['msg'] = '';
                $this->load->view('address/create_address', $data);
            }
        }
    }
    
    /**
    * event_details
    * event Details
    * @author GOPI PANGULURI<gopi.panguluri@mindtechlabs.com>
    * @param type $data
    */
    public function address_details($id){
        $data['address_types'] = array(''=>'Select one') + $this->address_model->get_address_types_list();
        $data['id_types'] = $this->config->item('address_receiver_id');
        $data['country'] = array(''=>'Select one') + $this->address_model->get_countries_list();
        $data['mode'] = 'details';
        $data['msg'] = '';
        $info = array(
            'select_fields' => '',
            'where' => array(
                'a_id' => $id
            ),
            'tablename' => 'address'
        );
        $data['item_details'] = $this->common_model->get_individual_details($info);
        $states = $this->address_model->get_states_list($data['item_details']['a_country']);
        $cities = $this->address_model->get_cities_list($data['item_details']['a_state']);
        foreach($states as $st_row){
            $data['states'][$st_row['state_id']] = $st_row['state_name'];
        }
        foreach($cities as $ct_row){
            $data['cities'][$ct_row['city_id']] = $ct_row['city_name'];
        }
        //echo '<pre>';print_r($data);exit;
        $this->load->view('address/create_address', $data);
    } 
    
}