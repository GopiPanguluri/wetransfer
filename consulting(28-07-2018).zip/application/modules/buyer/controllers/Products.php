<?php if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Products extends MX_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->lang->load('data');
        $this->load->model('common/upload_model');
        $this->load->model('common/common_model');
        $this->load->model('common/common_functions_model');
        $this->load->model('products_model');
        modules::run('admin/login/is_buyer_logged_in');
    }
    
    public function index()
    {
        $this->load->view('products/products');
    }
    
    /**
    * get_products_list
    * Get Photo product List
    * @author GOPI PANGULURI<gopi.panguluri@mindtechlabs.com>
    * @param type $data
    */
    public function get_products_list()
    {
        $result = $this->products_model->get_products_list();
        $aaData = array();
        foreach($result['aaData'] as $row){
            $row[0] = '<input type="checkbox" id="checkbox-1-' . intval($row[0]) . '" class="checkbox1 regular-checkbox" name="regular-checkbox"
                                value="' . $row[0] . '"/><label for="checkbox-1-' . intval($row[0]) . '"></label>';
            $row[1] = '<img src="'.config_item('root_dir').'assets/images/catelogues/'.$row['1'].'" height="150" width="150" alt="Image"/>';
            //$row[3] = word_limiter($row[3], 30);
            //$row[3] = date('M,Y',strtotime($row[3]));
            $user = $_SESSION['buyer_type'].'-'.$_SESSION['buyer_user_id'];
            $info = array(
                    'select_fields' => '',
                    'where' => array(
                        'product_id' => $row[7]
                    ),
                    'tablename' => 'negotiation_list'
            );
            
            $item_details = $this->common_model->get_individual_details($info);
            $users = explode(',',$item_details['users']);
            if(in_array($user, $users)){
                $row[6] = 1;
            }else{
                $row[6] = 0;
            }
            if($row[6]==1){
            $row[6] = '<div id="status' . $row[7] . '">
                    <a href="javascript:void(0);" class="show-tooltip" title="Change Status" onclick="addto_negotiation(' . $row[7] . ', ' . $row[6] . ')" >
                            <i class="fa fa-minus"></i>
                    </a></div> ';   
            }else{
                $row[6] = '<div id="status' . $row[7] . '">
                        <a href="javascript:void(0);" class="show-tooltip" title="Change Status" onclick="addto_negotiation(' . $row[7] . ', ' . $row[6] . ')" >
                                <i class="fa fa-plus"></i>
                        </a></div> ';
            }
                $row[7] = '<a href="'.base_url('buyer/products/product_details') ."/". $row[7] . '" title="View Record" data-toggle="tooltip">
                            <i class="fa_size fa fa-eye"></i></a>';
            $aaData[] = $row;
        }
        $result['aaData'] = $aaData;
        //echo '<pre>'; print_r($result);exit;
        print_r(json_encode($result));
    }
    
   /**
    * create_news
    * Create News
    * @author GOPI PANGULURI<gopi.panguluri@mindtechlabs.com>
    * @param type $data
    */
    public function create_product($id = ''){
        //echo '<pre>';print_r($_FILES);
        //echo '<pre>';print_r($_POST);exit;
        $data['product_cat'] = $this->common_functions_model->get_product_or_service_list('1');
        $data['service_cat'] = $this->common_functions_model->get_product_or_service_list('2');
        if ($id != '') {
            $data['mode'] = 'edit';
            $data['msg'] = '';
            $info = array(
                'select_fields' => '',
                'where' => array(
                    'product_id' => $id
                ),
                'tablename' => 'products'
            );
            $data['item_details'] = $this->common_model->get_individual_details($info);
            $info_catelog = array(
                'select_fields' => '',
                'where' => array(
                    'product_id' => $data['item_details']['product_id']
                ),
                'tablename' => 'catelogues'
            );
            $data['catelogues'] = $this->common_model->get_list($info_catelog);
            //echo '<pre>';print_r($data);exit;
            $this->load->view('products/create_product', $data);
        } else {
            if(isset($_POST['submit'])&&$_POST['submit']=='insert'){
                //echo '<pre>insert';print_r($_FILES);
                //echo '<pre>';print_r($_POST);exit;
                $ch_ed_data = array(
                    'select_fields' => '',
                    'where' => array(
                        'product_name' => $this->input->post('product_name'),
                        'type' => $this->input->post('type')
                    ),
                    'tablename' => 'products'
                );
                $check_unique = $this->common_model->get_list($ch_ed_data);
              if(count($check_unique)!=0){
                    $status = array(
                        'status' => 'fail',
                        'message' => 'Entered name for Product/Service is already taken please enter another'
                    );
                    //$this->session->set_flashdata('insert_record', $status);
                    echo json_encode($status);exit;
              }
                
              $product_image = '';
              if($_FILES['product_image']['name']!=''){
                    $product_image = '';
                    $files = $_FILES;
                    $time = time();
                    $string1 = str_replace(' ', '-', $_POST['product_name']); // Replaces all spaces with hyphens.
                    $string1 = preg_replace('/[^A-Za-z0-9\-]/', '', $string1); // Removes special chars.
                    $random_string = random_string('alnum', 16);
                    $title_product = $string1.'-'.$random_string;
                    $product_image_ext = explode(".",$_FILES['product_image']['name']);
                    $product_image_ext = end($product_image_ext);
                    //echo '<pre>';print_r($_FILES);exit;
                    $_FILES['product_image']['name'] =  $title_product .'.'.$product_image_ext;
                    //echo '<pre>';print_r($_FILES);exit;
                    $file_upl_data = $this->upload_model->uploadDocuments('product_image', 'seller_product_image');
                    //echo '<pre>';print_r($file_upl_data);exit;
                    if ($file_upl_data['success'] == 1) {
                        $product_image = $file_upl_data['file_name'];
                    } else {
                        $status = array(
                            'status' => 'fail',
                            'message' => $file_upl_data['msg']
                        );
                        //$this->session->set_flashdata('insert_record', $status);
                        //redirect('school/teachers/create_teacher');
                        echo json_encode($status);exit;
                    }
                }
                
                /* roles:-1= super admin,2= admin,3= user,4= School admin,5= product,6= parent,7= vendor */
                if($this->input->post('type')==1){
                    $info = array(
                        'product_name' => $this->input->post('product_name'),
                        'type' => $this->input->post('type'),
                        'product_price' => $this->input->post('product_price'),
                        'c_id' => $this->input->post('c_id'),
                        'user_id' => $_SESSION['seller_user_id']
                    );
                }else{
                    $info = array(
                        'product_name' => $this->input->post('product_name'),
                        'type' => $this->input->post('type'),
                        'service_type' => $this->input->post('service_type'),
                        'product_price' => $this->input->post('product_price'),
                        'man_power' => $this->input->post('man_power'),
                        'user_id' => $_SESSION['seller_user_id']
                    );
                }
                $info['product_image'] = $product_image;
                //echo "<pre>";print_r($info);exit;
                $result_id = $this->products_model->insert_id_details('products', $info);
                //echo "<pre>";print_r($result);exit;
                  if($result_id!=''){
                      if(isset($_FILES['catelogue']['name'][0]) && $_FILES['catelogue']['name'][0] != ''){
                        $certificate = '';
                        $files = $_FILES;
                        $pics_count = count($_FILES['catelogue']['name']);
                        //echo "<pre>";print_r($pics_count);exit;
                        $sno=0;
                        for($i = 0; $i < $pics_count; $i++){
                            $_FILES['picutes']['name'] = $files['catelogue']['name'][$sno];
                            $_FILES['picutes']['tmp_name'] = $files['catelogue']['tmp_name'][$sno];
                            $_FILES['picutes']['type'] = $files['catelogue']['type'][$sno];
                            $_FILES['picutes']['error'] = $files['catelogue']['error'][$sno];
                            $_FILES['picutes']['size'] = $files['catelogue']['size'][$sno];
                            $ce_img = 'picutes';
                            
                            $string1 = str_replace(' ', '-', $_POST['product_name']); // Replaces all spaces with hyphens.
                            $string1 = preg_replace('/[^A-Za-z0-9\-]/', '', $string1); // Removes special chars.
                            $random_string = random_string('alnum', 16);
                            $title_product = $string1.'-catelogue-'.$random_string;
                            $image_ext = explode(".",$_FILES['picutes']['name']);
                            $image_ext = end($image_ext);
                            //echo '<pre>';print_r($_FILES);exit;
                            $_FILES['picutes']['name'] =  $title_product .'.'.$image_ext;
                            
                            $y = $_FILES[$ce_img]['name'];
                            if ($y != '')
                            {
                                $file_upl_data = $this->upload_model->uploadfiles($ce_img, 'product_catelogue');
                                if ($file_upl_data['success'] == 1)
                                {
                                    $catelogue = $file_upl_data['file_name'];
                                    //echo '<pre>';print_r($catelogue);exit;
                                    $info = array('product_id' => $result_id, 'catlogues_name' => $catelogue);
                                    $result = $this->common_model->insert_details('catelogues', $info);
                                    $status = array(
                                        'status' => 'success',
                                        'go_to' => 'buyer/products',
                                        'message' => 'Product added successfully'
                                    );
                                    $this->session->set_flashdata('insert_record', $status);
                                    
                                }
                                else
                                {
                                   $status = array(
                                        'status' => 'fail',
                                        'message' => $file_upl_data['msg']
                                    );
                                    
                                }
                            }
                        $sno++; }
                        echo json_encode($status);exit;
                    }else{
                        $status = array(
                            'status' => 'success',
                            'go_to' => 'buyer/products',
                            'message' => 'Product added successfully'
                        );
                        $this->session->set_flashdata('insert_record', $status);
                        echo json_encode($status);exit;
                    }
               }else{
                    $status = array(
                        'status' => 'fail',
                        'message' => 'Error while adding product details...'
                    );
                    echo json_encode($status);exit;
               }
            } if(isset($_POST['submit'])&&$_POST['submit']=='update') {
                //echo '<pre>';print_r($_FILES);
                //echo '<pre>';print_r($_POST);exit;
                
                $ch_ed_data = array(
                    'select_fields' => '',
                    'where' => array(
                        'product_name' => $this->input->post('product_name'),
                        'type' => $this->input->post('type'),
                        'product_id !=' => $this->input->post('id')
                    ),
                    'tablename' => 'products'
                );
                $check_unique = $this->common_model->get_list($ch_ed_data);
                if(count($check_unique)!=0){
                    $status = array(
                        'status' => 'fail',
                        'message' => 'Entered name for Product/Service is already taken please enter another'
                    );
                    //$this->session->set_flashdata('insert_record', $status);
                    echo json_encode($status);exit;
                }
                
                
                if (isset($_FILES['product_image'])&&$_FILES['product_image']['name'] != ''){
                    $product_image = '';
                    $files = $_FILES;
                    $time = time();
                    $string1 = str_replace(' ', '-', $_POST['product_name']); // Replaces all spaces with hyphens.
                    $string1 = preg_replace('/[^A-Za-z0-9\-]/', '', $string1); // Removes special chars.
                    $random_string = random_string('alnum', 16);
                    $title_product = $string1.'-'.$random_string;
                    $product_image_ext = explode(".",$_FILES['product_image']['name']);
                    $product_image_ext = end($product_image_ext);
                    //echo '<pre>';print_r($_FILES);exit;
                    $_FILES['product_image']['name'] =  $title_product .'.'.$product_image_ext;
                    //echo '<pre>';print_r($_FILES);exit;
                    $file_upl_data = $this->upload_model->uploadDocuments('product_image', 'seller_product_image');
                    //echo '<pre>';print_r($file_upl_data);exit;
                    if ($file_upl_data['success'] == 1) {
                        $product_image = $file_upl_data['file_name'];
                        if (file_exists(config_item('root_dir').'assets/images/catelogues/'.$_POST['product_old_image'])) { 
                        unlink(FCPATH . 'assets/images/catelogues/' . $_POST['product_old_image']);
                        }
                    } else {
                        $status = array(
                            'status' => 'fail',
                            'message' => $file_upl_data['msg']
                        );
                        //$this->session->set_flashdata('insert_record', $status);
                        //redirect('school/teachers/create_teacher');
                        echo json_encode($status);exit;
                    }
                }else{
                    $product_image = $this->input->post('product_old_image');
                }
                
                if($this->input->post('type')==1){
                    $info_catl = array(
                        'product_name' => $this->input->post('product_name'),
                        'type' => $this->input->post('type'),
                        'product_price' => $this->input->post('product_price'),
                        'c_id' => $this->input->post('c_id'),
                        'user_id' => $_SESSION['seller_user_id']
                    );
                }else{
                    $info_catl = array(
                        'product_name' => $this->input->post('product_name'),
                        'type' => $this->input->post('type'),
                        'service_type' => $this->input->post('service_type'),
                        'man_power' => $this->input->post('man_power'),
                        'user_id' => $_SESSION['seller_user_id']
                    );
                }
                $info_catl['product_image'] = $product_image;
                $info = array(
                    'where' => array(
                        'product_id' => $this->input->post('id')
                    ),
                    'data' => $info_catl,
                    'tablename' => 'products'
                );
                //echo "<pre>";print_r($info);exit;
                $result = $this->products_model->update_techer_details($info);
                if($this->input->post('id')!==''){
                      if(isset($_FILES['catelogue']['name'][0]) && $_FILES['catelogue']['name'][0] != ''){
                        $certificate = '';
                        $files = $_FILES;
                        $pics_count = count($_FILES['catelogue']['name']);
                        //echo "<pre>";print_r($pics_count);exit;
                        $sno=0;
                        for($i = 0; $i < $pics_count; $i++){
                            $_FILES['picutes']['name'] = $files['catelogue']['name'][$sno];
                            $_FILES['picutes']['tmp_name'] = $files['catelogue']['tmp_name'][$sno];
                            $_FILES['picutes']['type'] = $files['catelogue']['type'][$sno];
                            $_FILES['picutes']['error'] = $files['catelogue']['error'][$sno];
                            $_FILES['picutes']['size'] = $files['catelogue']['size'][$sno];
                            $ce_img = 'picutes';
                            
                            $string1 = str_replace(' ', '-', $_POST['product_name']); // Replaces all spaces with hyphens.
                            $string1 = preg_replace('/[^A-Za-z0-9\-]/', '', $string1); // Removes special chars.
                            $random_string = random_string('alnum', 16);
                            $title_product = $string1.'-catelogue-'.$random_string;
                            $image_ext = explode(".",$_FILES['picutes']['name']);
                            $image_ext = end($image_ext);
                            //echo '<pre>';print_r($_FILES);exit;
                            $_FILES['picutes']['name'] =  $title_product .'.'.$image_ext;
                            
                            $y = $_FILES[$ce_img]['name'];
                            if ($y != '')
                            {
                                $file_upl_data = $this->upload_model->uploadfiles($ce_img, 'product_catelogue');
                                if ($file_upl_data['success'] == 1)
                                {
                                    $catelogue = $file_upl_data['file_name'];
                                    //echo '<pre>';print_r($catelogue);exit;
                                    $info = array('product_id' => $this->input->post('id'), 'catlogues_name' => $catelogue);
                                    $result = $this->common_model->insert_details('catelogues', $info);
                                    $status = array(
                                        'status' => 'success',
                                        'go_to' => 'buyer/products',
                                        'message' => 'Product updated successfully'
                                    );
                                    $this->session->set_flashdata('insert_record', $status);
                                    
                                }
                                else
                                {
                                   $status = array(
                                        'status' => 'fail',
                                        'message' => $file_upl_data['msg']
                                    );
                                    
                                }
                            }
                        $sno++; }
                        echo json_encode($status);exit;
                    }else{
                        $status = array(
                            'status' => 'success',
                            'go_to' => 'buyer/products',
                            'message' => 'Product updated successfully'
                        );
                        $this->session->set_flashdata('insert_record', $status);
                        echo json_encode($status);exit;
                    }
               }else{
                //echo '<pre>not ok';print_r($_FILES);exit;
                    $status = array(
                        'status' => 'fail',
                        'message' => 'Error while adding product details...'
                    );
                    echo json_encode($status);exit;
               }
            } else {
                $data['mode'] = 'create';
                $data['msg'] = '';
                $this->load->view('products/create_product', $data);
            }
        }
    }
    
    /**
    * get_states_list
    * Get States List
    * @author GOPI PANGULURI<gopi.panguluri@mindtechlabs.com>
    * @param type $data
    */
    public function get_states_list(){
        //echo '<pre>'; print_r($_POST);exit;
        $id = $this->input->post('id');
        $data['states'] = $this->products_model->get_states_list($id);
        if($data['states']){
            $data['status'] = 0;
        }else{
            $data['status'] = 1;
        }
        //echo '<pre>'; print_r($states);exit;
        echo json_encode($data);
    }
    
    /**
    * get_states_list
    * Get States List
    * @author GOPI PANGULURI<gopi.panguluri@mindtechlabs.com>
    * @param type $data
    */
    public function get_cities_list(){
        $id = $this->input->post('id');
        $data['states'] = $this->products_model->get_cities_list($id);
        if($data['states']){
            $data['status'] = 0;
        }else{
            $data['status'] = 1;
        }
        //echo '<pre>'; print_r($states);exit;
        echo json_encode($data);
    }
    
    /**
    * product_details
    * product Details
    * @author GOPI PANGULURI<gopi.panguluri@mindtechlabs.com>
    * @param type $data
    */
    public function product_details($id){       
        $data['product_cat'] = $this->common_functions_model->get_product_or_service_list('1');
        $data['service_cat'] = $this->common_functions_model->get_product_or_service_list('2');
        $data['mode'] = 'details';
        $data['msg'] = '';
        $info = array(
            'select_fields' => '',
            'where' => array(
                'product_id' => $id
            ),
            'tablename' => 'products'
        );
        $data['item_details'] = $this->common_model->get_individual_details($info);
        $info_catelog = array(
            'select_fields' => '',
            'where' => array(
                'product_id' => $data['item_details']['product_id']
            ),
            'tablename' => 'catelogues'
        );
        $data['catelogues'] = $this->common_model->get_list($info_catelog);
        //echo '<pre>';print_r($data);exit;
        $this->load->view('products/create_product', $data);
    } 
    
}