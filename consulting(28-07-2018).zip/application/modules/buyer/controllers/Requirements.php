<?php if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Requirements extends MX_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->lang->load('data');
        $this->load->model('common/upload_model');
        $this->load->model('common/common_model');
        $this->load->model('common/common_functions_model');
        $this->load->model('requirements_model');
        modules::run('admin/login/is_buyer_logged_in');
    }
    
    public function index()
    {
        $this->load->view('requirements/requirements');
    }
    
    /**
    * get_requirements_list
    * Get Photo requirement List
    * @author GOPI PANGULURI<gopi.panguluri@mindtechlabs.com>
    * @param type $data
    */
    public function get_requirements_list()
    {
        $result = $this->requirements_model->get_requirements_list();
        $aaData = array();
        foreach($result['aaData'] as $row){
            $row[0] = '<input type="checkbox" id="checkbox-1-' . intval($row[0]) . '" class="checkbox1 regular-checkbox" name="regular-checkbox"
                                value="' . $row[0] . '"/><label for="checkbox-1-' . intval($row[0]) . '"></label>';
            //$row[1] = '<img src="'.config_item('root_dir').'assets/images/catelogues/'.$row['1'].'" height="150" width="150" alt="Image"/>';
            //$row[3] = word_limiter($row[3], 30);
            //$row[3] = date('M,Y',strtotime($row[3]));
            
            //echo '<pre>'; print_r($item_details);exit;
            if($row[5]==1){
            $row[5] = '<div id="status' . $row[6] . '">
                    <a href="javascript:void(0);" class="show-tooltip" title="Change Status" onclick="changestatus(' . $row[6] . ', ' . $row[5] . ')" >
                            <i class="glyphicon glyphicon-remove"></i>
                    </a></div> ';   
            }else{
                $row[5] = '<div id="status' . $row[6] . '">
                        <a href="javascript:void(0);" class="show-tooltip" title="Change Status" onclick="changestatus(' . $row[6] . ', ' . $row[5] . ')" >
                                <i class="glyphicon glyphicon-ok"></i>
                        </a></div> ';
            }
                $row[6] = '<a href="'.base_url('buyer/requirements/create_requirement/'). $row[6] . '/details" title="View Record" data-toggle="tooltip">
                            <i class="fa_size fa fa-eye"></i></a>
                          <a href="'.base_url('buyer/requirements/create_requirement/'). $row[6] . '/edit" title="Edit Record" data-toggle="tooltip">
                                    <i class="fa_size fa fa-pencil" ></i></a>
                           <a href="javascript:void(0)" data-toggle="tooltip" id="' . $row[6] . '" class="deleteme show-tooltip deleteitem_' . $row[6] . '"" title="Delete Record" data-tablename="requirements" data-fieldname="r_id" url="'. site_url('buyer/delete_all_record') .'">
                                    <i class="fa_size fa fa-trash-o "></i></a>';
               //$row[7] = '<a href="'.base_url('buyer/requirements/requirement_details') ."/". $row[7] . '" title="View Record" data-toggle="tooltip">
//                            <i class="fa_size fa fa-eye"></i></a>
//                <a href="'.base_url('buyer/requirements/create_requirement')  ."/". $row[7] . '" title="Edit Record" data-toggle="tooltip">
//                                    <i class="fa_size fa fa-pencil" ></i></a>
//                           <a href="javascript:void(0)" data-toggle="tooltip" id="' . $row[7] . '" class="deleteme show-tooltip deleteitem_' . $row[7] . '"" title="Delete Record" data-tablename="requirements" data-fieldname="r_id" url="'. site_url('buyer/delete_all_record') .'">
//                                    <i class="fa_size fa fa-trash-o "></i></a>';
            //{
//                if($row[5]==0){
//                    $row[5] = '<span class="label bg-green">Active</span>';
//                }else{
//                    $row[5] = '<span class="label bg-red">Inactive</span>';
//                }
//                $row[6] = '<a href="'.base_url('buyer/requirements/requirement_details') ."/". $row[6] . '" title="View Record" data-toggle="tooltip">
//                            <i class="fa_size fa fa-eye"></i></a>';
//            }
            $aaData[] = $row;
        }
        $result['aaData'] = $aaData;
        //echo '<pre>'; print_r($result);exit;
        print_r(json_encode($result));
    }
    
   /**
    * create_news
    * Create News
    * @author GOPI PANGULURI<gopi.panguluri@mindtechlabs.com>
    * @param type $data
    */
    public function create_requirement($id = '',$mode = '') {
        //echo '<pre>';print_r($_FILES);
        //echo '<pre>';print_r($_POST);exit;
        //echo '<pre>';print_r($_SESSION);exit;
        $data['type_of_bid_process'] = $this->config->item('type_of_bid_process');
        //echo '<pre>';print_r($data);exit;
        $data['messures'] = $this->config->item('messures');
        $data['dis_addresses'] = $this->requirements_model->get_address_list($_SESSION['buyer_user_id'],'1');
        $data['bill_addresses'] = $this->requirements_model->get_address_list($_SESSION['buyer_user_id'],'2');
        $shortlist_list = $this->requirements_model->get_shortlist_list();
        //echo $this->db->last_query();exit;
        foreach($shortlist_list as $rowsl){
            $user = explode(',',$rowsl['users']);
            $user_pre_id = $_SESSION['buyer_type'].'-'.$_SESSION['buyer_user_id'];
            if(in_array($user_pre_id,$user)){
              $shortlist_list[] = $rowsl;  
            }
        }
        $st_list = array('0'=>'Select One');
        foreach($shortlist_list as $stls):
            $st_list[$stls['user_id']] = $stls['name'];
        endforeach;
        $data['shortlist_list'] = $st_list;
        //echo '<pre>';print_r($data);exit;
        $data['product_cat'] = $this->common_functions_model->get_product_or_service_list('1');
        $data['service_cat'] = $this->common_functions_model->get_product_or_service_list('2');
        $data['currency_types'] = $this->config->item('currency_types');
        $data['payment_terms'] = $this->config->item('payment_terms');
        if ($id != ''){
            $data['mode'] = $mode;
            $data['msg'] = '';
            $info = array(
                'select_fields' => '',
                'where' => array(
                    'r_id' => $id
                ),
                'tablename' => 'requirements'
            );
            //echo '<pre>';print_r($info);exit;
            $data['item_details'] = $this->common_model->get_individual_details($info);
            //echo '<pre>';print_r($data['item_details']);exit;
            $info_items = array(
                'select_fields' => '',
                'where' => array(
                    'r_id' => $id
                ),
                'tablename' => 'req_items'
            );
            $data['req_items'] = $this->common_model->get_list($info_items);
            
            $info_catelog = array(
                'select_fields' => '',
                'where' => array(
                    'r_id' => $id
                ),
                'tablename' => 'requirement_files'
            );
            $data['requirement_files'] = $this->common_model->get_list($info_catelog);
            //echo '<pre>';print_r($data);exit;
            $this->load->view('requirements/create_requirement', $data);
        } else {
            if(isset($_POST['submit'])&&$_POST['submit']=='insert'){
                $info = array(
                    //'r_name' => $this->input->post('r_name'),
                    //'r_type' => $this->input->post('r_type'),
                    'publish' => $this->input->post('publish'),
                    'tob_process' => $this->input->post('tob_process'),
                    'budget' => $this->input->post('budget'),
                    //'quantity' => $this->input->post('quantity'),
                    'payment_terms' => $this->input->post('payment_terms'),
                    'currency' => $this->input->post('currency'),
                    'enquire_time_from' => date('Y-m-d H:i:s',strtotime($this->input->post('enquire_time_from'))),
                    'enquire_time_to' => date('Y-m-d H:i:s',strtotime($this->input->post('enquire_time_to'))),
                    'dispach_time' => date('Y-m-d',strtotime($this->input->post('dispach_time'))),
                    'description' => $this->input->post('description'),
                    'selected_negotiation' => $this->input->post('selected_negotiation'),
                    'a_id' => $this->input->post('a_id'),
                    'bil_id' => $this->input->post('bil_id'),
                    'user_id' => $_SESSION['buyer_user_id']
                );
                //if($this->input->post('r_type')==1){
//                    $info['c_id'] = $this->input->post('c_id');
//                }else{
//                    $info['service_type'] = $this->input->post('service_type');
//                }
                //echo "<pre>";print_r($info);exit;
                //echo "<pre>";print_r($_POST);exit;
                $result_id = $this->requirements_model->insert_id_details('requirements', $info);
                //echo "<pre>";print_r($result_id);exit;
                if($result_id!=''){
                      $product_items = $_POST['items'];
                      foreach($product_items as $row_pro_items){
                            $info_items = array(
                                'r_i_name' => $row_pro_items['r_name'],
                                'r_type' => $row_pro_items['r_type'],
                                'r_id' => $result_id
                            );
                            
                            if($row_pro_items['r_type']==1){
                               $info_items['c_id'] = $row_pro_items['c_id'];
                               $info_items['r_i_messure'] = $row_pro_items['meassurement'];
                               $info_items['r_i_quantity'] = $row_pro_items['quantity'];
                            }else{
                               $info_items['service_type'] = $row_pro_items['service_type'];
                            }
                            //echo "<pre>";print_r($info_items);exit;
                            $result_items_id = $this->requirements_model->insert_id_details('req_items', $info_items);     
                      } 
                      if(isset($_FILES['files']['name'][0]) && $_FILES['files']['name'][0] != ''){
                        $certificate = '';
                        $files = $_FILES;
                        $pics_count = count($_FILES['files']['name']);
                        //echo "<pre>";print_r($pics_count);exit;
                        $sno=0;
                        for($i = 0; $i < $pics_count; $i++){
                            $_FILES['picutes']['name'] = $files['files']['name'][$sno];
                            $_FILES['picutes']['tmp_name'] = $files['files']['tmp_name'][$sno];
                            $_FILES['picutes']['type'] = $files['files']['type'][$sno];
                            $_FILES['picutes']['error'] = $files['files']['error'][$sno];
                            $_FILES['picutes']['size'] = $files['files']['size'][$sno];
                            $ce_img = 'picutes';
                            
                            $string1 = str_replace(' ', '-', 'requirement'); // Replaces all spaces with hyphens.
                            $string1 = preg_replace('/[^A-Za-z0-9\-]/', '', $string1); // Removes special chars.
                            $random_string = random_string('alnum', 16);
                            $title_product = $string1.'-files-'.$random_string;
                            $image_ext = explode(".",$_FILES['picutes']['name']);
                            $image_ext = end($image_ext);
                            //echo '<pre>';print_r($_FILES);exit;
                            $_FILES['picutes']['name'] =  $title_product .'.'.$image_ext;
                            
                            $y = $_FILES[$ce_img]['name'];
                            if ($y != '')
                            {
                                $file_upl_data = $this->upload_model->uploadfiles($ce_img, 'requirement_files');
                                if ($file_upl_data['success'] == 1)
                                {
                                    $requirement_files = $file_upl_data['file_name'];
                                    //echo '<pre>';print_r($requirement_files);exit;
                                    $info = array('r_id' => $result_id, 'rf_name' => $requirement_files);
                                    $result = $this->common_model->insert_details('requirement_files', $info);
                                    $status = array(
                                        'status' => 'success',
                                        'go_to' => 'buyer/requirements',
                                        'message' => 'Requirement added successfully'
                                    );
                                    $this->session->set_flashdata('insert_record', $status);
                                }
                                else
                                {
                                   $status = array(
                                        'status' => 'fail',
                                        'message' => $file_upl_data['msg']
                                    );
                                }
                            }
                        $sno++; }
                        //echo '<pre>';print_r($requirement_files);exit;
                        echo json_encode($status);exit;
                    }else{
                        $status = array(
                            'status' => 'success',
                            'go_to' => 'buyer/requirements',
                            'message' => 'Requirement added successfully'
                        );
                        $this->session->set_flashdata('insert_record', $status);
                        echo json_encode($status);exit;
                    }
               }else{
                    $status = array(
                        'status' => 'fail',
                        'message' => 'Error while adding requirement details...'
                    );
                    echo json_encode($status);exit;
               }
            } if(isset($_POST['submit'])&&$_POST['submit']=='update') {
                $info1 = array(
                    'publish' => $this->input->post('publish'),
                    'tob_process' => $this->input->post('tob_process'),
                    'budget' => $this->input->post('budget'),
                    'payment_terms' => $this->input->post('payment_terms'),
                    'currency' => $this->input->post('currency'),
                    'enquire_time_from' => date('Y-m-d H:i:s',strtotime($this->input->post('enquire_time_from'))),
                    'enquire_time_to' => date('Y-m-d H:i:s',strtotime($this->input->post('enquire_time_to'))),
                    'dispach_time' => date('Y-m-d',strtotime($this->input->post('dispach_time'))),
                    'a_id' => $this->input->post('a_id'),
                    'bil_id' => $this->input->post('bil_id'),
                    'description' => $this->input->post('description'),
                    'selected_negotiation' => $this->input->post('selected_negotiation'),
                    'user_id' => $_SESSION['buyer_user_id']
                );
                //if($this->input->post('r_type')==1){
//                    $info1['c_id'] = $this->input->post('c_id');
//                }else{
//                    $info1['service_type'] = $this->input->post('service_type');
//                }
                $info = array(
                    'where' => array(
                        'r_id' => $this->input->post('id')
                    ),
                    'data' => $info1,
                    'tablename' => 'requirements'
                );
                //echo "<pre>";print_r($info);exit;
                $result = $this->common_model->update_details($info);
                if($this->input->post('id')!=''&&$result){
                      $product_items = $_POST['items'];
                      foreach($product_items as $row_pro_items){
                            if(isset($row_pro_items['r_i_id'])&&$row_pro_items['r_i_id']!=''&&$row_pro_items['r_i_id']!='undefined'){
                                $info_items_update = array(
                                    'r_i_name' => $row_pro_items['r_name'],
                                    'r_type' => $row_pro_items['r_type']
                                );
                                
                                if($row_pro_items['r_type']==1){
                                   $info_items_update['c_id'] = $row_pro_items['c_id'];
                                   $info_items_update['r_i_messure'] = $row_pro_items['meassurement'];
                                   $info_items_update['r_i_quantity'] = $row_pro_items['quantity'];
                                }else{
                                   $info_items_update['service_type'] = $row_pro_items['service_type'];
                                }
                                
                                $info_items_up = array(
                                    'where' => array(
                                        'r_i_id' => $row_pro_items['r_i_id']
                                    ),
                                    'data' => $info_items_update,
                                    'tablename' => 'req_items'
                                );
                                //echo "<pre>";print_r($info_items_up);exit;
                                $result = $this->common_model->update_details($info_items_up);
                            } else {
                                $info_items = array(
                                    'r_i_name' => $row_pro_items['r_name'],
                                    'r_type' => $row_pro_items['r_type'],
                                    'r_id' => $this->input->post('id')
                                );
                                
                                if($row_pro_items['r_type']==1){
                                   $info_items['c_id'] = $row_pro_items['c_id'];
                                   $info_items['r_i_messure'] = $row_pro_items['meassurement'];
                                   $info_items['r_i_quantity'] = $row_pro_items['quantity'];
                                }else{
                                   $info_items['service_type'] = $row_pro_items['service_type'];
                                }
                                //echo "<pre>";print_r($info_items);exit;
                                $result_items_id = $this->requirements_model->insert_id_details('req_items', $info_items);
                            }     
                      }
                      if(isset($_FILES['files']['name'][0]) && $_FILES['files']['name'][0] != ''){
                        $certificate = '';
                        $files = $_FILES;
                        $pics_count = count($_FILES['files']['name']);
                        //echo "<pre>";print_r($pics_count);exit;
                        $sno=0;
                        for($i = 0; $i < $pics_count; $i++){
                            $_FILES['picutes']['name'] = $files['files']['name'][$sno];
                            $_FILES['picutes']['tmp_name'] = $files['files']['tmp_name'][$sno];
                            $_FILES['picutes']['type'] = $files['files']['type'][$sno];
                            $_FILES['picutes']['error'] = $files['files']['error'][$sno];
                            $_FILES['picutes']['size'] = $files['files']['size'][$sno];
                            $ce_img = 'picutes';
                            
                            $string1 = str_replace(' ', '-', 'requirement'); // Replaces all spaces with hyphens.
                            $string1 = preg_replace('/[^A-Za-z0-9\-]/', '', $string1); // Removes special chars.
                            $random_string = random_string('alnum', 16);
                            $title_product = $string1.'-files-'.$random_string;
                            $image_ext = explode(".",$_FILES['picutes']['name']);
                            $image_ext = end($image_ext);
                            //echo '<pre>';print_r($_FILES);exit;
                            $_FILES['picutes']['name'] =  $title_product .'.'.$image_ext;
                            
                            $y = $_FILES[$ce_img]['name'];
                            if ($y != '')
                            {
                                $file_upl_data = $this->upload_model->uploadfiles($ce_img, 'requirement_files');
                                if ($file_upl_data['success'] == 1)
                                {
                                    $requirement_files = $file_upl_data['file_name'];
                                    //echo '<pre>';print_r($requirement_files);exit;
                                    $info = array('r_id' => $this->input->post('id'), 'rf_name' => $requirement_files);
                                    $result = $this->common_model->insert_details('requirement_files', $info);
                                    $status = array(
                                        'status' => 'success',
                                        'go_to' => 'buyer/requirements',
                                        'message' => 'Requirement updated successfully'
                                    );
                                    $this->session->set_flashdata('insert_record', $status);
                                }
                                else
                                {
                                   $status = array(
                                        'status' => 'fail',
                                        'message' => $file_upl_data['msg']
                                    );
                                    
                                }
                            }
                        $sno++; }
                        echo json_encode($status);exit;
                    }else{
                        $status = array(
                            'status' => 'success',
                            'go_to' => 'buyer/requirements',
                            'message' => 'Requirement updated successfully'
                        );
                        $this->session->set_flashdata('insert_record', $status);
                        echo json_encode($status);exit;
                    }
               }else{
                //echo '<pre>not ok';print_r($_FILES);exit;
                    $status = array(
                        'status' => 'fail',
                        'message' => 'Error while adding requirement details...'
                    );
                    echo json_encode($status);exit;
               }
            } else {
                $data['mode'] = 'create';
                $data['msg'] = '';
                $this->load->view('requirements/create_requirement', $data);
            }
        }
    }
    
    /**
    * requirement_details
    * requirement Details
    * @author GOPI PANGULURI<gopi.panguluri@mindtechlabs.com>
    * @param type $data
    */
    public function requirement_details($id){
        $data['service_cat'] = array(''=>'Select one','1'=>'Electrician','2'=>'Painter','4'=>'AC Repair','5'=>'Carpenter','6'=>'Full home cleaning','7'=>'Plumber');
        $data['requirement_cat'] = array(''=>'Select one','1'=>'TMT Steels','2'=>'Cement','3'=>'Agri Commodities','4'=>'Gold','5'=>'Sugar Domestic');
        $data['mode'] = 'details';
        $data['msg'] = '';
        $info = array(
            'select_fields' => '',
            'where' => array(
                'r_id' => $id
            ),
            'tablename' => 'requirements'
        );
        $data['item_details'] = $this->common_model->get_individual_details($info);
        //echo '<pre>';print_r($data);exit;
        $this->load->view('requirements/create_requirement', $data);
    }
    
    public function change_status_to_bidding(){
        //echo '<pre>'; print_r($_POST);exit;
        $info = array(
            'select_fields' => '',
            'where' => array(
                'r_id' => $_POST['r_id']
            ),
            'tablename' => 'requirements'
        );
        $item_details = $this->common_model->get_individual_details($info);
        if($item_details['publish']==1){
            $info_users = array(
                'select_fields' => '',
                'where' => array(
                    'user_id !=' => '1',
                    'type' => '1'
                ),
                'tablename' => 'users'
            );
            $users_detail = $this->common_model->get_list($info_users);
            foreach($users_detail as $rw_users){
                $users[] = $rw_users['user_id'];
            }
            //echo '<pre>'; print_r($users_detail);exit;
        }else{
            $users = explode(',',$item_details['selected_negotiation']);
        }
        //echo '<pre>'; print_r($users);exit;
        foreach($users as $row_sel_sellers){
            //echo $row_sel_sellers;exit;
            $info_bid = array(
                    'user_id' => $row_sel_sellers,
                    'negotiation' => 'N',
                    'selected' => 'N',
                    'negotiation_round' => 0, 
                    'r_id' => $_POST['r_id']
                   );
            $result = $this->common_model->insert_details('project_bidding', $info_bid);
            $info_msg = array(
                    'user_id' => $row_sel_sellers,
                    'r_id' => $_POST['r_id'],
                    'notification_text' => $_POST['notifi_text'], 
                    'notification_type' => 'N'
            );
            $result_nft = $this->common_model->insert_details('notifications', $info_msg);
        }
        $this->load->model('common/common_model');
        $info_up = array(
            'where' => array(
                'r_id' => $_POST['r_id']
            ),
            'data' => array(
                'add_to_bidding' => '1',
            ),
            'tablename' => 'requirements'
        );
        //echo '<pre>'; print_r($info_up);exit;
        $result = $this->common_model->update_details($info_up);
        //echo '<pre>'; print_r($result);exit;
        //echo $this->db->last_query();exit;
        if($result){
            echo "1";
        }else{
            echo "0";
        }
    } 
    
}