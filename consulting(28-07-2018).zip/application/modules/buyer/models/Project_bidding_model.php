<?php

class Project_bidding_model extends CI_Model {
        
    /**
     * get_reg_users()
     * get the registered users list
     * @author GOPI PANGULURI<gopi.panguluri@mindtechlabs.com>
     */
    public function get_project_bidding_list() {
        $tableName = 'requirements';
        $tableName1 = 'pro_service_types';
        $tableName2 = 'users';
        $columns   = array("$tableName.r_id",
                           "$tableName.description",
                           "$tableName.added_date",
                           "$tableName.enquire_time_from",
                           "$tableName.enquire_time_to",
                           "$tableName.r_id"
                          );
        $indexId     = '$tableName.r_id';
        $columnOrder = "$tableName.r_id";
        $orderby     = "";
        $joinMe      = "left join $tableName2 on $tableName2.user_id=$tableName.user_id";
        $condition   = " WHERE $tableName.user_id= '".$_SESSION['buyer_user_id']."' AND $tableName.status='". 0 ."' AND $tableName.add_to_bidding='". 1 ."'";
        //$condition   = " WHERE $tableName.r_id!= '' AND $tableName.sc_id= '".$_SESSION['admin_user_id']."' ";
        return $this->db->drawdatatable($tableName, $columns, $indexId, $joinMe, $condition, $orderby);
    }
    
    /**
     * get_parents_list()
     * get Parents List
     * @author GOPI PANGULURI<gopi.panguluri@mindtechlabs.com>
     */
    public function get_parents_list() {
        $this->db->select('*');
        $this->db->from('parents');
        $this->db->order_by('parent_name','ASC');
        $res = $this->db->get()->result_array();
        $country_list = array(''=>'Select One');
        foreach($res as $country):
            $country_list[$country['parent_id']] = $country['parent_name'];
        endforeach;
        //echo '<pre>'; print_r($country_list);exit;
        return $country_list;
    }
    
    /**
     * get_schools_list()
     * get Schools List
     * @author GOPI PANGULURI<gopi.panguluri@mindtechlabs.com>
     */
    public function get_schools_list($id='') {
        $this->db->select('*');
        $this->db->from('schools');
        if($id!=''){
            $this->db->where('sc_id',$id);
        }
        $this->db->order_by('name','ASC');
        $res = $this->db->get()->result_array();
        $school_list = array(''=>'Select One');
        foreach($res as $school):
            $school_list[$school['sc_id']] = $school['name'];
        endforeach;
        //echo '<pre>'; print_r($school_list);exit;
        return $school_list;
    }
    
    /**
     * get_subjects_list()
     * get Subjects List
     * @author GOPI PANGULURI<gopi.panguluri@mindtechlabs.com>
     */
    public function get_subjects_list($id='') {
        $this->db->select('*');
        $this->db->from('subjects');
        if($id!=''){
            $this->db->where('sub_id',$id);
        }
        $this->db->order_by('sub_name','ASC');
        $this->db->join('classes', 'subjects.cl_id = classes.cl_id');
        $res = $this->db->get()->result_array();
        //echo '<pre>'; print_r($res);exit;
        $school_list = array(''=>'Select One');
        foreach($res as $school):
            $school_list[$school['sub_id']] = $school['cl_name'].'-'.$school['sub_name'];
        endforeach;
        //echo '<pre>'; print_r($school_list);exit;
        return $school_list;
    }
    
    /**
     * get_classes_list()
     * get Classes List
     * @author GOPI PANGULURI<gopi.panguluri@mindtechlabs.com>
     */
    public function get_classes_list($id='') {
        $this->db->select('*');
        $this->db->from('sections');
        if($id!=''){
            $this->db->where('sec_id',$id);
        }
        $this->db->order_by('cl_name','ASC');
        $this->db->join('classes', 'sections.cl_id = classes.cl_id');
        $res = $this->db->get()->result_array();
        //echo '<pre>'; print_r($res);exit;
        $school_list = array(''=>'Select One');
        foreach($res as $school):
            $school_list[$school['sec_id']] = $school['cl_name'].'-'.$school['sec_name'];
        endforeach;
        //echo '<pre>'; print_r($school_list);exit;
        return $school_list;
    }
    
    /**
     * get_address_list()
     * get Address List
     * @author GOPI PANGULURI<gopi.panguluri@mindtechlabs.com>
     */
    public function get_address_list($id='') {
        $this->db->select('address.*,countries.name as c_name,states.state_name,cities.city_name');
        $this->db->from('address');
        if($id!=''){
            $this->db->where('user_id',$id);
        }
        $this->db->order_by('a_name','ASC');
        $this->db->order_by('user_id',$_SESSION['buyer_user_id']);
        $this->db->join('countries', 'address.a_country = countries.id');
        $this->db->join('states', 'address.a_state = states.state_id');
        $this->db->join('cities', 'address.a_city = cities.city_id');
        $res = $this->db->get()->result_array();
        //echo '<pre>'; print_r($res);exit;
        $address_list = array(''=>'Select One');
        foreach($res as $address):
            $address_list[$address['a_id']] = $address['a_name'].'-'.$address['a_address_line'].'-'.$address['a_pincode'].'-'.$address['city_name'].'-'.$address['state_name'].'-'.$address['c_name'];
        endforeach;
        //echo '<pre>'; print_r($address_list);exit;
        return $address_list;
    }
    
    /**
     * insert_id_details
     * Insert Id Details
     * @author GOPI PANGULURI<gopi.panguluri@mindtechlabs.com>
     * @param type $data
     */
    public function insert_id_details($table_name, $data) {
        $result = $this->db->insert($table_name, $data);
        return $this->db->insert_id();
    }
	
	/**
     * update_techer_details
     * @param type $data
     * @author GOPI PANGULURI<gopi.panguluri@mindtechlabs.com>
     * @return type
     */
    public function update_techer_details($data) {		
        $this->db->where($data['where']);
        $result = $this->db->update($data['tablename'], $data['data']);		
        return $this->db->insert_id();
    }
    
	
	/**
     * get_project_bidding_list
     * @param type $data
     * @author GOPI PANGULURI<gopi.panguluri@mindtechlabs.com>
     * @return type
     */
    public function get_project_bids_list($id=''){
        $this->db->select('project_bidding.*,users.name,users.user_id,users.image');
        $this->db->from('project_bidding');
        if($id!=''){
            $this->db->where('project_bidding.r_id',$id);
        }
        //$this->db->where('project_bidding.user_id',$id);
        $this->db->where('project_bidding.negotiation','Y');
        $this->db->order_by('added_date','ASC');
        //$this->db->group_by('negotiation_round');
        $this->db->join('users', 'project_bidding.user_id = users.user_id');
        //$this->db->join('project_bidding_files', 'project_bidding.pb_id = project_bidding_files.pb_id');
        //$this->db->join('project_bidding_items', 'project_bidding.pb_id = project_bidding_items.pb_id');
        //$this->db->join('project_bidding_taxes', 'project_bidding.pb_id = users.user_id');
        $res = $this->db->get()->result_array();
        //echo $this->db->last_query();
        //echo '<pre>'; print_r($res);exit;
        return $res;
    }
	
	/**
     * get_project_bidding_files_list
     * @param type $data
     * @author GOPI PANGULURI<gopi.panguluri@mindtechlabs.com>
     * @return type
     */
    public function get_project_bidding_files_list($id){
        $this->db->select('');
        $this->db->from('project_bidding_files');
        $this->db->where('pb_id',$id);
        $this->db->order_by('added_date','ASC');
        $res = $this->db->get()->result_array();
        //echo '<pre>'; print_r($res);exit;
        return $res;
    }
	
	/**
     * get_project_bidding_items_list
     * @param type $data
     * @author GOPI PANGULURI<gopi.panguluri@mindtechlabs.com>
     * @return type
     */
    public function get_project_bidding_items_list($id){
        $this->db->select('req_items.*,project_bidding_items.price,project_bidding_items.quantity');
        $this->db->from('project_bidding_items');
        $this->db->where('pb_id',$id);
        $this->db->order_by('project_bidding_items.added_date','ASC');
        $this->db->join('req_items', 'project_bidding_items.r_i_id = req_items.r_i_id');
        $res = $this->db->get()->result_array();
        //echo '<pre>'; print_r($res);exit;
        return $res;
    }
	
	/**
     * get_project_bidding_taxes_list
     * @param type $data
     * @author GOPI PANGULURI<gopi.panguluri@mindtechlabs.com>
     * @return type
     */
    public function get_project_bidding_taxes_list($id){
        $this->db->select('');
        $this->db->from('project_bidding_taxes');
        $this->db->where('pb_id',$id);
        $this->db->order_by('added_date','ASC');
        $res = $this->db->get()->result_array();
        //echo '<pre>'; print_r($res);exit;
        return $res;
    }
    
	
	/**
     * get_shortlist_list
     * @param type $data
     * @author GOPI PANGULURI<gopi.panguluri@mindtechlabs.com>
     * @return type
     */
    public function get_shortlist_list($where){
        $result = $this->db->query("SELECT * FROM users WHERE user_id IN($where)")->result_array();
        //echo '<pre>'; print_r($result);exit;
        return $result;
    }
    
}

?>