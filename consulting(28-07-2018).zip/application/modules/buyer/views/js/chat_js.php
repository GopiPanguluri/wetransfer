<script type="">
    $(document).ready(function() {
    $.validator.setDefaults({
            //ignore: []
    });
    $("#customer_form").validate({
        rules: {
            message: {
                required: true,
                minlength:1
            }
        },
        
        messages: {				
           message:{					
                required: "Message should not leave empty."
           }
        },
        submitHandler: function(form,event){
        event.preventDefault();// using this page stop being refreshing
        var formData = new FormData();
        if($('#files')[0].files!==''){
            jQuery.each(jQuery('#files')[0].files, function(i, file) {
                formData.append('files[]', file);
            });
        }
        //alert($('#type:checked').val());
        //return false;
        formData.append('message', $('#message').val());
        formData.append('nm_id', $('#nm_id').val());
        $.ajax({
            url: form.action,
            type: form.method,
            async: false,
            cache: false,
            contentType: false,
            enctype: 'multipart/form-data',
            processData: false,
            dataType: "json",
            //data: $(form).serialize(),
            data: formData,
            success: function(res) {
                if(res.status=='success'){
                    $('#customer_form').trigger('reset');
                }else{
                    bootbox.alert('Something went wrong!');
                }
            }            
        });
    }
    });
    });
    
    function Load_external_content()
    {
          var id = $('#nm_id').val();
          var formData = new FormData();
          formData.append('nm_id', id);
          var data;
          Pace.ignore(function(){
          $.ajax({
            url: BASE_URL + 'buyer/negotiations_list/get_messages_load_list',
            type: "POST",
            async: false,
            cache: false,
            contentType: false,
            enctype: 'multipart/form-data',
            processData: false,
            dataType: "json",
            //data: $(form).serialize(),
            data: formData,
            success: function(res) {
                if(res.status=='success'){
                    $('.chat_list').html(res.message);
                }else{
                    //bootbox.alert('sdfsdkjfh');
                }
            }            
        })
        });
    }
    
    function scrollToBottom(){
       $('.fix_scroll').scrollTop(1E10);
    }
    
    setInterval('Load_external_content()', 1000);
    //setInterval('scrollToBottom()', 5000);
    $(window).on("load",Load_external_content);
    $(window).on("load",scrollToBottom);
         
</script>