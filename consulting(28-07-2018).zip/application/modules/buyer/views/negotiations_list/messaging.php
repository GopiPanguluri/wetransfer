<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <?php $this->load->view('common/common/css'); ?>
  <link rel="stylesheet" href="<?php echo config_item('ui_base_path') ?>plugins/bootstrap-select/bootstrap-select.min.css"/>
</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">
  <?php $this->load->view('common/buyer-top_nav') ?>
  <?php $this->load->view('common/buyer-left_nav') ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1> Negotiation Details </h1>
        <ol class="breadcrumb">
            <li><a href="<?php echo site_url('buyer/dashboard'); ?>"><i class="fa fa-dashboard"></i> Home </a></li>
            <li><a href="<?php echo site_url('buyer/negotiations_list'); ?>"><i class="fa fa-check"></i> Negotiation List </a></li>
            <li class="active"> Negotiation Details </li>
        </ol>
     </section>
    <!-- Main content -->
    <input type="hidden" id="page" value="nav-negotiation_list"/>    
    <section class="content">
        <div class="box box-primary">
          <div class="panel-body">
            <?php
                $success_message = $this->session->flashdata('insert_record');
                if ($success_message['status'] == "success") {
                    echo '<p class="alert alert-success sas-succcess-message">' . $success_message['message'] . '</p><div class="clearfix"></div>';
                } else if ($success_message['status'] == "fail") {
                    echo '<p class="alert alert-danger sas-succcess-message">' . $success_message['message'] . '</p><div class="clearfix"></div>';
                }
            ?>
            <div class="error_msg alert alert-danger alert-dismissible"></div>
            <div class="info_msg alert alert-success alert-dismissible"></div>
            <div class="panel-body">
                <div class="error_msg alert alert-danger alert-dismissible"></div>
                <div class="info_msg alert alert-success alert-dismissible"></div>
                    <?php echo form_open_multipart('#', array('class' => 'form-horizontal')); ?>
                    <div class="box-header with-border">
                        <a href="<?php echo site_url('buyer/negotiations_list') ?>" class="btn btn-primary pull-left">Back</a>
                        <a href="javascript:void(0)" onclick="location.reload();" data-toggle="tooltip" class="btn btn-info btn-background pull-right" title="Reload Page"><i class="fa fa-refresh"></i></a>
                    </div>
                    <h3>Products</h3>
                    <hr />
                    <div class="pro_items_list">
                        <?php $i=1; foreach($req_items as $row){ ?>
                            <div class="list_<?php echo $i; ?> items_divs existed_item">
                                <div class="form-group">
                                    <label class="col-md-2"><?php echo $i; ?>. Name </label>
                                    <div class="col-md-4">
                                        <?php echo $row['r_i_name']; ?>
                                    </div>
                                    <label class="col-md-2"> Type </label>
                                    <div class="col-md-4 r_type_val" attr_val="<?php echo $i; ?>">
                                        <?php if($row['r_type']==1){ echo 'Product';}else{ echo 'Service';} ?>
                                    </div>  
                                </div>
                                <div class="service_col_<?php echo $i; ?> <?php if($row['r_type']!=2){ echo 'no_display_col'; } ?>" attr_val="<?php echo $i; ?>">
                                    <div class="form-group">
                                      <label class="col-md-2"> Service type </label>
                                      <div class="col-md-4">
                                            <?php echo $service_cat[$row['service_type']]; ?>
                                      </div>
                                    </div>
                                </div>
                                <div class="requirement_col_<?php echo $i; ?> <?php if($row['r_type']!=1){ echo 'no_display_col'; } ?>" attr_val="<?php echo $i; ?>">
                                   <div class="form-group">
                                        <label class="col-md-2"> Category </label>
                                        <div class="col-md-4">
                                            <?php echo $product_cat[$row['c_id']]; ?>
                                        </div>
                                        <label class="col-md-2"> Measurement </label>
                                        <div class="col-md-4">
                                            <?php echo $messures[$row['r_i_messure']]; ?>
                                        </div>
                                  </div>
                                  <div class="form-group">
                                        <label class="col-md-2"> Quantity </label>
                                        <div class="col-md-4">
                                            <?php echo $row['r_i_quantity']; ?>
                                        </div>
                                  </div>
                                </div>
                           </div>
                       <?php $i++; } ?>
                    </div>
                    <hr />
                    <h3>Details</h3>
                    <hr />
                    <div class="form-group">
                        <label class="col-md-2"> Payment terms </label>
                        <div class="col-md-4">
                            <?php //echo '<pre>';print_r($payment_terms);exit; 
                            echo $payment_terms[$item_details['payment_terms']]; ?>
                        </div>
                        <label class="col-md-2"> Publish </label>
                        <div class="col-md-4">
                            <?php if($item_details['publish']==1){ echo 'Public';}else{ echo 'Private';} ?>
                        </div>
                    </div>
                    <div class="select_neg_col <?php if($item_details['publish']!=2){ echo 'no_display_col'; } ?>">
                        <div class="form-group">
                            <label class="col-md-2"> Shortlisted sellers </label>
                            <div class="col-md-4">
                                <?php $shortlist_list; $ids = explode(',',$item_details['selected_negotiation']); 
                                  foreach($ids as $key=>$rw_ids):
                                    $id_rws[] = $shortlist_list[$rw_ids];
                                  endforeach;
                                  $id_rws = implode(',',$id_rws);
                                  echo $id_rws; ?>
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-md-2"> Currency </label>
                        <div class="col-md-4">
                            <?php echo $currency_types[$item_details['currency']]; ?>
                        </div>
                        <label class="col-md-2"> Date of Dispatch </label>
                        <div class="col-md-4">
                            <?php echo $item_details['dispach_time']; ?>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-md-2"> Bidding start on </label>
                        <div class="col-md-4">
                            <?php echo date('Y-m-d h:i a',strtotime($item_details['enquire_time_from'])); ?>
                            <input id="enquire_time_from" value="<?php echo date('M d, Y H:i:s',strtotime($item_details['enquire_time_from'])); ?>" type="hidden"/>
                        </div>
                        <label class="col-md-2"> Bidding end on </label>
                        <div class="col-md-4">
                            <?php echo date('Y-m-d h:i a',strtotime($item_details['enquire_time_to'])); ?>
                            <input id="enquire_time_to" value="<?php echo date('M d, Y H:i:s',strtotime($item_details['enquire_time_to'])); ?>" type="hidden"/>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-md-2"> Dispatch Address </label>
                        <div class="col-md-10">
                            <?php echo $addresses[$item_details['a_id']]; ?>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-md-2"> View files </label>
                        <div class="col-md-10">
                               <?php if(count($requirement_files)!=0){ $sno=1; foreach($requirement_files as $row):?>
                                    <div class="border_files col-md-3 text-center" style="margin: 10px;"> 
                                      <span class=""> <a target="_blank" href="<?php echo config_item('root_dir').'assets/images/requirement_files/'.$row['rf_name']; ?>"> <i>Click here to see</i> file - <?php echo $sno; ?> </a> </span> 
                                    </div>
                                <?php $sno++; endforeach; }else{ ?>
                                    <a class="" href="javascript:void(0)"> No Certificates </a>
                                <?php } ?>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-md-2"> Description </label>
                        <div class="col-md-10">
                            <?php echo $item_details['description']; ?>
                        </div>
                    </div>
                </div>
                <?php echo form_close(); ?>
                <div class="box-body">
                  <!-- Conversations are loaded here -->
                  <div class="direct-chat-messages fix_scroll">
                        <div class="chat_list"></div>
                  </div>
                </div>
                
                <?php echo form_open_multipart('buyer/negotiations_list/send_message', array('id' => 'customer_form', 'class' => 'form-inline pull-right')); ?> 
                <div class="box-footer">
                    <!--div class="input-group">
                      <input type="text" name="message" placeholder="Type Message ..." class="form-control"/>
                          <span class="input-group-btn">
                            <button type="button" class="btn btn-warning btn-flat">Send</button>
                          </span>
                    </div-->
                    <div class="row inputs_row">
                        <div class="form-group">
                            <textarea name="message" id="message" class="form-control input-feilds_send" placeholder="Type Message ..."></textarea>
                            <input type="hidden" name="nm_id" id="nm_id" value="<?php echo $negotiation_member['nm_id']; ?>"/>
                        </div>
                        <div class="form-group">
                            <input type="file" name="files" class="form-control" id="files" multiple=""/>
                            <button type="submit" class="btn btn-warning btn-flat">Submit</button>
                        </div>
                        <label id="message-error" class="error" for="message"></label>
                    </div>
                </div>
                <?php echo form_close(); ?>
          </div>            
        </div>
      </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <!-- Control Sidebar -->
  <?php $this->load->view('common/common/footer'); ?>
  <!-- Add the sidebar's background. This div must be placed
       immediately after the control sidebar -->
  <div class="control-sidebar-bg"></div>
</div>
<!-- ./wrapper -->

<?php $this->load->view('common/common/js') ?>
<script src="<?php echo config_item('ui_base_path') ?>custom/js/jquery.validate.min.js"></script>
<script src="<?php echo config_item('ui_base_path') ?>plugins/bootstrap-select/bootstrap-select.min.js"></script>
<?php $this->load->view('buyer/js/chat_js'); ?>

</body>
</html>