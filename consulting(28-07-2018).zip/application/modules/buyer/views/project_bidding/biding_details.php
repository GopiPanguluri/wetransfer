<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <?php $this->load->view('common/common/css'); ?>
  <link rel="stylesheet" href="<?php echo config_item('ui_base_path') ?>plugins/bootstrap-select/bootstrap-select.min.css"/>
  <link rel='stylesheet prefetch' href='<?php echo config_item('ui_base_path') ?>custom/css/bootstrap-datetimepicker.min.css'/>
  <style>
    .no_display_col,.negotiation_form_div{
        display: none;
    }
    .bidding-anchor{
        color: #3c8dbc;
        margin: 150px;
        font-size: xx-large;
    }
    .bidding-profile{
        border: unset;
    }
    #form_bidding{
        margin: 50px;
    }
  </style>
</head>
<body class="hold-transition skin-blue sidebar-mini">
    <div class="wrapper">
      <?php $this->load->view('common/buyer-top_nav') ?>
      <?php $this->load->view('common/buyer-left_nav') ?>
      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <h1> Details of project bidding </h1>
            <ol class="breadcrumb">
                <li><a href="<?php echo site_url('buyer'); ?>"><i class="fa fa-dashboard"></i> Home </a></li>
                <li><a href="<?php echo site_url('buyer/requirements'); ?>"><i class="fa fa-university"></i> Project biddings </a></li>
                <li class="active"> Details of project bidding </li>
            </ol>
          </section>
    
        <!-- Main content -->
        <input type="hidden" id="page" value="nav-bidding"/>    
        <section class="content">
            <div class="box box-primary">
              <div class="panel-body">
                <?php
                    $success_message = $this->session->flashdata('insert_record');
                    if ($success_message['status'] == "success") {
                        echo '<p class="alert alert-success sas-succcess-message">' . $success_message['message'] . '</p><div class="clearfix"></div>';
                    } else if ($success_message['status'] == "fail") {
                        echo '<p class="alert alert-danger sas-succcess-message">' . $success_message['message'] . '</p><div class="clearfix"></div>';
                    }
                    echo '<div class="response_alert"></div>';
                ?>
                <div class="error_msg alert alert-danger alert-dismissible"></div>
                <div class="info_msg alert alert-success alert-dismissible"></div>
                <?php
                    echo form_open_multipart('buyer/requirements/create_requirement', array('id' => 'customer_form', 'class' => 'form-horizontal'));
                    
                ?>  
                    <div class="box-header with-border">
                        <a href="<?php echo site_url('buyer/project_bidding') ?>" class="btn btn-primary pull-left">Back</a>
                        <a class="pull-center bidding-anchor" style="color: #3c8dbc;"><span id="demo"></span></a>
                        <a href="javascript:void(0)" onclick="location.reload();" data-toggle="tooltip" class="btn btn-info btn-background pull-right" title="Reload Page"><i class="fa fa-refresh"></i></a>
                    </div>
                    <h3>Products</h3>
                    <hr />
                    <div class="pro_items_list">
                        <?php $i=1; foreach($req_items as $row){ ?>
                            <div class="list_<?php echo $i; ?> items_divs existed_item">
                                <div class="form-group">
                                    <label class="col-md-2"><?php echo $i; ?>. Name </label>
                                    <div class="col-md-4">
                                        <?php echo $row['r_i_name']; ?>
                                    </div>
                                    <label class="col-md-2"> Type </label>
                                    <div class="col-md-4 r_type_val" attr_val="<?php echo $i; ?>">
                                        <?php if($row['r_type']==1){ echo 'Product';}else{ echo 'Service';} ?>
                                    </div>  
                                </div>
                                <div class="service_col_<?php echo $i; ?> <?php if($row['r_type']!=2){ echo 'no_display_col'; } ?>" attr_val="<?php echo $i; ?>">
                                    <div class="form-group">
                                      <label class="col-md-2"> Service type </label>
                                      <div class="col-md-4">
                                            <?php echo $service_cat[$row['service_type']]; ?>
                                      </div>
                                    </div>
                                </div>
                                <div class="requirement_col_<?php echo $i; ?> <?php if($row['r_type']!=1){ echo 'no_display_col'; } ?>" attr_val="<?php echo $i; ?>">
                                   <div class="form-group">
                                        <label class="col-md-2"> Category </label>
                                        <div class="col-md-4">
                                            <?php echo $product_cat[$row['c_id']]; ?>
                                        </div>
                                        <label class="col-md-2"> Measurement </label>
                                        <div class="col-md-4">
                                            <?php echo $messures[$row['r_i_messure']]; ?>
                                        </div>
                                  </div>
                                  <div class="form-group">
                                        <label class="col-md-2"> Quantity </label>
                                        <div class="col-md-4">
                                            <?php echo $row['r_i_quantity']; ?>
                                        </div>
                                  </div>
                                </div>
                           </div>
                       <?php $i++; } ?>
                    </div>
                    <hr />
                    <h3>Details</h3>
                    <hr />
                    <div class="form-group">
                        <label class="col-md-2"> Payment terms </label>
                        <div class="col-md-4">
                            <?php echo $payment_terms[$item_details['payment_terms']]; ?>
                        </div>
                        <label class="col-md-2"> Publish </label>
                        <div class="col-md-4">
                            <?php if($item_details['publish']==1){ echo 'Public';}else{ echo 'Private';} ?>
                        </div>
                    </div>
                    <div class="select_neg_col <?php if($item_details['publish']!=2){ echo 'no_display_col'; } ?>">
                        <div class="form-group">
                            <label class="col-md-2"> Shortlisted sellers </label>
                            <div class="col-md-4">
                                <?php $shortlist_list; $ids = explode(',',$item_details['selected_negotiation']); 
                                  foreach($ids as $key=>$rw_ids):
                                    $id_rws[] = $shortlist_list[$rw_ids];
                                  endforeach;
                                  $id_rws = implode(',',$id_rws);
                                  echo $id_rws; ?>
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-md-2"> Currency </label>
                        <div class="col-md-4">
                            <?php echo $currency_types[$item_details['currency']]; ?>
                        </div>
                        <label class="col-md-2"> Date of Dispatch </label>
                        <div class="col-md-4">
                            <?php echo $item_details['dispach_time']; ?>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-md-2"> Bidding start on </label>
                        <div class="col-md-4">
                            <?php echo date('Y-m-d h:i a',strtotime($item_details['enquire_time_from'])); ?>
                            <input id="enquire_time_from" value="<?php echo date('M d, Y H:i:s',strtotime($item_details['enquire_time_from'])); ?>" type="hidden"/>
                        </div>
                        <label class="col-md-2"> Bidding end on </label>
                        <div class="col-md-4">
                            <?php echo date('Y-m-d h:i a',strtotime($item_details['enquire_time_to'])); ?>
                            <input id="enquire_time_to" value="<?php echo date('M d, Y H:i:s',strtotime($item_details['enquire_time_to'])); ?>" type="hidden"/>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-md-2"> Dispatch Address </label>
                        <div class="col-md-10">
                            <?php echo $addresses[$item_details['a_id']]; ?>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-md-2"> View files </label>
                        <div class="col-md-10">
                               <?php if(count($requirement_files)!=0){ $sno=1; foreach($requirement_files as $row):?>
                                    <div class="border_files col-md-3 text-center" style="margin: 10px;"> 
                                      <span class=""> <a target="_blank" href="<?php echo config_item('root_dir').'assets/images/requirement_files/'.$row['rf_name']; ?>"> <i>Click here to see</i> file - <?php echo $sno; ?> </a> </span> 
                                    </div>
                                <?php $sno++; endforeach; }else{ ?>
                                    <a class="" href="javascript:void(0)"> No Certificates </a>
                                <?php } ?>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-md-2"> Description </label>
                        <div class="col-md-10">
                            <?php echo $item_details['description']; ?>
                        </div>
                    </div>
                    <?php echo form_close(); ?>
                </div>
                <hr/>
                <div class="box-header with-border text-center">
                    <a href="javascript:void(0)" class="btn btn-primary pull-left">Construction Bay Bids</a>
                    <?php if(!isset($bid_selected)){ ?><a href="javascript:void(0)" class="btn btn-success pull-center select_seller_bid" id="<?php echo $item_details['r_id']; ?>" url="<?php echo base_url('buyer/project_bidding/select_seller_bid'); ?>">Select seller</a>
                    <a href="javascript:void(0)" class="btn btn-info pull-right send_call_for_neg" id="<?php echo $item_details['r_id']; ?>" url="<?php echo base_url('buyer/project_bidding/create_negotiation_proc'); ?>">Call for Negotiation</a>
                    <?php } ?>
                </div>
                <div class="error_msg alert alert-danger alert-dismissible"></div>
                <div class="info_msg alert alert-success alert-dismissible"></div>
                <hr/>
                <div class="row">
                    <div class="col-md-12 details_bidings">
                    <!-- The time line -->
                        <?php //echo '<pre>'; print_r($row_pb);exit;
                         $i=0;foreach($negotiations as $key_neg=>$row_negotiation){ ?>
                         <h3 class="text-center"><?php echo $row_negotiation; ?></h3>  
                        <?php foreach($project_biddings as $row_pb){ 
                             if($key_neg==$row_pb['negotiation_round']){ ?>
                                <ul class="timeline">
                                    <li>
                                        <div class="timeline-item">
                                            <span class="time"><i class="fa fa-clock-o"></i>&nbsp;&nbsp;<?php echo $row_pb['added_date']; ?></span>
                                            <h3 class="timeline-header">
                                            <?php if($key_neg==($ngo_count-1)&&!isset($bid_selected)){ //echo $i;exit; ?>
                                                <td><input type="checkbox" id="checkbox-1-<?php echo intval($row_pb['user_id']);?>" class="checkbox1 regular-checkbox" name="regular-checkbox"
                                                value="<?php echo intval($row_pb['user_id']);?>"/><label for="checkbox-1-<?php echo intval($row_pb['user_id']);?>"></label></td>
                                            <?php } ?>
                                            <a href="javascript:void(0)"><?php if(isset($bid_selected)&&$bid_selected['pb_id']==$row_pb['pb_id']){ ?>
                                            <?php echo $row_pb['name'].'(Selected)'; ?>
                                            <?php }else{ ?>
                                            <?php echo $row_pb['name']; ?>
                                            <?php } ?></a></h3>
                                            <img class="bidding-profile timeline-header profile-user-img img-responsive img-circle" src="<?php echo profile_img($row_pb['image']); ?>" alt="User profile picture"/>
                                            <div class="timeline-body">
                                                <div class="pro_items_list">
                                                    <div class="table-responsive">          
                                                        <table class="table">
                                                            <thead>
                                                                <tr>
                                                                    <th>Sno</th>
                                                                    <th>Name</th>
                                                                    <th>Type</th>
                                                                    <th>Category</th>
                                                                    <th>Meassurement</th>
                                                                    <th>Quantity</th>
                                                                    <th>Seller Quantity</th>
                                                                    <th>Seller Price</th>
                                                                </tr>
                                                            </thead>
                                                            <tbody>
                                                            <?php $i=1; foreach($row_pb['bidding_items'] as $row){ ?>
                                                                <tr>
                                                                    <td><?php echo $i.'.'; ?></td>
                                                                    <td><?php echo $row['r_i_name']; ?></td>
                                                                    <td><?php if($row['r_type']==1){ echo 'Product';}else{ echo 'Service';} ?></td>
                                                                    <td><?php if($row['r_type']==1){
                                                                            echo $product_cat[$row['c_id']];
                                                                         }else{ 
                                                                            echo $service_cat[$row['service_type']];
                                                                         } ?>
                                                                    </td>
                                                                    <td><?php echo $messures[$row['r_i_messure']]; ?></td>
                                                                    <td><?php echo $row['r_i_quantity']; ?></td>
                                                                    <td><?php if($row['r_type']==1){ ?> <?php echo $row['quantity']; ?> <?php }else{  } ?></td>
                                                                    <td><?php echo $row['price']; ?></td>
                                                                </tr>
                                                            <?php $i++; } ?>
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                    <form class="form-horizontal">
                                                        <div class="form-group">
                                                            <label class="col-md-1"> Description: </label>
                                                            <div class="col-md-11">
                                                                <?php echo $row_pb['pb_desc']; ?>
                                                            </div>
                                                        </div>
                                                        <div class="form-group">
                                                            <label class="col-md-1"> Files: </label>
                                                            <div class="col-md-11">
                                                                <?php if(count($row_pb['bidding_files'])!=0){ $sno=1; foreach($row_pb['bidding_files'] as $row_bid_files):?>
                                                                    <div class="border_files col-md-3 text-center" style="margin: 10px;"> 
                                                                      <span class=""> <a target="_blank" href="<?php echo config_item('root_dir').'assets/images/project_bidding_files/'.$row_bid_files['pbf_name']; ?>"> <i>Click here to see</i> file - <?php echo $sno; ?> </a> </span> 
                                                                    </div>
                                                                <?php $sno++; endforeach; }else{ ?>
                                                                    <a class="" href="javascript:void(0)"> No Certificates </a>
                                                                <?php } ?>
                                                            </div>
                                                        </div>
                                                     </form>
                                                </div>
                                            </div>
                                            <div class="timeline-footer">
                                                <a class="btn btn-primary btn-xs"><i class="fa fa-star"></i>&nbsp;&nbsp;5.0</a>
                                            </div>
                                        </div>
                                    </li>
                                </ul>
                           <?php  }   
                        }?>    
                        <?php $i++; } ?>
                    </div>
                <!-- /.col -->
                </div>            
            </div>
          </section>
        <!-- /.content -->
      </div>
      <!-- /.content-wrapper -->
      <!-- Control Sidebar -->
      <?php $this->load->view('common/common/footer'); ?>
      <!-- Add the sidebar's background. This div must be placed
           immediately after the control sidebar -->
      <div class="control-sidebar-bg"></div>
    </div>
<!-- ./wrapper -->
<?php $this->load->view('common/common/js'); ?>
<script src="<?php echo config_item('ui_base_path') ?>custom/js/jquery.validate.min.js"></script>
<script src="<?php echo config_item('ui_base_path') ?>plugins/bootstrap-select/bootstrap-select.min.js"></script>
<script src='<?php echo config_item('ui_base_path') ?>custom/js/bootstrap-datetimepicker.min.js'></script>
<script>
    // Set the date we're counting down to
    //var countDownDate = new Date("Jan 5, 2018 15:37:25").getTime();
    var countDownDate = new Date("<?php echo date('M d, Y H:i:s',strtotime($item_details['enquire_time_from'])); ?>").getTime();
    var expireDownDate = new Date("<?php echo date('M d, Y H:i:s',strtotime($item_details['enquire_time_to'])); ?>").getTime();

    // Update the count down every 1 second
    var x = setInterval(function() {
    
        // Get todays date and time
        var now = new Date().getTime();
        
        // Find the distance between now an the count down date
        var distance = countDownDate - now;
        var expire = expireDownDate - now;
        
        // Time calculations for days, hours, minutes and seconds
        var days = Math.floor(distance / (1000 * 60 * 60 * 24));
        var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
        var seconds = Math.floor((distance % (1000 * 60)) / 1000);
        
        // Time calculations for days, hours, minutes and seconds
        var ex_days = Math.floor(expire / (1000 * 60 * 60 * 24));
        var ex_hours = Math.floor((expire % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        var ex_minutes = Math.floor((expire % (1000 * 60 * 60)) / (1000 * 60));
        var ex_seconds = Math.floor((expire % (1000 * 60)) / 1000);
        
        
        //alert(distance);
        //alert(expire);
        //If the Bidding is started,
        if (distance > 0 && expire > 0){
            // Output the result in an element with id="demo"
            //document.getElementById("demo").innerHTML = ': will start in ' + days + "d " + hours + "h "+ minutes + "m " + seconds + "s ";
            $('#demo').html('Bidding will start in '+days+"d "+hours+"h "+minutes+"m "+seconds+"s ");
        }
        
         //If the Bidding is going on,
        if (distance<0&&expire>0){
            //clearInterval(x);
            //document.getElementById("demo").innerHTML = ": is going on";
            //$('#demo').html(': will start in '+days+"d "+hours+"h "+minutes+"m "+seconds+"s ");
            $('#demo').html('Bidding is going on - will end in '+ex_days+"d "+ex_hours+"h "+ex_minutes+"m "+ex_seconds+"s ");
        }
        
        //If the bidding is over,
        if (distance < 0 && expire < 0) {
            clearInterval(x);
            //document.getElementById("demo").innerHTML = ":Expired";
            $('#demo').html('Bidding is expired');
        }
    }, 1000);
    
    $(document).on("click", ".send_call_for_neg" ,function(e){
			var r_id = $(this).attr("id");
            var url = $(this).attr("url");
		    //alert(table_name)
				var checked = $(".regular-checkbox:checked").length > 0;
				if (!checked){
					bootbox.alert("Please check at least one seller");
					return false;
				}
				var data = new Array();
				$("input[name='regular-checkbox']:checked").each(function(i) {
					data.push($(this).val());
				});
			if (!data){
				bootbox.alert("Please check at least one seller");
				return false;
			} else {
			    bootbox.confirm({
                message: "Do you really want to create a negotiation?",
                buttons: {
                confirm: {
                label: 'Yes',
                className: 'btn-success'
                },
                cancel: {
                label: 'No',
                className: 'btn-danger'
                }
                },
                callback: function (result) {
                if(result){
					$.ajax({
						type: "POST",
						url: url,
						data: 'change_status='+ data + "&& r_id=" + r_id,
						success:function(msg){
							if(msg){
                                $('.error_msg').hide();
                                $('.info_msg').show();
                                $('.info_msg').html('Negotiation created and invitation sent successfully'); 	
							}else{
								$('.info_msg').hide();
                                $('.error_msg').show();
                                $('.error_msg').html('Something went wrong! Please try again later.');
							}
						}
					});
                  }
                } 
             });
		}
	});
    
    $(document).on("click", ".select_seller_bid" ,function(e){
			var r_id = $(this).attr("id");
            var url = $(this).attr("url");
		    //alert(table_name)
				var checked = $(".regular-checkbox:checked").length > 0;
				if (!checked){
					bootbox.alert("Please check at seller to select");
					return false;
				}
				var data = new Array();
				$("input[name='regular-checkbox']:checked").each(function(i) {
					data.push($(this).val());
				});
			if (!data){
				bootbox.alert("Please check at seller to select");
				return false;
			} else {
			    bootbox.confirm({
                message: "Do you really want to give bid to this seller?",
                buttons: {
                confirm: {
                label: 'Yes',
                className: 'btn-success'
                },
                cancel: {
                label: 'No',
                className: 'btn-danger'
                }
                },
                callback: function (result) {
                if(result){
					$.ajax({
						type: "POST",
						url: url,
						data: 'data='+ data + "&& r_id=" + r_id,
						success:function(msg){
							if(msg){
                                $('.error_msg').hide();
                                $('.info_msg').show();
                                $('.send_call_for_neg').fadeOut();
                                $('.select_seller_bid').fadeOut();
                                $('.send_call_for_neg').remove();
                                $('.select_seller_bid').remove();
                                $('.info_msg').html('Seller selected successfully.'); 	
							}else{
								$('.info_msg').hide();
                                $('.error_msg').show();
                                $('.error_msg').html('Something went wrong! Please try again later.');
							}
						}
					});
                  }
                } 
             });
		}
	});
    
</script>
</body>
</html>