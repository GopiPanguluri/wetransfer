<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <?php $this->load->view('common/common/css'); ?>
  <link rel="stylesheet" href="<?php echo config_item('ui_base_path') ?>plugins/bootstrap-select/bootstrap-select.min.css"/>
  <link rel='stylesheet prefetch' href='<?php echo config_item('ui_base_path') ?>custom/css/bootstrap-datetimepicker.min.css'/>
  <style>
  .no_display_col{
    display: none;
  }
  </style>
</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">
  <?php $this->load->view('common/buyer-top_nav') ?>
  <?php $this->load->view('common/buyer-left_nav') ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1><?php if ($mode == 'edit') {
                echo "Edit";
            }  else if($mode == 'details'){
                echo "Details of";
            }else {
                echo "Post";
            } ?> requirement
        </h1>
        <ol class="breadcrumb">
            <li><a href="<?php echo site_url('buyer'); ?>"><i class="fa fa-dashboard"></i> Home </a></li>
            <li><a href="<?php echo site_url('buyer/requirements'); ?>"><i class="fa fa-university"></i> requirements </a></li>
            <li class="active"> <?php if ($mode == 'edit') {echo "<i class='fa fa-pencil'></i>&nbsp;&nbsp;Edit";}  else if($mode == 'details'){ echo "<i class='fa fa-eye'></i>&nbsp;&nbsp;Details of"; } else {echo "<i class='fa fa-plus'></i>&nbsp;&nbsp;Post";} ?> requirement </li>
        </ol>
      </section>

    <!-- Main content -->
    <input type="hidden" id="page" value="nav-posts"/>    
    <section class="content">
        <div class="box box-primary">
          <div class="panel-body">
            <?php
                $success_message = $this->session->flashdata('insert_record');
                if ($success_message['status'] == "success") {
                    echo '<p class="alert alert-success sas-succcess-message">' . $success_message['message'] . '</p><div class="clearfix"></div>';
                } else if ($success_message['status'] == "fail") {
                    echo '<p class="alert alert-danger sas-succcess-message">' . $success_message['message'] . '</p><div class="clearfix"></div>';
                }
                echo '<div class="response_alert"></div>';
            ?>
            <div class="error_msg alert alert-danger alert-dismissible"></div>
            <div class="info_msg alert alert-success alert-dismissible"></div>
            <label id="general_validation" class="text-center error"></label>
            <?php
                echo form_open_multipart('buyer/requirements/create_requirement', array('id' => 'customer_form', 'class' => 'form-horizontal'));
                if ($mode == 'edit') {
            ?>  
                
                <h3>Products</h3>
                <hr />
                <div class="pro_items_list">
                    <?php $i=1; foreach($req_items as $row){ ?>
                        <div class="list_<?php echo $i; ?> items_divs existed_item">
                            <div class="form-group">
                                <label class="col-md-2"><?php echo $i; ?>. Name </label>
                                <div class="col-md-4">
                                    <input name="r_name[]" id="r_name" type="text" class="r_name form-control" value="<?php echo $row['r_i_name']; ?>"/>
                                    <label id="r_name-error" class="error" for="r_name" style="display: inline;"></label>                                                                        
                                    <input type="hidden" name="r_i_id" id="r_i_id" value="<?php echo $row['r_i_id']; ?>" />
                                </div>
                                <label class="col-md-2"> Type </label>
                                <div class="col-md-3 r_type_val" attr_val="<?php echo $i; ?>">
                                    <label>
                                        <input type="radio" id="r_type" <?php if($row['r_type']==1){ echo 'checked'; } ?> name="r_type_<?php echo $i; ?>" value="1" attr_val="<?php echo $i; ?>" class="flat-red"/>
                                        Product
                                    </label>&nbsp;&nbsp;&nbsp;&nbsp;
                                    <label>
                                        <input type="radio" id="r_type" <?php if($row['r_type']==2){ echo 'checked'; } ?> name="r_type_<?php echo $i; ?>" value="2" attr_val="<?php echo $i; ?>" class="flat-red"/>
                                        Service
                                    </label><br />
                                    <label id="type-error" class="error" for="r_type"></label>
                                </div>
                                <a href="javascript:void(0)" data-toggle="tooltip" id="<?php echo $row['r_i_id']; ?>" class="col-md-1 deleteme show-tooltip deleteitem_<?php echo $row['r_i_id']; ?>" title="Delete Record" data-tablename="req_items" data-fieldname="r_i_id" url="<?php echo site_url('buyer/delete_all_record'); ?>">
                                <i class="fa_size fa fa-trash-o "></i></a>  
                            </div>
                            <div class="service_col_<?php echo $i; ?> <?php if($row['r_type']!=2){ echo 'no_display_col'; } ?>" attr_val="<?php echo $i; ?>">
                                <div class="form-group">
                                  <label class="col-md-2"> Service type </label>
                                  <div class="col-md-4">
                                        <?php echo form_dropdown('service_type[]',$service_cat,$row['service_type'],'id="service_type" class="select2 ser_type_sel form-control"'); ?>
                                  </div>
                                </div>
                            </div>
                            <div class="requirement_col_<?php echo $i; ?> <?php if($row['r_type']!=1){ echo 'no_display_col'; } ?>" attr_val="<?php echo $i; ?>">
                               <div class="form-group">
                                    <label class="col-md-2"> Category </label>
                                    <div class="col-md-4">
                                        <?php echo form_dropdown('c_id[]',$product_cat,$row['c_id'],'id="c_id" class="select2 pro_sel form-control"'); ?>
                                    </div>
                                    <label class="col-md-2"> Measurement </label>
                                    <div class="col-md-4">
                                        <?php echo form_dropdown('meassurement[]',$messures,$row['r_i_messure'],'id="meassurement" class="form-control"'); ?>
                                    </div>
                              </div>
                              <div class="form-group">
                                    <label class="col-md-2"> Quantity </label>
                                    <div class="col-md-4">
                                        <?php echo form_input('quantity[]',$row['r_i_quantity'],'id="quantity" class="form-control"'); ?>
                                    </div>
                                    
                              </div>
                            </div>
                       </div>
                   <?php $i++; } ?>
                </div>
                <div class="col-md-2 col-md-offset-6 pull-center">
                    <a href="javascript:void(0)" onclick="addnewrecord()" data-toggle="tooltip" title="" class="btn btn-success btn-background" data-original-title="Add product"><i class="fa fa-plus"></i></a>
                    <a onclick="removerecord()" class="btn btn-danger remove_row_period btn-background action-links" data-toggle="tooltip" title="Delete Last Record" href="javascript:void(0);" style="display: none;"><i class="fa fa-trash-o"></i></a>
                </div>
                <br />
                <hr />
                <h3 class="">Details</h3>
                <hr />
                <div class="form-group">
                    <label class="col-md-2"> Type of bidding </label>
                    <div class="col-md-4">
                        <?php echo form_dropdown('tob_process',$type_of_bid_process,$item_details['tob_process'],'id="tob_process" class="form-control"'); ?>
                    </div>
                    <div id="budget_div<?php //if($item_details['tob_process']!=='3'){ echo ' no_display_col'; } ?>">
                        <div class='col-md-1'>
                            <input type="checkbox" name="check_tob" id="check_tob"/>
                        </div>
                        <div class='col-md-3'>
                            <?php echo form_input('budget',$item_details['budget'],'id="budget" class="form-control" readonly=""'); ?>
                        </div>
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-md-2"> Payment terms </label>
                    <div class="col-md-4">
                        <?php echo form_dropdown('payment_terms',$payment_terms,$item_details['payment_terms'],'id="payment_terms" class="form-control"'); ?>
                    </div>
                    <label class="col-md-2"> Publish </label>
                    <div class="col-md-4">
                        <label>
                            <input type="radio" id="publish" name="publish" value="1" <?php if($item_details['publish']==1){ echo 'checked'; } ?> class="flat-red"/>
                            Public
                        </label>&nbsp;&nbsp;&nbsp;&nbsp;
                        <label>
                            <input type="radio" id="publish" name="publish" value="2" <?php if($item_details['publish']==2){ echo 'checked'; } ?> class="flat-red"/>
                            Private
                        </label><br />
                        <label id="type-error" class="error" for="publish"></label>
                    </div>
                </div>
                <div class="select_neg_col <?php if($item_details['publish']!=2){ echo 'no_display_col'; } ?>">
                    <div class="form-group">
                        <label class="col-md-2"> Shortlisted sellers </label>
                        <div class="col-md-4">
                            <?php echo form_dropdown('selected_negotiation',$shortlist_list,explode(',',$item_details['selected_negotiation']),'id="selected_negotiation" class="form-control select2" multiple=""'); ?>
                        </div>
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-md-2"> Currency </label>
                    <div class="col-md-4">
                        <?php echo form_dropdown('currency',$currency_types,$item_details['currency'],'id="currency" class="form-control"'); ?>
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-md-2"> Bidding start on </label>
                    <div class="col-md-4">
                        <div class='input-group date' id='datetimepicker1'>
                            <?php echo form_input('enquire_time_from',date('Y-m-d h:i:s a',strtotime($item_details['enquire_time_from'])),'id="enquire_time_from" class="form-control"'); ?>
                            <span class="input-group-addon"><span class="glyphicon glyphicon-calendar"></span>
                            </span>
                        </div>
                        <label id="enquire_time_from-error" class="error" for="enquire_time_from"></label>
                    </div>
                    <label class="col-md-2"> Bidding ends on </label>
                    <div class="col-md-4">
                        <div class='input-group date' id='datetimepicker1'>
                            <?php echo form_input('enquire_time_to',date('Y-m-d h:i:s a',strtotime($item_details['enquire_time_to'])),'id="enquire_time_to" class="form-control"'); ?>
                            <span class="input-group-addon"><span class="glyphicon glyphicon-calendar"></span>
                            </span>
                        </div>
                        <label id="enquire_time_to-error" class="error" for="enquire_time_to"></label>
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-md-2"> Date of Dispatch </label>
                    <div class="col-md-4">
                        <?php echo form_input('dispach_time',$item_details['dispach_time'],'id="dispach_time" class="form-control"'); ?>
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-md-2"> Dispatch Address </label>
                    <div class="col-md-10">
                        <?php echo form_dropdown('a_id',$dis_addresses,$item_details['a_id'],'id="a_id" class="form-control select2"'); ?>
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-md-2"> Billing Address </label>
                    <div class="col-md-10">
                        <?php echo form_dropdown('bil_id',$bill_addresses,$item_details['bil_id'],'id="bil_id" class="form-control select2"'); ?>
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-md-2"> Files </label>
                    <div class="col-md-10">
                        <?php echo form_upload('files','','id="files" class="form-control" multiple=""'); ?>
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-md-2"> View files </label>
                    <div class="col-md-10">
                           <?php if(count($requirement_files)!=0){ $sno=1; foreach($requirement_files as $row):?>
                                <div class="border_files col-md-3 text-center" style="margin: 10px;"> 
                                  <span class=""> <a target="_blank" href="<?php echo config_item('root_dir').'assets/images/requirement_files/'.$row['rf_name']; ?>"> <i>Click here to see</i> file - <?php echo $sno; ?> </a><a href="javascript:void(0)" data-toggle="tooltip" id="<?php echo $row['rf_id']; ?>" class="deleteme show-tooltip deleteitem_<?php echo $row['rf_id']; ?>" title="Delete Record" data-tablename="requirement_files" data-fieldname="rf_id" url="<?php echo base_url('seller/delete_all_record'); ?>"><i class="fa_size fa fa-trash-o "></i></a></span> 
                                </div>
                            <?php $sno++; endforeach; }else{ ?>
                                <a class="" href="javascript:void(0)"> No Certificates </a>
                            <?php } ?>
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-md-2"> Description </label>
                    <div class="col-md-10">
                        <textarea name="description" id="description" rows="5" class="form-control"><?php echo $item_details['description']; ?></textarea>
                    </div>
                </div>
                <!--div>
                    <label class="col-md-2"> Image </label>
                    <div class="col-md-4">
                        <img src="<?php //echo config_item('root_dir').'assets/images/users/'.$item_details['image']; ?>" alt="image" height="200" width="200"/>
                    </div>
                </div-->
                
                <div class="col-md-9 col-md-offset-2">
                    <input type="hidden" name="id" id="id" value="<?php echo $item_details['r_id']; ?>" />
                    <button type="submit" name="submit" id="submit" val="update" class="btn btn-success">Update </button>
                    <a href="<?php echo site_url('buyer/requirements') ?>" class="btn btn-default">Cancel</a>
                </div>
                
            <?php } else if($mode == 'details'){ ?> 
                
                <div class="box-header with-border">
                    <a href="javascript:void(0)" class="btn btn-primary pull-left">Products</a>
                    
                </div>
                <hr />
                <div class="pro_items_list">
                    <?php $i=1; foreach($req_items as $row){ ?>
                        <div class="list_<?php echo $i; ?> items_divs existed_item">
                            <div class="form-group">
                                <label class="col-md-2"><?php echo $i; ?>. Name </label>
                                <div class="col-md-4">
                                    <?php echo $row['r_i_name']; ?>
                                </div>
                                <label class="col-md-2"> Type </label>
                                <div class="col-md-4 r_type_val" attr_val="<?php echo $i; ?>">
                                    <?php if($row['r_type']==1){ echo 'Product';}else{ echo 'Service';} ?>
                                </div>  
                            </div>
                            <div class="service_col_<?php echo $i; ?> <?php if($row['r_type']!=2){ echo 'no_display_col'; } ?>" attr_val="<?php echo $i; ?>">
                                <div class="form-group">
                                  <label class="col-md-2"> Service type </label>
                                  <div class="col-md-4">
                                        <?php echo $service_cat[$row['service_type']]; ?>
                                  </div>
                                </div>
                            </div>
                            <div class="requirement_col_<?php echo $i; ?> <?php if($row['r_type']!=1){ echo 'no_display_col'; } ?>" attr_val="<?php echo $i; ?>">
                               <div class="form-group">
                                    <label class="col-md-2"> Category </label>
                                    <div class="col-md-4">
                                        <?php echo $product_cat[$row['c_id']]; ?>
                                    </div>
                                    <label class="col-md-2"> Measurement </label>
                                    <div class="col-md-4">
                                        <?php echo $messures[$row['r_i_messure']]; ?>
                                    </div>
                              </div>
                              <div class="form-group">
                                    <label class="col-md-2"> Quantity </label>
                                    <div class="col-md-4">
                                        <?php echo $row['r_i_quantity']; ?>
                                    </div>
                              </div>
                            </div>
                       </div>
                   <?php $i++; } ?>
                </div>
                <hr />
                <h3>Details</h3>
                <hr />
                <div class="form-group">
                    <label class="col-md-2"> Type of bidding </label>
                    <div class="col-md-4">
                        <?php echo $type_of_bid_process[$item_details['tob_process']]; ?>
                    </div>
                    <div id="budget_div<?php //if($item_details['tob_process']!==3){ echo ' no_display_col'; } ?>">
                        <label class="col-md-2"> Budget </label>
                        <div class='col-md-3'>
                            <?php echo $item_details['budget'].' /-'; ?>
                        </div>
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-md-2"> Payment terms </label>
                    <div class="col-md-4">
                        <?php echo $payment_terms[$item_details['payment_terms']]; ?>
                    </div>
                    <label class="col-md-2"> Publish </label>
                    <div class="col-md-4">
                        <?php if($item_details['publish']==1){ echo 'Public';}else{ echo 'Private';} ?>
                    </div>
                </div>
                <div class="select_neg_col <?php if($item_details['publish']!=2){ echo 'no_display_col'; } ?>">
                    <div class="form-group">
                        <label class="col-md-2"> Shortlisted sellers </label>
                        <div class="col-md-4">
                            <?php $shortlist_list; $ids = explode(',',$item_details['selected_negotiation']); 
                              foreach($ids as $key=>$rw_ids):
                                $id_rws[] = $shortlist_list[$rw_ids];
                              endforeach;
                              $id_rws = implode(',',$id_rws);
                              echo $id_rws; ?>
                        </div>
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-md-2"> Currency </label>
                    <div class="col-md-4">
                        <?php echo $currency_types[$item_details['currency']]; ?>
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-md-2"> Bidding start on </label>
                    <div class="col-md-4">
                        <?php echo $item_details['enquire_time_from']; ?>
                    </div>
                    <label class="col-md-2"> Bidding ends on </label>
                    <div class="col-md-4">
                        <?php echo $item_details['enquire_time_to']; ?>
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-md-2"> Date of Dispatch </label>
                    <div class="col-md-4">
                        <?php echo $item_details['dispach_time']; ?>
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-md-2"> Dispatch Address </label>
                    <div class="col-md-10">
                        <?php echo $dis_addresses[$item_details['a_id']]; ?>
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-md-2"> Billing Address </label>
                    <div class="col-md-10">
                        <?php echo $bill_addresses[$item_details['bil_id']]; ?>
                    </div>
                </div>                                
                <div class="form-group">
                    <label class="col-md-2"> View files </label>
                    <div class="col-md-10">
                           <?php if(count($requirement_files)!=0){ $sno=1; foreach($requirement_files as $row):?>
                                <div class="border_files col-md-3 text-center" style="margin: 10px;"> 
                                  <span class=""> <a target="_blank" href="<?php echo config_item('root_dir').'assets/images/requirement_files/'.$row['rf_name']; ?>"> <i>Click here to see</i> file - <?php echo $sno; ?> </a> </span> 
                                </div>
                            <?php $sno++; endforeach; }else{ ?>
                                <a class="" href="javascript:void(0)"> No Certificates </a>
                            <?php } ?>
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-md-2"> Description </label>
                    <div class="col-md-10">
                        <?php echo $item_details['description']; ?>
                    </div>
                </div>
                <div class="col-md-12">
                    <a href="<?php echo site_url('buyer/requirements') ?>" class="btn btn-default">Back</a>
                    <a href="javascript:void(0)" data-toggle="tooltip" class="text-center btn btn-<?php if($item_details['add_to_bidding']=='0'){ echo 'warning add_to_bidding'; }else{ echo 'success'; } ?> pull-right" pb_id="<?php echo $item_details['r_id']; ?>"><i class="fa fa-tags"></i>&nbsp;&nbsp;
                    <?php if($item_details['add_to_bidding']==0){ echo '<span>Add to Project Bidding</span>'; }else{ echo '<span>Project Added to Bidding</span>'; } ?></a>
                </div>
                <br /><br />
                <div class="post_bidd_div panel-body">   
                    <?php echo form_open_multipart('buyer/requirements/change_status_to_bidding', array('id' => 'form_bidding', 'class' => 'form-horizontal')); ?>
                        <label id="general_validation" class="text-center error"></label>
                        <div class="form-group">
                            <label class="col-md-3"> Bidding invitation message: </label>
                            <div class="col-md-9">
                                <textarea name="notifi_text" id="notifi_text" class="form-control"></textarea>
                            </div>
                        </div>           
                        <div class="col-md-7 col-md-offset-5">
                            <input type="hidden" name="id" id="id" value="<?php echo $item_details['r_id']; ?>" />
                            <button type="submit" name="submit" id="form_bidding_button" val="submit" class="btn btn-success"> Submit </button>
                        </div>            
                    <?php  echo form_close(); ?>
                    <hr/>
                </div>
                <div class="error_msg_bid alert alert-danger alert-dismissible"></div>
                <div class="info_msg_bid alert alert-success alert-dismissible"></div>
            <?php } else { ?>
            
                <h3>Products</h3>
                <hr />
                <div class="pro_items_list">
                    <div class="list_1 items_divs">
                        <div class="form-group">
                            <label class="col-md-2"> Name </label>
                            <div class="col-md-4">
                                <input name="r_name[]" id="r_name" type="text" class="r_name form-control" value=""/>
                                <label id="r_name-error" class="error" for="r_name" style="display: inline;"></label>                                
                            </div>
                            <label class="col-md-2"> Type </label>
                            <div class="col-md-4 r_type_val" attr_val="1">
                                <label>
                                    <input type="radio" id="r_type" name="r_type_1" value="1" attr_val="1" class="flat-red"/>
                                    Product
                                </label>&nbsp;&nbsp;&nbsp;&nbsp;
                                <label>
                                    <input type="radio" id="r_type" name="r_type_1" value="2" attr_val="1" class="flat-red"/>
                                    Service
                                </label><br />
                                <label id="type-error" class="error" for="r_type"></label>
                            </div>
                        </div>
                        <div class="service_col_1 no_display_col" attr_val="1">
                            <div class="form-group">
                              <label class="col-md-2"> Service type </label>
                              <div class="col-md-4">
                                    <?php echo form_dropdown('service_type[]',$service_cat,'','id="service_type" class="select2 ser_type_sel form-control"'); ?>
                              </div>
                            </div>
                        </div>
                        <div class="requirement_col_1 no_display_col" attr_val="1">
                           <div class="form-group">
                                <label class="col-md-2"> Category </label>
                                <div class="col-md-4">
                                    <?php echo form_dropdown('c_id[]',$product_cat,'','id="c_id" class="select2 pro_sel form-control"'); ?>
                                </div>
                                <label class="col-md-2"> Measurement </label>
                                <div class="col-md-4">
                                    <?php echo form_dropdown('meassurement[]',$messures,'','id="meassurement" class="form-control"'); ?>
                                </div>
                          </div>
                          <div class="form-group">
                                <label class="col-md-2"> Quantity </label>
                                <div class="col-md-4">
                                    <?php echo form_input('quantity[]','','id="quantity" class="form-control"'); ?>
                                </div>
                          </div>
                        </div>
                   </div>
                </div>
                <div class="col-md-2 col-md-offset-6 pull-center">
                    <a href="javascript:void(0)" onclick="addnewrecord()" data-toggle="tooltip" title="" class="btn btn-success btn-background" data-original-title="Add product"><i class="fa fa-plus"></i></a>
                    <a onclick="removerecord()" class="btn btn-danger remove_row_period btn-background action-links" data-toggle="tooltip" title="Delete Last Record" href="javascript:void(0);" style="display: none;"><i class="fa fa-trash-o"></i></a>
                </div>
                <br />
                <hr />
                <div class="form-group">
                    <label class="col-md-2"> Type of bidding </label>
                    <div class="col-md-4">
                        <?php echo form_dropdown('tob_process',$type_of_bid_process,'','id="tob_process" class="form-control"'); ?>
                    </div>
                    <div id="budget_div">
                        <div class='col-md-1'>
                            <input type="checkbox" name="check_tob" id="check_tob"/>
                        </div>
                        <div class='col-md-3'>
                            <?php echo form_input('budget','','id="budget" class="form-control" readonly=""'); ?>
                        </div>
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-md-2"> Payment terms </label>
                    <div class="col-md-4">
                        <?php echo form_dropdown('payment_terms',$payment_terms,'','id="payment_terms" class="form-control"'); ?>
                    </div>
                    <label class="col-md-2"> Publish </label>
                    <div class="col-md-4">
                        <label>
                            <input type="radio" id="publish" name="publish" value="1" class="flat-red"/>
                            Public
                        </label>&nbsp;&nbsp;&nbsp;&nbsp;
                        <label>
                            <input type="radio" id="publish" name="publish" value="2" class="flat-red"/>
                            Private
                        </label><br />
                        <label id="type-error" class="error" for="publish"></label>
                    </div>
                </div>
                <div class="select_neg_col no_display_col">
                    <div class="form-group">
                        <label class="col-md-2"> Shortlisted sellers </label>
                        <div class="col-md-4">
                            <?php echo form_dropdown('selected_negotiation',$shortlist_list,'','id="selected_negotiation" class="form-control select2" multiple=""'); ?>
                        </div>
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-md-2"> Currency </label>
                    <div class="col-md-4">
                        <?php echo form_dropdown('currency',$currency_types,'','id="currency" class="form-control"'); ?>
                    </div>  
                </div>
                <div class="form-group">
                    <label class="col-md-2"> Bidding start on </label>
                    <div class="col-md-4">
                        <div class='input-group date' id='datetimepicker1'>
                            <?php echo form_input('enquire_time_from','','id="enquire_time_from" class="form-control"'); ?>
                            <span class="input-group-addon"><span class="glyphicon glyphicon-calendar"></span>
                            </span>
                        </div>
                        <label id="enquire_time_from-error" class="error" for="enquire_time_from"></label>
                    </div>
                    <label class="col-md-2"> Bidding ends on </label>
                    <div class="col-md-4">
                        <div class='input-group date' id='datetimepicker1'>
                            <?php echo form_input('enquire_time_to','','id="enquire_time_to" class="form-control"'); ?>
                            <span class="input-group-addon"><span class="glyphicon glyphicon-calendar"></span>
                            </span>
                        </div>
                        <label id="enquire_time_to-error" class="error" for="enquire_time_to"></label>
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-md-2"> Date of Dispatch </label>
                    <div class="col-md-4">
                        <?php echo form_input('dispach_time','','id="dispach_time" class="form-control"'); ?>
                    </div>  
                </div>
                <div class="form-group">
                    <label class="col-md-2"> Dispatch Address </label>
                    <div class="col-md-10">
                        <?php echo form_dropdown('a_id',$dis_addresses,'','id="a_id" class="form-control select2"'); ?>
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-md-2"> Billing Address </label>
                    <div class="col-md-10">
                        <?php echo form_dropdown('bil_id',$bill_addresses,'','id="bil_id" class="form-control select2"'); ?>
                    </div>
                </div>                
                <div class="form-group">
                    <label class="col-md-2"> Files </label>
                    <div class="col-md-10">
                        <?php echo form_upload('files','','id="files" class="form-control" multiple=""'); ?>
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-md-2"> Description </label>
                    <div class="col-md-10">
                        <textarea name="description" id="description" rows="5" class="form-control"></textarea>
                    </div>
                </div>
                <div class="col-md-9 col-md-offset-2">
                    <button type="submit" name="submit" class="btn btn-success" id="submit" val="insert">Save </button>
                    <a href="<?php echo site_url('buyer/requirements') ?>" class="btn btn-default">Cancel</a>
                </div>
            <?php } echo form_close(); ?>
            </div>            
        </div>
      </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <!-- Control Sidebar -->
  <?php $this->load->view('common/common/footer'); ?>
  <!-- Add the sidebar's background. This div must be placed
       immediately after the control sidebar -->
  <div class="control-sidebar-bg"></div>
</div>
<!-- ./wrapper -->

<?php $this->load->view('common/common/js') ?>
<script src="<?php echo config_item('ui_base_path') ?>custom/js/jquery.validate.min.js"></script>
<script src="<?php echo config_item('ui_base_path') ?>custom/js/additional-methods.js"></script>
<script src="<?php echo config_item('ui_base_path') ?>plugins/bootstrap-select/bootstrap-select.min.js"></script>
<script src='<?php echo config_item('ui_base_path') ?>custom/js/bootstrap-datetimepicker.min.js'></script>
<script type="text/javascript" src="<?php echo config_item('ui_base_path') ?>plugins/jQuery/jquery.tmpl.js"></script>
<script id="blogPostTemplate" type="text/x-jQuery-tmpl">
    <div class="list_${attr_val} items_divs">
        <div class="form-group">
            <label class="col-md-2"> Name </label>
            <div class="col-md-4">
                <input name="r_name[]" id="r_name" type="text" class="r_name form-control" value=""/>
            </div>
            <label class="col-md-2"> Type </label>
            <div class="col-md-4 r_type_val" attr_val="${attr_val}">
                <label>
                    <input type="radio" id="r_type" name="r_type_${attr_val}" value="1" attr_val="${attr_val}" class="flat-red"/>
                    Product
                </label>&nbsp;&nbsp;&nbsp;&nbsp;
                <label>
                    <input type="radio" id="r_type" name="r_type_${attr_val}" value="2" attr_val="${attr_val}" class="flat-red"/>
                    Service
                </label><br />
                <label id="type-error" class="error" for="r_type"></label>
            </div>
        </div>
        <div class="service_col_${attr_val} no_display_col" attr_val="${attr_val}">
            <div class="form-group">
              <label class="col-md-2"> Service type </label>
              <div class="col-md-4">
                    <?php echo form_dropdown('service_type[]',$service_cat,'','id="service_type" class="select2 ser_type_sel form-control"'); ?>
              </div>
            </div>
        </div>
        <div class="requirement_col_${attr_val} no_display_col" attr_val="${attr_val}">
           <div class="form-group">
                <label class="col-md-2"> Category </label>
                <div class="col-md-4">
                    <?php echo form_dropdown('c_id[]',$product_cat,'','id="c_id" class="select2 pro_sel form-control"'); ?>
                </div>
                <label class="col-md-2"> Measurement </label>
                <div class="col-md-4">
                    <?php echo form_dropdown('meassurement[]',$messures,'','id="meassurement" class="form-control"'); ?>
                </div>
          </div>
          <div class="form-group">
                <label class="col-md-2"> Quantity </label>
                <div class="col-md-4">
                    <?php echo form_input('quantity[]','','id="quantity" class="form-control"'); ?>
                </div>
          </div>
        </div>
   </div>
</script>
<script type="">
    $(".add_to_bidding").click(function(){
       $(".post_bidd_div").toggle();
    });
    function addnewrecord(){
        var data;
        if($('.pro_items_list .items_divs').length!=0){
            var attr_val = parseInt($('.pro_items_list > div:last > div > .r_type_val').attr("attr_val"))+1;
        }else{
            attr_val = 1;
        }
        data = {attr_val: attr_val};
        $("#blogPostTemplate").tmpl(data).appendTo(".pro_items_list");
        $(".remove_row_period").show();
    }
    
    function removerecord(){
        var attr_val = parseInt($('.pro_items_list > div:last > div > .r_type_val').attr("attr_val"));
        var no_of_exist = $('.pro_items_list .existed_item').length;
        if(no_of_exist!==0){
            if(attr_val > no_of_exist){
              $(".pro_items_list .list_"+attr_val).remove();
              $(".remove_row_period").show();
            }else{
              console.log('attr_val is :', attr_val);
              $(".remove_row_period").hide();
            }
        }else{
            if(attr_val > 2){
              $(".pro_items_list .list_"+attr_val).remove();
              $(".remove_row_period").show();
            }else if(attr_val == 2){
              $(".pro_items_list .list_"+attr_val).remove();
              $(".remove_row_period").hide();  
            }else{
              console.log('attr_val is :', attr_val);
              $(".remove_row_period").hide();
            }
        }
        
    }
    
    $(function(){
        $('#dispach_time').datepicker({
            format: 'yyyy-mm-dd'
        });
        //Initialize Select2 Elements
        $(".select2").select2();
    });
    
    $(function(){
           var bindDatePicker = function(){
        		$(".date").datetimepicker({
                format:'YYYY-MM-DD h:mm a',
        			icons: {
        				time: "fa fa-clock-o",
        				date: "fa fa-calendar",
        				up: "fa fa-arrow-up",
        				down: "fa fa-arrow-down"
        			}
        		}).find('input:first').on("blur",function () {
        			// check if the date is correct. We can accept dd-mm-yyyy and yyyy-mm-dd.
        			// update the format if it's yyyy-mm-dd
        			var date = parseDate($(this).val());
        			if (! isValidDate(date)) {
        				//create date based on momentjs (we have that)
        				date = moment().format('YYYY-MM-DD');
        			}
        			$(this).val(date);
        		});
        	}
   
           var isValidDate = function(value, format){
        		format = format || false;
        		// lets parse the date to the best of our knowledge
        		if (format) {
        			value = parseDate(value);
        		}
        		var timestamp = Date.parse(value);
        		return isNaN(timestamp) == false;
           }
   
           var parseDate = function(value) {
        		var m = value.match(/^(\d{1,2})(\/|-)?(\d{1,2})(\/|-)?(\d{4})$/);
        		if (m)
        			value = m[5] + '-' + ("00" + m[3]).slice(-2) + '-' + ("00" + m[1]).slice(-2);
        		return value;
           }
           bindDatePicker();
    });
    
    
    $(document).ready(function(){
    $.validator.setDefaults({
            //ignore: []
    });
    <?php if ($mode!=='details') { ?>
    $("#customer_form").validate({
    <?php if ($mode == 'create') { ?>
        rules: {
            'r_name[]': {
                "required": true,
                letterswithbasicpunc: true,
                minlength:3,
                maxlength:40
            },
            'r_type[]': {
                required: true
            },
            'quantity[]': {
                required: true,
                number:true
            },
            payment_terms: {
                required: true
            },
            publish: {
                required: true
            },
            currency: {
                required: true
            },
            dispach_time: {
                required: true
            },
            files: {
                required: true
            },
            enquire_time_from: {
                required: true
            },
            enquire_time_to: {
                required: true
            },
            'c_id[]': {
                required: true
            },
            a_id: {
                required: true
            },
            'service_type[]': {
                required: true
            },
            description: {
                required: true
            },
            selected_negotiation: {
                required: true
            },
            'meassurement[]': {
                required: true
            },
            tob_process: {
                required: true
            },
            budget:{
                number:true
            }
        },
        
        messages: {				
            'r_name[]': {					
                required: "Please enter product name."
             }
        },
    <?php }else{ ?>
        rules: {
            'r_name[]': {
                "required": true,
                letterswithbasicpunc: true,
                minlength:3,
                maxlength:40
            },
            'r_type[]': {
                required: true
            },
            'quantity[]': {
                required: true,
                number:true
            },
            payment_terms: {
                required: true
            },
            publish: {
                required: true
            },
            currency: {
                required: true
            },
            dispach_time: {
                required: true
            },
            enquire_time_from: {
                required: true
            },
            enquire_time_to: {
                required: true
            },
            'c_id[]': {
                required: true
            },
            a_id: {
                required: true
            },
            'service_type[]': {
                required: true
            },
            description: {
                required: true
            },
            selected_negotiation: {
                required: true
            },
            meassurement: {
                required: true
            },
            tob_process: {
                required: true
            },
            budget:{
                number:true
            }
        },
        
        messages: {				
            requirement_email: {					
                required: "Email should not leave empty."
                }
        },
    <?php } ?>
        submitHandler: function(form){
        event.preventDefault();// using this page stop being refreshing
        var bugdet = $('#budget:checked').val();
        if(bugdet==''){
            $('#general_validation').show()
            $('#general_validation').html('Please give quantity for selected items');
        }
        var formData = new FormData();
        formData.append('publish', $('#publish:checked').val());
        formData.append('payment_terms', $('#payment_terms').val());
        formData.append('currency', $('#currency').val());
        formData.append('payment_terms', $('#payment_terms').val());
        formData.append('enquire_time_from', $('#enquire_time_from').val());
        formData.append('enquire_time_to', $('#enquire_time_to').val());
        formData.append('dispach_time', $('#dispach_time').val());
        formData.append('description', $('#description').val());
        formData.append('a_id', $('#a_id').val());
        formData.append('bil_id', $('#bil_id').val());
        formData.append('tob_process', $('#tob_process').val());
        formData.append('budget', $('#budget').val());
        
        formData.append('selected_negotiation', $('#selected_negotiation').val());
        var attr_val = parseInt($('.pro_items_list > div:last > div > .r_type_val').attr("attr_val"))+1;
        for(var i = 1; i < attr_val; i++){
           var deltaArray=new Array();
           var pre_arr;
           var r_type = $('input[name=r_type_'+i+']:checked').val();
           var r_name = $('.list_'+i+' #r_name').val();
           var c_id = $('.list_'+i+' #c_id').val();
           var service_type = $('.list_'+i+' #service_type').val();
           var meassurement = $('.list_'+i+' #meassurement').val();
           var quantity = $('.list_'+i+' #quantity').val();
           //alert(r_name);
           formData.append('items['+i+'][r_name]', r_name);
           formData.append('items['+i+'][r_type]', r_type);
           if(r_type==1){   
                formData.append('items['+i+'][meassurement]', meassurement);
                formData.append('items['+i+'][c_id]', c_id);
                formData.append('items['+i+'][quantity]', quantity);                
           }else if(r_type==2){
                formData.append('items['+i+'][service_type]', service_type);
           }
           <?php if ($mode == 'edit') { ?>
                var r_i_id = $('.list_'+i+' #r_i_id').val();
                formData.append('items['+i+'][r_i_id]', r_i_id);
            <?php } ?>
        }
        if($('#files')[0].files!==''){
            jQuery.each(jQuery('#files')[0].files, function(i, file) {
                formData.append('files[]', file);
            });
        }
        <?php if ($mode == 'edit') { ?>
        formData.append('id', $('#id').val());
        <?php } ?>
        formData.append('submit', $("#submit").attr('val'));
        $.ajax({
            url:form.action,
            type:form.method,
            async:false,
            cache:false,
            contentType:false,
            enctype:'multipart/form-data',
            processData:false,
            dataType:"json",
            //data:$(form).serialize(),
            data: formData,
            success:function(res){
                if(res.status=='success'){
                    $('.error_msg').hide();
                    $('.info_msg').show();
                    $('.info_msg').html(res.message);
                    $(location).attr('href', BASE_URL + res.go_to)
                    redirect(res.go_to);
                }else{
                    $('.info_msg').hide();
                    $('.error_msg').show();
                    $('.error_msg').html(res.message);
                }
            }            
        });
    }
    });
    <?php } ?>
    
    
    });
     
      
    //$('#r_type').click(function(e){
    $(document).on('click', '#r_type', function(){
      var id =  $(this).val();
      var attr_val = parseInt($(this).attr("attr_val"));
      //alert(id);
      //return false;
      if(id==1){
        $(".service_col_"+attr_val).hide();
        $(".requirement_col_"+attr_val).show();
      }else if(id==2){
        $(".requirement_col_"+attr_val).hide();
        $(".service_col_"+attr_val).show();
      }
    $(".select2").select2();
    });
    
      
    //$('#r_type').click(function(e){
    $(document).on('click', '#publish', function(){
      var id =  $(this).val();
      //alert(id);
      //return false;
      if(id==1){
        $(".select_neg_col").hide();
      }else if(id==2){
        $(".select_neg_col").show();
      }
     $(".select2").select2();
    });
    //$(".no_display_col").hide();
    
    
  
   //change the product active or in active status
    $("#form_bidding_button").click(function(event){
        event.preventDefault();// using this page stop being refreshing
        var r_id = $('#id').val();
        var notifi_text = $('#notifi_text').val();
        //alert(notifi_text);
//        return false;
        $.ajax({
            url: BASE_URL + 'buyer/requirements/change_status_to_bidding',
            method: 'POST',
            data: {
                r_id: r_id,
                notifi_text: notifi_text
            },
            success: function (response) {
                //alert(status)
                if(response == "1"){
                        $('.add_to_bidding').removeAttr('status');
                        $('.add_to_bidding').attr('status','0');
                        $('.add_to_bidding').removeClass('btn-warning');
                        $('.add_to_bidding').addClass('btn-success');
                        $('.add_to_bidding span').empty();
                        $('.post_bidd_div').hide();
                        $('.add_to_bidding span').html('Project Added to Bidding');
                        $('.info_msg_bid').show();
                        $('.info_msg_bid').html('Project added to bidding successfully.');
                        $('.info_msg_bid').fadeOut(8000);
                        $('.post_bidd_div').remove();
                    } else {
                        bootbox.alert('Something went wrogn!.');
                    }
            }
        });
    });
    
    //select_item
    $(document).on("click", "#check_tob" ,function(){
        if ($(this).is(':checked')){
            $('#budget').removeAttr('readonly');
        }else{
            $('#budget').attr('readonly','readonly');
            //$('#budget').val('');
        }
    });
    
    //select_item
    $(document).on("change", "#tob_process" ,function(){
        //alert($(this).val());
        if ($(this).val()=='3'){
            $('#budget_div').show();
        }else{
            $('#budget_div').hide();
            $('#budget').val('');
        }
    });
    
    //$("#form_bidding").validate({
//        rules: {
//            notifi_text: {
//                required: true
//            }
//        },
//        
//        messages: {				
//            notifi_text: {					
//                required: "Please enter product name."
//             }
//        },
//        submitHandler: function(form){
//        event.preventDefault();// using this page stop being refreshing
//        var formData = new FormData();
//        formData.append('payment_terms', $('#payment_terms').val());
//        
//        //alert(attr_val+'attr_id');
//        formData.append('submit', $("#submit").attr('val'));
//        $.ajax({
//            url:form.action,
//            type:form.method,
//            async:false,
//            cache:false,
//            contentType:false,
//            processData:false,
//            dataType:"json",
//            //data:$(form).serialize(),
//            data: formData,
//            success:function(res){
//                if(res.status=='success'){
//                    $('.error_msg').hide();
//                    $('.info_msg').show();
//                    $('.info_msg').html(res.message);
//                    $(location).attr('href', BASE_URL + res.go_to)
//                    redirect(res.go_to);
//                }else{
//                    $('.info_msg').hide();
//                    $('.error_msg').show();
//                    $('.error_msg').html(res.message);
//                }
//            }            
//        });
//    }
//    });
    $('#budget_div').hide();
  </script>
</body>
</html>