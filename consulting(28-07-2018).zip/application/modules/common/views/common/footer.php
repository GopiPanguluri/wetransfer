<footer class="main-footer">
    <div class="pull-right hidden-xs">
      <b>Powered by</b> <a target="_blank" href="<?php echo $this->config->item('powered_by_link'); ?>"><?php echo $this->config->item('powered_by'); ?></a> 
    </div>
    <strong> <?php echo $this->config->item('Copyrights'); ?> <a href="<?php echo base_url(''); ?>" target="_blank"><?php echo $this->config->item('site_title'); ?></a>.</strong> All rights
    reserved.
</footer>