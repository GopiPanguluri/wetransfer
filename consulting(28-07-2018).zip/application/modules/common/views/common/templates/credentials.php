Dear <?php echo $name; ?>,<br /><br />

We�re getting you all setup right now.<br />

And now that you�re a part of the Entourage, I want to get started on the right foot � because I want you to skip the struggles I felt to learn all this.<br />

You�ll literally shave 10 YEARS off your learning curve, in the first TEN minutes of this.<br />

So your first step?<br />

Click here, and get started on your Step 1.<br />

Talk Soon,<br />
Colin

P.S. Here�s Your Course Login :
<b>Link: </b> <?php echo base_url(); ?>.<br />
<b>Username: </b> <?php echo $username; ?>.<br />
<b>Password: </b> <?php echo $Password; ?>.<br />
<!--i>Regards,</i><br /-->
<?php //echo 'WE Transfer team.'; ?>
<?php //exit;  ?>