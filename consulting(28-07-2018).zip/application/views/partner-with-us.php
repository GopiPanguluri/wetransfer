<!-- PAGE TITLE 1 -->
	<div class="page-title-bg indent-header-1 page-main-content m-bot-40">
		<div class="container">
			<div class="page-title-container">
				<div class="row">
					<div class="col-md-12">
						<h2>PARTNER WITH US</h2>
					</div>
				</div>
				<div class="row">
					<div class="col-md-12">
						<ul class="breadcrumb">
							<li><a class="a-invert" href="/">HOME</a></li>
							<li class="active">PARTNER WITH US</li>
						</ul>
					</div>
				</div>
			</div>
		</div>
	</div>

<!-- COTENT CONTAINER -->
	<div class="container">

		<div class="row">
            <div class="col-md-12" style="text-align: center;">
				<img src="<?php echo config_item('frontend_assets');?>images/content/partner-with-us.png" alt="Ipsum"/>
			</div>                
	<!-- STYLE 1 -->	
			<div class="col-md-12 feature-box3">
			    <p>&nbsp;</p> 
				<p>Since Construction industry is the most dynamic of all industries , almost whatever product we see at our home or offices becomes a part of the industry along with many raw materials like cements , sands , bricks etc. Thus there is a huge palate of business that is still untapped and together by partnering with us , we can tap the virgin market effectively.</p>
                <h4>1. Be a Franchisee</h4>
                <p>We have a  franchisee system in place where in we support and encourage the franchisees to grow along with us thus inculcating a win win senario for both . Franchisee is given all the rights to utilise our brand name , website and is being supported technically and legally.</p>
                <p>Franchisee are given Unique Identification Numbers and separate login in our website  to track and monitor performance , business and payout on a monthly basis thus maintaining transparency at all times.</p>
                <h5>Main responsibilies of Franchisees will be as follows</h5>
                <ul>
                    <li>Product listing</li>
                    <li>Service provider / contractor listing</li>
                    <li>Generating advertisements</li>
                    <li>Listing of  apartments / villas / houses</li>                                                                                                                
                </ul>
                <h4>2.  Be a Freelancee</h4>                                                
                <p>We have a unique programm where we encourage people to earn handsomely just by refering .Upon login an individual is given an Unique Identification Number (UIN) and while refering on mentioning the UIN our website registers and payouts are made to the individual on a monthly basis.</p>
                <p>&nbsp;</p>
                <h5>Roles and responsibilities.</h5>
                <ul>
                    <li>Listing of products & contractors in the website .</li>
                    <li>Listing of apartments /villas/houses</li>
                    <li>Generate advertisments.</li>
                    <li>Listing of products & contractors in the website .</li>                                                                                
                </ul>
                <p>Payout model in referal program is 30 % of revenue.</p>                                
			</div>            
		</div>
<!-- PROMO -->		
	</div>
<div id="footer-offset" class="m-top-80">
<!-- NEWS LETTER -->
	<!-- <div class="title-lines-container">
		<div class="container">

			<div class="nl-container nl-lines" >
				<div class="nl-icon-container-bg" >
					<div class="nl-icon-container" >
						<span aria-hidden="true" class="icon_mail_alt main-menu-icon"></span>
					</div>
				</div>
				<div class="nl-main-container-bg" >
					<div class="nl-main-container clearfix" >
						<div class="nl-caption">NEWSLETTER</div>
						<div id="mc_embed_signup" class="nl-form-container clearfix">

							<form action="http://abcgomel.us9.list-manage.com/subscribe/post-json?u=ba37086d08bdc9f56f3592af0&amp;id=e38247f7cc&amp;c=?" method="post" id="mc-embedded-subscribe-form" name="mc-embedded-subscribe-form" class="newsletterform validate" target="_blank" novalidate>   EDIT THIS ACTION URL (add "post-json?u" instead of "post?u" and appended "&amp;c=?" to the end of this URL)
								
								<input type="email" value="" name="EMAIL" class="email nl-email-input" id="mce-EMAIL" placeholder="YOUR EMAIL HERE" required>
								
		<div style="position: absolute; left: -5000px;"><input type="text" name="b_ba37086d08bdc9f56f3592af0_e38247f7cc" tabindex="-1" value=""></div>
		
								<input type="submit" value="SIGN UP" name="subscribe" id="mc-embedded-subscribe" class="nl-button">
								
							</form>
							<div id="notification_container"  ></div>
							
						</div>
					</div>
				</div>
			</div>
			
		</div>
	</div>	 -->
<style>
.promo-1-bg-before:before {
    border-bottom: 0px solid #fff;
}
</style>